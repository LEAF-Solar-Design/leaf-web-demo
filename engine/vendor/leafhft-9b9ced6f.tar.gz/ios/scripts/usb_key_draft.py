"""Deliver an existing key as an encrypted USB draft. Never activates Kalshi.

Run under control/device_access.py for the exact device. No secret arguments,
plaintext files, clipboard, UI typing, or dynamic provider errors are emitted.
"""
import argparse
import asyncio
import base64
import json
import logging
import secrets
import time
import urllib.request
import uuid
from pathlib import Path

INFO = b"Kashbot HFT USB import v1"
BUNDLE = "com.evan.leafhft"
DIRECTORY = "/Documents/KashbotPairing"


def decode_request(data, now=None):
    if len(data) > 4096:
        raise ValueError("request size")
    request = json.loads(data)
    request_id = request["request_id"]
    if request.get("version") != 1 or str(uuid.UUID(request_id)) != request_id:
        raise ValueError("request version or id")
    now = time.time() if now is None else now
    expiry = request["expires_at"]
    if type(expiry) is not int or not now < expiry <= now + 121:
        raise ValueError("request expired or invalid")
    public = base64.b64decode(request["public_key"], validate=True)
    if len(public) != 65 or public[0] != 4:
        raise ValueError("recipient key")
    from cryptography.hazmat.primitives.asymmetric import ec
    ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), public)
    return request


def encrypt_payload(request, payload):
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec, rsa
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    identifier, pem = payload["key_id"], payload["private_key_pem"]
    if not isinstance(identifier, str) or not identifier.strip() or len(identifier.encode()) > 256:
        raise ValueError("key id")
    if not isinstance(pem, str) or len(pem.encode()) > 65536:
        raise ValueError("PEM size")
    private = serialization.load_pem_private_key(pem.encode(), password=None)
    if not isinstance(private, rsa.RSAPrivateKey):
        raise ValueError("RSA required")
    plain = json.dumps({"key_id": identifier, "private_key_pem": pem}, separators=(",", ":")).encode()
    if len(plain) > 65536:
        raise ValueError("payload size")
    recipient = ec.EllipticCurvePublicKey.from_encoded_point(
        ec.SECP256R1(), base64.b64decode(request["public_key"], validate=True))
    sender = ec.generate_private_key(ec.SECP256R1())
    binding = request["request_id"].encode()
    key = HKDF(algorithm=hashes.SHA256(), length=32, salt=binding, info=INFO).derive(sender.exchange(ec.ECDH(), recipient))
    nonce = secrets.token_bytes(12)
    encrypted = AESGCM(key).encrypt(nonce, plain, binding)
    public = sender.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    return json.dumps({"version": 1, "request_id": request["request_id"],
                       "sender_public_key": base64.b64encode(public).decode(),
                       "nonce": base64.b64encode(nonce).decode(),
                       "ciphertext": base64.b64encode(encrypted).decode()}, separators=(",", ":")).encode()


def verify_lease(args):
    with urllib.request.urlopen("http://127.0.0.1:8787/api/device-queue", timeout=5) as response:
        queue = json.load(response)
    target = next(x for x in queue["catalog"] if x["id"] == args.device)
    if target["detail"] != args.udid:
        raise ValueError("device mismatch")
    if not any(args.device in x.get("devices", []) and x.get("owner") == args.owner for x in queue["active"]):
        raise ValueError("device lease absent")


async def bounded_request(afc):
    path = DIRECTORY + "/request.json"
    info = await afc.stat(path)
    if info.get("st_ifmt") != "S_IFREG" or int(info["st_size"]) > 4096:
        raise ValueError("request not a bounded regular file")
    handle = await afc.fopen(path, "r")
    try:
        return await afc.fread(handle, 4097)
    finally:
        await afc.fclose(handle)


async def transfer(args):
    # Suppress third-party debug logging before any named secret is resolved.
    logging.disable(logging.CRITICAL)
    from pymobiledevice3.lockdown import create_using_usbmux
    from pymobiledevice3.services.house_arrest import HouseArrestService
    import boto3
    from botocore.config import Config
    verify_lease(args)
    lockdown = await create_using_usbmux(serial=args.udid, connection_type="USB", autopair=False)
    async with lockdown:
        async with await HouseArrestService.create(lockdown, BUNDLE, documents_only=True) as afc:
            directory = await afc.stat(DIRECTORY)
            if directory.get("st_ifmt") != "S_IFDIR":
                raise ValueError("pairing directory")
            raw = await bounded_request(afc)
            request = decode_request(raw)
            if args.check:
                return {"result": "READY", "secret_resolved": False, "activated": False}
            session = boto3.Session(profile_name=args.profile, region_name="us-east-1")
            config = Config(connect_timeout=5, read_timeout=10, retries={"max_attempts": 1})
            identity = session.client("sts", config=config).get_caller_identity()
            if identity["Account"] != args.account or identity["Arn"].endswith(":root"):
                raise ValueError("AWS identity mismatch")
            value = session.client("secretsmanager", config=config).get_secret_value(
                SecretId=args.secret_name, VersionId=args.secret_version)
            envelope = encrypt_payload(request, json.loads(value["SecretString"]))
            # Recheck the device, request, and expiry after provider work.
            verify_lease(args)
            if await bounded_request(afc) != raw:
                raise ValueError("pairing request changed")
            decode_request(raw)
            temporary = DIRECTORY + "/envelope.pending"
            await afc.set_file_contents(temporary, envelope)
            try:
                await afc.rename(temporary, DIRECTORY + "/envelope.json")
            except Exception:
                await afc.rm(temporary)
                raise
            return {"result": "CIPHERTEXT_DELIVERED", "secret_resolved": True,
                    "activated": False, "draft_consumption": "UNVERIFIED",
                    "device": args.device, "bundle": BUNDLE}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--udid", required=True)
    parser.add_argument("--device", required=True, choices=["ios-iphone", "ios-ipad"])
    parser.add_argument("--owner", required=True)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--profile")
    parser.add_argument("--account")
    parser.add_argument("--secret-name")
    parser.add_argument("--secret-version")
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if not args.check and not all((args.profile, args.account, args.secret_name, args.secret_version)):
        parser.error("named secret, immutable version, profile and expected account required")
    try:
        receipt = asyncio.run(asyncio.wait_for(transfer(args), timeout=90))
    except Exception as error:
        # Provider and crypto exception messages can contain inputs. Never print them.
        receipt = {"result": "FAIL", "error_type": type(error).__name__, "activated": False}
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))
    return 1 if receipt["result"] == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(main())
