# Kashbot existing-key connection

This optional setup path moves an existing Kalshi key from a trusted computer
into masked Settings drafts. It does not create a key, save credentials, or
activate Kalshi. The operator taps **Import key** for those last two actions.

## Operator flow

1. Connect and unlock the iPhone, then open Kashbot Settings.
2. Tap **Receive key from computer**. Keep Settings open during the transfer.
3. When **Key ready** appears, tap **Import key** to save and connect.

Transfers expire after two minutes. Cancel, backgrounding, or leaving Settings
invalidates the request. Invalid transfers preserve previous drafts. Leaving
Settings clears drafts. Existing saved credentials are unchanged by transfer.

## Desktop replay

Install the helper dependencies `cryptography`, `boto3`, and `pymobiledevice3`.
Use `control/device_access.py` from the shared device rail to acquire the exact
device. The helper verifies its owner and UDID against that queue before work
and again before delivery. Supply references only, never credential values.

Run `python ios/scripts/usb_key_draft.py --help` for arguments. Start with
`--check`, which reads only the public pairing request and does not contact AWS.
For transfer, supply the credential's name and immutable version, AWS profile,
expected account, exact UDID, queue device and owner, and a local receipt path.
The helper refuses root AWS identities and other accounts.

The receipt distinguishes `READY`, `CIPHERTEXT_DELIVERED`, and `FAIL`.
Delivery does not prove that the phone accepted the draft or connected.
Verify **Key ready** using a synthetic transfer before resolving a real key.
Never automate the real-key **Import key** action in the test ladder.

## Data boundary

Only a public request and an encrypted envelope cross iOS Documents through
paired USB `VendDocuments`. Observation history stays in Application Support.
The phone keeps the ephemeral P256 recipient key in memory. Both ends derive
an AES-256-GCM key with ECDH and HKDF-SHA256; the request UUID binds HKDF salt
and authenticated data. Files contain no plaintext key, key ID or PEM.
The pairing folder is excluded from backup and uses complete file protection.

The trusted computer can read the existing secret in-process. No values enter
arguments, logs, screenshots, clipboard, receipts, or plaintext temporary files.
Do not enable SDK debug logging or capture Settings after a real-key import.
Receipt errors intentionally omit provider exception text.

## Verification

`python ios/scripts/test_usb_key_draft.py` exercises synthetic encryption,
wrong-recipient/request and tamper rejection, bounds and expiry.
`USBKeyDraftReceiverTests` exercises native decrypt/consume, cancellation,
replay, invalid keys, bounds and symlink rejection. Test keys are generated
in memory. `python ios/scripts/verify_core.py` checks the existing boundaries.
Native compile, physical USB acceptance and TestFlight installation must be
recorded separately. Source tests are not physical-transfer proof.
