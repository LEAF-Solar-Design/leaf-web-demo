#!/usr/bin/env python3
"""Windows controller for the existing Mac-local, source-bound physical rung."""
from __future__ import annotations

import argparse
import io
import json
import os
import platform
from pathlib import Path, PurePosixPath
import re
import shlex
import subprocess
import tarfile
import time
from datetime import datetime, timezone


FIELDS = {
    "host", "remote_project", "ipa", "ipa_receipt", "ipa_sha256",
    "ipa_receipt_sha256", "wda_artifact", "wda_receipt", "wda_sha256",
    "wda_receipt_sha256", "wda_runner_bundle_id",
}
REMOTE = r'''
import json, pathlib, subprocess, sys
data = json.load(sys.stdin)
c = data['config']
project = pathlib.Path(c['remote_project']).resolve(strict=True)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=project, stderr=subprocess.DEVNULL, text=True).strip()
if git('rev-parse', 'HEAD') != data['sha'] or git('status', '--porcelain', '--untracked-files=no', '--', 'ios', 'scripts/device-walk'):
    raise SystemExit(3)
if sys.platform != 'darwin':
    raise SystemExit(3)
# Existing server-owned exact-root binding must pass before any device action.
from cadwalk_core.mcps.ios_walk import physical_device
directory = project / '_marathon/evidence' / data['run']
check = physical_device.recipe_preflight(
    str(project), 'leafhft-read-only', data['sha'], c['ipa_sha256'],
    c['ipa_receipt_sha256'], c['wda_sha256'], c['wda_receipt_sha256'],
    str(directory), str(directory / 'receipt.json'), False)
if check.get('ok') is not True:
    print(json.dumps({'preflight': False}))
    raise SystemExit(0)
root = project / '_marathon/evidence' / data['run']
argv = [sys.executable, str(project / 'ios/scripts/device_rung.py'),
        '--source-sha', data['sha'], '--evidence-root', str(root)]
for key in sorted(set(c) - {'host', 'remote_project'}):
    argv += ['--' + key.replace('_', '-'), c[key]]
# Never expose subprocess stdout, WDA responses, or provider error details.
completed = subprocess.run(argv, cwd=project, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
receipts = list(root.glob('*/rung-4.json'))
if len(receipts) != 1:
    raise SystemExit(4)
receipt = json.loads(receipts[0].read_text())
paths = [receipts[0]]
if receipt.get('physicalReceipt'):
    physical = pathlib.Path(receipt['physicalReceipt']).resolve(strict=True)
    base = (project / '_marathon/evidence').resolve()
    physical.relative_to(base)
    paths += [p for p in physical.parent.rglob('*') if p.is_file()]
relative = []
for path in paths:
    path = path.resolve(strict=True)
    path.relative_to((project / '_marathon/evidence').resolve())
    relative.append(path.relative_to(project).as_posix())
print(json.dumps({'preflight': True, 'exit': completed.returncode, 'receipt': receipt,
                  'paths': relative, 'receipt_path': receipts[0].relative_to(project).as_posix()}))
'''
DOWNLOAD = r'''
import json, pathlib, sys, tarfile
data = json.load(sys.stdin)
project = pathlib.Path(data['project']).resolve(strict=True)
base = (project / '_marathon/evidence').resolve(strict=True)
with tarfile.open(fileobj=sys.stdout.buffer, mode='w|') as archive:
    for relative in data['paths']:
        path = (project / relative).resolve(strict=True)
        path.relative_to(base)
        if not path.is_file():
            raise SystemExit(3)
        archive.add(path, arcname=relative, recursive=False)
'''


def validate(config):
    if not isinstance(config, dict) or set(config) != FIELDS:
        raise ValueError('Config must contain only the documented nonsecret fields')
    if any(not isinstance(value, str) or not value or any(ord(char) < 32 for char in value)
           for value in config.values()):
        raise ValueError('Invalid config value')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', config['host']):
        raise ValueError('Use an existing SSH alias')
    for key in FIELDS:
        if key.endswith('sha256') and not re.fullmatch(r'[0-9a-f]{64}', config[key]):
            raise ValueError('Invalid artifact digest')
    for key in ('remote_project', 'ipa', 'ipa_receipt', 'wda_artifact', 'wda_receipt'):
        if not PurePosixPath(config[key]).is_absolute():
            raise ValueError('Remote paths must be absolute')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', config['wda_runner_bundle_id']):
        raise ValueError('Invalid WDA bundle')
    return config


def ssh(host, script, payload, timeout):
    return subprocess.run(
        ['ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
         '-o', 'ConnectTimeout=10', host, 'python3 -c ' + shlex.quote(script)],
        input=json.dumps(payload).encode(), stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL, timeout=timeout,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--evidence-root', type=Path, default=Path('C:/tmp/leafhft-ios/evidence')
                        if os.name == 'nt' else Path.home() / 'leafhft-ios/evidence')
    args = parser.parse_args()
    started = time.monotonic()
    now = datetime.now(timezone.utc)
    target = args.evidence_root / now.strftime('%Y-%m-%d') / 'rung-4.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    project = Path(__file__).resolve().parents[2]
    record = {'rung': 4, 'result': 'UNAVAILABLE', 'exitCode': 2, 'basis': 'confirmed',
              'host': platform.node(),
              'command': 'python ios/scripts/test_device.py --config JSON',
              'budgetSeconds': 480, 'screenshots': [], 'xcresult': None}
    dispatched = False
    try:
        sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project, text=True).strip()
        record.update(sourceSha=sha, source_sha=sha)
        if args.config is None or not args.config.is_file():
            record['reason'] = 'Nonsecret Mac/artifact config is required. Open the Mac lid, connect and unlock the iPhone, and trust the computer.'
            return 2
        config = validate(json.loads(args.config.read_text(encoding='utf-8')))
        if subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no', '--',
                                    'ios', 'scripts/device-walk'], cwd=project, text=True).strip():
            record['reason'] = 'Commit the tracked iOS and device driver source before running.'
            return 2
        record['host'] = config['host']
        payload = {'config': config, 'sha': sha, 'run': 'windows-' + now.strftime('%Y%m%dT%H%M%S%fZ')}
        dispatched = True
        result = ssh(config['host'], REMOTE, payload, 600)
        if result.returncode:
            raise RuntimeError('Remote outcome is unknown')
        envelope = json.loads(result.stdout)
        if envelope.get('preflight') is not True:
            record['reason'] = 'Existing Mac rail exact-root binding is unavailable. No device action started.'
            return 2
        remote = envelope['receipt']
        if remote.get('sourceSha') != sha:
            raise ValueError('Remote receipt source mismatch')
        terminal_copy = target.parent / (payload['run'] + '-remote-rung-4.json')
        terminal_copy.write_text(json.dumps(remote, indent=2) + '\n', encoding='utf-8')
        record['remoteReceipt'] = str(terminal_copy)
        paths = envelope['paths']
        if not isinstance(paths, list) or not paths or any(
            not isinstance(p, str) or not p.startswith('_marathon/evidence/')
            or '\\' in p or ':' in p or '..' in PurePosixPath(p).parts for p in paths
        ):
            raise ValueError('Unsafe evidence path')
        download = ssh(config['host'], DOWNLOAD, {'project': config['remote_project'], 'paths': paths}, 120)
        if download.returncode:
            raise RuntimeError('Evidence transfer failed')
        local = target.parent / payload['run']
        with tarfile.open(fileobj=io.BytesIO(download.stdout), mode='r:') as archive:
            members = archive.getmembers()
            if sorted(m.name for m in members) != sorted(paths) or any(not m.isfile() for m in members):
                raise ValueError('Unexpected evidence archive')
            for member in members:
                destination = local.joinpath(*PurePosixPath(member.name).parts)
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(archive.extractfile(member).read())
        record.update(remote)
        record['remoteReceipt'] = str(local / envelope['receipt_path'])
        def local_path(value):
            relative = PurePosixPath(value).relative_to(PurePosixPath(config['remote_project']))
            return str(local.joinpath(*relative.parts))
        record['screenshots'] = [local_path(p) for p in remote.get('screenshots', [])]
        if remote.get('physicalReceipt'):
            record['physicalReceipt'] = local_path(remote['physicalReceipt'])
        record['command'] = 'python ios/scripts/test_device.py --config JSON'
        if envelope['exit'] != remote.get('exitCode'):
            raise ValueError('Remote exit and receipt disagree')
    except Exception as error:
        record.update(result='UNAVAILABLE', exitCode=2,
                      reason=('Remote outcome or evidence is incomplete; inspect retained Mac receipts before any rerun. '
                              if dispatched else 'Config or source preflight failed. ') + type(error).__name__)
    finally:
        elapsed = round(time.monotonic() - started, 3)
        record.update(controller_seconds=elapsed, duration_seconds=elapsed,
                      number=elapsed, unit='seconds', budget_seconds=480)
        if record.get('result') == 'PASS' and elapsed >= 480:
            record.update(result='FAIL', exitCode=1, reason='Windows install and walk exceeded eight minutes.')
        record['exit_code'] = record['exitCode']
        target.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'result': record['result'], 'receipt': str(target)}))
    return record['exitCode']


if __name__ == '__main__':
    raise SystemExit(main())
