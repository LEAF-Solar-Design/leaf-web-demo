"""Ops proof: independent outage retries and failure reruns, followed by an all-leg verdict."""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import verify_ops_overhaul as verify  # noqa: E402

ZERO_LOG = """$ ssh mac-mini cd ~/leafhft-verify/ios && xcodebuild test -only-testing:LeafHFTUITests/BooksUITests
Testing started
Executed 0 tests, with 0 failures (0 unexpected) in 0.000 (0.001) seconds
** TEST FAILED **
exit 65
LOG C:/tmp/kashbot-ops-proof/BooksUITests-light.log
"""
PASS_LOG = """$ ssh mac-mini xcodebuild test -only-testing:LeafHFTUITests/BooksUITests
Test Case '-[LeafHFTUITests.BooksUITests testBooks]' passed (4.1 seconds).
Executed 4 tests, with 0 failures (0 unexpected) in 20.0 (20.1) seconds
** TEST SUCCEEDED **
exit 0
LOG C:/tmp/kashbot-ops-proof/BooksUITests-light.log
"""
FAILED_LOG = """$ ssh mac-mini xcodebuild test -only-testing:LeafHFTUITests/BooksUITests
BooksUITests.swift:42: error: -[LeafHFTUITests.BooksUITests testBooks] : assertion failed
BooksUITests.swift:43: error: -[LeafHFTUITests.BooksUITests testBooks] : assertion failed
Test Case '-[LeafHFTUITests.BooksUITests testBooks]' failed (3.2 seconds).
Executed 5 tests, with 1 failure (0 unexpected) in 30.0 (30.1) seconds
** TEST FAILED **
exit 65
LOG C:/tmp/kashbot-ops-proof/BooksUITests-light.log
"""
KILLED_LOG = """$ ssh mac-mini xcodebuild test -only-testing:LeafHFTUITests/BooksUITests
Test Case '-[LeafHFTUITests.BooksUITests testBooks]' failed (9.0 seconds).
BooksUITests.swift:0: error: -[LeafHFTUITests.BooksUITests testBooks] : Test crashed with signal kill.
Executed 3 tests, with 1 failure (0 unexpected) in 30.0 (30.1) seconds
** TEST FAILED **
exit 65
LOG C:/tmp/kashbot-ops-proof/BooksUITests-light.log
"""
UNIT_THEN_ZERO_UI_LOG = """$ ssh mac-mini xcodebuild test -only-testing:LeafHFTTests
Executed 120 tests, with 0 failures (0 unexpected) in 12.0 (12.1) seconds
** TEST SUCCEEDED **
exit 0
$ ssh mac-mini xcodebuild test -only-testing:LeafHFTUITests/FixtureUITests
Executed 0 tests, with 0 failures (0 unexpected) in 0.000 (0.001) seconds
** TEST FAILED **
exit 65
"""


def make_run(tmp_path: Path, label: str = "BooksUITests-light") -> dict:
    runs = [run for run in verify.run_plan(tmp_path, "iPhone 17", "iPhone 17e") if run["run"] == label]
    assert runs, label
    return runs[0]


class Script:
    """A fake mac_verify: each call writes the next transcript to the run's log and returns its exit."""

    def __init__(self, *outcomes: tuple[int, str], pngs: int = 1):
        self.outcomes = list(outcomes)
        self.pngs = pngs
        self.calls: list[str] = []

    def __call__(self, run: dict, environment: dict) -> tuple[int, str]:
        self.calls.append(run["run"])
        code, output = self.outcomes.pop(0)
        Path(run["log"]).parent.mkdir(parents=True, exist_ok=True)
        Path(run["log"]).write_text(output, encoding="utf-8")
        folder = Path(run["screenshots"])
        folder.mkdir(parents=True, exist_ok=True)
        for index in range(self.pngs if code == 0 else 0):
            (folder / f"shot-{index}.png").write_bytes(b"png")
        return code, output


@pytest.fixture
def reboots(monkeypatch):
    calls: list[str] = []

    def reboot(name: str) -> bool:
        calls.append(name)
        return True

    monkeypatch.setattr(verify, "reboot_simulator", reboot)
    return calls


def no_contention_probe():
    raise AssertionError("contention probe must not run for this transcript")


def test_run_plan_drops_no_tests(tmp_path):
    assert not hasattr(verify, "BASELINE_SKIPS")
    runs = verify.run_plan(tmp_path, "iPhone 17", "iPhone 17e")
    assert all("--skip" not in run["command"] for run in runs)
    assert "--unit" in runs[0]["command"]


def test_run_plan_isolates_engine_settings_per_appearance(tmp_path):
    source = (Path(__file__).resolve().parents[3]
              / "ios/LeafHFTUITests/EngineSettingsUITests.swift").read_text(encoding="utf-8")
    tests = re.findall(r"\bfunc\s+(test\w+)\s*\(", source)
    assert set(tests) == set(verify.PER_TEST_CLASSES["EngineSettingsUITests"])
    assert tuple(tests) == verify.PER_TEST_CLASSES["EngineSettingsUITests"]
    runs = verify.run_plan(tmp_path, "iPhone 17", "iPhone 17e")
    assert len(runs) == 17 - 2 + 24 == 39
    expected_labels = ["FixtureUITests-light"]
    for appearance in ("light", "dark"):
        for name in verify.UI_CLASSES:
            if name in verify.PER_TEST_CLASSES:
                expected_labels += [f"{name}-{appearance}-{test}"
                                    for test in verify.PER_TEST_CLASSES[name]]
            else:
                expected_labels.append(f"{name}-{appearance}")
        assert not any(run["run"] == f"EngineSettingsUITests-{appearance}" for run in runs)
        class_runs = [run for run in runs if run["test_class"] == "EngineSettingsUITests"
                      and run["appearance"] == appearance]
        assert len(class_runs) == len(tests)
        for test in tests:
            matching = [run for run in class_runs
                        if [run["command"][index + 1]
                            for index, option in enumerate(run["command"]) if option == "--only"] == [test]]
            assert len(matching) == 1
            isolated = matching[0]
            assert isolated["run"] == f"EngineSettingsUITests-{appearance}-{test}"
            assert isolated["content_size"] == "medium"
            assert isolated["simulator"] == "iPhone 17"
            command = isolated["command"]
            assert "--no-sync" in command and "--unit" not in command
            for option, value in (("--ui", "EngineSettingsUITests"), ("--appearance", appearance),
                                  ("--content-size", "medium"),
                                  ("--log", isolated["log"])):
                assert command[command.index(option) + 1] == value
            assert isolated["screenshots"] == str(tmp_path / isolated["run"])
            assert isolated["log"] == str(tmp_path / f"{isolated['run']}.log")
    expected_labels += [f"OpsLayoutUITests-{appearance}-ax" for appearance in ("light", "dark")]
    assert [run["run"] for run in runs] == expected_labels
    for key in ("run", "log", "screenshots"):
        assert len({run[key] for run in runs}) == len(runs)


def test_run_plan_requests_screenshots_only_from_tests_that_take_them(tmp_path):
    source = (Path(__file__).resolve().parents[3]
              / "ios/LeafHFTUITests/EngineSettingsUITests.swift").read_text(encoding="utf-8")
    bodies = {}
    for match in re.finditer(r"\bfunc\s+(test\w+)\s*\(\s*\)\s*\{", source):
        start = match.end()
        depth = 1
        for index in range(start, len(source)):
            if source[index] == "{":
                depth += 1
            elif source[index] == "}":
                depth -= 1
            if depth == 0:
                bodies[match.group(1)] = source[start:index]
                break
        else:
            pytest.fail(f"Unclosed test body: {match.group(1)}")
    assert set(bodies) == set(verify.PER_TEST_CLASSES["EngineSettingsUITests"])
    no_screenshots = {name for name, body in bodies.items() if "screenshot(" not in body}
    assert set(verify.NO_SCREENSHOT_TESTS["EngineSettingsUITests"]) == no_screenshots
    runs = verify.run_plan(tmp_path, "iPhone 17", "iPhone 17e")
    omitted = []
    for run in runs:
        command = run["command"]
        test = command[command.index("--only") + 1] if "--only" in command else None
        if run["test_class"] == "EngineSettingsUITests" and test in no_screenshots:
            assert run["screenshots_expected"] is False
            assert "--screenshots" not in command
            assert run["screenshots"] not in command
            omitted.append((test, run["appearance"]))
        else:
            assert run["screenshots_expected"] is True
            assert command[command.index("--screenshots") + 1] == run["screenshots"]
    assert set(omitted) == {(test, appearance) for test in no_screenshots
                            for appearance in ("light", "dark")}
    assert len(omitted) == 2 * len(no_screenshots)


def test_class_counts_reads_the_class_own_summary():
    assert verify.class_counts(ZERO_LOG) == (0, 0)
    assert verify.class_counts(FAILED_LOG) == (5, 1)
    assert verify.class_counts(PASS_LOG) == (4, 0)
    assert verify.class_counts(UNIT_THEN_ZERO_UI_LOG) == (0, 0)
    assert verify.class_counts("no summary here\nexit 65\n") is None
    assert verify.test_count(UNIT_THEN_ZERO_UI_LOG) == 120


def test_zero_tests_retried_twice_then_unavailable(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path)
    script = Script((65, ZERO_LOG), (65, ZERO_LOG), (65, ZERO_LOG))
    monkeypatch.setattr(verify, "execute", script)
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    verify.score_class(run, {})
    assert script.calls == ["BooksUITests-light"] * 3
    assert reboots == ["iPhone 17"] * 2
    assert run["status"] == "unavailable"
    assert run["unavailable_reason"] == verify.ZERO_TESTS
    assert run["unavailable_log"] == run["log"]
    assert run["retries"] == 2
    assert (run["executed"], run["passed"], run["failed"]) == (0, 0, 0)
    assert run["exit_code"] == 65
    first = Path(run["attempt_logs"][0])
    assert first.name == "BooksUITests-light.attempt1.log"
    assert first.read_text(encoding="utf-8") == ZERO_LOG


def test_zero_tests_then_pass_scores_passed(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path)
    monkeypatch.setattr(verify, "execute", Script((65, ZERO_LOG), (0, PASS_LOG)))
    verify.score_class(run, {})
    assert reboots == ["iPhone 17"]
    assert run["status"] == "passed"
    assert run["retries"] == 1
    assert (run["executed"], run["passed"], run["failed"]) == (4, 4, 0)
    assert run["unavailable_reason"] is None


@pytest.mark.parametrize("code, output, reason", [
    (76, "mini allocator: lease lost\n", "lease lost"),
    (65, "Simulator device FAILED TO LAUNCH com.evan.leafhft\n", "failed to launch"),
])
def test_harness_outage_then_pass(tmp_path, monkeypatch, reboots, code, output, reason):
    run = make_run(tmp_path)
    script = Script((code, output), (0, PASS_LOG))
    monkeypatch.setattr(verify, "execute", script)
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    verify.score_class(run, {})
    assert len(script.calls) == 2
    assert reboots == ["iPhone 17"]
    assert run["status"] == "passed"
    assert run["retries"] == 1
    assert run["harness_outages"] == [reason]
    assert run["unavailable_reason"] is None
    assert (run["executed"], run["passed"], run["failed"]) == (4, 4, 0)
    assert [Path(path).read_text(encoding="utf-8") for path in run["attempt_logs"]] == [output, PASS_LOG]


@pytest.mark.parametrize("message", verify.INFRA_MESSAGES)
def test_pass_with_outage_text_scores_passed_without_retry(tmp_path, monkeypatch, reboots, message):
    run = make_run(tmp_path)
    script = Script((0, message + "\n" + PASS_LOG))
    monkeypatch.setattr(verify, "execute", script)
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    verify.score_class(run, {})
    assert len(script.calls) == 1
    assert reboots == []
    assert run["status"] == "passed"
    assert run["retries"] == 0
    assert run["harness_outages"] == []
    assert run["unavailable_reason"] is None
    assert (run["executed"], run["passed"], run["failed"]) == (4, 4, 0)


@pytest.mark.parametrize("message", verify.INFRA_MESSAGES)
def test_assertion_failure_with_outage_text_stays_failed_after_rerun(tmp_path, monkeypatch,
                                                                     reboots, message):
    run = make_run(tmp_path)
    script = Script(*[(65, message + "\n" + FAILED_LOG)] * 2)
    monkeypatch.setattr(verify, "execute", script)
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    verify.score_class(run, {})
    assert len(script.calls) == 2
    assert reboots == ["iPhone 17"]
    assert run["status"] == "failed"
    assert run["retries"] == 0
    assert run["harness_outages"] == []
    assert run["unavailable_reason"] is None
    assert (run["executed"], run["passed"], run["failed"]) == (5, 4, 1)


def test_timeout_exhausts_retries_and_keeps_three_logs(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path)
    outputs = [f"TIMEOUT after {seconds}s\n" for seconds in (100, 200, 300)]
    script = Script(*[(124, output) for output in outputs])
    monkeypatch.setattr(verify, "execute", script)
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    verify.score_class(run, {})
    assert len(script.calls) == 3
    assert reboots == ["iPhone 17"] * 2
    assert run["status"] == "unavailable"
    assert run["unavailable_reason"] == verify.HARNESS_OUTAGE
    assert run["unavailable_log"] == run["log"]
    assert run["retries"] == 2
    assert run["harness_outages"] == ["timeout after"] * 3
    assert [Path(path).name for path in run["attempt_logs"]] == [
        "BooksUITests-light.attempt1.log", "BooksUITests-light.attempt2.log", "BooksUITests-light.log",
    ]
    assert [Path(path).read_text(encoding="utf-8") for path in run["attempt_logs"]] == outputs


@pytest.mark.parametrize("code, output, reason", [
    (75, "", "exit_75"),
    (76, "", "exit_76"),
    (124, "", "exit_124"),
    (4, "", "exit_4"),
    (65, "LEASE UNAVAILABLE", "lease unavailable"),
    (65, "Queue Timeout", "queue timeout"),
])
def test_harness_outage_signals(code, output, reason):
    assert verify.harness_outage_reason(code, output, None, None) == reason


def test_harness_outage_then_assertion_failure_stays_failed(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path)
    script = Script((76, "lease lost\n"), (65, FAILED_LOG), (65, FAILED_LOG))
    monkeypatch.setattr(verify, "execute", script)
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    verify.score_class(run, {})
    assert len(script.calls) == 3
    assert reboots == ["iPhone 17"] * 2
    assert run["status"] == "failed"
    assert run["retries"] == 1
    assert run["harness_outages"] == ["lease lost"]
    assert (run["executed"], run["failed"]) == (5, 1)


def test_zero_tests_on_first_run_uses_ui_stage(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path, "FixtureUITests-light")
    monkeypatch.setattr(verify, "execute", Script(*[(65, UNIT_THEN_ZERO_UI_LOG)] * 3))
    verify.score_class(run, {})
    assert run["status"] == "unavailable"
    assert run["test_count"] == 120
    assert run["executed"] == 0


def test_executed_failure_twice_scores_failed(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path)
    script = Script((65, FAILED_LOG), (65, FAILED_LOG))
    monkeypatch.setattr(verify, "execute", script)
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    verify.score_class(run, {})
    assert len(script.calls) == 2
    assert reboots == ["iPhone 17"]
    assert run["status"] == "failed"
    assert run["retries"] == 0
    assert (run["executed"], run["passed"], run["failed"]) == (5, 4, 1)
    assert run["unavailable_reason"] is None


def test_executed_failure_then_pass_records_flaky_rerun(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path)
    script = Script((65, FAILED_LOG), (0, PASS_LOG))
    monkeypatch.setattr(verify, "execute", script)
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    verify.score_class(run, {})
    assert len(script.calls) == 2
    assert reboots == ["iPhone 17"]
    assert run["status"] == "passed" and run["flaky_rerun"] is True
    assert run["first_failures"] == 1
    assert run["first_failed_tests"] == ["LeafHFTUITests.BooksUITests testBooks"]
    assert run["retries"] == 0 and run["harness_outages"] == []
    assert (run["executed"], run["passed"], run["failed"]) == (4, 4, 0)
    assert [Path(path).name for path in run["attempt_logs"]] == ["BooksUITests-light.attempt1.log"]
    assert Path(run["attempt_logs"][0]).read_text(encoding="utf-8") == FAILED_LOG
    assert Path(run["log"]).read_text(encoding="utf-8") == PASS_LOG


def test_outage_then_failure_then_pass_uses_independent_retries(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path)
    script = Script((65, ZERO_LOG), (65, FAILED_LOG), (0, PASS_LOG))
    monkeypatch.setattr(verify, "execute", script)
    verify.score_class(run, {})
    assert len(script.calls) == 3
    assert reboots == ["iPhone 17"] * 2
    assert run["status"] == "passed" and run["flaky_rerun"] is True
    assert run["retries"] == 1 and run["harness_outages"] == [verify.ZERO_TESTS]
    assert run["first_failures"] == 1
    assert [Path(path).name for path in run["attempt_logs"]] == [
        "BooksUITests-light.attempt1.log", "BooksUITests-light.attempt2.log", "BooksUITests-light.log",
    ]
    assert [Path(path).read_text(encoding="utf-8") for path in run["attempt_logs"]] == [
        ZERO_LOG, FAILED_LOG, PASS_LOG,
    ]


def test_failure_rerun_can_retry_two_outages(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path)
    script = Script((65, FAILED_LOG), (65, ZERO_LOG), (65, ZERO_LOG), (0, PASS_LOG))
    monkeypatch.setattr(verify, "execute", script)
    verify.score_class(run, {})
    assert len(script.calls) == 4
    assert reboots == ["iPhone 17"] * 3
    assert run["status"] == "passed" and run["flaky_rerun"] is True
    assert run["retries"] == verify.INFRA_RETRIES
    assert [Path(path).read_text(encoding="utf-8") for path in run["attempt_logs"]] == [
        FAILED_LOG, ZERO_LOG, ZERO_LOG, PASS_LOG,
    ]


@pytest.mark.parametrize("names", [[], [f"testFailure{index}" for index in range(12)]])
def test_first_failed_tests_optional_and_bounded(tmp_path, monkeypatch, reboots, names):
    run = make_run(tmp_path)
    errors = "".join(f"error: -[LeafHFTUITests.BooksUITests {name}] : failed\n"
                     for name in names for _ in range(2))
    output = errors + "Executed 12 tests, with 12 failures\nexit 65\n"
    monkeypatch.setattr(verify, "execute", Script((65, output), (0, PASS_LOG)))
    verify.score_class(run, {})
    assert run["status"] == "passed" and run["first_failures"] == 12
    if names:
        assert run["first_failed_tests"] == [f"LeafHFTUITests.BooksUITests {name}" for name in names[:10]]
    else:
        assert "first_failed_tests" not in run


def test_zero_tests_with_other_exit_is_failed(tmp_path, monkeypatch, reboots):
    run = make_run(tmp_path)
    monkeypatch.setattr(verify, "execute", Script((70, ZERO_LOG)))
    verify.score_class(run, {})
    assert reboots == []
    assert run["status"] == "failed"


@pytest.mark.parametrize("probe, status, reason", [
    (True, "unavailable", verify.CONTENDED),
    (False, "failed", None),
    (None, "failed", None),
])
def test_signal_kill_contended_only_when_another_xcodebuild_runs(tmp_path, monkeypatch, reboots,
                                                                 probe, status, reason):
    run = make_run(tmp_path)
    monkeypatch.setattr(verify, "execute", Script((65, KILLED_LOG)))
    monkeypatch.setattr(verify, "other_xcodebuild_running", lambda: probe)
    verify.score_class(run, {})
    assert reboots == []
    assert run["status"] == status
    assert run["unavailable_reason"] == reason
    assert (run["executed"], run["failed"]) == (3, 1)


def test_other_xcodebuild_running_reads_ps(monkeypatch):
    def fake(stdout: str, code: int = 0):
        return lambda command, timeout: subprocess.CompletedProcess(["ssh"], code, stdout, "")

    monkeypatch.setattr(verify, "remote", fake("/sbin/launchd\n/Applications/Xcode.app/Contents/Developer/usr/bin/xcodebuild\n"))
    assert verify.other_xcodebuild_running() is True
    monkeypatch.setattr(verify, "remote", fake("/sbin/launchd\n/usr/bin/xcodebuild-helper\nbash\n"))
    assert verify.other_xcodebuild_running() is False
    monkeypatch.setattr(verify, "remote", fake("", 255))
    assert verify.other_xcodebuild_running() is None
    monkeypatch.setattr(verify, "remote", lambda command, timeout: None)
    assert verify.other_xcodebuild_running() is None


def test_reboot_simulator_shuts_down_then_boots(monkeypatch):
    seen: list[str] = []

    def fake(command: str, timeout: int):
        seen.append(command)
        return subprocess.CompletedProcess(["ssh"], 0, "", "")

    monkeypatch.setattr(verify, "remote", fake)
    assert verify.reboot_simulator("iPhone 17") is True
    assert "simctl shutdown 'iPhone 17'" in seen[0]
    assert seen[0].index("shutdown") < seen[0].index("simctl boot")
    monkeypatch.setattr(verify, "remote", lambda command, timeout: None)
    assert verify.reboot_simulator("iPhone 17") is False


@pytest.mark.parametrize("statuses, expected", [
    (["passed", "passed"], ("passed", 0)),
    (["passed", "unavailable"], ("unavailable", 3)),
    (["unavailable", "failed", "planned"], ("failed", 1)),
    (["passed", "evidence missing"], ("evidence missing", 3)),
])
def test_verdict_exit_codes(statuses, expected):
    assert verify.verdict([{"status": status} for status in statuses]) == expected


def run_main(tmp_path: Path, monkeypatch, script: Script, labels: tuple[str, ...]) -> tuple[int, dict]:
    out = tmp_path / "proof"
    plan = verify.run_plan

    def small_plan(directory, simulator, ax_simulator):
        return [run for run in plan(directory, simulator, ax_simulator) if run["run"] in labels]

    monkeypatch.setattr(verify, "run_plan", small_plan)
    monkeypatch.setattr(verify, "source_sha", lambda: "a" * 40)
    monkeypatch.setattr(verify, "execute", script)
    monkeypatch.setattr(sys, "argv", ["verify_ops_overhaul.py", "--out", str(out)])
    code = verify.main()
    return code, json.loads((out / "summary.json").read_text(encoding="utf-8"))


LABELS = ("BooksUITests-light", "EnginesUITests-light")


@pytest.mark.parametrize("label, expected_status, expected_code", [
    (f"EngineSettingsUITests-{appearance}-{test}", "passed", 0)
    for test in verify.NO_SCREENSHOT_TESTS["EngineSettingsUITests"]
    for appearance in ("light", "dark")
] + [
    ("EnginesUITests-light", "evidence missing", 3),
    ("-".join(("EngineSettingsUITests", "light", "testHelp" + "ExpandsInline")), "evidence missing", 3),
])
def test_main_zero_pngs_respects_screenshot_expectation(tmp_path, monkeypatch, reboots,
                                                      label, expected_status, expected_code):
    script = Script((0, PASS_LOG), (0, PASS_LOG))

    def execute(run, environment):
        script.pngs = 0 if run["run"] == label else 1
        return script(run, environment)

    code, summary = run_main(tmp_path, monkeypatch, execute, (LABELS[0], label))
    assert code == expected_code
    assert summary["status"] == expected_status
    assert summary["exit_code"] == expected_code
    normal, target = summary["runs"]
    assert normal["status"] == "passed" and normal["png_count"] == 1
    assert target["status"] == expected_status and target["png_count"] == 0
    assert target["exit_code"] == 0
    assert reboots == []


def test_main_unavailable_exit_3_and_keeps_running(tmp_path, monkeypatch, reboots, capsys):
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    script = Script((65, ZERO_LOG), (65, ZERO_LOG), (65, ZERO_LOG), (0, PASS_LOG))
    code, summary = run_main(tmp_path, monkeypatch, script, LABELS)
    assert code == 3
    assert summary["status"] == "unavailable" and summary["exit_code"] == 3
    books, engines = summary["runs"]
    assert books["status"] == "unavailable" and books["retries"] == 2
    assert books["unavailable_reason"] == verify.ZERO_TESTS
    for key in ("executed", "passed", "failed", "retries", "unavailable_reason"):
        assert key in books and key in engines
    assert engines["status"] == "passed" and engines["executed"] == 4
    table = capsys.readouterr().out
    assert "Unavailable" in table and verify.ZERO_TESTS in table


def test_main_failed_exit_1(tmp_path, monkeypatch, reboots, capsys):
    monkeypatch.setattr(verify, "other_xcodebuild_running", no_contention_probe)
    script = Script((65, FAILED_LOG), (65, FAILED_LOG), (0, PASS_LOG))
    code, summary = run_main(tmp_path, monkeypatch, script, LABELS)
    assert code == 1
    assert summary["status"] == "failed" and summary["exit_code"] == 1
    assert summary["runs"][0]["status"] == "failed"
    assert summary["runs"][1]["status"] == "passed"
    assert script.calls == [LABELS[0], LABELS[0], LABELS[1]]
    assert summary["flaky_legs"] == []
    output = capsys.readouterr().out
    assert f"FAILED: {LABELS[0]}" in output
    assert output.count("Unavailable") == 1


def test_main_lists_only_flaky_legs(tmp_path, monkeypatch, reboots):
    script = Script((65, FAILED_LOG), (0, PASS_LOG), (0, PASS_LOG))
    code, summary = run_main(tmp_path, monkeypatch, script, LABELS)
    assert code == 0 and summary["status"] == "passed"
    assert summary["flaky_legs"] == [LABELS[0]]
    assert summary["runs"][0]["flaky_rerun"] is True
    assert not summary["runs"][1].get("flaky_rerun")


def test_main_passed_exit_0(tmp_path, monkeypatch, reboots):
    code, summary = run_main(tmp_path, monkeypatch, Script((0, PASS_LOG), (0, PASS_LOG)), LABELS)
    assert code == 0
    assert summary["status"] == "passed"
    assert [run["retries"] for run in summary["runs"]] == [0, 0]
    assert reboots == []
