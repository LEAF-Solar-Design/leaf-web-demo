"""Serial fixture proof for the ops overhaul. No live credentials or runner writes.

--dry-run prints the same run plan without syncing or launching native tests.
--sim overrides all runs; otherwise LEAFHFT_SIM_NAME (iPhone 17 by default)
is used for regular runs and iPhone 17e for accessibility layout proof.

A harness outage is not a feature failure. A class with a harness outage,
including xcodebuild exit 65 having executed zero tests (the bundle never
launched), gets its simulator rebooted and up to TWO reruns; exhausted
outages score it `unavailable`. A class
killed by signal kill while another xcodebuild runs on the Mac scores
`unavailable` (simulator_contended). Exit codes: 0 passed, 1 failed,
3 unavailable or evidence missing, 2 setup error. Real test failures get ONE
rerun after a simulator reboot, independently of harness-outage retries;
a clean rerun records the leg as flaky. Every leg runs before the final verdict.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[2]
VERIFY = ROOT / "ios/scripts/mac_verify.py"
MAC_HOST = os.environ.get("LEAFHFT_MAC_HOST", "mac-mini")
EXIT_PASSED, EXIT_FAILED, EXIT_UNAVAILABLE, EXIT_EVIDENCE_MISSING = 0, 1, 3, 3
XCODEBUILD_TEST_FAILED = 65
INFRA_RETRIES = 2
FAILURE_RERUNS = 1
HARNESS_OUTAGE = "harness_outage"
INFRA_EXIT_CODES = (75, 76, 124, 4)
INFRA_MESSAGES = ("failed to launch", "lease lost", "lease unavailable", "queue timeout", "timeout after")
ZERO_TESTS = "zero_tests_executed"
CONTENDED = "simulator_contended"
KILLED = re.compile(r"signal kill|signal 9\b|SIGKILL", re.IGNORECASE)
UI_CLASSES = (
    "AccountUITests", "BooksUITests", "EnginesUITests", "EngineHistoryUITests",
    "EngineSettingsUITests", "EngineLabUITests", "MushyStudioUITests",
)
# One xcodebuild pass per test; long passes of this class hang on the Mac mini.
PER_TEST_CLASSES = {"EngineSettingsUITests": (
    "testSearchFiltersAndClears",
    "testUntouchedConfigurationNamesItsPrerequisites",
    "testNoConfigurableAccountExplainsDisabledPicker",
    "testSearchResultsFitAboveKeyboardAndKeepContext",
    "testHelpExpandsInline",
    "testAccountOverrideAndRestore",
    "testValidationWarningBlocksReview",
    "testSavedPerOrderAboveTenPercentCannotSubmitInEitherScope",
    "testSavedValueAboveMaximumExplainsAndSetsDraftOnly",
    "testReviewDiscardRejectionAndApply",
    "testProfitDialsStayVisibleInEngineList",
    "testEngineListScreenshot",
)}
# These per-test runs do not create screenshot attachments.
NO_SCREENSHOT_TESTS = {"EngineSettingsUITests": (
    "testSearchFiltersAndClears",
    "testUntouchedConfigurationNamesItsPrerequisites",
    "testNoConfigurableAccountExplainsDisabledPicker",
    "testSearchResultsFitAboveKeyboardAndKeepContext",
)}


def run_plan(out: Path, simulator: str, ax_simulator: str) -> list[dict]:
    selections = [("FixtureUITests", "light", "medium")]
    selections += [(name, appearance, "medium")
                   for appearance in ("light", "dark") for name in UI_CLASSES]
    selections += [("OpsLayoutUITests", appearance, "accessibility-extra-large")
                   for appearance in ("light", "dark")]
    runs = []
    for index, (name, appearance, size) in enumerate(selections):
        ax = size == "accessibility-extra-large"
        for test in PER_TEST_CLASSES.get(name, (None,)):
            label = f"{name}-{appearance}" + ("-ax" if ax else "")
            if test is not None:
                label += f"-{test}"
            screenshots = out / label
            log = out / f"{label}.log"
            command = [sys.executable, str(VERIFY)]
            if index == 0:
                command += ["--unit"]
            else:
                command += ["--no-sync"]
            command += ["--ui", name]
            if index == 0:
                command += ["--only", "testFourScreensAndFrozenFixtureValues"]
            elif test is not None:
                command += ["--only", test]
            command += ["--appearance", appearance, "--content-size", size]
            screenshots_expected = test is None or test not in NO_SCREENSHOT_TESTS.get(name, ())
            if screenshots_expected:
                command += ["--screenshots", str(screenshots)]
            command += ["--log", str(log)]
            runs.append(dict(run=label, test_class=name, simulator=ax_simulator if ax else simulator,
                             appearance=appearance, content_size=size, screenshots=str(screenshots),
                             screenshots_expected=screenshots_expected,
                             log=str(log), command=command, exit_code=None, test_count=None,
                             executed=None, passed=None, failed=None, retries=0, harness_outages=[],
                             unavailable_reason=None, png_count=0, status="planned"))
    return runs


def test_count(log: str) -> int | None:
    """Take the final aggregate in each remote stage, not repeated suite totals."""
    counts = []
    for stage in re.split(r"^exit -?\d+\s*$", log, flags=re.MULTILINE):
        totals = re.findall(r"Executed (\d+) tests?\b", stage)
        swift = re.findall(r"Test run with (\d+) tests? .*passed", stage)
        if totals or swift:
            counts.append(int(totals[-1]) if totals else 0)
            if swift:
                counts[-1] += int(swift[-1])
    return sum(counts) if counts else None


def class_counts(log: str) -> tuple[int, int] | None:
    """(executed, failures) of the class's own xcodebuild: the last summary in the last stage."""
    for stage in reversed(re.split(r"^exit -?\d+\s*$", log, flags=re.MULTILINE)):
        totals = re.findall(r"Executed (\d+) tests?(?:, with (\d+) failures?)?", stage)
        if totals:
            executed, failures = totals[-1]
            return int(executed), int(failures or 0)
    return None


def remote(command: str, timeout: int) -> subprocess.CompletedProcess | None:
    """One bounded ssh call to the Mac; None when ssh could not run or timed out."""
    try:
        return subprocess.run(["ssh", "-o", "BatchMode=yes", MAC_HOST, "bash -c " + shlex.quote(command)],
                              capture_output=True, text=True, encoding="utf-8", errors="replace",
                              timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None


def reboot_simulator(name: str) -> bool:
    sim = shlex.quote(name)
    result = remote(f"xcrun simctl shutdown {sim} >/dev/null 2>&1; "
                    f"xcrun simctl boot {sim} && xcrun simctl bootstatus {sim}", 300)
    return result is not None and result.returncode == 0


def other_xcodebuild_running() -> bool | None:
    """Our xcodebuild has exited, so any xcodebuild left on the Mac is another lane's; None if unreadable."""
    result = remote("ps -axo comm=", 60)
    if result is None or result.returncode != 0:
        return None
    return any(line.strip().rsplit("/", 1)[-1] == "xcodebuild" for line in result.stdout.splitlines())


def execute(run: dict, environment: dict) -> tuple[int, str]:
    """Run one mac_verify invocation; return its exit code and its log (stdout if no log)."""
    result = subprocess.run(run["command"], cwd=ROOT, env=environment, capture_output=True,
                            text=True, encoding="utf-8", errors="replace", check=False)
    print(result.stdout, end="", flush=True)
    if result.stderr:
        print(result.stderr, file=sys.stderr, end="", flush=True)
    log_path = Path(run["log"])
    output = log_path.read_text(encoding="utf-8", errors="replace") if log_path.exists() else result.stdout
    return result.returncode, output


def harness_outage_reason(code: int, output: str, executed: int | None,
                          failures: int | None) -> str | None:
    """Identify an outage of the test harness rather than an assertion failure."""
    if code == 0:
        return None
    if executed is not None and executed > 0 and failures is not None and failures > 0:
        return None
    lowered = output.lower()
    for message in INFRA_MESSAGES:
        if message in lowered:
            return message
    if code in INFRA_EXIT_CODES:
        return f"exit_{code}"
    if code == XCODEBUILD_TEST_FAILED and executed == 0:
        return ZERO_TESTS
    return None


def score_class(run: dict, environment: dict) -> None:
    """Run one class with separate outage retries and a test-failure rerun."""
    failure_reruns = 0
    attempt = 0
    while True:
        attempt += 1
        try:
            code, output = execute(run, environment)
        except OSError as error:
            run.update(exit_code=2, error=str(error), status="failed")
            return
        counts = class_counts(output)
        executed, failures = counts if counts else (None, None)
        run.update(exit_code=code, test_count=test_count(output), executed=executed,
                   passed=None if executed is None else max(executed - failures, 0), failed=failures)
        outage = harness_outage_reason(code, output, executed, failures)
        if outage:
            run.setdefault("harness_outages", []).append(outage)
        test_failure = executed is not None and executed > 0 and failures is not None and failures > 0
        # Signal kills retain their existing contention classification.
        retry_failure = test_failure and not KILLED.search(output) and failure_reruns < FAILURE_RERUNS
        retry_outage = outage and run["retries"] < INFRA_RETRIES
        if not retry_outage and not retry_failure:
            break
        # Keep each earlier attempt's log; mac_verify truncates --log on every run.
        log_path = Path(run["log"])
        if log_path.exists():
            previous = log_path.with_name(f"{log_path.stem}.attempt{attempt}{log_path.suffix}")
            log_path.replace(previous)
            run.setdefault("attempt_logs", []).append(str(previous))
        if retry_outage:
            run["retries"] += 1
            retry_reason = f"harness outage {outage}"
        else:
            failure_reruns += 1
            run["first_failures"] = failures
            failed_tests = list(dict.fromkeys(re.findall(
                r"error: -\[(LeafHFTUITests\.\w+ \w+)\]", output)))[:10]
            if failed_tests:
                run["first_failed_tests"] = failed_tests
            retry_reason = f"test failures {failures}"
        run["simulator_rebooted"] = reboot_simulator(run["simulator"])
        print(f"RETRY: {run['run']} {retry_reason} (exit {code}); simulator "
              f"{run['simulator']} rebooted={run['simulator_rebooted']}", flush=True)
    if run["retries"] and Path(run["log"]).exists():
        run.setdefault("attempt_logs", []).append(run["log"])
    if outage:
        reason = ZERO_TESTS if outage == ZERO_TESTS else HARNESS_OUTAGE
        run.update(status="unavailable", unavailable_reason=reason, unavailable_log=run["log"])
    elif code == 0 and not test_failure:
        run["status"] = "passed"
        if failure_reruns:
            run["flaky_rerun"] = True
    elif KILLED.search(output) and (contended := other_xcodebuild_running()):
        run.update(status="unavailable", unavailable_reason=CONTENDED, unavailable_log=run["log"],
                   contention_check=contended)
    else:
        run["status"] = "failed"


def verdict(runs: list[dict]) -> tuple[str, int]:
    statuses = {run["status"] for run in runs}
    if "failed" in statuses:
        return "failed", EXIT_FAILED
    if "unavailable" in statuses:
        return "unavailable", EXIT_UNAVAILABLE
    if "evidence missing" in statuses:
        return "evidence missing", EXIT_EVIDENCE_MISSING
    return "passed", EXIT_PASSED


def png_count(directory: str) -> int:
    return sum(1 for path in Path(directory).rglob("*")
               if path.is_file() and path.suffix.lower() == ".png")


def print_table(runs: list[dict]) -> None:
    print(f"{'Run':44} {'Exit':>6} {'Tests':>7} {'PNGs':>6} {'Retries':>7}  {'Unavailable':20}  Status")
    for run in runs:
        code = "-" if run["exit_code"] is None else str(run["exit_code"])
        count = "unknown" if run["test_count"] is None else str(run["test_count"])
        reason = run.get("unavailable_reason") or "-"
        print(f"{run['run']:44} {code:>6} {count:>7} {run['png_count']:>6} {run.get('retries', 0):>7}"
              f"  {reason:20}  {run['status']}")


def source_sha() -> str | None:
    try:
        git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True,
                             text=True, encoding="utf-8", errors="replace", check=False)
    except OSError as error:
        print(f"Cannot record source sha: {error}", file=sys.stderr)
        return None
    sha = git.stdout.strip()
    if git.returncode or not re.fullmatch(r"[0-9a-fA-F]{40}", sha):
        print("Cannot record source sha: git rev-parse HEAD failed", file=sys.stderr)
        return None
    return sha


def main() -> int:
    # Windows consoles default to cp1252; xcodebuild output carries glyphs outside it.
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sim", metavar="NAME", help="override the simulator for every run")
    parser.add_argument("--out", type=Path, default=Path("C:/tmp/kashbot-ops-proof"))
    parser.add_argument("--dry-run", action="store_true", help="print plan only; no native runs")
    args = parser.parse_args()
    out = args.out.resolve()
    simulator = args.sim or os.environ.get("LEAFHFT_SIM_NAME", "iPhone 17")
    ax_simulator = args.sim or "iPhone 17e"
    runs = run_plan(out, simulator, ax_simulator)
    sha = source_sha()
    if sha is None:
        return 2
    summary = dict(source_sha=sha, proof="fixture", dry_run=args.dry_run,
                   simulator=simulator, accessibility_simulator=ax_simulator, runs=runs, flaky_legs=[])
    if args.dry_run:
        # A plan must not overwrite a real summary or create fake evidence.
        print(json.dumps(summary, indent=2))
        return 0
    out.mkdir(parents=True, exist_ok=True)

    def save_summary(status: str, code: int | None) -> None:
        summary.update(status=status, exit_code=code)
        summary["flaky_legs"] = [run["run"] for run in runs if run.get("flaky_rerun")]
        (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    save_summary("running", None)
    for run in runs:
        folder = Path(run["screenshots"])
        # Keep prior evidence, but never count it as output from this invocation.
        if folder.exists():
            previous = folder.with_name(f"{folder.name}.previous-{time.time_ns()}")
            folder.rename(previous)
            run["previous_screenshots"] = str(previous)
        folder.mkdir(parents=True)
        environment = os.environ.copy()
        environment["LEAFHFT_SIM_NAME"] = run["simulator"]
        run["status"] = "running"
        save_summary("running", None)
        print(f"Running {run['run']} on {run['simulator']}", flush=True)
        score_class(run, environment)
        run["png_count"] = png_count(run["screenshots"])
        if run["status"] == "failed":
            print(f"FAILED: {run['run']} (exit {run['exit_code']}); log: {run['log']}")
        if run["status"] == "unavailable":
            print(f"UNAVAILABLE: {run['run']} ({run['unavailable_reason']}); log: {run['log']}")
        save_summary("running", None)

    for run in runs:
        run["png_count"] = png_count(run["screenshots"])
        if run["status"] == "passed" and run["screenshots_expected"] and not run["png_count"]:
            run["status"] = "evidence missing"
            print(f"evidence missing: {run['run']} ({run['screenshots']})")
    status, code = verdict(runs)
    save_summary(status, code)
    print_table(runs)
    print(f"Summary: {out / 'summary.json'}")
    return code


if __name__ == "__main__":
    sys.exit(main())
