"""Structural fallback only. Native compilation and signer tests belong to the Mac."""
from pathlib import Path
import argparse
import json
import plistlib
import re
import runpy
import shlex
import shutil
import subprocess
import sys
import os
import platform
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / "ios/Packages/LeafHFTCore"
EXPECTED = [
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/ExitLedger.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/ExitLedgerTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/exits.json",
    "ios/LeafHFT/Views/Monitor/ExitsCard.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/EntryCalibration.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/EntryCalibrationTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/calibration.json",
    "ios/LeafHFT/Views/Monitor/CalibrationCard.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/AttemptFunnel.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/AttemptFunnelTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/attempt-funnel.json",
    "ios/LeafHFT/Views/Monitor/AttemptFunnelCard.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/EngineWorkshop.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/EngineWorkshopTests.swift",
    "ios/LeafHFT/Views/EngineWorkshopTools.swift",
    "ios/LeafHFTTests/MushyPrefillTests.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/EngineLab.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/EngineLabTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/engine-lab.json",
    "ios/LeafHFT/Views/EngineLabView.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/EngineModels.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/PolicyBounds.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/EngineModelsTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/engines.json",
    "ios/LeafHFT/Views/EnginesView.swift",
    "ios/LeafHFTTests/EnginesClientTests.swift",
    "ios/project.yml",
    "ios/LeafHFT/Info.plist",
    "ios/LeafHFT/PrivacyInfo.xcprivacy",
    "ios/LeafHFT/LeafHFTApp.swift",
    "ios/LeafHFT/Model/AppState.swift",
    "ios/LeafHFT/Net/KalshiClient.swift",
    "ios/LeafHFT/Net/DashboardClient.swift",
    "ios/LeafHFT/Net/AccountEnrollmentFlow.swift",
    "ios/LeafHFT/Net/AccountRunnerControlFlow.swift",
    "ios/LeafHFTTests/AccountRunnerControlFlowTests.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/BindingModels.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/BindingModelsTests.swift",
    "ios/LeafHFTTests/AccountEnrollmentFlowTests.swift",
    "ios/LeafHFT/Net/DevicePairingFlow.swift",
    "ios/LeafHFT/PushRegistrar.swift",
    "ios/LeafHFT/Net/PushClient.swift",
    "ios/LeafHFTTests/PushRegistrarTests.swift",
    "ios/LeafHFTTests/AutopilotClientTests.swift",
    "ios/LeafHFT/Store/ObservationStore.swift",
    "ios/LeafHFT/Views/AccountView.swift",
    "ios/LeafHFT/Views/BooksView.swift",
    "ios/LeafHFT/Views/SettingsView.swift",
    "ios/LeafHFTTests/KalshiClientTests.swift",
    "ios/LeafHFTTests/DashboardClientTests.swift",
    "ios/LeafHFTTests/DevicePairingFlowTests.swift",
    "ios/LeafHFTTests/ObservationStoreTests.swift",
    "ios/scripts/verify-ios.sh",
    "ios/LeafHFT/Auth/KalshiSigner.swift",
    "ios/LeafHFT/Auth/KeychainStore.swift",
    "ios/LeafHFTTests/SignerTests.swift",
    "ios/scripts/verify_core.py",
    "ios/Packages/LeafHFTCore/Package.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/Money.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/AccountModels.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/AccountHistory.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/ChartReduction.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/TelemetryModels.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/BindingCondition.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/Freshness.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/KalshiGETEndpoint.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/SigningMessage.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/PEMDecoder.swift",
    "ios/Packages/LeafHFTCore/Sources/LeafHFTCore/PairingModels.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/MoneyTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/AccountModelsTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/AccountHistoryTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/ChartReductionTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/TelemetryModelsTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/BindingConditionTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/FreshnessTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/EndpointAndSigningTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/PEMDecoderTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/PairingModelsTests.swift",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/balance.json",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/positions.json",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/fills.json",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/settlements.json",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/books.json",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/probes.json",
    "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/signature-fixture.json"
]

def check(condition, name):
    if not condition:
        raise ValueError(name)
    print("PASS " + name)


TUNING_VECTORS = ROOT / "ios/LeafHFTTests/Fixtures/tuning-inbox-v1-vectors.json"
TUNING_V2_VECTORS = ROOT / "ios/LeafHFTTests/Fixtures/tuning-inbox-v2-vectors.json"
TUNING_WIRE = ROOT / "ios/LeafHFTTests/Fixtures/tuning-wire-v1.json"
TUNING_INBOX_TESTS = ROOT / "ios/LeafHFTTests/TuningInboxTests.swift"
# Split so this file, which the scan also reads, never holds the run itself.
TUNING_BAD_UUID = "00000000-0000-4000-8000-" + "00000000000G"
# Only these public vector fields may carry base64 or key=value runs.
TUNING_VECTOR_PUBLIC_KEYS = frozenset({
    "spki_b64", "public_key_b64", "bytes", "plan_b64", "grid_b64",
    "signature_b64", "grid_sig_b64", "decision_ascii", "grid_message_ascii",
})
TUNING_WIRE_PUBLIC_KEYS = frozenset({"plan_b64", "grid_b64", "grid_sig_b64", "assertion_b64"})
TUNING_V2_VECTOR_PUBLIC_KEYS = frozenset({"plan_b64"})


def is_high_entropy_run(value):
    """Apply the shared secret-scan predicate to a matched run."""
    if re.fullmatch(r"[0-9a-fA-F]+", value):
        return False
    if re.fullmatch(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", value):
        # A fixed UUID is non-secret test data, not credential material.
        return False
    if re.fullmatch(r"n[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", value):
        # The regex starts after the backslash in a Swift escaped newline.
        return False
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
        # Long Swift and Python identifiers are source labels, not secrets.
        return False
    classes = (r"[A-Z]", r"[a-z]", r"[0-9]", r"[+_=-]")
    return sum(bool(re.search(pattern, value)) for pattern in classes) >= 3


def validate_tuning_fixture(text, schema, public_keys, name, *, require_test_only=True,
                            exact_v2_plan_path=False):
    """Scan every JSON key and string in a public tuning fixture."""
    def unique_keys(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(name + " carry a duplicate key: " + key)
            result[key] = value
        return result

    data = json.loads(text, object_pairs_hook=unique_keys)
    runs = re.compile(r"[A-Za-z0-9+_=-]{32,}")

    def non_public_runs(value):
        return (run for run in runs.findall(re.sub(r"\s", " ", value))
                if is_high_entropy_run(run))

    pending = [(data, None, ())]
    while pending:
        node, owning_key, path = pending.pop()
        if isinstance(node, list):
            pending.extend((value, owning_key, path + (index,)) for index, value in enumerate(node))
        elif isinstance(node, dict):
            for key, value in node.items():
                if re.search(r"private|secret|seed|password|token", key, re.IGNORECASE):
                    raise ValueError(name + " carry a secret-shaped field: " + key)
                if any(non_public_runs(key)):
                    raise ValueError(name + " carry a high-entropy run in a key: " + key)
                pending.append((value, key, path + (key,)))
        elif isinstance(node, str):
            is_public = owning_key in public_keys
            if exact_v2_plan_path:
                is_public = (isinstance(data, dict) and isinstance(data.get("vectors"), list)
                             and len(path) == 3 and path[0] == "vectors"
                             and isinstance(path[1], int) and path[2] == "plan_b64"
                             and isinstance(data["vectors"][path[1]], dict))
            if not is_public and any(non_public_runs(node)):
                raise ValueError(name + " carry a high-entropy run outside public keys: "
                                 + (owning_key if owning_key is not None else "<root>"))
    if not (isinstance(data, dict) and data.get("schema") == schema
            and (not require_test_only or data.get("test_only") is True)):
        raise ValueError(name + (" are not the test-only public set" if require_test_only
                                 else " are not the public set"))


def project_yaml(text):
    try:
        import yaml
    except ImportError:
        # Strict parser for the block mappings, lists, and scalar subset used here.
        # Unsupported YAML fails closed; installing PyYAML permits broader syntax.
        rows = []
        for line in text.splitlines():
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            if "\t" in line:
                raise ValueError("Tabs in YAML")
            rows.append((len(line) - len(line.lstrip()), line.strip()))

        def scalar(value):
            if value.startswith('"'):
                return json.loads(value)
            if value.startswith("[") and value.endswith("]"):
                return [scalar(item.strip()) for item in value[1:-1].split(",") if item.strip()]
            if value in ("true", "false"):
                return value == "true"
            if any(token in value for token in ("{", "}", "&", "*", "#")):
                raise ValueError("Unsupported YAML scalar")
            return value

        def block(index, indent):
            is_list = rows[index][1].startswith("- ")
            result = [] if is_list else {}
            while index < len(rows) and rows[index][0] == indent:
                value = rows[index][1]
                if is_list:
                    if not value.startswith("- "):
                        raise ValueError("Mixed YAML container")
                    value = value[2:]
                    index += 1
                    if ":" in value:
                        key, raw = value.split(":", 1)
                        item = {key: scalar(raw.strip())} if raw.strip() else {key: None}
                        if index < len(rows) and rows[index][0] > indent:
                            continuation, index = block(index, rows[index][0])
                            if not isinstance(continuation, dict):
                                raise ValueError("Invalid YAML list mapping")
                            item.update(continuation)
                        result.append(item)
                    else:
                        result.append(scalar(value))
                else:
                    if ":" not in value:
                        raise ValueError("Missing YAML mapping separator")
                    key, raw = value.split(":", 1)
                    if key in result:
                        raise ValueError("Duplicate YAML key")
                    index += 1
                    if raw.strip():
                        result[key] = scalar(raw.strip())
                    elif index < len(rows) and rows[index][0] > indent:
                        result[key], index = block(index, rows[index][0])
                    else:
                        result[key] = None
            return result, index

        result, consumed = block(0, 0)
        if consumed != len(rows):
            raise ValueError("Invalid YAML indentation")
        return result
    else:
        return yaml.safe_load(text)


def swift_braces_and_spaces(text, path):
    """Check code braces, including interpolation, without parsing Swift syntax."""
    def fail(message):
        raise ValueError(message + ": " + str(path))

    if "\t" in text:
        fail("Tabs in Swift source")

    size = len(text)

    def block_comment(index):
        depth = 1
        index += 2
        while index < size:
            if text.startswith("/*", index):
                depth += 1
                index += 2
            elif text.startswith("*/", index):
                depth -= 1
                index += 2
                if depth == 0:
                    return index
            else:
                index += 1
        fail("Unterminated block comment")

    # Each interpolation owns its brace and parenthesis depths. Explicit frames
    # let deeply nested strings/interpolations avoid Python's recursion limit.
    frames = [{"kind": "code", "braces": 0, "parentheses": 0}]
    index = 0
    while index < size:
        frame = frames[-1]
        if frame["kind"] == "string":
            quote = frame["quote"]
            hashes = frame["hashes"]
            closing = quote + hashes
            escape = "\\" + hashes
            if text.startswith(closing, index) and (
                not hashes or not text.startswith("#", index + len(closing))
            ):
                frames.pop()
                index += len(closing)
                continue
            if text.startswith(escape, index):
                escaped = index + len(escape)
                if escaped < size and text[escaped] == "(":
                    frames.append({"kind": "code", "braces": 0, "parentheses": 1})
                    index = escaped + 1
                    continue
                # Consume escaped quotes and backslashes as one literal unit.
                if escaped < size and (quote == '"""' or text[escaped] not in "\r\n"):
                    index = escaped + 1
                    continue
            if quote == '"' and text[index] in "\r\n":
                fail("Unterminated string")
            index += 1
            continue
        if text.startswith("//", index):
            index += 2
            while index < size and text[index] not in "\r\n":
                index += 1
            continue
        if text.startswith("/*", index):
            index = block_comment(index)
            continue
        start = index
        while index < size and text[index] == "#":
            index += 1
        if index < size and text[index] == '"':
            quote = '"""' if text.startswith('"""', index) else '"'
            frames.append({"kind": "string", "quote": quote, "hashes": text[start:index]})
            index += len(quote)
            continue
        if index != start:
            continue
        char = text[index]
        if char == "{":
            frame["braces"] += 1
        elif char == "}":
            frame["braces"] -= 1
            if frame["braces"] < 0:
                fail("Unbalanced braces")
        elif frame["parentheses"] and char == "(":
            frame["parentheses"] += 1
        elif frame["parentheses"] and char == ")":
            frame["parentheses"] -= 1
            if frame["parentheses"] == 0:
                if frame["braces"]:
                    fail("Unbalanced braces in interpolation")
                frames.pop()
        index += 1
    if frames[-1]["kind"] == "string":
        fail("Unterminated string")
    if len(frames) > 1:
        fail("Unterminated interpolation")
    if frames[0]["braces"]:
        fail("Unbalanced braces")


def check_tuning_review_urls():
    app_dir = ROOT / "ios/LeafHFT"
    sources = {path: path.read_text(encoding="utf-8") for path in app_dir.rglob("*.swift")}
    handlers = [(path, text) for path, text in sources.items() if ".onOpenURL" in text]
    check(sum(text.count(".onOpenURL") for text in sources.values()) == 1,
          "exactly one tuning review onOpenURL handler")
    path, text = handlers[0]
    check(path == app_dir / "LeafHFTApp.swift", "tuning review handler belongs to app")
    begin = "// BEGIN tuning review URL handler:"
    end = "// END tuning review URL handler"
    check(text.count(begin) == 1 and text.count(end) == 1,
          "tuning review handler anchors")
    body = text.split(begin, 1)[1].split(end, 1)[0]
    check(body.count(".onOpenURL") == 1, "tuning review handler inside anchors")
    check(not re.search(r'submit|accept\s*\(|"POST"', body, re.IGNORECASE),
          "tuning review handler only opens review")
    with (app_dir / "Info.plist").open("rb") as stream:
        info = plistlib.load(stream)
    types = info.get("CFBundleURLTypes", [])
    check(isinstance(types, list) and len(types) == 1 and isinstance(types[0], dict)
          and types[0].get("CFBundleURLSchemes") == ["leafhft"],
          "only leafhft URL scheme registered")


def structural():
    check_tuning_review_urls()
    check(all((ROOT / path).is_file() for path in EXPECTED), "all frozen files exist")
    project = project_yaml((ROOT / "ios/project.yml").read_text(encoding="utf-8"))
    app = project["targets"]["LeafHFT"]
    ui = project["targets"]["LeafHFTUITests"]
    widget = project["targets"]["LeafHFTWidgetExtension"]
    check(ui["type"] == "bundle.ui-testing" and {"target": "LeafHFT"} in ui["dependencies"],
          "UI target tests the application")
    check("LeafHFTUITests" in project["schemes"]["LeafHFT"]["test"]["targets"],
          "UI target is in test action")
    fixtures = "Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures"
    check(any(entry.get("path") == fixtures and entry.get("buildPhase") == "resources"
              for entry in app["sources"]), "application bundles the fixture corpus")
    mode = (ROOT / "ios/LeafHFT/Model/FixtureMode.swift").read_text(encoding="utf-8")
    check('flag("-LEAFHFT_FIXTURES")' in mode and '== "1"' in mode,
          "fixture mode requires explicit launch flag")
    check("FixtureNetworkBlocker" in mode and "notConnectedToInternet" in mode,
          "fixture network rejection is present")
    appearance = (ROOT / "ios/LeafHFT/LeafHFTApp.swift").read_text(encoding="utf-8")
    check("guard FixtureMode.current.enabled" in appearance
          and "-LEAFHFT_APPEARANCE" in appearance
          and "@Environment(\\.colorScheme)" in appearance
          and "fixture.renderedAppearance" in appearance,
          "fixture appearance is guarded and exposes rendered environment")
    settings_source = (ROOT / "ios/LeafHFT/Views/SettingsView.swift").read_text(encoding="utf-8")
    check(all('"settings.' + name + '"' in settings_source
              for name in ("enableLive", "pauseTrading", "revokeRunner", "laneState")),
          "per-account live controls expose accessibility identifiers")
    check(all('.accessibilityIdentifier("settings.' + name + '")' in settings_source
              for name in ("openKalshi", "permissionWarning", "keyID", "pasteKeyID",
                           "chooseKeyFile", "keyFileReady", "pem", "import")),
          "Kalshi onboarding exposes accessibility identifiers")
    check('Real orders can be placed' in settings_source
          and "phone's saved key remains" in settings_source
          and 'Button("Start trading")' in settings_source
          and 'Button("Save, connect, and start trading", action: importKey)' in settings_source
          and '.alert("Revoke runner access?"' in settings_source,
          "one-tap live consent and revoke confirmation are explicit")
    runner_flow = (ROOT / "ios/LeafHFT/Net/AccountRunnerControlFlow.swift").read_text(encoding="utf-8")
    check(runner_flow.count("await submit(") == 1
          and "fresh.allows(action)" in runner_flow
          and "expectedTenantID" in runner_flow and "expectedLaneID" in runner_flow
          and "credentialIdentity() == identity" in runner_flow,
          "runner controls use one scoped submission and fresh status")
    app_state = (ROOT / "ios/LeafHFT/Model/AppState.swift").read_text(encoding="utf-8")
    check("confirmedRevision == accountControlRevision" in app_state
          and "if oldValue != kashbotStatus { accountControlRevision = UUID() }" in app_state
          and "confirmedRevision: state.accountControlRevision" in settings_source
          and settings_source.count("confirmedRevision: confirmedControlRevision") == 1,
          "live start and revoke remain tied to the displayed account status")
    status_change = settings_source.split(".onChange(of: state.kashbotStatus)", 1)[1].split(".onChange(of: scenePhase)", 1)[0]
    inactive_scene = settings_source.split("if phase != .active {", 1)[1].split("}", 1)[0]
    check(all(reset in body for body in (status_change, inactive_scene)
              for reset in ("confirmedControlRevision = nil", "confirmingRevoke = false")),
          "account status changes and inactive scenes dismiss revoke confirmation")
    enrollment_start = app_state.split("func setupDryRun(startLiveWhenReady:", 1)[1].split("func runAccountAction", 1)[0]
    check(enrollment_start.index("if status.isBound && !status.needsEnrollment")
          < enrollment_start.index("store.load(account: KeychainStore.keyDERAccount)")
          < enrollment_start.index("dashboard.bindingChallenge()"),
          "existing enrolled lanes skip private key reads and binding")
    setup_finish = app_state.split("private func finishSetupDryRun", 1)[1].split("func runAccountAction", 1)[0]
    check(enrollment_start.count("try await finishSetupDryRun(") == 2
          and "flow.perform(.startDryRun" in setup_finish
          and "client.startDryRun(clientRequestId: requestID)" in setup_finish
          and "guard action == .startDryRun" in setup_finish
          and "flow.perform(.startLive" in setup_finish
          and "client.startLive(clientRequestId: requestID)" in setup_finish
          and "autoLiveIntentKey" in enrollment_start
          and enrollment_start.count("try await finishAutoLiveIfRequested") == 2
          and "try await finishAutoLiveIfRequested(identity: credentialIdentity)" in app_state.split("private func pollBindingStatus", 1)[1],
          "one-tap setup persists consent and starts live only after dry run")
    check('defaults.set(requestID.uuidString, forKey: dryRunKey)' in runner_flow
          and 'if !resumeDryRun { try await submit(action, requestID) }' in runner_flow
          and 'status.request?.clientRequestId.lowercased()' in runner_flow
          and 'case .startDryRun where dryRunComplete(status):' in runner_flow
          and 'status.lane?.liveEnabled == false' in runner_flow
          and 'status.request?.action == .startDryRun' in runner_flow,
          "dry run records its attempt before submission and waits for matching safe acknowledgement")
    runner_start = app_state.split("func runAccountAction", 1)[1].split("private func updateSetupMessage", 1)[0]
    check("keyDERAccount" not in runner_start and "localizedDescription" not in runner_start
          and "accountMutationInProgress = true" in runner_start,
          "runner controls share the mutation lock without private key reads or raw errors")
    check('SecureField("Existing private key PEM"' in settings_source and "TextEditor" not in settings_source,
          "private key entry uses a secure field")
    check(all(copy in settings_source for copy in (
        "The Kalshi iPhone app does not show API keys",
        "Account Settings → API Keys → Create New API Key",
        "Grant only Read and Trade",
        "Leave Transfer funds, FCM risk, and Block Trade acceptance off",
        "Do not email or message the private key",
        "Kashbot trades exchange index 2",
        "https://kalshi.com/account/exchange-indexes",
        "Kashbot can scan markets in that state, but it cannot place an order",
    )), "Kalshi setup explains browser handoff, least privilege, and file transfer")
    check("awaitingKalshiBrowserReturn" in settings_source
          and "choosingKeyFile = true" in settings_source
          and "PasteButton(payloadType: String.self)" in settings_source
          and 'Button("Save, connect, and start trading", action: importKey)' in settings_source,
          "Kalshi browser return automates file selection and key-ID entry")
    check(".universalLinksOnly" not in settings_source
          and "apps.apple.com/app" not in settings_source
          and "UIApplication.shared.open(profile)" in settings_source,
          "Kalshi setup opens the website in the default browser")
    unit = project["targets"]["LeafHFTTests"]
    check(unit["type"] == "bundle.unit-test" and {"target": "LeafHFT"} in unit["dependencies"],
          "unit tests host the application")
    check("LeafHFTTests" in project["schemes"]["LeafHFT"]["test"]["targets"],
          "unit tests are in the test action")
    check(project["name"] == "LeafHFT" and app["type"] == "application", "project YAML and app target")
    check(app["settings"]["base"]["PRODUCT_BUNDLE_IDENTIFIER"] == "com.evan.leafhft", "bundle identifier")
    check(widget["type"] == "app-extension"
          and widget["settings"]["base"]["PRODUCT_BUNDLE_IDENTIFIER"] == "com.evan.leafhft.widget"
          and {"target": "LeafHFTWidgetExtension", "embed": True} in app["dependencies"],
          "portfolio widget target is embedded")
    build_number = project["settings"]["base"]["CURRENT_PROJECT_VERSION"]
    check(isinstance(build_number, str) and re.fullmatch(r"[0-9]{1,4}", build_number) is not None,
          "release build number is numeric")
    for path in (ROOT / "ios/LeafHFT/LeafHFT.entitlements",
                 ROOT / "ios/LeafHFTWidget/LeafHFTWidget.entitlements"):
        with path.open("rb") as stream:
            entitlements = plistlib.load(stream)
        check(entitlements.get("com.apple.security.application-groups") == ["group.com.evan.leafhft"],
              "portfolio widget app group: " + str(path.relative_to(ROOT)))
    widget_source = (ROOT / "ios/LeafHFTWidget/KashbotPortfolioWidget.swift").read_text(encoding="utf-8")
    snapshot_source = (ROOT / "ios/LeafHFT/Model/PortfolioWidgetSnapshot.swift").read_text(encoding="utf-8")
    check("15 * 60" in widget_source and "change15MinutesCents" in widget_source
          and "prefix(3)" in snapshot_source,
          "portfolio widget refresh, change, and compact positions")
    check(app["settings"]["base"].get("ASSETCATALOG_COMPILER_APPICON_NAME") == "AppIcon",
          "app icon build setting")
    icon_set = ROOT / "ios/LeafHFT/Assets.xcassets/AppIcon.appiconset"
    check((icon_set / "Contents.json").is_file(), "app icon descriptor exists")
    icon = json.loads((icon_set / "Contents.json").read_text(encoding="utf-8"))
    check(icon["images"] == [{"filename": "AppIcon-1024.png", "idiom": "universal",
                              "platform": "ios", "size": "1024x1024"}],
          "single-size iOS app icon descriptor")
    icon_png = icon_set / "AppIcon-1024.png"
    check(icon_png.is_file(), "app icon PNG exists")
    with icon_png.open("rb") as stream:
        header = stream.read(33)
    check(len(header) == 33 and header[:8] == b"\x89PNG\r\n\x1a\n"
          and int.from_bytes(header[8:12], "big") == 13 and header[12:16] == b"IHDR",
          "app icon PNG IHDR header")
    check(int.from_bytes(header[16:20], "big") == 1024
          and int.from_bytes(header[20:24], "big") == 1024 and header[25] == 2,
          "app icon is 1024x1024 RGB without alpha")
    check(project["packages"]["LeafHFTCore"]["path"] == "Packages/LeafHFTCore"
          and {"package": "LeafHFTCore"} in app["dependencies"], "local package dependency")
    test = project["targets"]["LeafHFTTests"]
    check(test["type"] == "bundle.unit-test" and {"target": "LeafHFT"} in test["dependencies"]
          and "LeafHFTTests" in project["schemes"]["LeafHFT"]["test"]["targets"], "hosted test target")
    forbidden = re.compile(r"^\s*(?:@\w+\s+)?import\s+(Security|SwiftUI|Charts|UIKit)\b", re.MULTILINE)
    check(all(not forbidden.search(path.read_text(encoding="utf-8"))
              for path in PACKAGE.rglob("*.swift")), "portable core imports")
    check(all("import CryptoKit" not in path.read_text(encoding="utf-8")
              for path in PACKAGE.rglob("*.swift")
              if path.name not in {"BindingModels.swift", "BindingModelsTests.swift"}),
          "CryptoKit restricted to account binding proof and its tests")
    endpoint = (PACKAGE / "Sources/LeafHFTCore/KalshiGETEndpoint.swift").read_text(encoding="utf-8")
    check(all('"' + method + '"' not in endpoint for method in ("POST", "PUT", "DELETE", "PATCH")),
          "GET-only endpoint")
    for name in ("KalshiClient", "DashboardClient"):
        client = (ROOT / ("ios/LeafHFT/Net/" + name + ".swift")).read_text(encoding="utf-8")
        forbidden_methods = ("POST", "PUT", "DELETE", "PATCH") if name == "KalshiClient" else ("PUT", "DELETE", "PATCH")
        check('httpMethod = "GET"' in client
              and all('"' + method + '"' not in client for method in forbidden_methods),
              name + " permitted request methods")
        if name == "DashboardClient":
            post_lines = [line for line in client.splitlines() if '"POST"' in line]
            check(len(post_lines) == 3
                  and any("request.httpMethod" in line for line in post_lines)
                  and any("controlRequest.httpMethod" in line for line in post_lines)
                  and any('request.httpMethod = "POST"' in line for line in post_lines)
                  and any('pairingRequest(method: "POST"' in line for line in post_lines),
                  "bounded setup, control and pairing POST assignments")
            control = client.split("func control(_ intent:", 1)[1].split("private func get", 1)[0]
            check(control.count('"POST"') == 1
                  and 'Self.baseURL.appendingPathComponent("/api/leafhft/mobile/control")' in control
                  and 'controlRequest.httpMethod = "POST"' in control
                  and "session.data(for: controlRequest)" in control,
                  "control POST uses the literal mobile control target")
        check(".ephemeral" in client and "willPerformHTTPRedirection" in client
              and "completionHandler(nil)" in client, name + " ephemeral session and redirect refusal")
        check(not re.search(r"print\s*\(", client), name + " no header logging")
    engine_models = (PACKAGE / "Sources/LeafHFTCore/EngineModels.swift").read_text(encoding="utf-8")
    check(all('"engine.' + kind + '"' in engine_models for kind in ("bind", "set", "create")),
          "three engine control kinds")
    policy_source = (PACKAGE / "Sources/LeafHFTCore/PolicyCatalog.swift").read_text(encoding="utf-8")
    # All 31 PolicyCatalog keys, frozen here; risk_resize_live joined in #364 (c5cc70c).
    policy_keys = {
        "size_fraction",
        "favorite_mult",
        "per_order_fraction",
        "cluster_fraction",
        "daily_loss_fraction",
        "cash_floor_cents",
        "risk_resize_live",
        "drawdown_brake_fraction",
        "drawdown_stop_fraction",
        "stake_ceiling_usd",
        "min_k",
        "min_price_cents",
        "max_price_cents",
        "favorite_price_cents",
        "favorite_edge_threshold_cents",
        "edge_threshold_cents",
        "big_edge_cents",
        "big_edge_min_prob",
        "min_depth",
        "exit_margin_cents",
        "exit_prob_ceiling",
        "exit_variance_scale",
        "exit_max_quote_age_ms",
        "exit_min_depth",
        "exit_min_hold_s",
        "reentry_block_s",
        "exit_min_hold_fraction",
        "conviction_min",
        "conviction_max",
        "target_win_cents",
        "min_win_cents",
    }
    check(set(re.findall(r'\bparameter\(\s*"([a-z_]+)"\s*,', policy_source)) == policy_keys,
          "all enumerated frozen policy bounds")
    mushy = (ROOT / "ios/LeafHFT/Net/MushyClient.swift").read_text(encoding="utf-8")
    # Eight POST literals: Studio, Kit turns, card approval and inbox seen guards/sends,
    # plus the nomination accept guard and accept send.
    check(mushy.count('"POST"') == 8
          and 'request.httpMethod = body == nil ? "GET" : "POST"' in mushy
          and 'static let root = "/api/leafhft/mobile/mushy"' in mushy
          and 'DashboardClient.baseURL.appendingPathComponent(endpoint)' in mushy
          and 'private func request<T: Decodable>' in mushy
          and '(method == "POST" && parts[1] == "sessions" && parts[3] == "turns")' in mushy
          and '|| (method == "GET" && parts[1] == "turns" && parts[3] == "events")' in mushy
          and '|| (method == "GET" && parts[1] == "turns" && parts[3] == "cards")' in mushy
          and 'let approveRoute = parts.count == 4 && parts[0].isEmpty && method == "POST" && parts[1] == "cards" && parts[3] == "approve"' in mushy
          and 'AssistantCard.validId(String(parts[2])) && query.isEmpty' in mushy
          and 'guard uuidRoute || approveRoute || inboxRoute || seenRoute || acceptRoute else' in mushy
          and ('let inboxRoute = method == "GET" && path == "/inbox" && (query.isEmpty\n'
               '            || (query.count == 1 && query[0].name == "count" && query[0].value == "1"))\n'
               '        let seenRoute = method == "POST" && path == "/inbox/seen" && query.isEmpty\n'
               '        let acceptRoute = method == "POST" && parts.count == 5 && parts[0].isEmpty\n'
               '            && parts[1] == "inbox" && parts[2] == "nominations" && parts[4] == "accept"\n'
               '            && AssistantNomination.validId(String(parts[3])) && query.isEmpty\n'
               '        let uuidRoute =') in mushy
          and 'let uuidRoute = parts.count == 4 && parts[0].isEmpty && UUID(uuidString: String(parts[2])) != nil' in mushy
          and 'func approveCard(cardId: String, cardDigest: String, identity: String)' in mushy
          and 'kitSend(method: "POST", path: "/cards/" + cardId + "/approve"' in mushy
          and 'func acceptNomination(id: String, packetAsOf: String, identity: String)' in mushy
          and 'guard AssistantNomination.validId(id) else { throw MushyClientError.response }' in mushy
          and 'kitSend(method: "POST", path: "/inbox/nominations/" + id + "/accept"' in mushy
          and '"/api/kashbot/assistant/v1" + path' in mushy
          and all('"' + method + '"' not in mushy for method in ("PUT", "DELETE", "PATCH")),
          "bounded Studio, Kit turns and card approve POSTs; inbox GET has no query or exactly count=1, inbox/seen POST has no query; nomination accept POST has a validated id and no query")
    studio_files = [
        "LeafHFT/Model/MushyModels.swift", "LeafHFT/Model/MushyState.swift",
        "LeafHFT/Net/MushyClient.swift", "LeafHFT/Views/StudioView.swift",
        "LeafHFT/Views/AssistantConversationView.swift", "LeafHFT/Model/AssistantConversation.swift",
        "LeafHFTTests/MushyModelsTests.swift", "LeafHFTTests/MushyClientTests.swift",
        "LeafHFTUITests/MushyStudioUITests.swift"
    ]
    check(all((ROOT / "ios" / path).is_file() for path in studio_files),
          "Studio native source and focused test files exist")
    models = (ROOT / "ios/LeafHFT/Model/MushyModels.swift").read_text(encoding="utf-8")
    studio_state = (ROOT / "ios/LeafHFT/Model/MushyState.swift").read_text(encoding="utf-8")
    renderer = (ROOT / "ios/LeafHFT/Views/AssistantConversationView.swift").read_text(encoding="utf-8")
    studio_app = (ROOT / "ios/LeafHFT/LeafHFTApp.swift").read_text(encoding="utf-8")
    assistant_model = (ROOT / "ios/LeafHFT/Model/AssistantConversation.swift").read_text(encoding="utf-8")
    check(".convertToSnakeCase" in models and ".convertFromSnakeCase" in models
          and "enum MushyModel:" not in models and "enum MushyReasoning:" not in models,
          "Studio uses snake case and dynamic catalog selections")
    check("URLSessionConfiguration.ephemeral" in mushy
          and "config.httpShouldSetCookies = false" in mushy
          and "config.urlCache = nil" in mushy
          and "config.httpCookieStorage = nil" in mushy,
          "Studio transport has no cookie or cache persistence")
    check(all(route in mushy for route in ('"/catalog"', '"/state"', '"/session"', '"/turn"',
          '"/jobs/"', '"/events"', '"/artifacts/"', '"/slots"', '"/proposals"', '"/config-drafts/"'))
          and 'URLQueryItem(name: "after"' in mushy,
          "Studio exact route family and event cursor are present")
    check("5_000_000_000" in studio_state and "pending.body" in mushy
          and "try persist() // Exact bytes" in studio_state
          and "await studio.tick()" in studio_app,
          "Studio persists request bytes and polls from the active app lifecycle")
    check('"studio.launcher"' in studio_app and "if studio.visible" not in studio_app
          and "if studio.featureDisabled" not in studio_app and "case .config:" in studio_state
          and "summaryDigest: draft.contents.summaryDigest" in studio_state
          and "ControlIntent" not in studio_state + models + renderer + assistant_model
          and "app.submit" not in studio_state + renderer + assistant_model,
          "Assistant launcher stays visible and confirms server configuration digests")
    check("LineMark(" in renderer and "Grid(" in renderer and 'case "metric":' in renderer
          and "WKWebView" not in renderer and "import WebKit" not in renderer,
          "Assistant panels use native chart table and metric rendering")
    post_clients = {ROOT / "ios/LeafHFT/Net/DashboardClient.swift",
                    ROOT / "ios/LeafHFT/Net/MushyClient.swift",
                    ROOT / "ios/LeafHFT/Net/PushClient.swift",
                    ROOT / "ios/LeafHFT/Net/TuningInboxClient.swift"}
    push = (ROOT / "ios/LeafHFT/Net/PushClient.swift").read_text(encoding="utf-8")
    push_paths = re.findall(r'"(/api/[^"\s]+)"', push)
    check(sorted(push_paths) == ["/api/leafhft/mobile/autopilot/toggle", "/api/leafhft/mobile/capabilities", "/api/leafhft/mobile/live-activity-token", "/api/leafhft/mobile/push-token"]
          and push.count('"POST"') == 4 and push.count('request.httpMethod = "POST"') == 4
          and len(re.findall(r'\bPOST\b', push)) == 4
          and all('"' + method + '"' not in push for method in ("PUT", "DELETE", "PATCH")),
          "PushClient permits exactly registration, capabilities, live activity token and account toggle operations")
    push_implementation = push.split("final class PushClient:", 1)[1]
    for method, target in (("register", "/api/leafhft/mobile/push-token"),
                           ("registerCapabilities", "/api/leafhft/mobile/capabilities"),
                           ("toggle", "/api/leafhft/mobile/autopilot/toggle")):
        body = push_implementation.split("    func " + method + "(", 1)[1].split("\n    }", 1)[0]
        check(body.count('request.httpMethod = "POST"') == 1
              and 'appendingPathComponent("' + target + '")' in body
              and "try fixtureMode.requireLiveAccess()" in body,
              "Push operation is literal and fixture guarded: " + method)
    # Tuning inbox (docs/contracts/tuning-inbox-v1.md): two guarded GET reads and one guarded decision POST.
    tuning = (ROOT / "ios/LeafHFT/Net/TuningInboxClient.swift").read_text(encoding="utf-8")
    check(re.findall(r'"(/api/[^"\s]+)"', tuning) == ["/api/leafhft/mobile/tuning-inbox"]
          and 'static let path = "/api/leafhft/mobile/tuning-inbox"' in tuning
          and tuning.count('"POST"') == 1 and tuning.count('urlRequest.httpMethod = "POST"') == 1
          and tuning.count('"GET"') == 1 and tuning.count('request.httpMethod = "GET"') == 1
          and len(re.findall(r'httpMethod\s*=', tuning)) == 2
          and all('"' + method + '"' not in tuning for method in ("PUT", "DELETE", "PATCH")),
          "TuningInboxClient permits exactly item reads and the decision POST")
    check("URLSessionConfiguration.ephemeral" in tuning and "delegate: DashboardRedirectDelegate()" in tuning
          and "configuration.httpCookieStorage = nil" in tuning and "configuration.urlCache = nil" in tuning,
          "TuningInboxClient ephemeral session and redirect refusal")
    tuning_implementation = tuning.split("final class TuningInboxClient:", 1)[1].split("\n}", 1)[0]
    decision = tuning_implementation.split("    func submitDecision(", 1)[1].split("\n    }", 1)[0]
    check(decision.startswith("_ request: TuningDecisionRequest) async throws -> TuningDecisionOutcome {\n"
                              "        try fixtureMode.requireLiveAccess()\n")
          and decision.count('urlRequest.httpMethod = "POST"') == 1
          and "guard TuningSyntax.isUUID(request.proposalID), TuningSyntax.isUUID(request.requestID)," in decision
          and 'DashboardClient.baseURL.appendingPathComponent(Self.path + "/" + request.proposalID + "/decision")'
              in decision,
          "TuningInboxClient decision POST is literal and fixture guarded")
    read = tuning_implementation.split("    private func read(", 1)[1].split("\n    }", 1)[0]
    check("\n        try fixtureMode.requireLiveAccess()\n        try Task.checkCancellation()\n" in read
          and read.count('request.httpMethod = "GET"') == 1
          and "DashboardClient.baseURL.appendingPathComponent(Self.path)" in read
          and tuning_implementation.count("try await read(") == 2,
          "TuningInboxClient item reads are GET only and fixture guarded")
    with (ROOT / "ios/LeafHFT/LeafHFT.entitlements").open("rb") as stream:
        push_entitlements = plistlib.load(stream)
    check(push_entitlements.get("aps-environment") == "production", "production APNs entitlement")
    registrar = (ROOT / "ios/LeafHFT/PushRegistrar.swift").read_text(encoding="utf-8")
    for action in ("keepOn", "turnOff", "reviewTuning"):
        check(re.search(r'UNNotificationAction\(identifier: Self\.' + action
                        + r',\s*title: "[^"]+",\s*options: \[[^\]]*\.authenticationRequired[^\]]*\]',
                        registrar) is not None,
              "notification action requires unlock: " + action)
    check(re.search(r'UNNotificationAction\(identifier: Self\.reviewTuning'
                    + r',\s*title: "[^"]+",\s*options: \[[^\]]*\.foreground[^\]]*\]',
                    registrar) is not None,
          "tuning review action opens the foreground")
    tuning_branch = re.search(r'Self\.tuningCategories\.contains\(category\)(.*?)return\n        }',
                              registrar, re.DOTALL)
    check(tuning_branch is not None and "client." not in tuning_branch.group(1),
          "tuning notification action never calls client")
    for path in (ROOT / "ios/LeafHFT").rglob("*.swift"):
        if path not in post_clients:
            check('"POST"' not in path.read_text(encoding="utf-8"),
                  "no POST outside dashboard control, Studio, push and tuning inbox: " + str(path.relative_to(ROOT)))
    settings = (ROOT / "ios/LeafHFT/Views/SettingsView.swift").read_text(encoding="utf-8")
    check('-LEAFHFT_FILE_PICKER_WALK' in settings
          and '.disabled(!filePickerAllowed)' in settings
          and 'guard filePickerAllowed else { return }' in settings,
          "system picker requires explicit fixture opt-in")
    import_body = settings.split('private func importKey()', 1)[1].split('private func checkConnection()', 1)[0]
    check('guard !state.fixtureMode.enabled, !checkingConnection else { return }' in import_body,
          "picker fixture cannot persist a key or start import connection check")
    check(not re.search(r"create[- ](?:a[- ])?key|create[- ]api[- ]key", settings, re.IGNORECASE),
          "Settings imports existing keys only")
    store = (ROOT / "ios/LeafHFT/Store/ObservationStore.swift").read_text(encoding="utf-8")
    check("actor ObservationStore" in store and "import SQLite3" in store
          and "defer { sqlite3_finalize(" in store, "SQLite actor finalizes statements")
    check({"sdk": "libsqlite3.tbd"} in app["dependencies"], "SQLite linked")
    source_paths = {entry["path"] for entry in app["sources"]}
    check(all("LeafHFT/" + group in source_paths for group in ("Model", "Net", "Store", "Views")),
          "screen client and store source groups")
    for path in (ROOT / "ios").rglob("*.swift"):
        if ".build" in path.parts:
            continue
        text = path.read_text(encoding="utf-8")
        try:
            swift_braces_and_spaces(text, path.relative_to(ROOT))
        except Exception as error:
            raise ValueError("Swift scanner failed: " + str(path.relative_to(ROOT))
                             + ": " + str(error)) from error
        check(True, "Swift braces and spaces: " + str(path.relative_to(ROOT)))
    fixture_dir = PACKAGE / "Tests/LeafHFTCoreTests/Fixtures"
    header_start = "BEGIN"
    private_header = re.compile(header_start + r"[^\r\n]*PRIVATE KEY")
    runs = re.compile(r"[A-Za-z0-9+_=-]{32,}")
    for path in (ROOT / "ios").rglob("*"):
        if not path.is_file():
            continue
        # Compiled bytecode is not source: this module's own .pyc carries the split header pattern above.
        if "__pycache__" in path.parts or path.suffix in (".pyc", ".pyo"):
            continue
        text = path.read_bytes().decode("utf-8", errors="replace")
        relative = str(path.relative_to(ROOT))
        if private_header.search(text):
            raise ValueError("Private key header: " + relative)
        if path == TUNING_VECTORS:
            validate_tuning_fixture(text, "leafhft.tuning-inbox-vectors.v1",
                                    TUNING_VECTOR_PUBLIC_KEYS, "Tuning inbox vectors")
            continue
        if path == TUNING_V2_VECTORS:
            validate_tuning_fixture(text, "leafhft.tuning-plan-v2.vectors.v1",
                                    TUNING_V2_VECTOR_PUBLIC_KEYS, "Tuning plan v2 vectors",
                                    require_test_only=False, exact_v2_plan_path=True)
            continue
        if path == TUNING_WIRE:
            validate_tuning_fixture(text, "leafhft.tuning-wire.v1",
                                    TUNING_WIRE_PUBLIC_KEYS, "Tuning wire fixtures")
            continue
        for number, line in enumerate(text.splitlines(), 1):
            if (path == ROOT / "ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/engine-glyphs.json"
                    and re.fullmatch(
                        r'\s*"path"\s*:\s*"[Mm][MmLlHhVvCcSsQqTtAaZzEe0-9+.,\s-]*"\s*,?\s*',
                        line)):
                # Packed public SVG coordinates resemble secret runs. Exempt
                # only a whole path line here; metadata and copies stay scanned.
                continue
            # Escaped whitespace in source literals separates values just as it
            # does at runtime. Otherwise a fixture UUID can include a leading n.
            scan_line = re.sub(r"\\[nrt]", " ", line)
            for match in runs.finditer(scan_line):
                value = match.group()
                if (path == ROOT / "ios/ui-surfaces.yaml"
                        or (path.parent == ROOT / "ios/ui-findings" and path.suffix == ".yaml")) and re.fullmatch(
                    r"[a-z0-9]+(?:[._-][a-z0-9]+)+", value
                ):
                    # Registry labels are public; other runs and files stay scanned.
                    continue
                if ("LeafHFTTests" in path.parts or "LeafHFTCoreTests" in path.parts) and re.fullmatch(
                    r"[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}", value
                ):
                    # Public UUID test vectors, not private credential material.
                    continue
                if value == "expected_artifact_receipt_sha256":
                    # Public ios_walk keyword, not credential material.
                    continue
                if path == TUNING_INBOX_TESTS and value == TUNING_BAD_UUID:
                    # The one malformed UUID the tuning router test must refuse.
                    continue
                if is_high_entropy_run(value):
                    raise ValueError("High-entropy run: " + relative + ":" + str(number))
    check(True, "no private key headers or high-entropy runs under ios")
    with (ROOT / "ios/LeafHFT/Info.plist").open("rb") as stream:
        info = plistlib.load(stream)
    check(info.get("ITSAppUsesNonExemptEncryption") is False, "export compliance plist")
    face_id_usage = info.get("NSFaceIDUsageDescription")
    check(isinstance(face_id_usage, str) and bool(face_id_usage.strip())
          and len(face_id_usage) <= 120 and face_id_usage.splitlines() == [face_id_usage],
          "Face ID usage description present")
    with (ROOT / "ios/LeafHFT/PrivacyInfo.xcprivacy").open("rb") as stream:
        privacy = plistlib.load(stream)
    check(privacy.get("NSPrivacyTracking") is False, "privacy manifest")
    fixture = json.loads((fixture_dir / "signature-fixture.json").read_text(encoding="utf-8"))
    hex_fields = ("public_key_pkcs1_der_hex", "public_key_spki_der_hex", "signature_hex")
    check(isinstance(fixture, dict)
          and {"timestamp_ms", "path", "message", *hex_fields}.issubset(fixture)
          and isinstance(fixture["timestamp_ms"], str)
          and re.fullmatch(r"[0-9]+", fixture["timestamp_ms"])
          and isinstance(fixture["path"], str)
          and fixture["path"].startswith("/trade-api/v2")
          and isinstance(fixture["message"], str),
          "signature fixture fields")
    expected = fixture["timestamp_ms"] + "GET" + fixture["path"]
    check(fixture["message"] == expected
          and all(isinstance(fixture[field], str) and len(fixture[field]) % 2 == 0
                  and re.fullmatch(r"[0-9a-f]+", fixture[field]) for field in hex_fields)
          and len(bytes.fromhex(fixture["signature_hex"])) == 256,
          "signature fixture message and encoding")
    for name in ("balance", "positions", "fills", "settlements", "books", "engines", "probes"):
        json.loads((fixture_dir / (name + ".json")).read_text(encoding="utf-8"))
    check(True, "account and telemetry JSON fixtures")
    lab_fixture = json.loads((fixture_dir / "engine-lab.json").read_text(encoding="utf-8"))
    check(set(lab_fixture) == {"schema_version", "reviewed_at", "lanes"}
          and lab_fixture["schema_version"] == 2
          and lab_fixture["reviewed_at"] == "2026-09-20",
          "Engine Lab reviewed notes schema")
    lanes = lab_fixture["lanes"]
    check([lane["lane_id"] for lane in lanes] == ["darkhorse", "dip-recovery", "relay-divergence"]
          and [lane["name"] for lane in lanes] == ["Darkhorse", "Dip Recovery", "Relay Divergence"]
          and [lane["stage"] for lane in lanes] == ["not_reported", "research", "research"]
          and all(lane.get("owner") is None for lane in lanes)
          and [lane["next_action"] for lane in lanes] == [
              "First-class account integration", "Build a shadow engine", "Run a stable shadow trial"]
          and [lane["evidence"][0]["label"] for lane in lanes] == [
              "Cap and holdout", "Replay", "Daily diagnostic"],
          "Engine Lab candidate status evidence ownership and next actions")
    required = {"lane_id", "name", "stage", "hypothesis", "evidence", "next_action", "readiness"}
    for lane in lanes:
        check(required <= set(lane) <= required | {"engine_id", "owner"}
              and bool(lane["hypothesis"]) and bool(lane["evidence"])
              and all(set(item) == {"label", "value", "as_of"}
                      and all(isinstance(value, str) and value for value in item.values())
                      for item in lane["evidence"]),
              "Engine Lab lane and evidence contract: " + lane["lane_id"])
        check(set(lane["readiness"]) == {"data_coverage", "holdout_evidence", "risk_limits", "account_integration", "telemetry"}
              and all(set(item) == {"status", "note", "as_of"}
                      and item["status"] in {"noted", "not_reported"}
                      and isinstance(item["note"], str) and bool(item["note"])
                      and item["as_of"] == "2026-09-20"
                      for item in lane["readiness"].values()),
              "Engine Workshop notes report evidence without approval: " + lane["lane_id"])
    lab_core = (PACKAGE / "Sources/LeafHFTCore/EngineLab.swift").read_text(encoding="utf-8")
    lab_view = (ROOT / "ios/LeafHFT/Views/EngineLabView.swift").read_text(encoding="utf-8")
    lab_tests = (PACKAGE / "Tests/LeafHFTCoreTests/EngineLabTests.swift").read_text(encoding="utf-8")
    engines_view = (ROOT / "ios/LeafHFT/Views/EnginesView.swift").read_text(encoding="utf-8")
    bundled = re.search(r'bundledNotesJSON = #"""(.*?)"""#', lab_core, re.S)
    check(bundled is not None and json.loads(bundled.group(1)) == lab_fixture,
          "Production bundled notes exactly match the reviewed fixture")
    check("EngineLabView()" in engines_view and '"engine.lab.open"' in engines_view
          and 'Section("Account lanes")' in lab_view
          and 'Section("Pending work")' in lab_view
          and "EngineLabNoteSummary(lane: lane, reviewedAt: notes.reviewedAt)" in lab_view
          and all(value in lab_view for value in [
              "lane.ownerLabel", "lane.hypothesis", "lane.evidence", "lane.nextAction",
              "evidence.asOf", "lane.stage.label", "lane.stage.symbol", "lane.boundary"]),
          "Engine Lab overview renders stage symbols owners hypotheses evidence next steps and review date")
    check(not re.search(r"\b(?:Toggle|ControlIntent|DashboardClient|URLSession)\b|\.submit\s*\(",
                        lab_view + lab_core)
          and "EngineControlSheet" not in lab_view,
          "Engine Lab has no control submission or network client")
    check('Stage(rawValue: value) ?? .research' in lab_core
          and "NotesError.invalidContract" in lab_core
          and '"Not trading.' in lab_core and '"Status not reported.' in lab_core
          and "Entry setting unknown" in lab_core and "Account lane state inconsistent" in lab_core
          and "EngineLab.freshness" in lab_view and "state.enginesError" in lab_view
          and "state.controlOutcomeUnknown" in lab_view and "state.fixtureMode.enabled" in lab_view,
          "Notes cannot assert live status and Lab preserves unknown stale and fixture boundaries")
    check('accounts.first { $0.accountId == accountId }' in lab_core
          and 'configuration.override.policy.count + (configuration.override.enabled != nil ? 1 : 0)' in lab_core
          and 'eligible.count == 1' in lab_core
          and '$0.configurable && $0.id != "unassigned"' in lab_core
          and "EngineLab.yourLane(in: accounts)" in lab_view
          and "EngineLab.customSettings(configuration)" in lab_view
          and "configuration.pending" in lab_view,
          "Account lanes join by ID count sparse overrides and identify only one eligible account")
    check("NavigationLink" in lab_view
          and "EngineHistoryView(engineId: engine.engineId)" in lab_view
          and "EngineSettingsView(engineId: engine.engineId, initialAccountId: account.id)" in lab_view
          and lab_view.count("EngineSettingsView(") == 2
          and "if EngineLab.canOpenSettings(account: account, engine: engine)" in lab_view
          and 'account.configurable && account.id != "unassigned" && account.host == engine.host' in lab_core
          and "engine.pnl?.netCents" in lab_view and "engine.boundBooks" in lab_view
          and "?.effective.policy" in lab_view and 'Section("Requests")' in lab_view,
          "Live details show P&L books effective dials requests history and guarded account settings")
    check(all(identifier in lab_view for identifier in [
              "engine.lab.list", "engine.lab.row.", "engine.lab.stage.",
              "engine.lab.lane.", "engine.lab.settings."]),
          "Engine Lab accessibility identifiers")
    check(all(name in lab_tests for name in [
              "testBundledNotesRemainAvailableOnlyAsLegacyFallback", "testNotesCannotClaimLiveOrPausedStages",
              "testStrictNotesContractRejectsMalformedOrDriftingData",
              "testAccountJoinNeverFallsBackToGlobal", "testYourLaneRequiresExactlyOneEligibleAccount",
              "testSettingsLinksRequireConfigurableAssignedMatchingHost",
              "testFreshnessRequiresSourceAndTransportTimes"]),
          "Native Engine Lab tests cover notes account isolation navigation guards and freshness")
    workshop_tools = (ROOT / "ios/LeafHFT/Views/EngineWorkshopTools.swift").read_text(encoding="utf-8")
    workshop_core = (PACKAGE / "Sources/LeafHFTCore/EngineWorkshop.swift").read_text(encoding="utf-8")
    workshop_tests = (PACKAGE / "Tests/LeafHFTCoreTests/EngineWorkshopTests.swift").read_text(encoding="utf-8")
    prefill_tests = (ROOT / "ios/LeafHFTTests/MushyPrefillTests.swift").read_text(encoding="utf-8")
    studio_view = (ROOT / "ios/LeafHFT/Views/StudioView.swift").read_text(encoding="utf-8")
    check("AssistantConversationView()" in studio_view and "legacyBody" not in studio_view,
          "Studio always opens the canonical assistant")
    workshop_ui_tests = (ROOT / "ios/LeafHFTUITests/FixtureUITests.swift").read_text(encoding="utf-8")
    check(not re.search(r'\b(?:ControlIntent|DashboardClient|URLSession|MushyClient|Toggle|TextField)\b|"POST"|\.(?:submit|send|apply|publish|suggest)\s*\(',
                        workshop_tools + workshop_core),
          "Engine Workshop tools and core have no network or mutation rail")
    check(all(identifier in lab_view + workshop_tools for identifier in [
              "engine.workshop.yourLane", "engine.workshop.readiness.", "engine.workshop.tools",
              "engine.workshop.compare.", "engine.workshop.compare.row.", "engine.workshop.ask.design.",
              "engine.workshop.ask.test.", "engine.workshop.brief.", "engine.workshop.share."])
          and all(identifier in renderer for identifier in [
              "assistant.prefill.banner", "assistant.prefill.use", "assistant.prefill.dismiss", "assistant.engineToggle"]),
          "Engine Workshop and assistant prefill and engine toggle accessibility identifiers")
    check(all(name in workshop_tests for name in [
              "testLiveReadinessNeverClaimsHoldoutOrApproval", "testMissingAccountNeverUsesGlobalDials",
              "testRiskCountsAndAccountIntegrationAreOnlyReportedEvidence", "testBriefIsBoundedAndOmitsIdentifiers",
              "testTelemetryAndCoverageKeepMissingAndStaleState", "testResearchReadinessIsNotesNotTelemetry",
              "testUnselectedBriefAndStudioPromptsKeepReviewBoundary", "testNotesRejectReportedStatusAndMissingReadinessKeys"])
          and all(name in prefill_tests for name in [
              "testEmptyPrefillPersistsWithoutClientCalls", "testExistingDraftRequiresExplicitReplacementWithoutClientCalls",
              "testDismissPrefillKeepsDraftWithoutClientCalls", "testPendingRequestAndExactBytesSurvivePrefill"])
          and all(name in workshop_ui_tests for name in [
              "testEngineLabSharedWorkboard", "testEngineWorkshopLiveToolsAndCompare",
              "testEngineWorkshopStudioPrefillKeepsDraftUntilReplace"]),
          "Workshop tests cover evidence privacy draft preservation and native navigation")
    for method in ("offerPrefill", "acceptPrefill", "dismissPrefill"):
        body = re.search(r"    func " + method + r"\([^)]*\)\s*\{(.*?)(?=\n    (?:func|var|private|//))", studio_state, re.S)
        check(body is not None and not re.search(r"\b(?:send|newSession|prepare|client)\b", body.group(1)),
              "Studio prefill stays local: " + method)
    check("studio.offerPrefill(text)" in studio_app and "OpenStudioAction" in studio_app
          and "pending == nil" in studio_state and "offeredPrefill" in studio_state,
          "Workshop opens Studio through a local draft offer")
    ui_registry = runpy.run_path(str(ROOT / "ios/scripts/ui_surface_map.py"))
    check(ui_registry["check"](ROOT, emit=False) == 0, "UI surface registry valid")
    print("COMPILE DEFERRED TO MAC")


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--structural-only", action="store_true",
                        help="run structural checks without discovering or launching Swift")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    try:
        structural()
    except (ValueError, KeyError, TypeError, OSError, IndexError) as error:
        print("FAIL " + str(error), file=sys.stderr)
        return 1
    if args.structural_only:
        return 0
    swift = shutil.which("swift")
    if swift:
        return subprocess.run([swift, "test", "--package-path", str(PACKAGE)], cwd=ROOT).returncode
    return 0


if __name__ == "__main__":
    arguments = ["--structural-only"] if parse_args().structural_only else []
    # Preserve the interpreter and its options, normalizing accepted flag aliases.
    command_argv = sys.orig_argv[:len(sys.orig_argv) - len(sys.argv) + 1] + arguments
    started = time.monotonic()
    result = main(arguments)
    elapsed = round(time.monotonic() - started, 3)
    sha = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                         capture_output=True, text=True, check=True).stdout.strip()
    dirty = subprocess.run(["git", "status", "--porcelain", "--", "ios"], cwd=ROOT,
                           capture_output=True, text=True, check=True).stdout.strip()
    evidence = Path(os.environ.get("LEAFHFT_EVIDENCE_ROOT", "C:/tmp/leafhft-ios/evidence"
                    if os.name == "nt" else str(ROOT / "_marathon/evidence")))
    evidence /= datetime.now(timezone.utc).strftime("%Y-%m-%d")
    evidence.mkdir(parents=True, exist_ok=True)
    receipt = evidence / "rung-0.json"
    receipt.write_text(json.dumps({
        "rung": 0, "source_sha": sha, "source_dirty": bool(dirty),
        "host": platform.node(), "argv": command_argv,
        "command": (subprocess.list2cmdline(command_argv) if os.name == "nt"
                    else shlex.join(command_argv)),
        "exit_code": result, "duration_seconds": elapsed,
        "number": elapsed, "unit": "seconds", "budget_seconds": None,
        "result": "PASS" if result == 0 else "FAIL", "basis": "confirmed",
        "scope": "desktop structural checks; native compilation is a separate rung",
        "xcresult": None, "screenshots": [],
        "observed_at": datetime.now(timezone.utc).isoformat()
    }, indent=2) + "\n", encoding="utf-8")
    print("Receipt: " + str(receipt))
    sys.exit(result)
