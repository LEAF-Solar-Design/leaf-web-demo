"""Focused attachment regression checks. Run directly with Python, no pytest."""
import contextlib
import io
import json
import math
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch
from types import SimpleNamespace

import mac_verify as verify


class Clock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now


class Process:
    def __init__(self, clock, duration=0, hung=False, code=0):
        self.clock = clock
        self.duration = duration
        self.hung = hung
        self.code = code
        self.returncode = None
        self.stdout = io.BytesIO()
        self.killed = False
        self.waits = []

    def wait(self, timeout=None):
        if timeout is None:
            raise AssertionError("unbounded wait")
        self.waits.append(timeout)
        if self.returncode is not None:
            return self.returncode
        if self.hung or self.duration > timeout:
            self.clock.now += timeout
            raise subprocess.TimeoutExpired("fake process", timeout)
        self.clock.now += self.duration
        self.returncode = self.code
        return self.returncode

    def poll(self):
        return self.returncode

    def kill(self):
        self.killed = True
        self.returncode = -9


class AttachmentTests(unittest.TestCase):
    def setUp(self):
        lock_patch = patch.object(verify, "lock_applies", return_value=False)
        lock_patch.start()
        self.addCleanup(lock_patch.stop)
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.handle = io.StringIO()
        self.console = contextlib.redirect_stdout(io.StringIO())
        self.console.__enter__()
        self.addCleanup(self.console.__exit__, None, None, None)

    def test_shared_deadline_kills_hung_producer(self):
        clock = Clock()
        producer = Process(clock, hung=True)
        consumer = Process(clock, duration=230)
        with patch.object(verify.time, "monotonic", clock), \
                patch.object(verify.subprocess, "Popen", side_effect=[producer, consumer]):
            result = verify.pull_attachments("~/work/artifacts/ui-Test-1-attachments",
                                             self.root, self.handle, 300)
        self.assertFalse(result)
        self.assertTrue(producer.killed)
        self.assertEqual(producer.waits[0], 70)
        self.assertEqual(clock.now, 300)
        self.assertTrue(producer.stdout.closed)
        self.assertIn("TIMEOUT attachment pull", self.handle.getvalue())

    def test_hung_extraction_kills_both_processes(self):
        clock = Clock()
        producer = Process(clock, hung=True)
        consumer = Process(clock, hung=True)
        with patch.object(verify.time, "monotonic", clock), \
                patch.object(verify.subprocess, "Popen", side_effect=[producer, consumer]):
            self.assertFalse(verify.pull_attachments("~/work/out", self.root, self.handle, 7))
        self.assertTrue(producer.killed)
        self.assertTrue(consumer.killed)
        self.assertEqual(clock.now, 7)

    def test_failed_tar_launch_stops_producer(self):
        clock = Clock()
        producer = Process(clock, hung=True)
        with patch.object(verify.subprocess, "Popen", side_effect=[producer, OSError("no tar")]):
            self.assertFalse(verify.pull_attachments("~/work/out", self.root, self.handle, 7))
        self.assertTrue(producer.killed)
        self.assertTrue(producer.stdout.closed)

    def test_nonzero_tar_stops_producer(self):
        clock = Clock()
        producer = Process(clock, hung=True)
        consumer = Process(clock, code=2)
        with patch.object(verify.subprocess, "Popen", side_effect=[producer, consumer]):
            self.assertFalse(verify.pull_attachments("~/work/out", self.root, self.handle, 7))
        self.assertTrue(producer.killed)
        self.assertIn("tar failed: exit 2", self.handle.getvalue())

    def test_filter_quoting_and_stage_metrics(self):
        def pull(out, stage, handle, timeout):
            self.assertEqual(timeout, 13)
            (stage / "nested").mkdir()
            (stage / "nested" / "proof.png").write_bytes(b"png")
            (stage / "manifest.json").write_bytes(b"{}")
            return True

        for glob in ("*.png", "*", "a' ; $(touch unwanted) *.png"):
            with self.subTest(glob=glob), \
                    patch.object(verify.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, "")) as run, \
                    patch.object(verify, "pull_attachments", side_effect=pull), \
                    patch.object(verify, "prune_attachments") as prune:
                count = verify.collect_attachments("~/work/a.xcresult", "~/work/out",
                                                   self.root, glob, 13, self.handle)
                self.assertEqual(count, 1)
                args, kwargs = run.call_args
                self.assertEqual(kwargs["timeout"], 600)
                command = shlex.split(args[0][-1])[2]
                words = shlex.split(command)
                self.assertEqual(words[words.index("--filter") + 1], glob)
                self.assertNotIn("| tail", command)
                prune.assert_called_once_with("~/work/out", self.handle)
        text = self.handle.getvalue()
        self.assertRegex(text, r"attachment export: seconds=\d+\.\d{3} exit=0")
        self.assertRegex(text, r"attachment pull: seconds=\d+\.\d{3} files=2 bytes=5 success=True")
        self.assertEqual((self.root / "nested" / "proof.png").read_bytes(), b"png")

    def test_silent_export_timeout_is_bounded_and_logged(self):
        (self.root / "old.png").write_bytes(b"old")
        with patch.object(verify.subprocess, "run", side_effect=subprocess.TimeoutExpired("ssh", 600)) as run, \
                patch.object(verify, "pull_attachments") as pull, \
                patch.object(verify, "prune_attachments") as prune:
            count = verify.collect_attachments("~/work/bundle", "~/work/out", self.root,
                                               "*.png", 300, self.handle)
        self.assertEqual(count, 0)
        self.assertEqual(run.call_args.kwargs["timeout"], 600)
        pull.assert_not_called()
        prune.assert_not_called()
        self.assertIn("TIMEOUT after 600s", self.handle.getvalue())
        self.assertIn("files=0 bytes=0", self.handle.getvalue())
        self.assertIn("attachment export: seconds=", self.handle.getvalue())
        self.assertIn("attachment pull: seconds=", self.handle.getvalue())

    def test_failed_pull_does_not_prune_or_count_stale_screenshots(self):
        (self.root / "old.png").write_bytes(b"old")
        with patch.object(verify, "attachment_ssh", return_value=0), \
                patch.object(verify, "pull_attachments", return_value=False), \
                patch.object(verify, "prune_attachments") as prune:
            self.assertEqual(verify.collect_attachments("bundle", "out", self.root,
                                                        "*.png", 300, self.handle), 0)
        prune.assert_not_called()

    def test_partial_pull_preserves_arrived_screenshot_without_pruning(self):
        def partial(out, stage, handle, timeout):
            (stage / "proof.png").write_bytes(b"png")
            return False

        with patch.object(verify, "attachment_ssh", return_value=0), \
                patch.object(verify, "pull_attachments", side_effect=partial), \
                patch.object(verify, "prune_attachments") as prune:
            self.assertEqual(verify.collect_attachments("bundle", "out", self.root,
                                                        "*.png", 300, self.handle), 1)
        self.assertEqual((self.root / "proof.png").read_bytes(), b"png")
        self.assertIn("files=1 bytes=3 success=False", self.handle.getvalue())
        prune.assert_not_called()

    def test_prune_keeps_six_and_stays_inside_worktree_artifacts(self):
        workspace = self.root / "workspace with ' quote"
        artifacts = workspace / "artifacts"
        artifacts.mkdir(parents=True)
        names = []
        for index in range(10):
            name = (f"unit-{index}.xcresult" if index % 2 == 0
                    else f"ui-Proof-{index}-attachments")
            entry = artifacts / name
            entry.mkdir()
            (entry / "payload").write_bytes(b"data")
            os.utime(entry, (100 + index, 100 + index))
            names.append(name)
        export = artifacts / "ui-Proof-99-attachments"
        export.mkdir()
        unrelated = artifacts / "ui-not-created-by-script"
        unrelated.mkdir()
        outside = workspace / "ui-Proof-0.xcresult"
        outside.mkdir()

        def remote(command, handle, timeout):
            self.assertEqual(timeout, 120)
            tokens = shlex.split(command)
            self.assertEqual(tokens[:2], ["python3", "-c"])
            self.assertEqual(tokens[3:], [str(workspace), str(export)])
            with patch.object(sys, "argv", ["-c"] + tokens[3:]):
                exec(compile(tokens[2], "<remote cleanup>", "exec"), {"__name__": "__main__"})
            return 0

        with patch.object(verify, "REMOTE", str(workspace)), \
                patch.object(verify, "attachment_ssh", side_effect=remote):
            verify.prune_attachments(str(export), self.handle)
        self.assertFalse(export.exists())
        self.assertTrue(unrelated.exists())
        self.assertTrue(outside.exists())
        self.assertEqual(sorted(p.name for p in artifacts.iterdir() if p != unrelated), sorted(names[4:]))

    def test_prune_rejects_export_outside_artifacts(self):
        workspace = self.root / "work"
        (workspace / "artifacts").mkdir(parents=True)
        outside = self.root / "ui-Proof-1-attachments"
        outside.mkdir()
        with patch.object(verify, "REMOTE", str(workspace)), \
                patch.object(verify, "attachment_ssh", return_value=0) as remote:
            verify.prune_attachments(str(outside), self.handle)
        tokens = shlex.split(remote.call_args.args[0])
        with patch.object(sys, "argv", ["-c"] + tokens[3:]), self.assertRaises(ValueError):
            exec(compile(tokens[2], "<remote cleanup>", "exec"), {})
        self.assertTrue(outside.exists())

    def test_main_screenshot_exit_policy_and_defaults(self):
        for test_rc, count, expected in ((0, 0, 1), (0, 1, 0), (65, 1, 65), (65, 0, 65)):
            with self.subTest(test_rc=test_rc, count=count), \
                    patch.object(sys, "argv", ["mac_verify.py", "--ui", "Proof", "--no-sync",
                                               "--screenshots", str(self.root / "shots"),
                                               "--log", str(self.root / "verify.log")]), \
                    patch.object(verify, "ssh", side_effect=[0, test_rc]), \
                    patch.object(verify, "collect_attachments", return_value=count) as collect:
                self.assertEqual(verify.main(), expected)
                self.assertEqual(collect.call_args.args[3:5], ("*.png", 300))

    def test_without_screenshots_does_not_export_pull_or_prune(self):
        with patch.object(sys, "argv", ["mac_verify.py", "--ui", "Proof", "--no-sync",
                                       "--log", str(self.root / "verify.log")]), \
                patch.object(verify, "ssh", side_effect=[0, 0]), \
                patch.object(verify, "collect_attachments") as collect:
            self.assertEqual(verify.main(), 0)
        collect.assert_not_called()

    def test_main_passes_custom_filter_and_pull_timeout(self):
        with patch.object(sys, "argv", ["mac_verify.py", "--ui", "Proof", "--no-sync",
                                       "--screenshots", str(self.root / "shots"),
                                       "--screenshot-filter", "*", "--pull-timeout", "12.5",
                                       "--log", str(self.root / "verify.log")]), \
                patch.object(verify, "ssh", side_effect=[0, 0]), \
                patch.object(verify, "collect_attachments", return_value=1) as collect:
            self.assertEqual(verify.main(), 0)
        self.assertEqual(collect.call_args.args[3:5], ("*", 12.5))


class MiniLockTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.gates = self.root / "gates"
        self.gates.mkdir()
        self.lock = self.gates / "mini-ios-test.lock"
        self.hold = self.gates / "MINI_HOLD"
        self.clock = Clock()
        self.sleeps = []
        self.handle = io.StringIO()
        self.stack = contextlib.ExitStack()
        self.addCleanup(self.stack.close)
        for name, value in (("GATES", self.gates), ("LOCK", self.lock), ("HOLD", self.hold)):
            self.stack.enter_context(patch.object(verify, name, value))
        self.stack.enter_context(patch.object(verify.time, "monotonic", self.clock))
        self.stack.enter_context(patch.object(verify.time, "sleep", side_effect=self.sleep))
        self.stack.enter_context(patch.object(verify.time, "time", return_value=1700000100.5))
        self.stack.enter_context(patch.dict(os.environ, {verify.HELD_ENV: "", verify.REMOTE_LOCK_HELD_ENV: "",
                                                        "MINI_ALLOC": "0", "MINI_ALLOC_TICKET": ""}))
        self.stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
        self.stack.enter_context(contextlib.redirect_stderr(io.StringIO()))
        self.stack.enter_context(patch.object(verify.subprocess, "run",
                                             side_effect=AssertionError("unexpected subprocess")))
        self.stack.enter_context(patch.object(verify.subprocess, "Popen",
                                             side_effect=AssertionError("unexpected subprocess")))

    def sleep(self, seconds):
        self.sleeps.append(seconds)
        self.clock.now += seconds

    def write_holder(self, text="other 4242 1700000100.5\n"):
        self.lock.write_text(text, encoding="utf-8")
        return text

    def main(self, *extra, applies=True, ssh_effect=None):
        with patch.object(sys, "argv", ["mac_verify.py", "--core", "--no-sync",
                                       "--log", str(self.root / "verify.log"), *extra]), \
                patch.object(verify, "lock_applies", return_value=applies), \
                patch.object(verify, "ssh", side_effect=ssh_effect, return_value=0) as ssh:
            result = verify.main()
        return result, ssh

    def test_free_lock_and_release(self):
        token = verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertEqual(self.lock.read_text(encoding="utf-8"), token)
        self.assertRegex(token, rf"^ours {os.getpid()} [0-9]+\.[0-9]+\n$")
        verify.release_mini_lock(token, self.handle)
        self.assertFalse(self.lock.exists())

    def test_hold_prevents_acquisition(self):
        self.hold.touch()
        with self.assertRaisesRegex(verify.LockUnavailable, "operator hold"):
            verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertFalse(self.lock.exists())

    def test_fdopen_failure_removes_lock_and_closes_descriptor(self):
        with patch.object(verify.os, "fdopen", side_effect=OSError("fdopen failed")) as fdopen, \
                patch.object(verify.os, "close", wraps=os.close) as close, \
                self.assertRaisesRegex(OSError, "fdopen failed"):
            verify.acquire_mini_lock("ours", 60, self.handle)
        close.assert_called_once_with(fdopen.call_args.args[0])
        self.assertFalse(self.lock.exists())

    def test_write_failure_removes_lock(self):
        real_fdopen = os.fdopen
        for prefix_length in (0, 5):
            def failing_stream(fd, *args, **kwargs):
                real_stream = real_fdopen(fd, *args, **kwargs)
                stream = MagicMock()
                stream.__enter__.return_value = stream
                stream.__exit__.side_effect = real_stream.__exit__

                def write(token):
                    real_stream.write(token[:prefix_length])
                    real_stream.flush()
                    raise OSError("write failed")

                stream.write.side_effect = write
                return stream

            with self.subTest(prefix_length=prefix_length), \
                    patch.object(verify.os, "fdopen", side_effect=failing_stream), \
                    patch.object(verify.os, "close", wraps=os.close) as close, \
                    self.assertRaisesRegex(OSError, "write failed"):
                verify.acquire_mini_lock("ours", 60, self.handle)
            close.assert_not_called()
            self.assertFalse(self.lock.exists())

    def test_close_interrupt_removes_lock(self):
        real_fdopen = os.fdopen

        def interrupting_stream(fd, *args, **kwargs):
            real_stream = real_fdopen(fd, *args, **kwargs)
            stream = MagicMock()
            stream.__enter__.return_value = real_stream

            def close(*exc):
                real_stream.close()
                raise KeyboardInterrupt

            stream.__exit__.side_effect = close
            return stream

        with patch.object(verify.os, "fdopen", side_effect=interrupting_stream), \
                self.assertRaises(KeyboardInterrupt):
            verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertFalse(self.lock.exists())

    def test_taken_log_failure_removes_lock(self):
        def fail_log(handle, text):
            self.assertIn("mini lock taken", text)
            raise OSError("log failed")

        with patch.object(verify, "log", side_effect=fail_log), \
                self.assertRaisesRegex(OSError, "log failed"):
            verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertFalse(self.lock.exists())

    def test_taken_log_failure_preserves_replacement(self):
        replacement = "other 4242 1700000100.5\n"

        def fail_log(handle, text):
            self.assertIn("mini lock taken", text)
            self.write_holder(replacement)
            raise RuntimeError("log failed")

        with patch.object(verify, "log", side_effect=fail_log), \
                self.assertRaisesRegex(RuntimeError, "log failed"):
            verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertEqual(self.lock.read_text(encoding="utf-8"), replacement)

    def test_long_wait_keeps_fresh_epoch(self):
        start = 1700000100.5
        self.write_holder(f"other 4242 {start}\n")

        def release_after_wait(seconds):
            self.sleep(seconds)
            if self.clock.now >= 3600:
                self.lock.unlink()

        with patch.object(verify, "pid_alive", return_value=True), \
                patch.object(verify.time, "time", side_effect=lambda: start + self.clock.now), \
                patch.object(verify.time, "sleep", side_effect=release_after_wait):
            token = verify.acquire_mini_lock("ours", 7200, self.handle)
        self.assertGreaterEqual(self.clock.now, 3600)
        self.assertGreater(len(self.sleeps), 1)
        self.assertEqual(verify.parse_holder(token)[2], start + self.clock.now)
        self.assertEqual(self.lock.read_text(encoding="utf-8"), token)

    def test_dead_holder_takeover(self):
        self.write_holder()
        with patch.object(verify, "pid_alive", return_value=False):
            token = verify.acquire_mini_lock("ours", 0, self.handle)
        self.assertEqual(self.lock.read_text(), token)
        self.assertIn("took over stale lock from other", self.handle.getvalue())

    def test_old_live_holder_takeover(self):
        self.write_holder(f"old 4242 {verify.time.time() - 7201}\n")
        with patch.object(verify, "pid_alive", return_value=True):
            token = verify.acquire_mini_lock("ours", 0, self.handle)
        self.assertEqual(self.lock.read_text(), token)

    def test_live_holder_wait_is_bounded_and_logged_once(self):
        original = self.write_holder()
        with patch.object(verify, "pid_alive", return_value=True), \
                self.assertRaisesRegex(verify.LockUnavailable, "other"):
            verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertEqual(self.lock.read_text(), original)
        self.assertEqual(sum(self.sleeps), 60)
        self.assertTrue(all(0 < seconds <= 20 for seconds in self.sleeps))
        self.assertEqual(self.handle.getvalue().count("mini lock held by"), 1)

    def test_holder_releases_during_sleep(self):
        self.write_holder()

        def release(seconds):
            self.sleep(seconds)
            self.lock.unlink()

        with patch.object(verify, "pid_alive", return_value=True), \
                patch.object(verify.time, "sleep", side_effect=release):
            token = verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertEqual(self.lock.read_text(), token)
        self.assertEqual(self.sleeps, [20])

    def test_unparseable_holder_is_preserved(self):
        for content in ("garbage", "other bad 1", "other 42 nan", "other 42 inf"):
            with self.subTest(content=content):
                self.write_holder(content)
                with self.assertRaises(verify.LockUnavailable):
                    verify.acquire_mini_lock("ours", 25, self.handle)
                self.assertEqual(self.lock.read_text(), content)

    def test_zero_wait_does_not_sleep(self):
        original = self.write_holder()
        with patch.object(verify, "pid_alive", return_value=True), \
                self.assertRaises(verify.LockUnavailable):
            verify.acquire_mini_lock("ours", 0, self.handle)
        self.assertEqual(self.lock.read_text(), original)
        self.assertEqual(self.sleeps, [])

    def test_repeated_disappearance_zero_wait_is_bounded(self):
        with patch.object(verify.os, "open", side_effect=FileExistsError("exists")) as opener, \
                self.assertRaisesRegex(verify.LockUnavailable, "vanished"):
            verify.acquire_mini_lock("ours", 0, self.handle)
        self.assertEqual(self.sleeps, [])
        self.assertLessEqual(opener.call_count, verify.LOCK_IMMEDIATE_RETRIES + 1)
        self.assertFalse(self.lock.exists())

    def test_repeated_disappearance_wait_is_bounded(self):
        with patch.object(verify.os, "open", side_effect=FileExistsError("exists")) as opener, \
                self.assertRaises(verify.LockUnavailable):
            verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertGreaterEqual(self.clock.now, 60)
        self.assertTrue(all(0 < seconds <= 20 for seconds in self.sleeps))
        self.assertLessEqual(opener.call_count,
                             (verify.LOCK_IMMEDIATE_RETRIES + 1) * (len(self.sleeps) + 1))

    def test_repeated_stale_replacement_zero_wait_is_bounded(self):
        def replace_then_exist(*args, **kwargs):
            self.write_holder()
            raise FileExistsError("exists")

        with patch.object(verify, "pid_alive", return_value=False), \
                patch.object(verify.os, "open", side_effect=replace_then_exist) as opener, \
                self.assertRaisesRegex(verify.LockUnavailable, "other"):
            verify.acquire_mini_lock("ours", 0, self.handle)
        self.assertEqual(self.sleeps, [])
        self.assertLessEqual(opener.call_count, verify.LOCK_IMMEDIATE_RETRIES + 1)

    def test_vanished_during_stale_recheck_retries_without_sleep(self):
        self.write_holder()
        real_read = Path.read_text
        reads = []

        def read_text(path, *args, **kwargs):
            if path == self.lock:
                reads.append(path)
                if len(reads) == 2:
                    path.unlink()
                    raise FileNotFoundError(str(path))
            return real_read(path, *args, **kwargs)

        with patch.object(verify, "pid_alive", return_value=False), \
                patch.object(type(self.lock), "read_text", read_text):
            token = verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertEqual(len(reads), 2)
        self.assertEqual(self.lock.read_text(encoding="utf-8"), token)
        self.assertEqual(self.sleeps, [])

    def test_create_permission_error_zero_wait(self):
        original = self.write_holder()
        with patch.object(verify.os, "open", side_effect=PermissionError("pending delete")), \
                self.assertRaisesRegex(verify.LockUnavailable, "PermissionError"):
            verify.acquire_mini_lock("ours", 0, self.handle)
        self.assertEqual(self.sleeps, [])
        self.assertEqual(self.lock.read_text(encoding="utf-8"), original)

    def test_create_permission_error_then_success(self):
        real_open = os.open
        calls = []

        def open_once_denied(*args, **kwargs):
            calls.append(args)
            if len(calls) == 1:
                raise PermissionError("pending delete")
            return real_open(*args, **kwargs)

        with patch.object(verify.os, "open", side_effect=open_once_denied):
            token = verify.acquire_mini_lock("ours", 60, self.handle)
        self.assertEqual(len(self.sleeps), 1)
        self.assertEqual(len(calls), 2)
        self.assertEqual(self.lock.read_text(encoding="utf-8"), token)

    def test_release_preserves_replacement_and_none(self):
        original = self.write_holder()
        verify.release_mini_lock("ours 1 2\n", self.handle)
        verify.release_mini_lock(None, self.handle)
        self.assertEqual(self.lock.read_text(), original)
        self.assertIn("content changed to other", self.handle.getvalue())

    def test_windows_pid_probe_exact_match_and_fail_safe(self):
        cases = [
            (subprocess.CompletedProcess([], 0, '"app.exe","1234","Console"'), True),
            (subprocess.CompletedProcess([], 0, ""), True),
            (subprocess.CompletedProcess([], 0, "garbage\n"), True),
            (subprocess.CompletedProcess([], 0, '"app.exe","1234","Console"\ngarbage\n'), True),
            (subprocess.CompletedProcess([], 0, '"app.exe","123","Console"'), True),
            (subprocess.CompletedProcess([], 0, "INFO: No tasks are running..."), False),
            (subprocess.CompletedProcess([], 0,
                                         "INFO: No tasks are running which match the specified criteria.\n"), False),
            (subprocess.CompletedProcess([], 1, ""), True),
            (OSError("unavailable"), True),
            (subprocess.TimeoutExpired("tasklist", 60), True),
        ]
        for result, expected in cases:
            with self.subTest(result=result):
                kwargs = ({"side_effect": result} if isinstance(result, Exception)
                          else {"return_value": result})
                with patch.object(verify.os, "name", "nt"), \
                        patch.object(verify.subprocess, "run", **kwargs) as run:
                    actual = verify.pid_alive(123)
                self.assertEqual(actual, expected)
                run.assert_called_once_with(
                    ["tasklist", "/FI", "PID eq 123", "/NH", "/FO", "CSV"],
                    capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)

    def test_main_holds_lock_during_remote_leg(self):
        def remote(*args):
            self.assertTrue(self.lock.exists())
            self.assertTrue(self.lock.read_text().startswith(verify.lock_name() + " "))
            return 0

        result, ssh = self.main(ssh_effect=remote)
        self.assertEqual(result, 0)
        ssh.assert_called_once()
        self.assertFalse(self.lock.exists())

    def test_main_releases_on_sync_system_exit(self):
        def failed_sync(handle):
            self.assertTrue(self.lock.exists())
            raise SystemExit("sync failed")

        with patch.object(sys, "argv", ["mac_verify.py", "--core", "--log",
                                       str(self.root / "verify.log")]), \
                patch.object(verify, "lock_applies", return_value=True), \
                patch.object(verify, "sync", side_effect=failed_sync), \
                self.assertRaises(SystemExit):
            verify.main()
        self.assertFalse(self.lock.exists())

    def test_main_releases_on_keyboard_interrupt_and_failed_leg(self):
        with self.assertRaises(KeyboardInterrupt):
            self.main(ssh_effect=KeyboardInterrupt)
        self.assertFalse(self.lock.exists())
        result, _ = self.main(ssh_effect=lambda *args: 65)
        self.assertEqual(result, 65)
        self.assertFalse(self.lock.exists())

    def test_caller_held_lock_is_preserved_even_with_hold(self):
        original = self.write_holder("wrapper 4242 1700000000.5\n")
        self.hold.touch()
        with patch.dict(os.environ, {verify.HELD_ENV: original.strip()}), \
                patch.object(verify, "acquire_mini_lock") as acquire:
            result, ssh = self.main()
        self.assertEqual(result, 0)
        ssh.assert_called_once()
        acquire.assert_not_called()
        self.assertEqual(self.lock.read_text(), original)

    def test_caller_token_mismatch(self):
        original = self.write_holder()
        with patch.dict(os.environ, {verify.HELD_ENV: "wrapper 4242 1700000000.5"}):
            result, ssh = self.main()
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertEqual(self.lock.read_text(), original)

    def test_caller_token_whitespace_mismatch(self):
        original = self.write_holder("wrapper 4242 1700000000.5\n")
        for held in (" wrapper 4242 1700000000.5", "wrapper  4242 1700000000.5",
                     "wrapper 4242 1700000000.5 ", original + "\n"):
            with self.subTest(held=held), patch.dict(os.environ, {verify.HELD_ENV: held}):
                result, ssh = self.main()
            self.assertEqual(result, 75)
            ssh.assert_not_called()
            self.assertEqual(self.lock.read_text(), original)

    def test_caller_token_with_exact_trailing_newline(self):
        original = self.write_holder("wrapper 4242 1700000000.5\n")
        with patch.dict(os.environ, {verify.HELD_ENV: original}):
            result, ssh = self.main()
        self.assertEqual(result, 0)
        ssh.assert_called_once()
        self.assertEqual(self.lock.read_text(), original)

    def test_caller_token_without_lock(self):
        with patch.dict(os.environ, {verify.HELD_ENV: "wrapper 4242 1700000000.5"}):
            result, ssh = self.main()
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertFalse(self.lock.exists())

    def test_main_hold(self):
        self.hold.touch()
        result, ssh = self.main()
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertFalse(self.lock.exists())

    def test_nonparticipating_host_ignores_caller_token(self):
        with patch.dict(os.environ, {verify.HELD_ENV: "wrapper 4242 1700000000.5"}), \
                patch.object(verify, "verify_held_lock") as held, \
                patch.object(verify, "acquire_mini_lock") as acquire:
            result, ssh = self.main(applies=False)
        self.assertEqual(result, 0)
        ssh.assert_called_once()
        held.assert_not_called()
        acquire.assert_not_called()
        self.assertFalse(self.lock.exists())

    def test_invalid_lock_wait(self):
        for value in ("-1", "nan", "inf", "1e308", "1441"):
            with self.subTest(value=value), self.assertRaises(SystemExit) as raised:
                self.main("--lock-wait", value)
            self.assertEqual(raised.exception.code, 2)
        self.assertFalse(self.lock.exists())

    def test_maximum_lock_wait_is_allowed(self):
        result, ssh = self.main("--lock-wait", "1440", applies=False)
        self.assertEqual(result, 0)
        ssh.assert_called_once()
        self.assertFalse(self.lock.exists())

    def test_lock_name_has_no_whitespace(self):
        with patch.object(verify, "REMOTE", "~/leafhft verify\t two"):
            self.assertEqual(verify.lock_name(), "leafhft-mac-verify:leafhft_verify_two")

    def test_holder_description(self):
        self.assertEqual(verify.describe_holder("wrapper 4242 1700000000.5\n"),
                         "wrapper (pid 4242, taken 2023-11-14T22:13:20Z, 100 s ago)")
        self.assertEqual(verify.describe_holder("bad"), "unparseable lock content 'bad'")

    def test_lock_applies_only_on_participating_windows_host(self):
        with patch.object(verify.os, "name", "nt"):
            self.assertTrue(verify.lock_applies())
        with patch.object(verify.os, "name", "posix"):
            self.assertFalse(verify.lock_applies())
        self.gates.rmdir()
        with patch.object(verify.os, "name", "nt"):
            self.assertFalse(verify.lock_applies())
        self.assertFalse(self.gates.exists())


TOKEN = "0123456789abcdef0123456789abcdef"
ACQUIRED = json.dumps({"schema": "leaf.mini-ios-lock.v1", "owner": "windows:leafhft-mac-verify:x",
                       "host": "remote", "token": TOKEN, "expires_at": 1700007300.0})


def completed(code, stdout="", stderr=""):
    return subprocess.CompletedProcess([], code, stdout, stderr)


class RemoteLockTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.gates = self.root / "gates"
        self.gates.mkdir()
        self.lock = self.gates / "mini-ios-test.lock"
        self.hold = self.gates / "MINI_HOLD"
        self.log_path = self.root / "verify.log"
        self.clock = Clock()
        self.events = []
        self.calls = []
        self.out = io.StringIO()
        self.err = io.StringIO()
        self.stack = contextlib.ExitStack()
        self.addCleanup(self.stack.close)
        for name, value in (("GATES", self.gates), ("LOCK", self.lock), ("HOLD", self.hold)):
            self.stack.enter_context(patch.object(verify, name, value))
        self.stack.enter_context(patch.object(verify.time, "monotonic", self.clock))
        self.stack.enter_context(patch.object(verify.time, "sleep", side_effect=self.sleep))
        self.stack.enter_context(patch.object(verify.time, "time", return_value=1700000100.5))
        self.stack.enter_context(patch.dict(os.environ))
        os.environ["MINI_ALLOC"] = "0"
        os.environ.pop("MINI_ALLOC_TICKET", None)
        os.environ.pop(verify.HELD_ENV, None)
        os.environ.pop(verify.REMOTE_LOCK_HELD_ENV, None)
        self.stack.enter_context(contextlib.redirect_stdout(self.out))
        self.stack.enter_context(contextlib.redirect_stderr(self.err))
        self.stack.enter_context(patch.object(verify.subprocess, "Popen",
                                             side_effect=AssertionError("unexpected subprocess")))
        real_release = verify.release_mini_lock

        def windows_release(token, handle):
            self.events.append("windows-release")
            return real_release(token, handle)

        self.stack.enter_context(patch.object(verify, "release_mini_lock", side_effect=windows_release))

    def sleep(self, seconds):
        self.clock.now += seconds

    def fake_run(self, acquire, release=None):
        def run(argv, **kwargs):
            command = argv[-1]
            if " acquire " in command:
                kind, outcome = "acquire", acquire
            elif " release " in command:
                kind, outcome = "release", release
            else:
                raise AssertionError("unexpected subprocess " + repr(argv))
            self.events.append(kind)
            self.calls.append((kind, argv, kwargs))
            if isinstance(outcome, BaseException):
                raise outcome
            if outcome is None:
                raise AssertionError("no outcome for " + kind)
            return outcome
        return run

    def leg(self, *args):
        self.events.append("leg")
        self.assertTrue(self.lock.exists())
        self.assertIn("acquire", self.events)
        self.assertNotIn("release", self.events)
        return 0

    def main(self, *extra, run=None, applies=True):
        run_effect = run if run is not None else AssertionError("unexpected subprocess")
        leg = self.leg if run is not None else (lambda *args: 0)
        self.events.clear()
        self.calls.clear()
        with patch.object(sys, "argv", ["mac_verify.py", "--core", "--no-sync",
                                       "--log", str(self.log_path), *extra]), \
                patch.object(verify, "lock_applies", return_value=applies), \
                patch.object(verify.subprocess, "run", side_effect=run_effect) as runner, \
                patch.object(verify, "ssh", side_effect=leg) as ssh:
            result = verify.main()
        return result, ssh, runner

    def kinds(self):
        return [kind for kind, _, _ in self.calls]

    def acquire_words(self):
        argv = next(argv for kind, argv, _ in self.calls if kind == "acquire")
        return shlex.split(argv[-1])

    def log_text(self):
        return self.log_path.read_text(encoding="utf-8")

    def test_acquired_and_released(self):
        result, ssh, _ = self.main("--lock-wait", "60",
                                   run=self.fake_run(completed(0, ACQUIRED), completed(0)))
        self.assertEqual(result, 0)
        ssh.assert_called_once()
        self.assertEqual(self.events, ["acquire", "leg", "release", "windows-release"])
        self.assertFalse(self.lock.exists())
        kind, argv, kwargs = self.calls[0]
        self.assertEqual(kind, "acquire")
        self.assertIn("BatchMode=yes", argv)
        self.assertTrue(any(word.startswith("ConnectTimeout=") for word in argv))
        self.assertEqual(kwargs["stdin"], subprocess.DEVNULL)
        self.assertTrue(math.isfinite(kwargs["timeout"]))
        words = shlex.split(argv[-1])
        self.assertEqual(words[words.index("--host") + 1], "remote")
        self.assertEqual(words[words.index("--ttl") + 1], "7200")
        self.assertLessEqual(int(words[words.index("--wait-seconds") + 1]), 60 * 60)
        self.assertRegex(words[words.index("--owner") + 1],
                         rf"^windows:{re.escape(verify.lock_name())}-[0-9a-f]{{12}}$")
        kind, argv, kwargs = self.calls[1]
        self.assertEqual(kind, "release")
        self.assertIn(f"--token {TOKEN}", argv[-1])
        self.assertTrue(math.isfinite(kwargs["timeout"]))
        self.assertIn("on-mini lock released", self.log_text())

    def test_held(self):
        held = completed(75, json.dumps({"held_by": "windows:other-run", "expires_at": 1700003700.0}))
        result, ssh, _ = self.main(run=self.fake_run(held))
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertEqual(self.kinds(), ["acquire"])
        self.assertIn("windows-release", self.events)
        self.assertFalse(self.lock.exists())
        text = self.log_text()
        self.assertIn("on-mini lock held by windows:other-run (expires 2023-11-14T23:15:00Z)", text)

    def test_huge_expires_at_omits_expiry(self):
        held = completed(75, '{"held_by": "windows:other", "expires_at": ' + "9" * 400 + "}")
        result, ssh, _ = self.main(run=self.fake_run(held))
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertEqual(self.kinds(), ["acquire"])
        self.assertFalse(self.lock.exists())
        self.assertIn("on-mini lock held by windows:other", self.log_text())
        self.assertNotIn("expires", self.log_text())

    def test_deeply_nested_acquire_response_fails_closed(self):
        stdout = "[" * 100000 + "]" * 100000
        for code in (75, 0):
            with self.subTest(code=code):
                result, ssh, _ = self.main(run=self.fake_run(completed(code, stdout)))
                self.assertEqual(result, 75)
                ssh.assert_not_called()
                self.assertEqual(self.kinds(), ["acquire"])
                self.assertFalse(self.lock.exists())
                self.assertIn("invalid response", self.log_text())

    def test_unexpected_acquire_parser_error_fails_closed(self):
        token = "0123456789abcdef0123456789abcdef"
        with patch.object(verify, "parse_acquire_response", side_effect=RuntimeError("boom " + token)):
            result, ssh, _ = self.main(run=self.fake_run(completed(0, ACQUIRED)))
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertEqual(self.kinds(), ["acquire"])
        self.assertFalse(self.lock.exists())
        for text in (self.log_text(), self.out.getvalue() + self.err.getvalue()):
            self.assertIn("invalid response", text)
            self.assertNotIn("boom", text)
            self.assertNotIn(token, text)

    def test_parse_acquire_response(self):
        self.assertEqual(verify.parse_acquire_response(completed(0, ACQUIRED)), TOKEN)
        with self.assertRaisesRegex(verify.LockUnavailable, "HOLD"):
            verify.parse_acquire_response(completed(75, json.dumps({"held_by": "hold"})))

    def test_held_by_redacts_tokens(self):
        for token in (TOKEN, "ABCDEF0123456789ABCDEF0123456789"):
            with self.subTest(token=token):
                held = completed(75, json.dumps({"held_by": f"windows:other token={token}",
                                                  "expires_at": None}))
                result, ssh, _ = self.main(run=self.fake_run(held))
                self.assertEqual(result, 75)
                ssh.assert_not_called()
                self.assertFalse(self.lock.exists())
                for text in (self.log_text(), self.out.getvalue() + self.err.getvalue()):
                    self.assertIn("<redacted>", text)
                    self.assertIn("windows:other", text)
                    for start in range(len(token) - 7):
                        self.assertNotIn(token[start:start + 8], text)

    def test_held_by_cannot_forge_log_lines(self):
        held = completed(75, json.dumps({"held_by": "x\nLOG C:/forged.log\r\x1b[31mred",
                                          "expires_at": None}))
        result, ssh, _ = self.main(run=self.fake_run(held))
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertFalse(self.lock.exists())
        with self.log_path.open(encoding="utf-8", newline="") as handle:
            text = handle.read().replace("\r\n", "\n")
        self.assertFalse(any(line.startswith("LOG C:/forged.log") for line in text.splitlines()))
        self.assertNotIn("\x1b", text)
        self.assertNotIn("\r", text)

    def test_held_by_is_bounded(self):
        held = completed(75, json.dumps({"held_by": "a" * 10000, "expires_at": None}))
        result, ssh, _ = self.main(run=self.fake_run(held))
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertFalse(self.lock.exists())
        self.assertTrue(all(len(line) <= 400 for line in self.log_text().splitlines()))

    def test_lock_failure_logging_backstop(self):
        with patch.object(verify, "acquire_remote_lock",
                          side_effect=verify.LockUnavailable("synthetic " + TOKEN)):
            result, ssh, runner = self.main()
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        runner.assert_not_called()
        self.assertFalse(self.lock.exists())
        for text in (self.log_text(), self.out.getvalue() + self.err.getvalue()):
            self.assertNotIn(TOKEN, text)
            self.assertIn("<redacted>", text)

    def test_remote_text(self):
        self.assertEqual(verify.remote_text("Z" * 10 + TOKEN, 12, tail=True), "ZZ<redacted>")
        self.assertEqual(verify.remote_text("a\tb\nc", 50), "a?b?c")
        self.assertEqual(verify.remote_text("x" * 50, 10), "x" * 10)

    def test_operator_hold_on_the_mini(self):
        held = completed(75, json.dumps({"held_by": "hold", "expires_at": None}))
        result, ssh, _ = self.main(run=self.fake_run(held))
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertEqual(self.kinds(), ["acquire"])
        self.assertFalse(self.lock.exists())
        self.assertIn("~/.mini-locks/HOLD", self.log_text())

    def test_failure(self):
        cases = [
            (completed(1, "", "ssh: connect to host mac-mini port 22: refused\n"),
             "on-mini lock unavailable: exit 1: ssh: connect to host mac-mini port 22: refused"),
            (completed(0, "not json"), "on-mini lock unavailable: invalid response"),
            (completed(0, json.dumps({"token": "XYZ"})), "on-mini lock unavailable: invalid token"),
            (completed(75, json.dumps({"held_by": 7})), "on-mini lock unavailable: invalid response"),
            (OSError("no ssh"), "on-mini lock unavailable: ssh could not start"),
            (subprocess.TimeoutExpired("ssh", 3720), "on-mini lock unavailable: timed out after"),
        ]
        for outcome, message in cases:
            with self.subTest(outcome=outcome):
                result, ssh, _ = self.main(run=self.fake_run(outcome))
                self.assertEqual(result, 75)
                ssh.assert_not_called()
                self.assertEqual(self.kinds(), ["acquire"])
                self.assertIn("windows-release", self.events)
                self.assertFalse(self.lock.exists())
                self.assertIn(message, self.log_text())

    def test_failure_redacts_stderr_tokens(self):
        uppercase_token = "ABCDEF0123456789ABCDEF0123456789ABCD"
        stderr = f"lock failure token={TOKEN} and {uppercase_token}\n"
        result, ssh, _ = self.main(run=self.fake_run(completed(1, "", stderr)))
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertEqual(self.kinds(), ["acquire"])
        self.assertFalse(self.lock.exists())
        self.assertIn("exit 1", self.log_text())
        for text in (self.log_text(), self.out.getvalue() + self.err.getvalue()):
            self.assertIn("<redacted>", text)
            self.assertNotIn(TOKEN, text)
            self.assertNotIn(uppercase_token, text)

    def test_failure_redacts_stderr_before_slicing_tail(self):
        stderr = TOKEN + "x" * 280
        result, ssh, _ = self.main(run=self.fake_run(completed(1, "", stderr)))
        self.assertEqual(result, 75)
        ssh.assert_not_called()
        self.assertEqual(self.kinds(), ["acquire"])
        self.assertFalse(self.lock.exists())
        self.assertIn("exit 1", self.log_text())
        for text in (self.log_text(), self.out.getvalue() + self.err.getvalue()):
            self.assertIn("<redacted>", text)
            for start in range(len(TOKEN) - 7):
                self.assertNotIn(TOKEN[start:start + 8], text)

    def test_failure_never_logs_stdout(self):
        secret = "SECRET-STDOUT-" + TOKEN
        result, _, _ = self.main(run=self.fake_run(completed(3, secret, "boom")))
        self.assertEqual(result, 75)
        self.assertNotIn(secret, self.log_text())
        self.assertNotIn(secret, self.out.getvalue() + self.err.getvalue())

    def test_mini_ios_lock_held_skips_it(self):
        for value in ("1", ""):
            with self.subTest(value=value), patch.dict(os.environ, {verify.REMOTE_LOCK_HELD_ENV: value}):
                result, ssh, runner = self.main()
                self.assertEqual(result, 0)
                ssh.assert_called_once()
                runner.assert_not_called()
                self.assertFalse(self.lock.exists())
                self.assertIn(f"on-mini lock held by caller ({verify.REMOTE_LOCK_HELD_ENV})", self.log_text())

    def test_token_never_in_log_or_console(self):
        releases = [(completed(0), "on-mini lock released"),
                    (completed(76, TOKEN, TOKEN), "on-mini lock release failed: exit 76"),
                    (OSError(TOKEN), "on-mini lock release failed: OSError")]
        for release, message in releases:
            with self.subTest(release=release):
                result, ssh, _ = self.main(run=self.fake_run(completed(0, ACQUIRED), release))
                self.assertEqual(result, 0)
                ssh.assert_called_once()
                self.assertEqual(self.kinds(), ["acquire", "release"])
                self.assertEqual(self.events[-2:], ["release", "windows-release"])
                self.assertFalse(self.lock.exists())
                text = self.log_text()
                self.assertIn(message, text)
                self.assertNotIn(TOKEN, text)
        self.assertNotIn(TOKEN, self.out.getvalue())
        self.assertNotIn(TOKEN, self.err.getvalue())

    def test_shared_budget_zero_wait_is_single_try(self):
        result, _, _ = self.main("--lock-wait", "0", run=self.fake_run(completed(0, ACQUIRED), completed(0)))
        self.assertEqual(result, 0)
        words = self.acquire_words()
        self.assertEqual(words[words.index("--wait-seconds") + 1], "0")
        self.assertEqual(self.calls[0][2]["timeout"], verify.REMOTE_LOCK_SLACK_S)

    def test_shared_budget_after_windows_wait(self):
        self.lock.write_text("other 4242 1700000100.5\n", encoding="utf-8")

        def release_after_wait(seconds):
            self.sleep(seconds)
            self.lock.unlink()

        with patch.object(verify, "pid_alive", return_value=True), \
                patch.object(verify.time, "sleep", side_effect=release_after_wait):
            result, _, _ = self.main("--lock-wait", "1",
                                     run=self.fake_run(completed(0, ACQUIRED), completed(0)))
        self.assertEqual(result, 0)
        words = self.acquire_words()
        self.assertEqual(words[words.index("--wait-seconds") + 1], "40")

    def test_non_participating_host(self):
        result, ssh, runner = self.main(applies=False)
        self.assertEqual(result, 0)
        ssh.assert_called_once()
        runner.assert_not_called()
        self.assertFalse(self.lock.exists())

    def test_leafhft_mini_lock_held_caller(self):
        original = "wrapper 4242 1700000000.5\n"
        self.lock.write_text(original, encoding="utf-8")
        with patch.dict(os.environ, {verify.HELD_ENV: original.strip()}):
            result, ssh, _ = self.main(run=self.fake_run(completed(0, ACQUIRED), completed(0)))
        self.assertEqual(result, 0)
        ssh.assert_called_once()
        self.assertEqual(self.kinds(), ["acquire", "release"])
        self.assertEqual(self.lock.read_text(encoding="utf-8"), original)


class AllocatorTests(unittest.TestCase):
    def setUp(self):
        self.stack = contextlib.ExitStack()
        self.addCleanup(self.stack.close)
        self.temp = self.stack.enter_context(tempfile.TemporaryDirectory())
        self.root = Path(self.temp)
        self.log_path = self.root / "verify.log"
        self.stack.enter_context(patch.dict(os.environ, {}, clear=True))
        self.stack.enter_context(patch.object(verify, "GATES", self.root))
        self.stack.enter_context(patch.object(verify, "lock_applies", return_value=True))
        self.stack.enter_context(patch.object(verify, "REMOTE", "~/leafhft-verify-c28208eea5"))
        self.stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
        self.windows = self.stack.enter_context(patch.object(verify, "acquire_mini_lock", return_value="windows"))
        self.remote = self.stack.enter_context(patch.object(verify, "acquire_remote_lock", return_value="remote"))
        self.release_windows = self.stack.enter_context(patch.object(verify, "release_mini_lock"))
        self.release_remote = self.stack.enter_context(patch.object(verify, "release_remote_lock"))
        self.held = SimpleNamespace(ticket="ticket-12345", lost=False, outcome=None,
                                    env={"MINI_ALLOC_TICKET": "ticket-12345", "MINI_IOS_LOCK_HELD": "1",
                                         "LEAFHFT_MINI_LOCK_HELD": "windows", "LEAFHFT_SIM_NAME": "pool-iPhone-7"})
        self.client = SimpleNamespace(AllocatorUnavailable=type("AllocatorUnavailable", (Exception,), {}),
                                      QueueTimeout=type("QueueTimeout", (Exception,), {}),
                                      LeaseLost=type("LeaseLost", (Exception,), {}))
        self.requests = []

        @contextlib.contextmanager
        def lease(**kwargs):
            self.requests.append(kwargs)
            yield self.held

        self.client.lease = lease
        self.real_loader = verify.load_alloc_client
        self.loader = self.stack.enter_context(patch.object(verify, "load_alloc_client", return_value=self.client))
        self.argvs = []
        self.exit_code = 0

        def popen(argv, **kwargs):
            self.argvs.append(argv)
            return SimpleNamespace(stdout=io.StringIO(""), wait=lambda: self.exit_code)

        self.stack.enter_context(patch.object(verify.subprocess, "Popen", side_effect=popen))

    def main(self, *args):
        with patch.object(sys, "argv", ["mac_verify.py", "--no-sync", "--log", str(self.log_path), *args]):
            return verify.main()

    def logs(self):
        return self.log_path.read_text(encoding="utf-8")

    def assert_wrapped(self, argv, timeout):
        words = shlex.split(argv[-1])
        self.assertEqual(words[:4], ["/usr/bin/python3", "~/bin/mini_alloc.py", "run", "--ticket"])
        self.assertEqual(words[4], "ticket-12345")
        self.assertEqual(words[5:10], ["--timeout-s", str(timeout), "--", "bash", "-c"])
        self.assertNotIn("--hangup-on-eof", words)
        return words[10]

    def test_already_leased_skips_locks_and_wraps_all_remote_helpers(self):
        os.environ.update(self.held.env)
        self.assertEqual(self.main("--unit"), 0)
        self.loader.assert_not_called()
        self.windows.assert_not_called()
        self.remote.assert_not_called()
        self.assertIn("running under ticket ticket-1", self.logs())
        for argv, timeout in zip(self.argvs, (1200, 300, 2400)):
            self.assert_wrapped(argv, timeout)
        handle = io.StringIO()
        producer = SimpleNamespace(stdout=io.BytesIO(), returncode=0, wait=lambda: 0)
        with patch.object(verify.subprocess, "Popen", return_value=producer), \
                patch.object(verify.subprocess, "run", return_value=completed(0)) as run:
            verify.sync(handle)
            self.assert_wrapped(run.call_args.args[0], 600)
            verify.attachment_ssh("echo 'attachments'", handle, 120)
            self.assertEqual(self.assert_wrapped(run.call_args.args[0], 120), "echo 'attachments'")
        clock = Clock()
        producer, consumer = Process(clock), Process(clock)
        with patch.object(verify.subprocess, "Popen", side_effect=[producer, consumer]) as popen:
            self.assertTrue(verify.pull_attachments("~/out", self.root, handle, 300))
            self.assert_wrapped(popen.call_args_list[0].args[0], 300)

    def test_held_windows_lock_skips_allocator_and_uses_legacy_path(self):
        original = "wrapper 4242 1700000000.5\n"
        lock = self.root / "mini-ios-test.lock"
        lock.write_text(original, encoding="utf-8")
        os.environ[verify.HELD_ENV] = original.strip()
        with patch.object(verify, "LOCK", lock), \
                patch.object(verify, "verify_held_lock", wraps=verify.verify_held_lock) as held:
            self.assertEqual(self.main("--core"), 0)
        held.assert_called_once_with(original.strip())
        self.loader.assert_not_called()
        self.assertEqual(self.requests, [])
        self.windows.assert_not_called()
        self.remote.assert_called_once()
        self.release_windows.assert_called_once_with(None, unittest.mock.ANY)
        self.release_remote.assert_called_once_with("remote", unittest.mock.ANY)
        self.assertEqual(lock.read_text(encoding="utf-8"), original)
        self.assertEqual(self.logs().count(
            "mini allocator: caller holds the legacy locks; not requesting an allocator slot"), 1)
        self.assertTrue(self.argvs[-1][-1].startswith("bash -c "))

    def test_held_remote_lock_alone_skips_allocator_and_uses_legacy_path(self):
        for value in ("1", ""):
            with self.subTest(value=value):
                os.environ[verify.REMOTE_LOCK_HELD_ENV] = value
                self.windows.reset_mock()
                self.release_windows.reset_mock()
                self.release_remote.reset_mock()
                self.assertEqual(self.main("--core"), 0)
                self.loader.assert_not_called()
                self.assertEqual(self.requests, [])
                self.windows.assert_called_once()
                self.remote.assert_not_called()
                self.release_windows.assert_called_once_with("windows", unittest.mock.ANY)
                self.release_remote.assert_called_once_with(None, unittest.mock.ANY)
                self.assertIn("on-mini lock held by caller", self.logs())
                self.assertEqual(self.logs().count(
                    "mini allocator: caller holds the legacy locks; not requesting an allocator slot"), 1)
                self.assertTrue(self.argvs[-1][-1].startswith("bash -c "))

    def test_ticket_has_priority_over_both_held_legacy_locks(self):
        os.environ.update(self.held.env)
        with patch.object(verify, "verify_held_lock") as held:
            self.assertEqual(self.main("--unit"), 0)
        self.loader.assert_not_called()
        self.assertEqual(self.requests, [])
        held.assert_not_called()
        self.windows.assert_not_called()
        self.remote.assert_not_called()
        self.assertIn("running under ticket ticket-1", self.logs())
        self.assertNotIn("caller holds the legacy locks; not requesting an allocator slot", self.logs())
        self.assertEqual(len(self.argvs), 3)
        for argv, timeout in zip(self.argvs, (1200, 300, 2400)):
            self.assert_wrapped(argv, timeout)

    def test_self_lease_rebinds_sim_and_restores_environment(self):
        original = verify.SIM_NAME
        self.assertEqual(self.main("--unit", "--alloc-deadline-s", "4000", "--lock-wait", "2"), 0)
        request = self.requests[0]
        self.assertEqual(request, dict(lane="leafhft-mac-verify", job=verify.lock_name(), slots="sim,build",
                                      deadline_s=3000, kind="mac_verify", markers=["leafhft-verify-c28208eea5"],
                                      sim_types=["iPhone 17"], queue_wait_s=120))
        command = self.assert_wrapped(self.argvs[-1], 2400)
        self.assertIn("name=pool-iPhone-7", command)
        self.assertEqual(verify.SIM_NAME, original)
        self.assertNotIn("MINI_ALLOC_TICKET", os.environ)
        self.assertEqual(self.held.outcome, "ok")
        self.windows.assert_not_called()
        self.remote.assert_not_called()

    def test_core_only_requests_build_without_sim_types(self):
        self.assertEqual(self.main("--core", "--alloc-deadline-s", "900"), 0)
        self.assertEqual(self.requests[0]["slots"], "build")
        self.assertNotIn("sim_types", self.requests[0])
        self.assertEqual(self.requests[0]["deadline_s"], 900)

    def test_unavailable_falls_back_to_both_legacy_locks(self):
        cases = (verify.LockUnavailable("MINI_ALLOC=0"), verify.LockUnavailable("client file missing"),
                 ImportError("broken import"), self.client.AllocatorUnavailable("offline"))
        for error in cases:
            with self.subTest(error=error):
                self.windows.reset_mock()
                self.remote.reset_mock()
                if isinstance(error, self.client.AllocatorUnavailable):
                    self.loader.side_effect = None
                    self.client.lease = MagicMock(side_effect=error)
                else:
                    self.loader.side_effect = error
                self.assertEqual(self.main("--core"), 0)
                self.windows.assert_called_once()
                self.remote.assert_called_once()
                self.release_remote.assert_called_with("remote", unittest.mock.ANY)
                self.release_windows.assert_called_with("windows", unittest.mock.ANY)
                self.assertIn("using the legacy locks", self.logs())
                self.assertTrue(self.argvs[-1][-1].startswith("bash -c "))

    def test_disabled_missing_and_off_file_use_real_loader_and_legacy_locks(self):
        os.environ["MINI_ALLOC_CLIENT"] = str(self.root / "missing.py")
        self.loader.side_effect = self.real_loader
        for reason in ("MINI_ALLOC=0", "client file missing", "MINI_ALLOC_OFF exists"):
            with self.subTest(reason=reason):
                self.windows.reset_mock()
                self.remote.reset_mock()
                if reason == "MINI_ALLOC=0":
                    os.environ["MINI_ALLOC"] = "0"
                else:
                    os.environ.pop("MINI_ALLOC", None)
                if reason == "MINI_ALLOC_OFF exists":
                    (self.root / "MINI_ALLOC_OFF").touch()
                self.assertEqual(self.main("--core"), 0)
                self.windows.assert_called_once()
                self.remote.assert_called_once()
                self.assertIn(f"unavailable ({reason}); using the legacy locks", self.logs())

    def test_client_loads_by_path_with_siblings_and_import_error_falls_back(self):
        path = self.root / "client.py"
        os.environ["MINI_ALLOC_CLIENT"] = str(path)
        path.write_text("import sys\nloaded_path = sys.path[0]\n", encoding="utf-8")
        original_path = list(sys.path)
        with patch.dict(sys.modules):
            module = self.real_loader()
            self.assertEqual(module.loaded_path, str(self.root))
        self.assertEqual(sys.path, original_path)
        path.write_text("raise ImportError('unavailable sibling')\n", encoding="utf-8")
        self.loader.side_effect = self.real_loader
        self.assertEqual(self.main("--core"), 0)
        self.windows.assert_called_once()
        self.remote.assert_called_once()
        self.assertIn("unavailable sibling", self.logs())
        self.assertEqual(sys.path, original_path)

    def test_queue_timeout_is_exit_75_and_redacted(self):
        secret = "a" * 32
        self.client.lease = MagicMock(side_effect=self.client.QueueTimeout(secret))
        self.assertEqual(self.main("--core"), 75)
        self.assertNotIn(secret, self.logs())
        self.assertIn("<redacted>", self.logs())
        self.assertFalse(verify.TOKEN_SHAPED_RE.search(self.logs()))
        self.windows.assert_not_called()
        self.remote.assert_not_called()
        self.assertEqual(self.argvs, [])

    def test_wrapper_exit_76_and_heartbeat_loss_are_infra(self):
        self.exit_code = 76
        self.assertEqual(self.main("--core"), 75)
        self.assertEqual(self.held.outcome, "infra")
        self.assertIn("mini allocator: lease lost", self.logs())
        self.exit_code = 0
        self.held.lost = True
        self.assertEqual(self.main("--core"), 75)
        self.assertEqual(self.held.outcome, "infra")

    def test_attachment_and_sync_wrapper_loss_reaches_main(self):
        for helper in ("sync", "attachment", "pull"):
            with self.subTest(helper=helper):
                clock = Clock()
                producer = Process(clock, code=76)
                consumer = Process(clock)

                def legs(args, handle, log_path):
                    if helper == "sync":
                        verify.sync(handle)
                    elif helper == "attachment":
                        verify.attachment_ssh("echo attachments", handle, 120)
                    else:
                        verify.pull_attachments("~/out", self.root, handle, 300)
                    return 0

                with patch.object(verify, "run_legs", side_effect=legs), \
                        patch.object(verify.subprocess, "run", return_value=completed(76)), \
                        patch.object(verify.subprocess, "Popen", side_effect=[producer, consumer]):
                    # sync's existing producer wait is unbounded; no real process is launched.
                    if helper == "sync":
                        producer.wait = lambda: 0
                    self.assertEqual(self.main("--core"), 75)
                self.assertEqual(self.held.outcome, "infra")
                self.assertIn("mini allocator: lease lost", self.logs())

    def test_client_lease_loss_on_exit_is_infra(self):
        @contextlib.contextmanager
        def lease(**kwargs):
            yield self.held
            raise self.client.LeaseLost("private details")

        self.client.lease = lease
        self.assertEqual(self.main("--core"), 75)
        self.assertEqual(self.held.outcome, "infra")
        self.assertIn("mini allocator: lease lost", self.logs())
        self.assertNotIn("private details", self.logs())

    def test_failure_outcome_and_nonparticipating_host(self):
        self.exit_code = 65
        self.assertEqual(self.main("--core"), 65)
        self.assertEqual(self.held.outcome, "fail")
        self.loader.reset_mock()
        os.environ.update(self.held.env)
        with patch.object(verify, "lock_applies", return_value=False):
            self.assertEqual(self.main("--core"), 65)
        self.loader.assert_not_called()
        self.assertTrue(self.argvs[-1][-1].startswith("bash -c "))

    def test_allocator_unavailable_diagnostic_redacts_tokens(self):
        secret = "B" * 40
        self.client.lease = MagicMock(side_effect=self.client.AllocatorUnavailable(secret))
        self.assertEqual(self.main("--core"), 0)
        self.assertNotIn(secret, self.logs())
        self.assertFalse(verify.TOKEN_SHAPED_RE.search(self.logs()))


if __name__ == "__main__":
    unittest.main()
