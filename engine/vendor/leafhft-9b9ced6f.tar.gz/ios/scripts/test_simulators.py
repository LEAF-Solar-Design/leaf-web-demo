"""Run one source-bound simulator rung from Windows and download its xcresult evidence."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shlex
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]


def transport(command, **kwargs):
    for attempt in range(3):
        result = subprocess.run(command, **kwargs)
        if result.returncode not in (124, 255) or attempt == 2:
            return result
        time.sleep(2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rung", type=int, choices=[2, 3])
    parser.add_argument("--runtime", default="26.2")
    parser.add_argument("--host", default="exzachly-aws-mac")
    parser.add_argument("--appearance", choices=["light", "dark"], help="Diagnostic appearance-only run; does not replace the full-rung receipt")
    args = parser.parse_args()
    if args.appearance and args.rung != 3:
        parser.error("Appearance diagnostics apply only to rung 3.")
    sha = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    if subprocess.check_output(["git", "status", "--porcelain", "--", "ios"], cwd=ROOT).strip():
        parser.error("Commit ios changes first; only committed source is tested.")
    evidence = Path("C:/tmp/leafhft-ios/evidence") / datetime.now(timezone.utc).strftime("%Y-%m-%d")
    evidence.mkdir(parents=True, exist_ok=True)
    job = f"rung-{args.rung}-{sha[:12]}-{time.time_ns()}"
    remote = "leafhft-ios-tests-01a09ff9/" + job
    local = evidence / job
    local.mkdir()
    archive = local / "source.tar"
    subprocess.run(["git", "archive", "--format=tar", "-o", str(archive), sha, "ios"], cwd=ROOT, check=True)
    ssh = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=20", args.host]
    scp = ["scp", "-q", "-o", "BatchMode=yes", "-o", "ConnectTimeout=20",
           "-o", "ServerAliveInterval=15", "-o", "ServerAliveCountMax=2"]
    receipt = {"rung": args.rung, "source_sha": sha, "host": args.host, "runtime": args.runtime,
               "command": f"python ios/scripts/test_simulators.py {args.rung} --runtime {args.runtime}",
               "result": "UNAVAILABLE", "exit_code": None, "basis": "confirmed", "remote_job": remote,
               "duration_seconds": None, "number": None, "budget_seconds": 300 if args.rung == 2 else 600,
               "xcresult": None, "screenshots": []}
    if args.appearance:
        receipt["scope"] = "diagnostic " + args.appearance + " appearance only"
        receipt["command"] += " --appearance " + args.appearance
    try:
        transport(ssh + ["mkdir -p " + shlex.quote(remote)], capture_output=True).check_returncode()
        transport(scp + [str(archive), args.host + ":" + remote + "/source.tar"], capture_output=True).check_returncode()
        launcher = ("import subprocess; log=open('launcher.log','ab'); "
                    "subprocess.Popen(['python3','ios/scripts/simulator_job.py'," + repr(str(args.rung)) +
                    ",'--runtime'," + repr(args.runtime) + (",'--appearance'," + repr(args.appearance) if args.appearance else "") + "],stdin=subprocess.DEVNULL,stdout=log,"
                    "stderr=subprocess.STDOUT,start_new_session=True)")
        launch = ("cd " + shlex.quote(remote) + " && tar -xf source.tar && if mkdir started 2>/dev/null; then python3 -c "
                  + shlex.quote(launcher) + "; fi")
        transport(ssh + [launch], capture_output=True).check_returncode()
        deadline = time.monotonic() + receipt["budget_seconds"] + 120 + (300 if args.rung == 3 else 0)
        while time.monotonic() < deadline:
            status = transport(ssh + ["cat " + shlex.quote(remote + "/simulator-result.json")], capture_output=True, text=True)
            if status.returncode == 0:
                receipt.update(json.loads(status.stdout))
                break
            time.sleep(10)
        else:
            receipt["reason"] = "No terminal receipt; inspect this retained job before retrying."
        transport(ssh + ["cd " + shlex.quote(remote) + " && python3 ios/scripts/result_bundle.py"],
                  capture_output=True).check_returncode()
        transport(scp + [args.host + ":" + remote + "/artifacts.tar.gz", str(local / "artifacts.tar.gz")],
                  capture_output=True).check_returncode()
        import tarfile
        with tarfile.open(local / "artifacts.tar.gz") as bundle:
            bundle.extractall(local, filter="data")
        receipt["xcresult"] = [str(local / p) for p in receipt.pop("xcresults", [])]
        receipt["screenshots"] = [str(local / p) for p in receipt["screenshots"]]
    except (OSError, subprocess.SubprocessError, ValueError):
        receipt.update(result="UNAVAILABLE", reason="Transport or evidence collection failed; remote job is retained.")
    receipt["observed_at"] = datetime.now(timezone.utc).isoformat()
    suffix = "-" + args.appearance + "-diagnostic" if args.appearance else ""
    (evidence / f"rung-{args.rung}{suffix}.json").write_text(json.dumps(receipt, indent=2) + "\n")
    (local / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    return 0 if receipt["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
