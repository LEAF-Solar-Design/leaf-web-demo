"""Pack simulator evidence as a standard gzip tar, deduplicating bytes with hardlinks."""
import hashlib
import os
from pathlib import Path
import stat
import tarfile
import tempfile


def pack(root: Path) -> Path:
    root = root.resolve()
    output = root / "artifacts.tar.gz"
    seen = {}
    descriptor, temporary_name = tempfile.mkstemp(prefix=".artifacts-", suffix=".tar.gz.tmp", dir=root)
    os.close(descriptor)
    temporary = Path(temporary_name)

    def add(bundle, path):
        metadata = path.lstat()
        name = path.relative_to(root).as_posix()
        if stat.S_ISDIR(metadata.st_mode):
            bundle.addfile(bundle.gettarinfo(str(path), arcname=name))
            for child in sorted(path.iterdir(), key=lambda item: item.name):
                add(bundle, child)
        elif stat.S_ISREG(metadata.st_mode):
            with path.open("rb") as source:
                initial = os.fstat(source.fileno())
                digest = hashlib.sha256()
                for chunk in iter(lambda: source.read(1024 * 1024), b""):
                    digest.update(chunk)
                key = (initial.st_size, digest.digest())
                info = bundle.gettarinfo(str(path), arcname=name, fileobj=source)
                # File payloads are immutable after the simulator's terminal receipt.
                # Reject a changed file instead of producing a stale digest link.
                current = os.fstat(source.fileno())
                if (initial.st_size, initial.st_mtime_ns) != (current.st_size, current.st_mtime_ns):
                    raise ValueError("Evidence changed while hashing: " + name)
                if key in seen:
                    info.type = tarfile.LNKTYPE
                    info.linkname = seen[key]
                    info.size = 0
                    bundle.addfile(info)
                else:
                    # Force a regular first entry even if the source already has hardlinks.
                    info.type = tarfile.REGTYPE
                    info.linkname = ""
                    info.size = initial.st_size
                    source.seek(0)
                    bundle.addfile(info, source)
                    seen[key] = name
                current = os.fstat(source.fileno())
                if (initial.st_size, initial.st_mtime_ns) != (current.st_size, current.st_mtime_ns):
                    raise ValueError("Evidence changed while packing: " + name)
        else:
            raise ValueError("Unsupported evidence entry (symlinks are not accepted): " + name)

    try:
        with tarfile.open(temporary, "w:gz", format=tarfile.PAX_FORMAT) as bundle:
            for name in ("artifacts", "launcher.log", "simulator-result.json"):
                add(bundle, root / name)
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    return output


if __name__ == "__main__":
    try:
        result = pack(Path.cwd())
    except (OSError, ValueError, tarfile.TarError) as error:
        raise SystemExit("Evidence archive failed: " + str(error)) from None
    print(result.name)
