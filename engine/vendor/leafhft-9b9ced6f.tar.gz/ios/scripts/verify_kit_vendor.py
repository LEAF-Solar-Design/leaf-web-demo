"""Structural check of the vendored LeafAssistantKit and its wiring; fails closed on the first broken rule; reads only files under ios/."""

from pathlib import Path, PurePosixPath
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).parent))
from verify_core import project_yaml

PIN = "2c97b2133fcc9bed1abf333f3496e48c32abe9bd"
KIT = ROOT / "ios/Packages/LeafAssistantKit"
PIN_FILE_DIGEST = "fb5fcba3c53a39cf1472256875655794d5849936b5336c5e608da1edce9f6e64"
GOLDENS = {
    "answer-with-view": "0f963b8a7e92a47404f7e7919c37c6919418b6b9bac0226b71ff8c48c12c9007",
    "card-approved": "3cb3d5b1c3ab1a75487ff2d1ba8ba5ed99530ad8617515898e4b7c5bbd62b388",
    "card-expired": "1d5c14818fe40c0d164e847a6c809acb549e2c936abb503d133598e326cb09f7",
    "idle": "b7770831e9667b616bf9f68bd79bea3f468a2133a17612d78d523be2e3dfd1e6",
    "rate-limited": "47a04f478c834fd1a7e508f23e070283b90248f242683fac9efea7856399ede9",
    "tool-failed": "81d5a5ebac1c5533b9a255a9cc3284bc3537ea50c64d90538d104f828450e541",
    "worker-offline": "202fb1aa28a6393c3818f838c11e2b1f8f58fa25150548abb60cc666168b487e",
}


def check(condition, name):
    if not condition:
        raise ValueError(name)
    print("PASS " + name)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def vendor_file_matches(rel, expected):
    # Reject paths outside the package before reading their bytes.
    relative = PurePosixPath(rel)
    if (relative.is_absolute() or ".." in relative.parts or "\\" in rel
            or ":" in rel or relative.as_posix() != rel):
        return False
    path = (KIT / rel).resolve()
    if not path.is_relative_to(KIT.resolve()) or not path.is_file():
        return False
    data = path.read_bytes()
    return sha256(data) == expected or (
        b"\0" not in data and b"\r\n" in data
        and sha256(data.replace(b"\r\n", b"\n")) == expected
    )


def main():
    project = project_yaml((ROOT / "ios/project.yml").read_text(encoding="utf-8"))
    packages = project["packages"]
    check(packages["LeafHFTCore"]["path"] == "Packages/LeafHFTCore"
          and packages["LeafAssistantKit"]["path"] == "Packages/LeafAssistantKit",
          "1 local package paths")

    targets = project["targets"]
    products = [
        {"package": "LeafAssistantKit", "product": "LeafAssistantCore"},
        {"package": "LeafAssistantKit", "product": "LeafAssistantUI"},
    ]
    app_dependencies = targets["LeafHFT"]["dependencies"]
    check(all(item in app_dependencies for item in products + [
        {"package": "LeafHFTCore"}, {"sdk": "libsqlite3.tbd"},
        {"sdk": "Charts.framework"}, {"target": "LeafHFTWidgetExtension", "embed": True},
    ]), "2 app dependencies")

    test_dependencies = targets["LeafHFTTests"]["dependencies"]
    check(all(item in test_dependencies for item in products + [
        {"target": "LeafHFT"}, {"package": "LeafHFTCore"},
    ]) and all(
        dependency.get("package") != "LeafAssistantKit"
        for target in ("LeafHFTWidgetExtension", "LeafHFTUITests")
        for dependency in targets[target]["dependencies"]
    ), "3 test dependencies and excluded targets")

    record = json.loads((KIT / "UPSTREAM.json").read_text(encoding="utf-8"))
    files = record["files"]
    if not isinstance(files, dict) or not all(
        isinstance(rel, str) and isinstance(digest, str) for rel, digest in files.items()
    ):
        raise ValueError("4 upstream files must map paths to digests")
    tree = "".join(f"{rel}\0{files[rel]}\n" for rel in sorted(files)).encode("utf-8")
    check(all(record[key] == value for key, value in {
        "schema": "leaf.assistant-kit.upstream.v1",
        "upstream": "LEAF-Solar-Design/mushy-code",
        "package": "LeafAssistantKit", "path": "swift/LeafAssistantKit", "commit": PIN,
    }.items()) and record["tree_sha256"] == sha256(tree) and "Package.swift" in files,
          "4 upstream identity and tree digest")

    check(all(vendor_file_matches(rel, digest) for rel, digest in files.items()),
          "5 vendored file hashes")

    actual = {
        path.relative_to(KIT).as_posix()
        for path in KIT.rglob("*")
        if path.is_file() and path.relative_to(KIT).as_posix() != "UPSTREAM.json"
        and not any(part.startswith(".") for part in path.relative_to(KIT).parts)
    }
    check(actual == set(files), "6 no vendor overlay")

    prefix = "Tests/LeafAssistantCoreTests/Fixtures/"
    check(all(files[prefix + name + ".json"] == digest for name, digest in GOLDENS.items())
          and files[prefix + "FIXTURES.sha256"] == PIN_FILE_DIGEST,
          "7 golden fixture pins")

    mapping_path = ROOT / "ios/LeafHFT/Design/LeafAssistantThemeMapping.swift"
    mapping = mapping_path.read_text(encoding="utf-8")
    required_mapping = [
        "import LeafAssistantUI", "extension LeafAssistantTheme",
        "static var leaf: LeafAssistantTheme", "func leafKitThemed()",
        "accent: LeafTheme.primary", "surface: LeafTheme.card",
        "userBubble: LeafTheme.accentFill", "assistantBubble: LeafTheme.ground",
        "textPrimary: LeafTheme.ink", "textSecondary: LeafTheme.inkMuted",
        "danger: LeafTheme.loss", "warning: LeafTheme.warn", "success: LeafTheme.gain",
        "border: LeafTheme.line", "cornerRadius: LeafTheme.radius", "minimumTarget: 44",
    ]
    check(all(token in mapping for token in required_mapping), "8 Leaf theme mapping")

    app = (ROOT / "ios/LeafHFT/LeafHFTApp.swift").read_text(encoding="utf-8")
    sheet_start = app.index(".sheet(isPresented: $showingStudio)")
    sheet_end = app.index(".onChange(of: scenePhase", sheet_start)
    check(app.count(".leafKitThemed()") == 1
          and ".leafKitThemed()" in app[sheet_start:sheet_end], "9 sheet theme injection")

    imports = set()
    for path in (ROOT / "ios/LeafHFT").rglob("*.swift"):
        source = path.read_text(encoding="utf-8")
        if "import LeafAssistantCore" in source or "import LeafAssistantUI" in source:
            imports.add(path)
    check(imports == {mapping_path, ROOT / "ios/LeafHFT/Net/KashbotKitTransport.swift"},
          "10 app Kit import scope")

    tests = ROOT / "ios/LeafHFTTests"
    fixture_tests = (tests / "KitFixtureConformanceTests.swift").read_text(encoding="utf-8")
    theme_tests = (tests / "LeafAssistantThemeMappingTests.swift").read_text(encoding="utf-8")
    check(all(name in fixture_tests for name in (
        "testUpstreamRecordPinsTheKit", "testFixturePinRecomputesAtThePin",
        "testEveryGoldenDecodesFoldsAndKeepsTheContract", "testTheShapesTheIosScreenWillRender",
    )) and "testLeafMappingMatchesLeafThemeTokens" in theme_tests, "11 consumer test coverage")
    print("KIT VENDOR OK")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        print(f"FAIL {error}", file=sys.stderr)
        sys.exit(1)
