"""Validate the Kashbot UI registry and per-area audit findings.

The checked-in YAML uses JSON syntax (a safe YAML subset), so the structural
gate needs no dependency. PyYAML, already used by verify_core, is supported
for ordinary YAML edits when installed.

Errors (exit 1): an unknown schema or top-level shape; a surface, alias, action
or flow id that is not unique; a parent, alias target, flow step or finding
surface that does not resolve; a state value outside covered | missing | n/a;
a source file that does not exist or does not contain its symbol; a non-null
action identifier that appears in no Swift file under ios/LeafHFT or
ios/LeafHFTWidget; a screenshot whose test_class is not a file in
ios/LeafHFTUITests or whose appearance is outside the enum; a finding without
its required fields. Warnings (counted, exit 0): a risk-raising money action
whose confirm or auth is "MISSING (<finding id>)", which keeps a known gap
visible without failing the gate. Completeness against the audit that produced
the findings is not checked here; the audit receipt lives with the program.

Publishing: payload [--root R] [--source-ref SHA] [--out FILE] emits compact
UTF-8 JSON after validation; publish --url HTTPS_URL sends the same body.
Both require a clean registry/findings tree unless --allow-dirty is supplied.
The source reference defaults to HEAD and must be 40 lowercase hex digits.
publish reads UI_MAP_PUBLISHER_TOKEN only from the environment; the token is
never an argument. --dry-run needs no token and sends no request. Publishing
uses a 30-second timeout and retries connection errors and 5xx twice, after
2 and 4 seconds; 4xx are not retried.
"""
import argparse
from collections import Counter
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request


ROOT = Path(__file__).resolve().parents[2]
_ALLOW_INSECURE_LOOPBACK = False
STATES = {"covered", "missing", "n/a"}
APPEARANCES = {"light", "dark", "light-ax", "dark-ax"}
SEVERITIES = {"blocker", "major", "minor", "polish"}
STATUSES = {"open", "fixing", "fixed", "wontfix", "refuted", "by-design", "deferred"}
AREAS = ("shell", "settings", "account", "onboarding", "monitor", "books",
         "engines", "autopilot", "tuning", "assistant", "widget", "live",
         "notification", "deeplink", "people")


def load_document(path):
    text = path.read_text(encoding="utf-8-sig")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        try:
            import yaml
        except ImportError as error:
            raise ValueError(str(path) + ": use JSON-compatible YAML or install PyYAML") from error
        try:
            return yaml.safe_load(text)
        except yaml.YAMLError as error:
            raise ValueError(str(path) + ": invalid YAML: " + str(error)) from error


def validate(registry, findings, root=ROOT):
    """Return errors, warnings and counts without launching another process."""
    root = Path(root).resolve()
    errors, warnings = [], []
    counts = {"surfaces": 0, "flows": 0, "actions": 0, "findings": 0,
              "severity": Counter(), "status": Counter()}

    def error(message):
        errors.append(message)

    def sequence(value, context):
        if not isinstance(value, list):
            error(context + " must be a list")
            return []
        return value

    def mapping(value, context):
        if not isinstance(value, dict):
            error(context + " must be a mapping")
            return {}
        return value

    def path_for(value, context):
        if not isinstance(value, str) or not value:
            error(context + ": source file must be a path")
            return None
        path = (root / value).resolve()
        if not path.is_relative_to(root):
            error(context + ": path escapes root: " + value)
            return None
        return path

    registry = mapping(registry, "registry")
    expected = {"schema": "leaf.ui-surface-map.v1", "app": "kashbot-ios",
                "platform": "ios", "repo": "LEAF-Solar-Design/leaf-hft",
                "source_root": "ios", "id_anchor": "accessibilityIdentifier"}
    for key, value in expected.items():
        if registry.get(key) != value:
            error("registry " + key + " must be " + value)
    if not re.fullmatch(r"[0-9a-f]{40}", str(registry.get("source_ref", ""))):
        error("registry source_ref must be a full commit SHA")
    if "generated_at" in registry or "findings" in registry:
        error("registry must not contain generated_at or findings")
    surfaces = sequence(registry.get("surfaces"), "surfaces")
    flows = sequence(registry.get("flows"), "flows")
    counts["surfaces"], counts["flows"] = len(surfaces), len(flows)
    ids, surface_ids, flow_ids = set(), set(), set()

    def claim(value, context):
        if not isinstance(value, str) or not value:
            error(context + ": id must be a nonempty string")
        elif value in ids:
            error(context + ": duplicate id or alias: " + value)
        else:
            ids.add(value)

    for surface in surfaces:
        surface = mapping(surface, "surface")
        sid = surface.get("id")
        claim(sid, "surface")
        if isinstance(sid, str):
            surface_ids.add(sid)
        for alias in sequence(surface.get("aliases", []), str(sid) + " aliases"):
            claim(alias, str(sid))
            if isinstance(alias, str):
                surface_ids.add(alias)
    for flow in flows:
        flow = mapping(flow, "flow")
        fid = flow.get("id")
        claim(fid, "flow")
        if isinstance(fid, str):
            flow_ids.add(fid)

    def resolves(value, context, allowed=surface_ids):
        if value is not None and (not isinstance(value, str) or value not in allowed):
            error(context + ": unresolved surface/reference: " + str(value))

    swift = "\n".join(path.read_text(encoding="utf-8")
                      for directory in (root / "ios/LeafHFT", root / "ios/LeafHFTWidget")
                      for path in sorted(directory.rglob("*.swift")))

    def identifier(value, context):
        if value is not None and (not isinstance(value, str) or not value
                                  or ('"' + value + '"') not in swift):
            error(context + ": missing identifier in Swift: " + str(value))

    for raw_surface in surfaces:
        surface = mapping(raw_surface, "surface")
        sid = str(surface.get("id", "<surface>"))
        resolves(surface.get("parent"), sid + " parent")
        for entry in sequence(surface.get("entry_points", []), sid + " entry_points"):
            resolves(mapping(entry, sid + " entry").get("from"), sid + " entry")
        identifier(surface.get("identifier"), sid)
        if "findings" in surface:
            error(sid + ": findings belong in per-area files")
        for raw_screenshot in sequence(surface.get("screenshots", []), sid + " screenshots"):
            screenshot = mapping(raw_screenshot, sid + " screenshot")
            if set(screenshot) != {"test_class", "appearance", "set"}:
                error(sid + ": screenshot requires test_class, appearance and set")
            test_class = screenshot.get("test_class")
            if (not isinstance(test_class, str)
                    or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", test_class)
                    or not (root / "ios/LeafHFTUITests" / (test_class + ".swift")).is_file()):
                error(sid + ": missing screenshot test class: " + str(test_class))
            appearance = screenshot.get("appearance")
            if not isinstance(appearance, str) or appearance not in APPEARANCES:
                error(sid + ": invalid screenshot appearance: " + str(appearance))
            if screenshot.get("set") != "baseline-ab4322ea":
                error(sid + ": screenshot set must be baseline-ab4322ea")
        for raw_source in sequence(surface.get("source"), sid + " source"):
            source = mapping(raw_source, sid + " source")
            path = path_for(source.get("file"), sid)
            if path is None:
                continue
            if not path.is_file():
                error(sid + ": missing source file: " + str(source.get("file")))
                continue
            symbol = source.get("symbol")
            if not isinstance(symbol, str) or not symbol or not re.search(
                    r"\b(?:struct|class|enum|actor|protocol|func|extension)\s+"
                    + re.escape(symbol) + r"\b", path.read_text(encoding="utf-8")):
                error(sid + ": missing source symbol: " + str(symbol))
        for name, value in mapping(surface.get("states"), sid + " states").items():
            if not isinstance(value, str) or value not in STATES:
                error(sid + ": invalid state " + name + ": " + str(value))
        for raw_action in sequence(surface.get("actions", []), sid + " actions"):
            action = mapping(raw_action, sid + " action")
            aid = action.get("id")
            claim(aid, sid + " action")
            counts["actions"] += 1
            if isinstance(aid, str) and not aid.startswith(sid + "."):
                error(str(aid) + ": action id must be under its surface")
            context = str(aid)
            direction = action.get("direction")
            if direction not in ("raises-risk", "lowers-risk", "neutral"):
                error(context + ": invalid action direction")
            if action.get("risk") == "money" and direction == "raises-risk":
                for field in ("confirm", "auth"):
                    value = action.get(field)
                    if not isinstance(value, str) or not value.strip() or (field == "confirm" and value.lower() == "none"):
                        error(context + ": raises-risk money action requires " + field)
                    elif "MISSING" in value:
                        warnings.append(context + ": " + field + " " + value)
            if direction == "lowers-risk":
                steps = action.get("steps", [])
                taps = action.get("taps", 1)
                if not isinstance(steps, list) or len(steps) > 1 or not isinstance(taps, int) or taps > 1:
                    error(context + ": lowers-risk action has more than one step")
            identifier(action.get("identifier"), context)
    for raw_flow in flows:
        flow = mapping(raw_flow, "flow")
        fid = str(flow.get("id"))
        if flow.get("entry") not in ("cold", "push", "widget", "deeplink"):
            error(fid + ": invalid flow entry")
        if type(flow.get("taps")) is not int or flow["taps"] < 0:
            error(fid + ": taps must be a nonnegative integer")
        for field in ("steps", "alternate_steps", "failure_steps"):
            steps = flow.get(field) if field == "steps" else flow.get(field, [])
            for raw_step in sequence(steps, fid + " " + field):
                step = mapping(raw_step, fid + " step")
                if not step.get("surface"):
                    error(fid + ": flow step requires surface")
                resolves(step.get("surface"), fid + " flow step")
        for entry in sequence(flow.get("alternate_entry_surfaces", []), fid + " alternate entries"):
            resolves(entry, fid + " alternate entry")

    finding_ids, duplicates = set(), []
    for raw_finding in sequence(findings, "findings"):
        finding = mapping(raw_finding, "finding")
        fid = str(finding.get("id", "<finding>"))
        for field in ("id", "severity", "kind", "summary", "surface", "found_ref", "evidence", "status"):
            if field not in finding or finding[field] is None or finding[field] == "":
                error(fid + ": finding requires " + field)
        if fid in finding_ids:
            error(fid + ": duplicate finding id")
        finding_ids.add(fid)
        resolves(finding.get("surface"), fid + " finding")
        for related in sequence(finding.get("related_surfaces", []), fid + " related_surfaces"):
            resolves(related, fid + " finding")
        resolves(finding.get("flow"), fid + " finding flow", flow_ids)
        if finding.get("duplicate_of"):
            duplicates.append((fid, finding["duplicate_of"]))
        if finding.get("severity") not in SEVERITIES:
            error(fid + ": invalid finding severity")
        if finding.get("status") not in STATUSES:
            error(fid + ": invalid finding status")
        if finding.get("found_ref") != "ab4322ea":
            error(fid + ": finding found_ref must be ab4322ea")
        evidence = sequence(finding.get("evidence"), fid + " evidence")
        if not evidence:
            error(fid + ": finding requires evidence")
        for item in evidence:
            item = mapping(item, fid + " evidence")
            if not isinstance(item.get("file"), str) or not item.get("file") or type(item.get("line")) is not int or item["line"] < 1:
                error(fid + ": evidence requires file and positive line")
        counts["findings"] += 1
        counts["severity"][str(finding.get("severity"))] += 1
        counts["status"][str(finding.get("status"))] += 1
    for fid, target in duplicates:
        if not isinstance(target, str) or target not in finding_ids or target == fid:
            error(fid + ": unresolved duplicate_of: " + str(target))
    return errors, warnings, counts


def check(root=ROOT, emit=True):
    root = Path(root)
    findings = []
    try:
        registry = load_document(root / "ios/ui-surfaces.yaml")
        directory = root / "ios/ui-findings"
        for area in AREAS:
            if not (directory / (area + ".yaml")).is_file():
                raise ValueError("Missing finding file: " + area + ".yaml")
        for path in sorted(directory.glob("*.yaml")):
            area = path.stem
            document = load_document(path)
            if not isinstance(document, dict) or document.get("area") != area or not isinstance(document.get("findings"), list):
                raise ValueError(str(path) + ": requires area and findings list")
            findings.extend(document["findings"])
        errors, warnings, counts = validate(registry, findings, root)
    except (OSError, ValueError, TypeError) as error:
        if emit:
            print("ERROR " + str(error), file=sys.stderr)
        return 1
    if emit:
        for message in errors:
            print("ERROR " + message, file=sys.stderr)
        for message in warnings:
            print("WARNING " + message)
        print("UI surface map: {surfaces} surfaces, {flows} flows, {actions} actions, {findings} findings".format(**counts))
        print("Findings by severity: " + ", ".join(key + "=" + str(counts["severity"][key]) for key in sorted(SEVERITIES)))
        print("Findings by status: " + ", ".join(key + "=" + str(counts["status"][key]) for key in sorted(STATUSES)))
        print(str(len(warnings)) + " warnings, " + str(len(errors)) + " errors")
    return 1 if errors else 0


def build_payload(root, source_ref=None, allow_dirty=False):
    """Return validated wire bytes, or an exit code and no bytes."""
    root = Path(root).resolve()
    if check(root, emit=False):
        check(root)
        return 1, None
    try:
        if source_ref is None:
            source_ref = subprocess.run(
                ["git", "-C", str(root), "rev-parse", "HEAD"],
                capture_output=True, text=True, check=True, timeout=10).stdout.strip()
        if not re.fullmatch(r"[0-9a-f]{40}", source_ref):
            print("ERROR source_ref must be 40 lowercase hex digits", file=sys.stderr)
            return 2, None
        dirty = subprocess.run(
            ["git", "-C", str(root), "status", "--porcelain", "--",
             "ios/ui-surfaces.yaml", "ios/ui-findings"],
            capture_output=True, text=True, check=True, timeout=10).stdout
        if dirty:
            if not allow_dirty:
                print("ERROR registry or findings have uncommitted changes; use --allow-dirty",
                      file=sys.stderr)
                return 2, None
            print("WARNING publishing uncommitted registry or findings changes", file=sys.stderr)
        registry = load_document(root / "ios/ui-surfaces.yaml")
        findings = []
        for path in sorted((root / "ios/ui-findings").glob("*.yaml")):
            findings.extend(load_document(path)["findings"])
        errors, warnings, counts = validate(registry, findings, root)
        for message in errors:
            print("ERROR " + message, file=sys.stderr)
        for message in warnings:
            print("WARNING " + message, file=sys.stderr)
        if errors:
            return 1, None
        body = {key: registry[key] for key in ("schema", "app", "platform", "repo")}
        body.update(source_ref=source_ref, registry=registry, findings=findings)
        data = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    except (OSError, subprocess.SubprocessError):
        print("ERROR unable to read payload files or Git state", file=sys.stderr)
        return 2, None
    except (ValueError, TypeError, KeyError):
        print("ERROR unable to build validated payload", file=sys.stderr)
        return 1, None
    print("sha256={} bytes={} surfaces={} findings={}".format(
        hashlib.sha256(data).hexdigest(), len(data), counts["surfaces"], counts["findings"]),
        file=sys.stderr)
    return 0, data


class _NoPublishRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Do not forward the publisher credential to a redirect destination.
        return None


def publish(url, data, token):
    digest = hashlib.sha256(data).hexdigest()
    opener = urllib.request.build_opener(_NoPublishRedirect())
    for attempt in range(3):
        try:
            request = urllib.request.Request(url, data=data, method="POST", headers={
                "Content-Type": "application/json", "Authorization": "Bearer " + token})
            with opener.open(request, timeout=30) as response:
                status = response.status
                reply = response.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as error:
            status = error.code
            try:
                reply = error.read().decode("utf-8", errors="replace")
            except (OSError, ValueError, http.client.HTTPException):
                reply = "Unable to read server reply"
            finally:
                error.close()
        except (OSError, ValueError, urllib.error.URLError, http.client.HTTPException):
            if attempt < 2:
                time.sleep(2 ** (attempt + 1))
                continue
            print("publish status=connection-error sha256={} bytes={}".format(digest, len(data)))
            return 1
        if 500 <= status < 600 and attempt < 2:
            time.sleep(2 ** (attempt + 1))
            continue
        reply = reply.replace(token, "[redacted]")
        print("publish status={} sha256={} bytes={}".format(status, digest, len(data)))
        if 200 <= status < 300:
            print(reply)
            return 0
        print(reply[:500])
        return 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    commands = parser.add_subparsers(dest="command", required=True)
    check_parser = commands.add_parser("check")
    check_parser.add_argument("--root", type=Path, default=argparse.SUPPRESS)
    for command in ("payload", "publish"):
        command_parser = commands.add_parser(command)
        command_parser.add_argument("--root", type=Path, default=argparse.SUPPRESS)
        command_parser.add_argument("--source-ref")
        command_parser.add_argument("--allow-dirty", action="store_true")
        if command == "payload":
            command_parser.add_argument("--out", type=Path)
        else:
            command_parser.add_argument("--url", required=True)
            command_parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "check":
        return check(args.root)
    token = None
    if args.command == "publish":
        try:
            url = urllib.parse.urlsplit(args.url)
            allowed = url.scheme == "https" or (
                _ALLOW_INSECURE_LOOPBACK and url.scheme == "http"
                and url.hostname in ("127.0.0.1", "::1", "localhost"))
            allowed = allowed and bool(url.hostname) and not url.username and not url.password
        except ValueError:
            allowed = False
        if not allowed:
            print("ERROR --url must be https", file=sys.stderr)
            return 2
        if not args.dry_run:
            token = os.environ.get("UI_MAP_PUBLISHER_TOKEN")
            if not token:
                print("UI_MAP_PUBLISHER_TOKEN is not set", file=sys.stderr)
                return 2
    code, data = build_payload(args.root, args.source_ref, args.allow_dirty)
    if code:
        return code
    if args.command == "publish":
        if args.dry_run:
            print("publish status=dry-run sha256={} bytes={}".format(
                hashlib.sha256(data).hexdigest(), len(data)))
            return 0
        return publish(args.url, data, token)
    try:
        if args.out:
            args.out.write_bytes(data)
        elif hasattr(sys.stdout, "buffer"):
            sys.stdout.buffer.write(data)
        else:
            sys.stdout.write(data.decode("utf-8"))
    except OSError:
        print("ERROR unable to write payload", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
