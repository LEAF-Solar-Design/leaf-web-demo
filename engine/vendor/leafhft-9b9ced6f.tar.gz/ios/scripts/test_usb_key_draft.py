"""Synthetic-only protocol checks. No provider, device, or private-key fixture."""
import base64
import json
import unittest
import uuid

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from usb_key_draft import INFO, decode_request, encrypt_payload


class USBKeyDraftTests(unittest.TestCase):
    def setUp(self):
        self.recipient = ec.generate_private_key(ec.SECP256R1())
        public = self.recipient.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
        self.request = {"version": 1, "request_id": str(uuid.uuid4()), "expires_at": 1120,
                        "public_key": base64.b64encode(public).decode()}
        synthetic = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self.payload = {"key_id": "synthetic-only", "private_key_pem": synthetic.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption()).decode()}

    def decrypt(self, envelope, recipient=None, binding=None):
        sender = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), base64.b64decode(envelope["sender_public_key"]))
        binding = binding or envelope["request_id"].encode()
        shared = (recipient or self.recipient).exchange(ec.ECDH(), sender)
        key = HKDF(algorithm=hashes.SHA256(), length=32, salt=binding, info=INFO).derive(shared)
        return AESGCM(key).decrypt(base64.b64decode(envelope["nonce"]), base64.b64decode(envelope["ciphertext"]), binding)

    def test_roundtrip_and_no_plaintext_in_envelope(self):
        request = decode_request(json.dumps(self.request).encode(), now=1000)
        encoded = encrypt_payload(request, self.payload)
        self.assertNotIn(self.payload["key_id"].encode(), encoded)
        self.assertNotIn(self.payload["private_key_pem"].encode(), encoded)
        self.assertEqual(json.loads(self.decrypt(json.loads(encoded))), self.payload)

    def test_tamper_wrong_recipient_and_request_rejected(self):
        envelope = json.loads(encrypt_payload(self.request, self.payload))
        with self.assertRaises(InvalidTag):
            self.decrypt(envelope, recipient=ec.generate_private_key(ec.SECP256R1()))
        with self.assertRaises(InvalidTag):
            self.decrypt(envelope, binding=str(uuid.uuid4()).encode())
        ciphertext = bytearray(base64.b64decode(envelope["ciphertext"]))
        ciphertext[0] ^= 1
        envelope["ciphertext"] = base64.b64encode(ciphertext).decode()
        with self.assertRaises(InvalidTag):
            self.decrypt(envelope)

    def test_expired_oversized_and_bad_public_request_rejected(self):
        for now in (1120, 998):
            with self.assertRaises(ValueError):
                decode_request(json.dumps(self.request).encode(), now=now)
        with self.assertRaises(ValueError):
            decode_request(b" " * 4097, now=1000)
        self.request["public_key"] = "not base64"
        with self.assertRaises(ValueError):
            decode_request(json.dumps(self.request).encode(), now=1000)

    def test_invalid_or_oversized_credentials_rejected(self):
        for replacement in ({"key_id": " "}, {"key_id": "a" * 257},
                            {"private_key_pem": "bad"}, {"private_key_pem": "a" * 65537}):
            with self.assertRaises(ValueError):
                encrypt_payload(self.request, self.payload | replacement)


if __name__ == "__main__":
    unittest.main()
