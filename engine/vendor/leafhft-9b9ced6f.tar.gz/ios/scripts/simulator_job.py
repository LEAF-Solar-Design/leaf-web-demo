"""Mac-side isolated simulator job for the Leaf HFT test ladder."""
import argparse
import json
from pathlib import Path
import subprocess
import time
import re
import os
from concurrent.futures import ThreadPoolExecutor
from threading import Lock


def run(command, **kwargs):
    return subprocess.run(command, check=True, **kwargs)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("rung", type=int, choices=[2, 3])
    parser.add_argument("--runtime", default="26.2")
    parser.add_argument("--appearance", choices=["light", "dark"])
    args = parser.parse_args()
    root = Path.cwd()
    evidence = root / "artifacts"
    evidence.mkdir(exist_ok=True)
    budget = 300 if args.rung == 2 else 600
    # Retain the complete matrix after a missed SLA, within a bounded diagnostic tail.
    collection_limit = budget if args.rung == 2 else budget + 300
    started = time.monotonic()
    sims = []
    commands = []
    results = []
    lock = Lock()
    receipt = {"result": "UNAVAILABLE", "exit_code": None, "budget_seconds": budget,
               "collection_limit_seconds": collection_limit,
               "runtime": args.runtime, "screenshots": [], "xcresults": [], "commands": commands,
               "logs": [], "queue_failures": []}
    try:
        runtime_id = "com.apple.CoreSimulator.SimRuntime.iOS-" + args.runtime.replace(".", "-")
        runtimes = json.loads(subprocess.check_output(["xcrun", "simctl", "list", "runtimes", "--json"]))
        if not any(r["identifier"] == runtime_id and r.get("isAvailable") for r in runtimes["runtimes"]):
            receipt["reason"] = "Requested simulator runtime is not installed."
            return 2
        generators = [Path("/opt/homebrew/bin/xcodegen"), Path.home() / "bin/xcodegen"]
        generator = next(path for path in generators if path.is_file())
        run([str(generator), "generate"], cwd=root / "ios")
        devices = ["iPhone-16"] if args.rung == 2 else ["iPhone-SE-3rd-generation", "iPhone-16-Pro-Max"]
        appearances = ["light"] if args.rung == 2 else ["light", "dark"]
        if args.appearance:
            appearances = [args.appearance]
        device_ids = {}
        for device in devices:
            udid = subprocess.check_output(["xcrun", "simctl", "create", "LeafHFT-" + root.name + "-" + device,
                    "com.apple.CoreSimulator.SimDeviceType." + device, runtime_id], text=True).strip()
            sims.append(udid)
            device_ids[device] = udid
            run(["xcrun", "simctl", "boot", udid])
        # Both first boots overlap. Build once before any queue reads DerivedData.
        if args.rung == 3:
            build = ["xcodebuild", "build-for-testing", "-project", "LeafHFT.xcodeproj", "-scheme", "LeafHFT",
                     "-destination", "platform=iOS Simulator,id=" + device_ids[devices[0]],
                     "-derivedDataPath", str(root / "DerivedData"), "-configuration", "Release",
                     "ENABLE_TESTABILITY=YES", "ONLY_ACTIVE_ARCH=YES",
                     "CODE_SIGNING_ALLOWED=NO", "CODE_SIGNING_REQUIRED=NO"]
            commands.append(build)
            receipt["logs"].append("artifacts/build-for-testing.log")
            with (evidence / "build-for-testing.log").open("w") as log:
                run(build, cwd=root / "ios", stdout=log, stderr=subprocess.STDOUT,
                    timeout=max(1, collection_limit - (time.monotonic() - started)))

        metric_methods = ["testColdLaunchFirstFrameMetric", "testChartAppearsClockMetric"]

        def device_queue(device, udid, performance_only=False):
            boot_command = ["xcrun", "simctl", "bootstatus", udid, "-b"]
            with lock:
                commands.append(boot_command)
            run(boot_command, timeout=max(1, collection_limit - (time.monotonic() - started)))
            for appearance_index, appearance in enumerate(["light"] if performance_only else appearances):
                appearance_command = ["xcrun", "simctl", "ui", udid, "appearance", appearance]
                with lock:
                    commands.append(appearance_command)
                run(appearance_command)
                if args.rung == 3:
                    size_command = ["xcrun", "simctl", "ui", udid, "content_size", "accessibility-extra-extra-extra-large"]
                    with lock:
                        commands.append(size_command)
                    run(size_command)
                name = device + ("-performance" if performance_only else "-" + appearance)
                result_path = evidence / (name + ".xcresult")
                command = ["xcodebuild", "test-without-building" if args.rung == 3 else "test", "-project", "LeafHFT.xcodeproj", "-scheme", "LeafHFT",
                           "-destination", "platform=iOS Simulator,id=" + udid,
                           "-derivedDataPath", str(root / "DerivedData"),
                           "-resultBundlePath", str(result_path), "-parallel-testing-enabled", "NO",
                           "-only-testing:" + ("LeafHFTTests" if args.rung == 2 else "LeafHFTUITests"),
                           "CODE_SIGNING_ALLOWED=NO", "CODE_SIGNING_REQUIRED=NO"]
                if args.rung == 3:
                    # Measure optimized app code, matching the shipping configuration.
                    command += ["-configuration", "Release", "ENABLE_TESTABILITY=YES", "ONLY_ACTIVE_ARCH=YES"]
                if args.rung == 3 and not performance_only and device == devices[0] and appearance_index == 0 and not args.appearance:
                    command.append("-only-testing:LeafHFTTests")
                if args.rung == 3:
                    if performance_only:
                        command.remove("-only-testing:LeafHFTUITests")
                        for method in metric_methods:
                            command.append("-only-testing:LeafHFTUITests/FixtureUITests/" + method)
                    else:
                        # Functional walks remain concurrent. Measure launch and chart
                        # only after both queues finish so they do not compete for CPU.
                        for method in metric_methods:
                            command.append("-skip-testing:LeafHFTUITests/FixtureUITests/" + method)
                        if appearance == "dark":
                            command.append("-skip-testing:LeafHFTUITests/FixtureUITests/testFirstLaunchWithoutKey")
                log_path = evidence / (name + ".log")
                with lock:
                    commands.append(command)
                    receipt["logs"].append(str(log_path.relative_to(root)))
                with log_path.open("w") as log:
                    test_environment = os.environ.copy()
                    test_environment["TEST_RUNNER_LEAFHFT_TEST_APPEARANCE"] = appearance
                    result = subprocess.run(command, cwd=root / "ios", stdout=log, stderr=subprocess.STDOUT,
                                            env=test_environment,
                                            timeout=max(1, collection_limit - (time.monotonic() - started)))
                with lock:
                    results.append(result.returncode)
                if result_path.exists():
                    with lock:
                        receipt["xcresults"].append(str(result_path.relative_to(root)))
                    attachments = evidence / (name + "-attachments")
                    export_command = ["xcrun", "xcresulttool", "export", "attachments", "--path", str(result_path),
                                      "--output-path", str(attachments)]
                    with lock:
                        commands.append(export_command)
                    exported = subprocess.run(export_command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                              timeout=max(1, collection_limit - (time.monotonic() - started)))
                    if exported.returncode:
                        raise subprocess.CalledProcessError(exported.returncode, export_command)
                # A failed test must not suppress the other appearance's evidence.

        # Each queue owns one simulator and serializes its appearances. Build products
        # remain immutable and every result bundle and log has a distinct path.
        with ThreadPoolExecutor(max_workers=2 if args.rung == 3 else 1) as executor:
            futures = {executor.submit(device_queue, device, udid): device for device, udid in device_ids.items()}
            for future, device in futures.items():
                try:
                    future.result()
                except (subprocess.SubprocessError, OSError, ValueError) as error:
                    receipt["queue_failures"].append({"device": device, "error": type(error).__name__})
                    results.append(124 if isinstance(error, subprocess.TimeoutExpired) else 1)
        # Executor exit joins every functional queue. Reuse the same booted devices
        # for serial performance measurements before any teardown or budget check.
        if args.rung == 3 and not args.appearance:
            for device, udid in device_ids.items():
                try:
                    device_queue(device, udid, performance_only=True)
                except (subprocess.SubprocessError, OSError, ValueError) as error:
                    receipt["queue_failures"].append({"device": device, "phase": "performance",
                                                      "error": type(error).__name__})
                    results.append(124 if isinstance(error, subprocess.TimeoutExpired) else 1)
        receipt["exit_code"] = next((rc for rc in results if rc), 0)
        receipt["result"] = "PASS" if results and not any(results) else "FAIL"
    except subprocess.TimeoutExpired:
        receipt.update(result="FAIL", reason="Simulator test budget exceeded.", exit_code=124)
    except (subprocess.SubprocessError, OSError, ValueError):
        receipt.update(reason="Simulator setup or result collection failed.")
    finally:
        for udid in sims:
            subprocess.run(["xcrun", "simctl", "shutdown", udid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            # Delete only simulator IDs returned by this job's own create call.
            subprocess.run(["xcrun", "simctl", "delete", udid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        receipt["screenshots"] = [str(p.relative_to(root)) for p in evidence.rglob("*")
                                  if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".heic"}]
        if args.rung == 3:
            measurements = []
            for log in evidence.glob("*.log"):
                for kind, value in re.findall(r"measured \[([^\]]+)\] average: ([0-9.]+)", log.read_text(errors="replace")):
                    measurements.append({"run": log.stem, "metric": kind, "seconds": float(value)})
            receipt["performance"] = measurements
            receipt["chart_clock_role"] = "diagnostic; first-frame metric is the under-2-second gate"
            first_frames = [m["seconds"] for m in measurements
                            if "ApplicationFirstFrame" in m["metric"] or "AppLaunch" in m["metric"]]
            receipt["cold_launch_budget_seconds"] = 2
            receipt["cold_launch_budget_met"] = bool(first_frames) and max(first_frames) < 2
            if receipt["result"] == "PASS" and not receipt["cold_launch_budget_met"] and not args.appearance:
                receipt.update(result="FAIL", native_exit_code=receipt["exit_code"], exit_code=1,
                               reason="Cold launch first-frame budget not met.")
            if args.appearance:
                receipt["scope"] = "diagnostic " + args.appearance + " appearance only; not full rung acceptance"
        elapsed = round(time.monotonic() - started, 3)
        receipt.update(duration_seconds=elapsed, number=elapsed, unit="seconds", budget_met=elapsed < budget)
        if receipt["result"] == "PASS" and elapsed >= budget:
            receipt.update(result="FAIL", reason="Simulator test budget exceeded.", exit_code=124)
        temporary = root / "simulator-result.tmp"
        receipt["xcresults"] = [str(p.relative_to(root)) for p in evidence.glob("*.xcresult")]
        temporary.write_text(json.dumps(receipt, indent=2) + "\n")
        temporary.replace(root / "simulator-result.json")
    return 0 if receipt["result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
