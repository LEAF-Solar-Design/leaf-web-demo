"""Run the simulator-only Leaf HFT live shape smoke with a memory-only bearer."""
import argparse
import contextlib
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="Perform the single live smoke if ready")
    parser.add_argument("--evidence-root", default="C:/tmp/leafhft-ios/evidence")
    parser.add_argument("--host", default="exzachly-aws-mac", help="Existing SSH build host; never starts a stopped host")
    parser.add_argument("--runtime", default="26.2", help="Installed iOS simulator runtime version")
    args = parser.parse_args()
    started = time.monotonic()
    evidence = Path(args.evidence_root) / datetime.now(timezone.utc).strftime("%Y-%m-%d")
    evidence.mkdir(parents=True, exist_ok=True)
    receipt = dict(rung=5, source_sha=None, host=args.host, runtime=args.runtime,
                   controller_host=platform.node(), command="python ios/scripts/live_smoke.py --execute",
                   result="UNAVAILABLE", basis="confirmed", exit_code=1, duration_seconds=None,
                   number=0, unit="accepted live routes", budget=None, xcresult=None, screenshots=[])
    token = None
    child_env = dict(os.environ)
    child_env.pop("LEAFHFT_MOBILE_TOKEN", None)

    def run(command, **kwargs):
        return subprocess.run(command, cwd=ROOT, env=child_env, capture_output=True,
                              timeout=kwargs.pop("timeout", 60), **kwargs)

    def transport(command, **kwargs):
        for attempt in range(3):
            result = run(command, **kwargs)
            if result.returncode not in (124, 255) or attempt == 2:
                if result.returncode:
                    raise RuntimeError("Transport unavailable")
                return result
            time.sleep(2)

    try:
        receipt["source_sha"] = run(["git", "rev-parse", "HEAD"], check=True).stdout.decode().strip()
        # No resolver report, error text, headers, bodies, or masks enter evidence.
        sys.path.insert(0, "C:/Users/ehaug/claudewalk-build/packages/cadwalk-core")
        with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
            from cadwalk_core.credentials.resolver import CredentialResolver, CREDENTIAL_LOCATIONS
            # Older installed resolvers predate this application's named credential.
            # Register its store location; resolution and transport remain in-process.
            if not any(name == "LEAFHFT_MOBILE_TOKEN" for name, _, _ in CREDENTIAL_LOCATIONS):
                CREDENTIAL_LOCATIONS.append(("LEAFHFT_MOBILE_TOKEN",
                                             Path("~/.cadwalk/credentials.json"), "leafhft_mobile_token"))
            token = CredentialResolver().resolve("LEAFHFT_MOBILE_TOKEN")
        if not token:
            receipt["reason"] = "LEAFHFT_MOBILE_TOKEN is unavailable. No Mac or live request occurred."
            return 1
        if not args.execute:
            receipt["reason"] = "Credential ready. Use --execute to run the single live smoke. No Mac or live request occurred."
            return 1
        if not isinstance(token, str) or not token.isascii() or any(c.isspace() for c in token) or len(token) > 16384:
            receipt["reason"] = "Credential format is unsupported. No Mac or live request occurred."
            return 1
        if run(["git", "status", "--porcelain", "--", "ios"], check=True).stdout.strip():
            receipt["reason"] = "Commit ios changes first. Remote tests require exact committed source."
            return 1
        sha = receipt["source_sha"]
        job = "leafhft-ios-live/" + sha[:12] + "-" + str(time.time_ns())
        receipt["remote_job"] = job
        archive = evidence / (job.replace("/", "-") + ".tar")
        run(["git", "archive", "--format=tar", "-o", str(archive), sha, "ios"], check=True)
        ssh = ["ssh", "-T", "-o", "BatchMode=yes", "-o", "ConnectTimeout=20", receipt["host"]]
        transport(ssh + ["mkdir -p " + shlex.quote(job)])
        transport(["scp", "-q", "-o", "BatchMode=yes", str(archive), receipt["host"] + ":" + job + "/source.tar"])
        transport(ssh + ["cd " + shlex.quote(job) + " && tar -xf source.tar"])
        helper = "cd " + shlex.quote(job) + " && python3 ios/scripts/live_smoke_mac.py "
        # Preparation is idempotent and sends no credential. Live execution is never retried.
        transport(ssh + [helper + "prepare " + shlex.quote(args.runtime)], timeout=1100)
        receipt["stage"] = "LIVE_OUTCOME_UNKNOWN"
        outcome = run(ssh + [helper + "run"], input=token.encode("ascii"), timeout=400)
        token = None
        # Read the fixed-schema receipt from disk even if the SSH result was lost.
        status = transport(ssh + ["cat " + shlex.quote(job + "/result.json")])
        remote = json.loads(status.stdout)
        accepted = remote.get("accepted_routes")
        passed = remote.get("result") == "PASS" and remote.get("exit_code") == 0 and accepted == 2
        receipt.update(result="PASS" if passed else "FAIL", exit_code=0 if passed else 1,
                       number=accepted if isinstance(accepted, int) else 0,
                       stage="RECEIPT", xcresult=receipt["host"] + ":" + job + "/live.xcresult",
                       simulator=remote.get("simulator"), smoke_seconds=remote.get("duration_seconds"))
        if not passed:
            receipt["reason"] = "Simulator smoke did not satisfy both routes and the explicit XCTest completion check."
        # The xcresult contains only test diagnostics. The bearer never enters the simulator.
        local_result = evidence / (job.replace("/", "-") + ".xcresult")
        copied = run(["scp", "-q", "-r", "-o", "BatchMode=yes",
                      receipt["host"] + ":" + job + "/live.xcresult", str(local_result)], timeout=120)
        if copied.returncode == 0:
            receipt["xcresult"] = str(local_result)
        return receipt["exit_code"]
    except Exception:
        receipt["reason"] = "Readiness, preparation, transport, or result unavailable. Inspect the retained job before any live retry."
        return 1
    finally:
        token = None
        receipt["duration_seconds"] = round(time.monotonic() - started, 3)
        receipt["observed_at"] = datetime.now(timezone.utc).isoformat()
        (evidence / "rung-5.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    raise SystemExit(main())
