#!/bin/bash
# Build on the signing Mac. Inputs identify existing signing material only.
set -euo pipefail
exec python3 - "$@" <<'PY'
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import plistlib
import re
import shutil
import subprocess
import tempfile
import zipfile

p = argparse.ArgumentParser(description='Development-only Leaf HFT IPA using an existing identity and profile')
p.add_argument('--project', type=Path, required=True)
p.add_argument('--identity-file', type=Path, required=True, help='File containing the existing Apple Development identity SHA-1')
p.add_argument('--profile', type=Path, required=True, help='Existing development mobileprovision file')
p.add_argument('--source-sha', required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--xcodegen', default=str(Path.home() / 'bin/xcodegen'))
a = p.parse_args()
project = a.project.resolve()
identity = a.identity_file.read_text().strip().upper()
if not re.fullmatch(r'[0-9A-F]{40}', identity) or not re.fullmatch(r'[0-9a-f]{40}', a.source_sha):
    raise SystemExit('Invalid identity or source digest')
if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project, text=True).strip() != a.source_sha:
    raise SystemExit('Checkout does not match source digest')
if subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=project, text=True).strip():
    raise SystemExit('Tracked source changes must be committed before building')
inventory = subprocess.check_output(['/usr/bin/security', 'find-identity', '-v', '-p', 'codesigning'], text=True)
if not any(identity in line and 'Apple Development:' in line for line in inventory.splitlines()):
    raise SystemExit('Existing Apple Development identity is unavailable; no certificate was created')
profile = plistlib.loads(subprocess.check_output(['/usr/bin/security', 'cms', '-D', '-i', str(a.profile.resolve())], stderr=subprocess.DEVNULL))
entitlements = profile.get('Entitlements', {})
if entitlements.get('get-task-allow') is not True or not profile.get('ProvisionedDevices') or profile.get('ProvisionsAllDevices'):
    raise SystemExit('Only a device-bound development profile is accepted; distribution IPA refused')
expiry = profile.get('ExpirationDate')
if not expiry or expiry.replace(tzinfo=timezone.utc) <= datetime.now(timezone.utc):
    raise SystemExit('Development profile expired')
if identity not in {hashlib.sha1(cert).hexdigest().upper() for cert in profile.get('DeveloperCertificates', [])}:
    raise SystemExit('Existing identity is not included in the profile')
bundle = 'com.evan.leafhft'
app_id = entitlements.get('application-identifier', '')
prefix = app_id.split('.', 1)[0]
allowed = app_id.split('.', 1)[1] if '.' in app_id else ''
if allowed != bundle and not (allowed.endswith('*') and bundle.startswith(allowed[:-1])):
    raise SystemExit('Development profile does not cover the Leaf HFT bundle')
entitlements['application-identifier'] = prefix + '.' + bundle
for key in ('keychain-access-groups',):
    if key in entitlements:
        entitlements[key] = [value.replace('*', bundle) for value in entitlements[key]]
output = a.output.resolve()
output.mkdir(parents=True, exist_ok=True)
# Provisioning data is used in-process and in the signed app, never printed.
with tempfile.TemporaryDirectory(prefix='leafhft-development-') as temporary:
    temp = Path(temporary)
    with (output / 'development-build.log').open('w') as log:
        subprocess.run([a.xcodegen, 'generate'], cwd=project / 'ios', stdout=log, stderr=subprocess.STDOUT, check=True)
        subprocess.run(['xcodebuild', '-project', 'LeafHFT.xcodeproj', '-scheme', 'LeafHFT',
                        '-configuration', 'Release', '-destination', 'generic/platform=iOS',
                        '-derivedDataPath', str(temp / 'DerivedData'), 'build',
                        'CODE_SIGNING_ALLOWED=NO', 'CODE_SIGNING_REQUIRED=NO',
                        'LEAFHFT_SOURCE_SHA=' + a.source_sha],
                       cwd=project / 'ios', stdout=log, stderr=subprocess.STDOUT, check=True)
    app = temp / 'Payload/LeafHFT.app'
    app.parent.mkdir()
    shutil.copytree(temp / 'DerivedData/Build/Products/Release-iphoneos/LeafHFT.app', app)
    info = plistlib.loads((app / 'Info.plist').read_bytes())
    if info.get('CFBundleIdentifier') != bundle or info.get('LeafHFTSourceSHA') != a.source_sha:
        raise SystemExit('Built app source marker or bundle identity does not match')
    shutil.copy2(a.profile, app / 'embedded.mobileprovision')
    entitlement_file = temp / 'entitlements.plist'
    entitlement_file.write_bytes(plistlib.dumps(entitlements))
    sign = ['/usr/bin/codesign', '--force', '--sign', identity, '--timestamp=none']
    for nested in sorted(app.rglob('*.framework'), key=lambda path: len(path.parts), reverse=True):
        subprocess.run(sign + [str(nested)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    for nested in app.rglob('*.dylib'):
        subprocess.run(sign + [str(nested)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    subprocess.run(sign + ['--entitlements', str(entitlement_file), str(app)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', str(app)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    ipa = output / 'LeafHFT-development.ipa'
    # ditto preserves executable bits and bundle structure needed on iOS.
    subprocess.run(['/usr/bin/ditto', '-c', '-k', '--keepParent', str(app.parent), str(ipa)], check=True)
    digest = hashlib.sha256(ipa.read_bytes()).hexdigest()
    receipt = output / 'LeafHFT-development.receipt.json'
    receipt.write_text(json.dumps({'schemaVersion': 1, 'sourceSha': a.source_sha,
        'ipaSha256': digest, 'signingMethod': 'development', 'bundleId': bundle,
        'embeddedSourceSha': info['LeafHFTSourceSHA'], 'certificateCreated': False,
        'keychainMutated': False}, indent=2) + '\n')
    print(json.dumps({'ipa': str(ipa), 'ipaSha256': digest, 'receipt': str(receipt),
                      'receiptSha256': hashlib.sha256(receipt.read_bytes()).hexdigest()}))
PY
