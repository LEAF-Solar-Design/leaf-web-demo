#!/bin/bash
set -euo pipefail
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This verifier requires macOS and Xcode." >&2
  exit 1
fi
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/ios"
xcodegen generate
xcodebuild -scheme LeafHFT -destination "platform=iOS Simulator,name=iPhone 16" test
cd "$ROOT"
swift test --package-path ios/Packages/LeafHFTCore
