"""Sync ios/ to the Mac mini and run the native verification there.

Windows has no Swift toolchain; the Mac mini (ssh alias ``mac-mini``) is the one Mac for
every build and test lane. This script is the single verify command for iOS pair records:

  python ios/scripts/mac_verify.py --core          # swift test on LeafHFTCore only (fast)
  python ios/scripts/mac_verify.py --unit [--unit-only CLASS ...]
                                                   # core + hosted LeafHFTTests, optionally selected classes
  python ios/scripts/mac_verify.py --ui <TestClass> [--screenshots DIR]
                                                   # one UI test class, attachments pulled back

Use repeatable --skip TEST options with --unit or --ui to exclude named tests.

On participating Windows hosts, runs first request a Mac mini allocator build/simulator
slot, or reuse MINI_ALLOC_TICKET from the caller. Remote commands run under that ticket;
a lost lease exits 75. When the allocator is disabled or unavailable, the legacy locks
below remain the fallback, waiting up to --lock-wait minutes (default 60).
On Windows when C:/tmp/gates exists, fallback runs serialize on C:/tmp/gates/mini-ios-test.lock
(shared with ios_test.py), waiting up to --lock-wait minutes (default 60). Failure to
take the lock or MINI_HOLD exits 75. A wrapper already holding the lock sets
LEAFHFT_MINI_LOCK_HELD to its exact token. The same runs also take the on-mini lock
(~/bin/mini_ios_lock.py over ssh, shared with ios_test.py and on-mini CI) within the same
--lock-wait budget; a held or unavailable on-mini lock also exits 75. A caller already
holding the on-mini lock sets MINI_IOS_LOCK_HELD (any value) and it is neither taken nor released.

Exit code is the remote test exit code (0 pass). Every remote command and its tail lands in
the log path printed at the end, so a failing run names the failing test, not just "1".
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import importlib.util
from datetime import datetime, timezone
import json
import math
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path, PurePosixPath

# Windows consoles default to cp1252; xcodebuild output carries box-drawing glyphs.
for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[2]
HOST = os.environ.get("LEAFHFT_MAC_HOST", "mac-mini")
# One remote tree per local checkout: two lanes syncing into one directory clobber each other
# mid-run (measured 2026-09-19, a sibling's test file landed in this lane's tree during a verify).
import hashlib
_REMOTE_DEFAULT = "~/leafhft-verify-" + hashlib.sha256(str(ROOT).lower().encode()).hexdigest()[:10]
REMOTE = os.environ.get("LEAFHFT_MAC_DIR", _REMOTE_DEFAULT)
SIM_NAME = os.environ.get("LEAFHFT_SIM_NAME", "iPhone 17")
EXCLUDES = ["DerivedData", ".build", "LeafHFT.xcodeproj", "artifacts", "simulator-result.json", ".DS_Store"]

# Only participating Windows hosts have this directory; never create it.
GATES = Path("C:/tmp/gates")
# Shared with ios_test.py, including its whitespace-delimited token format.
LOCK = GATES / "mini-ios-test.lock"
# Operator gate preventing new Mac mini runs.
HOLD = GATES / "MINI_HOLD"
# Must match ios_test.py's stale-lock threshold.
LOCK_STALE_S = 7200
# Seconds between checks of a live holder.
LOCK_POLL_S = 20
# Retries without sleeping (lock vanished or stale lock removed) before the deadline check.
LOCK_IMMEDIATE_RETRIES = 8
# Bounds the wait so the seconds conversion stays finite.
LOCK_WAIT_MAX_MIN = 1440
# EX_TEMPFAIL means lock unavailable, never a test result.
LOCK_EXIT = 75
# Wrappers pass the exact token of their already-held lock.
HELD_ENV = "LEAFHFT_MINI_LOCK_HELD"
# The on-mini lock, shared with ios_test.py and CI running on the mini itself.
REMOTE_LOCK_CMD = "/usr/bin/python3 ~/bin/mini_ios_lock.py"
# Present (any value, even empty) means the caller already holds the on-mini lock.
REMOTE_LOCK_HELD_ENV = "MINI_IOS_LOCK_HELD"
# Matches LOCK_STALE_S and ios_test.py; the mini's maximum TTL bounds a leaked lock.
REMOTE_LOCK_TTL_S = 7200
# Local ssh timeout is the remote wait plus this slack.
REMOTE_LOCK_SLACK_S = 120
# Bounds ssh connection setup for the lock calls.
SSH_CONNECT_TIMEOUT_S = 10
# The on-mini lock token: exactly 32 lowercase hex characters.
REMOTE_TOKEN_RE = re.compile(r"[0-9a-f]{32}")
# Anything token-shaped is redacted before any lock diagnostic reaches the log.
TOKEN_SHAPED_RE = re.compile(r"[0-9A-Fa-f]{32,}")


class LockUnavailable(Exception):
    pass


class AllocatorLeaseLost(Exception):
    pass


def allocator_log(handle, text: str) -> None:
    log(handle, TOKEN_SHAPED_RE.sub("<redacted>", "mini allocator: " + text))


def load_alloc_client():
    if os.environ.get("MINI_ALLOC") == "0":
        raise LockUnavailable("MINI_ALLOC=0")
    if (GATES / "MINI_ALLOC_OFF").exists():
        raise LockUnavailable("MINI_ALLOC_OFF exists")
    path = Path(os.environ.get("MINI_ALLOC_CLIENT",
                              "C:/Users/ehaug/.claude/scripts/mac-mini/mini_alloc_client.py"))
    if not path.is_file():
        raise LockUnavailable("client file missing")
    spec = importlib.util.spec_from_file_location("mini_alloc_client", path)
    if spec is None or spec.loader is None:
        raise ImportError("client loader unavailable")
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    sys.path.insert(0, str(path.parent))
    try:
        spec.loader.exec_module(module)
    except BaseException:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
        raise
    finally:
        sys.path.pop(0)
    return module


def build_remote_command(command: str, timeout: float) -> str:
    shell = "bash -c " + shlex.quote(command)
    ticket = os.environ.get("MINI_ALLOC_TICKET", "") if lock_applies() else ""
    if ticket:
        return ("/usr/bin/python3 ~/bin/mini_alloc.py run --ticket " + shlex.quote(ticket)
                + f" --timeout-s {timeout:g} -- " + shell)
    return shell


def check_allocator_exit(rc: int) -> int:
    if rc == 76 and os.environ.get("MINI_ALLOC_TICKET") and lock_applies():
        raise AllocatorLeaseLost()
    return rc


def lock_applies() -> bool:
    return os.name == "nt" and GATES.is_dir()


def pid_alive(pid: int) -> bool:
    if os.name == "nt":
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
        except (OSError, subprocess.TimeoutExpired):
            return True
        if result.returncode:
            return True
        if any(len(row) >= 2 and row[1].strip() == str(pid)
               for row in csv.reader(result.stdout.splitlines())):
            return True
        lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        return not (lines and all(line.startswith("INFO:") for line in lines))
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except OSError:
        return True
    return True


def parse_holder(text: str) -> tuple[str, int, float]:
    fields = text.split()
    if len(fields) < 3:
        raise ValueError("lock token needs name, pid and epoch")
    pid, started = int(fields[1]), float(fields[2])
    if not math.isfinite(started):
        raise ValueError("lock epoch must be finite")
    return fields[0], pid, started


def describe_holder(text: str) -> str:
    try:
        name, pid, started = parse_holder(text)
        taken = datetime.fromtimestamp(started, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
        return f"{name} (pid {pid}, taken {taken}Z, {int(time.time() - started)} s ago)"
    except (ValueError, OverflowError, OSError):
        return "unparseable lock content " + repr(text[:200])


def lock_name() -> str:
    return re.sub(r"\s+", "_", "leafhft-mac-verify:" + PurePosixPath(REMOTE).name)


def acquire_mini_lock(name: str, wait_s: float, handle) -> str:
    deadline = time.monotonic() + wait_s
    last_content = None
    immediate = 0
    while True:
        if HOLD.exists():
            raise LockUnavailable(f"{HOLD} exists (operator hold on the Mac mini)")
        token = f"{name} {os.getpid()} {time.time()}\n"
        retry_now = False
        try:
            fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            try:
                content = LOCK.read_text(encoding="utf-8")
            except FileNotFoundError:
                content = "<lock vanished while reading>"
                retry_now = True
            except OSError:
                content = "<unreadable>"
            if not retry_now:
                try:
                    _, pid, started = parse_holder(content)
                    if (not pid_alive(pid) or time.time() - started > LOCK_STALE_S):
                        if LOCK.read_text(encoding="utf-8") == content:
                            try:
                                LOCK.unlink()
                            except FileNotFoundError:
                                pass
                            else:
                                log(handle, f"mini lock: took over stale lock from {describe_holder(content)}")
                            retry_now = True
                except FileNotFoundError:
                    retry_now = True
                except (OSError, ValueError):
                    pass
        except OSError as exc:
            content = f"<cannot create lock: {type(exc).__name__}: {exc}>"
        else:
            try:
                stream = os.fdopen(fd, "w", encoding="utf-8", newline="\n")
                fd = None
                with stream:
                    stream.write(token)
                log(handle, f"mini lock taken: {LOCK} as {name}")
            except BaseException:
                if fd is not None:
                    with contextlib.suppress(OSError):
                        os.close(fd)
                with contextlib.suppress(OSError):
                    content = LOCK.read_text(encoding="utf-8")
                    if token.startswith(content):
                        LOCK.unlink()
                raise
            return token
        if retry_now and immediate < LOCK_IMMEDIATE_RETRIES:
            immediate += 1
            continue
        if content != last_content:
            log(handle, f"mini lock held by {describe_holder(content)}; "
                        f"waiting up to {wait_s/60:g} min for {LOCK}")
            last_content = content
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise LockUnavailable(f"mini lock wait exceeded {wait_s/60:g} min; "
                                  f"holder: {describe_holder(content)}")
        time.sleep(min(LOCK_POLL_S, remaining))
        immediate = 0


def verify_held_lock(held: str) -> None:
    try:
        content = LOCK.read_text(encoding="utf-8")
    except OSError as exc:
        raise LockUnavailable(f"{HELD_ENV} is set but {LOCK} is missing or unreadable") from exc
    if content != held and content != held + "\n":
        raise LockUnavailable(f"{HELD_ENV} does not match {LOCK}; holder: {describe_holder(content)}")


def release_mini_lock(token: str | None, handle) -> None:
    if token is None:
        return
    try:
        content = LOCK.read_text(encoding="utf-8")
        if content == token:
            LOCK.unlink()
            log(handle, "mini lock released")
        else:
            log(handle, f"mini lock not released: content changed to {describe_holder(content)}")
    except OSError:
        pass


def remote_lock_argv(remote_command: str) -> list[str]:
    return ["ssh", "-o", "BatchMode=yes", "-o", f"ConnectTimeout={SSH_CONNECT_TIMEOUT_S}", HOST, remote_command]


def remote_text(text: str, limit: int, tail: bool = False) -> str:
    """Remote-supplied text made safe to log: token-shaped runs redacted first, control characters
    replaced, then bounded to `limit` characters (the end when `tail`), so no cut can expose a token."""
    text = TOKEN_SHAPED_RE.sub("<redacted>", text)
    text = "".join(char if char.isprintable() else "?" for char in text)
    return (text[-limit:] if tail else text[:limit]).strip()


def parse_acquire_response(result) -> str:
    """Return the token from an acquire response or raise LockUnavailable; any malformed response fails closed."""
    if result.returncode == LOCK_EXIT:
        try:
            info = json.loads(result.stdout)
        except (ValueError, RecursionError):
            info = None
        held_by = info.get("held_by") if isinstance(info, dict) else None
        if not isinstance(held_by, str):
            raise LockUnavailable("on-mini lock unavailable: invalid response")
        message = f"on-mini lock held by {remote_text(held_by, 200)}"
        expires = info.get("expires_at")
        if isinstance(expires, (int, float)) and not isinstance(expires, bool):
            with contextlib.suppress(OverflowError, OSError, ValueError):
                if math.isfinite(expires):
                    stamp = datetime.fromtimestamp(expires, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
                    message += f" (expires {stamp}Z)"
        if held_by == "hold":
            message += " (operator hold ~/.mini-locks/HOLD on the mini)"
        raise LockUnavailable(message)
    if result.returncode != 0:
        tail = remote_text(result.stderr or "", 300, tail=True)
        raise LockUnavailable(f"on-mini lock unavailable: exit {result.returncode}" + (f": {tail}" if tail else ""))
    try:
        info = json.loads(result.stdout)
    except (ValueError, RecursionError):
        info = None
    if not isinstance(info, dict):
        raise LockUnavailable("on-mini lock unavailable: invalid response")
    token = info.get("token")
    if not isinstance(token, str) or not REMOTE_TOKEN_RE.fullmatch(token):
        raise LockUnavailable("on-mini lock unavailable: invalid token")
    return token


def acquire_remote_lock(owner: str, wait_s: float, handle) -> str:
    """Take the on-mini lock and return its token; raises LockUnavailable. Never logs stdout (it carries the token)."""
    wait = max(0, int(wait_s))
    timeout = wait + REMOTE_LOCK_SLACK_S
    command = (f"{REMOTE_LOCK_CMD} acquire --owner {shlex.quote(owner)} --host remote "
               f"--ttl {REMOTE_LOCK_TTL_S} --wait-seconds {wait}")
    log(handle, f"on-mini lock: acquiring as {owner} (wait up to {wait} s)")
    try:
        result = subprocess.run(remote_lock_argv(command), stdin=subprocess.DEVNULL, capture_output=True,
                                text=True, encoding="utf-8", errors="replace", timeout=timeout)
    except subprocess.TimeoutExpired:
        raise LockUnavailable(f"on-mini lock unavailable: timed out after {timeout}s") from None
    except OSError:
        raise LockUnavailable("on-mini lock unavailable: ssh could not start") from None
    try:
        token = parse_acquire_response(result)
    except LockUnavailable:
        raise
    except Exception:
        # Fail closed: a response we cannot parse is an unavailable lock, never a traceback.
        raise LockUnavailable("on-mini lock unavailable: invalid response") from None
    log(handle, f"on-mini lock taken as {owner}")
    return token


def release_remote_lock(token: str | None, handle) -> None:
    """Best-effort release of the on-mini lock; never raises and never logs the token or the command."""
    if token is None:
        return
    try:
        result = subprocess.run(remote_lock_argv(f"{REMOTE_LOCK_CMD} release --token {shlex.quote(token)}"),
                                stdin=subprocess.DEVNULL, capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=60)
    except Exception as exc:
        log(handle, f"on-mini lock release failed: {type(exc).__name__}")
        return
    if result.returncode == 0:
        log(handle, "on-mini lock released")
    else:
        log(handle, f"on-mini lock release failed: exit {result.returncode}")


def log(handle, text: str) -> None:
    handle.write(text + "\n")
    handle.flush()
    print(text, flush=True)


def ssh(remote_command: str, handle, timeout: int) -> int:
    """Run one remote command, streaming its output into the log; return its exit code."""
    log(handle, f"$ ssh {HOST} {remote_command}")
    proc = subprocess.Popen(["ssh", "-o", "BatchMode=yes", HOST, build_remote_command(remote_command, timeout)],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace")
    started = time.monotonic()
    tail: list[str] = []
    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip("\n")
        handle.write(line + "\n")
        tail.append(line)
        if len(tail) > 60:
            tail.pop(0)
        if time.monotonic() - started > timeout:
            proc.kill()
            log(handle, f"TIMEOUT after {timeout}s")
            return 124
    rc = proc.wait()
    handle.flush()
    print("\n".join(tail[-40:]), flush=True)
    log(handle, f"exit {rc}")
    return check_allocator_exit(rc)


def sync(handle) -> None:
    """Replace the remote ios/ tree with the local one (tar over ssh; no rsync on Windows)."""
    tar = ["tar", "-cf", "-", "-C", str(ROOT)] + [f"--exclude={e}" for e in EXCLUDES] + ["ios"]
    remote = f"mkdir -p {REMOTE} && rm -rf {REMOTE}/ios && tar -xf - -C {REMOTE}"
    log(handle, f"$ {' '.join(tar)} | ssh {HOST} {remote}")
    producer = subprocess.Popen(tar, stdout=subprocess.PIPE)
    consumer = subprocess.run(["ssh", "-o", "BatchMode=yes", HOST, build_remote_command(remote, 600)], stdin=producer.stdout,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=600)
    producer.wait()
    check_allocator_exit(consumer.returncode)
    if producer.returncode or consumer.returncode:
        log(handle, consumer.stdout)
        raise SystemExit(f"sync failed: tar {producer.returncode} ssh {consumer.returncode}")
    log(handle, "synced")


def remote_path(path: str) -> str:
    """Quote a remote path while preserving the default home-relative workspace."""
    if path.startswith("~/"):
        return '"$HOME"/' + shlex.quote(path[2:])
    return shlex.quote(path)


def attachment_ssh(command: str, handle, timeout: int) -> int:
    """Bound attachment commands even when the remote process produces no output."""
    log(handle, f"$ ssh {HOST} {command}")
    try:
        result = subprocess.run(
            ["ssh", "-o", "BatchMode=yes", HOST, build_remote_command(command, timeout)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            encoding="utf-8", errors="replace", timeout=timeout)
        if result.stdout:
            log(handle, result.stdout.rstrip())
        return check_allocator_exit(result.returncode)
    except subprocess.TimeoutExpired:
        log(handle, f"TIMEOUT after {timeout}s")
        return 124
    except OSError as exc:
        log(handle, f"attachment command failed: {exc}")
        return 1


def pull_attachments(out: str, local: Path, handle, timeout: float) -> bool:
    """Give tar extraction and its SSH producer one shared deadline."""
    deadline = time.monotonic() + timeout
    producer = consumer = None
    timed_out = False
    try:
        command = f"tar -C {remote_path(out)} -cf - ."
        log(handle, f"$ ssh {HOST} {command} | tar -xf - -C {local}")
        producer = subprocess.Popen(["ssh", "-o", "BatchMode=yes", HOST, build_remote_command(command, timeout)],
                                    stdout=subprocess.PIPE)
        consumer = subprocess.Popen(["tar", "-xf", "-", "-C", str(local)],
                                    stdin=producer.stdout)
        producer.stdout.close()
        consumer_rc = consumer.wait(timeout=max(0, deadline - time.monotonic()))
        if consumer_rc:
            if producer.poll() is not None:
                check_allocator_exit(producer.returncode)
            log(handle, f"attachment tar failed: exit {consumer_rc}")
            return False
        producer_rc = producer.wait(timeout=max(0, deadline - time.monotonic()))
        check_allocator_exit(producer_rc)
        if producer_rc:
            log(handle, f"attachment ssh failed: exit {producer_rc}")
            return False
        return True
    except subprocess.TimeoutExpired:
        timed_out = True
        return False
    except OSError as exc:
        log(handle, f"attachment pull failed: {exc}")
        return False
    finally:
        # Kill both before attempting to reap either. Never add an unbounded wait
        # after the deadline, including on a broken pipe or failed tar launch.
        for proc in (consumer, producer):
            if proc is not None:
                try:
                    if proc.poll() is None:
                        proc.kill()
                except OSError:
                    pass
        for proc in (consumer, producer):
            if proc is not None:
                try:
                    proc.wait(timeout=0)
                except (subprocess.TimeoutExpired, OSError):
                    pass
        if producer is not None and producer.stdout is not None:
            producer.stdout.close()
        if timed_out:
            log(handle, f"TIMEOUT attachment pull after {timeout:g}s")


def prune_attachments(out: str, handle) -> None:
    """Remove this export and retain six matching artifacts in this workspace."""
    script = r'''
import re
import shutil
import sys
from pathlib import Path
root = Path(sys.argv[1]).expanduser().resolve()
artifacts = root / "artifacts"
if artifacts.is_symlink():
    raise ValueError("refusing symlink artifacts directory")
pattern = re.compile(r"(?:unit-[0-9]+\.xcresult|ui-[A-Za-z0-9_.-]+-[0-9]+(?:\.xcresult|-attachments))")
export = Path(sys.argv[2]).expanduser()
if not export.is_absolute():
    export = Path.cwd() / export
if export.parent.resolve() != artifacts or not pattern.fullmatch(export.name) or not export.name.endswith("-attachments"):
    raise ValueError("export is outside this workspace's artifacts")
def remove(entry):
    if entry.is_symlink() or not entry.is_dir():
        entry.unlink()
    else:
        shutil.rmtree(entry)
if export.exists() or export.is_symlink():
    remove(artifacts / export.name)
entries = [p for p in artifacts.iterdir() if pattern.fullmatch(p.name)]
entries.sort(key=lambda p: (p.lstat().st_mtime_ns, p.name), reverse=True)
for entry in entries[6:]:
    remove(entry)
print("artifacts: kept=" + str(min(6, len(entries))) + " pruned=" + str(max(0, len(entries) - 6)))
'''
    command = "python3 -c " + shlex.quote(script) + " " + shlex.quote(REMOTE) + " " + shlex.quote(out)
    rc = attachment_ssh(command, handle, 120)
    if rc:
        log(handle, f"attachment cleanup failed: exit {rc}")


def collect_attachments(bundle: str, out: str, local: Path, screenshot_filter: str,
                        pull_timeout: float, handle) -> int:
    started = time.monotonic()
    command = (f"xcrun xcresulttool export attachments --path {remote_path(bundle)} "
               f"--output-path {remote_path(out)} --filter {shlex.quote(screenshot_filter)}")
    export = attachment_ssh(command, handle, 600)
    log(handle, f"attachment export: seconds={time.monotonic() - started:.3f} exit={export}")
    started = time.monotonic()
    files = total_bytes = screenshots = 0
    pulled = False
    try:
        if export == 0:
            local.mkdir(parents=True, exist_ok=True)
            # A fresh staging directory prevents old screenshots from masking a
            # failed pull and lets counts describe only this run's attachments.
            with tempfile.TemporaryDirectory(prefix=".attachments-", dir=local) as staging:
                stage = Path(staging)
                pulled = pull_attachments(out, stage, handle, pull_timeout)
                for source in stage.rglob("*"):
                    if source.is_file() and not source.is_symlink():
                        size = source.stat().st_size
                        destination = local / source.relative_to(stage)
                        destination.parent.mkdir(parents=True, exist_ok=True)
                        source.replace(destination)
                        files += 1
                        total_bytes += size
                        screenshots += int(destination.suffix.lower() == ".png" and size > 0)
    except OSError as exc:
        pulled = False
        log(handle, f"attachment pull failed: {exc}")
    log(handle, f"attachment pull: seconds={time.monotonic() - started:.3f} "
                f"files={files} bytes={total_bytes} success={pulled}")
    if pulled:
        prune_attachments(out, handle)
    if not screenshots:
        log(handle, "no screenshots arrived")
    return screenshots


def main() -> int:
    global SIM_NAME
    parser = argparse.ArgumentParser()
    parser.add_argument("--core", action="store_true")
    parser.add_argument("--unit", action="store_true")
    parser.add_argument("--unit-only", action="append", default=[], metavar="CLASS")
    parser.add_argument("--ui", metavar="TESTCLASS", help="LeafHFTUITests class to run, e.g. EngineSettingsUITests")
    parser.add_argument("--erase-sim", action="store_true",
                        help="shut down and erase the selected simulator before --ui (default off)")
    parser.add_argument("--only", metavar="TEST", help="single test method inside --ui class")
    parser.add_argument("--screenshots", metavar="DIR", help="local directory that receives exported attachments")
    parser.add_argument("--screenshot-filter", default="*.png", metavar="GLOB",
                        help="attachment filename filter (default *.png; '*' exports all)")
    parser.add_argument("--pull-timeout", type=float, default=300, metavar="SECONDS",
                        help="overall attachment pull deadline (default 300 seconds)")
    parser.add_argument("--content-size", metavar="SIZE",
                        help="simctl content size for --ui, e.g. accessibility-extra-large")
    parser.add_argument("--appearance", choices=["light", "dark"],
                        help="simctl appearance for --ui; also exported as TEST_RUNNER_LEAFHFT_TEST_APPEARANCE")
    parser.add_argument("--skip", action="append", default=[], metavar="TEST",
                        help="xcodebuild -skip-testing target, repeatable (pre-existing failures outside the lane)")
    parser.add_argument("--no-sync", action="store_true")
    parser.add_argument("--alloc-deadline-s", type=float, default=3000, metavar="SECONDS",
                        help="allocator lease deadline (positive seconds, capped at 3000)")
    parser.add_argument("--lock-wait", type=float, default=60, metavar="MINUTES",
                        help="wait for C:/tmp/gates/mini-ios-test.lock (0 to 1440 minutes, default 60); "
                             "wrappers pass their token in LEAFHFT_MINI_LOCK_HELD")
    parser.add_argument("--log", default=str(Path("C:/tmp") / f"leafhft-mac-verify-{int(time.time())}.log"))
    args = parser.parse_args()
    if not math.isfinite(args.alloc_deadline_s) or args.alloc_deadline_s <= 0:
        parser.error("--alloc-deadline-s must be a finite positive number")
    if not math.isfinite(args.lock_wait) or not 0 <= args.lock_wait <= LOCK_WAIT_MAX_MIN:
        parser.error("--lock-wait must be finite and between 0 and 1440")
    if not math.isfinite(args.pull_timeout) or args.pull_timeout <= 0:
        parser.error("--pull-timeout must be a finite positive number")
    if args.unit_only and not args.unit:
        parser.error("--unit-only requires --unit")
    if not (args.core or args.unit or args.ui):
        args.unit = True
    log_path = Path(args.log)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as handle:
        token = None
        remote_token = None
        client = None
        lease = None
        try:
            # The on-mini lock follows the participating-host gate: that gate is the fleet protocol
            # boundary, Linux CI suites must never ssh, and such hosts skip the Windows lock too.
            if lock_applies():
                if os.environ.get("MINI_ALLOC_TICKET"):
                    allocator_log(handle, "running under ticket " + os.environ["MINI_ALLOC_TICKET"][:8])
                    original_sim = SIM_NAME
                    try:
                        SIM_NAME = os.environ.get("LEAFHFT_SIM_NAME", SIM_NAME)
                        return check_allocator_exit(run_legs(args, handle, log_path))
                    finally:
                        SIM_NAME = original_sim
                if os.environ.get(HELD_ENV) or REMOTE_LOCK_HELD_ENV in os.environ:
                    allocator_log(handle, "caller holds the legacy locks; not requesting an allocator slot")
                else:
                    try:
                        client = load_alloc_client()
                    except Exception as exc:
                        allocator_log(handle, f"unavailable ({exc}); using the legacy locks")
                if client is not None:
                    with contextlib.ExitStack() as leases:
                        try:
                            sim_requested = args.unit or bool(args.ui)
                            options = dict(lane="leafhft-mac-verify", job=lock_name(),
                                           slots="sim,build" if sim_requested else "build",
                                           deadline_s=min(3000, args.alloc_deadline_s), kind="mac_verify",
                                           markers=[PurePosixPath(REMOTE).name], queue_wait_s=args.lock_wait * 60)
                            if sim_requested:
                                options["sim_types"] = [os.environ.get("LEAFHFT_SIM_TYPE", "iPhone 17")]
                            lease = leases.enter_context(client.lease(**options))
                        except client.AllocatorUnavailable as exc:
                            allocator_log(handle, f"unavailable ({exc}); using the legacy locks")
                        except client.QueueTimeout as exc:
                            allocator_log(handle, f"queue timeout ({exc})")
                            return LOCK_EXIT
                        except client.LeaseLost:
                            raise AllocatorLeaseLost() from None
                        else:
                            original_env = {key: os.environ.get(key) for key in lease.env}
                            original_sim = SIM_NAME
                            try:
                                os.environ.update(lease.env)
                                SIM_NAME = lease.env.get("LEAFHFT_SIM_NAME", SIM_NAME)
                                lease.outcome = "fail"
                                try:
                                    rc = check_allocator_exit(run_legs(args, handle, log_path))
                                    if lease.lost:
                                        raise AllocatorLeaseLost()
                                except (AllocatorLeaseLost, client.LeaseLost):
                                    lease.outcome = "infra"
                                    raise AllocatorLeaseLost() from None
                                lease.outcome = "ok" if rc == 0 else "fail"
                                return rc
                            finally:
                                SIM_NAME = original_sim
                                for key, value in original_env.items():
                                    if value is None:
                                        os.environ.pop(key, None)
                                    else:
                                        os.environ[key] = value
                deadline = time.monotonic() + args.lock_wait * 60
                held = os.environ.get(HELD_ENV, "")
                try:
                    if held:
                        verify_held_lock(held)
                        log(handle, f"mini lock held by caller ({HELD_ENV}); not taking or releasing it")
                    else:
                        token = acquire_mini_lock(lock_name(), args.lock_wait * 60, handle)
                    if REMOTE_LOCK_HELD_ENV in os.environ:
                        log(handle, f"on-mini lock held by caller ({REMOTE_LOCK_HELD_ENV}); "
                                    "not taking or releasing it")
                    else:
                        owner = "windows:" + lock_name() + "-" + uuid.uuid4().hex[:12]
                        remote_token = acquire_remote_lock(owner, max(0.0, deadline - time.monotonic()), handle)
                except LockUnavailable as exc:
                    # Backstop: no lock diagnostic reaches the log with anything token-shaped in it.
                    log(handle, "mini lock: " + TOKEN_SHAPED_RE.sub("<redacted>", str(exc)))
                    log(handle, f"LOG {log_path}")
                    return LOCK_EXIT
            return run_legs(args, handle, log_path)
        except AllocatorLeaseLost:
            allocator_log(handle, "lease lost")
            return LOCK_EXIT
        except Exception as exc:
            if client is not None and isinstance(exc, client.LeaseLost):
                if lease is not None:
                    lease.outcome = "infra"
                allocator_log(handle, "lease lost")
                return LOCK_EXIT
            raise
        finally:
            # On-mini first, then Windows; a failed remote release never skips the Windows one.
            try:
                release_remote_lock(remote_token, handle)
            finally:
                release_mini_lock(token, handle)


def run_legs(args, handle, log_path) -> int:
    rc = 0
    if not args.no_sync:
        sync(handle)
    if args.core or args.unit:
        rc = ssh(f"cd {REMOTE} && swift test --package-path ios/Packages/LeafHFTCore 2>&1 | tail -40; "
                 "exit ${PIPESTATUS[0]}", handle, 1200)
        if rc:
            log(handle, f"LOG {log_path}")
            return rc
    if args.unit or args.ui:
        gen = ssh(f"cd {REMOTE}/ios && xcodegen generate 2>&1 | tail -5", handle, 300)
        if gen:
            log(handle, f"LOG {log_path}")
            return gen
    skips = " ".join(f"-skip-testing:{shlex.quote(t)}" for t in args.skip)
    if args.unit:
        bundle = f"{REMOTE}/artifacts/unit-{int(time.time())}.xcresult"
        targets = (" ".join(f"-only-testing:LeafHFTTests/{shlex.quote(t)}" for t in args.unit_only)
                   if args.unit_only else "-only-testing:LeafHFTTests")
        rc = ssh(f"cd {REMOTE}/ios && mkdir -p {REMOTE}/artifacts && "
                 f"xcodebuild test -project LeafHFT.xcodeproj -scheme LeafHFT "
                 f"-destination 'platform=iOS Simulator,name={SIM_NAME}' "
                 f"-derivedDataPath {REMOTE}/DerivedData -resultBundlePath {bundle} "
                 f"-parallel-testing-enabled NO {targets} {skips} "
                 f"CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO 2>&1 | "
                 "grep -E 'error:|Test Case|Executed|TEST |\\*\\* ' | tail -80; exit ${PIPESTATUS[0]}",
                 handle, 2400)
    if args.ui and rc == 0:
        if args.erase_sim:
            ssh(f"xcrun simctl shutdown {shlex.quote(SIM_NAME)}", handle, 120)
            rc = ssh(f"xcrun simctl erase {shlex.quote(SIM_NAME)}", handle, 300)
            if rc:
                log(handle, f"LOG {log_path}")
                return rc
        stamp = int(time.time())
        bundle = f"{REMOTE}/artifacts/ui-{args.ui}-{stamp}.xcresult"
        target = f"LeafHFTUITests/{args.ui}" + (f"/{args.only}" if args.only else "")
        size = ""
        if args.content_size or args.appearance:
            size = f"xcrun simctl boot '{SIM_NAME}' >/dev/null 2>&1; "
        if args.content_size:
            size += f"xcrun simctl ui '{SIM_NAME}' content_size {args.content_size} && "
        if args.appearance:
            size += (f"xcrun simctl ui '{SIM_NAME}' appearance {args.appearance} && "
                     f"export TEST_RUNNER_LEAFHFT_TEST_APPEARANCE={args.appearance} && ")
        rc = ssh(f"cd {REMOTE}/ios && mkdir -p {REMOTE}/artifacts && {size}"
                 f"xcodebuild test -project LeafHFT.xcodeproj -scheme LeafHFT "
                 f"-destination 'platform=iOS Simulator,name={SIM_NAME}' "
                 f"-derivedDataPath {REMOTE}/DerivedData -resultBundlePath {bundle} "
                 f"-parallel-testing-enabled NO -only-testing:{target}{' ' + skips if skips else ''} "
                 f"CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO 2>&1 | "
                 "grep -E 'error:|Test Case|Executed|TEST |\\*\\* |XCTAssert' | tail -80; exit ${PIPESTATUS[0]}",
                 handle, 3000)
        if args.content_size:
            ssh(f"xcrun simctl ui '{SIM_NAME}' content_size medium", handle, 120)
        if args.appearance == "dark":
            ssh(f"xcrun simctl ui '{SIM_NAME}' appearance light", handle, 120)
        if args.screenshots:
            out = f"{REMOTE}/artifacts/ui-{args.ui}-{stamp}-attachments"
            screenshots = collect_attachments(bundle, out, Path(args.screenshots),
                                              args.screenshot_filter, args.pull_timeout, handle)
            if not screenshots and rc == 0:
                rc = 1
    log(handle, f"LOG {log_path}")
    return rc


if __name__ == "__main__":
    sys.exit(main())
