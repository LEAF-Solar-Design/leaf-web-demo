#!/usr/bin/env python3
"""Run on the Windows or Mac USB host using the installed ios_walk physical rail."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import plistlib
import tempfile
import zipfile
import re
import subprocess
import shutil
import sys
import time

STEPS = "Connect the intended iPhone to this USB host, unlock it, and trust the computer. Configure IOS_DEVICE_UDID when other devices are attached. Keep the signing Mac reachable."


def read_profile(path):
    if sys.platform == "darwin":
        command = ["/usr/bin/security", "cms", "-D", "-i", str(path)]
    elif sys.platform == "win32":
        openssl = shutil.which("openssl")
        if not openssl:
            raise ImportError("OpenSSL is required to read the signed provisioning profile")
        # Verify the CMS content signature, without requiring Windows to trust
        # Apple's certificate chain. The immutable producer binds the IPA bytes.
        command = [openssl, "cms", "-verify", "-inform", "DER", "-binary",
                   "-noverify", "-in", str(path)]
    else:
        raise ImportError("Unsupported USB host platform")
    return plistlib.loads(subprocess.check_output(command, stderr=subprocess.DEVNULL, timeout=20))


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("ipa", "ipa-receipt", "wda-artifact", "wda-receipt", "wda-runner-bundle-id"):
        parser.add_argument("--" + name)
    parser.add_argument("--source-sha")
    parser.add_argument("--ipa-sha256")
    parser.add_argument("--ipa-receipt-sha256")
    parser.add_argument("--wda-sha256")
    parser.add_argument("--wda-receipt-sha256")
    parser.add_argument("--evidence-root", type=Path, default=Path("C:/tmp/leafhft-ios/evidence") if os.name == "nt" else Path.home() / "leafhft-ios/evidence")
    args = parser.parse_args()
    started = time.monotonic()
    project = Path(__file__).resolve().parents[2]
    date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    target = args.evidence_root / date / "rung-4.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    sha = args.source_sha or subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=project, text=True).strip()
    evidence = project / "_marathon/evidence" / ("leafhft-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"))
    recipe_receipt = evidence / "receipt.json"
    record = {"rung": 4, "sourceSha": sha, "host": platform.node(), "command": "python ios/scripts/device_rung.py", "result": "UNAVAILABLE", "exitCode": 2,
              "budgetSeconds": 480, "xcresult": None, "screenshots": [], "stages": [],
              "manualTestFlight": {"build": 1, "result": "UNAVAILABLE", "differences": "Not observed. Tester enrollment and manual walk have not been performed."}}
    device = None
    started_wda = False
    prepared = None
    def require(result, stage):
        record["stages"].append({"name": stage, "ok": result.get("ok") is True, "state": result.get("state")})
        if result.get("ok") is not True:
            raise RuntimeError("Canonical rail did not complete " + stage)
        return result
    try:
        required = [args.ipa, args.ipa_receipt, args.wda_artifact, args.wda_receipt, args.wda_runner_bundle_id,
                    args.ipa_sha256, args.ipa_receipt_sha256, args.wda_sha256, args.wda_receipt_sha256]
        if not all(required):
            record["reason"] = "Development IPA, producer receipts, WDA artifact, expected digests and runner binding are required. " + STEPS
            return 2
        if sys.platform not in ("darwin", "win32"):
            record["reason"] = "Run this command on the Windows or Mac USB host. " + STEPS
            return 2
        if not re.fullmatch(r"[0-9a-f]{40}", sha):
            raise ValueError("Invalid source digest")
        files = [(args.ipa, args.ipa_sha256), (args.ipa_receipt, args.ipa_receipt_sha256),
                 (args.wda_artifact, args.wda_sha256), (args.wda_receipt, args.wda_receipt_sha256)]
        for file, expected in files:
            if not re.fullmatch(r"[0-9a-f]{64}", expected) or digest(Path(file)) != expected:
                raise ValueError("Artifact or producer receipt digest mismatch")
        producer = json.loads(Path(args.ipa_receipt).read_text())
        if producer.get("sourceSha") != sha or producer.get("ipaSha256") != args.ipa_sha256 or producer.get("signingMethod") != "development":
            raise ValueError("A source-bound development IPA receipt is required")
        with zipfile.ZipFile(args.ipa) as archive:
            info = plistlib.loads(archive.read("Payload/LeafHFT.app/Info.plist"))
            if info.get("CFBundleIdentifier") != "com.evan.leafhft" or info.get("LeafHFTSourceSHA") != sha:
                raise ValueError("IPA embedded source or bundle does not match")
            with tempfile.TemporaryDirectory(prefix="leafhft-profile-check-") as temporary:
                profile_path = Path(temporary) / "embedded.mobileprovision"
                profile_path.write_bytes(archive.read("Payload/LeafHFT.app/embedded.mobileprovision"))
                profile = read_profile(profile_path)
            if profile.get("Entitlements", {}).get("get-task-allow") is not True or not profile.get("ProvisionedDevices"):
                raise ValueError("Distribution IPA refused")
        # A producer receipt is retained as immutable evidence; the canonical rail binds its digest.
        json.loads(Path(args.wda_receipt).read_text())
        from cadwalk_core.mcps.ios_walk import physical_device
        device = physical_device
        request = dict(project_dir=str(project), recipe="leafhft-read-only", source_sha=sha,
                       app_artifact_sha256=args.ipa_sha256, app_artifact_receipt_sha256 = args.ipa_receipt_sha256,
                       wda_artifact_sha256=args.wda_sha256, wda_artifact_receipt_sha256 = args.wda_receipt_sha256,
                       evidence_dir=str(evidence), receipt_path=str(recipe_receipt), fresh_install=False)
        require(device.recipe_preflight(**request), "recipe preflight")
        status = device.status()
        if not status.get("selected_device_ready", status.get("exactly_one_usb_device", False)):
            record["reason"] = "The selected USB iPhone is not ready. " + STEPS
            return 2
        record["stages"].append({"name": "status", "ok": True})
        installed = require(device.install_bound(ipa_path=args.ipa, artifact_receipt_path=args.ipa_receipt,
                            expected_source_sha=sha, expected_ipa_sha256=args.ipa_sha256,
                            expected_artifact_receipt_sha256 = args.ipa_receipt_sha256), "install_bound")
        deadline = started + 240
        while not installed.get("terminal"):
            if time.monotonic() > deadline:
                raise RuntimeError("Bound install timed out; inspect job before retry")
            time.sleep(2)
            installed = require(device.install_status(installed["job_id"]), "install_status")
        if installed.get("state") != "succeeded":
            raise RuntimeError("Bound install did not succeed")
        record["installReceipt"] = installed.get("terminal_receipt_path")
        started_wda = True
        require(device.start_wda(runner_bundle_id=args.wda_runner_bundle_id, timeout_seconds=180), "start_wda")
        spec = importlib.util.spec_from_file_location("leafhft_device_driver", project / "scripts/device-walk/drive_recipe.py")
        driver = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(driver)
        prepared = driver.prepare_fixture_screen("http://127.0.0.1:8100")
        evidence.mkdir(parents=True, exist_ok=True)
        require(device.screenshot(str(evidence / "initial-fixture.png")), "screenshot")
        prepared.close()
        prepared = None
        require(device.run_recipe(**request), "run_recipe")
        result = json.loads(recipe_receipt.read_text())
        if result.get("installedBuild", {}).get("embeddedSourceSha") != sha:
            raise RuntimeError("Installed source marker mismatch")
        record["physicalReceipt"] = str(recipe_receipt)
        record["screenshots"] = [str(evidence / item["relativePath"]) for item in result["evidence"] if item["kind"] == "screenshot"]
        record["result"] = "PASS"
        record["exitCode"] = 0
    except Exception as error:
        record["result"] = "UNAVAILABLE" if isinstance(error, ImportError) else "FAIL"
        record["exitCode"] = 2 if record["result"] == "UNAVAILABLE" else 1
        # Do not put provider subprocess or WDA payloads into the summary.
        record["reason"] = "Required physical stage failed (" + type(error).__name__ + "). Inspect retained stage receipts."
    finally:
        if prepared:
            try:
                prepared.close()
            except Exception:
                pass
        if started_wda:
            try:
                require(device.stop_wda(), "stop_wda")
            except Exception:
                record["result"], record["exitCode"] = "FAIL", 1
                record["reason"] = "WDA cleanup needs attention."
        record["durationSeconds"] = round(time.monotonic() - started, 3)
        record.update(source_sha=sha, exit_code=record["exitCode"], basis="confirmed",
                      duration_seconds=record["durationSeconds"], number=record["durationSeconds"],
                      unit="seconds", budget_seconds=480)
        record["withinBudget"] = record["durationSeconds"] < 480
        if record["result"] == "PASS" and not record["withinBudget"]:
            record["result"], record["exitCode"] = "FAIL", 1
            record["reason"] = "Physical walk exceeded the eight-minute budget."
        record["exit_code"] = record["exitCode"]
        target.write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps({"result": record["result"], "receipt": str(target), "reason": record.get("reason")}))
    return record["exitCode"]

if __name__ == "__main__":
    raise SystemExit(main())
