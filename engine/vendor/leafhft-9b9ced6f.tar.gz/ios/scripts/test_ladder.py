"""Run Leaf HFT's fixture test ladder from Windows, retaining source-bound evidence."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]


def transport(args, **kwargs):
    for attempt in range(3):
        result = subprocess.run(args, **kwargs)
        if result.returncode not in (124, 255) or attempt == 2:
            return result
        time.sleep(2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rung", type=int, choices=[1])
    parser.add_argument("--host", default="exzachly-aws-mac")
    parser.add_argument("--evidence-root", default="C:/tmp/leafhft-ios/evidence")
    args = parser.parse_args()
    sha = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    dirty = subprocess.check_output(["git", "status", "--porcelain", "--", "ios"], cwd=ROOT, text=True)
    if dirty.strip():
        parser.error("Commit ios changes first: remote tests run the exact committed source.")
    evidence = Path(args.evidence_root) / datetime.now(timezone.utc).strftime("%Y-%m-%d")
    evidence.mkdir(parents=True, exist_ok=True)
    run_id = f"rung-{args.rung}-{sha[:12]}-{time.time_ns()}"
    archive = evidence / (run_id + ".tar")
    subprocess.run(["git", "archive", "--format=tar", "-o", str(archive), sha, "ios"], cwd=ROOT, check=True)
    remote = "leafhft-ios-tests-01a09ff9/" + run_id
    ssh = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=20", args.host]
    command = "swift test --package-path ios/Packages/LeafHFTCore"
    budget = 60
    receipt = {"rung": args.rung, "source_sha": sha, "host": args.host,
               "controller_host": platform.node(), "command": command,
               "exit_code": None, "duration_seconds": None, "budget_seconds": budget,
               "number": None, "unit": "seconds", "result": "UNAVAILABLE", "basis": "confirmed",
               "xcresult": None, "screenshots": [], "log": str(evidence / (run_id + ".log"))}
    try:
        transport(ssh + ["mkdir -p " + shlex.quote(remote)], check=False, capture_output=True).check_returncode()
        transport(["scp", "-q", "-o", "BatchMode=yes", str(archive), args.host + ":" + remote + "/source.tar"],
                  capture_output=True).check_returncode()
        # Source is git archive output, so CRLF worktree settings never cross the wire.
        script = ("#!/bin/bash\ncd \"$(dirname \"$0\")\"\n"
                  "tar -xf source.tar || exit 70\n"
                  "start=$(date +%s)\n" + command + " > test.log 2>&1\n"
                  "rc=$?\nend=$(date +%s)\n"
                  "printf '%s %s\\n' \"$rc\" \"$((end-start))\" > result.tmp\n"
                  "mv result.tmp result.txt\n")
        launcher = evidence / (run_id + ".sh")
        launcher.write_text(script, encoding="utf-8", newline="\n")
        transport(["scp", "-q", "-o", "BatchMode=yes", str(launcher), args.host + ":" + remote + "/run.sh"],
                  capture_output=True).check_returncode()
        # Retrying a lost SSH response cannot launch a second job.
        spawn = ("import subprocess; log=open('launcher.log','ab'); "
                 "subprocess.Popen(['bash','run.sh'],stdin=subprocess.DEVNULL,"
                 "stdout=log,stderr=subprocess.STDOUT,start_new_session=True)")
        launch = ("cd " + shlex.quote(remote) + " && if mkdir started 2>/dev/null; then python3 -c "
                  + shlex.quote(spawn) + "; fi")
        transport(ssh + [launch], capture_output=True).check_returncode()
        deadline = time.monotonic() + 300
        while time.monotonic() < deadline:
            status = transport(ssh + ["cat " + shlex.quote(remote + "/result.txt")], capture_output=True, text=True)
            if status.returncode == 0:
                rc, elapsed = map(int, status.stdout.strip().split())
                receipt.update(exit_code=rc, duration_seconds=elapsed, number=elapsed,
                               result="PASS" if rc == 0 and elapsed < budget else "FAIL",
                               budget_met=elapsed < budget)
                break
            time.sleep(5)
        else:
            receipt["reason"] = "Remote result unavailable after 300 seconds; inspect existing job before retry."
        transport(["scp", "-q", args.host + ":" + remote + "/test.log", receipt["log"]], capture_output=True)
    except (OSError, subprocess.SubprocessError, ValueError):
        receipt["reason"] = "Transport or test result unavailable. Inspect the retained job before retrying."
    receipt["remote_job"] = remote
    receipt["observed_at"] = datetime.now(timezone.utc).isoformat()
    path = evidence / f"rung-{args.rung}.json"
    path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))
    return 0 if receipt["result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
