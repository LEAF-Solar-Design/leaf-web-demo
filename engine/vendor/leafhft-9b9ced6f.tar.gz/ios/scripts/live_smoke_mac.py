"""Isolated Mac build and one-shot loopback relay for Leaf HFT rung 5."""
import http.client
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
import plistlib
import subprocess
import sys
import threading
import time

JOB = Path.cwd().resolve()
ROUTES = frozenset(("/api/leafhft/mobile/books", "/api/leafhft/mobile/engines"))
ORIGIN = "ops-dashboard-seven.vercel.app"
MARKER = b"LEAFHFT_LIVE_SHAPES_PASSED"


def command(args, timeout=60):
    return subprocess.run(args, cwd=JOB / "ios", stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=timeout, check=True)


def test_targets(value):
    if isinstance(value, dict):
        if "TestBundlePath" in value:
            yield value
        for item in value.values():
            yield from test_targets(item)
    elif isinstance(value, list):
        for item in value:
            yield from test_targets(item)


def prepare(runtime_version="26.2"):
    if (JOB / "ready.json").exists():
        return 0
    # A failed preparation stays visible; do not duplicate a possibly active build.
    (JOB / "preparing").mkdir()
    device = None
    try:
        available = json.loads(command(["xcrun", "simctl", "list", "runtimes", "-j"]).stdout)
        runtime = next(r["identifier"] for r in available["runtimes"]
                       if r.get("isAvailable") and r.get("version") == runtime_version
                       and "iOS" in r["identifier"])
        device = command(["xcrun", "simctl", "create", "LeafHFT live " + JOB.name,
                          "com.apple.CoreSimulator.SimDeviceType.iPhone-16", runtime]).stdout.decode().strip()
        (JOB / "simulator.txt").write_text(device)
        # Prefer the packaged executable, whose settings presets ship together.
        # A source-tree binary without its presets can emit empty test products.
        generators = [Path("/opt/homebrew/bin/xcodegen"), Path.home() / "bin/xcodegen"]
        generator = next(path for path in generators if path.is_file())
        command([str(generator), "generate"])
        command(["xcodebuild", "build-for-testing", "-project", "LeafHFT.xcodeproj", "-scheme", "LeafHFT",
                 "-destination", "platform=iOS Simulator,id=" + device,
                 "-derivedDataPath", str(JOB / "DerivedData"),
                 "CODE_SIGNING_ALLOWED=NO", "CODE_SIGNING_REQUIRED=NO"], timeout=900)
        candidates = list((JOB / "DerivedData/Build/Products").glob("*.xctestrun"))
        if len(candidates) != 1:
            raise RuntimeError("Expected one test manifest")
        # Local HTTP is enabled only in the disposable, unsigned simulator host product.
        # No production plist or repository file is weakened.
        app_info = JOB / "DerivedData/Build/Products/Debug-iphonesimulator/LeafHFT.app/Info.plist"
        info = plistlib.loads(app_info.read_bytes())
        info["NSAppTransportSecurity"] = {"NSAllowsLocalNetworking": True,
            "NSExceptionDomains": {"localhost": {"NSExceptionAllowsInsecureHTTPLoads": True}}}
        app_info.write_bytes(plistlib.dumps(info, fmt=plistlib.FMT_BINARY))
        (JOB / "ready.json").write_text(json.dumps({"simulator": device, "manifest": str(candidates[0])}))
        return 0
    except Exception:
        if device:
            subprocess.run(["xcrun", "simctl", "delete", device], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return 1


def run():
    # Preserve a prior terminal receipt or an active unknown outcome unchanged.
    try:
        (JOB / "live-started").mkdir()
    except FileExistsError:
        return 1
    start = time.monotonic()
    result = dict(result="FAIL", exit_code=1, accepted_routes=0, simulator=None, duration_seconds=None)
    server = None
    device = None
    token = None
    worker = None
    stop = threading.Event()
    try:
        ready = json.loads((JOB / "ready.json").read_text())
        device = ready["simulator"]
        result["simulator"] = device
        token = sys.stdin.buffer.read(16385)
        if not token or len(token) > 16384 or not token.isascii() or any(chr(c).isspace() for c in token):
            raise RuntimeError("Unsupported credential")
        accepted = set()
        attempted = set()

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"

            def log_message(self, *args):
                pass

            def reject(self):
                self.send_response(403)
                self.send_header("Content-Length", "0")
                self.end_headers()

            do_POST = do_PUT = do_PATCH = do_DELETE = do_HEAD = do_OPTIONS = do_CONNECT = do_TRACE = reject

            def do_GET(self):
                if self.path not in ROUTES or self.path in attempted or len(attempted) >= 2:
                    self.reject()
                    return
                attempted.add(self.path)
                connection = None
                try:
                    # HTTPSConnection makes one direct HTTPS request. It has no redirect or proxy behavior.
                    connection = http.client.HTTPSConnection(ORIGIN, timeout=25)
                    connection.request("GET", self.path, headers={"Authorization": "Bearer " + token.decode("ascii"),
                                                                  "Accept": "application/json"})
                    upstream = connection.getresponse()
                    body = upstream.read(4 * 1024 * 1024 + 1)
                    # Never forward a credential echoed by a defective upstream.
                    if upstream.status != 200 or len(body) > 4 * 1024 * 1024 or token in body:
                        self.reject()
                        return
                    json.loads(body)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(body)
                    accepted.add(self.path)
                except Exception:
                    try:
                        self.reject()
                    except Exception:
                        pass
                finally:
                    if connection:
                        connection.close()

        class QuietServer(HTTPServer):
            def handle_error(self, request, client_address):
                pass

        server = QuietServer(("127.0.0.1", 0), Handler)
        server.timeout = 1

        def serve():
            deadline = time.monotonic() + 300
            while len(attempted) < 2 and time.monotonic() < deadline and not stop.is_set():
                try:
                    server.handle_request()
                except Exception:
                    break
            server.server_close()

        worker = threading.Thread(target=serve, daemon=True)
        worker.start()
        manifest = Path(ready["manifest"])
        plan = plistlib.loads(manifest.read_bytes())
        targets = list(test_targets(plan))
        if not targets:
            raise RuntimeError("Missing test target")
        for target in targets:
            target.setdefault("EnvironmentVariables", {})["LEAFHFT_LIVE_SMOKE_PORT"] = str(server.server_port)
        manifest.write_bytes(plistlib.dumps(plan))
        outcome = command(["xcodebuild", "test-without-building", "-xctestrun", str(manifest),
                           "-destination", "platform=iOS Simulator,id=" + device,
                           "-only-testing:LeafHFTTests/LiveShapeSmokeTests/testLiveBooksAndEnginesShapes",
                           "-parallel-testing-enabled", "NO",
                           "-resultBundlePath", str(JOB / "live.xcresult"),
                           "CODE_SIGNING_ALLOWED=NO", "CODE_SIGNING_REQUIRED=NO"], timeout=300)
        if MARKER in outcome.stdout and accepted == ROUTES:
            result.update(result="PASS", exit_code=0)
    except Exception:
        # Exceptions can carry response/request information. Never serialize or print them.
        pass
    finally:
        stop.set()
        if worker:
            worker.join(timeout=30)
        if server:
            server.server_close()
        token = None
        result["accepted_routes"] = len(accepted) if "accepted" in locals() else 0
        if device:
            for operation in ("shutdown", "delete"):
                try:
                    subprocess.run(["xcrun", "simctl", operation, device], timeout=30,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                except Exception:
                    pass
        result["duration_seconds"] = round(time.monotonic() - start, 3)
        (JOB / "result.json").write_text(json.dumps(result))
    return result["exit_code"]


if __name__ == "__main__":
    try:
        mode = sys.argv[1]
        raise SystemExit(prepare(sys.argv[2] if len(sys.argv) > 2 else "26.2") if mode == "prepare" else run() if mode == "run" else 1)
    except Exception:
        raise SystemExit(1)
