import Foundation
import XCTest
@testable import LeafHFTCore

final class PositionMarksTests: XCTestCase {
    private let now = ISO8601DateFormatter().date(from: "2026-09-29T19:10:00Z")!

    private func market(_ fields: [String: String], ticker: String = "TEST") throws -> KalshiMarket {
        var fields = fields
        fields["ticker"] = ticker
        return try accountJSONDecoder().decode(KalshiMarket.self, from: JSONSerialization.data(withJSONObject: fields))
    }

    func testSharedValuationVectors() throws {
        let frozen = ["close_time": "2026-09-29T19:05:00Z", "status": "active", "result": "",
                      "last_price_dollars": "0.9700", "yes_bid_dollars": "0.0000", "yes_ask_dollars": "1.0000"]
        let vectors: [(String, Bool, [String: String]?, String, MarkBasis, String)] = [
            ("V1", true, ["status": "open", "close_time": "2026-09-29T19:15:00Z", "yes_bid_dollars": "0.5200", "yes_ask_dollars": "0.5600"], "54", .live, "540"),
            ("V2", false, ["status": "open", "close_time": "2026-09-29T19:15:00Z", "no_bid_dollars": "0.4400", "no_ask_dollars": "0.4800"], "46", .live, "460"),
            ("V3", true, ["status": "open", "yes_bid_dollars": "0.3000", "yes_ask_dollars": "0.0000"], "30", .live, "300"),
            ("V4", true, ["status": "open", "yes_bid_dollars": "0.0000", "yes_ask_dollars": "0.0000", "last_price_dollars": "0.6100"], "61", .live, "610"),
            ("V5", true, ["status": "open"], "45", .live, "450"),
            ("V6", true, frozen, "97", .frozen, "970"),
            ("V7", false, ["close_time": "2026-09-29T19:05:00Z", "status": "closed", "result": "", "last_price_dollars": "0.9700"], "3", .frozen, "30"),
            ("V8", true, ["status": "finalized", "result": "yes"], "100", .settled, "1000"),
            ("V9", true, ["status": "determined", "result": "no"], "0", .settled, "0"),
            ("V10", false, ["status": "finalized", "result": "no"], "100", .settled, "1000"),
            ("V11", true, nil, "45", .cost, "450"),
            ("V12", true, frozen, "97", .frozen, "970"),
            ("V13", true, ["status": "open", "yes_bid_dollars": "0.0010", "yes_ask_dollars": "0.0030"], "0.2", .live, "0.5")
        ]
        for (id, yes, fields, expected, basis, positionCents) in vectors {
            let quote = try fields.map { try market($0) }
            let count: Decimal = id == "V13" ? Decimal(string: "2.5")! : 10
            let at = id == "V12" ? ISO8601DateFormatter().date(from: "2026-09-30T00:00:00Z")! : now
            let mark = PositionMarks.perContractMark(sideYes: yes, costPerContractCents: 450 / count, market: quote, now: at)
            XCTAssertEqual(mark.cents, Decimal(string: expected), id)
            XCTAssertEqual(mark.basis, basis, id)
            XCTAssertEqual(mark.cents * count, Decimal(string: positionCents), id)
            let position = Position(ticker: "TEST", positionFp: id == "V13" ? "2.5" : (yes ? "10" : "-10"), marketExposureDollars: "4.50")
            let portfolio = PositionMarks.marked(cashCents: 10000, positions: [position],
                                                 markets: quote.map { ["TEST": $0] } ?? [:], now: at)
            let rounded = id == "V13" ? 1 : Int(positionCents)!
            XCTAssertEqual(portfolio.openCents, rounded, id)
            XCTAssertEqual(portfolio.totalCents, 10000 + rounded, id)
            XCTAssertEqual(portfolio.counts, [basis: 1], id)
            XCTAssertEqual(portfolio.unpriced, 0, id)
        }
    }

    func testPortfolioP1() throws {
        let positions = [Position(ticker: "V1", positionFp: "10", marketExposureDollars: "4.50"),
                         Position(ticker: "V7", positionFp: "-10", marketExposureDollars: "4.50"),
                         Position(ticker: "V11", positionFp: "10", marketExposureDollars: "4.50")]
        let quotes = ["V1": try market(["yes_bid_dollars": "0.5200", "yes_ask_dollars": "0.5600"], ticker: "V1"),
                      "V7": try market(["status": "closed", "last_price_dollars": "0.9700"], ticker: "V7")]
        let result = PositionMarks.marked(cashCents: 10000, positions: positions, markets: quotes, now: now)
        XCTAssertEqual(result.cashCents, 10000)
        XCTAssertEqual(result.openCents, 1020)
        XCTAssertEqual(result.totalCents, 11020)
        XCTAssertEqual(result.counts, [.live: 1, .frozen: 1, .cost: 1])
    }

    func testRoundsOnlyAfterSummingFractionalPositions() throws {
        let quote = try market(["yes_bid_dollars": "0.0010", "yes_ask_dollars": "0.0030"])
        let position = Position(ticker: "TEST", positionFp: "2.5", marketExposureDollars: "4.50")
        XCTAssertEqual(PositionMarks.marked(cashCents: 0, positions: [position, position],
                                           markets: ["TEST": quote], now: now).openCents, 1)
    }

    func testRealMarketPayload() throws {
        let json = #"{"markets":[{"ticker":"KXBTC15M-26SEP291515-15","status":"finalized","result":"no","close_time":"2026-09-29T19:15:00Z","yes_bid_dollars":"0.0000","yes_ask_dollars":"1.0000","no_bid_dollars":"0.0000","no_ask_dollars":"1.0000","last_price_dollars":"0.0010","settlement_value_dollars":"0.0000"}],"cursor":""}"#
        let response = try accountJSONDecoder().decode(PositionMarksMarketsResponse.self, from: Data(json.utf8))
        let quote = try XCTUnwrap(response.markets?.first)
        XCTAssertEqual(response.cursor, "")
        XCTAssertEqual(quote.ticker, "KXBTC15M-26SEP291515-15")
        XCTAssertEqual(quote.closeTime, "2026-09-29T19:15:00Z")
        XCTAssertEqual(quote.yesBidDollars, "0.0000")
        XCTAssertEqual(quote.yesAskDollars, "1.0000")
        XCTAssertEqual(quote.noBidDollars, "0.0000")
        XCTAssertEqual(quote.noAskDollars, "1.0000")
        XCTAssertEqual(quote.lastPriceDollars, "0.0010")
        XCTAssertEqual(quote.settlementValueDollars, "0.0000")
        let mark = PositionMarks.perContractMark(sideYes: false, costPerContractCents: 45, market: quote, now: now)
        XCTAssertEqual(mark.cents, 100)
        XCTAssertEqual(mark.basis, .settled)
    }

    func testGarbagePricesAndFrozenCostFallback() throws {
        for garbage in ["", "garbage", "NaN", "Infinity", "-0.01", "1.0001", "0.5junk", "1e999"] {
            for status in ["open", "closed"] {
                let quote = try market(["status": status, "result": "scalar", "settlement_value_dollars": garbage,
                                        "yes_bid_dollars": garbage, "yes_ask_dollars": garbage, "last_price_dollars": garbage])
                let mark = PositionMarks.perContractMark(sideYes: true, costPerContractCents: 45, market: quote, now: now)
                XCTAssertEqual(mark.cents, 45, garbage)
                XCTAssertEqual(mark.basis, status == "open" ? .live : .frozen, garbage)
            }
        }
    }

    func testScalarSettlementAndMissingExposure() throws {
        let scalar = try market(["result": "scalar", "settlement_value_dollars": "0.2500"])
        for yes in [true, false] {
            let mark = PositionMarks.perContractMark(sideYes: yes, costPerContractCents: 45, market: scalar, now: now)
            XCTAssertEqual(mark.cents, yes ? 25 : 75)
            XCTAssertEqual(mark.basis, .settled)
        }
        let missing = Position(ticker: "TEST", positionFp: "10")
        let zero = Position(ticker: "ZERO", positionFp: "0")
        for (fields, expected, basis) in [(["yes_bid_dollars": "0.5"], 500, MarkBasis.live),
                                         (["status": "closed", "last_price_dollars": "0.7"], 700, .frozen),
                                         (["result": "yes"], 1000, .settled),
                                         (["status": "closed"], 0, .frozen)] {
            let result = PositionMarks.marked(cashCents: 0, positions: [missing, zero],
                                              markets: ["TEST": try market(fields)], now: now)
            XCTAssertEqual(result.openCents, expected)
            XCTAssertEqual(result.counts, [basis: 1])
            XCTAssertEqual(result.unpriced, 1)
        }
        let result = PositionMarks.marked(cashCents: 123, positions: [missing, zero], markets: [:], now: now)
        XCTAssertEqual(result.totalCents, 123)
        XCTAssertEqual(result.unpriced, 1)
        XCTAssertEqual(result.counts, [.cost: 1])
    }
}
