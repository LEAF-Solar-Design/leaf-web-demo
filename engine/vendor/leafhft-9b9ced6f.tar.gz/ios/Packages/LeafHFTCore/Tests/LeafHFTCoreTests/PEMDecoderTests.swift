import Foundation
import XCTest
@testable import LeafHFTCore

final class PEMDecoderTests: XCTestCase {
    private func pem(_ label: String, _ bytes: [UInt8]) -> String {
        "-----BEGIN \(label)-----\n\(Data(bytes).base64EncodedString())\n-----END \(label)-----"
    }
    private func der(_ tag: UInt8, _ body: [UInt8]) -> [UInt8] {
        var length = body.count
        var bytes: [UInt8] = []
        repeat {
            bytes.insert(UInt8(length & 0xff), at: 0)
            length >>= 8
        } while length > 0
        return [tag] + (body.count < 128 ? bytes : [0x80 | UInt8(bytes.count)] + bytes) + body
    }
    private var toyKey: [UInt8] {
        let integers: [[UInt8]] = [[0], [0, 0xc7], [3], [0x2b], [0x0b], [0x11], [3], [0x0b], [2]]
        return der(0x30, integers.flatMap { der(0x02, $0) })
    }
    private func wrapped(_ key: [UInt8], oid: [UInt8]) -> [UInt8] {
        let algorithm = der(0x30, der(0x06, oid) + der(0x05, []))
        return der(0x30, der(0x02, [0]) + algorithm + der(0x04, key))
    }
    func testSyntheticFormatsMatch() throws {
        let bytes = toyKey
        let oid: [UInt8] = [0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 1, 1, 1]
        let pkcs1 = try decodeRSAPrivateKeyPEM(pem("RSA PRIVATE KEY", bytes))
        let pkcs8 = try decodeRSAPrivateKeyPEM(pem("PRIVATE KEY", wrapped(bytes, oid: oid)))
        XCTAssertEqual(pkcs1, Data(bytes))
        XCTAssertEqual(pkcs8, pkcs1)
    }
    func testLabelsAndBase64() {
        XCTAssertThrowsError(try decodeRSAPrivateKeyPEM("not a key")) { XCTAssertEqual($0 as? PEMDecodeError, .notPEM) }
        XCTAssertThrowsError(try decodeRSAPrivateKeyPEM(pem("ENCRYPTED PRIVATE KEY", [1]))) { XCTAssertEqual($0 as? PEMDecodeError, .encrypted) }
        XCTAssertThrowsError(try decodeRSAPrivateKeyPEM(pem("PUBLIC KEY", [1]))) { XCTAssertEqual($0 as? PEMDecodeError, .unsupportedLabel("PUBLIC KEY")) }
        var lines = pem("PRIVATE KEY", [1]).components(separatedBy: "\n")
        lines[1] = "!"
        XCTAssertThrowsError(try decodeRSAPrivateKeyPEM(lines.joined(separator: "\n"))) { XCTAssertEqual($0 as? PEMDecodeError, .badBase64) }
    }
    func testMalformedLengthsAndNonRSA() {
        let malformed: [[UInt8]] = [[0x30, 0x80], [0x30, 0x82, 0xff], [0x30, 0x03, 0x02], [0x30, 0x81, 0x01, 0], [0x30, 1, 0, 0]]
        for bytes in malformed {
            XCTAssertThrowsError(try decodeRSAPrivateKeyPEM(pem("RSA PRIVATE KEY", bytes))) {
                guard let error = $0 as? PEMDecodeError, case .malformedDER = error else {
                    return XCTFail("Expected malformed DER, got \($0)")
                }
            }
        }
        // Valid outer DER with a non-RSA algorithm identifier.
        let ecOID: [UInt8] = [0x2a, 0x86, 0x48, 0xce, 0x3d, 0x02, 0x01]
        let wrongOID = wrapped(toyKey, oid: ecOID)
        XCTAssertThrowsError(try decodeRSAPrivateKeyPEM(pem("PRIVATE KEY", wrongOID))) { XCTAssertEqual($0 as? PEMDecodeError, .notRSA) }
    }
}
