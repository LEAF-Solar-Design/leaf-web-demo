import Foundation
import XCTest
@testable import LeafHFTCore

final class ChartReductionTests: XCTestCase {
    private func samples(_ count: Int) -> [ChartReduction.Sample] {
        (0..<count).map {
            ChartReduction.Sample(date: Date(timeIntervalSince1970: Double($0)),
                                  value: Double(($0 * 37) % 101))
        }
    }

    func testUnderBudgetAndSmallBudgetsAreUnchanged() {
        let run = samples(20)
        XCTAssertEqual(ChartReduction.reduce(run, maxPoints: 20), run)
        XCTAssertEqual(ChartReduction.reduce(run, maxPoints: 30), run)
        for budget in [-1, 0, 1, 2, 3] {
            XCTAssertEqual(ChartReduction.reduce(run, maxPoints: budget), run)
        }
        XCTAssertEqual(ChartReduction.reduce([], maxPoints: 600), [])
    }

    func testLargeRunPreservesExtremaEndpointsAndOrderedSubsequence() {
        let run = samples(10_000)
        for budget in [4, 5, 599, 600] {
            let reduced = ChartReduction.reduce(run, maxPoints: budget)
            XCTAssertLessThanOrEqual(reduced.count, budget + 2)
            XCTAssertEqual(reduced.first, run.first)
            XCTAssertEqual(reduced.last, run.last)
            XCTAssertEqual(reduced.map(\.value).min(), run.map(\.value).min())
            XCTAssertEqual(reduced.map(\.value).max(), run.map(\.value).max())
            XCTAssertEqual(Set(reduced.map(\.date)).count, reduced.count)
            var next = 0
            for sample in reduced {
                while next < run.count && run[next] != sample { next += 1 }
                XCTAssertLessThan(next, run.count)
                next += 1
            }
            XCTAssertTrue(zip(reduced, reduced.dropFirst()).allSatisfy { $0.date < $1.date })
        }
    }

    func testSingleSpikeSurvivesAndConstantRunKeepsEndpoints() {
        let constant = (0..<10_000).map {
            ChartReduction.Sample(date: Date(timeIntervalSince1970: Double($0)), value: 10)
        }
        let reduced = ChartReduction.reduce(constant, maxPoints: 600)
        XCTAssertEqual(reduced.first, constant.first)
        XCTAssertEqual(reduced.last, constant.last)
        XCTAssertLessThanOrEqual(reduced.count, 602)
        var spike = constant
        spike[4321] = ChartReduction.Sample(date: spike[4321].date, value: 1_000_000)
        XCTAssertTrue(ChartReduction.reduce(spike, maxPoints: 600).contains(spike[4321]))
        spike[6789] = ChartReduction.Sample(date: spike[6789].date, value: -1_000_000)
        XCTAssertTrue(ChartReduction.reduce(spike, maxPoints: 600).contains(spike[6789]))
    }

    func testBucketsFollowTimeRatherThanObservationCount() {
        let run = [0.0, 1, 2, 3, 4, 99, 100].map {
            ChartReduction.Sample(date: Date(timeIntervalSince1970: $0), value: $0)
        }
        XCTAssertEqual(ChartReduction.reduce(run, maxPoints: 4), [run[0], run[4], run[5], run[6]])
    }

    func testBudgetsPreserveCountsOrAllocateProportionallyWithFloor() {
        XCTAssertEqual(ChartReduction.budgets(runCounts: [10, 20, 30], total: 60), [10, 20, 30])
        XCTAssertEqual(ChartReduction.budgets(runCounts: [1, 2], total: 600), [1, 2])
        XCTAssertEqual(ChartReduction.budgets(runCounts: [], total: 600), [])
        XCTAssertEqual(ChartReduction.budgets(runCounts: [1000, 2000, 3000], total: 600), [100, 200, 300])
        XCTAssertEqual(ChartReduction.budgets(runCounts: [1, 999], total: 600), [4, 599])
        XCTAssertEqual(ChartReduction.budgets(runCounts: [1, 999], total: 600, minimumPerRun: 8), [8, 599])
    }
}
