import Foundation
import XCTest
@testable import LeafHFTCore

final class ExitLedgerTests: XCTestCase {
    private func ledger() throws -> ExitLedger {
        try accountJSONDecoder().decode(ExitLedger.self, from: fixtureData("exits"))
    }

    func testFrozenContractAndOptionalAnnotations() throws {
        let value = try ledger()
        XCTAssertEqual(value.schemaVersion, 1)
        XCTAssertEqual(value.window.days, 30)
        XCTAssertEqual(value.rows.count, 5)
        XCTAssertEqual(value.calibration.count, 3)
        XCTAssertEqual(value.engines.count, 3)
        XCTAssertEqual(value.rows[3].heldSide, "no")
        XCTAssertEqual(value.rows[3].count, Decimal(string: "0.25"))
        XCTAssertEqual(value.rows[3].exitPriceCents, Decimal(string: "20.5"))
        XCTAssertNil(value.rows[4].engineId)
        XCTAssertNil(value.rows[4].entryPriceCents)
        XCTAssertNil(value.rows[4].modelBidCents)
        XCTAssertNil(value.rows[4].modelWinProb)
        XCTAssertNil(value.rows[4].decidedAt)
        XCTAssertNil(value.rows[4].decisionToFillMs)
        XCTAssertNil(value.rows[4].realizedPnlCents)
        XCTAssertNil(value.rows[2].holdValueCents)
        XCTAssertNil(value.rows[2].netVsHoldCents)
        XCTAssertNil(value.summary.cashRefusals)
        XCTAssertEqual(value.summary.decisionToFillMsP95, 230)
    }

    func testSummaryStringsPositiveNegativeZeroAndUnresolved() throws {
        var summary = try ledger().summary
        XCTAssertEqual(summary.priceLine, "3 fills below their limit")
        summary.worseThanLimitCount = 0
        XCTAssertEqual(summary.headline, "Cashouts beat holding by +$1,154.85")
        XCTAssertEqual(summary.tally, "193 saved · 125 gave back · 8 pending")
        XCTAssertEqual(summary.priceLine, "Every fill at or above its limit (+$292.78)")
        XCTAssertEqual(summary.timingLine, "Filled in 103 ms (median) · 47 s before close")
        summary.netVsHoldCents = -1230
        XCTAssertEqual(summary.headline, "Cashouts cost -$12.30 versus holding")
        summary.netVsHoldCents = 0
        XCTAssertEqual(summary.headline, "Cashouts beat holding by +$0.00")
        summary.resolved = 0
        XCTAssertEqual(summary.headline, "No resolved cashouts yet")
        summary.worseThanLimitCount = 3
        XCTAssertEqual(summary.priceLine, "3 fills below their limit")
        summary.priceImprovementCents = -50
        summary.worseThanLimitCount = 0
        XCTAssertEqual(summary.priceLine, "Every fill at or above its limit (-$0.50)")
        summary.priceImprovementCents = 0
        XCTAssertEqual(summary.priceLine, "Every fill at or above its limit (+$0.00)")
        summary.decisionToFillMsP50 = nil
        XCTAssertEqual(summary.timingLine, "47 s before close")
        summary.secondsBeforeCloseP50 = nil
        XCTAssertEqual(summary.timingLine, "Timing not reported")
        summary.decisionToFillMsP50 = 0
        XCTAssertEqual(summary.timingLine, "Filled in 0 ms (median)")
        summary.savedCount = 0
        summary.gaveBackCount = 0
        summary.pending = 0
        XCTAssertEqual(summary.tally, "0 saved · 0 gave back · 0 pending")
        XCTAssertEqual(ExitLedger.money(Int.min).prefix(2), "-$")
    }

    func testVerdictStrings() throws {
        let rows = try ledger().rows
        XCTAssertEqual(rows[0].verdictLabel, "Saved +$1.13 vs hold")
        XCTAssertEqual(rows[1].verdictLabel, "Gave back -$7.52 vs hold")
        XCTAssertEqual(rows[2].verdictLabel, "Waiting for settlement")
        var row = rows[0]
        row.verdict = .even
        row.netVsHoldCents = 0
        XCTAssertEqual(row.verdictLabel, "Even with hold")
        row.verdict = .saved
        row.netVsHoldCents = nil
        XCTAssertEqual(row.verdictLabel, "Comparison not reported")
        row.verdict = .gaveBack
        XCTAssertEqual(row.verdictLabel, "Comparison not reported")
        row.verdict = .unknown
        XCTAssertEqual(row.verdictLabel, "Comparison not reported")
    }

    func testUnknownEnumStringsAndExtraKeysNeverThrow() throws {
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData("exits")) as? [String: Any])
        var rows = try XCTUnwrap(object["rows"] as? [[String: Any]])
        rows[0]["verdict"] = "future_verdict"
        rows[0]["price_check"] = "future_price"
        rows[0]["new_annotation"] = true
        object["rows"] = rows
        var lessons = try XCTUnwrap(object["lessons"] as? [[String: Any]])
        lessons[0]["severity"] = "future_severity"
        object["lessons"] = lessons
        object["extra"] = 42
        var summary = try XCTUnwrap(object["summary"] as? [String: Any])
        for key in ["cash_refusals", "decision_to_fill_ms_p50", "decision_to_fill_ms_p95", "seconds_before_close_p50"] {
            summary[key] = NSNull()
        }
        object["summary"] = summary
        let value = try accountJSONDecoder().decode(ExitLedger.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(value.rows[0].verdict, .unknown)
        XCTAssertEqual(value.rows[0].priceCheck, .unknown)
        XCTAssertEqual(value.lessons[0].severity, .unknown)
        XCTAssertNil(value.summary.cashRefusals)
        XCTAssertEqual(value.summary.timingLine, "Timing not reported")
    }

    func testTopLessonPrioritizesActThenWatchThenFirst() throws {
        var value = try ledger()
        XCTAssertEqual(value.topLesson?.severity, .act)
        let act = try XCTUnwrap(value.topLesson)
        value.lessons.insert(act, at: 0)
        XCTAssertEqual(value.topLesson, value.lessons.first)
        value.lessons.removeAll { $0.severity == .act }
        XCTAssertEqual(value.topLesson?.severity, .watch)
        value.lessons.removeAll { $0.severity == .watch }
        XCTAssertEqual(value.topLesson, value.lessons.first)
        value.lessons[0].severity = .unknown
        XCTAssertEqual(value.topLesson?.severity, .unknown)
        value.lessons = []
        XCTAssertNil(value.topLesson)
    }
}
