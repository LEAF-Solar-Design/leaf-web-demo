import Foundation
import XCTest
@testable import LeafHFTCore

final class MonitorPresentationTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 2_000_000_000)

    func testListNeverReadIsNotReportedRegardlessOfItems() {
        for items in [[], ["cached"]] {
            XCTAssertEqual(MonitorPresentation.list(items, observedAt: nil, error: nil, missing: "Never read"),
                .notReported(reason: "Never read"))
            XCTAssertEqual(MonitorPresentation.list(items, observedAt: nil, error: "Read failed", missing: "Never read"),
                .notReported(reason: "Read failed"))
        }
    }

    func testListSuccessfulEmptyAndValueReads() {
        XCTAssertEqual(MonitorPresentation.list([String](), observedAt: now, error: nil, missing: "Never read"),
            .empty(observedAt: now))
        XCTAssertEqual(MonitorPresentation.list(["position"], observedAt: now, error: nil, missing: "Never read"),
            .value(["position"], observedAt: now))
    }

    func testListErrorRetainsLastItemsAndObservationTime() {
        let previous = now.addingTimeInterval(-60)
        for items in [[], ["position"]] {
            XCTAssertEqual(MonitorPresentation.list(items, observedAt: previous, error: "Read failed", missing: "Never read"),
                .value(items, observedAt: previous))
        }
    }

    func testFeedAgeBoundariesAndAbsence() throws {
        let samples: [(Double, MonitorPresentation.FeedAge.State)] = [
            (89.9, .fresh), (90, .aging), (599.9, .aging), (600, .dead)
        ]
        for (age, expected) in samples {
            let feed = MonitorPresentation.feedAge(name: "runner", observedAt: now.addingTimeInterval(-age), now: now)
            XCTAssertEqual(feed.name, "runner")
            XCTAssertEqual(feed.state, expected)
            XCTAssertEqual(try XCTUnwrap(feed.ageSeconds), age, accuracy: 0.000001)
        }
        let absent = MonitorPresentation.feedAge(name: "runner", observedAt: nil, now: now)
        XCTAssertEqual(absent.state, .absent)
        XCTAssertNil(absent.ageSeconds)
    }

    func testFeedAgeCustomThresholdsAndFutureTimestamp() {
        XCTAssertEqual(MonitorPresentation.feedAge(name: "feed", observedAt: now.addingTimeInterval(-10),
            now: now, freshUnder: 10, deadPast: 20).state, .aging)
        XCTAssertEqual(MonitorPresentation.feedAge(name: "feed", observedAt: now.addingTimeInterval(-20),
            now: now, freshUnder: 10, deadPast: 20).state, .dead)
        let future = MonitorPresentation.feedAge(name: "feed", observedAt: now.addingTimeInterval(1), now: now)
        XCTAssertEqual(future.ageSeconds, 0)
        XCTAssertEqual(future.state, .fresh)
    }

    func testNextCloseRemainsNotReportedWithoutBookTelemetry() throws {
        let book = try accountJSONDecoder().decode(Book.self,
            from: Data(#"{"book_id":"unknown","kalshi_book":{}}"#.utf8))
        for books in [[], [book]] {
            XCTAssertEqual(MonitorPresentation.nextClose(books: books), .notReported)
            XCTAssertEqual(MonitorPresentation.nextCloseText(MonitorPresentation.nextClose(books: books)),
                MonitorPresentation.notReported)
        }
    }

    func testPortfolioCaptionUsesCashAndOpenMarkOnce() throws {
        let balance = try accountJSONDecoder().decode(AccountBalance.self,
            from: Data(#"{"balance":2388,"portfolio_value":142}"#.utf8))
        XCTAssertEqual(MonitorPresentation.portfolioCaption(balance: balance),
            "cash at venue $23.88 + open $1.42 at venue value")
    }

    func testPortfolioCaptionMissingAndPartialBalance() throws {
        XCTAssertEqual(MonitorPresentation.portfolioCaption(balance: nil),
            "cash at venue Not reported + open Not reported at venue value")
        let samples = [
            (#"{}"#, "cash at venue Not reported + open Not reported at venue value"),
            (#"{"balance":2388}"#, "cash at venue $23.88 + open Not reported at venue value"),
            (#"{"portfolio_value":142}"#, "cash at venue Not reported + open $1.42 at venue value"),
            (#"{"balance":0,"portfolio_value":0}"#, "cash at venue $0.00 + open $0.00 at venue value")
        ]
        for (json, expected) in samples {
            let balance = try accountJSONDecoder().decode(AccountBalance.self, from: Data(json.utf8))
            XCTAssertEqual(MonitorPresentation.portfolioCaption(balance: balance), expected)
        }
    }
}
