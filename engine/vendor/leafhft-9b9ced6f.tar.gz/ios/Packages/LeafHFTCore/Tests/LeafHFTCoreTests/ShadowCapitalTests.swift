import Foundation
import XCTest
@testable import LeafHFTCore

final class ShadowCapitalTests: XCTestCase {
    private func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }

    private func view(_ json: String) throws -> ShadowCapitalView {
        try decoder().decode(ShadowCapitalView.self, from: Data(json.utf8))
    }

    func testRequestWireIsIdenticalUnderBothEncoderStrategies() throws {
        let id = try XCTUnwrap(UUID(uuidString: "abcdefab-1234-4234-9234-123456789abc"))
        let request = try ShadowCapitalRequest(capitalCents: 40000, clientRequestId: id)
        let literal = #"{"client_request_id":"abcdefab-1234-4234-9234-123456789abc","kind":"account.shadow_capital","value":{"capital_cents":40000,"consent":"paper"}}"#
        for strategy in [JSONEncoder.KeyEncodingStrategy.useDefaultKeys, .convertToSnakeCase] {
            let encoder = JSONEncoder()
            encoder.keyEncodingStrategy = strategy
            encoder.outputFormatting = [.sortedKeys]
            let data = try encoder.encode(request)
            XCTAssertEqual(data, Data(literal.utf8))
            let object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
            XCTAssertEqual(Set(object.keys), ["kind", "client_request_id", "value"])
            let value = try XCTUnwrap(object["value"] as? [String: Any])
            XCTAssertEqual(Set(value.keys), ["capital_cents", "consent"])
        }
    }

    func testWholeDollarsAndFallbackBounds() throws {
        for cents in [9900, 200100, 40050, Int.min, Int.max] {
            XCTAssertThrowsError(try ShadowCapitalRequest(capitalCents: cents))
        }
        for dollars in [99, 2001, 400.5, Double.nan, .infinity, -.infinity, Double.greatestFiniteMagnitude] {
            XCTAssertThrowsError(try ShadowCapitalRequest(dollars: dollars))
        }
        for dollars in ShadowCapital.presetDollars {
            XCTAssertEqual(try ShadowCapitalRequest(dollars: Double(dollars)).value.capitalCents, dollars * 100)
        }
    }

    func testPublishedBoundsAndStepAreUsedAndInvalidBoundsFailClosed() throws {
        let bounds = try view(#"{"min_cents":20000,"max_cents":80000,"step_cents":200}"#)
        XCTAssertThrowsError(try ShadowCapitalRequest(capitalCents: 10000, status: bounds))
        XCTAssertThrowsError(try ShadowCapitalRequest(capitalCents: 80200, status: bounds))
        XCTAssertThrowsError(try ShadowCapitalRequest(capitalCents: 40100, status: bounds))
        XCTAssertEqual(try ShadowCapitalRequest(capitalCents: 40200, status: bounds).value.capitalCents, 40200)
        for json in [#"{"step_cents":0}"#, #"{"step_cents":-100}"#,
                     #"{"min_cents":80000,"max_cents":20000}"#, #"{"min_cents":-100}"#] {
            XCTAssertThrowsError(try ShadowCapitalRequest(capitalCents: 40000, status: view(json)))
        }
    }

    func testStatusDecodesWithAndWithoutShadowCapital() throws {
        let prefix = #"{"dashboard_pairing":"paired","account_binding":"unbound","automated_trading":"not_configured""#
        for suffix in ["}", #", "shadow_capital":null}"#] {
            XCTAssertNil(try decoder().decode(KashbotStatus.self, from: Data((prefix + suffix).utf8)).shadowCapital)
        }
        let suffix = #", "shadow_capital":{"applied_cents":40000,"source":"default","observed_at":"2026-10-04T12:00:00Z","consumer":{"state":"confirmed","in_use_cents":40000},"pending":null,"last_failure":null,"cooldown_until":null,"suspended":false,"runner_error":null,"writes_open":true,"min_cents":10000,"max_cents":200000,"step_cents":100,"default_cents":40000,"editable":true,"runs":[{"engine_id":"risky-batman-15m","mirror":false,"state":"running","started_at":"2026-10-04T11:00:00Z","paper_pnl_cents":1234,"capital_basis_cents":40000,"return_bps":308.5}]}}"#
        let status = try decoder().decode(KashbotStatus.self, from: Data((prefix + suffix).utf8))
        let capital = try XCTUnwrap(status.shadowCapital)
        XCTAssertEqual(capital.appliedCents, 40000)
        XCTAssertEqual(capital.consumer?.inUseCents, 40000)
        XCTAssertEqual(capital.runs?.first?.returnBps, 308.5)
        XCTAssertEqual(try XCTUnwrap(capital.runs?.first?.returnPercent), 3.085, accuracy: 0.000001)
    }

    func testStatusIgnoresMalformedShadowCapital() throws {
        let prefix = #"{"dashboard_pairing":"paired","account_binding":"unbound","automated_trading":"not_configured","shadow_capital":"#
        for capital in [#"{"applied_cents":"invalid"}"#, #""invalid""#, "42", "[]"] {
            let status = try decoder().decode(KashbotStatus.self, from: Data((prefix + capital + "}").utf8))
            XCTAssertNil(status.shadowCapital)
            XCTAssertEqual(status.dashboardPairing, .paired)
            XCTAssertEqual(status.accountBinding, .unbound)
            XCTAssertEqual(status.automatedTrading, .notConfigured)
        }
        let invalidStatus = #"{"dashboard_pairing":42,"account_binding":"unbound","automated_trading":"not_configured","shadow_capital":null}"#
        XCTAssertThrowsError(try decoder().decode(KashbotStatus.self, from: Data(invalidStatus.utf8)))
    }

    func testStatusAcceptsStringAndIntegerShadowCapitalRequestIDs() throws {
        let prefix = #"{"dashboard_pairing":"paired","account_binding":"unbound","automated_trading":"not_configured","shadow_capital":{"applied_cents":40000,"request_id":"#
        for identifier in ["12345", #""12345""#] {
            let json = prefix + identifier + #", "pending":{"request_id":"# + identifier + #", "capital_cents":80000,"requested_at":"2026-10-04T12:00:00Z"}}}"#
            let status = try decoder().decode(KashbotStatus.self, from: Data(json.utf8))
            let capital = try XCTUnwrap(status.shadowCapital)
            XCTAssertEqual(capital.requestId, "12345")
            XCTAssertEqual(capital.pending?.requestId, "12345")
            XCTAssertEqual(capital.pending?.capitalCents, 80000)
        }
    }

    func testSharedStateFixturesCoverEveryStateAndEditCapability() throws {
        struct Fixture: Decodable {
            let name: String
            let now: Date
            let view: ShadowCapitalView?
            let expected: ShadowCapitalState
            let editable: Bool
        }
        let url = try XCTUnwrap(Bundle.module.url(forResource: "shadow-capital-states", withExtension: "json", subdirectory: "Fixtures"))
        let fixtures = try decoder().decode([Fixture].self, from: Data(contentsOf: url))
        XCTAssertFalse(fixtures.isEmpty)
        XCTAssertEqual(Set(fixtures.map(\.expected)), Set(ShadowCapitalState.allCases))
        for fixture in fixtures {
            XCTAssertEqual(deriveShadowCapitalState(fixture.view, now: fixture.now), fixture.expected, fixture.name)
            XCTAssertEqual(fixture.view?.canEdit(now: fixture.now) ?? false, fixture.editable, fixture.name)
        }
    }

    func testRunReturnPercentIsUnavailableForZeroNegativeCapitalAndMirrors() throws {
        for (capital, mirror) in [(0, false), (-100, false), (40000, true)] {
            let input = "{\"engine_id\":\"risky-batman-15m\",\"mirror\":\(mirror),\"state\":\"running\",\"paper_pnl_cents\":1234,\"capital_basis_cents\":\(capital),\"return_bps\":null}"
            let run = try decoder().decode(ShadowCapitalView.Run.self, from: Data(input.utf8))
            XCTAssertNil(run.returnPercent)
        }
    }
}
