import Foundation
import XCTest
@testable import LeafHFTCore

final class AccountChartDomainTests: XCTestCase {
    private func date(_ seconds: Double) -> Date { Date(timeIntervalSince1970: seconds) }

    func testVaryingVisiblePointsHavePaddedDomains() {
        let domain = AccountChartDomain(dates: [date(200), date(100), date(150)], dollars: [80, 20, 50])
        XCTAssertEqual(domain.x, date(95)...date(205))
        XCTAssertEqual(domain.y, 17...83)
        XCTAssertFalse(domain.y.contains(10), "The entry floor must not expand the scale")

        let narrower = AccountChartDomain(dates: [date(150), date(200)], dollars: [50, 80])
        XCTAssertEqual(narrower.x, date(147.5)...date(202.5))
        XCTAssertEqual(narrower.y, 48.5...81.5)
    }

    func testFlatDollarSeriesHasNonzeroPadding() {
        let domain = AccountChartDomain(dates: [date(100), date(200)], dollars: [100, 100])
        XCTAssertEqual(domain.y, 95...105)
        let zero = AccountChartDomain(dates: [date(100), date(200)], dollars: [0, 0])
        XCTAssertEqual(zero.y, -1...1)
    }

    func testSingletonHasNonzeroDomains() {
        let domain = AccountChartDomain(dates: [date(100)], dollars: [25])
        XCTAssertEqual(domain.x, date(40)...date(160))
        XCTAssertEqual(domain.y, 23.75...26.25)
    }

    func testEmptyDomainsAreDeterministic() {
        let domain = AccountChartDomain(dates: [], dollars: [])
        XCTAssertEqual(domain.x, date(0)...date(120))
        XCTAssertEqual(domain.y, 0...1)
        XCTAssertEqual(domain, AccountChartDomain(dates: [], dollars: []))
    }
}
