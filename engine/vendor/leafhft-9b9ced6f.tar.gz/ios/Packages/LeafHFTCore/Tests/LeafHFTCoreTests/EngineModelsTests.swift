import Foundation
import XCTest
@testable import LeafHFTCore

final class EngineModelsTests: XCTestCase {
    func testServerOnlyKeysAreThePolicyKeysWithoutBounds() throws {
        var engine = try accountJSONDecoder().decode(Engine.self,
            from: Data(#"{"engine_id":"default","policy":{"min_k":12,"server_z":7,"server_a":3}}"#.utf8))
        XCTAssertEqual(engineServerOnlyKeys(for: engine), ["server_a", "server_z"])
        engine.configuration = EngineConfiguration(global: EngineGlobalConfiguration(enabled: true,
            policy: ["min_k": 12, "server_global": 4], revision: nil, observedAt: nil,
            freshness: nil, pending: nil), accounts: [])
        XCTAssertEqual(engineServerOnlyKeys(for: engine), ["server_global"])
        engine.engineId = "darkhorse"
        XCTAssertEqual(engineServerOnlyKeys(for: engine), [])
    }

    func testTopLevelRiskEnvelopeDecodesBackendFields() throws {
        let json = #"{"engines":[],"risk_envelope":{"per_order_fraction":0.1,"cluster_fraction":0.25,"daily_loss_fraction":0.15,"drawdown_brake_fraction":0.15,"drawdown_stop_fraction":0.25,"digest":"canonical"}}"#
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: Data(json.utf8))
        XCTAssertEqual(response.riskEnvelope?.maxima, RiskEnvelope.hardMaxima)
        XCTAssertEqual(response.riskEnvelope?.digest, "canonical")
    }

    func testRiskEnvelopeDecodeFallsBackPerKey() throws {
        for json in [
            #"{"engine_id":"default"}"#,
            #"{"engine_id":"default","risk_envelope":null}"#,
            #"{"engine_id":"default","risk_envelope":"invalid"}"#
        ] {
            let engine = try accountJSONDecoder().decode(Engine.self, from: Data(json.utf8))
            XCTAssertEqual((engine.riskEnvelope ?? RiskEnvelope()).maxima, RiskEnvelope.hardMaxima)
        }
        let mixed = try accountJSONDecoder().decode(Engine.self, from: Data(#"{"engine_id":"default","risk_envelope":{"per_order_fraction":"bad","cluster_fraction":-1,"daily_loss_fraction":1}}"#.utf8))
        var expected = RiskEnvelope.hardMaxima
        expected["daily_loss_fraction"] = 1
        XCTAssertEqual(mixed.riskEnvelope?.maxima, expected)
        let engine = try accountJSONDecoder().decode(Engine.self, from: Data(#"{"engine_id":"default","risk_envelope":{"per_order_fraction":0.05,"cluster_fraction":0.2,"daily_loss_fraction":0.1,"drawdown_brake_fraction":0.08,"drawdown_stop_fraction":0.12,"digest":"v2"}}"#.utf8))
        XCTAssertEqual(engine.riskEnvelope?.maxima, ["per_order_fraction": 0.05, "cluster_fraction": 0.2,
            "daily_loss_fraction": 0.1, "drawdown_brake_fraction": 0.08, "drawdown_stop_fraction": 0.12])
        XCTAssertEqual(engine.riskEnvelope?.digest, "v2")
        let envelope = RiskEnvelope(maxima: ["per_order_fraction": .nan, "cluster_fraction": .infinity,
            "daily_loss_fraction": -0.1, "drawdown_brake_fraction": 1])
        expected = RiskEnvelope.hardMaxima
        expected["drawdown_brake_fraction"] = 1
        XCTAssertEqual(envelope.maxima, expected)
        XCTAssertEqual(RiskEnvelope().maxima, RiskEnvelope.hardMaxima)
    }

    func testOwnerEnvelopeDecodeHonoursPublishedMaxima() throws {
        let engine = try accountJSONDecoder().decode(Engine.self, from: Data(#"{"engine_id":"default","risk_envelope":{"per_order_fraction":1,"cluster_fraction":1,"daily_loss_fraction":1,"drawdown_brake_fraction":1,"drawdown_stop_fraction":1}}"#.utf8))
        let owner = try XCTUnwrap(engine.riskEnvelope)
        XCTAssertEqual(owner.maxima, RiskEnvelope.hardMaxima.mapValues { _ in 1.0 })
        XCTAssertNil(PolicyBounds.validateFriendly(key: "per_order_fraction", value: 0.125, envelope: owner))
        XCTAssertNotNil(PolicyBounds.validateFriendly(key: "per_order_fraction", value: 0.125))
    }

    func testOwnerEnvelopeAllowsDirectRequests() throws {
        let owner = RiskEnvelope(maxima: RiskEnvelope.hardMaxima.mapValues { _ in 1.0 })
        XCTAssertNoThrow(try ControlIntent.set(engineId: "default", key: "per_order_fraction",
            value: 0.125, envelope: owner))
        for scope in [ControlScope.global, try .account("sample-main")] {
            XCTAssertNoThrow(try ControlIntent.configure(engineId: "default", host: "sample-runner",
                scope: scope, set: ["per_order_fraction": 0.125], expectedRevision: "r1",
                clientRequestId: UUID().uuidString, envelope: owner))
            XCTAssertThrowsError(try ControlIntent.configure(engineId: "default", host: "sample-runner",
                scope: scope, set: ["per_order_fraction": 0.125], expectedRevision: "r1",
                clientRequestId: UUID().uuidString))
            XCTAssertThrowsError(try ControlIntent.configure(engineId: "default", host: "sample-runner",
                scope: scope, set: ["per_order_fraction": 0.125], expectedRevision: "r1",
                clientRequestId: UUID().uuidString, envelope: RiskEnvelope()))
        }
    }

    func testHardRiskLimitsRejectDirectRequests() throws {
        for (key, maximum) in RiskEnvelope.hardMaxima {
            XCTAssertNoThrow(try ControlIntent.set(engineId: "default", key: key, value: maximum))
            XCTAssertThrowsError(try ControlIntent.set(engineId: "default", key: key, value: maximum + 0.01))
            for scope in [ControlScope.global, try .account("sample-main")] {
                XCTAssertThrowsError(try ControlIntent.configure(engineId: "default", host: "sample-runner",
                    scope: scope, set: [key: maximum + 0.01], expectedRevision: "r1", clientRequestId: UUID().uuidString))
            }
        }
    }

    func testFrozenEnginesFixture() throws {
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: fixtureData("engines"))
        XCTAssertEqual(response.engines?.count, 2)
        XCTAssertEqual(response.bindings?.default, "default")
        XCTAssertEqual(response.bindings?.symbols?["BTC-15M"], "aggressive")
        let engine = try XCTUnwrap(response.engines?.first)
        XCTAssertEqual(engine.engineId, "default")
        XCTAssertEqual(engine.version, 1)
        XCTAssertEqual(engine.parentEngineId, "baseline")
        XCTAssertEqual(engine.policyDigest, "0123456789abcdef")
        XCTAssertEqual(engine.capabilities?.bandsOpen, ["30-50", "50-70"])
        XCTAssertEqual(engine.capabilities?.drawdownLaw?.brake, 0.12)
        XCTAssertEqual(engine.pnl?.netCents, 250)
        XCTAssertEqual(engine.pnl?.exitsN, 3)
        XCTAssertEqual(engine.pnl?.exitPnlCents, 45.5)
        XCTAssertEqual(engine.pnl?.lastTicketAt, "2026-09-13T00:00:00Z")
        XCTAssertEqual(engine.policy?["edge_threshold_cents"], 3.5)
        XCTAssertEqual(response.accounts?.count, 2)
        XCTAssertEqual(response.accounts?.first?.host, "sample-runner")
        XCTAssertEqual(engine.host, "sample-runner")
        XCTAssertEqual(engine.configuration?.global.enabled, true)
        XCTAssertEqual(engine.configuration?.accounts.first?.override.enabled, nil)
        XCTAssertEqual(engine.configuration?.accounts.first?.effective.enabled, true)
        XCTAssertEqual(engine.configuration?.accounts.last?.override.enabled, false)
        XCTAssertEqual(engine.configuration?.accounts.last?.effective.policy?["edge_threshold_cents"], 5)
        XCTAssertEqual(Set(engine.policy?.keys.map { $0 } ?? []), Set(PolicyBounds.bounds.keys))
        let withoutPolicy = try XCTUnwrap(response.engines?.last)
        XCTAssertNil(withoutPolicy.policy)
        XCTAssertEqual(engineSetKeys(for: withoutPolicy), PolicyBounds.bounds.keys.sorted())
        let minimal = try accountJSONDecoder().decode(Engine.self, from: Data(#"{"engine_id":"default","unknown":42}"#.utf8))
        XCTAssertNil(minimal.policy)
        XCTAssertNil(minimal.pnl)
        XCTAssertNil(minimal.parentEngineId)
        XCTAssertNil(minimal.policyDigest)
        XCTAssertThrowsError(try accountJSONDecoder().decode(Engine.self, from: Data("{}".utf8)))
    }

    func testSetKeysUsesPresentPolicyIncludingEmptyPolicy() throws {
        var engine = try accountJSONDecoder().decode(Engine.self,
            from: Data(#"{"engine_id":"default","policy":{"min_k":12,"edge_threshold_cents":3.5,"future_server_only":7}}"#.utf8))
        XCTAssertEqual(engineSetKeys(for: engine), ["edge_threshold_cents", "min_k"])
        engine.policy = [:]
        XCTAssertEqual(engineSetKeys(for: engine), [])
        engine.policy = nil
        XCTAssertEqual(engineSetKeys(for: engine), PolicyBounds.bounds.keys.sorted())
    }

    func testExactIntentValues() throws {
        XCTAssertEqual(try ControlIntent.bind(symbol: "BTC-15M", engineId: "aggressive").value, .legacy("BTC-15M=aggressive"))
        XCTAssertEqual(try ControlIntent.bind(symbol: nil, engineId: "default").value, .legacy("all=default"))
        XCTAssertEqual(try ControlIntent.set(engineId: "default", key: "edge_threshold_cents", value: 3.5).value,
                       .legacy("default:edge_threshold_cents=3.5"))
        XCTAssertEqual(try ControlIntent.set(engineId: "default", key: "min_k", value: 12).value, .legacy("default:min_k=12"))
        XCTAssertEqual(try ControlIntent.create(engineId: "aggr-2", name: "Aggressive 2", from: "default").value,
                       .legacy(#"{"engine_id":"aggr-2","from":"default","name":"Aggressive 2"}"#))
        XCTAssertEqual(try ControlIntent.bind(symbol: nil, engineId: "default").kind.rawValue, "engine.bind")
        XCTAssertEqual(try ControlIntent.set(engineId: "default", key: "min_k", value: 12).kind.rawValue, "engine.set")
        XCTAssertEqual(try ControlIntent.create(engineId: "new", name: "New", from: "default").kind.rawValue, "engine.create")
        let book = try ControlIntent.configureBook(bookId: "BTC-15M", host: "sample-runner", enabled: false,
            clientRequestId: "33333333-3333-4333-8333-333333333333")
        XCTAssertEqual(book.kind, .bookConfigure)
        XCTAssertEqual(book.host, "sample-runner")
        XCTAssertEqual(book.value, .bookConfigure(BookConfigureValue(bookId: "BTC-15M", enabled: false)))
        XCTAssertEqual(book.value.displayValue, "BTC-15M: disabled")
    }

    func testAccountConfigureIntentIsStructuredAndSupportsInheritance() throws {
        let scope = try ControlScope.account("sample-main")
        let clientId = "11111111-1111-4111-8111-111111111111"
        let set = try ControlIntent.configure(engineId: "default", host: "sample-runner", scope: scope,
            enabled: .value(false), set: ["edge_threshold_cents": 4.5], expectedRevision: "opaque-r1",
            clientRequestId: clientId)
        XCTAssertEqual(set.kind, .configure)
        XCTAssertEqual(set.scope, scope)
        XCTAssertEqual(set.host, "sample-runner")
        XCTAssertEqual(set.expectedRevision, "opaque-r1")
        guard case let .configure(value) = set.value else { return XCTFail("Expected structured configure value") }
        XCTAssertEqual(value.enabledChange, .value(false))
        XCTAssertEqual(value.set, ["edge_threshold_cents": 4.5])
        XCTAssertNil(value.unset)

        let inherit = try ControlIntent.configure(engineId: "default", host: "sample-runner", scope: scope,
            enabled: .inherit, unset: ["edge_threshold_cents"], expectedRevision: "opaque-r2",
            clientRequestId: "22222222-2222-4222-8222-222222222222")
        let encoder = JSONEncoder(); encoder.keyEncodingStrategy = .convertToSnakeCase
        let object = try XCTUnwrap(try JSONSerialization.jsonObject(with: encoder.encode(inherit)) as? [String: Any])
        XCTAssertEqual((object["scope"] as? [String: Any])?["account_id"] as? String, "sample-main")
        let body = try XCTUnwrap(object["value"] as? [String: Any])
        XCTAssertTrue(body.keys.contains("enabled"))
        XCTAssertTrue(body["enabled"] is NSNull)
        XCTAssertEqual(body["unset"] as? [String], ["edge_threshold_cents"])
    }

    func testConfigureRejectsUnsafeOrGlobalInheritance() throws {
        XCTAssertThrowsError(try ControlScope.account("unassigned"))
        XCTAssertThrowsError(try ControlScope.account("bad account"))
        XCTAssertThrowsError(try ControlIntent.configure(engineId: "default", host: "sample-runner", scope: .global,
            enabled: .inherit, expectedRevision: "r1", clientRequestId: UUID().uuidString))
        XCTAssertThrowsError(try ControlIntent.configure(engineId: "default", host: "sample-runner", scope: .global,
            unset: ["min_k"], expectedRevision: "r1", clientRequestId: UUID().uuidString))
        XCTAssertThrowsError(try ControlIntent.configureBook(bookId: "bad book", host: "sample-runner", enabled: true,
            clientRequestId: UUID().uuidString))
    }

    func testPolicyValidationAndIdentity() throws {
        for (key, bound) in PolicyBounds.bounds {
            XCTAssertNil(PolicyBounds.validate(key: key, value: bound.min), key)
            XCTAssertNil(PolicyBounds.validate(key: key, value: min(bound.max, RiskEnvelope.hardMaxima[key] ?? bound.max)), key)
            XCTAssertNotNil(PolicyBounds.validate(key: key, value: bound.max + 1), key)
            XCTAssertNotNil(PolicyBounds.validate(key: key, value: bound.min - 1), key)
            if bound.isInt { XCTAssertNotNil(PolicyBounds.validate(key: key, value: bound.min + 0.5), key) }
        }
        XCTAssertNotNil(PolicyBounds.validate(key: "unknown", value: 1))
        XCTAssertNotNil(PolicyBounds.validate(key: "size_fraction", value: .nan))
        XCTAssertNotNil(PolicyBounds.validate(key: "size_fraction", value: .infinity))
        XCTAssertThrowsError(try ControlIntent.set(engineId: "default", key: "min_k", value: 1.5))
        for id in ["", "UPPER", "-start", "a=b", "a\n", String(repeating: "a", count: 33)] {
            XCTAssertThrowsError(try ControlIntent.bind(symbol: nil, engineId: id))
        }
        XCTAssertThrowsError(try ControlIntent.create(engineId: "new", name: String(repeating: "a", count: 65), from: "default"))
        XCTAssertThrowsError(try ControlIntent.bind(symbol: "BTC=other", engineId: "default"))
    }

    func testControlResponseAndTimestamp() throws {
        let response = try accountJSONDecoder().decode(ControlResponse.self,
            from: Data(#"{"request":{"id":"request-1","kind":"engine.bind","value":"all=default","state":"pending","requested_at":"2026-09-13T00:00:00.123Z"}}"#.utf8))
        XCTAssertEqual(response.request?.state, "pending")
        XCTAssertEqual(response.request?.value, .legacy("all=default"))
        XCTAssertNotNil(response.request?.requestedDate)
    }
}
