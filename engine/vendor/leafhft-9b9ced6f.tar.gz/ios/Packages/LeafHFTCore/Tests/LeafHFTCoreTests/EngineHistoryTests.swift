import Foundation
import XCTest
@testable import LeafHFTCore

final class EngineHistoryTests: XCTestCase {
    private func history() throws -> EngineHistoryResponse {
        let url = try XCTUnwrap(Bundle.module.url(forResource: "engine-history", withExtension: "json", subdirectory: "Fixtures"))
        let decoder = accountJSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(EngineHistoryResponse.self, from: Data(contentsOf: url))
    }

    func testOverallIncludesUnassignedAndAccountsDoNotLeak() throws {
        let response = try history()
        let all = response.performance()
        XCTAssertEqual(all.summary.realizedPnlCents, 300)
        XCTAssertEqual(all.summary.settlementsN, 7)
        XCTAssertEqual(all.summary.wonN, 4)
        XCTAssertEqual(all.winRate!, 4.0 / 8.0, accuracy: 0.0001)
        XCTAssertEqual(response.performance(accountId: "sample-main").summary.realizedPnlCents, 350)
        XCTAssertEqual(response.performance(accountId: "sample-secondary").summary.realizedPnlCents, -100)
        XCTAssertEqual(response.performance(accountId: "unassigned").summary.realizedPnlCents, 50)
        XCTAssertNil(response.performance(accountId: "absent").summary.realizedPnlCents)
        XCTAssertNil(response.performance(engineId: "aggressive", accountId: "sample-main").summary.realizedPnlCents)
    }

    func testSameDayBucketsMergeAndReconcileToTotal() throws {
        let result = try history().performance()
        XCTAssertEqual(result.series.count, 2)
        XCTAssertEqual(result.series.map(\.day), ["2026-09-14", "2026-09-15"])
        XCTAssertEqual(result.series.compactMap(\.pnlCents).reduce(0, +), result.summary.realizedPnlCents)
        XCTAssertEqual(result.series.first?.pnlCents, 250)
        XCTAssertNotNil(result.series.first?.date)
    }

    func testMissingIsNotZeroAndRealZeroIsPreserved() {
        let missing = EngineHistorySummary(realizedPnlCents: nil, settlementsN: 1, exitsN: 0, wonN: 0, openN: 0)
        XCTAssertNil(EnginePerformance(summaries: [missing], points: []).summary.realizedPnlCents)
        XCTAssertNil(EnginePerformance(summaries: [], points: []).winRate)
        let zero = EngineHistorySummary(realizedPnlCents: 0, settlementsN: 2, exitsN: 0, wonN: 1, openN: 0)
        XCTAssertEqual(EnginePerformance(summaries: [zero], points: []).summary.realizedPnlCents, 0)
    }
}
