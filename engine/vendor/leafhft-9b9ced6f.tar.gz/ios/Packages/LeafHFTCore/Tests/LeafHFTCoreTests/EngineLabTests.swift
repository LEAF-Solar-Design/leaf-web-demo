import Foundation
import XCTest
@testable import LeafHFTCore

final class EngineLabTests: XCTestCase {
    func testReasonTextFormatsMissingTokensAndPreservesOtherReasons() {
        XCTAssertEqual(EngineLab.reasonText("not_reported"), "Not reported")
        XCTAssertEqual(EngineLab.reasonText("promotion verdict not_reported"), "Promotion verdict not reported")
        XCTAssertEqual(EngineLab.reasonText("population not_reported"), "Population not reported")
        XCTAssertEqual(EngineLab.reasonText("population not_reported, verdict not_reported"),
                       "Population not reported, verdict not reported")
        XCTAssertEqual(EngineLab.reasonText("Report unreadable"), "Report unreadable")
        XCTAssertEqual(EngineLab.reasonText("count_gate"), "count_gate")
        XCTAssertEqual(EngineLab.reasonText(""), "")
    }

    func testLifecycleRequiresCompleteCanaryEvidence() throws {
        let digest = String(repeating: "a", count: 64)
        var object: [String: Any] = [
            "state": "canary", "account_id": "account-a", "size_fraction": 0.05,
            "entries_enabled": true, "settlement_enabled": true,
            "historical_evidence_digest": digest, "shadow_evidence_digest": digest,
            "snapshot_digest": digest, "stop_reasons": [String]()
        ]
        func decode() throws -> EngineLab.Lifecycle {
            try JSONDecoder().decode(EngineLab.Lifecycle.self,
                                     from: JSONSerialization.data(withJSONObject: object))
        }
        XCTAssertTrue(try decode().canEnter)
        XCTAssertEqual(try decode().label, "5% account canary")
        object["size_fraction"] = 1.0
        XCTAssertFalse(try decode().canEnter)
        object["size_fraction"] = 0.05
        object["state"] = "halted"
        XCTAssertFalse(try decode().canEnter)
        XCTAssertEqual(try decode().label, "Entries halted, settlement only")
        object["state"] = "live"
        XCTAssertEqual(try decode().state, .unknown)
        XCTAssertFalse(try decode().canEnter)
    }

    private func notesObject() throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: Data(EngineLab.bundledNotesJSON.utf8)) as? [String: Any])
    }
    private func decode(_ object: [String: Any]) throws -> EngineLab.Notes {
        try EngineLab.decodeNotes(JSONSerialization.data(withJSONObject: object))
    }
    private func engine() throws -> Engine {
        let json = """
        {"engine_id":"test-engine","host":"runner","configuration":{
          "global":{"enabled":true,"policy":{"edge":1}},
          "accounts":[{"account_id":"account-a",
            "override":{"enabled":false,"policy":{"edge":2}},
            "effective":{"enabled":false,"policy":{"edge":2}},
            "pending":{"id":"pending","state":"queued"}}]}}
        """
        return try accountJSONDecoder().decode(Engine.self, from: Data(json.utf8))
    }
    private func account(_ id: String, configurable: Bool = true, host: String = "runner") -> EngineControlAccount {
        EngineControlAccount(id: id, label: id, host: host, subaccountNumber: nil, configurable: configurable)
    }

    func testBundledNotesRemainAvailableOnlyAsLegacyFallback() throws {
        let notes = try EngineLab.decodeNotes(Data(EngineLab.bundledNotesJSON.utf8))
        XCTAssertEqual(notes, EngineLab.bundledNotes)
        XCTAssertEqual(notes.schemaVersion, 2)
        XCTAssertEqual(notes.reviewedAt, "2026-09-20")
        XCTAssertEqual(notes.lanes.map(\.id), ["darkhorse", "dip-recovery", "relay-divergence"])
        XCTAssertEqual(notes.lanes.map(\.stage), [.notReported, .research, .research])
        XCTAssertTrue(notes.lanes.allSatisfy { $0.owner == nil && $0.ownerLabel == "No owner yet" })
        XCTAssertTrue(notes.lanes[0].boundary.contains("Status not reported"))
        XCTAssertTrue(notes.lanes[1].boundary.contains("Not trading"))
        XCTAssertTrue(notes.lanes[2].boundary.contains("Not trading"))
        XCTAssertEqual(notes.lanes.map(\.nextAction),
                       ["First-class account integration", "Build a shadow engine", "Run a stable shadow trial"])
        XCTAssertEqual(notes.lanes.map { $0.evidence[0].label }, ["Cap and holdout", "Replay", "Daily diagnostic"])
        XCTAssertTrue(notes.lanes.allSatisfy { !$0.stage.symbol.isEmpty && !$0.stage.label.isEmpty })
    }

    func testNotesCannotClaimLiveOrPausedStages() throws {
        for raw in ["live", "paused", "future-stage", "unknown"] {
            var object = try notesObject()
            var lanes = try XCTUnwrap(object["lanes"] as? [[String: Any]])
            lanes[0]["stage"] = raw
            object["lanes"] = lanes
            XCTAssertEqual(try decode(object).lanes[0].stage, .research)
        }
        var object = try notesObject()
        var lanes = try XCTUnwrap(object["lanes"] as? [[String: Any]])
        lanes[0]["stage"] = "shadow"
        object["lanes"] = lanes
        XCTAssertEqual(try decode(object).lanes[0].stage, .shadow)
    }

    func testStrictNotesContractRejectsMalformedOrDriftingData() throws {
        var object = try notesObject()
        object["extra"] = true
        XCTAssertThrowsError(try decode(object))
        object = try notesObject()
        object["schema_version"] = 1
        XCTAssertThrowsError(try decode(object))
        object = try notesObject()
        object["reviewed_at"] = "not-a-date"
        XCTAssertThrowsError(try decode(object))
        for field in ["lane_id", "name", "stage", "hypothesis", "evidence", "next_action", "readiness"] {
            object = try notesObject()
            var lanes = try XCTUnwrap(object["lanes"] as? [[String: Any]])
            lanes[0].removeValue(forKey: field)
            object["lanes"] = lanes
            XCTAssertThrowsError(try decode(object), field)
        }
        for replacement in [["extra": "value"], ["label": "Replay", "value": "Evidence", "as_of": "bad"]] {
            object = try notesObject()
            var lanes = try XCTUnwrap(object["lanes"] as? [[String: Any]])
            lanes[0]["evidence"] = [replacement]
            object["lanes"] = lanes
            XCTAssertThrowsError(try decode(object))
        }
        object = try notesObject()
        var lanes = try XCTUnwrap(object["lanes"] as? [[String: Any]])
        lanes[1]["lane_id"] = lanes[0]["lane_id"]
        object["lanes"] = lanes
        XCTAssertThrowsError(try decode(object))
    }

    func testAccountJoinNeverFallsBackToGlobal() throws {
        let engine = try engine()
        XCTAssertEqual(EngineLab.entriesLabel(engine: engine), "New entries enabled")
        XCTAssertEqual(EngineLab.entriesLabel(engine: engine, accountId: "account-a"), "New entries paused")
        XCTAssertEqual(EngineLab.entriesLabel(engine: engine, accountId: "missing"), "Entry setting unknown")
        XCTAssertNil(EngineLab.configuration(engine: engine, accountId: "missing"))
        let configuration = try XCTUnwrap(EngineLab.configuration(engine: engine, accountId: "account-a"))
        XCTAssertEqual(EngineLab.customSettings(configuration), 2)
        XCTAssertEqual(configuration.effective.policy?["edge"], 2)
        XCTAssertEqual(configuration.pending?.state, "queued")
        let inherited = EngineAccountConfiguration(accountId: "account-b",
            override: EngineConfigurationOverride(enabled: nil, policy: ["edge": 3]),
            effective: EngineEffectiveConfiguration(enabled: nil, policy: nil),
            revision: nil, observedAt: nil, freshness: nil, pending: nil)
        XCTAssertEqual(EngineLab.customSettings(inherited), 1)
        XCTAssertEqual(EngineLab.entriesLabel(inherited.effective.enabled), "Entry setting unknown")
        XCTAssertEqual(EngineLab.entriesLabel(true), "New entries enabled")
        XCTAssertEqual(EngineLab.entriesLabel(false), "New entries paused")
    }

    func testLiveV3DiscoversCandidatesAndCollaborationWithoutHardcodedLanes() throws {
        let lab = try EngineLab.decodeResponse(Data(EngineLab.previewResponseJSON.utf8))
        XCTAssertEqual(lab.schemaVersion, 3)
        XCTAssertEqual(lab.candidates.map(\.id), ["darkhorse", "dip-recovery", "atlas-discovery"])
        XCTAssertEqual(lab.evidence.map(\.provenance), ["shadow", "replay", "paper"])
        XCTAssertEqual(lab.owner(for: "dip-recovery"), "Research team")
        let assignment = try XCTUnwrap(lab.events.first { $0.kind == "assignment" })
        XCTAssertEqual(lab.assignmentState(assignment), "in_progress")
        XCTAssertTrue(lab.events.contains { $0.kind == "comment" })
        XCTAssertEqual(lab.events.first { $0.kind == "decision" }?.payload["action"], "hold")
        XCTAssertTrue(lab.candidates[1].shadowOnly)
        XCTAssertTrue(lab.candidates.allSatisfy { $0.liveProfitCents.isMissing })
        XCTAssertTrue(lab.candidates[2].workshopLane.evidence[0].value.contains("paper"))
    }

    func testV3AcceptsRegistrationEvidenceAlongsideFullReportHistory() throws {
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(EngineLab.previewResponseJSON.utf8)) as? [String: Any])
        var candidates = try XCTUnwrap(object["candidates"] as? [[String: Any]])
        let evidence = try XCTUnwrap(candidates[0]["evidence"] as? [[String: Any]])
        // The producer can emit 256 reports plus registration and snapshot evidence.
        candidates[0]["evidence"] = Array(repeating: evidence[0], count: 257)
        object["candidates"] = candidates
        object["evidence"] = try candidates.flatMap { candidate in
            try XCTUnwrap(candidate["evidence"] as? [[String: Any]])
        }
        let lab = try EngineLab.decodeResponse(JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(lab.candidates[0].evidence.count, 257)
        XCTAssertEqual(lab.evidence.count, 259)
    }

    func testGenericPaperResultsSeparateModesAndSetupSplits() throws {
        let lab = try EngineLab.decodeResponse(Data(EngineLab.previewResponseJSON.utf8))
        XCTAssertEqual(lab.candidates[0].paperModeLabel, "Shadow")
        XCTAssertEqual(lab.candidates[0].paperResults.statusLabel, "Collecting evidence")
        let candidate = lab.candidates[1]
        let paper = candidate.paperResults
        XCTAssertEqual(candidate.paperModeLabel, "Paper")
        XCTAssertEqual(paper.statusLabel, "Paper results available")
        XCTAssertEqual(paper.resolved, 8)
        XCTAssertEqual(paper.open, 2)
        XCTAssertEqual(paper.wins, 5)
        XCTAssertEqual(paper.losses, 3)
        XCTAssertEqual(paper.simulatedPnLLabel, "Simulated P&L: 2.40 USD")
        XCTAssertEqual(paper.returnLabel, "Simulated return: 2.40%")
        XCTAssertEqual(paper.drawdownLabel, "Simulated drawdown: 0.80 USD")
        XCTAssertEqual(paper.setup("A").simulatedNetCents, 160)
        XCTAssertEqual(paper.setup("B").resolved, 3)
        XCTAssertTrue(candidate.liveProfitCents.isMissing)
        let collecting = lab.candidates[2].paperResults
        XCTAssertTrue(collecting.isCollecting)
        XCTAssertFalse(collecting.hasMetrics)
        XCTAssertEqual(collecting.simulatedPnLLabel, "Simulated P&L: Unavailable")
    }

    func testPaperMetricsAcceptNumericStringsAndPreserveZeroAndLoss() {
        let paper = EngineLab.PaperResults(metrics: .object([
            "resolved_count": .text("4"), "open_count": .number(0),
            "won": .number(1), "lost": .number(3), "net_cents": .text("-125"),
            "return_on_fixed_base": .text("-0.01255"), "drawdown_fraction": .number(0.05),
            "by_setup": .object(["A": .object(["resolved": .number(0), "open": .number(2)])])
        ]))
        XCTAssertEqual(paper.resolved, 4)
        XCTAssertEqual(paper.open, 0)
        XCTAssertEqual(paper.simulatedPnLLabel, "Simulated P&L: -1.25 USD")
        XCTAssertEqual(paper.drawdownLabel, "Simulated drawdown: 5.00%")
        XCTAssertTrue(paper.setup("A").isCollecting)
        XCTAssertEqual(paper.setup("A").open, 2)
        XCTAssertFalse(paper.setup("B").hasMetrics)
        XCTAssertTrue(EngineLab.PaperResults(metrics: .object(["resolved": .number(4)]), status: "collecting").isCollecting)
    }

    func testMalformedPaperMetricsRemainUnavailableWithoutUnsafeConversions() {
        let missing: [EngineLab.ResearchValue] = [.null, .text("not_reported"), .array([]), .flag(true)]
        for value in missing {
            let paper = EngineLab.PaperResults(metrics: value)
            XCTAssertTrue(paper.isCollecting)
            XCTAssertFalse(paper.hasMetrics)
        }
        let paper = EngineLab.PaperResults(metrics: .object([
            "resolved": .number(1e100), "open": .number(-1), "wins": .number(1.5),
            "losses": .flag(true), "simulated_net_cents": .text("125junk"),
            "return_on_fixed_base": .number(.infinity), "max_drawdown_cents": .number(-5),
            "setups": .array([])
        ]))
        XCTAssertFalse(paper.hasMetrics)
        XCTAssertEqual(paper.countsLabel, "Resolved: Unavailable · Open: Unavailable")
        XCTAssertEqual(paper.returnLabel, "Simulated return: Unavailable")
        XCTAssertEqual(paper.drawdownLabel, "Simulated drawdown: Unavailable")
        XCTAssertFalse(paper.setup("A").hasMetrics)
        XCTAssertNil(EngineLab.PaperResults(metrics: .object(["simulated_net_cents": .text("NaN")])).simulatedNetCents)
        XCTAssertLessThan(EngineLab.PaperResults(metrics: .object(["simulated_net_cents": .number(1e300)])).simulatedPnLLabel.count, 60)
    }

    func testLatestPaperReportDoesNotMixLiveOrOlderMetrics() throws {
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(EngineLab.previewResponseJSON.utf8)) as? [String: Any])
        var candidates = try XCTUnwrap(object["candidates"] as? [[String: Any]])
        var report = try XCTUnwrap((candidates[1]["evidence"] as? [[String: Any]])?.first)
        let older = report
        report["source_timestamp"] = "2026-09-21T12:00:00Z"
        report["metrics"] = ["open": 6]
        var live = report
        live["source_timestamp"] = "2026-09-22T12:00:00Z"
        live["provenance"] = "live_fill"
        live["metrics"] = ["net_cents": 99999, "resolved": 20]
        var registration = live
        registration["kind"] = "trial_registration"
        registration["provenance"] = "paper"
        candidates[1]["evidence"] = [live, report, registration, older]
        object["candidates"] = candidates
        object["evidence"] = try candidates.flatMap { try XCTUnwrap($0["evidence"] as? [[String: Any]]) }
        let result = try EngineLab.decodeResponse(JSONSerialization.data(withJSONObject: object)).candidates[1].paperResults
        XCTAssertEqual(result.open, 6)
        XCTAssertNil(result.simulatedNetCents)
        XCTAssertNil(result.resolved)
        XCTAssertTrue(result.isCollecting)
    }

    func testV3MissingOrMalformedMetricsDoNotDiscardCandidates() throws {
        let malformed: [Any?] = [nil, NSNull(), "invalid", ["resolved": "wrong", "simulated_net_cents": false] as [String: Any]]
        for metrics in malformed {
            var object = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(EngineLab.previewResponseJSON.utf8)) as? [String: Any])
            var candidates = try XCTUnwrap(object["candidates"] as? [[String: Any]])
            var report = try XCTUnwrap((candidates[1]["evidence"] as? [[String: Any]])?.first)
            report["metrics"] = metrics
            candidates[1]["evidence"] = [report]
            object["candidates"] = candidates
            object["evidence"] = try candidates.flatMap { try XCTUnwrap($0["evidence"] as? [[String: Any]]) }
            let lab = try EngineLab.decodeResponse(JSONSerialization.data(withJSONObject: object))
            XCTAssertEqual(lab.candidates.count, 3)
            XCTAssertTrue(lab.candidates[1].paperResults.isCollecting)
            XCTAssertFalse(lab.candidates[1].paperResults.hasMetrics)
        }
    }

    func testV3RejectsWrongVersionDuplicateCandidatesAndSimulatedLiveProfit() throws {
        let original = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(EngineLab.previewResponseJSON.utf8)) as? [String: Any])
        var object = original
        object["schema_version"] = 2
        XCTAssertThrowsError(try EngineLab.decodeResponse(JSONSerialization.data(withJSONObject: object)))
        object = original
        var candidates = try XCTUnwrap(object["candidates"] as? [[String: Any]])
        candidates.append(candidates[0])
        object["candidates"] = candidates
        XCTAssertThrowsError(try EngineLab.decodeResponse(JSONSerialization.data(withJSONObject: object)))
        object = original
        candidates = try XCTUnwrap(object["candidates"] as? [[String: Any]])
        candidates[1]["live_profit_cents"] = 500
        object["candidates"] = candidates
        XCTAssertThrowsError(try EngineLab.decodeResponse(JSONSerialization.data(withJSONObject: object)))
        object = original
        object["evidence"] = []
        XCTAssertThrowsError(try EngineLab.decodeResponse(JSONSerialization.data(withJSONObject: object)))
    }

    func testCollaborationInputsBoundPayloadsAndKeepRequestIdentity() throws {
        let id = UUID().uuidString
        let input = try EngineLab.EventInput(engineId: "atlas-discovery", kind: "comment", payload: ["text": "Review replay"], clientRequestId: id)
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoder.encode(input)) as? [String: Any])
        XCTAssertEqual(object["client_request_id"] as? String, id)
        XCTAssertEqual(object["engine_id"] as? String, "atlas-discovery")
        XCTAssertNil(object["actor"])
        XCTAssertThrowsError(try EngineLab.EventInput(engineId: "atlas-discovery", kind: "decision", payload: ["action": "enable", "reason": "Now"]))
        XCTAssertThrowsError(try EngineLab.EventInput(engineId: "atlas-discovery", kind: "comment", payload: ["text": String(repeating: "a", count: 2001)]))
        XCTAssertThrowsError(try EngineLab.EventInput(engineId: "atlas-discovery", kind: "owner", payload: ["owner": "   "]))
        XCTAssertThrowsError(try EngineLab.EventInput(engineId: "atlas-discovery", kind: "assignment_state", payload: ["assignment_id": "missing", "state": "done"]))
    }

    func testEmptyLiveV3IsNotReplacedByBundledCandidates() throws {
        let lab = try EngineLab.decodeResponse(Data(#"""
        {"schema_version":3,"generated_at":"2026-09-20T12:00:00Z","candidates":[],"evidence":[],
         "problems":["Engine Lab evidence not_reported"],"missing_value":"not_reported",
         "advisory":true,"stale":true,"events":[],"events_truncated":false}
        """#.utf8))
        XCTAssertTrue(lab.candidates.isEmpty)
        XCTAssertTrue(lab.stale)
        XCTAssertFalse(lab.problems.isEmpty)
    }

    func testYourLaneRequiresExactlyOneEligibleAccount() {
        XCTAssertNil(EngineLab.yourLane(in: []))
        XCTAssertNil(EngineLab.yourLane(in: [account("unassigned"), account("read-only", configurable: false)]))
        XCTAssertEqual(EngineLab.yourLane(in: [account("account-a"), account("unassigned")]), "account-a")
        XCTAssertNil(EngineLab.yourLane(in: [account("account-a"), account("account-b")]))
    }

    func testSettingsLinksRequireConfigurableAssignedMatchingHost() throws {
        var engine = try engine()
        XCTAssertTrue(EngineLab.canOpenSettings(account: account("account-a"), engine: engine))
        XCTAssertFalse(EngineLab.canOpenSettings(account: account("unassigned"), engine: engine))
        XCTAssertFalse(EngineLab.canOpenSettings(account: account("account-a", configurable: false), engine: engine))
        XCTAssertFalse(EngineLab.canOpenSettings(account: account("account-a", host: "other"), engine: engine))
        engine.host = nil
        XCTAssertFalse(EngineLab.canOpenSettings(account: account("account-a"), engine: engine))
    }

    func testFreshnessRequiresSourceAndTransportTimes() throws {
        let source = "2026-09-20T12:00:00Z"
        let now = try XCTUnwrap(ISO8601DateFormatter().date(from: source))
        XCTAssertEqual(EngineLab.freshness(generatedAt: source, observedAt: now, now: now), .current)
        XCTAssertEqual(EngineLab.freshness(generatedAt: source, observedAt: now, now: now.addingTimeInterval(120)), .current)
        XCTAssertEqual(EngineLab.freshness(generatedAt: source, observedAt: now.addingTimeInterval(121), now: now.addingTimeInterval(121)), .delayed)
        XCTAssertEqual(EngineLab.freshness(generatedAt: source, observedAt: now.addingTimeInterval(-121), now: now), .delayed)
        XCTAssertEqual(EngineLab.freshness(generatedAt: nil, observedAt: now, now: now), .unknown)
        XCTAssertEqual(EngineLab.freshness(generatedAt: "invalid", observedAt: now, now: now), .unknown)
        XCTAssertEqual(EngineLab.freshness(generatedAt: source, observedAt: nil, now: now), .unknown)
        XCTAssertEqual(EngineLab.freshness(generatedAt: source, observedAt: now, now: now.addingTimeInterval(-1)), .unknown)
        XCTAssertEqual(EngineLab.freshness(generatedAt: source, observedAt: now.addingTimeInterval(1), now: now), .unknown)
        XCTAssertEqual(EngineLab.freshness(generatedAt: "2026-09-20T12:00:00.000Z", observedAt: now, now: now), .current)
    }

    func testContradictoryAndIncompleteLaneStates() throws {
        var lane: [String: Any] = [
            "id": "22222222-2222-4222-8222-222222222222", "state": "dry_run",
            "kill_requested": false, "live_enabled": false
        ]
        var status: [String: Any] = [
            "dashboard_pairing": "paired", "account_binding": "bound",
            "automated_trading": "dry_run",
            "tenant": ["id": "11111111-1111-4111-8111-111111111111", "runner_host": "runner"],
            "lane": lane
        ]
        func label() throws -> String {
            EngineLab.laneLabel(try accountJSONDecoder().decode(KashbotStatus.self,
                from: JSONSerialization.data(withJSONObject: status)))
        }
        XCTAssertEqual(try label(), "Dry run only")
        lane["live_enabled"] = true
        status["lane"] = lane
        XCTAssertEqual(try label(), "Account lane state inconsistent")
        lane["live_enabled"] = false
        lane["state"] = "live"
        status["automated_trading"] = "live"
        status["lane"] = lane
        XCTAssertEqual(try label(), "Account lane state inconsistent")
        lane["live_enabled"] = true
        status["lane"] = lane
        XCTAssertEqual(try label(), "Live trading enabled")
        lane["kill_requested"] = true
        status["lane"] = lane
        XCTAssertEqual(try label(), "Stop requested")
        lane.removeValue(forKey: "live_enabled")
        status["lane"] = lane
        XCTAssertEqual(try label(), "Account lane state incomplete")
        status["account_binding"] = "unbound"
        XCTAssertEqual(try label(), "Account lane not bound")
    }

    func testUnknownRequestsAndLaneStatesRemainExplicit() {
        XCTAssertTrue(EngineLab.isPending(nil))
        XCTAssertTrue(EngineLab.isPending("future-state"))
        XCTAssertTrue(EngineLab.isPending("queued"))
        for state in ["APPLIED", "rejected", "failed", "cancelled", "completed", "succeeded", "expired"] {
            XCTAssertFalse(EngineLab.isPending(state))
        }
        XCTAssertEqual(EngineLab.requestScope(nil), "Scope not published")
        XCTAssertEqual(EngineLab.requestScope(.global), "Global engine settings")
        XCTAssertEqual(EngineLab.laneLabel(nil), "Account lane not checked")
    }
}
