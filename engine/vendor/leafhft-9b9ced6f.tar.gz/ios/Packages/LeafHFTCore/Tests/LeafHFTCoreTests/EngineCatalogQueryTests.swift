import XCTest
@testable import LeafHFTCore

final class EngineCatalogQueryTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)

    private func engine(_ id: String, _ fields: [String: Any] = [:]) throws -> Engine {
        let object = fields.merging(["engine_id": id]) { _, new in new }
        return try accountJSONDecoder().decode(Engine.self, from: JSONSerialization.data(withJSONObject: object))
    }

    private func ids(_ engines: [Engine], _ query: EngineCatalogQuery) -> [String] {
        query.apply(engines, now: now).map(\.engineId)
    }

    func testTokensAreANDedAcrossEverySearchField() throws {
        let target = try engine("runner-needle", [
            "name": "Café Momentum", "description": "patient entries", "parent_engine_id": "ancestor",
            "host": "mini", "bound_books": ["BTC-15M"], "markets": ["weather"],
            "assignment": ["account_id": "secondary"]
        ])
        let decoy = try engine("decoy", ["name": "Café"])
        for term in ["runner-needle", "patient", "ancestor", "mini", "BTC-15M", "weather", "secondary", "Savings"] {
            let result = EngineCatalogQuery(text: "cafe \(term)")
                .apply([decoy, target], accountLabels: ["secondary": "Savings account"], now: now)
            XCTAssertEqual(result.map(\.engineId), ["runner-needle"], term)
        }
        XCTAssertTrue(EngineCatalogQuery(text: "cafe absent").apply([target]).isEmpty)
    }

    func testSearchIgnoresCaseAndDiacritics() throws {
        let rows = [try engine("one", ["name": "Café Élan"])]
        XCTAssertEqual(ids(rows, EngineCatalogQuery(text: "CAFE elan")), ["one"])
        XCTAssertEqual(ids(rows, EngineCatalogQuery(text: " \n cafe\tELAN  ")), ["one"])
    }

    func testTextIsTrimmedAndCappedAt64Characters() throws {
        var query = EngineCatalogQuery(text: "  " + String(repeating: "a", count: 80) + "  ")
        XCTAssertEqual(query.text, String(repeating: "a", count: 64))
        query.text = " \n" + String(repeating: "é", count: 70) + "\n"
        XCTAssertEqual(query.text.count, 64)
        XCTAssertEqual(ids([try engine("one", ["name": String(repeating: "é", count: 64)])], query), ["one"])
    }

    func testRunnerAndNameSortKeepStableTies() throws {
        let rows = [try engine("z", ["name": "Beta"]), try engine("b", ["name": "Alpha"]),
                    try engine("a", ["name": "Alpha"]), try engine("c", ["name": "Gamma"])]
        XCTAssertEqual(ids(rows, EngineCatalogQuery()), ["z", "b", "a", "c"])
        XCTAssertEqual(ids(rows, EngineCatalogQuery(sort: .name)), ["b", "a", "z", "c"])
    }

    func testNetSortNilLastInBothDirectionsAndStableTies() throws {
        let rows = [try engine("nil"), try engine("b", ["pnl": ["net_cents": 20]]),
                    try engine("a", ["pnl": ["net_cents": 20]]),
                    try engine("low", ["pnl": ["net_cents": -5]]), try engine("nil2")]
        XCTAssertEqual(ids(rows, EngineCatalogQuery(sort: .netHigh)), ["b", "a", "low", "nil", "nil2"])
        XCTAssertEqual(ids(rows, EngineCatalogQuery(sort: .netLow)), ["low", "b", "a", "nil", "nil2"])
    }

    func testOtherMetricSortsKeepNilLastAndStableTies() throws {
        let rows = [try engine("nil"),
                    try engine("b", ["pnl": ["n": 10, "won": 8, "tickets_per_hour": 3],
                                     "live": ["n": 10, "days": 7, "per_contract_cents": 2.5]]),
                    try engine("a", ["pnl": ["n": 10, "won": 8, "tickets_per_hour": 3],
                                     "live": ["n": 10, "days": 7, "per_contract_cents": 2.5]]),
                    try engine("low", ["pnl": ["n": 10, "won": 1, "tickets_per_hour": 1],
                                       "live": ["n": 10, "days": 7, "per_contract_cents": -1]])]
        for sort in [EngineCatalogQuery.Sort.perContract, .winRate, .rate] {
            XCTAssertEqual(ids(rows, EngineCatalogQuery(sort: sort)), ["b", "a", "low", "nil"])
        }
        let noSample = try engine("empty", ["pnl": ["n": 0, "won": 0]])
        XCTAssertNil(EngineCatalogQuery.winRate(noSample))
    }

    func testAllAcceptingAndPausedUseTheSuppliedEntryState() throws {
        let rows = [try engine("on"), try engine("off")]
        for (show, expected) in [(EngineCatalogQuery.Show.all, ["on", "off"]),
                                  (.accepting, ["on"]), (.paused, ["off"])] {
            XCTAssertEqual(EngineCatalogQuery(show: show).apply(rows, enabled: { $0.engineId == "on" })
                .map(\.engineId), expected)
        }
    }

    func testMissingEnabledTelemetryIsUnknownAndExcludedFromEntryFilters() throws {
        let rows = [try engine("unknown"), try engine("on", ["configuration": [
            "global": ["enabled": true], "accounts": []]]),
            try engine("off", ["configuration": ["global": ["enabled": false], "accounts": []]])]
        XCTAssertEqual(ids(rows, EngineCatalogQuery(show: .all)), ["unknown", "on", "off"])
        XCTAssertEqual(ids(rows, EngineCatalogQuery(show: .accepting)), ["on"])
        XCTAssertEqual(ids(rows, EngineCatalogQuery(show: .paused)), ["off"])
        XCTAssertEqual(EngineCatalogQuery.entryText(nil), "Unknown")
        XCTAssertEqual(EngineCatalogQuery.entryText(false), "New entries paused")
        XCTAssertEqual(EngineCatalogQuery.entryText(true), "Accepting new entries")
    }

    func testTelemetryChangesInvalidateCatalogWithoutControlChanges() throws {
        let base = try engine("one")
        let variants: [[String: Any]] = [
            ["name": "New name"], ["description": "New description"], ["parent_engine_id": "parent"],
            ["host": "runner"], ["assignment": ["account_id": "secondary"]],
            ["bound_books": ["BTC-15M"]], ["markets": ["weather"]],
            ["pnl": ["net_cents": 20]], ["pnl": ["tickets_per_hour": 3]],
            ["pnl": ["n": 10]], ["pnl": ["won": 8]],
            ["live": ["n": 10, "days": 7, "per_contract_cents": 2.5]],
            ["lifecycle": ["state": "probe", "breaker": ["engine_loss_cents": 75, "engine_limit_cents": 100]]],
            ["lifecycle": ["state": "probe", "entries_suspended_until":
                ISO8601DateFormatter().string(from: now.addingTimeInterval(60))]]
        ]
        let fingerprint = EngineCatalogQuery.fingerprint([base], now: now)
        for fields in variants {
            let changed = try engine("one", fields)
            XCTAssertNotEqual(fingerprint, EngineCatalogQuery.fingerprint([changed], now: now), "\(fields)")
        }
        XCTAssertNotEqual(fingerprint, EngineCatalogQuery.fingerprint([base], accountLabels: ["main": "Renamed"], now: now))
        let other = try engine("two")
        XCTAssertNotEqual(EngineCatalogQuery.fingerprint([base, other], now: now),
                          EngineCatalogQuery.fingerprint([other, base], now: now))
    }

    func testTelemetryChangeResortsAndRefiltersCachedIDs() throws {
        let old = [try engine("one", ["name": "Alpha", "pnl": ["net_cents": 10, "tickets_per_hour": 1]]),
                   try engine("two", ["name": "Beta", "pnl": ["net_cents": 20, "tickets_per_hour": 2]])]
        let changed = [try engine("one", ["name": "Zulu", "pnl": ["net_cents": 30, "tickets_per_hour": 3],
            "assignment": ["account_id": "main"]]), old[1]]
        for (query, before, after) in [
            (EngineCatalogQuery(sort: .netHigh), ["two", "one"], ["one", "two"]),
            (EngineCatalogQuery(sort: .rate), ["two", "one"], ["one", "two"]),
            (EngineCatalogQuery(sort: .name), ["one", "two"], ["two", "one"]),
            (EngineCatalogQuery(text: "Alpha"), ["one"], []),
            (EngineCatalogQuery(accountId: "main"), [], ["one"])
        ] {
            var cached = ids(old, query)
            XCTAssertEqual(cached, before)
            if EngineCatalogQuery.fingerprint(old, now: now) != EngineCatalogQuery.fingerprint(changed, now: now) {
                cached = ids(changed, query)
            }
            XCTAssertEqual(cached, after)
        }
    }

    func testSuspensionExpiryAndBreakerChangeInvalidateAttentionMembership() throws {
        let until = now.addingTimeInterval(60)
        let rows = [try engine("suspended", ["lifecycle": ["state": "probe",
            "entries_suspended_until": ISO8601DateFormatter().string(from: until)]])]
        let query = EngineCatalogQuery(show: .attention)
        XCTAssertEqual(ids(rows, query), ["suspended"])
        XCTAssertNotEqual(EngineCatalogQuery.fingerprint(rows, now: now),
                          EngineCatalogQuery.fingerprint(rows, now: until))
        XCTAssertTrue(query.apply(rows, now: until).isEmpty)
        XCTAssertEqual(EngineCatalogQuery.fingerprint(rows, now: now),
                       EngineCatalogQuery.fingerprint(rows, now: now.addingTimeInterval(30)))
        let low = [try engine("one", ["lifecycle": ["state": "probe",
            "breaker": ["engine_loss_cents": 74, "engine_limit_cents": 100]]])]
        let high = [try engine("one", ["lifecycle": ["state": "probe",
            "breaker": ["engine_loss_cents": 75, "engine_limit_cents": 100]]])]
        XCTAssertNotEqual(EngineCatalogQuery.fingerprint(low, now: now), EngineCatalogQuery.fingerprint(high, now: now))
        XCTAssertTrue(ids(low, query).isEmpty)
        XCTAssertEqual(ids(high, query), ["one"])
    }

    func testAttentionIncludesEachCauseAndExcludesExpiredSuspension() throws {
        let future = ISO8601DateFormatter().string(from: now.addingTimeInterval(60))
        let past = ISO8601DateFormatter().string(from: now.addingTimeInterval(-60))
        let rows = [
            try engine("halted", ["lifecycle": ["state": "halted"]]),
            try engine("suspended", ["lifecycle": ["state": "probe", "entries_suspended_until": future]]),
            try engine("breaker", ["lifecycle": ["state": "probe",
                "breaker": ["engine_loss_cents": 75, "engine_limit_cents": 100, "engine_pct": 0]]]),
            try engine("error"), try engine("pending"),
            try engine("expired", ["lifecycle": ["state": "probe", "entries_suspended_until": past]]),
            try engine("normal")
        ]
        let result = EngineCatalogQuery(show: .attention).apply(rows, now: now, attention: {
            EngineCatalogQuery.attentionReason($0, now: self.now,
                error: $0.engineId == "error" ? "Could not submit" : nil,
                pending: $0.engineId == "pending") != nil
        })
        XCTAssertEqual(result.map(\.engineId), ["halted", "suspended", "breaker", "error", "pending"])
    }

    func testBreakerUsesCentsAndRequiresAPositiveLimit() throws {
        for (loss, limit, expected) in [(74, 100, false), (75, 100, true), (100, 100, true),
                                       (1, 0, false), (-10, 100, false)] {
            let row = try engine("one", ["lifecycle": ["state": "probe",
                "breaker": ["engine_loss_cents": loss, "engine_limit_cents": limit, "engine_pct": 99]]])
            XCTAssertEqual(EngineCatalogQuery.attentionReason(row, now: now) != nil, expected)
        }
    }

    func testFilteredHaltedEnginesCountAsHiddenAttention() throws {
        let rows = [try engine("halted", ["lifecycle": ["state": "halted"]]), try engine("visible")]
        let visible = Set(ids(rows, EngineCatalogQuery(text: "visible")))
        let hidden = rows.filter { !visible.contains($0.engineId) &&
            EngineCatalogQuery.attentionReason($0, now: now) != nil }
        XCTAssertEqual(hidden.map(\.engineId), ["halted"])
    }

    func testAccountFilterIncludesUnassignedSpellings() throws {
        let rows = [try engine("main", ["assignment": ["account_id": "main"]]),
                    try engine("secondary", ["assignment": ["account_id": "secondary"]]),
                    try engine("missing"), try engine("empty", ["assignment": ["account_id": ""]]),
                    try engine("unassigned", ["assignment": ["account_id": "unassigned"]])]
        XCTAssertEqual(ids(rows, EngineCatalogQuery(accountId: "main")), ["main"])
        XCTAssertEqual(ids(rows, EngineCatalogQuery(accountId: "unassigned")), ["missing", "empty", "unassigned"])
        XCTAssertEqual(EngineCatalogQuery().apply(rows).count, 5)
    }

    func testSynthetic64EngineCatalog() throws {
        let rows = try (0..<64).map { try engine("engine-\($0)", [
            "name": "Catalog \($0)", "pnl": ["net_cents": $0],
            "assignment": ["account_id": $0.isMultiple(of: 2) ? "even" : "odd"]
        ]) }
        let result = EngineCatalogQuery(text: "catalog", sort: .netHigh, accountId: "even").apply(rows)
        XCTAssertEqual(result.count, 32)
        XCTAssertEqual(result.first?.engineId, "engine-62")
        XCTAssertEqual(result.last?.engineId, "engine-0")
        XCTAssertEqual(Set(result.map(\.engineId)).count, 32)
    }
}
