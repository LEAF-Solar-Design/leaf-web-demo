import Foundation
import XCTest
@testable import LeafHFTCore

final class PolicyCatalogTests: XCTestCase {
    func testEveryBoundKeyHasCompleteMetadata() {
        XCTAssertEqual(PolicyCatalog.parameters.count, 31)
        XCTAssertEqual(Set(PolicyCatalog.parameters.map(\.key)), Set(PolicyBounds.bounds.keys))
        for parameter in PolicyCatalog.parameters {
            XCTAssertFalse(parameter.name.isEmpty, parameter.key)
            XCTAssertFalse(parameter.summary.isEmpty, parameter.key)
            XCTAssertFalse(parameter.whenHigher.isEmpty, parameter.key)
            XCTAssertFalse(parameter.whenLower.isEmpty, parameter.key)
            XCTAssertFalse(parameter.searchTerms.isEmpty, parameter.key)
            XCTAssertTrue(parameter.searchTerms.contains(parameter.key), parameter.key)
            XCTAssertLessThan(parameter.minimum, parameter.maximum, parameter.key)
            XCTAssertGreaterThan(parameter.step, 0, parameter.key)
            XCTAssertFalse(parameter.name.contains("_"), parameter.key)
            XCTAssertTrue(parameter.summary.hasSuffix("."), parameter.key)
            for text in [parameter.name, parameter.summary, parameter.whenHigher, parameter.whenLower] {
                XCTAssertFalse(text.contains(parameter.key), parameter.key)
            }
        }
    }

    func testRiskResizeLiveIsBoundedToggle() throws {
        let parameter = try XCTUnwrap(PolicyCatalog.parameter(for: "risk_resize_live"))
        XCTAssertEqual(parameter.control, .toggle)
        XCTAssertTrue(parameter.isInteger)
        XCTAssertEqual(parameter.minimum, 0)
        XCTAssertEqual(parameter.maximum, 1)
    }

    func testRiskResizeLiveValidationUsesDerivedBounds() {
        XCTAssertNil(PolicyBounds.validate(key: "risk_resize_live", value: 1))
        XCTAssertNotNil(PolicyBounds.validate(key: "risk_resize_live", value: 2))
    }

    func testBoundsMatchRunnerStaticMaxima() throws {
        let expected: [String: (Double, Double, Bool)] = [
            "size_fraction": (0, 0.5, false),
            "favorite_mult": (1, 10, true),
            "stake_ceiling_usd": (1, 500, false),
            "per_order_fraction": (0, 1.0, false),
            "cluster_fraction": (0, 1.0, false),
            "min_k": (0, 59, true),
            "edge_threshold_cents": (1, 50, false),
            "favorite_edge_threshold_cents": (0, 50, false),
            "min_depth": (1, 10000, true),
            "big_edge_cents": (0, 99, false),
            "big_edge_min_prob": (0.5, 1, false),
            "min_price_cents": (0, 99, true),
            "max_price_cents": (0, 99, true),
            "favorite_price_cents": (0, 99, true),
            "daily_loss_fraction": (0, 1.0, false),
            "drawdown_brake_fraction": (0, 1.0, false),
            "drawdown_stop_fraction": (0, 1.0, false),
            "cash_floor_cents": (0, 100000, true),
            "risk_resize_live": (0, 1, true),
            "exit_margin_cents": (0, 50, false),
            "exit_prob_ceiling": (0, 1, false),
            "exit_variance_scale": (1, 5, false),
            "exit_min_depth": (0, 10000, true),
            "exit_max_quote_age_ms": (0, 600000, true),
            "exit_min_hold_s": (0, 120, true),
            "reentry_block_s": (0, 900, true),
            "exit_min_hold_fraction": (0, 1, false),
            "conviction_min": (0.1, 1, false),
            "conviction_max": (1, 5, false),
            "target_win_cents": (0, 5000, true),
            "min_win_cents": (0, 5000, true)
        ]
        XCTAssertEqual(Set(expected.keys), Set(PolicyBounds.bounds.keys))
        for (key, value) in expected {
            let bound = try XCTUnwrap(PolicyBounds.bounds[key])
            XCTAssertEqual(bound.min, value.0, key)
            XCTAssertEqual(bound.max, value.1, key)
            XCTAssertEqual(bound.isInt, value.2, key)
        }
    }

    func testGroupingCoversEveryKeyOnce() {
        let groups = PolicyCatalog.grouped()
        XCTAssertEqual(groups.map(\.category), PolicyCategory.allCases)
        let keys = groups.flatMap(\.parameters).map(\.key)
        XCTAssertEqual(keys, PolicyCatalog.parameters.map(\.key))
        XCTAssertEqual(keys.count, Set(keys).count)
        XCTAssertTrue(groups.allSatisfy { !$0.parameters.isEmpty })
    }

    func testGroupedRespectsRequestedKeys() {
        let groups = PolicyCatalog.grouped(["min_k", "size_fraction", "min_k", "unknown"])
        XCTAssertEqual(groups.map(\.category), [.positionSizing, .entryRequirements])
        XCTAssertEqual(groups.flatMap(\.parameters).map(\.key), ["size_fraction", "min_k"])
        XCTAssertTrue(PolicyCatalog.grouped([]).isEmpty)
    }

    func testSearchMatchesNameConceptCategoryAndDescription() {
        func keys(_ query: String) -> Set<String> { Set(PolicyCatalog.search(query).map(\.key)) }
        XCTAssertTrue(keys("drawdown").isSuperset(of: ["drawdown_brake_fraction", "drawdown_stop_fraction"]))
        XCTAssertTrue(keys("percent").isSuperset(of: PolicyCatalog.parameters.filter { $0.unit == .fraction }.map(\.key)))
        XCTAssertTrue(keys("risk").isSuperset(of: PolicyCatalog.parameters.filter { $0.impact.contains(.risk) }.map(\.key)))
        XCTAssertEqual(keys("min_k"), ["min_k"])
        XCTAssertEqual(keys("  MIN K  "), ["min_k"])
        XCTAssertTrue(keys("mispricing").contains("edge_threshold_cents"))
        XCTAssertTrue(keys("capital one position").contains("size_fraction"))
        XCTAssertTrue(keys("zzz").isEmpty)
        XCTAssertEqual(PolicyCatalog.search("edge", in: ["edge_threshold_cents"]).map(\.key), ["edge_threshold_cents"])
    }

    func testSearchCombinesWordsAndIgnoresConnectors() throws {
        let size = try XCTUnwrap(PolicyCatalog.parameter(for: "size_fraction"))
        XCTAssertTrue(size.matches("capital for one position"))
        XCTAssertTrue(size.matches("  POSITION\tand\ncapital  "))
        XCTAssertFalse(size.matches("capital nonexistent position"))
        for query in ["", " \t\n ", "the and of"] {
            XCTAssertEqual(PolicyCatalog.search(query).map(\.key), PolicyCatalog.parameters.map(\.key))
        }
        XCTAssertTrue(Set(PolicyCatalog.search("position sizing").map(\.key)).isSuperset(of:
            PolicyCatalog.parameters.filter { $0.category == .positionSizing }.map(\.key)))
    }

    func testFormatterDisplays() throws {
        let cases: [(Double, PolicyUnit, String)] = [
            (0.1, .fraction, "10%"), (0.125, .fraction, "12.5%"),
            (0.8, .probability, "80%"),
            (1000, .centsAsDollars, "$10.00"), (100000, .centsAsDollars, "$1,000.00"),
            (3.5, .cents, "3.5¢"), (10, .cents, "10¢"), (25, .dollars, "$25.00"),
            (90, .seconds, "1 minute 30 seconds"), (1, .seconds, "1 second"),
            (120, .seconds, "2 minutes"), (250, .milliseconds, "250 ms"),
            (60000, .milliseconds, "1 minute"), (1000, .milliseconds, "1 second"),
            (1500, .milliseconds, "1.5 seconds"),
            (5, .contracts, "5 contracts"), (1, .contracts, "1 contract"),
            (2, .multiplier, "2×"), (1.5, .multiplier, "1.5×"), (12, .count, "12")
        ]
        for (value, unit, expected) in cases {
            XCTAssertEqual(PolicyValueFormatter.display(value, unit: unit), expected)
        }
        let maximum = try XCTUnwrap(PolicyCatalog.parameter(for: "max_price_cents"))
        XCTAssertEqual(PolicyValueFormatter.display(0, parameter: maximum), "Off")
        XCTAssertEqual(try XCTUnwrap(PolicyCatalog.parameter(for: "min_k")).rangeText, "0 to 59 observations")
    }

    func testFormatterRoundTrips() throws {
        for parameter in PolicyCatalog.parameters {
            let maximum = PolicyBounds.maximum(for: parameter)
            for value in [parameter.minimum, maximum, (parameter.minimum + maximum) / 2] {
                let display = PolicyValueFormatter.displayValue(fromAPI: value, unit: parameter.unit)
                XCTAssertEqual(PolicyValueFormatter.apiValue(fromDisplay: display, unit: parameter.unit), value, accuracy: 1e-9)
            }
        }
        let size = try XCTUnwrap(PolicyCatalog.parameter(for: "size_fraction"))
        let cash = try XCTUnwrap(PolicyCatalog.parameter(for: "cash_floor_cents"))
        let depth = try XCTUnwrap(PolicyCatalog.parameter(for: "min_depth"))
        let favorite = try XCTUnwrap(PolicyCatalog.parameter(for: "favorite_mult"))
        XCTAssertEqual(PolicyValueFormatter.parse("12.5%", parameter: size), 0.125)
        XCTAssertEqual(PolicyValueFormatter.parse("$10", parameter: cash), 1000)
        XCTAssertEqual(PolicyValueFormatter.parse("1,000", parameter: depth), 1000)
        XCTAssertNil(PolicyValueFormatter.parse("abc", parameter: size))
        XCTAssertNil(PolicyValueFormatter.parse("", parameter: size))
        XCTAssertNil(PolicyValueFormatter.parse("1,00", parameter: depth))
        XCTAssertNil(PolicyValueFormatter.parse("nan", parameter: size))
        XCTAssertEqual(PolicyValueFormatter.normalized(0.30000000000000004, parameter: size), 0.3)
        XCTAssertEqual(PolicyValueFormatter.normalized(2.4, parameter: favorite), 2)
    }

    func testFriendlyValidation() {
        XCTAssertEqual(PolicyBounds.validateFriendly(key: "size_fraction", value: 0.9), "Position size: enter a value between 0% and 50%.")
        XCTAssertEqual(PolicyBounds.validateFriendly(key: "min_k", value: 1.5), "Minimum observations needs a whole number.")
        XCTAssertEqual(PolicyBounds.validateFriendly(key: "unknown", value: 1), "This setting cannot be changed here.")
        XCTAssertEqual(PolicyBounds.validateFriendly(key: "min_k", value: .infinity), "Enter a finite number.")
        XCTAssertEqual(PolicyBounds.validate(key: "min_k", value: 1.5), "min_k requires a whole number.")
        XCTAssertEqual(PolicyBounds.validate(key: "min_k", value: 60), "min_k must be between 0.0 and 59.0.")
        XCTAssertEqual(PolicyBounds.validate(key: "unknown", value: 1), "Unknown policy key: unknown.")
        XCTAssertNil(PolicyBounds.validateFriendly(key: "min_k", value: 12))
    }

    func testGuidanceLabels() throws {
        let size = try XCTUnwrap(PolicyCatalog.parameter(for: "size_fraction"))
        let observations = try XCTUnwrap(PolicyCatalog.parameter(for: "min_k"))
        let maximum = try XCTUnwrap(PolicyCatalog.parameter(for: "max_price_cents"))
        XCTAssertEqual(PolicyGuidance.label(for: size, value: 0.4), .aggressive)
        XCTAssertEqual(PolicyGuidance.label(for: size, value: 0.01), .restrictive)
        XCTAssertNil(PolicyGuidance.label(for: size, value: 0.1))
        XCTAssertEqual(PolicyGuidance.label(for: observations, value: 45), .restrictive)
        XCTAssertEqual(PolicyGuidance.label(for: observations, value: 1), .aggressive)
        XCTAssertNil(PolicyGuidance.label(for: maximum, value: 99))
    }

    func testConflicts() throws {
        let cases: [(String, String, String, Double, Double, Double, Double, PolicyConflict.Severity)] = [
            ("drawdown-order", "drawdown_stop_fraction", "drawdown_brake_fraction", 0.1, 0.12, 0.25, 0.12, .error),
            ("favorite-edge-order", "favorite_edge_threshold_cents", "edge_threshold_cents", 5, 3.5, 3, 3.5, .error),
            ("price-order", "min_price_cents", "max_price_cents", 50, 40, 30, 40, .warning),
            ("conviction-order", "conviction_min", "conviction_max", 2, 1, 0.5, 2, .warning),
            ("win-order", "min_win_cents", "target_win_cents", 200, 100, 10, 100, .warning),
            ("favorite-price-order", "favorite_price_cents", "min_price_cents", 50, 60, 70, 60, .warning)
        ]
        for (id, first, second, badFirst, badSecond, goodFirst, goodSecond, severity) in cases {
            let conflict = try XCTUnwrap(PolicyConflicts.check([first: badFirst, second: badSecond]).first)
            XCTAssertEqual(conflict.id, id)
            XCTAssertEqual(conflict.severity, severity)
            XCTAssertEqual(Set(conflict.keys), [first, second])
            XCTAssertTrue(PolicyConflicts.check([first: goodFirst, second: goodSecond]).isEmpty)
            XCTAssertTrue(PolicyConflicts.check([first: badFirst]).isEmpty)
        }
        XCTAssertTrue(PolicyConflicts.check([:]).isEmpty)
        XCTAssertTrue(PolicyConflicts.check(["min_price_cents": 50, "max_price_cents": 0]).isEmpty)
        XCTAssertTrue(PolicyConflicts.check(["min_win_cents": 200, "target_win_cents": 0]).isEmpty)
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: fixtureData("engines"))
        let policy = try XCTUnwrap(response.engines?.first?.configuration?.global.policy)
        XCTAssertTrue(PolicyConflicts.check(policy).isEmpty)
    }
}
