import Foundation
import XCTest
@testable import LeafHFTCore

final class LiveBoardMathTests: XCTestCase {
    private func market(_ json: String) throws -> Market {
        try accountJSONDecoder().decode(Market.self, from: Data(json.utf8))
    }

    func testContractsAndWin() {
        XCTAssertEqual(LiveBoardMath.contracts(positionFp: "0.25")?.milli, 250)
        XCTAssertEqual(LiveBoardMath.contracts(positionFp: "-0.25")?.side, "no")
        XCTAssertEqual(LiveBoardMath.contracts(positionFp: "0.0005")?.milli, 1)
        XCTAssertNil(LiveBoardMath.contracts(positionFp: "0"))
        for malformed in ["", "NaN", "1oops", "1.2.3"] {
            XCTAssertNil(LiveBoardMath.decimal(malformed))
        }
        XCTAssertEqual(LiveBoardMath.winCents(contracts: Decimal(25) / 100,
            exposure: Decimal(30) / 100, fees: Decimal(1) / 1000), -6)
        XCTAssertEqual(LiveBoardMath.winCents(contracts: Decimal(25) / 100,
            exposure: Decimal(10) / 100, fees: nil), 15)
        XCTAssertNil(LiveBoardMath.winCents(contracts: 1, exposure: nil, fees: nil))
    }

    func testLiveMarkAndPnl() throws {
        var quote = try market(#"{"ticker":"A","status":"active","yes_bid_dollars":"0.40","yes_ask_dollars":"0.50","last_price_dollars":"0.80"}"#)
        let yes = try XCTUnwrap(LiveBoardMath.markDollars(market: quote, side: "yes"))
        let no = try XCTUnwrap(LiveBoardMath.markDollars(market: quote, side: "no"))
        XCTAssertEqual(yes, Decimal(45) / 100)
        XCTAssertEqual(no, Decimal(55) / 100)
        XCTAssertEqual(LiveBoardMath.pnlCents(contracts: 4, exposure: 1, fees: nil, mark: yes), 80)
        XCTAssertEqual(LiveBoardMath.pnlCents(contracts: -1, exposure: Decimal(40) / 100, fees: nil, mark: no), 15)
        XCTAssertEqual(LiveBoardMath.pnlCents(contracts: Decimal(1) / 100, exposure: 0, fees: nil, mark: yes), 0)
        XCTAssertEqual(LiveBoardMath.pnlCents(contracts: Decimal(25) / 100,
            exposure: Decimal(10) / 100, fees: nil, mark: yes), 1)
        XCTAssertEqual(LiveBoardMath.pnlCents(contracts: Decimal(25) / 100,
            exposure: Decimal(30) / 100, fees: Decimal(1) / 1000, mark: yes), -19)
        quote.yesAskDollars = "0.5001"
        XCTAssertEqual(LiveBoardMath.markDollars(market: quote, side: "yes"), Decimal(80) / 100)
        quote.lastPriceDollars = nil
        XCTAssertNil(LiveBoardMath.markDollars(market: quote, side: "yes"))
        XCTAssertNil(LiveBoardMath.pnlCents(contracts: 1, exposure: 0, fees: nil, mark: nil))
        XCTAssertNil(LiveBoardMath.pnlCents(contracts: 1, exposure: nil, fees: nil, mark: yes))
        quote.yesAskDollars = "0.50"
        quote.status = "settled"
        XCTAssertEqual(LiveBoardMath.markDollars(market: quote, side: "yes"), yes)
    }

    func testOddsBoundariesAndFallback() throws {
        var value = try market(#"{"ticker":"A","status":"active","yes_bid_dollars":"0.40","yes_ask_dollars":"0.50"}"#)
        XCTAssertEqual(LiveBoardMath.oddsPct(market: value, side: "yes"), 45)
        XCTAssertEqual(LiveBoardMath.oddsPct(market: value, side: "no"), 55)
        value.yesBidDollars = "0"
        XCTAssertNil(LiveBoardMath.oddsPct(market: value, side: "yes"))
        value.lastPriceDollars = "0.625"
        XCTAssertEqual(LiveBoardMath.oddsPct(market: value, side: "yes"), 62)
        value.yesBidDollars = "0.90"
        value.yesAskDollars = "1"
        XCTAssertEqual(LiveBoardMath.oddsPct(market: value, side: "yes"), 62)
        value.lastPriceDollars = "0.635"
        XCTAssertEqual(LiveBoardMath.oddsPct(market: value, side: "yes"), 64)
        value.lastPriceDollars = "1"
        XCTAssertEqual(LiveBoardMath.oddsPct(market: value, side: "yes"), 99)
        XCTAssertEqual(LiveBoardMath.oddsPct(market: value, side: "no"), 1)
        value.status = "settled"
        XCTAssertNil(LiveBoardMath.oddsPct(market: value, side: "yes"))
    }

    func testLedgerRoundingZeroCostAndDates() throws {
        var settlement = try accountJSONDecoder().decode(Settlement.self, from: Data(#"{"ticker":"A","yes_total_cost_dollars":"0.005","no_total_cost_dollars":"0.01","revenue":0,"fee_cost":"0.005","settled_time":"2026-09-29T04:00:00Z"}"#.utf8))
        let entry = try XCTUnwrap(LiveBoardMath.ledgerEntry(settlement: settlement))
        XCTAssertEqual(entry.pnlCents, -3)
        XCTAssertEqual(entry.pnlBps, -15000)
        settlement.yesTotalCostDollars = "0.03"
        settlement.noTotalCostDollars = "0"
        settlement.feeCost = "0"
        settlement.revenue = 2
        XCTAssertEqual(LiveBoardMath.ledgerEntry(settlement: settlement)?.pnlBps, -3333)
        settlement.yesTotalCostDollars = "0"
        XCTAssertNil(LiveBoardMath.ledgerEntry(settlement: settlement)?.pnlBps)
        settlement.revenue = 0
        XCTAssertNil(LiveBoardMath.ledgerEntry(settlement: settlement))
        settlement.revenue = 1
        settlement.settledTime = "2026-09-29T04:00:00.123Z"
        XCTAssertEqual(LiveBoardMath.ledgerEntry(settlement: settlement)?.at, entry.at)
        let midnight = Date(timeIntervalSince1970: TimeInterval(entry.at))
        XCTAssertEqual(LiveBoardMath.easternDayStart(for: midnight), midnight)
        XCTAssertEqual(LiveBoardMath.easternDayStart(for: midnight.addingTimeInterval(-1)),
                       midnight.addingTimeInterval(-86400))
    }

    func testLedgerMissingAndMalformedCosts() throws {
        let cases: [(String?, String?, Int, Int?)] = [
            ("0.10", nil, 15, 15000),
            (nil, "0.10", 15, 15000),
            (nil, nil, 25, nil),
            ("invalid", "0.10", 15, 15000),
            ("0.10", "invalid", 15, 15000)
        ]
        for (yes, no, pnlCents, pnlBps) in cases {
            var settlement = try accountJSONDecoder().decode(Settlement.self,
                from: Data(#"{"ticker":"A","revenue":25,"settled_time":"2026-09-29T04:00:00Z"}"#.utf8))
            settlement.yesTotalCostDollars = yes
            settlement.noTotalCostDollars = no
            let entry = try XCTUnwrap(LiveBoardMath.ledgerEntry(settlement: settlement))
            XCTAssertEqual(entry.pnlCents, pnlCents)
            XCTAssertEqual(entry.pnlBps, pnlBps)
        }
    }

    func testEndpointQueries() {
        let endpoint = KalshiGETEndpoint.markets(tickers: ["B", "", "A", "B"])
        XCTAssertEqual(endpoint.path, "/trade-api/v2/markets")
        XCTAssertEqual(endpoint.queryItems, [.init(name: "tickers", value: "A,B"), .init(name: "limit", value: "2")])
        let capped = KalshiGETEndpoint.markets(tickers: (0..<30).map { String(format: "T%02d", $0) })
        XCTAssertEqual(capped.queryItems[1].value, "20")
        XCTAssertEqual(capped.queryItems[0].value?.components(separatedBy: ",").last, "T19")
        // The cap keeps the caller's first 20, not the first 20 by name.
        let priority = ["Z-TOP"] + (0..<20).map { String(format: "T%02d", $0) }
        let kept = KalshiGETEndpoint.markets(tickers: priority).queryItems
        XCTAssertEqual(kept[1].value, "20")
        let keptTickers = kept[0].value?.components(separatedBy: ",") ?? []
        XCTAssertTrue(keptTickers.contains("Z-TOP"))
        XCTAssertFalse(keptTickers.contains("T19"))
        XCTAssertEqual(keptTickers, keptTickers.sorted())
        XCTAssertEqual(KalshiGETEndpoint.markets(tickers: ["B", "A", "B", "C"]).queryItems[0].value, "A,B,C")
        XCTAssertEqual(KalshiGETEndpoint.markets(tickers: []).queryItems,
                       [.init(name: "tickers", value: ""), .init(name: "limit", value: "0")])
        XCTAssertEqual(KalshiGETEndpoint.openPositions.path, KalshiGETEndpoint.positions.path)
        XCTAssertEqual(KalshiGETEndpoint.openPositions.queryItems,
                       [.init(name: "count_filter", value: "position"), .init(name: "limit", value: "200")])
        XCTAssertTrue(KalshiGETEndpoint.positions.queryItems.isEmpty)
    }

    func testMarketsFixture() throws {
        let response = try accountJSONDecoder().decode(MarketsResponse.self, from: fixtureData("markets"))
        let markets = try XCTUnwrap(response.markets)
        XCTAssertEqual(markets.count, 4)
        XCTAssertEqual(markets[0].yesSubTitle, "Rain tomorrow")
        XCTAssertEqual(LiveBoardMath.oddsPct(market: markets[1], side: "yes"), 62)
        XCTAssertNil(LiveBoardMath.oddsPct(market: markets[2], side: "yes"))
        XCTAssertEqual(markets[3].result, "yes")
        var invalid = markets[0]
        invalid.yesBidDollars = "0.3junk"
        XCTAssertNil(invalid.yesBid)
    }
}
