import Foundation
import XCTest
@testable import LeafHFTCore

final class RiskyBatmanTests: XCTestCase {
    func testVariantReturnPercentAndPrimaryPresentationRow() throws {
        let input = variantJSON
            .replacingOccurrences(of: "\"paper_pnl_cents\":-840", with: "\"paper_pnl_cents\":1234")
            .replacingOccurrences(of: "\"capital_basis_cents\":10000", with: "\"capital_basis_cents\":40000")
        let variant = try RiskyBatman.decoder().decode(RiskyBatman.Variant.self, from: Data(input.utf8))
        XCTAssertEqual(try XCTUnwrap(variant.returnPercent), 3.085, accuracy: 0.000001)
        let first = RiskyBatman.Presentation(variant: variant).rows.first
        XCTAssertEqual(first?.id, "return")
        XCTAssertEqual(first?.value, "3.085%")
        for capital in [0, -100] {
            let zero = input.replacingOccurrences(of: "\"capital_basis_cents\":40000", with: "\"capital_basis_cents\":\(capital)")
            XCTAssertNil(try RiskyBatman.decoder().decode(RiskyBatman.Variant.self, from: Data(zero.utf8)).returnPercent)
        }
        let mirror = input.replacingOccurrences(of: "\"state\":\"running\"", with: "\"state\":\"running\",\"mirror\":true")
        let gold = input.replacingOccurrences(of: "risky-batman-15m", with: "kalshi-gold-paper")
        for json in [mirror, gold] {
            let summary = try RiskyBatman.decoder().decode(RiskyBatman.Variant.self, from: Data(json.utf8))
            XCTAssertNil(summary.returnPercent)
            XCTAssertEqual(RiskyBatman.Presentation(variant: summary).rows.first?.value, "On system Gold capital")
        }
    }

    private func liveResponse(variant: String = "null") throws -> RiskyBatman.Response {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        // Variant timestamps are strings, so no Date decoding strategy is used.
        return try decoder.decode(RiskyBatman.Response.self, from: Data("""
        {"success":true,"engines":[{"engine_id":"risky-batman-15m","name":"Risky Batman 15m",
        "gate_minutes":60,"default_enabled":false,"live_available":false,
        "policy_bounds":{"min_k":{"lo":0,"hi":59,"kind":"int"},
          "per_order_fraction":{"lo":0.0,"hi":1.0,"kind":"float"},
          "edge_min_20_49_cents":{"lo":0.0,"hi":100.0,"kind":"float"}},
        "base_policy":{"min_k":30,"per_order_fraction":0.1,"edge_min_20_49_cents":5.0},
        "variant":\(variant)}],"warnings":["Simulated tuning overstates live results."]}
        """.utf8))
    }

    func testLiveReplyDecodesBoundsAndPreservesDictionaryKeys() throws {
        let reply = try liveResponse()
        let engine = try XCTUnwrap(reply.engines.first)
        XCTAssertEqual(reply.engines.count, 1)
        XCTAssertEqual(reply.warnings, ["Simulated tuning overstates live results."])
        XCTAssertEqual(engine.engineId, "risky-batman-15m")
        XCTAssertEqual(engine.gateMinutes, 60)
        XCTAssertFalse(engine.defaultEnabled)
        XCTAssertFalse(engine.liveAvailable)
        XCTAssertNil(engine.variant)
        XCTAssertEqual(Set(engine.policyBounds.keys), ["min_k", "per_order_fraction", "edge_min_20_49_cents"])
        XCTAssertEqual(engine.policyBounds["min_k"], .init(min: 0, max: 59, isInt: true))
        XCTAssertEqual(engine.policyBounds["per_order_fraction"], .init(min: 0, max: 1, isInt: false))
        XCTAssertEqual(engine.policyBounds["edge_min_20_49_cents"], .init(min: 0, max: 100, isInt: false))
        XCTAssertEqual(engine.basePolicy["edge_min_20_49_cents"], 5)
        XCTAssertEqual(engine.effectivePolicy, engine.basePolicy)
    }

    func testLiveReplyDecodesVariantWithNullOrAbsentOverrides() throws {
        let variant = """
        {"schema":"leafhft.account-shadow-summary.v1","account_id":"own-account",
        "engine_id":"risky-batman-15m","generation":4,"effective_policy_digest":"digest-at-generation-4",
        "state":"running","started_at":"2026-09-22T20:00:00Z","updated_at":"2026-09-22T20:13:00Z",
        "live_tail_seconds":780,"decisions":24,"entries":7,"wins":2,"losses":4,
        "paper_pnl_cents":-840,"max_drawdown_cents":1250,"worst_trade_cents":-600,
        "capital_basis_cents":10000,"reasons":[],"overrides":null,"eligible_minutes_remaining":47}
        """
        for input in [variant, variant.replacingOccurrences(of: "\"overrides\":null,", with: "")] {
            let engine = try XCTUnwrap(liveResponse(variant: input).engines.first)
            let summary = try XCTUnwrap(engine.variant)
            XCTAssertNil(summary.overrides)
            XCTAssertEqual(summary.schema, "leafhft.account-shadow-summary.v1")
            XCTAssertEqual(summary.accountId, "own-account")
            XCTAssertEqual(summary.engineId, engine.engineId)
            XCTAssertEqual(summary.generation, 4)
            XCTAssertEqual(summary.effectivePolicyDigest, "digest-at-generation-4")
            XCTAssertEqual(summary.state, "running")
            XCTAssertEqual(summary.startedAt, "2026-09-22T20:00:00Z")
            XCTAssertEqual(summary.updatedAt, "2026-09-22T20:13:00Z")
            XCTAssertEqual(summary.paperPnlCents, -840)
            XCTAssertEqual(summary.eligibleMinutesRemaining, 47)
            XCTAssertEqual(engine.effectivePolicy, engine.basePolicy)
        }
    }

    func testFrozenGoldRowIsListedWithoutAllowingShadowRequests() throws {
        let goldVariant = variantJSON
            .replacingOccurrences(of: "risky-batman-15m", with: "kalshi-gold-paper")
            .replacingOccurrences(of: "\"overrides\":{\"min_k\":20}", with: "\"overrides\":{}")
        let goldRow = """
        {"engine_id":"kalshi-gold-paper","name":"Gold 15m (paper, frozen)",
        "gate_minutes":60,"default_enabled":false,"live_available":false,
        "policy_bounds":{},"base_policy":{},"frozen":true,"variant":\(goldVariant)}
        """
        let reply = try RiskyBatman.decoder().decode(RiskyBatman.Response.self, from: Data("""
        {"engines":[{"engine_id":"risky-batman-15m","name":"Risky Batman 15m",
        "gate_minutes":60,"default_enabled":false,"live_available":false,
        "policy_bounds":{},"base_policy":{},"variant":\(variantJSON)},\(goldRow)],"warnings":[]}
        """.utf8))
        XCTAssertEqual(reply.engines.count, 2)
        let risky = try XCTUnwrap(reply.engines.first)
        let gold = try XCTUnwrap(reply.engines.last)
        XCTAssertEqual(risky.engineId, "risky-batman-15m")
        XCTAssertNil(risky.frozen)
        XCTAssertFalse(risky.isFrozen)
        XCTAssertTrue(RiskyBatman.isListed(risky))
        XCTAssertEqual(gold.engineId, "kalshi-gold-paper")
        XCTAssertTrue(gold.isFrozen)
        XCTAssertTrue(gold.policyBounds.isEmpty)
        XCTAssertTrue(gold.editableKeys.isEmpty)
        XCTAssertTrue(RiskyBatman.isListed(gold))
        XCTAssertEqual(try XCTUnwrap(gold.variant).engineId, gold.engineId)
        XCTAssertFalse(RiskyBatman.isEngine(gold.engineId))
        XCTAssertThrowsError(try RiskyBatman.ShadowRequest(engineId: gold.engineId, enabled: true))
        XCTAssertThrowsError(try RiskyBatman.ShadowRequest(engineId: gold.engineId, enabled: false))

        let nonFrozen = try RiskyBatman.decoder().decode(RiskyBatman.Engine.self, from: Data(
            goldRow.replacingOccurrences(of: "\"frozen\":true,", with: "").utf8))
        XCTAssertNil(nonFrozen.frozen)
        XCTAssertFalse(nonFrozen.isFrozen)
        XCTAssertFalse(RiskyBatman.isListed(nonFrozen))
    }

    func testLiveBoundRejectsUnknownKind() {
        let input = Data("""
        {"lo":0,"hi":59,"kind":"text"}
        """.utf8)
        XCTAssertThrowsError(try RiskyBatman.decoder().decode(RiskyBatman.Bound.self, from: input))
    }

    private func response(variant: String? = nil, liveAvailable: Bool = false) throws -> RiskyBatman.Response {
        let variantField = variant.map { ",\"variant\":\($0)" } ?? ""
        return try RiskyBatman.decoder().decode(RiskyBatman.Response.self, from: Data("""
        {"engines":[{"engine_id":"risky-batman-15m","name":"Risky Batman 15m",
        "gate_minutes":60,"default_enabled":false,"live_available":\(liveAvailable),
        "policy_bounds":{"size_fraction":{"min":0.1,"max":0.4,"is_int":false},
          "min_k":[2,40,true],"per_order_fraction":[0,0.3,false],"future_key":[0,1,false]},
        "base_policy":{"size_fraction":0.3,"min_k":30,"per_order_fraction":0.3,"future_key":0.5},
        "future_field":"ignored"\(variantField)}],"warnings":[],"future_response":true}
        """.utf8))
    }

    private var variantJSON: String {
        """
        {"schema":"leafhft.account-shadow-summary.v1","account_id":"own-account",
        "engine_id":"risky-batman-15m","generation":4,"effective_policy_digest":"digest-at-generation-4",
        "state":"running","started_at":"2026-09-22T07:00:00Z","updated_at":"2026-09-22T07:13:00Z",
        "live_tail_seconds":780,"decisions":24,"entries":7,"wins":2,"losses":4,
        "paper_pnl_cents":-840,"max_drawdown_cents":1250,"worst_trade_cents":-600,
        "capital_basis_cents":10000,"reasons":[],"overrides":{"min_k":20},
        "eligible_minutes_remaining":47,"future_variant":42}
        """
    }

    func testMissingAndNullVariantAreOffAndUnknownFieldsAreIgnored() throws {
        for input in [nil, "null"] as [String?] {
            let engine = try XCTUnwrap(response(variant: input).engines.first)
            XCTAssertNil(engine.variant)
            let display = RiskyBatman.Presentation(variant: engine.variant)
            XCTAssertEqual(display.state, "Off")
            XCTAssertEqual(display.countdown, "60 min of tuning left at these settings")
            XCTAssertTrue(display.rows.isEmpty)
        }
    }

    func testVariantDecodesPolicyKeysAndSoberingTelemetry() throws {
        let engine = try XCTUnwrap(response(variant: variantJSON).engines.first)
        let variant = try XCTUnwrap(engine.variant)
        XCTAssertEqual(variant.accountId, "own-account")
        XCTAssertEqual(variant.effectivePolicyDigest, "digest-at-generation-4")
        XCTAssertEqual(engine.effectivePolicy["min_k"], 20)
        XCTAssertEqual(engine.basePolicy["size_fraction"], 0.3)
        let display = RiskyBatman.Presentation(variant: variant, restarted: true)
        XCTAssertEqual(display.state, "Tuning running")
        XCTAssertEqual(display.countdown, "47 min of tuning left at these settings")
        XCTAssertEqual(display.restartNotice, "Tuning clock restarted after your change")
        let rows = Dictionary(uniqueKeysWithValues: display.rows.map { ($0.label, $0.value) })
        XCTAssertEqual(rows["Simulated P&L"], "-$8.40")
        XCTAssertEqual(rows["Max drawdown"], "$12.50")
        XCTAssertEqual(rows["Worst trade"], "-$6.00")
        XCTAssertEqual(rows["Wins"], "2")
        XCTAssertEqual(rows["Losses"], "4")
        XCTAssertEqual(rows["Loss rate"], "66.7%")
        XCTAssertEqual(rows["Decisions"], "24")
        XCTAssertEqual(rows["Capital basis"], "$100.00")
        XCTAssertEqual(rows["Minutes at these settings"], "13")
    }

    func testTuningCountdownNeverUsesWallClockEvenWhenServerSaysLiveAvailable() throws {
        let engine = try XCTUnwrap(response(variant: variantJSON, liveAvailable: true).engines.first)
        XCTAssertTrue(engine.liveAvailable)
        var variant = try XCTUnwrap(engine.variant)
        variant.state = "delayed"
        variant.liveTailSeconds = 779
        variant.eligibleMinutesRemaining = 0
        variant.startedAt = "2000-01-01T00:00:00Z"
        XCTAssertEqual(RiskyBatman.Presentation(variant: variant).countdown, "48 min of tuning left at these settings")
        XCTAssertEqual(RiskyBatman.Presentation(variant: variant).state, "Tuning delayed")
        variant.liveTailSeconds = 7200
        XCTAssertEqual(RiskyBatman.Presentation(variant: variant).countdown, "0 min of tuning left at these settings")
        variant.liveTailSeconds = -30
        XCTAssertEqual(RiskyBatman.Presentation(variant: variant).countdown, "60 min of tuning left at these settings")
    }

    func testUnknownStatesAndEmptyTradeSamplesStayHonest() throws {
        var variant = try XCTUnwrap(response(variant: variantJSON).engines.first?.variant)
        variant.state = "future-state"
        variant.wins = 0
        variant.losses = 0
        let display = RiskyBatman.Presentation(variant: variant)
        XCTAssertEqual(display.state, "Tuning status unknown")
        XCTAssertEqual(display.rows.first { $0.id == "lossRate" }?.value, "No closed trades")
    }

    func testPublishedBoundsCanTightenButCannotRelaxHardMaxima() throws {
        let engine = try XCTUnwrap(response().engines.first)
        XCTAssertEqual(engine.editableBound(for: "size_fraction"), .init(min: 0.1, max: 0.4, isInt: false))
        XCTAssertEqual(engine.editableBound(for: "min_k"), .init(min: 2, max: 40, isInt: true))
        XCTAssertEqual(engine.editableBound(for: "per_order_fraction")?.max, 0.1)
        XCTAssertFalse(engine.editableKeys.contains("future_key"))
    }

    func testOwnerEnvelopeAllowsPublishedRiskBoundsAndSavedPolicy() throws {
        let owner = RiskEnvelope(maxima: RiskEnvelope.hardMaxima.mapValues { _ in 1.0 })
        let engine = try RiskyBatman.decoder().decode(RiskyBatman.Engine.self, from: Data("""
        {"engine_id":"risky-batman-15m","name":"Risky Batman 15m",
         "gate_minutes":60,"default_enabled":false,"live_available":false,
         "policy_bounds":{"per_order_fraction":[0,1,false]},
         "base_policy":{"per_order_fraction":0.125}}
        """.utf8))
        XCTAssertEqual(engine.editableBound(for: "per_order_fraction"), .init(min: 0, max: 0.10, isInt: false))
        XCTAssertEqual(engine.editableBound(for: "per_order_fraction", envelope: owner), .init(min: 0, max: 1, isInt: false))
        XCTAssertTrue(engine.editableKeys(envelope: owner).contains("per_order_fraction"))
    }

    func testShadowRequestHonoursOwnerEnvelope() throws {
        let owner = RiskEnvelope(maxima: RiskEnvelope.hardMaxima.mapValues { _ in 1.0 })
        XCTAssertNoThrow(try RiskyBatman.ShadowRequest(engineId: "risky-batman-15m", enabled: true,
            set: ["per_order_fraction": 0.125], envelope: owner))
        XCTAssertThrowsError(try RiskyBatman.ShadowRequest(engineId: "risky-batman-15m", enabled: true,
            set: ["per_order_fraction": 0.125]))
    }

    func testPublishedNumericTypeBoundsDecode() throws {
        for input in ["[0,59,\"int\"]", "{\"min\":0,\"max\":59,\"type\":\"int\"}"] {
            let bound = try RiskyBatman.decoder().decode(RiskyBatman.Bound.self, from: Data(input.utf8))
            XCTAssertEqual(bound, .init(min: 0, max: 59, isInt: true))
        }
    }

    func testShadowBodyIsAccountScopedByServerAndPaperOnly() throws {
        let uuid = try XCTUnwrap(UUID(uuidString: "A4E4C785-79F0-46C7-9C32-41A4A8F40161"))
        let request = try RiskyBatman.ShadowRequest(engineId: "risky-batman-15m", enabled: true,
            set: ["size_fraction": 0.25], unset: ["min_k"], clientRequestId: uuid)
        for strategy in [JSONEncoder.KeyEncodingStrategy.useDefaultKeys, .convertToSnakeCase] {
            let encoder = JSONEncoder()
            encoder.keyEncodingStrategy = strategy
            let object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoder.encode(request)) as? [String: Any])
            XCTAssertEqual(Set(object.keys), ["kind", "client_request_id", "value"])
            XCTAssertEqual(object["kind"] as? String, "engine.shadow")
            XCTAssertEqual(object["client_request_id"] as? String, uuid.uuidString)
            let value = try XCTUnwrap(object["value"] as? [String: Any])
            XCTAssertEqual(value["engine_id"] as? String, "risky-batman-15m")
            XCTAssertEqual(value["enabled"] as? Bool, true)
            XCTAssertEqual(value["consent"] as? String, "paper")
            XCTAssertEqual(value["set"] as? [String: Double], ["size_fraction": 0.25])
            XCTAssertEqual(value["unset"] as? [String], ["min_k"])
            XCTAssertNil(value["scope"])
            XCTAssertNil(value["account_id"])
        }
        let stop = try RiskyBatman.ShadowRequest(engineId: "risky-batman-15m", enabled: false)
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(stop)) as? [String: Any])
        let value = try XCTUnwrap(object["value"] as? [String: Any])
        XCTAssertNil(value["set"])
        XCTAssertNil(value["unset"])
        XCTAssertEqual(value["consent"] as? String, "paper")
    }

    func testInvalidPaperRequestsAreRejectedBeforeEncoding() {
        XCTAssertThrowsError(try RiskyBatman.ShadowRequest(engineId: "default", enabled: true))
        XCTAssertThrowsError(try RiskyBatman.ShadowRequest(engineId: "risky-batman-15m", enabled: false, set: ["min_k": 3]))
        XCTAssertThrowsError(try RiskyBatman.ShadowRequest(engineId: "risky-batman-15m", enabled: true, set: ["min_k": 3.5]))
        XCTAssertThrowsError(try RiskyBatman.ShadowRequest(engineId: "risky-batman-15m", enabled: true, set: ["size_fraction": .nan]))
        XCTAssertThrowsError(try RiskyBatman.ShadowRequest(engineId: "risky-batman-15m", enabled: true, set: ["per_order_fraction": 0.3]))
        XCTAssertThrowsError(try RiskyBatman.ShadowRequest(engineId: "risky-batman-15m", enabled: true, set: ["min_k": 3], unset: ["min_k"]))
    }

    func testShadowAcknowledgementDoesNotRequireLegacyControlValue() throws {
        let response = try RiskyBatman.decoder().decode(RiskyBatman.ShadowResponse.self, from: Data("""
        {"request":{"id":"request-1","state":"requested","value":{"engine_id":"risky-batman-15m",
        "enabled":true,"consent":"paper"}}}
        """.utf8))
        XCTAssertEqual(response.request.id, "request-1")
        XCTAssertEqual(response.request.state, "requested")
    }

    // MARK: The probe control (plan D8, I6)

    private func lifecycle(_ json: String) throws -> EngineLifecycle {
        try accountJSONDecoder().decode(EngineLifecycle.self, from: Data(json.utf8))
    }

    private func eligibility(_ json: String) throws -> ProbeEligibility {
        try JSONDecoder().decode(ProbeEligibility.self, from: Data(json.utf8))
    }

    func testProbeControlReadsTheRunnerLifecycle() throws {
        let off = RiskyBatman.ProbeControl(lifecycle: nil, markets: ["BTC-15M", "ETH-15M", "BTC-15M", ""], eligibility: nil)
        XCTAssertEqual(off.state, "Not probing")
        XCTAssertEqual(off.tone, .neutral)
        XCTAssertEqual(off.breaker, "Breaker: Not reported")
        XCTAssertEqual(off.markets, ["BTC-15M", "ETH-15M"])
        XCTAssertTrue(off.showsProbe)
        XCTAssertTrue(off.canProbe)
        XCTAssertNil(off.probeBlockedReason)
        XCTAssertFalse(off.canHalt)

        let probing = RiskyBatman.ProbeControl(lifecycle: try lifecycle("""
            {"state":"probe","entries_enabled":true,
             "breaker":{"engine_pct":50,"inherited":true,"engine_loss_cents":1240,"engine_limit_cents":125000}}
            """), markets: ["BTC-1H"], eligibility: nil)
        XCTAssertEqual(probing.state, "Probing")
        XCTAssertEqual(probing.tone, .active)
        XCTAssertEqual(probing.breaker, "Breaker: -$12.40 of $1,250.00 (50%) · UTC day")
        XCTAssertFalse(probing.showsProbe)
        XCTAssertFalse(probing.canProbe)
        XCTAssertTrue(probing.canHalt)

        let sized = RiskyBatman.ProbeControl(lifecycle: try lifecycle(#"{"state":"probe_sized","contracts":2}"#),
                                             markets: ["BTC-1H"], eligibility: nil)
        XCTAssertEqual(sized.state, "Probing at 2 contracts")
        XCTAssertTrue(sized.canHalt)

        // A breaker trip suspends entries until 00:00Z; it is not a halt, so Halt stays available.
        let suspended = RiskyBatman.ProbeControl(lifecycle: try lifecycle("""
            {"state":"probe","entries_enabled":false,"entries_suspended_until":"2026-09-24T00:00:00Z",
             "stop_reasons":[{"code":"breaker_engine","text":"This engine's day loss reached 50% of the day-start portfolio."}]}
            """), markets: ["BTC-1H"], eligibility: nil)
        XCTAssertEqual(suspended.state, "Suspended until 00:00Z")
        XCTAssertEqual(suspended.tone, .warning)
        XCTAssertEqual(suspended.reasons, ["This engine's day loss reached 50% of the day-start portfolio."])
        XCTAssertFalse(suspended.showsProbe)
        XCTAssertTrue(suspended.canHalt)

        let halted = RiskyBatman.ProbeControl(lifecycle: try lifecycle(#"{"state":"halted","stop_reasons":["owner_halt"]}"#),
                                              markets: ["BTC-1H"], eligibility: nil)
        XCTAssertEqual(halted.state, "Entries halted, settlement only")
        XCTAssertEqual(halted.tone, .stopped)
        XCTAssertEqual(halted.reasons, ["owner_halt"])
        XCTAssertTrue(halted.showsProbe)
        XCTAssertTrue(halted.canProbe)
        XCTAssertFalse(halted.canHalt)

        let graduated = RiskyBatman.ProbeControl(lifecycle: try lifecycle(#"{"state":"graduated"}"#), markets: nil, eligibility: nil)
        XCTAssertEqual(graduated.state, "Graduated")
        XCTAssertFalse(graduated.showsProbe)
        XCTAssertTrue(graduated.canHalt)
    }

    func testProbeFailsClosedWithoutMarketsWhenIneligibleOrFrozen() throws {
        let unpublished = RiskyBatman.ProbeControl(lifecycle: nil, markets: nil, eligibility: nil)
        XCTAssertTrue(unpublished.showsProbe)
        XCTAssertFalse(unpublished.canProbe)
        XCTAssertEqual(unpublished.probeBlockedReason, "Markets are not published for this engine.")

        let ineligible = RiskyBatman.ProbeControl(lifecycle: nil, markets: ["BTC-15M"],
            eligibility: try eligibility(#"{"eligible":false,"reasons":["Feeds are not provisioned."]}"#))
        XCTAssertFalse(ineligible.canProbe)
        XCTAssertEqual(ineligible.probeBlockedReason, "Feeds are not provisioned.")

        let silent = RiskyBatman.ProbeControl(lifecycle: nil, markets: ["BTC-15M"],
            eligibility: try eligibility(#"{"eligible":false}"#))
        XCTAssertEqual(silent.probeBlockedReason, "The runner reports this engine is not eligible to probe.")

        let frozen = RiskyBatman.ProbeControl(lifecycle: try lifecycle(#"{"state":"probe"}"#), markets: ["BTC-15M"],
                                              eligibility: nil, frozen: true)
        XCTAssertFalse(frozen.showsProbe)
        XCTAssertFalse(frozen.canProbe)
        XCTAssertFalse(frozen.canHalt)
    }

    func testProbePostsEngineProbeWithTheApprovalLeftForKM5() throws {
        let uuid = try XCTUnwrap(UUID(uuidString: "11111111-1111-4111-8111-111111111111"))
        let now = try XCTUnwrap(ISO8601DateFormatter().date(from: "2026-09-23T04:00:00Z"))
        let intent = try RiskyBatman.probeIntent(engineId: "risky-batman-15m", markets: ["BTC-15M", "ETH-15M"],
                                                 now: now, clientRequestId: uuid)
        XCTAssertEqual(intent.kind, .probe)
        XCTAssertNil(intent.host)
        XCTAssertNil(intent.scope)
        XCTAssertEqual(intent.venue, "kalshi")
        XCTAssertEqual(intent.clientRequestId, uuid.uuidString)
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        let body = String(decoding: try encoder.encode(intent), as: UTF8.self)
        XCTAssertEqual(body, #"{"client_request_id":"11111111-1111-4111-8111-111111111111","kind":"engine.probe","value":{"bind":false,"engine_id":"risky-batman-15m","expires_at":"2026-10-14T04:00:00Z","symbols":["BTC-15M","ETH-15M"]},"venue":"kalshi"}"#)
        XCTAssertFalse(body.contains("approval"))

        XCTAssertThrowsError(try RiskyBatman.probeIntent(engineId: "aggr-2", markets: ["BTC-15M"], now: now, clientRequestId: uuid))
        XCTAssertThrowsError(try RiskyBatman.probeIntent(engineId: "risky-batman-15m", markets: [], now: now, clientRequestId: uuid))
        XCTAssertThrowsError(try RiskyBatman.probeIntent(engineId: "risky-batman-15m", markets: ["BTC-15M", "BTC-15M"],
                                                         now: now, clientRequestId: uuid))
        XCTAssertThrowsError(try RiskyBatman.probeIntent(engineId: "risky-batman-15m", markets: ["BTC 15M"], now: now,
                                                         clientRequestId: uuid))
    }

    func testHaltIsUnsignedAndLimitedToRiskyEngines() throws {
        let uuid = try XCTUnwrap(UUID(uuidString: "11111111-1111-4111-8111-111111111111"))
        let halt = try RiskyBatman.haltIntent(engineId: "risky-batman-1h", clientRequestId: uuid)
        XCTAssertEqual(halt.kind, .halt)
        XCTAssertEqual(halt.value, .halt(HaltControlValue(engineId: "risky-batman-1h", reason: RiskyBatman.haltReason)))
        XCTAssertEqual(halt.clientRequestId, uuid.uuidString)
        XCTAssertThrowsError(try RiskyBatman.haltIntent(engineId: "default", clientRequestId: uuid))
    }

    func testControlMessagesFollowRequestedAppliedRejected() {
        XCTAssertEqual(RiskyBatman.controlMessage(action: "Probe", state: nil, note: nil), "Probe requested. Waiting for the runner.")
        XCTAssertEqual(RiskyBatman.controlMessage(action: "Probe", state: "requested", note: nil), "Probe requested. Waiting for the runner.")
        XCTAssertEqual(RiskyBatman.controlMessage(action: "Probe", state: "applied", note: "ok"), "Probe applied.")
        XCTAssertEqual(RiskyBatman.controlMessage(action: "Probe", state: "rejected", note: "No signed approval."),
                       "Probe rejected. No signed approval.")
        XCTAssertEqual(RiskyBatman.controlMessage(action: "Halt", state: "REJECTED", note: " "), "Halt rejected. Refresh and try again.")
        XCTAssertEqual(RiskyBatman.controlMessage(action: "Halt", state: "failed", note: "Runner offline."), "Halt failed. Runner offline.")
    }

    // MARK: The hedge mode (plan v1.9 H2c)

    func testHedgeModeDecodesAsOptionalIntAndRoundTrips() throws {
        let modes = try JSONDecoder().decode([RiskyBatman.HedgeMode].self, from: Data(#"[null,1,2,7,"two",1.5]"#.utf8))
        XCTAssertEqual(modes, [.legacy, .hedgeFirst, .cashoutFirst, .unknown(7), .unknown(nil), .unknown(nil)])
        XCTAssertEqual(modes.map(\.rawValue), [nil, 1, 2, 7, nil, nil])
        XCTAssertEqual(modes.map(\.label), ["Not set", "Hedge first (entry autosizing)", "Cash out first",
                                            "Not reported", "Not reported", "Not reported"])
        XCTAssertEqual(modes.map(\.isKnown), [true, true, true, false, false, false])

        // The three values plus null and an unknown integer survive a round trip byte for byte.
        let known: [RiskyBatman.HedgeMode] = [.legacy, .hedgeFirst, .cashoutFirst, .unknown(7)]
        let encoded = try JSONEncoder().encode(known)
        XCTAssertEqual(String(decoding: encoded, as: UTF8.self), "[null,1,2,7]")
        XCTAssertEqual(try JSONDecoder().decode([RiskyBatman.HedgeMode].self, from: encoded), known)

        struct Row: Decodable { let reversalExecutionMode: RiskyBatman.HedgeMode? }
        let decoder = RiskyBatman.decoder()
        for (json, expected) in [(#"{"reversal_execution_mode":2}"#, RiskyBatman.HedgeMode.cashoutFirst),
                                 (#"{"reversal_execution_mode":1}"#, .hedgeFirst),
                                 (#"{"reversal_execution_mode":9}"#, .unknown(9))] {
            XCTAssertEqual(try decoder.decode(Row.self, from: Data(json.utf8)).reversalExecutionMode, expected, json)
        }
        XCTAssertEqual(try decoder.decode(Row.self, from: Data(#"{"reversal_execution_mode":null}"#.utf8))
            .reversalExecutionMode ?? .legacy, .legacy)
        XCTAssertNil(try decoder.decode(Row.self, from: Data("{}".utf8)).reversalExecutionMode)
    }

    func testHedgeModeRulesAreOneSentenceWithoutDashes() {
        let all: [RiskyBatman.HedgeMode] = [.legacy, .hedgeFirst, .cashoutFirst, .unknown(nil)]
        XCTAssertEqual(Set(all.map(\.slug)).count, all.count)
        for mode in all {
            XCTAssertFalse(mode.rule.isEmpty)
            XCTAssertTrue(mode.rule.hasSuffix("."), mode.rule)
            XCTAssertEqual(mode.rule.filter { $0 == "." }.count, 1, mode.rule)
            for dash in ["\u{2014}", "\u{2013}", " - "] {
                XCTAssertFalse(mode.rule.contains(dash), mode.rule)
                XCTAssertFalse(mode.label.contains(dash), mode.label)
            }
        }
        XCTAssertEqual(RiskyBatman.HedgeMode.choices, [.hedgeFirst, .cashoutFirst])
    }

    private func runnerRow(_ json: String) throws -> Engine {
        try accountJSONDecoder().decode(Engine.self, from: Data(json.utf8))
    }

    func testHedgeModeIsReadFromTheRunnerStatusNeverGuessed() throws {
        XCTAssertEqual(RiskyBatman.HedgeMode.reported(by: nil), .unknown(nil))
        XCTAssertEqual(RiskyBatman.HedgeMode.reported(by: try runnerRow(#"{"engine_id":"risky-batman-15m"}"#)), .unknown(nil))
        XCTAssertEqual(RiskyBatman.HedgeMode.reported(by: try runnerRow("""
            {"engine_id":"risky-batman-15m","policy":{"min_k":30}}
            """)), .legacy)
        XCTAssertEqual(RiskyBatman.HedgeMode.reported(by: try runnerRow("""
            {"engine_id":"risky-batman-15m","policy":{"min_k":30,"reversal_execution_mode":1}}
            """)), .hedgeFirst)
        // The engine controls' global policy is the runner's current configuration and wins over the status policy.
        XCTAssertEqual(RiskyBatman.HedgeMode.reported(by: try runnerRow("""
            {"engine_id":"risky-batman-15m","policy":{"reversal_execution_mode":1},
             "configuration":{"global":{"enabled":true,"policy":{"reversal_execution_mode":2},"revision":"rev-7"},"accounts":[]}}
            """)), .cashoutFirst)
        XCTAssertEqual(RiskyBatman.HedgeMode.reported(by: try runnerRow("""
            {"engine_id":"risky-batman-15m","policy":{"reversal_execution_mode":1.5}}
            """)), .unknown(nil))
        XCTAssertEqual(RiskyBatman.HedgeMode.reported(by: try runnerRow("""
            {"engine_id":"risky-batman-15m","policy":{"reversal_execution_mode":3}}
            """)), .unknown(3))
    }

    func testOnlyTheOwnerOrTheAssignedLaneMayChangeTheHedgeMode() {
        let assigned = EngineAssignment(accountId: "lane-a", domain: nil, role: nil, since: nil, account: nil)
        XCTAssertTrue(RiskyBatman.HedgeMode.canChange(isOwner: true, laneId: nil, assignment: nil))
        XCTAssertTrue(RiskyBatman.HedgeMode.canChange(isOwner: false, laneId: "lane-a", assignment: assigned))
        XCTAssertFalse(RiskyBatman.HedgeMode.canChange(isOwner: false, laneId: "lane-b", assignment: assigned))
        XCTAssertFalse(RiskyBatman.HedgeMode.canChange(isOwner: false, laneId: nil, assignment: assigned))
        XCTAssertFalse(RiskyBatman.HedgeMode.canChange(isOwner: false, laneId: "", assignment:
            EngineAssignment(accountId: "", domain: nil, role: nil, since: nil, account: nil)))
        XCTAssertFalse(RiskyBatman.HedgeMode.canChange(isOwner: false, laneId: "lane-a", assignment: nil))
    }

    func testHedgeModePostsEngineConfigureWithTheExactBody() throws {
        let uuid = try XCTUnwrap(UUID(uuidString: "11111111-1111-4111-8111-111111111111"))
        let intent = try RiskyBatman.hedgeModeIntent(engineId: "risky-batman-15m", mode: .cashoutFirst,
            host: "sample-runner", scope: .global, expectedRevision: "rev-7", clientRequestId: uuid)
        XCTAssertEqual(intent.kind, .configure)
        XCTAssertEqual(intent.value, .configure(EngineConfigureValue(engineId: "risky-batman-15m",
            set: ["reversal_execution_mode": 2], unset: nil, enabledChange: .unchanged)))
        XCTAssertEqual(intent.host, "sample-runner")
        XCTAssertEqual(intent.venue, "kalshi")
        XCTAssertEqual(intent.scope, .global)
        XCTAssertEqual(intent.clientRequestId, uuid.uuidString)
        XCTAssertEqual(intent.expectedRevision, "rev-7")

        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoder.encode(intent)) as? [String: Any])
        XCTAssertEqual(Set(object.keys), ["kind", "value", "host", "venue", "scope", "client_request_id", "expected_revision"])
        XCTAssertEqual(object["kind"] as? String, "engine.configure")
        let value = try XCTUnwrap(object["value"] as? [String: Any])
        XCTAssertEqual(Set(value.keys), ["engine_id", "set"])
        XCTAssertEqual(value["engine_id"] as? String, "risky-batman-15m")
        let set = try XCTUnwrap(value["set"] as? [String: Any])
        XCTAssertEqual(Set(set.keys), ["reversal_execution_mode"])
        XCTAssertEqual((set["reversal_execution_mode"] as? NSNumber)?.intValue, 2)
        XCTAssertEqual(object["scope"] as? [String: String], ["kind": "global"])

        // A request round trips through the request list decoded by kind, so it never reads as another kind's body.
        let listed = try RiskyBatman.decoder().decode(ControlRequest.self, from: Data("""
            {"id":"request-1","kind":"engine.configure","value":{"engine_id":"risky-batman-15m",
             "set":{"reversal_execution_mode":1}},"client_request_id":"\(uuid.uuidString)","state":"rejected",
             "note":"The runner refused the mode change."}
            """.utf8))
        XCTAssertEqual(listed.value, .configure(EngineConfigureValue(engineId: "risky-batman-15m",
            set: ["reversal_execution_mode": 1], unset: nil, enabledChange: .unchanged)))
        XCTAssertEqual(RiskyBatman.controlMessage(action: RiskyBatman.HedgeMode.hedgeFirst.label, state: listed.state,
                                                  note: listed.note),
                       "Hedge first (entry autosizing) rejected. The runner refused the mode change.")

        let account = try RiskyBatman.hedgeModeIntent(engineId: "risky-batman-1h", mode: .hedgeFirst,
            host: "sample-runner", scope: .account("lane-a"), expectedRevision: "rev-8", clientRequestId: uuid)
        XCTAssertEqual(account.scope, try .account("lane-a"))
    }

    func testHedgeModeRequestsFailClosed() throws {
        let uuid = try XCTUnwrap(UUID(uuidString: "11111111-1111-4111-8111-111111111111"))
        func build(engineId: String = "risky-batman-15m", mode: RiskyBatman.HedgeMode = .hedgeFirst,
                   host: String = "sample-runner", scope: ControlScope = .global, revision: String = "rev-7") throws {
            _ = try RiskyBatman.hedgeModeIntent(engineId: engineId, mode: mode, host: host, scope: scope,
                                                expectedRevision: revision, clientRequestId: uuid)
        }
        XCTAssertNoThrow(try build())
        XCTAssertThrowsError(try build(engineId: "default"))
        XCTAssertThrowsError(try build(engineId: "kalshi-gold-paper"))
        XCTAssertThrowsError(try build(mode: .legacy))
        XCTAssertThrowsError(try build(mode: .unknown(3)))
        XCTAssertThrowsError(try build(mode: .unknown(nil)))
        XCTAssertThrowsError(try build(host: ""))
        XCTAssertThrowsError(try build(revision: ""))
        XCTAssertThrowsError(try build(scope: ControlScope(kind: .account, accountId: "unassigned")))
        XCTAssertThrowsError(try build(scope: ControlScope(kind: .global, accountId: "lane-a")))
    }

    /// No paper-as-verdict copy in the Swift sources this slice owns, this file included. The needles are split
    /// so that the list itself does not match.
    func testNoPaperAsVerdictCopyInOwnedSources() throws {
        let ios = URL(fileURLWithPath: #filePath)
            .deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
            .deletingLastPathComponent().deletingLastPathComponent()
        let owned = ["LeafHFT/Views/RiskyBatmanSection.swift", "LeafHFT/Model/RiskyBatmanState.swift",
                     "Packages/LeafHFTCore/Sources/LeafHFTCore/RiskyBatman.swift",
                     "Packages/LeafHFTCore/Tests/LeafHFTCoreTests/RiskyBatmanTests.swift",
                     "LeafHFTUITests/RiskyBatmanUITests.swift", "LeafHFTUITests/EngineLabUITests.swift"]
        let needles = ["paper" + " result", "paper" + " P&L", "simulated" + " profit", "Deploy" + " live"]
        for path in owned {
            let text = try String(contentsOf: ios.appendingPathComponent(path), encoding: .utf8)
            XCTAssertFalse(text.isEmpty, path)
            for needle in needles {
                XCTAssertNil(text.range(of: needle, options: .caseInsensitive), "\(path) contains \"\(needle)\"")
            }
        }
        XCTAssertEqual(RiskyBatman.tuningTitle, "Offline tuning (simulated)")
    }
}
