import Foundation
import XCTest
@testable import LeafHFTCore

final class AccountHistoryTests: XCTestCase {
    func testSelectedMatchesLinearFilterAcrossLargeHistory() {
        let start = Date(timeIntervalSince1970: 1_800_000_000)
        let observations = (0..<5000).map {
            AccountObservation(capturedAt: start.addingTimeInterval(Double($0) * 3600),
                               source: .runner, cashCents: $0)
        }
        var series = Series(source: .runner)
        series.merge(observations)
        let durations: [HistoryRange: TimeInterval] = [
            .hour: 3600, .fourHours: 14400, .twelveHours: 43200,
            .day: 86400, .week: 604800, .month: 2592000
        ]
        for offset in [-1.0, 2500, 5000] {
            let now = start.addingTimeInterval(offset * 3600)
            for range in HistoryRange.allCases {
                let lower = durations[range].map { now.addingTimeInterval(-$0) }
                let linear = observations.filter { observation in
                    observation.capturedAt <= now && (lower.map { observation.capturedAt >= $0 } ?? true)
                }
                XCTAssertEqual(series.selected(range, now: now), linear, "\(range.label) at \(offset)")
                if offset == 2500, let lower {
                    XCTAssertEqual(linear.first?.capturedAt, lower)
                    XCTAssertEqual(linear.last?.capturedAt, now)
                }
            }
        }
    }

    func testCashFloorPolicyReadsPolicyAndFallsBack() {
        XCTAssertEqual(CashFloorPolicy.cents(policy: ["cash_floor_cents": 2500]), 2500)
        XCTAssertEqual(CashFloorPolicy.cents(policy: ["cash_floor_cents": 2500.6]), 2501)
        XCTAssertEqual(CashFloorPolicy.cents(policy: ["cash_floor_cents": 0]), 0)
        XCTAssertEqual(CashFloorPolicy.cents(policy: ["cash_floor_cents": 100_000]), 100_000)
        XCTAssertNil(CashFloorPolicy.cents(policy: nil))
        XCTAssertNil(CashFloorPolicy.cents(policy: [:]))
        XCTAssertNil(CashFloorPolicy.cents(policy: ["cash_floor_cents": -1]))
        XCTAssertNil(CashFloorPolicy.cents(policy: ["cash_floor_cents": .nan]))
        XCTAssertNil(CashFloorPolicy.cents(policy: ["cash_floor_cents": .infinity]))
        XCTAssertNil(CashFloorPolicy.cents(policy: ["cash_floor_cents": 100_001]))
        XCTAssertEqual(CashFloorPolicy.cents(policy: nil) ?? CashFloorPolicy.fallbackCents, 1000)
    }

    func testMergeKeepsOrderWithoutResortingAppends() {
        var series = Series(source: .phone, exchangeIndex: 2)
        let start = Date(timeIntervalSince1970: 1000)
        let ascending = [0.0, 60, 120].map {
            AccountObservation(capturedAt: start.addingTimeInterval($0), source: .phone,
                               exchangeIndex: 2, cashCents: 100)
        }
        series.merge(ascending)
        XCTAssertEqual(series.observations, ascending)
        let earlier = AccountObservation(capturedAt: start.addingTimeInterval(-60), source: .phone,
                                         exchangeIndex: 2, cashCents: 50)
        let duplicate = AccountObservation(capturedAt: start, source: .phone,
                                           exchangeIndex: 2, cashCents: 999)
        series.merge([earlier, duplicate])
        XCTAssertEqual(series.observations.count, 4)
        XCTAssertEqual(series.observations, [earlier] + ascending)
        XCTAssertEqual(series.observations[1].cashCents, 100)
    }

    func testScopeOrderDeduplicationAndGaps() {
        var series = Series(source: .phone, exchangeIndex: 2)
        let start = Date(timeIntervalSince1970: 1000)
        let first = AccountObservation(capturedAt: start, source: .phone, exchangeIndex: 2, cashCents: 100)
        let last = AccountObservation(capturedAt: start.addingTimeInterval(300), source: .phone, exchangeIndex: 2)
        series.merge([last, first, first,
                      AccountObservation(capturedAt: start, source: .runner, exchangeIndex: 2),
                      AccountObservation(capturedAt: start, source: .phone, exchangeIndex: nil)])
        XCTAssertEqual(series.observations, [first, last])
        XCTAssertEqual(series.gaps(over: 120), [DateInterval(start: start, end: last.capturedAt)])
        XCTAssertTrue(series.gaps(over: 300).isEmpty)
        XCTAssertEqual(series.cashFloorAnnotationCents, 1000)
        XCTAssertNil(Series(source: .runner, metric: .portfolioValue).cashFloorAnnotationCents)
    }
    func testRangeBoundaries() {
        let now = Date(timeIntervalSince1970: 1_000_000)
        var series = Series(source: .runner)
        series.merge([0.0, -86400, -172800, -691200, 1].map {
            AccountObservation(capturedAt: now.addingTimeInterval($0), source: .runner)
        })
        XCTAssertEqual(series.selected(.day, now: now).count, 2)
        XCTAssertEqual(series.selected(.week, now: now).count, 3)
        XCTAssertEqual(series.selected(.all, now: now).count, 4)
    }

    func testRangeMenuOrderAndLabels() {
        XCTAssertEqual(HistoryRange.allCases, [.hour, .fourHours, .twelveHours, .day, .week, .month, .all])
        XCTAssertEqual(HistoryRange.allCases.map(\.label), ["1h", "4h", "12h", "1d", "7d", "30d", "All"])
    }

    func testEveryBoundedRangeIncludesBothEndpointsAndExcludesFuture() {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        let ranges: [(HistoryRange, TimeInterval)] = [
            (.hour, 3600), (.fourHours, 14400), (.twelveHours, 43200),
            (.day, 86400), (.week, 604800), (.month, 2592000)
        ]
        for (range, duration) in ranges {
            var series = Series(source: .runner)
            let observations = [-duration - 1, -duration, -duration / 2, 0, 1].map {
                AccountObservation(capturedAt: now.addingTimeInterval($0), source: .runner)
            }
            series.merge(observations)
            XCTAssertEqual(series.selected(range, now: now), Array(observations[1...3]), range.label)
            XCTAssertEqual(series.selected(.all, now: now), Array(observations[0...3]))
        }
    }
}
