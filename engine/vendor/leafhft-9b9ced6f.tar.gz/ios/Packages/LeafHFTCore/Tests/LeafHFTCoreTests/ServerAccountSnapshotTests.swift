import Foundation
import XCTest
@testable import LeafHFTCore

final class ServerAccountSnapshotTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_790_710_800)

    private func snapshot(age: TimeInterval = 120, mark: Int? = 4210) -> ServerAccountSnapshot {
        ServerAccountSnapshot(source: .venueSnapshot,
            observedAt: ISO8601DateFormatter().string(from: now.addingTimeInterval(-age)),
            cashCents: 9968, portfolioValueCents: mark, positions: [], positionsComplete: true)
    }

    func testVenueSnapshotDecodesAllPositionFieldsAndFractionalTimestamp() throws {
        let json = #"""
        {"source":"venue_snapshot","observed_at":"2026-09-29T19:40:00.123Z",
         "cash_cents":9968,"portfolio_value_cents":4210,"positions_complete":true,
         "positions":[{"ticker":"KXBTCD-26SEP2915-T83599.99","position_fp":"3.00",
          "market_exposure_dollars":"1.4700","realized_pnl_dollars":"0.0000",
          "fees_paid_dollars":"0.0300","resting_orders_count":0}]}
        """#
        let value = try accountJSONDecoder().decode(ServerAccountSnapshot.self, from: Data(json.utf8))
        XCTAssertEqual(value.source, .venueSnapshot)
        XCTAssertEqual(value.cashCents, 9968)
        XCTAssertEqual(value.portfolioValueCents, 4210)
        XCTAssertTrue(value.positionsComplete)
        let position = try XCTUnwrap(value.positions?.first)
        XCTAssertEqual(position.ticker, "KXBTCD-26SEP2915-T83599.99")
        XCTAssertEqual(position.positionFp, "3.00")
        XCTAssertEqual(position.marketExposureDollars, "1.4700")
        XCTAssertEqual(position.realizedPnlDollars, "0.0000")
        XCTAssertEqual(position.feesPaidDollars, "0.0300")
        XCTAssertEqual(position.restingOrdersCount, 0)
        let whole = try XCTUnwrap(ISO8601DateFormatter().date(from: "2026-09-29T19:40:00Z"))
        XCTAssertEqual(try XCTUnwrap(value.observedDate).timeIntervalSince(whole), 0.123, accuracy: 0.001)
        XCTAssertEqual(try JSONDecoder().decode(ServerAccountSnapshot.self, from: JSONEncoder().encode(value)), value)
    }

    func testCashOnlyAndOwnerShapesAndUnknownSource() throws {
        for source in ["lane_cash", "venue_snapshot", "future_source"] {
            let json = """
            {"source":"\(source)","observed_at":"2026-09-29T19:40:00Z","cash_cents":9968,
             "portfolio_value_cents":null,"positions":null,"positions_complete":false}
            """
            let value = try accountJSONDecoder().decode(ServerAccountSnapshot.self, from: Data(json.utf8))
            XCTAssertEqual(value.source, ServerAccountSnapshot.Source(rawValue: source) ?? .unknown)
            XCTAssertNotNil(value.observedDate)
            XCTAssertNil(value.portfolioValueCents)
            XCTAssertNil(value.positions)
            XCTAssertFalse(value.positionsComplete)
        }
        let missingPositions = #"{"source":"lane_cash","observed_at":"2026-09-29T19:40:00Z","cash_cents":9968,"positions_complete":false}"#
        XCTAssertNil(try accountJSONDecoder().decode(ServerAccountSnapshot.self, from: Data(missingPositions.utf8)).positions)
    }

    func testOnlyTransportAndEligibleSnapshotCanFallback() {
        let failures: [DirectAccountFailure?] = [nil, .transport, .unauthorized, .noCredential, .rateLimited, .http, .decoding]
        let undated = ServerAccountSnapshot(source: .laneCash, observedAt: "not a date",
            cashCents: 9968, portfolioValueCents: nil, positions: nil, positionsComplete: false)
        let snapshots: [ServerAccountSnapshot?] = [snapshot(), snapshot(age: 1801), snapshot(age: -61), nil, undated]
        for failure in failures {
            for (index, value) in snapshots.enumerated() {
                let decision = AccountFallback.decide(directFailure: failure, snapshot: value, now: now)
                if failure == .transport && index == 0 {
                    guard case let .useServer(balance, positions, observedAt) = decision else {
                        XCTFail("Fresh transport failure must use server")
                        continue
                    }
                    XCTAssertEqual(balance.balance, 9968)
                    XCTAssertEqual(balance.portfolioValue, 4210)
                    XCTAssertEqual(balance.accountValue?.cents.rawValue, 14178)
                    XCTAssertEqual(positions, [])
                    XCTAssertEqual(observedAt, now.addingTimeInterval(-120))
                } else {
                    XCTAssertEqual(decision, .keepDirect, "failure: \(String(describing: failure)), snapshot: \(index)")
                }
            }
        }
    }

    func testMissingMarkNeverInventsAccountValue() {
        guard case let .useServer(balance, _, _) = AccountFallback.decide(
            directFailure: .transport, snapshot: snapshot(mark: nil), now: now) else {
            return XCTFail("Cash-only snapshot should be usable")
        }
        XCTAssertEqual(balance.cash?.cents.rawValue, 9968)
        XCTAssertNil(balance.portfolioValue)
        XCTAssertNil(balance.accountValue)
    }

    func testAgeBoundariesAndCustomMaximum() {
        for age in [TimeInterval(-60), 1800] {
            guard case .useServer = AccountFallback.decide(directFailure: .transport, snapshot: snapshot(age: age), now: now) else {
                XCTFail("Boundary \(age) should be accepted")
                continue
            }
        }
        XCTAssertEqual(AccountFallback.decide(directFailure: .transport, snapshot: snapshot(age: 121), now: now, maxAge: 120), .keepDirect)
    }
}
