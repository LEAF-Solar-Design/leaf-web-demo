import Foundation
import XCTest
@testable import LeafHFTCore

final class ControlLifecycleTests: XCTestCase {
    func testEnrolledKeyPolicy() {
        let record = EnrolledKeyRecord(scope: "key:original", tenantId: "tenant", laneId: "lane")
        for state in [AutomatedTradingState.dryRun, .live, .livePending] {
            XCTAssertTrue(EnrolledKeyPolicy.keyChanged(record: record, currentScope: "key:changed",
                tenantId: "tenant", laneId: "lane", state: state))
        }
        XCTAssertFalse(EnrolledKeyPolicy.keyChanged(record: record, currentScope: record.scope,
            tenantId: "tenant", laneId: "lane", state: .live))
        XCTAssertFalse(EnrolledKeyPolicy.keyChanged(record: record, currentScope: "key:changed",
            tenantId: "tenant", laneId: "lane", state: .ready))
        XCTAssertFalse(EnrolledKeyPolicy.keyChanged(record: record, currentScope: "key:changed",
            tenantId: "tenant", laneId: "other-lane", state: .live))
        XCTAssertFalse(EnrolledKeyPolicy.keyChanged(record: record, currentScope: "key:changed",
            tenantId: "other-tenant", laneId: "lane", state: .live))
        XCTAssertFalse(EnrolledKeyPolicy.keyChanged(record: record, currentScope: nil,
            tenantId: "tenant", laneId: "lane", state: .live))
        XCTAssertFalse(EnrolledKeyPolicy.keyChanged(record: nil, currentScope: "key:changed",
            tenantId: "tenant", laneId: "lane", state: .live))
        XCTAssertFalse(EnrolledKeyPolicy.keyChanged(record: record, currentScope: "key:changed",
            tenantId: nil, laneId: "lane", state: .live))
        XCTAssertFalse(EnrolledKeyPolicy.keyChanged(record: record, currentScope: "key:changed",
            tenantId: "tenant", laneId: nil, state: .live))
        for state in [AutomatedTradingState.notConfigured, .credentialRequired, .revoked] {
            XCTAssertTrue(EnrolledKeyPolicy.recordIsObsolete(record: record,
                tenantId: "tenant", laneId: "lane", state: state))
        }
        XCTAssertTrue(EnrolledKeyPolicy.recordIsObsolete(record: record,
            tenantId: "other-tenant", laneId: "lane", state: .live))
        XCTAssertTrue(EnrolledKeyPolicy.recordIsObsolete(record: record,
            tenantId: "tenant", laneId: "other-lane", state: .live))
        XCTAssertFalse(EnrolledKeyPolicy.recordIsObsolete(record: record,
            tenantId: "tenant", laneId: "lane", state: .live))
    }

    func testEnrolledKeyRecordRoundTrips() throws {
        let record = EnrolledKeyRecord(scope: "key:public-key-digest", tenantId: "tenant", laneId: "lane")
        let data = try JSONEncoder().encode(record)
        XCTAssertEqual(try JSONDecoder().decode(EnrolledKeyRecord.self, from: data), record)
    }

    func testControlRefusalIncludesReason() {
        XCTAssertEqual(ControlRefusalMessage.text(for: "  Account scope required  "),
            "The runner declined this change: Account scope required")
    }

    func testEmptyControlRefusalUsesGenericMessage() {
        let expected = "The account request was declined. Refresh its status before trying again."
        XCTAssertEqual(ControlRefusalMessage.text(for: ""), expected)
        XCTAssertEqual(ControlRefusalMessage.text(for: " \n\t\r "), expected)
    }

    func testControlRefusalCollapsesNewlinesAndTabs() {
        XCTAssertEqual(ControlRefusalMessage.text(for: "\nOutside\r\n\t account\t\t lane\n"),
            "The runner declined this change: Outside account lane")
    }

    func testControlRefusalBoundsLongReason() {
        let prefix = "The runner declined this change: "
        XCTAssertEqual(ControlRefusalMessage.text(for: String(repeating: "x", count: 400)),
            prefix + String(repeating: "x", count: 157) + "...")
        XCTAssertEqual(ControlRefusalMessage.text(for: String(repeating: "x", count: 160)),
            prefix + String(repeating: "x", count: 160))
    }

    func testControlRequestTerminalStates() {
        let pendingStates: [String?] = [nil, "", "requested", "REQUESTED"]
        for state in pendingStates {
            XCTAssertFalse(ControlRequestLifecycle.isTerminal(state: state), state ?? "nil")
        }
        for state in ["applied", "rejected", "superseded", "anything"] {
            XCTAssertTrue(ControlRequestLifecycle.isTerminal(state: state), state)
        }
    }

    func testAutoLiveIntentExpiry() {
        let now = Date(timeIntervalSince1970: 2_000_000_000)
        let ttl = AutoLiveIntentPolicy.timeToLive
        XCTAssertEqual(ttl, 600)
        XCTAssertFalse(AutoLiveIntentPolicy.isExpired(requestedAt: now.addingTimeInterval(-ttl + 1), now: now))
        XCTAssertFalse(AutoLiveIntentPolicy.isExpired(requestedAt: now.addingTimeInterval(-ttl), now: now))
        XCTAssertTrue(AutoLiveIntentPolicy.isExpired(requestedAt: now.addingTimeInterval(-ttl - 1), now: now))
        XCTAssertFalse(AutoLiveIntentPolicy.isExpired(requestedAt: now.addingTimeInterval(60), now: now))
        XCTAssertTrue(AutoLiveIntentPolicy.isExpired(requestedAt: now.addingTimeInterval(61), now: now))
    }

    func testUnresolvedControlExpiry() {
        let now = Date(timeIntervalSince1970: 2_000_000_000)
        let ttl = UnresolvedControlPolicy.timeToLive
        XCTAssertEqual(ttl, 1800)
        XCTAssertFalse(UnresolvedControlPolicy.isExpired(since: now.addingTimeInterval(-ttl + 1), now: now))
        XCTAssertFalse(UnresolvedControlPolicy.isExpired(since: now.addingTimeInterval(-ttl), now: now))
        XCTAssertTrue(UnresolvedControlPolicy.isExpired(since: now.addingTimeInterval(-ttl - 1), now: now))
        XCTAssertFalse(UnresolvedControlPolicy.isExpired(since: now.addingTimeInterval(60), now: now))
        XCTAssertTrue(UnresolvedControlPolicy.isExpired(since: now.addingTimeInterval(61), now: now))
    }
}
