import Foundation
import XCTest
@testable import LeafHFTCore

final class TelemetryModelsTests: XCTestCase {
    func testBooksPayloadAndOptionalEvaluation() throws {
        let payload = try accountJSONDecoder().decode(MobileBooks.self, from: fixtureData("books"))
        XCTAssertEqual(payload.schemaVersion, 1)
        XCTAssertEqual(payload.books.count, 14)
        let eval = try XCTUnwrap(payload.books.first?.kalshiBook.eval)
        XCTAssertEqual(eval.capturedAtMs, 1757800000000)
        XCTAssertEqual(eval.candidates?.first?.edgeRequiredCents, 2)
        XCTAssertEqual(eval.tickets?.first?.surplus, -0.8)
        XCTAssertEqual(Set(payload.books.map(\.bookId)).count, 14)
        XCTAssertTrue(payload.books.allSatisfy { $0.kalshiBook.eval != nil })
        XCTAssertEqual(payload.books.last?.kalshiBook.eval?.candidates?.first?.edgeRequiredCents, 15)
    }
    func testLegacyBookWithoutEvaluationRemainsCompatible() throws {
        let bytes = Data(#"{"schema_version":1,"books":[{"book_id":"legacy-book","kalshi_book":{"params":{},"stats":{}}}]}"#.utf8)
        let payload = try accountJSONDecoder().decode(MobileBooks.self, from: bytes)
        XCTAssertEqual(payload.books.first?.bookId, "legacy-book")
        XCTAssertNil(payload.books.first?.kalshiBook.eval)
        XCTAssertNil(payload.books.first?.enabled)
    }
    func testBookEnabledStateDecodes() throws {
        let bytes = Data(#"{"schema_version":1,"books":[{"book_id":"BTC-15M","enabled":false,"kalshi_book":{}}]}"#.utf8)
        let payload = try accountJSONDecoder().decode(MobileBooks.self, from: bytes)
        XCTAssertEqual(payload.books.first?.enabled, false)
    }
    func testMinimalCandidateKeepsUnknownValues() throws {
        let candidate = try accountJSONDecoder().decode(Candidate.self, from: Data(#"{"ticker":"T","unknown":42}"#.utf8))
        XCTAssertNil(candidate.edgeCents)
        XCTAssertNil(candidate.intentSent)
        XCTAssertThrowsError(try accountJSONDecoder().decode(Candidate.self, from: Data("{}".utf8)))
    }
}
