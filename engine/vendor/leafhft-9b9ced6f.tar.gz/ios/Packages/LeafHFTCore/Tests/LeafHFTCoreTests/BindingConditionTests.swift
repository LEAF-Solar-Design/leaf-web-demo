import XCTest
@testable import LeafHFTCore

final class BindingConditionTests: XCTestCase {
    func testBindingStates() {
        var candidate = Candidate(ticker: "T")
        XCTAssertEqual(BindingCondition.from(candidate: candidate, windowS: 120, minK: 10), .unknown(missing: "gate"))
        candidate.gate = "skip_outside_window"
        candidate.secondsToClose = 200
        XCTAssertEqual(BindingCondition.from(candidate: candidate, windowS: 120, minK: 10), .waiting(secondsUntilWindow: 80))
        candidate.gate = "skip_k_floor"
        XCTAssertEqual(BindingCondition.from(candidate: candidate, windowS: 120, minK: 10), .unknown(missing: "k"))
        candidate.k = 7
        XCTAssertEqual(BindingCondition.from(candidate: candidate, windowS: 120, minK: 10), .observing(k: 7, minK: 10))
        for gate in ["skip_edge_below_bar", "skip_band_edge"] {
            candidate.gate = gate
            candidate.edgeCents = 0.5
            candidate.edgeRequiredCents = 2
            XCTAssertEqual(BindingCondition.from(candidate: candidate, windowS: 120, minK: 10), .evaluating(edgeShortfallCents: 1.5))
        }
        candidate.gate = "passed"
        XCTAssertEqual(BindingCondition.from(candidate: candidate, windowS: nil, minK: nil), .intentEmitted)
        candidate.gate = nil
        candidate.intentSent = true
        XCTAssertEqual(BindingCondition.from(candidate: candidate, windowS: nil, minK: nil), .intentEmitted)
    }
    func testNamedBlockers() {
        let gates = ["skip_price_ceiling": "Price above ceiling", "skipped_thin_quote": "Quote too thin",
                     "skip_market_full": "Market at its cap", "skip_reentry_after_exit": "Blocked after exit"]
        for (gate, reason) in gates {
            var candidate = Candidate(ticker: "T")
            candidate.gate = gate
            XCTAssertEqual(BindingCondition.from(candidate: candidate, windowS: nil, minK: nil), .blocked(reason: reason))
        }
    }
    func testExitSurplusAndMissingValues() {
        var ticket = Ticket(ticker: "T")
        XCTAssertEqual(ExitCondition.from(ticket: ticket), .unknown)
        ticket.netValue = 50
        ticket.holdValue = 49
        ticket.margin = 2
        XCTAssertEqual(ExitCondition.from(ticket: ticket), .surplus(cents: -1))
        ticket.surplus = 3
        XCTAssertEqual(ExitCondition.from(ticket: ticket), .surplus(cents: 3))
    }
}
