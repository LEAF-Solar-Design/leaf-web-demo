import Foundation
import XCTest
@testable import LeafHFTCore

final class ProbePresentationTests: XCTestCase {
    func testBreakerMeterExactText() {
        XCTAssertEqual(ProbePresentation.breakerMeter(loss: 1240, limit: 125_000, pct: 50),
                       "-$12.40 of $1,250.00 (50%) · UTC day")
        XCTAssertEqual(ProbePresentation.breakerMeter(loss: 0, limit: 5_000, pct: 12.5),
                       "$0.00 of $50.00 (12.5%) · UTC day")
        XCTAssertEqual(ProbePresentation.breakerMeter(loss: -305, limit: 123_456_789, pct: nil),
                       "+$3.05 of $1,234,567.89 · UTC day")
    }

    func testBreakerMeterNullIsNotReported() throws {
        XCTAssertEqual(ProbePresentation.breakerMeter(loss: nil, limit: nil, pct: nil), "Not reported")
        XCTAssertEqual(ProbePresentation.breakerMeter(loss: 100, limit: nil, pct: 50), "Not reported")
        XCTAssertEqual(ProbePresentation.breakerMeter(loss: nil, limit: 100, pct: 50), "Not reported")
        let meter = try accountJSONDecoder().decode(BreakerMeter.self, from: Data(#"{"engine_pct":50}"#.utf8))
        XCTAssertEqual(ProbePresentation.breakerMeter(meter), "Not reported")
        let noMeter: BreakerMeter? = nil
        XCTAssertEqual(ProbePresentation.breakerMeter(noMeter), "Not reported")
        let full = try accountJSONDecoder().decode(BreakerMeter.self, from: Data(
            #"{"engine_pct":50,"engine_loss_cents":1240,"engine_limit_cents":125000}"#.utf8))
        XCTAssertEqual(ProbePresentation.breakerMeter(full), "-$12.40 of $1,250.00 (50%) · UTC day")
    }

    func testPerContractExactText() throws {
        XCTAssertEqual(ProbePresentation.perContract(cents: 3.2, n: 41), "+3.2c per contract · n 41")
        XCTAssertEqual(ProbePresentation.perContract(cents: -1.25, n: 7), "-1.3c per contract · n 7")
        XCTAssertEqual(ProbePresentation.perContract(cents: 0.01, n: 3), "0.0c per contract · n 3")
        XCTAssertEqual(ProbePresentation.perContract(cents: nil, n: 0), "Not reported")
        XCTAssertEqual(ProbePresentation.perContract(cents: .nan, n: 5), "Not reported")
        let noLive: EngineLiveStats? = nil
        XCTAssertEqual(ProbePresentation.perContract(noLive), "Not reported")
        let live = try accountJSONDecoder().decode(EngineLiveStats.self,
            from: Data(#"{"per_contract_cents":3.2,"n":41,"days":7}"#.utf8))
        XCTAssertEqual(ProbePresentation.perContract(live), "+3.2c per contract · n 41")
    }

    func testNextStepPassesServerSentenceThroughUnchanged() {
        let sentence = "Probing: day 3 of 14, 41 tickets, -$1.20; verdict due Oct 7"
        XCTAssertEqual(ProbePresentation.nextStep(code: "probing", text: sentence), sentence)
        XCTAssertEqual(ProbePresentation.nextStep(code: "test_it", text: "  Test it  "), "  Test it  ")
        XCTAssertEqual(ProbePresentation.nextStep(code: "probe_it", text: nil), "Not reported")
        XCTAssertEqual(ProbePresentation.nextStep(code: nil, text: ""), "Not reported")
    }
}
