import Foundation
import XCTest
@testable import LeafHFTCore

final class EngineWorkshopTests: XCTestCase {
    private let account = EngineControlAccount(id: "private-account", label: "My account label",
        host: "private-host", subaccountNumber: nil, configurable: true)
    private let timestamp = "2026-09-20T12:00:00Z"
    private var now: Date { ISO8601DateFormatter().date(from: timestamp)! }
    private func engine(policy: [String: Double] = ["per_order_fraction": 0.02]) throws -> Engine {
        let object: [String: Any] = ["engine_id": "engine", "name": "Example engine", "host": account.host,
            "pnl": ["n": 4, "last_ticket_at": timestamp],
            "configuration": ["global": ["enabled": true, "policy": ["per_order_fraction": 0.91]],
                "accounts": [["account_id": account.id, "override": ["policy": [:]],
                    "effective": ["enabled": false, "policy": policy]]]]]
        return try accountJSONDecoder().decode(Engine.self, from: JSONSerialization.data(withJSONObject: object))
    }
    private func readiness(_ engine: Engine, id: String? = "private-account",
                           accounts: [EngineControlAccount]? = nil) -> [EngineWorkshop.ReadinessItem] {
        EngineWorkshop.readiness(engine: engine, accountId: id, generatedAt: timestamp,
            observedAt: now, now: now, accounts: accounts ?? [account])
    }

    func testLiveReadinessNeverClaimsHoldoutOrApproval() throws {
        let items = readiness(try engine())
        XCTAssertEqual(items.map(\.kind), EngineWorkshop.ReadinessKind.allCases)
        XCTAssertEqual(items.first { $0.kind == .holdoutEvidence }?.status, .notReported)
        XCTAssertEqual(items.first { $0.kind == .dataCoverage }?.status, .partial)
        XCTAssertEqual(items.first { $0.kind == .telemetry }?.status, .reported)
        for status in EngineWorkshop.ReadinessStatus.allCases {
            for forbidden in ["ready", "pass", "approved"] { XCTAssertFalse(status.rawValue.contains(forbidden)) }
        }
    }

    func testRiskCountsAndAccountIntegrationAreOnlyReportedEvidence() throws {
        let full = Dictionary(uniqueKeysWithValues: EngineWorkshop.riskKeys.map { ($0, 0.02) })
        XCTAssertEqual(readiness(try engine(policy: full)).first { $0.kind == .riskLimits }?.status, .reported)
        let partial = readiness(try engine())
        XCTAssertEqual(partial.first { $0.kind == .riskLimits }?.status, .partial)
        XCTAssertTrue(partial.first { $0.kind == .riskLimits }?.detail.contains("1 of 7 reported") == true)
        XCTAssertEqual(partial.first { $0.kind == .accountIntegration }?.status, .reported)
        XCTAssertEqual(readiness(try engine(policy: [:])).first { $0.kind == .riskLimits }?.status, .notReported)
        let otherHost = EngineControlAccount(id: account.id, label: account.label, host: "other-host",
            subaccountNumber: nil, configurable: true)
        XCTAssertEqual(readiness(try engine(), accounts: [otherHost]).first { $0.kind == .accountIntegration }?.status, .partial)
    }

    func testMissingAccountNeverUsesGlobalDials() throws {
        let engine = try engine()
        let missing = EngineControlAccount(id: "missing", label: "Missing", host: account.host,
            subaccountNumber: nil, configurable: true)
        let items = readiness(engine, id: missing.id)
        XCTAssertEqual(items.first { $0.kind == .riskLimits }?.status, .notReported)
        XCTAssertEqual(items.first { $0.kind == .accountIntegration }?.status, .notReported)
        let row = try XCTUnwrap(EngineWorkshop.dialComparison(engine: engine, accounts: [account, missing]).first)
        XCTAssertEqual(row.globalValue, 0.91)
        XCTAssertEqual(row.accounts[0].value, 0.02)
        XCTAssertTrue(row.accounts[0].differs)
        XCTAssertEqual(row.accounts[1].valueText, "Unknown")
        XCTAssertFalse(row.accounts[1].differs)
        let brief = EngineWorkshop.brief(engine: engine, accountId: missing.id, accounts: [missing],
            generatedAt: timestamp, observedAt: now, now: now, fixture: false)
        XCTAssertTrue(brief.contains("Effective dials unknown"))
        XCTAssertFalse(brief.contains("0.91"))
    }

    func testTelemetryAndCoverageKeepMissingAndStaleState() throws {
        var engine = try engine()
        engine.pnl = nil
        let items = EngineWorkshop.readiness(engine: engine, accountId: nil, generatedAt: timestamp,
            observedAt: now, now: now.addingTimeInterval(121))
        XCTAssertEqual(items.first { $0.kind == .dataCoverage }?.status, .notReported)
        XCTAssertEqual(items.first { $0.kind == .telemetry }?.status, .partial)
        let unknown = EngineWorkshop.readiness(engine: engine, accountId: nil, generatedAt: nil,
            observedAt: nil, now: now)
        XCTAssertEqual(unknown.first { $0.kind == .telemetry }?.status, .notReported)
    }

    func testBriefIsBoundedAndOmitsIdentifiers() throws {
        var engine = try engine()
        engine.name = "Example private-account private-host private-tenant private-lane " + String(repeating: "name ", count: 500)
        func brief(_ audience: EngineWorkshop.BriefAudience) -> String {
            EngineWorkshop.brief(engine: engine, accountId: account.id, accounts: [account],
                generatedAt: timestamp, observedAt: now, now: now, fixture: true, audience: audience,
                redactingIdentifiers: ["private-tenant", "private-lane"])
        }
        let shared = brief(.share)
        XCTAssertLessThanOrEqual(shared.count, 2000)
        XCTAssertTrue(shared.hasPrefix("Fixture data, not a live account\n"))
        for identifier in [account.id, account.host, "private-tenant", "private-lane", account.label] {
            XCTAssertFalse(shared.contains(identifier), identifier)
        }
        XCTAssertTrue(shared.contains("one account"))
        XCTAssertTrue(shared.contains("per_order_fraction: 0.02"))
        XCTAssertTrue(shared.contains("Requested change:"))
        XCTAssertTrue(shared.hasSuffix("Context only. This text changes nothing."))
        for kind in EngineWorkshop.ReadinessKind.allCases { XCTAssertTrue(shared.contains(kind.label)) }
        XCTAssertTrue(brief(.studio).contains(account.label))
    }

    func testUnselectedBriefAndStudioPromptsKeepReviewBoundary() throws {
        let brief = EngineWorkshop.brief(engine: try engine(), accountId: nil, accounts: [account],
            generatedAt: timestamp, observedAt: now, now: now, fixture: false)
        XCTAssertTrue(brief.contains("Account not selected"))
        XCTAssertFalse(brief.contains("0.91"))
        XCTAssertFalse(brief.contains("Fixture data"))
        for intent in [EngineWorkshop.StudioIntent.design, .test] {
            let prompt = EngineWorkshop.studioPrompt(intent, brief)
            XCTAssertTrue(prompt.contains(brief))
            XCTAssertTrue(prompt.hasSuffix("Do not apply anything. If a change is warranted, produce a config draft for my review."))
        }
    }

    func testResearchReadinessIsNotesNotTelemetry() throws {
        let notes = try EngineLab.decodeNotes(fixtureData("engine-lab"))
        let darkhorse = notes.lanes[0]
        let items = EngineWorkshop.readiness(lane: darkhorse)
        XCTAssertEqual(items.first { $0.kind == .holdoutEvidence }?.status, .noted)
        XCTAssertEqual(items.first { $0.kind == .riskLimits }?.detail, "Three-contract order ceiling shipped.")
        XCTAssertEqual(items.first { $0.kind == .telemetry }?.status, .notReported)
        for lane in notes.lanes {
            let brief = EngineWorkshop.brief(lane: lane, fixture: true)
            XCTAssertFalse(brief.contains(lane.id))
            XCTAssertTrue(brief.contains(lane.name))
            XCTAssertLessThanOrEqual(brief.count, 2000)
        }
    }

    func testNotesRejectReportedStatusAndMissingReadinessKeys() throws {
        let original = try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData("engine-lab")) as? [String: Any])
        for key in EngineWorkshop.ReadinessKind.allCases.map(\.rawValue) {
            for status in ["reported", "partial", "approved", "missing"] {
                var object = original
                var lanes = try XCTUnwrap(object["lanes"] as? [[String: Any]])
                var readiness = try XCTUnwrap(lanes[0]["readiness"] as? [String: [String: Any]])
                if status == "missing" { readiness.removeValue(forKey: key) }
                else { readiness[key]?["status"] = status }
                lanes[0]["readiness"] = readiness
                object["lanes"] = lanes
                XCTAssertThrowsError(try EngineLab.decodeNotes(JSONSerialization.data(withJSONObject: object))) { error in
                    guard case EngineLab.NotesError.invalidContract = error else {
                        return XCTFail("Expected invalidContract, received \(error)")
                    }
                }
            }
        }
    }
}
