import Foundation
import XCTest
@testable import LeafHFTCore

final class PairingModelsTests: XCTestCase {
    func testUnknownTerminalStateNeverDecodesAsApproved() throws {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        let result = try decoder.decode(DevicePairingPollEnvelope.self,
            from: Data(#"{"pairing":{"state":"claimed"}}"#.utf8))
        XCTAssertEqual(result.pairing.state, .terminal)
        XCTAssertNil(result.pairing.token)
    }
}

