import Foundation
import XCTest
@testable import LeafHFTCore

final class EngineModelsGainTests: XCTestCase {
    func testGainFieldsDecodeFromMobileEnginePayload() throws {
        let json = #"{"engines":[{"engine_id":"default","pnl":{"n":42,"won":18,"net_cents":250,"avg_win_gain_pct":12.3,"win_gain_n":18,"avg_closed_gain_pct":-1.4,"closed_gain_n":42}}]}"#
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: Data(json.utf8))
        let engine = try XCTUnwrap(response.engines?.first)
        let pnl = try XCTUnwrap(engine.pnl)

        XCTAssertEqual(engine.engineId, "default")
        XCTAssertEqual(pnl.avgWinGainPct, 12.3)
        XCTAssertEqual(pnl.winGainN, 18)
        XCTAssertEqual(pnl.avgClosedGainPct, -1.4)
        XCTAssertEqual(pnl.closedGainN, 42)
        XCTAssertEqual(pnl.netCents, 250)
    }

    func testOlderPayloadWithoutGainFieldsStillDecodes() throws {
        let json = #"{"engines":[{"engine_id":"default","pnl":{"n":42,"won":18,"net_cents":250}},{"engine_id":"legacy"}]}"#
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: Data(json.utf8))
        let engines = try XCTUnwrap(response.engines)
        XCTAssertEqual(engines.count, 2)
        let pnl = try XCTUnwrap(engines.first?.pnl)

        XCTAssertNil(pnl.avgWinGainPct)
        XCTAssertNil(pnl.winGainN)
        XCTAssertNil(pnl.avgClosedGainPct)
        XCTAssertNil(pnl.closedGainN)
        XCTAssertEqual(pnl.n, 42)
        XCTAssertEqual(pnl.won, 18)
        XCTAssertEqual(pnl.netCents, 250)
        XCTAssertNil(engines.last?.pnl)
    }

    func testNullAveragesAndZeroCountsDecode() throws {
        let json = #"{"engines":[{"engine_id":"default","pnl":{"avg_win_gain_pct":null,"win_gain_n":0,"avg_closed_gain_pct":null,"closed_gain_n":0}}]}"#
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: Data(json.utf8))
        let pnl = try XCTUnwrap(response.engines?.first?.pnl)

        XCTAssertNil(pnl.avgWinGainPct)
        XCTAssertEqual(pnl.winGainN, 0)
        XCTAssertNil(pnl.avgClosedGainPct)
        XCTAssertEqual(pnl.closedGainN, 0)
    }
}
