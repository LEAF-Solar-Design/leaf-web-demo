import Foundation
import XCTest
@testable import LeafHFTCore

final class EngineConfigurationDraftTests: XCTestCase {
    private func darkhorse() throws -> Engine {
        try accountJSONDecoder().decode(Engine.self, from: Data(#"""
        {"engine_id":"darkhorse","host":"sample-runner",
         "darkhorse":{"available":true,"pending":false,"stale":false,"models":[
           {"offset":120,"sha":"model120","trained_threshold":0.6,"score_p99":0.9,"score_threshold":0.65},
           {"offset":45,"sha":"model45","trained_threshold":0.55,"score_p99":0.95,"score_threshold":0.6}]},
         "configuration":{"global":{"enabled":false,"policy":{"base_count":0.5,"max_mult":10}},
           "accounts":[{"account_id":"sample-main","override":{"enabled":false,"policy":{}},
             "effective":{"enabled":false,"policy":{"base_count":0.1,"max_mult":2,"score_threshold_120":0.65,"score_threshold_45":0.6}},
             "revision":"dh-r1","freshness":"fresh"}]}}
        """#.utf8))
    }

    func testDarkhorseAccountControlsAndReviewUseFractionalCounts() throws {
        let engine = try darkhorse()
        var draft = EngineConfigurationDraft(baseline: EngineConfigurationBaseline(engine: engine, scope: try .account("sample-main")))
        draft.setValue(0.01, for: "base_count")
        draft.setValue(1, for: "max_mult")
        draft.setValue(0.7, for: "score_threshold_120")
        draft.setEnabled(true)
        XCTAssertTrue(draft.blockingProblems.isEmpty)
        XCTAssertEqual(draft.changes.first { $0.id == "base_count" }?.newText, "0.01")
        let intent = try draft.intent(engineId: "darkhorse", host: "sample-runner", clientRequestId: UUID().uuidString)
        XCTAssertEqual(intent.scope, try .account("sample-main"))
        guard case let .configure(value) = intent.value else { return XCTFail("Expected configure") }
        XCTAssertEqual(value.set?["base_count"], 0.01)
        XCTAssertEqual(value.enabledChange, .value(true))
        XCTAssertEqual(engineSetKeys(for: engine), DarkhorsePolicy.keys)
    }

    func testDarkhorseRejectsBoundsPrecisionLowerThresholdAndP99() throws {
        let engine = try darkhorse()
        for (key, value) in [("base_count", 0.0), ("base_count", 0.51), ("base_count", 0.011),
                             ("max_mult", 0.99), ("max_mult", 10.01), ("max_mult", Double.infinity),
                             ("score_threshold_120", 0.59), ("score_threshold_120", 0.9),
                             ("score_threshold_45", 0.54), ("score_threshold_45", 0.95)] {
            var draft = EngineConfigurationDraft(baseline: EngineConfigurationBaseline(engine: engine, scope: try .account("sample-main")))
            draft.setValue(value, for: key)
            XCTAssertFalse(draft.blockingProblems.isEmpty, key)
            XCTAssertThrowsError(try draft.intent(engineId: "darkhorse", host: "sample-runner", clientRequestId: UUID().uuidString))
        }
        XCTAssertThrowsError(try ControlIntent.configure(engineId: "darkhorse", host: "sample-runner", scope: .global,
            enabled: .value(true), expectedRevision: "r1", clientRequestId: UUID().uuidString))
        XCTAssertThrowsError(try ControlIntent.configure(engineId: "darkhorse", host: "sample-runner", scope: .account("sample-main"),
            set: ["size_fraction": 0.1], expectedRevision: "r1", clientRequestId: UUID().uuidString))
    }

    func testDarkhorseMissingModelsAndShadowOnlyBlockDrafts() throws {
        var engine = try darkhorse()
        engine.darkhorse = nil
        var draft = EngineConfigurationDraft(baseline: EngineConfigurationBaseline(engine: engine, scope: try .account("sample-main")))
        draft.setEnabled(true)
        XCTAssertFalse(draft.blockingProblems.isEmpty)
        engine = try darkhorse()
        engine.shadowOnly = true
        engine.reason = "Holdout required"
        draft = EngineConfigurationDraft(baseline: EngineConfigurationBaseline(engine: engine, scope: try .account("sample-main")))
        draft.setEnabled(true)
        XCTAssertTrue(draft.blockingProblems.contains("Holdout required"))
    }
    private func response() throws -> EnginesResponse {
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: fixtureData("engines"))
        let policy = response.engines?.first { $0.engineId == "default" }?.configuration?.global.policy ?? [:]
        let safe = policy.filter { RiskEnvelope.hardMaxima[$0.key] != nil }.mapValues { $0 }
        let limits = safe.reduce(into: [String: Double]()) { result, pair in
            result[pair.key] = min(pair.value, RiskEnvelope.hardMaxima[pair.key]!)
        }
        return response.applyingConfigure(EngineConfigureValue(engineId: "default", set: limits,
            unset: nil, enabledChange: .unchanged), scope: .global,
            newRevision: "global-default-r1", observedAt: "now")
    }
    private func engine() throws -> Engine { try XCTUnwrap(response().engines?.first { $0.engineId == "default" }) }
    private func draft(_ scope: ControlScope = .global) throws -> EngineConfigurationDraft {
        EngineConfigurationDraft(baseline: EngineConfigurationBaseline(engine: try engine(), scope: scope))
    }

    func testGlobalBaselineAndSources() throws {
        let value = try draft()
        XCTAssertEqual(value.source(for: "edge_threshold_cents"), .global)
        XCTAssertEqual(value.currentValue(for: "edge_threshold_cents"), 3.5)
        XCTAssertEqual(value.effectiveValue(for: "edge_threshold_cents"), 3.5)
        XCTAssertEqual(value.changeCount, 0)
        XCTAssertFalse(value.hasChanges)
    }

    func testHardRiskLimitsBlockSavedInheritedAndEditedValues() throws {
        for (key, maximum) in RiskEnvelope.hardMaxima {
            let unsafe = EngineConfigureValue(engineId: "default", set: [key: maximum + 0.01],
                unset: nil, enabledChange: .unchanged)
            for unsafeScope in [ControlScope.global, try .account("sample-secondary")] {
                let response = try response().applyingConfigure(unsafe, scope: unsafeScope,
                    newRevision: "unsafe", observedAt: "now")
                let engine = try XCTUnwrap(response.engines?.first { $0.engineId == "default" })
                let scopes = unsafeScope.kind == .global
                    ? [ControlScope.global, try .account("sample-main")] : [unsafeScope]
                for scope in scopes {
                    var draft = EngineConfigurationDraft(baseline: .init(engine: engine, scope: scope))
                    XCTAssertEqual(draft.effectiveValue(for: key), maximum + 0.01)
                    XCTAssertNotNil(draft.validationErrors[key], key)
                    draft.setValue(15, for: "min_k")
                    XCTAssertThrowsError(try draft.intent(engineId: "default", host: "sample-runner",
                        clientRequestId: UUID().uuidString), key)
                    draft.setValue(maximum, for: key)
                    XCTAssertNil(draft.validationErrors[key], key)
                    XCTAssertNoThrow(try draft.intent(engineId: "default", host: "sample-runner",
                        clientRequestId: UUID().uuidString), key)
                    draft.setValue(maximum + 0.01, for: key)
                    XCTAssertNotNil(draft.validationErrors[key], key)
                }
            }
        }
    }

    func testSavedValueAboveMaximumIsExplainedAndSetToMaximumClearsIt() throws {
        let unsafe = EngineConfigureValue(engineId: "default", set: ["per_order_fraction": 0.2],
            unset: nil, enabledChange: .unchanged)
        let updated = try response().applyingConfigure(unsafe, scope: .global,
            newRevision: "unsafe", observedAt: "now")
        let engine = try XCTUnwrap(updated.engines?.first { $0.engineId == "default" })
        for scope in [ControlScope.global, try .account("sample-main")] {
            var draft = EngineConfigurationDraft(baseline: .init(engine: engine, scope: scope))
            let saved = try XCTUnwrap(draft.savedAboveMaximum["per_order_fraction"])
            XCTAssertEqual(saved.saved, 0.2)
            XCTAssertEqual(saved.maximum, 0.10)
            XCTAssertEqual(draft.savedAboveMaximum.count, 1)
            XCTAssertEqual(draft.savedAboveMaximumNames, ["Per-order cap"])
            let message = try XCTUnwrap(draft.validationErrors["per_order_fraction"])
            XCTAssertEqual(draft.savedAboveMaximumMessages, [message])
            XCTAssertTrue(draft.blockingProblems.contains(message), "A saved value above the maximum still blocks")
            XCTAssertFalse(draft.hasChanges)

            // An edited value above the maximum is an edit error, not a saved-value problem.
            draft.setValue(0.15, for: "per_order_fraction")
            XCTAssertNil(draft.savedAboveMaximum(for: "per_order_fraction"))
            XCTAssertTrue(draft.savedAboveMaximumMessages.isEmpty)
            XCTAssertNotNil(draft.validationErrors["per_order_fraction"])
            XCTAssertFalse(draft.blockingProblems.isEmpty)
            XCTAssertThrowsError(try draft.intent(engineId: "default", host: "sample-runner",
                clientRequestId: UUID().uuidString))

            // Undoing restores the saved value and its explanation.
            draft.discard(key: "per_order_fraction")
            XCTAssertNotNil(draft.savedAboveMaximum(for: "per_order_fraction"))

            // Setting the draft to the maximum clears it and sends only that key.
            draft.setValue(saved.maximum, for: "per_order_fraction")
            XCTAssertTrue(draft.savedAboveMaximum.isEmpty)
            XCTAssertTrue(draft.savedAboveMaximumNames.isEmpty)
            XCTAssertNil(draft.validationErrors["per_order_fraction"])
            XCTAssertTrue(draft.blockingProblems.isEmpty)
            let intent = try draft.intent(engineId: "default", host: "sample-runner",
                clientRequestId: UUID().uuidString)
            guard case let .configure(value) = intent.value else { return XCTFail("Expected configure") }
            XCTAssertEqual(value.set, ["per_order_fraction": 0.10])
        }
        let legacy = try accountJSONDecoder().decode(EnginesResponse.self, from: fixtureData("engines"))
        let legacyDraft = EngineConfigurationDraft(baseline: .init(engine: try XCTUnwrap(legacy.engines?.first), scope: .global))
        XCTAssertEqual(Set(legacyDraft.savedAboveMaximum.keys), ["per_order_fraction", "cluster_fraction"])
        XCTAssertTrue(try draft().savedAboveMaximum.isEmpty)
        var darkhorseDraft = EngineConfigurationDraft(baseline: .init(engine: try darkhorse(), scope: try .account("sample-main")))
        darkhorseDraft.setValue(0.01, for: "base_count")
        XCTAssertTrue(darkhorseDraft.savedAboveMaximum.isEmpty)
    }

    func testSavedMaximumExplanationDistinguishesReportedAndGuardedLimits() throws {
        let key = "per_order_fraction"
        let updated = try response().applyingConfigure(EngineConfigureValue(engineId: "default",
            set: [key: 0.2], unset: nil, enabledChange: .unchanged), scope: .global,
            newRevision: "unsafe", observedAt: "now")
        var engine = try XCTUnwrap(updated.engines?.first { $0.engineId == "default" })
        let reported = try accountJSONDecoder().decode(RiskEnvelope.self,
            from: Data(#"{"per_order_fraction":0.1}"#.utf8))
        let partial = try accountJSONDecoder().decode(RiskEnvelope.self,
            from: Data(#"{"cluster_fraction":0.25}"#.utf8))
        let cases: [(RiskEnvelope?, Bool)] = [(nil, false), (partial, false), (reported, true)]
        for (envelope, isReported) in cases {
            engine.riskEnvelope = envelope
            for scope in [ControlScope.global, try .account("sample-main")] {
                let draft = EngineConfigurationDraft(baseline: .init(engine: engine, scope: scope))
                XCTAssertEqual(draft.baseline.riskEnvelope.reportedKeys.contains(key), isReported)
                XCTAssertEqual(draft.savedAboveMaximum(for: key)?.maximum, 0.1)
                let expected = isReported
                    ? "Saved 20%. The runner's maximum is 10%. The runner applies 10%. Lower it to 10% or less to send changes."
                    : "Saved 20%. The app's guarded maximum is 10% because the runner has not reported its maximum. Lower it to 10% or less to send changes."
                XCTAssertEqual(draft.savedAboveMaximumExplanation(for: key), expected)
                XCTAssertNotNil(draft.validationErrors[key])
                XCTAssertFalse(draft.hasChanges)
            }
        }
        XCTAssertEqual(partial.reportedKeys, ["cluster_fraction"])
        XCTAssertTrue(RiskEnvelope().reportedKeys.isEmpty)
        XCTAssertTrue(RiskEnvelope(maxima: [key: .nan]).reportedKeys.isEmpty)
    }

    func testOwnerEnvelopeAllowsSavedPolicyAndDraftIntent() throws {
        let policy: [String: Double] = ["per_order_fraction": 0.125, "daily_loss_fraction": 1.0,
            "drawdown_brake_fraction": 0.9, "drawdown_stop_fraction": 0.95]
        let updated = try response().applyingConfigure(EngineConfigureValue(engineId: "default",
            set: policy, unset: nil, enabledChange: .unchanged), scope: .global,
            newRevision: "owner-r1", observedAt: "now")
        var engine = try XCTUnwrap(updated.engines?.first { $0.engineId == "default" })
        for scope in [ControlScope.global, try .account("sample-main")] {
            engine.riskEnvelope = nil
            let guarded = EngineConfigurationDraft(baseline: .init(engine: engine, scope: scope))
            for key in policy.keys {
                XCTAssertNotNil(guarded.validationErrors[key], key)
            }
            engine.riskEnvelope = RiskEnvelope(maxima: RiskEnvelope.hardMaxima.mapValues { _ in 1.0 })
            var owner = EngineConfigurationDraft(baseline: .init(engine: engine, scope: scope))
            XCTAssertFalse(owner.hasChanges)
            XCTAssertTrue(owner.validationErrors.isEmpty)
            for (key, value) in policy {
                XCTAssertEqual(owner.effectiveValue(for: key), value, key)
            }
            owner.setValue(0.15, for: "per_order_fraction")
            XCTAssertNoThrow(try owner.intent(engineId: "default", host: "sample-runner",
                clientRequestId: UUID().uuidString))
        }
    }

    func testLegacyFixtureRemainsVisibleButCannotSubmit() throws {
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: fixtureData("engines"))
        let engine = try XCTUnwrap(response.engines?.first)
        for scope in [ControlScope.global, try .account("sample-secondary")] {
            var draft = EngineConfigurationDraft(baseline: .init(engine: engine, scope: scope))
            XCTAssertEqual(draft.effectiveValue(for: "per_order_fraction"), 0.2)
            XCTAssertEqual(draft.effectiveValue(for: "cluster_fraction"), 0.3)
            XCTAssertNotNil(draft.validationErrors["per_order_fraction"])
            XCTAssertNotNil(draft.validationErrors["cluster_fraction"])
            draft.setValue(0.5, for: "per_order_fraction")
            XCTAssertNotNil(draft.validationErrors["per_order_fraction"])
            XCTAssertThrowsError(try draft.intent(engineId: "default", host: "sample-runner",
                clientRequestId: UUID().uuidString))
        }
    }

    func testBackendEnvelopeTightensBothScopesAndChangesFingerprint() throws {
        var engine = try engine()
        let original = EngineConfigurationBaseline(engine: engine, scope: .global)
        engine.riskEnvelope = RiskEnvelope(maxima: ["per_order_fraction": 0.05], digest: "tighter")
        XCTAssertNotEqual(original.fingerprint, EngineConfigurationBaseline(engine: engine, scope: .global).fingerprint)
        for scope in [ControlScope.global, try .account("sample-main")] {
            var draft = EngineConfigurationDraft(baseline: .init(engine: engine, scope: scope))
            XCTAssertNotNil(draft.validationErrors["per_order_fraction"])
            draft.setValue(0.05, for: "per_order_fraction")
            XCTAssertNil(draft.validationErrors["per_order_fraction"])
            XCTAssertNoThrow(try draft.intent(engineId: "default", host: "sample-runner",
                clientRequestId: UUID().uuidString))
        }
    }

    func testRestoringUnsafeGlobalValueBlocksAndEqualBrakeStopConflicts() throws {
        let response = try response().applyingConfigure(EngineConfigureValue(engineId: "default",
            set: ["per_order_fraction": 0.5], unset: nil, enabledChange: .unchanged),
            scope: .global, newRevision: "unsafe", observedAt: "now")
            .applyingConfigure(EngineConfigureValue(engineId: "default", set: ["per_order_fraction": 0.05],
                unset: nil, enabledChange: .unchanged), scope: .account("sample-secondary"),
                newRevision: "safe-account", observedAt: "now")
        var draft = EngineConfigurationDraft(baseline: .init(engine: try XCTUnwrap(response.engines?.first),
            scope: try .account("sample-secondary")))
        XCTAssertNil(draft.validationErrors["per_order_fraction"])
        draft.useGlobal(for: "per_order_fraction")
        XCTAssertNotNil(draft.validationErrors["per_order_fraction"])
        XCTAssertThrowsError(try draft.intent(engineId: "default", host: "sample-runner", clientRequestId: UUID().uuidString))
        draft.setValue(0.10, for: "per_order_fraction")
        draft.setValue(0.15, for: "drawdown_brake_fraction")
        draft.setValue(0.15, for: "drawdown_stop_fraction")
        XCTAssertTrue(draft.conflicts.contains { $0.id == "drawdown-order" && $0.severity == .error })
    }

    func testAccountInheritanceAndOverride() throws {
        var value = try draft(.account("sample-secondary"))
        XCTAssertEqual(value.source(for: "edge_threshold_cents"), .overridden)
        XCTAssertEqual(value.currentValue(for: "edge_threshold_cents"), 5)
        XCTAssertEqual(value.effectiveValue(for: "edge_threshold_cents"), 5)
        XCTAssertEqual(value.source(for: "size_fraction"), .inherited)
        XCTAssertEqual(value.currentValue(for: "size_fraction"), 0.1)
        XCTAssertEqual(value.effectiveEnabled, false)
        XCTAssertEqual(value.baseline.overrideEnabled, false)
        value.useGlobal(for: "edge_threshold_cents")
        XCTAssertEqual(value.unset, ["edge_threshold_cents"])
        XCTAssertEqual(value.changeCount, 1)
        XCTAssertEqual(value.effectiveValue(for: "edge_threshold_cents"), 3.5)
        XCTAssertEqual(value.source(for: "edge_threshold_cents"), .drafted)
        value.discard(key: "edge_threshold_cents")
        XCTAssertEqual(value.changeCount, 0)
        var inherited = try draft(.account("sample-main"))
        inherited.useGlobal(for: "edge_threshold_cents")
        XCTAssertEqual(inherited.changeCount, 0)
    }

    func testSetValueDropsNoOpEdits() throws {
        var value = try draft()
        value.setValue(0.1, for: "size_fraction")
        XCTAssertEqual(value.changeCount, 0)
        value.setValue(0.2, for: "size_fraction")
        XCTAssertEqual(value.changeCount, 1)
        value.setValue(0.1, for: "size_fraction")
        XCTAssertEqual(value.changeCount, 0)
        var account = try draft(.account("sample-secondary"))
        account.setValue(5, for: "edge_threshold_cents")
        XCTAssertEqual(account.changeCount, 0)
        account.setValue(0.1, for: "size_fraction")
        XCTAssertEqual(account.changeCount, 1, "An explicit override still changes future inheritance.")
        account.discardAll()
        XCTAssertFalse(account.hasChanges)
    }

    func testMultiSettingIntent() throws {
        var value = try draft()
        value.setValue(0.2, for: "size_fraction")
        value.setValue(15, for: "min_k")
        value.setEnabled(false)
        XCTAssertEqual(value.changeCount, 3)
        let id = UUID().uuidString
        let intent = try value.intent(engineId: "default", host: "sample-runner", clientRequestId: id)
        XCTAssertEqual(intent.kind, .configure)
        XCTAssertEqual(intent.scope, .global)
        XCTAssertEqual(intent.host, "sample-runner")
        XCTAssertEqual(intent.clientRequestId, id)
        XCTAssertEqual(intent.expectedRevision, "global-default-r1")
        guard case let .configure(configure) = intent.value else { return XCTFail("Expected configure") }
        XCTAssertEqual(configure.set, ["size_fraction": 0.2, "min_k": 15])
        XCTAssertNil(configure.unset)
        XCTAssertEqual(configure.enabledChange, .value(false))
        XCTAssertEqual(intent.value.displayValue, "default: 2 settings changed, entries off")

        var account = try draft(.account("sample-secondary"))
        account.setValue(15, for: "min_k")
        account.useGlobal(for: "edge_threshold_cents")
        account.inheritEnabled()
        let accountIntent = try account.intent(engineId: "default", host: "sample-runner", clientRequestId: UUID().uuidString)
        guard case let .configure(accountValue) = accountIntent.value else { return XCTFail("Expected configure") }
        XCTAssertEqual(accountValue.set, ["min_k": 15])
        XCTAssertEqual(accountValue.unset, ["edge_threshold_cents"])
        XCTAssertEqual(accountValue.enabledChange, .inherit)
        XCTAssertEqual(accountIntent.expectedRevision, "secondary-default-r1")
        XCTAssertEqual(accountIntent.value.displayValue, "default: 1 setting changed, 1 use global, entries use global")
        var inherited = try draft(.account("sample-main"))
        inherited.inheritEnabled()
        XCTAssertEqual(inherited.enabledChange, .unchanged)
        value.useGlobal(for: "size_fraction")
        value.inheritEnabled()
        XCTAssertTrue(value.unset.isEmpty)
        XCTAssertNotEqual(value.enabledChange, .inherit)
    }

    func testChangesListOldNewScopeEffect() throws {
        var value = try draft()
        value.setValue(0.2, for: "size_fraction")
        value.setValue(15, for: "min_k")
        value.setEnabled(false)
        XCTAssertEqual(value.changes.map(\.id), ["size_fraction", "min_k", "enabled"])
        let size = try XCTUnwrap(value.changes.first)
        XCTAssertEqual(size.name, "Position size")
        XCTAssertEqual(size.oldText, "10%")
        XCTAssertEqual(size.newText, "20%")
        XCTAssertEqual(size.scopeText, "All accounts")
        XCTAssertEqual(size.effect, PolicyCatalog.parameter(for: "size_fraction")?.whenHigher)
        XCTAssertEqual(value.changes[1].oldText, "12")
        XCTAssertEqual(value.changes[1].newText, "15")
        XCTAssertEqual(value.changes.last?.effect, "Blocks new positions in this scope. Existing positions keep their normal exit and risk handling.")
        var account = try draft(.account("sample-secondary"))
        account.useGlobal(for: "edge_threshold_cents")
        let change = try XCTUnwrap(account.changes(accountLabel: "Secondary subaccount (sample)").first)
        XCTAssertEqual(change.oldText, "5¢")
        XCTAssertEqual(change.newText, "Use global (3.5¢)")
        XCTAssertEqual(change.scopeText, "Secondary subaccount (sample)")
        XCTAssertEqual(change.effect, "Restores the global value.")
    }

    func testValidationAndConflictsBlock() throws {
        var value = try draft()
        value.setValue(0.1, for: "drawdown_stop_fraction")
        XCTAssertTrue(value.blockingProblems.contains("Drawdown stop must be above Drawdown slowdown, or the runner will reject the change."))
        value.setValue(0.9, for: "size_fraction")
        XCTAssertNotNil(value.validationErrors["size_fraction"])
        XCTAssertFalse(value.blockingProblems.isEmpty)
        XCTAssertThrowsError(try value.intent(engineId: "default", host: "sample-runner", clientRequestId: UUID().uuidString))
        value.discardAll()
        value.setValue(50, for: "min_price_cents")
        value.setValue(40, for: "max_price_cents")
        XCTAssertTrue(value.blockingProblems.isEmpty)
        XCTAssertEqual(value.conflicts.map(\.id), ["price-order"])
    }

    func testSavedAndInheritedInvalidValuesBlockUntilCorrected() throws {
        let original = try response()
        let unsafe = EngineConfigureValue(engineId: "default", set: ["size_fraction": 0.9],
                                          unset: nil, enabledChange: .unchanged)
        for unsafeScope in [ControlScope.global, try .account("sample-secondary")] {
            let updated = original.applyingConfigure(unsafe, scope: unsafeScope,
                                                     newRevision: "unsafe", observedAt: "now")
            let engine = try XCTUnwrap(updated.engines?.first { $0.engineId == "default" })
            let scopes = unsafeScope.kind == .global
                ? [ControlScope.global, try .account("sample-main")] : [unsafeScope]
            for scope in scopes {
                var value = EngineConfigurationDraft(baseline: EngineConfigurationBaseline(engine: engine, scope: scope))
                XCTAssertNotNil(value.validationErrors["size_fraction"])
                XCTAssertEqual(value.effectiveValue(for: "size_fraction"), 0.9)
                value.setValue(15, for: "min_k")
                XCTAssertThrowsError(try value.intent(engineId: "default", host: "sample-runner",
                                                      clientRequestId: UUID().uuidString))
                value.setValue(0.1, for: "size_fraction")
                XCTAssertNil(value.validationErrors["size_fraction"])
                XCTAssertNoThrow(try value.intent(engineId: "default", host: "sample-runner",
                                                  clientRequestId: UUID().uuidString))
            }
        }
    }

    func testApplyingConfigureRecomputesEffective() throws {
        let original = try response()
        let global = EngineConfigureValue(engineId: "default", set: ["min_k": 15], unset: nil, enabledChange: .unchanged)
        let applied = original.applyingConfigure(global, scope: .global, newRevision: "new-global", observedAt: "now")
        let engine = try XCTUnwrap(applied.engines?.first)
        XCTAssertEqual(engine.configuration?.global.policy?["min_k"], 15)
        XCTAssertEqual(engine.policy?["min_k"], 15)
        XCTAssertEqual(engine.configuration?.global.revision, "new-global")
        XCTAssertEqual(engine.configuration?.global.observedAt, "now")
        XCTAssertEqual(engine.configuration?.global.freshness, "fresh")
        XCTAssertNil(engine.configuration?.global.pending)
        for account in try XCTUnwrap(engine.configuration?.accounts) {
            XCTAssertEqual(account.effective.policy?["min_k"], 15)
        }
        XCTAssertEqual(engine.configuration?.accounts.last?.effective.policy?["edge_threshold_cents"], 5)
        XCTAssertEqual(engine.configuration?.accounts.last?.effective.enabled, false)
        let account = EngineConfigureValue(engineId: "default", set: nil, unset: ["edge_threshold_cents"], enabledChange: .inherit)
        let restored = original.applyingConfigure(account, scope: try .account("sample-secondary"), newRevision: "new-account", observedAt: "now")
        let secondary = try XCTUnwrap(restored.engines?.first?.configuration?.accounts.last)
        XCTAssertTrue(secondary.override.policy.isEmpty)
        XCTAssertNil(secondary.override.enabled)
        XCTAssertEqual(secondary.effective.policy?["edge_threshold_cents"], 3.5)
        XCTAssertEqual(secondary.effective.enabled, true)
        XCTAssertEqual(secondary.revision, "new-account")
        XCTAssertEqual(secondary.observedAt, "now")
        XCTAssertEqual(secondary.freshness, "fresh")
        XCTAssertNil(secondary.pending)
        let unknown = EngineConfigureValue(engineId: "missing", set: ["min_k": 15], unset: nil, enabledChange: .unchanged)
        let encoder = JSONEncoder()
        encoder.outputFormatting = .sortedKeys
        XCTAssertEqual(try encoder.encode(original.applyingConfigure(unknown, scope: .global, newRevision: "new", observedAt: "now")),
                       try encoder.encode(original))
    }

    func testFingerprintChangesOnRevisionOrValues() throws {
        let original = try response()
        let baseline = EngineConfigurationBaseline(engine: try engine(), scope: .global)
        let configure = EngineConfigureValue(engineId: "default", set: ["min_k": 15], unset: nil, enabledChange: .unchanged)
        for (set, revision) in [(configure.set, "global-default-r1"), (nil, "different-revision")] {
            let value = EngineConfigureValue(engineId: "default", set: set, unset: nil, enabledChange: .unchanged)
            let changed = original.applyingConfigure(value, scope: .global, newRevision: revision, observedAt: "now")
            let newBaseline = EngineConfigurationBaseline(engine: try XCTUnwrap(changed.engines?.first), scope: .global)
            XCTAssertNotEqual(baseline.fingerprint, newBaseline.fingerprint)
        }
        XCTAssertEqual(baseline.fingerprint, EngineConfigurationBaseline(engine: try engine(), scope: .global).fingerprint)
        var missingRevision = try engine()
        let global = try XCTUnwrap(missingRevision.configuration?.global)
        missingRevision.configuration = EngineConfiguration(global: EngineGlobalConfiguration(enabled: global.enabled,
            policy: global.policy, revision: nil, observedAt: global.observedAt, freshness: global.freshness, pending: nil), accounts: [])
        var missing = EngineConfigurationDraft(baseline: EngineConfigurationBaseline(engine: missingRevision, scope: .global))
        missing.setValue(15, for: "min_k")
        XCTAssertThrowsError(try missing.intent(engineId: "default", host: "sample-runner", clientRequestId: UUID().uuidString))
    }
}
