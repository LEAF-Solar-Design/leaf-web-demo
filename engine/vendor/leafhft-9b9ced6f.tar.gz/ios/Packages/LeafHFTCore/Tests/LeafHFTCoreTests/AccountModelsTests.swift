import Foundation
import XCTest
@testable import LeafHFTCore

func fixtureData(_ name: String, extension ext: String = "json") throws -> Data {
    let url = try XCTUnwrap(Bundle.module.url(forResource: name, withExtension: ext, subdirectory: "Fixtures"))
    return try Data(contentsOf: url)
}

final class AccountModelsTests: XCTestCase {
    func testTradingPocketUsesExchangeIndexTwo() throws {
        let value = try accountJSONDecoder().decode(AccountBalance.self, from: fixtureData("balance"))
        XCTAssertEqual(value.tradingPocketCents, value.cashCents(exchangeIndex: 2))
        XCTAssertEqual(KashbotTradingPocket.exchangeIndex, 2)
    }

    func testBalanceAddsCashToPositionsMark() throws {
        let value = try accountJSONDecoder().decode(AccountBalance.self, from: fixtureData("balance"))
        XCTAssertEqual(value.balance, 2388)
        XCTAssertEqual(value.positionsMark?.cents, Cents(0))
        XCTAssertEqual(value.accountValue?.cents, Cents(2388))
        XCTAssertEqual(value.cashCents(exchangeIndex: 2), Cents(2388))
        XCTAssertNil(value.cashCents(exchangeIndex: 99))
        XCTAssertEqual(value.updatedTs, 1789257600)
        let missing = try accountJSONDecoder().decode(AccountBalance.self, from: Data("{}".utf8))
        XCTAssertNil(missing.cash)
        XCTAssertNil(missing.accountValue)
        for json in [#"{"balance":2388}"#, #"{"portfolio_value":42}"#] {
            XCTAssertNil(try accountJSONDecoder().decode(AccountBalance.self, from: Data(json.utf8)).accountValue)
        }
        let marked = try accountJSONDecoder().decode(AccountBalance.self,
            from: Data(#"{"balance":2388,"portfolio_value":142}"#.utf8))
        XCTAssertEqual(marked.accountValue?.cents, Cents(2530))
    }
    func testPocketDecimalAndInvalidValue() throws {
        let value = try accountJSONDecoder().decode(AccountBalance.self,
            from: Data(#"{"balance_breakdown":[{"balance":"0.015","exchange_index":2},{"balance":"bad","exchange_index":3}]}"#.utf8))
        XCTAssertEqual(value.cashCents(exchangeIndex: 2), Cents(2))
        XCTAssertNil(value.cashCents(exchangeIndex: 3))
    }
    func testPositions() throws {
        let result = try accountJSONDecoder().decode(PositionsResponse.self, from: fixtureData("positions"))
        XCTAssertEqual(result.cursor, "next-position")
        XCTAssertEqual(result.marketPositions?.first?.positionFp, "1.50")
        XCTAssertEqual(result.marketPositions?.first?.exposure?.cents, Cents(42))
    }
    func testFillsAndSettlementsPreserveDecimals() throws {
        let fills = try accountJSONDecoder().decode(FillsResponse.self, from: fixtureData("fills"))
        XCTAssertEqual(fills.fills?.first?.feeCost, "0.0150")
        XCTAssertEqual(fills.fills?.first?.fee?.exactDollars, Decimal(string: "0.0150"))
        XCTAssertEqual(fills.fills?.first?.tradeId, "trade-fixture")
        let settlements = try accountJSONDecoder().decode(SettlementsResponse.self, from: fixtureData("settlements"))
        XCTAssertEqual(settlements.settlements?.first?.yesCountFp, "1.50")
        XCTAssertEqual(settlements.settlements?.first?.payout?.cents, Cents(150))
    }
    func testIdentityRequiredAndOptionalFieldsMissing() throws {
        XCTAssertThrowsError(try accountJSONDecoder().decode(Fill.self, from: Data("{}".utf8)))
        let fill = try accountJSONDecoder().decode(Fill.self, from: Data(#"{"ticker":"T","trade_id":"F","future":true}"#.utf8))
        XCTAssertNil(fill.yesPrice)
    }
}
