import Foundation
import XCTest
@testable import LeafHFTCore

final class AttemptFunnelTests: XCTestCase {
    private func funnel() throws -> AttemptFunnel {
        try accountJSONDecoder().decode(AttemptFunnel.self, from: fixtureData("attempt-funnel"))
    }
    private func object() throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData("attempt-funnel")) as? [String: Any])
    }
    private func decode(_ object: [String: Any]) throws -> AttemptFunnel {
        try accountJSONDecoder().decode(AttemptFunnel.self, from: JSONSerialization.data(withJSONObject: object))
    }

    func testFullReadContractAndHelpers() throws {
        let value = try funnel()
        XCTAssertEqual(value.schema, "leaf.attempt-funnel.read.v1")
        XCTAssertEqual(value.status, .ok)
        XCTAssertNil(value.host)
        XCTAssertEqual(value.totals.yes, 812)
        XCTAssertEqual(value.stages.count, 9)
        XCTAssertEqual(value.stages.reduce(0) { $0 + $1.count }, value.totals.yes)
        XCTAssertEqual(value.engines.count, 3)
        XCTAssertEqual(value.engines[0].byStage["zero_fill"], 110)
        XCTAssertEqual(value.traces.count, 3)
        XCTAssertNil(value.traces[2].priceCents)
        XCTAssertNil(value.traces[2].quoteAgeMs)
        XCTAssertNil(value.traces[2].submitToAckMs)
        XCTAssertEqual(value.missedBeforeDecision?.staleQuoteEvals, 12345)
        XCTAssertEqual(value.coverage.hostsReporting, 1)
        XCTAssertEqual(value.fillRateText, "40% of 812 engine yeses filled")
        XCTAssertEqual(value.latencyLine(.decisionToSubmitMs), "p50 5 ms · p95 25 ms")
        XCTAssertEqual(value.latencyLine(.submitToAckMs), "p50 250 ms · p95 500 ms")
        XCTAssertEqual(value.latencyLine(.quoteAgeMs), "p50 250 ms · p95 1000 ms")
        XCTAssertEqual(value.interimLine, "372 order claims, 165 fills (44%)")
        XCTAssertEqual(value.windowLabel, "last 24 h")
    }

    func testStageOrderAndLossOrderIgnoreJSONOrder() throws {
        var value = try funnel()
        value.stages.reverse()
        XCTAssertEqual(value.stageRows.map(\.stage), [.halted, .riskBlocked, .conflict, .tooLate,
            .unexplained, .sendError, .zeroFill, .partial, .filled])
        XCTAssertEqual(value.lossRows.map(\.stage), [.zeroFill, .conflict, .riskBlocked, .partial,
            .tooLate, .unexplained, .halted, .sendError])
        XCTAssertEqual(value.stageRows[0].count, 10)
        XCTAssertEqual(value.stageRows[0].pct, 1.2)
        value.stages.removeAll { $0.stage == .halted }
        XCTAssertEqual(value.stageRows.count, 9)
        XCTAssertEqual(value.stageRows[0].count, 10)
    }

    func testNoDataPayloadAndNullTelemetry() throws {
        var payload = try object()
        payload["status"] = "no_data"
        payload["headline"] = "The runner has not reported attempts yet"
        var totals = try XCTUnwrap(payload["totals"] as? [String: Int])
        for key in Array(totals.keys) { totals[key] = 0 }
        payload["totals"] = totals
        var stages = try XCTUnwrap(payload["stages"] as? [[String: Any]])
        for i in stages.indices {
            stages[i]["count"] = 0
            stages[i]["pct"] = 0
            stages[i]["reasons"] = []
        }
        payload["stages"] = stages
        payload["engines"] = []
        payload["traces"] = []
        payload["latency"] = ["decision_to_submit_ms": ["p50": NSNull(), "p95": NSNull(), "n": 0],
                              "submit_to_ack_ms": ["p50": NSNull(), "p95": NSNull(), "n": 0],
                              "quote_age_ms": ["p50": NSNull(), "p95": NSNull(), "n": 0]] as [String: [String: Any]]
        payload["missed_before_decision"] = NSNull()
        payload["coverage"] = ["hosts_reporting": 0, "decision_rows_dropped": 0, "last_report_at": NSNull()] as [String: Any]
        var value = try decode(payload)
        XCTAssertEqual(value.status, .noData)
        XCTAssertEqual(value.headline, "The runner has not reported attempts yet")
        XCTAssertEqual(value.stageRows.count, 9)
        XCTAssertTrue(value.lossRows.isEmpty)
        XCTAssertEqual(value.fillRateText, "0% of 0 engine yeses filled")
        XCTAssertEqual(value.latencyLine(.decisionToSubmitMs), "No samples")
        XCTAssertEqual(value.latencyLine(.submitToAckMs), "No samples")
        XCTAssertEqual(value.latencyLine(.quoteAgeMs), "No samples")
        XCTAssertNil(value.latency.quoteAgeMs.p95)
        XCTAssertNil(value.coverage.lastReportAt)
        XCTAssertNil(value.missedBeforeDecision)
        XCTAssertEqual(value.interimLine, "372 order claims, 165 fills (44%)")
        value.interim?.claims = 0
        value.interim?.fills = 0
        XCTAssertEqual(value.interimLine, "0 order claims, 0 fills (0%)")
        payload["interim"] = NSNull()
        XCTAssertNil(try decode(payload).interimLine)
    }

    func testUnknownEnumsAndExtraKeysDoNotThrow() throws {
        var payload = try object()
        payload["status"] = "future_status"
        payload["future_key"] = true
        var stages = try XCTUnwrap(payload["stages"] as? [[String: Any]])
        stages[0]["stage"] = "future_stage"
        stages[0]["group"] = "future_group"
        payload["stages"] = stages
        var engines = try XCTUnwrap(payload["engines"] as? [[String: Any]])
        engines[0]["top_loss"] = ["stage": "future_stage", "count": 1] as [String: Any]
        engines[1]["top_loss"] = NSNull()
        payload["engines"] = engines
        var traces = try XCTUnwrap(payload["traces"] as? [[String: Any]])
        traces[0]["stage"] = "future_stage"
        for key in ["price_cents", "count", "quote_age_ms", "decision_to_submit_ms", "submit_to_ack_ms", "filled_count"] {
            traces[0][key] = NSNull()
        }
        payload["traces"] = traces
        payload["missed_before_decision"] = ["stale_quote_evals": NSNull(), "stale_index_evals": NSNull(), "evals": NSNull()]
        let value = try decode(payload)
        XCTAssertEqual(value.status, .unknown)
        XCTAssertEqual(value.stages[0].stage, .unknown)
        XCTAssertEqual(value.stages[0].group, .unknown)
        XCTAssertEqual(value.engines[0].topLoss?.stage, .unknown)
        XCTAssertNil(value.engines[1].topLoss)
        XCTAssertEqual(value.traces[0].stage, .unknown)
        XCTAssertNil(value.traces[0].count)
        XCTAssertNil(value.missedBeforeDecision?.evals)
        XCTAssertEqual(value.stageRows.count, 9)
    }
}
