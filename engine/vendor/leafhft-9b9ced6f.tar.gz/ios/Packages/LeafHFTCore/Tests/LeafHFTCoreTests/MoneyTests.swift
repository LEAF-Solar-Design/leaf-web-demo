import Foundation
import XCTest
@testable import LeafHFTCore

final class MoneyTests: XCTestCase {
    func testExactDecimalAndDisplay() throws {
        XCTAssertEqual(try Cents(decimalString: "12.34").formatted(), "$12.34")
        XCTAssertEqual(Cents(-5).formatted(), "-$0.05")
        let money = try Money(decimalString: "0.0150")
        XCTAssertEqual(money.exactDollars, Decimal(string: "0.0150"))
        XCTAssertEqual(money.cents, Cents(2))
        XCTAssertEqual(try Money(decimalString: "-0.015").cents, Cents(-2))
        XCTAssertLessThan(Cents(-1), Cents(0))
    }
    func testInvalidAndOverflow() {
        for input in ["", "12x", "1,000", "NaN", "1e4", "999999999999999999999999"] {
            XCTAssertThrowsError(try Money(decimalString: input))
        }
    }
    func testCentsWireIsInteger() throws {
        XCTAssertEqual(try JSONEncoder().encode(Cents(123)), Data("123".utf8))
        XCTAssertEqual(try JSONDecoder().decode(Cents.self, from: Data("-5".utf8)), Cents(-5))
    }
}
