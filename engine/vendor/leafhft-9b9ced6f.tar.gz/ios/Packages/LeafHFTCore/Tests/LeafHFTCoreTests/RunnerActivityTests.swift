import Foundation
import XCTest
@testable import LeafHFTCore

final class RunnerActivityTests: XCTestCase {
    func testOptionalAccountAbsentNullAndPresent() throws {
        for account in ["", ",\"account\":null",
                        #", "account":{"source":"lane_cash","observed_at":"2026-09-29T19:40:00.123Z","cash_cents":9968,"portfolio_value_cents":null,"positions":null,"positions_complete":false}"#] {
            let json = """
            {"schema_version":1,"generated_at":"2026-09-29T19:40:00Z","host":"sample",
             "orders":[],"fills":[],"refusals":[]\(account)}
            """
            let activity = try accountJSONDecoder().decode(RunnerActivity.self, from: Data(json.utf8))
            if account.contains("lane_cash") {
                XCTAssertEqual(activity.account?.source, .laneCash)
                XCTAssertEqual(activity.account?.cashCents, 9968)
                XCTAssertNotNil(activity.account?.observedDate)
            } else {
                XCTAssertNil(activity.account)
            }
        }
    }

    func testSanitizedActivityFixtureDecodesExactBudgetAndRows() throws {
        let activity = try accountJSONDecoder().decode(RunnerActivity.self, from: fixtureData("activity"))
        XCTAssertEqual(activity.schemaVersion, 1)
        XCTAssertEqual(activity.budget?.freeCashCents, 2_388)
        XCTAssertEqual(activity.budget?.perBookStakeCents, 500)
        XCTAssertEqual(activity.budget?.aggregateStakeCents, 7_000)
        XCTAssertEqual(activity.budget?.bookCount, 14)
        XCTAssertEqual(activity.budget?.cashStatus, "Available for one book")
        XCTAssertEqual(activity.budget?.totalClaims, 8)
        XCTAssertEqual(activity.budget?.totalFills, 5)
        XCTAssertEqual(activity.budget?.submittedCents, 336)
        XCTAssertEqual(activity.budget?.filledCents, 214)
        XCTAssertEqual(activity.budget?.cashRefusals, 1)
        XCTAssertEqual(activity.orders.first?.safeTicker, "FIXTURE-T")
        XCTAssertEqual(activity.orders.first?.stateLabel, "Filled")
        XCTAssertEqual(activity.fills.first?.sideLabel, "Yes")
        XCTAssertEqual(activity.refusals.first?.refusalLabel, "Cash floor protected")
    }

    func testNullableBudgetRemainsUnavailableRatherThanZero() throws {
        let json = #"{"schema_version":1,"generated_at":"2026-09-20T12:00:00Z","host":"fixture-host","budget":null,"orders":[],"fills":[],"refusals":[]}"#
        let activity = try accountJSONDecoder().decode(RunnerActivity.self, from: Data(json.utf8))
        XCTAssertNil(activity.budget)
    }

    func testUnknownProducerTextIsNotRenderedVerbatim() throws {
        let json = #"{"ticker":"private value","kind":"order","state":"secret-state","occurred_at":"2026-09-20T12:00:00Z","reason":"private-reason"}"#
        let row = try accountJSONDecoder().decode(RunnerActivityRow.self, from: Data(json.utf8))
        XCTAssertEqual(row.safeTicker, "Unknown market")
        XCTAssertEqual(row.stateLabel, "Unknown")
        XCTAssertEqual(row.refusalLabel, "Runner declined the order")
    }

    func testClosedTradeEconomicsAndAttributionAreDerivedFromSanitizedFields() throws {
        let json = #"{"ticker":"KXBTC-25SEP","kind":"settle","state":"filled","side":"yes","count":2,"price_cents":41,"cost_cents":82,"fee_cents":3,"pnl_cents":-82,"cost_basis_cents":82,"close_kind":"full_loss","engine_id":"darkhorse-v3","occurred_at":"2026-09-20T12:00:00Z"}"#
        let row = try accountJSONDecoder().decode(RunnerActivityRow.self, from: Data(json.utf8))
        XCTAssertEqual(row.pnlPercent, -100)
        XCTAssertEqual(NSDecimalNumber(decimal: row.feeShareOfPnlPercent ?? 0).doubleValue, 3.6585, accuracy: 0.0001)
        XCTAssertEqual(row.outcomeLabel, "Full position loss")
        XCTAssertEqual(row.safeEngineLabel, "darkhorse-v3")
    }

    func testCashoutAndUnsafeEngineHaveBoundedLabels() throws {
        let json = #"{"ticker":"KXETH","kind":"exit","state":"filled","pnl_cents":27,"cost_basis_cents":54,"close_kind":"cashout","engine_id":"secret engine/path","occurred_at":"2026-09-20T12:00:00Z"}"#
        let row = try accountJSONDecoder().decode(RunnerActivityRow.self, from: Data(json.utf8))
        XCTAssertEqual(row.pnlPercent, 50)
        XCTAssertEqual(row.outcomeLabel, "Cashout")
        XCTAssertNil(row.safeEngineLabel)
    }
}
