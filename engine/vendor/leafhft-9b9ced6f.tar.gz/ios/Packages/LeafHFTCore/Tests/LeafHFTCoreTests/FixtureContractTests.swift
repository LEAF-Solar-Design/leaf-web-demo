import Foundation
import XCTest
@testable import LeafHFTCore

final class FixtureContractTests: XCTestCase {
    func testActivityTopLevelContract() throws {
        try assertTopLevelKeys("activity", equalTo: [
            "schema_version", "generated_at", "host", "budget", "orders", "fills", "refusals"
        ])
    }

    func testEngineLabTopLevelContract() throws {
        try assertTopLevelKeys("engine-lab", equalTo: ["schema_version", "reviewed_at", "lanes"])
    }

    func testBalanceTopLevelContract() throws {
        try assertTopLevelKeys("balance", equalTo: [
            "balance", "balance_breakdown", "portfolio_value", "updated_ts"
        ])
    }

    func testBooksTopLevelContract() throws {
        try assertTopLevelKeys("books", equalTo: [
            "schema_version", "generated_at", "books"
        ])
    }

    func testEnginesTopLevelContract() throws {
        try assertTopLevelKeys("engines", equalTo: [
            "success", "engines", "bindings", "generated_at", "accounts"
        ])
    }

    func testFillsTopLevelContract() throws {
        try assertTopLevelKeys("fills", equalTo: ["fills", "cursor"])
    }

    func testProbesTopLevelContract() throws {
        try assertTopLevelKeys("probes", equalTo: ["account", "engines", "observed_at"])
    }

    func testPositionsTopLevelContract() throws {
        try assertTopLevelKeys("positions", equalTo: ["market_positions", "cursor"])
    }

    func testSettlementsTopLevelContract() throws {
        try assertTopLevelKeys("settlements", equalTo: ["settlements", "cursor"])
    }

    func testSignatureTopLevelContract() throws {
        try assertTopLevelKeys("signature-fixture", equalTo: [
            "note", "timestamp_ms", "path", "message",
            "public_key_pkcs1_der_hex", "public_key_spki_der_hex", "signature_hex"
        ])
    }

    func testSignatureFixtureDecodesAllFields() throws {
        let fixture = try JSONDecoder().decode(
            SignatureFixture.self, from: fixtureData("signature-fixture")
        )
        XCTAssertFalse(fixture.note.isEmpty)
        let timestamp = try XCTUnwrap(Int64(fixture.timestampMs))
        XCTAssertEqual(timestamp, 1757800000000)
        XCTAssertEqual(fixture.path, "/trade-api/v2/portfolio/balance")
        XCTAssertEqual(
            Data(fixture.message.utf8),
            canonicalSigningMessage(timestampMs: timestamp, path: fixture.path)
        )
        // These are public artifacts. This checks their encoding, not cryptographic validity.
        assertHex(fixture.publicKeyPKCS1DERHex, byteCount: 270)
        assertHex(fixture.publicKeySPKIDERHex, byteCount: 294)
        assertHex(fixture.signatureHex, byteCount: 256)
    }

    private func assertTopLevelKeys(
        _ name: String, equalTo expected: Set<String>,
        file: StaticString = #filePath, line: UInt = #line
    ) throws {
        let object = try XCTUnwrap(
            try JSONSerialization.jsonObject(with: fixtureData(name)) as? [String: Any],
            "\(name) must be a JSON object", file: file, line: line
        )
        // Codable ignores unknown keys, so compare the complete raw key set separately.
        XCTAssertEqual(Set(object.keys), expected, "\(name) top-level contract", file: file, line: line)
    }

    private func assertHex(
        _ value: String, byteCount: Int,
        file: StaticString = #filePath, line: UInt = #line
    ) {
        XCTAssertEqual(value.utf8.count, byteCount * 2, file: file, line: line)
        XCTAssertTrue(
            value.utf8.allSatisfy { (48...57).contains($0) || (97...102).contains($0) },
            "Expected lowercase hexadecimal bytes", file: file, line: line
        )
    }
}

// The signing artifact has no production response model. Keep its decoder test-local.
private struct SignatureFixture: Decodable {
    let note: String
    let timestampMs: String
    let path: String
    let message: String
    let publicKeyPKCS1DERHex: String
    let publicKeySPKIDERHex: String
    let signatureHex: String

    enum CodingKeys: String, CodingKey {
        case note, path, message
        case timestampMs = "timestamp_ms"
        case publicKeyPKCS1DERHex = "public_key_pkcs1_der_hex"
        case publicKeySPKIDERHex = "public_key_spki_der_hex"
        case signatureHex = "signature_hex"
    }
}
