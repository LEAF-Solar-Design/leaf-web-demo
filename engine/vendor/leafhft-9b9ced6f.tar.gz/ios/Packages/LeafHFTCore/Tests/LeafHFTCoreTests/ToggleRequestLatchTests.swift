import Foundation
import XCTest
@testable import LeafHFTCore

final class ToggleRequestLatchTests: XCTestCase {
    private let start = Date(timeIntervalSince1970: 2_000_000_000)

    func testAppliedClearsAndExternalChangeWins() {
        var latch = ToggleRequestLatch()
        latch.request(id: "book", desired: true, clientRequestId: "request", at: start)
        XCTAssertTrue(latch.effective(id: "book", observed: false, fallback: false))
        latch.reconcile(id: "book", observed: false, request: .applied, now: start)
        XCTAssertFalse(latch.isPending(id: "book"))
        XCTAssertFalse(latch.effective(id: "book", observed: false, fallback: true))
        XCTAssertTrue(latch.entries.isEmpty)
    }

    func testRejectedClearsAndShowsObservedValue() {
        var latch = ToggleRequestLatch()
        latch.request(id: "book", desired: false, clientRequestId: "request", at: start)
        latch.reconcile(id: "book", observed: true, request: .rejected, now: start)
        XCTAssertFalse(latch.isPending(id: "book"))
        XCTAssertTrue(latch.effective(id: "book", observed: true, fallback: false))
    }

    func testMatchingObservationStaysPendingUntilTerminalOrMissing() {
        for resolution: ToggleRequestLatch.RequestState in [.applied, .missing] {
            var latch = ToggleRequestLatch()
            latch.request(id: "book", desired: true, clientRequestId: "request", at: start)
            latch.reconcile(id: "book", observed: true, request: .pending, now: start)
            XCTAssertTrue(latch.isPending(id: "book"))
            latch.reconcile(id: "book", observed: true, request: resolution, now: start)
            XCTAssertFalse(latch.isPending(id: "book"))
        }
    }

    func testUnresolvedStatesUseExistingPolicyBoundary() {
        let ttl = UnresolvedControlPolicy.timeToLive
        for state: ToggleRequestLatch.RequestState in [.pending, .unknown] {
            var latch = ToggleRequestLatch()
            latch.request(id: "book", desired: true, clientRequestId: "request", at: start)
            for age in [ttl - 1, ttl] {
                latch.reconcile(id: "book", observed: false, request: state, now: start.addingTimeInterval(age))
                XCTAssertTrue(latch.isPending(id: "book"))
            }
            latch.reconcile(id: "book", observed: false, request: state, now: start.addingTimeInterval(ttl + 1))
            XCTAssertFalse(latch.isPending(id: "book"))
        }
    }

    func testMissingMismatchClearsAtGraceBoundaryAndShowsObservedValue() {
        XCTAssertEqual(ToggleRequestLatch.missingGrace, 45)
        var latch = ToggleRequestLatch()
        latch.request(id: "book", desired: true, clientRequestId: "request", at: start)
        latch.reconcile(id: "book", observed: false, request: .missing, now: start.addingTimeInterval(44))
        XCTAssertTrue(latch.isPending(id: "book"))
        XCTAssertTrue(latch.effective(id: "book", observed: false, fallback: false))
        latch.reconcile(id: "book", observed: false, request: .missing, now: start.addingTimeInterval(45))
        XCTAssertFalse(latch.isPending(id: "book"))
        XCTAssertFalse(latch.effective(id: "book", observed: false, fallback: true))
    }

    func testUnknownMatchingObservationDoesNotClearBeforeExpiry() {
        var latch = ToggleRequestLatch()
        latch.request(id: "book", desired: true, clientRequestId: "request", at: start)
        latch.reconcile(id: "book", observed: true, request: .unknown, now: start)
        XCTAssertTrue(latch.isPending(id: "book"))
    }

    func testMissingWithoutObservationWaitsAndClockRollbackUsesPolicy() {
        var latch = ToggleRequestLatch()
        latch.request(id: "book", desired: false, clientRequestId: "request", at: start)
        latch.reconcile(id: "book", observed: nil, request: .missing, now: start)
        XCTAssertTrue(latch.isPending(id: "book"))
        latch.reconcile(id: "book", observed: nil, request: .unknown, now: start.addingTimeInterval(-61))
        XCTAssertFalse(latch.isPending(id: "book"))
    }

    func testSubmissionFailureAndReconciliationAffectOnlyTheirID() {
        var latch = ToggleRequestLatch()
        latch.request(id: "book", desired: true, clientRequestId: "book-request", at: start)
        latch.request(id: "engine", desired: false, clientRequestId: "engine-request", at: start)
        latch.submissionFailed(id: "book")
        XCTAssertFalse(latch.isPending(id: "book"))
        XCTAssertTrue(latch.isPending(id: "engine"))
        XCTAssertFalse(latch.effective(id: "engine", observed: true, fallback: true))
        latch.reconcile(id: "absent", observed: nil, request: .applied, now: start)
        XCTAssertEqual(latch.entries.count, 1)
        latch.reconcile(id: "engine", observed: false, request: .missing, now: start)
        XCTAssertTrue(latch.entries.isEmpty)
        XCTAssertTrue(latch.effective(id: "book", observed: nil, fallback: true))
        XCTAssertFalse(latch.effective(id: "book", observed: nil, fallback: false))
    }

    func testNewRequestReplacesIdentityAndResetsExpiry() {
        var latch = ToggleRequestLatch()
        latch.request(id: "book", desired: true, clientRequestId: "old", at: start)
        let later = start.addingTimeInterval(UnresolvedControlPolicy.timeToLive)
        latch.request(id: "book", desired: false, clientRequestId: "new", at: later)
        XCTAssertEqual(latch.entries["book"], .init(desired: false, clientRequestId: "new", requestedAt: later))
        latch.reconcile(id: "book", observed: true, request: .pending, now: later.addingTimeInterval(1))
        XCTAssertTrue(latch.isPending(id: "book"))
    }
}
