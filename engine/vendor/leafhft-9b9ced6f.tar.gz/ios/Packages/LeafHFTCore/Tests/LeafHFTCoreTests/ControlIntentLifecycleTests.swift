import Foundation
import XCTest
@testable import LeafHFTCore

final class ControlIntentLifecycleTests: XCTestCase {
    private let clientId = "44444444-4444-4444-8444-444444444444"

    private func snakeEncoder() -> JSONEncoder {
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        encoder.outputFormatting = .sortedKeys
        return encoder
    }

    private func request(kind: String, value: String) throws -> ControlRequest {
        try accountJSONDecoder().decode(ControlRequest.self, from: Data(
            #"{"id":"r1","kind":"\#(kind)","value":\#(value),"state":"requested"}"#.utf8))
    }

    private func roundTrip(_ request: ControlRequest) throws -> ControlRequest {
        try accountJSONDecoder().decode(ControlRequest.self, from: snakeEncoder().encode(request))
    }

    func testEveryKindDecodesItsOwnBodyAndRoundTrips() throws {
        let cases: [(String, String, ControlValue)] = [
            ("engine.bind", #""all=default""#, .legacy("all=default")),
            ("engine.set", #""default:min_k=12""#, .legacy("default:min_k=12")),
            ("engine.create", #""{\"engine_id\":\"new\"}""#, .legacy(#"{"engine_id":"new"}"#)),
            ("engine.configure", #"{"engine_id":"default","enabled":false,"set":{"min_k":12}}"#,
             .configure(EngineConfigureValue(engineId: "default", set: ["min_k": 12], unset: nil, enabledChange: .value(false)))),
            ("book.configure", #"{"book_id":"BTC-15M","enabled":true}"#,
             .bookConfigure(BookConfigureValue(bookId: "BTC-15M", enabled: true))),
            ("engine.probe", #"{"engine_id":"aggr-2","symbols":["BTC-15M","ETH-15M"],"approval":"tok.sig","expires_at":"2026-10-14T00:00:00Z","bind":true}"#,
             .probe(ProbeControlValue(engineId: "aggr-2", symbols: ["BTC-15M", "ETH-15M"], approval: "tok.sig",
                                      expiresAt: "2026-10-14T00:00:00Z", bind: true))),
            ("engine.halt", #"{"engine_id":"aggr-2","reason":"operator"}"#,
             .halt(HaltControlValue(engineId: "aggr-2", reason: "operator"))),
            ("engine.assign", #"{"engine_id":"aggr-2","account_id":"acct-1","domain":"kalshi"}"#,
             .assign(AssignControlValue(engineId: "aggr-2", accountId: "acct-1", domain: "kalshi"))),
            ("engine.graduate", #"{"engine_id":"aggr-2"}"#, .graduate(GraduateControlValue(engineId: "aggr-2"))),
            ("risk.breaker", #"{"scope":"engine","id":"aggr-2","pct":50}"#,
             .breaker(BreakerControlValue(scope: .engine, id: "aggr-2", pct: 50)))
        ]
        XCTAssertEqual(Set(cases.map { $0.0 }).count, 10)
        for (kind, body, expected) in cases {
            let decoded = try request(kind: kind, value: body)
            XCTAssertEqual(decoded.value, expected, kind)
            XCTAssertEqual(try roundTrip(decoded).value, expected, kind)
            XCTAssertNotNil(ControlKind(rawValue: kind), kind)
        }
    }

    func testBodyIsReadByKindNotByShape() throws {
        // A halt body carries engine_id, which the shape-based decoder read as a configure change (D-e).
        let halt = try request(kind: "engine.halt", value: #"{"engine_id":"aggr-2","reason":"operator"}"#)
        XCTAssertEqual(halt.value, .halt(HaltControlValue(engineId: "aggr-2", reason: "operator")))
        let probe = try request(kind: "engine.probe", value:
            #"{"engine_id":"aggr-2","symbols":["BTC-15M"],"approval":"t","expires_at":"2026-10-14T00:00:00Z","bind":false}"#)
        guard case .probe = probe.value else { return XCTFail("Expected a probe body") }
        // A body that does not match its kind is kept verbatim, never read as another kind.
        let mismatched = try request(kind: "engine.probe", value: #"{"engine_id":"aggr-2"}"#)
        // String-keyed dictionaries keep their wire keys under convertFromSnakeCase.
        XCTAssertEqual(mismatched.value, .unknown(.object(["engine_id": .string("aggr-2")])))
    }

    func testUnknownKindDecodesUnknownAndRoundTrips() throws {
        let retire = try request(kind: "engine.retire", value: #"{"engine_id":"aggr-2","note":"done"}"#)
        guard case let .unknown(raw)? = retire.value else { return XCTFail("Expected .unknown") }
        XCTAssertNotEqual(raw, .null)
        XCTAssertEqual(retire.value?.displayValue, "Unknown change")
        XCTAssertEqual(try roundTrip(retire).value, retire.value)
        XCTAssertEqual(retire.kind, "engine.retire")
        let shadow = try request(kind: "engine.shadow", value: #""on""#)
        XCTAssertEqual(shadow.value, .unknown(.string("on")))
    }

    func testMissingKindKeepsShapeDecodingAndNullValueIsNil() throws {
        let legacy = try accountJSONDecoder().decode(ControlRequest.self,
            from: Data(#"{"id":"r1","value":"all=default"}"#.utf8))
        XCTAssertEqual(legacy.value, .legacy("all=default"))
        let empty = try accountJSONDecoder().decode(ControlRequest.self,
            from: Data(#"{"id":"r1","kind":"engine.halt","value":null}"#.utf8))
        XCTAssertNil(empty.value)
        let absent = try accountJSONDecoder().decode(ControlRequest.self, from: Data(#"{"id":"r1"}"#.utf8))
        XCTAssertNil(absent.value)
    }

    func testProbeIntentBodyIsExact() throws {
        let intent = try ControlIntent.probe(engineId: "aggr-2", symbols: ["BTC-15M"], approval: "tok.sig",
            expiresAt: "2026-10-14T00:00:00Z", bind: true, clientRequestId: clientId)
        XCTAssertEqual(intent.kind.rawValue, "engine.probe")
        XCTAssertNil(intent.host)
        let object = try XCTUnwrap(try JSONSerialization.jsonObject(with: snakeEncoder().encode(intent)) as? [String: Any])
        let body = try XCTUnwrap(object["value"] as? [String: Any])
        XCTAssertEqual(Set(body.keys), ["engine_id", "symbols", "approval", "expires_at", "bind"])
        XCTAssertEqual(body["symbols"] as? [String], ["BTC-15M"])
        XCTAssertEqual(body["bind"] as? Bool, true)
        XCTAssertEqual(object["client_request_id"] as? String, clientId)
        let decoded = try accountJSONDecoder().decode(ControlIntent.self, from: snakeEncoder().encode(intent))
        XCTAssertEqual(decoded, intent)
    }

    func testHaltAndBreakerIntentBodiesAreExact() throws {
        let halt = try ControlIntent.halt(engineId: "aggr-2", reason: " operator stop ", clientRequestId: clientId)
        let haltObject = try XCTUnwrap(try JSONSerialization.jsonObject(with: snakeEncoder().encode(halt)) as? [String: Any])
        XCTAssertEqual(haltObject["kind"] as? String, "engine.halt")
        let haltBody = try XCTUnwrap(haltObject["value"] as? [String: Any])
        XCTAssertEqual(Set(haltBody.keys), ["engine_id", "reason"])
        XCTAssertEqual(haltBody["reason"] as? String, "operator stop")
        XCTAssertEqual(try accountJSONDecoder().decode(ControlIntent.self, from: snakeEncoder().encode(halt)), halt)

        let breaker = try ControlIntent.breaker(scope: .account, id: "sample-main", pct: 50, clientRequestId: clientId)
        let breakerObject = try XCTUnwrap(try JSONSerialization.jsonObject(with: snakeEncoder().encode(breaker)) as? [String: Any])
        XCTAssertEqual(breakerObject["kind"] as? String, "risk.breaker")
        let breakerBody = try XCTUnwrap(breakerObject["value"] as? [String: Any])
        XCTAssertEqual(Set(breakerBody.keys), ["scope", "id", "pct"])
        XCTAssertEqual(breakerBody["scope"] as? String, "account")
        XCTAssertEqual(breakerBody["pct"] as? Int, 50)
        XCTAssertEqual(try accountJSONDecoder().decode(ControlIntent.self, from: snakeEncoder().encode(breaker)), breaker)
        XCTAssertEqual(breaker.value.displayValue, "account sample-main: breaker 50%")
    }

    func testLifecycleIntentsFailClosed() {
        XCTAssertThrowsError(try ControlIntent.probe(engineId: "aggr-2", symbols: [], approval: "t",
            expiresAt: "2026-10-14T00:00:00Z", bind: true, clientRequestId: clientId))
        XCTAssertThrowsError(try ControlIntent.probe(engineId: "aggr-2", symbols: ["BTC-15M", "BTC-15M"], approval: "t",
            expiresAt: "2026-10-14T00:00:00Z", bind: true, clientRequestId: clientId))
        XCTAssertThrowsError(try ControlIntent.probe(engineId: "aggr-2", symbols: ["BTC-15M"], approval: "",
            expiresAt: "2026-10-14T00:00:00Z", bind: true, clientRequestId: clientId))
        XCTAssertThrowsError(try ControlIntent.probe(engineId: "aggr-2", symbols: ["BTC-15M"], approval: "t",
            expiresAt: "next week", bind: true, clientRequestId: clientId))
        XCTAssertThrowsError(try ControlIntent.probe(engineId: "Bad Id", symbols: ["BTC-15M"], approval: "t",
            expiresAt: "2026-10-14T00:00:00Z", bind: true, clientRequestId: clientId))
        XCTAssertThrowsError(try ControlIntent.halt(engineId: "aggr-2", reason: "   ", clientRequestId: clientId))
        XCTAssertThrowsError(try ControlIntent.halt(engineId: "aggr-2", reason: "stop", clientRequestId: "not-a-uuid"))
        XCTAssertThrowsError(try ControlIntent.breaker(scope: .engine, id: "aggr-2", pct: 0, clientRequestId: clientId))
        XCTAssertThrowsError(try ControlIntent.breaker(scope: .engine, id: "aggr-2", pct: 101, clientRequestId: clientId))
        XCTAssertThrowsError(try ControlIntent.breaker(scope: .account, id: "unassigned", pct: 50, clientRequestId: clientId))
    }
}
