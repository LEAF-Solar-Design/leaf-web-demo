import Foundation
import XCTest
@testable import LeafHFTCore

final class EntryCalibrationTests: XCTestCase {
    private func calibration() throws -> EntryCalibration {
        try accountJSONDecoder().decode(EntryCalibration.self, from: fixtureData("calibration"))
    }

    func testFrozenContractAndOptionalFields() throws {
        let value = try calibration()
        XCTAssertEqual(value.schemaVersion, 1)
        XCTAssertEqual(value.host, "fixture-host")
        XCTAssertEqual(value.window.days, 30)
        XCTAssertEqual(value.summary.entries, 1008)
        XCTAssertEqual(value.summary.cashedOut, 200)
        XCTAssertEqual(value.summary.venueSettled, 21)
        XCTAssertEqual(value.summary.realizedCents, -4521)
        XCTAssertEqual(value.buckets.map(\.label),
                       ["Under 80%", "80 to 90%", "90 to 95%", "95 to 99%", "99% and up"])
        XCTAssertEqual(value.buckets.map(\.bucket), ["under_80", "80_90", "90_95", "95_99", "99_up"])
        XCTAssertEqual(value.buckets[4].wilsonLowPct, 82.6)
        XCTAssertEqual(value.engines.count, 3)
        XCTAssertNil(value.engines[1].engineId)
        XCTAssertNil(value.engines[1].modelWinPct)
        XCTAssertNil(value.engines[1].actualWinPct)
        XCTAssertEqual(value.grid.cells.count, 7)
        XCTAssertNil(value.grid.cells[0].maxPriceCents)
        XCTAssertNil(value.grid.cells[0].minProbPct)
        XCTAssertEqual(value.grid.best?.deltaCents, 12345)
        XCTAssertEqual(value.grid.walkForward?.testEntries, 40)
        XCTAssertEqual(value.grid.walkForward?.chosen?.maxPriceCents, 95)
        XCTAssertEqual(value.advice.count, 3)
        XCTAssertEqual(Set(value.lessons.map(\.severity)), [.good, .watch, .act])
        XCTAssertNil(value.lessons[0].cents)
    }

    func testSummaryStringsPositiveNegativeZeroAndNull() throws {
        var summary = try calibration().summary
        XCTAssertEqual(summary.headline, "Model said 93.4%, entries won 81.9%")
        XCTAssertEqual(summary.edgeLine, "+1.2 points after price")
        XCTAssertEqual(summary.coverageLine, "913 scored of 1,008 entries · 87 open")
        summary.edgeAfterPricePts = -0.5
        XCTAssertEqual(summary.edgeLine, "-0.5 points after price")
        summary.edgeAfterPricePts = 0
        XCTAssertEqual(summary.edgeLine, "+0.0 points after price")
        summary.edgeAfterPricePts = -0.04
        XCTAssertEqual(summary.edgeLine, "+0.0 points after price")
        summary.edgeAfterPricePts = nil
        XCTAssertEqual(summary.edgeLine, "Edge after price not reported")
        summary.modelWinPct = 0
        summary.actualWinPct = 0
        XCTAssertEqual(summary.headline, "Model said 0.0%, entries won 0.0%")
        summary.actualWinPct = nil
        XCTAssertEqual(summary.headline, "Not enough settled entries yet")
        summary.actualWinPct = 81.9
        summary.modelWinPct = nil
        XCTAssertEqual(summary.headline, "Not enough settled entries yet")
        summary.scored = 0
        summary.entries = 0
        summary.open = 0
        XCTAssertEqual(summary.coverageLine, "0 scored of 0 entries · 0 open")
        summary.scored = 1_234_567
        summary.entries = 1_000
        summary.open = 999
        XCTAssertEqual(summary.coverageLine, "1,234,567 scored of 1,000 entries · 999 open")
    }

    func testBucketLines() throws {
        let buckets = try calibration().buckets
        XCTAssertEqual(buckets[4].line, "99% and up · model 99.5% · won 86.1% (83 to 89%) · -0.5 pts")
        XCTAssertEqual(buckets[0].line, "Under 80% · model 70.2% · won 72.5% (57 to 84%) · +4.2 pts")
        var bucket = buckets[1]
        XCTAssertEqual(bucket.line, "80 to 90% · model 85.1% · won 80.0% (71 to 87%) · -3.5 pts")
        bucket.edgeAfterPricePts = 0
        bucket.wilsonLowPct = 0
        bucket.wilsonHighPct = 100
        XCTAssertEqual(bucket.line, "80 to 90% · model 85.1% · won 80.0% (0 to 100%) · +0.0 pts")
    }

    func testEngineLinesAndWorstFirstOrder() throws {
        var value = try calibration()
        XCTAssertEqual(value.engines[0].line, "atlas · won 80.5% of 550 settled · -$61.20")
        XCTAssertEqual(value.engines[1].line, "Engine unknown · win rate not reported · -$2.12")
        XCTAssertEqual(value.engines[2].line, "orion · won 84.1% of 359 settled · +$18.11")
        XCTAssertEqual(value.enginesWorstFirst.map(\.engineId), ["atlas", nil, "orion"])
        value.engines.reverse()
        XCTAssertEqual(value.enginesWorstFirst.map(\.engineId), ["atlas", nil, "orion"])
        value.engines[0].realizedCents = -6120
        value.engines[2].realizedCents = -6120
        XCTAssertEqual(value.enginesWorstFirst.map(\.engineId), ["orion", "atlas", nil])
        value.engines = []
        XCTAssertTrue(value.enginesWorstFirst.isEmpty)
    }

    func testGridBestLineForEveryGateShape() throws {
        var grid = try calibration().grid
        XCTAssertEqual(grid.bestLine, "Cap price at 95c: +$123.45 by skipping 60 entries (in-sample)")
        grid.best = grid.cells[5]
        XCTAssertEqual(grid.bestLine,
                       "Price cap 95c and probability floor 97%: +$88.00 by skipping 205 entries (in-sample)")
        grid.best = grid.cells[2]
        XCTAssertEqual(grid.bestLine, "Probability floor 99.5%: +$15.00 by skipping 205 entries (in-sample)")
        grid.best = grid.cells[6]
        XCTAssertEqual(grid.bestLine, "Cap price at 90c: -$24.00 by skipping 305 entries (in-sample)")
        grid.best?.deltaCents = 0
        XCTAssertEqual(grid.bestLine, "Cap price at 90c: +$0.00 by skipping 305 entries (in-sample)")
        grid.best = grid.cells[0]
        XCTAssertNil(grid.bestLine)
        grid.best = nil
        XCTAssertNil(grid.bestLine)
        XCTAssertEqual(grid.cells[0].line, "No extra gate · kept 905 · removed 0 · +$0.00")
        XCTAssertEqual(grid.cells[4].line, "Cap price at 95c · kept 845 · removed 60 · +$123.45")
        XCTAssertEqual(grid.cells[6].line, "Cap price at 90c · kept 600 · removed 305 · -$24.00")
    }

    func testWalkForwardLine() throws {
        var grid = try calibration().grid
        XCTAssertEqual(grid.walkForwardLine, "Held-out test: +$12.00 over 40 entries")
        grid.walkForward?.testDeltaCents = -300
        XCTAssertEqual(grid.walkForwardLine, "Held-out test: -$3.00 over 40 entries")
        grid.walkForward?.testDeltaCents = 0
        XCTAssertEqual(grid.walkForwardLine, "Held-out test: +$0.00 over 40 entries")
        grid.walkForward?.testDeltaCents = nil
        XCTAssertEqual(grid.walkForwardLine, "Not enough history to test")
        grid.walkForward?.testDeltaCents = 1200
        grid.walkForward?.chosen = nil
        XCTAssertEqual(grid.walkForwardLine, "Held-out test: no stricter gate helped on the earlier half")
        grid.walkForward = nil
        XCTAssertEqual(grid.walkForwardLine, "Not enough history to test")
    }

    func testTopCellsHighestDeltaFirstAndBounded() throws {
        var grid = try calibration().grid
        XCTAssertEqual(grid.topCells().map(\.deltaCents), [12345, 8800, 6010, 2063, 1500])
        XCTAssertEqual(grid.topCells(2).map(\.deltaCents), [12345, 8800])
        XCTAssertTrue(grid.topCells(0).isEmpty)
        XCTAssertTrue(grid.topCells(-1).isEmpty)
        XCTAssertEqual(grid.topCells(100).count, 7)
        grid.cells[1].deltaCents = 12345
        XCTAssertEqual(grid.topCells(2).map(\.removed), [400, 60])
        grid.cells = []
        XCTAssertTrue(grid.topCells().isEmpty)
    }

    func testFormattingHelpers() {
        XCTAssertEqual(EntryCalibration.grouped(0), "0")
        XCTAssertEqual(EntryCalibration.grouped(999), "999")
        XCTAssertEqual(EntryCalibration.grouped(1008), "1,008")
        XCTAssertEqual(EntryCalibration.grouped(-1000), "-1,000")
        XCTAssertEqual(EntryCalibration.grouped(Int.min).prefix(2), "-9")
        XCTAssertEqual(EntryCalibration.trimmedPercent(99), "99")
        XCTAssertEqual(EntryCalibration.trimmedPercent(99.5), "99.5")
        XCTAssertEqual(EntryCalibration.signedPoints(1.24), "+1.2")
        XCTAssertEqual(EntryCalibration.signedPoints(-2), "-2.0")
    }

    func testUnknownSeverityExtraKeysAndNullsNeverThrow() throws {
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData("calibration")) as? [String: Any])
        var lessons = try XCTUnwrap(object["lessons"] as? [[String: Any]])
        lessons[0]["severity"] = "future_severity"
        lessons[0]["new_annotation"] = true
        object["lessons"] = lessons
        object["extra"] = 42
        var summary = try XCTUnwrap(object["summary"] as? [String: Any])
        for key in ["model_win_pct", "actual_win_pct", "avg_price_cents", "edge_after_price_pts"] {
            summary[key] = NSNull()
        }
        summary["future_count"] = 7
        object["summary"] = summary
        var grid = try XCTUnwrap(object["grid"] as? [String: Any])
        grid["best"] = NSNull()
        grid["walk_forward"] = NSNull()
        object["grid"] = grid
        let value = try accountJSONDecoder().decode(EntryCalibration.self,
                                                    from: JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(value.lessons[0].severity, .unknown)
        XCTAssertNil(value.summary.modelWinPct)
        XCTAssertEqual(value.summary.headline, "Not enough settled entries yet")
        XCTAssertEqual(value.summary.edgeLine, "Edge after price not reported")
        XCTAssertNil(value.grid.best)
        XCTAssertNil(value.grid.bestLine)
        XCTAssertNil(value.grid.walkForward)
        XCTAssertEqual(value.grid.walkForwardLine, "Not enough history to test")
    }

    private func decodeWithAdvice(_ change: (inout [String: Any]) -> Void) throws -> EntryCalibration {
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData("calibration")) as? [String: Any])
        change(&object)
        return try accountJSONDecoder().decode(EntryCalibration.self, from: JSONSerialization.data(withJSONObject: object))
    }

    func testAdviceMissingNullAndPresent() throws {
        XCTAssertTrue(try decodeWithAdvice { $0.removeValue(forKey: "advice") }.advice.isEmpty)
        XCTAssertTrue(try decodeWithAdvice { $0["advice"] = NSNull() }.advice.isEmpty)
        XCTAssertTrue(try decodeWithAdvice { $0["advice"] = [] as [Any] }.advice.isEmpty)
        let value = try calibration()
        XCTAssertEqual(value.advice.count, 3)
        XCTAssertEqual(value.advice.map(\.engineId), ["atlas", "orion", "vega"])
        XCTAssertEqual(value.advice.map(\.verdict), [.candidate, .noGain, .insufficientEvidence])
        XCTAssertEqual(value.advice[0].candidate, ["max_price_cents": 95])
        XCTAssertEqual(value.advice[1].candidate, ["max_price_cents": 97, "min_depth": 5])
        XCTAssertEqual(value.advice[1].evaluationDeltaCents, -300)
        XCTAssertEqual(value.advice[1].evaluationComparable, 52)
        XCTAssertEqual(value.advice[2].createdAt, "2026-09-30T08:00:00Z")
        let unknown = try decodeWithAdvice { object in
            object["advice"] = [["engine_id": NSNull(), "candidate": ["min_k": 0.95], "verdict": "future_verdict",
                                 "evaluation_delta_cents": NSNull(), "extra": true]] as [[String: Any]]
        }
        XCTAssertEqual(unknown.advice.count, 1)
        XCTAssertEqual(unknown.advice[0].verdict, .unknown)
        XCTAssertNil(unknown.advice[0].engineId)
        XCTAssertNil(unknown.advice[0].evaluationDeltaCents)
        XCTAssertNil(unknown.advice[0].createdAt)
        XCTAssertEqual(unknown.advice[0].candidate, ["min_k": 0.95])
    }

    func testAdviceLinePerVerdict() throws {
        var advice = try calibration().advice
        XCTAssertEqual(advice[0].line, "atlas: Cap price at 95c · held-out +$12.00 on 48 entries · Candidate")
        XCTAssertEqual(advice[1].line,
                       "orion: Cap price at 97c and minimum depth 5 · held-out -$3.00 on 52 entries · No gain")
        XCTAssertEqual(advice[2].line,
                       "vega: Quote age at most 1500 ms · held-out +$1.50 on 12 entries · Not enough data")
        advice[0].verdict = .unknown
        XCTAssertEqual(advice[0].line, "atlas: Cap price at 95c · held-out +$12.00 on 48 entries · Verdict unknown")
        advice[0].verdict = .candidate
        advice[0].evaluationDeltaCents = 0
        advice[0].evaluationComparable = 1_200
        XCTAssertEqual(advice[0].line, "atlas: Cap price at 95c · held-out +$0.00 on 1,200 entries · Candidate")
        advice[0].evaluationDeltaCents = nil
        XCTAssertEqual(advice[0].line, "atlas: Cap price at 95c · held-out result not reported · Candidate")
        advice[0].engineId = nil
        advice[0].evaluationDeltaCents = 100
        advice[0].candidate = ["max_price_cents": 95, "min_prob_pct": 97]
        XCTAssertEqual(advice[0].line,
                       "Engine unknown: Price cap 95c and probability floor 97% · held-out +$1.00 on 1,200 entries · Candidate")
        advice[0].candidate = ["min_k": 0.95]
        XCTAssertEqual(advice[0].gate, "Minimum k 0.95")
        advice[0].candidate = [:]
        XCTAssertEqual(advice[0].gate, "No extra gate")
        advice[0].candidate = ["future_key": 3]
        XCTAssertEqual(advice[0].gate, "Future key 3")
    }

    func testInlineAdviceNewestFirstAndBounded() throws {
        var value = try calibration()
        XCTAssertEqual(value.inlineAdvice().map(\.engineId), ["atlas", "vega", "orion"])
        XCTAssertEqual(value.inlineAdvice(1).map(\.engineId), ["atlas"])
        XCTAssertTrue(value.inlineAdvice(0).isEmpty)
        XCTAssertTrue(value.inlineAdvice(-1).isEmpty)
        value.advice[0].createdAt = "not a time"
        XCTAssertEqual(value.inlineAdvice().map(\.engineId), ["vega", "orion", "atlas"])
        value.advice[2].createdAt = value.advice[1].createdAt
        XCTAssertEqual(value.inlineAdvice().map(\.engineId), ["orion", "vega", "atlas"])
        value.advice = []
        XCTAssertTrue(value.inlineAdvice().isEmpty)
    }

    func testAskPromptWithAndWithoutBestGate() throws {
        var value = try calibration()
        XCTAssertEqual(value.askPrompt,
                       "Run a held-out check of Cap price at 95c on my engines, then tell me which engine it helps.")
        value.grid.best = value.grid.cells[5]
        XCTAssertEqual(value.askPrompt, "Run a held-out check of Price cap 95c and probability floor 97% on my engines,"
                       + " then tell me which engine it helps.")
        value.grid.best = value.grid.cells[0]
        XCTAssertEqual(value.askPrompt, "Which stricter entry gate would help my engines? Check it held-out.")
        value.grid.best = nil
        XCTAssertEqual(value.askPrompt, "Which stricter entry gate would help my engines? Check it held-out.")
    }

    func testTopLessonPrioritizesActThenWatchThenFirst() throws {
        var value = try calibration()
        XCTAssertEqual(value.topLesson?.id, "calibration")
        let watch = try XCTUnwrap(value.lessons.first { $0.severity == .watch })
        value.lessons.insert(watch, at: 0)
        XCTAssertEqual(value.topLesson?.id, "calibration")
        value.lessons.removeAll { $0.severity == .act }
        XCTAssertEqual(value.topLesson?.id, "grid_best")
        value.lessons.removeAll { $0.severity == .watch }
        XCTAssertEqual(value.topLesson?.id, "bucket_under_80")
        XCTAssertEqual(value.topLesson?.severity, .good)
        value.lessons[0].severity = .unknown
        XCTAssertEqual(value.topLesson?.severity, .unknown)
        value.lessons = []
        XCTAssertNil(value.topLesson)
    }
}
