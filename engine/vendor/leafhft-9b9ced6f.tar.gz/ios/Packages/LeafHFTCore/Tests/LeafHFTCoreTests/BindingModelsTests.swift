import Foundation
import CryptoKit
import XCTest
@testable import LeafHFTCore

final class BindingModelsTests: XCTestCase {
    private let challengeHash = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    private func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
    private func challenge(hash: String? = nil, version: String = "kashbot-bind-v1") throws -> BindingChallenge {
        let fields: [String: Any] = ["challenge_id": "ABCDEFAB-1234-4234-9234-123456789ABC",
            "device_id": "FEDCBAFE-1234-4234-9234-123456789ABC", "challenge": "abc",
            "challenge_hash": hash ?? self.challengeHash, "expires_at": "2030-01-01T00:00:00Z", "binding_version": version]
        return try decoder().decode(BindingChallenge.self, from: JSONSerialization.data(withJSONObject: fields))
    }
    func testCanonicalBindingMatchesServerSixFieldContract() throws {
        let der = Data(repeating: 0x41, count: 256)
        let publicHash = SHA256.hash(data: der).map { String(format: "%02x", $0) }.joined()
        let message = try challenge().canonicalMessage(keyID: " KEY_1 ", publicKeyDER: der, now: Date(timeIntervalSince1970: 0))
        let expected = ["kashbot-bind-v1", "abcdefab-1234-4234-9234-123456789abc",
                        "fedcbafe-1234-4234-9234-123456789abc", challengeHash, "key_1", publicHash]
            .joined(separator: "\n")
        XCTAssertEqual(message, Data(expected.utf8))
        XCTAssertNotEqual(message.last, 10)
    }
    func testInvalidOrExpiredChallengeIsNotSigned() throws {
        let der = Data(repeating: 0, count: 256)
        let now = Date(timeIntervalSince1970: 0)
        XCTAssertThrowsError(try challenge(hash: String(repeating: "0", count: 64)).canonicalMessage(keyID: "key", publicKeyDER: der, now: now))
        XCTAssertThrowsError(try challenge(version: "future").canonicalMessage(keyID: "key", publicKeyDER: der, now: now))
        XCTAssertThrowsError(try challenge().canonicalMessage(keyID: "key\nother", publicKeyDER: der, now: now))
        XCTAssertThrowsError(try challenge().canonicalMessage(keyID: "key", publicKeyDER: der, now: Date(timeIntervalSince1970: 2_000_000_000)))
    }
    func testUnboundPairingNeverMeansAutomationReady() throws {
        let status = try decoder().decode(KashbotStatus.self, from: Data(#"{"dashboard_pairing":"paired","account_binding":"unbound","automated_trading":"dry_run","tenant":null,"request":null}"#.utf8))
        XCTAssertEqual(status.dashboardPairing, .paired)
        XCTAssertFalse(status.isBound)
        XCTAssertEqual(status.automationLabel, "Not configured")
    }
    func testRiskRegimeDecodes() throws {
        let json = #"{"dashboard_pairing":"paired","account_binding":"bound","automated_trading":"live","risk_regime":{"id":"owner","label":"risky_batman"}}"#
        let status = try decoder().decode(KashbotStatus.self, from: Data(json.utf8))
        let regime = try XCTUnwrap(status.riskRegime)
        XCTAssertEqual(regime.id, "owner")
        XCTAssertEqual(regime.label, "risky_batman")
    }
    func testAbsentRiskRegimeDecodesAsNil() throws {
        let json = #"{"dashboard_pairing":"paired","account_binding":"bound","automated_trading":"live"}"#
        let status = try decoder().decode(KashbotStatus.self, from: Data(json.utf8))
        XCTAssertNil(status.riskRegime)
    }
    func testNullRiskRegimeDecodesAsNil() throws {
        let json = #"{"dashboard_pairing":"paired","account_binding":"bound","automated_trading":"live","risk_regime":null}"#
        let status = try decoder().decode(KashbotStatus.self, from: Data(json.utf8))
        XCTAssertNil(status.riskRegime)
    }
    func testProvisioningIsNotAnActiveDryRunAndUnknownStateFailsClosed() throws {
        let json = #"{"dashboard_pairing":"paired","account_binding":"bound","automated_trading":"provisioning","tenant":{"id":"tenant","runner_host":"kashbot-tenant"},"request":{"id":"request","client_request_id":"client","action":"start_dry_run","state":"provisioning","requested_at":"2026-09-19T00:00:00Z"}}"#
        let status = try decoder().decode(KashbotStatus.self, from: Data(json.utf8))
        XCTAssertTrue(status.isBound)
        XCTAssertEqual(status.automationLabel, "Preparing your account")
        XCTAssertEqual(status.request?.clientRequestId, "client")
        let live = try decoder().decode(KashbotStatus.self, from: Data(json.replacingOccurrences(of: "provisioning", with: "live").utf8))
        XCTAssertEqual(live.automatedTrading, .live)
        let unknown = try decoder().decode(KashbotStatus.self, from: Data(json.replacingOccurrences(of: "provisioning", with: "future").utf8))
        XCTAssertEqual(unknown.automatedTrading, .unknown)
        XCTAssertFalse(unknown.allows(.startLive))
        XCTAssertFalse(unknown.allows(.startDryRun))
    }
    func testBindingRequestContainsOnlyPublicProof() throws {
        let request = BindingRequest(challengeId: "ABC", keyId: "key", publicKeyDer: "public", signature: "proof")
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: encoder.encode(request)) as? [String: String])
        XCTAssertEqual(body, ["challenge_id": "abc", "key_id": "key", "public_key_der": "public", "signature": "proof"])
    }

    func testAllEnrollmentStatesDecodeWithoutExposingScope() throws {
        for value in ["credential_required", "provisioning", "dry_run", "ready", "live", "paused", "failed"] {
            let fields: [String: Any] = ["dashboard_pairing": "paired", "account_binding": "bound",
                "automated_trading": value, "tenant": ["id": "private-account"],
                "lane": ["id": "private-lane"]]
            let status = try decoder().decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: fields))
            XCTAssertFalse(status.automationLabel.contains("private"))
            XCTAssertEqual(status.lane?.id, "private-lane")
            XCTAssertNil(status.tenant?.runnerHost)
            XCTAssertEqual(status.needsEnrollment, value == "credential_required")
        }
    }

    func testExactRunnerCapabilityMatrix() throws {
        let expected: [String: Set<KashbotRunnerAction>] = [
            "not_configured": [], "credential_required": [], "provisioning": [.revoke],
            "ready": [.startDryRun, .revoke], "dry_run": [.startLive, .revoke],
            "live": [.pause, .revoke], "paused": [.revoke], "failed": [.revoke], "revoked": []
        ]
        for (state, actions) in expected {
            let fields: [String: Any] = ["dashboard_pairing": "paired", "account_binding": "bound",
                "automated_trading": state, "tenant": ["id": "11111111-1111-4111-8111-111111111111"],
                "lane": ["id": "22222222-2222-4222-8222-222222222222", "state": state,
                         "kill_requested": state == "paused", "live_enabled": state == "live"]]
            let status = try decoder().decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: fields))
            XCTAssertEqual(Set(KashbotRunnerAction.allCases.filter { status.allows($0) }), actions, state)
        }
    }

    func testMissingContradictoryAndUnknownLaneStateFailsClosed() throws {
        var fields: [String: Any] = ["dashboard_pairing": "paired", "account_binding": "bound",
            "automated_trading": "dry_run", "tenant": ["id": "11111111-1111-4111-8111-111111111111"]]
        for lane in [
            ["id": "22222222-2222-4222-8222-222222222222"],
            ["id": "22222222-2222-4222-8222-222222222222", "state": "ready", "kill_requested": false, "live_enabled": false],
            ["id": "22222222-2222-4222-8222-222222222222", "state": "dry_run", "kill_requested": true, "live_enabled": false],
            ["id": "22222222-2222-4222-8222-222222222222", "state": "dry_run", "kill_requested": false, "live_enabled": true]
        ] as [[String: Any]] {
            fields["lane"] = lane
            let status = try decoder().decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: fields))
            XCTAssertFalse(status.allows(.startLive))
        }
        fields["lane"] = ["id": "22222222-2222-4222-8222-222222222222", "state": "future"]
        let status = try decoder().decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: fields))
        XCTAssertEqual(status.lane?.state, .unknown)
        XCTAssertFalse(status.hasActionableLane)
        XCTAssertTrue(KashbotRunnerAction.allCases.allSatisfy { !status.allows($0) })
    }

    func testPendingErrorAndUnknownStatesKeepStopControlsAvailable() throws {
        for (value, expected) in [("live_pending", AutomatedTradingState.livePending),
                                  ("error", .error), ("quantum", .unknown)] {
            for liveEnabled in [false, true] {
                let fields: [String: Any] = ["dashboard_pairing": "paired", "account_binding": "bound",
                    "automated_trading": value, "tenant": ["id": "11111111-1111-4111-8111-111111111111"],
                    "lane": ["id": "22222222-2222-4222-8222-222222222222", "state": value,
                             "kill_requested": false, "live_enabled": liveEnabled]]
                let status = try decoder().decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: fields))
                XCTAssertEqual(status.automatedTrading, expected, value)
                XCTAssertEqual(status.lane?.state, expected, value)
                XCTAssertTrue(status.hasActionableLane, value)
                XCTAssertTrue(status.allows(.pause), value)
                XCTAssertTrue(status.allows(.revoke), value)
                XCTAssertFalse(status.allows(.startLive), value)
                XCTAssertFalse(status.allows(.startDryRun), value)
            }
        }
    }

    func testLivePauseDoesNotRequireLiveEnabled() throws {
        let fields: [String: Any] = ["dashboard_pairing": "paired", "account_binding": "bound",
            "automated_trading": "live", "tenant": ["id": "11111111-1111-4111-8111-111111111111"],
            "lane": ["id": "22222222-2222-4222-8222-222222222222", "state": "live",
                     "kill_requested": false, "live_enabled": false]]
        let status = try decoder().decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: fields))
        XCTAssertTrue(status.allows(.pause))
    }

    func testTypedRunnerWireValues() throws {
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        let requestID = UUID()
        for (action, wire) in [(KashbotRunnerAction.startDryRun, "start_dry_run"),
                               (.startLive, "start_live"), (.pause, "pause"), (.revoke, "revoke")] {
            let data = try encoder.encode(KashbotRunnerActionRequest(clientRequestId: requestID, action: action))
            XCTAssertEqual(try JSONSerialization.jsonObject(with: data) as? [String: String],
                           ["client_request_id": requestID.uuidString.lowercased(), "action": wire])
        }
        XCTAssertThrowsError(try JSONDecoder().decode(KashbotRunnerAction.self, from: Data("\"future\"".utf8)))
    }
}
