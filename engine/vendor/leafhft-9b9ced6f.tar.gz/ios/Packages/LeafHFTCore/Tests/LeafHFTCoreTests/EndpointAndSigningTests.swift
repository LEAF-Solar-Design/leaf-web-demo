import Foundation
import XCTest
@testable import LeafHFTCore

final class EndpointAndSigningTests: XCTestCase {
    func testMarketsQueryKeepsFirstTwentyThenSorts() {
        let tickers = ["Z-TOP"] + (0..<30).map { String(format: "T%02d", $0) }
        let endpoint = KalshiGETEndpoint.markets(tickers: ["", "Z-TOP", "Z-TOP", ""] + tickers)
        XCTAssertEqual(endpoint.path, "/trade-api/v2/markets")
        XCTAssertEqual(endpoint.queryItems, [
            URLQueryItem(name: "tickers", value: tickers.prefix(20).sorted().joined(separator: ",")),
            URLQueryItem(name: "limit", value: "20")
        ])
        XCTAssertEqual(KalshiGETEndpoint.markets(tickers: ["B", "", "A", "B", ""]).queryItems, [
            URLQueryItem(name: "tickers", value: "A,B"), URLQueryItem(name: "limit", value: "2")
        ])
        XCTAssertEqual(KalshiGETEndpoint.markets(tickers: ["", ""]).queryItems, [
            URLQueryItem(name: "tickers", value: ""), URLQueryItem(name: "limit", value: "0")
        ])
    }

    func testEndpointQueriesAndLimits() {
        XCTAssertEqual(KalshiGETEndpoint.method, "GET")
        XCTAssertEqual(KalshiGETEndpoint.origin.absoluteString, "https://api.elections.kalshi.com")
        let endpoint = KalshiGETEndpoint.fills(cursor: "a&b?", limit: 999)
        XCTAssertEqual(endpoint.path, "/trade-api/v2/portfolio/fills")
        XCTAssertEqual(endpoint.queryItems, [URLQueryItem(name: "limit", value: "200"), URLQueryItem(name: "cursor", value: "a&b?")])
        XCTAssertEqual(KalshiGETEndpoint.settlements(cursor: nil, limit: 0).queryItems.first?.value, "1")
        for endpoint in [KalshiGETEndpoint.balance, .positions, .deposits] {
            XCTAssertTrue(endpoint.path.hasPrefix("/trade-api/v2/"))
            XCTAssertFalse(endpoint.path.contains("?"))
            XCTAssertTrue(endpoint.queryItems.isEmpty)
        }
    }
    func testCanonicalFixtureMessage() throws {
        let fixture = try JSONSerialization.jsonObject(with: fixtureData("signature-fixture")) as! [String: String]
        let timestamp = try XCTUnwrap(Int64(try XCTUnwrap(fixture["timestamp_ms"])))
        let path = try XCTUnwrap(fixture["path"])
        XCTAssertEqual(canonicalSigningMessage(timestampMs: timestamp, path: path), Data(try XCTUnwrap(fixture["message"]).utf8))
        XCTAssertEqual(canonicalSigningMessage(timestampMs: timestamp, path: path + "?limit=1"), canonicalSigningMessage(timestampMs: timestamp, path: path))
    }
}
