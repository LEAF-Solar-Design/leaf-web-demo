import Foundation
import XCTest
@testable import LeafHFTCore

final class EngineRuntimeTests: XCTestCase {
    private static let lifecycleJSON = """
    {"state":"probe_sized","entries_enabled":false,"entries_suspended_until":"2026-09-24T00:00:00Z",
     "stop_reasons":[{"code":"breaker_engine","text":"This engine's day loss reached 50% of the day-start portfolio."},"legacy_code"],
     "probe_started_at":"2026-09-23T04:00:00Z","expires_at":"2026-10-14T04:00:00Z","contracts":2,
     "breaker":{"engine_pct":50,"inherited":true,"account_pct":50,"engine_loss_cents":1240,"engine_limit_cents":125000,
       "account_loss_cents":2000,"account_limit_cents":125000,"day_start_marked_cents":250000}}
    """

    private static let probeEngineKeys = [
        "lifecycle", "assignment", "markets", "inputs", "probe_today", "live", "eligible_to_probe"
    ]

    private func iso(_ text: String) -> Date? { ISO8601DateFormatter().date(from: text) }

    func testEveryKnownStateDecodesAndUnknownStatesDecodeUnknown() throws {
        let expected: [String: EngineLifecycle.State] = [
            "probe": .probe, "probe_sized": .probeSized, "halted": .halted, "graduated": .graduated,
            "retired": .retired, "shadow": .shadow, "canary": .canary, "live": .unknown, "": .unknown
        ]
        for (raw, state) in expected {
            let lifecycle = try accountJSONDecoder().decode(EngineLifecycle.self, from: Data(#"{"state":"\#(raw)"}"#.utf8))
            XCTAssertEqual(lifecycle.state, state, raw)
        }
        let missing = try accountJSONDecoder().decode(EngineLifecycle.self, from: Data("{}".utf8))
        XCTAssertEqual(missing.state, .unknown)
        XCTAssertEqual(missing.label, "Lifecycle not reported")
    }

    func testLifecycleDecodesUnderBothKeyStrategies() throws {
        for decoder in [accountJSONDecoder(), JSONDecoder()] {
            let lifecycle = try decoder.decode(EngineLifecycle.self, from: Data(Self.lifecycleJSON.utf8))
            XCTAssertEqual(lifecycle.state, .probeSized)
            XCTAssertEqual(lifecycle.label, "Probing at 2 contracts")
            XCTAssertEqual(lifecycle.entriesEnabled, false)
            XCTAssertEqual(lifecycle.entriesSuspendedUntil, iso("2026-09-24T00:00:00Z"))
            XCTAssertEqual(lifecycle.stopReasons, [
                .init(code: "breaker_engine", text: "This engine's day loss reached 50% of the day-start portfolio."),
                .init(code: "legacy_code", text: nil)
            ])
            XCTAssertEqual(lifecycle.probeStartedAt, "2026-09-23T04:00:00Z")
            XCTAssertEqual(lifecycle.expiresAt, "2026-10-14T04:00:00Z")
            XCTAssertEqual(lifecycle.contracts, 2)
            let breaker = try XCTUnwrap(lifecycle.breaker)
            XCTAssertEqual(breaker.enginePct, 50)
            XCTAssertEqual(breaker.inherited, true)
            XCTAssertEqual(breaker.engineLossCents, 1240)
            XCTAssertEqual(breaker.engineLimitCents, 125_000)
            XCTAssertEqual(breaker.accountLossCents, 2000)
            XCTAssertEqual(breaker.dayStartMarkedCents, 250_000)
            XCTAssertFalse(lifecycle.canEnter)
        }
        let original = try accountJSONDecoder().decode(EngineLifecycle.self, from: Data(Self.lifecycleJSON.utf8))
        let encoder = JSONEncoder(); encoder.keyEncodingStrategy = .convertToSnakeCase
        XCTAssertEqual(try accountJSONDecoder().decode(EngineLifecycle.self, from: encoder.encode(original)), original)
        XCTAssertEqual(try JSONDecoder().decode(EngineLifecycle.self, from: JSONEncoder().encode(original)), original)
    }

    func testUnparseableSuspensionIsNilNeverAGuessedDate() throws {
        let lifecycle = try accountJSONDecoder().decode(EngineLifecycle.self,
            from: Data(#"{"state":"probe","entries_suspended_until":"tomorrow"}"#.utf8))
        XCTAssertNil(lifecycle.entriesSuspendedUntil)
        let fractional = try accountJSONDecoder().decode(EngineLifecycle.self,
            from: Data(#"{"state":"probe","entries_suspended_until":"2026-09-24T00:00:00.000Z"}"#.utf8))
        XCTAssertEqual(fractional.entriesSuspendedUntil, iso("2026-09-24T00:00:00Z"))
    }

    func testEngineLabLifecycleIsTheRuntimeLifecycle() {
        XCTAssertTrue(EngineLab.Lifecycle.self == EngineLifecycle.self)
    }

    func testOlderServerWithoutAnyNewFieldStillDecodes() throws {
        // An older server is the fixture with every probe-paradigm field stripped.
        var enginesObject = try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData("engines")) as? [String: Any])
        let rawEngines = try XCTUnwrap(enginesObject["engines"] as? [[String: Any]])
        XCTAssertTrue(rawEngines.contains { engine in Self.probeEngineKeys.allSatisfy { engine[$0] != nil } },
                      "engines.json carries every new optional field on one engine")
        enginesObject["engines"] = rawEngines.map { engine in
            engine.filter { !Self.probeEngineKeys.contains($0.key) }
        }
        let response = try accountJSONDecoder().decode(EnginesResponse.self,
            from: JSONSerialization.data(withJSONObject: enginesObject))
        let engines = try XCTUnwrap(response.engines)
        XCTAssertEqual(engines.count, rawEngines.count)
        for engine in engines {
            XCTAssertNil(engine.lifecycle)
            XCTAssertNil(engine.assignment)
            XCTAssertNil(engine.markets)
            XCTAssertNil(engine.inputs)
            XCTAssertNil(engine.probeToday)
            XCTAssertNil(engine.live)
            XCTAssertNil(engine.eligibleToProbe)
        }

        var booksObject = try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData("books")) as? [String: Any])
        let rawBooks = try XCTUnwrap(booksObject["books"] as? [[String: Any]])
        XCTAssertTrue(rawBooks.contains { ($0["kalshi_book"] as? [String: Any])?["executor"] != nil },
                      "books.json carries an executor block on one book")
        booksObject["books"] = rawBooks.map { book -> [String: Any] in
            var book = book
            if var kalshi = book["kalshi_book"] as? [String: Any] {
                kalshi.removeValue(forKey: "executor")
                book["kalshi_book"] = kalshi
            }
            return book
        }
        let books = try accountJSONDecoder().decode(MobileBooks.self,
            from: JSONSerialization.data(withJSONObject: booksObject))
        XCTAssertEqual(books.books.count, rawBooks.count)
        XCTAssertTrue(books.books.allSatisfy { $0.kalshiBook.executor == nil })
        let minimal = try accountJSONDecoder().decode(Engine.self, from: Data(#"{"engine_id":"default"}"#.utf8))
        XCTAssertNil(minimal.lifecycle)
    }

    func testFixturesCarryTheNewOptionalFields() throws {
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: fixtureData("engines"))
        let engines = try XCTUnwrap(response.engines)
        let baseline = try XCTUnwrap(engines.first { $0.engineId == "default" })
        XCTAssertNil(baseline.lifecycle)
        XCTAssertNil(baseline.assignment)
        XCTAssertNil(baseline.eligibleToProbe)
        let probe = try XCTUnwrap(engines.first { $0.engineId == "aggressive" })
        XCTAssertEqual(probe.lifecycle?.state, .probe)
        XCTAssertEqual(probe.lifecycle?.entriesEnabled, true)
        XCTAssertEqual(probe.lifecycle?.stopReasons, [])
        XCTAssertEqual(probe.lifecycle?.contracts, 1)
        XCTAssertEqual(probe.lifecycle?.breaker?.engineLossCents, 1240)
        XCTAssertEqual(probe.lifecycle?.breaker?.engineLimitCents, 125_000)
        XCTAssertEqual(ProbePresentation.breakerMeter(probe.lifecycle?.breaker), "-$12.40 of $1,250.00 (50%) · UTC day")
        XCTAssertEqual(probe.assignment?.accountId, "sample-secondary")
        XCTAssertEqual(probe.assignment?.role, "probe")
        XCTAssertEqual(probe.markets, ["BTC-15M"])
        XCTAssertEqual(probe.inputs, [EngineInput(kind: "kalshi_book", id: "BTC-15M")])
        XCTAssertEqual(probe.probeToday?.tickets, 41)
        XCTAssertEqual(probe.live?.n, 41)
        XCTAssertEqual(ProbePresentation.perContract(probe.live), "+3.2c per contract · n 41")
        XCTAssertEqual(probe.eligibleToProbe?.eligible, false)
        XCTAssertEqual(probe.eligibleToProbe?.reasons, ["Already probing"])

        let books = try accountJSONDecoder().decode(MobileBooks.self, from: fixtureData("books"))
        XCTAssertEqual(books.books.filter { $0.kalshiBook.executor != nil }.map(\.bookId), ["fixture-book-02"])
        let executor = try XCTUnwrap(books.books.first { $0.bookId == "fixture-book-02" }?.kalshiBook.executor)
        XCTAssertEqual(executor.incumbentEngineId, "default")
        XCTAssertEqual(executor.disagreementsToday, 2)
        XCTAssertEqual(executor.position?.holderEngineId, "default")
        XCTAssertEqual(executor.engines.map(\.id), ["default", "aggressive"])
        XCTAssertEqual(executor.engines.map(\.state), [.graduated, .probe])
        XCTAssertEqual(executor.engines[1].lastProposal?.disposition, "refused")
    }

    func testEngineDecodesEveryProbeField() throws {
        let json = """
        {"engine_id":"aggr-2","lifecycle":\(Self.lifecycleJSON),
         "assignment":{"account_id":"acct-probe","domain":"kalshi-crypto","role":"probe","since":"2026-09-23T04:00:00Z"},
         "markets":["BTC-15M","ETH-15M"],"inputs":[{"kind":"kalshi_book","id":"BTC-15M"},{"kind":"index","id":"cfbenchmarks-brti"}],
         "probe_today":{"utc_day":"2026-09-23","realized_cents":-120,"tickets":41},
         "live":{"per_contract_cents":3.2,"n":41,"days":7},
         "eligible_to_probe":{"eligible":false,"reasons":["Bound on 2 accounts"]}}
        """
        let engine = try accountJSONDecoder().decode(Engine.self, from: Data(json.utf8))
        XCTAssertEqual(engine.lifecycle?.state, .probeSized)
        XCTAssertEqual(engine.assignment?.accountId, "acct-probe")
        XCTAssertEqual(engine.assignment?.domain, "kalshi-crypto")
        XCTAssertEqual(engine.assignment?.role, "probe")
        XCTAssertEqual(engine.assignment?.since, "2026-09-23T04:00:00Z")
        XCTAssertEqual(engine.markets, ["BTC-15M", "ETH-15M"])
        XCTAssertEqual(engine.inputs?.map(\.kind), ["kalshi_book", "index"])
        XCTAssertEqual(engine.inputs?.map(\.id), ["BTC-15M", "cfbenchmarks-brti"])
        XCTAssertEqual(engine.probeToday?.utcDay, "2026-09-23")
        XCTAssertEqual(engine.probeToday?.realizedCents, -120)
        XCTAssertEqual(engine.probeToday?.tickets, 41)
        XCTAssertEqual(engine.live?.perContractCents, 3.2)
        XCTAssertEqual(engine.live?.n, 41)
        XCTAssertEqual(engine.live?.days, 7)
        XCTAssertEqual(engine.eligibleToProbe?.eligible, false)
        XCTAssertEqual(engine.eligibleToProbe?.reasons, ["Bound on 2 accounts"])

        let other = try accountJSONDecoder().decode(Engine.self,
            from: Data(#"{"engine_id":"x","assignment":{"account":"other"},"eligible_to_probe":{"eligible":true}}"#.utf8))
        XCTAssertEqual(other.assignment?.account, "other")
        XCTAssertNil(other.assignment?.accountId)
        XCTAssertEqual(other.eligibleToProbe?.reasons, [])
    }

    func testProbeBoardDecodes() throws {
        let board = try accountJSONDecoder().decode(ProbeBoardResponse.self, from: fixtureData("probes"))
        XCTAssertEqual(board.observedAt, "2026-09-23T12:00:00Z")
        XCTAssertEqual(board.account?.pct, 50)
        XCTAssertEqual(board.account?.lossCents, 2000)
        XCTAssertEqual(board.account?.limitCents, 125_000)
        XCTAssertEqual(board.account?.suspended, false)
        XCTAssertEqual(board.account?.dayStartMarkedCents, 250_000)
        XCTAssertEqual(board.engines.map(\.id), ["aggr-2", "future-engine"])
        let row = board.engines[0]
        XCTAssertEqual(row.name, "Aggressive 2")
        XCTAssertEqual(row.lifecycle?.state, .probe)
        XCTAssertEqual(row.lifecycle?.stopReasons, [])
        XCTAssertEqual(row.assignment?.accountId, "acct-probe")
        XCTAssertEqual(row.probeToday?.tickets, 41)
        XCTAssertEqual(ProbePresentation.breakerMeter(row.lifecycle?.breaker), "-$12.40 of $1,250.00 (50%) · UTC day")
        XCTAssertEqual(ProbePresentation.perContract(row.live), "+3.2c per contract · n 41")
        XCTAssertEqual(ProbePresentation.nextStep(code: row.nextStep?.code, text: row.nextStep?.text),
                       "Probing: day 3 of 14, 41 tickets, -$1.20; verdict due Oct 7")
        XCTAssertEqual(board.engines[1].lifecycle?.state, .unknown)
        XCTAssertNil(board.engines[1].live)
        XCTAssertEqual(ProbePresentation.breakerMeter(board.engines[1].lifecycle?.breaker), "Not reported")

        let empty = try accountJSONDecoder().decode(ProbeBoardResponse.self, from: Data(#"{"account":null}"#.utf8))
        XCTAssertNil(empty.account)
        XCTAssertEqual(empty.engines, [])
    }

    func testExecutorSummaryDecodesOnBook() throws {
        let json = """
        {"schema_version":1,"books":[{"book_id":"BTC-15M","kalshi_book":{"executor":{
          "incumbent_engine_id":"default","disagreements_today":2,
          "position":{"ticker":"KXBTC-T1","side_yes":true,"contracts":1.5,"holder_engine_id":"default","opened_at_ms":1758600000000},
          "engines":[{"engine_id":"default","role":"incumbent","state":"graduated","entries_enabled":true},
                     {"engine_id":"aggr-2","role":"probe","state":"probe","stop_reasons":["breaker_engine"],
                      "entries_suspended_until":"2026-09-24T00:00:00Z","realized_today_cents":-120,"open_positions":1,
                      "last_proposal":{"ticker":"KXBTC-T1","side_yes":false,"price_cents":41,"edge_cents":3.5,
                        "at_ms":1758600000000,"disposition":"refused","reason":"engine_disagreement"}}]}}}]}
        """
        let payload = try accountJSONDecoder().decode(MobileBooks.self, from: Data(json.utf8))
        let executor = try XCTUnwrap(payload.books.first?.kalshiBook.executor)
        XCTAssertEqual(executor.incumbentEngineId, "default")
        XCTAssertEqual(executor.disagreementsToday, 2)
        XCTAssertEqual(executor.position?.contracts, 1.5)
        XCTAssertEqual(executor.position?.holderEngineId, "default")
        XCTAssertEqual(executor.engines.map(\.id), ["default", "aggr-2"])
        XCTAssertEqual(executor.engines[0].state, .graduated)
        let probe = executor.engines[1]
        XCTAssertEqual(probe.state, .probe)
        XCTAssertEqual(probe.stopReasons, [.init(code: "breaker_engine", text: nil)])
        XCTAssertEqual(probe.realizedTodayCents, -120)
        XCTAssertEqual(probe.lastProposal?.disposition, "refused")
        XCTAssertEqual(probe.lastProposal?.edgeCents, 3.5)

        let bare = try accountJSONDecoder().decode(ExecutorSummary.self, from: Data("{}".utf8))
        XCTAssertEqual(bare.engines, [])
        XCTAssertNil(bare.position)
    }

    // MARK: - Server shape (GET /api/leafhft/mobile/engines with x-kashbot-engine-runtime: 1)

    private static let aggrAccountId = #"["opbox-1","kalshi",1]"#

    /// The server-shape fixture with `aggr-2` (the first engine) passed through `mutate`, re-serialized.
    private func serverFixture(aggr mutate: (inout [String: Any]) -> Void) throws -> Data {
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData("engines-runtime-server")) as? [String: Any])
        var engines = try XCTUnwrap(object["engines"] as? [[String: Any]])
        XCTAssertEqual(engines.first?["engine_id"] as? String, "aggr-2")
        mutate(&engines[0])
        object["engines"] = engines
        return try JSONSerialization.data(withJSONObject: object)
    }

    private func assertNoRuntime(_ engine: Engine) {
        XCTAssertNil(engine.lifecycle, engine.engineId)
        XCTAssertNil(engine.assignment, engine.engineId)
        XCTAssertNil(engine.inputs, engine.engineId)
        XCTAssertNil(engine.markets, engine.engineId)
        XCTAssertNil(engine.probeToday, engine.engineId)
        XCTAssertNil(engine.live, engine.engineId)
        XCTAssertNil(engine.eligibleToProbe, engine.engineId)
    }

    private func assertFast(_ engine: Engine) throws {
        XCTAssertEqual(engine.engineId, "fast")
        let lifecycle = try XCTUnwrap(engine.lifecycle)
        XCTAssertEqual(lifecycle.state, .probe)
        XCTAssertEqual(lifecycle.label, "Probing")
        XCTAssertNil(lifecycle.contracts)
        let assignment = try XCTUnwrap(engine.assignment)
        XCTAssertEqual(assignment.account, "other")
        XCTAssertNil(assignment.accountId)
        XCTAssertNil(engine.probeToday)
        XCTAssertNil(engine.live)
        XCTAssertEqual(engine.eligibleToProbe?.eligible, false)
        XCTAssertEqual(engine.eligibleToProbe?.reasons, [])
    }

    private func assertDefault(_ engine: Engine) {
        XCTAssertEqual(engine.engineId, "default")
        XCTAssertEqual(engine.name, "Default")
        assertNoRuntime(engine)
    }

    func testServerShapeFixtureDecodesEveryRuntimeField() throws {
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: fixtureData("engines-runtime-server"))
        let engines = try XCTUnwrap(response.engines)
        XCTAssertEqual(engines.map(\.engineId), ["aggr-2", "fast", "default"])
        let aggr = engines[0]

        let lifecycle = try XCTUnwrap(aggr.lifecycle)
        XCTAssertEqual(lifecycle.state, .halted)
        XCTAssertEqual(lifecycle.label, "Entries halted, settlement only")
        XCTAssertEqual(lifecycle.entriesEnabled, false)
        XCTAssertEqual(lifecycle.entriesSuspendedUntil, iso("2026-09-28T00:00:00Z"))
        XCTAssertEqual(lifecycle.contracts, 2)
        XCTAssertEqual(lifecycle.stopReasons, [
            .init(code: "breaker_engine", text: "This engine's day loss reached 50% of the day-start portfolio."),
            .init(code: "operator_halt", text: "")
        ])
        XCTAssertEqual(lifecycle.probeStartedAt, "2026-09-23T04:00:00.000Z")
        XCTAssertEqual(lifecycle.expiresAt, "2026-10-14T04:00:00.000Z")
        XCTAssertNil(lifecycle.breaker)
        XCTAssertEqual(ProbePresentation.breakerMeter(lifecycle.breaker), "Not reported")

        let assignment = try XCTUnwrap(aggr.assignment)
        XCTAssertEqual(assignment.account, "own")
        XCTAssertEqual(assignment.accountId, Self.aggrAccountId)
        XCTAssertEqual(assignment.role, "probe")
        XCTAssertEqual(assignment.domain, "kalshi")
        XCTAssertEqual(assignment.since, "2026-09-23T04:00:00.000Z")

        XCTAssertEqual(aggr.inputs, [EngineInput(kind: "kalshi_book", id: "kalshi-book:BTC-15M"),
                                     EngineInput(kind: "kalshi_book", id: "kalshi-book:ETH-15M")])
        XCTAssertEqual(aggr.markets, ["BTC-15M", "ETH-15M"])

        let day = try XCTUnwrap(aggr.probeToday)
        XCTAssertEqual(day.utcDay, "2026-09-27")
        XCTAssertEqual(day.realizedCents, -1240)
        XCTAssertEqual(day.entries, 11)
        XCTAssertNil(day.tickets)

        let live = try XCTUnwrap(aggr.live)
        XCTAssertEqual(live.n, 41)
        XCTAssertEqual(live.days, 5)
        XCTAssertEqual(live.perContractCents, 3.23)
        XCTAssertEqual(ProbePresentation.perContract(live), "+3.2c per contract · n 41")

        XCTAssertEqual(aggr.eligibleToProbe?.eligible, true)
        XCTAssertEqual(aggr.eligibleToProbe?.reasons, [])

        try assertFast(engines[1])
        assertDefault(engines[2])

        // The legacy fields survive beside the runtime extension.
        XCTAssertEqual(aggr.pnl?.n, 41)
        XCTAssertEqual(aggr.configuration?.accounts.first?.accountId, Self.aggrAccountId)
        XCTAssertEqual(response.accounts?.first?.label, "Subaccount 1 · opbox-1")
    }

    func testEligibilityDecodesBoolAndObject() throws {
        let cases: [(json: String, eligible: Bool, reasons: [String])] = [
            ("true", true, []),
            ("false", false, []),
            (#"{"eligible":true}"#, true, []),
            (#"{"eligible":false,"reasons":["Already probing"]}"#, false, ["Already probing"])
        ]
        for (json, eligible, reasons) in cases {
            let wrapped = try accountJSONDecoder().decode([String: ProbeEligibility].self,
                from: Data(#"{"value":\#(json)}"#.utf8))
            let decoded = try XCTUnwrap(wrapped["value"], json)
            XCTAssertEqual(decoded.eligible, eligible, json)
            XCTAssertEqual(decoded.reasons, reasons, json)
        }
        // The encoder still writes the object form, and it round-trips.
        let original = ProbeEligibility(eligible: false, reasons: ["Already probing"])
        XCTAssertEqual(try accountJSONDecoder().decode(ProbeEligibility.self, from: JSONEncoder().encode(original)), original)
    }

    func testMalformedRuntimeFieldsAreNilAndNeverFailTheList() throws {
        let malformed = try serverFixture { aggr in
            aggr["lifecycle"] = "halted"
            aggr["assignment"] = 5
            aggr["inputs"] = [["kind": 1]]
            aggr["markets"] = "BTC-15M"
            aggr["probeToday"] = [Any]()
            aggr["live"] = ["n": NSNull(), "days": 5] as [String: Any]
            aggr["eligibleToProbe"] = "yes"
        }
        let response = try accountJSONDecoder().decode(EnginesResponse.self, from: malformed)
        let engines = try XCTUnwrap(response.engines)
        XCTAssertEqual(engines.map(\.engineId), ["aggr-2", "fast", "default"])
        assertNoRuntime(engines[0])
        XCTAssertEqual(engines[0].name, "Aggressive 2")
        XCTAssertEqual(engines[0].pnl?.n, 41)
        try assertFast(engines[1])
        assertDefault(engines[2])

        let fractional = try serverFixture { aggr in
            var lifecycle = aggr["lifecycle"] as? [String: Any] ?? [:]
            lifecycle["contracts"] = 2.5
            aggr["lifecycle"] = lifecycle
        }
        let sized = try XCTUnwrap(accountJSONDecoder().decode(EnginesResponse.self, from: fractional).engines?.first)
        let lifecycle = try XCTUnwrap(sized.lifecycle)
        XCTAssertEqual(lifecycle.state, .halted)
        XCTAssertNil(lifecycle.contracts)
    }

    func testFutureMobileBreakerDecodes() throws {
        let json = """
        {"state":"probe_sized","contracts":2,"breaker":{"utc_day":"2026-09-27","engine_pct":50,"inherited":true,
          "engine_loss_cents":1240,"engine_limit_cents":125000,"engine_suspended":false,"account_pct":50,
          "account_loss_cents":2000,"account_limit_cents":125000,"account_suspended":false,
          "day_start_marked_cents":250000,"observed_at":"2026-09-27T15:03:58.000Z"}}
        """
        let lifecycle = try accountJSONDecoder().decode(EngineLifecycle.self, from: Data(json.utf8))
        XCTAssertNotNil(lifecycle.breaker)
        XCTAssertEqual(ProbePresentation.breakerMeter(lifecycle.breaker), "-$12.40 of $1,250.00 (50%) · UTC day")

        // A malformed breaker is nil and never fails the lifecycle.
        let malformed = try accountJSONDecoder().decode(EngineLifecycle.self,
            from: Data(#"{"state":"probe","breaker":"tripped"}"#.utf8))
        XCTAssertEqual(malformed.state, .probe)
        XCTAssertNil(malformed.breaker)
    }
}
