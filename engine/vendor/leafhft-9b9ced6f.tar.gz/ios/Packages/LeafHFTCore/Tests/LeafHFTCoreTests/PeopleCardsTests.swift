import Foundation
import XCTest
@testable import LeafHFTCore

final class PeopleCardsTests: XCTestCase {
    private typealias P = PeopleCards
    private let now = Date(timeIntervalSince1970: 1_790_424_000)
    private var slots: [String] { (13...26).map { "2026-09-\($0)" } }
    private func at(_ seconds: TimeInterval = 0) -> Date { now.addingTimeInterval(seconds) }
    private var refusal: P.Refusal {
        P.Refusal(reason: "cash unavailable", supported: true, observedAt: at(-1), validUntil: at(1))
    }
    private var history: P.History {
        P.History(complete: true, from: at(-P.sixHours), through: now, orders: 0, provenance: .live)
    }
    private func order(_ seconds: TimeInterval = 0, provenance: P.Execution = .live) -> P.ExecutionEvidence {
        P.ExecutionEvidence(time: at(seconds), observedAt: now, provenance: provenance)
    }
    private func live() -> P.Lane { P.Lane(state: .live, revoked: false, killRequested: false, observedAt: now) }

    // Literal shapes from kashbot-people.ts unknownPerson and people-model.ts recordedActivity.
    private func response(lane: String = #"{"state":null,"revoked_at":null,"kill_requested":null}"#,
                          cash: String = #"{"value":null,"source":"card_unavailable:card_build_failed","observed_at":null}"#,
                          activationBudgetCash: String = #"{"value":null,"source":"card_unavailable:card_build_failed","observed_at":null}"#,
                          stake: String = #"{"value":null,"source":"card_unavailable:card_build_failed","observed_at":null}"#,
                          turnoverUsed: String = #"{"value":null,"source":"card_unavailable:card_build_failed","observed_at":null}"#,
                          cap: String = #"{"value":null,"source":"card_unavailable:card_build_failed","observed_at":null}"#,
                          lastRecordedAt: String = #"{"value":null,"source":"card_unavailable:card_build_failed","observed_at":null}"#,
                          observed24h: String = #"{"value":null,"source":"card_unavailable:card_build_failed","observed_at":"2026-09-26T12:00:00.000Z"}"#,
                          observed7d: String = #"{"value":null,"source":"card_unavailable:card_build_failed","observed_at":"2026-09-26T12:00:00.000Z"}"#,
                          exact24h: String = #"{"value":null,"source":"complete_history_unavailable","observed_at":null}"#,
                          exact7d: String = #"{"value":null,"source":"complete_history_unavailable","observed_at":null}"#,
                          accountID: String = "null",
                          engines: String = #"{"available":false,"truncated":false,"items":[],"unknown_reason":"card_build_failed"}"#) throws -> P.Response {
        let json = """
        {
          "generated_at":"2026-09-26T12:00:00.000Z",
          "sections":{
            "roster":{"available":true,"truncated":false},
            "telemetry":{"available":true,"truncated":false},
            "activity":{"available":true,"truncated":false},
            "balances":{"available":true,"truncated":false},
            "assignments":{"available":true,"truncated":false},
            "catalog":{"available":true,"truncated":false},
            "controls":{"available":true,"truncated":false},
            "performance":{"available":true,"truncated":false}
          },
          "truncated":false,
          "people":[{
            "lane_id":"l1","account_id":\(accountID),"host":null,"owner":false,"tenant_label":null,"label":"Lane l1",
            "lane":\(lane),
            "verdict":{"value":null,"source":"card_unavailable:card_build_failed","observed_at":null,"text":"unknown"},
            "refusal":{"dominant":{"value":null,"source":"comprehensive_refusal_unavailable","observed_at":null},"text":"unknown"},
            "activity":{
              "orders":{
                "coverage":"recorded_only",
                "last_recorded_at":\(lastRecordedAt),
                "observed_24h":\(observed24h),
                "observed_7d":\(observed7d),
                "exact_24h":\(exact24h),
                "exact_7d":\(exact7d)
              },
              "fills":{
                "coverage":"recorded_only",
                "last_recorded_at":\(lastRecordedAt),
                "observed_24h":\(observed24h),
                "observed_7d":\(observed7d),
                "exact_24h":\(exact24h),
                "exact_7d":\(exact7d)
              }
            },
            "money":{
              "current_cash_cents":\(cash),
              "reconciled":{"value":null,"source":"card_unavailable:card_build_failed","observed_at":null},
              "activation_budget_cash_cents":\(activationBudgetCash),
              "reported_per_book_stake_cents":\(stake),
              "reported_turnover_used_cents":\(turnoverUsed),
              "reported_cap_cents":\(cap)
            },
            "engines":\(engines)
          }]
        }
        """
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let value = try container.decode(String.self)
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            guard let date = formatter.date(from: value) else {
                throw DecodingError.dataCorruptedError(in: container, debugDescription: "Invalid fixture date")
            }
            return date
        }
        return try decoder.decode(P.Response.self, from: Data(json.utf8))
    }

    func testUnknownLane() throws {
        let response = try self.response()
        let person = try XCTUnwrap(response.people.first)
        XCTAssertEqual(person.lane.state, .unknown, "unknown-lane")
        XCTAssertNil(person.lane.revoked, "unknown-lane")
        XCTAssertNil(person.lane.killRequested, "unknown-lane")
        XCTAssertNil(person.lane.observedAt, "unknown-lane")
        XCTAssertEqual(person.lane.verdict(at: response.generatedAt), .unknown)
        XCTAssertEqual(person.lane.killText, "Kill request: no data.")
        XCTAssertNil(person.lane.refusal.reason)
        XCTAssertNil(person.lane.refusal.observedAt)
        for activity in [person.orders, person.fills] {
            XCTAssertNil(activity.recorded24h.value)
            XCTAssertNil(activity.recorded7d.value)
            XCTAssertNil(activity.total24h.value)
            XCTAssertNil(activity.total7d.value)
            XCTAssertNil(activity.observedAt)
        }
        XCTAssertTrue(person.scopedEngines.isEmpty)
    }

    func testKnownFalse() throws {
        let response = try self.response(
            lane: #"{"state":"live","revoked_at":null,"kill_requested":false}"#,
            cash: #"{"value":0,"source":"leafhft_kalshi_balances","observed_at":"2026-09-26T12:00:00.000Z"}"#)
        let person = try XCTUnwrap(response.people.first)
        XCTAssertEqual(person.lane.state, .live, "known-false")
        // Only kill_requested is an explicit boolean; null revoked_at does not attest false.
        XCTAssertNil(person.lane.revoked, "known-false")
        XCTAssertEqual(person.lane.killRequested, false, "known-false")
        XCTAssertEqual(person.lane.killText, "Kill not requested in supplied evidence.")
        XCTAssertEqual(person.lane.observedAt, response.generatedAt)
        XCTAssertEqual(person.funds.currentCash?.text, "0 USD")
        XCTAssertEqual(person.funds.observedAt, response.generatedAt)
        let revoked = try self.response(
            lane: #"{"state":"live","revoked_at":"2026-09-26T12:00:00.000Z","kill_requested":false}"#)
        XCTAssertEqual(revoked.people.first?.lane.revoked, true)
        XCTAssertEqual(revoked.people.first?.lane.verdict(at: revoked.generatedAt), .off)
    }

    func testEvidenceNull() throws {
        // The balance producer can return null cash with a known captured_at.
        let response = try self.response(
            cash: #"{"value":null,"source":"leafhft_kalshi_balances","observed_at":"2026-09-26T12:00:00.000Z"}"#)
        let funds = try XCTUnwrap(response.people.first).funds
        XCTAssertNil(funds.currentCash, "evidence-null")
        XCTAssertNil(funds.observedAt, "evidence-null")
        XCTAssertNil(funds.activationBudgetCash)
        XCTAssertNil(funds.reportedStake)
        XCTAssertNil(funds.turnoverUsed)
        XCTAssertNil(funds.reportedCap)
    }

    func testPartialMoney() throws {
        let response = try self.response(
            cash: #"{"value":null,"source":"leafhft_kalshi_balances","observed_at":"2026-09-26T12:00:00.000Z"}"#,
            stake: #"{"value":100,"source":"telemetry","observed_at":"2026-09-26T12:00:00.000Z"}"#)
        let funds = try XCTUnwrap(response.people.first).funds
        XCTAssertNil(funds.currentCash, "partial-money")
        XCTAssertEqual(funds.reportedStake?.text, "1 USD", "partial-money")
        XCTAssertEqual(funds.observedAt, response.generatedAt, "partial-money")

        let mixed = try self.response(
            cash: #"{"value":null,"source":"leafhft_kalshi_balances","observed_at":"2026-09-26T12:00:00.000Z"}"#,
            activationBudgetCash: #"{"value":500,"source":"telemetry","observed_at":"2026-09-26T10:00:00.000Z"}"#,
            stake: #"{"value":100,"source":"telemetry","observed_at":"2026-09-26T09:00:00.000Z"}"#,
            turnoverUsed: #"{"value":200,"source":"telemetry","observed_at":"2026-09-26T11:00:00.000Z"}"#,
            cap: #"{"value":null,"source":"telemetry","observed_at":"2026-09-26T12:00:00.000Z"}"#)
        XCTAssertEqual(mixed.people.first?.funds.observedAt,
            mixed.generatedAt.addingTimeInterval(-3600), "partial-money")
    }

    func testKnownMoneyUnchanged() throws {
        let response = try self.response(
            cash: #"{"value":1000,"source":"leafhft_kalshi_balances","observed_at":"2026-09-26T10:00:00.000Z"}"#,
            activationBudgetCash: #"{"value":500,"source":"telemetry","observed_at":"2026-09-26T09:00:00.000Z"}"#,
            stake: #"{"value":100,"source":"telemetry","observed_at":"2026-09-26T12:00:00.000Z"}"#,
            turnoverUsed: #"{"value":200,"source":"telemetry","observed_at":"2026-09-26T11:00:00.000Z"}"#,
            cap: #"{"value":800,"source":"telemetry","observed_at":"2026-09-26T12:00:00.000Z"}"#)
        let funds = try XCTUnwrap(response.people.first).funds
        XCTAssertEqual(funds.observedAt, response.generatedAt.addingTimeInterval(-7200), "known-money-unchanged")
        XCTAssertEqual(funds.currentCash?.text, "10 USD", "known-money-unchanged")
        XCTAssertEqual(funds.activationBudgetCash?.text, "5 USD")
        XCTAssertEqual(funds.reportedStake?.text, "1 USD")
        XCTAssertEqual(funds.turnoverUsed?.text, "2 USD")
        XCTAssertEqual(funds.reportedCap?.text, "8 USD")
    }

    func testAllUnknownMoney() throws {
        let response = try self.response(
            cash: #"{"value":null,"source":"leafhft_kalshi_balances","observed_at":"2026-09-26T12:00:00.000Z"}"#,
            activationBudgetCash: #"{"value":null,"source":"telemetry","observed_at":"2026-09-26T09:00:00.000Z"}"#,
            stake: #"{"value":null,"source":"telemetry","observed_at":"2026-09-26T10:00:00.000Z"}"#,
            turnoverUsed: #"{"value":null,"source":"telemetry","observed_at":"2026-09-26T11:00:00.000Z"}"#,
            cap: #"{"value":null,"source":"telemetry","observed_at":"2026-09-26T12:00:00.000Z"}"#)
        let funds = try XCTUnwrap(response.people.first).funds
        XCTAssertNil(funds.observedAt, "all-unknown-money")
        XCTAssertNil(funds.currentCash)
        XCTAssertNil(funds.activationBudgetCash)
        XCTAssertNil(funds.reportedStake)
        XCTAssertNil(funds.turnoverUsed)
        XCTAssertNil(funds.reportedCap)
    }

    func testActivityPartial() throws {
        let response = try self.response(
            lastRecordedAt: #"{"value":"2026-09-26T09:00:00.000Z","source":"leafhft_kalshi_orders","observed_at":"2026-09-26T09:00:00.000Z"}"#,
            observed24h: #"{"value":null,"source":"leafhft_kalshi_orders","observed_at":"2026-09-26T12:00:00.000Z"}"#,
            observed7d: #"{"value":1,"source":"leafhft_kalshi_orders","observed_at":"2026-09-26T12:00:00.000Z"}"#)
        let person = try XCTUnwrap(response.people.first)
        for activity in [person.orders, person.fills] {
            XCTAssertNil(activity.recorded24h.value, "activity-partial")
            XCTAssertEqual(activity.recorded7d.value, 1, "activity-partial")
            XCTAssertEqual(activity.observedAt, response.generatedAt, "activity-partial")
        }
        let mixed = try self.response(
            observed7d: #"{"value":1,"source":"leafhft_kalshi_orders","observed_at":"2026-09-26T09:00:00.000Z"}"#,
            exact24h: #"{"value":2,"source":"leafhft_kalshi_orders","observed_at":"2026-09-26T11:00:00.000Z"}"#,
            exact7d: #"{"value":null,"source":"complete_history_unavailable","observed_at":"2026-09-26T12:00:00.000Z"}"#)
        XCTAssertEqual(mixed.people.first?.orders.observedAt,
            mixed.generatedAt.addingTimeInterval(-3600), "activity-latest")
        XCTAssertEqual(mixed.people.first?.fills.observedAt,
            mixed.generatedAt.addingTimeInterval(-3600), "activity-latest")
    }

    func testKnownActivityUnchanged() throws {
        let response = try self.response(
            observed24h: #"{"value":0,"source":"leafhft_kalshi_orders","observed_at":"2026-09-26T10:00:00.000Z"}"#,
            observed7d: #"{"value":1,"source":"leafhft_kalshi_orders","observed_at":"2026-09-26T12:00:00.000Z"}"#)
        let person = try XCTUnwrap(response.people.first)
        for activity in [person.orders, person.fills] {
            XCTAssertEqual(activity.recorded24h.value, 0, "known-activity")
            XCTAssertEqual(activity.observedAt, response.generatedAt.addingTimeInterval(-7200), "known-activity")
        }
    }

    // Literal engine/day evidence shape from people-model.ts reportedPerformance.
    private func performanceResponse(
        realized: String = #"{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"}"#,
        entries: String = #"{"value":1,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T09:00:00.000Z"}"#,
        settled: String = #"{"value":0,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T11:00:00.000Z"}"#
    ) throws -> P.Response {
        try response(accountID: #""a1""#, engines: """
        {"available":true,"truncated":false,"items":[{
          "engine_id":"e1","account_id":"a1",
          "assignment":{"value":"assigned","source":"kashbot_engine_assignments","observed_at":"2026-09-26T09:00:00.000Z"},
          "enabled":{"value":null,"source":"leafhft_engine_control_state","observed_at":null},
          "execution_provenance":null,
          "sharing":{"status":"unknown","truncated":false,"source":"leafhft_engine_control_state","observed_at":null,"others":[]},
          "performance":{"source":"kashbot_engine_day_pnl","coverage":"reported_days","observed_days":1,"days":[{
            "utc_day":"2026-09-26","observed":true,
            "realized_cents":\(realized),"entries":\(entries),"settled":\(settled),
            "exits":{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"},
            "won":{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"},
            "lost":{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"},
            "voided":{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"}
          }],"totals":{
            "realized_cents":\(realized),"entries":\(entries),"settled":\(settled),
            "exits":{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"},
            "won":{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"},
            "lost":{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"},
            "voided":{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"}
          },"settlement_win_rate":{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T12:00:00.000Z"},
          "fees_cents":{"value":null,"source":"unsupported","observed_at":null},"projection":null,"tuning":null}
        }]}
        """)
    }

    func testPerformancePartial() throws {
        let response = try performanceResponse()
        let day = try XCTUnwrap(response.people.first?.scopedEngines.first?.performance.days.first)
        XCTAssertNil(day.metrics.realized, "performance-partial")
        XCTAssertEqual(day.metrics.entries.value, 1, "performance-partial")
        XCTAssertEqual(day.metrics.settled.value, 0, "performance-partial")
        XCTAssertEqual(day.observedAt, response.generatedAt.addingTimeInterval(-3600), "performance-partial")
    }

    func testKnownPerformanceUnchanged() throws {
        let response = try performanceResponse(
            realized: #"{"value":0,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T10:00:00.000Z"}"#)
        let day = try XCTUnwrap(response.people.first?.scopedEngines.first?.performance.days.first)
        XCTAssertEqual(day.metrics.realized?.text, "0 USD", "known-performance")
        XCTAssertEqual(day.observedAt, response.generatedAt.addingTimeInterval(-7200), "known-performance")
        let noTime = try performanceResponse(
            realized: #"{"value":0,"source":"kashbot_engine_day_pnl","observed_at":null}"#)
        let performance = try XCTUnwrap(noTime.people.first?.scopedEngines.first?.performance)
        let unobservedDay = try XCTUnwrap(performance.days.first)
        XCTAssertNil(unobservedDay.observedAt, "primary-known-no-time")
        XCTAssertFalse(unobservedDay.isObserved, "primary-known-no-time")
        XCTAssertEqual(performance.realizedText, "no data", "primary-known-no-time")
    }

    func testAllUnknownPerformance() throws {
        let response = try performanceResponse(
            entries: #"{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T09:00:00.000Z"}"#,
            settled: #"{"value":null,"source":"kashbot_engine_day_pnl","observed_at":"2026-09-26T11:00:00.000Z"}"#)
        let day = try XCTUnwrap(response.people.first?.scopedEngines.first?.performance.days.first)
        XCTAssertNil(day.observedAt, "performance-empty")
        XCTAssertFalse(day.isObserved, "performance-empty")
    }

    func testEnginesEmptyNoData() throws {
        let person = try XCTUnwrap(response().people.first)
        XCTAssertTrue(person.scopedEngines.isEmpty, "engines-empty-no-data")
        XCTAssertEqual(person.emptyEnginesText, "Account-engine performance: no data", "engines-empty-no-data")
        let viewURL = URL(fileURLWithPath: #filePath).deletingLastPathComponent()
            .appendingPathComponent("../../../../LeafHFT/Views/PeopleCardsView.swift").standardizedFileURL
        let viewSource = try String(contentsOf: viewURL, encoding: .utf8)
        XCTAssertTrue(viewSource.contains("if let text = person.emptyEnginesText { Text(text) }"),
            "engines-empty-no-data: the view must render the empty-engine text")
        let populated = try XCTUnwrap(performanceResponse().people.first)
        XCTAssertFalse(populated.scopedEngines.isEmpty)
        XCTAssertNil(populated.emptyEnginesText)
    }

    func testUnchangedLaneReevaluatesAsTimeAdvances() {
        var lane = live()
        lane.lastOrder = order(-P.sixHours + 30)
        XCTAssertEqual(lane.verdict(at: now), .trading)
        XCTAssertEqual(lane.verdict(at: at(30)), .trading)
        XCTAssertEqual(lane.verdict(at: at(60)), .unknown)

        lane.lastOrder = order()
        lane.refusal = refusal
        XCTAssertEqual(lane.verdict(at: now), .blocked)
        XCTAssertEqual(lane.refusal.currentReason(at: now), "cash unavailable")
        XCTAssertEqual(lane.verdict(at: at(1)), .blocked)
        XCTAssertNil(lane.refusal.currentReason(at: at(30)))
        XCTAssertEqual(lane.verdict(at: at(30)), .trading)
        XCTAssertEqual(lane.verdict(at: at(P.sixHours + 1)), .unknown)

        lane.lastOrder = P.ExecutionEvidence()
        lane.refusal = P.Refusal()
        lane.history = history
        XCTAssertEqual(lane.verdict(at: now), .idle)
        XCTAssertEqual(lane.verdict(at: at(30)), .unknown)
        lane.state = .paused
        XCTAssertEqual(lane.verdict(at: at(P.sixHours + 1)), .off)
    }

    func testOffAndUnknownStatePrecedeActivityAndRefusal() {
        for (id, state) in [("pause", P.LaneState.paused), ("nonlive", .nonLive), ("state", .unknown)] {
            var lane = live()
            lane.state = state
            lane.refusal = refusal
            lane.lastOrder = order()
            lane.history = history
            XCTAssertEqual(lane.verdict(at: now), state == .unknown ? .unknown : .off, id)
        }
        for id in ["revoke", "kill"] {
            var lane = live()
            lane.state = .unknown
            lane.revoked = id == "revoke"
            lane.killRequested = id == "kill"
            lane.refusal = refusal
            lane.lastOrder = order()
            XCTAssertEqual(lane.verdict(at: now), .off, id)
        }
    }

    func testRefusalSupportValidityAndPrecedence() {
        var cases: [(String, P.Refusal, P.Verdict)] = [("valid", refusal, .blocked)]
        var value = refusal
        value.validUntil = now
        cases.append(("boundary", value, .blocked))
        value.validUntil = at(-0.001)
        cases.append(("expired", value, .unknown))
        value = refusal; value.observedAt = at(0.001)
        cases.append(("future", value, .unknown))
        value = refusal; value.validFrom = at(0.001)
        cases.append(("notyet", value, .unknown))
        value = refusal; value.validUntil = nil
        cases.append(("noend", value, .unknown))
        value = refusal; value.observedAt = nil
        cases.append(("noat", value, .unknown))
        value = refusal; value.supported = false
        cases.append(("unsupported", value, .unknown))
        value = refusal; value.reason = " \n "
        cases.append(("blank", value, .unknown))
        value = refusal; value.reason = nil
        cases.append(("missing", value, .unknown))
        for (id, evidence, expected) in cases {
            var lane = live(); lane.refusal = evidence
            XCTAssertEqual(lane.verdict(at: now), expected, id)
        }
        var lane = live()
        lane.refusal = refusal; lane.lastOrder = order(); lane.history = history
        XCTAssertEqual(lane.verdict(at: now), .blocked)
        lane.refusal.validUntil = at(-1)
        XCTAssertEqual(lane.verdict(at: now), .trading)
        XCTAssertNil(lane.refusal.currentReason(at: now))
    }

    func testInclusiveSixHourTradingBoundaryAndObservationTimes() {
        for (id, age, expected) in [("now", 0.0, P.Verdict.trading), ("six", -P.sixHours, .trading),
                                     ("old", -P.sixHours - 0.001, .unknown), ("future", 0.001, .unknown)] {
            var lane = live(); lane.lastOrder = order(age)
            XCTAssertEqual(lane.verdict(at: now), expected, id)
        }
        var lane = live(); lane.lastOrder = order()
        lane.lastOrder.observedAt = at(1)
        XCTAssertEqual(lane.verdict(at: now), .unknown)
        lane.lastOrder.observedAt = nil
        XCTAssertEqual(lane.verdict(at: now), .unknown)
        lane.lastOrder.observedAt = at(-1)
        XCTAssertEqual(lane.verdict(at: now), .unknown, "order after observation")
        lane.lastOrder = order(); lane.history = history
        XCTAssertEqual(lane.verdict(at: now), .trading, "order precedes history")
        XCTAssertEqual(lane.verdict(at: Date(timeIntervalSinceReferenceDate: .nan)), .unknown)
        lane.observedAt = at(1)
        XCTAssertEqual(lane.verdict(at: now), .unknown, "future lane observation")
    }

    func testIdleRequiresCompleteLiveHistoryThroughReferenceTime() {
        var cases: [(String, P.History, P.Verdict)] = [("complete", history, .idle)]
        var value = history; value.complete = false
        cases.append(("partial", value, .unknown))
        value = history; value.from = at(-P.sixHours + 0.001)
        cases.append(("short", value, .unknown))
        value = history; value.through = at(-0.001)
        cases.append(("gap", value, .unknown))
        value = history; value.through = at(0.001)
        cases.append(("future", value, .unknown))
        value = history; value.from = nil
        cases.append(("nostart", value, .unknown))
        value = history; value.through = nil
        cases.append(("noend", value, .unknown))
        value = history; value.orders = P.Quantity()
        cases.append(("nocount", value, .unknown))
        value = history; value.orders = P.Quantity(1)
        cases.append(("nonzero", value, .unknown))
        value = history; value.provenance = .paper
        cases.append(("paper", value, .unknown))
        value = history; value.provenance = .unknown
        cases.append(("provenance", value, .unknown))
        for (id, evidence, expected) in cases {
            var lane = live(); lane.history = evidence
            XCTAssertEqual(lane.verdict(at: now), expected, id)
        }
        var lane = live()
        XCTAssertEqual(lane.verdict(at: now), .unknown, "missing is not an empty read")
        lane.lastOrder = order(-P.sixHours - 1)
        XCTAssertEqual(lane.verdict(at: now), .unknown, "old order does not prove idle")
        lane.history = history
        XCTAssertEqual(lane.verdict(at: now), .idle)
    }

    func testFillsAndUnprovenExecutionCannotEstablishTrading() {
        var lane = live(); lane.lastFill = order()
        XCTAssertEqual(lane.verdict(at: now), .unknown)
        lane.lastFill = order(1)
        XCTAssertEqual(lane.verdict(at: now), .unknown)
        for provenance in [P.Execution.paper, .unknown] {
            lane.lastOrder = order(provenance: provenance)
            XCTAssertEqual(lane.verdict(at: now), .unknown, provenance.rawValue)
        }
        lane.lastOrder = order(); lane.killRequested = true
        XCTAssertEqual(lane.verdict(at: now), .off)
        XCTAssertEqual(lane.killText, "Kill requested; runner termination unconfirmed.")
        XCTAssertEqual(P.Lane.offExplanation, "Off describes lane/control state, not confirmed runner termination.")
        lane.killRequested = nil
        XCTAssertEqual(lane.killText, "Kill request: no data.")
        lane.killRequested = false
        XCTAssertEqual(lane.killText, "Kill not requested in supplied evidence.")
    }

    func testFractionalNullZeroAndNonfiniteQuantities() {
        XCTAssertEqual(P.Quantity(0.01).value, 0.01)
        XCTAssertEqual(P.Quantity(0.01).text, "0.01")
        XCTAssertEqual(P.Quantity(0).text, "0")
        XCTAssertEqual(P.Quantity().text, "no data")
        for value in [Double.nan, .infinity, -.infinity] {
            XCTAssertNil(P.Quantity(value).value)
            XCTAssertEqual(P.Money(value, currency: "USD").text, "no data")
        }
        XCTAssertEqual(P.Money(0, currency: "USD").text, "0 USD")
        XCTAssertEqual(P.Money(0.01, currency: "USD").text, "0.01 USD")
        XCTAssertEqual(P.Money(currency: "USD").text, "no data")
        XCTAssertEqual(P.Money(1, currency: " ").text, "no data")
        let funds = P.Funds(currentCash: P.Money(0, currency: "USD"), activationBudgetCash: P.Money(5, currency: "USD"),
            reportedStake: P.Money(0.01, currency: "USD"), turnoverUsed: P.Money(2, currency: "USD"), reportedCap: P.Money(10, currency: "USD"))
        XCTAssertEqual(funds.currentCash?.amount.value, 0)
        XCTAssertEqual(funds.activationBudgetCash?.amount.value, 5)
        XCTAssertEqual(funds.reportedStake?.amount.value, 0.01)
        XCTAssertEqual(funds.turnoverUsed?.amount.value, 2)
        XCTAssertEqual(funds.reportedCap?.amount.value, 10)
        XCTAssertNil(P.Funds().currentCash)
    }

    func testRecordedCountsAreSeparateFromCompleteTotals() {
        let activity = P.Activity(recorded24h: 0, recorded7d: 2, observedAt: now)
        XCTAssertEqual(activity.recorded24h.value, 0)
        XCTAssertEqual(activity.recorded7d.value, 2)
        XCTAssertNil(activity.total24h.value)
        XCTAssertNil(activity.total7d.value)
        XCTAssertEqual(activity.coverage, "recorded only; complete totals unavailable")
        XCTAssertEqual(activity.observedAt, now)
        XCTAssertNil(P.Activity().recorded24h.value)
        let complete = P.Activity(recorded24h: 0, recorded7d: 0, total24h: 0, total7d: 0,
            coverage: "complete supplied history", observedAt: now)
        XCTAssertEqual(complete.total24h.value, 0)
        XCTAssertEqual(complete.total7d.value, 0)
    }

    func testAssignmentsRequireSuccessfulCompleteReads() {
        for read in [P.ReadStatus.incomplete, .unavailable, .failed] {
            XCTAssertEqual(P.assignmentLabel(engineID: "e1", accountID: "a1", enabled: true, read: read, assignments: []), "unknown")
            XCTAssertEqual(P.assignmentLabel(engineID: "e1", accountID: "a1", enabled: true, read: read,
                assignments: [P.Assignment(accountID: "a1", engineID: "e1")]), "unknown")
        }
        XCTAssertEqual(P.assignmentLabel(engineID: "e1", accountID: "a1", enabled: true, read: .complete, assignments: []), "unassigned catalog")
        for enabled in [Optional<Bool>.none, .some(false)] {
            XCTAssertEqual(P.assignmentLabel(engineID: "e1", accountID: "a1", enabled: enabled, read: .complete, assignments: []), "unknown")
        }
        let assigned = [P.Assignment(accountID: "alias", engineID: "e1")]
        XCTAssertEqual(P.assignmentLabel(engineID: "e1", accountID: "a1", enabled: true, read: .complete,
            assignments: assigned, aliases: ["alias": "a1"]), "assigned")
        XCTAssertEqual(P.assignmentLabel(engineID: "e1", accountID: "a2", enabled: true, read: .complete,
            assignments: assigned, aliases: ["alias": "a1"]), "unknown")
        XCTAssertEqual(P.assignmentLabel(engineID: "e2", accountID: "a1", enabled: true, read: .complete,
            assignments: assigned), "unassigned catalog")
    }

    private func use(_ account: String, engine: String = "e1") -> P.EngineUse {
        P.EngineUse(accountID: account, label: "Person \(account)", engineID: engine, family: "f1",
            enabled: true, provenance: .live, observedAt: now)
    }
    private func share(_ uses: [P.EngineUse], roster: P.ReadStatus = .complete, controls: P.ReadStatus = .complete,
                       aliases: [String: String] = [:]) -> P.Sharing {
        P.sharing(engineID: "e1", accountID: "a1", observations: uses, aliases: aliases,
            roster: roster, controls: controls, now: now)
    }

    func testSharingUsesExactEngineAndCanonicalAccountIdentities() {
        let aliases = ["alias": "a1", "other": "a2"]
        let result = share([use("a1"), use("alias"), use("a2"), use("other"), use("a2")], aliases: aliases)
        XCTAssertEqual(result.status, .shared)
        XCTAssertEqual(result.others.map(\.accountID), ["a2"])
        XCTAssertEqual(result.others.map(\.label), ["Person a2"])
        XCTAssertEqual(result.text, "Shared live use with Person a2")
        XCTAssertEqual(share([use("a1"), use("a1"), use("alias")], aliases: aliases).status, .notShared)
        XCTAssertEqual(share([use("a1"), use("a2", engine: "e2")]).status, .notShared, "same family is not same engine")
        var other = use("a2"); other.provenance = .paper
        XCTAssertEqual(share([use("a1"), other]).status, .notShared)
        XCTAssertTrue(share([use("a1"), other]).others.isEmpty)
        other = use("a2"); other.enabled = false
        XCTAssertEqual(share([use("a1"), other]).status, .notShared)
    }

    func testIncompleteSharingCannotClearButCanRetainProvenConflict() {
        XCTAssertEqual(share([]).status, .unknown)
        XCTAssertEqual(share([use("a2")]).status, .unknown)
        for read in [P.ReadStatus.incomplete, .unavailable, .failed] {
            XCTAssertEqual(share([use("a1")], roster: read).status, .unknown)
            XCTAssertEqual(share([use("a1")], controls: read).status, .unknown)
            let conflict = share([use("a1"), use("a2")], roster: read, controls: read)
            XCTAssertEqual(conflict.status, .shared)
            XCTAssertFalse(conflict.evidenceComplete)
        }
        var cases: [(String, P.EngineUse)] = []
        var other = use("a2"); other.enabled = nil; cases.append(("enabled", other))
        other = use("a2"); other.provenance = .unknown; cases.append(("provenance", other))
        other = use("a2"); other.observedAt = nil; cases.append(("missing", other))
        other = use("a2"); other.observedAt = at(1); cases.append(("future", other))
        for (id, uncertain) in cases {
            XCTAssertEqual(share([use("a1"), uncertain]).status, .unknown, id)
            XCTAssertTrue(share([use("a1"), uncertain]).others.isEmpty, id)
            let conflict = share([use("a1"), use("a3"), uncertain], roster: .incomplete)
            XCTAssertEqual(conflict.status, .shared, id)
            XCTAssertEqual(conflict.others.map(\.accountID), ["a3"], id)
        }
        XCTAssertEqual(share([use("a1"), use("alias")], aliases: ["alias": "loop", "loop": "alias"]).status, .unknown)
    }

    private func row(_ account: String = "a1", engine: String = "e1", slot: String = "2026-09-26",
                     amount: Double? = -0.3, observedAt: Date? = nil) -> P.PerformanceRow {
        P.PerformanceRow(accountID: account, engineID: engine, dateSlot: slot, observedAt: observedAt ?? now,
            metrics: P.Metrics(realized: P.Money(amount, currency: "USD"), entries: 0.01, settled: 0.01,
                exits: 0, won: 0, lost: 0.01, voided: 0))
    }
    private func performance(_ rows: [P.PerformanceRow]) -> P.Performance {
        P.performance(accountID: "a1", engineID: "e1", dateSlots: slots, dateBasis: "UTC calendar date as supplied", rows: rows, now: now)
    }

    func testPerformanceIsAccountAndEngineScopedAndRetainsDateSlots() {
        let result = performance([row("a2", amount: 999), row(engine: "e2", amount: 999),
            row(slot: "2026-09-12", amount: 999), row(slot: "2026-09-27", amount: 999),
            row(amount: 999, observedAt: at(1)), row(amount: -0.5, observedAt: at(-1)), row()])
        XCTAssertEqual(result.days.map(\.dateSlot), slots)
        XCTAssertEqual(result.observedDayCount, 1)
        XCTAssertEqual(result.coverage, "reported days only")
        XCTAssertEqual(result.dateBasis, "UTC calendar date as supplied")
        XCTAssertEqual(result.realizedText, "-0.3 USD")
        XCTAssertNil(result.days[0].metrics.realized)
        XCTAssertFalse(result.days[0].isObserved)
        XCTAssertEqual(result.days[13].metrics.entries.value, 0.01)
        XCTAssertEqual(result.days[13].metrics.settled.value, 0.01)
        XCTAssertEqual(result.days[13].metrics.exits.value, 0)
        XCTAssertEqual(result.days[13].metrics.voided.value, 0)
        XCTAssertEqual(result.days[13].observedAt, now)
        let other = P.performance(accountID: "a2", engineID: "e1", dateSlots: slots, dateBasis: "UTC", rows: [row()], now: now)
        let engine = P.EngineCard(id: "e1", name: "Engine 1", assignment: "unknown", sharing: share([]), performance: other)
        let person = P.Person(id: "p1", laneID: "l1", accountID: "a1", label: "Person 1", lane: live(), engines: [engine])
        XCTAssertTrue(person.scopedEngines.isEmpty)
    }

    func testPerformanceZeroMissingCoverageAndCurrencyStayDistinct() {
        XCTAssertEqual(performance([]).realizedText, "no data")
        XCTAssertEqual(performance([row(amount: 0)]).realizedText, "0 USD")
        XCTAssertEqual(performance([row(amount: nil)]).realizedText, "no data")
        XCTAssertEqual(performance([row(amount: .nan)]).realizedText, "no data")
        var invalid = row(); invalid.observedAt = nil
        XCTAssertEqual(performance([invalid]).observedDayCount, 0)
        invalid.observedAt = Date(timeIntervalSinceReferenceDate: .nan)
        XCTAssertEqual(performance([invalid]).observedDayCount, 0)
        XCTAssertEqual(performance([row(observedAt: at(1))]).observedDayCount, 0)
        let full = performance(slots.map { row(slot: $0, amount: 1) })
        XCTAssertEqual(full.observedDayCount, 14)
        XCTAssertEqual(full.coverage, "all 14 days reported")
        XCTAssertEqual(full.realizedText, "14 USD")
        var foreignCurrency = row(slot: slots[0]); foreignCurrency.metrics.realized = P.Money(2, currency: "EUR")
        XCTAssertEqual(performance([row(), foreignCurrency]).realizedText, "no data")
        XCTAssertEqual(performance([row(), row(slot: slots[0], amount: nil)]).realizedText, "no data")
    }

    func testProjectionIsSuppliedIllustrativeRangeWithBasis() {
        let projection = P.Projection(low: P.Money(-0.5, currency: "USD"), high: P.Money(0.75, currency: "USD"), basis: "scenario")
        XCTAssertEqual(projection.text, "Illustrative daily projection: -0.5 USD to 0.75 USD. Basis: scenario")
        for (id, low, high, basis) in [("missing", P.Money(currency: "USD"), P.Money(1, currency: "USD"), "scenario"),
            ("inverse", P.Money(2, currency: "USD"), P.Money(1, currency: "USD"), "scenario"),
            ("units", P.Money(0, currency: "USD"), P.Money(1, currency: "EUR"), "scenario"),
            ("basis", P.Money(0, currency: "USD"), P.Money(1, currency: "USD"), " ")] {
            XCTAssertEqual(P.Projection(low: low, high: high, basis: basis).text, "not estimable", id)
        }
    }

    #if DEBUG
    func testFixturesAreDeterministicAndAccountIsolated() {
        let people = P.fixtures()
        XCTAssertEqual(people.map(\.id), ["p1", "p2", "p3"])
        XCTAssertEqual(people.map { $0.lane.verdict(at: P.fixtureTime) }, [.trading, .blocked, .off])
        XCTAssertEqual(P.fixtures().map { $0.lane.verdict(at: P.fixtureTime) }, [.trading, .blocked, .off])
        XCTAssertEqual(people[0].funds.reportedStake?.amount.value, 0.01)
        XCTAssertEqual(people[0].scopedEngines[0].performance.realizedText, "0.25 USD")
        XCTAssertEqual(people[1].scopedEngines[0].performance.realizedText, "no data")
        XCTAssertNil(people[1].scopedEngines[0].projection)
        XCTAssertNil(people[2].lane.refusal.currentReason(at: P.fixtureTime))
        XCTAssertEqual(people[2].lane.killRequested, true)
    }
    #endif
}
