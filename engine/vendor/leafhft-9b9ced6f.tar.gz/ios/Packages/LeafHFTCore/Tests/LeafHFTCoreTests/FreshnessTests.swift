import Foundation
import XCTest
@testable import LeafHFTCore

final class FreshnessTests: XCTestCase {
    func testAgeAndTransportBoundary() {
        let now = Date(timeIntervalSince1970: 10000)
        for (age, expected) in [(42.0, "Observed 42 s ago"), (180, "Observed 3 min ago"), (7200, "Observed 2 h ago"), (-1, "Observed 0 s ago")] {
            XCTAssertEqual(ageDescription(observedAt: now.addingTimeInterval(-age), now: now), expected)
        }
        XCTAssertFalse(transportStale(observedAt: now.addingTimeInterval(-120), now: now))
        XCTAssertTrue(transportStale(observedAt: now.addingTimeInterval(-121), now: now))
    }
    func testQuoteFreshnessIsSeparate() {
        XCTAssertFalse(quoteStale(quoteAgeMs: 500, limitMs: 500))
        XCTAssertTrue(quoteStale(quoteAgeMs: 501, limitMs: 500))
        XCTAssertTrue(quoteStale(quoteAgeMs: .nan, limitMs: 500))
    }
}
