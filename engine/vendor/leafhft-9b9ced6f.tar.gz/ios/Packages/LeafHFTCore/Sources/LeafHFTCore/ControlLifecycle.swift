import Foundation

public struct EnrolledKeyRecord: Codable, Equatable, Sendable {
    public let scope: String
    public let tenantId: String
    public let laneId: String

    public init(scope: String, tenantId: String, laneId: String) {
        self.scope = scope
        self.tenantId = tenantId
        self.laneId = laneId
    }
}

public enum EnrolledKeyPolicy {
    /// Whether this lane is trading with a key other than the one on this phone.
    public static func keyChanged(record: EnrolledKeyRecord?, currentScope: String?,
                                  tenantId: String?, laneId: String?, state: AutomatedTradingState) -> Bool {
        guard let record, let currentScope, let tenantId, let laneId,
              record.tenantId == tenantId, record.laneId == laneId,
              state == .dryRun || state == .live || state == .livePending else { return false }
        return record.scope != currentScope
    }

    /// Whether the stored record no longer describes an enrolled lane.
    public static func recordIsObsolete(record: EnrolledKeyRecord, tenantId: String?,
                                        laneId: String?, state: AutomatedTradingState) -> Bool {
        record.tenantId != tenantId || record.laneId != laneId ||
            state == .notConfigured || state == .credentialRequired || state == .revoked
    }
}

public enum ControlRefusalMessage {
    public static func text(for reason: String) -> String {
        let cleaned = reason.split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
        guard !cleaned.isEmpty else {
            return "The account request was declined. Refresh its status before trying again."
        }
        let bounded = cleaned.count > 160 ? String(cleaned.prefix(157)) + "..." : cleaned
        return "The runner declined this change: " + bounded
    }
}

/// Treats every nonempty control state other than requested as terminal.
public enum ControlRequestLifecycle {
    public static func isTerminal(state: String?) -> Bool {
        guard let state, !state.isEmpty else { return false }
        return state.lowercased() != "requested"
    }
}

/// Expires auto-live intent after ten minutes or a clock rollback over one minute.
public enum AutoLiveIntentPolicy {
    public static let timeToLive: TimeInterval = 600

    public static func isExpired(requestedAt: Date, now: Date) -> Bool {
        let age = now.timeIntervalSince(requestedAt)
        return age > timeToLive || age < -60
    }
}

/// Expires unresolved controls after thirty minutes or a clock rollback over one minute.
public enum UnresolvedControlPolicy {
    public static let timeToLive: TimeInterval = 1800

    public static func isExpired(since: Date, now: Date) -> Bool {
        let age = now.timeIntervalSince(since)
        return age > timeToLive || age < -60
    }
}
