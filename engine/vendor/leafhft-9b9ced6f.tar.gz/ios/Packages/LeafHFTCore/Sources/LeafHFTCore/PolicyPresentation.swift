import Foundation

public enum PolicyValueFormatter {
    private static func number(_ value: Double, decimals: Int = 1, fixed: Bool = false, grouped: Bool = false) -> String {
        guard value.isFinite else { return "Unknown" }
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.numberStyle = .decimal
        formatter.usesGroupingSeparator = grouped
        formatter.minimumFractionDigits = fixed ? decimals : 0
        formatter.maximumFractionDigits = decimals
        return formatter.string(from: NSNumber(value: value)) ?? "Unknown"
    }

    private static func seconds(_ value: Double) -> String {
        if value < 60 { return "\(number(value)) \(value == 1 ? "second" : "seconds")" }
        let minutes = floor(value / 60)
        let remainder = value.truncatingRemainder(dividingBy: 60)
        let first = "\(number(minutes, decimals: 0)) \(minutes == 1 ? "minute" : "minutes")"
        return remainder == 0 ? first : first + " " + seconds(remainder)
    }

    public static func display(_ value: Double, unit: PolicyUnit) -> String {
        guard value.isFinite else { return "Unknown" }
        switch unit {
        case .fraction, .probability: return number(value * 100) + "%"
        case .cents: return number(value) + "¢"
        case .centsAsDollars: return "$" + number(value / 100, decimals: 2, fixed: true, grouped: true)
        case .dollars: return "$" + number(value, decimals: 2, fixed: true, grouped: true)
        case .seconds: return seconds(value)
        case .milliseconds:
            if value < 1000 { return number(value) + " ms" }
            if value.truncatingRemainder(dividingBy: 1000) == 0 { return seconds(value / 1000) }
            return number(value / 1000) + " seconds"
        case .contracts: return "\(number(value, decimals: 0)) \(value == 1 ? "contract" : "contracts")"
        case .count: return number(value, decimals: 0)
        case .multiplier: return number(value) + "×"
        }
    }

    public static func display(_ value: Double, parameter: PolicyParameter) -> String {
        if value == 0 && parameter.zeroMeaning != nil { return "Off" }
        return display(value, unit: parameter.unit)
    }

    public static func displayValue(fromAPI value: Double, unit: PolicyUnit) -> Double {
        switch unit {
        case .fraction, .probability: return value * 100
        case .centsAsDollars: return value / 100
        default: return value
        }
    }

    public static func apiValue(fromDisplay value: Double, unit: PolicyUnit) -> Double {
        switch unit {
        case .fraction, .probability: return value / 100
        case .centsAsDollars: return value * 100
        default: return value
        }
    }

    public static func parse(_ text: String, parameter: PolicyParameter) -> Double? {
        guard text.count <= 128 else { return nil }
        var text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if [.dollars, .centsAsDollars].contains(parameter.unit), text.hasPrefix("$") { text.removeFirst() }
        let suffix: String?
        switch parameter.unit {
        case .fraction, .probability: suffix = "%"
        case .cents: suffix = "¢"
        case .multiplier: suffix = "×"
        default: suffix = nil
        }
        if let suffix, text.hasSuffix(suffix) { text.removeLast() }
        text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        // Grouping is optional, but malformed groups must not silently change an amount.
        let pattern = #"^[+-]?(?:(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]*)?|\.[0-9]+)$"#
        guard text.range(of: pattern, options: .regularExpression) != nil,
              let value = Double(text.replacingOccurrences(of: ",", with: "")), value.isFinite else { return nil }
        let api = apiValue(fromDisplay: value, unit: parameter.unit)
        guard api.isFinite else { return nil }
        // Cent conversion can otherwise make a valid whole-cent amount fail integer validation.
        if parameter.unit == .centsAsDollars, abs(api - api.rounded()) < 1e-9 { return api.rounded() }
        return api
    }

    public static func normalized(_ value: Double, parameter: PolicyParameter) -> Double {
        guard value.isFinite, parameter.step > 0 else { return value }
        let stepped = (value / parameter.step).rounded() * parameter.step
        if parameter.isInteger { return stepped.rounded() }
        guard abs(stepped) < 1e12 else { return stepped }
        return (stepped * 1e9).rounded() / 1e9
    }
}

public enum PolicyGuidance {
    public enum Label: String { case aggressive = "Aggressive", restrictive = "Restrictive" }

    public static func label(for parameter: PolicyParameter, value: Double) -> Label? {
        guard value.isFinite, let thresholds = parameter.guidance else { return nil }
        if thresholds.aggressiveAbove.map({ value > $0 }) == true ||
            thresholds.aggressiveBelow.map({ value < $0 }) == true { return .aggressive }
        if thresholds.restrictiveAbove.map({ value > $0 }) == true ||
            thresholds.restrictiveBelow.map({ value < $0 }) == true { return .restrictive }
        return nil
    }
}

public struct PolicyConflict: Equatable, Identifiable, Sendable {
    public enum Severity: String, Sendable { case error, warning }
    public let id: String
    public let keys: [String]
    public let severity: Severity
    public let message: String
}

public enum PolicyConflicts {
    public static func check(_ policy: [String: Double]) -> [PolicyConflict] {
        var result: [PolicyConflict] = []
        func check(_ id: String, _ first: String, _ second: String, _ severity: PolicyConflict.Severity,
                   _ message: String, _ fails: (Double, Double) -> Bool) {
            guard let a = policy[first], let b = policy[second], fails(a, b) else { return }
            result.append(PolicyConflict(id: id, keys: [first, second], severity: severity, message: message))
        }
        check("drawdown-order", "drawdown_stop_fraction", "drawdown_brake_fraction", .error,
              "Drawdown stop must be above Drawdown slowdown, or the runner will reject the change.") { $0 <= $1 }
        check("favorite-edge-order", "favorite_edge_threshold_cents", "edge_threshold_cents", .error,
              "Favorite minimum edge must not exceed Minimum edge, or the runner will reject the change.") { $0 > $1 }
        check("price-order", "min_price_cents", "max_price_cents", .warning,
              "Minimum entry price is above Maximum entry price, so no contract can qualify.") { $1 > 0 && $0 > $1 }
        check("conviction-order", "conviction_min", "conviction_max", .warning,
              "Conviction floor is above Conviction ceiling, so sizing will always use the ceiling.") { $0 > $1 }
        check("win-order", "min_win_cents", "target_win_cents", .warning,
              "Minimum win is above Target win, so every entry sized to the target is skipped.") { $1 > 0 && $0 > $1 }
        check("favorite-price-order", "favorite_price_cents", "min_price_cents", .warning,
              "Favorite price is below Minimum entry price, so favorites can never be bought.") { $0 > 0 && $1 > $0 }
        return result
    }
}
