import Foundation

/// The backend envelope is authoritative per key when its maximum is finite and nonnegative.
/// Missing or invalid keys fall back to the guarded maximum; unknown keys are ignored.
public struct RiskEnvelope: Codable, Equatable, Sendable {
    public static let hardMaxima: [String: Double] = [
        "per_order_fraction": 0.10, "cluster_fraction": 0.25,
        "daily_loss_fraction": 0.15, "drawdown_brake_fraction": 0.15,
        "drawdown_stop_fraction": 0.25
    ]
    public let maxima: [String: Double]
    /// Valid maxima supplied by the runner, excluding guarded fallback values.
    public let reportedKeys: Set<String>
    public let digest: String?

    public init(maxima: [String: Double] = [:], digest: String? = nil) {
        reportedKeys = Set(maxima.filter { key, value in
            Self.hardMaxima[key] != nil && value.isFinite && value >= 0
        }.keys)
        self.maxima = Self.hardMaxima.mapValues { $0 }
            .merging(maxima.filter { key, value in
                Self.hardMaxima[key] != nil && value.isFinite && value >= 0
            }) { _, backend in backend }
        self.digest = digest
    }

    private struct Key: CodingKey {
        let stringValue: String
        var intValue: Int? { nil }
        init(_ value: String) { stringValue = value }
        init?(stringValue: String) { self.init(stringValue) }
        init?(intValue: Int) { return nil }
    }

    public init(from decoder: Decoder) throws {
        guard let container = try? decoder.container(keyedBy: Key.self) else {
            self.init()
            return
        }
        var limits: [String: Double] = [:]
        for key in Self.hardMaxima.keys {
            let parts = key.split(separator: "_")
            let camel = String(parts[0]) + parts.dropFirst().map { $0.capitalized }.joined()
            limits[key] = (try? container.decode(Double.self, forKey: Key(key)))
                ?? (try? container.decode(Double.self, forKey: Key(camel)))
        }
        self.init(maxima: limits, digest: try? container.decode(String.self, forKey: Key("digest")))
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: Key.self)
        for (key, value) in maxima { try container.encode(value, forKey: Key(key)) }
        try container.encodeIfPresent(digest, forKey: Key("digest"))
    }
}

public enum PolicyBounds {
    public static let bounds: [String: (min: Double, max: Double, isInt: Bool)] =
        Dictionary(uniqueKeysWithValues: PolicyCatalog.parameters.map {
            ($0.key, (min: $0.minimum, max: $0.maximum, isInt: $0.isInteger))
        })

    public static func validate(key: String, value: Double, envelope: RiskEnvelope? = nil) -> String? {
        guard let bound = bounds[key] else { return "Unknown policy key: \(key)." }
        guard value.isFinite else { return "Enter a finite number." }
        let maximum = min(bound.max, (envelope ?? RiskEnvelope()).maxima[key] ?? bound.max)
        guard value >= bound.min && value <= maximum else {
            return "\(key) must be between \(bound.min) and \(maximum)."
        }
        if bound.isInt && value.rounded() != value { return "\(key) requires a whole number." }
        return nil
    }

    /// Friendly validation for operator-facing controls.
    public static func validateFriendly(key: String, value: Double, envelope: RiskEnvelope? = nil) -> String? {
        guard let parameter = PolicyCatalog.parameter(for: key) else { return "This setting cannot be changed here." }
        guard value.isFinite else { return "Enter a finite number." }
        let maximum = maximum(for: parameter, envelope: envelope)
        guard value >= parameter.minimum && value <= maximum else {
            let lower = PolicyValueFormatter.display(parameter.minimum, unit: parameter.unit)
            let upper = PolicyValueFormatter.display(maximum, unit: parameter.unit)
            return "\(parameter.name): enter a value between \(lower) and \(upper)."
        }
        if parameter.isInteger && value.rounded() != value { return "\(parameter.name) needs a whole number." }
        return nil
    }

    public static func maximum(for parameter: PolicyParameter, envelope: RiskEnvelope? = nil) -> Double {
        min(parameter.maximum, (envelope ?? RiskEnvelope()).maxima[parameter.key] ?? parameter.maximum)
    }
}
