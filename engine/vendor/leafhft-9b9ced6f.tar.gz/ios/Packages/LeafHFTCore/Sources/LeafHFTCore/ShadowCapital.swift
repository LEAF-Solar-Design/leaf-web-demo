import Foundation

/// Account paper sizing, independent of the live account balance and engine policy.
public enum ShadowCapital {
    public typealias View = ShadowCapitalView
    public typealias Request = ShadowCapitalRequest
    public typealias State = ShadowCapitalState
    public static let minCents = 10_000
    public static let maxCents = 200_000
    public static let defaultCents = 40_000
    public static let presetDollars = [100, 200, 400, 800, 1_600, 2_000]

    public static func deriveState(_ view: View?, now: Date) -> State {
        deriveShadowCapitalState(view, now: now)
    }
}

/// Decode with the status decoder's convertFromSnakeCase and ISO-8601 strategies.
public struct ShadowCapitalView: Decodable, Equatable, Sendable {
    public let appliedCents: Int?
    public let source: String?
    public let requestId: String?
    public let appliedAt: Date?
    public let observedAt: Date?
    public let receivedAt: Date?
    public let consumer: Consumer?
    public let pending: Pending?
    public let lastFailure: Failure?
    public let cooldownUntil: Date?
    public let suspended: Bool?
    public let runnerError: RunnerError?
    public let writesOpen: Bool?
    public let minCents: Int?
    public let maxCents: Int?
    public let stepCents: Int?
    public let defaultCents: Int?
    public let editable: Bool?
    public let runs: [Run]?

    public struct Consumer: Decodable, Equatable, Sendable {
        public let state: String
        public let inUseCents: Int?
    }

    public struct Pending: Decodable, Equatable, Sendable {
        public let requestId: String
        public let capitalCents: Int
        public let requestedAt: Date
    }

    public struct Failure: Decodable, Equatable, Sendable {
        public let capitalCents: Int
        public let note: String?
        public let at: Date
    }

    /// Servers may report an error flag or an explanatory string.
    public enum RunnerError: Decodable, Equatable, Sendable {
        case flag(Bool), message(String)

        public init(from decoder: Decoder) throws {
            let value = try decoder.singleValueContainer()
            if let flag = try? value.decode(Bool.self) { self = .flag(flag) }
            else { self = .message(try value.decode(String.self)) }
        }

        public var isPresent: Bool {
            switch self {
            case .flag(let flag): return flag
            case .message(let message): return !message.isEmpty
            }
        }
    }

    public struct Run: Decodable, Equatable, Sendable {
        public let engineId: String
        public let mirror: Bool
        public let state: String
        public let startedAt: Date?
        public let paperPnlCents: Double
        public let capitalBasisCents: Double
        public let returnBps: Double?

        public var returnPercent: Double? {
            guard !mirror, capitalBasisCents.isFinite, capitalBasisCents > 0,
                  paperPnlCents.isFinite else { return nil }
            let percent = paperPnlCents / capitalBasisCents * 100
            return percent.isFinite ? percent : nil
        }
    }

    public func canEdit(now: Date) -> Bool {
        guard editable == true, writesOpen == true, suspended != true,
              runnerError?.isPresent != true else { return false }
        if let until = cooldownUntil, until > now { return false }
        let state = deriveShadowCapitalState(self, now: now)
        return ![.notReported, .stale, .pending, .slow, .cooldown].contains(state)
    }
}

/// Request identifiers can come from either UUIDs or database integer keys.
private struct ShadowCapitalRequestID: Decodable {
    let value: String

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let string = try? container.decode(String.self) { value = string }
        else { value = String(try container.decode(Int64.self)) }
    }
}

extension ShadowCapitalView {
    private enum CodingKeys: String, CodingKey {
        case appliedCents, source, requestId, appliedAt, observedAt, receivedAt
        case consumer, pending, lastFailure, cooldownUntil, suspended, runnerError
        case writesOpen, minCents, maxCents, stepCents, defaultCents, editable, runs
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        appliedCents = try container.decodeIfPresent(Int.self, forKey: .appliedCents)
        source = try container.decodeIfPresent(String.self, forKey: .source)
        requestId = try container.decodeIfPresent(ShadowCapitalRequestID.self, forKey: .requestId)?.value
        appliedAt = try container.decodeIfPresent(Date.self, forKey: .appliedAt)
        observedAt = try container.decodeIfPresent(Date.self, forKey: .observedAt)
        receivedAt = try container.decodeIfPresent(Date.self, forKey: .receivedAt)
        consumer = try container.decodeIfPresent(Consumer.self, forKey: .consumer)
        pending = try container.decodeIfPresent(Pending.self, forKey: .pending)
        lastFailure = try container.decodeIfPresent(Failure.self, forKey: .lastFailure)
        cooldownUntil = try container.decodeIfPresent(Date.self, forKey: .cooldownUntil)
        suspended = try container.decodeIfPresent(Bool.self, forKey: .suspended)
        runnerError = try container.decodeIfPresent(RunnerError.self, forKey: .runnerError)
        writesOpen = try container.decodeIfPresent(Bool.self, forKey: .writesOpen)
        minCents = try container.decodeIfPresent(Int.self, forKey: .minCents)
        maxCents = try container.decodeIfPresent(Int.self, forKey: .maxCents)
        stepCents = try container.decodeIfPresent(Int.self, forKey: .stepCents)
        defaultCents = try container.decodeIfPresent(Int.self, forKey: .defaultCents)
        editable = try container.decodeIfPresent(Bool.self, forKey: .editable)
        runs = try container.decodeIfPresent([Run].self, forKey: .runs)
    }
}

extension ShadowCapitalView.Pending {
    private enum CodingKeys: String, CodingKey { case requestId, capitalCents, requestedAt }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        requestId = try container.decode(ShadowCapitalRequestID.self, forKey: .requestId).value
        capitalCents = try container.decode(Int.self, forKey: .capitalCents)
        requestedAt = try container.decode(Date.self, forKey: .requestedAt)
    }
}

public struct ShadowCapitalRequest: Encodable, Sendable {
    public let kind = "account.shadow_capital"
    public let clientRequestId: String
    public let value: Value

    public struct Value: Encodable, Sendable {
        public let capitalCents: Int
        public let consent = "paper"
        private enum CodingKeys: String, CodingKey { case capitalCents = "capital_cents", consent }
    }

    private enum CodingKeys: String, CodingKey { case kind, clientRequestId = "client_request_id", value }

    public init(capitalCents: Int, clientRequestId: UUID = UUID(), status: ShadowCapitalView? = nil) throws {
        let minimum = status?.minCents ?? ShadowCapital.minCents
        let maximum = status?.maxCents ?? ShadowCapital.maxCents
        let step = status?.stepCents ?? 100
        guard minimum >= 0, maximum >= minimum, step > 0,
              capitalCents >= minimum, capitalCents <= maximum,
              capitalCents % 100 == 0, (capitalCents - minimum) % step == 0 else {
            throw ControlIntent.ValidationError.invalid("Choose whole-dollar paper capital within the published limits.")
        }
        self.clientRequestId = clientRequestId.uuidString.lowercased()
        value = Value(capitalCents: capitalCents)
    }

    public init(dollars: Double, clientRequestId: UUID = UUID(), status: ShadowCapitalView? = nil) throws {
        guard dollars.isFinite, dollars.rounded(.towardZero) == dollars,
              let cents = Int(exactly: dollars * 100) else {
            throw ControlIntent.ValidationError.invalid("Enter a whole-dollar paper capital amount.")
        }
        try self.init(capitalCents: cents, clientRequestId: clientRequestId, status: status)
    }
}

public enum ShadowCapitalState: String, Codable, CaseIterable, Sendable {
    case notReported = "not_reported"
    case applied
    case savedNotInUse = "saved_not_in_use"
    case pending, slow, failed, cooldown
    case runnerError = "runner_error"
    case suspended, stale
}

/// Precedence is part of the shared fixture contract. The caller supplies the clock.
public func deriveShadowCapitalState(_ view: ShadowCapitalView?, now: Date) -> ShadowCapitalState {
    guard let view else { return .notReported }
    if view.suspended == true { return .suspended }
    if view.runnerError?.isPresent == true { return .runnerError }
    if let observed = view.observedAt, now.timeIntervalSince(observed) > 600 { return .stale }
    if let pending = view.pending {
        return now.timeIntervalSince(pending.requestedAt) > 180 ? .slow : .pending
    }
    if view.lastFailure != nil { return .failed }
    if let until = view.cooldownUntil, until > now { return .cooldown }
    guard view.observedAt != nil, view.appliedCents != nil else { return .notReported }
    return view.consumer?.state == "confirmed" ? .applied : .savedNotInUse
}
