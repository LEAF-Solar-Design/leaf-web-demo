import Foundation

public func canonicalSigningMessage(timestampMs: Int64, path: String) -> Data {
    let pathOnly = path.split(separator: "?", maxSplits: 1, omittingEmptySubsequences: false)[0]
    return Data("\(timestampMs)GET\(pathOnly)".utf8)
}
