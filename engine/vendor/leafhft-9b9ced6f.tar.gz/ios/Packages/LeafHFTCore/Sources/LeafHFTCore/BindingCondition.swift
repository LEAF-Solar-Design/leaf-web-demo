import Foundation

public enum BindingCondition: Equatable {
    case waiting(secondsUntilWindow: Double)
    case observing(k: Int, minK: Int)
    case evaluating(edgeShortfallCents: Double)
    case blocked(reason: String)
    case intentEmitted
    case unknown(missing: String)

    public static func from(candidate: Candidate, windowS: Double?, minK: Int?) -> BindingCondition {
        if candidate.intentSent == true { return .intentEmitted }
        guard let gate = candidate.gate, !gate.isEmpty else { return .unknown(missing: "gate") }
        switch gate {
        case "passed": return .intentEmitted
        case "skip_outside_window":
            guard let seconds = candidate.secondsToClose, seconds.isFinite else { return .unknown(missing: "secondsToClose") }
            guard let window = windowS, window.isFinite else { return .unknown(missing: "windowS") }
            guard seconds > window else { return .unknown(missing: "secondsToClose > windowS") }
            return .waiting(secondsUntilWindow: seconds - window)
        case "skip_k_floor":
            guard let k = candidate.k else { return .unknown(missing: "k") }
            guard let floor = minK else { return .unknown(missing: "minK") }
            return .observing(k: k, minK: floor)
        case "skip_edge_below_bar", "skip_band_edge":
            guard let edge = candidate.edgeCents, edge.isFinite else { return .unknown(missing: "edgeCents") }
            guard let required = candidate.edgeRequiredCents, required.isFinite else { return .unknown(missing: "edgeRequiredCents") }
            return .evaluating(edgeShortfallCents: required - edge)
        default:
            let reasons = [
                "skip_price_ceiling": "Price above ceiling",
                "skip_price_floor": "Price below floor",
                "skipped_thin_quote": "Quote too thin",
                "skip_market_full": "Market at its cap",
                "skip_reentry_after_exit": "Blocked after exit",
                "skip_stale_quote": "Quote too old",
                "skip_depth": "Insufficient depth",
                "skip_cash_floor": "Cash below entry floor",
                "skip_refire": "Waiting before another entry"
            ]
            let fallback = gate.replacingOccurrences(of: "skipped_", with: "")
                .replacingOccurrences(of: "skip_", with: "").replacingOccurrences(of: "_", with: " ")
            return .blocked(reason: reasons[gate] ?? fallback.capitalized)
        }
    }
}
public enum ExitCondition: Equatable {
    case surplus(cents: Double)
    case unknown
    public static func from(ticket: Ticket) -> ExitCondition {
        if let surplus = ticket.surplus, surplus.isFinite { return .surplus(cents: surplus) }
        guard let net = ticket.netValue, let hold = ticket.holdValue, let margin = ticket.margin,
              net.isFinite, hold.isFinite, margin.isFinite else { return .unknown }
        let value = net - hold - margin
        return value.isFinite ? .surplus(cents: value) : .unknown
    }
}
