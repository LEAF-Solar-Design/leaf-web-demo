import Foundation

public struct EnginesResponse: Codable {
    public var engines: [Engine]?
    public var riskEnvelope: RiskEnvelope?
    public var bindings: EngineBindings?
    public var generatedAt: String?
    public var accounts: [EngineControlAccount]?
}

public struct EngineControlAccount: Codable, Identifiable, Hashable {
    public let id: String
    public let label: String
    public let host: String
    public let subaccountNumber: Int?
    public let configurable: Bool

    public init(id: String, label: String, host: String, subaccountNumber: Int?, configurable: Bool) {
        self.id = id
        self.label = label
        self.host = host
        self.subaccountNumber = subaccountNumber
        self.configurable = configurable
    }
}

public struct Engine: Codable, Identifiable {
    public var engineId: String
    public var id: String { engineId }
    public var host: String?
    public var name: String?
    public var description: String?
    public var version: Int?
    public var parentEngineId: String?
    public var policyDigest: String?
    public var capabilities: EngineCapabilities?
    public var policy: [String: Double]?
    public var boundBooks: [String]?
    public var pnl: EnginePnl?
    public var configuration: EngineConfiguration?
    public var riskEnvelope: RiskEnvelope?
    public var darkhorse: DarkhorseConfiguration?
    public var shadowOnly: Bool?
    public var reason: String?
    // Probe paradigm (D8). All optional: an older server sends none of them.
    public var lifecycle: EngineLifecycle?
    public var assignment: EngineAssignment?
    public var markets: [String]?
    public var inputs: [EngineInput]?
    public var probeToday: ProbeDay?
    public var live: EngineLiveStats?
    public var eligibleToProbe: ProbeEligibility?

    enum CodingKeys: String, CodingKey {
        case engineId, host, name, description, version, parentEngineId, policyDigest, capabilities, policy
        case boundBooks, pnl, configuration, riskEnvelope, darkhorse, shadowOnly, reason
        case lifecycle, assignment, markets, inputs, probeToday, live, eligibleToProbe
    }

    public var controlDisabledReason: String? {
        if shadowOnly == true { return reason ?? "Shadow-only engine. Trading controls are disabled." }
        if engineId == "darkhorse", darkhorse?.available != true {
            return darkhorse?.error ?? "Darkhorse host models are unavailable."
        }
        return nil
    }
}

extension Engine {
    /// Legacy fields keep the synthesized strictness. Each runtime field fails soft: a wrong type, a missing
    /// required sub-field or a misplaced null is nil for that field only, never a failed engine or list.
    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        engineId = try values.decode(String.self, forKey: .engineId)
        host = try values.decodeIfPresent(String.self, forKey: .host)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        description = try values.decodeIfPresent(String.self, forKey: .description)
        version = try values.decodeIfPresent(Int.self, forKey: .version)
        parentEngineId = try values.decodeIfPresent(String.self, forKey: .parentEngineId)
        policyDigest = try values.decodeIfPresent(String.self, forKey: .policyDigest)
        capabilities = try values.decodeIfPresent(EngineCapabilities.self, forKey: .capabilities)
        policy = try values.decodeIfPresent([String: Double].self, forKey: .policy)
        boundBooks = try values.decodeIfPresent([String].self, forKey: .boundBooks)
        pnl = try values.decodeIfPresent(EnginePnl.self, forKey: .pnl)
        configuration = try values.decodeIfPresent(EngineConfiguration.self, forKey: .configuration)
        riskEnvelope = try values.decodeIfPresent(RiskEnvelope.self, forKey: .riskEnvelope)
        darkhorse = try values.decodeIfPresent(DarkhorseConfiguration.self, forKey: .darkhorse)
        shadowOnly = try values.decodeIfPresent(Bool.self, forKey: .shadowOnly)
        reason = try values.decodeIfPresent(String.self, forKey: .reason)
        lifecycle = (try? values.decodeIfPresent(EngineLifecycle.self, forKey: .lifecycle)) ?? nil
        assignment = (try? values.decodeIfPresent(EngineAssignment.self, forKey: .assignment)) ?? nil
        markets = (try? values.decodeIfPresent([String].self, forKey: .markets)) ?? nil
        inputs = (try? values.decodeIfPresent([EngineInput].self, forKey: .inputs)) ?? nil
        probeToday = (try? values.decodeIfPresent(ProbeDay.self, forKey: .probeToday)) ?? nil
        live = (try? values.decodeIfPresent(EngineLiveStats.self, forKey: .live)) ?? nil
        eligibleToProbe = (try? values.decodeIfPresent(ProbeEligibility.self, forKey: .eligibleToProbe)) ?? nil
    }
}

public struct DarkhorseConfiguration: Codable, Equatable, Sendable {
    public struct Model: Codable, Equatable, Sendable {
        public let offset: Double
        public let sha: String
        public let trainedThreshold: Double
        public let scoreP99: Double
        public let scoreThreshold: Double
        public var key: String { offset == 120 ? "score_threshold_120" : offset == 45 ? "score_threshold_45" : "unsupported_model" }
    }
    public let available: Bool
    public let error: String?
    public let models: [Model]
    public let pending: Bool
    public let stale: Bool
}

/// Darkhorse controls are account-only and cannot change host-owned model artifacts.
public enum DarkhorsePolicy {
    public static let keys = ["base_count", "max_mult", "score_threshold_120", "score_threshold_45"]
    public static func validate(key: String, value: Double) -> String? {
        guard keys.contains(key) else { return "Unknown Darkhorse setting: \(key)." }
        guard value.isFinite else { return "Enter a finite number." }
        let range: ClosedRange<Double> = key == "base_count" ? 0.01...0.50 : key == "max_mult" ? 1...10 : 0...1
        guard range.contains(value) else { return "\(key) must be between \(range.lowerBound) and \(range.upperBound)." }
        if key == "base_count" || key == "max_mult", abs(value * 100 - (value * 100).rounded()) > 0.0000001 {
            return "Use at most two decimal places."
        }
        return nil
    }
    public static func validateThreshold(key: String, value: Double, models: [DarkhorseConfiguration.Model]) -> String? {
        guard key.hasPrefix("score_threshold_") else { return nil }
        guard let model = models.first(where: { $0.key == key }),
              model.trainedThreshold.isFinite, model.scoreP99.isFinite,
              model.trainedThreshold >= 0, model.trainedThreshold < model.scoreP99, model.scoreP99 <= 1 else {
            return "Model threshold bounds are not reported."
        }
        guard value >= model.trainedThreshold, value < model.scoreP99 else {
            return "Threshold must be at least \(model.trainedThreshold) and below \(model.scoreP99)."
        }
        return nil
    }
    public static func parameters(models: [DarkhorseConfiguration.Model]) -> [PolicyParameter] {
        keys.map { key in
            let model = models.first { $0.key == key }
            let sizing = key == "base_count" || key == "max_mult"
            return PolicyParameter(key: key,
                name: key == "base_count" ? "Base contract count" : key == "max_mult" ? "Maximum multiplier" : "Score threshold (\(key.hasSuffix("120") ? "120" : "45") seconds)",
                summary: sizing ? "Account sizing within the host's order limits." : "May only raise the trained threshold. Must stay below the model's score p99.",
                category: sizing ? .positionSizing : .entryRequirements,
                unit: key == "base_count" ? .contracts : key == "max_mult" ? .multiplier : .probability,
                minimum: key == "base_count" ? 0.01 : key == "max_mult" ? 1 : model?.trainedThreshold ?? 0,
                maximum: key == "base_count" ? 0.50 : key == "max_mult" ? 10 : model?.scoreP99 ?? 1,
                isInteger: false, step: 0.01, control: .field, impact: sizing ? .sizing : .entries,
                whenHigher: sizing ? "Allows larger positions within the host limits." : "Requires a higher model score before entry.",
                whenLower: sizing ? "Reduces position size." : "Cannot go below the host-trained threshold.",
                zeroMeaning: nil, searchTerms: [key, "darkhorse"], advanced: false, guidance: nil)
        }
    }
}

public struct EngineConfiguration: Codable {
    public let global: EngineGlobalConfiguration
    public let accounts: [EngineAccountConfiguration]

    public init(global: EngineGlobalConfiguration, accounts: [EngineAccountConfiguration]) {
        self.global = global
        self.accounts = accounts
    }
}

public struct EngineGlobalConfiguration: Codable {
    public let enabled: Bool?
    public let policy: [String: Double]?
    public let revision: String?
    public let observedAt: String?
    public let freshness: String?
    public let pending: EnginePendingRequest?

    public init(enabled: Bool?, policy: [String: Double]?, revision: String?, observedAt: String?, freshness: String?, pending: EnginePendingRequest?) {
        self.enabled = enabled
        self.policy = policy
        self.revision = revision
        self.observedAt = observedAt
        self.freshness = freshness
        self.pending = pending
    }
}

public struct EngineAccountConfiguration: Codable, Identifiable {
    public let accountId: String
    public var id: String { accountId }
    public let override: EngineConfigurationOverride
    public let effective: EngineEffectiveConfiguration
    public let revision: String?
    public let observedAt: String?
    public let freshness: String?
    public let pending: EnginePendingRequest?

    public init(accountId: String, override: EngineConfigurationOverride, effective: EngineEffectiveConfiguration, revision: String?, observedAt: String?, freshness: String?, pending: EnginePendingRequest?) {
        self.accountId = accountId
        self.override = override
        self.effective = effective
        self.revision = revision
        self.observedAt = observedAt
        self.freshness = freshness
        self.pending = pending
    }
}

public struct EngineConfigurationOverride: Codable {
    /// Nil means the account inherits the global enabled value.
    public let enabled: Bool?
    /// Sparse account-only policy overrides.
    public let policy: [String: Double]

    public init(enabled: Bool?, policy: [String: Double]) {
        self.enabled = enabled
        self.policy = policy
    }
}

public struct EngineEffectiveConfiguration: Codable {
    public let enabled: Bool?
    public let policy: [String: Double]?

    public init(enabled: Bool?, policy: [String: Double]?) {
        self.enabled = enabled
        self.policy = policy
    }
}

public struct EnginePendingRequest: Codable, Identifiable {
    public let id: String
    public let state: String?
    public let requestedAt: String?

    public init(id: String, state: String?, requestedAt: String?) {
        self.id = id
        self.state = state
        self.requestedAt = requestedAt
    }
}

public struct EngineCapabilities: Codable {
    public var exitRule: Bool?
    public var favorites: Bool?
    public var bandsOpen: [String]?
    public var bigEdgeCap: Bool?
    public var drawdownLaw: DrawdownLaw?
    public var reversal: Bool?
}

public struct DrawdownLaw: Codable { public var brake: Double?; public var stop: Double? }

public struct EnginePnl: Codable {
    public var n: Int?
    public var won: Int?
    public var avgWinGainPct: Double?
    public var winGainN: Int?
    public var avgClosedGainPct: Double?
    public var closedGainN: Int?
    public var netCents: Double?
    public var perTicketCents: Double?
    public var ticketsPerHour: Double?
    public var open: Int?
    public var exitsN: Int?
    public var exitPnlCents: Double?
    public var lastTicketAt: String?
}

public func engineSetKeys(for engine: Engine) -> [String] {
    if engine.engineId == "darkhorse" { return DarkhorsePolicy.keys }
    if let policy = engine.configuration?.global.policy ?? engine.policy {
        return policy.keys.filter { PolicyBounds.bounds[$0] != nil }.sorted()
    }
    return PolicyBounds.bounds.keys.sorted()
}

public func engineServerOnlyKeys(for engine: Engine) -> [String] {
    guard engine.engineId != "darkhorse" else { return [] }
    let policy = engine.configuration?.global.policy ?? engine.policy ?? [:]
    return policy.keys.filter { PolicyBounds.bounds[$0] == nil }.sorted()
}

public struct EngineBindings: Codable { public var `default`: String?; public var symbols: [String: String]? }

extension EnginesResponse {
    public func applyingConfigure(_ value: EngineConfigureValue, scope: ControlScope,
                                  newRevision: String, observedAt: String) -> EnginesResponse {
        guard var engines = engines, let index = engines.firstIndex(where: { $0.engineId == value.engineId }),
              let configuration = engines[index].configuration else { return self }
        if scope.kind == .account && !configuration.accounts.contains(where: { $0.accountId == scope.accountId }) {
            return self
        }
        func enabled(_ current: Bool?) -> Bool? {
            switch value.enabledChange {
            case .unchanged: return current
            case let .value(flag): return flag
            case .inherit: return nil
            }
        }
        var global = configuration.global
        if scope.kind == .global {
            let policy = (global.policy ?? [:]).merging(value.set ?? [:]) { _, new in new }
            global = EngineGlobalConfiguration(enabled: enabled(global.enabled), policy: policy,
                revision: newRevision, observedAt: observedAt, freshness: "fresh", pending: nil)
            engines[index].policy = policy
        }
        let accounts = configuration.accounts.map { account in
            let selected = scope.kind == .account && scope.accountId == account.accountId
            var override = account.override
            if selected {
                var policy = override.policy.merging(value.set ?? [:]) { _, new in new }
                for key in value.unset ?? [] { policy.removeValue(forKey: key) }
                override = EngineConfigurationOverride(enabled: enabled(override.enabled), policy: policy)
            }
            let effective = EngineEffectiveConfiguration(enabled: override.enabled ?? global.enabled,
                policy: (global.policy ?? [:]).merging(override.policy) { _, new in new })
            return EngineAccountConfiguration(accountId: account.accountId, override: override, effective: effective,
                revision: selected ? newRevision : account.revision,
                observedAt: selected ? observedAt : account.observedAt,
                freshness: selected ? "fresh" : account.freshness, pending: selected ? nil : account.pending)
        }
        engines[index].configuration = EngineConfiguration(global: global, accounts: accounts)
        var response = self
        response.engines = engines
        return response
    }
}

public struct ControlScope: Codable, Equatable, Hashable, Sendable {
    public enum Kind: String, Codable, Sendable { case global, account }
    public let kind: Kind
    public let accountId: String?

    public static let global = ControlScope(kind: .global, accountId: nil)

    public static func account(_ accountId: String) throws -> ControlScope {
        guard Self.validAccountId(accountId), accountId != "unassigned" else {
            throw ControlIntent.ValidationError.invalid("Choose a configurable account.")
        }
        return ControlScope(kind: .account, accountId: accountId)
    }

    public static func validAccountId(_ id: String) -> Bool {
        !id.isEmpty && id.utf8.count <= 128 && id.rangeOfCharacter(from: .controlCharacters) == nil &&
        id.rangeOfCharacter(from: .whitespacesAndNewlines) == nil
    }
}

public struct EngineConfigureValue: Codable, Equatable {
    public enum EnabledChange: Equatable { case unchanged, value(Bool), inherit }

    public let engineId: String
    public let set: [String: Double]?
    public let unset: [String]?
    public let enabledChange: EnabledChange

    enum CodingKeys: String, CodingKey { case engineId, enabled, set, unset }

    public init(engineId: String, set: [String: Double]?, unset: [String]?, enabledChange: EnabledChange) {
        self.engineId = engineId; self.set = set; self.unset = unset; self.enabledChange = enabledChange
    }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        engineId = try values.decode(String.self, forKey: .engineId)
        set = try values.decodeIfPresent([String: Double].self, forKey: .set)
        unset = try values.decodeIfPresent([String].self, forKey: .unset)
        if values.contains(.enabled) {
            enabledChange = try values.decodeNil(forKey: .enabled) ? .inherit : .value(try values.decode(Bool.self, forKey: .enabled))
        } else { enabledChange = .unchanged }
    }

    public func encode(to encoder: Encoder) throws {
        var values = encoder.container(keyedBy: CodingKeys.self)
        try values.encode(engineId, forKey: .engineId)
        try values.encodeIfPresent(set, forKey: .set)
        try values.encodeIfPresent(unset, forKey: .unset)
        switch enabledChange {
        case .unchanged: break
        case let .value(value): try values.encode(value, forKey: .enabled)
        case .inherit: try values.encodeNil(forKey: .enabled)
        }
    }
}

public struct BookConfigureValue: Codable, Equatable {
    public let bookId: String
    public let enabled: Bool

    public init(bookId: String, enabled: Bool) {
        self.bookId = bookId
        self.enabled = enabled
    }
}

/// engine.probe body. `approval` is the signed single-use token minted by the approve route (D7).
public struct ProbeControlValue: Codable, Equatable {
    public let engineId: String
    public let symbols: [String]
    public let approval: String
    public let expiresAt: String
    public let bind: Bool

    public init(engineId: String, symbols: [String], approval: String, expiresAt: String, bind: Bool) {
        self.engineId = engineId; self.symbols = symbols; self.approval = approval
        self.expiresAt = expiresAt; self.bind = bind
    }
}

/// engine.halt body. Halting stops new entries; open contracts settle normally.
public struct HaltControlValue: Codable, Equatable {
    public let engineId: String
    public let reason: String

    public init(engineId: String, reason: String) { self.engineId = engineId; self.reason = reason }
}

/// engine.assign body. Admin only; devices never send it, they only show it.
public struct AssignControlValue: Codable, Equatable {
    public let engineId: String
    public let accountId: String?
    public let domain: String?

    public init(engineId: String, accountId: String?, domain: String?) {
        self.engineId = engineId; self.accountId = accountId; self.domain = domain
    }
}

/// engine.graduate body. Admin only; devices never send it, they only show it.
public struct GraduateControlValue: Codable, Equatable {
    public let engineId: String

    public init(engineId: String) { self.engineId = engineId }
}

/// risk.breaker body: the UTC-day loss breaker percentage for one account or one engine (D5a).
public struct BreakerControlValue: Codable, Equatable {
    public enum Scope: String, Codable { case account, engine }
    public let scope: Scope
    public let id: String
    public let pct: Int

    public init(scope: Scope, id: String, pct: Int) { self.scope = scope; self.id = id; self.pct = pct }
}

public enum ControlValue: Codable, Equatable {
    case legacy(String)
    case configure(EngineConfigureValue)
    case bookConfigure(BookConfigureValue)
    case probe(ProbeControlValue)
    case halt(HaltControlValue)
    case assign(AssignControlValue)
    case graduate(GraduateControlValue)
    case breaker(BreakerControlValue)
    /// A kind this build does not know, or a body that does not match its kind. Kept verbatim.
    case unknown(JSONValue)

    /// Decodes the body the kind names, so one kind's body never reads as another's shape (fixes D-e).
    /// A nil kind keeps the shape-based decoding older rows relied on.
    public static func decode(kind: String?, from decoder: Decoder) throws -> ControlValue {
        guard let kind else { return try ControlValue(from: decoder) }
        let container = try decoder.singleValueContainer()
        func typed<T: Decodable>(_ type: T.Type, _ wrap: (T) -> ControlValue) -> ControlValue {
            if let value = try? container.decode(T.self) { return wrap(value) }
            return .unknown((try? container.decode(JSONValue.self)) ?? .null)
        }
        switch ControlKind(rawValue: kind) {
        case .bind?, .set?, .create?: return typed(String.self, ControlValue.legacy)
        case .configure?: return typed(EngineConfigureValue.self, ControlValue.configure)
        case .bookConfigure?: return typed(BookConfigureValue.self, ControlValue.bookConfigure)
        case .probe?: return typed(ProbeControlValue.self, ControlValue.probe)
        case .halt?: return typed(HaltControlValue.self, ControlValue.halt)
        case .assign?: return typed(AssignControlValue.self, ControlValue.assign)
        case .graduate?: return typed(GraduateControlValue.self, ControlValue.graduate)
        case .breaker?: return typed(BreakerControlValue.self, ControlValue.breaker)
        case nil: return .unknown((try? container.decode(JSONValue.self)) ?? .null)
        }
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let legacy = try? container.decode(String.self) { self = .legacy(legacy) }
        else if let value = try? container.decode(EngineConfigureValue.self) { self = .configure(value) }
        else { self = .bookConfigure(try container.decode(BookConfigureValue.self)) }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case let .legacy(value): try container.encode(value)
        case let .configure(value): try container.encode(value)
        case let .bookConfigure(value): try container.encode(value)
        case let .probe(value): try container.encode(value)
        case let .halt(value): try container.encode(value)
        case let .assign(value): try container.encode(value)
        case let .graduate(value): try container.encode(value)
        case let .breaker(value): try container.encode(value)
        case let .unknown(value): try container.encode(value)
        }
    }

    public var displayValue: String {
        switch self {
        case let .legacy(value): return value
        case let .configure(value):
            var parts: [String] = []
            if let count = value.set?.count, count > 0 {
                parts.append(count == 1 ? "1 setting changed" : "\(count) settings changed")
            }
            if let count = value.unset?.count, count > 0 { parts.append("\(count) use global") }
            switch value.enabledChange {
            case let .value(enabled): parts.append(enabled ? "entries on" : "entries off")
            case .inherit: parts.append("entries use global")
            case .unchanged: break
            }
            return parts.isEmpty ? value.engineId : "\(value.engineId): " + parts.joined(separator: ", ")
        case let .bookConfigure(value):
            return "\(value.bookId): \(value.enabled ? "enabled" : "disabled")"
        case let .probe(value):
            return "\(value.engineId): probe on \(value.symbols.joined(separator: ", "))"
        case let .halt(value): return "\(value.engineId): halt"
        case let .assign(value): return "\(value.engineId): assign to \(value.accountId ?? "no account")"
        case let .graduate(value): return "\(value.engineId): graduate"
        case let .breaker(value): return "\(value.scope.rawValue) \(value.id): breaker \(value.pct)%"
        case .unknown: return "Unknown change"
        }
    }
}

public struct ControlRequest: Codable, Identifiable {
    public var id: String
    public var kind: String?
    public var value: ControlValue?
    public var scope: ControlScope?
    public var clientRequestId: String?
    public var state: String?
    public var note: String?
    public var requestedAt: String?
    public var appliedAt: String?

    public var requestedDate: Date? {
        guard let requestedAt else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: requestedAt) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: requestedAt)
    }

    public init(id: String, kind: String?, value: ControlValue?, scope: ControlScope?, clientRequestId: String?, state: String?, note: String?, requestedAt: String?, appliedAt: String?) {
        self.id = id
        self.kind = kind
        self.value = value
        self.scope = scope
        self.clientRequestId = clientRequestId
        self.state = state
        self.note = note
        self.requestedAt = requestedAt
        self.appliedAt = appliedAt
    }

    enum CodingKeys: String, CodingKey {
        case id, kind, value, scope, clientRequestId, state, note, requestedAt, appliedAt
    }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(String.self, forKey: .id)
        kind = try values.decodeIfPresent(String.self, forKey: .kind)
        if values.contains(.value), try !values.decodeNil(forKey: .value) {
            value = try ControlValue.decode(kind: kind, from: values.superDecoder(forKey: .value))
        } else { value = nil }
        scope = try values.decodeIfPresent(ControlScope.self, forKey: .scope)
        clientRequestId = try values.decodeIfPresent(String.self, forKey: .clientRequestId)
        state = try values.decodeIfPresent(String.self, forKey: .state)
        note = try values.decodeIfPresent(String.self, forKey: .note)
        requestedAt = try values.decodeIfPresent(String.self, forKey: .requestedAt)
        appliedAt = try values.decodeIfPresent(String.self, forKey: .appliedAt)
    }
}

public struct ControlResponse: Codable { public var request: ControlRequest? }

public enum ControlKind: String, Codable {
    case bind = "engine.bind", set = "engine.set", create = "engine.create", configure = "engine.configure"
    case bookConfigure = "book.configure"
    case probe = "engine.probe", halt = "engine.halt", assign = "engine.assign", graduate = "engine.graduate"
    case breaker = "risk.breaker"
}

public struct ControlIntent: Codable, Equatable {
    public let kind: ControlKind
    public let value: ControlValue
    public let host: String?
    public let venue: String?
    public let scope: ControlScope?
    public let clientRequestId: String?
    public let expectedRevision: String?

    private init(kind: ControlKind, value: ControlValue, host: String? = nil, venue: String? = nil,
                 scope: ControlScope? = nil, clientRequestId: String? = nil, expectedRevision: String? = nil) {
        self.kind = kind; self.value = value; self.host = host; self.venue = venue; self.scope = scope
        self.clientRequestId = clientRequestId; self.expectedRevision = expectedRevision
    }

    enum CodingKeys: String, CodingKey { case kind, value, host, venue, scope, clientRequestId, expectedRevision }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        kind = try values.decode(ControlKind.self, forKey: .kind)
        guard values.contains(.value) else {
            throw DecodingError.keyNotFound(CodingKeys.value, .init(codingPath: values.codingPath, debugDescription: "No value."))
        }
        value = try ControlValue.decode(kind: kind.rawValue, from: values.superDecoder(forKey: .value))
        host = try values.decodeIfPresent(String.self, forKey: .host)
        venue = try values.decodeIfPresent(String.self, forKey: .venue)
        scope = try values.decodeIfPresent(ControlScope.self, forKey: .scope)
        clientRequestId = try values.decodeIfPresent(String.self, forKey: .clientRequestId)
        expectedRevision = try values.decodeIfPresent(String.self, forKey: .expectedRevision)
    }

    public enum ValidationError: LocalizedError {
        case invalid(String)
        public var errorDescription: String? { switch self { case let .invalid(reason): return reason } }
    }

    private static func validateId(_ id: String) throws {
        guard id.range(of: "^[a-z0-9][a-z0-9-]{0,31}$", options: .regularExpression) != nil,
              !id.contains("\n"), !id.contains("\r") else {
            throw ValidationError.invalid("Engine IDs need 1 to 32 lowercase letters, digits or hyphens, starting with a letter or digit.")
        }
    }

    public static func bind(symbol: String?, engineId: String) throws -> ControlIntent {
        try validateId(engineId)
        let target = symbol ?? "all"
        guard !target.isEmpty, !target.contains("="), target.rangeOfCharacter(from: .whitespacesAndNewlines) == nil else {
            throw ValidationError.invalid("Choose a book symbol or all.")
        }
        return ControlIntent(kind: .bind, value: .legacy("\(target)=\(engineId)"))
    }

    public static func set(engineId: String, key: String, value: Double, envelope: RiskEnvelope? = nil) throws -> ControlIntent {
        try validateId(engineId)
        if let reason = PolicyBounds.validate(key: key, value: value, envelope: envelope) { throw ValidationError.invalid(reason) }
        let number = PolicyBounds.bounds[key]?.isInt == true ? String(Int(value)) : String(value)
        return ControlIntent(kind: .set, value: .legacy("\(engineId):\(key)=\(number)"))
    }

    public static func create(engineId: String, name: String, from: String) throws -> ControlIntent {
        try validateId(engineId); try validateId(from)
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, name.count <= 64 else {
            throw ValidationError.invalid("Enter a name of 1 to 64 characters.")
        }
        let data = try JSONSerialization.data(withJSONObject: ["engine_id": engineId, "name": name, "from": from],
                                              options: [.sortedKeys, .withoutEscapingSlashes])
        return ControlIntent(kind: .create, value: .legacy(String(decoding: data, as: UTF8.self)))
    }

    public static func configure(engineId: String, host: String, scope: ControlScope,
                                 enabled: EngineConfigureValue.EnabledChange = .unchanged,
                                 set: [String: Double] = [:], unset: [String] = [],
                                 expectedRevision: String, clientRequestId: String,
                                 envelope: RiskEnvelope? = nil) throws -> ControlIntent {
        try validateId(engineId)
        guard !host.isEmpty, host.utf8.count <= 128, host.rangeOfCharacter(from: .controlCharacters) == nil else {
            throw ValidationError.invalid("The runner host is unavailable.")
        }
        guard !expectedRevision.isEmpty, expectedRevision.utf8.count <= 128 else {
            throw ValidationError.invalid("The current runner version is unavailable.")
        }
        guard UUID(uuidString: clientRequestId) != nil else { throw ValidationError.invalid("The request identifier is invalid.") }
        if scope.kind == .account {
            guard let id = scope.accountId, ControlScope.validAccountId(id), id != "unassigned" else {
                throw ValidationError.invalid("Choose a configurable account.")
            }
        } else if scope.accountId != nil { throw ValidationError.invalid("The global scope cannot name an account.") }
        if scope.kind == .global && (!unset.isEmpty || enabled == .inherit) {
            throw ValidationError.invalid("Global values cannot inherit from another scope.")
        }
        for (key, value) in set {
            let reason = engineId == "darkhorse" ? DarkhorsePolicy.validate(key: key, value: value) : PolicyBounds.validate(key: key, value: value, envelope: envelope)
            if let reason { throw ValidationError.invalid(reason) }
        }
        if engineId == "darkhorse" && scope.kind != .account { throw ValidationError.invalid("Darkhorse controls require an account.") }
        for key in unset {
            guard engineId == "darkhorse" ? DarkhorsePolicy.keys.contains(key) : PolicyBounds.bounds[key] != nil else {
                throw ValidationError.invalid("Unknown setting: \(key).")
            }
        }
        guard Set(set.keys).isDisjoint(with: unset) else { throw ValidationError.invalid("A setting cannot be set and inherited together.") }
        guard enabled != .unchanged || !set.isEmpty || !unset.isEmpty else { throw ValidationError.invalid("Make a change before saving.") }
        return ControlIntent(kind: .configure,
            value: .configure(EngineConfigureValue(engineId: engineId, set: set.isEmpty ? nil : set,
                unset: unset.isEmpty ? nil : unset, enabledChange: enabled)), host: host, venue: "kalshi", scope: scope,
            clientRequestId: clientRequestId, expectedRevision: expectedRevision)
    }

    public static func configureBook(bookId: String, host: String, enabled: Bool,
                                     clientRequestId: String) throws -> ControlIntent {
        guard !bookId.isEmpty, bookId.utf8.count <= 64,
              bookId.rangeOfCharacter(from: .whitespacesAndNewlines.union(.controlCharacters)) == nil else {
            throw ValidationError.invalid("The book identifier is unavailable.")
        }
        guard !host.isEmpty, host.utf8.count <= 128, host.rangeOfCharacter(from: .controlCharacters) == nil else {
            throw ValidationError.invalid("The runner host is unavailable.")
        }
        guard UUID(uuidString: clientRequestId) != nil else {
            throw ValidationError.invalid("The request identifier is invalid.")
        }
        return ControlIntent(kind: .bookConfigure,
            value: .bookConfigure(BookConfigureValue(bookId: bookId, enabled: enabled)),
            host: host, venue: "kalshi", clientRequestId: clientRequestId)
    }

    // Lifecycle kinds carry no host: the server assigns the target host.

    /// engine.probe. Fails closed on an empty symbol list, a missing approval or an unparseable expiry.
    public static func probe(engineId: String, symbols: [String], approval: String, expiresAt: String,
                             bind: Bool, clientRequestId: String) throws -> ControlIntent {
        try validateId(engineId)
        guard !symbols.isEmpty, symbols.count <= 64, Set(symbols).count == symbols.count else {
            throw ValidationError.invalid("Choose 1 to 64 distinct markets.")
        }
        for symbol in symbols {
            guard !symbol.isEmpty, symbol.utf8.count <= 64, !symbol.contains("="),
                  symbol.rangeOfCharacter(from: .whitespacesAndNewlines.union(.controlCharacters)) == nil else {
                throw ValidationError.invalid("A market symbol is invalid.")
            }
        }
        guard !approval.isEmpty, approval.utf8.count <= 4096,
              approval.rangeOfCharacter(from: .whitespacesAndNewlines.union(.controlCharacters)) == nil else {
            throw ValidationError.invalid("The probe approval is missing.")
        }
        guard RuntimeDate.parse(expiresAt) != nil else { throw ValidationError.invalid("The probe expiry is invalid.") }
        guard UUID(uuidString: clientRequestId) != nil else { throw ValidationError.invalid("The request identifier is invalid.") }
        return ControlIntent(kind: .probe, value: .probe(ProbeControlValue(engineId: engineId, symbols: symbols,
            approval: approval, expiresAt: expiresAt, bind: bind)), venue: "kalshi", clientRequestId: clientRequestId)
    }

    /// engine.halt. Unsigned and never refused for a pending request.
    public static func halt(engineId: String, reason: String, clientRequestId: String) throws -> ControlIntent {
        try validateId(engineId)
        let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed.count <= 280, trimmed.rangeOfCharacter(from: .controlCharacters) == nil else {
            throw ValidationError.invalid("Enter a reason of 1 to 280 characters.")
        }
        guard UUID(uuidString: clientRequestId) != nil else { throw ValidationError.invalid("The request identifier is invalid.") }
        return ControlIntent(kind: .halt, value: .halt(HaltControlValue(engineId: engineId, reason: trimmed)),
                             venue: "kalshi", clientRequestId: clientRequestId)
    }

    /// risk.breaker. The percentage of the day-start portfolio, 1 to 100.
    public static func breaker(scope: BreakerControlValue.Scope, id: String, pct: Int,
                               clientRequestId: String) throws -> ControlIntent {
        switch scope {
        case .engine: try validateId(id)
        case .account:
            guard ControlScope.validAccountId(id), id != "unassigned" else {
                throw ValidationError.invalid("Choose a configurable account.")
            }
        }
        guard (1...100).contains(pct) else { throw ValidationError.invalid("The breaker must be between 1% and 100%.") }
        guard UUID(uuidString: clientRequestId) != nil else { throw ValidationError.invalid("The request identifier is invalid.") }
        return ControlIntent(kind: .breaker, value: .breaker(BreakerControlValue(scope: scope, id: id, pct: pct)),
                             venue: "kalshi", clientRequestId: clientRequestId)
    }
}
