import Foundation

/// Preserve evolving nested producer fields without coercing nulls to zero.
public enum JSONValue: Codable, Equatable {
    case string(String), number(Decimal), bool(Bool), object([String: JSONValue]), array([JSONValue]), null
    public init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() { self = .null }
        else if let value = try? container.decode(Bool.self) { self = .bool(value) }
        else if let value = try? container.decode(String.self) { self = .string(value) }
        else if let value = try? container.decode(Decimal.self) { self = .number(value) }
        else if let value = try? container.decode([String: JSONValue].self) { self = .object(value) }
        else { self = .array(try container.decode([JSONValue].self)) }
    }
    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .null: try container.encodeNil()
        case let .string(value): try container.encode(value)
        case let .number(value): try container.encode(value)
        case let .bool(value): try container.encode(value)
        case let .object(value): try container.encode(value)
        case let .array(value): try container.encode(value)
        }
    }
}
public struct MobileBooks: Codable {
    public var schemaVersion: Int?
    public var generatedAt: String?
    public var books: [Book]
}
public struct Book: Codable {
    public var bookId: String
    public var runId: String?
    public var host: String?
    public var updatedAt: String?
    public var enabled: Bool?
    public var kalshiBook: KalshiBook
}
public struct KalshiBook: Codable {
    public var params: JSONValue?
    public var stats: JSONValue?
    public var policy: JSONValue?
    public var shard: JSONValue?
    public var eval: EvalBlock?
    public var executor: ExecutorSummary?
}
public struct EvalBlock: Codable {
    public var schemaVersion: Int?
    public var capturedAtMs: Int64?
    public var windowS: Double?
    public var minK: Int?
    public var minDepth: Double?
    public var edgeThresholdCents: Double?
    public var exitMarginCents: Double?
    public var candidates: [Candidate]?
    public var tickets: [Ticket]?
    public var coverage: JSONValue?
}
public struct Candidate: Codable {
    public var ticker: String
    public var expiryMs: Int64?
    public var secondsToClose: Double?
    public var status: String?
    public var quoteAgeMs: Double?
    public var strikeSet: Bool?
    public var evalAtMs: Int64?
    public var gate: String?
    public var k: Int?
    public var kSource: String?
    public var sideYes: Bool?
    public var askCents: Double?
    public var fairCents: Double?
    public var feeCents: Double?
    public var edgeCents: Double?
    public var edgeRequiredCents: Double?
    public var depth: Double?
    public var favorite: Bool?
    public var intentSent: Bool?
    public init(ticker: String) { self.ticker = ticker }
}
public struct Ticket: Codable {
    public var ticker: String
    public var sideYes: Bool?
    public var count: Double?
    public var priceCents: Double?
    public var exitEvalAtMs: Int64?
    public var exitGate: String?
    public var bidCents: Double?
    public var depth: Double?
    public var pSide: Double?
    public var holdValue: Double?
    public var netValue: Double?
    public var margin: Double?
    public var surplus: Double?
    public init(ticker: String) { self.ticker = ticker }
}
