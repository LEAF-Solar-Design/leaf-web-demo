import Foundation

public struct DevicePairingEnvelope: Decodable, Equatable, Sendable {
    public let pairing: DevicePairingRequest

    public init(pairing: DevicePairingRequest) { self.pairing = pairing }
}

public struct DevicePairingRequest: Decodable, Equatable, Sendable {
    public let id: String
    public let code: String
    public let pollToken: String
    public let expiresAt: Date

    public init(id: String, code: String, pollToken: String, expiresAt: Date) {
        self.id = id
        self.code = code
        self.pollToken = pollToken
        self.expiresAt = expiresAt
    }
}

public struct DevicePairingPollEnvelope: Decodable, Equatable, Sendable {
    public let pairing: DevicePairingPoll

    public init(pairing: DevicePairingPoll) { self.pairing = pairing }
}

public enum DevicePairingPollState: Equatable, Sendable {
    case pending
    case approved
    case terminal
}

extension DevicePairingPollState: Decodable {
    public init(from decoder: Decoder) throws {
        let value = try decoder.singleValueContainer().decode(String.self)
        switch value.lowercased() {
        case "pending": self = .pending
        case "approved": self = .approved
        default: self = .terminal
        }
    }
}

public struct DevicePairingPoll: Decodable, Equatable, Sendable {
    public let state: DevicePairingPollState
    public let expiresAt: Date?
    public let token: String?

    public init(state: DevicePairingPollState, expiresAt: Date? = nil, token: String? = nil) {
        self.state = state
        self.expiresAt = expiresAt
        self.token = token
    }
}
