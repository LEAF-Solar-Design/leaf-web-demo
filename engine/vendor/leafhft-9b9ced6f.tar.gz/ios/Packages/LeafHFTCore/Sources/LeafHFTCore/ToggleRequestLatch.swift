import Foundation

/// Holds optimistic book or engine toggles until their request resolves or expires.
/// Missing requests clear on a matching observation or after a 45-second grace period.
/// Unknown requests remain until UnresolvedControlPolicy considers them expired.
public struct ToggleRequestLatch: Equatable, Sendable {
    public static let missingGrace: TimeInterval = 45

    /// The desired value and identity of the request that owns it.
    public struct Entry: Equatable, Sendable {
        public let desired: Bool
        public let clientRequestId: String
        public let requestedAt: Date

        public init(desired: Bool, clientRequestId: String, requestedAt: Date) {
            self.desired = desired
            self.clientRequestId = clientRequestId
            self.requestedAt = requestedAt
        }
    }

    /// Lifecycle state for the entry's client request ID; missing means it is absent from the list.
    public enum RequestState: Equatable, Sendable {
        case pending, applied, rejected, unknown, missing
    }

    /// Entries keyed by book ID or engine ID.
    public private(set) var entries: [String: Entry] = [:]

    public init() {}

    /// Starts or replaces the optimistic request for one ID.
    public mutating func request(id: String, desired: Bool, clientRequestId: String, at: Date) {
        entries[id] = Entry(desired: desired, clientRequestId: clientRequestId, requestedAt: at)
    }

    /// Clears the optimistic value when submission itself fails.
    public mutating func submissionFailed(id: String) {
        entries.removeValue(forKey: id)
    }

    /// Reconciles one telemetry tick against the lifecycle of the entry's client request ID.
    /// A matching observation alone cannot resolve a pending or unknown request.
    public mutating func reconcile(id: String, observed: Bool?, request: RequestState, now: Date) {
        guard let entry = entries[id] else { return }
        switch request {
        case .applied, .rejected:
            entries.removeValue(forKey: id)
        case .missing:
            if observed == entry.desired || now.timeIntervalSince(entry.requestedAt) >= Self.missingGrace {
                entries.removeValue(forKey: id)
            }
        case .pending, .unknown:
            if UnresolvedControlPolicy.isExpired(since: entry.requestedAt, now: now) {
                entries.removeValue(forKey: id)
            }
        }
    }

    /// Uses active intent first, then telemetry, then the caller's fallback.
    public func effective(id: String, observed: Bool?, fallback: Bool) -> Bool {
        entries[id]?.desired ?? observed ?? fallback
    }

    /// Whether the ID still has unresolved optimistic intent.
    public func isPending(id: String) -> Bool {
        entries[id] != nil
    }
}
