import Foundation

/// Sanitized runner activity for the account lane paired to this device.
/// The server deliberately omits order, request, credential, and tenant identifiers.
public struct RunnerActivity: Codable, Equatable {
    public let schemaVersion: Int
    public let generatedAt: String
    public let host: String
    public let budget: RunnerSizingBudget?
    public let account: ServerAccountSnapshot?
    public let orders: [RunnerActivityRow]
    public let fills: [RunnerActivityRow]
    public let refusals: [RunnerActivityRow]

    public init(schemaVersion: Int, generatedAt: String, host: String, budget: RunnerSizingBudget?,
                orders: [RunnerActivityRow], fills: [RunnerActivityRow], refusals: [RunnerActivityRow],
                account: ServerAccountSnapshot? = nil) {
        self.schemaVersion = schemaVersion
        self.generatedAt = generatedAt
        self.host = host
        self.budget = budget
        self.orders = orders
        self.fills = fills
        self.refusals = refusals
        self.account = account
    }
}

public struct RunnerSizingBudget: Codable, Equatable {
    public let freeCashCents: Int
    public let perBookStakeCents: Int
    public let aggregateStakeCents: Int
    public let turnoverCapCents: Int
    public let totalClaims: Int
    public let totalFills: Int
    public let submittedCents: Int
    public let filledCents: Int
    public let cashRefusals: Int
    public let bookCount: Int
    public let observedAt: String

    public var cashStatus: String {
        guard freeCashCents >= 0, perBookStakeCents > 0 else { return "Unavailable" }
        return freeCashCents >= perBookStakeCents ? "Available for one book" : "Below per-book stake"
    }
}

public struct RunnerActivityRow: Codable, Equatable {
    public let ticker: String
    public let kind: String
    public let state: String
    public let side: String?
    public let count: Decimal?
    public let priceCents: Decimal?
    public let costCents: Decimal?
    public let feeCents: Decimal?
    public let pnlCents: Decimal?
    public let costBasisCents: Decimal?
    public let closeKind: String?
    public let engineId: String?
    public let occurredAt: String
    public let reason: String?

    public var pnlPercent: Decimal? {
        guard let pnlCents, let costBasisCents, costBasisCents > 0 else { return nil }
        return pnlCents / costBasisCents * 100
    }

    public var feeShareOfPnlPercent: Decimal? {
        guard let feeCents, let pnlCents, pnlCents != 0 else { return nil }
        return feeCents / abs(pnlCents) * 100
    }

    public var outcomeLabel: String? {
        switch closeKind?.lowercased() {
        case "cashout": return "Cashout"
        case "full_loss": return "Full position loss"
        case "settlement_win": return "Settled win"
        case "settlement_loss": return "Settled loss"
        case "settlement_flat": return "Settled flat"
        case "position_close": return "Position close"
        default: return pnlCents == nil ? nil : "Closed"
        }
    }

    public var safeEngineLabel: String? {
        guard let engineId else { return nil }
        let value = engineId.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty, value.utf8.count <= 64,
              value.range(of: "^[A-Za-z0-9][A-Za-z0-9._-]*$", options: .regularExpression) != nil else {
            return nil
        }
        return value
    }

    /// Do not pass arbitrary producer text into the interface.
    public var stateLabel: String {
        switch state.lowercased() {
        case "pending": return "Pending"
        case "submitted": return "Submitted"
        case "resting": return "Resting"
        case "partially_filled": return "Partially filled"
        case "filled": return "Filled"
        case "canceled", "cancelled": return "Canceled"
        case "rejected": return "Rejected"
        case "refused": return "Refused"
        case "expired": return "Expired"
        case "failed": return "Failed"
        default: return "Unknown"
        }
    }

    public var sideLabel: String? {
        switch side?.lowercased() {
        case "yes": return "Yes"
        case "no": return "No"
        default: return nil
        }
    }

    public var safeTicker: String {
        let value = ticker.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty, value.utf8.count <= 128,
              value.range(of: "^[A-Za-z0-9._:-]+$", options: .regularExpression) != nil else {
            return "Unknown market"
        }
        return value
    }

    public var refusalLabel: String? {
        guard let reason else { return nil }
        switch reason.lowercased() {
        case "cash_floor": return "Cash floor protected"
        case "insufficient_cash": return "Not enough free cash"
        case "aggregate_cap": return "Account cap reached"
        case "turnover_cap": return "Turnover cap reached"
        case "book_disabled": return "Book is paused"
        case "engine_disabled": return "Engine is paused"
        case "venue_paused": return "Venue is paused"
        case "risk_limit": return "Risk limit protected"
        default: return "Runner declined the order"
        }
    }
}
