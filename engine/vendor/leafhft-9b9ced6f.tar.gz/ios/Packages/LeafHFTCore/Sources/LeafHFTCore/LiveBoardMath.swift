import Foundation

public enum LiveBoardMath {
    public static func decimal(_ string: String?) -> Decimal? {
        guard let string,
              string.range(of: "^[+-]?[0-9]+(?:\\.[0-9]+)?$", options: .regularExpression) != nil,
              let value = Decimal(string: string, locale: Locale(identifier: "en_US_POSIX")),
              !value.isNaN else { return nil }
        return value
    }

    public static func integer(_ value: Decimal, rounding: Decimal.RoundingMode) -> Int? {
        guard !value.isNaN else { return nil }
        var value = value
        var rounded = Decimal()
        NSDecimalRound(&rounded, &value, 0, rounding)
        guard !rounded.isNaN, rounded >= Decimal(Int.min), rounded <= Decimal(Int.max) else { return nil }
        return NSDecimalNumber(decimal: rounded).intValue
    }

    public static func contracts(positionFp: String?) -> (side: String, milli: Int)? {
        guard let value = decimal(positionFp), value != 0,
              let milli = integer(abs(value) * 1000, rounding: .plain) else { return nil }
        return (value > 0 ? "yes" : "no", milli)
    }

    public static func winCents(contracts: Decimal, exposure: Decimal?, fees: Decimal?) -> Int? {
        guard let exposure else { return nil }
        return integer((abs(contracts) - exposure - (fees ?? 0)) * 100, rounding: .down)
    }

    public static func pnlCents(contracts: Decimal, exposure: Decimal?, fees: Decimal?, mark: Decimal?) -> Int? {
        guard let exposure, let mark else { return nil }
        return integer((abs(contracts) * mark - exposure - (fees ?? 0)) * 100, rounding: .down)
    }

    public static func markDollars(market: Market, side: String) -> Decimal? {
        let probability: Decimal
        if let bid = market.yesBid, let ask = market.yesAsk,
           bid > 0, ask < 1, ask >= bid, ask - bid <= Decimal(1) / 10 {
            probability = (ask + bid) / 2
        } else if let last = market.lastPrice, last > 0 {
            probability = last
        } else { return nil }
        return side == "no" ? 1 - probability : probability
    }

    public static func oddsPct(market: Market, side: String) -> Int? {
        guard market.status == "active" || market.status == "open",
              let mark = markDollars(market: market, side: side) else { return nil }
        guard let percent = integer(mark * 100,
                                    rounding: .bankers) else { return nil }
        return min(99, max(1, percent))
    }

    public static func ledgerEntry(settlement: Settlement) -> (ticker: String, pnlCents: Int, pnlBps: Int?, at: Int)? {
        let yes = decimal(settlement.yesTotalCostDollars) ?? 0
        let no = decimal(settlement.noTotalCostDollars) ?? 0
        guard let revenue = settlement.revenue,
              let cost = integer((yes + no) * 100, rounding: .plain),
              let fee = integer((decimal(settlement.feeCost) ?? 0) * 100, rounding: .plain),
              cost != 0 || revenue != 0,
              let time = settlement.settledTime else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        var date = formatter.date(from: time)
        if date == nil {
            formatter.formatOptions = [.withInternetDateTime]
            date = formatter.date(from: time)
        }
        guard let date,
              let at = Int(exactly: date.timeIntervalSince1970.rounded(.down)),
              let pnl = integer(Decimal(revenue) - Decimal(cost) - Decimal(fee), rounding: .plain) else { return nil }
        let ratio = cost > 0 ? Decimal(pnl) * 10000 / Decimal(cost) : nil
        let bps = ratio.flatMap { integer($0, rounding: $0 < 0 ? .up : .down) }
        return (settlement.ticker, pnl, bps, at)
    }

    public static func easternDayStart(for date: Date) -> Date {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "America/New_York")!
        return calendar.startOfDay(for: date)
    }
}
