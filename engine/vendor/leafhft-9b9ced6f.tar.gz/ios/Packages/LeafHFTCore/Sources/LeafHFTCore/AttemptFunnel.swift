import Foundation

/// Mobile attempt funnel read contract v1. Future enum values remain readable.
public struct AttemptFunnel: Codable, Equatable {
    public var schema: String
    public var generatedAt: String
    public var host: String?
    public var window: Window
    public var status: Status
    public var totals: Totals
    public var headline: String
    public var stages: [StageRow]
    public var engines: [EngineRow]
    public var latency: Latency
    public var missedBeforeDecision: MissedBeforeDecision?
    public var coverage: Coverage
    public var traces: [Trace]
    public var interim: Interim?

    public enum Stage: String, Codable, CaseIterable {
        case halted, riskBlocked = "risk_blocked", conflict, tooLate = "too_late"
        case unexplained, sendError = "send_error", zeroFill = "zero_fill", partial, filled, unknown
        public init(from decoder: Decoder) throws {
            self = Self(rawValue: try decoder.singleValueContainer().decode(String.self)) ?? .unknown
        }
        public static var ordered: [Stage] { allCases.filter { $0 != .unknown } }
        public var label: String {
            switch self {
            case .halted: return "Engine or venue halted"
            case .riskBlocked: return "Blocked by risk, cash or limits"
            case .conflict: return "Fought another engine or book"
            case .tooLate: return "Too late to send"
            case .unexplained: return "Vanished with no reason recorded"
            case .sendError: return "Order errored at the venue"
            case .zeroFill: return "Sent, nothing filled"
            case .partial: return "Partly filled"
            case .filled: return "Filled"
            case .unknown: return "Unknown stage"
            }
        }
        public var group: Group {
            switch self {
            case .halted, .riskBlocked, .conflict, .tooLate, .unexplained: return .beforeSend
            case .sendError, .zeroFill, .partial: return .atVenue
            case .filled: return .filled
            case .unknown: return .unknown
            }
        }
    }
    public enum Status: String, Codable {
        case ok, noData = "no_data", unknown
        public init(from decoder: Decoder) throws {
            self = Self(rawValue: try decoder.singleValueContainer().decode(String.self)) ?? .unknown
        }
    }
    public enum Group: String, Codable {
        case beforeSend = "before_send", atVenue = "at_venue", filled, unknown
        public init(from decoder: Decoder) throws {
            self = Self(rawValue: try decoder.singleValueContainer().decode(String.self)) ?? .unknown
        }
    }
    public struct Window: Codable, Equatable {
        public var since: String
        public var hours: Int
    }
    public struct Totals: Codable, Equatable {
        public var yes: Int
        public var halted: Int
        public var riskBlocked: Int
        public var conflict: Int
        public var tooLate: Int
        public var unexplained: Int
        public var sendError: Int
        public var zeroFill: Int
        public var partial: Int
        public var filled: Int
        public func count(for stage: Stage) -> Int {
            switch stage {
            case .halted: return halted
            case .riskBlocked: return riskBlocked
            case .conflict: return conflict
            case .tooLate: return tooLate
            case .unexplained: return unexplained
            case .sendError: return sendError
            case .zeroFill: return zeroFill
            case .partial: return partial
            case .filled: return filled
            case .unknown: return 0
            }
        }
    }
    public struct Reason: Codable, Equatable {
        public var reason: String
        public var count: Int
    }
    public struct StageRow: Codable, Equatable {
        public var stage: Stage
        public var group: Group
        public var label: String
        public var count: Int
        public var pct: Double
        public var reasons: [Reason]
    }
    public struct TopLoss: Codable, Equatable {
        public var stage: Stage
        public var count: Int
    }
    public struct EngineRow: Codable, Equatable {
        public var engineId: String
        public var yes: Int
        public var filled: Int
        public var fillPct: Double
        public var topLoss: TopLoss?
        public var byStage: TotalsByStage
        public var fillText: String { "\(AttemptFunnel.number(fillPct))% filled" }
    }
    /// Dictionary keys are wire slugs (JSONDecoder does not transform dictionary keys).
    public typealias TotalsByStage = [String: Int]
    public struct LatencyMetric: Codable, Equatable {
        public var p50: Double?
        public var p95: Double?
        public var n: Int
    }
    public struct Latency: Codable, Equatable {
        public var decisionToSubmitMs: LatencyMetric
        public var submitToAckMs: LatencyMetric
        public var quoteAgeMs: LatencyMetric
    }
    public enum Metric {
        case decisionToSubmitMs, submitToAckMs, quoteAgeMs
    }
    public struct MissedBeforeDecision: Codable, Equatable {
        public var staleQuoteEvals: Int?
        public var staleIndexEvals: Int?
        public var evals: Int?
    }
    public struct Coverage: Codable, Equatable {
        public var hostsReporting: Int
        public var decisionRowsDropped: Int
        public var lastReportAt: String?
    }
    public struct Trace: Codable, Equatable {
        public var decisionKey: String
        public var runId: String
        public var engineId: String
        public var ticker: String
        public var side: String
        public var priceCents: Int?
        public var count: Double?
        public var decidedAt: String
        public var quoteAgeMs: Double?
        public var decisionToSubmitMs: Double?
        public var submitToAckMs: Double?
        public var stage: Stage
        public var reason: String
        public var filledCount: Double?
    }
    public struct Interim: Codable, Equatable {
        public var claims: Int
        public var fills: Int
        public var submittedCents: Int
        public var filledCents: Int
        public var observedAt: String?
    }

    public var stageRows: [StageRow] {
        Stage.ordered.map { stage in
            stages.first { $0.stage == stage } ?? StageRow(stage: stage, group: stage.group,
                label: stage.label, count: totals.count(for: stage),
                pct: totals.yes > 0 ? Double(totals.count(for: stage)) / Double(totals.yes) * 100 : 0,
                reasons: [])
        }
    }
    public var lossRows: [StageRow] {
        stageRows.enumerated().filter { $0.element.stage != .filled && $0.element.count > 0 }
            .sorted { $0.element.count == $1.element.count ? $0.offset < $1.offset : $0.element.count > $1.element.count }
            .map(\.element)
    }
    public var fillRateText: String {
        let pct = totals.yes > 0 ? Double(totals.filled + totals.partial) / Double(totals.yes) * 100 : 0
        return "\(String(format: "%.0f", pct))% of \(EntryCalibration.grouped(totals.yes)) engine yeses filled"
    }
    public func latencyLine(_ metric: Metric) -> String {
        switch metric {
        case .decisionToSubmitMs: return latencyLine(latency.decisionToSubmitMs)
        case .submitToAckMs: return latencyLine(latency.submitToAckMs)
        case .quoteAgeMs: return latencyLine(latency.quoteAgeMs)
        }
    }
    public func latencyLine(_ metric: LatencyMetric) -> String {
        guard metric.n > 0 else { return "No samples" }
        let p50 = metric.p50.map { "\(Self.number($0)) ms" } ?? "Unavailable"
        let p95 = metric.p95.map { "\(Self.number($0)) ms" } ?? "Unavailable"
        return "p50 \(p50) · p95 \(p95)"
    }
    public var interimLine: String? {
        guard let interim else { return nil }
        let pct = interim.claims > 0 ? Double(interim.fills) / Double(interim.claims) * 100 : 0
        return "\(EntryCalibration.grouped(interim.claims)) order claims, \(EntryCalibration.grouped(interim.fills)) fills (\(String(format: "%.0f", pct))%)"
    }
    public var windowLabel: String { "last \(window.hours) h" }
    public static func number(_ value: Double) -> String {
        let text = String(format: "%.1f", locale: Locale(identifier: "en_US_POSIX"), value)
        return text.hasSuffix(".0") ? String(text.dropLast(2)) : text
    }
}
