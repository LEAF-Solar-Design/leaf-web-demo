import Foundation

/// Risky Batman is the owner's probe control (plan D8): lifecycle and breaker from the runner, Probe and Halt as
/// control requests. The tenant path (engine.shadow) is offline tuning: simulated, never a verdict on live trading.
public enum RiskyBatman {
    public static let enginePrefixes = ["risky-batman-"]
    public static let tuningTitle = "Offline tuning (simulated)"
    public static let tuningWarning = "Simulated tuning overstates live results: real fills, fees and latency are worse."
    public static let restartWarning = "Any change restarts the 60-minute tuning clock."
    public static let restartedMessage = "Tuning clock restarted after your change"
    /// Probe expiry sent with engine.probe: the 14-day window plus the 7-day terminal read (plan D7).
    public static let probeWindowDays = 21
    public static let haltReason = "Halted by the owner from the phone."

    public static func isEngine(_ id: String) -> Bool {
        enginePrefixes.contains { id.hasPrefix($0) }
    }

    public static func isListed(_ engine: Engine) -> Bool {
        isEngine(engine.engineId) || engine.isFrozen
    }

    public static func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return decoder
    }

    public struct Response: Decodable, Sendable {
        public let engines: [Engine]
        public let warnings: [String]
    }

    public struct Engine: Decodable, Identifiable, Sendable {
        public var id: String { engineId }
        public let engineId: String
        public let name: String
        public let gateMinutes: Int
        public let defaultEnabled: Bool
        public let liveAvailable: Bool
        public let frozen: Bool?
        public let policyBounds: [String: Bound]
        public let basePolicy: [String: Double]
        public var variant: Variant?

        public var isFrozen: Bool { frozen == true }

        public var effectivePolicy: [String: Double] {
            basePolicy.merging(variant?.overrides ?? [:]) { _, override in override }
        }

        /// Use only published keys, never wider than the runner's published envelope.
        public var editableKeys: [String] {
            editableKeys(envelope: nil)
        }

        public func editableKeys(envelope: RiskEnvelope? = nil) -> [String] {
            policyBounds.keys.filter { editableBound(for: $0, envelope: envelope) != nil }.sorted()
        }

        public func editableBound(for key: String, envelope: RiskEnvelope? = nil) -> Bound? {
            guard let published = policyBounds[key], let local = PolicyBounds.bounds[key],
                  let value = effectivePolicy[key], value.isFinite else { return nil }
            let lower = max(published.min, local.min)
            let upper = min(published.max, min(local.max, (envelope ?? RiskEnvelope()).maxima[key] ?? local.max))
            let integer = published.isInt || local.isInt
            let minimum = integer ? ceil(lower) : lower
            let maximum = integer ? floor(upper) : upper
            guard minimum.isFinite, maximum.isFinite, minimum <= maximum else { return nil }
            return Bound(min: minimum, max: maximum, isInt: integer)
        }
    }

    public struct Bound: Decodable, Equatable, Sendable {
        public let min: Double
        public let max: Double
        public let isInt: Bool

        public init(min: Double, max: Double, isInt: Bool) {
            self.min = min
            self.max = max
            self.isInt = isInt
        }

        private enum CodingKeys: String, CodingKey { case min, max, isInt, type, lo, hi, kind }

        public init(from decoder: Decoder) throws {
            // POLICY_BOUNDS tuples and the named mobile representation share these semantics.
            if var values = try? decoder.unkeyedContainer() {
                min = try values.decode(Double.self)
                max = try values.decode(Double.self)
                if let integer = try? values.decode(Bool.self) {
                    isInt = integer
                } else {
                    let type = try values.decode(String.self)
                    guard ["int", "integer", "float", "number"].contains(type) else {
                        throw DecodingError.dataCorrupted(.init(codingPath: decoder.codingPath,
                            debugDescription: "Unknown policy number type"))
                    }
                    isInt = type == "int" || type == "integer"
                }
            } else {
                let values = try decoder.container(keyedBy: CodingKeys.self)
                if values.contains(.lo) || values.contains(.hi) || values.contains(.kind) {
                    min = try values.decode(Double.self, forKey: .lo)
                    max = try values.decode(Double.self, forKey: .hi)
                    let kind = try values.decode(String.self, forKey: .kind)
                    guard ["int", "integer", "float", "number"].contains(kind) else {
                        throw DecodingError.dataCorrupted(.init(codingPath: decoder.codingPath,
                            debugDescription: "Unknown policy number type"))
                    }
                    isInt = kind == "int" || kind == "integer"
                } else {
                    min = try values.decode(Double.self, forKey: .min)
                    max = try values.decode(Double.self, forKey: .max)
                    if let integer = try values.decodeIfPresent(Bool.self, forKey: .isInt) {
                        isInt = integer
                    } else {
                        let type = try values.decodeIfPresent(String.self, forKey: .type)
                        isInt = type == "int" || type == "integer"
                    }
                }
            }
            guard min.isFinite, max.isFinite, min <= max else {
                throw DecodingError.dataCorrupted(.init(codingPath: decoder.codingPath,
                    debugDescription: "Invalid published policy bounds"))
            }
        }
    }

    public struct Variant: Decodable, Sendable {
        public let schema: String?
        public let accountId: String?
        public let engineId: String
        public var generation: Int
        public var effectivePolicyDigest: String
        public var state: String
        public var startedAt: String?
        public var updatedAt: String?
        public var liveTailSeconds: Double
        public var decisions: Int
        public var entries: Int
        public var wins: Int
        public var losses: Int
        public var paperPnlCents: Double
        public var maxDrawdownCents: Double
        public var worstTradeCents: Double
        public let capitalBasisCents: Double
        public let mirror: Bool?
        public var reasons: [String]
        public var overrides: [String: Double]?
        public var eligibleMinutesRemaining: Double?

        public var isMirror: Bool { mirror == true || engineId == "kalshi-gold-paper" }

        public var returnPercent: Double? {
            guard !isMirror, capitalBasisCents.isFinite, capitalBasisCents > 0,
                  paperPnlCents.isFinite else { return nil }
            let percent = paperPnlCents / capitalBasisCents * 100
            return percent.isFinite ? percent : nil
        }
    }

    public struct ShadowRequest: Encodable, Sendable {
        public let kind = "engine.shadow"
        public let clientRequestId: String
        public let value: Value

        public struct Value: Encodable, Sendable {
            public let engineId: String
            public let enabled: Bool
            public let set: [String: Double]?
            public let unset: [String]?
            public let consent = "paper"
            private enum CodingKeys: String, CodingKey { case engineId = "engine_id", enabled, set, unset, consent }
        }

        private enum CodingKeys: String, CodingKey { case kind, clientRequestId = "client_request_id", value }

        public init(engineId: String, enabled: Bool, set: [String: Double] = [:], unset: [String] = [],
                    clientRequestId: UUID = UUID(), envelope: RiskEnvelope? = nil) throws {
            guard RiskyBatman.isEngine(engineId),
                  engineId.range(of: "^[a-z0-9][a-z0-9-]{0,31}$", options: .regularExpression) != nil else {
                throw ControlIntent.ValidationError.invalid("Choose a Risky Batman engine.")
            }
            guard enabled || (set.isEmpty && unset.isEmpty) else {
                throw ControlIntent.ValidationError.invalid("Settings can only change while starting tuning.")
            }
            guard Set(unset).count == unset.count, Set(set.keys).isDisjoint(with: unset) else {
                throw ControlIntent.ValidationError.invalid("A setting cannot be set and reset together.")
            }
            for (key, number) in set {
                if let error = PolicyBounds.validate(key: key, value: number, envelope: envelope) {
                    throw ControlIntent.ValidationError.invalid(error)
                }
            }
            guard unset.allSatisfy({ PolicyBounds.bounds[$0] != nil }) else {
                throw ControlIntent.ValidationError.invalid("Unknown tuning setting.")
            }
            self.clientRequestId = clientRequestId.uuidString
            value = Value(engineId: engineId, enabled: enabled, set: set.isEmpty ? nil : set,
                          unset: unset.isEmpty ? nil : unset)
        }
    }

    /// The control's value is intentionally not decoded as a legacy engine.configure value.
    public struct ShadowResponse: Decodable {
        public struct Request: Decodable {
            public let id: String
            public let state: String?
            public let note: String?
        }
        public let request: Request
    }

    public struct Row: Equatable, Identifiable, Sendable {
        public let id: String
        public let label: String
        public let value: String
    }

    /// The tuning (engine.shadow) block: simulated, so every label says so and none reads as a live verdict.
    public struct Presentation: Equatable, Sendable {
        public let state: String
        public let countdown: String
        public let rows: [Row]
        public let restartNotice: String?

        public init(variant: Variant?, gateMinutes: Int = 60, restarted: Bool = false) {
            restartNotice = restarted ? RiskyBatman.restartedMessage : nil
            guard let variant else {
                state = "Off"
                countdown = "60 min of tuning left at these settings"
                rows = []
                return
            }
            switch variant.state {
            case "running": state = "Tuning running"
            case "stopped": state = "Tuning stopped"
            case "delayed": state = "Tuning delayed"
            case "refused": state = "Tuning refused"
            default: state = "Tuning status unknown"
            }
            // Never use wall-clock time: only reported live-tail seconds count.
            let seconds = variant.liveTailSeconds.isFinite ? max(0, variant.liveTailSeconds) : 0
            let gate = Double(max(60, gateMinutes))
            let reported = variant.eligibleMinutesRemaining.flatMap { $0.isFinite ? max(0, $0) : nil } ?? 0
            let left = ceil(max(max(0, gate - seconds / 60), reported))
            countdown = "\(String(format: "%.0f", left)) min of tuning left at these settings"
            let trades = Double(max(0, variant.wins)) + Double(max(0, variant.losses))
            let lossRate = trades > 0 ? String(format: "%.1f%%", Double(max(0, variant.losses)) / trades * 100) : "No closed trades"
            rows = [
                Row(id: "return", label: "Simulated return", value: variant.isMirror ? "On system Gold capital"
                    : variant.returnPercent.map { String(format: "%.3f%%", $0) } ?? "Unavailable"),
                Row(id: "pnl", label: "Simulated P&L", value: Self.money(variant.paperPnlCents)),
                Row(id: "drawdown", label: "Max drawdown", value: Self.money(variant.maxDrawdownCents)),
                Row(id: "worst", label: "Worst trade", value: Self.money(variant.worstTradeCents)),
                Row(id: "wins", label: "Wins", value: String(variant.wins)),
                Row(id: "losses", label: "Losses", value: String(variant.losses)),
                Row(id: "lossRate", label: "Loss rate", value: lossRate),
                Row(id: "decisions", label: "Decisions", value: String(variant.decisions)),
                Row(id: "capital", label: "Capital basis", value: Self.money(variant.capitalBasisCents)),
                Row(id: "minutes", label: "Minutes at these settings", value: String(format: "%.0f", floor(seconds / 60)))
            ]
        }

        private static func money(_ cents: Double) -> String {
            guard cents.isFinite else { return "Unavailable" }
            return String(format: "%@$%.2f", cents < 0 ? "-" : "", abs(cents) / 100)
        }
    }

    /// The owner's probe control for one engine, read from the runner's lifecycle (plan D8, D9). Pure: no wall
    /// clock, no recomputed breaker, runner text passed through. Fails closed: Probe needs published markets and
    /// no runner ineligibility; Halt is offered only while the engine can enter.
    public struct ProbeControl: Equatable, Sendable {
        public enum Tone: Equatable, Sendable { case neutral, active, warning, stopped }

        public let state: String
        public let tone: Tone
        /// "Breaker: -$12.40 of $1,250.00 (50%) · UTC day", or "Breaker: Not reported".
        public let breaker: String
        public let reasons: [String]
        public let markets: [String]
        public let showsProbe: Bool
        public let canProbe: Bool
        public let probeBlockedReason: String?
        public let canHalt: Bool

        public init(lifecycle: EngineLifecycle?, markets: [String]?, eligibility: ProbeEligibility?, frozen: Bool = false) {
            var unique: [String] = []
            for market in markets ?? [] where !market.isEmpty && !unique.contains(market) && unique.count < 64 {
                unique.append(market)
            }
            self.markets = unique
            breaker = "Breaker: " + ProbePresentation.breakerMeter(lifecycle?.breaker)
            reasons = Array((lifecycle?.stopReasons ?? []).prefix(16).map { reason in
                reason.text.flatMap { $0.isEmpty ? nil : $0 } ?? reason.code
            })
            switch lifecycle?.state {
            case nil:
                state = "Not probing"; tone = .neutral
            case .probe?, .probeSized?:
                if let until = lifecycle?.entriesSuspendedUntil {
                    // A breaker trip suspends entries until 00:00Z; it is not a halt.
                    state = "Suspended until \(ProbeControl.utcClock(until))"; tone = .warning
                } else {
                    state = lifecycle?.label ?? "Probing"; tone = .active
                }
            case .halted?:
                state = lifecycle?.label ?? "Entries halted, settlement only"; tone = .stopped
            case .graduated?, .canary?:
                state = lifecycle?.label ?? "Graduated"; tone = .active
            case let other?:
                state = lifecycle?.label ?? other.rawValue; tone = .neutral
            }
            let lifecycleState = lifecycle?.state
            // The runner's probe preconditions: lifecycle absent, shadow or halted (plan D7).
            let shows = !frozen && (lifecycleState == nil || lifecycleState == .shadow || lifecycleState == .halted)
            var blocked: String?
            if shows && unique.isEmpty {
                blocked = "Markets are not published for this engine."
            } else if shows && eligibility?.eligible == false {
                let listed = (eligibility?.reasons ?? []).prefix(8).filter { !$0.isEmpty }
                blocked = listed.isEmpty ? "The runner reports this engine is not eligible to probe."
                    : listed.joined(separator: " ")
            }
            showsProbe = shows
            probeBlockedReason = blocked
            canProbe = shows && blocked == nil
            canHalt = !frozen && (lifecycleState.map { [EngineLifecycle.State.probe, .probeSized, .graduated, .canary].contains($0) } ?? false)
        }

        static func utcClock(_ date: Date) -> String {
            var calendar = Calendar(identifier: .gregorian)
            calendar.timeZone = TimeZone(identifier: "UTC") ?? calendar.timeZone
            let parts = calendar.dateComponents([.hour, .minute], from: date)
            return String(format: "%02d:%02dZ", parts.hour ?? 0, parts.minute ?? 0)
        }
    }

    /// engine.probe for a 1-contract owner probe. The D7 `approval` field is left for KM5, which mints the signed
    /// single-use token from the owner's presence assertion; until then the server may refuse the row, and the
    /// phone shows requested -> rejected. Fails closed on a non-Risky engine, bad markets or a bad request id.
    public static func probeIntent(engineId: String, markets: [String], now: Date,
                                   clientRequestId: UUID) throws -> ControlIntent {
        guard isEngine(engineId), engineId.range(of: "^[a-z0-9][a-z0-9-]{0,31}$", options: .regularExpression) != nil else {
            throw ControlIntent.ValidationError.invalid("Choose a Risky Batman engine.")
        }
        guard !markets.isEmpty, markets.count <= 64, Set(markets).count == markets.count else {
            throw ControlIntent.ValidationError.invalid("Choose 1 to 64 distinct markets.")
        }
        for market in markets {
            guard !market.isEmpty, market.utf8.count <= 64, !market.contains("="),
                  market.rangeOfCharacter(from: .whitespacesAndNewlines.union(.controlCharacters)) == nil else {
                throw ControlIntent.ValidationError.invalid("A market symbol is invalid.")
            }
        }
        struct Wire: Encodable {
            struct Value: Encodable {
                let engineId: String
                let symbols: [String]
                let expiresAt: String
                let bind: Bool
                enum CodingKeys: String, CodingKey {
                    case engineId = "engine_id", symbols, expiresAt = "expires_at", bind
                }
            }
            let kind: String
            let venue: String
            let clientRequestId: String
            let value: Value
        }
        let expiry = ISO8601DateFormatter().string(from: now.addingTimeInterval(Double(probeWindowDays) * 86_400))
        let wire = Wire(kind: ControlKind.probe.rawValue, venue: "kalshi", clientRequestId: clientRequestId.uuidString,
                        value: .init(engineId: engineId, symbols: markets, expiresAt: expiry, bind: false))
        // ControlIntent keeps a kind's unrecognised body verbatim, so the approval-less body posts exactly as built.
        let intent = try JSONDecoder().decode(ControlIntent.self, from: JSONEncoder().encode(wire))
        guard intent.kind == .probe, intent.clientRequestId == clientRequestId.uuidString else {
            throw ControlIntent.ValidationError.invalid("The probe request could not be built.")
        }
        return intent
    }

    /// engine.halt: unsigned, risk-reducing, never refused for a pending request. Stops new entries only.
    public static func haltIntent(engineId: String, clientRequestId: UUID) throws -> ControlIntent {
        guard isEngine(engineId) else { throw ControlIntent.ValidationError.invalid("Choose a Risky Batman engine.") }
        return try ControlIntent.halt(engineId: engineId, reason: haltReason, clientRequestId: clientRequestId.uuidString)
    }

    /// requested -> applied | rejected, in words. The rejection note is the server's, shown as sent.
    public static func controlMessage(action: String, state: String?, note: String?) -> String {
        let detail = note.flatMap { $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : $0 }
        switch state?.lowercased() {
        case nil, ""?, "requested"?: return "\(action) requested. Waiting for the runner."
        case "applied"?: return "\(action) applied."
        case "rejected"?: return "\(action) rejected. " + (detail ?? "Refresh and try again.")
        case let other?: return "\(action) \(other)." + (detail.map { " " + $0 } ?? "")
        }
    }

    // MARK: The hedge mode (plan v1.9 H2c)

    /// The engine's `reversal_execution_mode`, as the RUNNER reports it; never read back from a request.
    /// Decodes as an optional Int: null or absent is legacy, 1 and 2 are the two modes, and any other value
    /// (another integer, a fraction, a string) is `.unknown`, which renders "Not reported". Fails closed.
    public enum HedgeMode: Codable, Equatable, Hashable, Sendable {
        case legacy
        case hedgeFirst
        case cashoutFirst
        /// The raw integer when the runner sent one this build does not know, else nil.
        case unknown(Int?)

        public static let key = "reversal_execution_mode"
        /// The values the phone may request. Legacy is never requested: an engine never loses a mode silently.
        public static let choices: [HedgeMode] = [.hedgeFirst, .cashoutFirst]

        public init(rawValue: Int?) {
            switch rawValue {
            case nil: self = .legacy
            case 1?: self = .hedgeFirst
            case 2?: self = .cashoutFirst
            case let other?: self = .unknown(other)
            }
        }

        public init(from decoder: Decoder) throws {
            let container = try decoder.singleValueContainer()
            if container.decodeNil() { self = .legacy; return }
            if let number = try? container.decode(Int.self) { self = HedgeMode(rawValue: number); return }
            self = .unknown(nil)
        }

        public func encode(to encoder: Encoder) throws {
            var container = encoder.singleValueContainer()
            if let rawValue { try container.encode(rawValue) } else { try container.encodeNil() }
        }

        public var rawValue: Int? {
            switch self {
            case .legacy: return nil
            case .hedgeFirst: return 1
            case .cashoutFirst: return 2
            case let .unknown(value): return value
            }
        }

        public var isKnown: Bool { if case .unknown = self { return false } else { return true } }

        public var label: String {
            switch self {
            case .legacy: return "Not set"
            case .hedgeFirst: return "Hedge first (entry autosizing)"
            case .cashoutFirst: return "Cash out first"
            case .unknown: return "Not reported"
            }
        }

        /// The one rule each value follows, in the words of the dashboard's hedge mode control.
        public var rule: String {
            switch self {
            case .legacy:
                return "The engine keeps the legacy reversal: one opposite side order nets the position, and entries are sized as before."
            case .hedgeFirst:
                return "Each entry is sized so the entry and its full reversal leg both fit in available cash."
            case .cashoutFirst:
                return "A reversal first sells the whole position, then buys the opposite side, never more than the reversal size."
            case .unknown:
                return "The runner has not reported a hedge mode this app can read."
            }
        }

        /// Accessibility identifier suffix, stable across label copy changes.
        public var slug: String {
            switch self {
            case .legacy: return "legacy"
            case .hedgeFirst: return "hedgeFirst"
            case .cashoutFirst: return "cashoutFirst"
            case .unknown: return "unknown"
            }
        }

        /// Reads the runner's status row from /mobile/engines: the engine controls' global policy first, then the
        /// status policy. The runner omits the key when unset, so a policy without it is legacy; no row or no
        /// policy at all is `.unknown(nil)`, never a guess.
        public static func reported(by runner: LeafHFTCore.Engine?) -> HedgeMode {
            guard let runner, let policy = runner.configuration?.global.policy ?? runner.policy else { return .unknown(nil) }
            guard let value = policy[key] else { return .legacy }
            guard value.isFinite, value.rounded() == value, abs(value) <= 1_000_000 else { return .unknown(nil) }
            return HedgeMode(rawValue: Int(value))
        }

        /// The assignment rule (I4): the owner may change any engine; a tenant only an engine assigned to its lane.
        public static func canChange(isOwner: Bool, laneId: String?, assignment: EngineAssignment?) -> Bool {
            if isOwner { return true }
            guard let laneId, !laneId.isEmpty, let assigned = assignment?.accountId, !assigned.isEmpty else { return false }
            return assigned == laneId
        }
    }

    /// engine.configure setting only `reversal_execution_mode`, through the kind's exact body
    /// (`EngineConfigureValue`, decoded by kind). Fails closed on a non-Risky engine, a legacy or unknown mode,
    /// a missing host or revision, or a malformed scope.
    public static func hedgeModeIntent(engineId: String, mode: HedgeMode, host: String, scope: ControlScope,
                                       expectedRevision: String, clientRequestId: UUID) throws -> ControlIntent {
        guard isEngine(engineId), engineId.range(of: "^[a-z0-9][a-z0-9-]{0,31}$", options: .regularExpression) != nil else {
            throw ControlIntent.ValidationError.invalid("Choose a Risky Batman engine.")
        }
        guard HedgeMode.choices.contains(mode), let raw = mode.rawValue else {
            throw ControlIntent.ValidationError.invalid("Choose Hedge first or Cash out first.")
        }
        guard !host.isEmpty, host.utf8.count <= 128, host.rangeOfCharacter(from: .controlCharacters) == nil else {
            throw ControlIntent.ValidationError.invalid("The runner host is unavailable.")
        }
        guard !expectedRevision.isEmpty, expectedRevision.utf8.count <= 128,
              expectedRevision.rangeOfCharacter(from: .controlCharacters) == nil else {
            throw ControlIntent.ValidationError.invalid("The current runner version is unavailable.")
        }
        switch scope.kind {
        case .global:
            guard scope.accountId == nil else { throw ControlIntent.ValidationError.invalid("The global scope cannot name an account.") }
        case .account:
            guard let id = scope.accountId, ControlScope.validAccountId(id), id != "unassigned" else {
                throw ControlIntent.ValidationError.invalid("Choose a configurable account.")
            }
        }
        struct Wire: Encodable {
            let kind: String
            let value: EngineConfigureValue
            let host: String
            let venue: String
            let scope: ControlScope
            let clientRequestId: String
            let expectedRevision: String
        }
        let value = EngineConfigureValue(engineId: engineId, set: [HedgeMode.key: Double(raw)], unset: nil,
                                         enabledChange: .unchanged)
        let wire = Wire(kind: ControlKind.configure.rawValue, value: value, host: host, venue: "kalshi", scope: scope,
                        clientRequestId: clientRequestId.uuidString, expectedRevision: expectedRevision)
        // Decoding by kind yields the typed configure body; anything else means the body was not built as sent.
        let intent = try JSONDecoder().decode(ControlIntent.self, from: JSONEncoder().encode(wire))
        guard intent.kind == .configure, intent.value == .configure(value),
              intent.clientRequestId == clientRequestId.uuidString else {
            throw ControlIntent.ValidationError.invalid("The hedge mode request could not be built.")
        }
        return intent
    }
}
