import Foundation

public struct ServerAccountSnapshot: Codable, Equatable {
    public enum Source: String, Codable {
        case venueSnapshot = "venue_snapshot"
        case laneCash = "lane_cash"
        case unknown

        public init(from decoder: Decoder) throws {
            let value = try decoder.singleValueContainer().decode(String.self)
            self = Source(rawValue: value) ?? .unknown
        }
    }

    public let source: Source
    public let observedAt: String
    public let cashCents: Int
    public let portfolioValueCents: Int?
    public let positions: [Position]?
    public let positionsComplete: Bool

    public var observedDate: Date? {
        let parser = ISO8601DateFormatter()
        parser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = parser.date(from: observedAt) { return date }
        parser.formatOptions = [.withInternetDateTime]
        return parser.date(from: observedAt)
    }
}

public enum DirectAccountFailure: Equatable {
    case transport, unauthorized, noCredential, rateLimited, http, decoding
}

public enum AccountFallbackDecision: Equatable {
    case keepDirect
    case useServer(balance: AccountBalance, positions: [Position]?, observedAt: Date)
}

public enum AccountFallback {
    public static func decide(directFailure: DirectAccountFailure?, snapshot: ServerAccountSnapshot?,
                              now: Date, maxAge: TimeInterval = 1800) -> AccountFallbackDecision {
        guard directFailure == .transport, let snapshot, let observedAt = snapshot.observedDate,
              observedAt.timeIntervalSince(now) <= 60,
              now.timeIntervalSince(observedAt) <= maxAge else { return .keepDirect }
        let balance = AccountBalance(balance: snapshot.cashCents, portfolioValue: snapshot.portfolioValueCents)
        return .useServer(balance: balance, positions: snapshot.positions, observedAt: observedAt)
    }
}
