import Foundation

public struct KalshiMarket: Codable, Equatable, Sendable {
    public var ticker: String
    public var status: String?
    public var result: String?
    public var closeTime: String?
    public var yesBidDollars: String?
    public var yesAskDollars: String?
    public var noBidDollars: String?
    public var noAskDollars: String?
    public var lastPriceDollars: String?
    public var settlementValueDollars: String?
}

public struct PositionMarksMarketsResponse: Codable, Sendable {
    public var markets: [KalshiMarket]?
    public var cursor: String?
}

public enum MarkBasis: String, Sendable { case live, frozen, settled, cost }

public struct MarkedPortfolio: Equatable, Sendable {
    public var cashCents: Int
    public var openCents: Int
    public var totalCents: Int
    public var counts: [MarkBasis: Int]
    public var unpriced: Int
}

public enum PositionMarks {
    // Decimal(string:) accepts numeric prefixes; validate the whole string first.
    private static func decimal(_ text: String?) -> Decimal? {
        guard let text,
              text.range(of: #"^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)$"#,
                         options: .regularExpression) != nil,
              let value = Decimal(string: text, locale: Locale(identifier: "en_US_POSIX")),
              !value.isNaN else { return nil }
        return value
    }

    private static func price(_ text: String?) -> Decimal? {
        guard let value = decimal(text), value >= 0, value <= 1 else { return nil }
        return value * 100
    }

    private static func closeDate(_ text: String?) -> Date? {
        guard let text else { return nil }
        let parser = ISO8601DateFormatter()
        parser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = parser.date(from: text) { return date }
        parser.formatOptions = [.withInternetDateTime]
        return parser.date(from: text)
    }

    public static func perContractMark(sideYes: Bool, costPerContractCents: Decimal,
                                       market: KalshiMarket?, now: Date) -> (cents: Decimal, basis: MarkBasis) {
        guard let market else { return (costPerContractCents, .cost) }
        if let result = market.result, !result.isEmpty {
            if result == "yes" || result == "no" {
                return ((result == "yes") == sideYes ? 100 : 0, .settled)
            }
            if let yes = price(market.settlementValueDollars) {
                return (sideYes ? yes : 100 - yes, .settled)
            }
        }
        let last = price(market.lastPriceDollars).map { sideYes ? $0 : 100 - $0 }
        let closed = ["closed", "determined", "finalized", "settled"].contains(market.status ?? "")
            || (closeDate(market.closeTime).map { now >= $0 } ?? false)
        if closed { return (last ?? costPerContractCents, .frozen) }
        let bid = price(sideYes ? market.yesBidDollars : market.noBidDollars)
        let ask = price(sideYes ? market.yesAskDollars : market.noAskDollars)
        if let bid, let ask, bid > 0, bid <= ask, ask < 100 {
            return ((bid + ask) / 2, .live)
        }
        if let bid, bid > 0 { return (bid, .live) }
        return (last ?? costPerContractCents, .live)
    }

    public static func marked(cashCents: Int, positions: [Position],
                              markets: [String: KalshiMarket], now: Date) -> MarkedPortfolio {
        var open: Decimal = 0
        var counts: [MarkBasis: Int] = [:]
        var unpriced = 0
        for position in positions {
            guard let signedCount = decimal(position.positionFp) else { unpriced += 1; continue }
            guard signedCount != 0 else { continue }
            let count = signedCount > 0 ? signedCount : -signedCount
            let exposure = decimal(position.marketExposureDollars).flatMap { $0 >= 0 ? $0 : nil }
            if exposure == nil { unpriced += 1 }
            // A missing cost contributes zero only when the market also cannot price it.
            let cost = exposure.map { $0 * 100 / count } ?? 0
            let mark = perContractMark(sideYes: signedCount > 0, costPerContractCents: cost,
                                       market: markets[position.ticker], now: now)
            counts[mark.basis, default: 0] += 1
            open += mark.cents * count
        }
        var rounded = Decimal()
        NSDecimalRound(&rounded, &open, 0, .plain)
        let openCents = NSDecimalNumber(decimal: rounded).intValue
        return MarkedPortfolio(cashCents: cashCents, openCents: openCents,
                               totalCents: cashCents + openCents, counts: counts, unpriced: unpriced)
    }
}
