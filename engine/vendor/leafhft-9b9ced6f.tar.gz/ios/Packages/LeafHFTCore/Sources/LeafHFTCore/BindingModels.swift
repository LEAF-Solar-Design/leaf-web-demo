import Foundation
import CryptoKit

public enum AccountReadability: String, Codable, Sendable {
    case unknown, readable, unavailable
    public var label: String {
        switch self {
        case .unknown: return "Not checked"
        case .readable: return "Readable on this phone"
        case .unavailable: return "Could not read account"
        }
    }
}

public enum DashboardPairingState: String, Codable, Sendable {
    case unknown, unpaired, paired
    public var label: String {
        switch self {
        case .unknown: return "Not checked"
        case .unpaired: return "Not paired"
        case .paired: return "Paired"
        }
    }
}

public enum AutomatedTradingState: String, Codable, Sendable {
    case notConfigured = "not_configured"
    case credentialRequired = "credential_required"
    case provisioning, dryRun = "dry_run", ready, live, paused, failed, revoked
    case livePending = "live_pending"
    case error, unknown

    public init(from decoder: Decoder) throws {
        let value = try decoder.singleValueContainer().decode(String.self)
        self = Self(rawValue: value) ?? .unknown
    }

    public var label: String {
        switch self {
        case .notConfigured: return "Not configured"
        case .credentialRequired: return "Credential required"
        case .provisioning: return "Preparing your account"
        case .dryRun: return "Dry run only"
        case .ready: return "Ready"
        case .live: return "Live trading enabled"
        case .livePending: return "Starting live trading"
        case .error: return "Runner error"
        case .unknown: return "Status not recognized"
        case .failed: return "Setup needs attention"
        case .paused: return "Paused"
        case .revoked: return "Revoked"
        }
    }
}

public enum AccountBindingState: String, Codable, Sendable { case bound, unbound }

public enum KashbotRunnerAction: String, Codable, CaseIterable, Sendable {
    case startDryRun = "start_dry_run"
    case startLive = "start_live"
    case pause, revoke
}

public struct KashbotRunnerActionRequest: Encodable, Sendable {
    public let clientRequestId: String
    public let action: KashbotRunnerAction
    public let presence: KashbotDomainPresence?
    public let expectGeneration: Int64?

    public init(clientRequestId: UUID, action: KashbotRunnerAction,
                presence: KashbotDomainPresence? = nil, expectGeneration: Int64? = nil) {
        self.clientRequestId = clientRequestId.uuidString.lowercased()
        self.action = action
        self.presence = presence
        self.expectGeneration = expectGeneration
    }
}

public struct KashbotDomainPresence: Encodable, Equatable, Sendable {
    public let assertion: String
    public let plan: String

    public init(assertion: String, plan: String) {
        self.assertion = assertion
        self.plan = plan
    }
}

/// Additive owner telemetry. Missing fields never grant a control capability.
public struct KashbotExecution: Decodable, Equatable, Sendable {
    public let schema: Int?
    public let domain: String?
    public let memberKey: String?
    public let host: String?
    public let observedAt: Date?
    public let summary: String?
    public let pause: Pause?
    public let pendingRequest: PendingRequest?
    public let counts: Counts?
    public let books: [Book]?
    public let lossBreaker: [String: Value]?
    public let capabilities: Capabilities?

    /// The breaker object is additive and has no frozen inner keys in v1.
    public indirect enum Value: Decodable, Equatable, Sendable {
        case null, bool(Bool), number(Double), string(String), array([Value]), object([String: Value])

        public init(from decoder: Decoder) throws {
            let container = try decoder.singleValueContainer()
            if container.decodeNil() { self = .null }
            else if let value = try? container.decode(Bool.self) { self = .bool(value) }
            else if let value = try? container.decode(Double.self) { self = .number(value) }
            else if let value = try? container.decode(String.self) { self = .string(value) }
            else if let value = try? container.decode([Value].self) { self = .array(value) }
            else { self = .object(try container.decode([String: Value].self)) }
        }
    }

    public struct Pause: Decodable, Equatable, Sendable {
        public let state: String?
        public let generation: Int64?
        public let pausedAt: Date?
        public let resumedAt: Date?
        public let requestedBy: String?
        public let requestId: String?
        public let resumeNonce: String?
    }

    public struct PendingRequest: Decodable, Equatable, Sendable {
        public let id: String?
        public let kind: String?
        public let state: String?
        public let note: String?
        public let requestedAt: Date?
    }

    public struct Counts: Decodable, Equatable, Sendable {
        public let expected: Int?
        public let running: Int?
        public let entryEnabled: Int?
        public let halted: Int?
        public let missing: Int?
    }

    public struct Book: Decodable, Equatable, Sendable {
        public let bookId: String?
        public let runId: String?
        public let heartbeatAt: Date?
        public let fresh: Bool?
        public let observedPauseGeneration: Int64?
        public let entryEnabled: Bool?
        public let blockers: [String]?
    }

    public struct Capabilities: Decodable, Equatable, Sendable {
        public let ownerDomainControl: Bool?
        public let pause: Bool?
        public let resume: Bool?
        public let resumeRequiresPresence: Bool?
    }

    public var summaryLabel: String {
        switch summary {
        case "running": return "Running"
        case "halted": return "Halted"
        case "degraded": return "Degraded"
        default: return "Unavailable"
        }
    }

    public var pendingLabel: String? {
        guard let pendingRequest else { return nil }
        switch pendingRequest.kind {
        case "domain.pause": return "Pausing"
        case "domain.resume": return "Resuming"
        default: return "Waiting for owner status"
        }
    }
}

public struct KashbotTenant: Decodable, Equatable, Sendable {
    public let id: String
    public let runnerHost: String?
}

public struct KashbotLane: Decodable, Equatable, Sendable {
    public let id: String
    public let state: AutomatedTradingState?
    public let killRequested: Bool?
    public let liveEnabled: Bool?
}

public struct KashbotRunnerRequest: Decodable, Equatable, Sendable {
    public let id: String
    public let clientRequestId: String
    public let action: KashbotRunnerAction
    public let state: String
    public let requestedAt: Date
}

public struct KashbotRunnerResponse: Decodable, Sendable {
    public let request: KashbotRunnerRequest
}

public struct KashbotRiskRegime: Decodable, Equatable, Sendable {
    public let id: String
    public let label: String
}

public struct KashbotStatus: Decodable, Equatable, Sendable {
    public let dashboardPairing: DashboardPairingState
    public let accountBinding: AccountBindingState
    public let automatedTrading: AutomatedTradingState
    public let tenant: KashbotTenant?
    public let lane: KashbotLane?
    public let request: KashbotRunnerRequest?
    public let riskRegime: KashbotRiskRegime?
    public let execution: KashbotExecution?
    public let shadowCapital: ShadowCapitalView?
    public var isOwnerExecution: Bool { execution?.capabilities?.ownerDomainControl == true }
    public var needsEnrollment: Bool {
        !isOwnerExecution && isBound && (automatedTrading == .notConfigured || automatedTrading == .credentialRequired)
    }

    public var isBound: Bool { accountBinding == .bound && tenant != nil && dashboardPairing == .paired }
    // Missing flags or contradictory lane/status states never grant a capability.
    public var hasActionableLane: Bool {
        isBound && tenant.map { UUID(uuidString: $0.id) != nil } == true &&
        lane.map { UUID(uuidString: $0.id) != nil && $0.state == automatedTrading &&
            $0.killRequested != nil && $0.liveEnabled != nil } == true
    }
    public func allows(_ action: KashbotRunnerAction) -> Bool {
        if isOwnerExecution {
            switch action {
            case .pause: return execution?.capabilities?.pause == true
            case .startLive: return execution?.capabilities?.resume == true
            case .startDryRun, .revoke: return false
            }
        }
        guard hasActionableLane else { return false }
        switch action {
        case .startDryRun:
            return automatedTrading == .ready && lane?.liveEnabled == false
        case .startLive:
            return automatedTrading == .dryRun && lane?.killRequested == false && lane?.liveEnabled == false
        case .pause:
            // Pause is the stop control; the server accepts it in these states regardless of liveEnabled.
            return [.live, .livePending, .error, .unknown].contains(automatedTrading)
        case .revoke:
            return ![.revoked, .notConfigured, .credentialRequired].contains(automatedTrading)
        }
    }
    public var automationLabel: String {
        if isOwnerExecution { return execution?.summaryLabel ?? "Unavailable" }
        return isBound ? automatedTrading.label : AutomatedTradingState.notConfigured.label
    }
}

extension KashbotStatus {
    private enum CodingKeys: String, CodingKey {
        case dashboardPairing, accountBinding, automatedTrading, tenant, lane, request
        case riskRegime, execution, shadowCapital
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        dashboardPairing = try container.decode(DashboardPairingState.self, forKey: .dashboardPairing)
        accountBinding = try container.decode(AccountBindingState.self, forKey: .accountBinding)
        automatedTrading = try container.decode(AutomatedTradingState.self, forKey: .automatedTrading)
        tenant = try container.decodeIfPresent(KashbotTenant.self, forKey: .tenant)
        lane = try container.decodeIfPresent(KashbotLane.self, forKey: .lane)
        request = try container.decodeIfPresent(KashbotRunnerRequest.self, forKey: .request)
        riskRegime = try container.decodeIfPresent(KashbotRiskRegime.self, forKey: .riskRegime)
        execution = try container.decodeIfPresent(KashbotExecution.self, forKey: .execution)
        // Additive telemetry must not prevent the rest of the account status from decoding.
        shadowCapital = try? container.decodeIfPresent(ShadowCapitalView.self, forKey: .shadowCapital)
    }
}

public struct KashbotBindResponse: Decodable, Sendable {
    public let tenantId: String
    public let runnerHost: String
    public let automatedTrading: AutomatedTradingState
}

public enum BindingMessageError: Error { case invalidChallenge, invalidKeyID, expired }

/// Public runner key delivered over the authenticated, pinned dashboard origin.
public struct AccountEnrollmentKey: Decodable, Sendable {
    public let enrollmentKeyId: String
    public let publicKeyDer: String
    public let algorithm: String
    public let expiresAt: Date?
}

/// Only this sealed envelope can be passed to the enrollment endpoint.
public struct SealedAccountCredential: Codable, Equatable, Sendable {
    public let enrollmentKeyId: String
    public let algorithm: String
    public let wrappedKey: String
    public let nonce: String
    public let ciphertext: String

    public init(enrollmentKeyId: String, wrappedKey: String, nonce: String, ciphertext: String) {
        self.enrollmentKeyId = enrollmentKeyId
        self.algorithm = "RSA-OAEP-256+A256GCM"
        self.wrappedKey = wrappedKey
        self.nonce = nonce
        self.ciphertext = ciphertext
    }
}

public struct AccountEnrollmentRequest: Codable, Equatable, Sendable {
    public let clientRequestId: String
    public let enrollmentKeyId: String
    public let algorithm: String
    public let wrappedKey: String
    public let nonce: String
    public let ciphertext: String

    public init(clientRequestId: UUID, credential: SealedAccountCredential) {
        self.clientRequestId = clientRequestId.uuidString.lowercased()
        self.enrollmentKeyId = credential.enrollmentKeyId
        self.algorithm = credential.algorithm
        self.wrappedKey = credential.wrappedKey
        self.nonce = credential.nonce
        self.ciphertext = credential.ciphertext
    }
}

public struct BindingChallenge: Decodable, Sendable {
    public let challengeId: String
    public let deviceId: String
    public let challenge: String
    public let challengeHash: String
    public let expiresAt: Date
    public let bindingVersion: String

    public func canonicalMessage(keyID: String, publicKeyDER: Data, now: Date = Date()) throws -> Data {
        guard expiresAt > now else { throw BindingMessageError.expired }
        guard bindingVersion == "kashbot-bind-v1",
              UUID(uuidString: challengeId) != nil, UUID(uuidString: deviceId) != nil,
              (1...128).contains(challenge.utf8.count),
              challengeHash == Self.sha256(Data(challenge.utf8)),
              (256...1536).contains(publicKeyDER.count) else { throw BindingMessageError.invalidChallenge }
        let normalized = try Self.normalizedKeyID(keyID)
        // Server v1: six UTF-8 fields separated by LF, without a final LF.
        return Data([bindingVersion, challengeId.lowercased(), deviceId.lowercased(), challengeHash,
                     normalized, Self.sha256(publicKeyDER)].joined(separator: "\n").utf8)
    }

    public static func normalizedKeyID(_ value: String) throws -> String {
        let normalized = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard value.count <= 128, normalized.range(of: "^[a-z0-9_-]{1,128}$", options: .regularExpression) != nil else {
            throw BindingMessageError.invalidKeyID
        }
        return normalized
    }

    private static func sha256(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }
}

public struct BindingRequest: Encodable, Sendable {
    public let challengeId: String
    public let keyId: String
    public let publicKeyDer: String
    public let signature: String

    public init(challengeId: String, keyId: String, publicKeyDer: String, signature: String) {
        self.challengeId = challengeId.lowercased()
        self.keyId = keyId
        self.publicKeyDer = publicKeyDer
        self.signature = signature
    }
}
