import Foundation

/// Distinguishes unavailable data from an observed empty result or a retained value.
public enum Reported<Value: Equatable & Sendable>: Equatable, Sendable {
    case notReported(reason: String)
    case empty(observedAt: Date)
    case value(Value, observedAt: Date)
}

/// Field mapping and presentation state shared by the operations monitor.
public enum MonitorPresentation {
    public static let notReported = "Not reported"

    /// A missing timestamp means no successful read, even if items are present.
    /// After a successful read, errors retain the last items and observation time.
    public static func list<T: Equatable & Sendable>(
        _ items: [T], observedAt: Date?, error: String?, missing reason: String
    ) -> Reported<[T]> {
        guard let observedAt else { return .notReported(reason: error ?? reason) }
        if items.isEmpty && error == nil { return .empty(observedAt: observedAt) }
        return .value(items, observedAt: observedAt)
    }

    /// Age and availability of one named feed.
    public struct FeedAge: Equatable, Sendable {
        public enum State: String, Sendable { case fresh, aging, dead, absent }
        public let name: String
        public let ageSeconds: Double?
        public let state: State

        public init(name: String, ageSeconds: Double?, state: State) {
            self.name = name
            self.ageSeconds = ageSeconds
            self.state = state
        }
    }

    /// Fresh is strictly below freshUnder; dead starts at deadPast.
    /// Future timestamps have zero elapsed age, matching the shared freshness formatter.
    public static func feedAge(
        name: String, observedAt: Date?, now: Date,
        freshUnder: TimeInterval = 90, deadPast: TimeInterval = 600
    ) -> FeedAge {
        guard let observedAt else { return FeedAge(name: name, ageSeconds: nil, state: .absent) }
        let age = max(0, now.timeIntervalSince(observedAt))
        let state: FeedAge.State = age >= deadPast ? .dead : (age < freshUnder ? .fresh : .aging)
        return FeedAge(name: name, ageSeconds: age, state: state)
    }

    /// Keeps feed readability, pairing, runner freshness, and automation distinct.
    public struct Alive: Equatable, Sendable {
        public let readable: FeedAge
        public let paired: Bool?
        public let runner: FeedAge
        public let automated: String?

        public init(readable: FeedAge, paired: Bool?, runner: FeedAge, automated: String?) {
            self.readable = readable
            self.paired = paired
            self.runner = runner
            self.automated = automated
        }
    }

    /// Cash plus the venue's open-position mark, never cash plus total account value.
    /// portfolioValue excludes cash and is the open component of accountValue.
    public static func portfolioCaption(balance: AccountBalance?) -> String {
        let cash = balance?.cash?.formatted() ?? notReported
        let open = balance?.positionsMark?.formatted() ?? notReported
        return "cash at venue \(cash) + open \(open) at venue value"
    }
}

public enum BookEntryHold: Equatable, Sendable {
    case bookPaused, entriesOff
}

extension MonitorPresentation {
    public static let bookPaused = "Book paused"
    public static let entriesOff = "Entries off"
    public static let allBooksPaused = "All books paused"
    public static let engineDisabledGate = "skip_engine_disabled"

    public static func entryHold(bookEnabled: Bool?, gate: String?) -> BookEntryHold? {
        guard gate == engineDisabledGate else { return nil }
        return bookEnabled == false ? .bookPaused : .entriesOff
    }

    public static func chipHold(bookEnabled: Bool?, candidate: Candidate) -> BookEntryHold? {
        guard candidate.intentSent != true else { return nil }
        return entryHold(bookEnabled: bookEnabled, gate: candidate.gate)
    }

    public static func entryHold(book: Book) -> BookEntryHold? {
        guard let candidates = book.kalshiBook.eval?.candidates, !candidates.isEmpty,
              candidates.allSatisfy({ $0.gate == engineDisabledGate }) else { return nil }
        return book.enabled == false ? .bookPaused : .entriesOff
    }

    public static func holdCopy(_ hold: BookEntryHold) -> String {
        switch hold {
        case .bookPaused: return bookPaused
        case .entriesOff: return entriesOff
        }
    }

    public static func field(_ reported: String?, hold: BookEntryHold?, missing: String = notReported) -> String {
        reported ?? hold.map(holdCopy) ?? missing
    }

    public static func clock(seconds: Double?) -> String? {
        guard let seconds, seconds.isFinite, abs(seconds) < Double(Int.max / 2) else { return nil }
        let value = Int(max(0, seconds).rounded(.up))
        return String(format: "%d:%02d", value / 60, value % 60)
    }

    public static func centsText(_ value: Double?) -> String? {
        guard let value, value.isFinite else { return nil }
        return String(format: "%.1f¢", value)
    }

    public enum NextClose: Equatable, Sendable {
        case seconds(Double), allPaused(books: Int), entriesOff, notReported
    }

    public static func nextClose(books: [Book]) -> NextClose {
        var nearest: Double?
        var allHeld = !books.isEmpty
        var allPaused = !books.isEmpty
        for book in books {
            let candidates = book.kalshiBook.eval?.candidates ?? []
            var bookHeld = !candidates.isEmpty
            for candidate in candidates {
                if candidate.gate != engineDisabledGate { bookHeld = false }
                if let seconds = candidate.secondsToClose, seconds.isFinite, seconds >= 0,
                   nearest.map({ seconds < $0 }) ?? true {
                    nearest = seconds
                }
            }
            allHeld = allHeld && bookHeld
            allPaused = allPaused && bookHeld && book.enabled == false
        }
        if let nearest { return .seconds(nearest) }
        if allPaused { return .allPaused(books: books.count) }
        if allHeld { return .entriesOff }
        return .notReported
    }

    public static func nextCloseText(_ value: NextClose) -> String {
        switch value {
        case let .seconds(seconds): return clock(seconds: seconds) ?? notReported
        case let .allPaused(books): return books == 1 ? bookPaused : allBooksPaused
        case .entriesOff: return entriesOff
        case .notReported: return notReported
        }
    }
}

public struct BookCandidateCells: Equatable, Sendable {
    public let hold: BookEntryHold?
    public let side: String
    public let observations: String
    public let edge: String
    public let closes: String

    public init(book: Book, candidate: Candidate, missing: String = MonitorPresentation.notReported) {
        hold = MonitorPresentation.entryHold(bookEnabled: book.enabled, gate: candidate.gate)
        let minK = book.kalshiBook.eval?.minK.map(String.init) ?? "?"
        side = MonitorPresentation.field(candidate.sideYes.map { $0 ? "YES" : "NO" }, hold: hold, missing: missing)
        if let k = candidate.k {
            observations = "\(k) of \(minK)"
        } else {
            observations = hold.map(MonitorPresentation.holdCopy) ?? "? of \(minK)"
        }
        let reportedEdge = MonitorPresentation.centsText(candidate.edgeCents)
        let requiredEdge = MonitorPresentation.centsText(candidate.edgeRequiredCents)
        if reportedEdge == nil, requiredEdge == nil, let hold {
            edge = MonitorPresentation.holdCopy(hold)
        } else {
            edge = "\(MonitorPresentation.field(reportedEdge, hold: hold, missing: missing)) / \(MonitorPresentation.field(requiredEdge, hold: hold, missing: missing))"
        }
        closes = MonitorPresentation.field(MonitorPresentation.clock(seconds: candidate.secondsToClose), hold: hold, missing: missing)
    }
}
