import Foundation

/// Read-only presentation inputs. Missing evidence never establishes trading activity.
public enum PeopleCards {
    public static let sixHours: TimeInterval = 6 * 60 * 60

    /// The mobile people route returns the same evidence wrappers as the owner people route.
    /// Decode only inputs this presentation supports; do not infer live provenance from recorded activity.
    public struct Response: Decodable {
        public let generatedAt: Date
        public let people: [Person]

        private enum CodingKeys: String, CodingKey { case generatedAt, people, sections }
        public init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            let generatedAt = try values.decode(Date.self, forKey: .generatedAt)
            self.generatedAt = generatedAt
            let sections = try values.decode(WireSections.self, forKey: .sections)
            let rows = try values.decode([WirePerson].self, forKey: .people)
            people = rows.map { $0.person(at: generatedAt, sections: sections) }
        }
    }

    private struct WireEvidence<Value: Decodable>: Decodable {
        let value: Value?
        let observedAt: Date?

        private enum CodingKeys: String, CodingKey { case value, observedAt }
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            value = try values.decodeIfPresent(Value.self, forKey: .value)
            let suppliedAt = try values.decodeIfPresent(Date.self, forKey: .observedAt)
            observedAt = value == nil ? nil : suppliedAt
        }
    }

    private struct WireSection: Decodable {
        let available: Bool
        let truncated: Bool
        var complete: Bool { available && !truncated }
    }

    private struct WireSections: Decodable {
        let roster: WireSection
        let assignments: WireSection
        let controls: WireSection
        var sharingComplete: Bool { roster.complete && assignments.complete && controls.complete }
    }

    private struct WireActivity: Decodable {
        let lastRecordedAt: WireEvidence<Date>
        let observed24h: WireEvidence<Double>
        let observed7d: WireEvidence<Double>
        let exact24h: WireEvidence<Double>
        let exact7d: WireEvidence<Double>
        // DashboardClient converts observed_24h to observed24H (likewise for 7d).
        private enum CodingKeys: String, CodingKey {
            case lastRecordedAt
            case observed24h = "observed24H"
            case observed7d = "observed7D"
            case exact24h = "exact24H"
            case exact7d = "exact7D"
        }
        var activity: Activity {
            Activity(recorded24h: observed24h.value, recorded7d: observed7d.value,
                total24h: exact24h.value, total7d: exact7d.value,
                observedAt: observedAt)
        }
        private var observedAt: Date? {
            // Activity primary: observed24h; otherwise use the latest known count evidence.
            if observed24h.value != nil { return observed24h.observedAt }
            return [observed7d.observedAt, exact24h.observedAt, exact7d.observedAt]
                .compactMap { $0 }.max()
        }
        var execution: ExecutionEvidence {
            ExecutionEvidence(time: lastRecordedAt.value, observedAt: lastRecordedAt.observedAt, provenance: .unknown)
        }
    }

    private struct WireMoney: Decodable {
        let currentCashCents: WireEvidence<Double>
        let activationBudgetCashCents: WireEvidence<Double>
        let reportedPerBookStakeCents: WireEvidence<Double>
        let reportedTurnoverUsedCents: WireEvidence<Double>
        let reportedCapCents: WireEvidence<Double>
        private var observedAt: Date? {
            // Funds primary: currentCashCents; otherwise use the latest known money evidence.
            if currentCashCents.value != nil { return currentCashCents.observedAt }
            return [activationBudgetCashCents.observedAt, reportedPerBookStakeCents.observedAt,
                reportedTurnoverUsedCents.observedAt, reportedCapCents.observedAt].compactMap { $0 }.max()
        }
        var funds: Funds {
            Funds(currentCash: PeopleCards.money(currentCashCents.value),
                activationBudgetCash: PeopleCards.money(activationBudgetCashCents.value),
                reportedStake: PeopleCards.money(reportedPerBookStakeCents.value),
                turnoverUsed: PeopleCards.money(reportedTurnoverUsedCents.value),
                reportedCap: PeopleCards.money(reportedCapCents.value), observedAt: observedAt)
        }
    }

    private static func money(_ cents: Double?) -> Money? {
        cents.map { Money($0 / 100, currency: "USD") }
    }

    private struct WirePerson: Decodable {
        struct LaneInput: Decodable {
            let state: String?
            let revokedAt: Date?
            let killRequested: Bool?
        }
        struct ActivityInput: Decodable { let orders: WireActivity; let fills: WireActivity }
        struct RefusalInput: Decodable { let dominant: WireEvidence<String> }
        struct EnginesInput: Decodable { let available: Bool; let truncated: Bool; let items: [WireEngine] }
        let laneId: String
        let accountId: String?
        let label: String
        let lane: LaneInput
        let activity: ActivityInput
        let refusal: RefusalInput
        let money: WireMoney
        let engines: EnginesInput

        func person(at now: Date, sections: WireSections) -> Person {
            let state: LaneState
            switch lane.state {
            case "live"?: state = .live
            case "paused"?: state = .paused
            case nil: state = .unknown
            default: state = .nonLive
            }
            let cards = engines.items.compactMap { engine -> EngineCard? in
                guard let accountId, !accountId.isEmpty, engine.accountId == accountId else { return nil }
                return engine.card(accountID: accountId, at: now,
                    sharingComplete: sections.sharingComplete && engines.available && !engines.truncated)
            }
            return Person(id: laneId, laneID: laneId, accountID: accountId ?? "", label: label,
                lane: Lane(state: state, revoked: lane.revokedAt.map { _ in true }, killRequested: lane.killRequested,
                    observedAt: lane.state == nil ? nil : now,
                    refusal: Refusal(reason: refusal.dominant.value, observedAt: refusal.dominant.observedAt),
                    lastOrder: activity.orders.execution, lastFill: activity.fills.execution),
                orders: activity.orders.activity, fills: activity.fills.activity, funds: money.funds, engines: cards)
        }
    }

    private struct WireEngine: Decodable {
        struct SharingInput: Decodable {
            struct Other: Decodable { let accountId: String; let label: String }
            let status: String
            let truncated: Bool
            let others: [Other]
        }
        struct PerformanceInput: Decodable {
            struct Day: Decodable {
                let utcDay: String
                let observed: Bool
                let realizedCents: WireEvidence<Double>
                let entries: WireEvidence<Double>
                let settled: WireEvidence<Double>
                let exits: WireEvidence<Double>
                let won: WireEvidence<Double>
                let lost: WireEvidence<Double>
                let voided: WireEvidence<Double>
                var metrics: Metrics {
                    Metrics(realized: PeopleCards.money(realizedCents.value), entries: entries.value,
                        settled: settled.value, exits: exits.value, won: won.value, lost: lost.value, voided: voided.value)
                }
                var observedAt: Date? {
                    // PerformanceDay primary: realizedCents; otherwise use the latest known metric evidence.
                    if realizedCents.value != nil {
                        return realizedCents.observedAt
                    }
                    return [entries.observedAt, settled.observedAt, exits.observedAt,
                        won.observedAt, lost.observedAt, voided.observedAt].compactMap { $0 }.max()
                }
            }
            let days: [Day]
        }
        let engineId: String
        let accountId: String?
        let assignment: WireEvidence<String>
        let sharing: SharingInput
        let performance: PerformanceInput

        func card(accountID: String, at now: Date, sharingComplete: Bool) -> EngineCard {
            let status: SharingStatus
            switch sharing.status {
            case "shared": status = .shared
            case "not_shared": status = sharingComplete && !sharing.truncated ? .notShared : .unknown
            default: status = .unknown
            }
            let rows = performance.days.filter(\.observed).map {
                PerformanceRow(accountID: accountID, engineID: engineId, dateSlot: $0.utcDay,
                    observedAt: $0.observedAt, metrics: $0.metrics)
            }
            return EngineCard(id: engineId, name: engineId, assignment: assignment.value ?? "unknown",
                sharing: Sharing(status: status,
                    others: status == .shared ? sharing.others.map { SharingAccount(accountID: $0.accountId, label: $0.label) } : [],
                    evidenceComplete: sharingComplete && !sharing.truncated),
                performance: PeopleCards.performance(accountID: accountID, engineID: engineId,
                    dateSlots: performance.days.map(\.utcDay), dateBasis: "Calendar date slots as supplied by the server",
                    rows: rows, now: now))
        }
    }

    public enum Verdict: String, Equatable { case off = "Off", blocked = "Blocked", trading = "Trading", idle = "Idle", unknown = "Unknown" }
    public enum LaneState: String, Equatable { case live, paused, nonLive = "non-live", unknown }
    public enum Execution: String, Equatable { case live, paper, unknown }
    public enum ReadStatus: Equatable { case complete, incomplete, unavailable, failed }

    /// Fractional values are retained. Invalid numeric input remains missing, never zero.
    public struct Quantity: Equatable {
        public let value: Double?
        public init(_ value: Double? = nil) { self.value = value.flatMap { $0.isFinite ? $0 : nil } }
        public var text: String {
            guard let value else { return "no data" }
            return NSDecimalNumber(value: value).stringValue
        }
    }

    public struct Money: Equatable {
        public let amount: Quantity
        public let currency: String
        /// Amount is in the named currency's major units, not implicit cents.
        public init(_ amount: Double? = nil, currency: String) {
            self.amount = Quantity(amount)
            self.currency = currency.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        public var text: String {
            guard amount.value != nil, !currency.isEmpty else { return "no data" }
            return "\(amount.text) \(currency)"
        }
    }

    public struct Refusal {
        public var reason: String?
        public var supported: Bool
        public var observedAt: Date?
        public var validFrom: Date?
        public var validUntil: Date?
        public init(reason: String? = nil, supported: Bool = false, observedAt: Date? = nil,
                    validFrom: Date? = nil, validUntil: Date? = nil) {
            self.reason = reason; self.supported = supported; self.observedAt = observedAt
            self.validFrom = validFrom; self.validUntil = validUntil
        }
        public func currentReason(at now: Date) -> String? {
            guard supported, let reason = reason?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !reason.isEmpty, PeopleCards.observed(observedAt, by: now),
                  let start = validFrom ?? observedAt, PeopleCards.valid(start), start <= now,
                  let end = validUntil, PeopleCards.valid(end), end >= now else { return nil }
            return reason
        }
    }

    public struct ExecutionEvidence {
        public var time: Date?
        public var observedAt: Date?
        public var provenance: Execution
        public init(time: Date? = nil, observedAt: Date? = nil, provenance: Execution = .unknown) {
            self.time = time; self.observedAt = observedAt; self.provenance = provenance
        }
    }

    public struct History {
        public var complete: Bool
        public var from: Date?
        public var through: Date?
        public var orders: Quantity
        public var provenance: Execution
        public init(complete: Bool = false, from: Date? = nil, through: Date? = nil,
                    orders: Double? = nil, provenance: Execution = .unknown) {
            self.complete = complete; self.from = from; self.through = through
            self.orders = Quantity(orders); self.provenance = provenance
        }
    }

    public struct Lane {
        public var state: LaneState
        public var revoked: Bool?
        public var killRequested: Bool?
        public var observedAt: Date?
        public var refusal: Refusal
        public var lastOrder: ExecutionEvidence
        public var lastFill: ExecutionEvidence
        public var history: History
        public init(state: LaneState = .unknown, revoked: Bool? = nil, killRequested: Bool? = nil,
                    observedAt: Date? = nil, refusal: Refusal = Refusal(),
                    lastOrder: ExecutionEvidence = ExecutionEvidence(),
                    lastFill: ExecutionEvidence = ExecutionEvidence(), history: History = History()) {
            self.state = state; self.revoked = revoked; self.killRequested = killRequested
            self.observedAt = observedAt; self.refusal = refusal; self.lastOrder = lastOrder
            self.lastFill = lastFill; self.history = history
        }
        public func verdict(at now: Date) -> Verdict {
            if revoked == true || killRequested == true || state == .paused || state == .nonLive { return .off }
            guard state == .live, PeopleCards.valid(now) else { return .unknown }
            if let observedAt, !PeopleCards.observed(observedAt, by: now) { return .unknown }
            if refusal.currentReason(at: now) != nil { return .blocked }
            if lastOrder.provenance == .live, PeopleCards.observed(lastOrder.observedAt, by: now),
               let order = lastOrder.time, PeopleCards.valid(order), order <= now,
               order >= now.addingTimeInterval(-PeopleCards.sixHours),
               let observation = lastOrder.observedAt, order <= observation { return .trading }
            if history.provenance == .live, history.complete, history.orders.value == 0,
               let from = history.from, PeopleCards.valid(from), from <= now.addingTimeInterval(-PeopleCards.sixHours),
               let through = history.through, PeopleCards.valid(through), through == now { return .idle }
            return .unknown
        }
        public var killText: String {
            switch killRequested {
            case true?: return "Kill requested; runner termination unconfirmed."
            case false?: return "Kill not requested in supplied evidence."
            case nil: return "Kill request: no data."
            }
        }
        public static let offExplanation = "Off describes lane/control state, not confirmed runner termination."
    }

    public struct Activity {
        public var recorded24h: Quantity
        public var recorded7d: Quantity
        public var total24h: Quantity
        public var total7d: Quantity
        public var coverage: String
        public var observedAt: Date?
        public init(recorded24h: Double? = nil, recorded7d: Double? = nil,
                    total24h: Double? = nil, total7d: Double? = nil,
                    coverage: String = "recorded only; complete totals unavailable", observedAt: Date? = nil) {
            self.recorded24h = Quantity(recorded24h); self.recorded7d = Quantity(recorded7d)
            self.total24h = Quantity(total24h); self.total7d = Quantity(total7d)
            self.coverage = coverage; self.observedAt = observedAt
        }
    }

    public struct Funds {
        public var currentCash: Money?
        public var activationBudgetCash: Money?
        public var reportedStake: Money?
        public var turnoverUsed: Money?
        public var reportedCap: Money?
        public var observedAt: Date?
        public init(currentCash: Money? = nil, activationBudgetCash: Money? = nil,
                    reportedStake: Money? = nil, turnoverUsed: Money? = nil,
                    reportedCap: Money? = nil, observedAt: Date? = nil) {
            self.currentCash = currentCash; self.activationBudgetCash = activationBudgetCash
            self.reportedStake = reportedStake; self.turnoverUsed = turnoverUsed
            self.reportedCap = reportedCap; self.observedAt = observedAt
        }
    }

    public struct Metrics {
        public var realized: Money?
        public var entries: Quantity
        public var settled: Quantity
        public var exits: Quantity
        public var won: Quantity
        public var lost: Quantity
        public var voided: Quantity
        public init(realized: Money? = nil, entries: Double? = nil, settled: Double? = nil,
                    exits: Double? = nil, won: Double? = nil, lost: Double? = nil, voided: Double? = nil) {
            self.realized = realized; self.entries = Quantity(entries); self.settled = Quantity(settled)
            self.exits = Quantity(exits); self.won = Quantity(won); self.lost = Quantity(lost); self.voided = Quantity(voided)
        }
        public var countText: String {
            "Entries \(entries.text), settled \(settled.text), exits \(exits.text), won \(won.text), lost \(lost.text), voided \(voided.text)"
        }
    }

    public struct PerformanceRow {
        public var accountID: String
        public var engineID: String
        public var dateSlot: String
        public var observedAt: Date?
        public var metrics: Metrics
        public init(accountID: String, engineID: String, dateSlot: String, observedAt: Date?, metrics: Metrics) {
            self.accountID = accountID; self.engineID = engineID; self.dateSlot = dateSlot
            self.observedAt = observedAt; self.metrics = metrics
        }
    }

    public struct PerformanceDay {
        public let dateSlot: String
        public let observedAt: Date?
        public let metrics: Metrics
        public var isObserved: Bool { observedAt != nil }
    }

    public struct Performance {
        public let accountID: String
        public let engineID: String
        public let dateBasis: String
        public let days: [PerformanceDay]
        public var observedDayCount: Int { days.filter(\.isObserved).count }
        public var coverage: String {
            observedDayCount == 14 && days.count == 14 ? "all 14 days reported" : "reported days only"
        }
        public var realizedText: String {
            let reported = days.filter(\.isObserved)
            guard !reported.isEmpty, let currency = reported.first?.metrics.realized?.currency,
                  !currency.isEmpty, reported.allSatisfy({ $0.metrics.realized?.currency == currency && $0.metrics.realized?.amount.value != nil })
            else { return "no data" }
            return Money(reported.reduce(0) { $0 + ($1.metrics.realized?.amount.value ?? 0) }, currency: currency).text
        }
    }

    /// Slots and date basis come from the caller; do not silently substitute a new calendar window.
    public static func performance(accountID: String, engineID: String, dateSlots: [String],
                                   dateBasis: String, rows: [PerformanceRow], now: Date) -> Performance {
        let days = dateSlots.map { slot -> PerformanceDay in
            let row = rows.filter {
                $0.accountID == accountID && $0.engineID == engineID && $0.dateSlot == slot && observed($0.observedAt, by: now)
            }.max { $0.observedAt! < $1.observedAt! }
            return PerformanceDay(dateSlot: slot, observedAt: row?.observedAt, metrics: row?.metrics ?? Metrics())
        }
        return Performance(accountID: accountID, engineID: engineID, dateBasis: dateBasis, days: days)
    }

    public struct Projection {
        public let low: Money
        public let high: Money
        public let basis: String
        public init(low: Money, high: Money, basis: String) { self.low = low; self.high = high; self.basis = basis }
        public var text: String {
            guard let lower = low.amount.value, let upper = high.amount.value, lower <= upper,
                  !low.currency.isEmpty, low.currency == high.currency,
                  !basis.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return "not estimable" }
            return "Illustrative daily projection: \(low.text) to \(high.text). Basis: \(basis)"
        }
    }

    public struct Assignment {
        public var accountID: String
        public var engineID: String
        public init(accountID: String, engineID: String) { self.accountID = accountID; self.engineID = engineID }
    }

    public static func assignmentLabel(engineID: String, accountID: String, enabled: Bool?,
                                       read: ReadStatus, assignments: [Assignment], aliases: [String: String] = [:]) -> String {
        guard read == .complete, let mine = canonical(accountID, aliases: aliases) else { return "unknown" }
        let matches = assignments.filter { $0.engineID == engineID }
        if matches.contains(where: { canonical($0.accountID, aliases: aliases) == mine }) { return "assigned" }
        return matches.isEmpty && enabled == true ? "unassigned catalog" : "unknown"
    }

    public struct EngineUse {
        public var accountID: String
        public var label: String
        public var engineID: String
        public var family: String?
        public var enabled: Bool?
        public var provenance: Execution
        public var observedAt: Date?
        public init(accountID: String, label: String, engineID: String, family: String? = nil,
                    enabled: Bool? = nil, provenance: Execution = .unknown, observedAt: Date? = nil) {
            self.accountID = accountID; self.label = label; self.engineID = engineID; self.family = family
            self.enabled = enabled; self.provenance = provenance; self.observedAt = observedAt
        }
    }

    public enum SharingStatus: Equatable { case shared, notShared, unknown }
    public struct SharingAccount: Equatable { public let accountID: String; public let label: String }
    public struct Sharing {
        public let status: SharingStatus
        public let others: [SharingAccount]
        public let evidenceComplete: Bool
        public var text: String {
            switch status {
            case .shared: return "Shared live use with \(others.map(\.label).joined(separator: ", "))" + (evidenceComplete ? "" : "; other evidence incomplete")
            case .notShared: return "No shared live use in complete supplied evidence"
            case .unknown: return "Live sharing: unknown"
            }
        }
    }

    private static func canonical(_ id: String, aliases: [String: String]) -> String? {
        guard !id.isEmpty else { return nil }
        var current = id
        var seen: Set<String> = []
        while let next = aliases[current], next != current {
            guard !next.isEmpty, seen.insert(current).inserted else { return nil }
            current = next
        }
        return current
    }

    public static func sharing(engineID: String, accountID: String, observations: [EngineUse],
                               aliases: [String: String] = [:], roster: ReadStatus, controls: ReadStatus,
                               now: Date) -> Sharing {
        let complete = roster == .complete && controls == .complete
        guard let mine = canonical(accountID, aliases: aliases) else {
            return Sharing(status: .unknown, others: [], evidenceComplete: complete)
        }
        let relevant = observations.filter { $0.engineID == engineID && $0.provenance != .paper }
        let proven = relevant.filter {
            $0.enabled == true && $0.provenance == .live && observed($0.observedAt, by: now)
                && canonical($0.accountID, aliases: aliases) != nil
        }
        let hasSelf = proven.contains { canonical($0.accountID, aliases: aliases) == mine }
        var others: [String: SharingAccount] = [:]
        for row in proven {
            if let id = canonical(row.accountID, aliases: aliases), id != mine, others[id] == nil {
                let label = row.label.trimmingCharacters(in: .whitespacesAndNewlines)
                others[id] = SharingAccount(accountID: id, label: label.isEmpty ? "Unnamed account" : label)
            }
        }
        let distinct = others.values.sorted { $0.accountID < $1.accountID }
        if hasSelf && !distinct.isEmpty { return Sharing(status: .shared, others: distinct, evidenceComplete: complete) }
        let uncertain = relevant.contains {
            $0.enabled == nil || $0.provenance == .unknown || !observed($0.observedAt, by: now)
                || canonical($0.accountID, aliases: aliases) == nil
        }
        let suppliedSelf = relevant.contains { canonical($0.accountID, aliases: aliases) == mine }
        return Sharing(status: complete && suppliedSelf && !uncertain ? .notShared : .unknown,
                       others: [], evidenceComplete: complete)
    }

    public struct EngineCard: Identifiable {
        public var id: String
        public var name: String
        public var assignment: String
        public var sharing: Sharing
        public var performance: Performance
        public var projection: Projection?
        public init(id: String, name: String, assignment: String, sharing: Sharing,
                    performance: Performance, projection: Projection? = nil) {
            self.id = id; self.name = name; self.assignment = assignment
            self.sharing = sharing; self.performance = performance; self.projection = projection
        }
    }

    public struct Person: Identifiable {
        public var id: String
        public var laneID: String
        public var accountID: String
        public var label: String
        public var lane: Lane
        public var orders: Activity
        public var fills: Activity
        public var funds: Funds
        public var engines: [EngineCard]
        public init(id: String, laneID: String, accountID: String, label: String, lane: Lane,
                    orders: Activity = Activity(), fills: Activity = Activity(), funds: Funds = Funds(), engines: [EngineCard] = []) {
            self.id = id; self.laneID = laneID; self.accountID = accountID; self.label = label
            self.lane = lane; self.orders = orders; self.fills = fills; self.funds = funds; self.engines = engines
        }
        /// Even a mis-scoped presentation input must not display another account's results.
        public var scopedEngines: [EngineCard] {
            engines.filter { $0.performance.accountID == accountID && $0.performance.engineID == $0.id }
        }
        public var emptyEnginesText: String? {
            scopedEngines.isEmpty ? "Account-engine performance: no data" : nil
        }
    }

    private static func valid(_ date: Date) -> Bool { date.timeIntervalSinceReferenceDate.isFinite }
    private static func observed(_ date: Date?, by now: Date) -> Bool {
        guard valid(now), let date, valid(date) else { return false }
        return date <= now
    }
    public static func timeText(_ date: Date?) -> String {
        guard let date, valid(date) else { return "unknown" }
        return ISO8601DateFormatter().string(from: date)
    }

    #if DEBUG
    public static let fixtureTime = Date(timeIntervalSince1970: 1_790_424_000)
    public static func fixtures() -> [Person] {
        let now = fixtureTime
        let slots = (13...26).map { "2026-09-\($0)" }
        return (1...3).map { index in
            let account = "a\(index)"
            let engine = "e\(index)"
            let rows = index == 1 ? [PerformanceRow(accountID: account, engineID: engine, dateSlot: slots[13],
                observedAt: now, metrics: Metrics(realized: Money(0.25, currency: "USD"), entries: 0.01, settled: 0, exits: 0))] : []
            let result = performance(accountID: account, engineID: engine, dateSlots: slots,
                dateBasis: "UTC calendar date as supplied", rows: rows, now: now)
            let use = EngineUse(accountID: account, label: "Person \(index)", engineID: engine,
                enabled: true, provenance: .live, observedAt: now)
            let card = EngineCard(id: engine, name: "Engine \(index)",
                assignment: assignmentLabel(engineID: engine, accountID: account, enabled: true,
                    read: .complete, assignments: []),
                sharing: sharing(engineID: engine, accountID: account, observations: [use],
                    roster: .complete, controls: .complete, now: now), performance: result,
                projection: index == 1 ? Projection(low: Money(-0.5, currency: "USD"), high: Money(0.75, currency: "USD"),
                    basis: "Supplied synthetic scenario range; not an endpoint forecast") : nil)
            let lane = Lane(state: index == 3 ? .paused : .live, revoked: false, killRequested: index == 3,
                observedAt: now,
                refusal: index == 2 ? Refusal(reason: "Synthetic cash unavailable", supported: true,
                    observedAt: now, validUntil: now.addingTimeInterval(60)) : Refusal(),
                lastOrder: index == 1 ? ExecutionEvidence(time: now.addingTimeInterval(-60), observedAt: now, provenance: .live) : ExecutionEvidence())
            return Person(id: "p\(index)", laneID: "l\(index)", accountID: account, label: "Person \(index)", lane: lane,
                orders: Activity(recorded24h: index == 1 ? 1 : nil, recorded7d: index == 1 ? 2 : nil, observedAt: now),
                fills: Activity(recorded24h: index == 1 ? 0 : nil, recorded7d: index == 1 ? 0 : nil, observedAt: now),
                funds: Funds(currentCash: index == 1 ? Money(0, currency: "USD") : nil,
                    reportedStake: index == 1 ? Money(0.01, currency: "USD") : nil, observedAt: now), engines: [card])
        }
    }
    #endif
}
