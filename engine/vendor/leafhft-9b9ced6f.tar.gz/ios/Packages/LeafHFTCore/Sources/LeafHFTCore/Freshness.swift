import Foundation

public func ageDescription(observedAt: Date, now: Date) -> String {
    let age = max(0, now.timeIntervalSince(observedAt))
    if age < 60 { return "Observed \(Int(age)) s ago" }
    if age < 3600 { return "Observed \(Int(age / 60)) min ago" }
    return "Observed \(Int(age / 3600)) h ago"
}

public func transportStale(observedAt: Date, now: Date) -> Bool {
    now.timeIntervalSince(observedAt) > 120
}

public func quoteStale(quoteAgeMs: Double, limitMs: Double) -> Bool {
    !quoteAgeMs.isFinite || !limitMs.isFinite || quoteAgeMs < 0 || limitMs < 0 || quoteAgeMs > limitMs
}
