import Foundation

// Probe-paradigm runtime models (plan D8, D9, D10). Every block is optional on the wire, so an
// older server that sends none of them still decodes. Decode with accountJSONDecoder().

/// One key type for both spellings: a plain JSONDecoder sees snake_case keys, accountJSONDecoder() camelCase.
struct RuntimeKey: CodingKey {
    let stringValue: String
    init(_ name: String) { stringValue = name }
    init?(stringValue: String) { self.stringValue = stringValue }
    var intValue: Int? { nil }
    init?(intValue: Int) { return nil }

    static func snake(_ camel: String) -> String {
        var name = ""
        for character in camel {
            if character.isUppercase { name += "_" + character.lowercased() } else { name.append(character) }
        }
        return name
    }
}

extension KeyedDecodingContainer where K == RuntimeKey {
    /// The value under either spelling; absent or null is nil, a present value of the wrong type throws.
    func field<T: Decodable>(_ camel: String, as type: T.Type = T.self) throws -> T? {
        let camelKey = RuntimeKey(camel)
        if contains(camelKey) { return try decodeIfPresent(T.self, forKey: camelKey) }
        return try decodeIfPresent(T.self, forKey: RuntimeKey(RuntimeKey.snake(camel)))
    }
}

enum RuntimeDate {
    /// ISO 8601 with or without fractional seconds; anything else is nil, never a guessed date.
    static func parse(_ text: String?) -> Date? {
        guard let text, !text.isEmpty else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: text) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: text)
    }

    static func string(_ date: Date) -> String { ISO8601DateFormatter().string(from: date) }
}

/// The runner's lifecycle for one engine. Replaces the legacy canary-only `EngineLab.Lifecycle`.
public struct EngineLifecycle: Codable, Equatable {
    public enum State: String, Codable {
        case probe, probeSized = "probe_sized", halted, graduated, retired, shadow, canary, unknown
        public init(from decoder: Decoder) throws {
            let raw = try decoder.singleValueContainer().decode(String.self)
            self = State(rawValue: raw) ?? .unknown
        }
    }

    /// A stop reason as the runner sends it: `{code, text}`, or a bare code from older runners (text nil).
    public struct StopReason: Codable, Equatable, Hashable {
        public let code: String
        public let text: String?

        public init(code: String, text: String?) { self.code = code; self.text = text }

        public init(from decoder: Decoder) throws {
            if let raw = try? decoder.singleValueContainer().decode(String.self) {
                code = raw; text = nil; return
            }
            let values = try decoder.container(keyedBy: RuntimeKey.self)
            code = try values.field("code") ?? ""
            text = try values.field("text")
        }

        public func encode(to encoder: Encoder) throws {
            var values = encoder.container(keyedBy: RuntimeKey.self)
            try values.encode(code, forKey: RuntimeKey("code"))
            try values.encodeIfPresent(text, forKey: RuntimeKey("text"))
        }
    }

    public let state: State
    public let entriesEnabled: Bool?
    /// A breaker trip suspends entries until 00:00Z; it is not a halt.
    public let entriesSuspendedUntil: Date?
    public let stopReasons: [StopReason]?
    public let probeStartedAt: String?
    public let expiresAt: String?
    /// Sized probe rung (2 or 5 contracts); nil for a 1-contract probe or an older runner.
    public let contracts: Int?
    public let breaker: BreakerMeter?
    // Legacy canary evidence, still sent by older runners.
    public let accountId: String?
    public let sizeFraction: Double?
    public let settlementEnabled: Bool?
    public let historicalEvidenceDigest: String?
    public let shadowEvidenceDigest: String?
    public let snapshotDigest: String?

    public var label: String {
        switch state {
        case .probe: return "Probing"
        case .probeSized: return contracts.map { "Probing at \($0) contracts" } ?? "Probing at size"
        case .graduated: return "Graduated"
        case .retired: return "Retired"
        case .shadow: return "Shadow only"
        case .canary: return "5% account canary"
        case .halted: return "Entries halted, settlement only"
        case .unknown: return "Lifecycle not reported"
        }
    }

    public var canEnter: Bool {
        state == .canary && entriesEnabled == true && sizeFraction == 0.05 &&
            accountId?.isEmpty == false && historicalEvidenceDigest?.count == 64 &&
            shadowEvidenceDigest?.count == 64 && snapshotDigest?.count == 64 &&
            stopReasons?.isEmpty == true
    }

    public var boundary: String { "Broad live rollout requires a manual decision." }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: RuntimeKey.self)
        state = try values.field("state") ?? .unknown
        entriesEnabled = try values.field("entriesEnabled")
        entriesSuspendedUntil = try RuntimeDate.parse(values.field("entriesSuspendedUntil", as: String.self))
        stopReasons = try values.field("stopReasons")
        probeStartedAt = try values.field("probeStartedAt")
        expiresAt = try values.field("expiresAt")
        contracts = Self.wholeCount(values, "contracts")
        // A malformed breaker is nil; the rest of the lifecycle still decodes.
        breaker = try? values.field("breaker", as: BreakerMeter.self)
        accountId = try values.field("accountId")
        sizeFraction = try values.field("sizeFraction")
        settlementEnabled = try values.field("settlementEnabled")
        historicalEvidenceDigest = try values.field("historicalEvidenceDigest")
        shadowEvidenceDigest = try values.field("shadowEvidenceDigest")
        snapshotDigest = try values.field("snapshotDigest")
    }

    /// An Int as sent, or a finite integral Double as that Int; anything else is nil and never throws.
    private static func wholeCount(_ values: KeyedDecodingContainer<RuntimeKey>, _ camel: String) -> Int? {
        if let count = try? values.field(camel, as: Int.self) { return count }
        guard let value = try? values.field(camel, as: Double.self), value.isFinite else { return nil }
        return Int(exactly: value)
    }

    public func encode(to encoder: Encoder) throws {
        var values = encoder.container(keyedBy: RuntimeKey.self)
        try values.encode(state, forKey: RuntimeKey("state"))
        try values.encodeIfPresent(entriesEnabled, forKey: RuntimeKey("entriesEnabled"))
        try values.encodeIfPresent(entriesSuspendedUntil.map(RuntimeDate.string), forKey: RuntimeKey("entriesSuspendedUntil"))
        try values.encodeIfPresent(stopReasons, forKey: RuntimeKey("stopReasons"))
        try values.encodeIfPresent(probeStartedAt, forKey: RuntimeKey("probeStartedAt"))
        try values.encodeIfPresent(expiresAt, forKey: RuntimeKey("expiresAt"))
        try values.encodeIfPresent(contracts, forKey: RuntimeKey("contracts"))
        try values.encodeIfPresent(breaker, forKey: RuntimeKey("breaker"))
        try values.encodeIfPresent(accountId, forKey: RuntimeKey("accountId"))
        try values.encodeIfPresent(sizeFraction, forKey: RuntimeKey("sizeFraction"))
        try values.encodeIfPresent(settlementEnabled, forKey: RuntimeKey("settlementEnabled"))
        try values.encodeIfPresent(historicalEvidenceDigest, forKey: RuntimeKey("historicalEvidenceDigest"))
        try values.encodeIfPresent(shadowEvidenceDigest, forKey: RuntimeKey("shadowEvidenceDigest"))
        try values.encodeIfPresent(snapshotDigest, forKey: RuntimeKey("snapshotDigest"))
    }
}

/// The runner's UTC-day loss breaker for one engine (D5a). Computed by the runner, never recomputed here.
public struct BreakerMeter: Codable, Equatable {
    public let enginePct: Double?
    public let inherited: Bool?
    public let accountPct: Double?
    public let engineLossCents: Int?
    public let engineLimitCents: Int?
    public let accountLossCents: Int?
    public let accountLimitCents: Int?
    public let dayStartMarkedCents: Int?

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: RuntimeKey.self)
        enginePct = try values.field("enginePct")
        inherited = try values.field("inherited")
        accountPct = try values.field("accountPct")
        engineLossCents = try values.field("engineLossCents")
        engineLimitCents = try values.field("engineLimitCents")
        accountLossCents = try values.field("accountLossCents")
        accountLimitCents = try values.field("accountLimitCents")
        dayStartMarkedCents = try values.field("dayStartMarkedCents")
    }

    public func encode(to encoder: Encoder) throws {
        var values = encoder.container(keyedBy: RuntimeKey.self)
        try values.encodeIfPresent(enginePct, forKey: RuntimeKey("enginePct"))
        try values.encodeIfPresent(inherited, forKey: RuntimeKey("inherited"))
        try values.encodeIfPresent(accountPct, forKey: RuntimeKey("accountPct"))
        try values.encodeIfPresent(engineLossCents, forKey: RuntimeKey("engineLossCents"))
        try values.encodeIfPresent(engineLimitCents, forKey: RuntimeKey("engineLimitCents"))
        try values.encodeIfPresent(accountLossCents, forKey: RuntimeKey("accountLossCents"))
        try values.encodeIfPresent(accountLimitCents, forKey: RuntimeKey("accountLimitCents"))
        try values.encodeIfPresent(dayStartMarkedCents, forKey: RuntimeKey("dayStartMarkedCents"))
    }
}

/// Which account and domain executes an engine. Another account's engine arrives as `{account: "other"}`.
public struct EngineAssignment: Codable, Equatable {
    public var accountId: String?
    public var domain: String?
    public var role: String?
    public var since: String?
    public var account: String?
}

public struct EngineInput: Codable, Equatable, Hashable, Identifiable {
    public var kind: String
    public var id: String
}

/// One UTC day of attributed probe results.
public struct ProbeDay: Codable, Equatable {
    public var utcDay: String?
    public var realizedCents: Int?
    public var tickets: Int?
    /// The runner's entry count for the day; the server sends this, never `tickets`.
    public var entries: Int?
}

/// Live per-contract P&L; `perContractCents` carries tenths of a cent, so it is fractional.
public struct EngineLiveStats: Codable, Equatable {
    public var perContractCents: Double?
    public var n: Int
    public var days: Int
}

public struct ProbeEligibility: Codable, Equatable {
    public var eligible: Bool
    public var reasons: [String]

    enum CodingKeys: String, CodingKey { case eligible, reasons }

    public init(eligible: Bool, reasons: [String]) { self.eligible = eligible; self.reasons = reasons }

    /// The server sends a bare `true`/`false`; older builds sent `{eligible, reasons}`. Both decode.
    public init(from decoder: Decoder) throws {
        if let flag = try? decoder.singleValueContainer().decode(Bool.self) {
            eligible = flag; reasons = []; return
        }
        let values = try decoder.container(keyedBy: CodingKeys.self)
        eligible = try values.decode(Bool.self, forKey: .eligible)
        reasons = try values.decodeIfPresent([String].self, forKey: .reasons) ?? []
    }
}

/// The runner's next-step sentence (D9). The app shows `text` as sent and never composes its own.
public struct EngineNextStep: Codable, Equatable {
    public var code: String?
    public var text: String?
}

/// The account breaker from the runner's `loss_breakers` block.
public struct AccountBreaker: Codable, Equatable {
    public var pct: Double?
    public var lossCents: Int?
    public var limitCents: Int?
    public var suspended: Bool?
    public var dayStartMarkedCents: Int?
}

public struct ProbeRow: Codable, Equatable, Identifiable {
    public var engineId: String
    public var id: String { engineId }
    public var name: String?
    public var lifecycle: EngineLifecycle?
    public var assignment: EngineAssignment?
    public var probeToday: ProbeDay?
    public var live: EngineLiveStats?
    public var nextStep: EngineNextStep?
}

/// GET /api/leafhft/mobile/probes.
public struct ProbeBoardResponse: Codable, Equatable {
    public var account: AccountBreaker?
    public var engines: [ProbeRow]
    public var observedAt: String?

    enum CodingKeys: String, CodingKey { case account, engines, observedAt }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        account = try values.decodeIfPresent(AccountBreaker.self, forKey: .account)
        engines = try values.decodeIfPresent([ProbeRow].self, forKey: .engines) ?? []
        observedAt = try values.decodeIfPresent(String.self, forKey: .observedAt)
    }
}

/// `kalshi_book.executor` (D10): the engines co-hosted on one book and who holds its position.
public struct ExecutorSummary: Codable, Equatable {
    public var incumbentEngineId: String?
    public var engines: [ExecutorEngine]
    public var position: ExecutorPosition?
    public var disagreementsToday: Int?

    enum CodingKeys: String, CodingKey { case incumbentEngineId, engines, position, disagreementsToday }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        incumbentEngineId = try values.decodeIfPresent(String.self, forKey: .incumbentEngineId)
        engines = try values.decodeIfPresent([ExecutorEngine].self, forKey: .engines) ?? []
        position = try values.decodeIfPresent(ExecutorPosition.self, forKey: .position)
        disagreementsToday = try values.decodeIfPresent(Int.self, forKey: .disagreementsToday)
    }
}

public struct ExecutorEngine: Codable, Equatable, Identifiable {
    public var engineId: String
    public var id: String { engineId }
    public var role: String?
    public var state: EngineLifecycle.State?
    public var entriesEnabled: Bool?
    public var entriesSuspendedUntil: String?
    public var stopReasons: [EngineLifecycle.StopReason]?
    public var expiresAt: String?
    public var realizedTodayCents: Int?
    public var openPositions: Int?
    public var lastProposal: ExecutorProposal?
}

public struct ExecutorProposal: Codable, Equatable {
    public var ticker: String?
    public var sideYes: Bool?
    public var priceCents: Double?
    public var edgeCents: Double?
    public var atMs: Int64?
    public var disposition: String?
    public var reason: String?
}

/// Kalshi fills can be fractional, so contracts is not a whole count.
public struct ExecutorPosition: Codable, Equatable {
    public var ticker: String?
    public var sideYes: Bool?
    public var contracts: Double?
    public var holderEngineId: String?
    public var openedAtMs: Int64?
}
