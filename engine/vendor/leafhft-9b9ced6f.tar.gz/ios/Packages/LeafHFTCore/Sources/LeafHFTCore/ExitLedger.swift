import Foundation

/// Venue fills are authoritative; runner annotations remain optional.
public struct ExitLedger: Codable, Equatable {
    public var schemaVersion: Int
    public var generatedAt: String
    public var host: String
    public var window: Window
    public var summary: Summary
    public var lessons: [Lesson]
    public var calibration: [CalibrationBucket]
    public var engines: [EngineExits]
    public var rows: [Row]

    public enum Verdict: String, Codable {
        case saved
        case gaveBack = "gave_back"
        case even
        case pending
        case unknown
        public init(from decoder: Decoder) throws {
            let value = try decoder.singleValueContainer().decode(String.self)
            self = Self(rawValue: value) ?? .unknown
        }
    }

    public enum Severity: String, Codable {
        case good
        case watch
        case act
        case unknown
        public init(from decoder: Decoder) throws {
            let value = try decoder.singleValueContainer().decode(String.self)
            self = Self(rawValue: value) ?? .unknown
        }
    }

    public enum PriceCheck: String, Codable {
        case improved
        case atLimit = "at_limit"
        case worse
        case unknown
        public init(from decoder: Decoder) throws {
            let value = try decoder.singleValueContainer().decode(String.self)
            self = Self(rawValue: value) ?? .unknown
        }
    }

    public struct Window: Codable, Equatable {
        public var since: String
        public var days: Int
    }

    public struct Summary: Codable, Equatable {
        public var exits: Int
        public var resolved: Int
        public var pending: Int
        public var savedCount: Int
        public var gaveBackCount: Int
        public var evenCount: Int
        public var savedCents: Int
        public var gaveBackCents: Int
        public var netVsHoldCents: Int
        public var proceedsCents: Int
        public var feesCents: Int
        public var priceImprovementCents: Int
        public var worseThanLimitCount: Int
        public var modelBidKnown: Int
        public var worseThanModelBidCount: Int
        public var slippageVsModelBidCents: Int
        public var latencyKnown: Int
        public var decisionToFillMsP50: Int?
        public var decisionToFillMsP95: Int?
        public var secondsBeforeCloseP50: Int?
        public var cashRefusals: Int?

        public var headline: String {
            guard resolved > 0 else { return "No resolved cashouts yet" }
            return netVsHoldCents >= 0
                ? "Cashouts beat holding by \(ExitLedger.money(netVsHoldCents))"
                : "Cashouts cost \(ExitLedger.money(netVsHoldCents)) versus holding"
        }
        public var tally: String {
            "\(savedCount) saved · \(gaveBackCount) gave back · \(pending) pending"
        }
        public var priceLine: String {
            worseThanLimitCount > 0
                ? "\(worseThanLimitCount) fills below their limit"
                : "Every fill at or above its limit (\(ExitLedger.money(priceImprovementCents)))"
        }
        public var timingLine: String {
            var parts: [String] = []
            if let milliseconds = decisionToFillMsP50 { parts.append("Filled in \(milliseconds) ms (median)") }
            if let seconds = secondsBeforeCloseP50 { parts.append("\(seconds) s before close") }
            return parts.isEmpty ? "Timing not reported" : parts.joined(separator: " · ")
        }
    }

    public struct Lesson: Codable, Equatable {
        public var id: String
        public var severity: Severity
        public var title: String
        public var detail: String
        public var evidenceCount: Int
        public var cents: Int?
    }

    public struct CalibrationBucket: Codable, Equatable {
        public var bucket: String
        public var label: String
        public var lo: Double
        public var hi: Double
        public var exits: Int
        public var modelWinPct: Double
        public var actualWinPct: Double
        public var netVsHoldCents: Int
    }

    public struct EngineExits: Codable, Equatable {
        public var engineId: String?
        public var exits: Int
        public var resolved: Int
        public var savedCents: Int
        public var gaveBackCents: Int
        public var netVsHoldCents: Int
    }

    public struct Row: Codable, Equatable {
        public var ticker: String
        public var engineId: String?
        public var heldSide: String?
        public var count: Decimal
        public var exitPriceCents: Decimal?
        public var limitPriceCents: Decimal?
        public var modelBidCents: Decimal?
        public var entryPriceCents: Decimal?
        public var proceedsCents: Int
        public var feeCents: Int
        public var holdValueCents: Int?
        public var netVsHoldCents: Int?
        public var verdict: Verdict
        public var marketResult: String?
        public var modelWinProb: Double?
        public var decidedAt: String?
        public var filledAt: String?
        public var decisionToFillMs: Int?
        public var secondsBeforeClose: Int?
        public var priceCheck: PriceCheck
        public var realizedPnlCents: Int?

        public var verdictLabel: String {
            switch verdict {
            case .saved:
                guard let cents = netVsHoldCents else { return "Comparison not reported" }
                return "Saved \(ExitLedger.money(cents)) vs hold"
            case .gaveBack:
                guard let cents = netVsHoldCents else { return "Comparison not reported" }
                return "Gave back \(ExitLedger.money(cents)) vs hold"
            case .even: return "Even with hold"
            case .pending: return "Waiting for settlement"
            case .unknown: return "Comparison not reported"
            }
        }
    }

    public var topLesson: Lesson? {
        lessons.first { $0.severity == .act } ?? lessons.first { $0.severity == .watch } ?? lessons.first
    }

    /// Cents provides exact integer formatting; add grouping without a floating-point conversion.
    public static func money(_ cents: Int) -> String {
        let base = Cents(cents).formatted()
        let parts = base.split(separator: ".")
        let dollars = String(parts[0].drop(while: { $0 == "-" || $0 == "$" }))
        let grouped = dollars.reversed().enumerated().map { index, digit in
            (index > 0 && index % 3 == 0 ? "," : "") + String(digit)
        }.joined().reversed()
        return "\(cents < 0 ? "-" : "+")$\(String(grouped)).\(parts[1])"
    }
}
