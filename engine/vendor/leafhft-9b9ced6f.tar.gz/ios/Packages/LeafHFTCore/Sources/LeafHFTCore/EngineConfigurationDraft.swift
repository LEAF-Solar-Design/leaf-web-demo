import Foundation

public enum PolicyValueSource: String, Sendable {
    case inherited, global, overridden, drafted
    public var label: String {
        switch self {
        case .inherited: return "Inherited"
        case .global: return "Global"
        case .overridden: return "Override"
        case .drafted: return "Unsaved"
        }
    }
}

public enum DraftValue: Equatable, Sendable { case set(Double), useGlobal }

public struct EngineConfigurationBaseline: Equatable, Sendable {
    public let scope: ControlScope
    public let globalEnabled: Bool?
    public let globalPolicy: [String: Double]
    public let overrideEnabled: Bool?
    public let overridePolicy: [String: Double]
    public let effectiveEnabled: Bool?
    public let effectivePolicy: [String: Double]
    public let revision: String?
    public let riskEnvelope: RiskEnvelope
    public let engineId: String
    public let darkhorseModels: [DarkhorseConfiguration.Model]
    public let controlDisabledReason: String?

    public init(engine: Engine, scope: ControlScope) {
        self.scope = scope
        riskEnvelope = engine.riskEnvelope ?? RiskEnvelope()
        engineId = engine.engineId
        darkhorseModels = engine.darkhorse?.models ?? []
        controlDisabledReason = engine.controlDisabledReason
        let global = engine.configuration?.global
        let account = scope.kind == .account
            ? engine.configuration?.accounts.first { $0.accountId == scope.accountId } : nil
        globalEnabled = engine.engineId == "darkhorse" ? false : global?.enabled
        var defaults = global?.policy ?? [:]
        if engine.engineId == "darkhorse" {
            for model in darkhorseModels { defaults[model.key] = model.trainedThreshold }
        }
        globalPolicy = defaults
        overrideEnabled = account?.override.enabled
        overridePolicy = account?.override.policy ?? [:]
        effectiveEnabled = scope.kind == .global ? global?.enabled : account?.effective.enabled
        effectivePolicy = (scope.kind == .global ? global?.policy : account?.effective.policy) ?? [:]
        revision = scope.kind == .global ? global?.revision : account?.revision
    }

    public var fingerprint: String {
        func policy(_ values: [String: Double]) -> [String] {
            values.keys.sorted().flatMap { [$0, values[$0].map { String($0) } ?? "unknown"] }
        }
        let parts = [scope.kind.rawValue, scope.accountId ?? "", revision ?? "unknown",
                     globalEnabled.map { String($0) } ?? "unknown",
                     overrideEnabled.map { String($0) } ?? "inherit",
                     effectiveEnabled.map { String($0) } ?? "unknown"]
            + ["global"] + policy(globalPolicy) + ["override"] + policy(overridePolicy)
            + ["effective"] + policy(effectivePolicy)
            + ["risk-envelope", riskEnvelope.digest ?? ""] + policy(riskEnvelope.maxima)
            + [engineId, controlDisabledReason ?? ""]
            + darkhorseModels.map { "\($0.key):\($0.sha):\($0.trainedThreshold):\($0.scoreP99)" }
        // Length prefixes avoid ambiguity if a revision includes a separator.
        return parts.map { "\($0.utf8.count):\($0)" }.joined()
    }
}

public struct EngineConfigurationDraft: Equatable, Sendable {
    public var baseline: EngineConfigurationBaseline
    public var values: [String: DraftValue]
    public var enabled: DraftValue?

    public init(baseline: EngineConfigurationBaseline) {
        self.baseline = baseline
        values = [:]
        enabled = nil
    }

    public var isGlobal: Bool { baseline.scope.kind == .global }
    public var changeCount: Int { self.set.count + unset.count + (enabledChange == .unchanged ? 0 : 1) }
    public var hasChanges: Bool { changeCount > 0 }
    private var storedPolicy: [String: Double] { isGlobal ? baseline.globalPolicy : baseline.overridePolicy }

    public mutating func setValue(_ value: Double, for key: String) {
        if storedPolicy[key] == value { values.removeValue(forKey: key) }
        else { values[key] = .set(value) }
    }

    public mutating func useGlobal(for key: String) {
        guard !isGlobal else { return }
        if baseline.overridePolicy[key] == nil { values.removeValue(forKey: key) }
        else { values[key] = .useGlobal }
    }

    public mutating func discard(key: String) { values.removeValue(forKey: key) }
    public mutating func discardAll() { values.removeAll(); enabled = nil }

    public mutating func setEnabled(_ value: Bool) {
        if (isGlobal ? baseline.globalEnabled : baseline.overrideEnabled) == value { enabled = nil }
        else { enabled = .set(value ? 1 : 0) }
    }

    public mutating func inheritEnabled() {
        guard !isGlobal else { return }
        enabled = baseline.overrideEnabled == nil ? nil : .useGlobal
    }

    public func isChanged(_ key: String) -> Bool { set[key] != nil || unset.contains(key) }

    public func source(for key: String) -> PolicyValueSource {
        if isChanged(key) { return .drafted }
        if isGlobal { return .global }
        return baseline.overridePolicy[key] == nil ? .inherited : .overridden
    }

    public func currentValue(for key: String) -> Double? {
        switch values[key] {
        case let .set(value): return value
        case .useGlobal: return baseline.globalPolicy[key]
        case nil: return storedPolicy[key] ?? (baseline.engineId == "darkhorse" ? baseline.effectivePolicy[key] : baseline.globalPolicy[key])
        }
    }

    public func effectiveValue(for key: String) -> Double? {
        switch values[key] {
        case let .set(value): return value
        case .useGlobal: return baseline.globalPolicy[key]
        case nil: return baseline.effectivePolicy[key]
        }
    }

    public var effectivePolicy: [String: Double] {
        var policy = baseline.effectivePolicy
        for key in values.keys { policy[key] = effectiveValue(for: key) }
        return policy
    }

    public var effectiveEnabled: Bool? {
        switch enabled {
        case let .set(value): return value != 0
        case .useGlobal: return baseline.globalEnabled
        case nil: return baseline.effectiveEnabled
        }
    }

    public var set: [String: Double] {
        values.reduce(into: [:]) { result, pair in
            if case let .set(value) = pair.value, storedPolicy[pair.key] != value { result[pair.key] = value }
        }
    }

    public var unset: [String] {
        guard !isGlobal else { return [] }
        return values.keys.filter { values[$0] == .useGlobal && baseline.overridePolicy[$0] != nil }.sorted()
    }

    public var enabledChange: EngineConfigureValue.EnabledChange {
        switch enabled {
        case let .set(value):
            let flag = value != 0
            return (isGlobal ? baseline.globalEnabled : baseline.overrideEnabled) == flag ? .unchanged : .value(flag)
        case .useGlobal: return !isGlobal && baseline.overrideEnabled != nil ? .inherit : .unchanged
        case nil: return .unchanged
        }
    }

    public var conflicts: [PolicyConflict] { PolicyConflicts.check(effectivePolicy) }
    public var parameters: [PolicyParameter] {
        baseline.engineId == "darkhorse" ? DarkhorsePolicy.parameters(models: baseline.darkhorseModels) : PolicyCatalog.parameters
    }
    public func validate(key: String, value: Double) -> String? {
        if baseline.engineId == "darkhorse" {
            return DarkhorsePolicy.validate(key: key, value: value) ??
                DarkhorsePolicy.validateThreshold(key: key, value: value, models: baseline.darkhorseModels)
        }
        return PolicyBounds.validateFriendly(key: key, value: value, envelope: baseline.riskEnvelope)
    }
    public var validationErrors: [String: String] {
        // Validate saved and inherited values too, not just the edited fields.
        // Published keys outside the editable catalog remain read-only.
        var errors: [String: String] = [:]
        let editableKeys = Set(parameters.map(\.key))
        for (key, value) in effectivePolicy where editableKeys.contains(key) {
            if let error = validate(key: key, value: value) {
                errors[key] = error
            }
        }
        for pair in values {
            if case let .set(value) = pair.value, editableKeys.contains(pair.key),
               let error = validate(key: pair.key, value: value) {
                errors[pair.key] = error
            }
        }
        return errors
    }
    /// A saved or inherited value, not edited in this draft, above the reported or guarded maximum.
    /// Explanation only: validationErrors and blockingProblems still block it exactly as before.
    public func savedAboveMaximum(for key: String) -> (saved: Double, maximum: Double)? {
        guard baseline.engineId != "darkhorse", values[key] == nil, RiskEnvelope.hardMaxima[key] != nil,
              let parameter = PolicyCatalog.parameter(for: key),
              let saved = baseline.effectivePolicy[key], saved.isFinite else { return nil }
        let maximum = PolicyBounds.maximum(for: parameter, envelope: baseline.riskEnvelope)
        return saved > maximum ? (saved: saved, maximum: maximum) : nil
    }
    public var savedAboveMaximum: [String: (saved: Double, maximum: Double)] {
        parameters.reduce(into: [:]) { result, parameter in
            if let value = savedAboveMaximum(for: parameter.key) { result[parameter.key] = value }
        }
    }
    public func savedAboveMaximumExplanation(for key: String) -> String? {
        guard let value = savedAboveMaximum(for: key),
              let parameter = PolicyCatalog.parameter(for: key) else { return nil }
        let saved = PolicyValueFormatter.display(value.saved, parameter: parameter)
        let limit = PolicyValueFormatter.display(value.maximum, unit: parameter.unit)
        let maximumText: String
        if baseline.riskEnvelope.reportedKeys.contains(key) {
            // The runner clamps on load, but refuses values past the catalog bound.
            let applied = value.saved <= parameter.maximum ? " The runner applies \(limit)." : ""
            maximumText = "The runner's maximum is \(limit).\(applied)"
        } else {
            maximumText = "The app's guarded maximum is \(limit) because the runner has not reported its maximum."
        }
        return "Saved \(saved). \(maximumText) Lower it to \(limit) or less to send changes."
    }
    /// Parameter names with a saved value above the maximum, in catalog order.
    public var savedAboveMaximumNames: [String] {
        parameters.filter { savedAboveMaximum(for: $0.key) != nil }.map(\.name)
    }
    /// The validation messages of those saved values, so a problem list can name them once instead.
    public var savedAboveMaximumMessages: Set<String> {
        let errors = validationErrors
        return Set(parameters.compactMap { savedAboveMaximum(for: $0.key) != nil ? errors[$0.key] : nil })
    }
    public var blockingProblems: [String] {
        let errors = validationErrors
        var problems = errors.keys.sorted().compactMap { errors[$0] } + conflicts.filter { $0.severity == .error }.map(\.message)
        if let reason = baseline.controlDisabledReason { problems.append(reason) }
        if baseline.engineId == "darkhorse" {
            if isGlobal { problems.append("Darkhorse controls require an account.") }
            for key in DarkhorsePolicy.keys where key.hasPrefix("score_threshold_") {
                if let value = effectiveValue(for: key) {
                    if let error = validate(key: key, value: value) { problems.append(error) }
                } else { problems.append("Model threshold is not reported.") }
            }
        }
        return problems
    }

    public var changes: [EngineConfigurationChange] { changes(accountLabel: nil) }

    public func changes(accountLabel: String?) -> [EngineConfigurationChange] {
        let scopeText = isGlobal ? "All accounts" : String((accountLabel ?? "This account").prefix(128))
        var changes = parameters.compactMap { parameter -> EngineConfigurationChange? in
            let key = parameter.key
            guard isChanged(key), let edit = values[key] else { return nil }
            func formatted(_ value: Double?) -> String {
                if baseline.engineId == "darkhorse" {
                    return value.map { String(format: "%.12g", $0) } ?? "Unknown"
                }
                return value.map { PolicyValueFormatter.display($0, parameter: parameter) } ?? "Unknown"
            }
            let before = storedPolicy[key] ?? (baseline.engineId == "darkhorse" ? baseline.effectivePolicy[key] : baseline.globalPolicy[key])
            let inherited = !isGlobal && baseline.overridePolicy[key] == nil
            let oldText = inherited ? "Inherited (\(formatted(before)))" : formatted(before)
            let newText: String
            let effect: String
            switch edit {
            case let .set(value):
                newText = formatted(value)
                if before == value { effect = "Keeps this value as an account override." }
                else { effect = value > (before ?? parameter.minimum) ? parameter.whenHigher : parameter.whenLower }
            case .useGlobal:
                newText = "Use global (\(formatted(baseline.globalPolicy[key])))"
                effect = "Restores the global value."
            }
            return EngineConfigurationChange(id: key, name: parameter.name, oldText: oldText,
                newText: newText, scopeText: scopeText, effect: effect)
        }
        if enabledChange != .unchanged {
            func onOff(_ value: Bool?) -> String { value.map { $0 ? "On" : "Off" } ?? "Unknown" }
            let inherited = !isGlobal && baseline.overrideEnabled == nil
            let oldText = inherited ? "Inherited (\(onOff(baseline.globalEnabled)))" : onOff(baseline.effectiveEnabled)
            let newText: String
            let effect: String
            switch enabledChange {
            case let .value(value):
                newText = onOff(value)
                effect = value ? "This scope may open new positions again."
                    : "Blocks new positions in this scope. Existing positions keep their normal exit and risk handling."
            case .inherit:
                newText = "Use global (\(onOff(baseline.globalEnabled)))"
                effect = baseline.engineId == "darkhorse" ? "Restores the account default: new entries off." : "Follows the global setting."
            case .unchanged: return changes
            }
            changes.append(EngineConfigurationChange(id: "enabled", name: "Allow new positions",
                oldText: oldText, newText: newText, scopeText: scopeText, effect: effect))
        }
        return changes
    }

    public func intent(engineId: String, host: String, clientRequestId: String) throws -> ControlIntent {
        guard engineId == baseline.engineId else { throw ControlIntent.ValidationError.invalid("The engine changed. Reload settings.") }
        guard let revision = baseline.revision else {
            throw ControlIntent.ValidationError.invalid("The current runner version is unavailable.")
        }
        if let problem = blockingProblems.first { throw ControlIntent.ValidationError.invalid(problem) }
        return try ControlIntent.configure(engineId: engineId, host: host, scope: baseline.scope,
            enabled: enabledChange, set: set, unset: unset, expectedRevision: revision, clientRequestId: clientRequestId,
            envelope: baseline.riskEnvelope)
    }
}

public struct EngineConfigurationChange: Identifiable, Equatable, Sendable {
    public let id: String
    public let name: String
    public let oldText: String
    public let newText: String
    public let scopeText: String
    public let effect: String
}
