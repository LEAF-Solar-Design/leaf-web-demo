import Foundation

/// Pure text for probe surfaces. Null renders "Not reported", never zero, and no sentence is invented:
/// runner text passes through unchanged. Formatting is fixed (no locale), so both apps read the same.
public enum ProbePresentation {
    public static let notReported = "Not reported"

    /// "-$12.40 of $1,250.00 (50%) · UTC day". Loss and limit are cents; a negative loss is a gain.
    public static func breakerMeter(loss: Int?, limit: Int?, pct: Double?) -> String {
        guard let loss, let limit, loss != .min else { return notReported }
        var text = "\(signedDollars(-loss)) of \(dollars(limit))"
        if let pct, pct.isFinite { text += " (\(percent(pct)))" }
        return text + " · UTC day"
    }

    public static func breakerMeter(_ meter: BreakerMeter?) -> String {
        breakerMeter(loss: meter?.engineLossCents, limit: meter?.engineLimitCents, pct: meter?.enginePct)
    }

    public static func breakerMeter(_ account: AccountBreaker?) -> String {
        breakerMeter(loss: account?.lossCents, limit: account?.limitCents, pct: account?.pct)
    }

    /// "+3.2c per contract · n 41". The sample size is always shown with the number.
    public static func perContract(cents: Double?, n: Int) -> String {
        guard let cents, cents.isFinite else { return notReported }
        let tenths = (cents * 10).rounded() / 10
        let sign = tenths > 0 ? "+" : tenths < 0 ? "-" : ""
        return "\(sign)\(String(format: "%.1f", abs(tenths)))c per contract · n \(n)"
    }

    public static func perContract(_ live: EngineLiveStats?) -> String {
        guard let live else { return notReported }
        return perContract(cents: live.perContractCents, n: live.n)
    }

    /// The runner's next-step sentence exactly as sent; the code is for identity, never for wording.
    public static func nextStep(code: String?, text: String?) -> String {
        guard let text, !text.isEmpty else { return notReported }
        return text
    }

    static func dollars(_ cents: Int) -> String {
        let magnitude = cents.magnitude
        let fraction = magnitude % 100
        return "\(cents < 0 ? "-" : "")$\(grouped(magnitude / 100)).\(fraction < 10 ? "0" : "")\(fraction)"
    }

    static func signedDollars(_ cents: Int) -> String {
        cents > 0 ? "+" + dollars(cents) : dollars(cents)
    }

    static func grouped(_ value: UInt) -> String {
        let digits = String(value)
        var result = ""
        for (index, digit) in digits.enumerated() {
            if index > 0, (digits.count - index) % 3 == 0 { result += "," }
            result.append(digit)
        }
        return result
    }

    static func percent(_ pct: Double) -> String {
        if pct.rounded() == pct, abs(pct) < 1e15 { return "\(Int(pct))%" }
        return String(format: "%.1f%%", pct)
    }
}
