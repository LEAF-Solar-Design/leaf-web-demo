import Foundation

public enum PolicyCategory: String, CaseIterable, Codable, Sendable {
    case positionSizing, entryRequirements, priceAndEdge, riskAndDrawdown, exitBehavior, timingAndReentry, advanced

    public var title: String {
        switch self {
        case .positionSizing: return "Position sizing"
        case .entryRequirements: return "Entry requirements"
        case .priceAndEdge: return "Price and edge"
        case .riskAndDrawdown: return "Risk and drawdown"
        case .exitBehavior: return "Exit behavior"
        case .timingAndReentry: return "Timing and re-entry"
        case .advanced: return "Advanced settings"
        }
    }

    public var summary: String {
        switch self {
        case .positionSizing: return "How much capital each position may use."
        case .entryRequirements: return "Evidence and liquidity required before opening a position."
        case .priceAndEdge: return "Prices that qualify for entry and favorite handling."
        case .riskAndDrawdown: return "Limits on losses, drawdown and cash committed."
        case .exitBehavior: return "When and how existing positions may be sold."
        case .timingAndReentry: return "How long positions stay open and when entries may resume."
        case .advanced: return "Additional conviction and profit rules for sizing."
        }
    }
}

public enum PolicyUnit: String, Codable, Sendable {
    case fraction, probability, cents, centsAsDollars, dollars, seconds, milliseconds, contracts, count, multiplier

    public var label: String {
        switch self {
        case .fraction: return "percent"
        case .probability: return "confidence"
        case .cents: return "cents"
        case .centsAsDollars, .dollars: return "dollars"
        case .seconds: return "seconds"
        case .milliseconds: return "milliseconds"
        case .contracts: return "contracts"
        case .count: return "observations"
        case .multiplier: return "multiplier"
        }
    }
}

public enum PolicyControl: String, Codable, Sendable { case toggle, stepper, slider, field }

public struct PolicyImpact: OptionSet, Codable, Sendable, Hashable {
    public let rawValue: Int
    public init(rawValue: Int) { self.rawValue = rawValue }
    public static let entries = PolicyImpact(rawValue: 1)
    public static let exits = PolicyImpact(rawValue: 2)
    public static let sizing = PolicyImpact(rawValue: 4)
    public static let risk = PolicyImpact(rawValue: 8)

    public var labels: [String] {
        let labels: [(PolicyImpact, String)] = [(.entries, "Entries"), (.exits, "Exits"), (.sizing, "Sizing"), (.risk, "Risk")]
        return labels.compactMap { contains($0.0) ? $0.1 : nil }
    }
}

public struct PolicyGuidanceThresholds: Codable, Sendable, Equatable {
    public let aggressiveAbove: Double?
    public let aggressiveBelow: Double?
    public let restrictiveAbove: Double?
    public let restrictiveBelow: Double?

    public init(aggressiveAbove: Double? = nil, aggressiveBelow: Double? = nil,
                restrictiveAbove: Double? = nil, restrictiveBelow: Double? = nil) {
        self.aggressiveAbove = aggressiveAbove
        self.aggressiveBelow = aggressiveBelow
        self.restrictiveAbove = restrictiveAbove
        self.restrictiveBelow = restrictiveBelow
    }
}

public struct PolicyParameter: Identifiable, Codable, Sendable, Equatable {
    public var id: String { key }
    public let key: String
    public let name: String
    public let summary: String
    public let category: PolicyCategory
    public let unit: PolicyUnit
    public let minimum: Double
    public let maximum: Double
    public let isInteger: Bool
    public let step: Double
    public let control: PolicyControl
    public let impact: PolicyImpact
    public let whenHigher: String
    public let whenLower: String
    public let zeroMeaning: String?
    public let searchTerms: [String]
    public let advanced: Bool
    public let guidance: PolicyGuidanceThresholds?

    public var rangeText: String {
        let range = "\(PolicyValueFormatter.display(minimum, unit: unit)) to \(PolicyValueFormatter.display(maximum, unit: unit))"
        return unit == .count ? range + " observations" : range
    }

    public func matches(_ query: String) -> Bool {
        let query = String(query.prefix(256)).trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return true }
        let terms = [name, summary, category.title, unit.label, key, key.replacingOccurrences(of: "_", with: " ")]
            + impact.labels + searchTerms
        let searchableTerms = terms.map { $0.lowercased() }
        if searchableTerms.contains(where: { $0.contains(query) }) { return true }
        let connectors: Set<String> = ["a", "an", "the", "and", "or", "of", "for", "to", "in", "on", "with", "one"]
        let words = query.split(whereSeparator: { $0.isWhitespace }).map(String.init)
            .filter { !connectors.contains($0) }
        let searchableWords = Set(searchableTerms.flatMap {
            $0.split(whereSeparator: { !$0.isLetter && !$0.isNumber && $0 != "_" }).map(String.init)
        })
        return words.allSatisfy { searchableWords.contains($0) }
    }
}

public enum PolicyCatalog {
    private static func parameter(
        _ key: String, _ name: String, _ category: PolicyCategory, _ unit: PolicyUnit,
        _ minimum: Double, _ maximum: Double, _ isInteger: Bool, _ step: Double,
        _ control: PolicyControl, _ impact: PolicyImpact, advanced: Bool = false,
        guidance: PolicyGuidanceThresholds? = nil,
        summary: String, higher: String, lower: String, zero: String? = nil, terms: [String]
    ) -> PolicyParameter {
        PolicyParameter(key: key, name: name, summary: summary, category: category, unit: unit,
            minimum: minimum, maximum: maximum, isInteger: isInteger, step: step, control: control,
            impact: impact, whenHigher: higher, whenLower: lower, zeroMeaning: zero,
            searchTerms: terms + [key, key.replacingOccurrences(of: "_", with: " ")],
            advanced: advanced, guidance: guidance)
    }

    public static let parameters: [PolicyParameter] = [
        parameter("size_fraction", "Position size", .positionSizing, .fraction, 0, 0.5, false, 0.01, .slider, .sizing,
            guidance: .init(aggressiveAbove: 0.35, restrictiveBelow: 0.02),
            summary: "Research sizing dial before amplification. The 10% market cap applies after amplification, or a tighter per-order cap if configured.",
            higher: "Each position uses more of the account, so wins and losses both grow.",
            lower: "Each position uses less capital, so swings are smaller and more cash stays free.",
            terms: ["size", "stake", "capital", "exposure", "bet size", "position size", "size fraction"]),
        parameter("favorite_mult", "Favorite size multiplier", .positionSizing, .multiplier, 1, 10, true, 1, .stepper, .sizing,
            guidance: .init(aggressiveAbove: 7),
            summary: "How many times larger a position on a strong favorite may be than a normal position.",
            higher: "Favorites get much larger positions than ordinary entries.",
            lower: "Favorites are sized closer to ordinary entries; 1 removes the bonus.",
            terms: ["favorite", "multiplier", "times", "bonus", "favorite mult"]),
        parameter("stake_ceiling_usd", "Maximum stake", .positionSizing, .dollars, 1, 500, false, 1, .field, [.sizing, .risk],
            guidance: .init(aggressiveAbove: 300),
            summary: "Hard dollar ceiling on the stake of any one position.",
            higher: "Single positions can grow larger in dollars.",
            lower: "Every position is capped at a smaller dollar amount whatever the account size.",
            terms: ["stake", "maximum", "dollar", "ceiling", "cap", "stake ceiling"]),
        parameter("per_order_fraction", "Per-order cap", .positionSizing, .fraction, 0, 1.0, false, 0.01, .slider, [.sizing, .risk],
            guidance: .init(restrictiveBelow: 0.05),
            summary: "Largest share of capital any single order may commit, whatever the sizing law says.",
            higher: "One order may commit more capital at once.",
            lower: "Each order is capped tighter, so large entries shrink.",
            zero: "0% blocks every order.", terms: ["order", "cap", "per order", "single order"]),
        parameter("cluster_fraction", "Cluster exposure cap", .positionSizing, .fraction, 0, 1.0, false, 0.01, .slider, [.sizing, .risk],
            guidance: .init(restrictiveBelow: 0.05),
            summary: "Largest share of capital that can be open across related markets at the same time.",
            higher: "More capital can be concentrated in one cluster of markets.",
            lower: "Exposure spreads thinner across clusters.",
            zero: "0% blocks new entries in every cluster.", terms: ["cluster", "concentration", "related markets", "exposure cap"]),
        parameter("min_k", "Minimum observations", .entryRequirements, .count, 0, 59, true, 1, .stepper, .entries,
            guidance: .init(aggressiveBelow: 3, restrictiveAbove: 40),
            summary: "Price observations the engine needs inside the settlement minute before it will enter.",
            higher: "Entries wait for more evidence, so fewer and later tickets.",
            lower: "Entries fire sooner on less evidence.",
            zero: "0 allows entry on the first observation.", terms: ["observations", "samples", "k", "evidence", "wait", "minute", "min k"]),
        parameter("edge_threshold_cents", "Minimum edge", .entryRequirements, .cents, 1, 50, false, 0.5, .slider, .entries,
            guidance: .init(aggressiveBelow: 1.5, restrictiveAbove: 15),
            summary: "Smallest advantage over the market price, in cents per contract, that justifies an entry.",
            higher: "Only clearly mispriced markets qualify, so fewer entries.",
            lower: "Marginal opportunities qualify too, so more entries with thinner margins.",
            terms: ["edge", "threshold", "advantage", "margin", "mispricing", "edge threshold"]),
        parameter("favorite_edge_threshold_cents", "Favorite minimum edge", .entryRequirements, .cents, 0, 50, false, 0.5, .slider, .entries,
            guidance: .init(aggressiveBelow: 0.5),
            summary: "Lower edge bar for a contract priced at or above the favorite price. It must not exceed Minimum edge.",
            higher: "Favorites need more edge, closer to ordinary entries.",
            lower: "Favorites enter with less edge.",
            zero: "0¢ lets favorites enter with any positive edge.", terms: ["favorite", "edge", "bar", "favorite edge"]),
        parameter("min_depth", "Minimum entry depth", .entryRequirements, .contracts, 1, 10000, true, 1, .field, .entries,
            guidance: .init(restrictiveAbove: 500),
            summary: "Contracts that must be available at the quoted price before the engine enters.",
            higher: "Only deep, liquid quotes qualify, so fewer entries.",
            lower: "Thin quotes qualify too, with more slippage risk.",
            terms: ["depth", "liquidity", "contracts", "book", "min depth"]),
        parameter("big_edge_cents", "Large edge check", .entryRequirements, .cents, 0, 99, false, 1, .field, [.entries, .risk],
            summary: "An edge this large or larger looks too good and must pass the large edge confidence check.",
            higher: "Fewer edges trigger the extra check.",
            lower: "More edges must pass the extra confidence check.",
            zero: "0¢ turns the check off.", terms: ["big edge", "large edge", "suspicious", "sanity", "too good"]),
        parameter("big_edge_min_prob", "Large edge confidence", .entryRequirements, .probability, 0.5, 1, false, 0.01, .slider, [.entries, .risk],
            advanced: true, guidance: .init(aggressiveBelow: 0.6),
            summary: "Model confidence required on the bought side when the edge is unusually large.",
            higher: "Large-edge entries need near certainty.",
            lower: "Large-edge entries pass with less confidence.",
            terms: ["confidence", "probability", "big edge", "large edge"]),
        parameter("min_price_cents", "Minimum entry price", .priceAndEdge, .cents, 0, 99, true, 1, .slider, .entries,
            guidance: .init(aggressiveBelow: 10),
            summary: "Never buy a contract priced below this.",
            higher: "Cheap long shots are skipped.", lower: "Cheaper long shots qualify.",
            zero: "0¢ turns the floor off.", terms: ["price", "floor", "cheap", "long shot", "min price"]),
        parameter("max_price_cents", "Maximum entry price", .priceAndEdge, .cents, 0, 99, true, 1, .slider, .entries,
            summary: "Never buy a contract priced above this.",
            higher: "Expensive, near-certain contracts qualify.", lower: "Expensive contracts are skipped.",
            zero: "0¢ turns the ceiling off.", terms: ["price", "ceiling", "expensive", "max price"]),
        parameter("favorite_price_cents", "Favorite price", .priceAndEdge, .cents, 0, 99, true, 1, .slider, [.entries, .sizing],
            guidance: .init(aggressiveBelow: 60),
            summary: "A contract priced at or above this counts as a favorite and uses the favorite edge bar and size multiplier.",
            higher: "Fewer contracts count as favorites.",
            lower: "More contracts count as favorites and get favorite sizing.",
            zero: "0¢ turns favorite handling off.", terms: ["favorite", "price", "favorite price"]),
        parameter("daily_loss_fraction", "Daily loss limit", .riskAndDrawdown, .fraction, 0, 1.0, false, 0.01, .slider, [.risk, .entries],
            guidance: .init(aggressiveAbove: 0.5, restrictiveBelow: 0.02),
            summary: "Share of capital the engine may lose in one day before it stops entering.",
            higher: "The engine keeps entering through larger daily losses.",
            lower: "Entries stop after a smaller daily loss.",
            zero: "0% stops entries after any loss.", terms: ["loss", "daily", "limit", "stop", "daily loss"]),
        parameter("drawdown_brake_fraction", "Drawdown slowdown", .riskAndDrawdown, .fraction, 0, 1.0, false, 0.01, .slider, [.risk, .sizing],
            guidance: .init(aggressiveAbove: 0.5),
            summary: "Drawdown from the peak at which position sizes start shrinking.",
            higher: "Sizes stay full through deeper drawdowns.", lower: "Sizes shrink sooner after losses.",
            zero: "0% never shrinks sizes for drawdown.", terms: ["drawdown", "brake", "slowdown", "shrink", "peak"]),
        parameter("drawdown_stop_fraction", "Drawdown stop", .riskAndDrawdown, .fraction, 0, 1.0, false, 0.01, .slider, [.risk, .entries],
            guidance: .init(aggressiveAbove: 0.6),
            summary: "Drawdown from the peak at which new entries stop. It must be above the slowdown.",
            higher: "The engine keeps entering through deeper drawdowns.", lower: "Entries stop after a smaller drawdown.",
            terms: ["drawdown", "stop", "halt", "peak", "drawdown stop"]),
        parameter("cash_floor_cents", "Minimum cash reserve", .riskAndDrawdown, .centsAsDollars, 0, 100000, true, 100, .field, [.risk, .entries],
            summary: "Cash that must stay untouched; the engine will not enter if a position would dip below it.",
            higher: "More cash stays idle and fewer entries fit.", lower: "More cash can be put to work.",
            zero: "$0.00 keeps no reserve.", terms: ["cash", "reserve", "floor", "keep", "cash floor"]),
        parameter("risk_resize_live", "Trim orders to fit risk limits", .riskAndDrawdown, .count, 0, 1, true, 1, .toggle, [.risk, .entries],
            summary: "When on, a live order larger than the remaining risk room is cut down to what fits and still goes through.",
            higher: "On cuts an oversized order down to the remaining risk room so the smaller order can go through.",
            lower: "Off refuses the entire order if it exceeds the remaining risk room, so no trade happens.",
            zero: "Off refuses the entire order if it exceeds the remaining risk room, so no trade happens.",
            terms: ["trim", "smaller order", "risk room", "risk limits", "remaining room", "refuse order"]),
        parameter("exit_margin_cents", "Exit margin", .exitBehavior, .cents, 0, 50, false, 0.5, .slider, .exits,
            guidance: .init(restrictiveAbove: 20),
            summary: "Extra cents the exit price must clear above the hold value before the engine sells out.",
            higher: "Exits wait for a better price and happen less often.", lower: "Exits trigger more readily.",
            zero: "0¢ turns the exit rule off.", terms: ["exit", "margin", "sell", "exit margin"]),
        parameter("exit_prob_ceiling", "Exit probability ceiling", .exitBehavior, .probability, 0, 1, false, 0.01, .slider, .exits,
            summary: "Above this model probability the engine stops trying to exit and lets the position settle.",
            higher: "More positions are held to settlement.", lower: "More positions are exited early.",
            terms: ["exit", "settle", "hold", "probability", "ceiling"]),
        parameter("exit_variance_scale", "Exit variance multiplier", .exitBehavior, .multiplier, 1, 5, false, 0.1, .slider, .exits,
            advanced: true,
            summary: "Multiplies the model's uncertainty when judging exits; 1× uses the model as is.",
            higher: "The engine treats outcomes as less certain and exits more cautiously.",
            lower: "The engine trusts the model more when deciding exits.",
            terms: ["variance", "uncertainty", "exit", "scale"]),
        parameter("exit_min_depth", "Minimum exit depth", .exitBehavior, .contracts, 0, 10000, true, 1, .field, .exits,
            advanced: true, guidance: .init(restrictiveAbove: 500),
            summary: "Contracts that must be bid before the engine sells into the book.",
            higher: "Exits wait for deeper bids.", lower: "Exits accept thinner bids.",
            zero: "0 contracts exits into any bid.", terms: ["exit", "depth", "bid", "liquidity"]),
        parameter("exit_max_quote_age_ms", "Maximum exit quote age", .exitBehavior, .milliseconds, 0, 600000, true, 250, .field, .exits,
            advanced: true,
            summary: "Oldest quote the engine will trust when exiting.",
            higher: "Older quotes still count, so exits keep working through quiet feeds.",
            lower: "Only very fresh quotes count, so exits may wait.",
            zero: "0 ms turns the age check off.", terms: ["quote", "age", "stale", "fresh", "exit"]),
        parameter("exit_min_hold_s", "Minimum hold time", .timingAndReentry, .seconds, 0, 120, true, 1, .slider, .exits,
            summary: "How long a position is held before an exit is considered.",
            higher: "Positions are held longer before any exit.", lower: "Exits can happen sooner.",
            zero: "0 seconds allows an immediate exit.", terms: ["hold", "time", "seconds", "wait", "min hold"]),
        parameter("reentry_block_s", "Wait before re-entry", .timingAndReentry, .seconds, 0, 900, true, 5, .field, .entries,
            guidance: .init(restrictiveAbove: 600),
            summary: "How long after leaving a market the engine waits before entering it again.",
            higher: "Re-entries are rarer.", lower: "The engine can re-enter quickly.",
            zero: "0 seconds allows immediate re-entry.", terms: ["reentry", "re-entry", "cooldown", "wait", "block"]),
        parameter("exit_min_hold_fraction", "Minimum hold share", .timingAndReentry, .fraction, 0, 1, false, 0.05, .slider, .exits,
            advanced: true, guidance: .init(restrictiveAbove: 0.8),
            summary: "Share of the market's remaining life a position is held before an exit is considered.",
            higher: "Positions ride longer toward settlement.", lower: "Exits may happen early in the market's life.",
            zero: "0% turns this hold off.", terms: ["hold", "share", "fraction", "life", "exit"]),
        parameter("conviction_min", "Conviction floor", .advanced, .multiplier, 0.1, 1, false, 0.05, .slider, .sizing,
            advanced: true,
            summary: "Lowest multiplier the conviction law may apply to position size.",
            higher: "Low-conviction entries are still sized near full.", lower: "Low-conviction entries get much smaller.",
            terms: ["conviction", "confidence", "floor", "minimum"]),
        parameter("conviction_max", "Conviction ceiling", .advanced, .multiplier, 1, 5, false, 0.1, .slider, .sizing,
            advanced: true, guidance: .init(aggressiveAbove: 3),
            summary: "Highest multiplier the conviction law may apply to position size.",
            higher: "High-conviction entries can be sized well above the base size.",
            lower: "1× keeps every entry at or below the base size.",
            terms: ["conviction", "confidence", "ceiling", "maximum"]),
        parameter("target_win_cents", "Target win", .advanced, .centsAsDollars, 0, 5000, true, 25, .field, .sizing,
            advanced: true,
            summary: "Profit per position the sizing law aims for when choosing a contract count.",
            higher: "The engine buys more contracts to reach a larger target.",
            lower: "The engine settles for a smaller target and fewer contracts.",
            zero: "$0.00 turns the target off.", terms: ["target", "win", "profit", "goal"]),
        parameter("min_win_cents", "Minimum win", .advanced, .centsAsDollars, 0, 5000, true, 25, .field, [.entries, .sizing],
            advanced: true,
            summary: "Smallest acceptable profit per position; entries that cannot reach it are skipped.",
            higher: "More marginal entries are skipped.", lower: "Smaller wins are accepted.",
            zero: "$0.00 turns the check off.", terms: ["minimum", "win", "profit", "skip"])
    ]

    public static let byKey = Dictionary(uniqueKeysWithValues: parameters.map { ($0.key, $0) })
    public static func parameter(for key: String) -> PolicyParameter? { byKey[key] }

    public static func grouped(_ keys: [String]? = nil) -> [(category: PolicyCategory, parameters: [PolicyParameter])] {
        let requested = keys.map { Set($0) }
        return PolicyCategory.allCases.compactMap { category in
            let members = parameters.filter { $0.category == category && (requested?.contains($0.key) ?? true) }
            return members.isEmpty ? nil : (category: category, parameters: members)
        }
    }

    public static func search(_ query: String, in keys: [String]? = nil) -> [PolicyParameter] {
        grouped(keys).flatMap(\.parameters).filter { $0.matches(query) }
    }
}
