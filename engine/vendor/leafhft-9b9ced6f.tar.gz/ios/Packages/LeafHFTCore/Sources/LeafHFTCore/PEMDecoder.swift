import Foundation

public enum PEMDecodeError: Error, Equatable {
    case notPEM, unsupportedLabel(String), encrypted, badBase64, malformedDER(String), notRSA
}

private struct DERReader {
    let bytes: [UInt8]
    var offset = 0
    var isAtEnd: Bool { offset == bytes.count }
    mutating func read(_ tag: UInt8) throws -> [UInt8] {
        guard offset < bytes.count, bytes[offset] == tag else {
            throw PEMDecodeError.malformedDER("Unexpected tag")
        }
        offset += 1
        guard offset < bytes.count else { throw PEMDecodeError.malformedDER("Missing length") }
        let first = bytes[offset]
        offset += 1
        var length = Int(first)
        if first & 0x80 != 0 {
            let count = Int(first & 0x7f)
            guard count > 0, count <= MemoryLayout<Int>.size, count <= bytes.count - offset,
                  bytes[offset] != 0 else { throw PEMDecodeError.malformedDER("Invalid length") }
            length = 0
            for _ in 0..<count {
                guard length <= (Int.max - Int(bytes[offset])) / 256 else {
                    throw PEMDecodeError.malformedDER("Length overflow")
                }
                length = length * 256 + Int(bytes[offset])
                offset += 1
            }
            guard length >= 128 else { throw PEMDecodeError.malformedDER("Nonminimal length") }
        }
        guard length <= bytes.count - offset else { throw PEMDecodeError.malformedDER("Truncated value") }
        let value = Array(bytes[offset..<(offset + length)])
        offset += length
        return value
    }
}

private func validateSequence(_ data: Data) throws {
    var reader = DERReader(bytes: Array(data))
    let value = try reader.read(0x30)
    guard !value.isEmpty, reader.isAtEnd else { throw PEMDecodeError.malformedDER("Invalid sequence") }
}

public func decodeRSAPrivateKeyPEM(_ text: String) throws -> Data {
    let lines = text.components(separatedBy: .newlines)
        .map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
    guard let first = lines.first, first.hasPrefix("-----BEGIN "), first.hasSuffix("-----") else {
        throw PEMDecodeError.notPEM
    }
    let label = String(first.dropFirst(11).dropLast(5))
    if label == "ENCRYPTED PRIVATE KEY" || text.contains("Proc-Type: 4,ENCRYPTED") {
        throw PEMDecodeError.encrypted
    }
    guard label == "RSA PRIVATE KEY" || label == "PRIVATE KEY" else {
        throw PEMDecodeError.unsupportedLabel(label)
    }
    guard lines.count >= 3, lines.last == "-----END \(label)-----" else { throw PEMDecodeError.notPEM }
    let body = lines.dropFirst().dropLast().joined()
    guard let data = Data(base64Encoded: body), !data.isEmpty else { throw PEMDecodeError.badBase64 }
    try validateSequence(data)
    if label == "RSA PRIVATE KEY" { return data }
    var outer = DERReader(bytes: Array(data))
    var sequence = DERReader(bytes: try outer.read(0x30))
    guard try sequence.read(0x02) == [0] else { throw PEMDecodeError.malformedDER("Expected version zero") }
    var algorithm = DERReader(bytes: try sequence.read(0x30))
    let oid = try algorithm.read(0x06)
    guard oid == [0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01] else {
        throw PEMDecodeError.notRSA
    }
    if !algorithm.isAtEnd {
        guard try algorithm.read(0x05).isEmpty, algorithm.isAtEnd else {
            throw PEMDecodeError.malformedDER("Invalid RSA parameters")
        }
    }
    let privateKey = Data(try sequence.read(0x04))
    // PKCS#8 permits optional attributes after the key.
    if !sequence.isAtEnd { _ = try sequence.read(0xa0) }
    guard sequence.isAtEnd else { throw PEMDecodeError.malformedDER("Trailing data") }
    try validateSequence(privateKey)
    return privateKey
}
