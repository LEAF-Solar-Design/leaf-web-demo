import Foundation

/// Published evidence and local text drafts for the Engine Lab workshop.
public enum EngineWorkshop {
    public enum ReadinessKind: String, CaseIterable {
        case dataCoverage = "data_coverage", holdoutEvidence = "holdout_evidence"
        case riskLimits = "risk_limits", accountIntegration = "account_integration", telemetry
        public var label: String {
            switch self {
            case .dataCoverage: return "Data coverage"
            case .holdoutEvidence: return "Holdout evidence"
            case .riskLimits: return "Risk limits"
            case .accountIntegration: return "Account integration"
            case .telemetry: return "Telemetry"
            }
        }
    }
    public enum ReadinessStatus: String, CaseIterable {
        case reported, partial, noted, notReported = "not_reported"
        public var label: String { self == .notReported ? "Not reported" : rawValue.capitalized }
    }
    public struct ReadinessItem: Equatable, Identifiable {
        public let kind: ReadinessKind
        public let status: ReadinessStatus
        public let detail: String
        public let asOf: String?
        public var id: String { kind.rawValue }
    }
    public static let riskKeys = ["per_order_fraction", "cluster_fraction", "daily_loss_fraction",
        "cash_floor_cents", "drawdown_brake_fraction", "drawdown_stop_fraction", "stake_ceiling_usd"]

    public static func readiness(engine: Engine, accountId: String?, generatedAt: String?,
                                 observedAt: Date?, now: Date,
                                 accounts: [EngineControlAccount] = []) -> [ReadinessItem] {
        let configuration = accountId.flatMap { EngineLab.configuration(engine: engine, accountId: $0) }
        let account = accounts.first { $0.id == accountId }
        let policy = configuration?.effective.policy ?? [:]
        let risks = riskKeys.filter { policy[$0]?.isFinite == true }
        let freshness = EngineLab.freshness(generatedAt: generatedAt, observedAt: observedAt, now: now)
        var coverage = "Ticket count and last ticket time are not published. Tape coverage is not published to the app."
        var coverageStatus = ReadinessStatus.notReported
        if let count = engine.pnl?.n, let last = engine.pnl?.lastTicketAt, !last.isEmpty {
            coverage = "\(count) tickets reported, last \(last). Tape coverage is not published to the app."
            coverageStatus = .partial
        }
        let integration: ReadinessStatus = configuration == nil ? .notReported :
            (account.map { EngineLab.canOpenSettings(account: $0, engine: engine) } == true ? .reported : .partial)
        return [
            ReadinessItem(kind: .dataCoverage, status: coverageStatus, detail: coverage, asOf: generatedAt),
            ReadinessItem(kind: .holdoutEvidence, status: .notReported,
                detail: "Holdout results are not published to the app.", asOf: nil),
            ReadinessItem(kind: .riskLimits, status: risks.isEmpty ? .notReported : (risks.count == 7 ? .reported : .partial),
                detail: risks.isEmpty ? "Account-effective risk limits not reported." :
                    "\(risks.count) of 7 reported. " + risks.map { "\($0): \(number(policy[$0]))" }.joined(separator: "; "),
                asOf: configuration?.observedAt),
            ReadinessItem(kind: .accountIntegration, status: integration,
                detail: configuration == nil ? "Account configuration not reported." :
                    (integration == .reported ? "Account configuration and settings navigation are reported." :
                        "Account configuration is reported; settings navigation is unavailable."),
                asOf: configuration?.observedAt),
            ReadinessItem(kind: .telemetry, status: freshness == .current ? .reported :
                (freshness == .delayed ? .partial : .notReported), detail: freshness.rawValue, asOf: generatedAt)
        ]
    }

    public static func readiness(lane: EngineLab.Lane) -> [ReadinessItem] {
        ReadinessKind.allCases.map { kind in
            let note = lane.readiness[kind.rawValue]
            return ReadinessItem(kind: kind,
                status: kind == .telemetry ? .notReported : (note?.status == .noted ? .noted : .notReported),
                detail: kind == .telemetry ? "Notes are not live telemetry." : (note?.note ?? "Not reported."),
                asOf: note?.asOf)
        }
    }

    public struct AccountDial: Equatable, Identifiable {
        public let accountId: String
        public let label: String
        public let value: Double?
        public let differs: Bool
        public var id: String { accountId }
        public var valueText: String { EngineWorkshop.number(value) }
    }
    public struct DialComparison: Equatable, Identifiable {
        public let key: String
        public let name: String
        public let globalValue: Double?
        public let accounts: [AccountDial]
        public var id: String { key }
        public var globalText: String { EngineWorkshop.number(globalValue) }
    }
    public static func dialComparison(engine: Engine, accounts: [EngineControlAccount]) -> [DialComparison] {
        let global = engine.configuration?.global.policy ?? [:]
        let policies = accounts.map { EngineLab.configuration(engine: engine, accountId: $0.id)?.effective.policy ?? [:] }
        let keys = policies.reduce(Set(global.keys)) { $0.union($1.keys) }
        return keys.sorted().map { key in
            let globalValue = finite(global[key])
            return DialComparison(key: key, name: PolicyCatalog.parameter(for: key)?.name ?? key,
                globalValue: globalValue, accounts: accounts.enumerated().map { index, account in
                    let value = finite(policies[index][key])
                    return AccountDial(accountId: account.id, label: account.label, value: value,
                        differs: value != nil && globalValue != nil && value != globalValue)
                })
        }
    }

    public enum BriefAudience: Equatable { case share, studio }
    public enum StudioIntent: Equatable { case design, test }

    public static func brief(engine: Engine, accountId: String?, accounts: [EngineControlAccount],
                             generatedAt: String?, observedAt: Date?, now: Date, fixture: Bool,
                             audience: BriefAudience = .share, redactingIdentifiers: [String] = []) -> String {
        let account = accounts.first { $0.id == accountId }
        let selected = account.flatMap {
            EngineLab.canOpenSettings(account: $0, engine: engine) || EngineLab.yourLane(in: accounts) == $0.id ? $0 : nil
        }
        let policy = selected.flatMap { EngineLab.configuration(engine: engine, accountId: $0.id)?.effective.policy }
        // Only catalog keys and numeric values enter exported text. Unknown server keys may carry identifiers.
        let dials = (policy ?? [:]).keys.sorted().filter { PolicyCatalog.parameter(for: $0) != nil }
            .map { "\($0): \(number(policy?[$0]))" }.joined(separator: "; ")
        let items = readiness(engine: engine, accountId: selected?.id, generatedAt: generatedAt,
            observedAt: observedAt, now: now, accounts: accounts)
        let identifiers = redactingIdentifiers + accounts.map(\.id) + accounts.map(\.host) +
            (engine.configuration?.accounts.map(\.accountId) ?? []) + [engine.host ?? ""] +
            (audience == .share ? accounts.map(\.label) : [])
        return buildBrief(name: engine.name ?? "Published engine",
            stage: selected.map { EngineLab.entriesLabel(engine: engine, accountId: $0.id) } ?? "Account not selected",
            freshness: EngineLab.freshness(generatedAt: generatedAt, observedAt: observedAt, now: now).rawValue,
            account: selected.map { audience == .studio ? $0.label : "one account" } ?? "Account not selected",
            dials: dials.isEmpty ? "Effective dials unknown" : "Effective dials: " + dials,
            items: items, fixture: fixture, identifiers: identifiers)
    }

    public static func brief(lane: EngineLab.Lane, fixture: Bool,
                             redactingIdentifiers: [String] = []) -> String {
        buildBrief(name: lane.name, stage: lane.stage.label, freshness: "Notes are not live telemetry.",
            account: "Account not selected", dials: "Effective dials unknown", items: readiness(lane: lane),
            fixture: fixture, identifiers: redactingIdentifiers + [lane.id, lane.engineId ?? ""])
    }

    public static func studioPrompt(_ intent: StudioIntent, _ brief: String) -> String {
        let request = intent == .design ? "Design a change using this published context." :
            "Design a test for this idea. Identify missing data and holdout evidence."
        return request + "\n\n" + brief +
            "\n\nDo not apply anything. If a change is warranted, produce a config draft for my review."
    }

    private static func finite(_ value: Double?) -> Double? { value.flatMap { $0.isFinite ? $0 : nil } }
    private static func number(_ value: Double?) -> String { finite(value).map { String($0) } ?? "Unknown" }
    private static func buildBrief(name: String, stage: String, freshness: String, account: String,
                                   dials: String, items: [ReadinessItem], fixture: Bool,
                                   identifiers: [String]) -> String {
        func clean(_ value: String, limit: Int) -> String {
            var value = value
            for id in Set(identifiers).filter({ !$0.isEmpty }).sorted(by: { $0.count > $1.count }) {
                value = value.replacingOccurrences(of: id, with: "[omitted]")
            }
            // Do not export credential-like strings, URLs, hostnames or UUIDs embedded in display text.
            for pattern in [#"https?://\S+"#, #"\b[\w-]+(?:\.[\w-]+)*\.[A-Za-z]{2,}\b"#,
                            #"\b[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b"#,
                            #"[A-Za-z0-9_+/=-]{32,}"#] {
                value = value.replacingOccurrences(of: pattern, with: "[omitted]", options: .regularExpression)
            }
            value = value.split(whereSeparator: { $0.isNewline }).joined(separator: " ")
            return value.count > limit ? String(value.prefix(limit - 1)) + "…" : value
        }
        var lines = fixture ? ["Fixture data, not a live account"] : []
        lines += [clean(name, limit: 80), clean(stage, limit: 80), clean(freshness, limit: 60),
                  "Scope: " + clean(account, limit: 80), clean(dials, limit: 350)]
        lines += items.map {
            "\($0.kind.label): \($0.status.label). " + clean($0.detail, limit: $0.kind == .riskLimits ? 400 : 120) +
                ($0.asOf.map { " As of " + clean($0, limit: 24) } ?? "")
        }
        let footer = "\n\nRequested change:\n\nContext only. This text changes nothing."
        return String(lines.joined(separator: "\n").prefix(2000 - footer.count)) + footer
    }
}
