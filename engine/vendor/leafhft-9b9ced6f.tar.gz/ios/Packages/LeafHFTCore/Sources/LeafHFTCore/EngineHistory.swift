import Foundation

public enum EngineHistoryRange: String, CaseIterable, Identifiable {
    case day, week, month, all
    public var id: String { rawValue }
    public var label: String {
        switch self { case .day: return "1d"; case .week: return "7d"; case .month: return "30d"; case .all: return "All" }
    }
}

public struct EngineHistoryResponse: Codable {
    public let schemaVersion: Int
    public let generatedAt: Date
    public let venue: String
    public let range: String
    public let since: Date?
    public let until: Date
    public let coverage: EngineHistoryCoverage
    public let accounts: [EngineHistoryAccount]
    public let engines: [EngineHistoryEntry]

    public func performance(engineId: String? = nil, accountId: String? = nil) -> EnginePerformance {
        let selected = engines.filter { engineId == nil || $0.engineId == engineId }
        if let accountId {
            let rows = selected.flatMap(\.accounts).filter {
                accountId == "unassigned" ? $0.accountId == nil : $0.accountId == accountId
            }
            return EnginePerformance(summaries: rows.map(\.summary), points: rows.flatMap(\.series))
        }
        return EnginePerformance(summaries: selected.map(\.summary), points: selected.flatMap(\.series))
    }
}

public struct EngineHistoryCoverage: Codable {
    public let scope: String
    public let ticketsDropped: Bool?
    public let truncated: Bool
    public let unassignedN: Int
    public let missingPnlN: Int
}

public struct EngineHistoryAccount: Codable, Identifiable {
    public let id: String
    public let label: String
    public let host: String
    public let subaccountNumber: Int
}

public struct EngineHistoryEntry: Codable {
    public let engineId: String?
    public let host: String
    public let name: String
    public let summary: EngineHistorySummary
    public let series: [EngineHistoryPoint]
    public let accounts: [EngineAccountHistory]
}

public struct EngineAccountHistory: Codable {
    public let accountId: String?
    public let summary: EngineHistorySummary
    public let series: [EngineHistoryPoint]
}

public struct EngineHistorySummary: Codable {
    public let realizedPnlCents: Double?
    public let settlementsN: Int
    public let exitsN: Int
    public let wonN: Int
    public let openN: Int
    public var missingPnlN: Int? = nil
}

public struct EngineHistoryPoint: Codable, Identifiable {
    public let day: String
    public let pnlCents: Double?
    public let settlementsN: Int
    public let exitsN: Int
    public var id: String { day }
    public var date: Date? {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: day)
    }
}

/// Add disjoint source/account totals, never average precomputed win rates.
public struct EnginePerformance {
    public let summary: EngineHistorySummary
    public let series: [EngineHistoryPoint]
    public var winRate: Double? {
        let outcomes = summary.settlementsN + summary.exitsN - (summary.missingPnlN ?? 0)
        return outcomes > 0 ? Double(summary.wonN) / Double(outcomes) : nil
    }
    public init(summaries: [EngineHistorySummary], points: [EngineHistoryPoint]) {
        let values = summaries.compactMap(\.realizedPnlCents)
        summary = EngineHistorySummary(realizedPnlCents: values.isEmpty ? nil : values.reduce(0, +),
            settlementsN: summaries.reduce(0) { $0 + $1.settlementsN },
            exitsN: summaries.reduce(0) { $0 + $1.exitsN },
            wonN: summaries.reduce(0) { $0 + $1.wonN },
            openN: summaries.reduce(0) { $0 + $1.openN },
            missingPnlN: summaries.reduce(0) { $0 + ($1.missingPnlN ?? 0) })
        let grouped = Dictionary(grouping: points, by: \.day)
        series = grouped.keys.sorted().map { day in
            let rows = grouped[day] ?? []
            let values = rows.compactMap(\.pnlCents)
            return EngineHistoryPoint(day: day, pnlCents: values.isEmpty ? nil : values.reduce(0, +),
                settlementsN: rows.reduce(0) { $0 + $1.settlementsN },
                exitsN: rows.reduce(0) { $0 + $1.exitsN })
        }
    }
}
