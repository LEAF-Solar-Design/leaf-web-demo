import Foundation

/// Scale bounds for the observations visible in an Account history range.
public struct AccountChartDomain: Equatable, Sendable {
    public let x: ClosedRange<Date>
    public let y: ClosedRange<Double>

    public init(dates: [Date], dollars: [Double]) {
        if let first = dates.min(), let last = dates.max() {
            let span = last.timeIntervalSince(first)
            let padding = span > 0 ? span * 0.05 : 60
            x = first.addingTimeInterval(-padding)...last.addingTimeInterval(padding)
        } else {
            x = Date(timeIntervalSince1970: 0)...Date(timeIntervalSince1970: 120)
        }

        if let low = dollars.min(), let high = dollars.max() {
            let span = high - low
            let padding = span > 0 ? max(span * 0.05, 0.01) : max(abs(low) * 0.05, 1)
            y = (low - padding)...(high + padding)
        } else {
            y = 0...1
        }
    }
}
