import Foundation

public enum ChartReduction {
    public struct Sample: Equatable, Sendable {
        public let date: Date
        public let value: Double

        public init(date: Date, value: Double) {
            self.date = date
            self.value = value
        }
    }

    /// Keeps at most about `maxPoints` samples of one continuous run without moving its shape.
    public static func reduce(_ run: [Sample], maxPoints: Int) -> [Sample] {
        guard maxPoints >= 4, run.count > maxPoints else { return run }
        let bucketCount = maxPoints / 2
        let first = run[0].date
        let span = run[run.count - 1].date.timeIntervalSince(first)
        var result: [Sample] = []
        result.reserveCapacity(maxPoints + 2)
        var lastIndex = -1
        func append(_ index: Int) {
            guard index > lastIndex else { return }
            if result.last != run[index] { result.append(run[index]) }
            lastIndex = index
        }
        var bucket = 0
        var minimum = 0
        var maximum = 0
        func flush() {
            append(min(minimum, maximum))
            append(max(minimum, maximum))
        }
        append(0)
        for index in run.indices {
            let nextBucket = span > 0
                ? min(bucketCount - 1, Int(run[index].date.timeIntervalSince(first) / span * Double(bucketCount)))
                : 0
            if nextBucket != bucket {
                flush()
                bucket = nextBucket
                minimum = index
                maximum = index
            } else {
                if run[index].value < run[minimum].value { minimum = index }
                if run[index].value > run[maximum].value { maximum = index }
            }
        }
        flush()
        append(run.count - 1)
        return result
    }

    /// Splits a series' drawing budget across its runs in proportion to their size, at least `minimumPerRun` each.
    public static func budgets(runCounts: [Int], total: Int, minimumPerRun: Int = 4) -> [Int] {
        let sum = runCounts.reduce(0, +)
        guard sum > total, sum > 0 else { return runCounts }
        return runCounts.map { max(minimumPerRun, total * $0 / sum) }
    }
}
