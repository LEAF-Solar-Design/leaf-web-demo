import Foundation

public struct MarketsResponse: Codable {
    public var markets: [Market]?
    public var cursor: String?
}

/// Decode with accountJSONDecoder(), just like the portfolio responses.
public struct Market: Codable {
    public var ticker: String
    public var yesSubTitle: String?
    public var status: String?
    public var result: String?
    public var closeTime: String?
    public var yesBidDollars: String?
    public var yesAskDollars: String?
    public var lastPriceDollars: String?

    public var yesBid: Decimal? { LiveBoardMath.decimal(yesBidDollars) }
    public var yesAsk: Decimal? { LiveBoardMath.decimal(yesAskDollars) }
    public var lastPrice: Decimal? { LiveBoardMath.decimal(lastPriceDollars) }
}
