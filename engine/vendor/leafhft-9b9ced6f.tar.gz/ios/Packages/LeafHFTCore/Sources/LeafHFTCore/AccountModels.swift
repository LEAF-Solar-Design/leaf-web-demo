import Foundation

/// Use this decoder for both Kalshi and mobile snake_case payloads.
public func accountJSONDecoder() -> JSONDecoder {
    let decoder = JSONDecoder()
    decoder.keyDecodingStrategy = .convertFromSnakeCase
    return decoder
}

public enum KashbotTradingPocket {
    public static let exchangeIndex = 2
    public static let label = "Trading cash (exchange index 2)"
}

public extension AccountBalance {
    var tradingPocketCents: Cents? { cashCents(exchangeIndex: KashbotTradingPocket.exchangeIndex) }
}

public struct AccountBalance: Codable, Equatable {
    public var balance: Int?
    /// Venue-reported mark of open positions, excluding cash.
    public var portfolioValue: Int?
    public var exchangeIndex: Int?
    public var balanceBreakdown: [BalanceBreakdown]?
    public var updatedTs: Int?
    public var cash: Money? { balance.map { Money(cents: Cents($0)) } }
    public var positionsMark: Money? { portfolioValue.map { Money(cents: Cents($0)) } }
    public var accountValue: Money? {
        guard let balance, let portfolioValue else { return nil }
        let sum = balance.addingReportingOverflow(portfolioValue)
        return sum.overflow ? nil : Money(cents: Cents(sum.partialValue))
    }
    public func cashCents(exchangeIndex: Int) -> Cents? {
        guard let pocket = balanceBreakdown?.first(where: { $0.exchangeIndex == exchangeIndex }) else { return nil }
        return try? Cents(decimalString: pocket.balance)
    }
}
public struct BalanceBreakdown: Codable, Equatable {
    public var balance: String
    public var exchangeIndex: Int
}
public struct PositionsResponse: Codable {
    public var marketPositions: [Position]?
    public var cursor: String?
}
public struct Position: Codable, Equatable {
    public var ticker: String
    public var marketExposure: Int?
    public var restingOrdersCount: Int?
    public var positionFp: String?
    public var marketExposureDollars: String?
    public var realizedPnlDollars: String?
    public var feesPaidDollars: String?
    public var exposure: Money? { marketExposureDollars.flatMap { try? Money(decimalString: $0) } }
}
public struct FillsResponse: Codable {
    public var fills: [Fill]?
    public var cursor: String?
}
public struct Fill: Codable {
    public var tradeId: String
    public var ticker: String
    public var orderId: String?
    public var countFp: String?
    public var yesPriceDollars: String?
    public var noPriceDollars: String?
    public var feeCost: String?
    public var side: String?
    public var action: String?
    public var createdTime: String?
    public var yesPrice: Money? { yesPriceDollars.flatMap { try? Money(decimalString: $0) } }
    public var noPrice: Money? { noPriceDollars.flatMap { try? Money(decimalString: $0) } }
    public var fee: Money? { feeCost.flatMap { try? Money(decimalString: $0) } }
}
public struct SettlementsResponse: Codable {
    public var settlements: [Settlement]?
    public var cursor: String?
}
public struct Settlement: Codable {
    public var ticker: String
    public var yesCountFp: String?
    public var noCountFp: String?
    public var yesTotalCostDollars: String?
    public var noTotalCostDollars: String?
    public var revenue: Int?
    public var feeCost: String?
    public var marketResult: String?
    public var settledTime: String?
    public var yesTotalCost: Money? { yesTotalCostDollars.flatMap { try? Money(decimalString: $0) } }
    public var noTotalCost: Money? { noTotalCostDollars.flatMap { try? Money(decimalString: $0) } }
    public var fee: Money? { feeCost.flatMap { try? Money(decimalString: $0) } }
    public var payout: Money? { revenue.map { Money(cents: Cents($0)) } }
}
