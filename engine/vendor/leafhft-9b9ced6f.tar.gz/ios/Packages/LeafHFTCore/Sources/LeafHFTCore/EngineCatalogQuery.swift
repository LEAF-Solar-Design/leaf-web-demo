import Foundation

/// The Engines catalog's local query. Runner offsets break every tie, including missing metrics.
public struct EngineCatalogQuery: Equatable, Sendable {
    public enum Sort: String, CaseIterable, Sendable {
        case runner, name, netHigh, netLow, perContract, winRate, rate

        public var title: String {
            switch self {
            case .runner: return "Runner order"
            case .name: return "Name"
            case .netHigh: return "Net P&L high to low"
            case .netLow: return "Net P&L low to high"
            case .perContract: return "Per contract"
            case .winRate: return "Win rate"
            case .rate: return "Rate"
            }
        }
    }

    public enum Show: String, CaseIterable, Sendable {
        case all, accepting, paused, attention

        public var title: String {
            switch self {
            case .all: return "All engines"
            case .accepting: return "Accepting entries"
            case .paused: return "Paused"
            case .attention: return "Needs attention"
            }
        }
    }

    public var text: String {
        didSet { text = Self.normalized(text) }
    }
    public var sort: Sort
    public var show: Show
    /// nil means all accounts; "unassigned" includes missing and empty assignments.
    public var accountId: String?

    public init(text: String = "", sort: Sort = .runner, show: Show = .all, accountId: String? = nil) {
        self.text = Self.normalized(text)
        self.sort = sort
        self.show = show
        self.accountId = accountId
    }

    public var isFiltering: Bool { !text.isEmpty || show != .all || accountId != nil }

    private static func normalized(_ value: String) -> String {
        String(value.trimmingCharacters(in: .whitespacesAndNewlines).prefix(64))
    }

    public static func winRate(_ engine: Engine) -> Double? {
        guard let count = engine.pnl?.n, count > 0, let won = engine.pnl?.won else { return nil }
        return Double(won) / Double(count)
    }

    /// Linear, allocation-light cache key for every input used by search, sorting and attention.
    /// Preserve runner order because offsets break ties. Time only matters at suspension expiry.
    public static func fingerprint(_ engines: [Engine], accountLabels: [String: String] = [:],
                                   now: Date = Date()) -> Int {
        var hash = Hasher()
        for engine in engines {
            hash.combine(engine.engineId)
            hash.combine(engine.name)
            hash.combine(engine.description)
            hash.combine(engine.parentEngineId)
            hash.combine(engine.host)
            hash.combine(engine.assignment?.accountId)
            hash.combine(engine.boundBooks)
            hash.combine(engine.markets)
            hash.combine(engine.pnl?.netCents)
            hash.combine(engine.pnl?.n)
            hash.combine(engine.pnl?.won)
            hash.combine(engine.pnl?.ticketsPerHour)
            hash.combine(engine.live?.perContractCents)
            hash.combine(engine.lifecycle?.state.rawValue)
            hash.combine(engine.lifecycle?.breaker?.engineLossCents)
            hash.combine(engine.lifecycle?.breaker?.engineLimitCents)
            hash.combine(engine.lifecycle?.entriesSuspendedUntil)
            hash.combine(engine.lifecycle?.entriesSuspendedUntil.map { $0 > now })
            hash.combine(engine.configuration?.global.enabled)
        }
        for id in accountLabels.keys.sorted() {
            hash.combine(id)
            hash.combine(accountLabels[id])
        }
        return hash.finalize()
    }

    public static func entryText(_ enabled: Bool?) -> String {
        switch enabled {
        case true?: return "Accepting new entries"
        case false?: return "New entries paused"
        case nil: return "Unknown"
        }
    }

    public static func attentionReason(_ engine: Engine, now: Date, error: String? = nil,
                                       pending: Bool = false) -> String? {
        if let error { return error }
        if pending { return "Entry change pending" }
        if engine.lifecycle?.state == .halted { return "Engine halted" }
        if let until = engine.lifecycle?.entriesSuspendedUntil, until > now { return "Entries suspended" }
        if let breaker = engine.lifecycle?.breaker,
           let loss = breaker.engineLossCents, let limit = breaker.engineLimitCents, limit > 0,
           Double(loss) / Double(limit) >= 0.75 { return "Breaker at or above 75% of its limit" }
        return nil
    }

    public func apply(_ engines: [Engine], accountLabels: [String: String] = [:], now: Date = Date(),
                      enabled: (Engine) -> Bool? = { $0.configuration?.global.enabled },
                      attention: (Engine) -> Bool = { _ in false }) -> [Engine] {
        let tokens = text.split(whereSeparator: { $0.isWhitespace }).map(String.init)
        let candidates = engines.enumerated().filter { _, engine in
            let assignment = engine.assignment?.accountId.flatMap { $0.isEmpty ? nil : $0 } ?? "unassigned"
            if let accountId, assignment != accountId { return false }
            switch show {
            case .all: break
            case .accepting: if enabled(engine) != true { return false }
            case .paused: if enabled(engine) != false { return false }
            case .attention:
                if Self.attentionReason(engine, now: now) == nil && !attention(engine) { return false }
            }
            let fields = [engine.name, engine.engineId, engine.description, engine.parentEngineId,
                          engine.host, engine.assignment?.accountId, accountLabels[assignment]].compactMap { $0 }
                + (engine.boundBooks ?? []) + (engine.markets ?? [])
            return tokens.allSatisfy { token in fields.contains { $0.localizedStandardContains(token) } }
        }
        func metric(_ engine: Engine) -> Double? {
            let value: Double?
            switch sort {
            case .netHigh, .netLow: value = engine.pnl?.netCents
            case .perContract: value = engine.live?.perContractCents
            case .winRate: value = Self.winRate(engine)
            case .rate: value = engine.pnl?.ticketsPerHour
            case .runner, .name: value = nil
            }
            return value.flatMap { $0.isFinite ? $0 : nil }
        }
        return candidates.sorted { lhs, rhs in
            switch sort {
            case .runner: return lhs.offset < rhs.offset
            case .name:
                let order = (lhs.element.name ?? lhs.element.engineId)
                    .localizedStandardCompare(rhs.element.name ?? rhs.element.engineId)
                return order == .orderedSame ? lhs.offset < rhs.offset : order == .orderedAscending
            default:
                switch (metric(lhs.element), metric(rhs.element)) {
                case let (left?, right?) where left != right:
                    return sort == .netLow ? left < right : left > right
                case (_?, nil): return true
                case (nil, _?): return false
                default: return lhs.offset < rhs.offset
                }
            }
        }.map(\.element)
    }
}
