import Foundation

/// Shared research is advisory. Account trading controls remain on their own rail.
public enum EngineLab {
    public static func reasonText(_ reason: String) -> String {
        guard reason.contains("not_reported") else { return reason }
        let text = reason.replacingOccurrences(of: "not_reported", with: "not reported")
        return text.prefix(1).uppercased() + text.dropFirst()
    }

    /// Runner evidence is separate from bundled research notes and grants no authority.
    public typealias Lifecycle = EngineLifecycle

    public indirect enum ResearchValue: Codable, Equatable {
        case text(String), number(Double), flag(Bool), array([ResearchValue]), object([String: ResearchValue]), null

        public init(from decoder: Decoder) throws {
            let value = try decoder.singleValueContainer()
            if value.decodeNil() { self = .null }
            else if let flag = try? value.decode(Bool.self) { self = .flag(flag) }
            else if let text = try? value.decode(String.self) { self = .text(text) }
            else if let number = try? value.decode(Double.self), number.isFinite { self = .number(number) }
            else if let array = try? value.decode([ResearchValue].self) { self = .array(array) }
            else { self = .object(try value.decode([String: ResearchValue].self)) }
        }
        public func encode(to encoder: Encoder) throws {
            var value = encoder.singleValueContainer()
            switch self {
            case let .text(text): try value.encode(text)
            case let .number(number): try value.encode(number)
            case let .flag(flag): try value.encode(flag)
            case let .array(array): try value.encode(array)
            case let .object(object): try value.encode(object)
            case .null: try value.encodeNil()
            }
        }
        public var display: String {
            switch self {
            case let .text(text): return text == "not_reported" ? "Not reported" : text
            case let .number(number): return String(format: "%.12g", number)
            case let .flag(flag): return flag ? "Yes" : "No"
            case let .array(array): return array.map(\.display).joined(separator: ", ")
            case let .object(object): return object.keys.sorted().map { "\($0): \(object[$0]!.display)" }.joined(separator: "\n")
            case .null: return "Not reported"
            }
        }
        public var isMissing: Bool { self == .text("not_reported") || self == .null }
    }

    public struct LiveEvidence: Codable, Equatable {
        public let candidateId: String
        public let kind: String
        public let sourceTimestamp: ResearchValue
        public let provenance: String
        public let source: String
        public let sourceHash: String
        public let status: String
        public let reason: String
        public let metrics: ResearchValue
        public let liveProfitCents: ResearchValue
        public let verdict: String?

        enum CodingKeys: String, CodingKey {
            case candidateId, kind, sourceTimestamp, provenance, source, sourceHash, status, reason
            case metrics, liveProfitCents, verdict
        }
        public init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            candidateId = try values.decode(String.self, forKey: .candidateId)
            kind = try values.decode(String.self, forKey: .kind)
            sourceTimestamp = try values.decode(ResearchValue.self, forKey: .sourceTimestamp)
            provenance = try values.decode(String.self, forKey: .provenance)
            source = try values.decode(String.self, forKey: .source)
            sourceHash = try values.decode(String.self, forKey: .sourceHash)
            status = try values.decode(String.self, forKey: .status)
            reason = try values.decode(String.self, forKey: .reason)
            metrics = try values.decodeIfPresent(ResearchValue.self, forKey: .metrics) ?? .null
            liveProfitCents = try values.decode(ResearchValue.self, forKey: .liveProfitCents)
            verdict = try values.decodeIfPresent(String.self, forKey: .verdict)
        }
    }

    /// A single simulated report, never a sum of report history or live fills.
    public struct PaperResults: Equatable {
        public let resolved: Int?
        public let open: Int?
        public let wins: Int?
        public let losses: Int?
        public let simulatedNetCents: Double?
        public let returnOnFixedBase: Double?
        public let drawdownCents: Double?
        public let drawdownFraction: Double?
        public let setupMetrics: [String: ResearchValue]
        public let explicitlyCollecting: Bool

        public init(metrics: ResearchValue = .null, status: String? = nil) {
            let fields: [String: ResearchValue]
            if case let .object(object) = metrics { fields = object } else { fields = [:] }
            func number(_ keys: [String]) -> Double? {
                for key in keys {
                    guard let value = fields[key] else { continue }
                    let number: Double?
                    switch value {
                    case let .number(raw): number = raw
                    case let .text(raw): number = Double(raw.trimmingCharacters(in: .whitespacesAndNewlines))
                    default: number = nil
                    }
                    if let number, number.isFinite { return number }
                }
                return nil
            }
            func count(_ keys: [String]) -> Int? {
                guard let value = number(keys), value >= 0 else { return nil }
                return Int(exactly: value)
            }
            resolved = count(["resolved", "resolved_count", "resolved_trades", "completed", "n"])
            open = count(["open", "open_count", "open_trades"])
            wins = count(["wins", "won"])
            losses = count(["losses", "lost"])
            simulatedNetCents = number(["simulated_net_cents", "net_cents", "pnl_cents"])
            returnOnFixedBase = number(["return_on_fixed_base", "return_fraction"])
            drawdownCents = number(["max_drawdown_cents", "drawdown_cents"]).flatMap { $0 >= 0 ? $0 : nil }
            drawdownFraction = number(["max_drawdown_fraction", "drawdown_fraction"]).flatMap { $0 >= 0 ? $0 : nil }
            var splits: [String: ResearchValue] = [:]
            for key in ["setups", "by_setup", "setup_splits"] {
                if let value = fields[key], case let .object(object) = value { splits = object; break }
            }
            setupMetrics = ["A": fields["setup_a"] ?? splits["A"] ?? splits["a"] ?? .null,
                            "B": fields["setup_b"] ?? splits["B"] ?? splits["b"] ?? .null]
            let reportedStatus: String?
            if let value = fields["status"], case let .text(text) = value { reportedStatus = text } else { reportedStatus = nil }
            explicitlyCollecting = [status, reportedStatus].compactMap { $0?.lowercased() }
                .contains { ["collecting", "collecting_evidence", "pending", "warming_up"].contains($0) }
        }

        public var hasMetrics: Bool {
            resolved != nil || open != nil || wins != nil || losses != nil || simulatedNetCents != nil ||
                returnOnFixedBase != nil || drawdownCents != nil || drawdownFraction != nil
        }
        public var isCollecting: Bool { explicitlyCollecting || resolved == nil || resolved == 0 }
        public var statusLabel: String { isCollecting ? "Collecting evidence" : "Paper results available" }
        public var countsLabel: String { "Resolved: \(Self.countText(resolved)) · Open: \(Self.countText(open))" }
        public var outcomesLabel: String { "Wins: \(Self.countText(wins)) · Losses: \(Self.countText(losses))" }
        public var simulatedPnLLabel: String { "Simulated P&L: \(Self.moneyText(simulatedNetCents))" }
        public var returnLabel: String { "Simulated return: \(Self.percentText(returnOnFixedBase))" }
        public var drawdownLabel: String {
            "Simulated drawdown: " + (drawdownCents != nil ? Self.moneyText(drawdownCents) : Self.percentText(drawdownFraction))
        }
        public func setup(_ name: String) -> PaperResults { PaperResults(metrics: setupMetrics[name] ?? .null) }
        public static func countText(_ value: Int?) -> String { value.map(String.init) ?? "Unavailable" }
        private static func moneyText(_ value: Double?) -> String {
            guard let value, value.isFinite else { return "Unavailable" }
            if abs(value) >= 100_000_000_000 { return String(format: "%.4g USD", value / 100) }
            return String(format: "%@%.2f USD", value < 0 ? "-" : "", abs(value) / 100)
        }
        private static func percentText(_ value: Double?) -> String {
            guard let value, value.isFinite, (value * 100).isFinite else { return "Unavailable" }
            if abs(value) >= 1_000_000 { return String(format: "%.4g%%", value * 100) }
            return String(format: "%.2f%%", value * 100)
        }
    }

    public struct Candidate: Codable, Identifiable, Equatable {
        public let id: String
        public let engineId: String
        public let name: String
        public let enabled: Bool
        public let shadowOnly: Bool
        public let reason: String
        public let promotionVerdict: String
        public let liveProfitCents: ResearchValue
        public let evidence: [LiveEvidence]
        public let sourceTimestamp: ResearchValue
        public let provenance: String
        public let trialIds: [String]?
        public let registeredMode: String?
        public var paperModeLabel: String {
            if registeredMode == "paper" { return "Paper" }
            if registeredMode == "shadow" { return "Shadow" }
            return ["paper", "replay"].contains(provenance) ? "Paper" : "Shadow"
        }
        public var paperEvidence: LiveEvidence? {
            let simulated = evidence.filter {
                ["paper", "shadow", "replay"].contains($0.provenance) &&
                    !["trial_registration", "generated_engine_registration"].contains($0.kind)
            }
            let reports = simulated.filter { $0.kind == "report" }
            return (reports.isEmpty ? simulated : reports).enumerated().max { left, right in
                let leftDate = EngineLab.date(left.element.sourceTimestamp.display) ?? .distantPast
                let rightDate = EngineLab.date(right.element.sourceTimestamp.display) ?? .distantPast
                return leftDate == rightDate ? left.offset < right.offset : leftDate < rightDate
            }?.element
        }
        public var paperResults: PaperResults {
            let evidence = paperEvidence
            return PaperResults(metrics: evidence?.metrics ?? .null, status: evidence?.status)
        }
        public var stageLabel: String { shadowOnly ? "Shadow only" : "Promotion passed, disabled by default" }
        public var workshopLane: Lane {
            Lane(laneId: id, engineId: engineId, name: name, stage: .shadow, owner: nil,
                hypothesis: "Discovered candidate. See source evidence and provenance before planning a change.",
                evidence: evidence.map { Evidence(label: $0.kind, value: "\($0.provenance): \($0.metrics.display)", asOf: $0.sourceTimestamp.display) },
                nextAction: reason, readiness: [:])
        }
    }

    public struct Event: Codable, Identifiable, Equatable {
        public struct Actor: Codable, Equatable {
            public let deviceId: String
            public let deviceName: String
        }
        public let id: String
        public let clientRequestId: String
        public let engineId: String
        public let kind: String
        public let payload: [String: String]
        public let actor: Actor
        public let createdAt: String
        public let advisory: Bool
    }

    public struct Response: Decodable, Equatable {
        public let schemaVersion: Int
        public let generatedAt: String
        public let candidates: [Candidate]
        public let evidence: [LiveEvidence]
        public let problems: [String]
        public let missingValue: String
        public let advisory: Bool
        public let stale: Bool
        public var events: [Event]
        public let eventsTruncated: Bool

        public func events(for engineId: String) -> [Event] {
            events.filter { $0.engineId == engineId }.sorted {
                $0.createdAt == $1.createdAt ? $0.id > $1.id : $0.createdAt > $1.createdAt
            }
        }
        public func owner(for engineId: String) -> String {
            events(for: engineId).first { $0.kind == "owner" }?.payload["owner"] ?? "No owner reported"
        }
        public func assignmentState(_ event: Event) -> String {
            events(for: event.engineId).first {
                $0.kind == "assignment_state" && $0.payload["assignment_id"] == event.id
            }?.payload["state"] ?? "open"
        }
        public func validated() throws -> Response {
            guard schemaVersion == 3, advisory, missingValue == "not_reported", EngineLab.date(generatedAt) != nil,
                  events.count <= 200,
                  Set(candidates.map(\.id)).count == candidates.count,
                  Set(events.map(\.id)).count == events.count,
                  candidates.allSatisfy({ candidate in
                      candidate.id == candidate.engineId && !candidate.enabled && !candidate.name.isEmpty &&
                      candidate.evidence.allSatisfy { $0.candidateId == candidate.id } &&
                      (candidate.liveProfitCents.isMissing || candidate.provenance == "live_fill")
                  }), candidates.flatMap(\.evidence) == evidence,
                  evidence.allSatisfy({ $0.liveProfitCents.isMissing || $0.provenance == "live_fill" }),
                  events.allSatisfy({ $0.advisory }) else { throw NotesError.invalidContract }
            return self
        }
    }

    public struct EventInput: Encodable, Equatable {
        public let clientRequestId: String
        public let engineId: String
        public let kind: String
        public let payload: [String: String]

        public init(engineId: String, kind: String, payload: [String: String], clientRequestId: String = UUID().uuidString.lowercased()) throws {
            let fields: [String: [String: Int]] = ["owner": ["owner": 80], "comment": ["text": 2000],
                "assignment": ["assignee": 80, "title": 240], "assignment_state": ["assignment_id": 36, "state": 20],
                "decision": ["action": 20, "reason": 2000]]
            guard UUID(uuidString: clientRequestId) != nil,
                  engineId.range(of: "^[a-z0-9][a-z0-9-]{0,63}$", options: .regularExpression) != nil,
                  let limits = fields[kind], Set(payload.keys) == Set(limits.keys),
                  payload.allSatisfy({ !$0.value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
                      $0.value.count <= limits[$0.key]! }) else { throw NotesError.invalidContract }
            if kind == "decision", !["promote", "hold", "kill", "extend"].contains(payload["action"] ?? "") { throw NotesError.invalidContract }
            if kind == "assignment_state", UUID(uuidString: payload["assignment_id"] ?? "") == nil ||
                !["open", "in_progress", "done", "cancelled"].contains(payload["state"] ?? "") { throw NotesError.invalidContract }
            self.clientRequestId = clientRequestId
            self.engineId = engineId
            self.kind = kind
            self.payload = payload.mapValues { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        }
    }

    public struct EventResponse: Decodable { public let event: Event; public let advisory: Bool }

    public static func decodeResponse(_ data: Data) throws -> Response {
        guard data.count <= 1_048_576 else { throw NotesError.invalidContract }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return try decoder.decode(Response.self, from: data).validated()
    }

    /// Deterministic v3 preview used only when fixture mode is explicitly enabled.
    /// The legacy engine-lab.json fixture remains the offline workshop contract.
    public static let previewResponseJSON = #"""
{
  "schema_version": 3,
  "generated_at": "2026-09-20T12:00:00Z",
  "candidates": [
    {
      "id": "darkhorse",
      "name": "Darkhorse",
      "shadow_only": false,
      "reason": "Promotion passed; account engine is disabled by default",
      "promotion_verdict": "SUCCESS",
      "evidence": [
        {
          "candidate_id": "darkhorse",
          "kind": "darkhorse_snapshot",
          "source_timestamp": "2026-09-20T12:00:00Z",
          "provenance": "shadow",
          "source": "TrialStore/darkhorse",
          "source_hash": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
          "status": "reported",
          "reason": "not_reported",
          "metrics": {
            "evaluated": 24,
            "selected": 3
          },
          "live_profit_cents": "not_reported"
        }
      ],
      "engine_id": "darkhorse",
      "enabled": false,
      "engine": {
        "engine_id": "darkhorse",
        "enabled": false,
        "default_enabled": false,
        "evidence_hash": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
      },
      "live_profit_cents": "not_reported",
      "source_timestamp": "2026-09-20T12:00:00Z",
      "provenance": "shadow",
      "trial_ids": [
        "darkhorse-trial"
      ],
      "registered_mode": "shadow"
    },
    {
      "id": "dip-recovery",
      "name": "Dip Recovery",
      "shadow_only": true,
      "reason": "Holdout evidence is not reported. Shadow only.",
      "promotion_verdict": "not_reported",
      "evidence": [
        {
          "candidate_id": "dip-recovery",
          "kind": "report",
          "source_timestamp": "2026-09-20T12:00:00Z",
          "provenance": "replay",
          "source": "TrialStore/dip-recovery",
          "source_hash": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
          "status": "reported",
          "reason": "not_reported",
          "metrics": {
            "simulated_net_cents": 240,
            "resolved": 8,
            "open": 2,
            "wins": 5,
            "losses": 3,
            "return_on_fixed_base": 0.024,
            "max_drawdown_cents": 80,
            "setups": {
              "A": {"resolved": 5, "open": 1, "wins": 3, "losses": 2, "simulated_net_cents": 160},
              "B": {"resolved": 3, "open": 1, "wins": 2, "losses": 1, "simulated_net_cents": 80}
            },
            "holdout": "not_reported"
          },
          "live_profit_cents": "not_reported"
        }
      ],
      "engine_id": "dip-recovery",
      "enabled": false,
      "engine": null,
      "live_profit_cents": "not_reported",
      "source_timestamp": "2026-09-20T12:00:00Z",
      "provenance": "replay",
      "trial_ids": [
        "dip-recovery-trial"
      ],
      "registered_mode": "paper"
    },
    {
      "id": "atlas-discovery",
      "name": "Atlas Discovery",
      "shadow_only": true,
      "reason": "Newly discovered trial awaiting review.",
      "promotion_verdict": "not_reported",
      "evidence": [
        {
          "candidate_id": "atlas-discovery",
          "kind": "trial_registration",
          "source_timestamp": "2026-09-20T12:00:00Z",
          "provenance": "paper",
          "source": "TrialStore/atlas-discovery",
          "source_hash": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
          "status": "reported",
          "reason": "not_reported",
          "metrics": {
            "hypothesis": "Compare matched frames",
            "observations": 64
          },
          "live_profit_cents": "not_reported"
        }
      ],
      "engine_id": "atlas-discovery",
      "enabled": false,
      "engine": null,
      "live_profit_cents": "not_reported",
      "source_timestamp": "2026-09-20T12:00:00Z",
      "provenance": "paper",
      "trial_ids": [
        "atlas-discovery-trial"
      ],
      "registered_mode": "paper"
    }
  ],
  "evidence": [
    {
      "candidate_id": "darkhorse",
      "kind": "darkhorse_snapshot",
      "source_timestamp": "2026-09-20T12:00:00Z",
      "provenance": "shadow",
      "source": "TrialStore/darkhorse",
      "source_hash": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "status": "reported",
      "reason": "not_reported",
      "metrics": {
        "evaluated": 24,
        "selected": 3
      },
      "live_profit_cents": "not_reported"
    },
    {
      "candidate_id": "dip-recovery",
      "kind": "report",
      "source_timestamp": "2026-09-20T12:00:00Z",
      "provenance": "replay",
      "source": "TrialStore/dip-recovery",
      "source_hash": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "status": "reported",
      "reason": "not_reported",
      "metrics": {
        "simulated_net_cents": 240,
        "resolved": 8,
        "open": 2,
        "wins": 5,
        "losses": 3,
        "return_on_fixed_base": 0.024,
        "max_drawdown_cents": 80,
        "setups": {
          "A": {"resolved": 5, "open": 1, "wins": 3, "losses": 2, "simulated_net_cents": 160},
          "B": {"resolved": 3, "open": 1, "wins": 2, "losses": 1, "simulated_net_cents": 80}
        },
        "holdout": "not_reported"
      },
      "live_profit_cents": "not_reported"
    },
    {
      "candidate_id": "atlas-discovery",
      "kind": "trial_registration",
      "source_timestamp": "2026-09-20T12:00:00Z",
      "provenance": "paper",
      "source": "TrialStore/atlas-discovery",
      "source_hash": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "status": "reported",
      "reason": "not_reported",
      "metrics": {
        "hypothesis": "Compare matched frames",
        "observations": 64
      },
      "live_profit_cents": "not_reported"
    }
  ],
  "problems": [],
  "missing_value": "not_reported",
  "live_profit_cents": "not_reported",
  "advisory": true,
  "stale": false,
  "events": [
    {
      "id": "11111111-1111-4111-8111-000000000005",
      "client_request_id": "22222222-2222-4222-8222-000000000005",
      "engine_id": "dip-recovery",
      "kind": "assignment_state",
      "payload": {
        "assignment_id": "11111111-1111-4111-8111-000000000003",
        "state": "in_progress"
      },
      "actor": {
        "device_id": "33333333-3333-4333-8333-333333333333",
        "device_name": "Research phone"
      },
      "created_at": "2026-09-20T12:00:00Z",
      "advisory": true
    },
    {
      "id": "11111111-1111-4111-8111-000000000004",
      "client_request_id": "22222222-2222-4222-8222-000000000004",
      "engine_id": "dip-recovery",
      "kind": "decision",
      "payload": {
        "action": "hold",
        "reason": "Collect independent holdout evidence before promotion."
      },
      "actor": {
        "device_id": "33333333-3333-4333-8333-333333333333",
        "device_name": "Research phone"
      },
      "created_at": "2026-09-20T12:00:00Z",
      "advisory": true
    },
    {
      "id": "11111111-1111-4111-8111-000000000003",
      "client_request_id": "22222222-2222-4222-8222-000000000003",
      "engine_id": "dip-recovery",
      "kind": "assignment",
      "payload": {
        "assignee": "Research team",
        "title": "Review held-out replay"
      },
      "actor": {
        "device_id": "33333333-3333-4333-8333-333333333333",
        "device_name": "Research phone"
      },
      "created_at": "2026-09-20T12:00:00Z",
      "advisory": true
    },
    {
      "id": "11111111-1111-4111-8111-000000000002",
      "client_request_id": "22222222-2222-4222-8222-000000000002",
      "engine_id": "dip-recovery",
      "kind": "comment",
      "payload": {
        "text": "Replay results use simulated capital."
      },
      "actor": {
        "device_id": "33333333-3333-4333-8333-333333333333",
        "device_name": "Research phone"
      },
      "created_at": "2026-09-20T12:00:00Z",
      "advisory": true
    },
    {
      "id": "11111111-1111-4111-8111-000000000001",
      "client_request_id": "22222222-2222-4222-8222-000000000001",
      "engine_id": "dip-recovery",
      "kind": "owner",
      "payload": {
        "owner": "Research team"
      },
      "actor": {
        "device_id": "33333333-3333-4333-8333-333333333333",
        "device_name": "Research phone"
      },
      "created_at": "2026-09-20T12:00:00Z",
      "advisory": true
    }
  ],
  "events_truncated": false
}
"""#

    public enum Stage: String, Decodable {
        case research, shadow, notReported = "not_reported"
        public init(from decoder: Decoder) throws {
            let value = try decoder.singleValueContainer().decode(String.self)
            self = Stage(rawValue: value) ?? .research
        }
        public var label: String {
            switch self {
            case .research: return "Research"
            case .shadow: return "Shadow"
            case .notReported: return "Not reported"
            }
        }
        public var symbol: String {
            switch self {
            case .research: return "flask"
            case .shadow: return "eye"
            case .notReported: return "questionmark.circle"
            }
        }
    }

    public struct Evidence: Decodable, Equatable {
        public let label: String
        public let value: String
        public let asOf: String
        enum CodingKeys: String, CodingKey { case label, value; case asOf = "as_of" }
    }
    public struct Lane: Decodable, Identifiable, Equatable {
        public let laneId: String
        public let engineId: String?
        public let name: String
        public let stage: Stage
        public let owner: String?
        public let hypothesis: String
        public let evidence: [Evidence]
        public let nextAction: String
        public let readiness: [String: ReadinessNote]
        public var id: String { laneId }
        public var ownerLabel: String { owner ?? "No owner yet" }
        public var boundary: String {
            stage == .notReported ? "Status not reported. These notes do not establish live trading." :
                "Not trading. Research and shadow evidence are not live fills."
        }
        enum CodingKeys: String, CodingKey {
            case name, stage, owner, hypothesis, evidence, readiness
            case laneId = "lane_id", engineId = "engine_id", nextAction = "next_action"
        }
    }
    public struct ReadinessNote: Decodable, Equatable {
        public enum Status: String, Decodable { case noted, notReported = "not_reported" }
        public let status: Status
        public let note: String
        public let asOf: String
        enum CodingKeys: String, CodingKey { case status, note; case asOf = "as_of" }
    }
    public struct Notes: Decodable, Equatable {
        public let schemaVersion: Int
        public let reviewedAt: String
        public let lanes: [Lane]
        enum CodingKeys: String, CodingKey {
            case lanes
            case schemaVersion = "schema_version", reviewedAt = "reviewed_at"
        }
    }
    public enum NotesError: Error { case invalidContract }

    /// Reject schema drift, missing evidence, duplicate lane IDs and invalid dates.
    public static func decodeNotes(_ data: Data) throws -> Notes {
        func keys(_ object: [String: Any], required: Set<String>, optional: Set<String> = []) -> Bool {
            required.isSubset(of: Set(object.keys)) && Set(object.keys).isSubset(of: required.union(optional))
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              keys(root, required: ["schema_version", "reviewed_at", "lanes"]),
              let rows = root["lanes"] as? [[String: Any]], !rows.isEmpty else {
            throw NotesError.invalidContract
        }
        for row in rows {
            guard keys(row, required: ["lane_id", "name", "stage", "hypothesis", "evidence", "next_action", "readiness"],
                       optional: ["engine_id", "owner"]),
                  let readiness = row["readiness"] as? [String: [String: Any]],
                  Set(readiness.keys) == Set(EngineWorkshop.ReadinessKind.allCases.map(\.rawValue)),
                  readiness.values.allSatisfy({
                      keys($0, required: ["status", "note", "as_of"]) &&
                      ["noted", "not_reported"].contains($0["status"] as? String ?? "")
                  }),
                  let evidence = row["evidence"] as? [[String: Any]], !evidence.isEmpty,
                  evidence.allSatisfy({ keys($0, required: ["label", "value", "as_of"]) }) else {
                throw NotesError.invalidContract
            }
        }
        let notes = try JSONDecoder().decode(Notes.self, from: data)
        func nonempty(_ value: String) -> Bool { !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        func day(_ value: String) -> Bool {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.timeZone = TimeZone(secondsFromGMT: 0)
            formatter.dateFormat = "yyyy-MM-dd"
            formatter.isLenient = false
            guard let date = formatter.date(from: value) else { return false }
            return formatter.string(from: date) == value
        }
        guard notes.schemaVersion == 2, day(notes.reviewedAt),
              Set(notes.lanes.map(\.id)).count == notes.lanes.count,
              notes.lanes.allSatisfy({ lane in
                  [lane.id, lane.name, lane.hypothesis, lane.nextAction].allSatisfy(nonempty) &&
                  lane.owner.map(nonempty) != false && lane.engineId.map(nonempty) != false &&
                  lane.readiness.values.allSatisfy { nonempty($0.note) && day($0.asOf) } &&
                  lane.evidence.allSatisfy { nonempty($0.label) && nonempty($0.value) && day($0.asOf) }
              }) else { throw NotesError.invalidContract }
        return notes
    }

    // Offline fallback only. Never substitute these notes for a successful live response.
    // The fixture contract checks these fields against the reviewed notes.
    public static let bundledNotesJSON = #"""
{
  "schema_version": 2,
  "reviewed_at": "2026-09-20",
  "lanes": [
    {
      "lane_id": "darkhorse",
      "engine_id": null,
      "name": "Darkhorse",
      "stage": "not_reported",
      "owner": null,
      "hypothesis": "Score the cheaper side of a market at scheduled entry times.",
      "evidence": [
        {
          "label": "Cap and holdout",
          "value": "Three-contract order ceiling shipped. A holdout scorer exists; account-level live status is not reported.",
          "as_of": "2026-09-20"
        }
      ],
      "next_action": "First-class account integration",
      "readiness": {
        "data_coverage": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" },
        "holdout_evidence": { "status": "noted", "note": "A holdout scorer exists; results are not published to the app.", "as_of": "2026-09-20" },
        "risk_limits": { "status": "noted", "note": "Three-contract order ceiling shipped.", "as_of": "2026-09-20" },
        "account_integration": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" },
        "telemetry": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" }
      }
    },
    {
      "lane_id": "dip-recovery",
      "engine_id": null,
      "name": "Dip Recovery",
      "stage": "research",
      "owner": null,
      "hypothesis": "Study an extra entry after a recorded live exit, held to settlement in replay.",
      "evidence": [
        {
          "label": "Replay",
          "value": "Report-only replay uses incremental simulated capital, not a reconstructed account balance.",
          "as_of": "2026-09-20"
        }
      ],
      "next_action": "Build a shadow engine",
      "readiness": {
        "data_coverage": { "status": "noted", "note": "Report-only replay on simulated capital.", "as_of": "2026-09-20" },
        "holdout_evidence": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" },
        "risk_limits": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" },
        "account_integration": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" },
        "telemetry": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" }
      }
    },
    {
      "lane_id": "relay-divergence",
      "engine_id": null,
      "name": "Relay Divergence",
      "stage": "research",
      "owner": null,
      "hypothesis": "Compare a 5 Hz relay mean candidate with parent engines on matched market frames.",
      "evidence": [
        {
          "label": "Daily diagnostic",
          "value": "Daily diagnostic compares paper admission and modeled fills, not live account profit.",
          "as_of": "2026-09-20"
        }
      ],
      "next_action": "Run a stable shadow trial",
      "readiness": {
        "data_coverage": { "status": "noted", "note": "Daily diagnostic on paper admission and modeled fills.", "as_of": "2026-09-20" },
        "holdout_evidence": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" },
        "risk_limits": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" },
        "account_integration": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" },
        "telemetry": { "status": "not_reported", "note": "Not reported.", "as_of": "2026-09-20" }
      }
    }
  ]
}
"""#
    public static var bundledNotes: Notes? { try? decodeNotes(Data(bundledNotesJSON.utf8)) }

    public static func yourLane(in accounts: [EngineControlAccount]) -> String? {
        let eligible = accounts.filter { $0.configurable && $0.id != "unassigned" }
        return eligible.count == 1 ? eligible[0].id : nil
    }

    public static func canOpenSettings(account: EngineControlAccount, engine: Engine) -> Bool {
        account.configurable && account.id != "unassigned" && account.host == engine.host
    }

    public static func configuration(engine: Engine, accountId: String) -> EngineAccountConfiguration? {
        engine.configuration?.accounts.first { $0.accountId == accountId }
    }

    public static func customSettings(_ configuration: EngineAccountConfiguration) -> Int {
        configuration.override.policy.count + (configuration.override.enabled != nil ? 1 : 0)
    }

    public enum Freshness: String, Equatable {
        case current = "Recent telemetry"
        case delayed = "Delayed telemetry"
        case unknown = "Freshness unknown"
    }

    public static func freshness(generatedAt: String?, observedAt: Date?, now: Date) -> Freshness {
        guard let observedAt, let generatedAt, let generated = date(generatedAt) else { return .unknown }
        let transportAge = now.timeIntervalSince(observedAt)
        let sourceAge = now.timeIntervalSince(generated)
        guard transportAge >= 0, sourceAge >= 0 else { return .unknown }
        return transportStale(observedAt: observedAt, now: now) || sourceAge > 120 ? .delayed : .current
    }

    private static func date(_ text: String) -> Date? {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let value = formatter.date(from: text) { return value }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: text)
    }

    public static func entriesLabel(_ enabled: Bool?) -> String {
        guard let enabled else { return "Entry setting unknown" }
        return enabled ? "New entries enabled" : "New entries paused"
    }

    /// Account views must not fall back to the global value when their row is missing.
    public static func entriesLabel(engine: Engine, accountId: String? = nil) -> String {
        if let accountId {
            return entriesLabel(engine.configuration?.accounts.first { $0.accountId == accountId }?.effective.enabled)
        }
        return entriesLabel(engine.configuration?.global.enabled)
    }

    public static func laneLabel(_ status: KashbotStatus?) -> String {
        guard let status else { return "Account lane not checked" }
        guard status.isBound else { return "Account lane not bound" }
        guard status.hasActionableLane else { return "Account lane state incomplete" }
        if status.lane?.killRequested == true { return "Stop requested" }
        if status.automatedTrading == .live && status.lane?.liveEnabled != true {
            return "Account lane state inconsistent"
        }
        if status.automatedTrading != .live && status.lane?.liveEnabled == true {
            return "Account lane state inconsistent"
        }
        return status.automatedTrading.label
    }

    public static func isPending(_ state: String?) -> Bool {
        // Unknown states remain visible instead of being silently treated as applied.
        !["applied", "rejected", "failed", "cancelled", "canceled", "completed", "succeeded", "expired"]
            .contains(state?.lowercased() ?? "")
    }

    public static func requestScope(_ scope: ControlScope?) -> String {
        guard let scope else { return "Scope not published" }
        if scope.kind == .global { return "Global engine settings" }
        return scope.accountId.map { "Account: \($0)" } ?? "Account scope unknown"
    }
}
