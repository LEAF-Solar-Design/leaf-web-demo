import Foundation

public enum ObservationSource: String, Codable { case runner, phone }
public struct AccountObservation: Codable, Equatable {
    public let capturedAt: Date
    public let source: ObservationSource
    public let exchangeIndex: Int?
    public let cashCents: Int?
    public let portfolioValueCents: Int?
    public init(capturedAt: Date, source: ObservationSource, exchangeIndex: Int? = nil,
                cashCents: Int? = nil, portfolioValueCents: Int? = nil) {
        self.capturedAt = capturedAt
        self.source = source
        self.exchangeIndex = exchangeIndex
        self.cashCents = cashCents
        self.portfolioValueCents = portfolioValueCents
    }
}
public enum HistoryRange: String, CaseIterable {
    case hour, fourHours, twelveHours, day, week, month, all

    public var label: String {
        switch self {
        case .hour: return "1h"
        case .fourHours: return "4h"
        case .twelveHours: return "12h"
        case .day: return "1d"
        case .week: return "7d"
        case .month: return "30d"
        case .all: return "All"
        }
    }
}
public enum AccountMetric { case cash, portfolioValue }
public enum CashFloorPolicy {
    public static let key = "cash_floor_cents"
    public static let fallbackCents = 1000

    public static func cents(policy: [String: Double]?) -> Int? {
        guard let value = policy?[key], value.isFinite, (0...100_000).contains(value) else { return nil }
        return Int(value.rounded())
    }
}

public struct Series {
    public let source: ObservationSource
    public let exchangeIndex: Int?
    public let metric: AccountMetric
    public private(set) var observations: [AccountObservation] = []
    private var dates: Set<Date> = []
    public var cashFloorAnnotationCents: Int? { metric == .cash ? CashFloorPolicy.fallbackCents : nil }
    public init(source: ObservationSource, exchangeIndex: Int? = nil, metric: AccountMetric = .cash) {
        self.source = source
        self.exchangeIndex = exchangeIndex
        self.metric = metric
    }
    /// First observation at an identical timestamp wins.
    public mutating func merge(_ incoming: [AccountObservation]) {
        var needsSort = false
        for item in incoming where item.source == source && item.exchangeIndex == exchangeIndex {
            if dates.insert(item.capturedAt).inserted {
                if item.capturedAt < (observations.last?.capturedAt ?? .distantPast) { needsSort = true }
                observations.append(item)
            }
        }
        if needsSort { observations.sort { $0.capturedAt < $1.capturedAt } }
    }
    public mutating func merge(_ observation: AccountObservation) { merge([observation]) }
    public func selected(_ range: HistoryRange, now: Date) -> [AccountObservation] {
        let duration: TimeInterval?
        switch range {
        case .hour: duration = 3600
        case .fourHours: duration = 4 * 3600
        case .twelveHours: duration = 12 * 3600
        case .day: duration = 86400
        case .week: duration = 7 * 86400
        case .month: duration = 30 * 86400
        case .all: duration = nil
        }
        func bound(_ date: Date, inclusive: Bool) -> Int {
            var low = 0
            var high = observations.count
            while low < high {
                let middle = low + (high - low) / 2
                let capturedAt = observations[middle].capturedAt
                if capturedAt < date || (inclusive && capturedAt == date) {
                    low = middle + 1
                } else {
                    high = middle
                }
            }
            return low
        }
        let start = duration.map { bound(now.addingTimeInterval(-$0), inclusive: false) } ?? 0
        let end = bound(now, inclusive: true)
        return Array(observations[start..<end])
    }
    public func gaps(over threshold: TimeInterval) -> [DateInterval] {
        zip(observations, observations.dropFirst()).compactMap { first, second in
            guard second.capturedAt.timeIntervalSince(first.capturedAt) > threshold else { return nil }
            return DateInterval(start: first.capturedAt, end: second.capturedAt)
        }
    }
}
