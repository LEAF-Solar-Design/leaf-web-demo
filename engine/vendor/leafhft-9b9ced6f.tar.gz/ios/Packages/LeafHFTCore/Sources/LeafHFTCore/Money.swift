import Foundation

public enum MoneyError: Error { case invalidDecimal, outOfRange }

public struct Cents: Codable, Comparable, Hashable {
    public let rawValue: Int
    public init(_ rawValue: Int) { self.rawValue = rawValue }
    public init(decimalString: String) throws {
        self = try Money(decimalString: decimalString).cents
    }
    public init(from decoder: Decoder) throws {
        rawValue = try decoder.singleValueContainer().decode(Int.self)
    }
    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(rawValue)
    }
    public static func < (lhs: Cents, rhs: Cents) -> Bool { lhs.rawValue < rhs.rawValue }
    public func formatted() -> String {
        let magnitude = rawValue.magnitude
        let fraction = magnitude % 100
        return "\(rawValue < 0 ? "-" : "")$\(magnitude / 100).\(fraction < 10 ? "0" : "")\(fraction)"
    }
}

public struct Money: Codable, Equatable {
    public let cents: Cents
    public let exactDollars: Decimal
    public init(cents: Cents) {
        self.cents = cents
        exactDollars = Decimal(cents.rawValue) / 100
    }
    /// Display cents round to nearest, ties away from zero. Exact dollars remain intact.
    public init(decimalString: String) throws {
        guard decimalString.range(of: "^[+-]?[0-9]+(?:\\.[0-9]+)?$", options: .regularExpression) != nil,
              let value = Decimal(string: decimalString, locale: Locale(identifier: "en_US_POSIX")),
              !value.isNaN else { throw MoneyError.invalidDecimal }
        var scaled = value * 100
        var rounded = Decimal()
        NSDecimalRound(&rounded, &scaled, 0, .plain)
        guard !rounded.isNaN, rounded >= Decimal(Int.min), rounded <= Decimal(Int.max) else {
            throw MoneyError.outOfRange
        }
        cents = Cents(NSDecimalNumber(decimal: rounded).intValue)
        exactDollars = value
    }
    public func formatted() -> String { cents.formatted() }
}
