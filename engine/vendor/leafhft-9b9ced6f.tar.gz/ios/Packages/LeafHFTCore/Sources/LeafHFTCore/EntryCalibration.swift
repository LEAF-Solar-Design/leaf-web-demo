import Foundation

/// Entry calibration contract v1. Unknown keys and severities never throw; nullable fields stay optional.
public struct EntryCalibration: Codable, Equatable {
    public var schemaVersion: Int
    public var generatedAt: String
    public var host: String
    public var window: Window
    public var summary: Summary
    public var buckets: [Bucket]
    public var engines: [EngineRow]
    public var grid: Grid
    public var lessons: [Lesson]
    /// Tune advice contract v1: newest held-out check per engine. Missing or null decodes as [].
    public var advice: [Advice]

    public enum Severity: String, Codable {
        case good
        case watch
        case act
        case unknown
        public init(from decoder: Decoder) throws {
            let value = try decoder.singleValueContainer().decode(String.self)
            self = Self(rawValue: value) ?? .unknown
        }
    }

    public struct Window: Codable, Equatable {
        public var since: String
        public var days: Int
    }

    public struct Summary: Codable, Equatable {
        public var entries: Int
        public var scored: Int
        public var unscored: Int
        public var resolved: Int
        public var open: Int
        public var settled: Int
        public var cashedOut: Int
        public var venueSettled: Int
        public var unattributed: Int
        public var modelWinPct: Double?
        public var actualWinPct: Double?
        public var avgPriceCents: Double?
        public var edgeAfterPricePts: Double?
        public var realizedCents: Int

        public var headline: String {
            guard let model = modelWinPct, let actual = actualWinPct else { return "Not enough settled entries yet" }
            return "Model said \(EntryCalibration.percent(model))%, entries won \(EntryCalibration.percent(actual))%"
        }
        public var edgeLine: String {
            guard let edge = edgeAfterPricePts else { return "Edge after price not reported" }
            return "\(EntryCalibration.signedPoints(edge)) points after price"
        }
        public var coverageLine: String {
            "\(EntryCalibration.grouped(scored)) scored of \(EntryCalibration.grouped(entries)) entries · \(EntryCalibration.grouped(open)) open"
        }
    }

    public struct Bucket: Codable, Equatable {
        public var bucket: String
        public var label: String
        public var lo: Double
        public var hi: Double
        public var entries: Int
        public var modelWinPct: Double
        public var actualWinPct: Double
        public var wilsonLowPct: Double
        public var wilsonHighPct: Double
        public var avgPriceCents: Double
        public var edgeAfterPricePts: Double
        public var realizedCents: Int

        public var line: String {
            "\(label) · model \(EntryCalibration.percent(modelWinPct))% · won \(EntryCalibration.percent(actualWinPct))%"
                + " (\(EntryCalibration.whole(wilsonLowPct)) to \(EntryCalibration.whole(wilsonHighPct))%)"
                + " · \(EntryCalibration.signedPoints(edgeAfterPricePts)) pts"
        }
    }

    public struct EngineRow: Codable, Equatable {
        public var engineId: String?
        public var entries: Int
        public var resolved: Int
        public var modelWinPct: Double?
        public var actualWinPct: Double?
        public var realizedCents: Int

        public var line: String {
            let name = engineId ?? "Engine unknown"
            guard let actual = actualWinPct else {
                return "\(name) · win rate not reported · \(ExitLedger.money(realizedCents))"
            }
            return "\(name) · won \(EntryCalibration.percent(actual))% of \(EntryCalibration.grouped(resolved)) settled"
                + " · \(ExitLedger.money(realizedCents))"
        }
    }

    public struct GridCell: Codable, Equatable {
        public var maxPriceCents: Int?
        public var minProbPct: Double?
        public var kept: Int
        public var removed: Int
        public var removedRealizedCents: Int
        public var deltaCents: Int

        public var gate: String {
            switch (maxPriceCents, minProbPct) {
            case (nil, nil): return "No extra gate"
            case let (price?, nil): return "Cap price at \(price)c"
            case let (nil, probability?): return "Probability floor \(EntryCalibration.trimmedPercent(probability))%"
            case let (price?, probability?):
                return "Price cap \(price)c and probability floor \(EntryCalibration.trimmedPercent(probability))%"
            }
        }
        public var line: String {
            "\(gate) · kept \(EntryCalibration.grouped(kept)) · removed \(EntryCalibration.grouped(removed))"
                + " · \(ExitLedger.money(deltaCents))"
        }
    }

    public struct WalkForward: Codable, Equatable {
        public var trainUntil: String
        public var chosen: GridCell?
        public var testEntries: Int
        public var testDeltaCents: Int?
    }

    public struct Grid: Codable, Equatable {
        public var note: String
        public var cells: [GridCell]
        public var best: GridCell?
        public var walkForward: WalkForward?

        public var bestLine: String? {
            guard let best, best.maxPriceCents != nil || best.minProbPct != nil else { return nil }
            return "\(best.gate): \(ExitLedger.money(best.deltaCents)) by skipping \(EntryCalibration.grouped(best.removed)) entries (in-sample)"
        }
        public var walkForwardLine: String {
            guard let walkForward else { return "Not enough history to test" }
            guard walkForward.chosen != nil else { return "Held-out test: no stricter gate helped on the earlier half" }
            guard let cents = walkForward.testDeltaCents else { return "Not enough history to test" }
            return "Held-out test: \(ExitLedger.money(cents)) over \(EntryCalibration.grouped(walkForward.testEntries)) entries"
        }
        /// Highest delta first; ties keep server order. Bounded by the contract's 66 cells.
        public func topCells(_ limit: Int = 5) -> [GridCell] {
            cells.enumerated()
                .sorted { $0.element.deltaCents != $1.element.deltaCents
                    ? $0.element.deltaCents > $1.element.deltaCents : $0.offset < $1.offset }
                .prefix(max(0, limit))
                .map(\.element)
        }
    }

    public struct Lesson: Codable, Equatable {
        public var id: String
        public var severity: Severity
        public var title: String
        public var detail: String
        public var evidenceCount: Int
        public var cents: Int?
    }

    /// Held-out verdict for one stricter gate. Unknown values never throw.
    public enum Verdict: String, Codable {
        case candidate
        case noGain = "no_gain"
        case insufficientEvidence = "insufficient_evidence"
        case unknown
        public init(from decoder: Decoder) throws {
            let value = try decoder.singleValueContainer().decode(String.self)
            self = Self(rawValue: value) ?? .unknown
        }

        public var label: String {
            switch self {
            case .candidate: return "Candidate"
            case .noGain: return "No gain"
            case .insufficientEvidence: return "Not enough data"
            case .unknown: return "Verdict unknown"
            }
        }
    }

    public struct Advice: Codable, Equatable {
        public var engineId: String?
        /// Changed settings only, keyed in snake case whatever the decoder's key strategy did to them.
        public var candidate: [String: Double]
        public var verdict: Verdict
        public var reason: String?
        public var evaluationDeltaCents: Int?
        public var evaluationComparable: Int?
        public var createdAt: String?

        enum CodingKeys: String, CodingKey {
            case engineId, candidate, verdict, reason, evaluationDeltaCents, evaluationComparable, createdAt
        }

        public init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            engineId = try? container.decodeIfPresent(String.self, forKey: .engineId)
            let raw: [String: Double] = (try? container.decodeIfPresent([String: Double].self, forKey: .candidate)) ?? [:]
            candidate = Dictionary(raw.map { (EntryCalibration.snakeCase($0.key), $0.value) },
                                   uniquingKeysWith: { first, _ in first })
            verdict = (try? container.decodeIfPresent(Verdict.self, forKey: .verdict)) ?? .unknown
            reason = try? container.decodeIfPresent(String.self, forKey: .reason)
            evaluationDeltaCents = try? container.decodeIfPresent(Int.self, forKey: .evaluationDeltaCents)
            evaluationComparable = try? container.decodeIfPresent(Int.self, forKey: .evaluationComparable)
            createdAt = try? container.decodeIfPresent(String.self, forKey: .createdAt)
        }

        /// Grid keys reuse GridCell's phrase; every other changed key gets its own phrase, sorted by key.
        public var gate: String {
            let price = candidate["max_price_cents"]
            let probability = candidate["min_prob_pct"]
            var parts: [String] = []
            if price != nil || probability != nil || candidate.isEmpty {
                let priceCents = price.flatMap { Int(exactly: $0) }
                if price == nil || priceCents != nil {
                    parts.append(GridCell(maxPriceCents: priceCents, minProbPct: probability, kept: 0, removed: 0,
                                          removedRealizedCents: 0, deltaCents: 0).gate)
                } else if let price {
                    parts.append("Cap price at \(EntryCalibration.number(price))c")
                    if let probability {
                        parts.append("Probability floor \(EntryCalibration.trimmedPercent(probability))%")
                    }
                }
            }
            for key in candidate.keys.sorted() where key != "max_price_cents" && key != "min_prob_pct" {
                parts.append(Self.phrase(key, candidate[key] ?? 0))
            }
            var joined = parts.first ?? "No extra gate"
            for part in parts.dropFirst() {
                joined += " and " + part.prefix(1).lowercased() + String(part.dropFirst())
            }
            return joined
        }

        static func phrase(_ key: String, _ value: Double) -> String {
            let text = EntryCalibration.number(value)
            switch key {
            case "min_price_cents": return "Price floor \(text)c"
            case "min_k": return "Minimum k \(text)"
            case "min_depth": return "Minimum depth \(text)"
            case "max_quote_age_ms": return "Quote age at most \(text) ms"
            case "edge_threshold_cents": return "Edge bar \(text)c"
            case "favorite_edge_threshold_cents": return "Favorite edge bar \(text)c"
            default:
                let words = key.replacingOccurrences(of: "_", with: " ")
                return words.prefix(1).uppercased() + String(words.dropFirst()) + " " + text
            }
        }

        /// "<engine>: <gate> · held-out <money> on <n> entries · <verdict>".
        public var line: String {
            let name = engineId ?? "Engine unknown"
            guard let cents = evaluationDeltaCents, let comparable = evaluationComparable else {
                return "\(name): \(gate) · held-out result not reported · \(verdict.label)"
            }
            return "\(name): \(gate) · held-out \(ExitLedger.money(cents)) on"
                + " \(EntryCalibration.grouped(comparable)) entries · \(verdict.label)"
        }
    }

    /// Newest first by created_at; unparseable times sort last and ties keep server order. Bounded by the
    /// contract's 10 rows.
    public func inlineAdvice(_ limit: Int = 3) -> [Advice] {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let whole = ISO8601DateFormatter()
        let dates: [Date?] = advice.map { row in
            row.createdAt.flatMap { fractional.date(from: $0) ?? whole.date(from: $0) }
        }
        return advice.indices
            .sorted { lhs, rhs in
                switch (dates[lhs], dates[rhs]) {
                case let (left?, right?) where left != right: return left > right
                case (.some, nil): return true
                case (nil, .some): return false
                default: return lhs < rhs
                }
            }
            .prefix(max(0, limit))
            .map { advice[$0] }
    }

    /// Prefill for the assistant composer; never sent by the app.
    public var askPrompt: String {
        guard let best = grid.best, best.maxPriceCents != nil || best.minProbPct != nil else {
            return "Which stricter entry gate would help my engines? Check it held-out."
        }
        return "Run a held-out check of \(best.gate) on my engines, then tell me which engine it helps."
    }

    public var topLesson: Lesson? {
        lessons.first { $0.severity == .act } ?? lessons.first { $0.severity == .watch } ?? lessons.first
    }

    /// Worst realized first; ties keep server order.
    public var enginesWorstFirst: [EngineRow] {
        engines.enumerated()
            .sorted { $0.element.realizedCents != $1.element.realizedCents
                ? $0.element.realizedCents < $1.element.realizedCents : $0.offset < $1.offset }
            .map(\.element)
    }

    /// One decimal, as the contract sends percents.
    static func percent(_ value: Double) -> String {
        String(format: "%.1f", value)
    }

    /// One decimal with a trailing ".0" dropped, for gate thresholds such as 97 and 99.5.
    static func trimmedPercent(_ value: Double) -> String {
        let text = String(format: "%.1f", value)
        return text.hasSuffix(".0") ? String(text.dropLast(2)) : text
    }

    /// Whole values without a decimal point; anything else in Swift's shortest form (0.95, 1.5).
    static func number(_ value: Double) -> String {
        if let whole = Int(exactly: value) { return String(whole) }
        return String(value)
    }

    /// "maxPriceCents" and "max_price_cents" both read "max_price_cents".
    static func snakeCase(_ key: String) -> String {
        var result = ""
        for character in key {
            if character.isUppercase {
                result.append("_")
                result.append(contentsOf: character.lowercased())
            } else {
                result.append(character)
            }
        }
        return result
    }

    static func whole(_ value: Double) -> String {
        String(format: "%.0f", value)
    }

    /// Sign always explicit; a value that rounds to zero reads "+0.0".
    static func signedPoints(_ value: Double) -> String {
        let text = String(format: "%.1f", abs(value))
        return (value >= 0 || text == "0.0" ? "+" : "-") + text
    }

    /// Thousands grouping without a locale.
    static func grouped(_ value: Int) -> String {
        let digits = String(value.magnitude)
        var result = ""
        for (index, digit) in digits.enumerated() {
            if index > 0 && (digits.count - index) % 3 == 0 { result.append(",") }
            result.append(digit)
        }
        return (value < 0 ? "-" : "") + result
    }
}

extension EntryCalibration {
    /// Every v1 field stays required; only the additive advice list tolerates missing or null.
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        schemaVersion = try container.decode(Int.self, forKey: .schemaVersion)
        generatedAt = try container.decode(String.self, forKey: .generatedAt)
        host = try container.decode(String.self, forKey: .host)
        window = try container.decode(Window.self, forKey: .window)
        summary = try container.decode(Summary.self, forKey: .summary)
        buckets = try container.decode([Bucket].self, forKey: .buckets)
        engines = try container.decode([EngineRow].self, forKey: .engines)
        grid = try container.decode(Grid.self, forKey: .grid)
        lessons = try container.decode([Lesson].self, forKey: .lessons)
        advice = try container.decodeIfPresent([Advice].self, forKey: .advice) ?? []
    }
}
