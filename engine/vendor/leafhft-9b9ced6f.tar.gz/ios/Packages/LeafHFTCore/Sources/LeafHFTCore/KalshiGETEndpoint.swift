import Foundation

public enum KalshiGETEndpoint: Equatable {
    case balance
    case positions
    case openPositions
    case markets(tickers: [String])
    case fills(cursor: String?, limit: Int)
    case settlements(cursor: String?, limit: Int)
    case deposits

    public static let method = "GET"
    public static let origin = URL(string: "https://api.elections.kalshi.com")!
    public var path: String {
        let suffix: String
        switch self {
        case .balance: suffix = "portfolio/balance"
        case .positions: suffix = "portfolio/positions"
        case .openPositions: suffix = "portfolio/positions"
        case .markets: suffix = "markets"
        case .fills: suffix = "portfolio/fills"
        case .settlements: suffix = "portfolio/settlements"
        case .deposits: suffix = "portfolio/deposits"
        }
        return "/trade-api/v2/" + suffix
    }
    public var queryItems: [URLQueryItem] {
        switch self {
        case let .markets(tickers):
            // Caller order is priority order: dedupe keeping first sight, cap at 20, then sort the kept ones.
            var seen = Set<String>()
            let selected = tickers.filter { !$0.isEmpty && seen.insert($0).inserted }.prefix(20).sorted()
            return [URLQueryItem(name: "tickers", value: selected.joined(separator: ",")),
                    URLQueryItem(name: "limit", value: String(selected.count))]
        case .openPositions:
            return [URLQueryItem(name: "count_filter", value: "position"),
                    URLQueryItem(name: "limit", value: "200")]
        case let .fills(cursor, limit), let .settlements(cursor, limit):
            var items = [URLQueryItem(name: "limit", value: String(min(200, max(1, limit))))]
            if let cursor = cursor { items.append(URLQueryItem(name: "cursor", value: cursor)) }
            return items
        default: return []
        }
    }
}
