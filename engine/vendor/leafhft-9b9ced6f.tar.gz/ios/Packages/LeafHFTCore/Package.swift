// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "LeafHFTCore",
    platforms: [.iOS(.v17), .macOS(.v13)],  // macOS only so `swift test` runs on the build Mac
    products: [.library(name: "LeafHFTCore", targets: ["LeafHFTCore"])],
    targets: [
        .target(name: "LeafHFTCore"),
        .testTarget(name: "LeafHFTCoreTests", dependencies: ["LeafHFTCore"],
                    resources: [.copy("Fixtures")])
    ]
)
