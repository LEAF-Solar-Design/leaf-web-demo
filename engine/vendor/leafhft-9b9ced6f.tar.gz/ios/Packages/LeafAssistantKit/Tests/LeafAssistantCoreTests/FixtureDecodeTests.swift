import Foundation
import XCTest
#if canImport(Testing)
import Testing
#endif
@testable import LeafAssistantCore

// The seven K0 golden conversations, vendored under Fixtures/ and decoded by the
// Swift models; plus unknown-value tolerance, the nullable-key rule, the origin
// rule on ConfirmCard, the fold and the client routes.

/// Paths the tests read. The goldens come from the test bundle (Package.swift
/// copies Fixtures/ as a resource), falling back to the source tree. The package
/// sits at swift/LeafAssistantKit in the repo, so K0 lives four levels above this
/// directory; LEAF_ASSISTANT_CONTRACT_DIR overrides it for another layout.
enum KitPaths {
    static let testsDir = URL(fileURLWithPath: #filePath).deletingLastPathComponent()
    static let fixturesDir: URL = {
        if let bundled = Bundle.module.url(forResource: "Fixtures", withExtension: nil) {
            return bundled
        }
        return testsDir.appendingPathComponent("Fixtures")
    }()
    static var contractDir: URL {
        if let override = ProcessInfo.processInfo.environment["LEAF_ASSISTANT_CONTRACT_DIR"], !override.isEmpty {
            return URL(fileURLWithPath: override)
        }
        return testsDir
            .deletingLastPathComponent() // Tests
            .deletingLastPathComponent() // LeafAssistantKit
            .deletingLastPathComponent() // swift
            .deletingLastPathComponent() // repo root
            .appendingPathComponent("packages")
            .appendingPathComponent("assistant-contract")
    }

    static func readLF(_ url: URL) throws -> Data {
        FixturePins.lfNormalized(try Data(contentsOf: url))
    }
}

let goldenNames = [
    "idle", "answer-with-view", "tool-failed", "card-approved", "card-expired", "rate-limited", "worker-offline",
]

func loadGolden(_ name: String) throws -> GoldenConversationV1 {
    let data = try KitPaths.readLF(KitPaths.fixturesDir.appendingPathComponent("\(name).json"))
    return try AssistantDecoding.decode(GoldenConversationV1.self, from: data)
}

func decodeJSON<T: Decodable>(_ type: T.Type, _ json: String) throws -> T {
    try AssistantDecoding.decode(T.self, from: Data(json.utf8))
}

final class FixtureDecodeTests: XCTestCase {
    // MARK: The seven conversations

    func testFixtureDirectoryHoldsExactlyTheSevenGoldens() throws {
        let present = try FileManager.default.contentsOfDirectory(atPath: KitPaths.fixturesDir.path)
            .filter { $0.hasSuffix(".json") }
            .sorted()
        XCTAssertEqual(present, goldenNames.map { "\($0).json" }.sorted())
    }

    func testEveryGoldenDecodesAndPassesTheContractChecks() throws {
        for name in goldenNames {
            let golden = try loadGolden(name)
            XCTAssertEqual(golden.name, name)
            XCTAssertEqual(ContractCheck.violations(in: golden), [], "\(name) breaks the contract")
            for (index, event) in golden.events.enumerated() {
                XCTAssertTrue(event.requiresActionIsConsistent, "\(name) events[\(index)] requires_action")
            }
        }
    }

    func testFoldingTheEventsReproducesTheThread() throws {
        for name in goldenNames {
            let golden = try loadGolden(name)
            XCTAssertEqual(ThreadFold.fold(golden.events), golden.thread.items, "\(name): batch fold")
            var items: [ItemV1] = []
            for event in golden.events {
                ThreadFold.apply(event, to: &items)
            }
            XCTAssertEqual(items, golden.thread.items, "\(name): incremental fold")
        }
    }

    func testEveryGoldenRoundTripsThroughTheSwiftModels() throws {
        for name in goldenNames {
            let golden = try loadGolden(name)
            let again = try AssistantDecoding.decode(GoldenConversationV1.self, from: AssistantDecoding.encode(golden))
            XCTAssertEqual(again, golden, "\(name) changed on a round trip")
        }
    }

    func testIdle() throws {
        let golden = try loadGolden("idle")
        XCTAssertTrue(golden.thread.items.isEmpty)
        XCTAssertTrue(golden.events.isEmpty)
        XCTAssertEqual(golden.thread.scope.kind, .tenant)
        XCTAssertEqual(golden.thread.provider.kind, .claudeCodeCli)
        XCTAssertEqual(golden.thread.quota?.used, 0)
        XCTAssertEqual(golden.thread.quota?.window, .hour)
    }

    func testAnswerWithView() throws {
        let golden = try loadGolden("answer-with-view")
        XCTAssertNil(golden.thread.quota)
        let blocks = golden.thread.items[1].blocks
        guard case .view(let view) = blocks[1] else { return XCTFail("expected a view block, got \(blocks[1].type)") }
        XCTAssertEqual(view.origin, .server)
        XCTAssertEqual(view.kind, .metric)
        XCTAssertEqual(view.invocationIds, ["inv-001"])
        XCTAssertEqual(view.rows.map(\.label), ["Realized P&L", "Open positions", "Fees"])
        XCTAssertEqual(view.rows[0].value, .number(1250))
        XCTAssertEqual(view.rows[0].unit, .cents)
        XCTAssertEqual(view.rows[1].value, .number(4))
        XCTAssertNil(view.rows[2].value, "a null value stays null, never 0")
        XCTAssertEqual(view.rows[2].unit, .cents)
        guard case .text(let text) = blocks[2] else { return XCTFail("expected a text block") }
        XCTAssertTrue(text.text.hasPrefix("Realized P&L today"))
    }

    func testToolFailed() throws {
        let golden = try loadGolden("tool-failed")
        guard case .tools(let tools) = golden.thread.items[1].blocks[0] else { return XCTFail("expected tools") }
        let tool = tools.tools[0]
        XCTAssertEqual(tool.state, .failed)
        XCTAssertEqual(tool.reason?.code, .toolFailed)
        XCTAssertEqual(tool.reason?.next, ReasonNext(label: "Try again", action: .retry))
    }

    func testCardApproved() throws {
        let golden = try loadGolden("card-approved")
        guard case .card(let block) = golden.thread.items[1].blocks[1] else { return XCTFail("expected a card") }
        let card = block.card
        XCTAssertEqual(card.kind, .control)
        XCTAssertEqual(card.state, .approved)
        XCTAssertTrue(card.requiresFaceId)
        XCTAssertEqual(card.spend.state, SpendState.none)
        XCTAssertNil(card.spend.cents)
        XCTAssertEqual(card.resolution?.actor?.kind, .owner)
        XCTAssertEqual(card.resolution?.actor?.principalId, "dev-owner-01")
        XCTAssertEqual(card.resolution?.receipt.text, "Approved on Owner iPhone at 11:20 AM CT")
        // The pending version was delivered first, and it required action.
        guard case .item(let pending) = golden.events[3] else { return XCTFail("expected an item event") }
        XCTAssertTrue(pending.requiresAction)
        XCTAssertTrue(pending.item.requiresAction)
    }

    func testCardExpired() throws {
        let golden = try loadGolden("card-expired")
        let blocks = golden.thread.items[1].blocks
        guard case .card(let block) = blocks[1] else { return XCTFail("expected a card") }
        XCTAssertEqual(block.card.kind, .configDraft)
        XCTAssertEqual(block.card.state, .expired)
        XCTAssertNotNil(block.card.resolution)
        XCTAssertNil(block.card.resolution?.actor, "expiry names no actor")
        XCTAssertFalse(block.card.presentation.canApprove)
        guard case .notice(let notice) = blocks[2] else { return XCTFail("expected a notice") }
        XCTAssertEqual(notice.reason.code, .cardExpired)
        XCTAssertEqual(notice.reason.next.action, .retry)
    }

    func testRateLimited() throws {
        let golden = try loadGolden("rate-limited")
        XCTAssertEqual(golden.thread.quota?.used, 30)
        XCTAssertEqual(golden.thread.quota?.limit, 30)
        guard case .turn(let turn) = golden.events[1] else { return XCTFail("expected a turn event") }
        XCTAssertEqual(turn.state, .failed)
        XCTAssertEqual(turn.reason?.code, .rateLimited)
        XCTAssertEqual(turn.reason?.next.action, .wait)
        XCTAssertEqual(turn.reason?.retryAt, "2026-09-23T21:12:00Z")
        XCTAssertEqual(golden.thread.items[1].role, .server)
    }

    func testWorkerOffline() throws {
        let golden = try loadGolden("worker-offline")
        XCTAssertEqual(golden.thread.items.map(\.role), [.user, .assistant, .server])
        guard case .notice(let notice) = golden.thread.items[2].blocks[0] else { return XCTFail("expected a notice") }
        XCTAssertEqual(notice.reason.code, .workerOffline)
        guard case .turn(let turn) = golden.events[4] else { return XCTFail("expected a turn event") }
        XCTAssertEqual(turn.state, .failed)
        XCTAssertEqual(turn.reason?.code, .workerOffline)
    }

    // MARK: Unknown-value tolerance

    func testUnknownEnumValuesDecodeToUnknownNeverAThrow() throws {
        let card = try decodeJSON(ConfirmCardV1.self, Self.cardJSON(
            kind: "hologram",
            state: "frozen",
            fields: [Self.field("action", origin: "robot", placement: "sidebar")],
            spendState: "estimated"
        ))
        XCTAssertEqual(card.kind, .unknown)
        XCTAssertEqual(card.state, .unknown)
        XCTAssertEqual(card.fields[0].origin, .unknown)
        XCTAssertEqual(card.fields[0].placement, .unknown)
        XCTAssertEqual(card.spend.state, .unknown)
        XCTAssertFalse(card.presentation.canApprove)

        let reason = try decodeJSON(ReasonV1.self, #"{"code":"brand_new","text":"x","next":{"label":"Go","action":"teleport"}}"#)
        XCTAssertEqual(reason.code, .unknown)
        XCTAssertEqual(reason.next.action, .unknown)
        XCTAssertNil(reason.code.rule)

        let tool = try decodeJSON(ToolCallV1.self, #"{"invocation_id":"inv-1","name":"t","label":"T","state":"paused"}"#)
        XCTAssertEqual(tool.state, .unknown)

        let thread = try decodeJSON(ThreadV1.self, #"""
        {"session_id":"s-1","scope":{"kind":"org","label":"Org"},
         "provider":{"kind":"gemini-cli","label":"G","model":"g-1"},
         "quota":{"used":1,"limit":2,"window":"week","resets_at":"2026-09-23T17:00:00Z"},
         "items":[{"seq":1,"item_id":"i-1","turn_id":"t-1","role":"robot","at":"2026-09-23T16:00:00Z",
                   "blocks":[{"type":"view","origin":"server","view_id":"v-1","kind":"pie","title":"T",
                              "invocation_ids":["inv-1"],"as_of":"2026-09-23T16:00:00Z",
                              "rows":[{"invocation_id":"inv-1","label":"L","value":"12","unit":"btc"}]}]}]}
        """#)
        XCTAssertEqual(thread.scope.kind, .unknown)
        XCTAssertEqual(thread.provider.kind, .unknown)
        XCTAssertEqual(thread.quota?.window, .unknown)
        XCTAssertEqual(thread.items[0].role, .unknown)
        guard case .view(let view) = thread.items[0].blocks[0] else { return XCTFail("expected a view") }
        XCTAssertEqual(view.kind, .unknown)
        XCTAssertEqual(view.rows[0].unit, .unknown)
        XCTAssertEqual(view.rows[0].value, .text("12"))
        XCTAssertFalse(ContractCheck.violations(in: thread).isEmpty, "unknown values are reported, not hidden")

        let event = try decodeJSON(TurnEventV1.self, #"{"type":"turn","session_id":"s-1","seq":2,"at":"2026-09-23T16:00:00Z","requires_action":false,"turn_id":"t-1","state":"paused"}"#)
        XCTAssertEqual(event.state, .unknown)

        let worker = try decodeJSON(WorkerErrorEventV1.self, #"{"job_id":"j-1","seq":1,"type":"error","code":"disk_full"}"#)
        XCTAssertEqual(worker.code, .unknown)

        let proposal = try decodeJSON(ProposalV1.self, #"""
        {"proposal_id":"p-1","session_id":"s-1","turn_id":"t-1","created_at":"2026-09-23T16:00:00Z",
         "expires_at":"2026-09-23T16:05:00Z","proposal_digest":"\#(String(repeating: "a", count: 64))",
         "kind":"teleport","teleport":{"to":"mars"}}
        """#)
        XCTAssertEqual(proposal.kind, .unknown)
        XCTAssertEqual(proposal.payload, .unknown)
    }

    func testUnknownBlockAndEventTypesDecodeToUnknown() throws {
        let item = try decodeJSON(ItemV1.self, #"""
        {"seq":3,"item_id":"i-1","turn_id":"t-1","role":"assistant","at":"2026-09-23T16:00:00Z",
         "blocks":[{"type":"hologram","origin":"server","payload":1},{"type":"text","text":"still here"}]}
        """#)
        XCTAssertEqual(item.blocks.count, 2)
        XCTAssertEqual(item.blocks[0], .unknown(type: "hologram"))
        XCTAssertEqual(item.blocks[1].type, "text")

        let page = try decodeJSON(EventsPageV1.self, #"""
        {"events":[{"type":"presence","session_id":"s-1","seq":7,"at":"2026-09-23T16:00:00Z"},
                   {"type":"turn","session_id":"s-1","seq":8,"at":"2026-09-23T16:00:01Z","requires_action":false,"turn_id":"t-1","state":"done"}],
         "next_after":8}
        """#)
        XCTAssertEqual(page.events[0], .unknown(type: "presence", seq: 7))
        XCTAssertEqual(page.events[0].seq, 7, "an unknown event still advances the cursor")
        XCTAssertEqual(page.events[1].seq, 8)
        XCTAssertEqual(page.nextAfter, 8)

        let batch = try decodeJSON(WorkerEventsBatchV1.self, #"""
        {"events":[{"job_id":"j-1","seq":1,"type":"status","status":"thinking"},
                   {"job_id":"j-1","seq":2,"type":"heartbeat"},
                   {"job_id":"j-1","seq":3,"type":"card_ref","card_id":"card-1"}]}
        """#)
        XCTAssertEqual(batch.events[1], .unknown(type: "heartbeat", seq: 2))
        guard case .cardRef(let ref) = batch.events[2] else { return XCTFail("expected a card_ref") }
        XCTAssertEqual(ref.cardId, "card-1")
    }

    func testARequiredNullableKeyMustBePresent() throws {
        let base = #"{"session_id":"s-1","scope":{"kind":"owner","label":"O"},"provider":{"kind":"bedrock","label":"B","model":"m-1"},"items":[]"#
        XCTAssertThrowsError(try decodeJSON(ThreadV1.self, base + "}"), "quota is required even though it may be null")
        let withNull = try decodeJSON(ThreadV1.self, base + #","quota":null}"#)
        XCTAssertNil(withNull.quota)
        let encoded = String(decoding: try AssistantDecoding.encode(withNull), as: UTF8.self)
        XCTAssertTrue(encoded.contains(#""quota":null"#), "a null is written, never dropped: \(encoded)")
    }

    func testAMalformedBlockStillThrows() {
        // Tolerance covers unknown VALUES, not a known block missing its fields.
        XCTAssertThrowsError(try decodeJSON(BlockV1.self, #"{"type":"text"}"#))
        XCTAssertThrowsError(try decodeJSON(BlockV1.self, #"{"text":"no type"}"#))
    }

    func testAnOversizedPayloadIsRefusedBeforeParsing() {
        let data = Data(count: AssistantDecoding.maxPayloadBytes + 1)
        XCTAssertThrowsError(try AssistantDecoding.decode(ThreadV1.self, from: data)) { error in
            XCTAssertEqual(
                error as? AssistantDecodingError,
                .payloadTooLarge(bytes: AssistantDecoding.maxPayloadBytes + 1, limit: AssistantDecoding.maxPayloadBytes)
            )
        }
    }

    // MARK: The origin rule on ConfirmCard

    func testOnlyServerFieldsRenderAboveApprove() throws {
        let golden = try loadGolden("card-approved")
        guard case .item(let pendingEvent) = golden.events[3],
              case .card(let block) = pendingEvent.item.blocks[1]
        else { return XCTFail("expected the pending card") }
        let presentation = block.card.presentation
        XCTAssertEqual(presentation.title, "Halt engine ETH-15m")
        XCTAssertEqual(presentation.aboveApprove.map(\.key), ["action", "engine", "effect"])
        XCTAssertTrue(presentation.aboveApprove.allSatisfy { $0.origin == .server })
        XCTAssertEqual(presentation.assistantsNote.map(\.key), ["note"])
        XCTAssertEqual(presentation.assistantsNote.first?.origin, .model)
        XCTAssertEqual(presentation.approveLabel, "Halt engine")
        XCTAssertEqual(presentation.declineLabel, "Keep it running")
        XCTAssertEqual(presentation.refusals, [])
        XCTAssertTrue(presentation.canApprove)
    }

    func testAModelFieldPlacedAboveApproveIsDemotedAndBlocksApprove() throws {
        let card = try decodeJSON(ConfirmCardV1.self, Self.cardJSON(fields: [
            Self.field("action", origin: "server", placement: "above_approve"),
            Self.field("amount", origin: "model", placement: "above_approve"),
            Self.field("note", origin: "model", placement: "assistants_note"),
        ]))
        let presentation = card.presentation
        XCTAssertEqual(presentation.aboveApprove.map(\.key), ["action"], "model prose never renders above Approve")
        XCTAssertEqual(presentation.assistantsNote.map(\.key), ["amount", "note"])
        XCTAssertFalse(presentation.canApprove)
        XCTAssertEqual(presentation.refusals.count, 1)
        XCTAssertFalse(ContractCheck.violations(in: card, at: "card").isEmpty)
    }

    func testACardWithNoServerFieldAboveApproveCannotBeApproved() throws {
        let card = try decodeJSON(ConfirmCardV1.self, Self.cardJSON(fields: [
            Self.field("note", origin: "model", placement: "assistants_note"),
        ]))
        XCTAssertTrue(card.presentation.aboveApprove.isEmpty)
        XCTAssertFalse(card.presentation.canApprove)
    }

    func testANonServerTitleOrButtonBlocksApprove() throws {
        let card = try decodeJSON(ConfirmCardV1.self, Self.cardJSON(titleOrigin: "model", approveOrigin: "model"))
        let presentation = card.presentation
        XCTAssertNil(presentation.title)
        XCTAssertNil(presentation.approveLabel)
        XCTAssertFalse(presentation.canApprove)
        XCTAssertEqual(presentation.refusals.count, 2)
    }

    func testApproveBindsTheDigestOfTheCardShown() throws {
        let card = try decodeJSON(ConfirmCardV1.self, Self.cardJSON())
        let approval = ApproveRequestV1(card: card, requestId: "req-1")
        XCTAssertEqual(approval.cardDigest, card.cardDigest)
        let encoded = try JSONSerialization.jsonObject(with: AssistantDecoding.encode(approval)) as? [String: String]
        XCTAssertEqual(encoded, ["card_digest": card.cardDigest, "request_id": "req-1"])
        XCTAssertTrue(Identifier.isValid(ApproveRequestV1(card: card).requestId))
    }

    // MARK: Scalars and the client

    func testTimestampsParseExactlyAndRefuseAnythingElse() {
        XCTAssertEqual(LeafTimestamp.secondsSince1970("1970-01-01T00:00:00Z"), 0)
        XCTAssertEqual(LeafTimestamp.secondsSince1970("2026-09-23T16:00:00Z"), 1_790_179_200)
        XCTAssertEqual(LeafTimestamp.secondsSince1970("2026-09-23T16:00:00.200Z") ?? 0, 1_790_179_200.2, accuracy: 0.0005)
        XCTAssertEqual(LeafTimestamp.secondsSince1970("2000-03-01T00:00:00Z"), 951_868_800)
        for bad in ["", "2026-09-23T16:00:00", "2026-09-23 16:00:00Z", "2026-13-01T00:00:00Z", "2026-09-23T16:00:00.2Z", "2026-09-23T16:00:00+00:00"] {
            XCTAssertNil(LeafTimestamp.date(bad), bad)
        }
    }

    func testIdentifiersMatchTheK0Pattern() {
        for good in ["a", "sess-owner-02", "config.propose_change", "A:b_c-d.9", String(repeating: "x", count: 128)] {
            XCTAssertTrue(Identifier.isValid(good), good)
        }
        for bad in ["", "-a", ".a", "a/b", "a b", "../x", "a?b", "é", String(repeating: "x", count: 129)] {
            XCTAssertFalse(Identifier.isValid(bad), bad)
        }
    }

    func testClientReasonsAreTheClientsOwnCopy() {
        let offline = ReasonV1.client(.offline)
        XCTAssertEqual(offline.code, .clientOffline)
        XCTAssertEqual(offline.text, "You're offline. Your message is saved.")
        XCTAssertEqual(offline.next, ReasonNext(label: "Try again", action: .retry))
        XCTAssertEqual(ReasonV1.client(.timeout).text, "The assistant didn't answer in time.")
        XCTAssertEqual(ReasonCode.clientOffline.rule?.owner, .client)
        // The server may never send a client-owned code.
        XCTAssertFalse(ContractCheck.violations(in: offline, at: "reason").isEmpty)
    }

    func testTheClientBuildsK0RoutesAndMapsRefusals() async throws {
        let transport = RecordingTransport(responses: [
            TransportResponse(status: 202, body: Data(#"{"type":"turn","session_id":"s-1","seq":2,"at":"2026-09-23T16:00:00Z","requires_action":false,"turn_id":"t-1","state":"queued"}"#.utf8)),
            TransportResponse(status: 429, body: Data(#"{"reason":{"code":"rate_limited","text":"Later.","next":{"label":"Wait","action":"wait"},"retry_at":"2026-09-23T17:00:00Z"}}"#.utf8)),
        ])
        let client = AssistantClient(transport: transport)
        let queued = try await client.sendTurn(sessionId: "s-1", TurnRequestV1(requestId: "req-1", text: "hi"))
        XCTAssertEqual(queued.seq, 2)
        do {
            _ = try await client.sendTurn(sessionId: "s-1", TurnRequestV1(requestId: "req-2", text: "again"))
            XCTFail("a 429 must throw")
        } catch let error as AssistantClientError {
            guard case .refused(let status, let reason) = error else { return XCTFail("unexpected \(error)") }
            XCTAssertEqual(status, 429)
            XCTAssertEqual(reason.code, .rateLimited)
            XCTAssertEqual(error.reason?.retryAt, "2026-09-23T17:00:00Z")
        }
        let sent = await transport.sent
        XCTAssertEqual(sent.map(\.path), ["/sessions/s-1/turns", "/sessions/s-1/turns"])
        XCTAssertEqual(sent.first?.method, .post)
        XCTAssertEqual(sent.first?.contentType, "application/json")

        // Nothing is sent for an id that could rewrite the route, or an over-long turn.
        do {
            _ = try await client.thread(sessionId: "../admin")
            XCTFail("a malformed id must throw")
        } catch let error as AssistantClientError {
            XCTAssertEqual(error, .invalidIdentifier("../admin"))
        }
        do {
            let long = String(repeating: "a", count: TurnRequestV1.maxTextLength + 1)
            _ = try await client.sendTurn(sessionId: "s-1", TurnRequestV1(requestId: "req-3", text: long))
            XCTFail("an over-long turn must throw")
        } catch let error as AssistantClientError {
            XCTAssertEqual(error, .textOutOfBounds(TurnRequestV1.maxTextLength + 1))
        }
        let sentAfter = await transport.sent
        XCTAssertEqual(sentAfter.count, 2)
    }

    func testTransportFailuresMapToTheClientReasons() async throws {
        let client = AssistantClient(transport: FailingTransport(failure: .offline))
        do {
            _ = try await client.events(sessionId: "s-1", after: 3, waitSeconds: 15)
            XCTFail("an offline transport must throw")
        } catch let error as AssistantClientError {
            XCTAssertEqual(error, .offline)
            XCTAssertEqual(error.reason?.code, .clientOffline)
        }
    }

    // MARK: Helpers

    static func field(_ key: String, origin: String, placement: String) -> String {
        #"{"key":"\#(key)","label":"\#(key)","value":"v","origin":"\#(origin)","placement":"\#(placement)"}"#
    }

    static func cardJSON(
        kind: String = "control",
        state: String = "pending",
        fields: [String]? = nil,
        titleOrigin: String = "server",
        approveOrigin: String = "server",
        spendState: String = "none"
    ) -> String {
        let digest = String(repeating: "b", count: 64)
        let fieldList = (fields ?? [field("action", origin: "server", placement: "above_approve")]).joined(separator: ",")
        return #"""
        {"card_id":"card-1","proposal_id":"prop-1","proposal_digest":"\#(digest)","kind":"\#(kind)","state":"\#(state)",
         "title":{"text":"Title","origin":"\#(titleOrigin)"},"fields":[\#(fieldList)],
         "approve":{"text":"Approve","origin":"\#(approveOrigin)"},"decline":{"text":"Decline","origin":"server"},
         "spend":{"state":"\#(spendState)","cents":null},"requires_face_id":false,
         "created_at":"2026-09-23T16:00:00Z","expires_at":"2026-09-23T16:05:00Z","card_digest":"\#(digest)","resolution":null}
        """#
    }
}

/// Records every request and answers from a fixed queue.
actor RecordingTransport: AssistantTransport {
    private var responses: [TransportResponse]
    private(set) var sent: [TransportRequest] = []

    init(responses: [TransportResponse]) {
        self.responses = responses
    }

    func send(_ request: TransportRequest) async throws -> TransportResponse {
        sent.append(request)
        guard !responses.isEmpty else { throw TransportFailure.timedOut }
        return responses.removeFirst()
    }
}

struct FailingTransport: AssistantTransport {
    let failure: TransportFailure

    func send(_ request: TransportRequest) async throws -> TransportResponse {
        throw failure
    }
}

#if canImport(Testing)
/// The seven fixture decodes again under swift-testing, so a toolchain that runs
/// only swift-testing still executes them. tools/mac_verify_kit.py requires each
/// test<Name> below (or its XCTest twin) to pass, one per golden.
@Suite struct GoldenFixtureSuite {
    private func checkGolden(_ name: String) throws {
        let golden = try loadGolden(name)
        #expect(golden.name == name)
        #expect(ContractCheck.violations(in: golden) == [], "\(name) breaks the contract")
        #expect(golden.events.allSatisfy { $0.requiresActionIsConsistent }, "\(name) requires_action")
        #expect(ThreadFold.fold(golden.events) == golden.thread.items, "\(name): batch fold")
        let again = try AssistantDecoding.decode(GoldenConversationV1.self, from: AssistantDecoding.encode(golden))
        #expect(again == golden, "\(name) changed on a round trip")
    }

    @Test func testIdle() throws { try checkGolden("idle") }
    @Test func testAnswerWithView() throws { try checkGolden("answer-with-view") }
    @Test func testToolFailed() throws { try checkGolden("tool-failed") }
    @Test func testCardApproved() throws { try checkGolden("card-approved") }
    @Test func testCardExpired() throws { try checkGolden("card-expired") }
    @Test func testRateLimited() throws { try checkGolden("rate-limited") }
    @Test func testWorkerOffline() throws { try checkGolden("worker-offline") }
}
#endif
