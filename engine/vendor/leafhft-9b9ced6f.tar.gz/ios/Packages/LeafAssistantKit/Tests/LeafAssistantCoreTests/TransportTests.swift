import Foundation
import XCTest
@testable import LeafAssistantCore

final class TransportTests: XCTestCase {
    func testTurnEventsBuildsTheTurnScopedRoute() async throws {
        let response = TransportResponse(
            status: 200,
            body: try AssistantDecoding.encode(EventsPageV1(events: [], nextAfter: 3))
        )
        let transport = RecordingTransport(responses: [response, response])
        let client = AssistantClient(transport: transport)

        _ = try await client.turnEvents(turnId: "turn-1", after: 3, waitSeconds: 15)
        let firstSent = await transport.sent
        XCTAssertEqual(firstSent, [TransportRequest(
            method: .get,
            path: "/turns/turn-1/events",
            query: [
                TransportQueryItem(name: "after", value: "3"),
                TransportQueryItem(name: "wait", value: "15"),
            ]
        )])
        XCTAssertNil(firstSent.first?.body)

        _ = try await client.turnEvents(turnId: "turn-1")
        let sent = await transport.sent
        XCTAssertEqual(sent.count, 2)
        XCTAssertEqual(sent.last, TransportRequest(method: .get, path: "/turns/turn-1/events"))
        XCTAssertEqual(sent.last?.query, [])
    }

    func testTurnEventsDecodesEveryGoldenPage() async throws {
        for name in goldenNames {
            let golden = try loadGolden(name)
            let nextAfter = golden.events.last?.seq ?? 0
            let transport = RecordingTransport(responses: [TransportResponse(
                status: 200,
                body: try AssistantDecoding.encode(EventsPageV1(events: golden.events, nextAfter: nextAfter))
            )])
            let client = AssistantClient(transport: transport)

            let page = try await client.turnEvents(turnId: "turn-1")
            XCTAssertEqual(page.events, golden.events, name)
            XCTAssertEqual(page.nextAfter, nextAfter, name)
            XCTAssertEqual(ThreadFold.fold(page.events), golden.thread.items, name)
        }
    }

    func testTurnEventsResumesFromNextAfter() async throws {
        let golden = try loadGolden("answer-with-view")
        let firstEvents = Array(golden.events.prefix(3))
        let remainingEvents = Array(golden.events.dropFirst(3))
        let transport = RecordingTransport(responses: [
            TransportResponse(
                status: 200,
                body: try AssistantDecoding.encode(EventsPageV1(events: firstEvents, nextAfter: 7))
            ),
            TransportResponse(
                status: 200,
                body: try AssistantDecoding.encode(EventsPageV1(events: remainingEvents, nextAfter: 7))
            ),
        ])
        let client = AssistantClient(transport: transport)

        let page = try await client.turnEvents(turnId: "turn-1")
        XCTAssertEqual(page.events, firstEvents)
        XCTAssertEqual(page.events.last?.seq, 3)
        XCTAssertEqual(page.nextAfter, 7)
        let nextPage = try await client.turnEvents(turnId: "turn-1", after: page.nextAfter)
        XCTAssertEqual(nextPage.events, remainingEvents)
        let sent = await transport.sent
        XCTAssertEqual(sent.count, 2)
        XCTAssertEqual(sent.last?.query, [TransportQueryItem(name: "after", value: "7")])
        XCTAssertEqual(ThreadFold.fold(page.events + nextPage.events), golden.thread.items)
    }

    func testTurnEventsRefusesBadInputWithNothingSent() async throws {
        let refusal = try decodeJSON(ErrorV1.self, #"{"reason":{"code":"turn_expired","text":"Turn expired.","next":{"label":"Try again","action":"retry"}}}"#)
        let transport = RecordingTransport(responses: [
            TransportResponse(
                status: 200,
                body: try AssistantDecoding.encode(EventsPageV1(events: [], nextAfter: 8001))
            ),
            TransportResponse(status: 404, body: try AssistantDecoding.encode(refusal)),
        ])
        let client = AssistantClient(transport: transport)
        let invalid: [(turnId: String, after: Int?, wait: Int?, error: AssistantClientError)] = [
            ("../x", nil, nil, .invalidIdentifier("../x")),
            ("turn-1", -1, nil, .parameterOutOfRange("after")),
            ("turn-1", 8002, nil, .parameterOutOfRange("after")),
            ("turn-1", nil, -1, .parameterOutOfRange("wait")),
            ("turn-1", nil, 16, .parameterOutOfRange("wait")),
        ]
        for input in invalid {
            do {
                _ = try await client.turnEvents(turnId: input.turnId, after: input.after, waitSeconds: input.wait)
                XCTFail("invalid input must throw: \(input)")
            } catch let error as AssistantClientError {
                XCTAssertEqual(error, input.error)
            }
            let sent = await transport.sent
            XCTAssertTrue(sent.isEmpty, "invalid input must not reach the transport")
        }

        _ = try await client.turnEvents(turnId: "turn-1", after: 8001, waitSeconds: 15)
        let accepted = await transport.sent
        XCTAssertEqual(accepted.count, 1)
        XCTAssertEqual(accepted.first?.query, [
            TransportQueryItem(name: "after", value: "8001"),
            TransportQueryItem(name: "wait", value: "15"),
        ])

        do {
            _ = try await client.turnEvents(turnId: "turn-1")
            XCTFail("a 404 must throw")
        } catch let error as AssistantClientError {
            XCTAssertEqual(error, .refused(status: 404, reason: refusal.reason))
        }
        let sent = await transport.sent
        XCTAssertEqual(sent.count, 2)

        let offlineClient = AssistantClient(transport: FailingTransport(failure: .offline))
        do {
            _ = try await offlineClient.turnEvents(turnId: "turn-1")
            XCTFail("an offline transport must throw")
        } catch let error as AssistantClientError {
            XCTAssertEqual(error, .offline)
        }
    }
}
