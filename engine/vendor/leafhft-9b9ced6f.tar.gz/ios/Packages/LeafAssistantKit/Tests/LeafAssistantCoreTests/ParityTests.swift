import Foundation
import XCTest
@testable import LeafAssistantCore

// Drift between the TS contract (K0) and these Swift models is a test failure:
// the vendored goldens must match K0's FIXTURES.sha256 byte for byte, and every
// Swift model's wire keys must equal the K0 JSON Schema's properties, with the
// non-optional ones equal to its required keys. Enum values are compared too.

struct SchemaPathError: Error, CustomStringConvertible {
    let description: String
}

/// Walks the parsed schema by object keys (String) and array indices (Int).
func schemaNode(_ root: Any, _ path: Any...) throws -> [String: Any] {
    var current = root
    for step in path {
        if let key = step as? String, let object = current as? [String: Any], let next = object[key] {
            current = next
        } else if let index = step as? Int, let array = current as? [Any], array.indices.contains(index) {
            current = array[index]
        } else {
            throw SchemaPathError(description: "the K0 schema has no \(path)")
        }
    }
    guard let object = current as? [String: Any] else {
        throw SchemaPathError(description: "the K0 schema node at \(path) is not an object")
    }
    return object
}

/// The anyOf branch whose `discriminator` property is the constant `value`.
func schemaBranch(_ union: [String: Any], _ discriminator: String, _ value: String) throws -> [String: Any] {
    for branch in union["anyOf"] as? [Any] ?? [] {
        guard let object = branch as? [String: Any],
              let properties = object["properties"] as? [String: Any],
              let property = properties[discriminator] as? [String: Any]
        else { continue }
        if property["const"] as? String == value { return object }
    }
    throw SchemaPathError(description: "the K0 union has no branch with \(discriminator) = \(value)")
}

func branchConstants(_ union: [String: Any], _ discriminator: String) -> [String] {
    (union["anyOf"] as? [Any] ?? []).compactMap { branch -> String? in
        let properties = (branch as? [String: Any])?["properties"] as? [String: Any]
        return (properties?[discriminator] as? [String: Any])?["const"] as? String
    }
}

final class ParityTests: XCTestCase {
    private var schema: Any = [String: Any]()
    private var defs: [String: Any] = [:]

    override func setUpWithError() throws {
        let url = KitPaths.contractDir.appendingPathComponent("schema").appendingPathComponent("assistant.schema.json")
        guard FileManager.default.fileExists(atPath: url.path) else {
            XCTFail("K0 schema not found at \(url.path); sync packages/assistant-contract/schema beside the package")
            throw SchemaPathError(description: "missing \(url.path)")
        }
        schema = try JSONSerialization.jsonObject(with: Data(contentsOf: url))
        defs = try schemaNode(schema, "$defs")
    }

    // MARK: Fixture pins

    private func pinDigest() throws -> any DigestProvider {
        #if canImport(CryptoKit)
        return CryptoKitDigest()
        #else
        throw XCTSkip("no SHA-256 provider on this platform; inject a DigestProvider to run the pin check")
        #endif
    }

    func testVendoredFixturesMatchTheK0Pins() throws {
        let digest = try pinDigest()
        let files = try goldenNames.map { name -> (name: String, contents: Data) in
            let file = "\(name).json"
            let contents = try Data(contentsOf: KitPaths.fixturesDir.appendingPathComponent(file))
            return (name: file, contents: contents)
        }
        let recomputed = FixturePins.render(files, digest: digest)
        let vendoredPin = String(decoding: try KitPaths.readLF(KitPaths.fixturesDir.appendingPathComponent("FIXTURES.sha256")), as: UTF8.self)
        XCTAssertEqual(recomputed, vendoredPin, "the vendored fixtures no longer match the vendored FIXTURES.sha256")

        let k0Fixtures = KitPaths.contractDir.appendingPathComponent("fixtures")
        let k0PinURL = k0Fixtures.appendingPathComponent("FIXTURES.sha256")
        guard FileManager.default.fileExists(atPath: k0PinURL.path) else {
            return XCTFail("K0 pin not found at \(k0PinURL.path); sync packages/assistant-contract/fixtures beside the package")
        }
        let k0Pin = String(decoding: try KitPaths.readLF(k0PinURL), as: UTF8.self)
        XCTAssertEqual(vendoredPin, k0Pin, "the vendored pin drifted from K0's; re-vendor the fixtures at the new pin")
        XCTAssertEqual(try FixturePins.parse(vendoredPin).count, goldenNames.count)
        for name in goldenNames {
            let file = "\(name).json"
            let vendored = try KitPaths.readLF(KitPaths.fixturesDir.appendingPathComponent(file))
            let upstream = try KitPaths.readLF(k0Fixtures.appendingPathComponent(file))
            XCTAssertEqual(vendored, upstream, "\(file) differs from K0's copy")
        }
    }

    func testPinFilesParseAndRefuseMalformedLines() throws {
        let hex = String(repeating: "0", count: 64)
        XCTAssertEqual(try FixturePins.parse("\(hex)  a.json\r\n\(hex)  b.json\n"), ["a.json": hex, "b.json": hex])
        XCTAssertThrowsError(try FixturePins.parse("\(hex) a.json\n"))
        XCTAssertThrowsError(try FixturePins.parse("\(hex.uppercased())X  a.json\n"))
        XCTAssertThrowsError(try FixturePins.parse("\(hex)  a.json\n\(hex)  a.json\n"))
        XCTAssertEqual(FixturePins.lfNormalized(Data("a\r\nb\r\r\nc\r".utf8)), Data("a\nb\r\nc\r".utf8))
    }

    // MARK: Field names

    private func assertKeys<M: WireModel>(
        _ model: M.Type,
        _ node: [String: Any],
        file: StaticString = #filePath,
        line: UInt = #line
    ) {
        let properties = Set((node["properties"] as? [String: Any] ?? [:]).keys)
        let required = Set(node["required"] as? [String] ?? [])
        let keys = Set(M.wireKeys)
        XCTAssertEqual(keys.count, M.wireKeys.count, "\(M.self) declares a key twice", file: file, line: line)
        XCTAssertEqual(keys, properties, "\(M.self) wire keys vs the K0 schema's properties", file: file, line: line)
        XCTAssertEqual(
            keys.subtracting(M.optionalWireKeys), required,
            "\(M.self) required keys vs the K0 schema's required", file: file, line: line
        )
        XCTAssertTrue(M.optionalWireKeys.isSubset(of: keys), "\(M.self) marks an undeclared key optional", file: file, line: line)
    }

    private func assertEnum<E: LenientEnum>(
        _ type: E.Type,
        _ node: [String: Any],
        file: StaticString = #filePath,
        line: UInt = #line
    ) {
        let schemaValues = Set(node["enum"] as? [String] ?? [])
        XCTAssertFalse(schemaValues.isEmpty, "no enum in the K0 schema for \(E.self)", file: file, line: line)
        XCTAssertEqual(Set(E.knownCases.map(\.rawValue)), schemaValues, "\(E.self) values vs the K0 schema", file: file, line: line)
    }

    func testEveryK0DefinitionIsCovered() {
        XCTAssertEqual(Set(defs.keys), [
            "ReasonV1", "ErrorV1", "ProposalV1", "ConfirmCardV1", "ApproveRequestV1", "ToolCallV1", "BlockV1",
            "ItemV1", "ThreadV1", "ThreadEventV1", "EventsPageV1", "TurnRequestV1", "WorkerEventV1",
            "WorkerEventsBatchV1", "GoldenConversationV1",
        ], "K0 added or removed a definition; model it here first")
    }

    func testReasonAndErrorKeys() throws {
        let reason = try schemaNode(defs, "ReasonV1")
        assertKeys(ReasonV1.self, reason)
        assertKeys(ReasonNext.self, try schemaNode(reason, "properties", "next"))
        assertEnum(ReasonCode.self, try schemaNode(reason, "properties", "code"))
        assertEnum(ReasonAction.self, try schemaNode(reason, "properties", "next", "properties", "action"))
        assertKeys(ErrorV1.self, try schemaNode(defs, "ErrorV1"))
        // Every known code has a reason-table row, and client-owned codes are exactly the two.
        XCTAssertTrue(ReasonCode.knownCases.allSatisfy { $0.rule != nil })
        XCTAssertEqual(ReasonCode.knownCases.filter { $0.rule?.owner == .client }, [.clientOffline, .clientTimeout])
    }

    func testConfirmCardKeys() throws {
        let card = try schemaNode(defs, "ConfirmCardV1")
        assertKeys(ConfirmCardV1.self, card)
        for key in ["title", "approve", "decline"] {
            assertKeys(ServerText.self, try schemaNode(card, "properties", key))
        }
        let field = try schemaNode(card, "properties", "fields", "items")
        assertKeys(CardField.self, field)
        assertEnum(Origin.self, try schemaNode(field, "properties", "origin"))
        assertEnum(CardPlacement.self, try schemaNode(field, "properties", "placement"))
        let spend = try schemaNode(card, "properties", "spend")
        assertKeys(Spend.self, spend)
        assertEnum(SpendState.self, try schemaNode(spend, "properties", "state"))
        let resolution = try schemaNode(card, "properties", "resolution", "anyOf", 0)
        assertKeys(CardResolution.self, resolution)
        assertKeys(ServerText.self, try schemaNode(resolution, "properties", "receipt"))
        let actor = try schemaNode(resolution, "properties", "actor", "anyOf", 0)
        assertKeys(CardActor.self, actor)
        assertEnum(ActorKind.self, try schemaNode(actor, "properties", "kind"))
        assertEnum(ProposalKind.self, try schemaNode(card, "properties", "kind"))
        assertEnum(CardState.self, try schemaNode(card, "properties", "state"))
        assertKeys(ApproveRequestV1.self, try schemaNode(defs, "ApproveRequestV1"))
        assertKeys(PresenceAssertionV1.self, try schemaNode(defs, "ApproveRequestV1", "properties", "presence"))
        assertEnum(PresenceMethod.self, try schemaNode(defs, "ApproveRequestV1", "properties", "presence", "properties", "method"))
    }

    func testProposalKeys() throws {
        let union = try schemaNode(defs, "ProposalV1")
        XCTAssertEqual(Set(branchConstants(union, "kind")), Set(ProposalKind.knownCases.map(\.rawValue)))
        for kind in ProposalKind.knownCases {
            let branch = try schemaBranch(union, "kind", kind.rawValue)
            let properties = Set((branch["properties"] as? [String: Any] ?? [:]).keys)
            let required = Set(branch["required"] as? [String] ?? [])
            let swiftKeys = Set(ProposalV1.wireKeys(for: kind))
            XCTAssertEqual(swiftKeys, properties, "ProposalV1 \(kind.rawValue) keys")
            XCTAssertEqual(swiftKeys, required, "ProposalV1 \(kind.rawValue) required keys")
        }
        let control = try schemaNode(schemaBranch(union, "kind", "control"), "properties", "control")
        assertKeys(ControlPayload.self, control)
        assertEnum(ControlAction.self, try schemaNode(control, "properties", "action"))
        assertKeys(BuildPayload.self, try schemaNode(schemaBranch(union, "kind", "build"), "properties", "build"))
        assertKeys(
            ConfigDraftPayload.self,
            try schemaNode(schemaBranch(union, "kind", "config_draft"), "properties", "config_draft")
        )
        assertKeys(
            SlotPromotionPayload.self,
            try schemaNode(schemaBranch(union, "kind", "slot_promotion"), "properties", "slot_promotion")
        )
        assertKeys(
            WalkResumePayload.self,
            try schemaNode(schemaBranch(union, "kind", "walk.resume"), "properties", "walk")
        )
        assertKeys(
            WalkSideQuestPayload.self,
            try schemaNode(schemaBranch(union, "kind", "walk.side_quest"), "properties", "walk")
        )
    }

    func testBlockAndItemKeys() throws {
        let tool = try schemaNode(defs, "ToolCallV1")
        assertKeys(ToolCallV1.self, tool)
        assertEnum(ToolState.self, try schemaNode(tool, "properties", "state"))

        let union = try schemaNode(defs, "BlockV1")
        XCTAssertEqual(branchConstants(union, "type"), BlockV1.knownTypes)
        assertKeys(TextBlock.self, try schemaBranch(union, "type", "text"))
        assertKeys(ToolsBlock.self, try schemaBranch(union, "type", "tools"))
        let view = try schemaBranch(union, "type", "view")
        assertKeys(ViewBlock.self, view)
        assertEnum(ViewKind.self, try schemaNode(view, "properties", "kind"))
        let row = try schemaNode(view, "properties", "rows", "items")
        assertKeys(ViewRow.self, row)
        assertEnum(ViewUnit.self, try schemaNode(row, "properties", "unit", "anyOf", 0))
        assertKeys(CardBlock.self, try schemaBranch(union, "type", "card"))
        assertKeys(ArtifactBlock.self, try schemaBranch(union, "type", "artifact"))
        assertKeys(NoticeBlock.self, try schemaBranch(union, "type", "notice"))
        // Every server-only block pins origin to "server" in the schema.
        for type in BlockV1.serverOnlyTypes {
            let origin = try schemaNode(schemaBranch(union, "type", type), "properties", "origin")
            XCTAssertEqual(origin["const"] as? String, "server", "\(type) origin")
        }

        let item = try schemaNode(defs, "ItemV1")
        assertKeys(ItemV1.self, item)
        assertEnum(ItemRole.self, try schemaNode(item, "properties", "role"))
    }

    func testThreadAndEventKeys() throws {
        let thread = try schemaNode(defs, "ThreadV1")
        assertKeys(ThreadV1.self, thread)
        let scope = try schemaNode(thread, "properties", "scope")
        assertKeys(ScopeV1.self, scope)
        assertEnum(ScopeKind.self, try schemaNode(scope, "properties", "kind"))
        let provider = try schemaNode(thread, "properties", "provider")
        assertKeys(ProviderV1.self, provider)
        assertEnum(ProviderKind.self, try schemaNode(provider, "properties", "kind"))
        let quota = try schemaNode(thread, "properties", "quota", "anyOf", 0)
        assertKeys(QuotaV1.self, quota)
        assertEnum(QuotaWindow.self, try schemaNode(quota, "properties", "window"))

        let events = try schemaNode(defs, "ThreadEventV1")
        XCTAssertEqual(branchConstants(events, "type"), ThreadEventV1.knownTypes)
        assertKeys(ItemEventV1.self, try schemaBranch(events, "type", "item"))
        let turn = try schemaBranch(events, "type", "turn")
        assertKeys(TurnEventV1.self, turn)
        assertEnum(TurnState.self, try schemaNode(turn, "properties", "state"))

        assertKeys(EventsPageV1.self, try schemaNode(defs, "EventsPageV1"))
        let turnRequest = try schemaNode(defs, "TurnRequestV1")
        assertKeys(TurnRequestV1.self, turnRequest)
        let text = try schemaNode(turnRequest, "properties", "text")
        XCTAssertEqual(text["maxLength"] as? Int, TurnRequestV1.maxTextLength)
        assertKeys(GoldenConversationV1.self, try schemaNode(defs, "GoldenConversationV1"))
    }

    func testWorkerEventKeys() throws {
        let union = try schemaNode(defs, "WorkerEventV1")
        XCTAssertEqual(branchConstants(union, "type"), WorkerEventV1.knownTypes)
        let status = try schemaBranch(union, "type", "status")
        assertKeys(WorkerStatusEventV1.self, status)
        assertEnum(WorkerStatus.self, try schemaNode(status, "properties", "status"))
        assertKeys(WorkerTextEventV1.self, try schemaBranch(union, "type", "text"))
        let tool = try schemaBranch(union, "type", "tool")
        assertKeys(WorkerToolEventV1.self, tool)
        assertEnum(ToolState.self, try schemaNode(tool, "properties", "state"))
        let error = try schemaBranch(union, "type", "error")
        assertKeys(WorkerErrorEventV1.self, error)
        assertEnum(WorkerErrorCode.self, try schemaNode(error, "properties", "code"))
        assertKeys(WorkerCardRefEventV1.self, try schemaBranch(union, "type", "card_ref"))
        assertKeys(WorkerArtifactRefEventV1.self, try schemaBranch(union, "type", "artifact_ref"))
        assertKeys(WorkerEventsBatchV1.self, try schemaNode(defs, "WorkerEventsBatchV1"))
    }
}
