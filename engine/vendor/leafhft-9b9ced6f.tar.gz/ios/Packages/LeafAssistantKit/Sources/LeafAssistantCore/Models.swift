import Foundation

// LeafAssistantCore mirrors packages/assistant-contract (K0) field for field.
// Contract: every wire key is spelled exactly as the K0 JSON Schema spells it
// (ParityTests compares them), every enum tolerates values it does not know
// (an unrecognized string decodes to `.unknown`, never a throw), and a key the
// schema requires but allows to be null must still be present (`@Nullable`).

// MARK: - Wire plumbing

/// The raw value every lenient enum's fallback case carries. Never a contract value.
public let leafUnknownRawValue = "_unknown"

/// A wire enum that never throws on a value it does not know, so a newer server
/// cannot crash an older client. Renderers treat `unknownCase` as the safe reading.
public protocol LenientEnum: RawRepresentable, CaseIterable, Codable, Hashable, Sendable where RawValue == String {
    static var unknownCase: Self { get }
}

extension LenientEnum {
    public init(from decoder: Decoder) throws {
        let raw = try decoder.singleValueContainer().decode(String.self)
        self = Self(rawValue: raw) ?? Self.unknownCase
    }

    /// The values the contract names, without the fallback.
    public static var knownCases: [Self] {
        allCases.filter { $0.rawValue != leafUnknownRawValue }
    }
}

/// A model whose JSON keys are declared once, so the parity test can compare them with K0.
public protocol WireModel: Codable, Hashable, Sendable {
    /// Every JSON key this model reads and writes, spelled as the K0 schema spells it.
    static var wireKeys: [String] { get }
    /// The keys the schema lets a sender omit. Every other wire key is required.
    static var optionalWireKeys: Set<String> { get }
}

extension WireModel {
    public static var optionalWireKeys: Set<String> { [] }
}

/// A required key whose value may be null. Decoding fails closed when the key is
/// missing (K0 marks it required); encoding writes an explicit null.
@propertyWrapper
public struct Nullable<Value: Codable & Hashable & Sendable>: Codable, Hashable, Sendable {
    public var wrappedValue: Value?

    public init(wrappedValue: Value?) {
        self.wrappedValue = wrappedValue
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            wrappedValue = nil
        } else {
            wrappedValue = try container.decode(Value.self)
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        if let value = wrappedValue {
            try container.encode(value)
        } else {
            try container.encodeNil()
        }
    }
}

/// Reads the `type` discriminator of a union member without committing to a variant.
struct WireDiscriminator: Codable {
    let type: String
    let seq: Int?

    init(type: String, seq: Int? = nil) {
        self.type = type
        self.seq = seq
    }
}

// MARK: - Enums

public enum Origin: String, LenientEnum {
    case server, model
    case unknown = "_unknown"
    public static var unknownCase: Origin { .unknown }
}

public enum ReasonCode: String, LenientEnum {
    case rateLimited = "rate_limited"
    case busy
    case workerOffline = "worker_offline"
    case toolFailed = "tool_failed"
    case turnExpired = "turn_expired"
    case cardExpired = "card_expired"
    case cardSuperseded = "card_superseded"
    case cardConsumed = "card_consumed"
    case cardDigestMismatch = "card_digest_mismatch"
    case selfApprovalRefused = "self_approval_refused"
    case accessRevoked = "access_revoked"
    case unpaired
    case unconfigured
    case assistantDisabled = "assistant_disabled"
    case updateRequired = "update_required"
    case notFound = "not_found"
    case refused
    case internalError = "internal"
    case clientOffline = "client.offline"
    case clientTimeout = "client.timeout"
    case unknown = "_unknown"
    public static var unknownCase: ReasonCode { .unknown }
}

public enum ReasonAction: String, LenientEnum {
    case retry, wait, refresh
    case openSettings = "open_settings"
    case pair
    case none
    case unknown = "_unknown"
    public static var unknownCase: ReasonAction { .unknown }
}

public enum ProposalKind: String, LenientEnum {
    case control, build
    case configDraft = "config_draft"
    case slotPromotion = "slot_promotion"
    case walkResume = "walk.resume"
    case walkSideQuest = "walk.side_quest"
    case unknown = "_unknown"
    public static var unknownCase: ProposalKind { .unknown }
}

public enum ControlAction: String, LenientEnum {
    case engineHalt = "engine.halt"
    case engineEnable = "engine.enable"
    case engineDisable = "engine.disable"
    case engineProbe = "engine.probe"
    case riskBreaker = "risk.breaker"
    case unknown = "_unknown"
    public static var unknownCase: ControlAction { .unknown }
}

public enum CardState: String, LenientEnum {
    case pending, approved, declined, expired, superseded
    case unknown = "_unknown"
    public static var unknownCase: CardState { .unknown }
}

public enum CardPlacement: String, LenientEnum {
    case aboveApprove = "above_approve"
    case assistantsNote = "assistants_note"
    case unknown = "_unknown"
    public static var unknownCase: CardPlacement { .unknown }
}

/// `unknown` is a contract value here ("spend not known"), and it is also the
/// safe reading of a state this client does not recognize, so it is the fallback.
public enum SpendState: String, LenientEnum {
    case none, unknown, reported
    public static var unknownCase: SpendState { .unknown }
}

public enum ActorKind: String, LenientEnum {
    case owner
    case tenantDevice = "tenant_device"
    case adminSession = "admin_session"
    case unknown = "_unknown"
    public static var unknownCase: ActorKind { .unknown }
}

public enum ToolState: String, LenientEnum {
    case running, done, failed
    case unknown = "_unknown"
    public static var unknownCase: ToolState { .unknown }
}

public enum ViewKind: String, LenientEnum {
    case metric, table, line
    case unknown = "_unknown"
    public static var unknownCase: ViewKind { .unknown }
}

public enum ViewUnit: String, LenientEnum {
    case cents, pct, count, text
    case unknown = "_unknown"
    public static var unknownCase: ViewUnit { .unknown }
}

public enum ItemRole: String, LenientEnum {
    case user, assistant, server
    case unknown = "_unknown"
    public static var unknownCase: ItemRole { .unknown }
}

public enum ScopeKind: String, LenientEnum {
    case owner, tenant
    case unknown = "_unknown"
    public static var unknownCase: ScopeKind { .unknown }
}

public enum ProviderKind: String, LenientEnum {
    case claudeCodeCli = "claude-code-cli"
    case anthropicApi = "anthropic-api"
    case bedrock
    case codexCli = "codex-cli"
    case unknown = "_unknown"
    public static var unknownCase: ProviderKind { .unknown }
}

public enum QuotaWindow: String, LenientEnum {
    case hour, day
    case unknown = "_unknown"
    public static var unknownCase: QuotaWindow { .unknown }
}

public enum TurnState: String, LenientEnum {
    case queued, running, done, failed, stopped, expired
    case unknown = "_unknown"
    public static var unknownCase: TurnState { .unknown }
}

public enum WorkerStatus: String, LenientEnum {
    case thinking, streaming
    case unknown = "_unknown"
    public static var unknownCase: WorkerStatus { .unknown }
}

public enum WorkerErrorCode: String, LenientEnum {
    case workerOffline = "worker_offline"
    case toolFailed = "tool_failed"
    case turnExpired = "turn_expired"
    case internalError = "internal"
    case unknown = "_unknown"
    public static var unknownCase: WorkerErrorCode { .unknown }
}

// MARK: - ReasonV1

/// One row of K0's reason table: the one exit a reason offers, whether it carries
/// `retry_at`, and who authors its text.
public struct ReasonRule: Hashable, Sendable {
    public enum RetryAt: Hashable, Sendable { case mustBePresent, mayBePresent, mustBeAbsent }
    public enum Owner: Hashable, Sendable { case server, client }

    public let action: ReasonAction
    public let retryAt: RetryAt
    public let owner: Owner
}

extension ReasonCode {
    /// K0's REASON_TABLE row for this code; nil for a code this client does not know.
    public var rule: ReasonRule? {
        switch self {
        case .rateLimited: return ReasonRule(action: .wait, retryAt: .mustBePresent, owner: .server)
        case .busy: return ReasonRule(action: .wait, retryAt: .mayBePresent, owner: .server)
        case .workerOffline, .toolFailed, .turnExpired, .cardExpired, .internalError:
            return ReasonRule(action: .retry, retryAt: .mustBeAbsent, owner: .server)
        case .cardSuperseded, .cardConsumed, .cardDigestMismatch, .notFound:
            return ReasonRule(action: .refresh, retryAt: .mustBeAbsent, owner: .server)
        case .selfApprovalRefused, .assistantDisabled, .refused:
            return ReasonRule(action: ReasonAction.none, retryAt: .mustBeAbsent, owner: .server)
        case .accessRevoked, .unpaired:
            return ReasonRule(action: .pair, retryAt: .mustBeAbsent, owner: .server)
        case .unconfigured, .updateRequired:
            return ReasonRule(action: .openSettings, retryAt: .mustBeAbsent, owner: .server)
        case .clientOffline, .clientTimeout:
            return ReasonRule(action: .retry, retryAt: .mustBeAbsent, owner: .client)
        case .unknown:
            return nil
        }
    }
}

public struct ReasonNext: WireModel {
    public var label: String
    public var action: ReasonAction

    public init(label: String, action: ReasonAction) {
        self.label = label
        self.action = action
    }

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case label, action
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct ReasonV1: WireModel {
    public var code: ReasonCode
    public var text: String
    public var next: ReasonNext
    public var retryAt: String?

    public init(code: ReasonCode, text: String, next: ReasonNext, retryAt: String? = nil) {
        self.code = code
        self.text = text
        self.next = next
        self.retryAt = retryAt
    }

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case code, text, next
        case retryAt = "retry_at"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
    public static var optionalWireKeys: Set<String> { ["retry_at"] }

    /// The two codes the client authors itself (K0 `clientReason`).
    public enum ClientCode: Sendable { case offline, timeout }

    /// The client's own copy for a client-owned code. The server never sends these.
    public static func client(_ code: ClientCode) -> ReasonV1 {
        switch code {
        case .offline:
            return ReasonV1(
                code: .clientOffline,
                text: "You're offline. Your message is saved.",
                next: ReasonNext(label: "Try again", action: .retry)
            )
        case .timeout:
            return ReasonV1(
                code: .clientTimeout,
                text: "The assistant didn't answer in time.",
                next: ReasonNext(label: "Try again", action: .retry)
            )
        }
    }
}

/// The error body of every refused request (400, 404, 409, 410, 429).
public struct ErrorV1: WireModel {
    public var reason: ReasonV1

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case reason
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

// MARK: - ConfirmCardV1

/// A server-authored string: titles, button labels and receipt lines.
public struct ServerText: WireModel {
    public var text: String
    public var origin: Origin

    public var isServer: Bool { origin == .server }

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case text, origin
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct CardField: WireModel {
    public var key: String
    public var label: String
    public var value: String
    public var origin: Origin
    public var placement: CardPlacement

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case key, label, value, origin, placement
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct Spend: WireModel {
    public var state: SpendState
    @Nullable public var cents: Int64?

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case state, cents
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// Who resolved a card. Approvals and declines name one; expiry and supersession do not.
public struct CardActor: WireModel {
    public var kind: ActorKind
    public var label: String
    public var principalId: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case kind, label
        case principalId = "principal_id"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct CardResolution: WireModel {
    public var at: String
    @Nullable public var actor: CardActor?
    public var receipt: ServerText

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case at, actor, receipt
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// Rendered by the SERVER from a stored proposal (K-D5). Only server-origin
/// fields may render above Approve; see `presentation` for the rule applied.
public struct ConfirmCardV1: WireModel {
    public var cardId: String
    public var proposalId: String
    public var proposalDigest: String
    public var kind: ProposalKind
    public var state: CardState
    public var title: ServerText
    public var fields: [CardField]
    public var approve: ServerText
    public var decline: ServerText
    public var spend: Spend
    public var requiresFaceId: Bool
    public var createdAt: String
    public var expiresAt: String
    public var cardDigest: String
    @Nullable public var resolution: CardResolution?

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case cardId = "card_id"
        case proposalId = "proposal_id"
        case proposalDigest = "proposal_digest"
        case kind, state, title, fields, approve, decline, spend
        case requiresFaceId = "requires_face_id"
        case createdAt = "created_at"
        case expiresAt = "expires_at"
        case cardDigest = "card_digest"
        case resolution
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// What a renderer may show, with the origin rule already applied. Build it with
/// `ConfirmCardV1.presentation`; never lay a card out from `fields` directly.
public struct CardPresentation: Hashable, Sendable {
    /// The title, only when it is server-origin.
    public let title: String?
    /// Server-origin fields placed above Approve, in wire order. Nothing else renders there.
    public let aboveApprove: [CardField]
    /// Everything else, shown only inside the collapsed, labelled assistant's note.
    public let assistantsNote: [CardField]
    /// Button labels, only when server-origin.
    public let approveLabel: String?
    public let declineLabel: String?
    /// Why this card breaks the contract; empty for a well-formed card.
    public let refusals: [String]
    /// True only for a pending, well-formed card. A refused card never offers Approve.
    public let canApprove: Bool
}

extension ConfirmCardV1 {
    /// Applies the origin rule: a field renders above Approve only when it is BOTH
    /// placed there and server-origin. Anything else is demoted to the note, and a
    /// card that needed demoting (or has a non-server title or button) cannot be approved.
    public var presentation: CardPresentation {
        var above: [CardField] = []
        var note: [CardField] = []
        var refusals: [String] = []
        for field in fields {
            if field.placement == .aboveApprove && field.origin == .server {
                above.append(field)
            } else {
                if field.placement == .aboveApprove {
                    refusals.append("field \(field.key) is placed above Approve but is not server-origin")
                }
                note.append(field)
            }
        }
        if above.isEmpty {
            refusals.append("a card shows at least one server field above Approve")
        }
        if !title.isServer { refusals.append("the title is not server-origin") }
        if !approve.isServer { refusals.append("the approve label is not server-origin") }
        if !decline.isServer { refusals.append("the decline label is not server-origin") }
        if let receipt = resolution?.receipt, !receipt.isServer {
            refusals.append("the receipt is not server-origin")
        }
        return CardPresentation(
            title: title.isServer ? title.text : nil,
            aboveApprove: above,
            assistantsNote: note,
            approveLabel: approve.isServer ? approve.text : nil,
            declineLabel: decline.isServer ? decline.text : nil,
            refusals: refusals,
            canApprove: state == .pending && refusals.isEmpty
        )
    }
}

public enum PresenceMethod: String, LenientEnum {
    case faceId = "face_id"
    case touchId = "touch_id"
    case passkey
    case unknown = "_unknown"
    public static var unknownCase: PresenceMethod { .unknown }
}

public struct PresenceAssertionV1: WireModel {
    public var method: PresenceMethod
    public var assertion: String
    public var assertedAt: String

    public init(method: PresenceMethod, assertion: String, assertedAt: String) {
        self.method = method
        self.assertion = assertion
        self.assertedAt = assertedAt
    }

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case method, assertion
        case assertedAt = "asserted_at"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// POST /cards/{card_id}/approve. The server rechecks: digest mismatch 409, expired 410, reuse 409.
public struct ApproveRequestV1: WireModel {
    public var cardDigest: String
    public var requestId: String
    public var presence: PresenceAssertionV1?

    public init(cardDigest: String, requestId: String, presence: PresenceAssertionV1? = nil) {
        self.cardDigest = cardDigest
        self.requestId = requestId
        self.presence = presence
    }

    /// Binds the approval to the exact card the user saw.
    public init(card: ConfirmCardV1, requestId: String = UUID().uuidString.lowercased(), presence: PresenceAssertionV1? = nil) {
        self.init(cardDigest: card.cardDigest, requestId: requestId, presence: presence)
    }

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case cardDigest = "card_digest"
        case requestId = "request_id"
        case presence
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
    public static var optionalWireKeys: Set<String> { ["presence"] }
}

// MARK: - ProposalV1

public struct ControlPayload: WireModel {
    public var action: ControlAction
    public var targetId: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case action
        case targetId = "target_id"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct BuildPayload: WireModel {
    public var recipeId: String
    public var maxRounds: Int

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case recipeId = "recipe_id"
        case maxRounds = "max_rounds"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct ConfigDraftPayload: WireModel {
    public var configKey: String
    public var baseSnapshotDigest: String
    public var draftDigest: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case configKey = "config_key"
        case baseSnapshotDigest = "base_snapshot_digest"
        case draftDigest = "draft_digest"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct SlotPromotionPayload: WireModel {
    public var slotId: String
    public var artifactId: String
    public var artifactDigest: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case slotId = "slot_id"
        case artifactId = "artifact_id"
        case artifactDigest = "artifact_digest"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct WalkResumePayload: WireModel {
    public var walkId: String
    public var device: String
    public var itemId: String
    public var field: String
    public var text: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case walkId = "walk_id"
        case device
        case itemId = "item_id"
        case field, text
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct WalkSideQuestPayload: WireModel {
    public var walkId: String
    public var device: String
    public var itemId: String
    public var field: String
    public var text: String
    public var childWalkId: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case walkId = "walk_id"
        case device
        case itemId = "item_id"
        case field, text
        case childWalkId = "child_walk_id"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// What the assistant may ask for. It never applies anything (K-D5). The kind
/// selects exactly one payload key; an unknown kind decodes with `.unknown` payload.
public struct ProposalV1: Codable, Hashable, Sendable {
    public var proposalId: String
    public var sessionId: String
    public var turnId: String
    public var createdAt: String
    public var expiresAt: String
    public var proposalDigest: String
    public var kind: ProposalKind
    public var payload: Payload

    public enum Payload: Hashable, Sendable {
        case control(ControlPayload)
        case build(BuildPayload)
        case configDraft(ConfigDraftPayload)
        case slotPromotion(SlotPromotionPayload)
        case walkResume(WalkResumePayload)
        case walkSideQuest(WalkSideQuestPayload)
        case unknown
    }

    enum CodingKeys: String, CodingKey, CaseIterable {
        case proposalId = "proposal_id"
        case sessionId = "session_id"
        case turnId = "turn_id"
        case createdAt = "created_at"
        case expiresAt = "expires_at"
        case proposalDigest = "proposal_digest"
        case kind, control, build
        case walk
        case configDraft = "config_draft"
        case slotPromotion = "slot_promotion"
    }

    /// Keys every proposal carries, before `kind` and its payload key.
    public static let commonWireKeys = [
        "proposal_id", "session_id", "turn_id", "created_at", "expires_at", "proposal_digest",
    ]

    /// Every key a proposal of `kind` carries; all of them are required.
    public static func wireKeys(for kind: ProposalKind) -> [String] {
        let payloadKey: [String]
        switch kind {
        case .unknown: payloadKey = []
        case .walkResume, .walkSideQuest: payloadKey = ["walk"]
        default: payloadKey = [kind.rawValue]
        }
        return commonWireKeys + ["kind"] + payloadKey
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        proposalId = try container.decode(String.self, forKey: .proposalId)
        sessionId = try container.decode(String.self, forKey: .sessionId)
        turnId = try container.decode(String.self, forKey: .turnId)
        createdAt = try container.decode(String.self, forKey: .createdAt)
        expiresAt = try container.decode(String.self, forKey: .expiresAt)
        proposalDigest = try container.decode(String.self, forKey: .proposalDigest)
        kind = try container.decode(ProposalKind.self, forKey: .kind)
        switch kind {
        case .control: payload = .control(try container.decode(ControlPayload.self, forKey: .control))
        case .build: payload = .build(try container.decode(BuildPayload.self, forKey: .build))
        case .configDraft: payload = .configDraft(try container.decode(ConfigDraftPayload.self, forKey: .configDraft))
        case .slotPromotion:
            payload = .slotPromotion(try container.decode(SlotPromotionPayload.self, forKey: .slotPromotion))
        case .walkResume:
            payload = .walkResume(try container.decode(WalkResumePayload.self, forKey: .walk))
        case .walkSideQuest:
            payload = .walkSideQuest(try container.decode(WalkSideQuestPayload.self, forKey: .walk))
        case .unknown: payload = .unknown
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(proposalId, forKey: .proposalId)
        try container.encode(sessionId, forKey: .sessionId)
        try container.encode(turnId, forKey: .turnId)
        try container.encode(createdAt, forKey: .createdAt)
        try container.encode(expiresAt, forKey: .expiresAt)
        try container.encode(proposalDigest, forKey: .proposalDigest)
        try container.encode(kind, forKey: .kind)
        switch payload {
        case .control(let value): try container.encode(value, forKey: .control)
        case .build(let value): try container.encode(value, forKey: .build)
        case .configDraft(let value): try container.encode(value, forKey: .configDraft)
        case .slotPromotion(let value): try container.encode(value, forKey: .slotPromotion)
        case .walkResume(let value): try container.encode(value, forKey: .walk)
        case .walkSideQuest(let value): try container.encode(value, forKey: .walk)
        case .unknown: break
        }
    }
}

// MARK: - Blocks

public struct ToolCallV1: WireModel {
    public var invocationId: String
    public var name: String
    public var label: String
    public var state: ToolState
    /// Present exactly when the tool failed, so a failed read renders as failed.
    public var reason: ReasonV1?

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case invocationId = "invocation_id"
        case name, label, state, reason
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
    public static var optionalWireKeys: Set<String> { ["reason"] }
}

public struct TextBlock: WireModel {
    public var type: String
    public var text: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case type, text
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct ToolsBlock: WireModel {
    public var type: String
    public var tools: [ToolCallV1]

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case type, tools
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// A view row value: a number, a short string, or null (`ViewRow.value`).
public enum ViewValue: Codable, Hashable, Sendable {
    case number(Double)
    case text(String)

    public var number: Double? {
        if case .number(let value) = self { return value }
        return nil
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let number = try? container.decode(Double.self) {
            self = .number(number)
        } else {
            self = .text(try container.decode(String.self))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .number(let value): try container.encode(value)
        case .text(let value): try container.encode(value)
        }
    }
}

public struct ViewRow: WireModel {
    public var invocationId: String
    public var label: String
    @Nullable public var value: ViewValue?
    @Nullable public var unit: ViewUnit?

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case invocationId = "invocation_id"
        case label, value, unit
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// A server view projected from completed tool invocations (K-D4).
public struct ViewBlock: WireModel {
    public var type: String
    public var origin: Origin
    public var viewId: String
    public var kind: ViewKind
    public var title: String
    public var invocationIds: [String]
    public var asOf: String
    public var rows: [ViewRow]

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case type, origin
        case viewId = "view_id"
        case kind, title
        case invocationIds = "invocation_ids"
        case asOf = "as_of"
        case rows
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct CardBlock: WireModel {
    public var type: String
    public var origin: Origin
    public var card: ConfirmCardV1

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case type, origin, card
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct ArtifactBlock: WireModel {
    public var type: String
    public var origin: Origin
    public var artifactId: String
    public var title: String
    public var digest: String
    public var asOf: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case type, origin
        case artifactId = "artifact_id"
        case title, digest
        case asOf = "as_of"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct NoticeBlock: WireModel {
    public var type: String
    public var origin: Origin
    public var reason: ReasonV1

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case type, origin, reason
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// One block of an item. A block type this client does not know decodes to
/// `.unknown(type:)` instead of failing the whole thread.
public enum BlockV1: Codable, Hashable, Sendable {
    case text(TextBlock)
    case tools(ToolsBlock)
    case view(ViewBlock)
    case card(CardBlock)
    case artifact(ArtifactBlock)
    case notice(NoticeBlock)
    case unknown(type: String)

    /// The `type` values K0 defines, in schema order.
    public static let knownTypes = ["text", "tools", "view", "card", "artifact", "notice"]
    /// Blocks only the server may author; each must carry `origin: "server"`.
    public static let serverOnlyTypes: Set<String> = ["view", "card", "artifact", "notice"]

    public init(from decoder: Decoder) throws {
        let type = try WireDiscriminator(from: decoder).type
        switch type {
        case "text": self = .text(try TextBlock(from: decoder))
        case "tools": self = .tools(try ToolsBlock(from: decoder))
        case "view": self = .view(try ViewBlock(from: decoder))
        case "card": self = .card(try CardBlock(from: decoder))
        case "artifact": self = .artifact(try ArtifactBlock(from: decoder))
        case "notice": self = .notice(try NoticeBlock(from: decoder))
        default: self = .unknown(type: type)
        }
    }

    public func encode(to encoder: Encoder) throws {
        switch self {
        case .text(let block): try block.encode(to: encoder)
        case .tools(let block): try block.encode(to: encoder)
        case .view(let block): try block.encode(to: encoder)
        case .card(let block): try block.encode(to: encoder)
        case .artifact(let block): try block.encode(to: encoder)
        case .notice(let block): try block.encode(to: encoder)
        case .unknown(let type): try WireDiscriminator(type: type).encode(to: encoder)
        }
    }

    public var type: String {
        switch self {
        case .text: return "text"
        case .tools: return "tools"
        case .view: return "view"
        case .card: return "card"
        case .artifact: return "artifact"
        case .notice: return "notice"
        case .unknown(let type): return type
        }
    }

    public var isServerOnly: Bool { Self.serverOnlyTypes.contains(type) }

    /// The declared origin of a server-only block; nil for text, tools and unknown blocks.
    public var origin: Origin? {
        switch self {
        case .view(let block): return block.origin
        case .card(let block): return block.origin
        case .artifact(let block): return block.origin
        case .notice(let block): return block.origin
        case .text, .tools, .unknown: return nil
        }
    }

    /// True when a renderer may show this block as authored by the server.
    public var isTrusted: Bool { !isServerOnly || origin == .server }
}

// MARK: - Items and threads

public struct ItemV1: WireModel {
    public var seq: Int
    public var itemId: String
    public var turnId: String
    public var role: ItemRole
    public var at: String
    public var blocks: [BlockV1]

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case seq
        case itemId = "item_id"
        case turnId = "turn_id"
        case role, at, blocks
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }

    /// True when the item holds a card still waiting for the user's decision.
    public var requiresAction: Bool {
        blocks.contains { block in
            if case .card(let card) = block { return card.card.state == .pending }
            return false
        }
    }
}

public struct ScopeV1: WireModel {
    public var kind: ScopeKind
    public var label: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case kind, label
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct ProviderV1: WireModel {
    public var kind: ProviderKind
    public var label: String
    public var model: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case kind, label, model
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct QuotaV1: WireModel {
    public var used: Int
    public var limit: Int
    public var window: QuotaWindow
    public var resetsAt: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case used, limit, window
        case resetsAt = "resets_at"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// The one view of a conversation both platforms render (VI.3).
public struct ThreadV1: WireModel {
    public var sessionId: String
    public var scope: ScopeV1
    public var provider: ProviderV1
    @Nullable public var quota: QuotaV1?
    public var items: [ItemV1]

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case sessionId = "session_id"
        case scope, provider, quota, items
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

// MARK: - Server-to-client events

public struct ItemEventV1: WireModel {
    public var type: String
    public var sessionId: String
    public var seq: Int
    public var at: String
    public var requiresAction: Bool
    public var item: ItemV1

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case type
        case sessionId = "session_id"
        case seq, at
        case requiresAction = "requires_action"
        case item
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct TurnEventV1: WireModel {
    public var type: String
    public var sessionId: String
    public var seq: Int
    public var at: String
    public var requiresAction: Bool
    public var turnId: String
    public var state: TurnState
    /// Present exactly when the turn failed or expired.
    public var reason: ReasonV1?

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case type
        case sessionId = "session_id"
        case seq, at
        case requiresAction = "requires_action"
        case turnId = "turn_id"
        case state, reason
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
    public static var optionalWireKeys: Set<String> { ["reason"] }
}

/// A server event. The type travels in the envelope (K-D7); an event type this
/// client does not know decodes to `.unknown` and keeps its seq so a cursor advances.
public enum ThreadEventV1: Codable, Hashable, Sendable {
    case item(ItemEventV1)
    case turn(TurnEventV1)
    case unknown(type: String, seq: Int?)

    public static let knownTypes = ["item", "turn"]

    public init(from decoder: Decoder) throws {
        let envelope = try WireDiscriminator(from: decoder)
        switch envelope.type {
        case "item": self = .item(try ItemEventV1(from: decoder))
        case "turn": self = .turn(try TurnEventV1(from: decoder))
        default: self = .unknown(type: envelope.type, seq: envelope.seq)
        }
    }

    public func encode(to encoder: Encoder) throws {
        switch self {
        case .item(let event): try event.encode(to: encoder)
        case .turn(let event): try event.encode(to: encoder)
        case .unknown(let type, let seq): try WireDiscriminator(type: type, seq: seq).encode(to: encoder)
        }
    }

    public var seq: Int? {
        switch self {
        case .item(let event): return event.seq
        case .turn(let event): return event.seq
        case .unknown(_, let seq): return seq
        }
    }

    public var sessionId: String? {
        switch self {
        case .item(let event): return event.sessionId
        case .turn(let event): return event.sessionId
        case .unknown: return nil
        }
    }

    /// Whether the client must surface this turn now.
    public var requiresAction: Bool {
        switch self {
        case .item(let event): return event.requiresAction
        case .turn(let event): return event.requiresAction
        case .unknown: return false
        }
    }

    /// K0's rule: an item event requires action exactly when its item holds a
    /// pending card, and a turn event never does.
    public var requiresActionIsConsistent: Bool {
        switch self {
        case .item(let event): return event.requiresAction == event.item.requiresAction
        case .turn(let event): return !event.requiresAction
        case .unknown: return true
        }
    }
}

public struct EventsPageV1: WireModel {
    public var events: [ThreadEventV1]
    public var nextAfter: Int

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case events
        case nextAfter = "next_after"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// POST /sessions/{session_id}/turns.
public struct TurnRequestV1: WireModel {
    /// K0's bound on `text`, counted in UTF-16 code units exactly as the server counts it.
    public static let maxTextLength = 7000

    public var requestId: String
    public var text: String

    public init(requestId: String = UUID().uuidString.lowercased(), text: String) {
        self.requestId = requestId
        self.text = text
    }

    /// True when the server's bounds would accept this text.
    public var isWithinBounds: Bool {
        let count = text.utf16.count
        return count >= 1 && count <= Self.maxTextLength
    }

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case requestId = "request_id"
        case text
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

// MARK: - Worker-to-server events (K-D3)

public struct WorkerStatusEventV1: WireModel {
    public var jobId: String
    public var seq: Int
    public var type: String
    public var status: WorkerStatus

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case jobId = "job_id"
        case seq, type, status
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct WorkerTextEventV1: WireModel {
    public var jobId: String
    public var seq: Int
    public var type: String
    public var text: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case jobId = "job_id"
        case seq, type, text
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct WorkerToolEventV1: WireModel {
    public var jobId: String
    public var seq: Int
    public var type: String
    public var toolCallId: String
    public var name: String
    public var state: ToolState

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case jobId = "job_id"
        case seq, type
        case toolCallId = "tool_call_id"
        case name, state
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct WorkerErrorEventV1: WireModel {
    public var jobId: String
    public var seq: Int
    public var type: String
    public var code: WorkerErrorCode

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case jobId = "job_id"
        case seq, type, code
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct WorkerCardRefEventV1: WireModel {
    public var jobId: String
    public var seq: Int
    public var type: String
    public var cardId: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case jobId = "job_id"
        case seq, type
        case cardId = "card_id"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

public struct WorkerArtifactRefEventV1: WireModel {
    public var jobId: String
    public var seq: Int
    public var type: String
    public var artifactId: String

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case jobId = "job_id"
        case seq, type
        case artifactId = "artifact_id"
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

/// The six event types a worker may send. There is no variant for view, card,
/// artifact or notice; an unknown type decodes to `.unknown` for observability.
public enum WorkerEventV1: Codable, Hashable, Sendable {
    case status(WorkerStatusEventV1)
    case text(WorkerTextEventV1)
    case tool(WorkerToolEventV1)
    case error(WorkerErrorEventV1)
    case cardRef(WorkerCardRefEventV1)
    case artifactRef(WorkerArtifactRefEventV1)
    case unknown(type: String, seq: Int?)

    public static let knownTypes = ["status", "text", "tool", "error", "card_ref", "artifact_ref"]

    public init(from decoder: Decoder) throws {
        let envelope = try WireDiscriminator(from: decoder)
        switch envelope.type {
        case "status": self = .status(try WorkerStatusEventV1(from: decoder))
        case "text": self = .text(try WorkerTextEventV1(from: decoder))
        case "tool": self = .tool(try WorkerToolEventV1(from: decoder))
        case "error": self = .error(try WorkerErrorEventV1(from: decoder))
        case "card_ref": self = .cardRef(try WorkerCardRefEventV1(from: decoder))
        case "artifact_ref": self = .artifactRef(try WorkerArtifactRefEventV1(from: decoder))
        default: self = .unknown(type: envelope.type, seq: envelope.seq)
        }
    }

    public func encode(to encoder: Encoder) throws {
        switch self {
        case .status(let event): try event.encode(to: encoder)
        case .text(let event): try event.encode(to: encoder)
        case .tool(let event): try event.encode(to: encoder)
        case .error(let event): try event.encode(to: encoder)
        case .cardRef(let event): try event.encode(to: encoder)
        case .artifactRef(let event): try event.encode(to: encoder)
        case .unknown(let type, let seq): try WireDiscriminator(type: type, seq: seq).encode(to: encoder)
        }
    }
}

public struct WorkerEventsBatchV1: WireModel {
    public var events: [WorkerEventV1]

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case events
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}

// MARK: - Golden conversations

/// A thread snapshot plus the event stream that built it (K0 fixtures).
public struct GoldenConversationV1: WireModel {
    public var name: String
    public var title: String
    public var thread: ThreadV1
    public var events: [ThreadEventV1]

    public enum CodingKeys: String, CodingKey, CaseIterable {
        case name, title, thread, events
    }

    public static var wireKeys: [String] { CodingKeys.allCases.map(\.rawValue) }
}
