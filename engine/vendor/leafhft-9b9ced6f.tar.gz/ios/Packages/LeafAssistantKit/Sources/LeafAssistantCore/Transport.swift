import Foundation

// Transport is INJECTED: the app supplies the HTTP stack (URLSession with its
// pairing credentials, timeouts and base URL `/assistant/v1`); Core owns the
// routes, the request bodies, the id checks and the mapping of a refusal body
// to the ReasonV1 the UI renders. Nothing here opens a socket.

public enum TransportMethod: String, Hashable, Sendable {
    case get = "GET"
    case post = "POST"
}

public struct TransportQueryItem: Hashable, Sendable {
    public var name: String
    public var value: String

    public init(name: String, value: String) {
        self.name = name
        self.value = value
    }
}

public struct TransportRequest: Hashable, Sendable {
    public var method: TransportMethod
    /// Relative to the contract's server base (`/assistant/v1`), always starting with `/`.
    public var path: String
    public var query: [TransportQueryItem]
    public var body: Data?

    /// Set on every request with a body.
    public var contentType: String? { body == nil ? nil : "application/json" }

    public init(method: TransportMethod, path: String, query: [TransportQueryItem] = [], body: Data? = nil) {
        self.method = method
        self.path = path
        self.query = query
        self.body = body
    }
}

public struct TransportResponse: Hashable, Sendable {
    public var status: Int
    public var body: Data

    public init(status: Int, body: Data) {
        self.status = status
        self.body = body
    }
}

/// What a transport throws when no response arrived. Anything else it throws is
/// passed through untouched.
public enum TransportFailure: Error, Hashable, Sendable {
    case offline
    case timedOut
}

/// The one seam between Core and the network. Implementations bound every call
/// with a timeout and throw `TransportFailure` when no response arrived.
public protocol AssistantTransport: Sendable {
    func send(_ request: TransportRequest) async throws -> TransportResponse
}

public enum AssistantClientError: Error, Equatable {
    /// The server refused with an ErrorV1 body; render `reason` as-is.
    case refused(status: Int, reason: ReasonV1)
    /// A status the contract does not define for this route, without a readable reason.
    case unexpectedStatus(Int)
    /// An id that does not match K0's Id pattern; nothing was sent.
    case invalidIdentifier(String)
    /// A turn whose text is empty or longer than 7,000 UTF-16 units; nothing was sent.
    case textOutOfBounds(Int)
    /// A query value outside the contract's range; nothing was sent.
    case parameterOutOfRange(String)
    case offline
    case timedOut

    /// The reason a renderer shows for this error. Offline and timeout use the
    /// client's own copy, the only reasons the client authors (K0 `clientReason`).
    public var reason: ReasonV1? {
        switch self {
        case .refused(_, let reason): return reason
        case .offline: return ReasonV1.client(.offline)
        case .timedOut: return ReasonV1.client(.timeout)
        case .unexpectedStatus, .invalidIdentifier, .textOutOfBounds, .parameterOutOfRange: return nil
        }
    }
}

/// Typed calls for K0's thread, session events, sendTurn, approve and proposal
/// routes, plus the Kashbot v1 turnEvents extension outside K0.
public struct AssistantClient: Sendable {
    public static let turnEventsMaxAfter = 8001

    public let transport: any AssistantTransport

    public init(transport: any AssistantTransport) {
        self.transport = transport
    }

    /// GET /sessions/{session_id}/thread
    public func thread(sessionId: String) async throws -> ThreadV1 {
        let request = TransportRequest(method: .get, path: try Self.path("sessions", sessionId, "thread"))
        return try await call(request, success: 200)
    }

    /// GET /sessions/{session_id}/events?after=&wait= (long poll, wait at most 15 s).
    public func events(sessionId: String, after: Int? = nil, waitSeconds: Int? = nil) async throws -> EventsPageV1 {
        var query: [TransportQueryItem] = []
        if let after {
            guard after >= 0 && after <= Int(Int32.max) else { throw AssistantClientError.parameterOutOfRange("after") }
            query.append(TransportQueryItem(name: "after", value: String(after)))
        }
        if let waitSeconds {
            guard waitSeconds >= 0 && waitSeconds <= 15 else { throw AssistantClientError.parameterOutOfRange("wait") }
            query.append(TransportQueryItem(name: "wait", value: String(waitSeconds)))
        }
        let request = TransportRequest(method: .get, path: try Self.path("sessions", sessionId, "events"), query: query)
        return try await call(request, success: 200)
    }

    /// Kashbot v1 extension outside K0: GET /turns/{turn_id}/events?after=&wait=.
    /// Resume with the returned page's nextAfter, never the last event's seq.
    public func turnEvents(turnId: String, after: Int? = nil, waitSeconds: Int? = nil) async throws -> EventsPageV1 {
        var query: [TransportQueryItem] = []
        if let after {
            guard (0...Self.turnEventsMaxAfter).contains(after) else { throw AssistantClientError.parameterOutOfRange("after") }
            query.append(TransportQueryItem(name: "after", value: String(after)))
        }
        if let waitSeconds {
            guard (0...15).contains(waitSeconds) else { throw AssistantClientError.parameterOutOfRange("wait") }
            query.append(TransportQueryItem(name: "wait", value: String(waitSeconds)))
        }
        let request = TransportRequest(method: .get, path: try Self.path("turns", turnId, "events"), query: query)
        return try await call(request, success: 200)
    }

    /// POST /sessions/{session_id}/turns. Answers 202 with the queued turn event.
    public func sendTurn(sessionId: String, _ turn: TurnRequestV1) async throws -> ThreadEventV1 {
        guard Identifier.isValid(turn.requestId) else { throw AssistantClientError.invalidIdentifier(turn.requestId) }
        guard turn.isWithinBounds else { throw AssistantClientError.textOutOfBounds(turn.text.utf16.count) }
        let request = TransportRequest(
            method: .post,
            path: try Self.path("sessions", sessionId, "turns"),
            body: try AssistantDecoding.encode(turn)
        )
        return try await call(request, success: 202)
    }

    /// POST /cards/{card_id}/approve, bound to the digest of the card the user saw.
    public func approve(cardId: String, _ approval: ApproveRequestV1) async throws -> ConfirmCardV1 {
        guard Identifier.isValid(approval.requestId) else {
            throw AssistantClientError.invalidIdentifier(approval.requestId)
        }
        let request = TransportRequest(
            method: .post,
            path: try Self.path("cards", cardId, "approve"),
            body: try AssistantDecoding.encode(approval)
        )
        return try await call(request, success: 200)
    }

    /// GET /proposals/{proposal_id}
    public func proposal(id: String) async throws -> ProposalV1 {
        let request = TransportRequest(method: .get, path: try Self.path("proposals", id))
        return try await call(request, success: 200)
    }

    /// Builds `/collection/{id}[/leaf]`, refusing an id that could rewrite the route.
    static func path(_ collection: String, _ id: String, _ leaf: String? = nil) throws -> String {
        guard Identifier.isValid(id) else { throw AssistantClientError.invalidIdentifier(id) }
        if let leaf { return "/\(collection)/\(id)/\(leaf)" }
        return "/\(collection)/\(id)"
    }

    private func call<T: Decodable>(_ request: TransportRequest, success: Int) async throws -> T {
        let response: TransportResponse
        do {
            response = try await transport.send(request)
        } catch TransportFailure.offline {
            throw AssistantClientError.offline
        } catch TransportFailure.timedOut {
            throw AssistantClientError.timedOut
        }
        if response.status == success {
            return try AssistantDecoding.decode(T.self, from: response.body)
        }
        if let refusal = try? AssistantDecoding.decode(ErrorV1.self, from: response.body) {
            throw AssistantClientError.refused(status: response.status, reason: refusal.reason)
        }
        throw AssistantClientError.unexpectedStatus(response.status)
    }
}
