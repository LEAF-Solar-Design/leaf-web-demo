import Foundation
#if canImport(CryptoKit)
import CryptoKit
#endif

// Digests are INJECTED. Apple platforms get CryptoKitDigest; a Linux build
// compiles without it and supplies its own DigestProvider (swift-crypto, a
// server-side hasher), so Core never hard-links a crypto library.

public protocol DigestProvider: Sendable {
    /// Lowercase hex SHA-256 of `data`.
    func sha256Hex(_ data: Data) -> String
}

public enum Hex {
    private static let alphabet: [UInt8] = Array("0123456789abcdef".utf8)

    /// Lowercase hex, one allocation sized up front.
    public static func encode<Bytes: Sequence>(_ bytes: Bytes) -> String where Bytes.Element == UInt8 {
        var out: [UInt8] = []
        out.reserveCapacity(bytes.underestimatedCount * 2)
        for byte in bytes {
            out.append(alphabet[Int(byte >> 4)])
            out.append(alphabet[Int(byte & 0x0F)])
        }
        return String(decoding: out, as: UTF8.self)
    }
}

#if canImport(CryptoKit)
public struct CryptoKitDigest: DigestProvider {
    public init() {}

    public func sha256Hex(_ data: Data) -> String {
        Hex.encode(SHA256.hash(data: data))
    }
}
#endif

public enum FixturePinError: Error, Equatable {
    case malformedLine(Int)
    case duplicateName(String)
}

/// K0's FIXTURES.sha256: `sha256sum -c` compatible, one `<hex>  <name>` line per
/// file sorted by name, hashing LF-normalized bytes so a CRLF checkout on
/// Windows recomputes the same pin.
public enum FixturePins {
    /// Replaces every CRLF with LF (and nothing else), in one pass.
    public static func lfNormalized(_ data: Data) -> Data {
        var out = Data()
        out.reserveCapacity(data.count)
        var pendingCR = false
        for byte in data {
            if pendingCR {
                if byte != 0x0A { out.append(0x0D) }
                pendingCR = false
            }
            if byte == 0x0D {
                pendingCR = true
            } else {
                out.append(byte)
            }
        }
        if pendingCR { out.append(0x0D) }
        return out
    }

    /// Renders the pin file exactly as K0 writes it.
    public static func render(_ files: [(name: String, contents: Data)], digest: any DigestProvider) -> String {
        files
            .sorted { $0.name < $1.name }
            .map { "\(digest.sha256Hex(lfNormalized($0.contents)))  \($0.name)\n" }
            .joined()
    }

    /// Parses a pin file into name -> hex. Fails closed on any line that is not
    /// 64 lowercase hex digits, two spaces and a name.
    public static func parse(_ text: String) throws -> [String: String] {
        var pins: [String: String] = [:]
        let lines = text.replacingOccurrences(of: "\r\n", with: "\n").split(separator: "\n", omittingEmptySubsequences: true)
        for (index, line) in lines.enumerated() {
            let bytes = Array(line.utf8)
            guard bytes.count > 66, bytes[64] == 0x20, bytes[65] == 0x20,
                  bytes[0..<64].allSatisfy({ ($0 >= 0x30 && $0 <= 0x39) || ($0 >= 0x61 && $0 <= 0x66) })
            else { throw FixturePinError.malformedLine(index + 1) }
            let hex = String(decoding: bytes[0..<64], as: UTF8.self)
            let name = String(decoding: bytes[66...], as: UTF8.self)
            if pins.updateValue(hex, forKey: name) != nil { throw FixturePinError.duplicateName(name) }
        }
        return pins
    }
}
