import Foundation

// Decoding, folding and the contract checks a client runs on what it decoded.
// Decoding tolerates unknown enum values and unknown block and event types;
// ContractCheck then names every rule K0's decoder would have refused, so a
// renderer or a test can fail closed without the decoder throwing mid-thread.

public enum AssistantDecodingError: Error, Equatable {
    /// The payload is larger than any response the contract can produce.
    case payloadTooLarge(bytes: Int, limit: Int)
}

public enum AssistantDecoding {
    /// Upper bound on one response body: 500 items of 32 blocks each fit well
    /// inside it. Anything larger is refused before the JSON parser sees it.
    public static let maxPayloadBytes = 8 * 1024 * 1024

    /// Decodes one contract payload. Fails closed on an oversized body or malformed JSON.
    public static func decode<T: Decodable>(_ type: T.Type, from data: Data) throws -> T {
        guard data.count <= maxPayloadBytes else {
            throw AssistantDecodingError.payloadTooLarge(bytes: data.count, limit: maxPayloadBytes)
        }
        return try JSONDecoder().decode(T.self, from: data)
    }

    public static func encode<T: Encodable>(_ value: T) throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return try encoder.encode(value)
    }
}

/// K0's Id scalar: `^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$`. Checked before an id
/// is placed in a request path, so a malformed id can never rewrite the route.
public enum Identifier {
    public static func isValid(_ value: String) -> Bool {
        var count = 0
        for byte in value.utf8 {
            count += 1
            if count > 128 { return false }
            let isAlnum = (byte >= 0x30 && byte <= 0x39) || (byte >= 0x41 && byte <= 0x5A) || (byte >= 0x61 && byte <= 0x7A)
            if count == 1 {
                if !isAlnum { return false }
            } else if !(isAlnum || byte == 0x2E || byte == 0x5F || byte == 0x3A || byte == 0x2D) {
                return false
            }
        }
        return count >= 1
    }
}

/// K0's IsoUtc scalar: `YYYY-MM-DDTHH:MM:SS(.sss)?Z`. Parsed by hand in one pass,
/// with no formatter allocation, so a renderer can call it per frame.
public enum LeafTimestamp {
    /// The instant `value` names, or nil when it does not match the contract's pattern.
    public static func date(_ value: String) -> Date? {
        guard let seconds = secondsSince1970(value) else { return nil }
        return Date(timeIntervalSince1970: seconds)
    }

    public static func secondsSince1970(_ value: String) -> Double? {
        let bytes = Array(value.utf8)
        guard bytes.count == 20 || bytes.count == 24 else { return nil }
        func digits(_ start: Int, _ length: Int) -> Int? {
            var number = 0
            for index in start..<(start + length) {
                let digit = Int(bytes[index]) - 48
                guard digit >= 0 && digit <= 9 else { return nil }
                number = number * 10 + digit
            }
            return number
        }
        guard bytes[4] == 0x2D, bytes[7] == 0x2D, bytes[10] == 0x54, bytes[13] == 0x3A, bytes[16] == 0x3A,
              bytes[bytes.count - 1] == 0x5A
        else { return nil }
        guard let year = digits(0, 4), let month = digits(5, 2), let day = digits(8, 2),
              let hour = digits(11, 2), let minute = digits(14, 2), let second = digits(17, 2)
        else { return nil }
        var millis = 0
        if bytes.count == 24 {
            guard bytes[19] == 0x2E, let fraction = digits(20, 3) else { return nil }
            millis = fraction
        }
        guard (1...12).contains(month), (1...31).contains(day), hour < 24, minute < 60, second < 60 else { return nil }
        // Days from the civil date (H. Hinnant's algorithm), exact for the proleptic Gregorian calendar.
        let shiftedYear = month <= 2 ? year - 1 : year
        let era = (shiftedYear >= 0 ? shiftedYear : shiftedYear - 399) / 400
        let yearOfEra = shiftedYear - era * 400
        let dayOfYear = (153 * ((month + 9) % 12) + 2) / 5 + day - 1
        let dayOfEra = yearOfEra * 365 + yearOfEra / 4 - yearOfEra / 100 + dayOfYear
        let days = era * 146097 + dayOfEra - 719468
        let whole = days * 86400 + hour * 3600 + minute * 60 + second
        return Double(whole) + Double(millis) / 1000
    }
}

/// Folds server events into thread items the way K0 does: the latest version of
/// each item wins, and items stay in seq order.
public enum ThreadFold {
    /// Applies one event in place. An update replaces the item where it sits; a new
    /// item is inserted by seq (normally an append, found by a backwards scan).
    /// Bounded: a thread holds at most 500 items (K0), so the id scan is O(500).
    public static func apply(_ event: ThreadEventV1, to items: inout [ItemV1]) {
        guard case .item(let itemEvent) = event else { return }
        let item = itemEvent.item
        if let index = items.firstIndex(where: { $0.itemId == item.itemId }) {
            items[index] = item
            return
        }
        let insertAt = items.lastIndex(where: { $0.seq < item.seq }).map { $0 + 1 } ?? 0
        items.insert(item, at: insertAt)
    }

    /// Folds a whole event stream: O(n log n), one dictionary entry per item.
    public static func fold(_ events: [ThreadEventV1]) -> [ItemV1] {
        var latest: [String: ItemV1] = [:]
        var order: [String] = []
        for event in events {
            guard case .item(let itemEvent) = event else { continue }
            if latest.updateValue(itemEvent.item, forKey: itemEvent.item.itemId) == nil {
                order.append(itemEvent.item.itemId)
            }
        }
        return order.compactMap { latest[$0] }.sorted { $0.seq < $1.seq }
    }
}

/// The rules K0's decoder enforces, restated over the decoded Swift models. An
/// empty result means the payload is one K0 would accept; each string names a path
/// and the rule it breaks. Unknown enum values and unknown types are reported too.
public enum ContractCheck {
    public static func violations(in thread: ThreadV1) -> [String] {
        var out: [String] = []
        if thread.scope.kind == .unknown { out.append("scope.kind: unknown value") }
        if thread.provider.kind == .unknown { out.append("provider.kind: unknown value") }
        if let quota = thread.quota {
            if quota.used > quota.limit { out.append("quota.used: quota used cannot exceed its limit") }
            if quota.window == .unknown { out.append("quota.window: unknown value") }
        }
        var previousSeq = -1
        var itemIds = Set<String>()
        var invocations: [String: ToolState] = [:]
        for (i, item) in thread.items.enumerated() {
            let at = "items[\(i)]"
            if item.seq <= previousSeq { out.append("\(at).seq: items are in strictly increasing seq order") }
            previousSeq = item.seq
            if !itemIds.insert(item.itemId).inserted { out.append("\(at).item_id: duplicate item \(item.itemId)") }
            if item.role == .unknown { out.append("\(at).role: unknown value") }
            for (b, block) in item.blocks.enumerated() {
                let path = "\(at).blocks[\(b)]"
                if item.role == .user && block.type != "text" {
                    out.append("\(path): a user item carries text only")
                }
                if item.role == .server && !block.isServerOnly {
                    out.append("\(path): a server item carries server blocks only")
                }
                if block.isServerOnly && block.origin != .server {
                    out.append("\(path).origin: a \(block.type) block must be server-origin")
                }
                switch block {
                case .tools(let tools):
                    for (t, tool) in tools.tools.enumerated() {
                        let toolPath = "\(path).tools[\(t)]"
                        if invocations[tool.invocationId] != nil {
                            out.append("\(toolPath).invocation_id: duplicate invocation \(tool.invocationId)")
                        }
                        invocations[tool.invocationId] = tool.state
                        if tool.state == .unknown { out.append("\(toolPath).state: unknown value") }
                        if (tool.state == .failed) != (tool.reason != nil) {
                            out.append("\(toolPath).reason: a tool carries a reason exactly when it failed")
                        }
                        if let reason = tool.reason {
                            out += violations(in: reason, at: "\(toolPath).reason")
                        }
                    }
                case .view(let view):
                    if view.kind == .unknown { out.append("\(path).kind: unknown value") }
                    let declared = Set(view.invocationIds)
                    for (k, id) in view.invocationIds.enumerated() where invocations[id] != .done {
                        out.append("\(path).invocation_ids[\(k)]: \(id) is not a completed tool invocation recorded before it")
                    }
                    for (r, row) in view.rows.enumerated() where !declared.contains(row.invocationId) {
                        out.append("\(path).rows[\(r)].invocation_id: \(row.invocationId) is not declared by this view")
                    }
                case .card(let card):
                    out += violations(in: card.card, at: "\(path).card")
                case .notice(let notice):
                    out += violations(in: notice.reason, at: "\(path).reason")
                case .unknown(let type):
                    out.append("\(path).type: unknown block type \(type)")
                case .text, .artifact:
                    break
                }
            }
        }
        return out
    }

    /// A reason the server sent: its code is known and server-owned, and its exit
    /// and retry_at follow the reason table.
    public static func violations(in reason: ReasonV1, at path: String) -> [String] {
        guard let rule = reason.code.rule else { return ["\(path).code: unknown reason code"] }
        var out: [String] = []
        if rule.owner != .server {
            out.append("\(path).code: \(reason.code.rawValue) is client-owned; the server may not send it")
        }
        if reason.next.action != rule.action {
            out.append("\(path).next.action: reason \(reason.code.rawValue) must offer action \(rule.action.rawValue)")
        }
        switch rule.retryAt {
        case .mustBePresent where reason.retryAt == nil:
            out.append("\(path).retry_at: reason \(reason.code.rawValue) requires retry_at")
        case .mustBeAbsent where reason.retryAt != nil:
            out.append("\(path).retry_at: reason \(reason.code.rawValue) carries no retry_at")
        default:
            break
        }
        if let retryAt = reason.retryAt, LeafTimestamp.date(retryAt) == nil {
            out.append("\(path).retry_at: not a UTC timestamp")
        }
        return out
    }

    public static func violations(in card: ConfirmCardV1, at path: String) -> [String] {
        var out = card.presentation.refusals.map { "\(path): \($0)" }
        if card.kind == .unknown { out.append("\(path).kind: unknown value") }
        if card.state == .unknown { out.append("\(path).state: unknown value") }
        var keys = Set<String>()
        for (index, field) in card.fields.enumerated() {
            if !keys.insert(field.key).inserted { out.append("\(path).fields[\(index)].key: duplicate card field \(field.key)") }
            if field.origin == .unknown { out.append("\(path).fields[\(index)].origin: unknown value") }
            if field.placement == .unknown { out.append("\(path).fields[\(index)].placement: unknown value") }
        }
        if let created = LeafTimestamp.secondsSince1970(card.createdAt),
           let expires = LeafTimestamp.secondsSince1970(card.expiresAt) {
            if !(expires > created) { out.append("\(path).expires_at: a card must expire after it is created") }
        } else {
            out.append("\(path): created_at and expires_at must be UTC timestamps")
        }
        if (card.spend.state == .reported) != (card.spend.cents != nil) {
            out.append("\(path).spend.cents: cents is present exactly when spend is reported")
        }
        if card.state == .pending {
            if card.resolution != nil { out.append("\(path).resolution: a pending card has no resolution") }
            return out
        }
        guard let resolution = card.resolution else {
            out.append("\(path).resolution: a \(card.state.rawValue) card carries its resolution")
            return out
        }
        let needsActor = card.state == .approved || card.state == .declined
        if needsActor != (resolution.actor != nil) {
            let rule = needsActor ? "names its actor" : "has no actor"
            out.append("\(path).resolution.actor: a \(card.state.rawValue) card \(rule)")
        }
        return out
    }

    /// Everything above, plus the golden rules: events in seq order within one
    /// session, requires_action consistent, first-delivery seq kept, and folding
    /// the item events reproduces thread.items exactly.
    public static func violations(in golden: GoldenConversationV1) -> [String] {
        var out = violations(in: golden.thread)
        var previousSeq = -1
        var firstSeq: [String: Int] = [:]
        for (index, event) in golden.events.enumerated() {
            let path = "events[\(index)]"
            guard let seq = event.seq else {
                out.append("\(path): unknown event without a seq")
                continue
            }
            if seq <= previousSeq { out.append("\(path).seq: events are in strictly increasing seq order") }
            previousSeq = seq
            if let sessionId = event.sessionId, sessionId != golden.thread.sessionId {
                out.append("\(path).session_id: event belongs to another session")
            }
            if !event.requiresActionIsConsistent {
                out.append("\(path).requires_action: true exactly when the item holds a pending card")
            }
            switch event {
            case .item(let itemEvent):
                let id = itemEvent.item.itemId
                if let first = firstSeq[id] {
                    if itemEvent.item.seq != first { out.append("\(path).item.seq: an updated item keeps its seq") }
                } else {
                    firstSeq[id] = itemEvent.seq
                    if itemEvent.item.seq != itemEvent.seq {
                        out.append("\(path).item.seq: an item's seq is the seq of the event that first delivered it")
                    }
                }
            case .turn(let turnEvent):
                if turnEvent.state == .unknown { out.append("\(path).state: unknown value") }
                let needsReason = turnEvent.state == .failed || turnEvent.state == .expired
                if needsReason != (turnEvent.reason != nil) {
                    out.append("\(path).reason: a \(turnEvent.state.rawValue) turn \(needsReason ? "carries its reason" : "carries no reason")")
                }
                if let reason = turnEvent.reason {
                    out += violations(in: reason, at: "\(path).reason")
                }
            case .unknown(let type, _):
                out.append("\(path).type: unknown event type \(type)")
            }
        }
        if ThreadFold.fold(golden.events) != golden.thread.items {
            out.append("events: folding the item events must reproduce thread.items")
        }
        return out
    }
}
