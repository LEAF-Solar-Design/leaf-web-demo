#if canImport(SwiftUI)
import LeafAssistantCore
import SwiftUI

// The VI.3 component set over the Core models. Every string a view shows comes
// from the decoded payload with `Text(verbatim:)` (never interpreted as markdown
// or a localization key) or is fixed client copy. Every tappable control is at
// least `theme.minimumTarget` (44 pt) on both axes, and every layout reflows up
// to accessibility5 (AX XXXL) instead of truncating.

/// Theme tokens the host injects. The LeafTheme mapping is KM3's; these defaults
/// are neutral system colors so the kit renders before a theme exists.
public struct LeafAssistantTheme {
    public var accent: Color
    public var surface: Color
    public var userBubble: Color
    public var assistantBubble: Color
    public var textPrimary: Color
    public var textSecondary: Color
    public var danger: Color
    public var warning: Color
    public var success: Color
    public var border: Color
    public var cornerRadius: CGFloat
    /// Never below 44 pt, whatever the host passes.
    public var minimumTarget: CGFloat

    public init(
        accent: Color = .accentColor,
        surface: Color = Color.gray.opacity(0.08),
        userBubble: Color = Color.accentColor.opacity(0.15),
        assistantBubble: Color = Color.gray.opacity(0.12),
        textPrimary: Color = .primary,
        textSecondary: Color = .secondary,
        danger: Color = .red,
        warning: Color = .orange,
        success: Color = .green,
        border: Color = Color.gray.opacity(0.3),
        cornerRadius: CGFloat = 12,
        minimumTarget: CGFloat = 44
    ) {
        self.accent = accent
        self.surface = surface
        self.userBubble = userBubble
        self.assistantBubble = assistantBubble
        self.textPrimary = textPrimary
        self.textSecondary = textSecondary
        self.danger = danger
        self.warning = warning
        self.success = success
        self.border = border
        self.cornerRadius = cornerRadius
        self.minimumTarget = max(44, minimumTarget)
    }
}

private struct LeafAssistantThemeKey: EnvironmentKey {
    static var defaultValue: LeafAssistantTheme { LeafAssistantTheme() }
}

extension EnvironmentValues {
    public var leafAssistantTheme: LeafAssistantTheme {
        get { self[LeafAssistantThemeKey.self] }
        set { self[LeafAssistantThemeKey.self] = newValue }
    }
}

extension View {
    /// Injects the host's theme tokens into every kit view below this one.
    public func leafAssistantTheme(_ theme: LeafAssistantTheme) -> some View {
        environment(\.leafAssistantTheme, theme)
    }
}

/// What the host does when the user acts. The kit never talks to the network
/// itself: approve hands back the exact card shown, and the host performs Face ID
/// (when `requires_face_id`) and calls `AssistantClient.approve` with its digest.
public struct AssistantActions {
    public var approve: (ConfirmCardV1) -> Void
    public var decline: (ConfirmCardV1) -> Void
    public var reason: (ReasonV1) -> Void

    public init(
        approve: @escaping (ConfirmCardV1) -> Void = { _ in },
        decline: @escaping (ConfirmCardV1) -> Void = { _ in },
        reason: @escaping (ReasonV1) -> Void = { _ in }
    ) {
        self.approve = approve
        self.decline = decline
        self.reason = reason
    }
}

/// The conversation: items in seq order, each rendered as a TurnBubble. Named
/// AssistantStream rather than Stream so it never shadows Foundation.Stream.
public struct AssistantStream: View {
    private let thread: ThreadV1
    private let actions: AssistantActions

    public init(thread: ThreadV1, actions: AssistantActions = AssistantActions()) {
        self.thread = thread
        self.actions = actions
    }

    public var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 12) {
                ForEach(thread.items, id: \.itemId) { item in
                    TurnBubble(item: item, actions: actions)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
        }
        .dynamicTypeSize(...DynamicTypeSize.accessibility5)
    }
}

/// One item. User text sits trailing in its own bubble; assistant and server
/// items take the full width so views and cards have room at AX sizes.
public struct TurnBubble: View {
    private let item: ItemV1
    private let actions: AssistantActions
    @Environment(\.leafAssistantTheme) private var theme

    public init(item: ItemV1, actions: AssistantActions = AssistantActions()) {
        self.item = item
        self.actions = actions
    }

    public var body: some View {
        if item.role == .user {
            HStack(spacing: 0) {
                Spacer(minLength: 40)
                content
                    .padding(12)
                    .background(theme.userBubble, in: RoundedRectangle(cornerRadius: theme.cornerRadius))
            }
        } else {
            content
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(theme.assistantBubble, in: RoundedRectangle(cornerRadius: theme.cornerRadius))
        }
    }

    private var content: some View {
        VStack(alignment: .leading, spacing: 10) {
            ForEach(Array(item.blocks.enumerated()), id: \.offset) { entry in
                BlockView(block: entry.element, role: item.role, actions: actions)
            }
        }
        .foregroundStyle(theme.textPrimary)
        .accessibilityElement(children: .contain)
    }
}

/// Dispatches one block to its component. A server-only block that is not
/// server-origin never renders as trusted content.
struct BlockView: View {
    let block: BlockV1
    let role: ItemRole
    let actions: AssistantActions

    var body: some View {
        if !block.isTrusted {
            UntrustedBlockNote()
        } else {
            switch block {
            case .text(let text):
                if role == .assistant {
                    Text(verbatim: text.text)
                        .fixedSize(horizontal: false, vertical: true)
                        .textSelection(.enabled)
                        .accessibilityIdentifier("assistant.reply.text")
                } else {
                    Text(verbatim: text.text)
                        .fixedSize(horizontal: false, vertical: true)
                        .textSelection(.enabled)
                }
            case .tools(let tools):
                VStack(alignment: .leading, spacing: 6) {
                    ForEach(tools.tools, id: \.invocationId) { tool in
                        ToolCard(tool: tool, actions: actions)
                    }
                }
            case .view(let view):
                ViewPanel(view: view)
            case .card(let card):
                ConfirmCard(card: card.card, actions: actions)
            case .artifact(let artifact):
                ArtifactRow(artifact: artifact)
            case .notice(let notice):
                NoticeView(reason: notice.reason, actions: actions)
            case .unknown:
                UpdateRequiredCard(actions: actions)
            }
        }
    }
}

/// Shown in place of a server-only block that did not come from the server.
struct UntrustedBlockNote: View {
    @Environment(\.leafAssistantTheme) private var theme

    var body: some View {
        Label {
            Text("This part of the answer couldn't be verified, so it is hidden.")
                .fixedSize(horizontal: false, vertical: true)
        } icon: {
            Image(systemName: "exclamationmark.shield")
        }
        .font(.footnote)
        .foregroundStyle(theme.textSecondary)
    }
}
#endif
