#if canImport(SwiftUI)
import LeafAssistantCore
import SwiftUI

/// A server view: metric tiles, a table, or a line with its table. Every value
/// shown comes from the view's rows; a null value reads "Not reported", never 0.
public struct ViewPanel: View {
    private let view: ViewBlock
    @Environment(\.leafAssistantTheme) private var theme

    public init(view: ViewBlock) {
        self.view = view
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .firstTextBaseline) {
                    title
                    Spacer(minLength: 8)
                    asOf
                }
                VStack(alignment: .leading, spacing: 2) {
                    title
                    asOf
                }
            }
            switch view.kind {
            case .metric:
                MetricGrid(rows: view.rows)
            case .line:
                Sparkline(values: view.rows.compactMap { $0.value?.number })
                RowTable(rows: view.rows)
            case .table, .unknown:
                RowTable(rows: view.rows)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(theme.surface, in: RoundedRectangle(cornerRadius: theme.cornerRadius))
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("assistant.panel." + view.kind.rawValue)
    }

    private var title: some View {
        Text(verbatim: view.title)
            .font(.headline)
            .fixedSize(horizontal: false, vertical: true)
            .accessibilityAddTraits(.isHeader)
    }

    @ViewBuilder
    private var asOf: some View {
        if let date = LeafTimestamp.date(view.asOf) {
            (Text("As of ") + Text(date, style: .time))
                .font(.caption)
                .foregroundStyle(theme.textSecondary)
        }
    }
}

/// Formats a view value for display. Pure, so it is cheap to call per row.
enum ViewValueText {
    static func string(_ value: ViewValue?, unit: ViewUnit?) -> String {
        guard let value else { return "Not reported" }
        switch value {
        case .text(let text):
            return text
        case .number(let number):
            switch unit ?? .unknown {
            case .cents:
                return (number / 100).formatted(.currency(code: "USD"))
            case .pct:
                return number.formatted(.number.precision(.fractionLength(0...2))) + "%"
            case .count:
                return number.formatted(.number.precision(.fractionLength(0)))
            case .text, .unknown:
                return number.formatted()
            }
        }
    }
}

struct MetricGrid: View {
    let rows: [ViewRow]
    @Environment(\.leafAssistantTheme) private var theme

    var body: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), spacing: 8, alignment: .topLeading)], alignment: .leading, spacing: 8) {
            ForEach(Array(rows.enumerated()), id: \.offset) { entry in
                VStack(alignment: .leading, spacing: 2) {
                    Text(verbatim: entry.element.label)
                        .font(.caption)
                        .foregroundStyle(theme.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(verbatim: ViewValueText.string(entry.element.value, unit: entry.element.unit))
                        .font(.title3.weight(.semibold))
                        .foregroundStyle(entry.element.value == nil ? theme.textSecondary : theme.textPrimary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .accessibilityElement(children: .combine)
            }
        }
    }
}

struct RowTable: View {
    let rows: [ViewRow]
    @Environment(\.leafAssistantTheme) private var theme

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(Array(rows.enumerated()), id: \.offset) { entry in
                ViewThatFits(in: .horizontal) {
                    HStack(alignment: .firstTextBaseline, spacing: 12) {
                        Text(verbatim: entry.element.label)
                            .foregroundStyle(theme.textSecondary)
                        Spacer(minLength: 8)
                        Text(verbatim: ViewValueText.string(entry.element.value, unit: entry.element.unit))
                            .monospacedDigit()
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(verbatim: entry.element.label)
                            .foregroundStyle(theme.textSecondary)
                        Text(verbatim: ViewValueText.string(entry.element.value, unit: entry.element.unit))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .font(.subheadline)
                .accessibilityElement(children: .combine)
            }
        }
    }
}

/// A decorative line over the numeric values; the table beside it carries the data.
struct Sparkline: View {
    let values: [Double]
    @Environment(\.leafAssistantTheme) private var theme

    var body: some View {
        if values.count > 1 {
            GeometryReader { geometry in
                Path { path in
                    let low = values.min() ?? 0
                    let high = values.max() ?? 0
                    let span = high - low == 0 ? 1 : high - low
                    let step = geometry.size.width / CGFloat(values.count - 1)
                    for (index, value) in values.enumerated() {
                        let point = CGPoint(
                            x: step * CGFloat(index),
                            y: geometry.size.height * (1 - CGFloat((value - low) / span))
                        )
                        if index == 0 {
                            path.move(to: point)
                        } else {
                            path.addLine(to: point)
                        }
                    }
                }
                .stroke(theme.accent, lineWidth: 2)
            }
            .frame(height: 60)
            .accessibilityHidden(true)
        }
    }
}

/// A server artifact: its title and the head of its digest.
struct ArtifactRow: View {
    let artifact: ArtifactBlock
    @Environment(\.leafAssistantTheme) private var theme

    var body: some View {
        Label {
            VStack(alignment: .leading, spacing: 2) {
                Text(verbatim: artifact.title)
                    .fixedSize(horizontal: false, vertical: true)
                Text(verbatim: String(artifact.digest.prefix(12)))
                    .font(.caption.monospaced())
                    .foregroundStyle(theme.textSecondary)
            }
        } icon: {
            Image(systemName: "doc")
        }
        .font(.subheadline)
        .accessibilityElement(children: .combine)
    }
}
#endif
