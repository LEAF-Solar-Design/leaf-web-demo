#if canImport(SwiftUI)
import LeafAssistantCore
import SwiftUI

/// One tool invocation. A failed tool renders as failed with its reason, never as
/// an empty success.
public struct ToolCard: View {
    private let tool: ToolCallV1
    private let actions: AssistantActions
    @Environment(\.leafAssistantTheme) private var theme

    public init(tool: ToolCallV1, actions: AssistantActions = AssistantActions()) {
        self.tool = tool
        self.actions = actions
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Label {
                Text(verbatim: tool.label)
                    .fixedSize(horizontal: false, vertical: true)
            } icon: {
                stateIcon
            }
            .font(.subheadline)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(Text(verbatim: "\(tool.label), \(stateText)"))
            if tool.state == .failed {
                if let reason = tool.reason {
                    ReasonBanner(reason: reason, onAction: actions.reason)
                } else {
                    Text("This step failed.")
                        .font(.footnote)
                        .foregroundStyle(theme.danger)
                }
            }
        }
    }

    @ViewBuilder
    private var stateIcon: some View {
        switch tool.state {
        case .running:
            ProgressView()
                .controlSize(.small)
        case .done:
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(theme.success)
        case .failed:
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(theme.danger)
        case .unknown:
            Image(systemName: "questionmark.circle")
                .foregroundStyle(theme.textSecondary)
        }
    }

    private var stateText: String {
        switch tool.state {
        case .running: return "running"
        case .done: return "done"
        case .failed: return "failed"
        case .unknown: return "status unknown"
        }
    }
}

/// The consent card. Only server-origin fields render above Approve (the origin
/// rule, applied by `ConfirmCardV1.presentation`); model prose appears only in the
/// collapsed, labelled assistant's note below the buttons. A card that breaks the
/// rule shows why and never offers Approve.
public struct ConfirmCard: View {
    private let card: ConfirmCardV1
    private let actions: AssistantActions
    @State private var noteExpanded = false
    @Environment(\.leafAssistantTheme) private var theme
    @Environment(\.dynamicTypeSize) private var typeSize

    public init(card: ConfirmCardV1, actions: AssistantActions = AssistantActions()) {
        self.card = card
        self.actions = actions
    }

    public var body: some View {
        let presentation = card.presentation
        VStack(alignment: .leading, spacing: 12) {
            Text(verbatim: presentation.title ?? "Request")
                .font(.headline)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
            ForEach(presentation.aboveApprove, id: \.key) { field in
                CardFieldRow(field: field)
            }
            spendRow
            if card.requiresFaceId && card.state == .pending {
                Label("Face ID required", systemImage: "faceid")
                    .font(.footnote)
                    .foregroundStyle(theme.textSecondary)
            }
            if card.state == .pending {
                if presentation.canApprove {
                    decisionButtons(presentation)
                } else {
                    Label("This request can't be approved here.", systemImage: "exclamationmark.octagon")
                        .font(.footnote)
                        .foregroundStyle(theme.danger)
                        .fixedSize(horizontal: false, vertical: true)
                }
            } else {
                resolutionRow
            }
            if !presentation.assistantsNote.isEmpty {
                DisclosureGroup(isExpanded: $noteExpanded) {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(presentation.assistantsNote, id: \.key) { field in
                            CardFieldRow(field: field)
                        }
                    }
                    .padding(.top, 4)
                } label: {
                    Text("Assistant's note")
                        .font(.subheadline)
                        .frame(minHeight: theme.minimumTarget)
                }
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(theme.surface, in: RoundedRectangle(cornerRadius: theme.cornerRadius))
        .overlay {
            RoundedRectangle(cornerRadius: theme.cornerRadius)
                .stroke(theme.border)
        }
        .opacity(card.state == .pending ? 1 : 0.85)
        .accessibilityElement(children: .contain)
    }

    @ViewBuilder
    private var spendRow: some View {
        switch card.spend.state {
        case .reported:
            if let cents = card.spend.cents {
                Text(verbatim: "Spend: " + (Double(cents) / 100).formatted(.currency(code: "USD")))
                    .font(.subheadline)
            }
        case .unknown:
            Text("Spend: not known yet")
                .font(.subheadline)
                .foregroundStyle(theme.textSecondary)
        case .none:
            EmptyView()
        }
    }

    @ViewBuilder
    private var resolutionRow: some View {
        if let resolution = card.resolution, resolution.receipt.isServer {
            Label {
                Text(verbatim: resolution.receipt.text)
                    .fixedSize(horizontal: false, vertical: true)
            } icon: {
                Image(systemName: resolutionSymbol)
            }
            .font(.subheadline)
            .foregroundStyle(theme.textSecondary)
        } else if card.state == .expired {
            Text("This request expired. Nothing was changed.")
                .font(.subheadline)
                .foregroundStyle(theme.textSecondary)
        }
    }

    private var resolutionSymbol: String {
        switch card.state {
        case .approved: return "checkmark.seal"
        case .declined: return "xmark.circle"
        case .expired: return "clock"
        case .superseded: return "arrow.triangle.2.circlepath"
        case .pending, .unknown: return "questionmark.circle"
        }
    }

    @ViewBuilder
    private func decisionButtons(_ presentation: CardPresentation) -> some View {
        let approve = Button {
            actions.approve(card)
        } label: {
            Text(verbatim: presentation.approveLabel ?? "")
                .font(.body.weight(.semibold))
                .frame(maxWidth: .infinity, minHeight: theme.minimumTarget)
        }
        .buttonStyle(.borderedProminent)
        let decline = Button {
            actions.decline(card)
        } label: {
            Text(verbatim: presentation.declineLabel ?? "")
                .frame(maxWidth: .infinity, minHeight: theme.minimumTarget)
        }
        .buttonStyle(.bordered)
        if typeSize.isAccessibilitySize {
            VStack(spacing: 8) {
                approve
                decline
            }
        } else {
            HStack(spacing: 8) {
                decline
                approve
            }
        }
    }
}

/// A label and value pair that stacks vertically when it no longer fits a row.
struct CardFieldRow: View {
    let field: CardField
    @Environment(\.leafAssistantTheme) private var theme

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: 12) {
                Text(verbatim: field.label)
                    .foregroundStyle(theme.textSecondary)
                Spacer(minLength: 8)
                Text(verbatim: field.value)
                    .multilineTextAlignment(.trailing)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(verbatim: field.label)
                    .foregroundStyle(theme.textSecondary)
                Text(verbatim: field.value)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .font(.subheadline)
        .accessibilityElement(children: .combine)
    }
}

/// Routes a server notice to its dedicated card, or to a ReasonBanner.
struct NoticeView: View {
    let reason: ReasonV1
    let actions: AssistantActions

    var body: some View {
        switch reason.code {
        case .cardExpired:
            ExpiredCard(reason: reason, actions: actions)
        case .cardConsumed, .cardSuperseded:
            ConsumedCard(reason: reason, actions: actions)
        case .workerOffline:
            WorkerOfflineCard(reason: reason, actions: actions)
        case .updateRequired:
            UpdateRequiredCard(reason: reason, actions: actions)
        default:
            ReasonBanner(reason: reason, onAction: actions.reason)
        }
    }
}

/// A card's time ran out before anyone approved it. Nothing was changed.
public struct ExpiredCard: View {
    private let reason: ReasonV1?
    private let actions: AssistantActions

    public init(reason: ReasonV1? = nil, actions: AssistantActions = AssistantActions()) {
        self.reason = reason
        self.actions = actions
    }

    public var body: some View {
        StatusCard(
            systemImage: "clock",
            title: "Request expired",
            fallback: "This request expired. Nothing was changed.",
            reason: reason,
            actions: actions
        )
    }
}

/// A card was already used, or a newer card replaced it.
public struct ConsumedCard: View {
    private let reason: ReasonV1?
    private let actions: AssistantActions

    public init(reason: ReasonV1? = nil, actions: AssistantActions = AssistantActions()) {
        self.reason = reason
        self.actions = actions
    }

    public var body: some View {
        StatusCard(
            systemImage: "arrow.triangle.2.circlepath",
            title: "Request already handled",
            fallback: "This request was already used or replaced.",
            reason: reason,
            actions: actions
        )
    }
}

/// The assistant's computer went offline mid-answer.
public struct WorkerOfflineCard: View {
    private let reason: ReasonV1?
    private let actions: AssistantActions

    public init(reason: ReasonV1? = nil, actions: AssistantActions = AssistantActions()) {
        self.reason = reason
        self.actions = actions
    }

    public var body: some View {
        StatusCard(
            systemImage: "wifi.slash",
            title: "Assistant offline",
            fallback: "The assistant's computer went offline mid-answer.",
            reason: reason,
            actions: actions
        )
    }
}

/// The server speaks a newer contract than this app, or sent something it can't show.
public struct UpdateRequiredCard: View {
    private let reason: ReasonV1?
    private let actions: AssistantActions

    public init(reason: ReasonV1? = nil, actions: AssistantActions = AssistantActions()) {
        self.reason = reason
        self.actions = actions
    }

    public var body: some View {
        StatusCard(
            systemImage: "arrow.down.circle",
            title: "Update required",
            fallback: "Update the app to see this part of the answer.",
            reason: reason,
            actions: actions
        )
    }
}

/// The shared layout of the status cards: icon, title, the server's text (or
/// fixed client copy), and the reason's one exit.
struct StatusCard: View {
    let systemImage: String
    let title: String
    let fallback: String
    let reason: ReasonV1?
    let actions: AssistantActions
    @Environment(\.leafAssistantTheme) private var theme

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label {
                Text(verbatim: title)
                    .font(.headline)
            } icon: {
                Image(systemName: systemImage)
            }
            .accessibilityAddTraits(.isHeader)
            Text(verbatim: reason?.text ?? fallback)
                .fixedSize(horizontal: false, vertical: true)
            if let reason {
                ReasonActionButton(reason: reason, onAction: actions.reason)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(theme.surface, in: RoundedRectangle(cornerRadius: theme.cornerRadius))
        .overlay {
            RoundedRectangle(cornerRadius: theme.cornerRadius)
                .stroke(theme.border)
        }
        .accessibilityElement(children: .contain)
    }
}
#endif
