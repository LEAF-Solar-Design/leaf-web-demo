#if canImport(SwiftUI)
import LeafAssistantCore
import SwiftUI

/// A reason with its one exit (VI.3 reason table). The text is the server's (or
/// the client's own copy for client.offline and client.timeout); the kit adds
/// only the icon and the button.
public struct ReasonBanner: View {
    private let reason: ReasonV1
    private let onAction: (ReasonV1) -> Void
    @Environment(\.leafAssistantTheme) private var theme
    @Environment(\.dynamicTypeSize) private var typeSize

    public init(reason: ReasonV1, onAction: @escaping (ReasonV1) -> Void = { _ in }) {
        self.reason = reason
        self.onAction = onAction
    }

    public var body: some View {
        let layout = typeSize.isAccessibilitySize
            ? AnyLayout(VStackLayout(alignment: .leading, spacing: 8))
            : AnyLayout(HStackLayout(alignment: .center, spacing: 8))
        layout {
            Image(systemName: symbol)
                .foregroundStyle(tint)
                .accessibilityHidden(true)
            Text(verbatim: reason.text)
                .accessibilityIdentifier("assistant.reply.error")
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
            ReasonActionButton(reason: reason, onAction: onAction)
        }
        .font(.subheadline)
        .padding(10)
        .background(tint.opacity(0.1), in: RoundedRectangle(cornerRadius: theme.cornerRadius))
        .accessibilityElement(children: .contain)
    }

    private var isWait: Bool { reason.next.action == .wait }

    private var tint: Color { isWait ? theme.warning : theme.danger }

    private var symbol: String {
        switch reason.code {
        case .rateLimited, .busy: return "hourglass"
        case .clientOffline, .workerOffline: return "wifi.slash"
        case .clientTimeout, .turnExpired, .cardExpired: return "clock"
        case .accessRevoked, .unpaired: return "lock"
        case .unconfigured, .updateRequired: return "gearshape"
        default: return "exclamationmark.triangle"
        }
    }
}

/// The reason's one exit. `wait` is shown as text (nothing to tap until retry_at);
/// `none` and an action this client does not know show nothing.
public struct ReasonActionButton: View {
    private let reason: ReasonV1
    private let onAction: (ReasonV1) -> Void
    @Environment(\.leafAssistantTheme) private var theme

    public init(reason: ReasonV1, onAction: @escaping (ReasonV1) -> Void = { _ in }) {
        self.reason = reason
        self.onAction = onAction
    }

    public var body: some View {
        switch reason.next.action {
        case .none, .unknown:
            EmptyView()
        case .wait:
            Text(verbatim: reason.next.label)
                .font(.callout)
                .foregroundStyle(theme.textSecondary)
        case .retry, .refresh, .openSettings, .pair:
            Button {
                onAction(reason)
            } label: {
                Text(verbatim: reason.next.label)
                    .frame(minWidth: theme.minimumTarget, minHeight: theme.minimumTarget)
            }
            .buttonStyle(.bordered)
        }
    }
}

/// How much of the hourly or daily quota is used, and when it resets.
public struct QuotaStrip: View {
    private let quota: QuotaV1
    @Environment(\.leafAssistantTheme) private var theme

    public init(quota: QuotaV1) {
        self.quota = quota
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            ViewThatFits(in: .horizontal) {
                HStack {
                    usage
                    Spacer(minLength: 8)
                    resets
                }
                VStack(alignment: .leading, spacing: 2) {
                    usage
                    resets
                }
            }
            .font(.footnote)
            ProgressView(value: Double(min(max(quota.used, 0), quota.limit)), total: Double(max(quota.limit, 1)))
                .tint(quota.used >= quota.limit ? theme.warning : theme.accent)
                .accessibilityHidden(true)
        }
        .accessibilityElement(children: .combine)
    }

    private var usage: some View {
        Text(verbatim: "\(quota.used) of \(quota.limit) asks this \(windowWord)")
    }

    @ViewBuilder
    private var resets: some View {
        if let date = LeafTimestamp.date(quota.resetsAt) {
            (Text("Resets ") + Text(date, style: .time))
                .foregroundStyle(theme.textSecondary)
        }
    }

    private var windowWord: String {
        switch quota.window {
        case .hour: return "hour"
        case .day: return "day"
        case .unknown: return "period"
        }
    }
}

/// Which model answers, and for whom (owner or tenant scope).
public struct ProviderChip: View {
    private let provider: ProviderV1
    private let scope: ScopeV1?
    @Environment(\.leafAssistantTheme) private var theme

    public init(provider: ProviderV1, scope: ScopeV1? = nil) {
        self.provider = provider
        self.scope = scope
    }

    public var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "sparkles")
                .accessibilityHidden(true)
            Text(verbatim: provider.label)
            Text(verbatim: provider.model)
                .foregroundStyle(theme.textSecondary)
            if let scope {
                Text(verbatim: scope.label)
                    .foregroundStyle(theme.textSecondary)
            }
        }
        .font(.footnote)
        .fixedSize(horizontal: false, vertical: true)
        .padding(.horizontal, 12)
        .frame(minHeight: theme.minimumTarget)
        .background(theme.surface, in: Capsule())
        .accessibilityElement(children: .combine)
    }
}
#endif
