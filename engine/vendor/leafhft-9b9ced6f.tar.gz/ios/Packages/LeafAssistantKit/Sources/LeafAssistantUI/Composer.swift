#if canImport(SwiftUI)
import LeafAssistantCore
import SwiftUI

/// The message field and send button. Counts UTF-16 units exactly as the server
/// does, shows a counter as the text nears K0's 7,000 limit, and refuses to send
/// an empty or over-long turn. Hands the host a ready TurnRequestV1.
public struct Composer: View {
    /// The counter appears at this many UTF-16 units, 1,000 before the limit.
    public static let counterStartsAt = TurnRequestV1.maxTextLength - 1000

    @Binding private var text: String
    private let placeholder: String
    private let isSending: Bool
    private let onSend: (TurnRequestV1) -> Void
    @Environment(\.leafAssistantTheme) private var theme

    public init(text: Binding<String>, placeholder: String = "Ask the assistant", isSending: Bool = false, onSend: @escaping (TurnRequestV1) -> Void) {
        self._text = text
        self.placeholder = placeholder
        self.isSending = isSending
        self.onSend = onSend
    }

    public var body: some View {
        VStack(alignment: .trailing, spacing: 6) {
            HStack(alignment: .bottom, spacing: 8) {
                TextField(placeholder, text: $text, axis: .vertical)
                    .accessibilityIdentifier("assistant.prompt")
                    .lineLimit(1...6)
                    .textFieldStyle(.plain)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                    .frame(minHeight: theme.minimumTarget)
                    .overlay {
                        RoundedRectangle(cornerRadius: theme.cornerRadius)
                            .stroke(theme.border)
                    }
                    .disabled(isSending)
                Button(action: send) {
                    Group {
                        if isSending {
                            ProgressView()
                        } else {
                            Image(systemName: "arrow.up.circle.fill")
                                .font(.title2)
                        }
                    }
                    .frame(minWidth: theme.minimumTarget, minHeight: theme.minimumTarget)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .foregroundStyle(canSend ? theme.accent : theme.textSecondary)
                .disabled(!canSend)
                .accessibilityLabel(Text(verbatim: isSending ? "Sending" : "Send"))
                .accessibilityIdentifier("assistant.send")
            }
            if count >= Self.counterStartsAt {
                Text(verbatim: "\(count) / \(TurnRequestV1.maxTextLength)")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(isOverLimit ? theme.danger : theme.textSecondary)
                    .accessibilityLabel(Text(verbatim: "\(count) of \(TurnRequestV1.maxTextLength) characters"))
            }
        }
    }

    private var count: Int { text.utf16.count }

    private var isOverLimit: Bool { count > TurnRequestV1.maxTextLength }

    private var trimmed: String { text.trimmingCharacters(in: .whitespacesAndNewlines) }

    private var canSend: Bool { !isSending && !isOverLimit && !trimmed.isEmpty }

    private func send() {
        guard canSend else { return }
        let request = TurnRequestV1(text: trimmed)
        guard request.isWithinBounds else { return }
        onSend(request)
        text = ""
    }
}
#endif
