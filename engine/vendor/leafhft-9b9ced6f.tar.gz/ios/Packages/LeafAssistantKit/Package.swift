// swift-tools-version: 5.9
import PackageDescription

// LeafAssistantKit: the Swift side of the assistant contract (Part VI K6).
// LeafAssistantCore is Foundation-only and builds on Linux with an injected
// digest; LeafAssistantUI is SwiftUI and compiles only where SwiftUI exists.
let package = Package(
    name: "LeafAssistantKit",
    platforms: [.iOS(.v17), .macOS(.v14)],
    products: [
        .library(name: "LeafAssistantCore", targets: ["LeafAssistantCore"]),
        .library(name: "LeafAssistantUI", targets: ["LeafAssistantUI"]),
    ],
    targets: [
        .target(name: "LeafAssistantCore"),
        .target(name: "LeafAssistantUI", dependencies: ["LeafAssistantCore"]),
        .testTarget(
            name: "LeafAssistantCoreTests",
            dependencies: ["LeafAssistantCore"],
            path: "Tests/LeafAssistantCoreTests",
            // The seven K0 goldens and their pin ship inside the test bundle
            // (Bundle.module), so the decode tests find them wherever the
            // package is built; the pin check still compares them to K0's.
            resources: [.copy("Fixtures")]
        ),
    ]
)
