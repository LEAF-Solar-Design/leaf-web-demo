# LeafAssistantKit: the assistant contract in Swift

The Swift side of Part VI K6. It decodes the same wire contract K0 defines in
`packages/assistant-contract` and renders it with the VI.3 component set. Core
comes first: the UI is only a thin layer over the Core models.

INTERNAL ONLY, like K0. Never publish it.

## Targets

- `LeafAssistantCore` (Foundation only, builds on Linux). Codable models for
  ThreadV1, ItemV1, BlockV1, ConfirmCardV1 (origin `server|model` on every
  field), ReasonV1 with the reason table, ProposalV1, the server events with
  `requires_action`, and the six worker events. Also `ThreadFold` (events to
  items), `ContractCheck` (the rules K0's decoder enforces, restated over the
  Swift models), `LeafTimestamp`, `Identifier`, and `AssistantClient` over an
  injected `AssistantTransport`.
- `LeafAssistantUI` (SwiftUI, compiled only where SwiftUI exists).
  `Composer`, `AssistantStream` (the VI.3 Stream, renamed so it never shadows
  `Foundation.Stream`), `TurnBubble`, `ToolCard`, `ViewPanel`, `ConfirmCard`,
  `ReasonBanner`, `QuotaStrip`, `ProviderChip`, and the `ExpiredCard`,
  `ConsumedCard`, `WorkerOfflineCard` and `UpdateRequiredCard` status cards.

## The rules the kit keeps

- Unknown values never throw. An enum value this client does not know decodes
  to `.unknown`; an unknown block or event type decodes to `.unknown(type:)`
  and an unknown event keeps its `seq`, so a cursor still advances.
  `ContractCheck` reports every unknown, so nothing is hidden. A known block
  that is missing a field still fails to decode.
- A key K0 requires but allows to be null (`quota`, `resolution`, `actor`,
  `cents`, a view row's `value` and `unit`) must be present. `@Nullable`
  refuses a missing key and writes an explicit null.
- The origin rule. `ConfirmCardV1.presentation` puts a field above Approve only
  when it is placed there AND server-origin. Anything else goes to the
  collapsed assistant's note. A card that needed a demotion, or whose title or
  buttons are not server-origin, lists why in `refusals` and never offers
  Approve. `ConfirmCard` renders only from `presentation`.
- A server-only block (view, card, artifact, notice) that is not server-origin
  never renders as trusted content.
- Digest and transport are injected. `CryptoKitDigest` exists behind
  `#if canImport(CryptoKit)`; a Linux build supplies its own `DigestProvider`.
  `AssistantClient` checks every id against K0's Id pattern before it builds a
  path, and it checks turn text against the 7,000 UTF-16 unit bound before
  sending. It maps an `ErrorV1` body to its reason, and maps offline and
  timeout to the client's own copy.
  `turnEvents` is a Kashbot v1 extension outside K0:
  GET `/turns/{turn_id}/events`, with `after` in 0..8001 and `wait` in 0..15.
  Resume from the returned `next_after` (`nextAfter` in Swift), never the last
  event's seq. The host transport supplies the base path, such as
  `/api/kashbot/assistant/v1` for Kashbot.
- Theme tokens are injected with `.leafAssistantTheme(_:)`. KM3 maps LeafTheme
  onto them. Every tappable control is at least 44 pt, and layouts reflow
  instead of truncating at every size up to accessibility5 (AX XXXL). Payload
  strings render with `Text(verbatim:)`, so they are never read as markdown or
  a localization key.

### Accessibility identifiers

The Kit sets these identifiers on its views:

| Identifier | File | Element |
|---|---|---|
| `assistant.prompt` | Composer.swift | TextField |
| `assistant.send` | Composer.swift | Send Button |
| `assistant.panel.` + `view.kind.rawValue` | ViewPanel.swift | Outer VStack (`metric`, `table`, `line`, or `_unknown`) |
| `assistant.reply.text` | Stream.swift | Trusted text block's Text, only for `.assistant` items |
| `assistant.reply.error` | Chips.swift | ReasonBanner's reason Text |

`Composer` accepts a `placeholder`, defaulting to "Ask the assistant".
The app owns `studio.*`, `assistant.empty`, `assistant.starter.N`,
`assistant.engineToggle`, `assistant.engineNote`, `assistant.new`,
`assistant.close`, `assistant.offline`, `assistant.thinking`, `assistant.tool`,
and `assistant.prefill.*`. The Kit does not set those identifiers.

## Fixtures and parity

`Tests/LeafAssistantCoreTests/Fixtures` is a vendored copy of K0's seven golden
conversations and their `FIXTURES.sha256`. The tests check four things:

- the pin recomputes from the vendored files (LF-normalized, like K0's);
- the vendored pin equals `packages/assistant-contract/fixtures/FIXTURES.sha256`;
- every vendored fixture equals K0's copy byte for byte;
- every Swift model's wire keys equal the K0 JSON Schema's properties, with the
  non-optional keys equal to its `required`, and every enum's values equal the
  schema's.

A K0 contract change therefore fails this suite until the Swift models and the
vendored fixtures move with it. To re-vendor after a K0 change, copy the seven
JSON files and `FIXTURES.sha256` from `packages/assistant-contract/fixtures`,
then update the models until `ParityTests` passes.

Set `LEAF_ASSISTANT_CONTRACT_DIR` to point the tests at a K0 checkout that is
not at `../../packages/assistant-contract` from this package.

## Verify

```
python tools/mac_verify_kit.py
```

This ships the package and K0's `fixtures` and `schema` directories to the Mac
mini (`ssh mac-mini`) as one tar stream. It runs
`swift test --package-path swift/LeafAssistantKit` there, pointing
`DEVELOPER_DIR` at an installed Xcode when `xcode-select` names the Command Line
Tools. A green exit alone does not pass: the script parses the output and exits
5 when the executed test count (XCTest plus swift-testing) is zero, or when any
of the seven golden fixture tests (`testIdle` through `testWorkerOffline`, run
by both `FixtureDecodeTests` and the swift-testing `GoldenFixtureSuite`) did
not pass. A zero-test run also prints `swift test list` so the missing target
is visible. A non-zero `swift test` exit is mirrored as is. `--filter` narrows
the run (and skips the fixture coverage check), `--host` or `LEAF_MAC_HOST`
picks another Mac, and `--timeout` bounds it (default 1800 s).

The fixtures are a test resource (`resources: [.copy("Fixtures")]`), read
through `Bundle.module`, with the source tree as the fallback.

On a Mac with the repo checked out, `swift test --package-path swift/LeafAssistantKit`
runs the same suite directly.
