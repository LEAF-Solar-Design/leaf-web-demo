import XCTest

final class FixtureUITests: XCTestCase {
    private var app: XCUIApplication!
    private var expectedAppearance = "light"

    override func setUpWithError() throws {
        continueAfterFailure = false
        let appearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] ?? "light"
        expectedAppearance = appearance
        XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
        XCTAssertEqual(XCUIDevice.shared.appearance, appearance == "dark" ? .dark : .light)
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-kashbot.engines.rowDetail", "detailed",
            "-kashbot.engines.grouped", "YES", "-kashbot.engines.sort", "runner", "-LEAFHFT_APPEARANCE", appearance,
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        // Set appearance inside XCTest because test configuration can reset simctl's value.
    }

    private func screenshot(_ screen: String) {
        let readback = app.staticTexts["fixture.renderedAppearance"]
        XCTAssertTrue(readback.waitForExistence(timeout: 2))
        XCTAssertEqual(readback.value as? String, expectedAppearance)
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = screen
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    private func reveal(_ element: XCUIElement, identifier: String? = nil, in scroll: XCUIElement, limit: Int = 35) {
        let targetIdentifier = identifier ?? (element.exists ? element.identifier : "requested element")
        for _ in 0..<limit {
            if app.keyboards.firstMatch.exists {
                let returnKey = app.keyboards.buttons["Return"].firstMatch
                if returnKey.exists {
                    returnKey.tap()
                } else {
                    app.navigationBars.firstMatch.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
                }
                continue
            }
            if element.exists && element.isHittable { return }
            let above = element.exists && element.frame.maxY > 0 && element.frame.minY < app.navigationBars.firstMatch.frame.maxY
            let start = scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.08, dy: above ? 0.30 : 0.60))
            let end = scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.08, dy: above ? 0.65 : 0.20))
            start.press(forDuration: 0, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0)
        }
        XCTFail("Could not reach \(targetIdentifier)")
    }

    private func revealInList(_ element: XCUIElement, in container: XCUIElement, limit: Int = 30) {
        if element.exists && element.isHittable { return }
        for _ in 0..<limit {
            let window = app.windows.firstMatch.frame
            let frame = container.frame
            let top = max(max(window.minY, app.navigationBars.firstMatch.frame.maxY), frame.minY)
            let bottom = min(min(window.maxY, app.tabBars.firstMatch.frame.minY), frame.maxY)
            if bottom - top < 60 {
                // Reveal more of the container using the page gutter, outside its rows.
                let page = container.identifier == "books.rows"
                    ? app.descendants(matching: .any)["books.scroll"].firstMatch
                    : app.collectionViews["engines.list"]
                let above = frame.midY < top
                let start = page.coordinate(withNormalizedOffset: CGVector(dx: 0.02, dy: above ? 0.20 : 0.60))
                let end = page.coordinate(withNormalizedOffset: CGVector(dx: 0.02, dy: above ? 0.60 : 0.20))
                start.press(forDuration: 0, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0)
                if element.exists && element.isHittable { return }
                continue
            }
            // Start inside the visible band so a clipped list cannot pan on the tab bar.
            let start = container.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: frame.width * 0.5, dy: (top + bottom) / 2 - frame.minY))
            let reverse = element.exists && !element.frame.isEmpty && element.frame.minY < top
            let end = start.withOffset(CGVector(dx: 0, dy: reverse ? 160 : -160))
            start.press(forDuration: 0, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0)
            if element.exists && element.isHittable { return }
        }
        XCTFail("Could not reach \(element.identifier)")
    }

    // A tappable fragment is insufficient for a readable evidence screenshot.
    private func revealForScreenshot(_ element: XCUIElement, in scroll: XCUIElement) {
        for _ in 0..<20 {
            guard element.exists else { XCTFail("Screenshot target is missing"); return }
            let viewport = scroll.frame.intersection(app.frame)
            let top = max(viewport.minY, app.navigationBars.firstMatch.frame.maxY) + 8
            let bottom = min(viewport.maxY, app.tabBars.firstMatch.frame.minY) - 8
            let frame = element.frame
            guard bottom > top, frame.height <= bottom - top else {
                XCTFail("Screenshot target does not fit between navigation and tabs")
                return
            }
            if frame.minY >= top && frame.maxY <= bottom { return }
            let correction = (top + bottom) / 2 - frame.midY
            let distance = max(-100.0, min(100.0, correction))
            let start = app.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: viewport.midX, dy: (top + bottom) / 2))
            // Hold at the endpoint to stop deceleration before releasing the drag.
            start.press(forDuration: 0, thenDragTo: start.withOffset(CGVector(dx: 0, dy: distance)),
                        withVelocity: .slow, thenHoldForDuration: 0.3)
        }
        XCTFail("Could not fully reveal screenshot target")
    }

    private func fixture(_ name: String) throws -> [String: Any] {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: name, withExtension: "json", subdirectory: "Fixtures"))
        return try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
    }

    func testFirstLaunchWithoutKey() {
        app.launchArguments += ["-LEAFHFT_NO_KEY", "1"]
        app.launch()
        XCTAssertTrue(app.staticTexts["account.settingsPrompt"].waitForExistence(timeout: 3))
        XCTAssertEqual(app.staticTexts["account.settingsPrompt"].label, "Import your runner key in Settings.")
        app.tabBars.buttons["Settings"].tap()
        XCTAssertTrue(app.staticTexts["settings.fixtureNotice"].exists)
    }

    func testMonitorShowsCashoutLedger() {
        app.launch()
        app.tabBars.buttons["Monitor"].tap()
        let scroll = app.scrollViews["account.scroll"]
        for identifier in ["exits.headline", "exits.tally", "exits.price", "exits.lesson", "exits.row.0"] {
            let element = app.descendants(matching: .any)[identifier].firstMatch
            reveal(element, identifier: identifier, in: scroll)
            XCTAssertTrue(element.exists)
        }
        revealForScreenshot(app.descendants(matching: .any)["exits.headline"].firstMatch, in: scroll)
        screenshot("Cashouts card")
        let all = app.buttons["exits.all"]
        reveal(all, identifier: "exits.all", in: scroll)
        all.tap()
        let sheet = app.scrollViews["exits.sheet.scroll"]
        XCTAssertTrue(sheet.waitForExistence(timeout: 3))
        for identifier in ["exits.lessons.0", "exits.calibration.0", "exits.engine.0", "exits.sheet.row.0"] {
            let element = app.descendants(matching: .any)[identifier].firstMatch
            reveal(element, identifier: identifier, in: sheet)
            XCTAssertTrue(element.exists)
            if identifier == "exits.lessons.0" {
                screenshot("Cashouts ledger")
            } else if identifier == "exits.calibration.0" {
                revealForScreenshot(element, in: sheet)
                screenshot("Cashouts calibration")
            }
        }
    }

    func testMonitorShowsEntryCalibration() {
        app.launch()
        app.tabBars.buttons["Monitor"].tap()
        let scroll = app.scrollViews["account.scroll"]
        for identifier in ["calibration.headline", "calibration.edge", "calibration.coverage",
                           "calibration.lesson", "calibration.best"] {
            let element = app.descendants(matching: .any)[identifier].firstMatch
            reveal(element, identifier: identifier, in: scroll)
            XCTAssertTrue(element.exists)
        }
        revealForScreenshot(app.descendants(matching: .any)["calibration.headline"].firstMatch, in: scroll)
        screenshot("Entries card")
        let advice = app.descendants(matching: .any)["calibration.advice.0"].firstMatch
        reveal(advice, identifier: "calibration.advice.0", in: scroll)
        XCTAssertTrue(advice.label.contains("atlas: Cap price at 95c"))
        let ask = app.buttons["calibration.ask"]
        reveal(ask, identifier: "calibration.ask", in: scroll)
        revealForScreenshot(advice, in: scroll)
        XCTAssertTrue(ask.exists)
        screenshot("Entries advice")
        reveal(ask, identifier: "calibration.ask", in: scroll)
        ask.tap()
        let expected = "Run a held-out check of Cap price at 95c on my engines, then tell me which engine it helps."
        let prompt = app.descendants(matching: .any)["assistant.prompt"].firstMatch
        XCTAssertTrue(prompt.waitForExistence(timeout: 3))
        XCTAssertEqual(prompt.value as? String, expected)
        // Prefilled, not sent: the send button still holds the draft and no turn exists.
        XCTAssertTrue(app.buttons["assistant.send"].isEnabled)
        XCTAssertFalse(app.descendants(matching: .any)["assistant.prefill.banner"].firstMatch.exists)
        XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label == %@", expected)).count, 0)
        XCTAssertFalse(app.staticTexts["assistant.reply.text"].exists)
        XCTAssertFalse(app.staticTexts["assistant.reply.error"].exists)
        XCTAssertFalse(app.descendants(matching: .any)["assistant.thinking"].firstMatch.exists)
        screenshot("Assistant prefilled")
        app.buttons["assistant.close"].tap()
        XCTAssertTrue(scroll.waitForExistence(timeout: 3))
        let all = app.buttons["calibration.all"]
        reveal(all, identifier: "calibration.all", in: scroll)
        all.tap()
        let sheet = app.scrollViews["calibration.sheet.scroll"]
        XCTAssertTrue(sheet.waitForExistence(timeout: 3))
        for identifier in ["calibration.lessons.0", "calibration.bucket.0", "calibration.cell.0", "calibration.engine.0"] {
            let element = app.descendants(matching: .any)[identifier].firstMatch
            reveal(element, identifier: identifier, in: sheet)
            XCTAssertTrue(element.exists)
        }
        screenshot("Entries calibration")
    }

    func testMonitorShowsAttemptFunnel() {
        app.launch()
        app.tabBars.buttons["Monitor"].tap()
        let scroll = app.scrollViews["account.scroll"]
        let title = app.descendants(matching: .any)["attemptFunnel.title"].firstMatch
        reveal(title, identifier: "attemptFunnel.title", in: scroll)
        XCTAssertTrue(title.label.contains("Where attempts die"))
        let headline = app.staticTexts["attemptFunnel.headline"]
        reveal(headline, identifier: "attemptFunnel.headline", in: scroll)
        XCTAssertEqual(headline.label, "Most attempts that did not fill were sent but got no fill (250 of 512)")
        revealForScreenshot(headline, in: scroll)
        screenshot("Where attempts die card")
    }

    func testGuidedTourAndSettingsReplay() {
        app.launchArguments += ["-LEAFHFT_TOUR"]
        app.launch()

        let title = app.staticTexts["tour.title"]
        XCTAssertTrue(title.waitForExistence(timeout: 3))
        XCTAssertEqual(title.label, "Monitor your account")
        XCTAssertEqual(app.staticTexts["tour.message"].label,
            "Start on Monitor for whether the runner is alive, cash and account value, current Kalshi positions, recent fills, and the runner's sizing summary.")
        XCTAssertTrue(app.tabBars.buttons["Monitor"].isSelected)
        screenshot("Tour account")

        for (expectedTitle, tab) in [
            ("Inspect live markets", "Books"),
            ("Compare your engines", "Engines"),
            ("Understand the system", "Lab")
        ] {
            app.buttons["tour.next"].tap()
            XCTAssertEqual(title.label, expectedTitle)
            XCTAssertTrue(app.tabBars.buttons[tab].isSelected)
        }
        app.buttons["tour.next"].tap()
        XCTAssertEqual(title.label, "Ask from anywhere")
        XCTAssertTrue(app.tabBars.buttons["Monitor"].isSelected)
        app.buttons["tour.next"].tap()
        XCTAssertEqual(title.label, "Connect and come back anytime")
        XCTAssertTrue(app.tabBars.buttons["Settings"].isSelected)
        screenshot("Tour settings")
        app.buttons["tour.done"].tap()
        XCTAssertFalse(app.otherElements["tour.overlay"].exists)

        let replay = app.buttons["settings.showTour"]
        let form = app.collectionViews["settings.form"]
        reveal(replay, identifier: "settings.showTour", in: form)
        XCTAssertTrue(replay.exists)
        revealForScreenshot(replay, in: form)
        XCTAssertTrue(replay.isHittable)
        XCTAssertTrue(replay.isEnabled)
        replay.tap()
        XCTAssertTrue(title.waitForExistence(timeout: 2))
        XCTAssertEqual(title.label, "Monitor your account")
        XCTAssertTrue(app.tabBars.buttons["Monitor"].isSelected)
        app.buttons["tour.close"].tap()
        XCTAssertFalse(app.otherElements["tour.overlay"].exists)
    }

    func testAccountShowsPhoneActivityAndSanitizedRunnerSummary() {
        app.launch()
        let scroll = app.descendants(matching: .any)["account.scroll"].firstMatch
        XCTAssertTrue(scroll.waitForExistence(timeout: 3))

        let position = app.staticTexts["account.position.0"]
        reveal(position, in: scroll)
        XCTAssertEqual(position.label, "FIXTURE-T")

        let fill = app.staticTexts["account.fill.0"]
        reveal(fill, in: scroll)
        XCTAssertEqual(fill.label, "FIXTURE-T")

        let freeCash = app.descendants(matching: .any)["account.runner.freeCash"].firstMatch
        reveal(freeCash, in: scroll)
        XCTAssertTrue(freeCash.label.contains("Free cash"))
        XCTAssertTrue(freeCash.label.contains("$23.88"))

        let submitted = app.descendants(matching: .any)["account.runner.submitted"].firstMatch
        XCTAssertTrue(submitted.label.contains("8 claims"))
        XCTAssertTrue(submitted.label.contains("$3.36"))
        let filled = app.descendants(matching: .any)["account.runner.filled"].firstMatch
        XCTAssertTrue(filled.label.contains("5 fills"))
        XCTAssertTrue(filled.label.contains("$2.14"))
        XCTAssertFalse(app.staticTexts.matching(NSPredicate(format: "label CONTAINS[c] %@", "00000000-0000")).firstMatch.exists)
    }

    func testFourScreensAndFrozenFixtureValues() throws {
        app.launch()
        let chart = app.otherElements["account.chart"]
        XCTAssertTrue(chart.waitForExistence(timeout: 3))
        let scroll = app.descendants(matching: .any)["account.scroll"].firstMatch
        reveal(chart, in: scroll)
        let balance = try XCTUnwrap(try fixture("balance")["balance"] as? Int)
        let positions = try XCTUnwrap(try fixture("positions")["market_positions"] as? [[String: Any]])
        let positionCostText = try XCTUnwrap(positions.first?["market_exposure_dollars"] as? String)
        let positionCost = try XCTUnwrap(Double(positionCostText))
        let rangeControl = app.buttons["account.range"]
        XCTAssertTrue(rangeControl.waitForExistence(timeout: 2))
        XCTAssertFalse(app.segmentedControls["account.range"].exists)
        for (label, range, count) in [("1h", "hour", 4), ("4h", "fourHours", 4),
                                     ("12h", "twelveHours", 4), ("1d", "day", 4),
                                     ("7d", "week", 8), ("30d", "month", 12), ("All", "all", 12),
                                     ("1h", "hour", 4)] {
            rangeControl.tap()
            let option = app.buttons[label].firstMatch
            XCTAssertTrue(option.waitForExistence(timeout: 2))
            option.tap()
            let expected = "\(range): \(count) points; latest Kalshi balance read: cash \(balance) cents; account value \(balance) cents"
            let updated = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value BEGINSWITH %@", expected + "; x "), object: chart)
            XCTAssertEqual(XCTWaiter.wait(for: [updated], timeout: 15), .completed, "chart did not report \(label): \(String(describing: chart.value))")
            let value = try XCTUnwrap(chart.value as? String)
            func bounds(_ axis: String) throws -> [Double] {
                let part = try XCTUnwrap(value.components(separatedBy: "; \(axis) ").dropFirst().first)
                let text = try XCTUnwrap(part.components(separatedBy: ";").first)
                let numbers = text.components(separatedBy: "...").compactMap { Double($0) }
                XCTAssertEqual(numbers.count, 2)
                return numbers
            }
            let x = try bounds("x")
            let y = try bounds("y")
            guard x.count == 2, y.count == 2 else { return }
            // Fixtures have two recent points, then pairs three and fourteen days old.
            let visibleSpan = count == 4 ? 60.0 : count == 8 ? 3 * 86400.0 - 60 : 14 * 86400.0 - 60
            XCTAssertEqual(x[1] - x[0], visibleSpan * 1.1, accuracy: 0.001)
            let dollars = Double(balance) / 100
            // The fixture position has no quote, so portfolio history includes its cost mark.
            let portfolioDollars = dollars + positionCost
            let padding = max(positionCost * 0.05, 0.01)
            XCTAssertEqual(y[0], dollars - padding, accuracy: 0.000001)
            XCTAssertEqual(y[1], portfolioDollars + padding, accuracy: 0.000001)
            XCTAssertTrue(chart.isHittable)
        }
        screenshot("Account")
        app.tabBars.buttons["Books"].tap()
        let books = try XCTUnwrap(try fixture("books")["books"] as? [[String: Any]])
        XCTAssertEqual(books.count, 14)
        XCTAssertEqual(app.staticTexts["books.count"].label, "14 books")
        screenshot("Books")
        let booksScroll = app.descendants(matching: .any)["books.scroll"].firstMatch
        XCTAssertTrue(booksScroll.waitForExistence(timeout: 2))
        let booksRows = app.scrollViews["books.rows"].firstMatch
        reveal(booksRows, in: booksScroll)
        for book in books.sorted(by: { ($0["book_id"] as? String ?? "") < ($1["book_id"] as? String ?? "") }) {
            let id = try XCTUnwrap(book["book_id"] as? String)
            let row = app.buttons["book.\(id)"]
            revealInList(row, in: booksRows)
            let rowLabel = row.label
            XCTAssertTrue(rowLabel.contains(id))
            XCTAssertTrue(rowLabel.contains("Accepting new entries"), rowLabel)
            revealInList(app.switches["book.toggle.\(id)"], in: booksRows)
            XCTAssertFalse(app.switches["book.toggle.\(id)"].isEnabled)
        }
        let lastID = try XCTUnwrap(books.compactMap { $0["book_id"] as? String }.sorted().last)
        revealInList(app.buttons["book.\(lastID)"], in: booksRows)
        XCTAssertTrue(app.navigationBars["Books"].exists)
        app.buttons["book.\(lastID)"].tap()
        XCTAssertTrue(app.navigationBars[lastID].waitForExistence(timeout: 2))
        XCTAssertTrue(app.staticTexts["FIXTURE-T-14"].exists)
        XCTAssertFalse(app.tabBars.firstMatch.isHittable)
        screenshot("Book detail")
        app.navigationBars[lastID].buttons["Books"].tap()
        XCTAssertTrue(app.navigationBars["Books"].waitForExistence(timeout: 2))
        XCTAssertTrue(booksScroll.waitForExistence(timeout: 2))
        XCTAssertTrue(booksRows.waitForExistence(timeout: 2))
        XCTAssertTrue(app.tabBars.buttons["Books"].isSelected)
        app.tabBars.buttons["Engines"].tap()
        let openLab = app.buttons["engine.lab.open"]
        XCTAssertTrue(openLab.waitForExistence(timeout: 2))
        XCTAssertTrue(openLab.label.contains("Open Engine Lab"))
        let engines = try XCTUnwrap(try fixture("engines")["engines"] as? [[String: Any]])
        let engineList = app.collectionViews["engines.list"]
        let engineRows = app.collectionViews["engines.list"].firstMatch
        let notStarted = app.buttons["engines.catalog.group.notStarted"]
        revealInList(notStarted, in: engineRows)
        notStarted.tap()
        for engine in engines {
            let id = try XCTUnwrap(engine["engine_id"] as? String)
            let bound = try XCTUnwrap(engine["bound_books"] as? [String])
            let row = app.buttons["engine.detail.\(id)"]
            revealInList(row, in: engineRows)
            XCTAssertTrue(row.label.contains("Accepting new entries"))
            revealInList(app.switches["engine.toggle.\(id)"], in: engineRows)
            XCTAssertFalse(app.switches["engine.toggle.\(id)"].isEnabled)
            revealInList(row, in: engineRows)
            XCTAssertTrue(app.navigationBars["Engines"].exists)
            row.tap()
            let label = app.descendants(matching: .any)["engine.boundBooks.\(id)"].firstMatch
            XCTAssertTrue(label.waitForExistence(timeout: 2))
            XCTAssertEqual(label.label, bound.joined(separator: ", "))
            app.navigationBars.buttons.firstMatch.tap()
            XCTAssertTrue(engineRows.waitForExistence(timeout: 2))
        }
        screenshot("Engines")
        for _ in 0..<20 {
            let tools = app.buttons["engines.tools.group"]
            if tools.exists && tools.isHittable && tools.frame.minY >= app.navigationBars.firstMatch.frame.maxY { break }
            engineList.swipeDown()
        }
        for name in ["bind", "create"] {
            let control = app.buttons["engine.control.\(name)"]
            reveal(control, in: engineList)
            XCTAssertFalse(control.isEnabled)
        }
        XCTAssertFalse(app.buttons["engine.control.set"].exists)
        app.tabBars.buttons["Settings"].tap()
        let field = app.secureTextFields["settings.pem"]
        let form = app.collectionViews["settings.form"]
        reveal(field, in: form)
        // A partially exposed field can be hittable while its tap meets the
        // navigation bar. Move the entire input into the visible form first.
        for _ in 0..<3 {
            if field.frame.minY > app.navigationBars.firstMatch.frame.maxY { break }
            let start = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.35))
            let end = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.55))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        XCTAssertGreaterThan(field.frame.minY, app.navigationBars.firstMatch.frame.maxY)
        XCTAssertTrue(field.isHittable)
        XCTAssertFalse(app.textViews["settings.pem"].exists)
        field.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 2))
        // Plain non-secret marker tests redaction; no credential enters this suite.
        let marker = "fixture"
        field.typeText(marker)
        XCTAssertNotEqual(field.value as? String, marker)
        XCTAssertFalse(app.staticTexts[marker].exists)
        screenshot("Settings")
        XCTAssertFalse(app.buttons["settings.import"].isEnabled)
    }

    func testEngineLabSharedWorkboard() throws {
        app.launchArguments += ["-LEAFHFT_LAB_OFFLINE"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        let topLink = app.buttons["engine.lab.open"]
        XCTAssertTrue(topLink.waitForExistence(timeout: 3))
        XCTAssertTrue(topLink.label.contains("Open Engine Lab"))
        screenshot("Engines top Lab link")
        let labTab = app.tabBars.buttons["Lab"]
        XCTAssertTrue(labTab.waitForExistence(timeout: 3))
        labTab.tap()
        XCTAssertTrue(labTab.isSelected)

        XCTAssertTrue(app.navigationBars["Engine Lab"].waitForExistence(timeout: 3))
        let workboard = app.collectionViews["engine.lab.list"]
        XCTAssertTrue(workboard.waitForExistence(timeout: 3))
        let about = app.buttons["About Engine Lab"].firstMatch
        XCTAssertTrue(about.waitForExistence(timeout: 3))
        reveal(about, identifier: "engine.lab.about", in: workboard)
        about.tap()
        XCTAssertTrue(app.staticTexts["Understand the engines behind Kashbot"].isHittable)
        XCTAssertTrue(app.staticTexts["Engine Lab shares research and advisory notes. Opening it cannot start trading. Account settings open on a separate screen."].isHittable)
        XCTAssertEqual(app.switches.count, 0)
        screenshot("Engine Lab overview")

        let engines = try XCTUnwrap(try fixture("engines")["engines"] as? [[String: Any]])
        XCTAssertFalse(engines.isEmpty)
        for engine in engines {
            let id = try XCTUnwrap(engine["engine_id"] as? String)
            let row = app.buttons["engine.lab.row.\(id)"]
            reveal(row, in: workboard)
            revealForScreenshot(row, in: workboard)
            XCTAssertTrue(row.isHittable)
            XCTAssertTrue(row.label.contains(engine["name"] as? String ?? id))
            XCTAssertEqual(app.switches.count, 0)
        }

        let darkhorse = app.buttons["engine.lab.row.darkhorse"]
        reveal(darkhorse, in: workboard)
        revealForScreenshot(darkhorse, in: workboard)
        XCTAssertTrue(darkhorse.label.contains("Darkhorse"))
        XCTAssertTrue(darkhorse.label.contains("Not reported"))
        XCTAssertTrue(darkhorse.label.contains("First-class account integration"))
        XCTAssertEqual(app.switches.count, 0)
        screenshot("Engine Lab research row")
        darkhorse.tap()

        XCTAssertTrue(app.navigationBars["Darkhorse"].waitForExistence(timeout: 3))
        let stage = app.descendants(matching: .any)["engine.lab.stage.darkhorse"].firstMatch
        XCTAssertTrue(stage.waitForExistence(timeout: 2))
        XCTAssertTrue(stage.label.contains("Not reported"))
        XCTAssertTrue(stage.isHittable)
        XCTAssertTrue(app.staticTexts["Next: First-class account integration"].isHittable)
        XCTAssertEqual(app.switches.count, 0)
        screenshot("Engine Lab Darkhorse detail")
        XCTAssertEqual(app.descendants(matching: .any).matching(
            NSPredicate(format: "identifier BEGINSWITH %@", "engine.lab.settings.")).count, 0)
        let detail = app.collectionViews.firstMatch
        let readiness = app.descendants(matching: .any)["engine.workshop.readiness.holdout_evidence"].firstMatch
        reveal(readiness, in: detail)
        XCTAssertEqual(readiness.value as? String, "noted")
        let design = app.buttons["engine.workshop.ask.design.darkhorse"]
        reveal(design, identifier: "engine.workshop.ask.design.darkhorse", in: detail)
        XCTAssertTrue(design.isHittable)
        XCTAssertTrue(app.buttons["engine.workshop.ask.test.darkhorse"].exists)
        XCTAssertTrue(app.buttons["engine.workshop.share.darkhorse"].exists)
        XCTAssertEqual(app.switches.count, 0)
    }

    func testEngineWorkshopLiveToolsAndCompare() throws {
        app.launch()
        app.tabBars.buttons["Lab"].tap()
        let engines = try XCTUnwrap(try fixture("engines")["engines"] as? [[String: Any]])
        let engine = try XCTUnwrap(engines.first)
        let id = try XCTUnwrap(engine["engine_id"] as? String)
        let row = app.buttons["engine.lab.row.\(id)"]
        reveal(row, in: app.collectionViews["engine.lab.list"])
        row.tap()
        let detail = app.collectionViews.firstMatch
        let readiness = app.descendants(matching: .any)["engine.workshop.readiness.holdout_evidence"].firstMatch
        reveal(readiness, in: detail)
        XCTAssertEqual(readiness.value as? String, "not_reported")
        let design = app.buttons["engine.workshop.ask.design.\(id)"]
        reveal(design, identifier: "engine.workshop.ask.design.\(id)", in: detail)
        XCTAssertTrue(app.buttons["engine.workshop.share.\(id)"].exists)
        XCTAssertEqual(app.switches.count, 0)
        let compare = app.buttons["engine.workshop.compare.\(id)"]
        reveal(compare, in: detail)
        compare.tap()
        XCTAssertTrue(app.navigationBars["Compare accounts"].waitForExistence(timeout: 3))
        XCTAssertEqual(app.switches.count, 0)
        app.navigationBars.buttons.element(boundBy: 0).tap()
        let accounts = try XCTUnwrap(try fixture("engines")["accounts"] as? [[String: Any]])
        if accounts.contains(where: { ($0["configurable"] as? Bool) == true &&
            ($0["id"] as? String) != "unassigned" && ($0["host"] as? String) == (engine["host"] as? String) }) {
            let settings = app.buttons["engine.lab.settings.\(id)"].firstMatch
            reveal(settings, in: detail)
            XCTAssertTrue(settings.isHittable)
        }
    }

    func testEngineWorkshopStudioPrefillKeepsDraftUntilReplace() {
        app.launchArguments += ["-LEAFHFT_LAB_OFFLINE"]
        app.launch()
        app.buttons["studio.launcher"].tap()
        let prompt = app.descendants(matching: .any)["assistant.prompt"].firstMatch
        XCTAssertTrue(prompt.waitForExistence(timeout: 3))
        prompt.tap()
        if let prior = prompt.value as? String, prior != prompt.placeholderValue {
            prompt.coordinate(withNormalizedOffset: CGVector(dx: 0.97, dy: 0.9)).tap()
            prompt.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: prior.count + 20))
        }
        let cleared = prompt.value as? String
        XCTAssertTrue(cleared.map { $0.isEmpty || $0 == prompt.placeholderValue } == true,
                      "Assistant prompt must be empty before requesting the first prefill")
        app.buttons["assistant.close"].tap()
        app.tabBars.buttons["Lab"].tap()
        let row = app.buttons["engine.lab.row.darkhorse"]
        reveal(row, in: app.collectionViews["engine.lab.list"])
        row.tap()
        let design = app.buttons["engine.workshop.ask.design.darkhorse"]
        reveal(design, identifier: "engine.workshop.ask.design.darkhorse", in: app.collectionViews.firstMatch)
        design.tap()
        XCTAssertTrue(app.buttons["assistant.close"].waitForExistence(timeout: 3))
        XCTAssertTrue(prompt.waitForExistence(timeout: 3))
        XCTAssertEqual(app.buttons["assistant.engineToggle"].value as? String, "On")
        XCTAssertTrue(app.staticTexts["assistant.engineNote"].exists)
        let original = prompt.value as? String
        XCTAssertTrue(original?.contains("Darkhorse") == true)
        XCTAssertTrue(original?.contains("Do not apply anything") == true)
        XCTAssertFalse(app.staticTexts["assistant.reply.text"].exists)
        XCTAssertFalse(app.staticTexts["assistant.reply.error"].exists)
        XCTAssertFalse(app.descendants(matching: .any)["assistant.prefill.banner"].firstMatch.exists)
        app.buttons["assistant.close"].tap()
        let test = app.buttons["engine.workshop.ask.test.darkhorse"]
        reveal(test, identifier: "engine.workshop.ask.test.darkhorse", in: app.collectionViews.firstMatch)
        test.tap()
        XCTAssertTrue(app.descendants(matching: .any)["assistant.prefill.banner"].firstMatch.waitForExistence(timeout: 3))
        XCTAssertEqual(prompt.value as? String, original)
        app.buttons["assistant.prefill.use"].tap()
        XCTAssertTrue((prompt.value as? String)?.contains("Design a test") == true)
        XCTAssertFalse(app.descendants(matching: .any)["assistant.prefill.banner"].firstMatch.exists)
        XCTAssertFalse(app.staticTexts["assistant.reply.text"].exists)
        XCTAssertFalse(app.staticTexts["assistant.reply.error"].exists)
        let replacement = prompt.value as? String
        app.buttons["assistant.close"].tap()
        design.tap()
        XCTAssertTrue(app.descendants(matching: .any)["assistant.prefill.banner"].firstMatch.waitForExistence(timeout: 3))
        app.buttons["assistant.prefill.dismiss"].tap()
        XCTAssertEqual(prompt.value as? String, replacement)
        XCTAssertFalse(app.descendants(matching: .any)["assistant.prefill.banner"].firstMatch.exists)
    }

    func testColdLaunchFirstFrameMetric() {
        let options = XCTMeasureOptions()
        options.iterationCount = 1
        measure(metrics: [XCTApplicationLaunchMetric(waitUntilResponsive: false)], options: options) {
            app.launch()
        }
    }

    func testSettingsConnectionRecovery() {
        app.launchArguments += ["-LEAFHFT_CONNECTION_WALK"]
        app.launch()
        app.tabBars.buttons["Settings"].tap()
        let form = app.collectionViews["settings.form"]
        let file = app.buttons["settings.chooseKeyFile"]
        reveal(file, in: form)
        XCTAssertFalse(file.isEnabled)
        revealForScreenshot(file, in: form)
        screenshot("Settings file choice")
        let check = app.buttons["settings.checkConnection"]
        reveal(check, in: form)
        check.tap()
        XCTAssertFalse(check.isEnabled)
        let status = app.staticTexts["settings.connectionStatus"]
        reveal(status, in: form)
        let failed = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", "Connection failed"), object: status)
        XCTAssertEqual(XCTWaiter.wait(for: [failed], timeout: 5), .completed)
        XCTAssertTrue(status.label.contains("Connection failed"))
        revealForScreenshot(status, in: form)
        screenshot("Settings connection retry")
        // Return to the same control rather than relaunching and resetting state.
        for _ in 0..<35 {
            if check.exists && check.isHittable && check.frame.minY > app.navigationBars.firstMatch.frame.maxY { break }
            let start = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.30))
            let end = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.55))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        check.tap()
        XCTAssertFalse(check.isEnabled)
        reveal(status, in: form)
        let connected = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", "Connected."), object: status)
        XCTAssertEqual(XCTWaiter.wait(for: [connected], timeout: 5), .completed)
        revealForScreenshot(status, in: form)
        screenshot("Settings connection success")
        for _ in 0..<35 {
            if check.exists && check.isHittable && check.frame.minY > app.navigationBars.firstMatch.frame.maxY { break }
            let start = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.30))
            let end = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.55))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        check.tap()
        revealForScreenshot(status, in: form)
        screenshot("Settings connection pending")
        app.tabBars.buttons["Monitor"].tap()
        app.tabBars.buttons["Settings"].tap()
        reveal(status, in: form)
        XCTAssertTrue(status.label.contains("Check stopped"))
        revealForScreenshot(status, in: form)
        screenshot("Settings connection cancelled")
    }

    func testFilePickerCancellationPreservesDraft() {
        app.launchArguments += ["-LEAFHFT_FILE_PICKER_WALK"]
        app.launch()
        app.tabBars.buttons["Settings"].tap()
        let form = app.collectionViews["settings.form"]
        let field = app.secureTextFields["settings.pem"]
        reveal(field, in: form)
        for _ in 0..<3 {
            if field.frame.minY > app.navigationBars.firstMatch.frame.maxY { break }
            form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.35))
                .press(forDuration: 0.05, thenDragTo: form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.55)))
        }
        field.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 2))
        field.typeText("fixture")
        let draft = field.value as? String
        XCTAssertNotEqual(draft, "fixture")
        let choose = app.buttons["settings.chooseKeyFile"]
        // The preceding field reveal leaves the button above the viewport.
        // Use short drags; a full swipe can overshoot it in this long form.
        for _ in 0..<35 {
            if choose.exists && choose.isHittable && choose.frame.minY > app.navigationBars.firstMatch.frame.maxY { break }
            form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.30))
                .press(forDuration: 0.05, thenDragTo: form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.55)))
        }
        XCTAssertTrue(choose.exists)
        XCTAssertTrue(choose.isEnabled)
        choose.tap()
        let cancel = app.buttons["Cancel"].firstMatch
        XCTAssertTrue(cancel.waitForExistence(timeout: 5))
        cancel.tap()
        XCTAssertTrue(choose.waitForExistence(timeout: 3))
        reveal(field, in: form)
        XCTAssertEqual(field.value as? String, draft)
        XCTAssertFalse(app.buttons["settings.import"].isEnabled)
        XCTAssertFalse(app.staticTexts["fixture"].exists)
        screenshot("Settings picker cancelled")
    }

    func testChartAppearsClockMetric() {
        let options = XCTMeasureOptions()
        options.iterationCount = 1
        options.invocationOptions = [.manuallyStart, .manuallyStop]
        measure(metrics: [XCTClockMetric()], options: options) {
            // XCTest also runs a warm-up iteration. Exclude teardown on every run.
            app.terminate()
            startMeasuring()
            app.launch()
            let chart = app.otherElements["account.chart"]
            // Avoid the waiter's polling delay when launch already exposed the chart.
            XCTAssertTrue(chart.exists || chart.waitForExistence(timeout: 2))
            // Include launch plus the reveal below the Alive rail and money hero.
            let scroll = app.descendants(matching: .any)["account.scroll"].firstMatch
            reveal(chart, in: scroll)
            XCTAssertTrue(chart.isHittable)
            stopMeasuring()
        }
        // Operator-approved acceptance: gate first frame in simulator_job.py.
        // This launch/query clock remains diagnostic because it includes XCTest work.
    }
}
