import XCTest

/// Replay: fixtures (engines.json, probes.json), the Engines catalog by lifecycle state, Default detail,
/// its performance history; then, under -LEAFHFT_CONTROL_WALK 1, a Halt that is rejected then applied.
final class EnginesUITests: XCTestCase {
    private var app: XCUIApplication!
    private var appearance = "light"

    override func setUpWithError() throws {
        continueAfterFailure = false
        appearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] ?? "light"
        XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-kashbot.engines.rowDetail",
            name.contains("SearchSortCollapseAndRefresh") ? "compact" : "detailed",
            "-LEAFHFT_APPEARANCE", appearance,
            "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        if name.contains("ControlWalk") { app.launchArguments += ["-LEAFHFT_CONTROL_WALK", "1"] }
        if name.contains("SearchSortCollapseAndRefresh") {
            app.launchArguments += ["-LEAFHFT_ENGINE_COUNT", "64", "-LEAFHFT_CONTROL_WALK", "1"]
        } else {
            app.launchArguments += ["-kashbot.engines.grouped", "YES", "-kashbot.engines.sort", "runner"]
        }
        app.launch()
    }

    func testSearchSortCollapseAndRefresh() {
        app.tabBars.buttons["Engines"].tap()
        let list = app.collectionViews["engines.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 5))
        XCTAssertFalse(app.scrollViews["engines.rows"].exists)
        let tools = app.buttons["engines.tools.group"]
        tools.tap()
        XCTAssertEqual(tools.value as? String, "Collapsed")
        chooseCatalog("Sort", value: "Runner order")
        if app.buttons["engines.catalog.group.all"].exists {
            app.buttons["engines.sortMenu"].tap()
            app.buttons["Group by lifecycle"].tap()
        }
        XCTAssertTrue(app.buttons["engines.catalog.group.probing"].exists)
        let aggressiveProbe = app.buttons["engine.detail.aggressive-006"]
        revealCatalog(aggressiveProbe, identifier: "engine.detail.aggressive-006", in: list)
        XCTAssertTrue(aggressiveProbe.isHittable)
        revealCatalog(app.staticTexts["engines.observed"], identifier: "engines.observed", in: list, upward: true)
        list.swipeDown()
        let search = app.searchFields.firstMatch
        XCTAssertTrue(search.waitForExistence(timeout: 3))
        search.tap()
        search.typeText("Default\n")
        let showing = app.staticTexts["Showing 32 of 64"]
        XCTAssertTrue(showing.waitForExistence(timeout: 3))
        let detailRows = list.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "engine.detail."))
        XCTAssertGreaterThan(detailRows.count, 0)
        for row in detailRows.allElementsBoundByIndex {
            XCTAssertTrue(row.label.hasPrefix("Default "), row.label)
        }
        XCTAssertTrue(app.staticTexts["7 halted or attention engines hidden"].exists)
        XCTAssertFalse(aggressiveProbe.exists)
        app.buttons["engines.filterClear"].tap()
        XCTAssertTrue(showing.waitForNonExistence(timeout: 3))
        let first = app.buttons["engine.detail.default-001"]
        revealCatalog(first, identifier: "engine.detail.default-001", in: list)
        XCTAssertTrue(first.isHittable)
        XCTAssertTrue(element("engine.summary.default-001").exists)
        XCTAssertFalse(element("engine.profitDials.default-001").exists)
        chooseCatalog("Sort", value: "Net P&L low to high")
        let sortedFirst = app.buttons["engine.detail.default-061"]
        revealCatalog(sortedFirst, identifier: "engine.detail.default-061", in: list, upward: true)
        let visibleTop = max(list.frame.minY, app.navigationBars.firstMatch.frame.maxY) + 8
        let visibleBottom = min(list.frame.maxY, app.tabBars.firstMatch.frame.minY) - 80
        let visibleBand = CGRect(x: list.frame.minX, y: visibleTop, width: list.frame.width,
                                 height: max(0, visibleBottom - visibleTop))
        let visibleRows = detailRows.allElementsBoundByIndex.compactMap { row -> (identifier: String, frame: CGRect)? in
            guard row.exists else { return nil }
            let frame = row.frame
            guard !frame.isEmpty && frame.intersects(visibleBand) && row.isHittable else { return nil }
            return (identifier: row.identifier, frame: frame)
        }
            .sorted { $0.frame.minY < $1.frame.minY }
        XCTAssertEqual(visibleRows.first?.identifier, "engine.detail.default-061")
        XCTAssertNotEqual(visibleRows.first?.identifier, "engine.detail.default-001")
        let probing = app.buttons["engines.catalog.group.probing"]
        revealCatalog(probing, identifier: "engines.catalog.group.probing", in: list, upward: true)
        probing.tap()
        XCTAssertEqual(probing.value as? String, "Collapsed")
        for index in stride(from: 0, to: 64, by: 5) {
            let id = (index.isMultiple(of: 2) ? "default" : "aggressive") + String(format: "-%03d", index + 1)
            XCTAssertFalse(app.buttons["engine.detail.\(id)"].exists)
        }
        let live = app.buttons["engines.catalog.group.live"]
        revealCatalog(live, identifier: "engines.catalog.group.live", in: list)
        XCTAssertTrue(live.exists)
        XCTAssertEqual(live.value as? String, "Expanded")
        let liveRow = app.buttons["engine.detail.default-057"]
        revealCatalog(liveRow, identifier: "engine.detail.default-057", in: list)
        XCTAssertTrue(liveRow.isHittable)
        app.buttons["engines.sortMenu"].tap()
        app.buttons["Expand all"].tap()
        chooseCatalog("Sort", value: "Runner order")
        app.buttons["engines.sortMenu"].tap()
        app.buttons["Group by lifecycle"].tap()
        let last = app.buttons["engine.detail.aggressive-064"]
        revealCatalog(last, identifier: "engine.detail.aggressive-064", in: list)
        XCTAssertTrue(last.isHittable)
        revealCatalog(app.switches["engine.toggle.aggressive-064"], identifier: "engine.toggle.aggressive-064", in: list)
        XCTAssertTrue(app.switches["engine.toggle.aggressive-064"].isHittable)
        XCTAssertFalse(app.scrollViews["engines.rows"].exists)

        // Leave a real fixture lifecycle request at Requested, then refresh only the catalog.
        revealCatalog(first, identifier: "engine.detail.default-001", in: list, upward: true)
        first.tap()
        let detail = app.collectionViews["engine.detail.list"]
        XCTAssertTrue(detail.waitForExistence(timeout: 3))
        halt(in: detail)
        let request = element("engine.detail.request.fixture-request-1")
        reveal(request, in: detail)
        XCTAssertTrue(request.label.hasPrefix("engine.halt, Requested"), request.label)
        app.navigationBars.buttons.firstMatch.tap()
        let observed = app.staticTexts["engines.observed"]
        revealCatalog(observed, identifier: "engines.observed", in: list, upward: true)
        let before = observed.value as? String
        XCTAssertNotNil(before)
        // A drag from the top of the single page List triggers native pull to refresh.
        let start = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.20))
        let end = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.85))
        start.press(forDuration: 0.1, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.3)
        revealCatalog(observed, identifier: "engines.observed", in: list, upward: true)
        let refreshed = XCTNSPredicateExpectation(
            predicate: NSPredicate(format: "value != %@", before ?? ""), object: observed)
        XCTAssertEqual(XCTWaiter.wait(for: [refreshed], timeout: 5), .completed)
        XCTAssertTrue(observed.label.hasPrefix("Observed "))
        screenshot("engines-compact")
        revealCatalog(first, identifier: "engine.detail.default-001", in: list)
        first.tap()
        XCTAssertTrue(detail.waitForExistence(timeout: 3))
        reveal(request, in: detail)
        XCTAssertTrue(request.label.hasPrefix("engine.halt, Requested"), request.label)
        XCTAssertFalse(request.label.contains("Applied"))
        XCTAssertFalse(request.label.contains("Rejected"))
        app.navigationBars.buttons.firstMatch.tap()
        chooseCatalog("Sort", value: "Runner order")
        app.buttons["engines.sortMenu"].tap()
        app.buttons["Group by lifecycle"].tap()
        revealCatalog(app.buttons["engines.catalog.group.probing"], identifier: "engines.catalog.group.probing", in: list, upward: true)
        XCTAssertTrue(app.buttons["engines.catalog.group.probing"].exists)
    }

    private func chooseCatalog(_ picker: String, value: String) {
        app.buttons["engines.sortMenu"].tap()
        app.buttons[picker].tap()
        app.buttons[value].tap()
    }

    private func revealCatalog(_ target: XCUIElement, identifier: String, in list: XCUIElement, upward: Bool = false) {
        for _ in 0..<100 {
            let top = max(list.frame.minY, app.navigationBars.firstMatch.frame.maxY) + 8
            let bottom = min(list.frame.maxY, app.tabBars.firstMatch.frame.minY) - 80
            if target.exists && !target.frame.isEmpty && target.frame.minY >= top && target.frame.maxY <= bottom && target.isHittable { return }
            let above = target.exists && target.frame.maxY > 0 ? target.frame.minY < top : upward
            let start = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.30 : 0.70))
            let end = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.75 : 0.25))
            start.press(forDuration: 0.05, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.1)
        }
        XCTFail("Could not reach \(identifier) using the page List")
    }

    func testCatalogGroupsByLifecycleWithChipsMeterAndSample() {
        app.tabBars.buttons["Engines"].tap()
        let list = app.collectionViews["engines.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 3))
        let catalog = element("engines.catalog")
        XCTAssertTrue(catalog.waitForExistence(timeout: 3))
        let rows = app.collectionViews["engines.list"]

        let probing = element("engines.catalog.group.probing")
        reveal(probing, in: rows)
        XCTAssertTrue(probing.label.contains("1"), probing.label)
        let lifecycle = element("engine.lifecycle.aggressive")
        reveal(lifecycle, in: rows)
        XCTAssertEqual(lifecycle.label, "Probing")
        XCTAssertEqual(element("engine.account.aggressive").label, "Secondary subaccount (sample)")
        let breaker = element("engine.breaker.aggressive")
        reveal(breaker, in: rows)
        XCTAssertEqual(breaker.label, "Breaker: -$12.40 of $1,250.00 (50%) · UTC day")
        let sample = element("engine.perContract.aggressive")
        reveal(sample, in: rows)
        XCTAssertEqual(sample.label, "Live: +3.2c per contract · n 41 over 7 days")
        let probeDay = element("engine.probeDay.aggressive")
        reveal(probeDay, in: rows)
        XCTAssertTrue(probeDay.label.hasPrefix("Probe day 2026-09-23 (UTC): "), probeDay.label)
        XCTAssertTrue(probeDay.label.hasSuffix("41 tickets"), probeDay.label)
        screenshot("Engines catalog probing")

        let notStarted = element("engines.catalog.group.notStarted")
        reveal(notStarted, in: rows)
        XCTAssertEqual(notStarted.value as? String, "Collapsed")
        notStarted.tap()
        XCTAssertEqual(notStarted.value as? String, "Expanded")
        let unknown = element("engine.lifecycle.default")
        reveal(unknown, in: rows)
        XCTAssertEqual(unknown.label, "No lifecycle")
        XCTAssertEqual(element("engine.account.default").label, "Unassigned")
        let missingBreaker = element("engine.breaker.default")
        reveal(missingBreaker, in: rows)
        XCTAssertEqual(missingBreaker.label, "Breaker: Not reported")
        let missingSample = element("engine.perContract.default")
        reveal(missingSample, in: rows)
        XCTAssertEqual(missingSample.label, "Live: Not reported")
        XCTAssertFalse(element("engine.probeDay.default").exists)
        XCTAssertFalse(element("engines.catalog.group.retired").exists)
        screenshot("Engines catalog not started")

        let assignments = element("engines.assignments")
        reveal(assignments, in: list)
        XCTAssertTrue(element("engines.assignment.aggressive").label.contains("Secondary subaccount (sample)"))
        XCTAssertFalse(element("engines.assignment.default").exists)
        XCTAssertTrue(element("engines.assignments.unassigned").exists)
        XCTAssertFalse(app.staticTexts["Bindings"].exists)
        screenshot("Engines assignments")
    }

    func testEngineDetailHaltRejectedThenAppliedControlWalk() {
        app.tabBars.buttons["Engines"].tap()
        let list = app.collectionViews["engines.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 3))
        let rows = app.collectionViews["engines.list"]
        let row = app.buttons["engine.detail.aggressive"]
        reveal(row, in: rows)
        row.tap()

        let detail = app.collectionViews["engine.detail.list"]
        XCTAssertTrue(detail.waitForExistence(timeout: 3))
        XCTAssertEqual(element("engine.detail.lifecycle").label, "Probing")
        XCTAssertEqual(element("engine.detail.account").label, "Secondary subaccount (sample)")
        XCTAssertEqual(element("engine.detail.breaker").label, "Breaker: -$12.40 of $1,250.00 (50%) · UTC day")
        XCTAssertTrue(element("engine.detail.probeDay").label.contains("(UTC)"))
        XCTAssertEqual(element("engine.boundBooks.aggressive").label, "BTC-15M")
        screenshot("Engine detail summary")

        let unavailable = element("engine.detail.probeUnavailable")
        reveal(unavailable, in: detail)
        XCTAssertTrue(unavailable.label.contains("Already probing"), unavailable.label)
        XCTAssertFalse(app.buttons["engine.detail.probe"].exists)

        halt(in: detail)
        let first = element("engine.detail.request.fixture-request-1")
        reveal(first, in: detail)
        XCTAssertTrue(first.label.hasPrefix("engine.halt, Requested"), first.label)
        XCTAssertFalse(first.label.contains("Rejected"))
        refresh(in: detail)
        waitFor(first, contains: "Requested → Rejected: Sample rejection: the runner refused this change.")
        screenshot("Engine halt rejected")

        halt(in: detail)
        let second = element("engine.detail.request.fixture-request-2")
        reveal(second, in: detail)
        XCTAssertTrue(second.label.hasPrefix("engine.halt, Requested"), second.label)
        refresh(in: detail)
        waitFor(second, contains: "Requested → Applied")
        XCTAssertTrue(first.label.contains("Rejected"), first.label)
        screenshot("Engine halt applied")

        let timeline = element("engine.detail.timeline")
        reveal(timeline, in: detail)
        XCTAssertTrue(timeline.exists)
        let expiry = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label BEGINSWITH %@", "Probe expires")).firstMatch
        XCTAssertTrue(expiry.exists)
        XCTAssertTrue(expiry.label.hasSuffix("UTC"), expiry.label)
        let chart = element("engine.detail.chart")
        reveal(chart, in: detail)
        XCTAssertTrue(chart.exists)
        screenshot("Engine detail chart and lifecycle")
    }

    func testEnginesDetailAndHistoryOverhaul() {
        app.tabBars.buttons["Engines"].tap()
        let list = app.collectionViews["engines.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 3))
        let rows = app.collectionViews["engines.list"]
        XCTAssertTrue(rows.waitForExistence(timeout: 3))
        rows.swipeUp()
        rows.swipeDown()
        let notStarted = app.buttons["engines.catalog.group.notStarted"]
        reveal(notStarted, in: rows)
        notStarted.tap()
        let engine = app.buttons["engine.detail.default"]
        reveal(engine, in: rows)
        XCTAssertTrue(app.staticTexts["Accepting new entries"].firstMatch.exists)
        XCTAssertFalse(app.switches["engine.toggle.default"].isEnabled)
        let dials = app.staticTexts["engine.profitDials.default"]
        reveal(dials, in: rows)
        XCTAssertTrue(dials.exists)
        screenshot("Engines overhaul")

        reveal(engine, in: rows)
        engine.tap()
        let detail = app.collectionViews["engine.detail.list"]
        XCTAssertTrue(detail.waitForExistence(timeout: 3))
        let books = app.staticTexts["engine.boundBooks.default"]
        XCTAssertTrue(books.waitForExistence(timeout: 3))
        reveal(books, in: detail)
        XCTAssertEqual(books.label, "ETH-15M")
        screenshot("Engine detail overhaul")

        let performance = app.buttons["engine.performance.default"]
        reveal(performance, in: detail)
        performance.tap()
        let history = app.collectionViews["engine.history.list"]
        XCTAssertTrue(history.waitForExistence(timeout: 3))
        let pnl = app.descendants(matching: .any)["engine.history.pnl"].firstMatch
        XCTAssertTrue(pnl.waitForExistence(timeout: 3))
        reveal(pnl, in: history)
        XCTAssertTrue(app.staticTexts["Sample history"].exists)
        screenshot("Engine history overhaul")
    }

    func testProbeApprovalExplainsTheDashboardRoute() {
        app.tabBars.buttons["Engines"].tap()
        let list = app.collectionViews["engines.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 3))
        let engine = app.buttons["engine.detail.aggressive"]
        reveal(engine, in: list)
        engine.tap()
        let detail = app.collectionViews["engine.detail.list"]
        XCTAssertTrue(detail.waitForExistence(timeout: 3))
        let guidance = app.staticTexts["engine.detail.probe.dashboard"]
        reveal(guidance, in: detail)
        XCTAssertEqual(guidance.label, "Approve on the dashboard. The dashboard signs the single-use approval and starts the probe.")
        XCTAssertFalse(app.buttons["engine.detail.probe.confirm"].exists)
    }

    func testCompareAccountsLabelsCachedValuesWithTheirObservationAge() {
        app.tabBars.buttons["Engines"].tap()
        let engines = app.collectionViews["engines.list"]
        XCTAssertTrue(engines.waitForExistence(timeout: 3))
        let lab = app.buttons["engine.lab.open"]
        reveal(lab, in: engines)
        lab.tap()
        let labList = app.collectionViews["engine.lab.list"]
        XCTAssertTrue(labList.waitForExistence(timeout: 3))
        let engine = app.buttons["engine.lab.row.default"]
        reveal(engine, in: labList)
        engine.tap()
        let compare = app.buttons["engine.workshop.compare.default"]
        reveal(compare, in: app.collectionViews.firstMatch)
        compare.tap()
        let list = app.collectionViews["engine.workshop.compare.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 3))
        // Fixture configurations deliberately retain their original source dates; fetching them
        // at launch must not make old effective values look current.
        for scope in ["global", "sample-main", "sample-secondary"] {
            let observed = app.staticTexts["engine.workshop.compare.observed.cash_floor_cents.\(scope)"]
            reveal(observed, in: list)
            XCTAssertTrue(observed.label.hasPrefix("Observed "), observed.label)
            XCTAssertTrue(observed.label.contains("Delayed or unknown telemetry"), observed.label)
        }
    }

    private func element(_ id: String) -> XCUIElement {
        app.descendants(matching: .any)[id].firstMatch
    }

    /// Opens the Halt confirm, checks its exact sentence and confirms; the sheet closes on a sent request.
    private func halt(in detail: XCUIElement) {
        let button = app.buttons["engine.detail.halt"]
        reveal(button, in: detail)
        XCTAssertTrue(button.isEnabled)
        button.tap()
        let message = app.staticTexts["engine.detail.halt.message"]
        XCTAssertTrue(message.waitForExistence(timeout: 3))
        XCTAssertEqual(message.label, "Stops new entries. Open contracts settle normally.")
        let confirm = app.buttons["engine.detail.halt.confirm"]
        XCTAssertTrue(confirm.isEnabled)
        confirm.tap()
        XCTAssertTrue(confirm.waitForNonExistence(timeout: 5))
    }

    /// In the fixture walk a refresh settles requested lifecycle requests, as a dashboard poll would.
    private func refresh(in detail: XCUIElement) {
        let button = app.buttons["engine.detail.refresh"]
        reveal(button, in: detail)
        button.tap()
    }

    private func waitFor(_ element: XCUIElement, contains text: String) {
        let predicate = NSPredicate(format: "label CONTAINS %@", text)
        let expectation = XCTNSPredicateExpectation(predicate: predicate, object: element)
        XCTAssertEqual(XCTWaiter().wait(for: [expectation], timeout: 5), .completed,
                       "\(element.identifier) label was \(element.label)")
    }

    private func reveal(_ element: XCUIElement, in list: XCUIElement) {
        for _ in 0..<35 {
            let top = max(app.navigationBars.firstMatch.frame.maxY + 8, list.frame.minY)
            let bottom = min((app.tabBars.firstMatch.exists ? app.tabBars.firstMatch.frame.minY : app.frame.maxY) - 8,
                             list.frame.maxY)
            if element.exists && !element.frame.isEmpty &&
                element.frame.minY >= top && element.frame.maxY <= bottom && element.isHittable { return }
            let above = element.exists && element.frame.maxY > 0 && element.frame.minY < top
            let start = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.35 : 0.70))
            let end = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.55 : 0.50))
            start.press(forDuration: 0.05, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        XCTFail("Could not fully reveal \(element.identifier)")
    }

    private func screenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
