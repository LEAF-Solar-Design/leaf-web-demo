import XCTest

final class EngineHistoryUITests: XCTestCase {
    func testHistoryAccountFilterAndEngineSettings() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-kashbot.engines.rowDetail", "detailed",
            "-kashbot.engines.grouped", "YES", "-kashbot.engines.sort", "runner", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        app.buttons["engine.history.open"].tap()
        XCTAssertTrue(app.staticTexts["Sample history"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.descendants(matching: .any)["engine.history.pnl"].firstMatch.label.contains("3.00"))
        app.buttons["engine.history.account"].tap()
        app.buttons["Main subaccount (sample)"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["engine.history.pnl"].firstMatch.label.contains("3.50"))
        let overview = XCTAttachment(screenshot: app.screenshot())
        overview.name = "Engine account performance"
        overview.lifetime = .keepAlways
        add(overview)
        let chart = app.descendants(matching: .any)["engine.history.chart"].firstMatch
        revealFully(chart, in: app)
        let historyChart = XCTAttachment(screenshot: app.screenshot())
        historyChart.name = "Engine daily history"
        historyChart.lifetime = .keepAlways
        add(historyChart)
        let accounts = app.descendants(matching: .any)["engine.history.accounts"].firstMatch
        revealFully(accounts, in: app)
        XCTAssertTrue(accounts.exists)
        app.navigationBars.buttons.firstMatch.tap()
        // The catalog groups by lifecycle, so Default can sit below the probing rows.
        let rows = app.collectionViews["engines.list"]
        XCTAssertTrue(rows.waitForExistence(timeout: 3))
        let notStarted = app.buttons["engines.catalog.group.notStarted"]
        reveal(notStarted, in: rows, app: app)
        notStarted.tap()
        let engine = app.buttons["engine.detail.default"]
        reveal(engine, in: rows, app: app)
        engine.tap()
        let detail = app.collectionViews["engine.detail.list"]
        XCTAssertTrue(detail.waitForExistence(timeout: 3))
        let performance = app.buttons["engine.performance.default"]
        reveal(performance, in: detail, app: app)
        performance.tap()
        app.buttons["engine.history.settings"].tap()
        // The preview warning now lives in the collapsed Scope details section.
        let form = app.collectionViews["engine.settings.form"]
        XCTAssertTrue(form.waitForExistence(timeout: 3))
        let scopeDetails = app.buttons["engine.settings.prerequisiteDetails"]
        revealAboveBar(scopeDetails, in: app)
        scopeDetails.tap()
        revealAboveBar(app.staticTexts["Preview data. Saving is disabled."], in: app)
        XCTAssertTrue(app.staticTexts["Preview data. Saving is disabled."].waitForExistence(timeout: 2))
        reveal(scopeDetails, in: form, app: app)
        revealAboveBar(scopeDetails, in: app)
        scopeDetails.tap()
        let scope = app.buttons["engine.settings.scopePicker"]
        reveal(scope, in: form, app: app)
        XCTAssertTrue(scope.waitForExistence(timeout: 2))
        scope.tap()
        app.buttons["Main subaccount (sample)"].tap()
        XCTAssertTrue(app.buttons["engine.settings.enabledInherited"].waitForExistence(timeout: 2))
        XCTAssertTrue(app.descendants(matching: .any)["engine.settings.enabledEffective"].firstMatch.exists)
        let search = app.textFields["engine.settings.search"]
        revealAboveBar(search, in: app)
        search.tap()
        search.typeText("Minimum edge\n")
        XCTAssertTrue(app.buttons["engine.settings.help.edge_threshold_cents"].waitForExistence(timeout: 2))
        XCTAssertTrue(app.descendants(matching: .any)["engine.settings.source.edge_threshold_cents"].firstMatch.exists)
        let save = app.buttons["engine.settings.save"]
        revealAboveBar(save, in: app)
        XCTAssertFalse(save.isEnabled)
        revealFully(save, in: app)
        let settings = XCTAttachment(screenshot: app.screenshot())
        settings.name = "Engine settings"
        settings.lifetime = .keepAlways
        add(settings)
    }

    /// Walk w3 F12: one tap on a By engine row pushed every engine. The second row must open only its own engine.
    func testByEngineSecondRowOpensOnlyThatEngine() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        app.buttons["engine.history.open"].tap()
        XCTAssertTrue(app.staticTexts["Sample history"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.navigationBars["Performance"].waitForExistence(timeout: 3))
        // Rows are sorted by engine id: aggressive first, default second.
        let first = app.buttons["engine.history.detail.aggressive"]
        let second = app.buttons["engine.history.detail.default"]
        revealFully(second, in: app)
        XCTAssertTrue(first.exists)
        second.tap()
        XCTAssertTrue(app.navigationBars["Default"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.navigationBars["Aggressive"].exists)
        XCTAssertFalse(app.navigationBars["Performance"].exists)
        // Default alone realized $2.50 in the sample week; the all-engines total is $3.00.
        let pnl = app.descendants(matching: .any)["engine.history.pnl"].firstMatch
        expectation(for: NSPredicate(format: "label CONTAINS %@", "2.50"), evaluatedWith: pnl)
        waitForExpectations(timeout: 3)
        let detail = XCTAttachment(screenshot: app.screenshot())
        detail.name = "By engine second row detail"
        detail.lifetime = .keepAlways
        add(detail)
        app.navigationBars["Default"].buttons.firstMatch.tap()
        XCTAssertTrue(app.navigationBars["Performance"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.navigationBars["Default"].exists)
        XCTAssertFalse(app.navigationBars["Aggressive"].exists)
        // Back on the all-engines screen: the By engine rows show again (the view reloads on appear,
        // so its scroll position may reset; revealFully scrolls to the row either way).
        revealFully(second, in: app)
        XCTAssertTrue(first.exists)
    }

    func testCoverageCaveatIsDirectlyBelowHero() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        app.buttons["engine.history.open"].tap()
        let caveat = app.staticTexts["engine.history.coverageCaveat"]
        XCTAssertTrue(caveat.waitForExistence(timeout: 3))
        let pnl = app.descendants(matching: .any)["engine.history.pnl"].firstMatch
        XCTAssertEqual(caveat.label, "Period coverage: 1 unassigned ticket; history may be incomplete.")
        XCTAssertGreaterThanOrEqual(caveat.frame.minY, pnl.frame.maxY)
        XCTAssertLessThan(caveat.frame.minY - pnl.frame.maxY, 30)
        XCTAssertTrue(caveat.isHittable)
    }

    func testEmptyAccountHasCompactMessageWithoutTableHeadings() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        app.buttons["engine.history.open"].tap()
        XCTAssertTrue(app.staticTexts["Sample history"].waitForExistence(timeout: 3))
        let aggressive = app.buttons["engine.history.detail.aggressive"]
        revealFully(aggressive, in: app)
        aggressive.tap()
        XCTAssertTrue(app.navigationBars["Aggressive"].waitForExistence(timeout: 3))
        let picker = app.buttons["engine.history.account"]
        XCTAssertTrue(picker.waitForExistence(timeout: 3))
        picker.tap()
        app.buttons["Main subaccount (sample)"].tap()
        let empty = app.staticTexts["engine.history.accounts.empty"]
        revealFully(empty, in: app)
        XCTAssertEqual(empty.label, "No account-attributed results for this period")
        let accounts = app.descendants(matching: .any)["engine.history.accounts"].firstMatch
        XCTAssertFalse(accounts.staticTexts["Account"].exists)
        XCTAssertFalse(accounts.staticTexts["Realized P&L"].exists)
        XCTAssertFalse(accounts.staticTexts["Engine"].exists)
        XCTAssertFalse(accounts.staticTexts["Activity"].exists)
        XCTAssertFalse(app.scrollViews["engine.history.accounts"].exists)
    }

    /// Scrolls `list` until `element` is hittable and clear of the navigation and tab bars.
    private func reveal(_ element: XCUIElement, in list: XCUIElement, app: XCUIApplication) {
        for _ in 0..<35 {
            let top = max(app.navigationBars.firstMatch.frame.maxY + 8, list.frame.minY)
            let bottom = min((app.tabBars.firstMatch.exists ? app.tabBars.firstMatch.frame.minY : app.frame.maxY) - 8,
                             list.frame.maxY)
            if element.exists && element.isHittable &&
                element.frame.minY >= top && element.frame.maxY <= bottom { return }
            let above = element.exists && element.frame.maxY > 0 && element.frame.minY < top
            let start = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.35 : 0.70))
            let end = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.55 : 0.50))
            start.press(forDuration: 0.05, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        XCTFail("Could not fully reveal \(element.identifier)")
    }

    /// Elements under the sticky action bar still report hittable, so a tap or drag would land on the bar.
    private func clearOfActionBar(_ element: XCUIElement, in app: XCUIApplication) -> Bool {
        let bar = app.descendants(matching: .any)["engine.settings.actionBar"].firstMatch
        guard bar.exists, element.exists else { return true }
        let id = element.identifier
        if !id.isEmpty, bar.descendants(matching: .any).matching(identifier: id).firstMatch.exists { return true } // lives in the bar
        return element.frame.maxY <= bar.frame.minY - 4
    }

    private func revealAboveBar(_ element: XCUIElement, in app: XCUIApplication) {
        let form = app.collectionViews["engine.settings.form"]
        for _ in 0..<35 {
            if element.exists && element.isHittable && clearOfActionBar(element, in: app) { break }
            let start = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.60))
            let end = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.20))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        guard element.exists && element.isHittable && clearOfActionBar(element, in: app) else {
            XCTFail("Could not reach \(element.identifier)")
            return
        }
        let bar = app.descendants(matching: .any)["engine.settings.actionBar"].firstMatch
        let id = element.identifier
        if !bar.exists { return }
        if !id.isEmpty, bar.descendants(matching: .any).matching(identifier: id).firstMatch.exists { return } // lives in the bar
        for _ in 0..<12 {
            if element.frame.maxY < bar.frame.minY - 12 && element.frame.minY > app.navigationBars.firstMatch.frame.maxY { return }
            let start = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.60))
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: -160)), withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        XCTFail("Could not place \(element.identifier) above the action bar")
    }

    private func revealFully(_ element: XCUIElement, in app: XCUIApplication) {
        for _ in 0..<10 {
            let bottom = app.tabBars.firstMatch.frame.minY - 12
            if element.exists && element.frame.maxY < bottom { break }
            let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.72))
            let end = app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.50))
            start.press(forDuration: 0.05, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        XCTAssertTrue(element.exists)
        XCTAssertLessThan(element.frame.maxY, app.tabBars.firstMatch.frame.minY - 8)
        XCTAssertGreaterThan(element.frame.minY, app.navigationBars.firstMatch.frame.maxY)
    }
}
