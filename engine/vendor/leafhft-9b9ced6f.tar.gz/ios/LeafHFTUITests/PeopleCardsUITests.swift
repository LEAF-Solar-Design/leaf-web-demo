import XCTest

/// Replay: launch fixtures, open Lab, People preview, then scroll through Person 1, 2 and 3.
final class PeopleCardsUITests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        let appearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] ?? "light"
        XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", appearance,
            "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
    }

    private func reveal(_ element: XCUIElement, in list: XCUIElement, identifier: String? = nil,
                        towardTop: Bool = false) {
        var missingScrolls = towardTop ? 0 : 10
        func visibleBounds(for frame: CGRect) -> (top: CGFloat, bottom: CGFloat) {
            let top = max(app.navigationBars.firstMatch.frame.maxY, list.frame.minY)
            var bottom = min(app.tabBars.firstMatch.exists ? app.tabBars.firstMatch.frame.minY : app.frame.maxY,
                             list.frame.maxY) - 8
            let launcher = app.buttons["studio.launcher"]
            if launcher.exists && frame.maxX > launcher.frame.minX && frame.minX < launcher.frame.maxX {
                bottom = min(bottom, launcher.frame.minY - 8)
            }
            return (top, bottom)
        }
        for _ in 0..<60 {
            let frame = element.exists ? element.frame : .zero
            let (top, bottom) = visibleBounds(for: frame)
            if element.exists && element.isHittable && element.frame.minY >= top && element.frame.maxY < bottom { return }
            // Lazy lists can remove earlier rows from the accessibility tree.
            // Start in the requested direction, then reverse if the row is still missing.
            let above: Bool
            if element.exists {
                missingScrolls = towardTop ? 0 : 10
                above = element.frame.maxY > 0 && element.frame.minY < top
            } else {
                above = (missingScrolls / 10) % 2 == 0
                missingScrolls += 1
            }
            // The trailing column is covered by the floating assistant launcher.
            let start = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.35 : 0.70))
            let end = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.55 : 0.50))
            start.press(forDuration: 0.05, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.2)
            let movedFrame = element.exists ? element.frame : .zero
            if movedFrame == frame {
                if above { list.swipeDown(velocity: .slow) }
                else { list.swipeUp(velocity: .slow) }
            }
        }
        let exists = element.exists
        let frame = exists ? element.frame : .zero
        let (top, bottom) = visibleBounds(for: frame)
        let hittable = exists && element.isHittable
        if hittable && frame.minY >= top && frame.maxY < bottom { return }
        let requestedIdentifier = identifier ?? (exists ? element.identifier : "(missing element)")
        XCTFail("People preview element \(requestedIdentifier) was not visible within 60 scrolls: " +
                "exists=\(exists), isHittable=\(hittable), frame=\(frame), " +
                "top=\(top), bottom=\(bottom), listFrame=\(list.frame)")
    }

    private func assertText(_ id: String, _ expected: String, in list: XCUIElement, towardTop: Bool = false) {
        let element = app.staticTexts[id]
        reveal(element, in: list, identifier: id, towardTop: towardTop)
        XCTAssertEqual(element.label, expected, id)
        XCTAssertTrue(element.isHittable, id)
    }

    private func screenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "People preview " + name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    func testPeopleEvidenceExpiresWhileScreenRemainsOpen() {
        app.terminate()
        app.launchArguments.append("-LEAFHFT_PEOPLE_ADVANCE_TIME")
        app.launch()
        app.tabBars.buttons["Lab"].tap()
        let lab = app.collectionViews["engine.lab.list"]
        XCTAssertTrue(lab.waitForExistence(timeout: 5))
        let preview = app.buttons["engine.lab.peoplePreview"]
        reveal(preview, in: lab)
        preview.tap()
        let list = app.collectionViews["people.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 5))
        assertText("people.verdict.p1", "Trading", in: list)
        assertText("people.verdict.p2", "Blocked", in: list)
        assertText("people.refusal.p2", "Refusal: Synthetic cash unavailable", in: list)

        // The DEBUG fixture clock advances past both expiry windows after 30 seconds.
        let refusal = app.staticTexts["people.refusal.p2"]
        let expired = XCTNSPredicateExpectation(
            predicate: NSPredicate(format: "label == %@", "Refusal: unknown"), object: refusal)
        XCTAssertEqual(XCTWaiter.wait(for: [expired], timeout: 45), .completed)
        assertText("people.verdict.p2", "Unknown", in: list)
        assertText("people.verdict.p1", "Unknown", in: list, towardTop: true)
        assertText("people.verdict.p3", "Off", in: list)
        screenshot("expired evidence")
    }

    func testFixturePeopleVerdictsAndMissingEvidence() {
        app.tabBars.buttons["Lab"].tap()
        let lab = app.collectionViews["engine.lab.list"]
        XCTAssertTrue(lab.waitForExistence(timeout: 5))
        let preview = app.buttons["engine.lab.peoplePreview"]
        reveal(preview, in: lab)
        preview.tap()
        XCTAssertTrue(app.navigationBars["People preview"].waitForExistence(timeout: 5))
        let list = app.collectionViews["people.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 5))
        assertText("people.fixture", "Fixture data, not live accounts", in: list)
        screenshot("fixture label")
        for (id, verdict) in [("p1", "Trading"), ("p2", "Blocked"), ("p3", "Off")] {
            assertText("people.verdict.\(id)", verdict, in: list)
            screenshot(id + " " + verdict)
        }
        assertText("people.refusal.p3", "Refusal: unknown", in: list)
        assertText("people.cash.p3", "Current cash: no data", in: list)
        assertText("people.performance.p3.e3", "Reported realized P&L: no data", in: list)
        assertText("people.projection.p3.e3", "Daily projection: not estimable", in: list)
        screenshot("missing data")
    }
}
