import XCTest

final class AccountUITests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        let appearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] ?? "light"
        XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", appearance,
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
    }

    private func reveal(_ element: XCUIElement, in scroll: XCUIElement, limit: Int = 35) {
        for _ in 0..<limit {
            if element.exists && element.isHittable { return }
            let x = scroll.identifier == "account.scroll" ? 0.98 : 0.5
            let start = scroll.coordinate(withNormalizedOffset: CGVector(dx: x, dy: 0.85))
            let end = scroll.coordinate(withNormalizedOffset: CGVector(dx: x, dy: 0.20))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        XCTFail("Could not reach \(element.identifier)")
    }

    private func screenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    private func revealForScreenshot(_ element: XCUIElement, in scroll: XCUIElement) {
        var previousFrame: CGRect?
        var stalledSteps = 0
        for _ in 0..<20 {
            guard element.exists else { XCTFail("Screenshot target is missing"); return }
            let viewport = scroll.frame.intersection(app.frame)
            let top = viewport.minY + 8
            // Keep the whole section above the floating Studio launcher as well as the tabs.
            let bottom = min(viewport.maxY - 8, app.tabBars.firstMatch.frame.minY - 96)
            let frame = element.frame
            guard bottom - top > 48, frame.height > 0, frame.height <= bottom - top else {
                XCTFail("Screenshot target does not fit above the Studio launcher and tabs")
                return
            }
            if frame.minY >= top && frame.maxY <= bottom { return }
            if let previousFrame = previousFrame,
               abs(frame.minY - previousFrame.minY) < 1,
               abs(frame.maxY - previousFrame.maxY) < 1 {
                stalledSteps += 1
            } else {
                stalledSteps = 0
            }
            if stalledSteps >= 2 { break }
            previousFrame = frame

            let margin = min(8, (bottom - top - frame.height) / 2)
            let correction = frame.maxY > bottom
                ? bottom - frame.maxY - margin
                : top - frame.minY + margin
            let distance = max(-(bottom - top - 48), min(bottom - top - 48, correction))
            // Both endpoints stay inside the scroll view; use its edge to avoid card controls.
            let startY = distance < 0 ? bottom - 24 : top + 24
            let start = app.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: viewport.maxX - app.frame.minX - 8,
                                     dy: startY - app.frame.minY))
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: distance)),
                        withVelocity: .slow, thenHoldForDuration: 0.5)
        }
        let viewport = scroll.frame.intersection(app.frame)
        let top = viewport.minY + 8
        // At the end of content, accept the whole section above the tabs even if the launcher overlaps.
        let bottom = min(viewport.maxY - 8,
                         app.tabBars.firstMatch.frame.minY - (stalledSteps >= 2 ? 8 : 96))
        let frame = element.frame
        if element.exists && frame.height > 0 && frame.minY >= top && frame.maxY <= bottom { return }
        XCTFail("Could not fully reveal screenshot target: frame=\(frame), band=\(top)...\(bottom), stalledSteps=\(stalledSteps)")
    }

    func testNeedsYouCardLinksToWaitingWork() {
        for appearance in ["light", "dark"] {
            app.terminate()
            XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
            app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", appearance,
                                   "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
            app.launch()

            let scroll = app.descendants(matching: .any)["account.scroll"].firstMatch
            XCTAssertTrue(scroll.waitForExistence(timeout: 5))
            let card = app.descendants(matching: .any)["monitor.needsYou"].firstMatch
            XCTAssertTrue(card.waitForExistence(timeout: 5))
            let assistant = app.buttons["monitor.needsYou.assistant"].firstMatch
            XCTAssertTrue(assistant.waitForExistence(timeout: 5))
            XCTAssertEqual(assistant.label, "5 assistant cards unread")
            revealForScreenshot(card, in: scroll)
            screenshot("Needs you - \(appearance)")

            // TuningPendingCache currently returns nil in fixtures; exercise the link if supplied.
            let tuning = app.buttons["monitor.needsYou.tuning"].firstMatch
            if tuning.exists {
                reveal(tuning, in: scroll)
                tuning.tap()
                XCTAssertTrue(app.descendants(matching: .any)["autopilot.scroll"].firstMatch
                    .waitForExistence(timeout: 5))
                XCTAssertTrue(app.navigationBars["Engine autopilot"].waitForExistence(timeout: 3))
                let back = app.navigationBars.buttons["Monitor"].firstMatch
                XCTAssertTrue(back.waitForExistence(timeout: 3))
                back.tap()
                XCTAssertTrue(scroll.waitForExistence(timeout: 3))
            }

            reveal(assistant, in: scroll)
            assistant.tap()
            XCTAssertTrue(app.descendants(matching: .any)["assistant.inbox.scroll"].firstMatch
                .waitForExistence(timeout: 5))
            XCTAssertTrue(app.navigationBars["Assistant inbox"].waitForExistence(timeout: 3))
            // The pushed screen must remain after its refresh marks the unread cards seen.
            let badge = app.descendants(matching: .any)["assistant.launcher.badge"].firstMatch
            let seen = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: badge)
            XCTAssertEqual(XCTWaiter.wait(for: [seen], timeout: 5), .completed)
            XCTAssertTrue(app.descendants(matching: .any)["assistant.inbox.scroll"].firstMatch.exists)
        }
    }

    func testAccountOverhaul() {
        let scroll = app.descendants(matching: .any)["account.scroll"].firstMatch
        XCTAssertTrue(scroll.waitForExistence(timeout: 3))
        let money = app.descendants(matching: .any)["monitor.money"].firstMatch
        XCTAssertTrue(money.waitForExistence(timeout: 3))
        let pnl = app.descendants(matching: .any)["account.tile.pnl"].firstMatch
        XCTAssertTrue(pnl.waitForExistence(timeout: 3))
        let loaded = XCTNSPredicateExpectation(
            predicate: NSPredicate(format: "label CONTAINS %@", "$"), object: pnl)
        XCTAssertEqual(XCTWaiter.wait(for: [loaded], timeout: 3), .completed)
        XCTAssertTrue(pnl.label.contains("$"))
        let chart = app.otherElements["account.chart"]
        XCTAssertTrue(chart.waitForExistence(timeout: 3))
        screenshot("Account performance")

        let ranges = app.buttons["account.range"]
        reveal(ranges, in: scroll)
        XCTAssertFalse(app.segmentedControls["account.range"].exists)
        for (label, range) in [("1h", "hour"), ("4h", "fourHours"), ("12h", "twelveHours"),
                               ("1d", "day"), ("7d", "week"), ("30d", "month"), ("All", "all")] {
            ranges.tap()
            let button = app.buttons[label].firstMatch
            XCTAssertTrue(button.waitForExistence(timeout: 2))
            button.tap()
            let updated = XCTNSPredicateExpectation(
                predicate: NSPredicate(format: "value BEGINSWITH %@", "\(range):"), object: chart)
            XCTAssertEqual(XCTWaiter.wait(for: [updated], timeout: 2), .completed)
        }

        let openOrders = app.descendants(matching: .any)["account.openOrders"].firstMatch
        reveal(openOrders, in: scroll)
        XCTAssertTrue(openOrders.exists)
        XCTAssertTrue(app.staticTexts["No open orders"].exists)

        let closedPositions = app.descendants(matching: .any)["account.closedPositions"].firstMatch
        reveal(closedPositions, in: scroll)
        XCTAssertTrue(closedPositions.exists)
        let closedTicker = app.staticTexts["FIXTURE-T"].firstMatch
        XCTAssertTrue(closedTicker.waitForExistence(timeout: 2))
        closedTicker.tap()
        let trade = app.descendants(matching: .any)["account.closed.0.trade.0"].firstMatch
        XCTAssertTrue(trade.waitForExistence(timeout: 2))
        let engine = app.descendants(matching: .any)["account.closed.0.trade.0.engine"].firstMatch
        XCTAssertTrue(engine.waitForExistence(timeout: 2))
        XCTAssertTrue(engine.label.contains("fixture-engine"))
        revealForScreenshot(closedPositions, in: scroll)
        screenshot("Closed position trades")

        // The probe board is mounted; the orphaned shadow and evidence views and the dead cards are gone.
        XCTAssertTrue(app.descendants(matching: .any)["probes.board"].firstMatch.exists)
        for identifier in ["monitor.alive", "monitor.shadow", "monitor.evidence", "account.positions",
                           "account.runnerSummary", "account.fills"] {
            XCTAssertFalse(app.descendants(matching: .any)[identifier].firstMatch.exists)
        }
    }
}
