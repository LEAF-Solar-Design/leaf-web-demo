import XCTest
import UIKit

/// Ops overhaul fixture proof. Page gestures only position a box; row traversal stays inside it.
final class OpsLayoutUITests: XCTestCase {
    private var app: XCUIApplication!
    private var appearance = "light"

    // Point budgets from the owning views, independent of Dynamic Type.
    // monitor.shadow identifies the card; monitor.shadowList is its bounded viewport.
    private let caps: [String: CGFloat] = [
        "monitor.openTable": 148, "monitor.fillsList": 220, "monitor.shadow": 330,
        "books.rows": 420, "books.openTable": 148,
        "engines.paper.rows": 300
    ]

    override func setUpWithError() throws {
        continueAfterFailure = false
        appearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] ?? "light"
        XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-kashbot.engines.rowDetail", "detailed",
            "-kashbot.engines.grouped", "YES", "-kashbot.engines.sort", "runner", "-LEAFHFT_CONTROL_WALK", "1",
                               "-LEAFHFT_APPEARANCE", appearance,
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
    }

    private func element(_ id: String) -> XCUIElement {
        app.descendants(matching: .any)[id].firstMatch
    }

    private var window: CGRect { app.windows.firstMatch.frame }

    private func viewport(of page: XCUIElement) -> CGRect {
        var frame = page.frame.intersection(window)
        let navigation = app.navigationBars.firstMatch
        if navigation.exists && !navigation.frame.isEmpty && navigation.frame.intersects(window) && navigation.isHittable {
            let top = max(frame.minY, navigation.frame.maxY)
            frame = CGRect(x: frame.minX, y: top, width: frame.width, height: max(0, frame.maxY - top))
        }
        for overlay in [app.tabBars.firstMatch, element("engine.settings.actionBar")] {
            if overlay.exists && overlay.frame.intersects(frame) {
                frame.size.height = max(0, overlay.frame.minY - frame.minY)
            }
        }
        return frame.insetBy(dx: 2, dy: 6)
    }

    /// Use the page gutter, outside the inset bounded content, to position a viewport.
    @discardableResult
    private func position(_ target: XCUIElement, on page: XCUIElement,
                          identifier: String? = nil) -> XCUICoordinate {
        XCTAssertTrue(page.waitForExistence(timeout: 5))
        func scrollSignature() -> [CGRect] {
            let cell = page.cells.firstMatch
            let anchor = cell.exists ? cell : page.descendants(matching: .any).element(boundBy: 0)
            return [anchor.exists ? anchor.frame : .null, target.exists ? target.frame : .null]
        }
        var stalledDrags = 0
        var previousAbove: Bool?
        for _ in 0..<120 {
            let visible = viewport(of: page)
            let exists = target.exists
            let frame = exists ? target.frame : CGRect.null
            let tall = exists && frame.height > visible.height
            if exists && !frame.isEmpty && frame.intersects(visible) && (tall || target.isHittable) {
                let part = visible.intersection(frame)
                let requiredHeight = tall ? visible.height * 0.6 : frame.height
                if !part.isNull && !part.isEmpty && part.height >= requiredHeight {
                    return app.coordinate(withNormalizedOffset: .zero)
                        .withOffset(CGVector(dx: part.midX, dy: part.midY))
                }
            }
            let dragDown: Bool
            if !exists || frame.minY >= visible.maxY {
                dragDown = false
            } else if frame.maxY <= visible.minY {
                dragDown = true
            } else {
                dragDown = frame.minY < visible.minY
            }
            let above = dragDown
            if previousAbove != above { stalledDrags = 0 }
            previousAbove = above
            let before = scrollSignature()
            let travel = max(100, visible.height * 0.5)
            var distance = travel
            if exists && !tall && frame.intersects(visible) {
                if frame.maxY > visible.maxY {
                    distance = min(frame.maxY - visible.maxY + 8, frame.minY - visible.minY)
                } else if frame.minY < visible.minY {
                    distance = min(visible.minY - frame.minY + 8, visible.maxY - frame.maxY)
                }
                distance = min(travel, max(24, distance))
            }
            let start = app.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: visible.minX + 2, dy: visible.midY))
            start.press(forDuration: 0,
                        thenDragTo: start.withOffset(CGVector(dx: 0, dy: dragDown ? distance : -distance)),
                        withVelocity: .slow, thenHoldForDuration: 0.2)
            stalledDrags = scrollSignature() == before ? stalledDrags + 1 : 0
            if stalledDrags >= 4 { break }
        }
        let exists = target.exists
        let frame = exists ? target.frame : CGRect.null
        let name = identifier ?? (exists ? target.identifier : "missing target")
        XCTFail("Could not position a visible portion of \(name) in the page viewport: exists=\(exists), frame=\(frame), viewport=\(viewport(of: page)), page frame=\(page.frame)")
        return app.coordinate(withNormalizedOffset: .zero)
    }

    private func assertBounds(_ container: XCUIElement, cap: CGFloat) {
        XCTAssertTrue(container.exists)
        XCTAssertGreaterThan(container.frame.height, 0)
        XCTAssertLessThanOrEqual(container.frame.height, cap + 2, container.identifier)
        XCTAssertGreaterThanOrEqual(container.frame.minX, window.minX, container.identifier)
        XCTAssertLessThanOrEqual(container.frame.maxX - window.minX, window.width,
                                 "Horizontal page overflow: \(container.identifier)")
    }

    @discardableResult
    private func check(_ id: String, on page: XCUIElement,
                       lastRow: (XCUIElement) -> XCUIElement) -> XCUIElement {
        let container = app.scrollViews[id == "monitor.shadow" ? "monitor.shadowList" : id].firstMatch
        position(container, on: page, identifier: id)
        assertBounds(container, cap: caps[id]!)
        if id == "monitor.shadow" {
            XCTAssertTrue(element(id).exists)
            XCTAssertLessThanOrEqual(element(id).frame.maxX, window.maxX)
        }
        let origin = container.frame.origin
        var reached = false
        for attempt in 0...40 {
            XCTAssertTrue(page.exists,
                          "Inner row traversal navigated away from the page: \(id)")
            let row = lastRow(container)
            let visibleRow = row.exists ? container.frame.intersection(row.frame) : .null
            // At AX sizes a book's navigation button can be taller than its viewport.
            // Its final row must still have a visible, tappable portion inside the box.
            let fits = row.exists && (container.frame.contains(row.frame) ||
                (row.frame.height > container.frame.height && visibleRow.height >= 44 && !visibleRow.isNull))
            if row.exists && !row.frame.isEmpty && fits &&
                visibleRow.intersects(viewport(of: page)) && row.isHittable {
                reached = true
                break
            }
            if attempt == 40 { break }
            var band = container.frame.intersection(viewport(of: page))
            if band.isNull || band.height < 60 {
                position(container, on: page, identifier: id)
                band = container.frame.intersection(viewport(of: page))
            }
            XCTAssertFalse(band.isNull, "No visible traversal band for \(id)")
            XCTAssertGreaterThanOrEqual(band.height, 60, "Traversal band is too short for \(id)")
            let panDistance = max(120, band.height * 0.8)
            let start = app.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: container.frame.minX + container.frame.width * 0.35,
                                     dy: band.maxY - band.height * 0.1))
            start.press(forDuration: 0,
                        thenDragTo: start.withOffset(CGVector(dx: 0, dy: -panDistance)),
                        withVelocity: .slow, thenHoldForDuration: 0)
        }
        XCTAssertTrue(reached, "Last fixture row was not reachable inside \(id) after 40 drags")
        let finalRow = lastRow(container)
        let overflows = finalRow.frame.minY < container.frame.minY ||
            finalRow.frame.maxY > container.frame.maxY
        if overflows {
            XCTAssertEqual(container.frame.minY, origin.y, accuracy: 24,
                           "Inner row traversal moved the page: \(id)")
            XCTAssertEqual(container.frame.minX, origin.x, accuracy: 2)
        } else {
            print("Skipping page-offset assertion for \(id): last row is inside the non-overflowing container")
        }
        assertBounds(container, cap: caps[id]!)
        return container
    }

    private func fixture(_ name: String) throws -> [String: Any] {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: name, withExtension: "json",
                                                         subdirectory: "Fixtures"))
        return try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
    }

    private var contentSize: String {
        switch UIApplication.shared.preferredContentSizeCategory {
        case .extraSmall: return "extra-small"
        case .small: return "small"
        case .medium: return "medium"
        case .large: return "large"
        case .extraLarge: return "extra-large"
        case .extraExtraLarge: return "extra-extra-large"
        case .extraExtraExtraLarge: return "extra-extra-extra-large"
        case .accessibilityMedium: return "accessibility-medium"
        case .accessibilityLarge: return "accessibility-large"
        case .accessibilityExtraLarge: return "accessibility-extra-large"
        case .accessibilityExtraExtraLarge: return "accessibility-extra-extra-large"
        case .accessibilityExtraExtraExtraLarge: return "accessibility-extra-extra-extra-large"
        default: return "unspecified"
        }
    }

    private func screenshot(_ screen: String) {
        let rendered = app.staticTexts["fixture.renderedAppearance"]
        XCTAssertTrue(rendered.waitForExistence(timeout: 3))
        XCTAssertEqual(rendered.value as? String, appearance)
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "\(screen) layout \(appearance) \(contentSize)"
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    func testMonitorLayout() throws {
        let page = element("account.scroll")
        XCTAssertTrue(page.waitForExistence(timeout: 5))
        let sections: [(id: String, name: String, boundedID: String?, cap: CGFloat)] = [
            ("monitor.accounts", "Monitor accounts", "monitor.accounts", viewport(of: page).height),
            ("monitor.money", "Monitor account P L", "account.chart", 220),
            ("probes.board", "Monitor probe board", "probes.list", 320),
            ("account.openOrders", "Monitor open orders", nil, 0),
            ("account.closedPositions", "Monitor closed positions", "monitor.closedPositions", 520)
        ]
        for section in sections {
            let card = element(section.id)
            position(card, on: page, identifier: section.id)
            XCTAssertGreaterThan(card.frame.height, 0, section.id)
            XCTAssertGreaterThanOrEqual(card.frame.minX, window.minX, section.id)
            XCTAssertLessThanOrEqual(card.frame.maxX, window.maxX, section.id)
            if let id = section.boundedID {
                let container = element(id)
                position(container, on: page, identifier: id)
                assertBounds(container, cap: section.cap)
                XCTAssertTrue(viewport(of: page).contains(container.frame),
                              "Bounded content must fit above the tab bar: \(id)")
                XCTAssertTrue(window.contains(container.frame), id)
            } else {
                // The activity fixture's only order is filled, so this card has no order list.
                XCTAssertTrue(viewport(of: page).contains(card.frame), section.id)
                XCTAssertTrue(window.contains(card.frame), section.id)
                XCTAssertTrue(card.staticTexts["No open orders"].exists)
            }
            screenshot(section.name)
        }
    }

    func testBooksLayout() throws {
        app.tabBars.buttons["Books"].tap()
        let page = element("books.scroll")
        let books = try XCTUnwrap(try fixture("books")["books"] as? [[String: Any]])
        let sorted = books.sorted { ($0["book_id"] as? String ?? "") < ($1["book_id"] as? String ?? "") }
        let lastID = try XCTUnwrap(sorted.last?["book_id"] as? String)
        let tickers = sorted.compactMap { book -> String? in
            let kalshi = book["kalshi_book"] as? [String: Any]
            let evaluation = kalshi?["eval"] as? [String: Any]
            let candidates = evaluation?["candidates"] as? [[String: Any]]
            return candidates?.first?["ticker"] as? String
        }
        let lastTicker = try XCTUnwrap(tickers.last)
        check("books.openTable", on: page) { $0.staticTexts[lastTicker].firstMatch }
        screenshot("Books open tickets")
        let hand = element("books.handTable")
        position(hand, on: page, identifier: "books.handTable")
        XCTAssertTrue(hand.exists)
        XCTAssertGreaterThan(hand.frame.height, 0)
        XCTAssertGreaterThanOrEqual(hand.frame.minX, window.minX)
        XCTAssertLessThanOrEqual(hand.frame.maxX, window.maxX)
        XCTAssertTrue(hand.descendants(matching: .any)
            .matching(NSPredicate(format: "identifier BEGINSWITH %@", "books.hand.")).firstMatch.exists)
        screenshot("Books needs a hand")
        let all = element("books.hand.all")
        if all.exists {
            position(all, on: page, identifier: "books.hand.all")
            XCTAssertGreaterThanOrEqual(all.frame.height, 44)
            all.tap()
            let list = app.scrollViews["books.hand.list"].firstMatch
            XCTAssertTrue(list.waitForExistence(timeout: 5))
            let lastRow = list.staticTexts[lastID].firstMatch
            for attempt in 0...40 {
                if lastRow.exists && lastRow.isHittable { break }
                if attempt == 40 { break }
                let visible = viewport(of: list)
                let start = app.coordinate(withNormalizedOffset: .zero)
                    .withOffset(CGVector(dx: visible.midX, dy: visible.maxY - visible.height * 0.1))
                start.press(forDuration: 0,
                            thenDragTo: start.withOffset(CGVector(dx: 0, dy: -visible.height * 0.7)),
                            withVelocity: .slow, thenHoldForDuration: 0)
            }
            XCTAssertTrue(lastRow.exists, "Last fixture row was not found in books.hand.list after 40 drags")
            XCTAssertTrue(lastRow.isHittable, "Last fixture row was not reachable in books.hand.list after 40 drags")
            screenshot("Books needs a hand all")
            app.navigationBars.buttons.firstMatch.tap()
            XCTAssertTrue(page.waitForExistence(timeout: 5))
        }
        // The row button is the navigation marker, even when its supporting caption is taller than the box.
        check("books.rows", on: page) { $0.buttons["book.\(lastID)"].firstMatch }
        screenshot("Books")
    }

    func testEnginesLayout() throws {
        app.tabBars.buttons["Engines"].tap()
        let engines = try XCTUnwrap(try fixture("engines")["engines"] as? [[String: Any]])
        let lastID = try XCTUnwrap(engines.last?["engine_id"] as? String)
        let page = app.collectionViews["engines.list"]
        XCTAssertTrue(page.waitForExistence(timeout: 5))
        XCTAssertFalse(app.scrollViews["engines.rows"].exists)
        let lastEngine = page.buttons["engine.detail.\(lastID)"].firstMatch
        position(lastEngine, on: page, identifier: "engine.detail.\(lastID)")
        XCTAssertTrue(lastEngine.exists)
        XCTAssertTrue(lastEngine.isHittable)
        XCTAssertTrue(viewport(of: page).intersects(lastEngine.frame))
        XCTAssertGreaterThanOrEqual(lastEngine.frame.minX, window.minX)
        XCTAssertLessThanOrEqual(lastEngine.frame.maxX, window.maxX)
        screenshot("Engines")
        check("engines.paper.rows", on: element("engines.list")) {
            $0.buttons["engine.paper.candidate.atlas-discovery"].firstMatch
        }
        let paper = app.buttons["engine.paper.candidate.atlas-discovery"]
        XCTAssertTrue(paper.label.contains("Collecting evidence"))
        XCTAssertTrue(paper.label.contains("Simulated P&L: Unavailable"))
        screenshot("Generated engine paper results")
    }

    func testEngineHistoryLayout() throws {
        app.tabBars.buttons["Engines"].tap()
        let open = app.buttons["engine.history.open"]
        position(open, on: element("engines.list"), identifier: "engine.history.open").tap()
        let history = try fixture("engine-history")
        let engines = try XCTUnwrap(history["engines"] as? [[String: Any]])
        let rows = engines.flatMap { $0["accounts"] as? [[String: Any]] ?? [] }
        XCTAssertFalse(rows.isEmpty)
        // Since #921 the By account section is a plain list of rows inside the page, not a bounded
        // scroll view, so its last row is reached by scrolling the history page itself.
        let page = element("engine.history.list")
        let accounts = app.descendants(matching: .any)["engine.history.accounts"].firstMatch
        position(accounts, on: page, identifier: "engine.history.accounts")
        XCTAssertFalse(app.scrollViews["engine.history.accounts"].exists)
        XCTAssertLessThanOrEqual(accounts.frame.maxX, window.maxX)
        let lastRow = app.descendants(matching: .any)["engine.history.accounts.row.\(rows.count - 1)"].firstMatch
        position(lastRow, on: page, identifier: "engine.history.accounts.row.\(rows.count - 1)")
        XCTAssertTrue(lastRow.isHittable)
        screenshot("Engine history")
    }

    private func assertActionBar() {
        let bar = element("engine.settings.actionBar")
        XCTAssertTrue(bar.waitForExistence(timeout: 3))
        XCTAssertTrue(window.contains(bar.frame), "The action bar must fit in the window")
        for id in ["engine.settings.save", "engine.settings.discard"] {
            let button = app.buttons[id]
            XCTAssertTrue(button.exists)
            XCTAssertTrue(bar.frame.contains(button.frame), id)
            XCTAssertTrue(button.isHittable, id)
            for boundedID in caps.keys {
                let viewportID = boundedID == "monitor.shadow" ? "monitor.shadowList" : boundedID
                for container in app.scrollViews.matching(identifier: viewportID).allElementsBoundByIndex {
                    XCTAssertFalse(button.frame.intersects(container.frame), "\(id) overlaps \(boundedID)")
                }
            }
        }
        let blocking = element("engine.settings.blocking")
        XCTAssertTrue(blocking.waitForExistence(timeout: 3))
        XCTAssertTrue(bar.frame.contains(blocking.frame), "Blocking reason must be fully inside the bar")
        let texts = blocking.staticTexts.allElementsBoundByIndex
        XCTAssertFalse(texts.isEmpty)
        for text in texts {
            XCTAssertTrue(bar.frame.contains(text.frame), "Blocking text is clipped by the bar")
        }
    }

    func testEngineSettingsLayout() {
        app.tabBars.buttons["Engines"].tap()
        let rows = app.collectionViews["engines.list"]
        let notStarted = app.buttons["engines.catalog.group.notStarted"]
        position(notStarted, on: rows, identifier: "engines.catalog.group.notStarted").tap()
        let engine = app.buttons["engine.detail.default"]
        position(engine, on: element("engines.list"), identifier: "engine.detail.default")
        XCTAssertTrue(engine.waitForExistence(timeout: 5))
        for _ in 0..<12 {
            if engine.exists && !engine.frame.isEmpty && rows.frame.contains(engine.frame) &&
                engine.frame.intersects(viewport(of: rows)) && engine.isHittable { break }
            let start = rows.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5))
            let delta: CGFloat = engine.frame.minY < rows.frame.minY ? 40 : -40
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: delta)))
        }
        XCTAssertTrue(engine.isHittable)
        XCTAssertTrue(rows.frame.contains(engine.frame))
        engine.tap()
        let configure = app.buttons["engine.configure.default"]
        position(configure, on: app.collectionViews.firstMatch, identifier: "engine.configure.default").tap()
        let form = element("engine.settings.form")
        XCTAssertTrue(form.waitForExistence(timeout: 5))
        assertActionBar()

        let search = app.textFields["engine.settings.search"]
        position(search, on: form, identifier: "engine.settings.search").tap()
        search.typeText("drawdown\n")
        let stop = app.sliders["engine.settings.control.drawdown_stop_fraction"]
        position(stop, on: form, identifier: "engine.settings.control.drawdown_stop_fraction")
        stop.adjust(toNormalizedSliderPosition: 0)
        let validation = element("engine.settings.conflict.drawdown-order")
        XCTAssertTrue(validation.waitForExistence(timeout: 3))
        let more = app.buttons["engine.settings.conflict.drawdown-order.more"]
        if more.waitForExistence(timeout: 2) {
            let moreTap = position(more, on: form, identifier: "engine.settings.conflict.drawdown-order.more")
            let full = "Drawdown stop must be above Drawdown slowdown, or the runner will reject the change."
            let text = validation.staticTexts[full].firstMatch
            XCTAssertTrue(text.exists)
            let collapsedHeight = text.frame.height
            let collapsedLabel = text.label
            moreTap.tap()
            let expanded = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: more)
            XCTAssertEqual(XCTWaiter.wait(for: [expanded], timeout: 3), .completed)
            XCTAssertEqual(text.label, full)
            // SwiftUI exposes the full accessibility label even while its rendered text is clamped.
            // In that case increased height proves More exposes additional lines of the same text.
            XCTAssertTrue(text.label.count > collapsedLabel.count || text.frame.height > collapsedHeight + 0.5,
                          "More must expose text beyond the collapsed caption")
        }
        assertActionBar()
        XCTAssertFalse(app.buttons["engine.settings.save"].isEnabled)
        screenshot("Engine settings")
    }
}
