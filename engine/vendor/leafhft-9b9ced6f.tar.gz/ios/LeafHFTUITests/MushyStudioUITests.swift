import XCTest

/// Run this suite on both a compact iPhone and a large iPhone destination.
final class MushyStudioUITests: XCTestCase {
    @MainActor func testStarterFillsDraftAndSendSendsWithAdvancedControlsHidden() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1"]
        app.launch()
        openStudio(app)
        XCTAssertTrue(app.staticTexts["assistant.empty"].waitForExistence(timeout: 5))
        for id in ["studio.model", "studio.reasoning", "studio.provider", "studio.settings"] {
            XCTAssertFalse(app.descendants(matching: .any)[id].firstMatch.exists)
        }
        for index in 0..<6 {
            let starter = app.buttons["assistant.starter.\(index)"]
            reveal(starter, app: app)
            XCTAssertTrue(starter.exists)
            XCTAssertGreaterThanOrEqual(starter.frame.height, 44)
            if index == 4 {
                XCTAssertEqual(starter.label, "What can I tune on my engines?")
            } else if index == 5 {
                XCTAssertEqual(starter.label, "Show my shadow engines")
            }
        }
        for _ in 0..<18 {
            if app.buttons["assistant.starter.0"].isHittable { break }
            app.swipeDown()
        }
        fillDraftFromStarterAndSend(app)
        let result = app.staticTexts["assistant.reply.text"]
        XCTAssertTrue(result.waitForExistence(timeout: 10))
        XCTAssertTrue(result.label.contains("$238.81"))
        XCTAssertFalse(app.staticTexts["assistant.reply.error"].exists)
    }

    @MainActor func testComposerStaysVisibleWhenScrollingOnPhone() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1"]
        app.launch()
        openStudio(app)
        let prompt = app.descendants(matching: .any)["assistant.prompt"].firstMatch
        let send = app.buttons["assistant.send"]
        let originalY = prompt.frame.minY
        app.swipeUp()
        XCTAssertTrue(prompt.isHittable)
        XCTAssertTrue(send.isHittable)
        XCTAssertEqual(prompt.frame.minY, originalY, accuracy: 2)
        XCTAssertGreaterThanOrEqual(send.frame.height, 44)
        for control in [prompt, send, app.buttons["assistant.close"], app.buttons["assistant.new"],
                        app.buttons["assistant.engineToggle"]] {
            XCTAssertTrue(control.isHittable)
            XCTAssertGreaterThanOrEqual(control.frame.minX, app.frame.minX)
            XCTAssertGreaterThanOrEqual(control.frame.minY, app.frame.minY)
            XCTAssertLessThanOrEqual(control.frame.maxX, app.frame.maxX)
            XCTAssertLessThanOrEqual(control.frame.maxY, app.frame.maxY)
        }
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "Assistant persistent composer phone fit"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }

    @MainActor func testTypedPromptEnablesSendAndShowsAdmission() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1"]
        app.launch()
        openStudio(app)
        let prompt = app.descendants(matching: .any)["assistant.prompt"].firstMatch
        reveal(prompt, app: app)
        XCTAssertTrue(prompt.isHittable)
        prompt.tap()
        if let prior = prompt.value as? String, prior != prompt.placeholderValue {
            prompt.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: prior.count))
        }
        prompt.typeText("Explain my account balance")
        let send = app.buttons["assistant.send"]
        XCTAssertTrue(send.isHittable)
        XCTAssertGreaterThanOrEqual(send.frame.height, 44)
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        XCTAssertLessThanOrEqual(send.frame.maxY, app.keyboards.firstMatch.frame.minY)
        XCTAssertLessThanOrEqual(prompt.frame.maxY, app.keyboards.firstMatch.frame.minY)
        expectation(for: NSPredicate(format: "enabled == true"), evaluatedWith: send)
        waitForExpectations(timeout: 5)
        send.tap()
        let result = app.staticTexts["assistant.reply.text"]
        reveal(result, app: app)
        XCTAssertTrue(result.waitForExistence(timeout: 5))
        XCTAssertTrue(result.label.contains("$238.81"))
        XCTAssertFalse(app.staticTexts["assistant.reply.error"].exists)
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "Assistant typed prompt answered from native Send"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }

    @MainActor private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<18 {
            if element.exists && element.isHittable { return }
            app.swipeUp()
        }
    }
    @MainActor func testNativePanelsAndActionsFitPhone() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1"]
        app.launch()
        openStudio(app)
        fillDraftFromStarterAndSend(app)
        for kind in ["line", "metric"] {
            let panel = app.descendants(matching: .any)["assistant.panel." + kind].firstMatch
            XCTAssertTrue(panel.waitForExistence(timeout: 10))
            reveal(panel, app: app)
            XCTAssertTrue(panel.exists)
            XCTAssertLessThanOrEqual(panel.frame.width, app.frame.width)
        }
        let newConversation = app.buttons["assistant.new"]
        expectation(for: NSPredicate(format: "enabled == true"), evaluatedWith: newConversation)
        waitForExpectations(timeout: 5)
        XCTAssertTrue(newConversation.isHittable)
        XCTAssertGreaterThanOrEqual(newConversation.frame.height, 44)
        newConversation.tap()
        XCTAssertTrue(app.staticTexts["assistant.empty"].waitForExistence(timeout: 5))
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "Assistant native panels and new conversation viewport"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }

    @MainActor func testDarkModeAndAccessibilityText() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", "dark",
            "-" + "UIPreferredContentSizeCategoryName", "UICTContentSizeCategoryAccessibilityXXXL"]
        app.launch()
        XCTAssertEqual(app.staticTexts["fixture.renderedAppearance"].value as? String, "dark")
        openStudio(app)
        let chatTab = app.buttons["assistant.tab.chat"]
        let autotuneTab = app.buttons["assistant.tab.autotune"]
        XCTAssertTrue(chatTab.exists)
        XCTAssertTrue(autotuneTab.exists)
        XCTAssertLessThanOrEqual(autotuneTab.frame.height, chatTab.frame.height * 1.6,
            "Autotune must stay on one line at accessibility XXXL")
        let send = app.buttons["assistant.send"]
        reveal(send, app: app)
        XCTAssertTrue(send.exists)
        XCTAssertGreaterThanOrEqual(send.frame.height, 44)
        XCTAssertTrue(send.isHittable)
        XCTAssertGreaterThanOrEqual(send.frame.minX, app.frame.minX)
        XCTAssertLessThanOrEqual(send.frame.maxX, app.frame.maxX)
        XCTAssertLessThanOrEqual(send.frame.maxY, app.frame.maxY)
        fillDraftFromStarterAndSend(app)
        let metric = app.descendants(matching: .any)["assistant.panel.metric"].firstMatch
        XCTAssertTrue(metric.waitForExistence(timeout: 10))
        reveal(metric, app: app)
        XCTAssertTrue(metric.exists)
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "Assistant dark accessibility viewport"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }
    @MainActor func testFeatureDisabledKeepsAssistantBubbleVisible() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-MUSHY_DISABLED"]
        app.launch()
        let launcher = app.buttons["studio.launcher"]
        XCTAssertTrue(launcher.waitForExistence(timeout: 5))
        XCTAssertTrue(launcher.isHittable)
        XCTAssertEqual(app.tabBars.buttons.count, 5)
        XCTAssertFalse(app.tabBars.buttons["Studio"].exists)
        launcher.tap()
        XCTAssertTrue(app.navigationBars["Assistant"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["assistant.empty"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.descendants(matching: .any)["assistant.prompt"].firstMatch.exists)
    }

    @MainActor func testAssistantBubbleOpensChatAndDismissesFromEveryTab() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1"]
        app.launch()
        XCTAssertEqual(app.tabBars.buttons.count, 5)
        XCTAssertFalse(app.tabBars.buttons["Studio"].exists)
        for tab in ["Monitor", "Books", "Engines", "Lab", "Settings"] {
            app.tabBars.buttons[tab].tap()
            let launcher = app.buttons["studio.launcher"]
            XCTAssertTrue(launcher.waitForExistence(timeout: 5))
            XCTAssertTrue(launcher.isHittable)
            XCTAssertGreaterThan(launcher.frame.midX, app.frame.midX)
            XCTAssertGreaterThan(launcher.frame.midY, app.frame.midY)
            XCTAssertGreaterThanOrEqual(launcher.frame.minX, app.frame.minX)
            XCTAssertGreaterThanOrEqual(launcher.frame.minY, app.frame.minY)
            XCTAssertLessThanOrEqual(launcher.frame.maxX, app.frame.maxX)
            XCTAssertLessThanOrEqual(launcher.frame.maxY, app.frame.maxY)
            XCTAssertEqual(launcher.frame.width, launcher.frame.height, accuracy: 2)
            let tabBar = app.tabBars.firstMatch
            XCTAssertTrue(tabBar.exists)
            XCTAssertLessThanOrEqual(launcher.frame.maxY, tabBar.frame.minY)
            if tab == "Monitor" {
                let screenshot = XCTAttachment(screenshot: app.screenshot())
                screenshot.name = "Assistant prompt bubble bottom right"
                screenshot.lifetime = .keepAlways
                add(screenshot)
            }
            openStudio(app)
            app.buttons["assistant.close"].tap()
            XCTAssertTrue(launcher.waitForExistence(timeout: 5))
            XCTAssertTrue(app.tabBars.buttons[tab].isSelected)
        }
    }

    @MainActor private func revealStarter(_ starter: XCUIElement, app: XCUIApplication) -> Bool {
        let chatTab = app.buttons["assistant.tab.chat"]
        let autotuneTab = app.buttons["assistant.tab.autotune"]
        let prompt = app.descendants(matching: .any)["assistant.prompt"].firstMatch
        let engineToggle = app.buttons["assistant.engineToggle"]
        guard chatTab.exists && autotuneTab.exists && prompt.exists else {
            XCTFail("Cannot position starter without the pinned tabs and composer")
            return false
        }
        for step in 0...8 {
            let top = max(chatTab.frame.maxY, autotuneTab.frame.maxY)
            let bottom = engineToggle.exists ? min(engineToggle.frame.minY, prompt.frame.minY) : prompt.frame.minY
            guard bottom - top > 16 else {
                XCTFail("No conversation space between the pinned tabs and composer")
                return false
            }
            let frame = starter.exists ? starter.frame : .zero
            if starter.exists && frame.height > 0 && frame.minY >= top && frame.maxY <= bottom && starter.isHittable {
                return true
            }
            if starter.exists && frame.height > bottom - top && frame.midY - 22 >= top &&
                frame.midY + 22 <= bottom && starter.isHittable {
                app.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(
                    dx: frame.midX - app.frame.minX, dy: frame.midY - app.frame.minY)).tap()
                return true
            }
            guard step < 8 else {
                XCTFail("Starter never cleared pinned tabs and composer after 8 scroll steps: \(frame), allowed Y \(top)...\(bottom)")
                return false
            }
            guard starter.exists && frame.height > 0 else {
                app.swipeUp()
                continue
            }
            // isHittable can be true while the starter's centre is under the pinned tabs.
            let middle = (top + bottom) / 2
            let maxStep = min((bottom - top) * 0.6, bottom - top - 16)
            let delta = max(-maxStep, min(maxStep, middle - frame.midY))
            let lowestStart = max(top + 8, top + 8 - delta)
            let highestStart = min(bottom - 8, bottom - 8 - delta)
            var startY = (lowestStart + highestStart) / 2
            // Prefer starting outside this button so the gesture scrolls the conversation.
            if lowestStart < frame.minY || lowestStart > frame.maxY {
                startY = lowestStart
            } else if highestStart < frame.minY || highestStart > frame.maxY {
                startY = highestStart
            }
            let origin = app.coordinate(withNormalizedOffset: .zero)
            let start = origin.withOffset(CGVector(dx: app.frame.width / 2,
                dy: startY - app.frame.minY))
            let end = origin.withOffset(CGVector(dx: app.frame.width / 2,
                dy: startY + delta - app.frame.minY))
            start.press(forDuration: 0.1, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.2)
            let movedFrame = starter.exists ? starter.frame : .zero
            if !starter.exists || abs(movedFrame.midY - frame.midY) < 1 {
                if delta > 0 {
                    app.swipeDown()
                } else {
                    app.swipeUp()
                }
            }
        }
        return false
    }

    @MainActor private func fillDraftFromStarterAndSend(_ app: XCUIApplication) {
        let starter = app.buttons["assistant.starter.0"]
        guard revealStarter(starter, app: app) else { return }
        XCTAssertTrue(starter.isHittable)
        let starterText = starter.label
        starter.tap()
        let prompt = app.descendants(matching: .any)["assistant.prompt"].firstMatch
        expectation(for: NSPredicate(format: "value == %@", starterText), evaluatedWith: prompt)
        waitForExpectations(timeout: 5)
        XCTAssertEqual(prompt.value as? String, starterText)
        let send = app.buttons["assistant.send"]
        reveal(send, app: app)
        XCTAssertTrue(send.isHittable)
        expectation(for: NSPredicate(format: "enabled == true"), evaluatedWith: send)
        waitForExpectations(timeout: 5)
        XCTAssertFalse(app.staticTexts["assistant.thinking"].exists)
        XCTAssertFalse(app.staticTexts["assistant.reply.text"].exists)
        XCTAssertFalse(app.staticTexts["assistant.reply.error"].exists)
        send.tap()
    }

    @MainActor private func openStudio(_ app: XCUIApplication) {
        let launcher = app.buttons["studio.launcher"]
        XCTAssertTrue(launcher.waitForExistence(timeout: 5))
        launcher.tap()
        XCTAssertTrue(app.navigationBars["Assistant"].waitForExistence(timeout: 5))
        let prompt = app.descendants(matching: .any)["assistant.prompt"].firstMatch
        XCTAssertTrue(prompt.waitForExistence(timeout: 5))
        XCTAssertTrue(prompt.isHittable)
        XCTAssertEqual(app.buttons.matching(identifier: "assistant.send").count, 1)
        XCTAssertLessThanOrEqual(prompt.frame.maxX, app.frame.maxX)
        XCTAssertLessThanOrEqual(prompt.frame.maxY, app.frame.maxY)
    }
}
