import XCTest

final class EngineSettingsUITests: XCTestCase {
    private var app: XCUIApplication!
    private var form: XCUIElement { app.collectionViews["engine.settings.form"] }

    override func setUpWithError() throws {
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-kashbot.engines.rowDetail", "detailed",
            "-kashbot.engines.grouped", "YES", "-kashbot.engines.sort", "runner", "-LEAFHFT_CONTROL_WALK", "1",
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        if let appearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] {
            XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
            app.launchArguments += ["-LEAFHFT_APPEARANCE", appearance]
        }
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        expandNotStarted(in: app.collectionViews["engines.list"])
        reveal(app.buttons["engine.detail.default"], in: app.collectionViews["engines.list"])
        XCTAssertTrue(app.buttons["engine.detail.default"].waitForExistence(timeout: 10))
    }

    private func expandNotStarted(in list: XCUIElement) {
        let group = app.buttons["engines.catalog.group.notStarted"]
        reveal(group, in: list)
        if group.value as? String == "Collapsed" { group.tap() }
    }

    private func openSettings() {
        app.buttons["engine.detail.default"].tap()
        let configure = app.buttons["engine.configure.default"]
        reveal(configure, in: app.collectionViews.firstMatch)
        configure.tap()
        XCTAssertTrue(form.waitForExistence(timeout: 10))
    }

    private func element(_ id: String) -> XCUIElement {
        app.descendants(matching: .any)[id].firstMatch
    }

    /// Elements under the sticky action bar still report hittable, so a tap or drag would land on the bar.
    private func clearOfActionBar(_ element: XCUIElement) -> Bool {
        let bar = self.element("engine.settings.actionBar")
        guard bar.exists, element.exists else { return true }
        // SwiftUI can expose bar controls as accessibility siblings. Avoid a descendant
        // lookup for every form row, and never mistake an obscured row for a bar control.
        let barControls = ["unsavedCount", "save", "discard", "result", "continueRejected", "loadApplied", "blocking"]
        if barControls.contains(where: { element.identifier == "engine.settings.\($0)" }),
           bar.frame.contains(element.frame) { return true }
        return element.frame.maxY <= bar.frame.minY - 4
    }

    private func reveal(_ element: XCUIElement, in scroll: XCUIElement, limit: Int = 35) {
        for _ in 0..<limit {
            if element.exists && element.isHittable && clearOfActionBar(element) { return }
            let start = scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.60))
            let above = element.exists && element.frame.maxY > 0 && element.frame.minY < app.navigationBars.firstMatch.frame.maxY
            let end = start.withOffset(CGVector(dx: 0, dy: above ? 160 : -160))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        XCTFail("Could not reach \(element.identifier) above the action bar")
    }

    private func scrollToTop(_ list: XCUIElement) {
        let anchor = list.cells.firstMatch
        for _ in 0..<10 {
            let previousFrame = anchor.exists ? anchor.frame : CGRect.zero
            let start = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.25))
            let end = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.75))
            start.press(forDuration: 0.05, thenDragTo: end)
            if anchor.exists && !previousFrame.isEmpty && anchor.frame == previousFrame { return }
        }
    }

    private func revealAboveBar(_ element: XCUIElement) {
        reveal(element, in: form)
        let bar = self.element("engine.settings.actionBar")
        for _ in 0..<12 {
            if element.frame.maxY < bar.frame.minY - 12 && element.frame.minY > app.navigationBars.firstMatch.frame.maxY { return }
            let start = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.60))
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: -160)), withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        XCTFail("Could not place \(element.identifier) above the action bar")
    }

    private func revealCatalog(_ target: XCUIElement, identifier: String, in list: XCUIElement, upward: Bool = false) {
        for _ in 0..<100 {
            let top = max(list.frame.minY, app.navigationBars.firstMatch.frame.maxY) + 8
            let bottom = min(list.frame.maxY, app.tabBars.firstMatch.frame.minY) - 80
            if target.exists && !target.frame.isEmpty && target.frame.minY >= top && target.frame.maxY <= bottom && target.isHittable { return }
            let above = target.exists && target.frame.maxY > 0 ? target.frame.minY < top : upward
            let start = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.30 : 0.70))
            let end = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: above ? 0.75 : 0.25))
            start.press(forDuration: 0.05, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.1)
        }
        XCTFail("Could not reach \(identifier) using the page List")
    }

    private func returnToTop() {
        let scope = app.buttons["engine.settings.scopePicker"]
        var previousFieldY: CGFloat?
        for _ in 0..<35 {
            let field = app.textFields["engine.settings.search"]
            // The field must sit below the navigation bar: under it, a tap lands on the bar.
            if scope.exists && scope.isHittable && field.exists && field.isHittable &&
                field.frame.minY >= app.navigationBars.firstMatch.frame.maxY + 4 { return }
            // At the top already: a drag that does not move the field cannot help.
            if field.exists, let previous = previousFieldY, abs(field.frame.minY - previous) < 1 { return }
            previousFieldY = field.exists ? field.frame.minY : nil
            let start = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.25))
            let end = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.60))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        XCTFail("Could not return to the scope picker and search field")
    }

    private func search(_ text: String) {
        returnToTop()
        let search = app.textFields["engine.settings.search"]
        reveal(search, in: form)
        for _ in 0..<8 {
            if search.frame.minY >= app.navigationBars.firstMatch.frame.maxY + 4 { break }
            let start = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.30))
            let end = form.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.55))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        if app.buttons["Clear search"].exists { app.buttons["Clear search"].tap() }
        if text.isEmpty { return }
        search.tap()
        search.typeText(text)
        if app.keyboards.buttons["return"].exists {
            app.keyboards.buttons["return"].tap()
        } else {
            search.typeText("\n")
        }
    }

    private func assertCount(_ text: String) {
        let count = element("engine.settings.unsavedCount")
        reveal(count, in: form)
        XCTAssertEqual(count.label, text)
    }

    private func screenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    func testSearchFiltersAndClears() {
        openSettings()
        search("drawdown")
        reveal(element("engine.settings.row.drawdown_brake_fraction"), in: form)
        XCTAssertTrue(element("engine.settings.row.drawdown_brake_fraction").exists)
        reveal(element("engine.settings.row.drawdown_stop_fraction"), in: form)
        XCTAssertTrue(element("engine.settings.row.drawdown_stop_fraction").exists)
        XCTAssertFalse(element("engine.settings.row.size_fraction").exists)
        search("zzz")
        XCTAssertTrue(element("engine.settings.noResults").waitForExistence(timeout: 2))
        app.buttons["Clear search"].tap()
        XCTAssertFalse(element("engine.settings.noResults").exists)
        reveal(element("engine.settings.row.size_fraction"), in: form)
        XCTAssertTrue(element("engine.settings.row.size_fraction").exists)
    }

    func testUntouchedConfigurationNamesItsPrerequisites() {
        openSettings()
        XCTAssertTrue(element("engine.settings.prerequisites").waitForExistence(timeout: 5))
        XCTAssertTrue(element("engine.settings.observedAt").exists)
        XCTAssertEqual(element("engine.settings.unsavedCount").label, "No unsaved changes")
        XCTAssertFalse(app.buttons["engine.settings.save"].isEnabled)
        let generic = app.staticTexts.matching(NSPredicate(format:
            "label BEGINSWITH 'Fix ' AND label CONTAINS 'before reviewing'"))
        XCTAssertEqual(generic.count, 0)
        XCTAssertTrue(element("engine.settings.blocking").label.contains("Saved values above the runner's maximum"))
    }

    func testNoConfigurableAccountExplainsDisabledPicker() {
        app.terminate()
        app.launchArguments += ["-LEAFHFT_CONFIGURE_NO_ACCOUNTS"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        let list = app.collectionViews["engines.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 10))
        expandNotStarted(in: list)
        revealCatalog(app.buttons["engine.detail.default"], identifier: "engine.detail.default", in: list)
        XCTAssertTrue(app.buttons["engine.detail.default"].waitForExistence(timeout: 10))
        openSettings()
        let picker = app.buttons["engine.settings.scopePicker"]
        XCTAssertTrue(picker.waitForExistence(timeout: 5))
        XCTAssertFalse(picker.isEnabled)
        XCTAssertTrue(picker.label.contains("No configurable accounts received"))
        let details = app.buttons["engine.settings.prerequisiteDetails"]
        reveal(details, in: form)
        details.tap()
        XCTAssertEqual(details.value as? String, "Expanded")
        let diagnostics = element("engine.settings.accountDiagnostics")
        XCTAssertTrue(diagnostics.waitForExistence(timeout: 5))
        reveal(diagnostics, in: form)
        XCTAssertTrue(diagnostics.label.contains("Checked at:"))
        XCTAssertTrue(diagnostics.label.contains("engine control response"))
        returnToTop()
        reveal(details, in: form)
        details.tap()
        XCTAssertEqual(details.value as? String, "Collapsed")
        XCTAssertFalse(diagnostics.exists)
    }

    func testSearchResultsFitAboveKeyboardAndKeepContext() {
        openSettings()
        let field = app.textFields["engine.settings.search"]
        reveal(field, in: form)
        field.tap()
        field.typeText("loss")
        let keyboard = app.keyboards.firstMatch
        XCTAssertTrue(keyboard.waitForExistence(timeout: 5))
        let result = app.buttons.matching(NSPredicate(format:
            "identifier BEGINSWITH 'engine.settings.searchResult.'")).firstMatch
        XCTAssertTrue(result.waitForExistence(timeout: 5))
        let visible = NSPredicate { _, _ in
            result.isHittable && result.frame.minY >= field.frame.maxY && result.frame.maxY <= keyboard.frame.minY
        }
        wait(for: [XCTNSPredicateExpectation(predicate: visible, object: result)], timeout: 5)
        XCTAssertTrue(element("engine.settings.searchCount").exists)
        XCTAssertEqual(element("engine.settings.searchStatus").frame.height, 44, accuracy: 1)
        let key = String(result.identifier.dropFirst("engine.settings.searchResult.".count))
        result.tap()
        returnToTop()
        reveal(field, in: form)
        XCTAssertEqual(field.value as? String, "loss")
        XCTAssertTrue(element("engine.settings.row.\(key)").waitForExistence(timeout: 5))
        XCTAssertTrue(element("engine.settings.actionBar").waitForExistence(timeout: 5))
    }

    func testHelpExpandsInline() {
        openSettings()
        search("Minimum edge")
        let help = app.buttons["engine.settings.help.edge_threshold_cents"]
        reveal(help, in: form)
        help.tap()
        let text = element("engine.settings.helpText.edge_threshold_cents")
        XCTAssertTrue(text.waitForExistence(timeout: 2))
        XCTAssertTrue(text.label.contains("When you raise it"))
        reveal(text, in: form)
        screenshot("Expanded help")
        returnToTop()
        reveal(help, in: form)
        help.tap()
        XCTAssertFalse(text.exists)
    }

    func testAccountOverrideAndRestore() {
        openSettings()
        app.buttons["engine.settings.scopePicker"].tap()
        app.buttons["Secondary subaccount (sample)"].tap()
        let inherited = element("engine.settings.source.size_fraction")
        reveal(inherited, in: form)
        XCTAssertTrue(inherited.label.contains("Inherited"))
        search("Minimum edge")
        let source = element("engine.settings.source.edge_threshold_cents")
        reveal(source, in: form)
        XCTAssertTrue(source.label.contains("Override"))
        let restore = app.buttons["engine.settings.useGlobal.edge_threshold_cents"]
        reveal(restore, in: form)
        restore.tap()
        XCTAssertTrue(source.label.contains("Unsaved"))
        assertCount("1 unsaved change")
        returnToTop()
        reveal(source, in: form)
        screenshot("Account override")
        let undo = app.buttons["engine.settings.undo.edge_threshold_cents"]
        reveal(undo, in: form)
        undo.tap()
        assertCount("No unsaved changes")
    }

    func testValidationWarningBlocksReview() {
        openSettings()
        search("drawdown")
        let stop = app.sliders["engine.settings.control.drawdown_stop_fraction"]
        revealAboveBar(stop)
        stop.adjust(toNormalizedSliderPosition: 0)
        XCTAssertTrue(element("engine.settings.conflict.drawdown-order").exists)
        let validation = element("engine.settings.conflict.drawdown-order")
        reveal(validation, in: form)
        let more = app.buttons["engine.settings.conflict.drawdown-order.more"]
        if more.waitForExistence(timeout: 2) {
            reveal(more, in: form)
            let fullText = "Drawdown stop must be above Drawdown slowdown, or the runner will reject the change."
            let text = validation.staticTexts[fullText].firstMatch
            let collapsedHeight = text.frame.height
            more.tap()
            XCTAssertTrue(text.label == fullText && text.frame.height > collapsedHeight && !more.exists,
                          "More must reveal the full validation text")
        }
        let blocking = element("engine.settings.blocking")
        reveal(blocking, in: form)
        XCTAssertTrue(blocking.exists)
        let review = app.buttons["engine.settings.save"]
        reveal(review, in: form)
        XCTAssertFalse(review.isEnabled)
        screenshot("Validation warning")
        returnToTop()
        let undo = app.buttons["engine.settings.undo.drawdown_stop_fraction"]
        reveal(undo, in: form)
        undo.tap()
    }

    func testSavedPerOrderAboveTenPercentCannotSubmitInEitherScope() {
        openSettings()
        for account in ["All accounts", "Secondary subaccount (sample)"] {
            returnToTop()
            let picker = app.buttons["engine.settings.scopePicker"]
            picker.tap()
            let choice = app.buttons[account]
            if !choice.waitForExistence(timeout: 5) { picker.tap() } // the menu can miss a tap while the list settles
            XCTAssertTrue(choice.waitForExistence(timeout: 5))
            choice.tap()
            search("per_order_fraction")
            let value = element("engine.settings.value.per_order_fraction")
            reveal(value, in: form)
            XCTAssertEqual(value.label, "20%", "Unsafe saved values must not be silently clamped")
            let invalid = element("engine.settings.validation.per_order_fraction")
            reveal(invalid, in: form)
            XCTAssertTrue(invalid.label.contains("10%"))
            XCTAssertTrue(element("engine.settings.hardMaximum.per_order_fraction").exists)
            search("Position size")
            let size = app.sliders["engine.settings.control.size_fraction"]
            revealAboveBar(size)
            size.adjust(toNormalizedSliderPosition: 1)
            let review = app.buttons["engine.settings.save"]
            XCTAssertTrue(review.waitForExistence(timeout: 2))
            XCTAssertFalse(review.isEnabled, "An unrelated research dial cannot bypass an unsafe risk cap")
            XCTAssertTrue(element("engine.settings.blocking").exists)
            screenshot("Unsafe risk cap \(account)")
        }
    }

    func testSavedValueAboveMaximumExplainsAndSetsDraftOnly() {
        openSettings()
        search("per_order_fraction")
        let saved = element("engine.settings.savedAboveMaximum.per_order_fraction")
        reveal(saved, in: form)
        XCTAssertTrue(saved.label.contains("Saved 20%"), saved.label)
        XCTAssertTrue(saved.label.contains("The app's guarded maximum is 10% because the runner has not reported its maximum."), saved.label)
        XCTAssertFalse(saved.label.contains("The runner applies"), saved.label)
        let validation = element("engine.settings.validation.per_order_fraction")
        XCTAssertTrue(validation.exists)
        XCTAssertTrue(element("engine.settings.hardMaximum.per_order_fraction").exists)
        let setTo = app.buttons["engine.settings.setToMaximum.per_order_fraction"]
        revealAboveBar(setTo)
        XCTAssertEqual(setTo.label, "Set to 10%")
        screenshot("Saved value above maximum")
        setTo.tap()
        let gone = NSPredicate(format: "exists == false")
        wait(for: [XCTNSPredicateExpectation(predicate: gone, object: validation),
                   XCTNSPredicateExpectation(predicate: gone, object: saved),
                   XCTNSPredicateExpectation(predicate: gone, object: setTo)], timeout: 5)
        XCTAssertEqual(element("engine.settings.value.per_order_fraction").label, "10%")
        XCTAssertTrue(element("engine.settings.source.per_order_fraction").label.contains("Unsaved"))
        screenshot("Saved value set to maximum")
        // The draft changed; nothing was sent, and the other saved cap still blocks Review.
        assertCount("1 unsaved change")
        XCTAssertFalse(element("engine.settings.review").exists)
        XCTAssertFalse(app.buttons["engine.settings.save"].isEnabled)
    }

    func testReviewDiscardRejectionAndApply() {
        openSettings()
        // The legacy fixture contains unsafe saved caps. Correct both before submitting.
        for key in ["per_order_fraction", "cluster_fraction"] {
            search(key)
            let setTo = app.buttons["engine.settings.setToMaximum.\(key)"]
            reveal(setTo, in: form)
            setTo.tap()
        }
        search("size_fraction")
        let size = app.sliders["engine.settings.control.size_fraction"]
        revealAboveBar(size)
        size.adjust(toNormalizedSliderPosition: 1)
        search("min_k")
        let observations = app.steppers["engine.settings.control.min_k"]
        revealAboveBar(observations)
        observations.coordinate(withNormalizedOffset: CGVector(dx: 0.92, dy: 0.5)).tap()
        XCTAssertEqual(element("engine.settings.value.min_k").label, "13")
        search("")
        let changed = element("engine.settings.filterChanged")
        reveal(changed, in: form)
        changed.tap()
        XCTAssertTrue(element("engine.settings.row.size_fraction").waitForExistence(timeout: 2))
        assertCount("4 unsaved changes")
        returnToTop()
        reveal(element("engine.settings.row.size_fraction"), in: form)
        screenshot("Grouped settings")
        let review = app.buttons["engine.settings.save"]
        reveal(review, in: form)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: review)], timeout: 10), .completed, "Review stayed disabled with 4 unsaved changes")
        review.tap()
        XCTAssertTrue(element("engine.settings.review").waitForExistence(timeout: 2))
        XCTAssertTrue(element("engine.settings.reviewRow.size_fraction").exists)
        XCTAssertTrue(element("engine.settings.reviewRow.min_k").exists)
        screenshot("Review changes")
        app.buttons["engine.settings.send"].tap()
        let result = element("engine.settings.result")
        XCTAssertTrue(result.waitForExistence(timeout: 10))
        XCTAssertTrue(result.label.contains("Rejected"))
        screenshot("Rejected")
        let continueEditing = app.buttons["engine.settings.continueRejected"]
        XCTAssertTrue(continueEditing.exists)
        assertCount("4 unsaved changes")
        continueEditing.tap()
        reveal(review, in: form)
        review.tap()
        XCTAssertTrue(app.buttons["engine.settings.send"].waitForExistence(timeout: 2))
        app.buttons["engine.settings.send"].tap()
        XCTAssertTrue(result.waitForExistence(timeout: 10))
        XCTAssertTrue(result.label.contains("Applied"))
        screenshot("Applied")
        let load = app.buttons["engine.settings.loadApplied"]
        XCTAssertTrue(load.exists)
        XCTAssertTrue(load.isEnabled)
        load.tap()
        assertCount("No unsaved changes")
        XCTAssertFalse(element("engine.settings.result").exists)
        returnToTop()
        reveal(changed, in: form)
        changed.tap()
        XCTAssertTrue(element("engine.settings.row.size_fraction").waitForExistence(timeout: 2))
        let sizeValue = element("engine.settings.value.size_fraction")
        reveal(sizeValue, in: form)
        XCTAssertEqual(sizeValue.label, "50%")
        revealAboveBar(observations)
        observations.coordinate(withNormalizedOffset: CGVector(dx: 0.92, dy: 0.5)).tap()
        returnToTop()
        reveal(changed, in: form)
        changed.tap()
        let discard = app.buttons["engine.settings.discard"]
        reveal(discard, in: form)
        discard.tap()
        let confirm = app.buttons["engine.settings.discardConfirm"].firstMatch
        XCTAssertTrue(confirm.waitForExistence(timeout: 2))
        confirm.tap()
        assertCount("No unsaved changes")
    }

    func testProfitDialsStayVisibleInEngineList() {
        let list = app.collectionViews["engines.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 10))
        let box = element("engines.list")
        XCTAssertTrue(box.isHittable)
        for engineId in ["default", "aggressive"] {
            scrollToTop(list)
            let summary = element("engine.profitDials.\(engineId)")
            reveal(summary, in: box)
            for _ in 0..<12 {
                if box.frame.contains(summary.frame)
                    && summary.frame.minY >= app.navigationBars.firstMatch.frame.maxY
                    && summary.frame.maxY <= app.tabBars.firstMatch.frame.minY - 80 { break }
                let start = box.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.50))
                let delta: CGFloat = summary.frame.minY < app.navigationBars.firstMatch.frame.maxY ? 60 : -60
                start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: delta)))
            }
            // The dials themselves must clear the bars now that there is no inner catalog box.
            XCTAssertTrue(list.frame.contains(summary.frame))
            XCTAssertGreaterThanOrEqual(summary.frame.minY, app.navigationBars.firstMatch.frame.maxY)
            XCTAssertLessThanOrEqual(summary.frame.maxY, app.tabBars.firstMatch.frame.minY)
            XCTAssertTrue(summary.isHittable)
            XCTAssertTrue(box.frame.contains(summary.frame), "All profit dials must fit in the visible list")
            for value in ["Position: Size 10%", "Order cap 20%", "Entry: Edge 3.5¢",
                          "Observations 12", "Price: Min 1¢", "Max 99¢",
                          "Exit: Hold 10 seconds", "Margin 2¢", "Risk: Daily loss 10%", "Drawdown stop 25%"] {
                XCTAssertTrue(summary.label.contains(value), "Missing global policy value: \(value)")
            }
            XCTAssertFalse(app.buttons["engine.configure.\(engineId)"].exists)
            screenshot("Profit dials \(engineId)")
        }
        let detail = app.buttons["engine.detail.aggressive"]
        revealCatalog(detail, identifier: "engine.detail.aggressive", in: list, upward: true)
        XCTAssertTrue(detail.isHittable)
        detail.tap()
        let configure = app.buttons["engine.configure.aggressive"]
        let detailList = app.collectionViews["engine.detail.list"]
        XCTAssertTrue(detailList.waitForExistence(timeout: 10))
        reveal(configure, in: detailList)
        configure.tap()
        XCTAssertTrue(form.waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["engine.settings.scopePicker"].exists)
    }

    func testEngineListScreenshot() {
        screenshot("Engine list")
    }
}
