import XCTest

/// Replay: launch the control-walk fixtures, open Engines, cancel then confirm Bind, Create or Pause.
/// The Toggle tests add the one-account fixture; Requests proves zero or one send after each dialog.
final class EngineControlConfirmUITests: XCTestCase {
    private var app: XCUIApplication!
    private var list: XCUIElement { app.collectionViews["engines.list"] }
    private let received = "Request received. See Requests for its applied or rejected state."
    private let pauseMessage = "Default stops opening new positions in Main subaccount (sample). Open positions keep their normal exit and risk handling."

    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.appearance = .light
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-kashbot.engines.rowDetail", "detailed",
            "-kashbot.engines.grouped", "YES", "-kashbot.engines.sort", "runner", "-LEAFHFT_CONTROL_WALK", "1",
            "-LEAFHFT_APPEARANCE", "light", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        if name.contains("Toggle") { app.launchArguments += ["-LEAFHFT_ONE_ACCOUNT", "1"] }
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        XCTAssertTrue(list.waitForExistence(timeout: 3))
    }

    func testBindCancelSendsNothingThenConfirmSendsOne() {
        openBind()
        let title = assertDialog(title: "Bind Aggressive to BTC-15M?",
            message: "The BTC-15M book switches to Aggressive right away. New entries on BTC-15M use Aggressive with real money.",
            label: "Bind Aggressive to BTC-15M")
        screenshot("Bind confirmation")
        dismissConfirmation(title)
        assertDismissed(title, label: "Bind Aggressive to BTC-15M")
        XCTAssertFalse(app.staticTexts[received].exists)
        done()
        assertNoRequests()

        openBind()
        dialogButton("engine.control.confirm", label: "Bind Aggressive to BTC-15M").tap()
        XCTAssertTrue(app.staticTexts[received].waitForExistence(timeout: 3))
        done()
        assertOneRequest(value: "BTC-15M=aggressive")
    }

    func testCreateCancelSendsNothingThenConfirmSendsOne() {
        openCreate()
        let title = assertDialog(title: "Create Default copy?",
            message: "Creates engine Default copy (default-copy) from Default's settings. It starts disabled and not bound to any book.",
            label: "Create Default copy")
        screenshot("Create confirmation")
        dismissConfirmation(title)
        assertDismissed(title, label: "Create Default copy")
        XCTAssertFalse(app.staticTexts[received].exists)
        done()
        assertNoRequests()

        openCreate()
        dialogButton("engine.control.confirm", label: "Create Default copy").tap()
        XCTAssertTrue(app.staticTexts[received].waitForExistence(timeout: 3))
        done()
        assertOneRequest(value: "{\"engine_id\":\"default-copy\",\"from\":\"default\",\"name\":\"Default copy\"}")
    }

    func testEngineToggleCancelSendsNothingThenConfirmSendsOne() {
        let toggle = catalogToggle()
        XCTAssertTrue(toggle.isEnabled)
        XCTAssertEqual(toggle.value as? String, "1")
        toggle.tap()
        let title = assertDialog(title: "Pause Default?", message: pauseMessage, label: "Pause Default")
        screenshot("Toggle confirmation")
        dismissConfirmation(title)
        assertDismissed(title, label: "Pause Default")
        XCTAssertEqual(toggle.value as? String, "1")
        assertNoRequests()

        catalogToggle().tap()
        dialogButton("engine.control.confirm", label: "Pause Default").tap()
        assertOneRequest(kind: "engine.configure")
    }

    func testDetailToggleShowsTheSameConfirmation() {
        let rows = app.collectionViews["engines.list"]
        let detail = element("engine.detail.default")
        expandNotStarted(in: rows)
        reveal(detail, identifier: "engine.detail.default", in: rows)
        detail.tap()
        let detailList = app.collectionViews["engine.detail.list"]
        XCTAssertTrue(detailList.waitForExistence(timeout: 3))
        let toggle = app.switches["engine.toggle.default"]
        reveal(toggle, identifier: "engine.toggle.default", in: detailList)
        XCTAssertTrue(toggle.isEnabled)
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
        let title = assertDialog(title: "Pause Default?", message: pauseMessage, label: "Pause Default")
        screenshot("Detail toggle confirmation")
        dismissConfirmation(title)
        assertDismissed(title, label: "Pause Default")
        app.navigationBars.buttons.element(boundBy: 0).tap()
        XCTAssertTrue(list.waitForExistence(timeout: 3))
        assertNoRequests()
    }

    private func openBind() {
        let bind = app.buttons["engine.control.bind"]
        reveal(bind, identifier: "engine.control.bind", in: list)
        XCTAssertTrue(bind.isEnabled)
        bind.tap()
        selectPicker("engine.control.enginePicker", label: "Aggressive")
        selectPicker("engine.control.symbolPicker", label: "BTC-15M")
        review()
    }

    private func openCreate() {
        let create = app.buttons["engine.control.create"]
        reveal(create, identifier: "engine.control.create", in: list)
        XCTAssertTrue(create.isEnabled)
        create.tap()
        selectPicker("engine.control.enginePicker", label: "Default")
        let id = app.textFields["engine.control.newId"]
        XCTAssertTrue(id.waitForExistence(timeout: 3))
        id.tap()
        id.typeText("default-copy")
        let name = app.textFields["engine.control.name"]
        name.tap()
        name.typeText("Default copy\n")
        review()
    }

    private func selectPicker(_ id: String, label: String) {
        let picker = element(id)
        XCTAssertTrue(picker.waitForExistence(timeout: 3))
        picker.tap()
        let button = app.buttons.matching(NSPredicate(format: "label == %@", label)).firstMatch
        if button.waitForExistence(timeout: 2) {
            button.tap()
        } else {
            let text = app.staticTexts.matching(NSPredicate(format: "label == %@", label)).firstMatch
            XCTAssertTrue(text.waitForExistence(timeout: 3))
            text.tap()
        }
    }

    private func review() {
        let review = app.buttons["engine.control.review"]
        reveal(review, identifier: "engine.control.review", in: app.collectionViews.firstMatch)
        XCTAssertTrue(review.isEnabled)
        review.tap()
    }

    private func done() {
        app.buttons["Done"].tap()
        XCTAssertTrue(list.waitForExistence(timeout: 3))
    }

    private func expandNotStarted(in list: XCUIElement) {
        let group = app.buttons["engines.catalog.group.notStarted"]
        reveal(group, identifier: "engines.catalog.group.notStarted", in: list)
        if group.value as? String == "Collapsed" { group.tap() }
    }

    private func catalogToggle() -> XCUIElement {
        let rows = app.collectionViews["engines.list"]
        let toggle = app.switches["engine.toggle.default"]
        expandNotStarted(in: rows)
        reveal(toggle, identifier: "engine.toggle.default", in: rows)
        return toggle
    }

    private func assertDialog(title: String, message: String, label: String) -> XCUIElement {
        let titleText = app.staticTexts[title]
        XCTAssertTrue(titleText.waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts[message].exists)
        XCTAssertEqual(dialogButton("engine.control.confirm", label: label).label, label)
        return titleText
    }

    private func assertDismissed(_ title: XCUIElement, label: String) {
        XCTAssertFalse(title.exists)
        let byId = app.buttons.matching(identifier: "engine.control.confirm").firstMatch
        let confirm = byId.exists ? byId : app.buttons.matching(NSPredicate(format: "label == %@", label)).firstMatch
        XCTAssertFalse(byId.exists)
        XCTAssertFalse(confirm.exists)
    }

    private func assertNoRequests() {
        let requests = element("engines.requests")
        reveal(requests, identifier: "engines.requests", in: list)
        XCTAssertTrue(requests.staticTexts["No recent requests."].exists)
        XCTAssertFalse(requests.staticTexts["fixture-request-1"].exists)
    }

    private func assertOneRequest(value: String? = nil, kind: String? = nil) {
        let requests = element("engines.requests")
        reveal(requests, identifier: "engines.requests", in: list)
        XCTAssertTrue(requests.staticTexts["fixture-request-1"].waitForExistence(timeout: 3))
        if let value { XCTAssertTrue(requests.staticTexts[value].exists) }
        if let kind { XCTAssertTrue(requests.staticTexts.matching(NSPredicate(format: "label == %@", kind)).firstMatch.exists) }
        XCTAssertFalse(requests.staticTexts["fixture-request-2"].exists)
    }

    private func element(_ id: String) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: id).firstMatch
    }

    private func dialogButton(_ id: String, label: String, excluding cardId: String? = nil) -> XCUIElement {
        let byId = app.buttons.matching(identifier: id).firstMatch
        if byId.waitForExistence(timeout: 2) { return byId }
        let predicate = cardId.map { NSPredicate(format: "label == %@ AND identifier != %@", label, $0) }
            ?? NSPredicate(format: "label == %@", label)
        let byLabel = app.buttons.matching(predicate).firstMatch
        XCTAssertTrue(byLabel.waitForExistence(timeout: 3), "no dialog button \(label)")
        return byLabel
    }

    private func dismissConfirmation(_ title: XCUIElement) {
        let cancelLabel = NSPredicate(format: "label ==[c] %@", "Cancel")
        let paths: [() -> Bool] = [
            {
                let button = self.app.buttons.matching(cancelLabel).firstMatch
                guard self.poll(timeout: 3, {
                    button.exists && !button.frame.isEmpty &&
                        button.frame.intersects(self.app.windows.firstMatch.frame) && button.isHittable
                }) else { return false }
                button.tap()
                return true
            },
            {
                let any = self.app.descendants(matching: .any).matching(cancelLabel).firstMatch
                guard any.exists && !any.frame.isEmpty &&
                    any.frame.intersects(self.app.windows.firstMatch.frame) && any.isHittable else { return false }
                any.tap()
                return true
            },
            {
                self.app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.08)).tap()
                return true
            },
            {
                guard title.exists else { return false }
                let screen = self.app.frame
                let box = title.frame
                let y = box.minY > screen.height * 0.3 ? box.minY - 80 : min(box.maxY + 260, screen.height * 0.9)
                self.app.coordinate(withNormalizedOffset: .zero)
                    .withOffset(CGVector(dx: screen.width * 0.97, dy: y)).tap()
                return true
            },
        ]
        for path in paths {
            guard title.exists else { break }
            guard path() else { continue }
            if poll(timeout: 3, { !title.exists }) { break }
        }
        let gone = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: title)
        XCTAssertEqual(XCTWaiter().wait(for: [gone], timeout: 5), .completed, "confirmation dialog did not dismiss")
    }

    private func poll(timeout: TimeInterval, _ condition: () -> Bool) -> Bool {
        let deadline = Date().addingTimeInterval(timeout)
        while Date() < deadline {
            if condition() { return true }
            RunLoop.current.run(until: Date().addingTimeInterval(0.25))
        }
        return condition()
    }

    private func reveal(_ element: XCUIElement, identifier: String, in scroll: XCUIElement) {
        func visibleBand() -> (top: CGFloat, bottom: CGFloat) {
            let top = max(app.navigationBars.firstMatch.frame.maxY + 8, scroll.frame.minY)
            let bottom = min(app.tabBars.firstMatch.exists ? app.tabBars.firstMatch.frame.minY - 8 : app.frame.maxY - 20,
                             scroll.frame.maxY)
            return (top, bottom)
        }
        func revealed() -> Bool {
            let band = visibleBand()
            return element.exists && !element.frame.isEmpty &&
                element.frame.minY >= band.top && element.frame.maxY <= band.bottom && element.isHittable
        }
        func visibleSignature() -> [String] {
            let band = visibleBand()
            return scroll.cells.allElementsBoundByIndex.compactMap { cell in
                let frame = cell.frame
                guard frame.maxY > band.top && frame.minY < band.bottom else { return nil }
                return "\(cell.identifier):\(frame.minY.rounded()):\(frame.height.rounded()):\(cell.label)"
            }
        }
        // Search toward the top even when an offscreen target has not been materialised.
        for downward in [true, false] {
            for _ in 0..<45 {
                if revealed() { return }
                let before = visibleSignature()
                let band = visibleBand()
                guard band.bottom > band.top else { break }
                let height = band.bottom - band.top
                let x = scroll.frame.width * (scroll.identifier == "engines.list" ? 0.97 : 0.5)
                let origin = scroll.coordinate(withNormalizedOffset: .zero)
                let startY = band.top + height * (downward ? 0.25 : 0.75) - scroll.frame.minY
                let endY = band.top + height * (downward ? 0.75 : 0.25) - scroll.frame.minY
                let start = origin.withOffset(CGVector(dx: x, dy: startY))
                let end = origin.withOffset(CGVector(dx: x, dy: endY))
                start.press(forDuration: 0.05, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.2)
                if revealed() { return }
                if visibleSignature() == before { break }
            }
        }
        XCTFail("Could not reveal \(identifier)")
    }

    private func screenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
