import XCTest

final class TabStateUITests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
    }

    func testReselectEnginesReturnsToRoot() {
        openEngineHistory()

        app.tabBars.buttons["Engines"].tap()

        XCTAssertTrue(app.collectionViews["engines.list"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.collectionViews["engine.history.list"].waitForNonExistence(timeout: 5))
        XCTAssertTrue(app.buttons["engine.history.open"].isHittable)
    }

    // Deliberate regression guard: an ordinary tab switch must preserve the navigation stack.
    func testOrdinaryTabSwitchPreservesEngineHistory() {
        openEngineHistory()

        app.tabBars.buttons["Books"].tap()
        XCTAssertTrue(app.tabBars.buttons["Books"].isSelected)
        app.tabBars.buttons["Engines"].tap()

        XCTAssertTrue(app.collectionViews["engine.history.list"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["Sample history"].exists)
        // Back still reaches the original root: the pushed stack was retained.
        app.navigationBars.buttons.firstMatch.tap()
        XCTAssertTrue(app.collectionViews["engines.list"].waitForExistence(timeout: 5))
    }

    private func openEngineHistory() {
        let engines = app.tabBars.buttons["Engines"]
        XCTAssertTrue(engines.waitForExistence(timeout: 5))
        engines.tap()
        let history = app.buttons["engine.history.open"]
        XCTAssertTrue(history.waitForExistence(timeout: 5))
        history.tap()
        XCTAssertTrue(app.collectionViews["engine.history.list"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["Sample history"].exists)
    }
}
