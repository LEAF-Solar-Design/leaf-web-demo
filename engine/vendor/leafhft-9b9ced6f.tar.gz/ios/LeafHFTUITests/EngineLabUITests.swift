import XCTest

/// Replay: fixture launch, Lab, candidate, evidence, collaboration; Engines, Darkhorse, settings.
final class EngineLabUITests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        let appearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] ?? "light"
        XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", appearance,
            "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
    }

    private func screenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "Engine Lab " + name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    /// `x` is the drag column; the Engines list passes its right edge so nested bounded lists do not take the drag.
    private func reveal(_ element: XCUIElement, in list: XCUIElement, x: CGFloat = 0.5) {
        for _ in 0..<60 {
            if element.exists && element.isHittable &&
                element.frame.minY > app.navigationBars.firstMatch.frame.maxY + 4 &&
                element.frame.maxY < (app.tabBars.firstMatch.exists ? app.tabBars.firstMatch.frame.minY : app.frame.maxY) - 8 { return }
            let above = element.exists && element.frame.maxY > 0 &&
                element.frame.minY < app.navigationBars.firstMatch.frame.maxY + 4
            let start = list.coordinate(withNormalizedOffset: CGVector(dx: x, dy: above ? 0.35 : 0.70))
            let end = list.coordinate(withNormalizedOffset: CGVector(dx: x, dy: above ? 0.55 : 0.50))
            start.press(forDuration: 0.05, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        XCTFail("Could not reveal the requested element within 60 scrolls")
    }

    private func expandNotStarted(in list: XCUIElement) {
        let group = app.buttons["engines.catalog.group.notStarted"]
        reveal(group, in: list)
        if group.value as? String == "Collapsed" { group.tap() }
    }

    private func openLab() {
        app.launch()
        app.tabBars.buttons["Lab"].tap()
        XCTAssertTrue(app.collectionViews["engine.lab.list"].waitForExistence(timeout: 3))
    }

    func testDiscoveredCandidatesEvidenceAndAdvisoryCollaborationScreenshots() {
        openLab()
        let list = app.collectionViews["engine.lab.list"]
        let source = app.staticTexts["engine.lab.source"]
        reveal(source, in: list)
        XCTAssertEqual(source.label, "Fixture Engine Lab v3")
        screenshot("v3 source")
        let dip = app.buttons["engine.lab.candidate.dip-recovery"]
        reveal(dip, in: list)
        XCTAssertTrue(dip.label.contains("Research team"))
        XCTAssertTrue(dip.label.contains("Shadow only"))
        screenshot("discovered candidates")
        dip.tap()
        XCTAssertTrue(app.navigationBars["Dip Recovery"].waitForExistence(timeout: 3))
        let detail = app.collectionViews["engine.lab.detail"]
        let disabled = app.buttons["engine.lab.shadowControls"]
        reveal(disabled, in: detail)
        XCTAssertFalse(disabled.isEnabled)
        screenshot("shadow controls and reason")
        // The status reads its mode and whether evidence is still collecting; it is simulated, never a verdict.
        let paperStatus = app.staticTexts["engine.lab.paper.status"]
        reveal(paperStatus, in: detail)
        XCTAssertTrue(paperStatus.label.hasPrefix("Paper · "), paperStatus.label)
        XCTAssertFalse(paperStatus.label.contains("Collecting evidence"), paperStatus.label)
        let paperPnL = app.staticTexts["engine.lab.paper.pnl"]
        reveal(paperPnL, in: detail)
        XCTAssertEqual(paperPnL.label, "Simulated P&L: 2.40 USD")
        screenshot("offline tuning (simulated)")
        for setup in ["A", "B"] {
            let split = app.descendants(matching: .any)["engine.lab.paper.setup.\(setup)"].firstMatch
            reveal(split, in: detail)
            XCTAssertTrue(split.label.contains("Setup \(setup)"))
            XCTAssertTrue(split.label.contains("Simulated P&L"))
        }
        let provenance = app.staticTexts["engine.lab.provenance.0"]
        reveal(provenance, in: detail)
        XCTAssertTrue(provenance.isHittable)
        XCTAssertTrue(provenance.label.hasPrefix("Provenance: "))
        screenshot("replay provenance")
        let decision = app.descendants(matching: .any)["engine.lab.event.decision"].firstMatch
        reveal(decision, in: detail)
        screenshot("advisory decision")
        let assignment = app.descendants(matching: .any)["engine.lab.event.assignment"].firstMatch
        reveal(assignment, in: detail)
        XCTAssertTrue(app.staticTexts["State: in_progress"].exists)
        screenshot("assignment")
        let comment = app.descendants(matching: .any)["engine.lab.event.comment"].firstMatch
        reveal(comment, in: detail)
        screenshot("comment and owner")
        let compose = app.buttons["engine.lab.collaborate"]
        reveal(compose, in: detail)
        compose.tap()
        XCTAssertTrue(app.navigationBars["Advisory note"].waitForExistence(timeout: 3))
        let post = app.buttons["engine.lab.post"]
        XCTAssertTrue(post.waitForExistence(timeout: 3))
        XCTAssertFalse(post.isEnabled)
        screenshot("advisory composer")
    }

    func testNewCandidateIsRenderedWithoutBundledLane() {
        openLab()
        let candidate = app.buttons["engine.lab.candidate.atlas-discovery"]
        reveal(candidate, in: app.collectionViews["engine.lab.list"])
        XCTAssertTrue(candidate.label.contains("Atlas Discovery"))
        candidate.tap()
        XCTAssertTrue(app.navigationBars["Atlas Discovery"].waitForExistence(timeout: 3))
        let detail = app.collectionViews["engine.lab.detail"]
        let status = app.staticTexts["engine.lab.paper.status"]
        reveal(status, in: detail)
        XCTAssertEqual(status.label, "Paper · Collecting evidence")
        let pnl = app.staticTexts["engine.lab.paper.pnl"]
        reveal(pnl, in: detail)
        XCTAssertEqual(pnl.label, "Simulated P&L: Unavailable")
        screenshot("newly discovered trial")
    }

    func testGeneratedEngineRowLinksToPaperResultsInLab() {
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        let list = app.collectionViews["engines.list"]
        let rows = app.scrollViews["engines.paper.rows"]
        reveal(rows, in: list)
        let candidate = app.buttons["engine.paper.candidate.atlas-discovery"]
        reveal(candidate, in: rows)
        XCTAssertTrue(candidate.label.contains("Paper"))
        XCTAssertTrue(candidate.label.contains("Collecting evidence"))
        XCTAssertTrue(candidate.label.contains("Simulated P&L: Unavailable"))
        candidate.tap()
        XCTAssertTrue(app.navigationBars["Atlas Discovery"].waitForExistence(timeout: 3))
        screenshot("generated engine Lab link")
    }

    /// Risky Batman is the probe control: runner lifecycle and breaker meter, Probe and Halt; its tuning block reads
    /// "Offline tuning (simulated)" and no permanently disabled live-deploy button or paper-before-live rule remains.
    func testRiskyBatmanIsTheProbeControlAndTuningReadsOfflineSimulated() {
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        let list = app.collectionViews["engines.list"]
        XCTAssertTrue(list.waitForExistence(timeout: 10))
        let notProbing = app.descendants(matching: .any)["risky.risky-batman-15m.state"].firstMatch
        reveal(notProbing, in: list, x: 0.97)
        XCTAssertEqual(notProbing.label, "Not probing")
        let probe = app.buttons["risky.risky-batman-15m.probe"]
        reveal(probe, in: list, x: 0.97)
        XCTAssertTrue(probe.isEnabled)
        let probing = app.descendants(matching: .any)["risky.risky-batman-1h.state"].firstMatch
        reveal(probing, in: list, x: 0.97)
        XCTAssertEqual(probing.label, "Probing")
        let breaker = app.staticTexts["risky.risky-batman-1h.breaker"]
        reveal(breaker, in: list, x: 0.97)
        XCTAssertEqual(breaker.label, "Breaker: -$12.40 of $1,250.00 (50%) · UTC day")
        let halt = app.buttons["risky.risky-batman-1h.halt"]
        reveal(halt, in: list, x: 0.97)
        XCTAssertTrue(halt.isEnabled)
        screenshot("Risky Batman probe control")
        let tuning = app.staticTexts["risky.risky-batman-1h.tuning"]
        reveal(tuning, in: list, x: 0.97)
        XCTAssertEqual(tuning.label, "Offline tuning (simulated)")
        let countdown = app.staticTexts["risky.risky-batman-1h.countdown"]
        reveal(countdown, in: list, x: 0.97)
        XCTAssertEqual(countdown.label, "47 min of tuning left at these settings")
        for id in ["risky.risky-batman-15m.deploy", "risky.risky-batman-1h.deploy"] {
            XCTAssertFalse(app.buttons[id].exists, id)
        }
        XCTAssertFalse(app.staticTexts["risky.risky-batman-1h.liveReason"].exists)
        screenshot("Risky Batman offline tuning")
    }

    func testOfflineFallbackIsExplicitlyLabelled() {
        app.launchArguments += ["-LEAFHFT_LAB_OFFLINE"]
        openLab()
        let fallback = app.staticTexts["engine.lab.offline"]
        reveal(fallback, in: app.collectionViews["engine.lab.list"])
        XCTAssertTrue(fallback.label.contains("Offline fallback only"))
        XCTAssertFalse(app.staticTexts["engine.lab.source"].exists)
        screenshot("offline fallback only")
    }

    func testDarkhorseUsesExistingEngineCardAndAccountSettings() {
        app.launchArguments += ["-LEAFHFT_LAB_CONTROLS", "-LEAFHFT_CONTROL_WALK", "1"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        let card = app.buttons["engine.detail.darkhorse"]
        expandNotStarted(in: app.collectionViews["engines.list"])
        reveal(card, in: app.collectionViews["engines.list"])
        XCTAssertTrue(card.label.contains("Darkhorse"))
        screenshot("Darkhorse engine card")
        card.tap()
        let configure = app.buttons["engine.configure.darkhorse"]
        reveal(configure, in: app.collectionViews.firstMatch)
        configure.tap()
        XCTAssertTrue(app.navigationBars["Engine settings"].waitForExistence(timeout: 3))
        let scope = app.buttons["engine.settings.scopePicker"]
        XCTAssertTrue(scope.waitForExistence(timeout: 2))
        scope.tap()
        let account = app.buttons.matching(NSPredicate(format: "label CONTAINS[c] %@", "Main")).firstMatch
        XCTAssertTrue(account.waitForExistence(timeout: 2))
        account.tap()
        screenshot("Darkhorse account scope")
        let form = app.collectionViews["engine.settings.form"]
        let enabled = app.switches["engine.settings.enabled"]
        reveal(enabled, in: form)
        XCTAssertTrue(enabled.isEnabled)
        let base = app.textFields["engine.settings.field.base_count"]
        reveal(base, in: form)
        XCTAssertEqual(base.value as? String, "0.1")
        screenshot("Darkhorse base count")
        let multiplier = app.textFields["engine.settings.field.max_mult"]
        reveal(multiplier, in: form)
        XCTAssertEqual(multiplier.value as? String, "2")
        screenshot("Darkhorse maximum multiplier")
        let threshold = app.textFields["engine.settings.field.score_threshold_120"]
        reveal(threshold, in: form)
        XCTAssertEqual(threshold.value as? String, "65")
        screenshot("Darkhorse upward-only threshold")
    }
}
