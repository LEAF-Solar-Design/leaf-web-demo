import XCTest

final class AssistantUITests: XCTestCase {
    @MainActor func testAutotunePullToRefreshKeepsOpenCardsWithoutRetry() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1"]
        app.launch()
        let launcher = app.buttons["studio.launcher"]
        XCTAssertTrue(launcher.waitForExistence(timeout: 5))
        launcher.tap()
        let autotune = app.buttons["assistant.tab.autotune"]
        XCTAssertTrue(autotune.waitForExistence(timeout: 5))
        autotune.tap()
        let scroll = app.descendants(matching: .any)["assistant.inbox.scroll"].firstMatch
        let firstApprove = app.buttons["assistant.inbox.card.card-fixture-tune.approve"]
        XCTAssertTrue(firstApprove.waitForExistence(timeout: 5))
        XCTAssertTrue(scroll.exists)
        scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.2))
            .press(forDuration: 0.05, thenDragTo: scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.85)))
        waitForAbsence(app.descendants(matching: .any)["assistant.inbox.loading"].firstMatch)
        XCTAssertFalse(app.descendants(matching: .any)["assistant.inbox.retry"].firstMatch.exists)
        XCTAssertTrue(firstApprove.exists)
        XCTAssertTrue(app.staticTexts["assistant.inbox.card.card-fixture-tune.state"].exists)
        let secondApprove = app.buttons["assistant.inbox.card.card-fixture-slot.approve"]
        reveal(secondApprove, in: scroll)
        XCTAssertTrue(secondApprove.exists)
        XCTAssertFalse(app.descendants(matching: .any)["assistant.inbox.retry"].firstMatch.exists)
    }

    @MainActor func testAutotuneInboxLight() {
        exerciseAutotuneInbox(appearance: "light")
    }

    @MainActor func testAutotuneInboxDark() {
        exerciseAutotuneInbox(appearance: "dark")
    }

    @MainActor private func exerciseAutotuneInbox(appearance: String) {
        continueAfterFailure = false
        XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", appearance,
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
        let appearanceReadback = app.staticTexts["fixture.renderedAppearance"]
        XCTAssertTrue(appearanceReadback.waitForExistence(timeout: 5))
        XCTAssertEqual(appearanceReadback.value as? String, appearance)
        let launcherBadge = app.descendants(matching: .any)["assistant.launcher.badge"].firstMatch
        XCTAssertTrue(launcherBadge.waitForExistence(timeout: 5))
        XCTAssertTrue(launcherBadge.label.contains("5"))
        app.buttons["studio.launcher"].tap()
        let chat = app.buttons["assistant.tab.chat"]
        let autotune = app.buttons["assistant.tab.autotune"]
        XCTAssertTrue(chat.waitForExistence(timeout: 5))
        XCTAssertEqual(chat.value as? String, "Selected")
        let tabBadge = app.descendants(matching: .any)["assistant.tab.autotune.badge"].firstMatch
        XCTAssertTrue(tabBadge.waitForExistence(timeout: 3))
        autotune.tap()
        let scroll = app.descendants(matching: .any)["assistant.inbox.scroll"].firstMatch
        let firstApprove = app.buttons["assistant.inbox.card.card-fixture-tune.approve"]
        XCTAssertTrue(firstApprove.waitForExistence(timeout: 5))
        waitForAbsence(tabBadge)
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "GOLD Gold Scout")).firstMatch.exists)
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "10 → 8")).firstMatch.exists)
        XCTAssertEqual(app.staticTexts["assistant.inbox.card.card-fixture-tune.state"].label, "fixture-gold · Open")
        XCTAssertGreaterThanOrEqual(firstApprove.frame.height, 44)
        attachScreenshot(app, name: "assistant-autotune-\(appearance)")

        let secondApprove = app.buttons["assistant.inbox.card.card-fixture-slot.approve"]
        reveal(secondApprove, in: scroll)
        XCTAssertEqual(secondApprove.label, "Save")
        XCTAssertGreaterThanOrEqual(secondApprove.frame.height, 44)
        let ownApprove = app.buttons["assistant.inbox.nomination.0000000000000001.approve"]
        reveal(ownApprove, in: scroll)
        XCTAssertEqual(ownApprove.label, "Approve")
        XCTAssertGreaterThanOrEqual(ownApprove.frame.height, 44)
        waitForEnabled(ownApprove)
        ownApprove.tap()
        let acceptedConfirmation = app.alerts["Confirm approval"]
        XCTAssertTrue(acceptedConfirmation.waitForExistence(timeout: 5))
        let acceptedDetails = acceptedConfirmation.staticTexts.matching(
            NSPredicate(format: "label CONTAINS %@", "Risk limit: 10 → 8")).firstMatch
        XCTAssertTrue(acceptedDetails.exists)
        XCTAssertTrue(acceptedDetails.label.contains("Tune Gold Scout"))
        XCTAssertFalse(app.staticTexts["assistant.inbox.approved.notice"].exists)
        acceptedConfirmation.buttons["Cancel"].tap()
        XCTAssertTrue(ownApprove.exists, "Cancel must leave the suggestion available")
        let ownReview = app.buttons["assistant.inbox.nomination.0000000000000001.review"]
        reveal(ownReview, in: scroll)
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "42 trades · return 3.2% · LB90 1.1%")).firstMatch.exists)
        let otherDiscuss = app.buttons["assistant.inbox.nomination.0000000000000002.discuss"]
        reveal(otherDiscuss, in: scroll)
        XCTAssertTrue(app.staticTexts["assistant.inbox.nomination.0000000000000002.account"].label.contains("other-account"))
        XCTAssertFalse(app.buttons["assistant.inbox.nomination.0000000000000002.review"].exists)
        XCTAssertFalse(app.buttons["assistant.inbox.nomination.0000000000000002.approve"].exists)
        let promoteDiscuss = app.buttons["assistant.inbox.nomination.0000000000000003.discuss"]
        reveal(promoteDiscuss, in: scroll)
        XCTAssertEqual(app.staticTexts["assistant.inbox.nomination.0000000000000003.reason"].label,
                       "Promotions and book changes cannot be approved here yet.")
        XCTAssertFalse(app.buttons["assistant.inbox.nomination.0000000000000003.review"].exists)
        XCTAssertFalse(app.buttons["assistant.inbox.nomination.0000000000000003.approve"].exists)
        attachScreenshot(app, name: "assistant-autotune-suggestions-\(appearance)")

        // Re-entering the tab starts at the top and uses the same seen marker.
        chat.tap()
        autotune.tap()
        let cardDiscuss = app.buttons["assistant.inbox.card.card-fixture-tune.discuss"]
        XCTAssertTrue(cardDiscuss.waitForExistence(timeout: 5))
        reveal(cardDiscuss, in: scroll)
        cardDiscuss.tap()
        let prompt = app.descendants(matching: .any)["assistant.prompt"].firstMatch
        XCTAssertTrue(prompt.waitForExistence(timeout: 5))
        XCTAssertEqual(chat.value as? String, "Selected")
        XCTAssertTrue((prompt.value as? String)?.contains("card-fixture-tune") == true)
        XCTAssertTrue((prompt.value as? String)?.hasPrefix("Discuss ") == true)
        XCTAssertFalse(app.staticTexts["assistant.reply.error"].exists)
        attachScreenshot(app, name: "assistant-chat-after-discuss-\(appearance)")

        autotune.tap()
        XCTAssertTrue(firstApprove.waitForExistence(timeout: 5))
        reveal(firstApprove, in: scroll)
        waitForEnabled(firstApprove)
        firstApprove.tap()
        let confirmation = app.alerts["Confirm approval"]
        XCTAssertTrue(confirmation.waitForExistence(timeout: 3))
        let details = confirmation.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "Risk limit: 10 → 8")).firstMatch
        XCTAssertTrue(details.exists)
        XCTAssertTrue(details.label.contains("Tune Gold Scout"))
        confirmation.buttons["Cancel"].tap()
        XCTAssertTrue(firstApprove.exists, "Cancel must leave the card waiting")
        XCTAssertEqual(app.staticTexts["assistant.inbox.card.card-fixture-tune.state"].label, "fixture-gold · Open")
        XCTAssertFalse(app.staticTexts["assistant.inbox.approved.notice"].exists)
        firstApprove.tap()
        XCTAssertTrue(confirmation.waitForExistence(timeout: 3))
        // An identified SwiftUI alert action is exposed as nested buttons with the same label,
        // so the query is not unique; either element is the same Approve action.
        confirmation.buttons["Approve"].firstMatch.tap()
        let approvedNotice = app.staticTexts["assistant.inbox.approved.notice"]
        XCTAssertTrue(approvedNotice.waitForExistence(timeout: 5))
        XCTAssertEqual(approvedNotice.label, "Approved: Tune Gold Scout")
        waitForAbsence(firstApprove)
        waitForAbsence(app.descendants(matching: .any)["assistant.inbox.card.card-fixture-tune"].firstMatch)
        XCTAssertFalse(app.buttons["assistant.inbox.card.card-fixture-tune.approve"].exists)
        app.buttons["assistant.close"].tap()
        XCTAssertTrue(app.buttons["studio.launcher"].waitForExistence(timeout: 5))
        waitForAbsence(launcherBadge)
    }

    @MainActor func testAutotuneReviewSendsIntoChat() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1"]
        app.launch()
        XCTAssertTrue(app.buttons["studio.launcher"].waitForExistence(timeout: 5))
        app.buttons["studio.launcher"].tap()
        XCTAssertTrue(app.buttons["assistant.tab.autotune"].waitForExistence(timeout: 5))
        app.buttons["assistant.tab.autotune"].tap()
        let scroll = app.descendants(matching: .any)["assistant.inbox.scroll"].firstMatch
        let review = app.buttons["assistant.inbox.nomination.0000000000000001.review"]
        reveal(review, in: scroll)
        review.tap()
        XCTAssertTrue(app.staticTexts["Review autotune suggestion 0000000000000001"].waitForExistence(timeout: 10))
        XCTAssertEqual(app.buttons["assistant.tab.chat"].value as? String, "Selected")
        XCTAssertFalse(app.descendants(matching: .any)["assistant.inbox.scroll"].firstMatch.exists)
        XCTAssertFalse(app.staticTexts["assistant.review.busy"].exists)
    }

    @MainActor func testAutotuneButtonsAtLargestDynamicType() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1",
                               "-" + "UIPreferredContentSizeCategoryName", "UICTContentSizeCategoryAccessibilityXXXL"]
        app.launch()
        let launcher = app.buttons["studio.launcher"]
        XCTAssertTrue(launcher.waitForExistence(timeout: 5))
        attachScreenshot(app, name: "assistant-launcher-xxxl")
        attachHierarchy(app, name: "assistant-launcher-xxxl-hierarchy")
        XCTAssertTrue(launcher.isHittable, "Launcher is not hittable at AX XXXL.\n\(app.debugDescription)")
        launcher.tap()
        let autotune = app.buttons["assistant.tab.autotune"]
        let autotuneExists = autotune.waitForExistence(timeout: 5)
        attachScreenshot(app, name: "assistant-after-launcher-xxxl")
        attachHierarchy(app, name: "assistant-after-launcher-xxxl-hierarchy")
        XCTAssertTrue(autotuneExists,
                      "Autotune is missing at AX XXXL. Assistant navigation: \(app.navigationBars["Assistant"].exists); close: \(app.buttons["assistant.close"].exists); Chat: \(app.buttons["assistant.tab.chat"].exists).\n\(app.debugDescription)")
        let chat = app.buttons["assistant.tab.chat"]
        XCTAssertTrue(chat.exists)
        for button in [chat, autotune] {
            XCTAssertTrue(button.isHittable)
            XCTAssertGreaterThanOrEqual(button.frame.height, 44)
            XCTAssertGreaterThanOrEqual(button.frame.minX, app.frame.minX)
            XCTAssertLessThanOrEqual(button.frame.maxX, app.frame.maxX)
            XCTAssertGreaterThanOrEqual(button.frame.minY, app.navigationBars["Assistant"].frame.maxY)
            XCTAssertLessThanOrEqual(button.frame.maxY, app.frame.maxY)
        }
        autotune.tap()
        let scroll = app.descendants(matching: .any)["assistant.inbox.scroll"].firstMatch
        let approve = app.buttons["assistant.inbox.card.card-fixture-tune.approve"]
        reveal(approve, in: scroll)
        XCTAssertGreaterThanOrEqual(approve.frame.height, 44)
        XCTAssertGreaterThanOrEqual(approve.frame.minX, 0)
        XCTAssertLessThanOrEqual(approve.frame.maxX, app.frame.maxX)
        let discuss = app.buttons["assistant.inbox.card.card-fixture-tune.discuss"]
        reveal(discuss, in: scroll)
        XCTAssertGreaterThanOrEqual(discuss.frame.height, 44)
        XCTAssertGreaterThanOrEqual(discuss.frame.minX, 0)
        XCTAssertLessThanOrEqual(discuss.frame.maxX, app.frame.maxX)
        let ownApprove = app.buttons["assistant.inbox.nomination.0000000000000001.approve"]
        reveal(ownApprove, in: scroll)
        XCTAssertGreaterThanOrEqual(ownApprove.frame.height, 44)
        XCTAssertGreaterThanOrEqual(ownApprove.frame.minX, 0)
        XCTAssertLessThanOrEqual(ownApprove.frame.maxX, app.frame.maxX)
        waitForEnabled(ownApprove)
        ownApprove.tap()
        let confirmation = app.alerts["Confirm approval"]
        XCTAssertTrue(confirmation.waitForExistence(timeout: 5))
        confirmation.buttons["Cancel"].tap()
        attachScreenshot(app, name: "assistant-autotune-xxxl")
    }

    @MainActor private func attachHierarchy(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(string: app.debugDescription)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    @MainActor private func reveal(_ element: XCUIElement, in scroll: XCUIElement) {
        XCTAssertTrue(scroll.waitForExistence(timeout: 5))
        for _ in 0..<40 {
            if element.exists && element.isHittable { return }
            scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.08, dy: 0.65))
                .press(forDuration: 0.05, thenDragTo: scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.08, dy: 0.25)))
        }
        XCTFail("Could not reach \(element.identifier)")
    }

    @MainActor private func waitForAbsence(_ element: XCUIElement) {
        let gone = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: element)
        XCTAssertEqual(XCTWaiter.wait(for: [gone], timeout: 5), .completed)
    }

    @MainActor private func waitForEnabled(_ element: XCUIElement) {
        let enabled = XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: element)
        XCTAssertEqual(XCTWaiter.wait(for: [enabled], timeout: 5), .completed)
    }

    @MainActor private func attachScreenshot(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    @MainActor func testAssistantConversation() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1"]
        app.launch()
        let launcher = app.buttons["studio.launcher"]
        XCTAssertTrue(launcher.waitForExistence(timeout: 5))
        launcher.tap()
        XCTAssertTrue(app.navigationBars["Assistant"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["assistant.empty"].waitForExistence(timeout: 5))
        app.buttons["assistant.starter.0"].tap()
        app.buttons["assistant.send"].tap()
        let answer = app.staticTexts.matching(NSPredicate(format: "identifier == %@ AND label CONTAINS %@",
            "assistant.reply.text", "$238.81")).firstMatch
        XCTAssertTrue(answer.waitForExistence(timeout: 10))
        XCTAssertTrue(app.descendants(matching: .any)["assistant.panel.line"].firstMatch.waitForExistence(timeout: 10))
        XCTAssertTrue(app.descendants(matching: .any)["assistant.panel.metric"].firstMatch.waitForExistence(timeout: 10))
        XCTAssertFalse(app.staticTexts["assistant.reply.error"].exists)
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "assistant-conversation"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }

    @MainActor func testEngineBuildingToggleAndPaperEngineReply() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_ASSISTANT_V2", "0"]
        app.launch()
        let launcher = app.buttons["studio.launcher"]
        XCTAssertTrue(launcher.waitForExistence(timeout: 5))
        launcher.tap()
        let toggle = app.buttons["assistant.engineToggle"]
        let prompt = app.descendants(matching: .any)["assistant.prompt"].firstMatch
        let note = app.staticTexts["assistant.engineNote"]
        XCTAssertTrue(toggle.waitForExistence(timeout: 5))
        XCTAssertEqual(toggle.value as? String, "Off")
        XCTAssertGreaterThanOrEqual(toggle.frame.height, 44)
        XCTAssertFalse(note.exists)
        XCTAssertEqual(prompt.placeholderValue, "Ask about your account")
        toggle.tap()
        XCTAssertEqual(toggle.value as? String, "On")
        XCTAssertTrue(note.exists)
        XCTAssertEqual(note.label, "Builds paper engines only. Nothing trades.")
        XCTAssertEqual(prompt.placeholderValue, "Describe an engine to build")
        XCTAssertTrue(app.buttons["Build a paper engine for gold 15-minute markets"].exists)
        XCTAssertTrue(app.buttons["Show my engine builds"].exists)
        toggle.tap()
        XCTAssertEqual(toggle.value as? String, "Off")
        XCTAssertFalse(note.exists)
        XCTAssertEqual(prompt.placeholderValue, "Ask about your account")
        toggle.tap()
        prompt.tap()
        prompt.typeText("Build a paper engine for gold 15-minute markets")
        app.buttons["assistant.send"].tap()
        XCTAssertTrue(app.staticTexts["Paper engine fixture-engine"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.descendants(matching: .any)["assistant.panel.table"].firstMatch.waitForExistence(timeout: 10))
        XCTAssertFalse(app.staticTexts["assistant.reply.error"].exists)
        expectation(for: NSPredicate(format: "enabled == true"), evaluatedWith: toggle)
        waitForExpectations(timeout: 5)
        XCTAssertEqual(toggle.value as? String, "On")
        app.buttons["assistant.new"].tap()
        XCTAssertTrue(app.staticTexts["assistant.empty"].waitForExistence(timeout: 5))
        XCTAssertEqual(toggle.value as? String, "On")
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "assistant-engine-building"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }
}
