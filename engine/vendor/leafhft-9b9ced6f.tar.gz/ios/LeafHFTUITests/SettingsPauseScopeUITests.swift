import XCTest

final class SettingsPauseScopeUITests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        let appearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] ?? "light"
        XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", appearance,
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
    }

    private func screenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    private func reveal(_ element: XCUIElement, in scroll: XCUIElement, limit: Int = 35) {
        for _ in 0..<limit {
            if element.exists && element.isHittable { return }
            let start = scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.08, dy: 0.60))
            let end = scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.08, dy: 0.20))
            start.press(forDuration: 0, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0)
        }
        XCTFail("Could not reach \(element.identifier)")
    }

    // The walk fixture's lane id is 9a8b7c6d-5e4f-4a3b-8c2d-1e0f9a8b7c6d (AppState.pauseScopeWalkStatus).
    // Pause names that lane, never Monitor's owner-runner label.
    private let laneLabel = "this phone's Kashbot account (lane 9a8b7c6d)"

    private func openSettings() -> XCUIElement {
        app.tabBars.buttons["Settings"].tap()
        let form = app.collectionViews["settings.form"]
        XCTAssertTrue(form.waitForExistence(timeout: 5))
        return form
    }

    func testPauseCaptionNamesAccountAndRevokeIsSeparated() throws {
        app.launchArguments += ["-LEAFHFT_PAUSE_SCOPE_WALK"]
        app.launch()
        let form = openSettings()

        let pause = app.buttons["settings.pauseTrading"]
        reveal(pause, in: form)
        XCTAssertEqual(pause.label, "Pause trading")

        let scope = app.staticTexts["settings.pauseTrading.scope"]
        XCTAssertTrue(scope.waitForExistence(timeout: 2))
        XCTAssertTrue(scope.label.contains("Applies to \(laneLabel) only."), scope.label)
        XCTAssertFalse(scope.label.contains("Main runner"), scope.label)
        XCTAssertTrue(scope.label.contains("no new live orders"), scope.label)
        XCTAssertTrue(scope.label.contains("Other runners, including the owner runner's books, keep running."), scope.label)
        XCTAssertTrue(scope.label.contains("Open positions are not sold."), scope.label)
        XCTAssertFalse(scope.label.contains("no resume control"), scope.label)
        XCTAssertGreaterThanOrEqual(scope.frame.minY, pause.frame.maxY - 1)
        screenshot("Pause trading scope")

        // Pause is one tap: no confirmation dialog stands between the tap and the action.
        let recorded = app.staticTexts["settings.pauseTrading.recorded"]
        XCTAssertFalse(recorded.exists)
        XCTAssertTrue(pause.isEnabled)
        pause.tap()
        XCTAssertTrue(recorded.waitForExistence(timeout: 2))
        XCTAssertEqual(recorded.label, "pause recorded")
        XCTAssertEqual(recorded.value as? String, "1")
        XCTAssertFalse(app.alerts.firstMatch.waitForExistence(timeout: 1))
        XCTAssertFalse(app.sheets.firstMatch.exists)

        // Revoke sits in its own "Runner access" section below Pause, never in the Pause section.
        let revoke = app.buttons["settings.revokeRunner"]
        let header = app.descendants(matching: .any)["settings.revokeSection"].firstMatch
        reveal(revoke, in: form)
        XCTAssertTrue(header.waitForExistence(timeout: 2))
        XCTAssertLessThanOrEqual(header.frame.maxY, revoke.frame.minY + 1)
        // Offscreen list rows may be recycled; compare frames only while both rows are still present.
        if scope.exists && pause.exists && !scope.frame.isEmpty {
            XCTAssertLessThan(scope.frame.maxY, header.frame.minY)
            XCTAssertGreaterThanOrEqual(revoke.frame.minY - pause.frame.maxY, 44)
        }
        screenshot("Revoke separated from Pause")
    }

    func testLiveTradingStateAppearsOnce() throws {
        // AppState loads the bound live status and runs updateSetupMessage, so this
        // walk catches a duplicate setup result as well as repeated view copy.
        app.launchArguments += ["-LEAFHFT_PAUSE_SCOPE_WALK"]
        app.launch()
        let form = openSettings()

        let state = app.descendants(matching: .any)["settings.laneState"].firstMatch
        XCTAssertTrue(state.waitForExistence(timeout: 2))
        XCTAssertEqual(state.label, "Automated trading, Live trading enabled")
        let tradingLabel = NSPredicate(
            format: "label == %@ OR label == %@",
            "Live trading enabled", "Automated trading, Live trading enabled")
        // Form cells can repeat their child's accessibility label. Count the deepest
        // matching elements so a cell and its child are one presentation, while a
        // separate badge, warning, or status row still counts as a duplicate.
        let labels = app.descendants(matching: .any).matching(tradingLabel)
            .allElementsBoundByIndex.filter {
                $0.descendants(matching: .any).matching(tradingLabel).count == 0
            }
        XCTAssertEqual(labels.count, 1)
        // Reveal the setup area separately: Form can recycle offscreen rows, so
        // counting labels at the top alone could miss a duplicate setup message.
        reveal(app.buttons["settings.checkLaneProgress"], in: form)
        reveal(app.staticTexts["Use Kalshi’s website"], in: form)
        XCTAssertFalse(app.staticTexts["settings.setupResult"].exists,
                       "A bound live account must not repeat its trading state as a setup result")
        screenshot("Single trading state")
    }

    private func assertTourReachableAfterAtMostOneScroll() {
        let form = openSettings()
        let tour = app.buttons["settings.showTourShortcut"]
        if !tour.isHittable { form.swipeUp() }
        XCTAssertTrue(tour.exists)
        XCTAssertTrue(tour.isHittable)
        XCTAssertEqual(tour.label, "Show me around")
        screenshot("Tour near Settings top")
    }

    func testLiveTourReachableAfterAtMostOneScroll() throws {
        app.launchArguments += ["-LEAFHFT_PAUSE_SCOPE_WALK"]
        app.launch()
        assertTourReachableAfterAtMostOneScroll()
    }

    func testSetupTourReachableAfterAtMostOneScroll() throws {
        app.launch()
        assertTourReachableAfterAtMostOneScroll()
    }

    func testOwnerExecutionHidesAccountTradingControls() throws {
        let baseArguments = app.launchArguments
        for trading in ["live", "dry_run", "paused"] {
            app.launchArguments = baseArguments + ["-LEAFHFT_OWNER_EXECUTION_WALK", trading]
            app.launch()
            let form = openSettings()

            XCTAssertFalse(app.buttons["settings.pauseTrading"].exists, trading)
            XCTAssertFalse(app.buttons["settings.enableLive"].exists, trading)
            XCTAssertFalse(app.buttons["settings.resumeTrading"].exists, trading)
            XCTAssertFalse(app.staticTexts["settings.pauseTrading.pausedScope"].exists, trading)
            XCTAssertFalse(app.staticTexts["settings.enrolledKeyChanged"].exists, trading)

            let ownerText = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "Control the owner books with Pause and Start on Monitor.")).firstMatch
            reveal(ownerText, in: form)
            XCTAssertTrue(ownerText.exists, trading)
            XCTAssertFalse(app.buttons["settings.pauseTrading"].exists, trading)
            XCTAssertFalse(app.buttons["settings.enableLive"].exists, trading)
            app.terminate()
        }
    }

    func testPausedLineNamesAccount() throws {
        app.launchArguments += ["-LEAFHFT_PAUSED_SCOPE_WALK"]
        app.launch()
        let form = openSettings()

        let paused = app.staticTexts["settings.pauseTrading.pausedScope"]
        reveal(paused, in: form)
        XCTAssertEqual(paused.label, "Paused for \(laneLabel). No new live orders.")
        XCTAssertFalse(paused.label.contains("Main runner"), paused.label)
        XCTAssertFalse(app.buttons["settings.pauseTrading"].exists)
        let resume = app.buttons["settings.resumeTrading"]
        reveal(resume, in: form)
        XCTAssertEqual(resume.label, "Resume trading")
        XCTAssertFalse(resume.isEnabled, "Fixtures cannot authorize real runner actions")
        reveal(app.buttons["settings.revokeRunner"], in: form)
        XCTAssertTrue(app.descendants(matching: .any)["settings.revokeSection"].firstMatch.exists
                      || app.buttons["settings.revokeRunner"].exists)
    }

    func testLivePendingPauseIsOneTapDuringMutation() throws {
        app.launchArguments += ["-LEAFHFT_PAUSE_SCOPE_WALK", "-LEAFHFT_SETTINGS_PENDING_WALK",
                                "-LEAFHFT_SETTINGS_MUTATION_WALK"]
        app.launch()
        let form = openSettings()
        let pause = app.buttons["settings.pauseTrading"]
        reveal(pause, in: form)
        XCTAssertTrue(pause.isEnabled)
        pause.tap()
        let recorded = app.staticTexts["settings.pauseTrading.recorded"]
        XCTAssertTrue(recorded.waitForExistence(timeout: 2))
        XCTAssertEqual(recorded.value as? String, "1")
        XCTAssertFalse(app.alerts.firstMatch.exists)
        XCTAssertFalse(app.sheets.firstMatch.exists)

        let tour = app.buttons["settings.showTourShortcut"]
        reveal(tour, in: form)
        XCTAssertTrue(tour.isEnabled, "An account mutation must not disable the entire form")
        let connect = app.buttons["settings.setupDryRun"]
        reveal(connect, in: form)
        XCTAssertFalse(connect.isEnabled)
        screenshot("Pending Pause during start mutation")
    }

    func testLivePauseRemainsEnabledDuringMutation() throws {
        app.launchArguments += ["-LEAFHFT_PAUSE_SCOPE_WALK", "-LEAFHFT_SETTINGS_MUTATION_WALK"]
        app.launch()
        let form = openSettings()
        let pause = app.buttons["settings.pauseTrading"]
        reveal(pause, in: form)
        XCTAssertTrue(pause.isEnabled)
        pause.tap()
        XCTAssertTrue(app.staticTexts["settings.pauseTrading.recorded"].waitForExistence(timeout: 2))
    }

    func testSavedKeyCopyDisclosesEncryptedRunnerEnrollment() throws {
        app.launchArguments += ["-LEAFHFT_CONNECTION_WALK"]
        app.launch()
        let form = openSettings()
        let copy = app.staticTexts["settings.keyStorage"]
        reveal(copy, in: form)
        XCTAssertTrue(copy.label.contains("Keychain"), copy.label)
        XCTAssertTrue(copy.label.contains("encrypts and enrolls a runner copy"), copy.label)
        XCTAssertFalse(copy.label.contains("stays in"), copy.label)
    }

    func testOwnerSavedKeyCopyDescribesReadOnlyPhoneAccess() throws {
        app.launchArguments += ["-LEAFHFT_CONNECTION_WALK", "-LEAFHFT_OWNER_EXECUTION_WALK", "live"]
        app.launch()
        let form = openSettings()
        let copy = app.staticTexts["settings.keyStorage"]
        reveal(copy, in: form)
        XCTAssertTrue(copy.label.contains("read-only phone access"), copy.label)
        XCTAssertFalse(copy.label.contains("enrolls"), copy.label)
    }

    func testTourKeyCopyDisclosesOwnerAndNonOwnerStorage() throws {
        app.launchArguments += ["-LEAFHFT_TOUR"]
        app.launch()
        let title = app.staticTexts["tour.title"]
        XCTAssertTrue(title.waitForExistence(timeout: 3))
        for _ in 0..<6 {
            if title.label == "Connect and come back anytime" { break }
            app.buttons["tour.next"].tap()
        }
        XCTAssertEqual(title.label, "Connect and come back anytime")
        let copy = app.staticTexts["tour.message"].label
        XCTAssertTrue(copy.contains("encrypts and enrolls a runner copy"), copy)
        XCTAssertTrue(copy.contains("Owner setup saves the key for read-only phone access"), copy)
        XCTAssertFalse(copy.contains("stays on this device"), copy)
    }
}
