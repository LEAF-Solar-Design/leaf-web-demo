import XCTest

final class BooksUITests: XCTestCase {
    private var app: XCUIApplication!
    private var expectedAppearance = "light"

    override func setUpWithError() throws {
        continueAfterFailure = false
        expectedAppearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] ?? "light"
        XCUIDevice.shared.appearance = expectedAppearance == "dark" ? .dark : .light
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", expectedAppearance,
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
    }

    func testBooksListAndDetail() throws {
        app.launch()
        app.tabBars.buttons["Books"].tap()
        let count = app.staticTexts["books.count"]
        XCTAssertTrue(count.waitForExistence(timeout: 3))
        XCTAssertEqual(count.label, "14 books")
        XCTAssertFalse(app.staticTexts["Open tickets"].exists)
        XCTAssertFalse(app.staticTexts["Cost at risk"].exists)
        XCTAssertTrue(app.staticTexts["Next close"].exists)

        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "books", withExtension: "json", subdirectory: "Fixtures"))
        let fixture = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
        let books = try XCTUnwrap(fixture["books"] as? [[String: Any]])
        let lastID = try XCTUnwrap(books.compactMap { $0["book_id"] as? String }.sorted().last)
        let list = app.descendants(matching: .any)["books.scroll"].firstMatch
        XCTAssertTrue(list.waitForExistence(timeout: 2))
        XCTAssertTrue(app.descendants(matching: .any)["books.openTable"].firstMatch.exists)
        XCTAssertTrue(app.descendants(matching: .any)["books.handTable"].firstMatch.exists)
        let rows = app.scrollViews["books.rows"].firstMatch
        revealRows(rows, on: list)
        let lastBook = app.buttons["book.\(lastID)"]
        reveal(lastBook, in: rows)
        XCTAssertTrue(lastBook.label.contains(lastID))
        XCTAssertTrue(lastBook.label.contains("Unknown"))
        XCTAssertTrue(app.staticTexts["book.enabledUnknown.\(lastID)"].exists)
        XCTAssertFalse(app.switches["book.toggle.\(lastID)"].exists)
        lastBook.tap()

        XCTAssertTrue(app.navigationBars[lastID].waitForExistence(timeout: 2))
        XCTAssertTrue(app.descendants(matching: .any)["books.detail"].firstMatch.waitForExistence(timeout: 2))
        XCTAssertTrue(app.staticTexts["FIXTURE-T-14"].exists)
        let quote = app.descendants(matching: .any)["book.quote.FIXTURE-T-14"].firstMatch
        XCTAssertTrue(quote.exists)
        XCTAssertEqual(quote.label, "YES ASK 42.0¢")
        XCTAssertFalse(app.staticTexts["NO 58.0¢"].exists)
        XCTAssertFalse(app.tabBars.firstMatch.isHittable)
        screenshot("Book detail overhaul")

        app.navigationBars[lastID].buttons["Books"].tap()
        XCTAssertTrue(app.navigationBars["Books"].waitForExistence(timeout: 2))
        XCTAssertTrue(list.waitForExistence(timeout: 2))
        XCTAssertTrue(app.tabBars.buttons["Books"].isSelected)
        for _ in 0..<35 {
            if count.exists && count.isHittable { break }
            list.coordinate(withNormalizedOffset: CGVector(dx: 0.02, dy: 0.25))
                .press(forDuration: 0.05, thenDragTo: list.coordinate(withNormalizedOffset: CGVector(dx: 0.02, dy: 0.85)))
        }
        XCTAssertTrue(count.exists)
        XCTAssertTrue(count.isHittable)
        XCTAssertEqual(count.label, "14 books")
        list.swipeDown()
        screenshot("Books overhaul")
    }

    func testBookDetailListsEnginesOnMarket() throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "books", withExtension: "json", subdirectory: "Fixtures"))
        let fixture = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
        let books = try XCTUnwrap(fixture["books"] as? [[String: Any]])
        let book = try XCTUnwrap(books.first { ($0["kalshi_book"] as? [String: Any])?["executor"] is [String: Any] })
        let bookID = try XCTUnwrap(book["book_id"] as? String)
        let executor = try XCTUnwrap((book["kalshi_book"] as? [String: Any])?["executor"] as? [String: Any])
        let engines = try XCTUnwrap(executor["engines"] as? [[String: Any]])
        let engineIDs = engines.compactMap { $0["engine_id"] as? String }
        XCTAssertGreaterThan(engineIDs.count, 1, "the fixture co-hosts several engines on one market")
        let holder = try XCTUnwrap((executor["position"] as? [String: Any])?["holder_engine_id"] as? String)
        let disagreements = try XCTUnwrap(executor["disagreements_today"] as? Int)
        let lastDisagreement = engines.first { engine in
            let proposal = engine["last_proposal"] as? [String: Any]
            return (proposal?["disposition"] as? String) == "conflict"
                || (proposal?["reason"] as? String)?.contains("disagreement") == true
        }?["engine_id"] as? String
        let disagreeing = try XCTUnwrap(lastDisagreement)

        app.launch()
        app.tabBars.buttons["Books"].tap()
        let list = app.descendants(matching: .any)["books.scroll"].firstMatch
        XCTAssertTrue(list.waitForExistence(timeout: 3))
        let rows = app.scrollViews["books.rows"].firstMatch
        revealRows(rows, on: list)
        let target = app.buttons["book.\(bookID)"]
        reveal(target, in: rows)
        target.tap()
        XCTAssertTrue(app.navigationBars[bookID].waitForExistence(timeout: 2))

        let section = app.descendants(matching: .any)["book.engines.\(bookID)"].firstMatch
        XCTAssertTrue(section.waitForExistence(timeout: 2))
        let listed = app.descendants(matching: .any)
            .matching(NSPredicate(format: "identifier BEGINSWITH %@", "book.engines.\(bookID).row."))
        XCTAssertEqual(listed.count, engineIDs.count)
        for id in engineIDs {
            let row = app.descendants(matching: .any)["book.engines.\(bookID).row.\(id)"].firstMatch
            XCTAssertTrue(row.exists, "engine row \(id)")
            XCTAssertTrue(row.label.contains(id))
        }
        let holderRow = app.descendants(matching: .any)["book.engines.\(bookID).holder"].firstMatch
        XCTAssertTrue(holderRow.exists)
        XCTAssertTrue(holderRow.label.contains(holder), holderRow.label)
        let disagreementRow = app.descendants(matching: .any)["book.engines.\(bookID).disagreements"].firstMatch
        XCTAssertTrue(disagreementRow.exists)
        XCTAssertTrue(disagreementRow.label.contains("Disagreements today"), disagreementRow.label)
        XCTAssertTrue(disagreementRow.label.contains("\(disagreements)"), disagreementRow.label)
        XCTAssertTrue(disagreementRow.label.contains("Last: \(disagreeing)"), disagreementRow.label)

        let detail = app.descendants(matching: .any)["books.detail"].firstMatch
        let firstRow = app.descendants(matching: .any)["book.engines.\(bookID).row.\(engineIDs[0])"].firstMatch
        for _ in 0..<8 {
            if firstRow.isHittable { break }
            detail.coordinate(withNormalizedOffset: CGVector(dx: 0.02, dy: 0.80))
                .press(forDuration: 0.05, thenDragTo: detail.coordinate(withNormalizedOffset: CGVector(dx: 0.02, dy: 0.45)))
        }
        XCTAssertTrue(firstRow.isHittable)
        screenshot("Book engines on market")

        // A book listed below the executor book: the fixture server reports the block elsewhere, so its null reads "Not reported".
        let otherID = try XCTUnwrap(books.compactMap { $0["book_id"] as? String }.sorted().first { $0 > bookID })
        app.navigationBars[bookID].buttons["Books"].tap()
        XCTAssertTrue(app.navigationBars["Books"].waitForExistence(timeout: 2))
        let other = app.buttons["book.\(otherID)"]
        reveal(other, in: rows)
        other.tap()
        XCTAssertTrue(app.navigationBars[otherID].waitForExistence(timeout: 2))
        let nullSection = app.descendants(matching: .any)["book.engines.\(otherID)"].firstMatch
        XCTAssertTrue(nullSection.waitForExistence(timeout: 2))
        XCTAssertTrue(nullSection.staticTexts["Not reported"].exists)
    }

    private func visiblePageFrame(_ page: XCUIElement) -> CGRect {
        let frame = page.frame.intersection(app.windows.firstMatch.frame)
        let top = max(frame.minY, app.navigationBars.firstMatch.frame.maxY) + 8
        let bottom = min(frame.maxY, app.tabBars.firstMatch.frame.minY) - 8
        return CGRect(x: frame.minX, y: top, width: frame.width, height: max(0, bottom - top))
    }

    private func revealRows(_ rows: XCUIElement, on page: XCUIElement) {
        // Offscreen nested scroll views may be absent from the accessibility tree.
        // Position the page through its gutter before querying the rows' geometry.
        for _ in 0..<35 {
            let viewport = visiblePageFrame(page)
            let exists = rows.exists
            let frame = exists ? rows.frame : CGRect.null
            if exists && rows.isHittable && frame.minY >= viewport.minY && frame.maxY <= viewport.maxY {
                return
            }
            let down = exists && frame.minY < viewport.minY
            let distance: CGFloat
            if exists && frame.height <= viewport.height {
                let overflow = down ? viewport.minY - frame.minY : frame.maxY - viewport.maxY
                distance = min(160, max(24, overflow + 8))
            } else {
                distance = 160
            }
            let start = app.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: viewport.minX + 2, dy: viewport.midY))
            start.press(forDuration: 0,
                        thenDragTo: start.withOffset(CGVector(dx: 0, dy: down ? distance : -distance)),
                        withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        XCTAssertTrue(rows.exists, "Books rows must be exposed after scrolling the page")
        XCTFail("Could not position books.rows between navigation and tabs")
    }

    private func reveal(_ element: XCUIElement, in scroll: XCUIElement) {
        for _ in 0..<35 {
            if element.exists && element.isHittable { return }
            let page = app.descendants(matching: .any)["books.scroll"].firstMatch
            let band = scroll.frame.intersection(visiblePageFrame(page))
            if band.isNull || band.height < 60 {
                revealRows(scroll, on: page)
                continue
            }
            let reverse = element.exists && !element.frame.isEmpty && element.frame.minY < band.minY
            let start = app.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: band.midX, dy: band.midY))
            start.press(forDuration: 0,
                        thenDragTo: start.withOffset(CGVector(dx: 0, dy: reverse ? 160 : -160)),
                        withVelocity: .slow, thenHoldForDuration: 0)
        }
        XCTFail("Could not reach \(element.identifier)")
    }

    private func screenshot(_ name: String) {
        let appearance = app.staticTexts["fixture.renderedAppearance"]
        XCTAssertTrue(appearance.waitForExistence(timeout: 2))
        XCTAssertEqual(appearance.value as? String, expectedAppearance)
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
