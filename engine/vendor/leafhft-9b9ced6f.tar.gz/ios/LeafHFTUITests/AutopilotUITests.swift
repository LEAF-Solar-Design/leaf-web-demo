import XCTest

final class AutopilotUITests: XCTestCase {
    private func openLegacyTuningDetail() -> XCUIApplication {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        let link = app.buttons["engine.autopilot.open"]
        XCTAssertTrue(link.waitForExistence(timeout: 5))
        link.tap()
        let proposal = app.buttons["tuning.inbox.row.00000000-0000-4000-8000-00000000d3e0"]
        XCTAssertTrue(proposal.waitForExistence(timeout: 5))
        proposal.tap()
        XCTAssertTrue(app.staticTexts["tuning.plan.sha256"].waitForExistence(timeout: 5))
        return app
    }

    func testLegacyTuningDetailPollsWithoutLeavingTheScreen() {
        let app = openLegacyTuningDetail()
        let hash = app.staticTexts["tuning.plan.sha256"]
        let original = hash.label
        // Demo reads regenerate the sample frozen bytes, so a changed hash proves another read.
        let refreshed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            hash.exists && hash.label != original
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [refreshed], timeout: 8), .completed)
        XCTAssertTrue(app.scrollViews["tuning.item.scroll"].exists)
        XCTAssertFalse(app.buttons["tuning.item.accept"].isEnabled)
    }

    func testLegacyTuningDetailPullToRefresh() {
        let app = openLegacyTuningDetail()
        let status = app.staticTexts["tuning.item.refresh-status"]
        XCTAssertTrue(status.exists)
        XCTAssertEqual(status.label, "Pull down to refresh")
        let scroll = app.scrollViews["tuning.item.scroll"]
        // Pull from the top of the actual scroll container, well past the refresh threshold.
        scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.15))
            .press(forDuration: 0.2, thenDragTo:
                scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.85)))
        let refreshed = XCTNSPredicateExpectation(predicate:
            NSPredicate(format: "label == %@", "Refresh complete"), object: status)
        // Only a manual read changes this feedback; background polling cannot satisfy it.
        XCTAssertEqual(XCTWaiter.wait(for: [refreshed], timeout: 2), .completed)
        XCTAssertTrue(app.staticTexts["tuning.item.state"].exists)
        XCTAssertFalse(app.buttons["tuning.item.accept"].isEnabled)
    }

    func testAutopilotSectionsFromEngines() {
        let app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        let link = app.buttons["engine.autopilot.open"]
        XCTAssertTrue(link.waitForExistence(timeout: 5))
        link.tap()
        XCTAssertTrue(app.staticTexts["Sample autopilot data"].waitForExistence(timeout: 5))
        let tuner = app.switches["autopilot.toggle.owner"]
        XCTAssertTrue(tuner.waitForExistence(timeout: 5))
        XCTAssertFalse(tuner.isEnabled, "Fixture switches must never write")
        XCTAssertTrue(app.staticTexts["autopilot.switch.confirmed.owner"].exists)
        let scroll = app.scrollViews["autopilot.scroll"]
        XCTAssertTrue(scroll.exists)
        for identifier in ["autopilot.status", "autopilot.verdicts", "autopilot.cycles",
                           "autopilot.pending", "autopilot.evidence", "autopilot.lineage", "autopilot.kills"] {
            let section = app.descendants(matching: .any)[identifier].firstMatch
            for _ in 0..<30 {
                if section.exists && section.frame.intersects(scroll.frame) && section.isHittable { break }
                scroll.swipeUp()
            }
            XCTAssertTrue(section.exists, "Missing \(identifier)")
            XCTAssertTrue(section.isHittable, "Could not reach \(identifier)")
        }
        for _ in 0..<30 {
            if app.staticTexts["Sample autopilot data"].isHittable { break }
            scroll.swipeDown()
        }
        XCTAssertTrue(app.staticTexts["Sample autopilot data"].isHittable)
        // Settle at the top even if the sample-data label became visible partway down.
        scroll.swipeDown()
        attachScreenshot(app, name: "Engine autopilot, top")
        scroll.swipeUp()
        attachScreenshot(app, name: "Engine autopilot, after one scroll")
        scroll.swipeUp()
        attachScreenshot(app, name: "Engine autopilot, after two scrolls")
    }

    private func attachScreenshot(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
