import XCTest

final class RiskyBatmanUITests: XCTestCase {
    private var app: XCUIApplication!
    private let off = "risky.risky-batman-15m"
    private let running = "risky.risky-batman-1h"
    private var list: XCUIElement { app.collectionViews["engines.list"] }

    override func setUpWithError() throws {
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_CONTROL_WALK", "1",
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        XCTAssertTrue(list.waitForExistence(timeout: 10))
    }

    func testOffByDefaultAndCancelLeavesItOff() {
        let state = element(off + ".tuning.state")
        reveal(state, in: list)
        XCTAssertEqual(state.label, "Off")
        let start = app.buttons[off + ".try"]
        reveal(start, in: list)
        start.tap()
        // XCUITest rejects identifiers over 128 characters, so the full sentence is matched as a label predicate.
        let title = app.staticTexts.matching(NSPredicate(format: "label == %@",
            "Start offline tuning on your account? No real orders are placed. It uses much larger position sizes than your other engines.")).firstMatch
        XCTAssertTrue(title.waitForExistence(timeout: 3))
        dismissConfirmation(title)
        XCTAssertEqual(state.label, "Off")
        XCTAssertFalse(app.buttons[off + ".stop"].exists)
    }

    func testConfirmStartsFixtureTuningAndStopRequiresConfirmation() {
        let start = app.buttons[off + ".try"]
        reveal(start, in: list)
        start.tap()
        dialogButton(off + ".confirmStart", label: "Start tuning", excluding: off + ".try").tap()
        let state = element(off + ".tuning.state")
        XCTAssertTrue(state.waitForExistence(timeout: 3))
        assertLabel(state, equals: "Tuning running")
        let stop = app.buttons[off + ".stop"]
        reveal(stop, in: list)
        stop.tap()
        let stopTitle = app.staticTexts["Stop Risky Batman tuning on your account?"]
        XCTAssertTrue(stopTitle.waitForExistence(timeout: 3))
        dismissConfirmation(stopTitle)
        XCTAssertEqual(state.label, "Tuning running")
        stop.tap()
        dialogButton(off + ".confirmStop", label: "Stop tuning", excluding: off + ".stop").tap()
        assertLabel(state, equals: "Tuning stopped")
    }

    func testTuningIsLabelledSimulatedAndNoLiveDeployButtonRemains() {
        let title = element(running + ".tuning")
        reveal(title, in: list)
        XCTAssertEqual(title.label, "Offline tuning (simulated)")
        let countdown = element(running + ".countdown")
        reveal(countdown, in: list)
        XCTAssertEqual(countdown.label, "47 min of tuning left at these settings")
        XCTAssertFalse(app.buttons[running + ".deploy"].exists)
        XCTAssertFalse(element(running + ".liveReason").exists)
        let warning = element(running + ".warning")
        reveal(warning, in: list)
        XCTAssertEqual(warning.label, "Simulated tuning overstates live results: real fills, fees and latency are worse.")
        let telemetry = app.scrollViews[running + ".telemetry"]
        reveal(telemetry, in: list)
        for (key, label) in [("pnl", "Simulated P&L"), ("drawdown", "Max drawdown"), ("worst", "Worst trade"),
                             ("wins", "Wins"), ("losses", "Losses"), ("lossRate", "Loss rate"),
                             ("decisions", "Decisions"), ("capital", "Capital basis"), ("minutes", "Minutes at these settings")] {
            let row = element(running + "." + key)
            reveal(row, in: telemetry)
            XCTAssertTrue(row.label.contains(label), row.label)
        }
        attach("Risky Batman offline tuning")
    }

    func testProbingEngineShowsRunnerLifecycleBreakerAndHalt() {
        let state = element(running + ".state")
        reveal(state, in: list)
        XCTAssertEqual(state.label, "Probing")
        let breaker = element(running + ".breaker")
        reveal(breaker, in: list)
        XCTAssertEqual(breaker.label, "Breaker: -$12.40 of $1,250.00 (50%) · UTC day")
        XCTAssertFalse(app.buttons[running + ".probe"].exists)
        let halt = app.buttons[running + ".halt"]
        reveal(halt, in: list)
        XCTAssertTrue(halt.isEnabled)
        halt.tap()
        let title = app.staticTexts["Halt Risky Batman 1h?"]
        XCTAssertTrue(title.waitForExistence(timeout: 3))
        dismissConfirmation(title)
        XCTAssertEqual(state.label, "Probing")
        XCTAssertFalse(element(running + ".probe.message").exists)
        attach("Risky Batman probing with breaker meter")
    }

    func testProbeWalksRequestedRejectedThenAppliedAndHaltApplies() {
        let state = element(off + ".state")
        reveal(state, in: list)
        XCTAssertEqual(state.label, "Not probing")
        XCTAssertEqual(element(off + ".breaker").label, "Breaker: Not reported")
        XCTAssertFalse(app.buttons[off + ".halt"].exists)

        requestProbe(cancelFirst: true)
        let message = element(off + ".probe.message")
        reveal(message, in: list)
        assertLabel(message, equals: "Probe requested. Waiting for the runner.")
        XCTAssertFalse(app.buttons[off + ".probe"].isEnabled)
        refreshControl()
        assertLabel(message, equals: "Probe rejected. Sample rejection: the signed owner approval arrives with KM5.")
        XCTAssertEqual(state.label, "Not probing")

        requestProbe(cancelFirst: false)
        assertLabel(message, equals: "Probe requested. Waiting for the runner.")
        refreshControl()
        assertLabel(message, equals: "Probe applied.")
        assertLabel(state, equals: "Probing")
        attach("Risky Batman probe applied")

        let halt = app.buttons[off + ".halt"]
        reveal(halt, in: list)
        halt.tap()
        dialogButton(off + ".confirmHalt", label: "Halt", excluding: off + ".halt").tap()
        XCTAssertTrue(message.waitForExistence(timeout: 3))
        assertLabel(message, equals: "Halt requested. Waiting for the runner.")
        refreshControl()
        assertLabel(message, equals: "Halt applied.")
        assertLabel(state, equals: "Entries halted, settlement only")
        XCTAssertTrue(app.buttons[off + ".probe"].exists)
        attach("Risky Batman halted")
    }

    func testSettingsConfirmClockRestartAndCancelRetainsDraft() {
        let settings = app.buttons[running + ".settings"]
        reveal(settings, in: list)
        settings.tap()
        let form = app.collectionViews["risky.settings.form"]
        XCTAssertTrue(form.waitForExistence(timeout: 3))
        XCTAssertTrue(element("risky.settings.warning").label.contains("60-minute tuning clock"))
        let stepper = app.steppers["risky.settings.min_k"]
        reveal(stepper, in: form)
        let before = stepper.label
        // The stepper's +/- buttons carry no "Increment" label on this iOS; use position, else the right edge.
        if stepper.buttons.count >= 2 { stepper.buttons.element(boundBy: 1).tap() }
        else { stepper.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap() }
        let save = app.buttons["risky.settings.save"]
        reveal(save, in: form)
        XCTAssertTrue(stepper.label != before || save.isEnabled, "stepper value did not change")
        save.tap()
        XCTAssertTrue(app.staticTexts["Restart the 60-minute tuning clock?"].waitForExistence(timeout: 3))
        let cancels = app.buttons.matching(identifier: "Cancel")
        cancels.element(boundBy: cancels.count - 1).tap()
        XCTAssertTrue(save.isEnabled)
        save.tap()
        dialogButton("risky.settings.confirm", label: "Restart tuning with these settings").tap()
        XCTAssertTrue(list.waitForExistence(timeout: 3))
        let restarted = element(running + ".restarted")
        reveal(restarted, in: list)
        assertLabel(restarted, equals: "Tuning clock restarted after your change")
        let countdown = element(running + ".countdown")
        reveal(countdown, in: list)
        assertLabel(countdown, equals: "60 min of tuning left at these settings")
        XCTAssertFalse(app.buttons[running + ".deploy"].exists)
        attach("Risky Batman tuning clock restarted")
    }

    // MARK: The hedge mode (plan v1.9 H2c)

    private let hedge15m = "risky.hedgeMode.risky-batman-15m"
    private let hedge1h = "risky.hedgeMode.risky-batman-1h"
    private let legacyRule = "The engine keeps the legacy reversal: one opposite side order nets the position, and entries are sized as before."
    private let hedgeFirstRule = "Each entry is sized so the entry and its full reversal leg both fit in available cash."
    private let cashoutFirstRule = "A reversal first sells the whole position, then buys the opposite side, never more than the reversal size."

    func testHedgeModeRendersTheRunnerValueAndItsRule() {
        let offValue = element(hedge15m + ".value")
        reveal(offValue, in: list)
        XCTAssertEqual(offValue.label, "Not set")
        let offRule = element(hedge15m + ".rule")
        reveal(offRule, in: list)
        XCTAssertEqual(offRule.label, legacyRule)
        let runningValue = element(hedge1h + ".value")
        reveal(runningValue, in: list)
        XCTAssertEqual(runningValue.label, "Hedge first (entry autosizing)")
        let runningRule = element(hedge1h + ".rule")
        reveal(runningRule, in: list)
        XCTAssertEqual(runningRule.label, hedgeFirstRule)
        // The fixture account is the owner, so the control shows and the read-only note does not.
        let change = app.buttons[hedge1h + ".change"]
        reveal(change, in: list)
        XCTAssertTrue(change.isEnabled)
        XCTAssertFalse(element(hedge1h + ".readOnly").exists)
        attach("Risky Batman hedge modes")
    }

    func testHedgeModeConfirmSheetShowsTheSentenceAndCancelChangesNothing() {
        let change = app.buttons[hedge15m + ".change"]
        reveal(change, in: list)
        XCTAssertTrue(change.isEnabled)
        change.tap()
        let sentence = element("risky.hedgeMode.sentence")
        XCTAssertTrue(sentence.waitForExistence(timeout: 3))
        XCTAssertEqual(sentence.label, cashoutFirstRule)
        XCTAssertEqual(element("risky.hedgeMode.current").label, "Now: Not set")
        XCTAssertEqual(app.buttons["risky.hedgeMode.confirm"].label, "Request Cash out first")
        app.buttons["risky.hedgeMode.choice.hedgeFirst"].tap()
        XCTAssertEqual(sentence.label, hedgeFirstRule)
        XCTAssertEqual(app.buttons["risky.hedgeMode.confirm"].label, "Request Hedge first (entry autosizing)")
        attach("Risky Batman hedge mode confirm sheet")
        app.buttons["risky.hedgeMode.cancel"].tap()
        let gone = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sentence)
        XCTAssertEqual(XCTWaiter().wait(for: [gone], timeout: 5), .completed, "hedge mode sheet did not close")
        let value = element(hedge15m + ".value")
        reveal(value, in: list)
        XCTAssertEqual(value.label, "Not set")
        XCTAssertFalse(element(hedge15m + ".message").exists)
    }

    func testHedgeModeWalkShowsRequestedThenApplied() {
        let change = app.buttons[hedge15m + ".change"]
        reveal(change, in: list)
        change.tap()
        let confirm = app.buttons["risky.hedgeMode.confirm"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 3))
        XCTAssertEqual(element("risky.hedgeMode.sentence").label, cashoutFirstRule)
        confirm.tap()
        let closed = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: confirm)
        XCTAssertEqual(XCTWaiter().wait(for: [closed], timeout: 5), .completed, "hedge mode sheet did not close")

        let message = element(hedge15m + ".message")
        reveal(message, in: list)
        assertLabel(message, equals: "Cash out first requested. Waiting for the runner.")
        // Requested is not applied: the value stays the runner's until the runner reports the change.
        let value = element(hedge15m + ".value")
        reveal(value, in: list)
        XCTAssertEqual(value.label, "Not set")
        reveal(change, in: list)
        XCTAssertFalse(change.isEnabled)
        attach("Risky Batman hedge mode requested")

        let refresh = app.buttons[hedge15m + ".refresh"]
        reveal(refresh, in: list)
        refresh.tap()
        let settled = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: refresh)
        XCTAssertEqual(XCTWaiter().wait(for: [settled], timeout: 5), .completed, "hedge mode request did not settle")
        reveal(message, in: list)
        assertLabel(message, equals: "Cash out first applied.")
        reveal(value, in: list)
        assertLabel(value, equals: "Cash out first")
        let rule = element(hedge15m + ".rule")
        reveal(rule, in: list)
        assertLabel(rule, equals: cashoutFirstRule)
        reveal(change, in: list)
        XCTAssertTrue(change.isEnabled)
        attach("Risky Batman hedge mode applied")
    }

    func testHedgeFailuresWithoutControlRecordStayVisibleInSheet() {
        for (kind, expected) in [
            ("validation", "The runner has not reported this engine yet."),
            ("credential", "Pair this phone with your dashboard account"),
            ("http", "The dashboard declined the request (400).")
        ] {
            app.terminate()
            app.launchArguments += ["-LEAFHFT_HEDGE_FAILURE", kind]
            app.launch()
            app.tabBars.buttons["Engines"].tap()
            XCTAssertTrue(list.waitForExistence(timeout: 10))
            let change = app.buttons[hedge15m + ".change"]
            reveal(change, in: list)
            change.tap()
            let confirm = app.buttons["risky.hedgeMode.confirm"]
            XCTAssertTrue(confirm.waitForExistence(timeout: 3))
            confirm.tap()
            let message = element("risky.hedgeMode.sheet.message")
            XCTAssertTrue(message.waitForExistence(timeout: 5))
            XCTAssertTrue(message.label.contains(expected), message.label)
            XCTAssertTrue(confirm.exists)
            XCTAssertTrue(confirm.isEnabled)
            app.buttons["risky.hedgeMode.cancel"].tap()
            app.launchArguments.removeLast(2)
        }
    }

    func testMissingTuningRequestClearsWaitingAndOffersCheckStatus() {
        app.terminate()
        app.launchArguments += ["-LEAFHFT_TUNING_PENDING", "1"]
        app.launch()
        app.tabBars.buttons["Engines"].tap()
        XCTAssertTrue(list.waitForExistence(timeout: 10))
        let start = app.buttons[off + ".try"]
        reveal(start, in: list)
        start.tap()
        dialogButton(off + ".confirmStart", label: "Start tuning", excluding: off + ".try").tap()
        let refresh = app.buttons[off + ".refresh"]
        reveal(refresh, in: list)
        XCTAssertTrue(refresh.isEnabled)
        refresh.tap()
        let message = element(off + ".message")
        reveal(message, in: list)
        assertLabel(message, equals: "Tuning request not found. Check status and Requests before sending another change.")
        XCTAssertFalse(refresh.exists)
        let check = app.buttons[off + ".checkStatus"]
        reveal(check, in: list)
        XCTAssertTrue(check.isEnabled)
        XCTAssertEqual(element(off + ".tuning.state").label, "Off")
        check.tap()
        XCTAssertFalse(refresh.exists)
    }

    /// Probe opens the confirm sheet; Cancel changes nothing, Request probe posts and closes the sheet.
    private func requestProbe(cancelFirst: Bool) {
        let probe = app.buttons[off + ".probe"]
        reveal(probe, in: list)
        XCTAssertTrue(probe.isEnabled)
        if cancelFirst {
            probe.tap()
            let cancel = app.buttons["risky.probe.cancel"]
            XCTAssertTrue(cancel.waitForExistence(timeout: 3))
            XCTAssertTrue(element("risky.probe.markets").label.contains("BTC-15M"))
            cancel.tap()
            XCTAssertTrue(list.waitForExistence(timeout: 3))
            XCTAssertFalse(element(off + ".probe.message").exists)
            reveal(probe, in: list)
        }
        probe.tap()
        let confirm = app.buttons["risky.probe.confirm"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 3))
        confirm.tap()
        let gone = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: confirm)
        XCTAssertEqual(XCTWaiter().wait(for: [gone], timeout: 5), .completed, "probe sheet did not close")
    }

    private func refreshControl() {
        let refresh = app.buttons[off + ".probe.refresh"]
        reveal(refresh, in: list)
        refresh.tap()
        let gone = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: refresh)
        XCTAssertEqual(XCTWaiter().wait(for: [gone], timeout: 5), .completed, "request did not settle")
        let message = element(off + ".probe.message")
        reveal(message, in: list)
    }

    private func assertLabel(_ element: XCUIElement, equals expected: String, timeout: TimeInterval = 5,
                             file: StaticString = #filePath, line: UInt = #line) {
        guard element.waitForExistence(timeout: timeout) else {
            XCTAssertTrue(element.exists, "Element did not appear for expected label: \(expected)", file: file, line: line)
            return
        }
        let matches = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@", expected), object: element)
        if XCTWaiter.wait(for: [matches], timeout: timeout) != .completed {
            XCTAssertEqual(element.label, expected, file: file, line: line)
        }
    }

    private func element(_ id: String) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: id).firstMatch
    }

    /// A confirmation dialog button: by its identifier when the dialog carries it, else the first label match
    /// that is not the card button of the same title.
    private func dialogButton(_ id: String, label: String, excluding cardId: String? = nil) -> XCUIElement {
        let byId = app.buttons.matching(identifier: id).firstMatch
        if byId.waitForExistence(timeout: 2) { return byId }
        let predicate = cardId.map { NSPredicate(format: "label == %@ AND identifier != %@", label, $0) }
            ?? NSPredicate(format: "label == %@", label)
        let byLabel = app.buttons.matching(predicate).firstMatch
        XCTAssertTrue(byLabel.waitForExistence(timeout: 3), "no dialog button \(label)")
        return byLabel
    }

    /// Dismisses a confirmation dialog, robust to how the platform renders it. Paths in order, each tried only while
    /// the title is still present: (1) a Cancel button (case-insensitive label) that becomes hittable within 3 s;
    /// (2) any element labelled Cancel that exists and is hittable; (3) a tap outside the dialog near the top;
    /// (4) a tap on the far side of the title, for a popover dialog drawn over the top of the screen (the tall
    /// running card's Stop dialog). After a path taps, it waits up to 3 s for the title to vanish; then the title
    /// must be gone within 5 s.
    private func dismissConfirmation(_ title: XCUIElement) {
        let cancelLabel = NSPredicate(format: "label ==[c] %@", "Cancel")
        let paths: [() -> Bool] = [
            {
                let button = self.app.buttons.matching(cancelLabel).firstMatch
                // Polled, not a KVC "hittable" predicate: hittability is read only once the button exists.
                guard self.poll(timeout: 3, { button.exists && button.isHittable }) else { return false }
                button.tap()
                return true
            },
            {
                let any = self.app.descendants(matching: .any).matching(cancelLabel).firstMatch
                guard any.exists && any.isHittable else { return false }
                any.tap()
                return true
            },
            {
                self.app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.08)).tap()
                return true
            },
            {
                guard title.exists else { return false }
                let screen = self.app.frame
                let box = title.frame
                // The title heads the dialog, so above it, or well below its one button, is outside the dialog.
                // The right edge sits in the list's row inset, clear of card buttons.
                let y = box.minY > screen.height * 0.3 ? box.minY - 80 : min(box.maxY + 260, screen.height * 0.9)
                self.app.coordinate(withNormalizedOffset: .zero)
                    .withOffset(CGVector(dx: screen.width * 0.97, dy: y)).tap()
                return true
            },
        ]
        for path in paths {
            guard title.exists else { break }
            guard path() else { continue }
            if poll(timeout: 3, { !title.exists }) { break }
        }
        let gone = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: title)
        XCTAssertEqual(XCTWaiter().wait(for: [gone], timeout: 5), .completed, "confirmation dialog did not dismiss")
    }

    /// Re-evaluates the condition every 0.25 s until it holds or the timeout passes.
    private func poll(timeout: TimeInterval, _ condition: () -> Bool) -> Bool {
        let deadline = Date().addingTimeInterval(timeout)
        while Date() < deadline {
            if condition() { return true }
            RunLoop.current.run(until: Date().addingTimeInterval(0.25))
        }
        return condition()
    }

    private func reveal(_ element: XCUIElement, in scroll: XCUIElement) {
        for _ in 0..<45 {
            let top = max(app.navigationBars.firstMatch.frame.maxY + 8, scroll.frame.minY)
            let bottom = min(app.tabBars.firstMatch.exists ? app.tabBars.firstMatch.frame.minY - 8 : app.frame.maxY - 20,
                             scroll.frame.maxY)
            if element.exists && element.isHittable && element.frame.minY >= top && element.frame.maxY <= bottom { return }
            let above = element.exists && element.frame.maxY > 0 && element.frame.minY < top
            // Drag at the edge to avoid scrolling the telemetry viewport when moving the outer list.
            let x: CGFloat = scroll.identifier == "engines.list" ? 0.97 : 0.5
            let start = scroll.coordinate(withNormalizedOffset: CGVector(dx: x, dy: above ? 0.35 : 0.70))
            let end = scroll.coordinate(withNormalizedOffset: CGVector(dx: x, dy: above ? 0.60 : 0.40))
            start.press(forDuration: 0.05, thenDragTo: end, withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        XCTFail("Could not reveal \(element.identifier)")
    }

    private func attach(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
