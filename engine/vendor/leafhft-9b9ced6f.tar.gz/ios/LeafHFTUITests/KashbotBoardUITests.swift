import XCTest

final class KashbotBoardUITests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.appearance = .dark
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", "dark",
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
    }

    func testBoardSettingsAndBuzz() {
        app.launch()
        let settings = app.tabBars.buttons["Settings"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5))
        settings.tap()
        let form = app.collectionViews["settings.form"]
        XCTAssertTrue(form.waitForExistence(timeout: 5))
        let section = app.descendants(matching: .any)["kashbot-live-section"].firstMatch
        reveal(section, in: form)
        let preview = app.descendants(matching: .any)["kashbot-live-preview"].firstMatch
        reveal(preview, in: form)
        XCTAssertTrue(preview.exists)
        XCTAssertEqual(preview.frame.height, 160, accuracy: 1)

        let ledger = app.descendants(matching: .any)["kashbot-live-ledger"].firstMatch
        reveal(ledger, in: form)
        XCTAssertTrue(ledger.exists)
        let enabled = app.switches["kashbot-live-toggle"]
        reveal(enabled, in: form)
        XCTAssertTrue(enabled.exists)
        let buzz = app.switches["kashbot-live-buzz-toggle"]
        reveal(buzz, in: form)
        XCTAssertTrue(buzz.exists)
        if buzz.value as? String == "1" {
            reveal(buzz, in: form, clearance: 96)
            buzz.coordinate(withNormalizedOffset: CGVector(dx: 0.92, dy: 0.5)).tap()
            expectValue("0", for: buzz)
        }
        XCTAssertEqual(buzz.value as? String, "0")
        reveal(buzz, in: form, clearance: 96)
        buzz.coordinate(withNormalizedOffset: CGVector(dx: 0.92, dy: 0.5)).tap()
        expectValue("1", for: buzz)
        reveal(buzz, in: form, clearance: 96)
        buzz.coordinate(withNormalizedOffset: CGVector(dx: 0.92, dy: 0.5)).tap()
        expectValue("0", for: buzz)

        reveal(section, in: form, towardTop: true)
        reveal(preview, in: form)
        let appearance = app.staticTexts["fixture.renderedAppearance"]
        XCTAssertTrue(appearance.waitForExistence(timeout: 2))
        XCTAssertEqual(appearance.value as? String, "dark")
        attach(app.screenshot(), named: "kashbot-board-settings")
        attach(preview.screenshot(), named: "kashbot-board-lockscreen")
    }

    private func expectValue(_ value: String, for element: XCUIElement) {
        let expectation = XCTNSPredicateExpectation(
            predicate: NSPredicate(format: "value == %@", value), object: element)
        XCTAssertEqual(XCTWaiter.wait(for: [expectation], timeout: 3), .completed)
    }

    private func attach(_ screenshot: XCUIScreenshot, named name: String) {
        let attachment = XCTAttachment(screenshot: screenshot)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    private func reveal(_ element: XCUIElement, in form: XCUIElement, towardTop: Bool = false, clearance: CGFloat = 0) {
        for _ in 0..<40 {
            let top = max(form.frame.minY, app.navigationBars.firstMatch.frame.maxY) + 4
            let bottom = min(form.frame.maxY, app.tabBars.firstMatch.frame.minY) - 4 - clearance
            if element.exists && element.isHittable && element.frame.minY >= top && element.frame.maxY <= bottom {
                return
            }
            let above = element.exists && !element.frame.isEmpty ? element.frame.minY < top : towardTop
            let start = form.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: form.frame.width * 0.08, dy: (top + bottom) / 2 - form.frame.minY))
            start.press(forDuration: 0, thenDragTo: start.withOffset(CGVector(dx: 0, dy: above ? 150 : -150)),
                        withVelocity: .slow, thenHoldForDuration: 0)
        }
        XCTFail("Could not fully reveal \(element.identifier)")
    }
}
