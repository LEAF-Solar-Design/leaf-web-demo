import XCTest

/// The Monitor probe board card (I3) against the bundled probes.json fixture.
final class ProbeBoardUITests: XCTestCase {
    private var app: XCUIApplication!
    private var appearance = "light"

    override func setUpWithError() throws {
        continueAfterFailure = false
        appearance = ProcessInfo.processInfo.environment["LEAFHFT_TEST_APPEARANCE"] ?? "light"
        XCUIDevice.shared.appearance = appearance == "dark" ? .dark : .light
    }

    private func launch(_ extra: [String] = []) {
        app = XCUIApplication()
        app.launchArguments = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_APPEARANCE", appearance,
                               "-AppleLanguages", "(en)", "-AppleLocale", "en_US"] + extra
        app.launch()
    }

    private func element(_ identifier: String) -> XCUIElement {
        app.descendants(matching: .any)[identifier].firstMatch
    }

    private var scroll: XCUIElement { element("account.scroll") }

    private func reveal(_ target: XCUIElement, limit: Int = 35) {
        for _ in 0..<limit {
            if target.exists && target.isHittable { return }
            let start = scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.98, dy: 0.85))
            let end = scroll.coordinate(withNormalizedOffset: CGVector(dx: 0.98, dy: 0.20))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        XCTFail("Could not reach \(target.identifier)")
    }

    private func screenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "\(name) (\(appearance))"
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    private func waitForLabel(_ target: XCUIElement, _ label: String, timeout: TimeInterval = 5) {
        let matched = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@", label), object: target)
        XCTAssertEqual(XCTWaiter.wait(for: [matched], timeout: timeout), .completed,
                       "\(target.identifier) reads \"\(target.exists ? target.label : "missing")\", expected \"\(label)\"")
    }

    private func waitForHittable(_ target: XCUIElement, timeout: TimeInterval = 5) {
        let hittable = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND hittable == true"),
                                                 object: target)
        XCTAssertEqual(XCTWaiter.wait(for: [hittable], timeout: timeout), .completed,
                       "\(target.identifier) is not hittable")
    }

    private func openHaltSheet(_ halt: XCUIElement) -> (confirm: XCUIElement, cancel: XCUIElement) {
        waitForHittable(halt)
        XCTAssertTrue(halt.isEnabled)
        halt.tap()
        let confirm = app.buttons["probes.halt.confirm"]
        let cancel = app.buttons["probes.halt.cancel"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 5))
        XCTAssertTrue(cancel.exists)
        let message = element("probes.halt.message")
        XCTAssertTrue(message.waitForExistence(timeout: 2))
        XCTAssertEqual(message.label, "Stops new entries. Open contracts settle normally.")
        return (confirm, cancel)
    }

    func testMeterRowsReconcileAndNotReported() {
        launch()
        XCTAssertTrue(scroll.waitForExistence(timeout: 5))
        let board = element("probes.board")
        XCTAssertTrue(board.waitForExistence(timeout: 5))
        // The first line is the protection verdict; the fixture reports the account meter and aggr-2's limit.
        let verdict = element("probes.verdict")
        XCTAssertTrue(verdict.waitForExistence(timeout: 5))
        XCTAssertTrue(verdict.label.hasPrefix("Loss limits reported by the runner."), verdict.label)
        let meter = element("probes.meter")
        reveal(meter)
        // The account breaker from the runner's loss_breakers block, 50% of the day-start mark.
        XCTAssertEqual(meter.label, "-$20.00 of $1,250.00 (50% of $2,500.00) · UTC day")

        let row = element("probes.row.aggr-2")
        XCTAssertTrue(row.waitForExistence(timeout: 2))
        XCTAssertEqual(element("probes.row.aggr-2.dayLoss").label, "-$12.40 of $1,250.00 (50% of $2,500.00) · UTC day")
        XCTAssertEqual(element("probes.row.aggr-2.ticketPnl").label, "-$1.20")
        XCTAssertEqual(element("probes.row.aggr-2.tickets").label, "41")
        XCTAssertEqual(element("probes.row.aggr-2.expires").label, "Oct 13, 11:00 PM CT")
        XCTAssertEqual(element("probes.row.aggr-2.stops").label, "None")
        // Runner -$12.40 against tickets -$1.20 differs by more than $1.
        XCTAssertTrue(element("probes.reconcile.aggr-2").exists)

        // A row whose fields are null reads "Not reported", never zero.
        XCTAssertTrue(element("probes.row.future-engine").waitForExistence(timeout: 2))
        for field in ["dayLoss", "ticketPnl", "tickets", "expires", "stops"] {
            XCTAssertEqual(element("probes.row.future-engine.\(field)").label, "Not reported", field)
        }
        XCTAssertFalse(element("probes.reconcile.future-engine").exists)

        // Plain fixture mode has no control walk, so Halt is not offered.
        XCTAssertFalse(app.buttons["probes.halt.aggr-2"].isEnabled)
        screenshot("Probe board")
    }

    func testCardHeightIsBounded() {
        launch()
        XCTAssertTrue(scroll.waitForExistence(timeout: 5))
        let board = element("probes.board")
        XCTAssertTrue(board.waitForExistence(timeout: 5))
        reveal(element("probes.meter"))
        let list = element("probes.list")
        XCTAssertTrue(list.exists)
        XCTAssertGreaterThan(list.frame.height, 0)
        XCTAssertLessThanOrEqual(list.frame.height, 321, "the engine rows scroll inside a 320 pt viewport")
        XCTAssertLessThanOrEqual(board.frame.height, 640, "the probe board card height is bounded")
    }

    func testHiddenOn404() {
        launch(["-LEAFHFT_PROBES", "missing"])
        XCTAssertTrue(scroll.waitForExistence(timeout: 5))
        XCTAssertTrue(element("monitor.money").waitForExistence(timeout: 5))
        XCTAssertTrue(element("account.openOrders").waitForExistence(timeout: 5))
        XCTAssertFalse(element("probes.board").exists)
        XCTAssertFalse(element("probes.meter").exists)
    }

    func testUnreadableBoardReadsNotReported() {
        launch(["-LEAFHFT_PROBES", "unreadable"])
        XCTAssertTrue(scroll.waitForExistence(timeout: 5))
        let meter = element("probes.meter")
        XCTAssertTrue(meter.waitForExistence(timeout: 5))
        XCTAssertEqual(meter.label, "Not reported")
        XCTAssertFalse(element("probes.row.aggr-2").exists)
    }

    func testInitialFetchFailureShowsRiskUnavailableAndRetry() {
        launch(["-LEAFHFT_PROBES", "failed"])
        XCTAssertTrue(scroll.waitForExistence(timeout: 5))
        let error = element("probes.error")
        reveal(error)
        XCTAssertTrue(error.label.contains("Could not refresh probes"), error.label)
        XCTAssertEqual(element("probes.meter").label, "Not reported")
        XCTAssertFalse(element("probes.row.aggr-2").exists)
        let retry = app.buttons["probes.retry"]
        reveal(retry)
        XCTAssertTrue(retry.isEnabled)
        retry.tap()
        XCTAssertTrue(error.waitForExistence(timeout: 5))
        XCTAssertEqual(element("probes.meter").label, "Not reported")
    }

    func testMoneyWarnsAboutRetainedPositionsAndAccountBadgeIsText() {
        launch(["-LEAFHFT_POSITIONS_FAILURE", "1"])
        XCTAssertTrue(scroll.waitForExistence(timeout: 5))
        let account = element("monitor.account")
        XCTAssertTrue(account.waitForExistence(timeout: 5))
        XCTAssertEqual(account.label, "Account Main runner")
        XCTAssertFalse(app.buttons["monitor.account"].exists)
        XCTAssertFalse(app.buttons["Main runner"].exists)
        let warning = element("account.money.positionsError")
        reveal(warning)
        XCTAssertTrue(warning.label.contains("last positions read"), warning.label)
        XCTAssertTrue(warning.label.contains("Could not refresh positions"), warning.label)
        XCTAssertFalse(warning.label.contains("read time not reported"), warning.label)
    }

    func testHaltCancelChangesNothingThenConfirmWalksRequestedToApplied() {
        launch(["-LEAFHFT_CONTROL_WALK", "1"])
        XCTAssertTrue(scroll.waitForExistence(timeout: 5))
        let halt = app.buttons["probes.halt.aggr-2"]
        XCTAssertTrue(halt.waitForExistence(timeout: 5))
        // Reveal a field below the row header so the header, Halt and the status line are all on screen.
        reveal(element("probes.row.aggr-2.dayLoss"))
        waitForHittable(halt)
        let status = element("probes.halt.aggr-2.status")
        let refresh = app.buttons["probes.halt.aggr-2.refresh"]

        // Cancel changes nothing.
        var sheet = openHaltSheet(halt)
        screenshot("Halt confirm sheet")
        sheet.cancel.tap()
        XCTAssertTrue(sheet.confirm.waitForNonExistence(timeout: 5))
        XCTAssertFalse(status.exists)
        waitForHittable(halt)
        XCTAssertTrue(halt.isEnabled)

        // The fixture control walk settles each halt in turn: requested, rejected, requested, applied.
        sheet = openHaltSheet(halt)
        sheet.confirm.tap()
        XCTAssertTrue(sheet.confirm.waitForNonExistence(timeout: 5))
        XCTAssertTrue(status.waitForExistence(timeout: 5))
        waitForLabel(status, "Halt requested")
        XCTAssertFalse(halt.isEnabled, "a pending halt is not sent twice")
        screenshot("Halt requested")
        waitForHittable(refresh)
        refresh.tap()
        waitForLabel(status, "Halt rejected")

        sheet = openHaltSheet(halt)
        sheet.confirm.tap()
        XCTAssertTrue(sheet.confirm.waitForNonExistence(timeout: 5))
        waitForLabel(status, "Halt requested")
        waitForHittable(refresh)
        refresh.tap()
        waitForLabel(status, "Halt applied")
        XCTAssertFalse(refresh.exists)
        XCTAssertFalse(halt.isEnabled)
        screenshot("Halt applied")
    }
}
