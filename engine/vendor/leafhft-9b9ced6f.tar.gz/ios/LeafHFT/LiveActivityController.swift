import ActivityKit
import Foundation
import UIKit

struct DrivenLiveActivity {
    let id: String
    let startDate: Date
    let state: KashbotLiveAttributes.ContentState
    var isRunning: Bool = true
}

@MainActor protocol LiveActivityDriving: AnyObject {
    var areActivitiesEnabled: Bool { get }
    var activities: [DrivenLiveActivity] { get }
    func request(_ content: ActivityContent<KashbotLiveAttributes.ContentState>) throws -> String
    func update(id: String, content: ActivityContent<KashbotLiveAttributes.ContentState>, alert: AlertConfiguration?) async
    func end(id: String) async
    func pushTokenUpdates(id: String) -> AsyncStream<Data>
    func pushToStartTokenUpdates() -> AsyncStream<Data>
}

@MainActor final class SystemLiveActivityDriver: LiveActivityDriving {
    private let defaults = UserDefaults.standard
    private func dateKey(_ id: String) -> String { "kashbot.live.started." + id }
    var areActivitiesEnabled: Bool { ActivityAuthorizationInfo().areActivitiesEnabled }
    var activities: [DrivenLiveActivity] {
        Activity<KashbotLiveAttributes>.activities.map { activity in
            let key = dateKey(activity.id)
            let date = defaults.object(forKey: key) as? Date ?? Date(timeIntervalSince1970: TimeInterval(activity.content.state.asOf))
            defaults.set(date, forKey: key)
            return .init(id: activity.id, startDate: date, state: activity.content.state,
                isRunning: activity.activityState == .active || activity.activityState == .stale)
        }
    }
    func request(_ content: ActivityContent<KashbotLiveAttributes.ContentState>) throws -> String {
        let activity = try Activity.request(attributes: KashbotLiveAttributes(), content: content, pushType: .token)
        defaults.set(Date(), forKey: dateKey(activity.id))
        return activity.id
    }
    func update(id: String, content: ActivityContent<KashbotLiveAttributes.ContentState>, alert: AlertConfiguration?) async {
        guard let activity = Activity<KashbotLiveAttributes>.activities.first(where: { $0.id == id }) else { return }
        await activity.update(content, alertConfiguration: alert)
    }
    func end(id: String) async {
        if let activity = Activity<KashbotLiveAttributes>.activities.first(where: { $0.id == id }) {
            await activity.end(nil, dismissalPolicy: .immediate)
        }
        defaults.removeObject(forKey: dateKey(id))
    }
    func pushTokenUpdates(id: String) -> AsyncStream<Data> {
        guard let activity = Activity<KashbotLiveAttributes>.activities.first(where: { $0.id == id }) else {
            return AsyncStream { $0.finish() }
        }
        return AsyncStream { continuation in
            if let token = activity.pushToken { continuation.yield(token) }
            let task = Task {
                for await token in activity.pushTokenUpdates {
                    guard !Task.isCancelled else { break }
                    continuation.yield(token)
                }
                continuation.finish()
            }
            continuation.onTermination = { _ in task.cancel() }
        }
    }
    func pushToStartTokenUpdates() -> AsyncStream<Data> {
        guard #available(iOS 17.2, *) else { return AsyncStream { $0.finish() } }
        return AsyncStream { continuation in
            if let token = Activity<KashbotLiveAttributes>.pushToStartToken { continuation.yield(token) }
            let task = Task {
                for await token in Activity<KashbotLiveAttributes>.pushToStartTokenUpdates {
                    guard !Task.isCancelled else { break }
                    continuation.yield(token)
                }
                continuation.finish()
            }
            continuation.onTermination = { _ in task.cancel() }
        }
    }
}

@MainActor final class LiveActivityController {
    typealias Upload = @MainActor (String, String, String?) async throws -> Void
    private let driver: any LiveActivityDriving
    private let defaults: UserDefaults
    private let now: @MainActor () -> Date
    private let isActive: @MainActor () -> Bool
    private let upload: Upload
    private let fixtureMode: FixtureMode
    private var operation: Task<Void, Never>?
    private var tokenTasks: [String: Task<Void, Never>] = [:]
    private var startTokenTask: Task<Void, Never>?
    private var pendingTokens: [String: Token] = [:]
    private var latest: KashbotBoardSnapshot?
    private var lastUpdate: Date?
    private var enabledObserver: (any NSObjectProtocol)?
    private var observedEnabled = true
    private struct Token: Equatable {
        let kind: String
        let value: String
        let activityId: String?
        var key: String { kind + ":" + (activityId ?? "") }
    }

    init(driver: (any LiveActivityDriving)? = nil, defaults: UserDefaults = .standard,
         fixtureMode: FixtureMode = .current, now: @escaping @MainActor () -> Date = Date.init,
         isActive: @escaping @MainActor () -> Bool = { UIApplication.shared.applicationState == .active },
         upload: Upload? = nil) {
        self.driver = driver ?? SystemLiveActivityDriver()
        self.defaults = defaults
        self.fixtureMode = fixtureMode
        self.now = now
        self.isActive = isActive
        self.upload = upload ?? { kind, token, id in
            try await PushClient(fixtureMode: fixtureMode).registerLiveActivityToken(kind: kind, token: token, activityId: id)
        }
        observedEnabled = enabled
        // Turning the setting off ends the activity at once; weak capture keeps the controller out of a cycle.
        enabledObserver = NotificationCenter.default.addObserver(forName: UserDefaults.didChangeNotification,
            object: defaults, queue: nil) { [weak self] _ in
            Task { @MainActor in self?.enabledSettingChanged() }
        }
    }

    deinit {
        if let enabledObserver { NotificationCenter.default.removeObserver(enabledObserver) }
        operation?.cancel()
        startTokenTask?.cancel()
        for task in tokenTasks.values { task.cancel() }
    }

    private var enabled: Bool { defaults.object(forKey: "kashbot.live.enabled") == nil || defaults.bool(forKey: "kashbot.live.enabled") }

    /// Only the true-to-false edge acts; turning it back on waits for the next apply to start one.
    private func enabledSettingChanged() {
        let isOn = enabled
        defer { observedEnabled = isOn }
        guard observedEnabled, !isOn else { return }
        endAll()
    }

    // All lifecycle mutations share one queue, including foreground/background races.
    private func enqueue(_ work: @escaping @MainActor () async -> Void) -> Task<Void, Never> {
        let previous = operation
        let task = Task {
            await previous?.value
            guard !Task.isCancelled else { return }
            await work()
        }
        operation = task
        return task
    }

    @discardableResult func apply(_ snapshot: KashbotBoardSnapshot) -> Task<Void, Never> {
        enqueue { [weak self] in
            guard let self, !self.fixtureMode.enabled else { return }
            self.latest = snapshot
            await self.applyNow(snapshot)
        }
    }

    @discardableResult func checkRestart() -> Task<Void, Never> {
        enqueue { [weak self] in
            guard let self, !self.fixtureMode.enabled else { return }
            guard self.enabled else { await self.endNow(); return }
            guard self.isActive() else { return }
            let restored = self.driver.activities.filter(\.isRunning).map {
                KashbotBoardSnapshot(state: $0.state, ledger: $0.state.ledger)
            }
            let cached = self.latest ?? (restored.isEmpty ? KashbotBoardStore.load(now: self.now()) : nil)
            let candidates = [cached].compactMap { $0 } + restored
            if let snapshot = candidates.max(by: { $0.state.asOf < $1.state.asOf }) {
                await self.applyNow(snapshot)
            }
            for token in Array(self.pendingTokens.values) { await self.send(token) }
        }
    }

    @discardableResult func endAll() -> Task<Void, Never> {
        enqueue { [weak self] in
            guard let self, !self.fixtureMode.enabled else { return }
            self.latest = nil
            await self.endNow()
        }
    }

    private func endNow() async {
        startTokenTask?.cancel()
        startTokenTask = nil
        for task in tokenTasks.values { task.cancel() }
        tokenTasks.removeAll()
        pendingTokens.removeAll()
        for activity in driver.activities { await driver.end(id: activity.id) }
        lastUpdate = nil
    }

    private func applyNow(_ snapshot: KashbotBoardSnapshot) async {
        guard enabled else { await endNow(); return }
        guard driver.areActivitiesEnabled else { return }
        let time = now()
        let content = ActivityContent(state: snapshot.state,
            staleDate: Date(timeIntervalSince1970: TimeInterval(snapshot.state.asOf) + 180))
        for activity in driver.activities where !activity.isRunning { await endActivity(activity.id) }
        let existing = driver.activities.filter(\.isRunning).sorted { $0.startDate > $1.startDate }
        var current = existing.first
        for extra in existing.dropFirst() { await endActivity(extra.id) }
        if let activity = current, time.timeIntervalSince(activity.startDate) >= 7.5 * 3600, isActive() {
            await endActivity(activity.id)
            current = nil
        }
        observeStartToken()
        if let activity = current {
            observeToken(activity.id)
            guard activity.state != snapshot.state else { return }
            let material = snapshot.state.isMaterialChange(from: activity.state)
            let odds = defaults.bool(forKey: "kashbot.live.buzzOnOdds") && Self.crossedOdds(snapshot.state, from: activity.state)
            guard material || odds || (lastUpdate.map({ time.timeIntervalSince($0) >= 10 }) ?? true) else { return }
            let reason = material ? Self.reason(snapshot.state, from: activity.state) : "Odds crossed 50%"
            let alert: AlertConfiguration? = material || odds
                ? AlertConfiguration(title: "Kashbot", body: "\(reason)", sound: .default) : nil
            await driver.update(id: activity.id, content: content, alert: alert)
            lastUpdate = time
        } else if isActive() {
            // Re-read after awaits so restored or remotely started activities cannot linger.
            for activity in driver.activities { await endActivity(activity.id) }
            do {
                let id = try driver.request(content)
                lastUpdate = time
                observeToken(id)
            } catch {
                // ActivityKit can refuse a request; the next foreground/poll retries.
            }
        }
    }

    private func endActivity(_ id: String) async {
        tokenTasks.removeValue(forKey: id)?.cancel()
        pendingTokens.removeValue(forKey: "update:" + id)
        await driver.end(id: id)
    }

    private func observeToken(_ id: String) {
        guard tokenTasks[id] == nil else { return }
        let stream = driver.pushTokenUpdates(id: id)
        tokenTasks[id] = Task { [weak self] in
            for await data in stream {
                guard !Task.isCancelled else { return }
                await self?.receive(data, kind: "update", id: id)
            }
        }
    }

    private func observeStartToken() {
        guard startTokenTask == nil else { return }
        let stream = driver.pushToStartTokenUpdates()
        startTokenTask = Task { [weak self] in
            for await data in stream {
                guard !Task.isCancelled else { return }
                await self?.receive(data, kind: "start", id: nil)
            }
        }
    }

    private func receive(_ data: Data, kind: String, id: String?) async {
        guard enabled, !fixtureMode.enabled else { return }
        let token = Token(kind: kind, value: data.map { String(format: "%02x", $0) }.joined(), activityId: id)
        pendingTokens[token.key] = token
        await send(token)
    }

    private func send(_ token: Token) async {
        guard enabled, !fixtureMode.enabled, !Task.isCancelled else { return }
        do {
            try await upload(token.kind, token.value, token.activityId)
            if pendingTokens[token.key] == token { pendingTokens.removeValue(forKey: token.key) }
        } catch {
            // Keep only the latest token per activity for a foreground retry. Never log tokens.
        }
    }

    static func crossedOdds(_ state: KashbotLiveAttributes.ContentState, from old: KashbotLiveAttributes.ContentState) -> Bool {
        state.rows.contains { row in
            guard let odds = row.oddsPct,
                  let before = old.rows.first(where: { $0.ticker == row.ticker && $0.side == row.side })?.oddsPct else { return false }
            return (before < 50 && odds >= 50) || (before >= 50 && odds < 50)
        }
    }

    static func reason(_ state: KashbotLiveAttributes.ContentState, from old: KashbotLiveAttributes.ContentState) -> String {
        if let entry = state.ledger.first,
           entry.ticker != old.ledger.first?.ticker || entry.at != old.ledger.first?.at {
            let amount = String(format: "%.2f", abs(Double(entry.pnlCents)) / 100)
            let percent = entry.pnlBps.map { String(format: " (%+.0f%%)", Double($0) / 100) } ?? ""
            return "Settled \(entry.pnlCents < 0 ? "-" : "+")$\(amount)\(percent)"
        }
        if let row = state.rows.first(where: { row in
            !old.rows.contains { $0.ticker == row.ticker && $0.side == row.side && $0.milli == row.milli }
        }) {
            let size = NSDecimalNumber(decimal: Decimal(row.milli) / 1000).stringValue
            return "Opened \(row.ticker) \(row.side.uppercased()) \(size)"
        }
        if let row = old.rows.first(where: { row in !state.rows.contains { $0.ticker == row.ticker } }) {
            return "Closed \(row.ticker)"
        }
        if let row = state.rows.first(where: { row in old.rows.contains { $0.ticker == row.ticker && $0.state != row.state } }) {
            return "\(row.ticker) \(row.state)"
        }
        return "Positions changed"
    }
}
