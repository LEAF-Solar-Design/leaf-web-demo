import SwiftUI
import LeafHFTCore
import BackgroundTasks

@main
@MainActor
struct LeafHFTApp: App {
    @UIApplicationDelegateAdaptor(PushRegistrar.self) private var pushRegistrar
    @State private var liveActivity: LiveActivityController
    @State private var state: AppState
    @State private var studio = MushyState(fixtureMode: .appLaunch)
    @State private var assistant: AssistantConversation
    @State private var inbox: AssistantInbox
    @State private var selectedTab: KashbotTab = .account
    @State private var tabResetCounters: [KashbotTab: Int] = [:]
    @State private var tabAwaySince: [KashbotTab: Date] = [:]
    @State private var routingSetup = false
    @State private var showingStudio = false
    @State private var launcherHidden = false
    @State private var autoPairingRequested = false
    @State private var showingTour = false
    @State private var tourStep = 0
    @AppStorage("kashbot.guidedTourVersion") private var guidedTourVersion = 0
    @AppStorage("kashbot.appearance") private var appearance = LeafAppearance.system.rawValue
    @Environment(\.scenePhase) private var scenePhase

    init() {
        let controller = LiveActivityController(fixtureMode: .appLaunch)
        _liveActivity = State(initialValue: controller)
        _state = State(initialValue: AppState(fixtureMode: .appLaunch, liveActivity: controller))
        let assistantClient = MushyClient(fixtureMode: .appLaunch)
        _assistant = State(initialValue: AssistantConversation(fixtureMode: .appLaunch, client: assistantClient))
        _inbox = State(initialValue: AssistantInbox(fixtureMode: .appLaunch, client: assistantClient))
        LeafFonts.registerIfNeeded()
    }

    private var fixtureAppearance: ColorScheme? {
        let arguments = ProcessInfo.processInfo.arguments
        guard FixtureMode.current.enabled,
              let index = arguments.firstIndex(of: "-LEAFHFT_APPEARANCE"),
              arguments.indices.contains(index + 1) else { return nil }
        switch arguments[index + 1] {
        case "dark": return .dark
        case "light": return .light
        default: return nil
        }
    }
    var body: some Scene {
        WindowGroup {
            ZStack(alignment: .top) {
                VStack(spacing: 0) {
                    if fixtureAppearance != nil { FixtureAppearanceReadback() }
                    TabView(selection: tabSelection) {
                        AccountView().id(tabResetCounters[.account, default: 0]).tabItem { Label("Monitor", systemImage: "chart.line.uptrend.xyaxis") }.tag(KashbotTab.account)
                        BooksView().id(tabResetCounters[.books, default: 0]).tabItem { Label("Books", systemImage: "square.grid.2x2") }.tag(KashbotTab.books)
                        EnginesView().id(tabResetCounters[.engines, default: 0]).tabItem { Label("Engines", systemImage: "cpu") }.tag(KashbotTab.engines)
                        NavigationStack { EngineLabView() }
                            .id(tabResetCounters[.lab, default: 0])
                            .tabItem { Label("Lab", systemImage: "testtube.2") }.tag(KashbotTab.lab)
                        SettingsView(autoStartPairing: autoPairingRequested, onShowTour: startTour)
                            .id(tabResetCounters[.settings, default: 0])
                            .tabItem { Label("Settings", systemImage: "gearshape") }.tag(KashbotTab.settings)
                    }
                    .onPreferenceChange(StudioLauncherHiddenKey.self) { launcherHidden = $0 }
                    .toolbarBackground(LeafTheme.card, for: .tabBar)
                    .toolbarBackground(.visible, for: .tabBar)
                    .overlay(alignment: .bottomTrailing) {
                        if !launcherHidden {
                            Button { showingStudio = true } label: {
                                Image(systemName: "bubble.left.fill")
                                    .font(.title2.weight(.semibold))
                                    .frame(width: 56, height: 56)
                                    .foregroundStyle(LeafTheme.ground)
                                    .background(LeafTheme.ink, in: Circle())
                                    .contentShape(Circle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Open assistant prompt")
                            .accessibilityHint("Opens a text prompt for charts, explanations, and account changes")
                            .accessibilityIdentifier("studio.launcher")
                            .overlay(alignment: .topTrailing) {
                                if inbox.unreadCount > 0 {
                                    AssistantUnreadBadge(count: inbox.unreadCount, identifier: "assistant.launcher.badge")
                                        .offset(x: 6, y: -6)
                                        .allowsHitTesting(false)
                                }
                            }
                            .padding(.trailing, 16)
                            .padding(.bottom, 64)
                        }
                    }
                }
                if showingTour {
                    GuidedTourOverlay(step: $tourStep, selectedTab: $selectedTab,
                                      onFinish: finishTour)
                        .transition(.opacity)
                }
            }
            .preferredColorScheme(fixtureAppearance ?? LeafAppearance(rawValue: appearance)?.colorScheme)
            .tint(LeafTheme.ink)
            .environment(state)
            .environment(studio)
            .environment(inbox)
            .environment(\.openStudio, OpenStudioAction { text in
                studio.offerPrefill(text)
                assistant.offerPrefill(text, engineBuilding: true)
                showingStudio = true
            })
            .environment(\.askAssistant, OpenStudioAction { text in
                // Tune advice is an account question, so the draft goes to ask mode, never engine building.
                assistant.setEngineBuilding(false)
                assistant.offerPrefill(text)
                showingStudio = true
            })
            .sheet(isPresented: Binding(get: { showingStudio || pushRegistrar.showAutopilot }, set: { presented in
                if !presented {
                    showingStudio = false
                    pushRegistrar.showAutopilot = false
                }
            }), onDismiss: {
                Task { await inbox.refreshBadge() }
            }) {
                if pushRegistrar.showAutopilot {
                    NavigationStack {
                        AutopilotView()
                            .safeAreaInset(edge: .top) {
                                if let message = pushRegistrar.actionError {
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text(message)
                                            .accessibilityIdentifier("autopilot.push.error")
                                        Button("Dismiss message") { pushRegistrar.actionError = nil }
                                    }
                                    .padding()
                                    .background(LeafTheme.card)
                                }
                            }
                            .toolbar { ToolbarItem(placement: .confirmationAction) {
                                Button("Done") { pushRegistrar.showAutopilot = false }
                            } }
                    }
                    .environment(state)
                    .leafKitThemed()
                } else {
                    StudioView()
                        .environment(studio)
                        .environment(assistant)
                        .environment(inbox)
                        .leafKitThemed()
                        .presentationDetents([.large])
                        .presentationDragIndicator(.visible)
                }
            }
            .riskConfirmation(state)
            .onChange(of: pushRegistrar.showAssistantInbox) { _, requested in
                if requested { openAssistantInbox() }
            }
            // BEGIN tuning review URL handler: opening carries no decision authority.
            .onOpenURL { url in
                guard let target = TuningInboxTarget.reviewURL(url) else { return }
                TuningInboxRouter.shared.open(target)
                pushRegistrar.showAutopilot = true
            }
            // END tuning review URL handler
            .onReceive(NotificationCenter.default.publisher(for: PushRegistrar.pairingCompleted)) { _ in
                Task { await pushRegistrar.activate(force: true) }
            }
            .onChange(of: scenePhase, initial: true) { _, phase in
                if phase == .background {
                    markTabAway(selectedTab, at: Date())
                } else if phase == .active {
                    resumeTab(selectedTab, at: Date())
                }
                state.sceneChanged(phase)
                if phase == .active { Task { await pushRegistrar.activate() } }
                if phase == .active { Task { await inbox.refreshBadge() } }
                if phase == .active { liveActivity.checkRestart() }
                if phase == .background { scheduleLiveBoardRefresh() }
            }
            .onChange(of: selectedTab) { previous, current in
                state.tabBecameVisible(current)
                let now = Date()
                markTabAway(previous, at: now)
                if scenePhase == .active {
                    resumeTab(current, at: now)
                } else {
                    markTabAway(current, at: now)
                }
            }
            .onChange(of: state.kashbotStatus) { _, status in
                let current = DashboardPairingLaunchPolicy.shouldRouteSetup(
                    dashboardPairing: status?.dashboardPairing,
                    accountBinding: status?.accountBinding)
                if DashboardPairingLaunchPolicy.shouldRouteSetup(previous: routingSetup, current: current) {
                    selectedTab = .settings
                }
                routingSetup = current
            }
            .task(id: scenePhase) {
                guard scenePhase == .active else { return }
                await studio.refresh()
                while !Task.isCancelled {
                    do { try await Task.sleep(nanoseconds: MushyState.pollNanoseconds) }
                    catch { break }
                    await studio.tick()
                }
            }
            .onAppear {
                if pushRegistrar.showAssistantInbox { openAssistantInbox() }
                state.tabBecameVisible(selectedTab)
                let arguments = ProcessInfo.processInfo.arguments
                let explicitTour = arguments.contains("-LEAFHFT_TOUR")
                if explicitTour || (!state.fixtureMode.enabled && guidedTourVersion < GuidedTourOverlay.currentVersion) {
                    startTour()
                } else {
                    prepareDashboardAccess()
                }
            }
        }
        .backgroundTask(.appRefresh("com.evan.leafhft.liveboard.refresh")) {
            await state.refreshLiveBoardOnce()
            await scheduleLiveBoardRefresh()
        }
    }

    private func openAssistantInbox() {
        guard pushRegistrar.showAssistantInbox else { return }
        pushRegistrar.showAutopilot = false
        inbox.requestOpen()
        showingStudio = true
        pushRegistrar.showAssistantInbox = false
    }

    private func scheduleLiveBoardRefresh() {
        guard !state.fixtureMode.enabled else { return }
        let request = BGAppRefreshTaskRequest(identifier: "com.evan.leafhft.liveboard.refresh")
        request.earliestBeginDate = Date().addingTimeInterval(15 * 60)
        try? BGTaskScheduler.shared.submit(request)
    }

    // Only tab-bar selection writes through this binding. Pushes and the tour
    // keep using selectedTab directly and cannot be interpreted as re-taps.
    private var tabSelection: Binding<KashbotTab> {
        Binding(get: { selectedTab }, set: { tab in
            if tab == selectedTab {
                tabResetCounters[tab, default: 0] += 1
            } else {
                selectedTab = tab
            }
        })
    }

    private func markTabAway(_ tab: KashbotTab, at now: Date) {
        // Preserve the start of an absence across tab switches in the background.
        if tabAwaySince[tab] == nil { tabAwaySince[tab] = now }
    }

    private func resumeTab(_ tab: KashbotTab, at now: Date) {
        if TabStatePolicy.shouldReset(awaySince: tabAwaySince[tab], now: now) {
            tabResetCounters[tab, default: 0] += 1
        }
        tabAwaySince[tab] = nil
    }

    private func startTour() {
        tourStep = 0
        selectedTab = .account
        showingTour = true
    }

    private func finishTour() {
        guidedTourVersion = GuidedTourOverlay.currentVersion
        showingTour = false
        prepareDashboardAccess()
    }

    private func prepareDashboardAccess() {
        guard !state.fixtureMode.enabled else { return }
        let dashboardCredential: Data?
        let privateKey: Data?
        let keyID: Data?
        do {
            let store = KeychainStore()
            dashboardCredential = try store.load(account: KeychainStore.dashboardTokenAccount)
            privateKey = try store.load(account: KeychainStore.keyDERAccount)
            keyID = try store.load(account: KeychainStore.keyIDAccount)
        } catch {
            return
        }
        let hasDashboardCredential = dashboardCredential?.isEmpty == false
        let hasKalshiCredential = privateKey?.isEmpty == false && keyID?.isEmpty == false
        guard DashboardPairingLaunchPolicy.shouldOpenSettings(
            hasDashboardCredential: hasDashboardCredential,
            hasKalshiCredential: hasKalshiCredential) else { return }
        selectedTab = .settings
        autoPairingRequested = DashboardPairingLaunchPolicy.shouldAutoStart(
            hasCredential: hasDashboardCredential)
    }
}

enum TabStatePolicy {
    static func shouldReset(awaySince: Date?, now: Date, threshold: TimeInterval = 30 * 60) -> Bool {
        guard let awaySince else { return false }
        return now.timeIntervalSince(awaySince) > threshold
    }
}

enum DashboardPairingLaunchPolicy {
    static func shouldAutoStart(hasCredential: Bool) -> Bool { !hasCredential }
    static func shouldOpenSettings(hasDashboardCredential: Bool, hasKalshiCredential: Bool) -> Bool {
        !hasDashboardCredential || !hasKalshiCredential
    }
    static func shouldRouteSetup(previous: Bool, current: Bool) -> Bool { current && !previous }
    static func shouldRouteSetup(dashboardPairing: DashboardPairingState?,
                                 accountBinding: AccountBindingState?) -> Bool {
        dashboardPairing == .paired && accountBinding == .unbound
    }
}

private struct FixtureAppearanceReadback: View {
    @Environment(\.colorScheme) private var colorScheme
    var body: some View {
        Text(colorScheme == .dark ? "Dark appearance" : "Light appearance")
            .font(.caption2)
            .accessibilityIdentifier("fixture.renderedAppearance")
            .accessibilityValue(colorScheme == .dark ? "dark" : "light")
    }
}
