import UIKit
import UserNotifications
import Combine

@MainActor
final class PushRegistrar: NSObject, ObservableObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    static let category = "AUTOPILOT_DECISION"
    static let keepOn = "AUTOPILOT_KEEP_ON"
    static let turnOff = "AUTOPILOT_TURN_OFF"
    /// Tuning inbox pushes only open their item; no notification can post a decision.
    static let candidateReady = "candidate_ready"
    static let tuningConfirmRequest = "tuning_confirm_request"
    static let reviewTuning = "tuning_review"
    static let assistantInbox = "ASSISTANT_INBOX"
    static let tuningCategories: Set<String> = [candidateReady, tuningConfirmRequest]
    static let pairingCompleted = Notification.Name("kashbot.dashboardPairingCompleted")
    @Published var showAutopilot = false
    @Published var showAssistantInbox = false
    @Published var actionError: String?
    @Published private(set) var registrationError: String?
    private(set) var planContractMax: Int?
    /// Where registration last stopped, in plain words. Never carries the APNs token or the dashboard credential.
    @Published private(set) var pushStatus = "Not checked yet"
    static let demoStatus = "Notifications are off in demo mode"
    private static let retryMessage = "Notifications could not be registered. We will retry when the app is opened."

    private let fixtureMode: FixtureMode
    private let client: PushClientProtocol
    private let dashboardToken: () throws -> String?
    private let authorize: () async throws -> Bool
    private let registerRemote: () -> Void
    private let now: () -> Date
    private let authorizationLabel: () async -> String
    private let notifyFailure: (String) async -> Void
    private let openTuningItem: (TuningInboxTarget?) -> Void
    private var apnsToken: String?
    private var lastSuccess: (apns: String, dashboard: String, at: Date)?
    private var activating = false
    private var activationQueued = false
    private var registering = false
    private var registrationQueued = false

    override convenience init() { self.init(fixtureMode: .appLaunch) }

    init(fixtureMode: FixtureMode, client: PushClientProtocol? = nil,
         dashboardToken: @escaping () throws -> String? = {
             guard let data = try KeychainStore().load(account: KeychainStore.dashboardTokenAccount) else { return nil }
             return String(data: data, encoding: .utf8)
         },
         authorize: @escaping () async throws -> Bool = {
             let center = UNUserNotificationCenter.current()
             let settings = await center.notificationSettings()
             if settings.authorizationStatus == .notDetermined {
                 return try await center.requestAuthorization(options: [.alert, .sound, .badge])
             }
             return settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional
         },
         registerRemote: @escaping () -> Void = { UIApplication.shared.registerForRemoteNotifications() },
         now: @escaping () -> Date = Date.init,
         authorizationLabel: @escaping () async -> String = {
             switch await UNUserNotificationCenter.current().notificationSettings().authorizationStatus {
             case .notDetermined: return "not asked"
             case .denied: return "denied"
             case .authorized: return "allowed"
             case .provisional: return "provisional"
             case .ephemeral: return "ephemeral"
             @unknown default: return "unknown"
             }
         },
         notifyFailure: @escaping (String) async -> Void = { message in
             let content = UNMutableNotificationContent()
             content.title = "Autotuner change not confirmed"
             content.body = message
             content.sound = .default
             let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil)
             // The in-memory state is already set, so a refused post is not surfaced again.
             try? await UNUserNotificationCenter.current().add(request)
         },
         openTuningItem: ((TuningInboxTarget?) -> Void)? = nil) {
        self.fixtureMode = fixtureMode
        self.openTuningItem = openTuningItem ?? { TuningInboxRouter.shared.open($0) }
        self.client = client ?? PushClient(fixtureMode: fixtureMode)
        self.dashboardToken = dashboardToken
        self.authorize = authorize
        self.registerRemote = registerRemote
        self.now = now
        self.authorizationLabel = authorizationLabel
        self.notifyFailure = notifyFailure
        super.init()
        if fixtureMode.enabled { pushStatus = Self.demoStatus }
    }

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        guard !fixtureMode.enabled else { return true }
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        center.setNotificationCategories(Self.notificationCategories())
        return true
    }

    /// AUTOPILOT_DECISION keeps its two toggle actions. The tuning review action
    /// only opens the inbox item, where Face ID over the fetched bytes is the only way to accept.
    static func notificationCategories() -> Set<UNNotificationCategory> {
        let keep = UNNotificationAction(identifier: Self.keepOn, title: "Keep tuner on",
                                        options: [.authenticationRequired])
        let off = UNNotificationAction(identifier: Self.turnOff, title: "Turn tuner off",
                                       options: [.destructive, .authenticationRequired])
        let review = UNNotificationAction(identifier: Self.reviewTuning, title: "Review and approve",
                                          options: [.authenticationRequired, .foreground])
        return [UNNotificationCategory(identifier: category, actions: [keep, off], intentIdentifiers: [], options: []),
                UNNotificationCategory(identifier: candidateReady, actions: [], intentIdentifiers: [], options: []),
                UNNotificationCategory(identifier: tuningConfirmRequest, actions: [review], intentIdentifiers: [], options: []),
                UNNotificationCategory(identifier: assistantInbox, actions: [], intentIdentifiers: [], options: [])]
    }

    /// Each lifecycle trigger makes at most one attempt; failure leaves it eligible for the next trigger.
    func activate(force: Bool = false) async {
        guard !fixtureMode.enabled else { return }
        if force { lastSuccess = nil }
        guard !activating else {
            activationQueued = true
            return
        }
        activating = true
        defer {
            activating = false
            if activationQueued {
                activationQueued = false
                Task { await activate() }
            }
        }
        do {
            guard let token = try dashboardToken(), !token.isEmpty else {
                pushStatus = "Not signed in"
                return
            }
        } catch {
            pushStatus = "Could not read sign-in from Keychain"
            registrationError = Self.retryMessage
            return
        }
        let allowed: Bool
        do {
            allowed = try await authorize()
        } catch {
            pushStatus = Self.bounded("Permission check failed: " + error.localizedDescription)
            registrationError = Self.retryMessage
            return
        }
        guard allowed else {
            let label = await authorizationLabel()
            pushStatus = Self.bounded("Notifications not allowed (" + label + ")")
            return
        }
        pushStatus = "Asking Apple for a push token"
        registerRemote()
        await registerToken()
    }

    /// Caps status text so an unexpected error description cannot flood the Settings row.
    static func bounded(_ text: String) -> String {
        text.count <= 120 ? text : String(text.prefix(119)) + "…"
    }

    static func registeredLabel(since at: Date, now: Date) -> String {
        now.timeIntervalSince(at) < 60 ? "Registered just now" : "Registered earlier today"
    }

    /// Maps the errors PushClient already throws; the text names the step, never a token or credential.
    static func serverStatus(for error: Error) -> String {
        if let clientError = error as? DashboardClientError {
            switch clientError {
            case .unauthorized: return "Kashbot refused: HTTP 401"
            case .forbidden: return "Kashbot refused: HTTP 403"
            case .rateLimited: return "Kashbot refused: HTTP 429"
            case .http(let status): return "Kashbot refused: HTTP \(status)"
            case .transport: return "Kashbot unreachable"
            case .decoding: return "Kashbot reply unreadable"
            case .noCredential: return "Not signed in"
            case .refused: return "Kashbot refused the registration"
            }
        }
        if error is KeychainStoreError { return "Could not read sign-in from Keychain" }
        if error is CancellationError { return "Registration cancelled" }
        return "Registration failed"
    }

    func appleRefused(_ error: Error) {
        let ns = error as NSError
        pushStatus = Self.bounded("Apple refused: \(ns.domain) \(ns.code) \(ns.localizedDescription)")
        registrationError = Self.retryMessage
    }

    static func bundleBuildNumber(_ bundle: Bundle = .main) -> Int? {
        parseBuildNumber(bundle.object(forInfoDictionaryKey: "CFBundleVersion"))
    }

    static func parseBuildNumber(_ value: Any?) -> Int? {
        guard let string = value as? String, let number = Int(string),
              (0...2_147_483_647).contains(number) else { return nil }
        return number
    }

    static func hexToken(_ data: Data) -> String {
        data.map { String(format: "%02x", $0) }.joined()
    }

    func receivedDeviceToken(_ data: Data) async {
        guard !fixtureMode.enabled else { return }
        apnsToken = Self.hexToken(data)
        await registerToken()
    }

    private func registerToken() async {
        guard !fixtureMode.enabled, let apnsToken else { return }
        guard !registering else {
            registrationQueued = true
            return
        }
        do {
            guard let credential = try dashboardToken(), !credential.isEmpty else {
                pushStatus = "Not signed in"
                return
            }
            if let lastSuccess, lastSuccess.apns == apnsToken, lastSuccess.dashboard == credential,
               now().timeIntervalSince(lastSuccess.at) < 24 * 60 * 60 {
                pushStatus = Self.registeredLabel(since: lastSuccess.at, now: now())
                return
            }
            pushStatus = "Got push token, registering with Kashbot"
            registering = true
            defer {
                registering = false
                if registrationQueued {
                    registrationQueued = false
                    Task { await registerToken() }
                }
            }
            try await client.register(apnsToken: apnsToken)
            do {
                planContractMax = try await client.registerCapabilities(
                    planContractMax: PushClient.maxPlanContract, buildNumber: Self.bundleBuildNumber())
            } catch {
                // Capability advertisement is best-effort; push registration already succeeded.
            }
            // A re-pair or token rotation during the request must remain eligible for registration.
            let registeredAt = now()
            if self.apnsToken == apnsToken, try dashboardToken() == credential {
                lastSuccess = (apnsToken, credential, registeredAt)
            }
            pushStatus = Self.registeredLabel(since: registeredAt, now: now())
            registrationError = nil
        } catch {
            pushStatus = Self.serverStatus(for: error)
            registrationError = Self.retryMessage
        }
    }

    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        Task { await receivedDeviceToken(deviceToken) }
    }

    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        appleRefused(error)
    }

    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter,
        willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }

    func handleAction(_ identifier: String, userInfo: [AnyHashable: Any], category: String? = nil) async throws {
        guard !fixtureMode.enabled else { return }
        if category == Self.assistantInbox {
            // Only route the tap; the inbox fetches its contents from the server.
            if identifier == UNNotificationDefaultActionIdentifier {
                showAssistantInbox = true
                showAutopilot = false
            }
            return
        }
        if let category, Self.tuningCategories.contains(category) {
            // Opening is the whole action: the app fetches and hashes the frozen bytes, then Face ID signs.
            guard identifier == UNNotificationDefaultActionIdentifier || identifier == Self.reviewTuning else { return }
            openTuningItem(TuningInboxTarget(userInfo: userInfo, category: category))
            showAutopilot = true
            return
        }
        if identifier == UNNotificationDefaultActionIdentifier {
            showAutopilot = true
            return
        }
        let enabled: Bool
        switch identifier {
        case Self.keepOn: enabled = true
        case Self.turnOff: enabled = false
        default: return
        }
        let scope: AutopilotScope = userInfo["account_id"] as? String == "owner" ? .owner : .lane
        let eventID = userInfo["event_id"] as? String
        guard let eventID, UUID(uuidString: eventID) != nil else { throw DashboardClientError.decoding }
        _ = try await client.toggle(enabled: enabled, scope: scope, eventID: eventID)
        actionError = nil
    }

    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        Task { @MainActor in
            await performAction(response.actionIdentifier, userInfo: response.notification.request.content.userInfo,
                                category: response.notification.request.content.categoryIdentifier)
            completionHandler()
        }
    }

    /// A background action that fails must reach the user: the app is suspended right after the completion handler.
    func performAction(_ identifier: String, userInfo: [AnyHashable: Any], category: String? = nil) async {
        do { try await handleAction(identifier, userInfo: userInfo, category: category) }
        catch {
            let message = "The autotuner change was not confirmed. Open Autopilot to check its state and try again."
            actionError = message
            showAutopilot = true
            await notifyFailure(message)
        }
    }
}
