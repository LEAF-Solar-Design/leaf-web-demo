import SwiftUI
import LeafHFTCore

@MainActor struct EngineLabView: View {
    @Environment(AppState.self) private var state
    private var accounts: [EngineControlAccount] { state.engines?.accounts ?? [] }

    var body: some View {
        TimelineView(.periodic(from: .now, by: 15)) { context in
            List {
                Section {
                    // One line of boundary, the rest behind a disclosure, so the first candidate is in the first viewport.
                    Label(Self.bannerText, systemImage: "flask")
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(2)
                        .accessibilityAddTraits(.isHeader)
                        .accessibilityIdentifier("engine.lab.build")
                    DisclosureGroup("About Engine Lab") {
                        Text("Understand the engines behind Kashbot").font(.headline)
                        Text("Engine Lab shares research and advisory notes. Opening it cannot start trading. Account settings open on a separate screen.")
                        Text("Workshop tools draft text and open review screens. Advisory notes are shared with collaborators and do not change trading settings.").font(.caption)
                    }.accessibilityIdentifier("engine.lab.about")
                    if state.fixtureMode.enabled {
                        Label("Fixture data, not a live account", systemImage: "testtube.2").font(.caption)
                    }
                    if let error = state.setupError { Text(error).foregroundStyle(.red) }
                }
                Section("Discovered candidates") {
                    if state.engineLabLoading { ProgressView("Refreshing Engine Lab") }
                    if let error = state.engineLabError { Text(error).foregroundStyle(.orange) }
                    if let lab = state.engineLab {
                        if !lab.candidates.isEmpty {
                            Text(Self.candidateSummary(lab.candidates)).font(.headline)
                                .accessibilityIdentifier("engine.lab.summary")
                        }
                        Text(Self.evidenceAgeText(generatedAt: lab.generatedAt, now: context.date))
                            .font(.caption).foregroundStyle(.secondary)
                            .accessibilityIdentifier("engine.lab.evidenceAge")
                        if lab.stale || state.engineLabError != nil {
                            Label("Evidence is delayed. Check source timestamps.", systemImage: "clock")
                        }
                        if lab.candidates.isEmpty { Text("No discovered candidates reported.") }
                        ForEach(lab.candidates) { candidate in
                            NavigationLink {
                                EngineLabCandidateDetail(candidateId: candidate.id)
                            } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(candidate.name).font(.headline)
                                        .lineLimit(2).truncationMode(.middle)
                                    Text(candidate.stageLabel)
                                    Text("\(candidate.paperModeLabel) · \(candidate.paperResults.statusLabel)")
                                        .font(.caption)
                                    Text("Owner: \(lab.owner(for: candidate.engineId))").font(.caption)
                                    Text(Self.rowStatus(candidate)).font(.caption)
                                }
                            }.accessibilityIdentifier("engine.lab.candidate.\(candidate.id)")
                        }
                        ForEach(Array(lab.problems.enumerated()), id: \.offset) { _, problem in
                            Text(problem).font(.caption).foregroundStyle(.orange)
                        }
                        Text(state.fixtureMode.enabled ? "Fixture Engine Lab v3" : "Live Engine Lab v3")
                            .font(.caption).foregroundStyle(.secondary)
                            .accessibilityIdentifier("engine.lab.source")
                    } else {
                        Text("Offline fallback only. Bundled notes are not live evidence.")
                            .accessibilityIdentifier("engine.lab.offline")
                    }
                    Button("Refresh Engine Lab") { Task { await state.refreshEngineLab() } }
                        .disabled(state.engineLabLoading || state.fixtureMode.enabled)
                }
                #if DEBUG
                if state.fixtureMode.enabled {
                    Section {
                        NavigationLink("People preview") {
                            PeopleCardsView(people: PeopleCards.fixtures(), referenceTime: PeopleCards.fixtureTime)
                        }.accessibilityIdentifier("engine.lab.peoplePreview")
                    }
                }
                #endif
                if !state.fixtureMode.enabled && !state.peopleNotAuthorized {
                    Section {
                        NavigationLink("People") {
                            PeopleScreenView()
                        }.accessibilityIdentifier("engine.lab.people")
                    }
                }
                if let accountId = EngineLab.yourLane(in: accounts),
                   let account = accounts.first(where: { $0.id == accountId }) {
                    Section("Your lane") {
                        ForEach(state.engines?.engines ?? []) { engine in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(engine.name ?? engine.engineId).font(.headline)
                                Text(EngineLab.entriesLabel(engine: engine, accountId: account.id))
                                EngineLabSettingsLink(engine: engine, account: account, tuning: true)
                            }
                        }
                    }.accessibilityIdentifier("engine.workshop.yourLane")
                }
                Section("Published engines") {
                    Text(EngineLab.freshness(generatedAt: state.engines?.generatedAt,
                        observedAt: state.enginesObservedAt, now: context.date).rawValue)
                    if let observed = state.enginesObservedAt {
                        Text(ageDescription(observedAt: observed, now: context.date)).font(.caption)
                    }
                    if let error = state.enginesError { Text(error).foregroundStyle(.red) }
                    if state.engines?.engines?.isEmpty != false {
                        Text("No engines published yet. Missing telemetry does not mean trading is stopped.")
                    }
                    ForEach(state.engines?.engines ?? []) { engine in
                        NavigationLink {
                            EngineLabLiveDetail(engineId: engine.engineId)
                        } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(engine.name ?? engine.engineId).font(.headline)
                                Label(EngineLab.entriesLabel(engine: engine), systemImage: "cpu")
                                    .accessibilityIdentifier("engine.lab.stage.\(engine.engineId)")
                            }
                        }.accessibilityIdentifier("engine.lab.row.\(engine.engineId)")
                    }
                }
                Section("Account lanes") {
                    Text(EngineLab.laneLabel(state.kashbotStatus))
                    if accounts.isEmpty { Text("Account lanes not reported.") }
                    ForEach(accounts) { account in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(account.label).font(.headline)
                            if EngineLab.yourLane(in: accounts) == account.id { Text("Your lane") }
                            ForEach(state.engines?.engines ?? []) { engine in
                                Text(engine.name ?? engine.engineId).font(.subheadline)
                                EngineLabAccountSummary(engine: engine, account: account)
                            }
                            if state.engines?.engines?.isEmpty != false { Text("Engine settings unknown.") }
                        }.accessibilityIdentifier("engine.lab.lane.\(account.id)")
                    }
                }
                Section("Pending work") {
                    Text("Requests are intentions until the runner reports their result. Unknown states stay visible.")
                    if pendingRequests.isEmpty { Text("No pending engine requests in the latest response.") }
                    ForEach(pendingRequests) { request in
                        EngineLabRequestRow(request: request)
                    }
                    if let request = state.kashbotStatus?.request {
                        LabeledContent("Latest lane request", value: request.action.rawValue)
                        LabeledContent("Request state", value: request.state)
                    }
                    if state.controlOutcomeUnknown {
                        Text("A submitted control has an unknown outcome. Check Requests on Engines before trying again.")
                            .foregroundStyle(.orange)
                    }
                }
                if state.engineLab == nil {
                Section("Offline fallback only") {
                    if let notes = EngineLab.bundledNotes {
                        Text("Bundled notes are offline fallback only, not live telemetry.").font(.caption)
                        ForEach(notes.lanes) { lane in
                            NavigationLink {
                                List {
                                    EngineLabNoteSummary(lane: lane, reviewedAt: notes.reviewedAt)
                                    EngineWorkshopReadinessSection(items: EngineWorkshop.readiness(lane: lane))
                                    EngineWorkshopToolsSection(id: lane.id,
                                        brief: EngineWorkshop.brief(lane: lane, fixture: state.fixtureMode.enabled),
                                        studioBrief: EngineWorkshop.brief(lane: lane, fixture: state.fixtureMode.enabled))
                                }.navigationTitle(lane.name)
                            } label: {
                                EngineLabNotePreview(lane: lane)
                            }.accessibilityIdentifier("engine.lab.row.\(lane.id)")
                        }
                    } else {
                        Text("Research notes unavailable. Status not reported.")
                    }
                }
                }
            }
            .accessibilityIdentifier("engine.lab.list")
            // The floating assistant launcher sits over the list bottom; keep the last rows clear of it.
            .contentMargins(.bottom, Self.assistantReserve, for: .scrollContent)
        }
        .navigationTitle("Engine Lab")
        .task { await state.refreshEngineLab() }
        .refreshable { await state.refreshEngineLab() }
    }

    private var pendingRequests: [ControlRequest] {
        state.pendingRequests.filter { EngineLab.isPending($0.state) }
    }

    static let bannerText = "Research only. Opening Engine Lab cannot start trading."
    /// The assistant launcher is 56 points tall plus spacing; the list reserves this much at its end.
    static let assistantReserve: CGFloat = 72

    /// Local time and age of the evidence snapshot, never the raw UTC string.
    static func evidenceAgeText(generatedAt: String, now: Date, timeZone: TimeZone = .current) -> String {
        guard let generated = LabTime.parse(generatedAt) else { return "Evidence time not reported" }
        return "Evidence generated " + LabTime.stamp(generated, now: now, timeZone: timeZone)
    }

    /// Counts come only from the candidates in this response; the scope is named in the sentence.
    static func candidateSummary(_ candidates: [EngineLab.Candidate]) -> String {
        let passed = candidates.filter { !$0.shadowOnly }.count
        var parts = ["\(passed) promotion passed", "\(candidates.count - passed) shadow only"]
        let incomplete = candidates.filter { EngineLabCandidateDetail.evidenceIncomplete($0) }.count
        if incomplete > 0 { parts.append("\(incomplete) evidence incomplete") }
        let noun = candidates.count == 1 ? "candidate" : "candidates"
        return "\(candidates.count) \(noun) in this snapshot: " + parts.joined(separator: ", ")
    }

    /// The row's one status line: an evidence blocker leads, otherwise the server's reason.
    static func rowStatus(_ candidate: EngineLab.Candidate) -> String {
        let reason = EngineLab.reasonText(candidate.reason)
        guard EngineLabCandidateDetail.evidenceIncomplete(candidate) else { return reason }
        return EngineLabCandidateDetail.inputFailureReasons.contains(candidate.reason)
            ? "Evidence incomplete: \(reason)" : "Evidence incomplete. \(reason)"
    }
}

/// Local-time and age wording shared by Lab and People. Pure: the caller supplies now and the time zone.
enum LabTime {
    static func parse(_ text: String) -> Date? {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let value = formatter.date(from: text) { return value }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: text)
    }

    static func age(from date: Date, to now: Date) -> String {
        let seconds = now.timeIntervalSince(date)
        guard seconds.isFinite else { return "age unknown" }
        if seconds < -60 { return "ahead of this device's clock" }
        if seconds < 60 { return "just now" }
        if seconds < 3_600 { return "\(Int(seconds / 60)) min ago" }
        if seconds < 86_400 { return "\(Int(seconds / 3_600)) h ago" }
        return "\(Int(seconds / 86_400)) d ago"
    }

    static func local(_ date: Date, timeZone: TimeZone = .current) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = timeZone
        formatter.dateFormat = "MMM d, h:mm a zzz"
        return formatter.string(from: date)
    }

    /// "5 min ago · Sep 20, 7:00 AM CDT"
    static func stamp(_ date: Date, now: Date, timeZone: TimeZone = .current) -> String {
        "\(age(from: date, to: now)) · \(local(date, timeZone: timeZone))"
    }
}

@MainActor struct EngineLabCandidateDetail: View {
    @Environment(AppState.self) private var state
    let candidateId: String
    @State private var composing = false
    private var candidate: EngineLab.Candidate? { state.engineLab?.candidates.first { $0.id == candidateId } }

    var body: some View {
        List {
            if let candidate, let lab = state.engineLab {
                Section {
                    // The full name wraps to two lines; the stable ID sits beneath it.
                    Text(candidate.name).font(.title2.bold())
                        .lineLimit(2).truncationMode(.middle)
                        .fixedSize(horizontal: false, vertical: true)
                        .accessibilityAddTraits(.isHeader)
                        .accessibilityIdentifier("engine.lab.detail.title")
                    Text("ID: \(candidate.id)").font(.caption).foregroundStyle(.secondary)
                        .textSelection(.enabled)
                        .accessibilityIdentifier("engine.lab.detail.id")
                }
                Section("Research status") {
                    let owner = lab.owner(for: candidate.engineId)
                    Text(candidate.stageLabel).accessibilityIdentifier("engine.lab.stage.\(candidate.id)")
                    Text(EngineLab.reasonText(candidate.reason)).accessibilityIdentifier("engine.lab.reason")
                    if Self.evidenceIncomplete(candidate) {
                        TimelineView(.periodic(from: .now, by: 15)) { context in
                            let summary = Self.evidenceSummary(candidate, now: context.date)
                            VStack(alignment: .leading, spacing: 4) {
                                Label(summary.headline, systemImage: "exclamationmark.triangle")
                                    .font(.subheadline.weight(.semibold)).foregroundStyle(.orange)
                                Text(summary.failedInput).font(.caption)
                                Text(summary.lastValid).font(.caption)
                                Text(summary.impact).font(.caption).foregroundStyle(.secondary)
                            }
                            .accessibilityElement(children: .combine)
                            .accessibilityIdentifier("engine.lab.evidenceSummary")
                        }
                    }
                    Text(Self.basisText(candidate.provenance)).accessibilityIdentifier("engine.lab.basis")
                    if owner != EngineLabCandidateDetail.ownerMissing {
                        LabeledContent("Owner", value: owner)
                    }
                    if candidate.promotionVerdict != "not_reported" {
                        LabeledContent("Promotion verdict", value: Self.verdictText(candidate.promotionVerdict))
                    }
                    if let sourceTime = LabTime.parse(candidate.sourceTimestamp.display) {
                        TimelineView(.periodic(from: .now, by: 15)) { context in
                            Text("Source time: \(LabTime.stamp(sourceTime, now: context.date))").font(.caption)
                        }
                    }
                    if !candidate.liveProfitCents.isMissing {
                        Text("Live profit (cents): \(candidate.liveProfitCents.display)")
                    }
                    let missing = Self.missingFields(candidate, owner: owner)
                    if !missing.isEmpty {
                        Text("Not reported: \(missing.joined(separator: ", "))").font(.caption)
                            .foregroundStyle(.secondary)
                            .accessibilityIdentifier("engine.lab.notReported")
                    }
                    Text("Replay, paper and shadow results are not live fills. Decisions here are advisory and do not enable an engine.")
                        .font(.caption)
                    if lab.stale || state.engineLabError != nil { Text("Evidence is delayed.").foregroundStyle(.orange) }
                    if candidate.shadowOnly {
                        Button("Trading controls unavailable") {}.disabled(true)
                            .accessibilityIdentifier("engine.lab.shadowControls")
                    } else if state.engines?.engines?.contains(where: { $0.engineId == candidate.engineId }) == true {
                        NavigationLink("Account engine settings") {
                            EngineSettingsView(engineId: candidate.engineId,
                                initialAccountId: EngineLab.yourLane(in: state.engines?.accounts ?? []))
                        }
                    } else { Text("Account controls have not been published.") }
                }
                Section("Offline tuning (simulated)") {
                    let results = candidate.paperResults
                    Text("\(candidate.paperModeLabel) · \(results.statusLabel)")
                        .accessibilityIdentifier("engine.lab.paper.status")
                    Text("Simulated results only. Live account results remain in Engine History.")
                        .font(.caption)
                    if !results.hasMetrics { Text("Paper metrics unavailable. Collecting evidence.") }
                    Text(results.countsLabel).accessibilityIdentifier("engine.lab.paper.counts")
                    Text(results.outcomesLabel)
                    Text(results.simulatedPnLLabel).accessibilityIdentifier("engine.lab.paper.pnl")
                    Text(results.returnLabel)
                    Text(results.drawdownLabel)
                    ForEach(["A", "B"], id: \.self) { name in
                        let setup = results.setup(name)
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Setup \(name)").font(.headline)
                            Text(setup.statusLabel)
                            Text(setup.countsLabel)
                            Text(setup.outcomesLabel)
                            Text(setup.simulatedPnLLabel)
                            Text(setup.returnLabel)
                            Text(setup.drawdownLabel)
                        }
                        .fixedSize(horizontal: false, vertical: true)
                        .accessibilityElement(children: .combine)
                        .accessibilityIdentifier("engine.lab.paper.setup.\(name)")
                    }
                    if let evidence = candidate.paperEvidence {
                        Text("Paper source time: \(Self.timeText(evidence.sourceTimestamp, now: .now))").font(.caption)
                    }
                }
                Section("Evidence and provenance") {
                    if candidate.evidence.isEmpty { Text("Evidence not reported.") }
                    ForEach(Array(candidate.evidence.enumerated()), id: \.offset) { index, evidence in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(evidence.kind.replacingOccurrences(of: "_", with: " ")).font(.headline)
                                .accessibilityIdentifier("engine.lab.evidence.\(index)")
                            Text("Provenance: \(Self.provenanceText(evidence.provenance))")
                                .accessibilityIdentifier("engine.lab.provenance.\(index)")
                            Text("Source time: \(Self.timeText(evidence.sourceTimestamp, now: .now))")
                            Text("Status: \(Self.statusText(evidence.status))")
                            Text("Source: \(evidence.source)").textSelection(.enabled)
                            Text("Hash: \(evidence.sourceHash)").font(.caption).textSelection(.enabled)
                            if ["paper", "shadow", "replay"].contains(evidence.provenance) {
                                Text("Simulated evidence: \(evidence.metrics.display)")
                            } else {
                                Text(evidence.metrics.display)
                            }
                            if evidence.reason != "not_reported" { Text(EngineLab.reasonText(evidence.reason)) }
                            Text("Live profit (cents): \(evidence.liveProfitCents.display)")
                        }
                    }
                }
                EngineLabCollaborationSection(engineId: candidate.engineId) { composing = true }
                EngineWorkshopToolsSection(id: candidate.id,
                    brief: EngineWorkshop.brief(lane: candidate.workshopLane, fixture: state.fixtureMode.enabled),
                    studioBrief: EngineWorkshop.brief(lane: candidate.workshopLane, fixture: state.fixtureMode.enabled))
            } else { Text("Candidate no longer reported. Refresh Engine Lab.") }
        }
        .accessibilityIdentifier("engine.lab.detail")
        .navigationTitle(candidate.map { Self.compactTitle($0.name) } ?? "Candidate")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $composing) {
            if let candidate {
                EngineLabEventComposer(engineId: candidate.engineId,
                    assignments: (state.engineLab?.events(for: candidate.engineId) ?? []).filter { $0.kind == "assignment" })
            }
        }
    }

    static let ownerMissing = "No owner reported"
    /// Server reasons that mean a report input failed its read or binding check (leafhft/engine_lab.py _input_reason).
    static let inputFailureReasons: Set<String> = [
        "Report input unavailable or invalid", "Report hash or size mismatch", "Report registration or candidate mismatch"]

    struct EvidenceSummary: Equatable {
        let headline: String
        let failedInput: String
        let lastValid: String
        let impact: String
    }

    /// Incomplete when the server reports an input failure or holds any evidence row.
    static func evidenceIncomplete(_ candidate: EngineLab.Candidate) -> Bool {
        inputFailureReasons.contains(candidate.reason) || candidate.evidence.contains { $0.status != "reported" }
    }

    /// One summary of the evidence blocker. Names only what the payload names; never invents a cause.
    static func evidenceSummary(_ candidate: EngineLab.Candidate, now: Date,
                                timeZone: TimeZone = .current) -> EvidenceSummary {
        let held = candidate.evidence.filter { $0.status != "reported" }
        let headline: String
        if inputFailureReasons.contains(candidate.reason) {
            headline = "Evidence incomplete: \(candidate.reason)"
        } else {
            headline = "Evidence incomplete: \(held.count) of \(candidate.evidence.count) evidence rows held"
        }
        let named = held.filter { !$0.source.isEmpty && $0.source != "not_reported" }
        let failedInput: String
        if named.isEmpty {
            failedInput = "The source did not name the failed input."
        } else {
            failedInput = named.map { row in
                let reason = row.reason == "not_reported" ? "reason not reported" : EngineLab.reasonText(row.reason)
                return "Held input: \(row.source) (\(reason)), observed \(Self.timeText(row.sourceTimestamp, now: now, timeZone: timeZone))"
            }.joined(separator: "\n")
        }
        let valid = candidate.evidence.filter { $0.status == "reported" }
            .compactMap { row in LabTime.parse(row.sourceTimestamp.display).map { (row, $0) } }
            .max { $0.1 < $1.1 }
        let lastValid = valid.map {
            "Last valid observation: \(Self.kindText($0.0.kind)), \(LabTime.stamp($0.1, now: now, timeZone: timeZone))"
        } ?? "No valid observation reported."
        return EvidenceSummary(headline: headline, failedInput: failedInput, lastValid: lastValid,
            impact: "Impact: results below may omit this input. The candidate stays disabled.")
    }

    /// Fields the payload left unreported, listed once instead of one row each. Provenance is on the basis line.
    static func missingFields(_ candidate: EngineLab.Candidate, owner: String) -> [String] {
        var fields: [String] = []
        if owner == ownerMissing { fields.append("owner") }
        if candidate.promotionVerdict == "not_reported" { fields.append("promotion verdict") }
        if LabTime.parse(candidate.sourceTimestamp.display) == nil { fields.append("source time") }
        if candidate.liveProfitCents.isMissing { fields.append("live profit") }
        return fields
    }

    /// Shadow, paper and replay stay labelled simulated; only live_fill reads as live.
    static func provenanceText(_ provenance: String) -> String {
        switch provenance {
        case "shadow": return "Shadow (simulated, not live fills)"
        case "paper": return "Paper (simulated, not live fills)"
        case "replay": return "Replay (simulated, not live fills)"
        case "live_fill": return "Live fills"
        case "not_reported": return "Not reported"
        default: return words(provenance)
        }
    }

    static func basisText(_ provenance: String) -> String { "Basis: " + provenanceText(provenance) }

    static func verdictText(_ verdict: String) -> String { verdict == "not_reported" ? "Not reported" : words(verdict) }

    static func statusText(_ status: String) -> String { status == "not_reported" ? "Not reported" : words(status) }

    static func kindText(_ kind: String) -> String { kind.replacingOccurrences(of: "_", with: " ") }

    static func timeText(_ value: EngineLab.ResearchValue, now: Date, timeZone: TimeZone = .current) -> String {
        guard let date = LabTime.parse(value.display) else { return value.isMissing ? "not reported" : value.display }
        return LabTime.stamp(date, now: now, timeZone: timeZone)
    }

    /// Short enough for the inline bar: keeps the head and the distinguishing tail, elides the middle.
    static func compactTitle(_ name: String, limit: Int = 20) -> String {
        guard limit >= 5, name.count > limit else { return name }
        let tail = (limit - 1) / 2
        let head = limit - 1 - tail
        let start = name.prefix(head).trimmingCharacters(in: .whitespaces)
        let end = name.suffix(tail).trimmingCharacters(in: .whitespaces)
        return start + "…" + end
    }

    private static func words(_ raw: String) -> String {
        let text = raw.replacingOccurrences(of: "_", with: " ").lowercased()
        return text.prefix(1).uppercased() + text.dropFirst()
    }
}

@MainActor private struct EngineLabCollaborationSection: View {
    @Environment(AppState.self) private var state
    let engineId: String
    let onCompose: () -> Void
    private var events: [EngineLab.Event] { state.engineLab?.events(for: engineId) ?? [] }
    var body: some View {
        Section("Collaboration") {
            Text("Shared advisory notes. Do not include private account information.").font(.caption)
            if state.engineLab?.eventsTruncated == true { Text("Showing the latest 200 events. Older owners and assignments may be missing.").foregroundStyle(.orange) }
            if events.isEmpty { Text("No collaboration events reported.") }
            ForEach(events) { event in
                VStack(alignment: .leading, spacing: 4) {
                    Text(event.kind.replacingOccurrences(of: "_", with: " ").capitalized).font(.headline)
                    ForEach(event.payload.keys.sorted(), id: \.self) { key in
                        Text("\(key.replacingOccurrences(of: "_", with: " ")): \(event.payload[key] ?? "")")
                    }
                    if event.kind == "assignment" {
                        Text("State: \(state.engineLab?.assignmentState(event) ?? "open")")
                    }
                    Text("\(event.actor.deviceName) · \(event.createdAt)").font(.caption).foregroundStyle(.secondary)
                }.accessibilityIdentifier("engine.lab.event.\(event.kind)")
            }
            Button("Add advisory note", action: onCompose)
                .accessibilityIdentifier("engine.lab.collaborate")
        }
    }
}

@MainActor private struct EngineLabEventComposer: View {
    @Environment(AppState.self) private var state
    @Environment(\.dismiss) private var dismiss
    let engineId: String
    let assignments: [EngineLab.Event]
    @State private var kind = "comment"
    @State private var person = ""
    @State private var note = ""
    @State private var action = "hold"
    @State private var assignmentId = ""
    @State private var assignmentState = "in_progress"
    @State private var pending: EngineLab.EventInput?
    @State private var sending = false
    @State private var result: String?
    @State private var posted = false
    @AccessibilityFocusState private var resultFocused: Bool

    private var payload: [String: String] {
        switch kind {
        case "owner": return ["owner": person]
        case "assignment": return ["assignee": person, "title": note]
        case "assignment_state": return ["assignment_id": assignmentId, "state": assignmentState]
        case "decision": return ["action": action, "reason": note]
        default: return ["text": note]
        }
    }
    private var valid: Bool { (try? EngineLab.EventInput(engineId: engineId, kind: kind, payload: payload)) != nil }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Advisory only. A nominate for probe, hold, kill or extend note does not change trading.")
                    Picker("Note type", selection: $kind) {
                        Text("Comment").tag("comment")
                        Text("Owner").tag("owner")
                        Text("Assignment").tag("assignment")
                        Text("Assignment state").tag("assignment_state")
                        Text("Decision").tag("decision")
                    }.accessibilityIdentifier("engine.lab.noteType")
                    if kind == "owner" || kind == "assignment" {
                        TextField(kind == "owner" ? "Owner" : "Assignee", text: $person)
                            .accessibilityIdentifier("engine.lab.person")
                    }
                    if kind == "decision" {
                        Picker("Decision", selection: $action) {
                            ForEach(["promote", "hold", "kill", "extend"], id: \.self) {
                                Text($0 == "promote" ? "Nominate for probe" : $0.capitalized).tag($0)
                            }
                        }
                    }
                    if kind == "assignment_state" {
                        Picker("Assignment", selection: $assignmentId) {
                            Text("Choose assignment").tag("")
                            ForEach(assignments) { Text($0.payload["title"] ?? "Assignment").tag($0.id) }
                        }
                        Picker("State", selection: $assignmentState) {
                            ForEach(["open", "in_progress", "done", "cancelled"], id: \.self) { Text($0.replacingOccurrences(of: "_", with: " ").capitalized).tag($0) }
                        }
                    } else if kind != "owner" {
                        TextField(kind == "assignment" ? "Task title" : kind == "decision" ? "Reason" : "Comment", text: $note, axis: .vertical)
                            .lineLimit(3...8).accessibilityIdentifier("engine.lab.note")
                        Text(kind == "assignment" ? "Up to 240 characters." : "Up to 2,000 characters.").font(.caption)
                    }
                }.disabled(sending || pending != nil || posted)
                Section {
                    if state.fixtureMode.enabled { Text("Fixture preview. Posting is disabled.") }
                    if sending { ProgressView("Posting advisory note") }
                    if let result {
                        Text(result).accessibilityIdentifier("engine.lab.postResult")
                            .accessibilityAddTraits(.updatesFrequently).accessibilityFocused($resultFocused)
                    }
                    Button(pending == nil ? "Post advisory note" : "Retry same note") { Task { await post() } }
                        .disabled(!valid || sending || state.engineLabSending || state.fixtureMode.enabled || posted)
                        .accessibilityIdentifier("engine.lab.post")
                    if pending != nil && !sending && !posted {
                        Text("The draft is locked until this request is confirmed. Retry safely before posting another note.").font(.caption)
                    }
                }
            }
            .navigationTitle("Advisory note")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() }.disabled(sending) } }
            .interactiveDismissDisabled(sending)
            .onAppear {
                if let saved = state.pendingEngineLabEvent, saved.engineId == engineId {
                    pending = saved
                    kind = saved.kind
                    person = saved.payload["owner"] ?? saved.payload["assignee"] ?? ""
                    note = saved.payload["text"] ?? saved.payload["title"] ?? saved.payload["reason"] ?? ""
                    action = saved.payload["action"] ?? "hold"
                    assignmentId = saved.payload["assignment_id"] ?? ""
                    assignmentState = saved.payload["state"] ?? "in_progress"
                    result = "The previous result is unknown. Retry the same note to confirm it without a duplicate."
                }
            }
        }
    }

    private func post() async {
        guard !sending, !posted, valid else { return }
        do {
            let input: EngineLab.EventInput
            if let pending { input = pending }
            else { input = try EngineLab.EventInput(engineId: engineId, kind: kind, payload: payload) }
            pending = input
            sending = true
            result = nil
            let error = await state.submitEngineLabEvent(input)
            sending = false
            posted = error == nil
            result = error ?? "Advisory note posted. Trading settings did not change."
            if error?.contains("declined") == true || error?.contains("Pair this device") == true { pending = nil }
            resultFocused = true
        } catch { result = "Check the required fields and text limits. Your draft is kept."; resultFocused = true }
    }
}

private struct EngineLabNotePreview: View {
    let lane: EngineLab.Lane

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(lane.name).font(.headline)
            Label(lane.stage.label, systemImage: lane.stage.symbol)
                .font(.caption.bold())
                .padding(4).background(.quaternary, in: Capsule())
                .accessibilityIdentifier("engine.lab.stage.\(lane.id)")
            Text(lane.hypothesis)
            Text("Next: \(lane.nextAction)")
        }
    }
}

private struct EngineLabNoteSummary: View {
    let lane: EngineLab.Lane
    let reviewedAt: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Offline fallback only. These bundled notes are not live evidence.").font(.caption).foregroundStyle(.orange)
            Text(lane.name).font(.headline)
            Label(lane.stage.label, systemImage: lane.stage.symbol)
                .font(.caption.bold())
                .padding(4).background(.quaternary, in: Capsule())
                .accessibilityIdentifier("engine.lab.stage.\(lane.id)")
            LabeledContent("Owner", value: lane.ownerLabel)
            Text(lane.hypothesis)
            ForEach(Array(lane.evidence.enumerated()), id: \.offset) { _, evidence in
                Text("\(evidence.label): \(evidence.value)")
                Text("As of \(evidence.asOf)").font(.caption).foregroundStyle(.secondary)
            }
            Text("Next: \(lane.nextAction)")
            Text("Reviewed \(reviewedAt)").font(.caption)
            Text(lane.boundary).font(.caption).foregroundStyle(.secondary)
        }
    }
}

private struct EngineLabAccountSummary: View {
    let engine: Engine
    let account: EngineControlAccount

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(EngineLab.entriesLabel(engine: engine, accountId: account.id))
            if let configuration = EngineLab.configuration(engine: engine, accountId: account.id) {
                Text("\(EngineLab.customSettings(configuration)) custom settings")
                Text("Reported freshness: \(configuration.freshness ?? "Unknown")")
                if let pending = configuration.pending {
                    Text("Request: \(pending.state ?? "State unknown")")
                } else {
                    Text("No pending request reported")
                }
            } else {
                Text("Custom settings unknown. Pending state unknown.")
            }
            if let pending = engine.configuration?.global.pending {
                Text("Global request: \(pending.state ?? "State unknown")")
            }
        }.font(.caption)
    }
}

private struct EngineLabRequestRow: View {
    let request: ControlRequest
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(request.value?.displayValue ?? request.kind ?? "Engine request")
            Text(EngineLab.requestScope(request.scope)).font(.caption)
            Text(request.state ?? "State unknown")
        }
    }
}

@MainActor private struct EngineLabLiveDetail: View {
    @Environment(AppState.self) private var state
    let engineId: String
    private var engine: Engine? { state.engines?.engines?.first { $0.engineId == engineId } }
    private var accounts: [EngineControlAccount] { state.engines?.accounts ?? [] }
    private var selectedAccountId: String? { EngineLab.yourLane(in: accounts) }

    private func brief(_ engine: Engine, audience: EngineWorkshop.BriefAudience) -> String {
        EngineWorkshop.brief(engine: engine, accountId: selectedAccountId, accounts: accounts,
            generatedAt: state.engines?.generatedAt, observedAt: state.enginesObservedAt,
            now: .now, fixture: state.fixtureMode.enabled, audience: audience,
            redactingIdentifiers: [state.kashbotStatus?.tenant?.id ?? "", state.kashbotStatus?.lane?.id ?? ""])
    }

    var body: some View {
        List {
            if let engine {
                Section("Reported engine") {
                    Text(engine.description ?? "Description not published.")
                    Text(EngineLab.entriesLabel(engine: engine))
                    Text("Enabled settings are not proof of live orders or fills.")
                    Text("Bound books: \(engine.boundBooks?.joined(separator: ", ") ?? "Not published")")
                    Text("Net P&L (cents): \(engine.pnl?.netCents.map { String($0) } ?? "Not published")")
                    Text("Tickets: \(engine.pnl?.n.map { String($0) } ?? "Not published")")
                    Text("Engine totals are not your account's fills.").font(.caption)
                    if let error = state.enginesError { Text(error).foregroundStyle(.red) }
                    TimelineView(.periodic(from: .now, by: 15)) { context in
                        Text(EngineLab.freshness(generatedAt: state.engines?.generatedAt,
                            observedAt: state.enginesObservedAt, now: context.date).rawValue)
                    }
                }
                TimelineView(.periodic(from: .now, by: 15)) { context in
                    EngineWorkshopReadinessSection(items: EngineWorkshop.readiness(engine: engine,
                        accountId: selectedAccountId, generatedAt: state.engines?.generatedAt,
                        observedAt: state.enginesObservedAt, now: context.date, accounts: accounts))
                }
                EngineWorkshopToolsSection(id: engine.engineId, brief: brief(engine, audience: .share),
                    studioBrief: brief(engine, audience: .studio))
                Section("Compare accounts") {
                    NavigationLink {
                        EngineWorkshopCompareView(engineId: engine.engineId)
                    } label: {
                        Label("Compare evidence", systemImage: "square.split.2x1")
                    }.accessibilityIdentifier("engine.workshop.compare.\(engine.engineId)")
                }
                Section("Account-effective dials") {
                    ForEach(state.engines?.accounts ?? []) { account in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(account.label).font(.headline)
                            EngineLabAccountSummary(engine: engine, account: account)
                            if let policy = EngineLab.configuration(engine: engine, accountId: account.id)?.effective.policy {
                                ForEach(policy.keys.sorted(), id: \.self) { key in
                                    LabeledContent(key, value: policy[key].map { String($0) } ?? "Unknown")
                                }
                                if policy.isEmpty { Text("No effective dials reported.") }
                            } else {
                                Text("Effective dials unknown.")
                            }
                            EngineLabSettingsLink(engine: engine, account: account)
                        }
                    }
                    if state.engines?.accounts?.isEmpty != false { Text("Account-effective settings not reported.") }
                }
                Section("Requests") {
                    if let pending = engine.configuration?.global.pending {
                        Text("Global request: \(pending.state ?? "State unknown")")
                    }
                    ForEach(requests) { request in EngineLabRequestRow(request: request) }
                    if requests.isEmpty { Text("No engine requests in the latest response.") }
                }
                Section {
                    NavigationLink {
                        EngineHistoryView(engineId: engine.engineId)
                    } label: {
                        Label("Performance and settings history", systemImage: "chart.xyaxis.line")
                    }
                }
            } else {
                Text("Engine no longer published. Current status unknown.")
            }
        }.navigationTitle(engine?.name ?? engineId)
    }

    private var requests: [ControlRequest] {
        state.pendingRequests.filter {
            if case let .configure(value)? = $0.value { return value.engineId == engineId }
            return false
        }
    }
}

@MainActor private struct EngineLabSettingsLink: View {
    let engine: Engine
    let account: EngineControlAccount
    var tuning = false
    var body: some View {
        if EngineLab.canOpenSettings(account: account, engine: engine) {
            NavigationLink {
                EngineSettingsView(engineId: engine.engineId, initialAccountId: account.id)
            } label: {
                Label(tuning ? "Tune for \(account.label)" : "Settings for \(account.label)", systemImage: "slider.horizontal.3")
            }.accessibilityIdentifier("engine.lab.settings.\(engine.engineId)")
        }
    }
}
