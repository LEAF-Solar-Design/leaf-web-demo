import SwiftUI

@MainActor struct StudioView: View {
    @Environment(MushyState.self) private var studio

    var body: some View {
        AssistantConversationView()
            .onAppear { studio.studioVisible = true }
            .onDisappear { studio.studioVisible = false }
    }
}
