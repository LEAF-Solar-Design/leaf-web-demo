import SwiftUI

@MainActor struct NeedsYouCard: View {
    @Environment(AppState.self) private var state
    @Environment(AssistantInbox.self) private var inbox
    @Environment(MushyState.self) private var studio
    @Environment(\.askAssistant) private var askAssistant

    enum Kind: String, Hashable {
        case tuning, assistant, requests
    }

    struct Row: Identifiable, Equatable {
        let kind: Kind
        let count: Int
        let text: String
        var id: String { "monitor.needsYou." + kind.rawValue }
    }

    /// Missing counts stay unknown; only a reported positive count produces a row.
    static func rows(tuning: Int?, assistant: Int?, requests: Int?) -> [Row] {
        var rows: [Row] = []
        if let tuning, tuning > 0 {
            rows.append(Row(kind: .tuning, count: tuning,
                            text: "\(tuning) tuning \(tuning == 1 ? "plan" : "plans") to approve"))
        }
        if let assistant, assistant > 0 {
            rows.append(Row(kind: .assistant, count: assistant,
                            text: "\(assistant) assistant \(assistant == 1 ? "card" : "cards") unread"))
        }
        if let requests, requests > 0 {
            rows.append(Row(kind: .requests, count: requests,
                            text: "\(requests) \(requests == 1 ? "request" : "requests") waiting for the runner"))
        }
        return rows
    }

    /// AppState retains terminal requests too; they are no longer waiting for the runner.
    static func pendingRequestCount(states: [String?]) -> Int {
        states.filter { $0?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == "requested" }.count
    }

    private func label(_ row: Row, linked: Bool) -> some View {
        HStack(spacing: 8) {
            Text(row.text).font(LeafType.body)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 8)
            if linked {
                Image(systemName: "chevron.right").font(LeafType.meta)
                    .accessibilityHidden(true)
            }
        }
        .foregroundStyle(LeafTheme.ink)
        .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
        .contentShape(Rectangle())
    }

    var body: some View {
        let rows = Self.rows(tuning: state.liveBoard?.approvalsWaiting, assistant: inbox.unreadCount,
                             requests: Self.pendingRequestCount(states: state.pendingControls.map(\.state)))
        Group {
            if !rows.isEmpty {
                FlatCard(title: "Needs you") {
                    ForEach(rows) { row in
                        if row.kind == .requests {
                            label(row, linked: false)
                                .accessibilityElement(children: .combine)
                                .accessibilityLabel(row.text)
                                .accessibilityIdentifier(row.id)
                        } else {
                            NavigationLink(value: row.kind) { label(row, linked: true) }
                                .buttonStyle(.plain)
                                .accessibilityLabel(row.text)
                                .accessibilityIdentifier(row.id)
                        }
                    }
                }
                .accessibilityElement(children: .contain)
                .accessibilityIdentifier("monitor.needsYou")
            }
        }
        // Keep destinations registered when opening the inbox marks its cards seen and hides the card.
        .navigationDestination(for: Kind.self) { kind in
            switch kind {
            case .tuning:
                AutopilotView()
            case .assistant:
                AssistantInboxView(
                    onReview: { askAssistant(inbox.reviewText(for: $0)) },
                    onDiscussCard: {
                        askAssistant(inbox.discussText(for: $0, currentSessionId: studio.selections.sessionId))
                    },
                    onDiscussNomination: { askAssistant(inbox.discussText(for: $0)) })
                    .leafScreenBackground()
                    .foregroundStyle(LeafTheme.ink)
                    .navigationTitle("Assistant inbox")
                    .navigationBarTitleDisplayMode(.inline)
            case .requests:
                EmptyView()
            }
        }
    }
}
