import SwiftUI

@MainActor private struct RiskConfirmationModifier: ViewModifier {
    @Bindable var state: AppState
    func body(content: Content) -> some View {
        content.sheet(item: Binding(get: { state.pendingConfirmation }, set: { value in
            if value == nil { state.cancelPending() }
        })) { confirmation in
            VStack(alignment: .leading, spacing: 20) {
                Text(confirmation.title).font(.title2)
                Text(confirmation.detail)
                HStack {
                    Button("Cancel") { state.cancelPending() }
                        .accessibilityIdentifier("risk.confirm.cancel")
                    Spacer()
                    Button(confirmation.actionLabel) { Task { await state.confirmPending() } }
                        .disabled(state.confirmationInProgress)
                        .accessibilityIdentifier("risk.confirm.action")
                }
            }
            .padding()
            .presentationDetents([.medium])
            .accessibilityIdentifier("risk.confirm.sheet")
        }
    }
}

extension View {
    @MainActor func riskConfirmation(_ state: AppState) -> some View {
        modifier(RiskConfirmationModifier(state: state))
    }
}
