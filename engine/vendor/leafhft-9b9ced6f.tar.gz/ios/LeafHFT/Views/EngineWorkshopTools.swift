import SwiftUI
import LeafHFTCore

struct OpenStudioAction: Sendable {
    let action: @MainActor @Sendable (String) -> Void
    init(_ action: @escaping @MainActor @Sendable (String) -> Void) { self.action = action }
    @MainActor func callAsFunction(_ text: String) { action(text) }
}
private struct OpenStudioKey: EnvironmentKey {
    static let defaultValue = OpenStudioAction { _ in }
}
extension EnvironmentValues {
    var openStudio: OpenStudioAction {
        get { self[OpenStudioKey.self] }
        set { self[OpenStudioKey.self] = newValue }
    }
}

struct EngineWorkshopReadinessSection: View {
    let items: [EngineWorkshop.ReadinessItem]
    var body: some View {
        Section {
            ForEach(items) { item in
                VStack(alignment: .leading, spacing: 4) {
                    LabeledContent(item.kind.label, value: item.status.label)
                    Text(item.detail).font(.caption)
                    if let asOf = item.asOf { Text("As of \(asOf)").font(.caption).foregroundStyle(.secondary) }
                }
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("engine.workshop.readiness.\(item.kind.rawValue)")
                .accessibilityValue(item.status.rawValue)
            }
        } header: {
            Text("Readiness")
        } footer: {
            Text("Shows what is published. It is not an approval.")
        }
    }
}

@MainActor struct EngineWorkshopToolsSection: View {
    @Environment(\.openStudio) private var openStudio
    let id: String
    let brief: String
    let studioBrief: String
    var body: some View {
        Section {
            Button("Ask Studio: design a change") {
                openStudio(EngineWorkshop.studioPrompt(.design, studioBrief))
            }
            .accessibilityHint("Opens the assistant with Engine building on and a draft request")
            .accessibilityIdentifier("engine.workshop.ask.design.\(id)")
            Button("Ask Studio: test this idea") {
                openStudio(EngineWorkshop.studioPrompt(.test, studioBrief))
            }
            .accessibilityHint("Opens the assistant with Engine building on and a draft request")
            .accessibilityIdentifier("engine.workshop.ask.test.\(id)")
            ShareLink(item: brief) {
                Label("Share build brief", systemImage: "square.and.arrow.up")
            }.accessibilityIdentifier("engine.workshop.share.\(id)")
            DisclosureGroup("Build brief") {
                Text(brief).font(.caption).textSelection(.enabled)
                    .accessibilityIdentifier("engine.workshop.brief.\(id)")
            }
        } header: {
            Text("Workshop tools")
                .accessibilityIdentifier("engine.workshop.tools")
        }
    }
}

@MainActor struct EngineWorkshopCompareView: View {
    @Environment(AppState.self) private var state
    let engineId: String
    private var engine: Engine? { state.engines?.engines?.first { $0.engineId == engineId } }
    var body: some View {
        TimelineView(.periodic(from: .now, by: 15)) { context in
        List {
            Text("Global values and each account's published effective values. Missing values are unknown.")
            if let error = state.enginesError ?? state.feedStatuses[.engines]?.lastError {
                Text("Read failed: \(error). Showing last published values.")
                    .foregroundStyle(LeafTheme.loss)
                    .accessibilityIdentifier("engine.workshop.compare.error")
            }
            if state.isStale(.engines, budget: 120, now: context.date) {
                Text("Delayed telemetry. These values may be out of date.")
                    .foregroundStyle(LeafTheme.stale)
                    .accessibilityIdentifier("engine.workshop.compare.stale")
            }
            if let engine {
                let rows = EngineWorkshop.dialComparison(engine: engine, accounts: state.engines?.accounts ?? [])
                ForEach(rows) { row in
                    Section {
                        LabeledContent("Global", value: row.globalText)
                        observation(engine.configuration?.global.observedAt,
                                    freshness: engine.configuration?.global.freshness, now: context.date)
                            .accessibilityIdentifier("engine.workshop.compare.observed.\(row.key).global")
                        ForEach(row.accounts) { account in
                            let configuration = engine.configuration?.accounts.first { $0.accountId == account.accountId }
                            VStack(alignment: .leading, spacing: 4) {
                                LabeledContent(account.label, value: account.valueText)
                                observation(configuration?.observedAt, freshness: configuration?.freshness, now: context.date)
                                    .accessibilityIdentifier("engine.workshop.compare.observed.\(row.key).\(account.accountId)")
                                if account.differs { Text("Differs from global").font(.caption.bold()) }
                            }
                        }
                    } header: {
                        Text(row.name)
                            .accessibilityIdentifier("engine.workshop.compare.row.\(row.key)")
                    }
                }
                if rows.isEmpty { Text("Effective dials unknown.") }
                if state.engines?.accounts?.isEmpty != false { Text("Account-effective settings not reported.") }
                NavigationLink {
                    EngineHistoryView(engineId: engineId)
                } label: {
                    Label("Performance and settings history", systemImage: "chart.xyaxis.line")
                }
                .accessibilityIdentifier("engine.workshop.compare.history")
            } else {
                Text("Engine no longer published. Current status unknown.")
            }
        }
        .accessibilityIdentifier("engine.workshop.compare.list")
        }.navigationTitle("Compare accounts")
    }

    private func observation(_ raw: String?, freshness: String?, now: Date) -> some View {
        let observed = EngineDetailReconcile.parse(raw)
        let stale = observed.map { transportStale(observedAt: $0, now: now) || $0 > now } ?? true
        let warning = stale || freshness?.lowercased() != "fresh"
        return Text((observed.map { ageDescription(observedAt: $0, now: now) } ?? "Observation age unknown") +
                    (warning ? " · Delayed or unknown telemetry" : ""))
            .font(.caption)
            .foregroundStyle(warning ? LeafTheme.stale : LeafTheme.inkMuted)
    }
}
