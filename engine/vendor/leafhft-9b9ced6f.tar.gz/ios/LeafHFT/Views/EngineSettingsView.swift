import SwiftUI
import LeafHFTCore

@MainActor struct EngineSettingsView: View {
    let engineId: String
    let initialAccountId: String?
    @Environment<AppState>(AppState.self) private var state
    @State private var scopeId: String
    @State private var scopeDefaulted = false
    @State private var drafts: [String: EngineConfigurationDraft] = [:]
    @State private var baselineFingerprints: [String: String] = [:]
    @State private var query = ""
    @State private var showChangedOnly = false
    @State private var showAdvanced = false
    @State private var expandedHelp: Set<String> = []
    @State private var reviewing = false
    @State private var sending = false
    @State private var error: String?
    @State private var submittedClientId: String?
    @State private var dismissedRequestId: String?
    @State private var fieldText: [String: String] = [:]
    @State private var confirmingDiscard = false
    @FocusState private var searchFocused: Bool
    @State private var keyboardVisible = false
    @State private var selectedSearchKey: String?
    @State private var scopeDetailsExpanded = false

    static func accountPickerUnavailable(accountCount: Int) -> Bool { accountCount == 0 }

    static func prerequisiteMessages(noAccounts: Bool, needsAccount: Bool, configurationMissing: Bool,
                                     scopeFresh: Bool?, transportFresh: Bool) -> [String] {
        var messages: [String] = []
        if noAccounts { messages.append("No configurable accounts received") }
        else if needsAccount { messages.append("Choose an account") }
        if configurationMissing { messages.append("Account controls not reported") }
        else if scopeFresh == nil { messages.append("Control freshness not reported") }
        else if scopeFresh == false { messages.append("Control data delayed") }
        if !transportFresh { messages.append("Engine observation delayed or not reported") }
        return messages
    }

    static func compactSearchResults(query: String, focused: Bool, keyboardVisible: Bool) -> Bool {
        keyboardVisible && (focused || !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
    }

    static func problemSummary(savedNames: [String], problems: [String]) -> String {
        ([savedNames.isEmpty ? nil : "Saved values above the runner's maximum: \(savedNames.joined(separator: ", "))."]
            .compactMap { $0 } + problems).joined(separator: " ")
    }

    private var searching: Bool { searchFocused || !trimmedQuery.isEmpty }
    private var compactResults: Bool {
        Self.compactSearchResults(query: query, focused: searchFocused, keyboardVisible: keyboardVisible)
    }
    private var accountPickerUnavailable: Bool { Self.accountPickerUnavailable(accountCount: accounts.count) }
    private var observationText: String {
        state.enginesObservedAt.map { "Engine data observed \($0.formatted(date: .abbreviated, time: .standard))" }
            ?? "Engine observation time not reported"
    }
    private var prerequisiteMessages: [String] {
        Self.prerequisiteMessages(noAccounts: accountPickerUnavailable, needsAccount: pairedDevice && isGlobal,
            configurationMissing: engine?.configuration == nil || (!isGlobal && accountConfiguration == nil),
            scopeFresh: (isGlobal ? globalConfiguration?.freshness : accountConfiguration?.freshness)
                .map { $0.lowercased() == "fresh" },
            transportFresh: state.enginesObservedAt.map { !transportStale(observedAt: $0, now: Date()) } == true)
            + [disabledReason, state.enginesError,
               sourceChanged ? "Runner values changed; reload before saving" : nil,
               !hostMatches ? (host == nil ? "Runner host not reported" : "Selected account belongs to a different runner") : nil,
               revision?.isEmpty != false ? "Control revision not reported" : nil,
               engineHasUnresolvedRequest ? "Waiting for the existing request" : nil,
               state.fixtureMode.enabled && !state.fixtureMode.controlWalk ? "Preview data; saving disabled" : nil]
                .compactMap { $0 }
    }

    private var namedProblems: String {
        Self.problemSummary(savedNames: draft?.savedAboveMaximumNames ?? [], problems: editedBlockingProblems)
    }

    init(engineId: String, initialAccountId: String? = nil) {
        self.engineId = engineId
        self.initialAccountId = initialAccountId
        _scopeId = State(initialValue: initialAccountId ?? "global")
    }

    private var engine: Engine? { state.engines?.engines?.first { $0.engineId == engineId } }
    private var accounts: [EngineControlAccount] {
        // Local UI fixture only; production account payloads and request handling are unchanged.
        if state.fixtureMode.enabled && ProcessInfo.processInfo.arguments.contains("-LEAFHFT_CONFIGURE_NO_ACCOUNTS") { return [] }
        return (state.engines?.accounts ?? []).filter { $0.configurable && $0.id != "unassigned" }
    }
    private var selectedAccount: EngineControlAccount? { accounts.first { $0.id == scopeId } }
    private var accountConfiguration: EngineAccountConfiguration? {
        engine?.configuration?.accounts.first { $0.accountId == scopeId }
    }
    private var globalConfiguration: EngineGlobalConfiguration? { engine?.configuration?.global }
    private var isGlobal: Bool { scopeId == "global" }
    private var pairedDevice: Bool { state.dashboardPairingState == .paired }
    private var scopeText: String { isGlobal ? "All accounts" : String((selectedAccount?.label ?? "This account").prefix(128)) }
    private var engineName: String { String((engine?.name ?? "Engine").prefix(128)) }
    private var engineSummary: String {
        [engine?.description, engine?.boundBooks?.joined(separator: ", ")]
            .compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: " · ")
    }
    private var parameters: [PolicyParameter] { draft?.parameters ?? PolicyCatalog.parameters }
    private var disabledReason: String? {
        AppState.labShadowReason(engineId: engineId, engines: state.engines, lab: state.engineLab) ?? engine?.controlDisabledReason
    }
    private var keys: [String] { engine.map { engineSetKeys(for: $0) } ?? [] }
    private var selectedScope: ControlScope? { isGlobal ? .global : (try? .account(scopeId)) }
    private var currentBaseline: EngineConfigurationBaseline? {
        guard let engine, engine.configuration != nil, let scope = selectedScope else { return nil }
        return EngineConfigurationBaseline(engine: engine, scope: scope)
    }
    private var draft: EngineConfigurationDraft? { drafts[scopeId] }
    private var revision: String? { currentBaseline?.revision }
    private var host: String? { isGlobal ? engine?.host : selectedAccount?.host }
    private var hostMatches: Bool {
        guard let host else { return false }
        return isGlobal || engine?.host == nil || engine?.host == host
    }
    private var sourceReference: String { currentBaseline?.fingerprint ?? "" }
    private var sourceChanged: Bool {
        guard let fingerprint = baselineFingerprints[scopeId] else { return false }
        return fingerprint != sourceReference
    }
    private var scopeFresh: Bool {
        let freshness = isGlobal ? globalConfiguration?.freshness : accountConfiguration?.freshness
        return freshness?.lowercased() == "fresh"
    }
    private var serverPending: Bool {
        globalConfiguration?.pending != nil || engine?.configuration?.accounts.contains { $0.pending != nil } == true
    }
    private var requests: [ControlRequest] {
        state.pendingRequests.filter { request in
            guard request.kind == ControlKind.configure.rawValue,
                  case let .configure(value)? = request.value, value.engineId == engineId else { return false }
            return request.scope == selectedScope
        }
    }
    private var engineHasUnresolvedRequest: Bool {
        serverPending || state.pendingRequests.contains { request in
            guard request.kind == ControlKind.configure.rawValue,
                  case let .configure(value)? = request.value, value.engineId == engineId else { return false }
            return !isTerminal(request)
        } || state.controlOutcomeUnknown
    }
    private var submittedRequest: ControlRequest? {
        let candidate: ControlRequest?
        if let submittedClientId {
            candidate = requests.first { $0.clientRequestId == submittedClientId }
        } else {
            candidate = requests.last
        }
        guard let candidate, candidate.id != dismissedRequestId else { return nil }
        return candidate
    }
    private var controlsDisabled: Bool { sending || engineHasUnresolvedRequest || draft == nil || disabledReason != nil || (engineId == "darkhorse" && isGlobal) }
    private var trimmedQuery: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var visibleGroups: [(category: PolicyCategory, parameters: [PolicyParameter])] {
        let groups = PolicyCategory.allCases.map { category in
            (category: category, parameters: parameters.filter { $0.category == category && keys.contains($0.key) })
        }
        return groups.compactMap { group in
            let visible = group.parameters.filter { parameter in
                (trimmedQuery.isEmpty || parameter.matches(trimmedQuery)) &&
                (!showChangedOnly || draft?.isChanged(parameter.key) == true) &&
                (!parameter.advanced || showAdvanced || !trimmedQuery.isEmpty || draft?.isChanged(parameter.key) == true)
            }
            return visible.isEmpty ? nil : (category: group.category, parameters: visible)
        }
    }
    private var fieldErrors: [String: String] {
        var result: [String: String] = [:]
        for parameter in parameters where parameter.control == .field {
            guard let text = fieldText[fieldKey(parameter.key)] else { continue }
            if let value = PolicyValueFormatter.parse(text, parameter: parameter) {
                result[parameter.key] = draft?.validate(key: parameter.key, value: value)
            } else {
                result[parameter.key] = "Enter a number in \(parameter.unit.label)."
            }
        }
        return result
    }
    private var blockingProblems: [String] {
        let errors = (draft?.validationErrors ?? [:]).merging(fieldErrors) { _, field in field }
        return Array(Set(errors.keys.sorted().compactMap { errors[$0] } + (draft?.blockingProblems ?? []))).sorted()
    }
    /// Display only: saved values above the maximum are listed once by name; blockingProblems still gates Review.
    private var editedBlockingProblems: [String] {
        let saved = draft?.savedAboveMaximumMessages ?? []
        return blockingProblems.filter { !saved.contains($0) }
    }
    private var unsavedCount: String {
        let count = draft?.changeCount ?? 0
        return count == 0 ? "No unsaved changes" : (count == 1 ? "1 unsaved change" : "\(count) unsaved changes")
    }
    private var enabledSource: PolicyValueSource {
        if draft?.enabledChange != .unchanged && draft != nil { return .drafted }
        if isGlobal { return .global }
        return draft?.baseline.overrideEnabled == nil ? .inherited : .overridden
    }
    private var statusLine: String { "\(enabledSource.label) · Effective \(onOff(draft?.effectiveEnabled))" }

    private func canReview(at date: Date) -> Bool {
        !controlsDisabled && engine != nil && engine?.configuration != nil && revision?.isEmpty == false && host != nil && hostMatches &&
        selectedScope != nil && scopeFresh && !(pairedDevice && isGlobal) &&
        state.enginesObservedAt.map { !transportStale(observedAt: $0, now: date) } == true &&
        state.enginesError == nil && baselineFingerprints[scopeId] != nil && !sourceChanged &&
        (!state.fixtureMode.enabled || state.fixtureMode.controlWalk) && !sending && !state.submittingControl &&
        !engineHasUnresolvedRequest && submittedClientId == nil && draft?.hasChanges == true && blockingProblems.isEmpty
    }

    var body: some View {
        TimelineView(.periodic(from: .now, by: 15)) { context in
            ScrollViewReader { proxy in
            Form {
                if !searching {
                    scopeSection
                }
                searchSection
                    .id("configure.search")
                if !searching { enabledSection }
                if engine != nil, engineId != "darkhorse", keys.isEmpty, trimmedQuery.isEmpty {
                    Section {
                        Caption("This engine published no editable settings. Its runner policy may be missing or not yet observed.", tone: .warn, expandable: true)
                            .accessibilityIdentifier("engine.settings.noParameters")
                    }
                    .listRowBackground(LeafTheme.card)
                    .listRowSeparatorTint(LeafTheme.line)
                }
                if compactResults { searchResults } else { parameterSections }
                if let engine, !engineServerOnlyKeys(for: engine).isEmpty, trimmedQuery.isEmpty {
                    Section("Server-defined settings") {
                        Caption("These settings exist on the runner but this app cannot edit them yet.", expandable: true)
                            .accessibilityIdentifier("engine.settings.serverOnly")
                        ForEach(engineServerOnlyKeys(for: engine), id: \.self) { key in
                            LabeledContent(key, value: serverOnlyValue(for: key))
                        }
                    }
                    .listRowBackground(LeafTheme.card)
                    .listRowSeparatorTint(LeafTheme.line)
                }
                requestSection
                if !requests.isEmpty {
                    Section("Recent requests") {
                        ForEach(requests) { request in
                            VStack(alignment: .leading, spacing: 4) {
                                Caption(String((request.value?.displayValue ?? "Unknown change").prefix(512)), expandable: true)
                                OneLine(request.state?.capitalized ?? "Status unknown")
                                if let note = request.note, !note.isEmpty {
                                    Caption(String(note.prefix(512)), expandable: true)
                                }
                            }
                        }
                    }
                    .listRowBackground(LeafTheme.card)
                    .listRowSeparatorTint(LeafTheme.line)
                    .accessibilityIdentifier("engine.settings.requests")
                }
            }
            .accessibilityIdentifier("engine.settings.form")
            .font(LeafType.body)
            .foregroundStyle(LeafTheme.ink)
            .listSectionSpacing(16)
            .leafScreenBackground()
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: searchFocused) { _, focused in
                if focused {
                    selectedSearchKey = nil
                    DispatchQueue.main.async { proxy.scrollTo("configure.search", anchor: .top) }
                }
            }
            .onChange(of: compactResults) { _, compact in
                if !compact, let key = selectedSearchKey {
                    DispatchQueue.main.async { proxy.scrollTo(key, anchor: .top) }
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                if compactResults {
                    Text(engineHasUnresolvedRequest ? requestMessage : unsavedCount)
                        .font(LeafType.meta).lineLimit(1)
                        .frame(maxWidth: .infinity).frame(height: 44)
                        .background(LeafTheme.card)
                        .accessibilityIdentifier("engine.settings.searchStatus")
                } else {
                    actionBar(at: context.date)
                }
            }
            }
        }
        .navigationTitle("Engine settings")
        .hidesStudioLauncher()
        .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { _ in keyboardVisible = true }
        .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)) { _ in keyboardVisible = false }
        .onAppear {
            defaultAccountScope()
            if draft == nil { loadCurrent() }
        }
        .onChange(of: state.engines?.accounts) { _, _ in defaultAccountScope() }
        .onChange(of: scopeId) { _, _ in
            error = nil
            submittedClientId = nil
            if draft == nil { loadCurrent() }
        }
        .onChange(of: sourceReference) { _, _ in
            if baselineFingerprints[scopeId] == nil && engine?.configuration != nil { loadCurrent() }
        }
        .sheet(isPresented: $reviewing) {
            if let draft {
                EngineChangeReviewView(engineName: engineName, scopeText: scopeText, draft: draft,
                    accountLabel: selectedAccount?.label, sending: sending, error: error, send: save)
            }
        }
        .confirmationDialog("Discard \(draft?.changeCount ?? 0) unsaved changes?",
                            isPresented: $confirmingDiscard, titleVisibility: .visible) {
            Button("Discard", role: .destructive) {
                editDraft { $0.discardAll() }
                clearFields()
            }.accessibilityIdentifier("engine.settings.discardConfirm")
                .foregroundStyle(LeafTheme.loss)
            Button("Cancel", role: .cancel) {}
        }
    }

    private func defaultAccountScope() {
        guard !scopeDefaulted, pairedDevice, initialAccountId == nil, isGlobal,
              let account = accounts.first else { return }
        scopeId = account.id
        scopeDefaulted = true
    }

    private var scopePicker: some View {
        Group {
            if accountPickerUnavailable {
                Button {} label: {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Applies to")
                        Text("No configurable accounts received").font(LeafType.meta)
                    }
                }
                .disabled(true)
                .accessibilityIdentifier("engine.settings.scopePicker")
            } else {
            Picker("Applies to", selection: $scopeId) {
                if !pairedDevice { Text("All accounts").tag("global") }
                ForEach(accounts) { account in OneLine(String(account.label.prefix(128))).tag(account.id) }
            }
            .pickerStyle(.menu)
            .accessibilityIdentifier("engine.settings.scopePicker")
            .disabled(sending || engineHasUnresolvedRequest)
            }
        }
    }

    private var scopeSection: some View {
        Section {
            VStack(alignment: .leading, spacing: 6) {
                OneLine(engineName).font(LeafType.heading)
                    .accessibilityIdentifier("engine.settings.header")
                scopePicker
                Text(observationText).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("engine.settings.observedAt")
                ForEach(Array(prerequisiteMessages.prefix(2).enumerated()), id: \.offset) { _, message in
                    DisclosureGroup(message) {
                        Text("Sources: engine control response and local draft state. \(observationText). Review scope details below; parameters remain available to inspect.")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                }
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("engine.settings.prerequisites")
            Button {
                scopeDetailsExpanded.toggle()
            } label: {
                HStack {
                    Text("Scope details")
                    Spacer()
                    Image(systemName: scopeDetailsExpanded ? "chevron.up" : "chevron.down")
                }
            }
            .accessibilityValue(scopeDetailsExpanded ? "Expanded" : "Collapsed")
            .accessibilityIdentifier("engine.settings.prerequisiteDetails")
            if scopeDetailsExpanded {
                scopeDetails
            }
        }
        .listRowBackground(LeafTheme.card)
        .listRowSeparatorTint(LeafTheme.line)
    }

    @ViewBuilder private var scopeDetails: some View {
        Text("Account source: engine control response. Checked at: \(state.enginesObservedAt.map { $0.formatted(date: .abbreviated, time: .standard) } ?? "not reported").")
            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            .accessibilityIdentifier("engine.settings.accountDiagnostics")
        if !engineSummary.isEmpty { Caption(engineSummary, expandable: true) }
            if let disabledReason {
                Caption(disabledReason, tone: .warn, expandable: true,
                        identifier: "engine.settings.disabledReason")
                    .accessibilityIdentifier("engine.settings.disabledReason")
            }
            if engineId == "darkhorse" {
                Caption("Darkhorse controls apply to one account. Host models and order limits cannot be changed here.", expandable: true)
                if isGlobal { Caption("Choose an account to edit Darkhorse.", tone: .warn, expandable: true) }
                ForEach(engine?.darkhorse?.models ?? [], id: \.key) { model in
                    Caption("\(model.offset.formatted()) second model: threshold at least \(model.trainedThreshold), below \(model.scoreP99).", expandable: true)
                }
                if engine?.darkhorse?.pending == true { Caption("Runner model settings are pending.", tone: .warn, expandable: true) }
                if engine?.darkhorse?.stale == true { Caption("Darkhorse execution telemetry is delayed.", tone: .warn, expandable: true) }
            }
            if pairedDevice && isGlobal {
                Caption("Choose an account. A paired phone cannot change the defaults for every account.", tone: .warn, expandable: true)
            }
            Caption(isGlobal ? "Global values are the defaults for every account." :
                "Only \(scopeText) changes. Settings without an override keep using the global value.", expandable: true)
            if let selectedAccount, engine?.host != nil, engine?.host != selectedAccount.host {
                Caption("This account belongs to a different runner. Saving is disabled.", tone: .warn, expandable: true)
            }
            if state.fixtureMode.enabled && !state.fixtureMode.controlWalk {
                Caption("Preview data. Saving is disabled.", tone: .warn, expandable: true)
            }
            if engine?.configuration == nil || (!isGlobal && accountConfiguration == nil) {
                Caption("Account controls have not arrived from the runner. Saving is disabled.", tone: .warn, expandable: true)
            } else if (isGlobal ? globalConfiguration?.freshness : accountConfiguration?.freshness) == nil {
                Caption("Control freshness is not reported. Saving is disabled.", tone: .warn, expandable: true)
            } else if !scopeFresh {
                Caption("Control data is delayed. Wait for fresh data before saving.", tone: .warn, expandable: true)
            }
            if let message = state.enginesError {
                Caption(String(message.prefix(512)), tone: .warn, expandable: true)
            }

        ForEach(Array(prerequisiteMessages.dropFirst(2).enumerated()), id: \.offset) { _, message in
            Text(message).font(LeafType.meta)
        }
    }

    private var enabledSection: some View {
        Section("New positions") {
            Toggle(isOn: Binding(
                get: { draft?.effectiveEnabled ?? false },
                set: { value in editDraft { $0.setEnabled(value) } })) {
                VStack(alignment: .leading, spacing: 4) {
                    OneLine("Allow new positions")
                    Caption(statusLine, expandable: true)
                        .accessibilityLabel(statusLine)
                        .accessibilityIdentifier("engine.settings.enabledEffective")
                    if enabledSource != .global {
                        SourceBadge(source: enabledSource)
                            .accessibilityIdentifier("engine.settings.enabledSource")
                    }
                }
            }
            .accessibilityIdentifier("engine.settings.enabled")
            .tint(LeafTheme.gain)
            .disabled(controlsDisabled)
            if !isGlobal {
                Button(engineId == "darkhorse" ? "Use account default (off)" : "Use global setting") { editDraft { $0.inheritEnabled() } }
                    .buttonStyle(.bordered).controlSize(.small)
                    .accessibilityIdentifier("engine.settings.enabledInherited")
                    .disabled(controlsDisabled || (draft?.baseline.overrideEnabled == nil && draft?.enabled == nil))
            }
            Caption("Turning this off blocks new positions in this scope. Existing positions keep their normal exit and risk handling.", expandable: true)
        }
        .listRowBackground(LeafTheme.card)
        .listRowSeparatorTint(LeafTheme.line)
    }

    private var searchSection: some View {
        Section("Find a setting") {
            HStack {
                Image(systemName: "magnifyingglass").foregroundStyle(LeafTheme.inkMuted)
                TextField("Search settings", text: Binding(get: { query }, set: { query = String($0.prefix(256)) }))
                    .autocorrectionDisabled().textInputAutocapitalization(.never)
                    .focused($searchFocused)
                    .submitLabel(.done)
                    .onSubmit { searchFocused = false }
                    .accessibilityIdentifier("engine.settings.search")
                if !query.isEmpty {
                    Button { query = "" } label: {
                        Image(systemName: "xmark.circle.fill").frame(minWidth: 44, minHeight: 44)
                    }.buttonStyle(.borderless).accessibilityLabel("Clear search")
                }
            }
            if searching {
                Text("\(engineName) · \(scopeText) · \(visibleGroups.flatMap(\.parameters).count) matching settings")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("engine.settings.searchCount")
                if !compactResults { scopePicker }
            }
            if !compactResults {
                ViewThatFits(in: .horizontal) {
                    HStack { filterControls }
                    VStack(alignment: .leading) { filterControls }
                }
            }
        }
        .listRowBackground(LeafTheme.card)
        .listRowSeparatorTint(LeafTheme.line)
    }

    @ViewBuilder private var filterControls: some View {
        Button((draft?.changeCount ?? 0) > 0 ? "Changed (\(draft?.changeCount ?? 0))" : "Changed") {
            showChangedOnly.toggle()
        }
            .buttonStyle(.bordered).controlSize(.small).buttonBorderShape(.capsule)
            .tint(showChangedOnly ? LeafTheme.ink : LeafTheme.inkMuted)
            .accessibilityAddTraits(showChangedOnly ? .isSelected : [])
            .accessibilityIdentifier("engine.settings.filterChanged")
        Button("Show advanced") { showAdvanced.toggle() }
            .buttonStyle(.bordered).controlSize(.small).buttonBorderShape(.capsule)
            .tint(showAdvanced ? LeafTheme.ink : LeafTheme.inkMuted)
            .accessibilityAddTraits(showAdvanced ? .isSelected : [])
            .accessibilityIdentifier("engine.settings.showAdvanced")
    }

    private func serverOnlyValue(for key: String) -> String {
        let value: Double?
        if let draft {
            value = draft.effectiveValue(for: key)
        } else {
            let policy = (isGlobal ? globalConfiguration?.policy : accountConfiguration?.effective.policy)
                ?? globalConfiguration?.policy ?? engine?.policy
            value = policy?[key]
        }
        return value.map { String(format: "%.12g", $0) } ?? "Unknown"
    }

    private var searchResults: some View {
        Section {
            if visibleGroups.isEmpty {
                Text("No settings match “\(trimmedQuery)”.")
                    .accessibilityIdentifier("engine.settings.noResults")
            }
            ForEach(visibleGroups.flatMap(\.parameters)) { parameter in
                Button {
                    // Keep the query and scope so the expanded parameter retains its context.
                    selectedSearchKey = parameter.key
                    searchFocused = false
                } label: {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(parameter.name).font(LeafType.body)
                            Text(parameter.category.title).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        }
                        Spacer()
                        Image(systemName: "chevron.right").foregroundStyle(LeafTheme.inkMuted)
                    }
                    .frame(minHeight: 44)
                }
                .accessibilityIdentifier("engine.settings.searchResult.\(parameter.key)")
            }
        }
        .listRowBackground(LeafTheme.card)
        .listRowSeparatorTint(LeafTheme.line)
    }

    @ViewBuilder private var parameterSections: some View {
        if visibleGroups.isEmpty && !trimmedQuery.isEmpty {
            Section {
                Text("No settings match “\(trimmedQuery)”.").accessibilityIdentifier("engine.settings.noResults")
            }
            .listRowBackground(LeafTheme.card)
            .listRowSeparatorTint(LeafTheme.line)
        }
        ForEach(visibleGroups, id: \.category) { group in
            Section {
                ForEach(group.parameters) { parameter in
                    Group {
                    if let draft {
                        if engineId == "darkhorse" {
                            VStack(alignment: .leading, spacing: 6) {
                                OneLine(parameter.name).font(LeafType.heading)
                                Caption(parameter.summary, expandable: true)
                                HStack {
                                    TextField(parameter.name, text: fieldBinding(parameter))
                                        .leafNumeral(.number)
                                        .keyboardType(.decimalPad)
                                        .accessibilityIdentifier("engine.settings.field.\(parameter.key)")
                                        .disabled(controlsDisabled)
                                    Text(parameter.unit.label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                                }
                                .padding(.vertical, 8).padding(.horizontal, 12)
                                .background(LeafTheme.cardRaised, in: RoundedRectangle(cornerRadius: LeafTheme.radiusSmall))
                                Caption(parameter.unit == .probability ? "Enter a percentage. Upper bound is exclusive." :
                                    parameter.key == "base_count" ? "0.01 to 0.50 contracts, up to two decimal places." : "1 to 10 times, up to two decimal places.", expandable: true)
                                if draft.source(for: parameter.key) != .global {
                                    SourceBadge(source: draft.source(for: parameter.key))
                                }
                                if let value = draft.effectiveValue(for: parameter.key) {
                                    Text("Effective: \(String(format: "%.12g", value))").leafNumeral(.number)
                                }
                                if let error = fieldErrors[parameter.key] ?? draft.validationErrors[parameter.key] {
                                    Caption(error, tone: .loss, expandable: true)
                                }
                                HStack {
                                    if !isGlobal {
                                        Button("Use host default") {
                                            editDraft { $0.useGlobal(for: parameter.key) }
                                            fieldText.removeValue(forKey: fieldKey(parameter.key))
                                        }.disabled(controlsDisabled || draft.baseline.globalPolicy[parameter.key] == nil)
                                    }
                                    Button("Undo") {
                                        editDraft { $0.discard(key: parameter.key) }
                                        fieldText.removeValue(forKey: fieldKey(parameter.key))
                                    }.disabled(controlsDisabled || !draft.isChanged(parameter.key))
                                }.buttonStyle(.bordered).controlSize(.small).buttonBorderShape(.capsule)
                            }
                        } else {
                        ParameterRow(parameter: parameter, draft: draft,
                            fieldText: fieldBinding(parameter), validation: fieldErrors[parameter.key] ?? draft.validationErrors[parameter.key],
                            helpExpanded: expandedHelp.contains(parameter.key), disabled: controlsDisabled,
                            conflicts: rowConflicts(parameter.key),
                            setValue: { value in editDraft { $0.setValue(value, for: parameter.key) } },
                            commitField: { commitField(parameter) },
                            useGlobal: {
                                editDraft { $0.useGlobal(for: parameter.key) }
                                fieldText.removeValue(forKey: fieldKey(parameter.key))
                            },
                            undo: {
                                editDraft { $0.discard(key: parameter.key) }
                                fieldText.removeValue(forKey: fieldKey(parameter.key))
                            },
                            toggleHelp: {
                                if expandedHelp.contains(parameter.key) { expandedHelp.remove(parameter.key) }
                                else { expandedHelp.insert(parameter.key) }
                            })
                        }
                    } else {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(parameter.name).font(LeafType.heading)
                            Caption(parameter.summary, expandable: true)
                            Text("Effective value not reported for \(scopeText)")
                                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        }
                        .accessibilityIdentifier("engine.settings.row.\(parameter.key)")
                    }
                    }
                    .id(parameter.key)
                }
            } header: {
                Text(group.category.title)
            } footer: {
                Caption(group.category.summary, expandable: true)
            }
            .listRowBackground(LeafTheme.card)
            .listRowSeparatorTint(LeafTheme.line)
        }
    }

    private func actionBar(at date: Date) -> some View {
        VStack(spacing: 0) {
            LeafTheme.line.frame(height: 1).accessibilityHidden(true)
            VStack(spacing: 8) {
                if engineHasUnresolvedRequest || submittedRequest != nil {
                    HStack {
                        Caption(requestMessage, tone: submittedRequest?.state?.lowercased() == "applied" ? .gain :
                            (submittedRequest?.state?.lowercased() == "rejected" ? .loss : .warn),
                            expandable: true, identifier: "engine.settings.result")
                            .accessibilityAddTraits(.updatesFrequently)
                            .accessibilityElement(children: .contain)
                            .accessibilityLabel(requestMessage)
                            .accessibilityIdentifier("engine.settings.result")
                        if let submittedRequest, isTerminal(submittedRequest) {
                            if submittedRequest.state?.lowercased() == "rejected" {
                                Button("Continue editing draft") { submittedClientId = nil; error = nil }
                                    .buttonStyle(.bordered).controlSize(.small).buttonBorderShape(.capsule)
                                    .accessibilityIdentifier("engine.settings.continueRejected")
                            } else {
                                Button("Load applied values") { loadCurrent(clearDraft: true) }
                                    .buttonStyle(.bordered).controlSize(.small).buttonBorderShape(.capsule)
                                    .disabled(!sourceChanged || !scopeFresh || sending || engineHasUnresolvedRequest)
                                    .accessibilityIdentifier("engine.settings.loadApplied")
                            }
                        }
                    }
                }
                if let error {
                    Caption(String(error.prefix(512)), tone: .loss, expandable: true)
                        .accessibilityAddTraits(.updatesFrequently)
                }
                if !blockingProblems.isEmpty {
                    // Review is always on screen in the sticky bar, so the reason it is disabled lives here too.
                    Caption(namedProblems,
                            tone: .loss, expandable: true, identifier: "engine.settings.blocking")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .accessibilityElement(children: .contain)
                        .accessibilityIdentifier("engine.settings.blocking")
                        .accessibilityLabel(namedProblems)
                }
                HStack {
                    Text(unsavedCount).font(LeafType.meta.weight(.semibold))
                        .lineLimit(1).minimumScaleFactor(0.8)
                        .accessibilityIdentifier("engine.settings.unsavedCount")
                        .accessibilityAddTraits(.updatesFrequently)
                    Spacer()
                    Button("Discard", role: .destructive) { confirmingDiscard = true }
                        .buttonStyle(.plain)
                        .font(LeafType.meta)
                        .foregroundStyle(LeafTheme.loss)
                        .padding(.horizontal, 12).frame(minHeight: 48)
                        .background(LeafTheme.lossSoft, in: Capsule())
                        .overlay {
                            Capsule().strokeBorder(LeafTheme.lossLine, lineWidth: 1)
                                .allowsHitTesting(false).accessibilityHidden(true)
                        }
                        .fixedSize().lineLimit(1)
                        .accessibilityIdentifier("engine.settings.discard")
                        .disabled(draft?.hasChanges != true || sending)
                    Group {
                        if canReview(at: date) {
                            Button("Review") { error = nil; reviewing = true }
                                .buttonStyle(.leafPrimary)
                        } else {
                            Button("Review") { error = nil; reviewing = true }
                                .buttonStyle(.leafSecondary)
                        }
                    }
                        .fixedSize().lineLimit(1)
                        .accessibilityLabel("Review changes")
                        .disabled(!canReview(at: date)).accessibilityIdentifier("engine.settings.save")
                }
            }
            .padding(.vertical, 12).padding(.horizontal, 16)
        }
        .foregroundStyle(LeafTheme.ink)
        .background(LeafTheme.card)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("engine.settings.actionBar")
    }

    private var requestSection: some View {
        Section {
            if !blockingProblems.isEmpty {
                Caption("Saved policy and draft validation", tone: .loss, expandable: true)
                if let names = draft?.savedAboveMaximumNames, !names.isEmpty {
                    let text = "Saved values above the runner's maximum: \(names.joined(separator: ", "))."
                    Caption(text, tone: .loss, expandable: true, identifier: "engine.settings.savedAboveMaximumSummary")
                        .accessibilityElement(children: .contain)
                        .accessibilityLabel(text)
                        .accessibilityIdentifier("engine.settings.savedAboveMaximumSummary")
                }
                ForEach(Array(editedBlockingProblems.enumerated()), id: \.offset) { _, problem in
                    Caption(problem, tone: .loss, expandable: true)
                }
            }
            if sourceChanged {
                Caption("The runner changed while you were editing. Your draft is kept. Reload the current values before saving.",
                        tone: .warn, expandable: true, identifier: "engine.settings.conflict")
                    .accessibilityIdentifier("engine.settings.conflict")
                Button("Reload current values") { loadCurrent() }
                    .disabled(sending || engineHasUnresolvedRequest || !scopeFresh)
                    .accessibilityIdentifier("engine.settings.reload")
            }
            if submittedRequest?.state?.lowercased() == "applied", !sourceChanged {
                Caption("Waiting for fresh values from the runner.", tone: .warn, expandable: true)
            }
            Caption("A request stays pending until the selected runner reports applied or rejected. Unknown results cannot be sent again blindly.", expandable: true)
        }
        .listRowBackground(LeafTheme.card)
        .listRowSeparatorTint(LeafTheme.line)
    }

    private func rowConflicts(_ key: String) -> [PolicyConflict] {
        let visible = Set(visibleGroups.flatMap(\.parameters).map(\.key))
        return draft?.conflicts.filter { $0.keys.first(where: { visible.contains($0) }) == key } ?? []
    }
    private func editDraft(_ edit: (inout EngineConfigurationDraft) -> Void) {
        guard var value = drafts[scopeId] else { return }
        edit(&value)
        drafts[scopeId] = value
    }
    // Text is namespaced so switching accounts also preserves unfinished field input.
    private func fieldKey(_ key: String) -> String { "\(scopeId):\(key)" }
    private func fieldBinding(_ parameter: PolicyParameter) -> Binding<String> {
        let storageKey = fieldKey(parameter.key)
        return Binding(get: {
            fieldText[storageKey] ?? draft?.currentValue(for: parameter.key).map {
                fieldSeed(PolicyValueFormatter.displayValue(fromAPI: $0, unit: parameter.unit))
            } ?? ""
        }, set: { text in
            fieldText[storageKey] = String(text.prefix(128))
            commitField(parameter)
        })
    }
    private func fieldSeed(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.numberStyle = .decimal
        formatter.usesGroupingSeparator = false
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = engineId == "darkhorse" ? 12 : 2
        return formatter.string(from: NSNumber(value: value)) ?? ""
    }

    private func commitField(_ parameter: PolicyParameter) {
        guard let text = fieldText[fieldKey(parameter.key)],
              let value = PolicyValueFormatter.parse(text, parameter: parameter) else { return }
        editDraft { $0.setValue(value, for: parameter.key) }
    }
    private func clearFields() {
        for parameter in parameters { fieldText.removeValue(forKey: fieldKey(parameter.key)) }
    }
    private var requestMessage: String {
        switch submittedRequest?.state?.lowercased() {
        case "applied": return "Applied by the runner. Reload current values before another change."
        case "rejected": return "Rejected by the runner. Your draft is kept. \(String((submittedRequest?.note ?? "Review the current values.").prefix(512)))"
        default: return state.controlOutcomeUnknown ?
            "The result is unknown. Waiting for the existing request before another change." :
            "Pending. Waiting for the selected runner to apply or reject this request."
        }
    }
    private func isTerminal(_ request: ControlRequest) -> Bool {
        ["applied", "rejected"].contains(request.state?.lowercased() ?? "")
    }
    private func loadCurrent(clearDraft: Bool = false) {
        guard let baseline = currentBaseline else { return }
        let previous = drafts[scopeId]
        var rebased = EngineConfigurationDraft(baseline: baseline)
        if !clearDraft, let previous {
            for (key, value) in previous.values {
                switch value {
                case let .set(value): rebased.setValue(value, for: key)
                case .useGlobal: rebased.useGlobal(for: key)
                }
            }
            switch previous.enabled {
            case let .set(value): rebased.setEnabled(value != 0)
            case .useGlobal: rebased.inheritEnabled()
            case nil: break
            }
        }
        if clearDraft {
            dismissedRequestId = submittedRequest?.id
            clearFields()
        }
        else {
            for parameter in parameters where !rebased.isChanged(parameter.key) && fieldErrors[parameter.key] == nil {
                fieldText.removeValue(forKey: fieldKey(parameter.key))
            }
        }
        drafts[scopeId] = rebased
        baselineFingerprints[scopeId] = baseline.fingerprint
        error = nil
        submittedClientId = nil
    }
    private func save() async -> String? {
        guard canReview(at: Date()), let host, selectedScope != nil, revision != nil, let draft else {
            let message = "The request cannot be sent yet. Check the current values and runner status."
            error = message
            return message
        }
        sending = true
        error = nil
        defer { sending = false }
        do {
            let clientId = UUID().uuidString.lowercased()
            let intent = try draft.intent(engineId: engineId, host: host, clientRequestId: clientId)
            submittedClientId = clientId
            dismissedRequestId = nil
            let result = await state.submit(intent, note: nil)
            error = result
            if let result, !result.localizedCaseInsensitiveContains("unknown") { submittedClientId = nil }
            return result
        } catch {
            let message = error.localizedDescription
            self.error = message
            submittedClientId = nil
            return message
        }
    }
    private func onOff(_ value: Bool?) -> String { value.map { $0 ? "On" : "Off" } ?? "Unknown" }
}
