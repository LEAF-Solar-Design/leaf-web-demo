import SwiftUI
import Charts

@MainActor struct AssistantConversationView: View {
    @Environment(MushyState.self) private var studio
    @Environment(AssistantConversation.self) private var conversation
    @Environment(AssistantInbox.self) private var inbox
    @Environment(\.dismiss) private var dismiss
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @FocusState private var composing: Bool
    @State private var tab: AssistantTab = .chat

    private enum AssistantTab { case chat, autotune }

    private var starters: [String] { conversation.engineBuilding ? [
        "Build a paper engine for gold 15-minute markets",
        "Show my engine builds"
    ] : [
        "How much did I make today?",
        "Why is the bot trading less than usual?",
        "Show my account value this week",
        "Which engine is doing best this week?",
        "What can I tune on my engines?",
        "Show my shadow engines"
    ] }
    private var busy: Bool { conversation.isBusy }

    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                VStack(spacing: 0) {
                    header
                    VStack(spacing: 0) {
                        if tab == .autotune {
                            AssistantInboxView(onReview: review, onDiscussCard: discuss, onDiscussNomination: discuss)
                        } else {
                            chat
                        }
                    }
                    .safeAreaInset(edge: .bottom, spacing: 0) {
                        if tab == .chat {
                            if dynamicTypeSize.isAccessibilitySize {
                                // Wrapped drafts and composer notices must leave room for the pinned tabs.
                                ScrollView { composer }
                                    .frame(maxHeight: geometry.size.height * 0.4)
                            } else {
                                composer
                            }
                        }
                    }
                }
                .background(LeafTheme.ground)
                .foregroundStyle(LeafTheme.ink)
            }
            .navigationTitle("Assistant")
            .navigationBarTitleDisplayMode(.inline)
            .task { await conversation.open(studio: studio) }
        }
        .onChange(of: inbox.openRequest) { _, _ in
            handleOpenRequest()
        }
        .onAppear { handleOpenRequest() }
    }

    private func handleOpenRequest() {
        guard inbox.consumeOpenRequest() else { return }
        tab = .autotune
        Task { await inbox.refresh() }
    }

    private var chat: some View {
            GeometryReader { geometry in
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 14) {
                            if conversation.items.isEmpty { emptyState }
                            ForEach(conversation.items) { item in
                                itemView(item, width: max(0, geometry.size.width - 32))
                            }
                            Color.clear.frame(height: 1).id("assistant.bottom")
                        }
                        .padding(16)
                    }
                    .scrollDismissesKeyboard(.interactively)
                    .refreshable {
                        await studio.refresh()
                        conversation.load(from: studio)
                    }
                    .onChange(of: conversation.items.map(\.id)) { _, _ in
                        withAnimation { proxy.scrollTo("assistant.bottom", anchor: .bottom) }
                    }
                    .onChange(of: conversation.activeReply?.text) { _, _ in
                        proxy.scrollTo("assistant.bottom", anchor: .bottom)
                    }
                    .onChange(of: conversation.activeReply?.views.count) { _, _ in
                        withAnimation { proxy.scrollTo("assistant.bottom", anchor: .bottom) }
                    }
                    .onChange(of: conversation.activeReply?.cards.count) { _, _ in
                        withAnimation { proxy.scrollTo("assistant.bottom", anchor: .bottom) }
                    }
                }
            }
    }

    // Kit VI.3: 44 pt tap targets at every content size through AX XXXL; these live in a pinned content row because the navigation bar clamps its items to 36 pt on iPhone.
    private var header: some View {
        VStack(spacing: 4) {
        HStack(spacing: 8) {
            Button {
                composing = false
                Task { await conversation.newConversation(studio: studio) }
            } label: {
                toolbarIcon("New conversation", systemImage: "square.and.pencil")
            }
            .disabled(busy)
            .accessibilityIdentifier("assistant.new")
            Spacer(minLength: 0)
            Button { dismiss() } label: {
                toolbarIcon("Close", systemImage: "xmark")
            }
            .accessibilityIdentifier("assistant.close")
        }
        .padding(.horizontal, 8)
        HStack(spacing: 4) {
            tabButton("Chat", tab: .chat, identifier: "assistant.tab.chat")
            tabButton("Autotune", tab: .autotune, identifier: "assistant.tab.autotune")
        }
        .padding(4)
        .background(LeafTheme.cardRaised, in: RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal, 16)
        .padding(.bottom, 8)
        }
        .background(LeafTheme.ground)
    }

    private func tabButton(_ title: String, tab selection: AssistantTab, identifier: String) -> some View {
        HStack(spacing: 6) {
        Button {
            composing = false
            tab = selection
        } label: {
            Text(title).font(LeafType.meta)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, 8)
                .frame(maxWidth: .infinity, minHeight: 44)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier(identifier)
        .accessibilityLabel(title)
        .accessibilityValue(tab == selection ? "Selected" : "")
        .accessibilityAddTraits(tab == selection ? [.isSelected] : [])
        if selection == .autotune && inbox.unreadCount > 0 {
            AssistantUnreadBadge(count: inbox.unreadCount, identifier: "assistant.tab.autotune.badge")
                .padding(.trailing, 8)
                .frame(minHeight: 44)
                .onTapGesture {
                    composing = false
                    tab = selection
                }
        }
        }
        .frame(maxWidth: .infinity)
        .background(tab == selection ? LeafTheme.card : Color.clear, in: RoundedRectangle(cornerRadius: 8))
    }

    private func toolbarIcon(_ title: String, systemImage: String) -> some View {
        Label(title, systemImage: systemImage)
            .labelStyle(.iconOnly)
            .frame(minWidth: 44, minHeight: 44)
            .contentShape(Rectangle())
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Ask about your money, trades, engines or the runner.")
                .font(LeafType.title)
                .accessibilityIdentifier("assistant.empty")
            ForEach(starters.indices, id: \.self) { index in
                Button {
                    conversation.selectStarter(starters[index])
                    composing = true
                } label: {
                    HStack(spacing: 12) {
                        Text(starters[index]).multilineTextAlignment(.leading)
                        Spacer(minLength: 0)
                        Image(systemName: "arrow.up.message")
                    }
                    .font(LeafType.body)
                    .padding(12)
                    .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                    .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(LeafTheme.line))
                }
                .buttonStyle(.plain)
                .disabled(busy)
                .accessibilityIdentifier("assistant.starter.\(index)")
            }
        }
    }

    @ViewBuilder private func itemView(_ item: AssistantConversation.Item, width: CGFloat) -> some View {
        switch item {
        case .user(_, let text):
            VStack(alignment: .trailing, spacing: 4) {
                Text(text)
                    .font(LeafType.body)
                    .foregroundStyle(LeafTheme.primaryForeground)
                    .padding(14)
                    .background(LeafTheme.primary, in: RoundedRectangle(cornerRadius: 18))
                    .frame(maxWidth: width * 0.85, alignment: .trailing)
                messageTime(item.id)
            }
            .frame(maxWidth: .infinity, alignment: .trailing)
        case .assistant(let id, let reply):
            VStack(alignment: .leading, spacing: 4) {
                replyView(reply, id: id)
                messageTime(id)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        case .notice(_, let text, let tone):
            Text(text).font(LeafType.meta).foregroundStyle(tone.color)
                .accessibilityAddTraits(.updatesFrequently)
        }
    }

    @ViewBuilder private func messageTime(_ id: UUID) -> some View {
        if let time = AssistantFormat.messageTime(conversation.messageDates[id]) {
            Text(time).font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
        }
    }

    private func replyView(_ reply: AssistantReply, id: UUID) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            if !reply.tools.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(reply.tools) { tool in
                            HStack(spacing: 6) {
                                if tool.state == "started" {
                                    ProgressView().controlSize(.small)
                                } else if tool.state == "finished" {
                                    Image(systemName: "checkmark.circle").foregroundStyle(LeafTheme.gain)
                                } else if tool.state == "failed" {
                                    Image(systemName: "exclamationmark.triangle").foregroundStyle(LeafTheme.warn)
                                }
                                Text(tool.label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                            }
                            .padding(.horizontal, 10).padding(.vertical, 8)
                            .background(LeafTheme.cardRaised, in: Capsule())
                            .accessibilityElement(children: .combine)
                            .accessibilityValue(tool.state)
                            .accessibilityIdentifier("assistant.tool")
                        }
                    }
                }
            }
            if !reply.text.isEmpty {
                Text((try? AttributedString(markdown: reply.text,
                    options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(reply.text))
                    .font(LeafType.body)
                    .textSelection(.enabled)
                    .accessibilityIdentifier("assistant.reply.text")
            } else if !reply.finished && reply.failed == nil {
                TimelineView(.periodic(from: .now, by: 1)) { context in
                    HStack(alignment: .top, spacing: 8) {
                        ProgressView().controlSize(.small)
                        Text(conversation.items.last?.id == id && conversation.waitingTooLong(now: context.date)
                            ? "Waiting for the assistant to start. It runs on the Leaf desktop." : "Thinking…")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityIdentifier("assistant.thinking")
                }
            }
            ForEach(reply.cards.filter { $0.kind != .control }) { card in
                VStack(alignment: .leading, spacing: 12) {
                    if let identity = card.identity { AssistantEngineIdentityView(identity: identity) }
                    Text(card.title).font(LeafType.heading)
                    AssistantCardFieldsView(fields: card.fields)
                    if let engineId = card.engineId {
                        Text(engineId).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                    if card.kind == .configDraft {
                        Text("Applies after your runner confirms it.")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                    switch card.state {
                    case .open:
                        Button { Task { await conversation.approve(card: card) } } label: {
                            Text(card.stateLabel).frame(minWidth: 44, minHeight: 44)
                        }
                        .disabled(conversation.approvingCards.contains(card.id))
                        .accessibilityIdentifier(card.kind.actionAccessibilityIdentifier)
                    case .approved: Text(card.stateLabel).foregroundStyle(LeafTheme.gain)
                    case .expired: Text(card.stateLabel).foregroundStyle(LeafTheme.inkMuted)
                    case .failed: Text(card.stateLabel).foregroundStyle(LeafTheme.loss)
                    }
                }
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(LeafTheme.line))
                .accessibilityElement(children: .contain)
            }
            ForEach(reply.views) { card in
                VStack(alignment: .leading, spacing: 14) {
                    Text(card.title).font(LeafType.heading)
                    ForEach(card.panels.indices, id: \.self) { index in
                        AssistantPanelView(panel: card.panels[index])
                    }
                }
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(LeafTheme.line))
            }
            if let error = reply.failed {
                Text(error).font(LeafType.body).foregroundStyle(LeafTheme.loss)
                    .accessibilityIdentifier("assistant.reply.error")
                    .accessibilityAddTraits(.updatesFrequently)
            }
        }
    }

    private var composer: some View {
        @Bindable var conversation = conversation
        return VStack(alignment: .leading, spacing: 8) {
            if let notice = inbox.reviewNotice {
                Text(notice)
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("assistant.review.busy")
            }
            if conversation.restoredDraft {
                HStack(spacing: 12) {
                    Text("Draft kept").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    Button("Clear") { conversation.clearDraft() }
                        .frame(minWidth: 44, minHeight: 44)
                        .accessibilityIdentifier("assistant.draft.clear")
                }
            }
            if conversation.offeredPrefill != nil {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Suggested text is ready. Your draft is kept.")
                        .font(LeafType.meta)
                    HStack(spacing: 12) {
                        Button("Replace") { conversation.acceptPrefill() }
                            .frame(minWidth: 44, minHeight: 44)
                            .accessibilityIdentifier("assistant.prefill.use")
                        Button("Keep") { conversation.dismissPrefill() }
                            .frame(minWidth: 44, minHeight: 44)
                            .accessibilityIdentifier("assistant.prefill.dismiss")
                    }
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(LeafTheme.line))
                .disabled(busy)
                .accessibilityElement(children: .contain)
                .accessibilityIdentifier("assistant.prefill.banner")
            }
            if studio.supports("assistant.engine") {
                Button {
                    conversation.setEngineBuilding(!conversation.engineBuilding)
                } label: {
                    Label("Engine building", systemImage: "cpu")
                        .font(LeafType.meta)
                        .padding(.horizontal, 14)
                        .frame(minHeight: 44)
                        .foregroundStyle(conversation.engineBuilding ? LeafTheme.primaryForeground : LeafTheme.ink)
                        .background(conversation.engineBuilding ? LeafTheme.primary : LeafTheme.card, in: Capsule())
                        .overlay(Capsule().stroke(LeafTheme.line))
                }
                .buttonStyle(.plain)
                .disabled(busy)
                .accessibilityIdentifier("assistant.engineToggle")
                .accessibilityValue(conversation.engineBuilding ? "On" : "Off")
            }
            HStack(alignment: .bottom, spacing: 8) {
                TextField(conversation.engineBuilding ? "Describe an engine to build" : "Ask about your account",
                          text: $conversation.draft, axis: .vertical)
                    .lineLimit(1...4)
                    .font(LeafType.body)
                    .padding(12)
                    .background(LeafTheme.cardRaised, in: RoundedRectangle(cornerRadius: 14))
                    .focused($composing)
                    .accessibilityIdentifier("assistant.prompt")
                Button { send(conversation.draft) } label: {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 32))
                        .frame(width: 44, height: 44)
                }
                .disabled(busy || conversation.draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                .accessibilityLabel("Send")
                .accessibilityIdentifier("assistant.send")
            }
            if conversation.engineBuilding {
                Text("Builds paper engines only. Nothing trades.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("assistant.engineNote")
            }
            if studio.catalog?.assistantReadiness?.ready == false {
                Text("The assistant is offline. It runs on the Leaf desktop.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("assistant.offline")
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 10)
        .background(LeafTheme.ground)
        .overlay(alignment: .top) { Rectangle().fill(LeafTheme.line).frame(height: 1) }
    }

    private func send(_ text: String) {
        composing = false
        inbox.dismissReviewNotice()
        Task { await conversation.send(text, studio: studio) }
    }

    private func review(_ nomination: AssistantNomination) {
        guard inbox.approvingCardId == nil, inbox.canReview(nomination) else { return }
        tab = .chat
        composing = false
        inbox.dismissReviewNotice()
        Task {
            await inbox.review(nomination, conversation: conversation, studio: studio)
        }
    }

    private func discuss(_ card: AssistantCard) {
        guard inbox.approvingCardId == nil, AssistantCard.validId(card.id) else { return }
        inbox.discuss(card, conversation: conversation, currentSessionId: studio.selections.sessionId)
        inbox.dismissReviewNotice()
        tab = .chat
    }

    private func discuss(_ nomination: AssistantNomination) {
        guard inbox.approvingCardId == nil, AssistantNomination.validId(nomination.id) else { return }
        inbox.discuss(nomination, conversation: conversation)
        inbox.dismissReviewNotice()
        tab = .chat
    }
}

struct AssistantCardFieldsView: View {
    let fields: [AssistantCard.Field]

    var body: some View {
        ForEach(fields.indices, id: \.self) { index in
            VStack(alignment: .leading, spacing: 4) {
                Text(fields[index].label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                Text(fields[index].value).font(LeafType.body)
            }
            .fixedSize(horizontal: false, vertical: true)
            .accessibilityElement(children: .combine)
        }
    }
}

private struct AssistantPanelView: View {
    let panel: AssistantPanel

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if !panel.title.isEmpty { Text(panel.title).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted) }
            switch panel.kind {
            case "metric": metrics
            case "table": table
            case "line": line
            default: Text("This view is not supported yet.").font(LeafType.meta)
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("assistant.panel." + panel.kind)
    }

    private var metrics: some View {
        Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 12) {
            ForEach(Array(stride(from: 0, to: panel.columns.count, by: 2)), id: \.self) { offset in
                GridRow(alignment: .top) {
                    ForEach(offset..<min(offset + 2, panel.columns.count), id: \.self) { index in
                        let column = panel.columns[index]
                        VStack(alignment: .leading, spacing: 4) {
                            Text(column.label).font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
                            Text(AssistantFormat.display(panel.rows.first?[column.key], format: column.format, now: Date()))
                                .font(.title3.bold()).monospacedDigit()
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
        }
    }

    private var table: some View {
        ScrollView(.horizontal) {
            Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 10) {
                GridRow {
                    ForEach(panel.columns.indices, id: \.self) { index in
                        Text(panel.columns[index].label).font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
                    }
                }
                ForEach(0..<min(50, panel.rows.count), id: \.self) { rowIndex in
                    GridRow {
                        ForEach(panel.columns.indices, id: \.self) { columnIndex in
                            let column = panel.columns[columnIndex]
                            Text(AssistantFormat.display(panel.rows[rowIndex][column.key], format: column.format, now: Date()))
                                .font(LeafType.meta).monospacedDigit()
                        }
                    }
                }
                if panel.rows.count > 50 {
                    Text("and \(panel.rows.count - 50) more").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                }
            }
        }
    }

    private struct Point: Identifiable {
        let id: String
        let date: Date?
        let category: String
        let series: String
        let value: Double
    }

    private var points: [Point] {
        guard let x = panel.columns.first else { return [] }
        return panel.rows.enumerated().flatMap { rowIndex, row in
            panel.columns.dropFirst().enumerated().compactMap { columnIndex, column -> Point? in
                guard let number = row[column.key]?.number else { return nil }
                let date = AssistantFormat.date(row[x.key], format: x.format)
                if ["time", "date"].contains(x.format), date == nil { return nil }
                return Point(id: "\(rowIndex):\(columnIndex)", date: date,
                    category: AssistantFormat.display(row[x.key], format: x.format, now: Date()),
                    series: column.label, value: ["usd", "usd_signed"].contains(column.format) ? number / 100 : number)
            }
        }
    }

    private var moneyAxis: Bool {
        let numeric = panel.columns.dropFirst().filter { column in panel.rows.contains { $0[column.key]?.number != nil } }
        return !numeric.isEmpty && numeric.allSatisfy { ["usd", "usd_signed"].contains($0.format) }
    }

    private var line: some View {
        Chart(points) { point in
            if let date = point.date {
                LineMark(x: .value("Date", date), y: .value("Value", point.value))
                    .foregroundStyle(by: .value("Series", point.series))
            } else {
                LineMark(x: .value("Category", point.category), y: .value("Value", point.value))
                    .foregroundStyle(by: .value("Series", point.series))
            }
        }
        .chartYAxis {
            AxisMarks { value in
                AxisGridLine()
                AxisTick()
                AxisValueLabel {
                    if let number = value.as(Double.self) {
                        Text(moneyAxis
                            ? number.formatted(.currency(code: "USD").precision(.fractionLength(0...2)).locale(Locale(identifier: "en_US")))
                            : number.formatted(.number.precision(.fractionLength(0...1))))
                    }
                }
            }
        }
        .frame(height: 200)
    }
}
