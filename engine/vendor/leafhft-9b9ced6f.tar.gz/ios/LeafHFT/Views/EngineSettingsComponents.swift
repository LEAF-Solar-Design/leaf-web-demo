import SwiftUI
import LeafHFTCore

struct SourceBadge: View {
    let source: PolicyValueSource
    private var symbol: String {
        switch source {
        case .inherited: return "arrow.down.to.line"
        case .global: return "globe"
        case .overridden: return "person.crop.circle"
        case .drafted: return "pencil"
        }
    }
    private var tone: LeafTone {
        switch source {
        case .drafted: return .warn
        case .inherited: return .stale
        case .global, .overridden: return .neutral
        }
    }
    var body: some View {
        StateInk(source.label, tone: tone, symbol: symbol)
            .accessibilityLabel(source.label)
    }
}

@MainActor struct ParameterRow: View {
    let parameter: PolicyParameter
    let draft: EngineConfigurationDraft
    @Binding var fieldText: String
    let validation: String?
    let helpExpanded: Bool
    let disabled: Bool
    let conflicts: [PolicyConflict]
    let setValue: (Double) -> Void
    let commitField: () -> Void
    let useGlobal: () -> Void
    let undo: () -> Void
    let toggleHelp: () -> Void
    @Environment(\.dynamicTypeSize) private var typeSize
    @FocusState private var fieldFocused: Bool

    private var maximum: Double { PolicyBounds.maximum(for: parameter, envelope: draft.baseline.riskEnvelope) }
    private var value: Double? { draft.effectiveValue(for: parameter.key) }
    private var valueText: String {
        value.map { PolicyValueFormatter.display($0, parameter: parameter) } ?? "Unknown"
    }
    private var baselineText: String {
        draft.baseline.effectivePolicy[parameter.key].map {
            PolicyValueFormatter.display($0, parameter: parameter)
        } ?? "Unknown"
    }
    private var changed: Bool { draft.isChanged(parameter.key) }
    private var savedAbove: (saved: Double, maximum: Double)? { draft.savedAboveMaximum(for: parameter.key) }
    private var source: PolicyValueSource { draft.source(for: parameter.key) }
    private var guidanceText: String? {
        guard let value else { return nil }
        return PolicyGuidance.label(for: parameter, value: value)?.rawValue
    }
    private var canUseGlobal: Bool {
        !draft.isGlobal && (draft.baseline.overridePolicy[parameter.key] != nil || changed)
    }
    private var controlValue: Double {
        let value = draft.currentValue(for: parameter.key) ?? parameter.minimum
        return value.isFinite ? min(maximum, max(parameter.minimum, value)) : parameter.minimum
    }
    private var apiBinding: Binding<Double> {
        Binding(get: { controlValue }, set: { setValue(min(maximum, PolicyValueFormatter.normalized($0, parameter: parameter))) })
    }
    private var displayBinding: Binding<Double> {
        Binding(get: { PolicyValueFormatter.displayValue(fromAPI: controlValue, unit: parameter.unit) },
                set: { value in
            setValue(min(maximum, PolicyValueFormatter.normalized(
                PolicyValueFormatter.apiValue(fromDisplay: value, unit: parameter.unit), parameter: parameter)))
        })
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if typeSize.isAccessibilitySize {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(alignment: .firstTextBaseline) { name; helpButton; Spacer() }
                    valueLine
                }
            } else {
                HStack(alignment: .firstTextBaseline) { name; helpButton; Spacer(); valueLine }
            }
            if source != .global || guidanceText != nil || changed || canUseGlobal {
                ViewThatFits(in: .horizontal) {
                    HStack { badges; rowActions }
                    VStack(alignment: .leading, spacing: 6) {
                        if source != .global || guidanceText != nil {
                            HStack { badges }
                        }
                        if changed || canUseGlobal {
                            HStack { rowActions }
                        }
                    }
                }
            }
            control.disabled(disabled)
            if RiskEnvelope.hardMaxima[parameter.key] != nil {
                Caption("Runner hard maximum: \(PolicyValueFormatter.display(maximum, unit: parameter.unit)).",
                        tone: .warn, expandable: true,
                        identifier: "engine.settings.hardMaximum.\(parameter.key)")
                    .accessibilityElement(children: .contain)
                    .accessibilityLabel("Runner hard maximum: \(PolicyValueFormatter.display(maximum, unit: parameter.unit)).")
                    .accessibilityIdentifier("engine.settings.hardMaximum.\(parameter.key)")
            }
            if let savedAbove {
                let text = draft.savedAboveMaximumExplanation(for: parameter.key) ?? ""
                Caption(text, tone: .loss, expandable: true,
                        identifier: "engine.settings.savedAboveMaximum.\(parameter.key)")
                    .accessibilityElement(children: .contain)
                    .accessibilityLabel(text)
                    .accessibilityIdentifier("engine.settings.savedAboveMaximum.\(parameter.key)")
                // Edits the draft only; Review and Send stay the explicit steps.
                Button("Set to \(PolicyValueFormatter.display(savedAbove.maximum, unit: parameter.unit))") {
                    setValue(savedAbove.maximum)
                }
                    .buttonStyle(.bordered).controlSize(.small).buttonBorderShape(.capsule)
                    .accessibilityIdentifier("engine.settings.setToMaximum.\(parameter.key)")
                    .disabled(disabled)
            }
            if parameter.key == "size_fraction" {
                Caption(parameter.summary, expandable: true)
            }
            if let validation {
                Caption(validation, tone: .loss, expandable: true,
                        identifier: "engine.settings.validation.\(parameter.key)")
                    .accessibilityElement(children: .contain)
                    .accessibilityLabel(validation)
                    .accessibilityIdentifier("engine.settings.validation.\(parameter.key)")
            }
            if helpExpanded {
                ParameterHelp(parameter: parameter, isGlobal: draft.isGlobal,
                              globalValue: draft.baseline.globalPolicy[parameter.key], maximum: maximum)
                    .accessibilityIdentifier("engine.settings.helpText.\(parameter.key)")
            }
            ForEach(conflicts) { conflict in
                Caption(conflict.message, tone: conflict.severity == .error ? .loss : .warn,
                        expandable: true, identifier: "engine.settings.conflict.\(conflict.id)")
                    .accessibilityElement(children: .contain)
                    .accessibilityLabel(conflict.message)
                    .accessibilityIdentifier("engine.settings.conflict.\(conflict.id)")
            }
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .contain)
        .accessibilityHint("Source: \(source.label)")
        .accessibilityIdentifier("engine.settings.row.\(parameter.key)")
    }

    private var name: some View { OneLine(parameter.name).font(LeafType.heading) }
    private var valueLine: some View {
        HStack(alignment: .firstTextBaseline, spacing: 6) {
            if changed {
                Text(baselineText).strikethrough().leafNumeral(.number).foregroundStyle(LeafTheme.inkMuted)
                Text("→").accessibilityHidden(true)
            }
            Text(valueText).leafNumeral(.number)
                .accessibilityIdentifier("engine.settings.value.\(parameter.key)")
                .accessibilityValue(valueText)
        }.fixedSize(horizontal: false, vertical: true)
    }
    @ViewBuilder private var badges: some View {
        if source != .global {
            SourceBadge(source: source)
                .accessibilityIdentifier("engine.settings.source.\(parameter.key)")
        }
        if let guidanceText {
            StateInk(guidanceText, tone: .warn, symbol: "exclamationmark.circle")
                .accessibilityLabel(guidanceText)
                .accessibilityIdentifier("engine.settings.guidance.\(parameter.key)")
        }
    }
    @ViewBuilder private var rowActions: some View {
        if changed {
            Button("Undo", action: undo)
                .buttonStyle(.bordered).controlSize(.small).buttonBorderShape(.capsule)
                .accessibilityIdentifier("engine.settings.undo.\(parameter.key)")
                .disabled(disabled)
        }
        if canUseGlobal {
            Button("Use global value", action: useGlobal)
                .buttonStyle(.bordered).controlSize(.small).buttonBorderShape(.capsule)
                .accessibilityIdentifier("engine.settings.useGlobal.\(parameter.key)")
                .disabled(disabled)
        }
    }
    private var helpButton: some View {
        Button(action: toggleHelp) {
            Image(systemName: "info.circle").frame(minWidth: 44, minHeight: 44)
        }
        .buttonStyle(.borderless)
        .accessibilityLabel("About \(parameter.name)")
        .accessibilityHint("Shows what this setting controls and what changes when you raise or lower it.")
        .accessibilityIdentifier("engine.settings.help.\(parameter.key)")
    }
    @ViewBuilder private var control: some View {
        switch parameter.control {
        case .toggle:
            Toggle(parameter.name, isOn: Binding(get: { controlValue == maximum },
                set: { setValue($0 ? maximum : parameter.minimum) }))
                .tint(LeafTheme.gain)
                .accessibilityIdentifier("engine.settings.control.\(parameter.key)")
        case .stepper:
            HStack {
                Text(parameter.unit.label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                Spacer()
                Stepper("", value: apiBinding, in: parameter.minimum...maximum, step: parameter.step)
                    .labelsHidden()
                    .accessibilityLabel(parameter.name)
                    .accessibilityValue(valueText)
                    .accessibilityIdentifier("engine.settings.control.\(parameter.key)")
            }
        case .slider:
            if maximum == parameter.minimum {
                Button("Set to \(PolicyValueFormatter.display(maximum, unit: parameter.unit))") { setValue(maximum) }
                    .accessibilityIdentifier("engine.settings.control.\(parameter.key)")
            } else {
            Slider(value: displayBinding,
                   in: PolicyValueFormatter.displayValue(fromAPI: parameter.minimum, unit: parameter.unit)...PolicyValueFormatter.displayValue(fromAPI: maximum, unit: parameter.unit),
                   step: PolicyValueFormatter.displayValue(fromAPI: min(parameter.step, maximum - parameter.minimum), unit: parameter.unit)) {
                Text(parameter.name)
            } minimumValueLabel: {
                Text(PolicyValueFormatter.display(parameter.minimum, unit: parameter.unit)).leafNumeral(.number).foregroundStyle(LeafTheme.inkMuted)
            } maximumValueLabel: {
                Text(PolicyValueFormatter.display(maximum, unit: parameter.unit)).leafNumeral(.number).foregroundStyle(LeafTheme.inkMuted)
            }
            .accessibilityLabel(parameter.name)
            .accessibilityValue(valueText)
            .accessibilityIdentifier("engine.settings.control.\(parameter.key)")
            }
        case .field:
            HStack {
                TextField(parameter.unit == .milliseconds ? "ms" : parameter.unit.label, text: $fieldText)
                    .leafNumeral(.number)
                    .keyboardType(.decimalPad).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .foregroundStyle(LeafTheme.ink).focused($fieldFocused).submitLabel(.done)
                    .accessibilityLabel(parameter.name)
                    .accessibilityIdentifier("engine.settings.control.\(parameter.key)")
                    .onSubmit { commitField(); fieldFocused = false }
                    .onChange(of: fieldFocused) { _, focused in if !focused { commitField() } }
                Text(parameter.unit.label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            .padding(.vertical, 8).padding(.horizontal, 12)
            .background(LeafTheme.cardRaised, in: RoundedRectangle(cornerRadius: LeafTheme.radiusSmall))
        }
    }
}

struct ParameterHelp: View {
    let parameter: PolicyParameter
    let isGlobal: Bool
    let globalValue: Double?
    var maximum: Double? = nil
    private var fields: [(String, String)] {
        var fields = [
            ("What it controls", parameter.summary),
            ("When you raise it", parameter.whenHigher),
            ("When you lower it", parameter.whenLower),
            ("Unit", parameter.unit.label),
            ("Allowed range", "\(PolicyValueFormatter.display(parameter.minimum, unit: parameter.unit)) to \(PolicyValueFormatter.display(maximum ?? parameter.maximum, unit: parameter.unit))" + (parameter.isInteger ? ". Whole numbers only." : "")),
            ("Affects", parameter.impact.labels.joined(separator: ", "))
        ]
        if let zero = parameter.zeroMeaning { fields.append(("Zero", zero)) }
        if !isGlobal {
            fields.append(("Global value", globalValue.map {
                PolicyValueFormatter.display($0, parameter: parameter)
            } ?? "Unknown"))
        }
        return fields
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(Array(fields.enumerated()), id: \.offset) { _, field in
                VStack(alignment: .leading, spacing: 2) {
                    OneLine(field.0).font(LeafType.meta.weight(.semibold))
                    Caption(field.1, expandable: true)
                }
            }
        }
        .padding(10).background(LeafTheme.cardRaised, in: RoundedRectangle(cornerRadius: LeafTheme.radiusSmall))
        .accessibilityElement(children: .contain)
        .accessibilityLabel(fields.map { "\($0.0): \($0.1)" }.joined(separator: " "))
    }
}

@MainActor struct EngineChangeReviewView: View {
    let engineName: String
    let scopeText: String
    let draft: EngineConfigurationDraft
    let accountLabel: String?
    let sending: Bool
    let error: String?
    let send: @MainActor () async -> String?
    @Environment(\.dismiss) private var dismiss
    @State private var submitting = false
    @State private var sendError: String?
    /// Display only: saved values above the maximum are listed once by name above these.
    private var editedBlockingProblems: [String] {
        let saved = draft.savedAboveMaximumMessages
        return draft.blockingProblems.filter { !saved.contains($0) }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 4) {
                        OneLine(engineName).font(LeafType.heading)
                        Text("\(draft.changeCount) \(draft.changeCount == 1 ? "change" : "changes") · \(scopeText)")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                    Caption("Sent as one request to the runner.", expandable: true)
                }
                .listRowBackground(LeafTheme.card)
                .listRowSeparatorTint(LeafTheme.line)
                Section("Changes") {
                    ForEach(draft.changes(accountLabel: accountLabel)) { change in
                        VStack(alignment: .leading, spacing: 8) {
                            OneLine(change.name).font(LeafType.heading)
                            ViewThatFits(in: .horizontal) {
                                HStack {
                                    Text(change.oldText).leafNumeral(.number).foregroundStyle(LeafTheme.inkMuted).strikethrough()
                                        .accessibilityLabel("Before \(change.oldText)")
                                    Image(systemName: "arrow.right").accessibilityHidden(true)
                                    Text(change.newText).leafNumeral(.number).bold().accessibilityLabel("After \(change.newText)")
                                }
                                VStack(alignment: .leading) {
                                    Text(change.oldText).leafNumeral(.number).foregroundStyle(LeafTheme.inkMuted).strikethrough()
                                        .accessibilityLabel("Before \(change.oldText)")
                                    HStack {
                                        Image(systemName: "arrow.right").accessibilityHidden(true)
                                        Text(change.newText).leafNumeral(.number).bold().accessibilityLabel("After \(change.newText)")
                                    }
                                }
                            }
                            Caption(change.scopeText, expandable: true)
                            Caption(change.effect, expandable: true)
                        }
                        .accessibilityElement(children: .contain)
                        .accessibilityIdentifier("engine.settings.reviewRow.\(change.id)")
                    }
                }
                .listRowBackground(LeafTheme.card)
                .listRowSeparatorTint(LeafTheme.line)
                if !draft.blockingProblems.isEmpty {
                    Section("Invalid settings") {
                        if !draft.savedAboveMaximumNames.isEmpty {
                            Caption("Saved values above the runner's maximum: \(draft.savedAboveMaximumNames.joined(separator: ", ")).",
                                    tone: .loss, expandable: true)
                        }
                        ForEach(Array(editedBlockingProblems.enumerated()), id: \.offset) { _, problem in
                            Caption(problem, tone: .loss, expandable: true)
                        }
                    }
                    .listRowBackground(LeafTheme.card)
                    .listRowSeparatorTint(LeafTheme.line)
                }
                if !draft.conflicts.filter({ $0.severity == .warning }).isEmpty {
                    Section("Warnings") {
                        ForEach(draft.conflicts.filter { $0.severity == .warning }) { conflict in
                            Caption(conflict.message, tone: .warn, expandable: true)
                        }
                    }
                    .listRowBackground(LeafTheme.card)
                    .listRowSeparatorTint(LeafTheme.line)
                }
                Section {
                    if let message = sendError ?? error {
                        Caption(String(message.prefix(512)), tone: .loss, expandable: true,
                                identifier: "engine.settings.reviewError")
                            .accessibilityIdentifier("engine.settings.reviewError")
                    }
                    Caption("The runner must acknowledge the request before it takes effect. Nothing changes until it reports applied.", expandable: true)
                }
                .listRowBackground(LeafTheme.card)
                .listRowSeparatorTint(LeafTheme.line)
            }
            .navigationTitle("Review changes")
            .font(LeafType.body)
            .foregroundStyle(LeafTheme.ink)
            .listSectionSpacing(16)
            .leafScreenBackground()
            .accessibilityIdentifier("engine.settings.review")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }.disabled(sending || submitting)
                        .accessibilityIdentifier("engine.settings.reviewCancel")
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Send request") {
                        guard !sending && !submitting && draft.blockingProblems.isEmpty else { return }
                        submitting = true
                        Task {
                            sendError = await send()
                            submitting = false
                            if sendError == nil { dismiss() }
                        }
                    }
                    .disabled(sending || submitting || !draft.blockingProblems.isEmpty)
                    .accessibilityIdentifier("engine.settings.send")
                }
            }
            .interactiveDismissDisabled(sending || submitting)
        }
    }
}
