import SwiftUI
import LeafHFTCore

/// One engine (D8): lifecycle and its timeline, the shared daily P&L chart, inputs, markets, effective policy,
/// the last attributed fills, this engine's requests, and the Halt and owner Probe confirm sheets.
/// Reads live AppState, so a request moves requested -> applied|rejected in place. Runner text is shown as
/// sent; null renders "Not reported", never zero.
@MainActor struct EngineDetailView<ToggleCard: View>: View {
    @Environment<AppState>(AppState.self) private var state
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    let engineId: String
    let scopedAccountId: String?
    private let toggleCard: ToggleCard
    @State private var history: EngineHistoryResponse?
    @State private var historyError: String?
    @State private var sheet: EngineDetailSheet?

    init(engineId: String, scopedAccountId: String?, @ViewBuilder toggleCard: () -> ToggleCard) {
        self.engineId = engineId
        self.scopedAccountId = scopedAccountId
        self.toggleCard = toggleCard()
    }

    private var engine: Engine? { state.engines?.engines?.first { $0.engineId == engineId } }
    private var accounts: [EngineControlAccount] { state.engines?.accounts ?? [] }
    private var isOwner: Bool { state.kashbotStatus?.riskRegime?.id == "owner" }
    private var controlsBlocked: Bool {
        state.submittingControl || state.controlOutcomeUnknown ||
            (state.fixtureMode.enabled && !state.fixtureMode.controlWalk)
    }

    var body: some View {
        List {
            if let engine {
                card { summary(engine) }
                card { toggleCard }
                links(engine)
                card { actions(engine) }
                card { requestsCard }
                card { timeline(engine) }
                card { chartCard(engine) }
                card { inputs(engine) }
                card {
                    VStack(alignment: .leading, spacing: 12) {
                        SectionHeader("Effective policy")
                        policyGrid(engine)
                    }
                }
                card { fills }
                card { details(engine) }
            } else {
                Text("Engine no longer published. Current status unknown.")
                    .foregroundStyle(LeafTheme.inkMuted)
                    .listRowBackground(Color.clear)
            }
        }
        .listStyle(.plain)
        .leafScreenBackground()
        .font(LeafType.body)
        .foregroundStyle(LeafTheme.ink)
        .navigationTitle(engine?.name ?? engineId)
        .navigationBarTitleDisplayMode(.inline)
        .accessibilityIdentifier("engine.detail.list")
        .task(id: engineId) { await loadHistory() }
        .sheet(item: $sheet) { item in
            if let engine {
                switch item {
                case .halt: EngineHaltSheet(engineId: engine.engineId, engineName: engine.name ?? engine.engineId)
                case .probe: EngineProbeSheet(engine: engine, accountLabel: probeAccountLabel(engine),
                                              accountBreaker: state.probeBoard?.account)
                }
            }
        }
    }

    private func card<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        LeafCard { content().frame(maxWidth: .infinity, alignment: .leading) }
            .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
            .listRowSeparator(.hidden)
            .listRowBackground(Color.clear)
    }

    // MARK: Summary

    private func summary(_ engine: Engine) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("\(engine.engineId) · Version \(engine.version.map(String.init) ?? "Not reported")")
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            ViewThatFits(in: .horizontal) {
                HStack(spacing: 6) { chips(engine) }
                VStack(alignment: .leading, spacing: 6) { chips(engine) }
            }
            Text(EngineRuntimeText.breaker(engine))
                .font(LeafType.meta).fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("engine.detail.breaker")
            Text(EngineDetailReconcile.liveLine(engine.live))
                .font(LeafType.meta).fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("engine.detail.perContract")
            if let day = EngineDetailReconcile.probeDayLine(engine.probeToday) {
                Text(day).font(LeafType.meta).fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("engine.detail.probeDay")
            }
            Text(EngineDetailReconcile.statusAsOf(state.engines?.generatedAt))
                .font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("engine.detail.statusSource")
            Eyebrow("Bound books")
            Text(engine.boundBooks?.joined(separator: ", ") ?? ProbePresentation.notReported)
                .font(LeafType.body)
                .accessibilityIdentifier("engine.boundBooks.\(engine.engineId)")
            Eyebrow("Markets")
            Text(engine.markets.map { $0.isEmpty ? "None" : $0.joined(separator: ", ") } ?? ProbePresentation.notReported)
                .font(LeafType.body)
                .accessibilityIdentifier("engine.detail.markets")
        }
    }

    @ViewBuilder private func chips(_ engine: Engine) -> some View {
        EngineLifecycleChip(lifecycle: engine.lifecycle, eligibility: engine.eligibleToProbe)
            .accessibilityIdentifier("engine.detail.lifecycle")
        EngineAccountChip(engine: engine, accounts: accounts,
                          boundAccountIds: EngineAccountChip.boundAccountIds(engine: engine, board: state.probeBoard))
            .accessibilityIdentifier("engine.detail.account")
    }

    private func links(_ engine: Engine) -> some View {
        Group {
            NavigationLink {
                EngineSettingsView(engineId: engine.engineId, initialAccountId: scopedAccountId)
            } label: {
                Label("Configure engine", systemImage: "slider.horizontal.3").frame(maxWidth: .infinity)
            }
            .buttonStyle(.leafPrimary)
            .accessibilityIdentifier("engine.configure.\(engine.engineId)")

            NavigationLink {
                EngineHistoryView(engineId: engine.engineId)
            } label: {
                Label("Performance and settings", systemImage: "chart.xyaxis.line").frame(maxWidth: .infinity)
            }
            .buttonStyle(.leafSecondary)
            .accessibilityIdentifier("engine.performance.\(engine.engineId)")
        }
        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
        .listRowSeparator(.hidden)
        .listRowBackground(Color.clear)
    }

    // MARK: Actions

    private func canHalt(_ engine: Engine) -> Bool {
        switch engine.lifecycle?.state {
        case .probe?, .probeSized?, .graduated?, .canary?: return true
        default: return false
        }
    }

    /// Why Probe is hidden: the runner's eligibility reasons first, as sent. Empty means Probe is offered.
    private func probeBlockers(_ engine: Engine) -> [String] {
        var reasons: [String] = []
        if let eligibility = engine.eligibleToProbe {
            if !eligibility.eligible {
                reasons += eligibility.reasons.isEmpty ? ["Not eligible (reason not reported)"] : eligibility.reasons
            }
        } else {
            reasons.append("Probe eligibility: \(ProbePresentation.notReported)")
        }
        if !isOwner { reasons.append("Only the owner can start a probe.") }
        return reasons
    }

    private func actions(_ engine: Engine) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader("Actions")
            if canHalt(engine) {
                Button { sheet = .halt } label: {
                    Label("Halt", systemImage: "hand.raised.fill").frame(maxWidth: .infinity)
                }
                .buttonStyle(.leafSecondary)
                .disabled(controlsBlocked)
                .accessibilityIdentifier("engine.detail.halt")
                Text("Stops new entries. Open contracts settle normally.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            } else {
                Text("Halt applies to probing or live engines.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            let blockers = probeBlockers(engine)
            if isOwner && !state.fixtureMode.controlWalk {
                Text("Approve on the dashboard. The dashboard signs the single-use approval and starts the probe.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("engine.detail.probe.dashboard")
            }
            if blockers.isEmpty {
                Button { sheet = .probe } label: {
                    Label("Probe", systemImage: "scope").frame(maxWidth: .infinity)
                }
                .buttonStyle(.leafPrimary)
                .disabled(controlsBlocked)
                .accessibilityIdentifier("engine.detail.probe")
            } else {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Probe unavailable").font(LeafType.heading)
                    ForEach(Array(blockers.enumerated()), id: \.offset) { _, reason in
                        Text(reason).font(LeafType.meta).fixedSize(horizontal: false, vertical: true)
                    }
                }
                .foregroundStyle(LeafTheme.inkMuted)
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Probe unavailable: " + blockers.joined(separator: "; "))
                .accessibilityIdentifier("engine.detail.probeUnavailable")
            }
            if state.fixtureMode.enabled && !state.fixtureMode.controlWalk {
                Text("Controls are disabled in fixture mode.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            if state.controlOutcomeUnknown {
                Text("A submitted control has an unknown outcome. Refresh requests before trying again.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.warn)
            }
        }
    }

    private func probeAccountLabel(_ engine: Engine) -> String {
        guard let id = engine.assignment?.accountId, !id.isEmpty else { return "Probe account (assigned by the server)" }
        return accounts.first { $0.id == id }?.label ?? id
    }

    // MARK: Requests

    /// This engine's requests, newest first. O(requests).
    private var engineRequests: [ControlRequest] {
        state.pendingRequests.filter { request in
            switch request.value {
            case let .configure(value)?: return value.engineId == engineId
            case let .probe(value)?: return value.engineId == engineId
            case let .halt(value)?: return value.engineId == engineId
            case let .assign(value)?: return value.engineId == engineId
            case let .graduate(value)?: return value.engineId == engineId
            case let .breaker(value)?: return value.scope == .engine && value.id == engineId
            default: return false
            }
        }.reversed()
    }

    private var requestsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader("Requests")
            Button {
                Task { await state.refreshDashboard() }
            } label: {
                Label("Refresh requests", systemImage: "arrow.clockwise").frame(maxWidth: .infinity)
            }
            .buttonStyle(.leafSecondary)
            .accessibilityIdentifier("engine.detail.refresh")
            if engineRequests.isEmpty {
                Text("No requests for this engine.").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            ForEach(engineRequests) { request in requestRow(request) }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("engine.detail.requests")
    }

    /// requested, then applied or rejected; a rejection shows the runner's reason text, never one composed here.
    static func requestChain(_ request: ControlRequest) -> (text: String, tone: LeafTone) {
        switch request.state?.lowercased() {
        case "requested"?, "pending"?: return ("Requested", .warn)
        case "applied"?: return ("Requested → Applied", .gain)
        case "rejected"?:
            let reason = request.note.flatMap { $0.isEmpty ? nil : $0 } ?? "Reason not reported"
            return ("Requested → Rejected: \(reason)", .loss)
        case let other?: return ("Requested → \(other)", .stale)
        case nil: return ("State not reported", .stale)
        }
    }

    private func requestRow(_ request: ControlRequest) -> some View {
        let chain = Self.requestChain(request)
        let kind = request.kind ?? "Unknown kind"
        return VStack(alignment: .leading, spacing: 4) {
            Text(kind).font(LeafType.heading)
            Text(request.value?.displayValue ?? "Unknown change").font(LeafType.body)
            Text(chain.text).font(LeafType.meta).foregroundStyle(chain.tone.color)
                .fixedSize(horizontal: false, vertical: true)
            Text(request.id).font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(kind), \(chain.text)")
        .accessibilityIdentifier("engine.detail.request.\(request.id)")
    }

    // MARK: Lifecycle timeline

    private struct TimelineEntry: Identifiable {
        let id: String
        let label: String
        let when: String
        let date: Date?
    }

    private static func parse(_ text: String?) -> Date? { EngineDetailReconcile.parse(text) }

    private func timelineEntries(_ engine: Engine) -> [TimelineEntry] {
        var entries: [TimelineEntry] = []
        func add(_ id: String, _ label: String, _ raw: String?) {
            guard let raw, !raw.isEmpty else { return }
            let date = Self.parse(raw)
            entries.append(TimelineEntry(id: id, label: label, when: date.map(EngineRuntimeText.utc) ?? raw, date: date))
        }
        if let assignment = engine.assignment {
            add("assigned", "Assigned" + (assignment.role.map { " as \($0)" } ?? ""), assignment.since)
        }
        add("probeStarted", "Probe started", engine.lifecycle?.probeStartedAt)
        if let until = engine.lifecycle?.entriesSuspendedUntil {
            entries.append(TimelineEntry(id: "resume", label: "Entries resume (breaker trip)",
                when: EngineLifecycleChip.centralTime(until), date: until))
        }
        add("expires", "Probe expires", engine.lifecycle?.expiresAt)
        return entries.sorted { ($0.date ?? .distantFuture) < ($1.date ?? .distantFuture) }
    }

    private func timeline(_ engine: Engine) -> some View {
        let entries = timelineEntries(engine)
        return VStack(alignment: .leading, spacing: 10) {
            SectionHeader("Lifecycle")
            EngineLifecycleChip(lifecycle: engine.lifecycle, eligibility: engine.eligibleToProbe)
            if engine.lifecycle?.state == .halted {
                Text("Stop reasons: " + EngineLifecycleChip.stopReasons(engine.lifecycle))
                    .font(LeafType.meta).fixedSize(horizontal: false, vertical: true)
            }
            if entries.isEmpty {
                Text("No lifecycle history reported.").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            ForEach(entries) { entry in
                HStack(alignment: .firstTextBaseline, spacing: 10) {
                    Circle().fill(LeafTheme.inkMuted).frame(width: 6, height: 6).accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(entry.label).font(LeafType.body)
                        Text(entry.when).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                }
                .accessibilityElement(children: .combine)
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("engine.detail.timeline")
    }

    // MARK: History chart

    private func chartCard(_ engine: Engine) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader("Daily attributed P&L", trailing: EngineDetailReconcile.historyHeader)
            if let history {
                let performance = history.performance(engineId: engineId)
                if performance.series.isEmpty {
                    Text("No recorded results for this engine and period.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        .accessibilityIdentifier("engine.detail.chartEmpty")
                } else {
                    EnginePnlChart(series: performance.series, identifier: "engine.detail.chart")
                }
            } else if let historyError {
                Text(historyError).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                    .accessibilityIdentifier("engine.detail.chartError")
            } else {
                ProgressView("Loading history…").tint(LeafTheme.ink)
            }
            if let bridge = EngineDetailReconcile.bridge(engineId: engineId, live: engine.live,
                                                         probeDay: engine.probeToday, history: history,
                                                         historyFailed: history == nil && historyError != nil) {
                Text(bridge).font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("engine.detail.reconcile")
            }
            if let history {
                Text(EngineDetailReconcile.historySource(history))
                    .font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("engine.detail.historySource")
            }
        }
    }

    private func loadHistory() async {
        historyError = nil
        do {
            let response = try await EngineHistoryView.fetch(range: EngineDetailReconcile.historyRange, engineId: engineId,
                                                             fixture: state.fixtureMode.enabled)
            try Task.checkCancellation()
            history = response
        } catch {
            guard !Task.isCancelled else { return }
            historyError = EngineHistoryView.loadMessage(error)
        }
    }

    // MARK: Inputs, policy, fills, details

    private func inputs(_ engine: Engine) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader("Inputs")
            if let inputs = engine.inputs, !inputs.isEmpty {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), alignment: .leading)], alignment: .leading) {
                    ForEach(inputs) { input in
                        StateChip("\(input.kind.replacingOccurrences(of: "_", with: " ")) \(input.id)", tone: .neutral)
                    }
                }
            } else {
                Text(ProbePresentation.notReported).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("engine.detail.inputs")
    }

    private func accountConfiguration(_ engine: Engine) -> EngineAccountConfiguration? {
        guard let id = scopedAccountId else { return nil }
        return engine.configuration?.accounts.first { $0.accountId == id }
    }

    private func policyGrid(_ engine: Engine) -> some View {
        let policy = accountConfiguration(engine)?.effective.policy ?? engine.configuration?.global.policy ?? engine.policy ?? [:]
        let keys = ["size_fraction", "per_order_fraction", "edge_threshold_cents", "min_k",
            "min_price_cents", "max_price_cents", "exit_min_hold_s", "exit_margin_cents",
            "daily_loss_fraction", "drawdown_stop_fraction", "favorite_mult", "reentry_block_s"]
        let parameters = keys.compactMap { PolicyCatalog.parameter(for: $0) }
        return VStack(alignment: .leading, spacing: 8) {
            BoundedList(maxHeight: 176, identifier: "engine.policySummary.\(engine.engineId)") {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), alignment: .topLeading),
                    count: dynamicTypeSize.isAccessibilitySize ? 1 : 3), alignment: .leading, spacing: 8) {
                    ForEach(parameters) { parameter in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(parameter.name).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                            Text(policy[parameter.key].map { PolicyValueFormatter.display($0, parameter: parameter) } ?? "Not published")
                                .leafNumeral(.small).foregroundStyle(LeafTheme.ink)
                        }
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                        .padding(10)
                        .background(LeafTheme.cardRaised, in: RoundedRectangle(cornerRadius: LeafTheme.radiusSmall))
                        .accessibilityElement(children: .combine)
                    }
                }
            }
            .frame(height: 176)
            Text("\(parameters.count) of \(PolicyCatalog.parameters.count)")
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
        }
    }

    /// The last 50 fills the runner attributed to this engine.
    private var attributedFills: [RunnerActivityRow] {
        Array((state.runnerActivity?.fills ?? []).filter { $0.safeEngineLabel == engineId }.prefix(50))
    }

    private var fills: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader("Attributed fills", trailing: "Last \(attributedFills.count)")
            if state.runnerActivity == nil {
                Text("Runner activity: \(ProbePresentation.notReported)").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            } else if attributedFills.isEmpty {
                Text("No fills attributed to this engine in the latest activity.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            ForEach(Array(attributedFills.enumerated()), id: \.offset) { index, fill in
                VStack(alignment: .leading, spacing: 2) {
                    Text(Self.fillLine(fill)).font(LeafType.tickerSmall)
                    // The activity feed does not carry decision_id yet; say so rather than inventing one.
                    Text("decision_id \(ProbePresentation.notReported) · \(fill.occurredAt)")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                }
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("engine.detail.fill.\(index)")
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("engine.detail.fills")
    }

    private static func fillLine(_ fill: RunnerActivityRow) -> String {
        let side = fill.sideLabel ?? "Side not reported"
        let count = fill.count.map { "\($0)" } ?? "count not reported"
        let price = fill.priceCents.map { "\($0)¢" } ?? "price not reported"
        return "\(fill.safeTicker) · \(side) · \(count) @ \(price)"
    }

    private func details(_ engine: Engine) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            DisclosureGroup("Details") {
                if let description = engine.description { Text(description) }
                if let parent = engine.parentEngineId { Text("from \(parent)").font(LeafType.meta) }
                if let digest = engine.policyDigest { Text("Policy \(String(digest.prefix(12)))").font(LeafType.meta) }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 130), alignment: .leading)], alignment: .leading) {
                    ForEach(Array(capabilities(engine.capabilities).enumerated()), id: \.offset) { _, label in
                        StateChip(label, tone: .neutral)
                    }
                }
                Text(EngineDetailReconcile.pnlPrefix + pnl(engine.pnl)).font(LeafType.numberSmall).foregroundStyle(LeafTheme.inkMuted)
            }
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .contain)
    }

    private func capabilities(_ value: EngineCapabilities?) -> [String] {
        guard let value else { return ["Capabilities unknown"] }
        var labels: [String] = []
        for (name, enabled) in [("Exit rule", value.exitRule), ("Favorites", value.favorites),
                                ("Big-edge cap", value.bigEdgeCap), ("Reversal", value.reversal)] {
            labels.append(name + (enabled.map { $0 ? "" : ": off" } ?? ": unknown"))
        }
        labels.append("Bands: " + (value.bandsOpen?.joined(separator: ", ") ?? "Unknown"))
        let brake = value.drawdownLaw?.brake.map { number($0 * 100) + "%" } ?? "Unknown"
        let stop = value.drawdownLaw?.stop.map { number($0 * 100) + "%" } ?? "Unknown"
        labels.append("Brake \(brake) / Stop \(stop)")
        return labels
    }

    private func number(_ value: Double?) -> String {
        value.map { String(format: "%g", $0) } ?? "Unknown"
    }

    private func pnl(_ value: EnginePnl?) -> String {
        let summary = "\(value?.n.map(String.init) ?? "Unknown") tickets, \(value?.won.map(String.init) ?? "Unknown") won, " +
        "\(number(value?.netCents))¢ net, \(number(value?.perTicketCents))¢ per ticket, " +
        "\(number(value?.ticketsPerHour)) per hour, \(value?.open.map(String.init) ?? "Unknown") open"
        if let exits = value?.exitsN {
            return summary + ", exits \(exits), exit P&L \(number(value?.exitPnlCents))¢"
        }
        return summary
    }
}

/// Names the period and source of every result figure on engine detail, and bridges the two datasets when
/// history is empty or has no P&L while the engine status feed reports trades. Pure and static; only fields the
/// payloads carry, never a recomputed figure and never a cause the data does not state.
enum EngineDetailReconcile {
    static let statusSource = "engine status feed"
    /// Engine detail reads history for one fixed period across every account (no account filter).
    static let historyRange: EngineHistoryRange = .week
    static let historyScope = "All accounts"
    static var historyHeader: String { "\(historyRange.label) · \(historyScope)" }
    static let pnlPrefix = "Engine status feed, period not reported: "

    /// "Live, engine status feed: +3.2c per contract · n 3 over 2 days". Null renders "Not reported".
    static func liveLine(_ live: EngineLiveStats?) -> String {
        "Live, \(statusSource): " + ProbePresentation.perContract(live) +
            (live.map { " over \($0.days) \($0.days == 1 ? "day" : "days")" } ?? "")
    }

    /// The probe day line (always labelled UTC) with its source.
    static func probeDayLine(_ day: ProbeDay?) -> String? {
        EngineRuntimeText.probeDay(day).map { $0 + " · \(statusSource)" }
    }

    /// Muted footer under the live and probe-day figures; the as-of time is the feed's own generatedAt.
    static func statusAsOf(_ generatedAt: String?) -> String {
        let asOf: String
        if let date = parse(generatedAt) {
            asOf = "as of " + EngineRuntimeText.utc(date)
        } else if let generatedAt, !generatedAt.isEmpty {
            asOf = "as of " + generatedAt
        } else {
            asOf = "as-of time not reported"
        }
        return "Live and probe-day figures: \(statusSource), \(asOf)."
    }

    /// "Engine history (ingested tickets) · 7d · All accounts · UTC days · through 2026-09-16 08:00 UTC".
    static func historySource(_ history: EngineHistoryResponse) -> String {
        let scope = history.coverage.scope.isEmpty ? "scope not reported" : history.coverage.scope.replacingOccurrences(of: "_", with: " ")
        return "Engine history (\(scope)) · \(rangeLabel(history)) · \(historyScope) · UTC days · through \(EngineRuntimeText.utc(history.until))"
    }

    static func rangeLabel(_ history: EngineHistoryResponse) -> String {
        EngineHistoryRange(rawValue: history.range)?.label ?? (history.range.isEmpty ? "period not reported" : history.range)
    }

    /// True when history holds any settled, exited or open ticket or any daily bucket for the selection.
    static func historyHasRecords(_ performance: EnginePerformance) -> Bool {
        performance.summary.settlementsN + performance.summary.exitsN + performance.summary.openN > 0 ||
            !performance.series.isEmpty
    }

    /// The engine status feed figures that report at least one trade, each with its own period.
    static func statusTradeFigures(live: EngineLiveStats?, probeDay: ProbeDay?) -> [String] {
        var figures: [String] = []
        if let live, live.n > 0 {
            figures.append("the live sample (n \(live.n) over \(live.days) \(live.days == 1 ? "day" : "days"))")
        }
        if let day = probeDay, let count = day.tickets ?? day.entries, count > 0 {
            figures.append("probe day \(day.utcDay ?? ProbePresentation.notReported) (UTC, \(count) \(count == 1 ? "ticket" : "tickets"))")
        }
        return figures
    }

    /// The sentence beside the history section when history is empty, has no P&L or failed to load while the
    /// engine status feed reports trades. nil when there is nothing to bridge.
    static func bridge(engineId: String, live: EngineLiveStats?, probeDay: ProbeDay?,
                       history: EngineHistoryResponse?, historyFailed: Bool) -> String? {
        let figures = statusTradeFigures(live: live, probeDay: probeDay)
        guard !figures.isEmpty else { return nil }
        let origin = "\(figures.joined(separator: " and ")) \(figures.count == 1 ? "comes" : "come") from the \(statusSource)"
        guard let history else {
            guard historyFailed else { return nil }
            return "History for \(historyHeader) could not be loaded; \(origin)."
        }
        let period = "\(rangeLabel(history)), \(historyScope) (through \(EngineRuntimeText.utc(history.until)))"
        let performance = history.performance(engineId: engineId)
        var text: String
        if !historyHasRecords(performance) {
            text = "History has no records for this engine for \(period); \(origin). History does not report why they are absent."
        } else if performance.summary.realizedPnlCents == nil {
            text = "History P&L for this engine for \(period) is not reported; \(origin)."
        } else {
            return nil
        }
        text += coverageNotes(history)
        return text
    }

    /// Coverage facts from the history payload that bear on missing records, stated as sent.
    static func coverageNotes(_ history: EngineHistoryResponse) -> String {
        var notes = ""
        if history.coverage.ticketsDropped != false || history.coverage.truncated {
            notes += " History coverage for \(rangeLabel(history)) may be incomplete (records dropped or truncated)."
        }
        let unattributed = history.engines.filter { $0.engineId == nil }
            .reduce(0) { $0 + $1.summary.settlementsN + $1.summary.exitsN + $1.summary.openN }
        if unattributed > 0 {
            notes += " \(unattributed) \(unattributed == 1 ? "ticket" : "tickets") in \(rangeLabel(history)) history \(unattributed == 1 ? "carries" : "carry") no engine attribution."
        }
        if history.coverage.missingPnlN > 0 {
            notes += " \(history.coverage.missingPnlN) \(history.coverage.missingPnlN == 1 ? "result" : "results") in \(rangeLabel(history)) history \(history.coverage.missingPnlN == 1 ? "is" : "are") missing P&L."
        }
        return notes
    }

    static func parse(_ text: String?) -> Date? {
        guard let text, !text.isEmpty else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: text) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.date(from: text)
    }
}

enum EngineDetailSheet: String, Identifiable {
    case halt, probe
    var id: String { rawValue }
}

/// engine.halt confirm. Unsigned and never refused for a pending request; the result shows under Requests.
@MainActor private struct EngineHaltSheet: View {
    @Environment<AppState>(AppState.self) private var state
    @Environment(\.dismiss) private var dismiss
    let engineId: String
    let engineName: String
    @State private var reason = "Halted from iPhone"
    @State private var error: String?
    @State private var sending = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Stops new entries. Open contracts settle normally.")
                        .accessibilityIdentifier("engine.detail.halt.message")
                    TextField("Reason", text: $reason, axis: .vertical)
                        .accessibilityIdentifier("engine.detail.halt.reason")
                }
                .disabled(sending)
                Section {
                    if let error {
                        Text(error).foregroundStyle(LeafTheme.loss)
                            .accessibilityIdentifier("engine.detail.halt.error")
                    }
                    Button(sending ? "Sending…" : "Halt \(engineName)", role: .destructive) { submit() }
                        .disabled(sending || state.submittingControl)
                        .accessibilityIdentifier("engine.detail.halt.confirm")
                }
            }
            .navigationTitle("Halt engine")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() }.disabled(sending) }
            }
            .interactiveDismissDisabled(sending)
        }
    }

    private func submit() {
        guard !sending else { return }
        do {
            let intent = try ControlIntent.halt(engineId: engineId, reason: reason, clientRequestId: UUID().uuidString)
            sending = true
            error = nil
            Task {
                let failure = await state.submit(intent, note: reason.trimmingCharacters(in: .whitespacesAndNewlines))
                sending = false
                if let failure { error = failure } else { dismiss() }
            }
        } catch let failure {
            error = failure.localizedDescription
        }
    }
}

/// The owner's engine.probe confirm: account, 1 contract, the breaker percentages that apply, and the expiry
/// (activation + 14 d window + 7 d terminal read). Fails closed without a presence-bound approval token.
@MainActor private struct EngineProbeSheet: View {
    @Environment<AppState>(AppState.self) private var state
    @Environment(\.dismiss) private var dismiss
    let engine: Engine
    let accountLabel: String
    let accountBreaker: AccountBreaker?
    @State private var expiresAt = Date().addingTimeInterval(21 * 86_400)
    @State private var error: String?
    @State private var sending = false

    private var symbols: [String] {
        (engine.markets ?? engine.boundBooks ?? []).filter { $0 != "all" }
    }

    /// The approve route mints the signed single-use token (D7). Only the fixture walk has a stand-in.
    private var approval: String? { state.fixtureMode.controlWalk ? "fixture-approval" : nil }

    private var engineBreaker: String {
        guard let pct = engine.lifecycle?.breaker?.enginePct, pct.isFinite else { return ProbePresentation.notReported }
        return "\(Self.percent(pct))" + (engine.lifecycle?.breaker?.inherited == true ? " (inherited)" : "")
    }

    private var accountBreakerText: String {
        guard let pct = engine.lifecycle?.breaker?.accountPct ?? accountBreaker?.pct, pct.isFinite else {
            return ProbePresentation.notReported
        }
        return Self.percent(pct)
    }

    private static func percent(_ pct: Double) -> String {
        pct.rounded() == pct && abs(pct) < 1e9 ? "\(Int(pct))%" : String(format: "%.1f%%", pct)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    LabeledContent("Account", value: accountLabel)
                        .accessibilityIdentifier("engine.detail.probe.account")
                    LabeledContent("Size", value: "1 contract")
                        .accessibilityIdentifier("engine.detail.probe.size")
                    LabeledContent("Markets", value: symbols.isEmpty ? ProbePresentation.notReported : symbols.joined(separator: ", "))
                    LabeledContent("Engine breaker", value: engineBreaker)
                        .accessibilityIdentifier("engine.detail.probe.engineBreaker")
                    LabeledContent("Account breaker", value: accountBreakerText)
                        .accessibilityIdentifier("engine.detail.probe.accountBreaker")
                    LabeledContent("Expires", value: EngineRuntimeText.utc(expiresAt))
                        .accessibilityIdentifier("engine.detail.probe.expiry")
                    Text("A probe trades real money at one contract. Breaker days are UTC days. Halting later stops new entries; open contracts settle normally.")
                        .font(LeafType.meta)
                }
                .disabled(sending)
                Section {
                    if approval == nil {
                        Text("Approve on the dashboard. The dashboard signs the single-use approval and starts the probe.")
                            .foregroundStyle(LeafTheme.warn)
                            .accessibilityIdentifier("engine.detail.probe.approvalMissing")
                    }
                    if let error {
                        Text(error).foregroundStyle(LeafTheme.loss)
                            .accessibilityIdentifier("engine.detail.probe.error")
                    }
                    if approval != nil {
                        Button(sending ? "Sending…" : "Start probe") {
                            state.requestRaisesRisk(title: "Start probe", detail: "Start a real-money probe at one contract for \(accountLabel).", actionLabel: "Start probe") {
                                submit()
                            }
                        }
                        .disabled(sending || state.submittingControl || symbols.isEmpty)
                        .accessibilityIdentifier("engine.detail.probe.confirm")
                    }
                }
            }
            .navigationTitle("Probe \(engine.name ?? engine.engineId)")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() }.disabled(sending) }
            }
            .interactiveDismissDisabled(sending)
        }
    }

    private func submit() {
        guard !sending, let approval else { return }
        do {
            let intent = try ControlIntent.probe(engineId: engine.engineId, symbols: symbols, approval: approval,
                expiresAt: ISO8601DateFormatter().string(from: expiresAt), bind: true,
                clientRequestId: UUID().uuidString)
            sending = true
            error = nil
            Task {
                let failure = await state.submit(intent, note: "Probe from iPhone")
                sending = false
                if let failure { error = failure } else { dismiss() }
            }
        } catch let failure {
            error = failure.localizedDescription
        }
    }
}
