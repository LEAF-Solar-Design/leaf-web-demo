import SwiftUI
import Charts
import LeafHFTCore

@MainActor struct EngineHistoryView: View {
    @Environment<AppState>(AppState.self) private var state
    var engineId: String? = nil
    @State private var range: EngineHistoryRange = .week
    @State private var account = "all"
    @State private var history: EngineHistoryResponse?
    @State private var error: String?
    @State private var loading = false
    @State private var refresh = 0

    init(engineId: String? = nil, range: EngineHistoryRange = .week, account: String = "all") {
        self.engineId = engineId
        _range = State(initialValue: range)
        _account = State(initialValue: account)
    }

    private var engine: Engine? { state.engines?.engines?.first { $0.engineId == engineId } }
    private var performance: EnginePerformance? {
        history?.performance(engineId: engineId, accountId: account == "all" ? nil : account)
    }

    var body: some View {
        List {
            if let engineId {
                historyCard {
                    VStack(alignment: .leading, spacing: 10) {
                        if let description = engine?.description {
                            Text(description).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        }
                        if let engine {
                            if account == "unassigned" {
                                Label("Unassigned history cannot be configured", systemImage: "lock")
                                    .foregroundStyle(LeafTheme.stale)
                                    .accessibilityIdentifier("engine.history.settingsUnavailable")
                            } else {
                                NavigationLink {
                                    EngineSettingsView(engineId: engineId, initialAccountId: account == "all" ? nil : account)
                                } label: {
                                    Label("Engine settings", systemImage: "slider.horizontal.3")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.leafSecondary)
                                .accessibilityIdentifier("engine.history.settings")
                            }
                            Text("Version \(engine.version.map(String.init) ?? "unknown") · \((engine.boundBooks ?? []).joined(separator: ", "))")
                                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        } else {
                            Text("Settings are unavailable for this historical engine.")
                                .foregroundStyle(LeafTheme.inkMuted)
                        }
                    }
                }
            }
            historyCard {
                VStack(alignment: .leading, spacing: 12) {
                    Picker("Period", selection: $range) {
                        ForEach(EngineHistoryRange.allCases) { item in Text(item.label).tag(item) }
                    }
                    .pickerStyle(.segmented)
                    .tint(LeafTheme.ink)
                    .accessibilityIdentifier("engine.history.range")
                    Picker("Account", selection: $account) {
                        Text("All accounts").tag("all")
                        ForEach(history?.accounts ?? []) { item in Text(item.label).tag(item.id) }
                        if account != "all" && account != "unassigned" && !(history?.accounts.contains { $0.id == account } ?? false) {
                            Text("Selected account (no records)").tag(account)
                        }
                        Text("Unassigned").tag("unassigned")
                    }
                    .pickerStyle(.menu)
                    .tint(LeafTheme.ink)
                    .accessibilityIdentifier("engine.history.account")
                    if state.fixtureMode.enabled {
                        Text("Sample history").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                    if loading {
                        ProgressView("Loading history…").tint(LeafTheme.ink)
                    }
                    if let error {
                        Text(error).foregroundStyle(LeafTheme.loss).accessibilityIdentifier("engine.history.error")
                        Button("Retry") { refresh += 1 }.buttonStyle(.leafSecondary).disabled(loading)
                    }
                }
            }
            if let history, let performance {
                performanceHero(performance)
                dailyChart(performance)
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    historyTile("Settled", value: performance.summary.settlementsN)
                    historyTile("Profitable", value: performance.summary.wonN)
                    historyTile("Early exits", value: performance.summary.exitsN)
                    historyTile("Open", value: performance.summary.openN)
                }
                .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                .listRowSeparator(.hidden)
                .listRowBackground(Color.clear)
                byAccount(history)
                if engineId == nil {
                    historyCard { SectionHeader("By engine") }
                    // One NavigationLink per List row: a row holding several links fires every one on a single tap.
                    ForEach(Array(Set(history.engines.compactMap(\.engineId))).sorted(), id: \.self) { id in
                        historyCard {
                            NavigationLink {
                                EngineHistoryView(engineId: id, range: range, account: account)
                            } label: {
                                attributionRow(engineName(id, history: history),
                                    cents: history.performance(engineId: id,
                                        accountId: account == "all" ? nil : account).summary.realizedPnlCents)
                            }
                            .buttonStyle(.plain)
                            .accessibilityIdentifier("engine.history.detail.\(id)")
                        }
                    }
                    if history.engines.contains(where: { $0.engineId == nil }) {
                        historyCard {
                            Text("The overall total also includes tickets without an engine attribution.")
                                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        }
                    }
                }
                historyCard {
                    VStack(alignment: .leading, spacing: 10) {
                        SectionHeader("History coverage")
                        Text("Through \(history.until.formatted(date: .abbreviated, time: .shortened))")
                        Text("Account views use verified exchange subaccount matches for each runner. They cannot distinguish accounts replaced on the same runner. Older or ambiguous tickets remain Unassigned.")
                        Text("\(history.coverage.unassignedN) unassigned tickets · \(history.coverage.missingPnlN) results missing P&L")
                        if history.coverage.ticketsDropped != false || history.coverage.truncated {
                            Text("Available records may not cover the full trading history.").foregroundStyle(LeafTheme.warn)
                        }
                        if history.coverage.missingPnlN > 0 {
                            Text("Totals include only results with recorded P&L.").foregroundStyle(LeafTheme.warn)
                        }
                        Text("Daily buckets use UTC. This is trading P&L, not account deposits, withdrawals or account value.")
                    }
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                }
            }
        }
        .listStyle(.plain)
        .leafScreenBackground()
        .font(LeafType.body)
        .foregroundStyle(LeafTheme.ink)
        .navigationTitle(engineId.map { id in
            Self.rowLabel(name: engine?.name ?? history?.engines.first { $0.engineId == id }?.name,
                          id: id, fallback: "Engine not reported")
        } ?? "Performance")
        .navigationBarTitleDisplayMode(.inline)
        .accessibilityIdentifier("engine.history.list")
        .task(id: "\(range.rawValue):\(refresh)") { await load() }
        .refreshable { refresh += 1 }
    }

    private func historyCard<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        LeafCard {
            content().frame(maxWidth: .infinity, alignment: .leading)
        }
        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
        .listRowSeparator(.hidden)
        .listRowBackground(Color.clear)
    }

    private func performanceHero(_ performance: EnginePerformance) -> some View {
        historyCard {
            VStack(alignment: .leading, spacing: 12) {
                Eyebrow("Realized P&L")
                EnginePnlValue(cents: performance.summary.realizedPnlCents, numeral: .hero)
                    .accessibilityLabel("Realized P&L, \(money(performance.summary.realizedPnlCents))")
                    .accessibilityIdentifier("engine.history.pnl")
                if let history, let caveat = Self.coverageCaveat(history.coverage) {
                    Text(caveat)
                        .font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                        .accessibilityIdentifier("engine.history.coverageCaveat")
                }
                EngineWinRateBar(rate: performance.winRate)
                if let missing = performance.summary.missingPnlN, missing > 0 {
                    Text("\(missing) results in this view have no recorded P&L. The total is partial.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                }
                Text("Realized results include settlements and early exits. Open positions are not marked to market here.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
        }
    }

    private func historyTile(_ label: String, value: Int) -> some View {
        LeafCard {
            VStack(alignment: .leading, spacing: 8) {
                Eyebrow(label)
                Text(LeafFormat.count(value)).leafNumeral(.number)
                    .foregroundStyle(LeafTheme.ink)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        .accessibilityElement(children: .combine)
    }

    private func dailyChart(_ performance: EnginePerformance) -> some View {
        historyCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionHeader("Daily realized P&L")
                if performance.series.isEmpty {
                    Text("No recorded results for this account and period.")
                        .foregroundStyle(LeafTheme.inkMuted)
                        .accessibilityIdentifier("engine.history.empty")
                } else {
                    HStack(alignment: .firstTextBaseline) {
                        Text("Period total").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        Spacer(minLength: 8)
                        Text(money(performance.summary.realizedPnlCents))
                            .leafNumeral(.number)
                            .foregroundStyle(EnginePnlValue.tone(performance.summary.realizedPnlCents).color)
                            .accessibilityIdentifier("engine.history.chartPnl")
                    }
                    EnginePnlChart(series: performance.series)
                }
            }
        }
    }

    private func byAccount(_ history: EngineHistoryResponse) -> some View {
        let entries = history.engines.filter { engineId == nil || $0.engineId == engineId }
        let rows = entries.flatMap { entry in
            entry.accounts.filter { row in
                account == "all" || row.accountId == account || (account == "unassigned" && row.accountId == nil)
            }.map { (entry: entry, account: $0) }
        }
        return historyCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionHeader("By account")
                if rows.isEmpty {
                    Text("No account-attributed results for this period")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        .accessibilityIdentifier("engine.history.accounts.empty")
                } else {
                    ForEach(rows.indices, id: \.self) { index in
                        let row = rows[index]
                        DisclosureGroup {
                            Text("This period: \(row.account.summary.settlementsN) settled · \(row.account.summary.exitsN) early exits · \(row.account.summary.openN) open")
                                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        } label: {
                            attributionRow(Self.accountName(row.account.accountId, history: history),
                                subtitle: engineId == nil ? row.entry.engineId.map { engineName($0, history: history) }
                                    ?? Self.rowLabel(name: row.entry.name, id: nil, fallback: "Engine not reported") : nil,
                                cents: row.account.summary.realizedPnlCents)
                        }
                        .accessibilityIdentifier("engine.history.accounts.row.\(index)")
                    }
                }
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("engine.history.accounts")
        }
    }

    private func attributionRow(_ name: String, subtitle: String? = nil, cents: Double?) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(name).lineLimit(2).truncationMode(.middle)
                if let subtitle {
                    Text(subtitle).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        .lineLimit(2).truncationMode(.middle)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            Text(money(cents))
                .monospacedDigit()
                .foregroundStyle(EnginePnlValue.tone(cents).color)
                .lineLimit(1).minimumScaleFactor(0.7)
                .frame(width: 112, alignment: .trailing)
        }
        .frame(minHeight: 44)
    }

    static func rowLabel(name: String?, id: String?, fallback: String) -> String {
        if let name, !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return name }
        if let id, !id.isEmpty { return id }
        return fallback
    }

    static func accountName(_ id: String?, history: EngineHistoryResponse) -> String {
        guard let id else { return "Unassigned" }
        return rowLabel(name: history.accounts.first { $0.id == id }?.label,
                        id: id, fallback: "Account not reported")
    }

    static func coverageCaveat(_ coverage: EngineHistoryCoverage) -> String? {
        guard coverage.unassignedN > 0 || coverage.missingPnlN > 0 ||
                coverage.ticketsDropped != false || coverage.truncated else { return nil }
        if coverage.unassignedN > 0 {
            let tickets = coverage.unassignedN == 1 ? "ticket" : "tickets"
            return "Period coverage: \(coverage.unassignedN) unassigned \(tickets); history may be incomplete."
        }
        if coverage.missingPnlN > 0 {
            let results = coverage.missingPnlN == 1 ? "result" : "results"
            return "Period coverage: \(coverage.missingPnlN) \(results) missing P&L; total is partial."
        }
        return "Period coverage: history may be incomplete."
    }

    private func load() async {
        loading = true
        history = nil
        error = nil
        do {
            let response = try await Self.fetch(range: range, engineId: engineId, fixture: state.fixtureMode.enabled)
            try Task.checkCancellation()
            history = response
            loading = false
        } catch {
            guard !Task.isCancelled else { return }
            self.error = Self.loadMessage(error)
            loading = false
        }
    }

    /// One read of engine history: the bundled fixture in fixture mode, else one dashboard request.
    static func fetch(range: EngineHistoryRange, engineId: String?, fixture: Bool) async throws -> EngineHistoryResponse {
        guard fixture else { return try await DashboardClient().engineHistory(range: range, engineId: engineId) }
        guard let url = Bundle.main.url(forResource: "engine-history", withExtension: "json", subdirectory: "Fixtures") else {
            throw FixtureAccessError.missingResource("engine-history")
        }
        let decoder = accountJSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(EngineHistoryResponse.self, from: Data(contentsOf: url))
    }

    static func loadMessage(_ error: Error) -> String {
        switch error as? DashboardClientError {
        case .noCredential: return "Connect the dashboard in Settings to load engine history."
        case .unauthorized: return "Dashboard access was denied. Check Settings."
        default: return "Engine history could not be loaded. Try again."
        }
    }

    private func engineName(_ id: String, history: EngineHistoryResponse) -> String {
        Self.rowLabel(name: state.engines?.engines?.first { $0.engineId == id }?.name
            ?? history.engines.first { $0.engineId == id }?.name, id: id, fallback: "Engine not reported")
    }

    private func money(_ cents: Double?) -> String {
        guard let cents, cents.isFinite else { return "Unavailable" }
        return (cents / 100).formatted(.currency(code: "USD"))
    }
}

/// Daily realized P&L bars by UTC day. The one chart implementation, shared by history and engine detail.
struct EnginePnlChart: View {
    let series: [EngineHistoryPoint]
    var identifier = "engine.history.chart"

    var body: some View {
        Chart {
            RuleMark(y: .value("Break even", 0))
                .foregroundStyle(LeafTheme.inkMuted.opacity(0.7))
                .lineStyle(StrokeStyle(lineWidth: 1, dash: [5, 4]))
            ForEach(series) { point in
                if let cents = point.pnlCents, cents.isFinite {
                    BarMark(x: .value("Day (UTC)", point.day), y: .value("Dollars", cents / 100))
                        .foregroundStyle(cents < 0 ? LeafTheme.loss : LeafTheme.series2)
                        .cornerRadius(3)
                }
            }
        }
        .chartXAxis {
            AxisMarks(values: Self.dayTicks(series)) { value in
                AxisValueLabel {
                    if let day = value.as(String.self) {
                        Text(String(day.suffix(5))).font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
                    }
                }
            }
        }
        .chartYAxis {
            AxisMarks { value in
                AxisGridLine(stroke: StrokeStyle(lineWidth: 0.5)).foregroundStyle(LeafTheme.line)
                AxisValueLabel {
                    if let amount = value.as(Double.self) {
                        Text(amount, format: .currency(code: "USD"))
                            .font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
                    }
                }
            }
        }
        .chartPlotStyle { plot in
            plot.background(LeafTheme.cardRaised)
        }
        .frame(height: 190)
        .accessibilityLabel("Daily realized profit and loss")
        .accessibilityIdentifier(identifier)
    }

    /// At most five axis labels, O(n) over the series.
    static func dayTicks(_ points: [EngineHistoryPoint]) -> [String] {
        let step = max(1, Int(ceil(Double(points.count) / 4)))
        return stride(from: 0, to: points.count, by: step).map { points[$0].day }
    }
}
