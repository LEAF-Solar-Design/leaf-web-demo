import SwiftUI
import LeafHFTCore

@MainActor struct AccountView: View {
    @Environment<AppState>(AppState.self) private var state
    @Environment(\.scenePhase) private var scenePhase
    @State private var range: LeafHFTCore.HistoryRange = .day
    @State private var showingReadOnly = false

    struct AccountRail: Equatable {
        let label: String
        /// Whether the label names a single assigned account rather than the runner.
        let isStatic: Bool
    }

    /// Labels are the configurable, assigned accounts; several accounts describe the main runner.
    static func accountRail(labels: [String]) -> AccountRail {
        guard labels.count <= 1 else { return AccountRail(label: "Main runner", isStatic: false) }
        let label = labels.first?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return AccountRail(label: label.isEmpty ? "Main runner" : label, isStatic: true)
    }

    /// The badge is fixed text: it describes this phone's Kalshi access (KalshiClient only sends GET requests),
    /// which is separate from whether the runner is trading.
    static func readOnlyExplanation(automation: String) -> [String] {
        [
            "Phone access: read-only. This phone reads your Kalshi balance, positions and fills with the saved key. It never places, changes or cancels a Kalshi order.",
            "Runner status: \(automation). This is separate from phone access; reported runner orders appear further down this screen.",
            "The badge does not change with runner state. Halt entries on a probe sends a request to the runner, not an order to Kalshi."
        ]
    }

    private var accountRail: AccountRail {
        let accounts = (state.engines?.accounts ?? []).filter { $0.configurable && $0.id != "unassigned" }
        return Self.accountRail(labels: accounts.map(\.label))
    }

    private func accountChip(_ label: String) -> some View {
        OneLine(label).font(LeafType.body)
            .padding(.horizontal, 12).frame(minHeight: 44)
            .background(LeafTheme.cardRaised, in: Capsule())
            .overlay { Capsule().strokeBorder(LeafTheme.ink, lineWidth: 2) }
    }

    private var readOnlyBadge: some View {
        Button { showingReadOnly = true } label: {
            StateInk("read-only", tone: .stale).frame(minHeight: 44)
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("monitor.readOnly")
        .accessibilityHint("Explains what read-only means here")
    }

    private var readOnlySheet: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(Self.readOnlyExplanation(automation: state.automationLabel), id: \.self) { line in
                        Text(line).font(LeafType.body).fixedSize(horizontal: false, vertical: true)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
            }
            .navigationTitle("Read-only")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { showingReadOnly = false }
                        .accessibilityIdentifier("monitor.readOnly.done")
                }
            }
        }
        .presentationDetents([.medium, .large])
        .accessibilityIdentifier("monitor.readOnly.sheet")
    }

    private var header: some View {
        let rail = accountRail
        return FlatCard(title: "") {
            ChipRow(identifier: "monitor.accounts") {
                accountChip(rail.label)
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel("Account \(rail.label)")
                    .accessibilityIdentifier("monitor.account")
            }
            if state.fixtureMode.enabled {
                Caption("Fixture data", expandable: false)
                    .accessibilityIdentifier("account.fixtureNotice")
            }
            if state.fixtureMode.noKey {
                OneLine("Import your runner key in Settings.").font(LeafType.body)
                    .accessibilityIdentifier("account.settingsPrompt")
            }
        }
    }

    @ViewBuilder private var ownerStatus: some View {
        if state.isOwnerExecution, let execution = state.execution {
            FlatCard(title: "Owner books") {
                StateInk(execution.summaryLabel, tone: execution.summary == "running" ? .gain : .stale)
                    .accessibilityIdentifier("account.owner.summary")
                if let running = execution.counts?.running, let expected = execution.counts?.expected {
                    Text("\(running) of \(expected) running").font(LeafType.body)
                        .accessibilityIdentifier("account.owner.runningCount")
                } else {
                    Text("Running count unavailable").font(LeafType.body)
                }
                if let entries = execution.counts?.entryEnabled, let expected = execution.counts?.expected {
                    Text("\(entries) of \(expected) entry-enabled").font(LeafType.body)
                        .accessibilityIdentifier("account.owner.entryCount")
                } else {
                    Text("Entry-enabled count unavailable").font(LeafType.body)
                }
                Text(ownerPauseLabel(execution)).font(LeafType.meta)
                    .accessibilityIdentifier("account.owner.pauseState")
                if let progress = state.ownerControlProgress {
                    ProgressView(progress).accessibilityAddTraits(.updatesFrequently)
                        .accessibilityIdentifier("account.owner.pending")
                }
                HStack(spacing: 12) {
                    Button("Pause") { state.runAccountAction(.pause) }
                        .buttonStyle(.leafSecondary)
                        .disabled(!state.canRunAccountAction(.pause) || scenePhase != .active)
                        .accessibilityIdentifier("account.owner.pause")
                    Button("Start") {
                        state.runAccountAction(.startLive, confirmedRevision: state.accountControlRevision)
                    }
                    .buttonStyle(.leafPrimary)
                    .disabled(!state.canRunAccountAction(.startLive) || scenePhase != .active)
                    .accessibilityIdentifier("account.owner.start")
                }
                Text("Pause stops new entries on every owner book. Exits and settlements continue. Start uses Face ID and clears only this pause; other safeguards still apply.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                if let error = state.setupError {
                    Text(error).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                        .accessibilityIdentifier("account.owner.error")
                }
            }
            .accessibilityIdentifier("account.owner.status")
        }
    }

    private func ownerPauseLabel(_ execution: KashbotExecution) -> String {
        let label: String
        switch execution.pause?.state {
        case "paused": label = "Owner entries paused"
        case "resumed": label = "Owner pause cleared"
        case "absent": label = "No owner pause recorded"
        default: label = "Owner pause status unavailable"
        }
        return execution.pause?.generation.map { label + " · generation \($0)" } ?? label
    }

    var body: some View {
        NavigationStack {
            TimelineView(.periodic(from: .now, by: 15)) { context in
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        OrderCapCard()
                        header
                        ownerStatus
                        NeedsYouCard()
                        MoneyCard(range: $range, now: context.date)
                        ProbeBoardCard(now: context.date)
                        OrdersCard(activity: state.runnerActivity)
                        AttemptFunnelCard(funnel: state.attemptFunnel, error: state.attemptFunnelError)
                        ExitsCard(ledger: state.exitLedger, error: state.exitLedgerError)
                        CalibrationCard(calibration: state.entryCalibration, error: state.entryCalibrationError)
                    }
                    .padding(16)
                }
                .accessibilityIdentifier("account.scroll")
                .leafScreenBackground()
                .foregroundStyle(LeafTheme.ink)
            }
            .navigationTitle("Monitor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { readOnlyBadge }
            }
            .toolbarBackground(.visible, for: .navigationBar)
            .sheet(isPresented: $showingReadOnly) { readOnlySheet }
        }
    }
}
