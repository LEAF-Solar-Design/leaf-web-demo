import SwiftUI
import LeafHFTCore

@MainActor struct BooksView: View {
    @Environment<AppState>(AppState.self) private var state
    @State private var latch = ToggleRequestLatch()
    @State private var errors: [String: String] = [:]
    @State private var openBookId: String?

    struct CardText: Equatable {
        let chip: String
        let chipTone: LeafTone
        let closes: String
        let edge: String?
    }

    struct DetailText: Equatable {
        let chip: String
        let chipTone: LeafTone
        let closesIn: String
        let observations: String
        let depth: String
        let edge: String?
        let side: String?
        let gate: String?
    }

    static func cardText(book: Book) -> CardText {
        let evaluation = book.kalshiBook.eval
        let candidate = evaluation?.candidates?.first
        let hold = candidate.flatMap { MonitorPresentation.chipHold(bookEnabled: book.enabled, candidate: $0) }
        let condition = Self.condition(candidate, evaluation: evaluation)
        let cells = candidate.map { BookCandidateCells(book: book, candidate: $0, missing: "Unknown") }
        let tone: LeafTone
        switch hold {
        case .bookPaused: tone = .warn
        case .entriesOff: tone = .stale
        case nil: tone = Self.conditionTone(condition)
        }
        return CardText(chip: hold.map(MonitorPresentation.holdCopy) ?? Self.phrase(condition),
                        chipTone: tone, closes: cells?.closes ?? "Unknown", edge: cells?.edge)
    }

    /// Books-level claim: DELAYED when stale, SAVED when the last refresh failed, LIVE only otherwise.
    static func booksLiveState(stale: Bool, refreshFailed: Bool) -> LiveState {
        if stale { return .delayed }
        return refreshFailed ? .saved : .live
    }

    /// Market-level claim: LIVE only when the books are live, the market's close is not past and it has a quote.
    static func marketLiveState(books: LiveState, candidate: Candidate?, now: Date) -> LiveState {
        guard books == .live else { return books }
        if let closeMs = closeTimeMs(candidate), Double(closeMs) <= now.timeIntervalSince1970 * 1000 { return .closed }
        return hasQuote(candidate) ? .live : .noQuote
    }

    /// Absolute close time: the reported expiry, else the evaluation time plus the reported countdown.
    private static func closeTimeMs(_ candidate: Candidate?) -> Int64? {
        guard let candidate else { return nil }
        if let expiry = candidate.expiryMs, expiry > 0 { return expiry }
        guard let seconds = candidate.secondsToClose, seconds.isFinite, abs(seconds) < 1e9,
              let evalAt = candidate.evalAtMs, evalAt > 0 else { return nil }
        let close = evalAt.addingReportingOverflow(Int64(seconds * 1000))
        return close.overflow ? nil : close.partialValue
    }

    private static func hasQuote(_ candidate: Candidate?) -> Bool {
        guard let candidate, let ask = candidate.askCents, ask.isFinite else { return false }
        return candidate.gate?.lowercased().contains("no_quote") != true
    }

    static func detailText(book: Book) -> DetailText {
        let card = Self.cardText(book: book)
        let evaluation = book.kalshiBook.eval
        let candidate = evaluation?.candidates?.first
        let cells = candidate.map { BookCandidateCells(book: book, candidate: $0, missing: "Unknown") }
        let hold = cells?.hold
        let depth = candidate?.depth.flatMap { $0.isFinite ? Self.number($0) : nil }
        let edge: String? = candidate.map { candidate in
            let reported = candidate.edgeCents.flatMap { $0.isFinite ? Self.signedCents($0) : nil }
            let required = MonitorPresentation.centsText(candidate.edgeRequiredCents)
            if reported == nil, required == nil, let hold { return MonitorPresentation.holdCopy(hold) }
            return "\(MonitorPresentation.field(reported, hold: hold, missing: "Unknown")) / \(MonitorPresentation.field(required, hold: hold, missing: "Unknown")) required"
        }
        let side: String? = candidate.map { candidate in
            MonitorPresentation.field(candidate.sideYes.map { $0 ? "Yes" : "No" }, hold: hold, missing: "Side unknown")
                + (candidate.favorite == true ? " · favorite" : "")
        }
        let gate = candidate.map { hold.map(MonitorPresentation.holdCopy) ?? Self.humanized($0.gate) }
        return DetailText(chip: card.chip, chipTone: card.chipTone,
                          closesIn: cells?.closes ?? "Unknown",
                          observations: cells?.observations ?? "? of \(evaluation?.minK.map(String.init) ?? "?")",
                          depth: MonitorPresentation.field(depth, hold: hold, missing: "Unknown"),
                          edge: edge, side: side, gate: gate)
    }

    var body: some View {
        NavigationStack {
            TimelineView(.periodic(from: .now, by: 15)) { context in
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                    booksHeader
                    if state.fixtureMode.enabled {
                        FlatCard(title: "Fixture data") { Caption("Sample book telemetry") }
                    }
                    if let error = state.dashboardError {
                        FlatCard(title: "Telemetry") { Caption(error, tone: .loss) }
                    }
                    if state.books?.books.isEmpty != false {
                        FlatCard(title: "Waiting for telemetry") {
                            ContentUnavailableView("Waiting for telemetry", systemImage: "square.grid.2x2",
                            description: Text("Save the dashboard token in Settings to see the books."))
                        }
                    }
                    OpenNowCard(books: state.books?.books ?? [], engines: state.engines?.engines ?? [])
                    HandCard(books: state.books?.books ?? [], engines: state.engines?.engines ?? [],
                             requests: state.pendingRequests)
                    FlatCard(title: "Books", trailing: "scrolls inside the box") {
                        BoundedList(maxHeight: 420, identifier: "books.rows") {
                        ForEach((state.books?.books ?? []).sorted { $0.bookId < $1.bookId }, id: \.bookId) { book in
                            ZStack(alignment: .topTrailing) {
                                Button {
                                    openBookId = book.bookId
                                } label: {
                                    bookCard(book, now: context.date)
                                }
                                .buttonStyle(.plain)
                                .accessibilityLabel("\(book.bookId), \(status(book, now: context.date))")
                                .accessibilityIdentifier("book.\(book.bookId)")
                                bookToggle(book, labeled: false)
                                    .fixedSize()
                                    .padding(.top, 14)
                                    .padding(.trailing, 14)
                            }
                        }
                        }
                        .frame(height: 420)
                        Caption("Turning a book off blocks new entries. Existing positions keep their exit and risk controls.")
                    }
                    }
                    .padding(16)
                }
                .accessibilityIdentifier("books.scroll")
                .navigationDestination(item: $openBookId) { id in
                    TimelineView(.periodic(from: .now, by: 15)) { detailContext in
                        if let book = state.books?.books.first(where: { $0.bookId == id }) {
                            bookDetail(book, now: detailContext.date)
                        } else {
                            Text("This book is no longer available.")
                                .foregroundStyle(LeafTheme.inkMuted)
                                .navigationTitle(id)
                                .navigationBarTitleDisplayMode(.inline)
                                .toolbar(.hidden, for: .tabBar)
                                .accessibilityIdentifier("books.detail")
                        }
                    }
                }
                .leafScreenBackground()
                .onChange(of: context.date) { _, now in reconcileLatch(now: now) }
            }
            .navigationTitle("Books")
            .navigationBarTitleDisplayMode(.inline)
            .transaction { $0.animation = nil }
            .onChange(of: reconciliationFingerprint) { _, _ in reconcileLatch(now: Date()) }
        }
    }

    private var booksHeader: some View {
        let books = state.books?.books ?? []
        let delayed = state.booksStale ? books.count : 0
        let unavailable = state.booksStale || state.booksRefreshFailed
        let accepting: Int? = unavailable ? nil : books.filter { $0.enabled != nil && isEnabled($0) }.count
        let paused: Int? = unavailable ? nil : books.filter { $0.enabled != nil && !isEnabled($0) }.count
        let live = Self.booksLiveState(stale: state.booksStale, refreshFailed: state.booksRefreshFailed)
        // SAVED replaces the Delayed tile so the header never pairs saved data with "0 Delayed".
        let lastLabel = live == .saved ? "Saved" : "Delayed"
        let lastCount = live == .saved ? books.count : delayed
        return FlatCard(title: "Overview") {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Books").font(LeafType.title).foregroundStyle(LeafTheme.ink)
                    .accessibilityAddTraits(.isHeader)
                Spacer()
                LiveDot(state: live)
            }
            if state.booksRestored, let savedAt = state.booksObservedAt {
                Caption("Saved \(RelativeDateTimeFormatter().localizedString(for: savedAt, relativeTo: Date())). Refreshing.")
                    .accessibilityIdentifier("books.restored")
            }
            if let explanation = booksFeedExplanation(now: Date()) {
                Caption(explanation, tone: .stale)
                    .accessibilityIdentifier("books.feedStatus")
            }
            if books.contains(where: { $0.enabled == nil }) {
                Caption("\(books.filter { $0.enabled == nil }.count) books: enabled state Unknown.")
                    .accessibilityIdentifier("books.unknownCount")
            }
            HStack(alignment: .top, spacing: 8) {
                summaryTile("Books", count: books.count, color: LeafTheme.ink, isTotal: true)
                summaryTile("Accepting", count: accepting, color: LeafTheme.gain)
                summaryTile("Paused", count: paused, color: (paused ?? 0) > 0 ? LeafTheme.warn : LeafTheme.inkMuted)
                summaryTile(lastLabel, count: lastCount, color: lastCount > 0 ? LeafTheme.stale : LeafTheme.inkMuted)
            }
        }
        }
    }

    private func summaryTile(_ label: String, count: Int?, color: Color, isTotal: Bool = false) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label).font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
            if isTotal {
                Text(count.map(String.init) ?? "Unknown")
                    .leafNumeral(.large)
                    .accessibilityLabel(count.map { "\($0) books" } ?? "Books count Unknown")
                    .accessibilityIdentifier("books.count")
            } else {
                Text(count.map(String.init) ?? "Unknown").leafNumeral(.large)
            }
        }
        .foregroundStyle(color)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: LeafTheme.radiusSmall))
        .overlay {
            RoundedRectangle(cornerRadius: LeafTheme.radiusSmall)
                .strokeBorder(LeafTheme.line, lineWidth: 1)
                .allowsHitTesting(false).accessibilityHidden(true)
        }
    }

    private func status(_ book: Book, now: Date) -> String {
        let stale = state.booksObservedAt.map { transportStale(observedAt: $0, now: now) } ?? true
        if stale { return "Delayed telemetry" }
        if state.feedStatuses[.books]?.lastError != nil { return "Saved telemetry · refresh failed" }
        return Self.enabledStatus(book.enabled.map { _ in isEnabled(book) })
    }

    static func enabledStatus(_ enabled: Bool?) -> String {
        enabled.map { $0 ? "Accepting new entries" : "New entries paused" } ?? "Unknown"
    }

    private func bookCard(_ book: Book, now: Date) -> some View {
        let text = Self.cardText(book: book)
        let evaluation = book.kalshiBook.eval
        let candidate = evaluation?.candidates?.first
        let bindingCondition = Self.condition(candidate, evaluation: evaluation)
        return FlatCard(title: "Book") {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 4) {
                        OneLine(book.bookId, truncation: .middle).font(LeafType.micro)
                            .foregroundStyle(LeafTheme.inkMuted)
                        Text(status(book, now: now))
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        if let candidate {
                            OneLine(candidate.ticker, truncation: .middle).font(LeafType.ticker)
                                .foregroundStyle(LeafTheme.ink)
                        }
                    }
                    Spacer(minLength: 0)
                }
                .padding(.trailing, 72)
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    conditionChip(text.chip, tone: text.chipTone, bookId: book.bookId)
                    Spacer(minLength: 0)
                    Text("closes \(text.closes)")
                        .leafNumeral(.small).foregroundStyle(LeafTheme.inkMuted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                observationProgress(candidate, evaluation: evaluation, condition: bindingCondition)
                if let candidate, let edge = text.edge {
                    Label("edge \(edge)",
                          systemImage: Self.edgeTone(candidate).glyph)
                        .font(LeafType.numberSmall).foregroundStyle(Self.edgeTone(candidate).color)
                        .fixedSize(horizontal: false, vertical: true)
                    quotePair(candidate)
                }
                if let error = errors[book.bookId] {
                    Text(error).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                }
                if let explanation = booksFeedExplanation(now: now) {
                    Caption(explanation, tone: .stale)
                        .accessibilityIdentifier("book.feedStatus.\(book.bookId)")
                }
                Image(systemName: "chevron.right")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .accessibilityHidden(true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func bookDetail(_ book: Book, now: Date) -> some View {
        let text = Self.detailText(book: book)
        let evaluation = book.kalshiBook.eval
        let candidate = evaluation?.candidates?.first
        let stale = state.booksObservedAt.map { transportStale(observedAt: $0, now: now) } ?? true
        let books = Self.booksLiveState(stale: stale, refreshFailed: state.booksRefreshFailed)
        let live = Self.marketLiveState(books: books, candidate: candidate, now: now)
        return ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                marketCard(candidate, text: text, live: live)
                entryCard(candidate, text: text, bookId: book.bookId)
                enginesCard(book)
                if let tickets = evaluation?.tickets, !tickets.isEmpty {
                    FlatCard(title: "Tickets", trailing: "\(tickets.count)") {
                        BoundedList(maxHeight: 260, identifier: "books.tickets") {
                            ForEach(Array(tickets.enumerated()), id: \.offset) { _, ticket in
                                ticketCard(ticket)
                            }
                        }
                        .frame(height: 260)
                    }
                }
                FlatCard(title: "Book enabled") {
                    toggleRow(book, includeLabel: true)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .padding(16)
        }
        .leafScreenBackground()
        .navigationTitle(book.bookId)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.hidden, for: .tabBar)
        .accessibilityIdentifier("books.detail")
    }

    private func marketCard(_ candidate: Candidate?, text: DetailText, live: LiveState) -> some View {
        FlatCard(title: "Market") {
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(candidate?.ticker ?? "Waiting for telemetry")
                            .font(LeafType.ticker).foregroundStyle(LeafTheme.ink)
                            .fixedSize(horizontal: false, vertical: true)
                            .textSelection(.enabled)
                    }
                    Spacer(minLength: 0)
                    LiveDot(state: live)
                }
                HStack(alignment: .top, spacing: 16) {
                    marketStat("Closes in", value: text.closesIn)
                    marketStat("Observations", value: text.observations)
                    marketStat("Depth", value: text.depth)
                }
                Caption("fair \(Self.cents(candidate?.fairCents)) · ask \(Self.cents(candidate?.askCents)) · fee \(Self.cents(candidate?.feeCents)) · quote age \(Self.number(candidate?.quoteAgeMs)) ms")
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func marketStat(_ label: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            Text(value).leafNumeral(.large).foregroundStyle(LeafTheme.ink)
                .minimumScaleFactor(0.6)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func entryCard(_ candidate: Candidate?, text: DetailText, bookId: String) -> some View {
        FlatCard(title: "Entry") {
            VStack(alignment: .leading, spacing: 12) {
                conditionChip(text.chip, tone: text.chipTone, bookId: bookId)
                if let candidate {
                    KeyValueRow("Edge", value: text.edge ?? "Unknown",
                                tone: Self.edgeTone(candidate))
                    KeyValueRow("Side", value: text.side ?? "Side unknown")
                    KeyValueRow("Gate", value: text.gate ?? "Not reported")
                    quotePair(candidate)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    /// D10 executor block. The decoded model cannot tell `"executor": null` from a missing field, so a payload with
    /// no executor on any book is an older server and keeps the pre-I5 detail; a nil beside a reporting book is null.
    @ViewBuilder private func enginesCard(_ book: Book) -> some View {
        let executor = book.kalshiBook.executor
        let serverReportsExecutor = (state.books?.books ?? []).contains { $0.kalshiBook.executor != nil }
        if executor != nil || serverReportsExecutor {
            FlatCard(title: "Engines on this market", trailing: executor.map { "\($0.engines.count)" }) {
                VStack(alignment: .leading, spacing: 10) {
                    if let executor, !executor.engines.isEmpty || executor.position != nil
                        || executor.disagreementsToday != nil {
                        ForEach(Array(executor.engines.enumerated()), id: \.offset) { _, engine in
                            engineRow(engine, executor: executor, bookId: book.bookId)
                        }
                        holderRow(executor.position, bookId: book.bookId)
                        disagreementRow(executor, bookId: book.bookId)
                    } else {
                        Text("Not reported").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .accessibilityElement(children: .contain)
                .accessibilityIdentifier("book.engines.\(book.bookId)")
            }
        }
    }

    private func engineRow(_ engine: ExecutorEngine, executor: ExecutorSummary, bookId: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                OneLine(engine.engineId, truncation: .middle).font(LeafType.ticker).foregroundStyle(LeafTheme.ink)
                Text(role(engine, executor: executor)).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                Spacer(minLength: 0)
                StateInk(lifecycle(engine.state), tone: lifecycleTone(engine.state))
            }
            if let reasons = engine.stopReasons, !reasons.isEmpty {
                Text("Stopped: " + reasons.map { $0.text ?? $0.code }.joined(separator: ", "))
                    .font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if let until = engine.entriesSuspendedUntil, !until.isEmpty {
                Text("Entries suspended until \(until)").font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if let proposal = engine.lastProposal {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    StateInk(disposition(proposal.disposition), tone: dispositionTone(proposal.disposition))
                    Text(proposalSummary(proposal)).font(LeafType.numberSmall).foregroundStyle(LeafTheme.inkMuted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if let reason = proposal.reason, !reason.isEmpty {
                    Text(reason).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        .fixedSize(horizontal: false, vertical: true)
                }
            } else {
                Text("No proposal reported").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: LeafTheme.radiusSmall))
        .overlay {
            RoundedRectangle(cornerRadius: LeafTheme.radiusSmall)
                .strokeBorder(LeafTheme.line, lineWidth: 1)
                .allowsHitTesting(false).accessibilityHidden(true)
        }
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("book.engines.\(bookId).row.\(engine.engineId)")
    }

    private func holderRow(_ position: ExecutorPosition?, bookId: String) -> some View {
        let value: String
        if let position {
            let holder = position.holderEngineId.flatMap { $0.isEmpty ? nil : $0 } ?? "Holder not reported"
            value = "\(holder) · \(position.ticker ?? "Ticker unknown") · \(Self.side(position.sideYes)) · "
                + "\(Self.number(position.contracts)) contracts · opened \(centralTime(position.openedAtMs))"
        } else {
            value = "No open position reported"
        }
        return KeyValueRow("Position held by", value: value)
            .accessibilityIdentifier("book.engines.\(bookId).holder")
    }

    private func disagreementRow(_ executor: ExecutorSummary, bookId: String) -> some View {
        let count = executor.disagreementsToday
        let lastText: String? = lastDisagreement(executor).map { last in
            let reason: String = last.proposal.reason.map { " · \($0)" } ?? ""
            let verb: String = disposition(last.proposal.disposition).lowercased()
            return "Last: \(last.engineId) \(verb) \(proposalSummary(last.proposal))\(reason)"
        }
        return VStack(alignment: .leading, spacing: 6) {
            KeyValueRow("Disagreements today", value: count.map(String.init) ?? "Not reported",
                        tone: (count ?? 0) > 0 ? .warn : .neutral)
            if let lastText {
                Text(lastText)
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .fixedSize(horizontal: false, vertical: true)
            } else if (count ?? 0) > 0 {
                Text("Last disagreement not reported").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("book.engines.\(bookId).disagreements")
    }

    /// The newest proposal the runner marked a conflict or refused for an engine disagreement.
    private func lastDisagreement(_ executor: ExecutorSummary) -> (engineId: String, proposal: ExecutorProposal)? {
        executor.engines
            .compactMap { engine in engine.lastProposal.map { (engineId: engine.engineId, proposal: $0) } }
            .filter { $0.proposal.disposition?.lowercased() == "conflict"
                || $0.proposal.reason?.lowercased().contains("disagreement") == true }
            .max { ($0.proposal.atMs ?? 0) < ($1.proposal.atMs ?? 0) }
    }

    private func proposalSummary(_ proposal: ExecutorProposal) -> String {
        "\(proposal.ticker ?? "Ticker unknown") · \(Self.side(proposal.sideYes)) @ \(Self.cents(proposal.priceCents)) · "
            + "edge \(Self.signedCents(proposal.edgeCents)) · \(centralTime(proposal.atMs))"
    }

    private func role(_ engine: ExecutorEngine, executor: ExecutorSummary) -> String {
        let role = (engine.role ?? "").lowercased()
        switch role {
        case "incumbent": return "Incumbent"
        case "probe": return "Probe"
        case "": return engine.engineId == executor.incumbentEngineId ? "Incumbent" : "Role not reported"
        default: return role.capitalized
        }
    }

    private func lifecycle(_ state: EngineLifecycle.State?) -> String {
        guard let state else { return "Lifecycle not reported" }
        switch state {
        case .probe: return "Probing"
        case .probeSized: return "Probing at size"
        case .graduated: return "Graduated"
        case .retired: return "Retired"
        case .shadow: return "Shadow only"
        case .canary: return "Canary"
        case .halted: return "Entries halted"
        case .unknown: return "Lifecycle not reported"
        }
    }

    private func lifecycleTone(_ state: EngineLifecycle.State?) -> LeafTone {
        guard let state else { return .stale }
        switch state {
        case .graduated: return .gain
        case .probe, .probeSized, .canary: return .warn
        case .halted: return .loss
        case .retired, .shadow, .unknown: return .stale
        }
    }

    private func disposition(_ value: String?) -> String {
        guard let value, !value.isEmpty else { return "Not reported" }
        return value.replacingOccurrences(of: "_", with: " ").capitalized
    }

    private func dispositionTone(_ value: String?) -> LeafTone {
        switch (value ?? "").lowercased() {
        case "sized": return .gain
        case "refused": return .loss
        case "conflict": return .warn
        default: return .stale
        }
    }

    private static let centralFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "America/Chicago")
        formatter.dateFormat = "MMM d, h:mm a 'CT'"
        return formatter
    }()

    private func centralTime(_ ms: Int64?) -> String {
        guard let ms, ms > 0 else { return "time unknown" }
        return Self.centralFormatter.string(from: Date(timeIntervalSince1970: TimeInterval(ms) / 1000))
    }

    private func ticketCard(_ ticket: Ticket) -> some View {
        let tone = exitTone(ticket)
        return FlatCard(title: ticket.ticker) {
            VStack(alignment: .leading, spacing: 10) {
                Text("\(Self.side(ticket.sideYes)) · \(Self.number(ticket.count)) contracts @ \(Self.cents(ticket.priceCents))")
                    .font(LeafType.number).foregroundStyle(LeafTheme.ink)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Image(systemName: tone.glyph).accessibilityHidden(true)
                    Text(exitPhrase(ticket))
                }
                .font(LeafType.number).foregroundStyle(tone.color)
                Text("Hold value \(Self.cents(ticket.holdValue)) · bid \(Self.cents(ticket.bidCents)) · depth \(Self.number(ticket.depth))")
                    .font(LeafType.numberSmall).foregroundStyle(LeafTheme.inkMuted)
                    .fixedSize(horizontal: false, vertical: true)
                StateInk(Self.humanized(ticket.exitGate), tone: .warn)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    @ViewBuilder private func toggleRow(_ book: Book, includeLabel: Bool = false) -> some View {
        if includeLabel {
            VStack(alignment: .leading, spacing: 8) {
                bookToggle(book, labeled: true)
                Text(book.enabled == nil ? "Enabled state Unknown." : (isEnabled(book) ? "This book can open new positions." : "New entries are paused for this book."))
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                if let explanation = booksFeedExplanation(now: Date()) {
                    Caption(explanation, tone: .stale)
                        .accessibilityIdentifier("book.feedStatus.\(book.bookId)")
                }
                Text("Turning a book off blocks new entries. Existing positions keep their exit and risk controls.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                if let error = errors[book.bookId] { Text(error).font(LeafType.meta).foregroundStyle(LeafTheme.loss) }
            }
        } else { bookToggle(book, labeled: false) }
    }

    @ViewBuilder private func bookToggle(_ book: Book, labeled: Bool) -> some View {
        let binding = Binding(get: { isEnabled(book) }, set: { enabled in Task { await requestSet(book, enabled: enabled) } })
        if book.enabled == nil {
            Text("Unknown").font(LeafType.meta).foregroundStyle(LeafTheme.stale)
                .accessibilityLabel("\(book.bookId) enabled state Unknown")
                .accessibilityIdentifier("book.enabledUnknown.\(book.bookId)")
        } else if labeled {
            Toggle("Book enabled", isOn: binding)
                .font(LeafType.heading).foregroundStyle(LeafTheme.ink)
                .tint(LeafTheme.gain)
                .disabled(!canToggle(book))
                .accessibilityIdentifier("book.toggle.\(book.bookId)")
        } else {
            Toggle("", isOn: binding).labelsHidden()
                .tint(LeafTheme.gain)
                .disabled(!canToggle(book))
                .accessibilityLabel("\(book.bookId) enabled")
                .accessibilityIdentifier("book.toggle.\(book.bookId)")
        }
    }

    private var reconciliationFingerprint: String {
        let books = (state.books?.books ?? []).sorted { $0.bookId < $1.bookId }
            .map { "\($0.bookId):\($0.enabled.map(String.init) ?? "unknown")" }.joined(separator: "|")
        let requests = state.pendingRequests.sorted { $0.id < $1.id }
            .map { "\($0.id):\($0.clientRequestId ?? ""): \($0.state ?? "")" }.joined(separator: "|")
        return books + "#" + requests
    }

    private func isEnabled(_ book: Book) -> Bool {
        book.enabled != nil && latch.effective(id: book.bookId, observed: book.enabled, fallback: false)
    }

    private func reconcileLatch(now: Date) {
        for book in state.books?.books ?? [] {
            let request = latch.entries[book.bookId].flatMap { entry in
                state.pendingRequests.first { $0.clientRequestId == entry.clientRequestId }
            }
            let lifecycle: ToggleRequestLatch.RequestState
            if let request {
                if ControlRequestLifecycle.isTerminal(state: request.state) {
                    switch request.state?.lowercased() {
                    case "applied": lifecycle = .applied
                    case "rejected": lifecycle = .rejected
                    default: lifecycle = .unknown
                    }
                } else {
                    lifecycle = .pending
                }
            } else {
                lifecycle = .missing
            }
            latch.reconcile(id: book.bookId, observed: book.enabled, request: lifecycle, now: now)
        }
    }

    private func canToggle(_ book: Book) -> Bool {
        Self.canToggle(fixture: state.fixtureMode.enabled, submitting: state.submittingControl,
            outcomeUnknown: state.controlOutcomeUnknown, hasHost: book.host?.isEmpty == false,
            restored: state.booksRestored, stale: state.isStale(.books, budget: 120, now: Date()),
            refreshFailed: state.feedStatuses[.books]?.lastError != nil, enabledKnown: book.enabled != nil)
    }

    static func canToggle(fixture: Bool, submitting: Bool, outcomeUnknown: Bool, hasHost: Bool, restored: Bool,
                          stale: Bool = false, refreshFailed: Bool = false, enabledKnown: Bool = true) -> Bool {
        !fixture && !submitting && !outcomeUnknown && hasHost && !restored && !stale && !refreshFailed && enabledKnown
    }

    private func booksFeedExplanation(now: Date) -> String? {
        Self.booksFeedExplanation(status: state.feedStatuses[.books],
            stale: state.isStale(.books, budget: 120, now: now), now: now)
    }

    static func booksFeedExplanation(status: FeedStatus?, stale: Bool, now: Date) -> String? {
        guard stale || status?.lastError != nil else { return nil }
        let age = status?.observedAt.map { ageDescription(observedAt: $0, now: now) } ?? "Never observed"
        let problem = status?.lastError.map { "Refresh failed: \($0)" } ?? "Telemetry delayed"
        return "\(problem). \(age). Book switches unavailable until a successful fresh read."
    }

    static func requestBookChange(state: AppState, bookId: String, enabled: Bool,
                                  perform: @escaping @MainActor () async -> Void) async {
        if enabled {
            state.requestRaisesRisk(title: "Enable \(bookId)",
                detail: "Allow \(bookId) to open new positions with real money.", actionLabel: "Enable book",
                perform: perform)
        } else {
            await perform()
        }
    }

    private func requestSet(_ book: Book, enabled: Bool) async {
        guard canToggle(book) else { return }
        let revision = state.accountControlRevision
        await Self.requestBookChange(state: state, bookId: book.bookId, enabled: enabled) { [self] in
            guard state.accountControlRevision == revision,
                  let current = state.books?.books.first(where: { $0.bookId == book.bookId }),
                  current.host == book.host, current.enabled == book.enabled else { return }
            await set(current, enabled: enabled)
        }
    }

    private func set(_ book: Book, enabled: Bool) async {
        guard canToggle(book), let host = book.host else { return }
        let clientRequestId = UUID().uuidString
        latch.request(id: book.bookId, desired: enabled, clientRequestId: clientRequestId, at: Date())
        errors[book.bookId] = nil
        do {
            let intent = try ControlIntent.configureBook(bookId: book.bookId, host: host, enabled: enabled,
                clientRequestId: clientRequestId)
            if let error = await state.submit(intent, note: enabled ? "Enabled from Books" : "Disabled from Books") {
                latch.submissionFailed(id: book.bookId)
                errors[book.bookId] = error
            }
        } catch {
            latch.submissionFailed(id: book.bookId)
            errors[book.bookId] = error.localizedDescription
        }
    }

    private static func condition(_ candidate: Candidate?, evaluation: EvalBlock?) -> BindingCondition {
        guard let candidate else { return .unknown(missing: "candidate") }
        return BindingCondition.from(candidate: candidate, windowS: evaluation?.windowS, minK: evaluation?.minK)
    }

    private func conditionChip(_ text: String, tone: LeafTone, bookId: String) -> some View {
        StateInk(text, tone: tone)
            .accessibilityLabel(text)
            .accessibilityIdentifier("book.distance.\(bookId)")
    }

    private static func conditionTone(_ condition: BindingCondition) -> LeafTone {
        switch condition {
        case .waiting, .blocked, .unknown: return .stale
        case .observing: return .warn
        case .evaluating: return .loss
        case .intentEmitted: return .gain
        }
    }

    @ViewBuilder private func observationProgress(_ candidate: Candidate?, evaluation: EvalBlock?,
                                                 condition: BindingCondition) -> some View {
        switch condition {
        case .waiting, .unknown:
            EmptyView()
        default:
            if let k = candidate?.k, let minK = evaluation?.minK, minK > 0 {
                HStack(spacing: 12) {
                    ProgressBar(value: Double(k) / Double(minK), tone: k >= minK ? .gain : .warn)
                    Text("\(k) of \(minK)").font(LeafType.numberSmall).foregroundStyle(LeafTheme.inkMuted)
                        .fixedSize()
                }
            }
        }
    }

    @ViewBuilder private func quotePair(_ candidate: Candidate) -> some View {
        if let quote = Self.reportedQuote(candidate) {
            StateInk(quote, tone: candidate.sideYes == true ? .gain : .loss)
                .accessibilityIdentifier("book.quote.\(candidate.ticker)")
        }
    }

    static func reportedQuote(_ candidate: Candidate) -> String? {
        guard let ask = candidate.askCents, ask.isFinite, let sideYes = candidate.sideYes else { return nil }
        return "\(sideYes ? "YES" : "NO") ask \(Self.cents(ask))"
    }

    private static func edgeTone(_ candidate: Candidate) -> LeafTone {
        guard let edge = candidate.edgeCents, edge.isFinite,
              let required = candidate.edgeRequiredCents, required.isFinite else { return .stale }
        return edge >= required ? .gain : .loss
    }

    private func exitTone(_ ticket: Ticket) -> LeafTone {
        guard case let .surplus(cents) = ExitCondition.from(ticket: ticket) else { return .stale }
        return cents > 0 ? .gain : cents < 0 ? .loss : .neutral
    }

    private static func number(_ value: Double?) -> String {
        guard let value, value.isFinite else { return "Unknown" }
        return String(format: "%g", value)
    }

    private static func cents(_ value: Double?) -> String {
        guard let value, value.isFinite else { return "Unknown" }
        return String(format: "%.1f¢", value)
    }

    private static func signedCents(_ value: Double?) -> String {
        guard let value, value.isFinite else { return "Unknown" }
        return (value < 0 ? "−" : "+") + Self.cents(abs(value))
    }

    private static func side(_ sideYes: Bool?) -> String {
        sideYes.map { $0 ? "Yes" : "No" } ?? "Side unknown"
    }

    private static func humanized(_ gate: String?) -> String {
        guard let gate, !gate.isEmpty else { return "Not reported" }
        return gate.replacingOccurrences(of: "skip_", with: "")
            .replacingOccurrences(of: "_", with: " ").capitalized
    }

    private static func time(_ seconds: Double?) -> String {
        guard let seconds, seconds.isFinite, abs(seconds) < Double(Int.max / 2) else { return "Unknown" }
        let value = Int(max(0, seconds).rounded(.up))
        return String(format: "%d:%02d", value / 60, value % 60)
    }

    private static func phrase(_ condition: BindingCondition) -> String {
        switch condition {
        case let .waiting(seconds): return "Entry window opens in \(Self.time(seconds))"
        case let .observing(k, minK): return "\(k) of \(minK) observations"
        case let .evaluating(shortfall): return String(format: "Edge %.1f¢ below requirement", shortfall)
        case let .blocked(reason): return reason
        case .intentEmitted: return "Intent emitted"
        case .unknown: return "Waiting for telemetry"
        }
    }

    private func exitPhrase(_ ticket: Ticket) -> String {
        switch ExitCondition.from(ticket: ticket) {
        case let .surplus(cents): return "Exit surplus " + (cents < 0 ? "−" : "+") + String(format: "%.1f¢", abs(cents))
        case .unknown:
            guard let gate = ticket.exitGate, !gate.isEmpty else { return "Waiting for exit telemetry" }
            return gate.replacingOccurrences(of: "skip_", with: "").replacingOccurrences(of: "_", with: " ").capitalized
        }
    }
}
