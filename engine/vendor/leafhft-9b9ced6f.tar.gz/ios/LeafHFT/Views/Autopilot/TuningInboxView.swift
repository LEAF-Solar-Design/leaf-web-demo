import SwiftUI

/// Picks the transport and signer for the current mode. Demo mode never touches the network or a key.
@MainActor enum TuningInboxEnvironment {
    static func transport(_ fixtureMode: FixtureMode) -> TuningInboxTransport {
        fixtureMode.enabled ? TuningInboxFixtureTransport() : TuningInboxClient(fixtureMode: fixtureMode)
    }

    static func signingKey(_ fixtureMode: FixtureMode) -> () throws -> DecisionSigningKey? {
        { try SecureEnclaveDecisionKey.load(fixtureMode: fixtureMode) }
    }
}

/// The inbox block on the Autopilot screen: owner and tenant rows, and the presence key link.
@MainActor struct TuningInboxSection: View {
    @StateObject private var model: TuningInboxListModel
    private let fixtureMode: FixtureMode

    init(fixtureMode: FixtureMode) {
        self.fixtureMode = fixtureMode
        _model = StateObject(wrappedValue: TuningInboxListModel(transport: TuningInboxEnvironment.transport(fixtureMode)))
    }

    var body: some View {
        AutopilotSection(title: "Tuning inbox", identifier: "tuning.inbox") {
            if model.items.isEmpty && !model.loading && model.error == nil {
                Text("No tuning proposals are waiting.").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            ForEach(model.items) { item in
                NavigationLink {
                    TuningInboxItemView(proposalID: item.id, fixtureMode: fixtureMode)
                } label: {
                    TuningInboxRow(item: item)
                }
                .buttonStyle(.plain)
                .accessibilityIdentifier("tuning.inbox.row." + item.id)
            }
            if model.nextCursor != nil {
                Button("Show more") { Task { await model.loadMore() } }
                    .buttonStyle(.leafSecondary).disabled(model.loading)
                    .accessibilityIdentifier("tuning.inbox.more")
            }
            if model.loading { ProgressView("Loading tuning inbox").tint(LeafTheme.ink) }
            if let error = model.error {
                Text(error).font(LeafType.meta).accessibilityIdentifier("tuning.inbox.error")
                Button("Retry") { Task { await model.load() } }
                    .buttonStyle(.leafSecondary).disabled(model.loading)
                    .accessibilityIdentifier("tuning.inbox.retry")
            }
            NavigationLink {
                PresenceEnrollmentView(fixtureMode: fixtureMode)
            } label: {
                Label("Presence key", systemImage: "faceid").font(LeafType.meta)
            }
            .accessibilityIdentifier("tuning.presence.open")
        }
        .task { await model.load() }
    }
}

private struct TuningInboxRow: View {
    let item: TuningInboxSummary

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(item.isOwner ? "Owner" : "Tenant").font(LeafType.micro)
                        .padding(.horizontal, 6).padding(.vertical, 2)
                        .background(LeafTheme.accentFill, in: Capsule())
                    Text(item.account).font(LeafType.tickerSmall)
                }
                Text(item.cycleID + " · " + item.cycleKind.replacingOccurrences(of: "_", with: " ")).font(LeafType.meta)
                Text(item.stateLabel).font(LeafType.meta)
                    .foregroundStyle(item.state == .ready ? LeafTheme.ink : LeafTheme.inkMuted)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            Image(systemName: "chevron.right").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .accessibilityHidden(true)
        }
        .accessibilityElement(children: .combine)
    }
}

/// One item: the exact frozen plan, hashed on this phone, then Accept behind Face ID.
@MainActor struct TuningInboxItemView: View {
    @StateObject private var model: TuningInboxItemModel
    @StateObject private var loader: TuningInboxDetailLoader
    @State private var manualRefreshResult: Bool?
    private let notificationTarget: TuningInboxTarget?

    init(proposalID: String, fixtureMode: FixtureMode, notificationTarget: TuningInboxTarget? = nil) {
        self.notificationTarget = notificationTarget
        let model = TuningInboxItemModel(
            proposalID: proposalID, fixtureMode: fixtureMode,
            transport: TuningInboxEnvironment.transport(fixtureMode),
            signingKey: TuningInboxEnvironment.signingKey(fixtureMode))
        _model = StateObject(wrappedValue: model)
        _loader = StateObject(wrappedValue: TuningInboxDetailLoader(model: model))
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(manualRefreshResult.map { $0 ? "Refresh complete" : "Refresh failed" } ?? "Pull down to refresh")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("tuning.item.refresh-status")
                if let detail = model.detail {
                    AutopilotSection(title: detail.summary.isOwner ? "Owner proposal" : "Tenant proposal",
                                     identifier: "tuning.item.header") {
                        Text("Account " + detail.summary.account).font(LeafType.tickerSmall)
                        Text(detail.summary.cycleID + " · " + detail.summary.cycleKind.replacingOccurrences(of: "_", with: " "))
                        Text(detail.summary.stateLabel).font(LeafType.heading)
                            .accessibilityIdentifier("tuning.item.state")
                        if let code = detail.summary.resultCode { Text("Result: " + code).font(LeafType.meta) }
                        if !TuningAcceptGate.runnerSyncing(detail.runnerSyncAtMs, nowMs: TuningSyntax.milliseconds(Date())) {
                            Text(TuningAcceptGate.Reason.runnerNotSyncing.message)
                                .font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                                .accessibilityIdentifier("tuning.item.runner-stale")
                        }
                    }
                    if detail.plan == nil {
                        Text("The runner has not frozen a plan for this proposal yet.").font(LeafType.meta)
                    }
                }
                if let planError = model.planError {
                    Text(planError).foregroundStyle(LeafTheme.loss).accessibilityIdentifier("tuning.item.plan-error")
                }
                if let plan = model.plan {
                    TuningPlanDetailView(plan: plan) { model.markRendered(sha256: $0) }
                }
                decisionBlock
                if model.loading { ProgressView("Loading the frozen plan").tint(LeafTheme.ink) }
                if let error = model.loadError {
                    Text(error).accessibilityIdentifier("tuning.item.error")
                    Button("Retry") { Task { _ = await loader.load() } }
                        .buttonStyle(.leafSecondary).disabled(model.loading)
                        .accessibilityIdentifier("tuning.item.reload")
                }
            }
            .padding(16)
            .padding(.bottom, 112)
        }
        .scrollBounceBehavior(.always, axes: .vertical)
        .refreshable {
            manualRefreshResult = nil
            manualRefreshResult = await loader.refreshDetail()
        }
        .background(LeafTheme.ground)
        .foregroundStyle(LeafTheme.ink)
        .font(LeafType.body)
        .navigationTitle("Tuning proposal")
        .navigationBarTitleDisplayMode(.inline)
        .accessibilityIdentifier("tuning.item.scroll")
        .task { _ = await loader.load() }
        .task(id: shouldPoll) {
            guard shouldPoll else { return }
            await loader.pollDetail()
        }
    }

    // A successful Retry can supply the first detail after the initial load failed.
    // Tie polling to that detail so it starts then and stops on terminal readback.
    private var shouldPoll: Bool {
        Self.shouldPoll(summary: model.detail?.summary)
    }

    static func shouldPoll(summary: TuningInboxSummary?) -> Bool {
        guard let summary else { return false }
        return !summary.state.isTerminal || (summary.isV2 && summary.state == .executed)
    }

    @ViewBuilder private var decisionBlock: some View {
        let gate = model.gate
        let accountMismatch = model.detail.map {
            notificationTarget?.accountMismatch(fetchedAccount: $0.summary.account) == true
        } ?? false
        AutopilotSection(title: "Decision", identifier: "tuning.item.decision") {
            if accountMismatch {
                Text("This approval belongs to a different account.")
                    .foregroundStyle(LeafTheme.warn)
                    .accessibilityIdentifier("tuning.item.account-mismatch")
            }
            switch model.phase {
            case .signing:
                ProgressView("Waiting for Face ID").accessibilityIdentifier("tuning.item.signing")
            case .submitting:
                ProgressView("Sending your decision").accessibilityIdentifier("tuning.item.submitting")
            case .accepted(let code):
                Text(acceptedMessage(code))
                    .accessibilityIdentifier("tuning.item.accepted")
            case .failed(let message), .outcomeUnknown(let message):
                Text(message).foregroundStyle(LeafTheme.warn).accessibilityIdentifier("tuning.item.submit-error")
            case .idle:
                EmptyView()
            }
            if !gate.enabled, let message = gate.message, !model.phase.showsRetry {
                Text(message).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("tuning.item.gate")
            }
            if let plan = model.plan,
               notificationTarget?.planChanged(fetchedSeq: plan.document.planSeq, fetchedSHA256: plan.sha256) == true {
                Text("This plan changed after the notification was sent. Review the current plan below before approving.")
                    .foregroundStyle(LeafTheme.warn)
                    .accessibilityIdentifier("tuning.item.plan-changed")
            }
            Button("Accept with Face ID") { Task { await model.accept() } }
                .buttonStyle(.leafPrimary)
                .disabled(!gate.enabled || accountMismatch)
                .accessibilityIdentifier("tuning.item.accept")
                .accessibilityHint("Signs this exact plan with the presence key after Face ID")
            if model.phase.showsRetry {
                Button("Retry") { Task { await model.retry() } }
                    .buttonStyle(.leafSecondary)
                    .accessibilityIdentifier("tuning.item.retry")
            }
            Text(model.detail?.summary.isV2 == true ?
                 "Reject from the dashboard. Accept authorizes this change. The account envelope boot acknowledgement is separate." :
                 "Reject from the dashboard. Accept covers placement only; the retire list is not run.")
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
        }
    }

    private func acceptedMessage(_ code: String) -> String {
        if code == "fixture_sample" { return "Sample accept recorded on this phone only." }
        if let summary = model.detail?.summary, summary.isV2 {
            return summary.state == .ready ? "Approved, waiting for the writer to apply this change." : summary.stateLabel
        }
        return "Accepted. The runner will place this plan."
    }
}

// Keep detail read scheduling with this screen; the injected sleep lets tests drive
// the same polling path without wall-clock delays or any decision submissions.
@MainActor final class TuningInboxDetailLoader: ObservableObject {
    private let model: TuningInboxItemModel
    private var inFlight: Task<Bool, Never>?

    init(model: TuningInboxItemModel) {
        self.model = model
    }

    func load() async -> Bool {
        if let inFlight { return await inFlight.value }
        // The read belongs to the screen, not to any one refresh or polling caller.
        // Capture its outcome before another caller can start the next read.
        let task = Task {
            await model.load()
            let succeeded = model.loadError == nil
            inFlight = nil
            return succeeded
        }
        inFlight = task
        return await task.value
    }

    func refreshDetail() async -> Bool {
        if let inFlight { return await inFlight.value }
        switch model.phase {
        case .signing, .submitting: return false
        default:
            return await load()
        }
    }

    func pollDetail(
        sleep: (Duration) async throws -> Void = { try await Task.sleep(for: $0) }
    ) async {
        while !Task.isCancelled && TuningInboxItemView.shouldPoll(summary: model.detail?.summary) {
            do { try await sleep(.seconds(5)) } catch { return }
            guard !Task.isCancelled,
                  TuningInboxItemView.shouldPoll(summary: model.detail?.summary) else { return }
            _ = await refreshDetail()
        }
    }
}


private struct TuningPlanV2DetailView: View {
    let plan: VerifiedTuningPlan
    let document: TuningPlanV2

    private var review: TuningV2Review { TuningV2Review(plan: document) }
    private var reviewRanks: [TuningV2Review.EffectRank] {
        TuningV2Review.EffectRank.allCases.filter { rank in review.displayRows.contains { $0.effectRank == rank } }
    }
    private var creates: [TuningJSON] { document.items.filter { $0.objectValue!["kind"] == .string("create") } }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            AutopilotSection(title: "Frozen change", identifier: "tuning.v2.identity") {
                Text("Plan \(document.planSeq), \(plan.bytes.count) received bytes")
                Text("sha256 " + plan.sha256).font(LeafType.tickerSmall).textSelection(.enabled)
                    .accessibilityIdentifier("tuning.plan.sha256")
                if !plan.hashMatches {
                    Text("Advertised sha256 " + plan.advertisedSHA256 + " does not match these bytes.")
                        .foregroundStyle(LeafTheme.loss).accessibilityIdentifier("tuning.plan.mismatch")
                }
                Text("Account " + document.account + " · " + document.cycleID)
                Text("Origin: " + document.origin)
                Text("Expires " + Date(timeIntervalSince1970: TimeInterval(document.expiresAtMs) / 1000)
                    .formatted(date: .abbreviated, time: .shortened)).font(LeafType.meta)
                Text("Runner \(document.runnerHost), code \(String(document.codeSHA.prefix(12)))").font(LeafType.meta)
                Text("Generation \(document.fields["expected_generation"]!.intValue!) → \(document.fields["resulting_generation"]!.intValue!)")
                ForEach(Array(review.controlSentences.enumerated()), id: \.offset) { _, sentence in Text(sentence) }
            }
            Text(review.riskSummary)
                .accessibilityIdentifier("tuning.v2.riskSummary")
            ForEach(reviewRanks, id: \.self) { rank in
                AutopilotSection(title: rank.label,
                                 identifier: "tuning.v2.effect.\(rank.rawValue)") {
                    ForEach(review.displayRows.filter { $0.effectRank == rank }) { row in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(row.book.isEmpty ? "New engine policy" : row.book).font(LeafType.meta)
                            Text(row.engine).font(LeafType.tickerSmall)
                            Text(row.effectRank.label).font(LeafType.meta)
                            Text(row.sentence)
                            Text(row.finalState).font(LeafType.meta)
                        }
                    }
                }
            }
            ForEach(Array(creates.enumerated()), id: \.offset) { _, value in
                let item = value.objectValue!
                AutopilotSection(title: "New policy " + item["engine"]!.stringValue!,
                                 identifier: "tuning.v2.create." + item["engine"]!.stringValue!) {
                    Text(item["summary"]!.stringValue!)
                    Text("Parent: " + item["parent"]!.stringValue!)
                    Text("Parent policy sha256 " + item["parent_policy_digest"]!.stringValue!).font(LeafType.meta)
                    Text("New policy sha256 " + item["policy_digest"]!.stringValue!).font(LeafType.meta)
                    Text("Settings: " + settings(item["set"]!)).font(LeafType.meta).textSelection(.enabled)
                    Text("Resolved policy bytes").font(LeafType.meta)
                    Text(String(data: Data(base64Encoded: item["policy_bytes"]!.stringValue!)!, encoding: .utf8)!)
                        .font(LeafType.tickerSmall).textSelection(.enabled)
                }
            }
            envelopeView
            if let migration = document.migration?.objectValue { migrationView(migration) }
            AutopilotSection(title: "Approval and readback", identifier: "tuning.v2.authorization") {
                Text("Accept with Face ID signs these exact received bytes, including changes that remain off.")
                Text("Approval waits for the writer. After applying, the book must confirm every changed engine before this change is live.")
                Text("Signing this change does not replace the separate account envelope boot acknowledgement.")
            }
        }
    }

    private func settings(_ json: TuningJSON) -> String {
        let map = json.objectValue!
        return map.keys.sorted().map { key in
            let value = String(decoding: try! TuningV2Canonical.bytes(map[key]!), as: UTF8.self)
            return key + "=" + value
        }.joined(separator: "  ")
    }

    private var envelopeView: some View {
        let envelope = document.envelopeDocument.objectValue!
        let basis = document.sizingBasis.objectValue!
        let balance = basis["free_balance_cents"]!.intValue!
        return AutopilotSection(title: "Account envelope", identifier: "tuning.v2.envelope") {
            Text("Signed free balance B: " + TuningV2Review.dollars(balance))
            Text("Day-open balance: " + TuningV2Review.dollars(basis["day_open_cents"]!.intValue!))
            Text("Balance observed at UTC Unix ms \(basis["observed_at_ms"]!.intValue!)").font(LeafType.meta)
            Text("Fraction dollar equivalents below use signed balance B and scale with balance.").font(LeafType.meta)
            Text("Daily loss: " + TuningV2Review.fractionAtBalance(envelope["daily_loss_fraction"]!, balanceCents: balance))
            Text("Per order: " + TuningV2Review.fractionAtBalance(envelope["per_order_fraction"]!, balanceCents: balance))
            Text("Cluster: " + TuningV2Review.fractionAtBalance(envelope["cluster_fraction"]!, balanceCents: balance))
            Text("Drawdown brake: " + TuningV2Review.fractionAtBalance(envelope["drawdown_brake_fraction"]!, balanceCents: balance))
            Text("Drawdown stop: " + TuningV2Review.fractionAtBalance(envelope["drawdown_stop_fraction"]!, balanceCents: balance))
            Text("Cash floor: " + TuningV2Review.dollars(envelope["cash_floor_cents"]!.intValue!))
            Text("Per-book stake: " + TuningV2Review.dollars(envelope["per_book_stake_cents"]!.intValue!))
            Text("Reversal maximum open: " + TuningV2Review.dollars(envelope["reversal_max_open_cents"]!.intValue!))
            Text("Reversal budget: " + TuningV2Review.dollars(envelope["reversal_budget_cents"]!.intValue!))
            Text("Envelope sha256 " + document.fields["envelope"]!.objectValue!["digest"]!.stringValue!)
                .font(LeafType.tickerSmall).textSelection(.enabled)
        }
    }

    private func migrationView(_ migration: [String: TuningJSON]) -> some View {
        AutopilotSection(title: "Sizing migration · " + migration["book"]!.stringValue!,
                         identifier: "tuning.v2.migration") {
            Text("Legacy → cells-v3. Buy prices round up to whole cents; budget allocation floors to cents.")
            Text("Per-entry figures are at most, at the signed balance B. They scale with balance; a growing balance can increase them. Conviction, Kelly, price and remaining risk room usually reduce them.")
            Text("Source generation \(migration["generation"]!.intValue!)").font(LeafType.meta)
            Text("Source sha256 " + migration["source_digest"]!.stringValue!).font(LeafType.meta).textSelection(.enabled)
            ScrollView(.horizontal) {
                Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 12) {
                    GridRow {
                        ForEach(Array(["Engine", "Before", "After", "Today contracts", "Today cost",
                                       "Window start (UTC ms)", "Window end (UTC ms)", "Budget S",
                                       "At most per entry, at B", "Role", "Small"].enumerated()), id: \.offset) { _, title in
                            Text(title).font(LeafType.meta).bold()
                        }
                    }
                    ForEach(Array(migration["rows"]!.arrayValue!.enumerated()), id: \.offset) { _, value in
                        let row = value.objectValue!
                        GridRow {
                            Text(row["engine"]!.stringValue!).font(LeafType.tickerSmall)
                            Text("\(row["leverage_before"]!.intValue!)x")
                            Text("\(row["leverage_after"]!.intValue!)x")
                            Text(row["today_contracts"]!.stringValue!)
                            Text(TuningV2Review.dollars(row["today_cents_at_median_fill"]!.intValue!))
                            Text(String(row["window_start_ms"]!.intValue!))
                            Text(String(row["window_end_ms"]!.intValue!))
                            Text(TuningV2Review.dollars(row["new_S_cents"]!.intValue!))
                            Text(TuningV2Review.dollars(row["new_per_entry_cap_cents"]!.intValue!))
                            Text(row["role"]!.stringValue!)
                            Text(row["small"] == .bool(true) ? "Yes" : "No")
                        }
                    }
                }
                .font(LeafType.meta)
            }
            Text("Small-engine budgets together: " + TuningV2Review.dollars(migration["small_rows_sum_S_cents"]!.intValue!))
            Text("Today's shared probe budget: " + TuningV2Review.dollars(migration["small_rows_today_slice_cents"]!.intValue!))
            Text("Whole-book budgets together: " + TuningV2Review.dollars(migration["book_sum_S_cents"]!.intValue!))
            if migration["small_rows_exceed_slice"] == .bool(true) {
                Text("These engines together get more than today's shared probe budget.")
                    .font(LeafType.heading).foregroundStyle(LeafTheme.warn)
                    .accessibilityIdentifier("tuning.v2.slice-overrun")
            } else {
                Text("Small-engine budgets do not exceed today's shared probe budget.").font(LeafType.meta)
            }
        }
    }
}
/// Renders the verified document. Reports the hash it drew once it is on screen, which arms Accept.
struct TuningPlanDetailView: View {
    let plan: VerifiedTuningPlan
    let onRendered: (String) -> Void

    var body: some View {
        Group {
            if let document = plan.document.v2Plan {
                TuningPlanV2DetailView(plan: plan, document: document)
            } else if let document = plan.document.legacy {
                legacyView(document)
            }
        }
        .onAppear { onRendered(plan.sha256) }
        .onChange(of: plan.sha256) { _, value in onRendered(value) }
    }

    private func legacyView(_ document: TuningPlanDocument) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            AutopilotSection(title: "Frozen plan", identifier: "tuning.plan.identity") {
                Text("Plan \(document.planSeq), wave \(document.wave), \(plan.bytes.count) bytes")
                Text("sha256 " + plan.sha256).font(LeafType.tickerSmall).textSelection(.enabled)
                    .accessibilityIdentifier("tuning.plan.sha256")
                if !plan.hashMatches {
                    Text("Advertised sha256 " + plan.advertisedSHA256 + " does not match these bytes.")
                        .foregroundStyle(LeafTheme.loss).accessibilityIdentifier("tuning.plan.mismatch")
                }
                Text("Expires " + Date(timeIntervalSince1970: TimeInterval(document.expiresAtMs) / 1000)
                    .formatted(date: .abbreviated, time: .shortened)).font(LeafType.meta)
                Text("Runner \(document.runnerHost), code \(String(document.codeSHA.prefix(12)))").font(LeafType.meta)
                Text("Placement cap \(document.nMaxTotal)").font(LeafType.meta)
            }
            AutopilotSection(title: "Engines (\(document.engines.count))", identifier: "tuning.plan.engines") {
                ForEach(document.engines, id: \.id) { engine in
                    VStack(alignment: .leading, spacing: 2) {
                        Text(engine.id).font(LeafType.tickerSmall)
                        Text(engine.symbols.joined(separator: ", ") + " · sizing " + engine.sizing).font(LeafType.meta)
                        Text(engine.settings.map { $0.key + "=" + $0.value }.joined(separator: "  ")).font(LeafType.meta)
                        if !engine.summary.isEmpty { Text(engine.summary).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted) }
                    }
                }
            }
            AutopilotSection(title: "Cards (\(document.manifests.count))", identifier: "tuning.plan.cards") {
                ForEach(document.manifests, id: \.requestID) { card in
                    Text(card.requestID + " · \(card.byteCount) bytes").font(LeafType.meta)
                }
            }
            AutopilotSection(title: "Gates", identifier: "tuning.plan.gates") {
                if let waiver = document.gateWaiver {
                    Text("Waiver \(waiver.waiverID), cap \(waiver.capTotal)").foregroundStyle(LeafTheme.warn)
                } else {
                    ForEach(document.gates, id: \.gate) { gate in
                        Text(gate.gate + " " + gate.verdict).font(LeafType.meta)
                    }
                }
            }
            if !document.restartSteps.isEmpty {
                AutopilotSection(title: "Automatic restarts (\(document.restartSteps.count))", identifier: "tuning.plan.restarts") {
                    ForEach(document.restartSteps, id: \.stepID) { step in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(step.unit ?? "").font(LeafType.tickerSmall)
                            Text(step.ackSentence ?? "").font(LeafType.meta)
                        }
                    }
                    Text("Restarts wait for a settlement gap; a refused window parks the plan as waiting, not failed.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                }
            }
            AutopilotSection(title: "Steps (\(document.steps.count))", identifier: "tuning.plan.steps") {
                ForEach(document.steps, id: \.stepID) { step in
                    Text(step.stepID + " " + step.op + ": " + step.argv.joined(separator: " "))
                        .font(LeafType.tickerSmall).textSelection(.enabled)
                }
            }
            if !document.deferred.isEmpty {
                AutopilotSection(title: "Deferred (\(document.deferred.count))", identifier: "tuning.plan.deferred") {
                    ForEach(document.deferred, id: \.engineID) { row in
                        Text(row.engineID + ": " + row.reason).font(LeafType.meta)
                    }
                }
            }
            if !document.retire.isEmpty {
                AutopilotSection(title: "Retire list, not run by Accept", identifier: "tuning.plan.retire") {
                    Text(document.retire.joined(separator: ", ")).font(LeafType.meta)
                }
            }
        }
    }
}
