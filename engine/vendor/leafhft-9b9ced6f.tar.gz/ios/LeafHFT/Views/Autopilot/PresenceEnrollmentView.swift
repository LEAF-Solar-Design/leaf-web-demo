import SwiftUI
import UIKit

/// Enrolls the Secure Enclave presence key and shows its public half for the reviewed pins pull request.
/// Only the SPKI and its SHA-256 fingerprint are ever displayed or copied; the private key has no export.
@MainActor struct PresenceEnrollmentView: View {
    let fixtureMode: FixtureMode
    @State private var spki: Data?
    @State private var enrolled = false
    @State private var error: String?
    @State private var busy = false
    @State private var confirmingReplace = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                AutopilotSection(title: "Presence key", identifier: "presence.key") {
                    Text("Accepting a tuning plan signs it with a P-256 key that lives in this phone's Secure Enclave. Face ID is required for every signature, and adding or removing a face disables the key.")
                        .font(LeafType.meta)
                    if fixtureMode.enabled {
                        Text("The presence key is not available in demo mode.").accessibilityIdentifier("presence.demo")
                    } else if !SecureEnclaveDecisionKey.hardwareAvailable {
                        Text("This device has no Secure Enclave, so it cannot accept tuning plans.")
                            .accessibilityIdentifier("presence.unavailable")
                    } else if let spki {
                        keyDetails(spki)
                    } else if enrolled {
                        Text("A presence key exists but its public key could not be read. Replace it.")
                    } else {
                        Text("No presence key on this phone yet.").accessibilityIdentifier("presence.none")
                        Button("Create presence key") { run { _ = try SecureEnclaveDecisionKey.create(fixtureMode: fixtureMode) } }
                            .buttonStyle(.leafPrimary).disabled(busy)
                            .accessibilityIdentifier("presence.create")
                    }
                    if enrolled && !fixtureMode.enabled {
                        Button("Replace presence key", role: .destructive) { confirmingReplace = true }
                            .buttonStyle(.leafSecondary).disabled(busy)
                            .accessibilityIdentifier("presence.replace")
                    }
                    if let error {
                        Text(error).foregroundStyle(LeafTheme.warn).accessibilityIdentifier("presence.error")
                    }
                }
            }
            .padding(16)
            .padding(.bottom, 112)
        }
        .background(LeafTheme.ground)
        .foregroundStyle(LeafTheme.ink)
        .font(LeafType.body)
        .navigationTitle("Presence key")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Replace the presence key?", isPresented: $confirmingReplace, titleVisibility: .visible) {
            Button("Replace key", role: .destructive) {
                run {
                    try SecureEnclaveDecisionKey.delete(fixtureMode: fixtureMode)
                    _ = try SecureEnclaveDecisionKey.create(fixtureMode: fixtureMode)
                }
            }
        } message: {
            Text("The runner stops trusting this phone until the new fingerprint is pinned in a reviewed pull request.")
        }
        .task { refresh() }
    }

    @ViewBuilder private func keyDetails(_ spki: Data) -> some View {
        let encoded = spki.base64EncodedString()
        let fingerprint = PresenceSPKI.credentialID(spki: spki)
        VStack(alignment: .leading, spacing: 8) {
            Text("Public key (SPKI, base64)").font(LeafType.heading)
            Text(encoded).font(LeafType.tickerSmall).textSelection(.enabled)
                .accessibilityIdentifier("presence.spki")
            Button("Copy public key") { UIPasteboard.general.string = encoded }
                .buttonStyle(.leafSecondary).accessibilityIdentifier("presence.copy-spki")
            Text("Fingerprint (sha256 of the SPKI)").font(LeafType.heading)
            Text(fingerprint).font(LeafType.tickerSmall).textSelection(.enabled)
                .accessibilityIdentifier("presence.fingerprint")
            Button("Copy fingerprint") { UIPasteboard.general.string = fingerprint }
                .buttonStyle(.leafSecondary).accessibilityIdentifier("presence.copy-fingerprint")
            Text("Put both values in the reviewed pins pull request. The private key cannot leave the Secure Enclave.")
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
        }
    }

    private func run(_ action: () throws -> Void) {
        busy = true
        defer { busy = false }
        error = nil
        do { try action() } catch { self.error = DecisionSigner.message(for: error) }
        refresh()
    }

    private func refresh() {
        guard !fixtureMode.enabled, SecureEnclaveDecisionKey.hardwareAvailable else { return }
        do {
            let key = try SecureEnclaveDecisionKey.load(fixtureMode: fixtureMode)
            enrolled = key != nil
            spki = try key?.publicKeySPKI()
        } catch {
            spki = nil
            self.error = DecisionSigner.message(for: error)
        }
    }
}
