import SwiftUI
import LeafHFTCore

@MainActor struct AutopilotView: View {
    @Environment<AppState>(AppState.self) private var state
    @State private var response: AutopilotResponse?
    @State private var error: String?
    @State private var loading = false
    @State private var refresh = 0
    @ObservedObject private var router = TuningInboxRouter.shared
    @State private var openedItem: TuningInboxTarget?
    @State private var checkedAt: Date?
    @State private var refreshNote: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                TuningInboxSection(fixtureMode: state.fixtureMode)
                if let response {
                    freshness(response.view)
                    AutopilotSection(title: "Account autopilot", identifier: "autopilot.status") {
                        Text(status(response.view))
                        Text("Last reported default: \(response.toggles.enabledDefault ? "On" : "Off")")
                            .font(LeafType.heading)
                        Text("Engine overrides from the last snapshot are shown below.")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        if response.view.autopilot.togglesSource != .api {
                            Text("Last cycle used \(response.view.autopilot.togglesSource.rawValue) toggle settings.")
                                .font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                        }
                        if state.fixtureMode.enabled { Text("Sample autopilot data").font(LeafType.meta) }
                        if response.view.truncated {
                            Text("Older records were omitted from this snapshot.").font(LeafType.meta)
                        }
                    }
                    AutopilotSummary(document: response.view)
                    VerdictTimeline(engines: response.view.engines, cycles: response.view.cycles)
                    CycleStrip(cycles: response.view.cycles)
                    if let pending = response.view.pending {
                        AutopilotSection(title: "Pending wave", identifier: "autopilot.pending") {
                            Text("\(pending.cycleId) has waited \(pending.daysWaiting.formatted(.number.precision(.fractionLength(1)))) days for evidence.")
                                .accessibilityLabel("Pending cycle \(pending.cycleId), waiting \(pending.daysWaiting.formatted()) days for evidence")
                        }
                    }
                    // Controls follow the evidence of what the autopilot did, so the owner reads before switching.
                    Text(Self.switchesNote)
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        .accessibilityIdentifier("autopilot.switches.note")
                    if let switches = response.accountSwitches {
                        ForEach(switches) { entry in
                            AutopilotSwitchRow(entry: entry, fixtureMode: state.fixtureMode)
                        }
                    } else {
                        Text("Autotuner switch state is not available on this server yet.")
                            .font(LeafType.meta)
                    }
                    EvidenceBars(engines: response.view.engines)
                    LineageList(engines: response.view.engines)
                    KillList(kills: response.view.kills)
                }
                if loading && response == nil { ProgressView("Loading autopilot data").tint(LeafTheme.ink) }
                if let error, response == nil {
                    Text(error).accessibilityIdentifier("autopilot.error")
                    Button("Retry") { refresh += 1 }
                        .buttonStyle(.leafSecondary).disabled(loading)
                        .accessibilityIdentifier("autopilot.retry")
                }
            }
            .padding(16)
            .padding(.bottom, 112)
        }
        .background(LeafTheme.ground)
        .foregroundStyle(LeafTheme.ink)
        .font(LeafType.body)
        .refreshable { refresh += 1 }
        .navigationTitle("Engine autopilot")
        .navigationBarTitleDisplayMode(.inline)
        .accessibilityIdentifier("autopilot.scroll")
        .task(id: refresh) { await load() }
        // A candidate_ready or tuning_confirm_request push only opens its item; the item view fetches
        // and hashes the frozen bytes before Accept can ask for Face ID.
        .onChange(of: router.openCount, initial: true) { _, _ in
            if let target = router.consume() { openedItem = target }
        }
        .navigationDestination(item: $openedItem) { target in
            TuningInboxItemView(proposalID: target.proposalID, fixtureMode: state.fixtureMode, notificationTarget: target)
        }
    }

    private func status(_ view: AutopilotDocument) -> String {
        if view.autopilot.mirrorStatus == .waitingForLedger {
            return "This account has no ledger mirror yet"
        }
        let last = view.cycles.first.map { "Last cycle \($0.etDay): \($0.detail.isEmpty ? $0.status : $0.detail)" }
            ?? "No cycle has been reported"
        let waiting = view.autopilot.waitingReason?.replacingOccurrences(of: "_", with: " ")
            ?? (view.pending == nil ? "the next cycle" : "pending wave evidence")
        return "\(last); waiting for \(waiting)."
    }

    // Snapshot as-of time and age sit above the content; a failed refresh keeps the data and says so here.
    private func freshness(_ view: AutopilotDocument) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(Self.snapshotLine(generatedAt: view.generatedAt))
                        .font(LeafType.meta)
                        .accessibilityIdentifier("autopilot.freshness.asOf")
                    Text(Self.ageLine(generatedAt: view.generatedAt, checkedAt: checkedAt))
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        .accessibilityIdentifier("autopilot.freshness.age")
                }
                Spacer(minLength: 8)
                Button(loading ? "Checking" : "Refresh") { refresh += 1 }
                    .buttonStyle(.leafSecondary).disabled(loading)
                    .accessibilityIdentifier("autopilot.refresh")
            }
            if let refreshNote {
                Text(refreshNote).font(LeafType.meta)
                    .accessibilityIdentifier("autopilot.freshness.note")
            }
            if let error {
                Text(error).foregroundStyle(LeafTheme.warn)
                    .accessibilityIdentifier("autopilot.error")
                Text(Self.retainedLine(generatedAt: view.generatedAt)).font(LeafType.meta)
                    .accessibilityIdentifier("autopilot.error.retained")
                Button("Retry") { refresh += 1 }
                    .buttonStyle(.leafSecondary).disabled(loading)
                    .accessibilityIdentifier("autopilot.retry")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("autopilot.freshness")
    }

    static let switchesNote = "Autotuner switches: each decides whether the autopilot tunes engines for its account. They are not the trading pause; pause trading from Settings."

    private static let utcFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyy-MM-dd HH:mm 'UTC'"
        return formatter
    }()

    /// Pure: an ISO 8601 stamp as a UTC minute, nil when unreadable.
    static func utcTime(_ stamp: String) -> String? {
        AutopilotEngine.parseFillTimestamp(stamp).map { utcFormatter.string(from: $0) }
    }

    /// Pure: what stays on screen after a failed refresh.
    static func retainedLine(generatedAt: String) -> String {
        utcTime(generatedAt).map { "Still showing the snapshot as of \($0)." }
            ?? "Still showing the last snapshot; its time is not reported."
    }

    /// Pure: the snapshot's own as-of time, never the device clock.
    static func snapshotLine(generatedAt: String) -> String {
        utcTime(generatedAt).map { "Snapshot as of \($0)" } ?? "Snapshot time not reported"
    }

    /// Pure: snapshot age measured at the moment this screen last received it.
    static func ageLine(generatedAt: String, checkedAt: Date?) -> String {
        guard let checkedAt else { return "Not checked yet" }
        let checked = "checked \(utcFormatter.string(from: checkedAt))"
        guard let generated = AutopilotEngine.parseFillTimestamp(generatedAt) else {
            return "Age not reported, \(checked)"
        }
        guard let age = ageText(seconds: checkedAt.timeIntervalSince(generated)) else {
            return "Age unknown: snapshot time is after this device's clock, \(checked)"
        }
        return "\(age) old when \(checked)"
    }

    /// Pure: a compact age; nil when the age is negative by more than a minute (clock skew).
    static func ageText(seconds: TimeInterval) -> String? {
        guard seconds > -60 else { return nil }
        let minutes = Int(max(0, seconds)) / 60
        if minutes < 1 { return "Under 1 min" }
        if minutes < 60 { return "\(minutes) min" }
        let hours = minutes / 60
        if hours < 24 { return minutes % 60 == 0 ? "\(hours) h" : "\(hours) h \(minutes % 60) min" }
        return hours % 24 == 0 ? "\(hours / 24) d" : "\(hours / 24) d \(hours % 24) h"
    }

    /// Pure: what a refresh changed, judged on the newest cycle only. Nil on the first load.
    static func refreshNote(previous: AutopilotCycle?, current: AutopilotCycle?, firstLoad: Bool) -> String? {
        guard !firstLoad else { return nil }
        guard let current else { return "No cycle has been reported yet." }
        guard let at = utcTime(current.updatedAt) else {
            guard let previous, previous.cycleId == current.cycleId else {
                return "New cycle \(current.cycleId). Update time not reported."
            }
            return "No new cycle. Update time not reported."
        }
        guard let previous, previous.cycleId == current.cycleId else {
            return "New cycle \(current.cycleId), updated \(at)."
        }
        if previous.updatedAt == current.updatedAt { return "No new cycle since \(at)." }
        return "Cycle \(current.cycleId) updated \(at); no new cycle."
    }

    private func load() async {
        loading = true
        error = nil
        do {
            let value = try await Self.fetch(fixture: state.fixtureMode.enabled)
            try Task.checkCancellation()
            refreshNote = Self.refreshNote(previous: response?.view.cycles.first,
                                           current: value.view.cycles.first, firstLoad: response == nil)
            checkedAt = Date()
            response = value
        } catch {
            if !Task.isCancelled { self.error = Self.loadMessage(error) }
        }
        loading = false
    }

    static func fetch(fixture: Bool) async throws -> AutopilotResponse {
        guard fixture else { return try await AutopilotClient().fetch() }
        guard let url = Bundle.main.url(forResource: "autopilot", withExtension: "json", subdirectory: "Fixtures") else {
            throw FixtureAccessError.missingResource("autopilot")
        }
        var response = try AutopilotResponse.decode(Data(contentsOf: url))
        if response.accountSwitches == nil {
            // Older bundled fixtures predate account_switches. Derive only from their local document.
            let doc = response.toggles
            response.accountSwitches = [AutopilotAccountSwitch(
                scope: doc.accountId == "owner" ? .owner : .lane, accountId: doc.accountId,
                enabled: doc.enabledDefault, overridesOn: doc.engines.values.filter { $0 == .on }.count,
                overridesOff: doc.engines.values.filter { $0 == .off }.count)]
        }
        return response
    }

    static func loadMessage(_ error: Error) -> String {
        switch error as? DashboardClientError {
        case .http(404): return "Autopilot data is not available on this server yet"
        case .noCredential: return "Connect the dashboard in Settings to load autopilot data."
        case .unauthorized, .forbidden: return "Dashboard access is unavailable. Check Settings."
        default: return "Autopilot data could not be loaded. Try again."
        }
    }
}

@MainActor private struct AutopilotSwitchRow: View {
    @StateObject private var model: AutopilotSwitchState
    private let entry: AutopilotAccountSwitch
    private let fixtureMode: FixtureMode

    init(entry: AutopilotAccountSwitch, fixtureMode: FixtureMode) {
        self.entry = entry
        self.fixtureMode = fixtureMode
        _model = StateObject(wrappedValue: AutopilotSwitchState(confirmed: entry, fixtureMode: fixtureMode))
    }

    var body: some View {
        AutopilotSection(title: model.confirmed.label, identifier: "autopilot.switch." + model.confirmed.scope.rawValue) {
            Toggle(model.confirmed.label, isOn: Binding(
                get: { model.confirmed.enabled },
                set: { value in Task { await model.setEnabled(value) } }))
                .disabled(fixtureMode.enabled || model.pending)
                .accessibilityIdentifier("autopilot.toggle." + model.confirmed.scope.rawValue)
            if model.pending {
                ProgressView("Saving autotuner setting")
                    .accessibilityIdentifier("autopilot.switch.pending")
            }
            Text("Confirmed: \(model.confirmed.enabled ? "On" : "Off")")
                .accessibilityIdentifier("autopilot.switch.confirmed." + model.confirmed.scope.rawValue)
            Text("Engine overrides: \(model.confirmed.overridesOn) on, \(model.confirmed.overridesOff) off")
                .font(LeafType.meta)
            if let error = model.error {
                Text(error).accessibilityIdentifier("autopilot.switch.error")
                    .accessibilityAddTraits(.updatesFrequently)
                Button("Retry") { Task { await model.retry() } }
                    .buttonStyle(.leafSecondary)
                    .disabled(model.pending || fixtureMode.enabled)
                    .accessibilityIdentifier("autopilot.switch.retry")
            }
        }
        .onChange(of: entry) { _, value in model.receive(value) }
    }
}
