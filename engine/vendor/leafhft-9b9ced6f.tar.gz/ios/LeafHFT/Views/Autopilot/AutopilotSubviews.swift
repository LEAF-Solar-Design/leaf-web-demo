import SwiftUI
import Charts

struct AutopilotSection<Content: View>: View {
    let title: String
    let identifier: String
    @ViewBuilder var content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(LeafType.heading).accessibilityAddTraits(.isHeader)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: 12))
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier(identifier)
    }
}

private func verdictColor(_ decision: AutopilotDecision) -> Color {
    switch decision {
    case .promote: return LeafTheme.series2
    case .keep: return LeafTheme.series1
    case .kill: return LeafTheme.series4
    case .insufficient: return LeafTheme.series3
    }
}

struct AutopilotSummary: View {
    let document: AutopilotDocument

    /// One summary figure. `value` is nil when the data does not carry it; that renders as a muted state, never a number.
    struct Figure: Equatable {
        let value: String?
        let label: String
        let scope: String
        var missing = "Not reported"
    }

    private func count(_ decision: AutopilotDecision) -> Int {
        document.engines.filter { $0.verdicts.first?.decision == decision }.count
    }

    /// Pure: both counts come from the same snapshot but measure different things
    /// (research variants versus engines whose autotuner is effectively on), so each names its own scope.
    static func scopeFigures(population: Int, autotuning: Int, total: Int,
                             accountId: String) -> (population: Figure, autotuning: Figure) {
        (Figure(value: String(population), label: "Research population",
                scope: "Research population: \(population) of \(total) engines in this snapshot (account \(accountId)) are variants in the current autopilot generation."),
         Figure(value: String(autotuning), label: "Autotuning on",
                scope: "Autotuning on: \(autotuning) of \(total) engines in this snapshot have the autotuner on, by their own switch or the account default."))
    }

    /// Pure: whole UTC calendar days from the newest finished advance to the snapshot; nil value when none or unreadable.
    static func advanceFigure(advancedDays: [String], generatedAt: String) -> Figure {
        let label = "Days since advance"
        guard let day = advancedDays.max() else {
            return Figure(value: nil, label: label, scope: "No cycle has reached the advanced stage yet.",
                          missing: "None yet")
        }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyy-MM-dd"
        guard let advanced = formatter.date(from: day),
              let snapshot = AutopilotEngine.parseFillTimestamp(generatedAt) else {
            return Figure(value: nil, label: label, scope: "Days since advance not reported: the cycle or snapshot date is unreadable.")
        }
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let days = max(0, calendar.dateComponents([.day], from: calendar.startOfDay(for: advanced),
                                                  to: calendar.startOfDay(for: snapshot)).day ?? 0)
        return Figure(value: String(days), label: label,
                      scope: "Days since advance: from the last advanced cycle (\(day)) to this snapshot.")
    }

    static func figures(_ document: AutopilotDocument) -> (population: Figure, autotuning: Figure, advance: Figure) {
        let scope = scopeFigures(population: document.engines.filter(\.inPopulation).count,
                                 autotuning: document.engines.filter(\.toggleEffective).count,
                                 total: document.engines.count, accountId: document.accountId)
        let advance = advanceFigure(
            advancedDays: document.cycles.filter { $0.stage == "advanced" && $0.status == "done" }.map(\.etDay),
            generatedAt: document.generatedAt)
        return (scope.population, scope.autotuning, advance)
    }

    var body: some View {
        let figures = Self.figures(document)
        AutopilotSection(title: "Population at a glance", identifier: "autopilot.summary") {
            HStack(alignment: .firstTextBaseline, spacing: 20) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(figures.population.value ?? figures.population.missing).font(LeafType.numberLarge)
                    Text(figures.population.label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                }
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("autopilot.summary.population")
                figure(figures.autotuning, identifier: "autopilot.summary.autotuning")
                figure(figures.advance, identifier: "autopilot.summary.advance")
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(figures.population.scope)
                Text(figures.autotuning.scope)
                Text(figures.advance.scope)
            }
            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            .accessibilityElement(children: .combine)
            .accessibilityIdentifier("autopilot.summary.scope")
            Text("Latest verdict mix").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            GeometryReader { geometry in
                HStack(spacing: 0) {
                    ForEach(AutopilotDecision.allCases, id: \.rawValue) { decision in
                        Rectangle().fill(verdictColor(decision))
                            .frame(width: geometry.size.width * CGFloat(count(decision)) /
                                   CGFloat(max(1, document.engines.filter { !$0.verdicts.isEmpty }.count)))
                    }
                }
            }
            .frame(height: 10)
            .clipShape(Capsule())
            .accessibilityHidden(true)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], alignment: .leading) {
                ForEach(AutopilotDecision.allCases, id: \.rawValue) { decision in
                    HStack(spacing: 5) {
                        Circle().fill(verdictColor(decision)).frame(width: 6, height: 6)
                        Text(decision.rawValue.capitalized).font(LeafType.meta)
                        Text(String(count(decision))).font(LeafType.numberSmall)
                    }
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }

    // Composition figure beside the dominant count; a missing value shows as muted text, not a number.
    private func figure(_ figure: Figure, identifier: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            if let value = figure.value {
                Text(value).font(LeafType.numberSmall)
            } else {
                Text(figure.missing).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            Text(figure.label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
        }
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier(identifier)
    }
}

struct CycleStrip: View {
    let cycles: [AutopilotCycle]
    @State private var selected: AutopilotCycle?
    private var visible: [AutopilotCycle] { Array(cycles.sorted { $0.etDay < $1.etDay }.suffix(14)) }

    var body: some View {
        AutopilotSection(title: "Last 14 cycles", identifier: "autopilot.cycles") {
            if cycles.isEmpty { Text("No cycles yet.").foregroundStyle(LeafTheme.inkMuted) }
            VStack(spacing: 0) {
                HStack(spacing: 0) {
                    ForEach(visible) { cycle in
                        Button { selected = cycle } label: {
                            Image(systemName: glyph(cycle))
                                .font(LeafType.micro)
                                .foregroundStyle(color(cycle))
                                .frame(maxWidth: .infinity, minHeight: 32)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(details(cycle))
                        .accessibilityHint("Show cycle details")
                    }
                }
                HStack {
                    Text(visible.first.map { String($0.etDay.suffix(5)) } ?? "")
                    Spacer()
                    Text(visible.last.map { String($0.etDay.suffix(5)) } ?? "")
                }
                .font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
            }
            .frame(maxHeight: 56)
            if let selected {
                Text(details(selected)).font(LeafType.meta)
                    .accessibilityIdentifier("autopilot.cycle.detail")
            }
        }
    }

    private func details(_ cycle: AutopilotCycle) -> String {
        let counts = (cycle.counts ?? [:]).sorted { $0.key < $1.key }.map { key, value in
            switch value {
            case .integer(let count): return "\(key): \(count)"
            case .grouped(let groups):
                return "\(key): " + groups.sorted { $0.key < $1.key }.map { "\($0.key) \($0.value)" }.joined(separator: ", ")
            }
        }.joined(separator: "; ")
        return "\(cycle.etDay), \(cycle.stage.replacingOccurrences(of: "_", with: " ")), \(cycle.status). \(counts.isEmpty ? "No counts reported" : counts)"
    }

    private func glyph(_ cycle: AutopilotCycle) -> String {
        if cycle.status == "failed" { return "xmark" }
        if cycle.status == "waiting" { return "circle.lefthalf.filled" }
        switch cycle.stage {
        case "advanced": return "circle.fill"
        case "awaiting_execution": return "diamond.fill"
        default: return "circle"
        }
    }

    private func color(_ cycle: AutopilotCycle) -> Color {
        if cycle.status == "failed" { return LeafTheme.loss }
        if cycle.status == "waiting" { return LeafTheme.warn }
        switch cycle.stage {
        case "advanced": return LeafTheme.gain
        case "awaiting_execution": return LeafTheme.series4
        default: return LeafTheme.inkMuted
        }
    }
}

struct VerdictTimeline: View {
    let engines: [AutopilotEngine]
    let cycles: [AutopilotCycle]
    @ScaledMetric(relativeTo: .body) private var rowHeight = 36.0

    private var orderedCycles: [AutopilotCycle] { Array(cycles.sorted { $0.etDay < $1.etDay }.suffix(14)) }
    private var cycleIds: [String] { orderedCycles.map(\.cycleId) }
    private var cycleDates: [String] { orderedCycles.map(\.etDay) }
    private var dateLabelIndices: [Int] {
        let count = min(4, orderedCycles.count)
        guard count > 1 else { return Array(0..<count) }
        return (0..<count).map { Int((Double($0 * (orderedCycles.count - 1)) / Double(count - 1)).rounded()) }
    }

    private struct VerdictPoint: Identifiable {
        let id: Int
        let column: Int
        let row: Int
        let engineId: String
        let verdict: AutopilotVerdict

        var label: String { "\(engineId), \(verdict.cycleId), \(verdict.decision.rawValue)" }
        var scoreLabel: String { verdict.score.map { "Score \($0.formatted())" } ?? "No score" }
    }

    private var points: [VerdictPoint] {
        let ids = cycleIds
        var result: [VerdictPoint] = []
        for (index, engine) in engines.enumerated() {
            for verdict in engine.verdicts {
                guard let column = ids.firstIndex(of: verdict.cycleId) else { continue }
                result.append(VerdictPoint(id: result.count, column: column,
                                           row: engines.count - 1 - index,
                                           engineId: engine.engineId, verdict: verdict))
            }
        }
        return result
    }

    var body: some View {
        AutopilotSection(title: "Verdicts by cycle", identifier: "autopilot.verdicts") {
            Text("Oldest to newest. Each row is one engine.").font(LeafType.meta)
                .foregroundStyle(LeafTheme.inkMuted)
            if engines.isEmpty || cycleIds.isEmpty {
                Text("No verdicts yet.")
            } else {
                HStack(alignment: .top, spacing: 8) {
                    VerdictNameColumnLayout {
                        VStack(alignment: .leading, spacing: 0) {
                            ForEach(engines) { engine in
                                Text(engine.engineId)
                                    .font(LeafType.micro).foregroundStyle(LeafTheme.ink)
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .frame(height: rowHeight)
                                    .accessibilityLabel(engine.engineId)
                            }
                        }
                    }
                    .clipped()
                    verdictChart
                }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], alignment: .leading) {
                    ForEach(AutopilotDecision.allCases, id: \.rawValue) { decision in
                        Label(decision.rawValue.capitalized, systemImage: legendGlyph(decision))
                            .font(LeafType.micro).foregroundStyle(verdictColor(decision))
                    }
                }
            }
        }
    }

    private var verdictChart: some View {
        Chart(points) { point in
            verdictMark(point)
        }
        .chartXScale(domain: -0.5...(Double(cycleDates.count) - 0.5))
        .chartYScale(domain: -0.5...(Double(engines.count) - 0.5),
                     range: .plotDimension(startPadding: 0, endPadding: 0))
        .chartForegroundStyleScale(domain: AutopilotDecision.allCases.map(\.rawValue),
                                   range: [LeafTheme.series2, LeafTheme.series1, LeafTheme.series4, LeafTheme.series3])
        .chartLegend(.hidden)
        .chartXAxis { dateAxis }
        .chartYAxis(.hidden)
        .chartPlotStyle { plot in
            plot.frame(height: rowHeight * Double(engines.count)).clipped()
        }
        .frame(maxWidth: .infinity)
        .clipped()
    }

    private func verdictMark(_ point: VerdictPoint) -> some ChartContent {
        PointMark(x: .value("Cycle date", point.column), y: .value("Engine row", point.row))
            .foregroundStyle(by: .value("Decision", point.verdict.decision.rawValue))
            .symbol {
                Image(systemName: legendGlyph(point.verdict.decision))
                    .font(LeafType.micro)
                    .foregroundStyle(verdictColor(point.verdict.decision))
            }
            .accessibilityLabel(point.label)
            .accessibilityValue(point.scoreLabel)
    }

    private var dateAxis: some AxisContent {
        AxisMarks(values: dateLabelIndices) { value in
            AxisValueLabel(collisionResolution: .greedy) {
                if let index = value.as(Int.self), cycleDates.indices.contains(index) {
                    Text(String(cycleDates[index].suffix(5)))
                        .font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
                        .fixedSize()
                }
            }
        }
    }

    private func legendGlyph(_ decision: AutopilotDecision) -> String {
        switch decision {
        case .promote: return "triangle.fill"
        case .keep: return "circle.fill"
        case .kill: return "xmark"
        case .insufficient: return "square.fill"
        }
    }
}

private struct VerdictNameColumnLayout: Layout {
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        guard let column = subviews.first else { return .zero }
        let width = min(120, column.sizeThatFits(.unspecified).width)
        let size = column.sizeThatFits(ProposedViewSize(width: width, height: nil))
        return CGSize(width: width, height: size.height)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        subviews.first?.place(at: bounds.origin, anchor: .topLeading,
                              proposal: ProposedViewSize(width: bounds.width, height: bounds.height))
    }
}

struct EvidenceBars: View {
    let engines: [AutopilotEngine]

    // Distance to satisfying both floors, normalized so the two measures are comparable.
    private func distance(_ engine: AutopilotEngine) -> Double {
        max(abs(Double(engine.evidence.maxCellN) / 20 - 1), abs(engine.evidence.sumNEff / 40 - 1))
    }
    private var sortedEngines: [AutopilotEngine] {
        engines.sorted {
            distance($0) == distance($1) ? $0.engineId < $1.engineId : distance($0) < distance($1)
        }
    }
    private var upperBound: Double {
        max(48, engines.map { max(Double($0.evidence.maxCellN), $0.evidence.sumNEff) }.max() ?? 48) * 1.1
    }

    var body: some View {
        AutopilotSection(title: "Evidence floors", identifier: "autopilot.evidence") {
            Text("Nearest to the floors first. Cell floor 20; effective sample floor 40.")
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            if engines.isEmpty { Text("No engine evidence yet.") }
            ForEach(sortedEngines) { engine in
                VStack(alignment: .leading, spacing: 6) {
                    Text(engine.engineId).font(LeafType.heading)
                    evidenceChart(engine)
                    ViewThatFits(in: .horizontal) {
                        HStack {
                            Text("Cell \(engine.evidence.maxCellN) / 20")
                            Spacer()
                            Text("Effective \(engine.evidence.sumNEff.formatted(.number.precision(.fractionLength(0...1)))) / 40")
                        }
                        VStack(alignment: .leading, spacing: 4) {
                        Text("Cell \(engine.evidence.maxCellN) / 20")
                        Text("Effective \(engine.evidence.sumNEff.formatted(.number.precision(.fractionLength(0...1)))) / 40")
                        }
                    }
                    .font(LeafType.numberSmall)
                }
                .padding(.vertical, 6)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("\(engine.engineId), largest cell \(engine.evidence.maxCellN) of 20, effective samples \(engine.evidence.sumNEff.formatted()) of 40")
            }
        }
    }

    private func evidenceChart(_ engine: AutopilotEngine) -> some View {
        Chart {
            BarMark(x: .value("Samples", engine.evidence.maxCellN),
                    y: .value("Measure", "Cell"), height: .fixed(12))
                .foregroundStyle(LeafTheme.series1)
                .accessibilityLabel("Largest cell")
                .accessibilityValue("\(engine.evidence.maxCellN), floor 20")
            BarMark(x: .value("Samples", engine.evidence.sumNEff),
                    y: .value("Measure", "Effective"), height: .fixed(5))
                .foregroundStyle(LeafTheme.series4)
                .accessibilityLabel("Effective samples")
                .accessibilityValue("\(engine.evidence.sumNEff.formatted()), floor 40")
            RuleMark(x: .value("Cell floor", 20))
                .foregroundStyle(LeafTheme.series1)
                .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 3]))
                .accessibilityLabel("Cell floor 20")
            RuleMark(x: .value("Effective sample floor", 40))
                .foregroundStyle(LeafTheme.series4)
                .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 3]))
                .accessibilityLabel("Effective sample floor 40")
        }
        .chartXScale(domain: 0...upperBound)
        .chartYScale(domain: ["Cell", "Effective"])
        .chartXAxis(.hidden)
        .chartYAxis(.hidden)
        .frame(height: 44)
    }
}

struct LineageList: View {
    let engines: [AutopilotEngine]
    private var roots: [String] { Array(Set(engines.map(\.lineageRoot))).sorted() }

    var body: some View {
        AutopilotSection(title: "Engine lineage", identifier: "autopilot.lineage") {
            if engines.isEmpty { Text("No engines reported.") }
            ForEach(roots, id: \.self) { root in
                Text(root).font(LeafType.heading)
                VStack(alignment: .leading, spacing: 8) {
                ForEach(engines.filter { $0.lineageRoot == root }.sorted {
                    $0.generation == $1.generation ? $0.engineId < $1.engineId : $0.generation < $1.generation
                }) { engine in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 8) {
                            Circle().fill(engine.verdicts.first.map { verdictColor($0.decision) } ?? LeafTheme.inkMuted)
                                .frame(width: 7, height: 7).accessibilityHidden(true)
                            Text(engine.engineId).font(LeafType.body)
                        }
                        Text("Generation \(engine.generation) · \(engine.verdicts.first?.decision.rawValue ?? "No verdict")")
                        Text("Autopilot \(engine.toggleEffective ? "On" : "Off") · \(engine.toggle.rawValue)")
                        lastFillLine(engine)
                        if let parent = engine.parent { Text("From \(parent)") }
                    }
                    .font(LeafType.meta)
                    .padding(.leading, 12 + CGFloat(min(max(engine.generation - 1, 0), 4)) * 12)
                    .padding(.vertical, 4)
                    .accessibilityElement(children: .combine)
                }
                }
                .overlay(alignment: .leading) {
                    Rectangle().fill(LeafTheme.inkMuted.opacity(0.35)).frame(width: 1)
                        .accessibilityHidden(true)
                }
            }
        }
    }

    private func lastFillLine(_ engine: AutopilotEngine) -> some View {
        let status = engine.lastFillStatus()
        let dormant = status.dormant == true
        return Text(dormant ? status.label + " · Dormant" : status.label)
            .font(LeafType.meta)
            .foregroundStyle(dormant ? LeafTheme.warn : LeafTheme.inkMuted)
            .accessibilityIdentifier("autopilot.engine.lastFill.\(engine.engineId)")
    }
}

struct KillList: View {
    let kills: [AutopilotKill]

    var body: some View {
        AutopilotSection(title: "Kill history", identifier: "autopilot.kills") {
            if kills.isEmpty { Text("No kills reported.") }
            ForEach(Array(kills.prefix(50).enumerated()), id: \.offset) { _, kill in
                VStack(alignment: .leading, spacing: 4) {
                    Label(kill.lineageRoot, systemImage: "xmark.circle").font(LeafType.heading)
                    Text(kill.reason)
                    Text(kill.killedAt).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                }
                .padding(.vertical, 4)
                .accessibilityElement(children: .combine)
            }
        }
    }
}
