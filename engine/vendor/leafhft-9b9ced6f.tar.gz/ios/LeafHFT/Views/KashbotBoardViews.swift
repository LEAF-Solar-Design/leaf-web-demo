import Foundation
import SwiftUI

enum KashbotBrand {
    static let ground = Color.black
    static let panel = Color(red: 12 / 255, green: 14 / 255, blue: 18 / 255)
    // Kept for KashbotPortfolioWidget; now the higher-contrast slate.
    static let inkMuted = slate
    static let panelRaised = Color(red: 21 / 255, green: 24 / 255, blue: 30 / 255)
    static let leaf = Color(red: 76 / 255, green: 195 / 255, blue: 138 / 255)
    static let leafDeep = Color(red: 31 / 255, green: 74 / 255, blue: 55 / 255)
    static let ink = Color.white
    static let slate = Color(red: 184 / 255, green: 190 / 255, blue: 199 / 255)
    static let loss = Color(red: 255 / 255, green: 122 / 255, blue: 107 / 255)
    static let hairline = Color(red: 42 / 255, green: 47 / 255, blue: 54 / 255)
    static let lossDeep = Color(red: 83 / 255, green: 40 / 255, blue: 37 / 255)

    static func tone(_ value: Int) -> Color {
        value > 0 ? leaf : value < 0 ? loss : slate
    }
}

enum KashbotBoardFormat {
    static func money(_ cents: Int, signed: Bool = true, compact: Bool = false) -> String {
        let magnitude = cents.magnitude
        let sign = cents < 0 ? "-" : signed ? "+" : ""
        let dollars = String(magnitude / 100)
        if compact && magnitude >= 100_000 { return "\(sign)$\(dollars)" }
        let fraction = String(magnitude % 100)
        return "\(sign)$\(dollars).\(fraction.count == 1 ? "0" : "")\(fraction)"
    }

    static func percent(_ bps: Int) -> String {
        let amount = Decimal(bps.magnitude) / 100
        let digits = bps.magnitude < 1_000 ? 1 : 0
        return (bps < 0 ? "-" : "+")
            + amount.formatted(.number.locale(Locale(identifier: "en_US"))
                .precision(.fractionLength(digits))) + "%"
    }

    static func size(_ milli: Int) -> String {
        let magnitude = milli.magnitude
        let remainder = magnitude % 1_000
        guard remainder != 0 else { return String(magnitude / 1_000) }
        var fraction = String(remainder + 1_000).dropFirst().description
        while fraction.last == "0" { fraction.removeLast() }
        return "\(magnitude / 1_000).\(fraction)"
    }

    static func time(_ epoch: Int) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US")
        formatter.dateFormat = "h:mm a"
        return formatter.string(from: Date(timeIntervalSince1970: TimeInterval(epoch)))
    }

    static func day(_ epoch: Int) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US")
        formatter.dateFormat = "MMM d"
        return formatter.string(from: Date(timeIntervalSince1970: TimeInterval(epoch)))
    }
}

enum KashbotSymbol {
    static func short(ticker: String) -> String {
        let series = ticker.components(separatedBy: "-").first ?? ""
        return String(series.prefix(12))
    }

    static func displayed(tickers: [String]) -> [String] {
        let series = tickers.map { $0.components(separatedBy: "-").first ?? "" }
        let counts = series.reduce(into: [String: Int]()) { $0[$1, default: 0] += 1 }
        return zip(tickers, series).map { ticker, base in
            let suffix = counts[base, default: 0] > 1 ? " " + (ticker.components(separatedBy: "-").last ?? "") : ""
            return String((base + suffix).prefix(12))
        }
    }
}

struct KashbotPositionRow: View {
    let row: KashbotLiveAttributes.Row
    var isStale = false
    var symbol: String? = nil
    var hero = false

    var body: some View {
        HStack(spacing: 6) {
            Text(symbol ?? KashbotSymbol.short(ticker: row.ticker))
                .font(.system(size: hero ? 20 : 17, weight: .semibold))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            if row.state == "won" || row.state == "lost" {
                Text(row.state.uppercased())
                    .font(.system(size: 13, weight: .heavy))
                    .foregroundStyle(row.state == "won" ? KashbotBrand.leaf : KashbotBrand.loss)
            }
            Spacer(minLength: 2)
            Text(row.pnlCents.map { ($0 >= 0 ? "▲ " : "▼ ") + KashbotBoardFormat.money($0) } ?? "--")
                .font(.system(size: hero ? 40 : 26, weight: .bold, design: .rounded))
                .foregroundStyle(isStale ? KashbotBrand.slate : row.pnlCents.map { KashbotBrand.tone($0) } ?? KashbotBrand.slate)
                .monospacedDigit()
                .contentTransition(.numericText(value: Double(row.pnlCents ?? 0)))
                .animation(.default, value: row.pnlCents)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
        }
        .foregroundStyle(KashbotBrand.ink)
        .frame(height: hero ? 52 : 30)
        .accessibilityElement(children: .combine)
    }
}

struct KashbotLedgerStrip: View {
    let entries: [KashbotLiveAttributes.Entry]
    var isStale = false

    var body: some View {
        let displayed = Array(entries.prefix(4))
        let symbols = KashbotSymbol.displayed(tickers: displayed.map(\.ticker))
        if !displayed.isEmpty {
            VStack(spacing: 3) {
                Rectangle().fill(KashbotBrand.hairline).frame(height: 1)
                HStack(spacing: 4) {
                    ForEach(Array(displayed.enumerated()), id: \.offset) { index, entry in
                        VStack(spacing: 0) {
                            Text(symbols[index])
                                .font(.system(size: 13))
                                .foregroundStyle(KashbotBrand.slate)
                            Text(KashbotBoardFormat.money(entry.pnlCents))
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(isStale ? KashbotBrand.slate : KashbotBrand.tone(entry.pnlCents))
                                .monospacedDigit()
                                .contentTransition(.numericText(value: Double(entry.pnlCents)))
                                .animation(.default, value: entry.pnlCents)
                        }
                        .lineLimit(1)
                        .minimumScaleFactor(0.6)
                        .frame(maxWidth: .infinity)
                    }
                }
            }
        }
    }
}

struct KashbotLockScreenBoard: View {
    let state: KashbotLiveAttributes.ContentState
    let isStale: Bool

    var body: some View {
        VStack(spacing: 3) {
            HStack(spacing: 5) {
                Image(systemName: "leaf.fill").foregroundStyle(KashbotBrand.leaf)
                Text("KASHBOT").tracking(1.5).foregroundStyle(KashbotBrand.leaf)
                Spacer(minLength: 2)
                Text(KashbotBoardFormat.money(state.totalCents, signed: false))
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(KashbotBrand.ink)
                    .monospacedDigit()
                    .contentTransition(.numericText(value: Double(state.totalCents)))
                    .animation(.default, value: state.totalCents)
            }
            .font(.system(size: 13, weight: .heavy))
            .lineLimit(1)
            KashbotBoardRows(state: state, limit: 3, isStale: isStale)
            KashbotLedgerStrip(entries: state.ledger, isStale: isStale)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
        .background(KashbotBrand.ground)
        .dynamicTypeSize(...DynamicTypeSize.large)
    }
}

struct KashbotBoardRows: View {
    let state: KashbotLiveAttributes.ContentState
    let limit: Int
    var isStale = false

    var body: some View {
        let rows = Array(state.rows.prefix(max(0, limit)))
        let symbols = KashbotSymbol.displayed(tickers: rows.map(\.ticker))
        VStack(spacing: 1) {
            if rows.isEmpty {
                Text("No open positions")
                    .font(.system(size: 13))
                    .foregroundStyle(KashbotBrand.slate)
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                ForEach(Array(rows.enumerated()), id: \.offset) { index, row in
                    KashbotPositionRow(row: row, isStale: isStale, symbol: symbols[index], hero: state.openCount == 1)
                }
            }
        }
    }
}

struct KashbotLedgerList: View {
    let entries: [KashbotLiveAttributes.Entry]
    let limit: Int

    var body: some View {
        let displayed = Array(entries.prefix(max(0, limit)))
        let symbols = KashbotSymbol.displayed(tickers: displayed.map(\.ticker))
        VStack(spacing: 6) {
            ForEach(Array(displayed.enumerated()), id: \.offset) { index, entry in
                HStack {
                    Text(symbols[index])
                        .foregroundStyle(KashbotBrand.slate)
                    Spacer(minLength: 0)
                    Text(KashbotBoardFormat.money(entry.pnlCents))
                        .foregroundStyle(KashbotBrand.tone(entry.pnlCents))
                        .monospacedDigit()
                        .contentTransition(.numericText(value: Double(entry.pnlCents)))
                        .animation(.default, value: entry.pnlCents)
                }
                .font(.system(size: 15, weight: .semibold))
                .lineLimit(1)
                .accessibilityElement(children: .combine)
            }
        }
    }
}

struct KashbotIslandCompactLeading: View {
    let state: KashbotLiveAttributes.ContentState
    var isStale = false
    var body: some View {
        HStack(spacing: 3) {
            Image(systemName: "leaf.fill").foregroundStyle(KashbotBrand.leaf)
            Text(KashbotBoardFormat.money(state.totalCents, signed: false, compact: true))
                .foregroundStyle(isStale ? KashbotBrand.slate : KashbotBrand.ink)
                .contentTransition(.numericText(value: Double(state.totalCents)))
                .animation(.default, value: state.totalCents)
        }
        .font(.system(size: 14, weight: .semibold, design: .rounded))
        .monospacedDigit()
    }
}

struct KashbotIslandCompactTrailing: View {
    let state: KashbotLiveAttributes.ContentState
    var isStale = false
    private var cents: Int? { state.rows.isEmpty ? state.ledger.first?.pnlCents : state.rows.first?.pnlCents }
    var body: some View {
        Text(cents.map { KashbotBoardFormat.money($0) } ?? "--")
            .foregroundStyle(isStale ? KashbotBrand.slate : cents.map { KashbotBrand.tone($0) } ?? KashbotBrand.slate)
            .font(.system(size: 14, weight: .semibold, design: .rounded))
            .monospacedDigit()
            .contentTransition(.numericText(value: Double(cents ?? 0)))
            .animation(.default, value: cents)
    }
}

struct KashbotIslandMinimal: View {
    let state: KashbotLiveAttributes.ContentState
    var body: some View {
        Image(systemName: "leaf.fill").foregroundStyle(KashbotBrand.leaf)
    }
}

extension KashbotBoardSnapshot {
    static let sample: KashbotBoardSnapshot = {
        let now = Int(Date().timeIntervalSince1970)
        let entries: [KashbotLiveAttributes.Entry] = [
            .init(ticker: "KXBTC", pnlCents: 184, pnlBps: 3_700, at: now - 900),
            .init(ticker: "KXFED", pnlCents: -210, pnlBps: -10_000, at: now - 86_400),
            .init(ticker: "KXETH", pnlCents: 42, pnlBps: 420, at: now - 90_000),
            .init(ticker: "KXHIGHNY", pnlCents: -38, pnlBps: -1_900, at: now - 172_800),
            .init(ticker: "KXSPX", pnlCents: 315, pnlBps: 6_300, at: now - 259_200)
        ]
        return KashbotBoardSnapshot(state: .init(
            asOf: now, totalCents: 12_436, todayCents: 184, openCount: 3,
            rows: [
                .init(ticker: "KXBTC", label: "Bitcoin above $100k", side: "yes", milli: 4_000,
                      winCents: 152, oddsPct: 62, state: "open", pnlCents: 152),
                .init(ticker: "KXFED", label: "Fed rate cut", side: "no", milli: 250,
                      winCents: 11, oddsPct: 44, state: "open", pnlCents: 11),
                .init(ticker: "KXHIGHNY", label: "NYC above 80°", side: "yes", milli: 1_000,
                      winCents: -8, oddsPct: 28, state: "open", pnlCents: -8)
            ], ledger: Array(entries.prefix(4))), ledger: entries)
    }()
}
