import SwiftUI
import LeafHFTCore

@MainActor struct RiskyBatmanSection: View {
    @Environment<AppState>(AppState.self) private var state
    @State var store: RiskyBatmanState
    var riskEnvelope: RiskEnvelope? = nil
    @State private var hedge = RiskyHedgeModeState()
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        if !state.isOwnerExecution { content }
    }

    private var content: some View {
        Section {
            if store.engines.isEmpty || store.error != nil {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Risky Batman").font(LeafType.heading)
                    if store.loading { ProgressView("Loading Risky Batman status") }
                    if let error = store.error {
                        Text(error).foregroundStyle(LeafTheme.loss)
                            .accessibilityIdentifier("risky.error")
                    } else if !store.loading {
                        Text("No Risky Batman engines published yet.").foregroundStyle(LeafTheme.inkMuted)
                    }
                    Button("Refresh status") { Task { await store.load() } }
                        .disabled(store.loading)
                        .accessibilityIdentifier("risky.refresh")
                }
            }
            ForEach(Array(store.warnings.enumerated()), id: \.offset) { _, warning in
                Text(warning).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
            }
            if let runtimeError = store.runtimeError {
                Text(runtimeError).font(LeafType.meta).foregroundStyle(LeafTheme.stale)
                    .accessibilityIdentifier("risky.runtimeError")
            }
            ForEach(store.engines) { engine in
                RiskyBatmanCard(engine: engine, store: store)
                // Its own row, so the card (the anchor of its confirmation dialog) keeps its shape.
                if RiskyBatman.isEngine(engine.id) && !engine.isFrozen {
                    LeafCard {
                        RiskyHedgeModeBlock(engine: engine, store: store, hedge: hedge)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .accessibilityElement(children: .contain)
                    .accessibilityIdentifier("risky.hedgeMode.\(engine.id).card")
                }
            }
        }
        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
        .listRowSeparator(.hidden)
        .listRowBackground(Color.clear)
        .onAppear { store.riskEnvelope = riskEnvelope }
        .onChange(of: riskEnvelope) { _, envelope in store.riskEnvelope = envelope }
        .task(id: scenePhase) {
            guard scenePhase == .active else { return }
            await store.load()
            await hedge.refresh(store: store)
            guard !store.fixtureMode.enabled else { return }
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 15_000_000_000) }
                catch { return }
                await store.load()
                await hedge.refresh(store: store)
            }
        }
    }
}

@MainActor private struct RiskyBatmanCard: View {
    let engine: RiskyBatman.Engine
    let store: RiskyBatmanState
    @State private var confirmation: Confirmation?
    @State private var settings = false
    @State private var probing = false
    @AccessibilityFocusState private var messageFocused: Bool

    private enum Confirmation { case start, stop, halt }
    private var prefix: String { "risky.\(engine.id)" }
    private var pending: Bool { store.pending[engine.id] != nil }
    private var controlOpen: Bool { store.controls[engine.id]?.isOpen == true }
    private var control: RiskyBatman.ProbeControl { store.probeControl(for: engine) }
    private var presentation: RiskyBatman.Presentation {
        .init(variant: engine.variant, gateMinutes: engine.gateMinutes, restarted: store.restarted.contains(engine.id))
    }
    private var canStart: Bool {
        engine.variant == nil || ["stopped", "refused"].contains(engine.variant?.state ?? "")
    }
    private var confirmationTitle: String {
        switch confirmation {
        case .halt?: return "Halt \(engine.name)?"
        case .stop?: return "Stop Risky Batman tuning on your account?"
        default: return "Start offline tuning on your account? No real orders are placed. It uses much larger position sizes than your other engines."
        }
    }
    private var stateTone: LeafTone {
        switch control.tone {
        case .neutral: return .neutral
        case .active: return .gain
        case .warning: return .warn
        case .stopped: return .loss
        }
    }

    var body: some View {
        LeafCard {
            VStack(alignment: .leading, spacing: 12) {
                Text(engine.name).font(LeafType.heading).accessibilityAddTraits(.isHeader)
                if store.fixtureMode.enabled {
                    Text("Fixture data. Controls are simulated on this phone.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                }
                if !engine.isFrozen { probeBlock }
                Divider().overlay(LeafTheme.line)
                tuningBlock
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier(prefix + ".card")
        .confirmationDialog(confirmationTitle, isPresented: Binding(
            get: { confirmation != nil }, set: { if !$0 { confirmation = nil } }), titleVisibility: .visible) {
            switch confirmation {
            case .halt?:
                Button("Halt", role: .destructive) {
                    Task { await store.requestHalt(engineId: engine.id) }
                }
                .accessibilityIdentifier(prefix + ".confirmHalt")
            case .stop?:
                Button("Stop tuning", role: .destructive) {
                    Task { await store.request(engineId: engine.id, enabled: false) }
                }
                .accessibilityIdentifier(prefix + ".confirmStop")
            default:
                Button("Start tuning") {
                    Task { await store.request(engineId: engine.id, enabled: true) }
                }
                .accessibilityIdentifier(prefix + ".confirmStart")
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            if confirmation == .halt { Text("Stops new entries. Open contracts settle normally.") }
        }
        .sheet(isPresented: $settings) { RiskyBatmanSettings(engine: engine, store: store) }
        .onChange(of: store.messages[engine.id]) { _, _ in messageFocused = true }
    }

    /// The probe control: runner lifecycle, breaker meter, Probe (owner, confirm sheet) and Halt (confirm).
    private var probeBlock: some View {
        VStack(alignment: .leading, spacing: 10) {
            StateInk(control.state, tone: stateTone)
                .accessibilityLabel(control.state)
                .accessibilityIdentifier(prefix + ".state")
            Text(control.breaker).font(LeafType.meta)
                .accessibilityIdentifier(prefix + ".breaker")
            ForEach(Array(control.reasons.enumerated()), id: \.offset) { index, reason in
                Text(reason).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                    .accessibilityIdentifier(prefix + ".reason.\(index)")
            }
            if control.showsProbe {
                Button("Probe") { probing = true }
                    .buttonStyle(.leafSecondary)
                    .disabled(!control.canProbe || controlOpen || store.loading || store.error != nil)
                    .accessibilityIdentifier(prefix + ".probe")
                Text("1 contract per entry, on the operator's account, with real money.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                if let reason = control.probeBlockedReason {
                    Text(reason).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        .accessibilityIdentifier(prefix + ".probe.blocked")
                }
            }
            if control.canHalt {
                Button("Halt", role: .destructive) { confirmation = .halt }
                    .buttonStyle(.leafSecondary)
                    .disabled(store.loading || (controlOpen && store.controls[engine.id]?.kind == .halt))
                    .accessibilityIdentifier(prefix + ".halt")
            }
            if let message = store.controlMessages[engine.id] {
                Text(message).font(LeafType.meta)
                    .accessibilityIdentifier(prefix + ".probe.message")
                    .accessibilityAddTraits(.updatesFrequently)
            }
            if controlOpen {
                ProgressView("Waiting for the runner")
                Button("Refresh status") { Task { await store.load() } }
                    .disabled(store.loading)
                    .accessibilityIdentifier(prefix + ".probe.refresh")
            }
        }
        // Attached here, not beside the settings sheet, so the two sheets never share one view.
        .sheet(isPresented: $probing) { RiskyBatmanProbeSheet(engine: engine, store: store) }
    }

    /// The tenant path (engine.shadow): offline and simulated, never a verdict on live trading.
    private var tuningBlock: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(RiskyBatman.tuningTitle).font(LeafType.heading)
                .accessibilityIdentifier(prefix + ".tuning")
            Text("Simulated on this account's feed. No real orders are placed, and the result is not a live verdict.")
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            StateInk(presentation.state, tone: engine.variant == nil ? .neutral : .warn)
                .accessibilityLabel(presentation.state)
                .accessibilityIdentifier(prefix + ".tuning.state")
            tuningActions
            if let message = store.messages[engine.id] {
                Text(message).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                    .accessibilityIdentifier(prefix + ".message")
                    .accessibilityAddTraits(.updatesFrequently)
                    .accessibilityFocused($messageFocused)
            }
            if pending {
                ProgressView("Waiting for tuning status")
                Button("Refresh tuning status") { Task { await store.load() } }
                    .disabled(store.loading)
                    .accessibilityIdentifier(prefix + ".refresh")
            } else if store.messages[engine.id] != nil {
                Button("Check tuning status") { Task { await store.load() } }
                    .disabled(store.loading)
                    .accessibilityIdentifier(prefix + ".checkStatus")
            }
            Text(presentation.countdown).font(LeafType.meta)
                .accessibilityIdentifier(prefix + ".countdown")
            if let notice = presentation.restartNotice {
                Text(notice).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                    .accessibilityIdentifier(prefix + ".restarted")
            }
            if let variant = engine.variant {
                Text(RiskyBatman.tuningWarning).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                    .accessibilityIdentifier(prefix + ".warning")
                BoundedList(maxHeight: 240, identifier: prefix + ".telemetry") {
                    ForEach(presentation.rows) { row in
                        VStack(alignment: .leading, spacing: 3) {
                            Text(row.label).font(LeafType.meta)
                            Text(row.value).font(LeafType.numberSmall)
                        }
                        .foregroundStyle(LeafTheme.inkMuted)
                        .accessibilityElement(children: .combine)
                        .accessibilityIdentifier(prefix + "." + row.id)
                    }
                    ForEach(Array(variant.reasons.prefix(16).enumerated()), id: \.offset) { _, reason in
                        Text(reason).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                    }
                }
                .frame(height: 240)
            }
        }
    }

    private var tuningActions: some View {
        VStack(alignment: .leading, spacing: 10) {
            if engine.isFrozen {
                Text("Frozen simulated mirror, turned on by the operator. Nothing to adjust.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier(prefix + ".frozen")
            } else {
                if canStart {
                    Button("Start tuning") { confirmation = .start }
                        .buttonStyle(.leafSecondary)
                        .accessibilityIdentifier(prefix + ".try")
                } else {
                    Button("Stop tuning", role: .destructive) { confirmation = .stop }
                        .buttonStyle(.leafSecondary)
                        .accessibilityIdentifier(prefix + ".stop")
                }
                if engine.variant != nil {
                    Button("Adjust settings") { settings = true }
                        .buttonStyle(.leafSecondary)
                        .disabled(engine.editableKeys(envelope: store.riskEnvelope).isEmpty)
                        .accessibilityIdentifier(prefix + ".settings")
                }
            }
        }
        .disabled(pending || store.loading || store.error != nil)
    }
}

/// The owner's Probe confirm sheet. It shows exactly what is requested; the signed approval arrives with KM5.
@MainActor private struct RiskyBatmanProbeSheet: View {
    let engine: RiskyBatman.Engine
    let store: RiskyBatmanState
    @Environment(\.dismiss) private var dismiss
    @State private var sending = false

    var body: some View {
        let control = store.probeControl(for: engine)
        NavigationStack {
            Form {
                Section {
                    Text("Probe \(engine.name) with real money on the operator's account: 1 contract per entry, for up to \(RiskyBatman.probeWindowDays) days.")
                        .accessibilityIdentifier("risky.probe.summary")
                    Text("Markets: " + control.markets.joined(separator: ", "))
                        .accessibilityIdentifier("risky.probe.markets")
                    Text(control.breaker).font(LeafType.meta)
                    Text("A breaker trip suspends entries until 00:00Z. Halt stops new entries at any time; open contracts settle normally.")
                        .font(LeafType.meta)
                }
                Section {
                    Text("The signed owner approval arrives with KM5. Until then the dashboard may reject this request.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    if let message = store.controlMessages[engine.id], !sending {
                        Text(message).foregroundStyle(LeafTheme.loss)
                            .accessibilityIdentifier("risky.probe.message")
                    }
                    Button(sending ? "Sending..." : "Request probe") {
                        sending = true
                        Task {
                            let accepted = await store.requestProbe(engineId: engine.id)
                            sending = false
                            if accepted { dismiss() }
                        }
                    }
                    .disabled(sending || !control.canProbe || store.controls[engine.id]?.isOpen == true)
                    .accessibilityIdentifier("risky.probe.confirm")
                }
            }
            .accessibilityIdentifier("risky.probe.form")
            .navigationTitle("Probe")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }.disabled(sending)
                        .accessibilityIdentifier("risky.probe.cancel")
                }
            }
            .interactiveDismissDisabled(sending)
        }
    }
}

@MainActor private struct RiskyBatmanSettings: View {
    let engine: RiskyBatman.Engine
    let store: RiskyBatmanState
    @Environment(\.dismiss) private var dismiss
    @State private var values: [String: Double]
    @State private var confirming = false
    @State private var sending = false

    init(engine: RiskyBatman.Engine, store: RiskyBatmanState) {
        self.engine = engine
        self.store = store
        _values = State(initialValue: engine.effectivePolicy)
    }

    private var changes: [String: Double] {
        values.filter { engine.editableKeys(envelope: store.riskEnvelope).contains($0.key) && $0.value != engine.effectivePolicy[$0.key] }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text(RiskyBatman.restartWarning).foregroundStyle(LeafTheme.loss)
                        .accessibilityIdentifier("risky.settings.warning")
                    Text("Saving asks to run offline tuning on your account with the new settings. No real orders are placed.")
                        .font(LeafType.meta)
                }
                Section("Tuning settings") {
                    ForEach(engine.editableKeys(envelope: store.riskEnvelope), id: \.self) { key in
                        if let bound = engine.editableBound(for: key, envelope: store.riskEnvelope), let parameter = PolicyCatalog.parameter(for: key) {
                            VStack(alignment: .leading, spacing: 6) {
                                Stepper {
                                    Text(parameter.name + ": " + PolicyValueFormatter.display(values[key] ?? bound.min, parameter: parameter))
                                } onIncrement: {
                                    adjust(key, bound: bound, step: parameter.step)
                                } onDecrement: {
                                    adjust(key, bound: bound, step: -parameter.step)
                                }
                                .accessibilityIdentifier("risky.settings.\(key)")
                                Text("\(PolicyValueFormatter.display(bound.min, parameter: parameter)) to \(PolicyValueFormatter.display(bound.max, parameter: parameter))")
                                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                            }
                        }
                    }
                }
                .disabled(sending)
                Section {
                    if let message = store.messages[engine.id] {
                        Text(message).foregroundStyle(LeafTheme.loss)
                            .accessibilityIdentifier("risky.settings.message")
                            .accessibilityAddTraits(.updatesFrequently)
                    }
                    Button(sending ? "Sending..." : "Save tuning settings") { confirming = true }
                        .disabled(changes.isEmpty || sending || store.pending[engine.id] != nil || store.error != nil)
                        .accessibilityIdentifier("risky.settings.save")
                }
            }
            .accessibilityIdentifier("risky.settings.form")
            .navigationTitle("Tuning settings")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }.disabled(sending)
                }
            }
            .interactiveDismissDisabled(sending)
            .confirmationDialog("Restart the 60-minute tuning clock?", isPresented: $confirming, titleVisibility: .visible) {
                Button("Restart tuning with these settings") {
                    sending = true
                    Task {
                        let accepted = await store.request(engineId: engine.id, enabled: true, set: changes)
                        sending = false
                        if accepted { dismiss() }
                    }
                }
                .accessibilityIdentifier("risky.settings.confirm")
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Are you sure? Any change restarts the 60-minute tuning clock. No real orders are placed.")
            }
        }
    }

    private func adjust(_ key: String, bound: RiskyBatman.Bound, step: Double) {
        let next = min(bound.max, max(bound.min, (values[key] ?? bound.min) + step))
        values[key] = bound.isInt ? next.rounded() : (next * 1_000_000).rounded() / 1_000_000
    }
}

/// The hedge mode (reversal_execution_mode, plan v1.9 H2c) as the runner reports it. The owner, or a tenant whose
/// lane holds the engine (I4), may request a change through engine.configure; everyone else reads it.
@MainActor private struct RiskyHedgeModeBlock: View {
    let engine: RiskyBatman.Engine
    let store: RiskyBatmanState
    let hedge: RiskyHedgeModeState
    @Environment(AppState.self) private var app
    @State private var changing = false

    private var prefix: String { "risky.hedgeMode.\(engine.id)" }
    private var mode: RiskyBatman.HedgeMode { hedge.reportedMode(for: engine.id, store: store) }
    private var isOwner: Bool { app.kashbotStatus?.riskRegime?.id == "owner" }
    private var laneId: String? { app.kashbotStatus?.lane?.id }
    private var canChange: Bool {
        RiskyBatman.HedgeMode.canChange(isOwner: isOwner, laneId: laneId, assignment: store.runtime[engine.id]?.assignment)
    }
    private var open: Bool { hedge.isOpen(engine.id) }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Hedge mode").font(LeafType.heading)
            Text(mode.label).font(LeafType.body)
                .accessibilityIdentifier(prefix + ".value")
            Text(mode.rule).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .accessibilityIdentifier(prefix + ".rule")
            if canChange {
                Button("Change hedge mode") { changing = true }
                    .buttonStyle(.leafSecondary)
                    .disabled(open || store.loading || store.error != nil
                              || (store.fixtureMode.enabled && !store.fixtureMode.controlWalk))
                    .accessibilityIdentifier(prefix + ".change")
            } else {
                Text(RiskyHedgeModeState.readOnlyNote).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier(prefix + ".readOnly")
            }
            if let message = hedge.messages[engine.id] {
                Text(message).font(LeafType.meta)
                    .accessibilityIdentifier(prefix + ".message")
                    .accessibilityAddTraits(.updatesFrequently)
            }
            if open {
                ProgressView("Waiting for the runner")
                Button("Refresh hedge mode") {
                    Task {
                        await store.load()
                        await hedge.refresh(store: store)
                    }
                }
                .disabled(store.loading)
                .accessibilityIdentifier(prefix + ".refresh")
            }
        }
        // Attached to this block so it never shares a view with the card's other sheets.
        .sheet(isPresented: $changing) {
            RiskyHedgeModeSheet(engine: engine, current: mode, store: store, hedge: hedge,
                                isOwner: isOwner, laneId: laneId)
        }
    }
}

/// The confirm sheet: the chosen value and the one rule it follows, then Request. Nothing posts until Request.
@MainActor private struct RiskyHedgeModeSheet: View {
    let engine: RiskyBatman.Engine
    let current: RiskyBatman.HedgeMode
    let store: RiskyBatmanState
    let hedge: RiskyHedgeModeState
    let isOwner: Bool
    let laneId: String?
    @Environment(\.dismiss) private var dismiss
    @State private var choice: RiskyBatman.HedgeMode
    @State private var sending = false
    @State private var attempted = false

    init(engine: RiskyBatman.Engine, current: RiskyBatman.HedgeMode, store: RiskyBatmanState,
         hedge: RiskyHedgeModeState, isOwner: Bool, laneId: String?) {
        self.engine = engine
        self.current = current
        self.store = store
        self.hedge = hedge
        self.isOwner = isOwner
        self.laneId = laneId
        _choice = State(initialValue: current == .cashoutFirst ? .hedgeFirst : .cashoutFirst)
    }

    /// A failed or rejected request stays readable here; a request still waiting is shown on the card.
    private var failure: String? {
        hedge.sheetMessage(engine.id, attempted: attempted, sending: sending)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Now: " + current.label)
                        .accessibilityIdentifier("risky.hedgeMode.current")
                    Text("The phone asks the runner for the change. The value shown on the card is always the runner's.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                }
                Section("Hedge mode") {
                    ForEach(RiskyBatman.HedgeMode.choices, id: \.self) { option in
                        Button {
                            choice = option
                        } label: {
                            HStack {
                                Text(option.label)
                                Spacer()
                                if option == choice { Image(systemName: "checkmark") }
                            }
                        }
                        .disabled(sending)
                        .accessibilityIdentifier("risky.hedgeMode.choice.\(option.slug)")
                        .accessibilityAddTraits(option == choice ? .isSelected : [])
                    }
                }
                Section {
                    Text(choice.rule)
                        .accessibilityIdentifier("risky.hedgeMode.sentence")
                    if let failure {
                        Text(failure).foregroundStyle(LeafTheme.loss)
                            .accessibilityIdentifier("risky.hedgeMode.sheet.message")
                    }
                    Button(sending ? "Sending..." : "Request " + choice.label) {
                        attempted = true
                        sending = true
                        Task {
                            let accepted = await hedge.request(engineId: engine.id, mode: choice, store: store,
                                                               isOwner: isOwner, laneId: laneId)
                            sending = false
                            if accepted { dismiss() }
                        }
                    }
                    .disabled(sending || choice == current || hedge.isOpen(engine.id))
                    .accessibilityIdentifier("risky.hedgeMode.confirm")
                }
            }
            .accessibilityIdentifier("risky.hedgeMode.form")
            .navigationTitle("Hedge mode")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }.disabled(sending)
                        .accessibilityIdentifier("risky.hedgeMode.cancel")
                }
            }
            .interactiveDismissDisabled(sending)
        }
    }
}

/// Hedge mode requests per Risky engine. The shown value is always the runner's; a request is tracked
/// requested, then applied or rejected, by its client request id, and a rejection shows the server's reason as sent.
/// Bounded: one open request per engine, keyed by the section's at most 64 engines.
@MainActor @Observable final class RiskyHedgeModeState {
    struct Control {
        let mode: RiskyBatman.HedgeMode
        let clientRequestId: String
        var state: String
        var note: String?
        /// Request-list reads that did not contain this request; after three the outcome is reported unknown.
        var misses = 0
        var isOpen: Bool { !ControlRequestLifecycle.isTerminal(state: state) }
    }

    static let readOnlyNote = "Read only. Only the owner, or a tenant whose lane holds this engine, can change it."

    private(set) var controls: [String: Control] = [:]
    private(set) var messages: [String: String] = [:]
    /// Fixture only: the runner's reported mode for each fixture engine. The walk moves 15m to Cash out first.
    private(set) var fixtureModes: [String: RiskyBatman.HedgeMode] = [
        "risky-batman-15m": .legacy,
        "risky-batman-1h": .hedgeFirst
    ]
    @ObservationIgnored private var client: DashboardClient?
    @ObservationIgnored private var refreshing = false
    @ObservationIgnored private var sending: Set<String> = []

    func reportedMode(for engineId: String, store: RiskyBatmanState) -> RiskyBatman.HedgeMode {
        store.fixtureMode.enabled ? (fixtureModes[engineId] ?? .unknown(nil)) : .reported(by: store.runtime[engineId])
    }

    func isOpen(_ engineId: String) -> Bool { controls[engineId]?.isOpen == true }

    func sheetMessage(_ engineId: String, attempted: Bool, sending: Bool) -> String? {
        attempted && !sending ? messages[engineId] : nil
    }

    private func dashboard(_ fixtureMode: FixtureMode) -> DashboardClient {
        if let client { return client }
        let made = DashboardClient(fixtureMode: fixtureMode)
        client = made
        return made
    }

    /// Posts engine.configure with only reversal_execution_mode. A POST is a request, never proof of the mode.
    @discardableResult
    func request(engineId: String, mode: RiskyBatman.HedgeMode, store: RiskyBatmanState,
                 isOwner: Bool, laneId: String?) async -> Bool {
        guard controls[engineId]?.isOpen != true, !sending.contains(engineId) else { return false }
        let runner = store.runtime[engineId]
        guard RiskyBatman.HedgeMode.canChange(isOwner: isOwner, laneId: laneId, assignment: runner?.assignment) else {
            messages[engineId] = Self.readOnlyNote
            return false
        }
        if store.fixtureMode.enabled && !store.fixtureMode.controlWalk {
            messages[engineId] = "Controls are disabled in fixture mode."
            return false
        }
        if store.fixtureMode.enabled,
           let index = ProcessInfo.processInfo.arguments.firstIndex(of: "-LEAFHFT_HEDGE_FAILURE"),
           ProcessInfo.processInfo.arguments.indices.contains(index + 1) {
            let kind = ProcessInfo.processInfo.arguments[index + 1]
            switch kind {
            case "credential": messages[engineId] = Self.message(DashboardClientError.noCredential)
            case "http": messages[engineId] = Self.message(DashboardClientError.http(400))
            default: messages[engineId] = "The runner has not reported this engine yet. Refresh and try again."
            }
            return false
        }
        guard mode != reportedMode(for: engineId, store: store) else {
            messages[engineId] = "The runner already reports \(mode.label)."
            return false
        }
        let intent: ControlIntent
        do {
            let target = try Self.target(runner: runner, isOwner: isOwner, fixture: store.fixtureMode.enabled)
            intent = try RiskyBatman.hedgeModeIntent(engineId: engineId, mode: mode, host: target.host,
                scope: target.scope, expectedRevision: target.revision, clientRequestId: UUID())
        } catch {
            messages[engineId] = error.localizedDescription
            return false
        }
        let action = mode.label
        controls[engineId] = Control(mode: mode, clientRequestId: intent.clientRequestId ?? UUID().uuidString,
                                     state: "requested", note: nil)
        if store.fixtureMode.enabled {
            // Fixture walk: the request applies on the next refresh, as a dashboard poll would.
            messages[engineId] = RiskyBatman.controlMessage(action: action, state: "requested", note: nil)
            return true
        }
        sending.insert(engineId)
        defer { sending.remove(engineId) }
        messages[engineId] = "Sending hedge mode request..."
        do {
            let response = try await dashboard(store.fixtureMode).control(intent, note: nil)
            guard let request = response.request else {
                messages[engineId] = "Hedge mode request outcome unknown. Refresh status before sending another."
                return true
            }
            controls[engineId]?.state = request.state ?? "requested"
            controls[engineId]?.note = request.note
            messages[engineId] = RiskyBatman.controlMessage(action: action, state: request.state, note: request.note)
            return request.state?.lowercased() != "rejected"
        } catch {
            switch error as? DashboardClientError {
            case .refused(let reason):
                controls[engineId]?.state = "rejected"
                controls[engineId]?.note = reason
                messages[engineId] = RiskyBatman.controlMessage(action: action, state: "rejected", note: reason)
            case .noCredential, .unauthorized, .forbidden, .rateLimited:
                controls[engineId] = nil
                messages[engineId] = Self.message(error)
            case .http(let code) where (400..<500).contains(code):
                controls[engineId] = nil
                messages[engineId] = Self.message(error)
            default:
                // A lost response can follow an accepted POST. Keep it open so no duplicate is sent.
                messages[engineId] = "Hedge mode request outcome unknown. Refresh status to check it before sending another."
            }
            return false
        }
    }

    /// Settles open requests from the dashboard's request list; the fixture walk applies them instead.
    func refresh(store: RiskyBatmanState) async {
        guard !refreshing, controls.values.contains(where: \.isOpen) else { return }
        refreshing = true
        defer { refreshing = false }
        if store.fixtureMode.enabled {
            for (engineId, control) in controls where control.isOpen {
                controls[engineId]?.state = "applied"
                fixtureModes[engineId] = control.mode
                messages[engineId] = RiskyBatman.controlMessage(action: control.mode.label, state: "applied", note: nil)
            }
            return
        }
        do {
            let requests = try await dashboard(store.fixtureMode).controlRequests()
            for (engineId, control) in controls where control.isOpen {
                guard let request = requests.first(where: {
                    $0.clientRequestId?.lowercased() == control.clientRequestId.lowercased()
                }) else {
                    controls[engineId]?.misses += 1
                    if (controls[engineId]?.misses ?? 0) >= 3 {
                        controls[engineId]?.state = "unknown"
                        messages[engineId] = "Hedge mode request not found. Check Requests before sending it again."
                    }
                    continue
                }
                controls[engineId]?.misses = 0
                controls[engineId]?.state = request.state ?? "requested"
                controls[engineId]?.note = request.note
                messages[engineId] = RiskyBatman.controlMessage(action: control.mode.label, state: request.state,
                                                                note: request.note)
            }
        } catch is CancellationError {
            return
        } catch {
            for (engineId, control) in controls where control.isOpen {
                messages[engineId] = "Could not check the \(control.mode.label) request. " + Self.message(error)
            }
        }
    }

    /// Owner changes are global; an assigned tenant's change is scoped to its own account. The fixture has no runner
    /// host or revision, so the walk uses sample values that never leave the phone.
    private static func target(runner: LeafHFTCore.Engine?, isOwner: Bool,
                               fixture: Bool) throws -> (host: String, scope: ControlScope, revision: String) {
        if fixture { return ("sample-runner", .global, "fixture-revision") }
        guard let runner else {
            throw ControlIntent.ValidationError.invalid("The runner has not reported this engine yet. Refresh and try again.")
        }
        let host = runner.host ?? ""
        if isOwner { return (host, .global, runner.configuration?.global.revision ?? "") }
        let accountId = runner.assignment?.accountId ?? ""
        let scope = try ControlScope.account(accountId)
        let revision = runner.configuration?.accounts.first { $0.accountId == accountId }?.revision ?? ""
        return (host, scope, revision)
    }

    private static func message(_ error: Error) -> String {
        switch error as? DashboardClientError {
        case .noCredential, .unauthorized: return "Pair this phone with your dashboard account, then refresh."
        case .forbidden: return "This account cannot request this change."
        case .rateLimited: return "Too many requests. Wait before trying again."
        case .refused(let reason): return reason
        case .http(let code): return "The dashboard declined the request (\(code))."
        default: return "Check your connection and try refreshing."
        }
    }
}
