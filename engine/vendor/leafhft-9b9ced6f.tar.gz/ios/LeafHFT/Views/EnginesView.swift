import SwiftUI
import LeafHFTCore

@MainActor struct EnginesView: View {
    @Environment<AppState>(AppState.self) private var state
    @State private var action: EngineAction?
    @State private var latch = ToggleRequestLatch()
    @State private var gate = EngineControlGate()
    @State private var errors: [String: String] = [:]
    @State private var searchText = ""
    @State private var searchPresented = false
    @State private var show: EngineCatalogQuery.Show = .all
    @State private var accountId: String?
    @State private var collapsedGroups: Set<EngineCatalogGroup> = [.retired, .notStarted]
    @State private var allCollapsed = false
    @State private var toolsCollapsed = false
    @State private var orderedEngineIDs: [String] = []
    @State private var route: EngineRoute?
    @AppStorage("kashbot.engines.sort") private var sortValue = "runner"
    @AppStorage("kashbot.engines.grouped") private var grouped = true
    @AppStorage("kashbot.engines.rowDetail") private var rowDetail = "compact"

    private enum EngineRoute: Hashable {
        case detail(String), history(String), settings(String)
    }

    var body: some View {
        NavigationStack {
            TimelineView(.periodic(from: .now, by: 15)) { context in
                let enginesStale = state.enginesObservedAt.map {
                    transportStale(observedAt: $0, now: context.date)
                } ?? true
                List {
                    Section {
                        if !toolsCollapsed {
                    NavigationLink {
                        EngineLabView()
                    } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            Label("Open Engine Lab", systemImage: "testtube.2")
                                .font(LeafType.heading)
                            Text("Shared status, research, evidence, owners, and next actions")
                                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .buttonStyle(.plain)
                    .accessibilityIdentifier("engine.lab.open")
                    .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)

                    NavigationLink {
                        EngineHistoryView()
                    } label: {
                        Label("Live performance across accounts", systemImage: "chart.xyaxis.line")
                            .font(LeafType.heading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .buttonStyle(.plain)
                    .accessibilityIdentifier("engine.history.open")
                    .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)

                    NavigationLink {
                        AutopilotView()
                    } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            Label("Engine autopilot", systemImage: "arrow.triangle.branch")
                                .font(LeafType.heading)
                            Text("What it did last")
                                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        }
                    }
                    .buttonStyle(.plain)
                    .accessibilityIdentifier("engine.autopilot.open")
                    .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                    if state.dashboardPairingState != .paired {
                        LeafCard {
                            VStack(alignment: .leading, spacing: 12) {
                                SectionHeader("Actions")
                                if state.fixtureMode.enabled && !state.fixtureMode.controlWalk {
                                    Text("Controls are disabled in fixture mode.")
                                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                                }
                                HStack(spacing: 10) {
                                    ForEach(EngineAction.allCases) { item in
                                        Button { action = item } label: {
                                            Text(item.rawValue).frame(maxWidth: .infinity)
                                        }
                                        .buttonStyle(.leafSecondary)
                                        .accessibilityIdentifier("engine.control.\(item.rawValue.lowercased())")
                                    }
                                }
                                .disabled((state.fixtureMode.enabled && !state.fixtureMode.controlWalk) || state.engines?.engines?.isEmpty != false || state.submittingControl)
                            }
                        }
                        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                    }
                        }
                    } header: {
                        Button { toolsCollapsed.toggle() } label: {
                            groupHeading("Tools", expanded: !toolsCollapsed)
                        }
                        .buttonStyle(.plain)
                        .accessibilityIdentifier("engines.tools.group")
                        .accessibilityAddTraits(.isHeader)
                        .accessibilityValue(toolsCollapsed ? "Collapsed" : "Expanded")
                        .listRowInsets(EdgeInsets())
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        Text("\(state.engines?.engines?.count ?? 0) engines")
                        if query.isFiltering {
                            Text("Showing \(displayedEngines.count) of \(state.engines?.engines?.count ?? 0)")
                            Text("\(hiddenAttention(now: context.date)) halted or attention engines hidden")
                                .foregroundStyle(hiddenAttention(now: context.date) > 0 ? LeafTheme.warn : LeafTheme.inkMuted)
                            Button("Clear") {
                                searchText = ""
                                searchPresented = false
                                show = .all
                                accountId = nil
                            }
                            .accessibilityIdentifier("engines.filterClear")
                            .buttonStyle(.borderless)
                        }
                        if state.fixtureMode.enabled {
                            Text("Fixture data").font(LeafType.meta)
                        }
                        if let observed = state.enginesObservedAt {
                            Text("Observed \(observed.formatted(.relative(presentation: .named)))")
                                .font(LeafType.meta)
                                .accessibilityIdentifier("engines.observed")
                                .accessibilityValue(String(observed.timeIntervalSince1970))
                        }
                        if enginesStale {
                            Text("Delayed telemetry").font(LeafType.meta).foregroundStyle(LeafTheme.stale)
                        }
                        if let error = state.enginesError {
                            Text(error).foregroundStyle(LeafTheme.loss)
                        }
                        if state.engines?.engines?.isEmpty != false {
                            Text("No engines published yet. The runner publishes engines after its next re-arm.")
                        }
                    }
                    .foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityElement(children: .contain)
                    .accessibilityIdentifier("engines.catalog")
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)

                    LeafCard {
                        VStack(alignment: .leading, spacing: 14) {
                            SectionHeader("Requests")
                            if state.pendingRequests.isEmpty {
                                Text("No recent requests.").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                            }
                            ForEach(state.pendingRequests) { request in
                                VStack(alignment: .leading, spacing: 6) {
                                    ViewThatFits(in: .horizontal) {
                                        HStack(alignment: .top) {
                                            Text(request.kind ?? "Unknown kind").font(LeafType.heading)
                                            Spacer(minLength: 8)
                                            requestState(request.state)
                                        }
                                        VStack(alignment: .leading, spacing: 6) {
                                            Text(request.kind ?? "Unknown kind").font(LeafType.heading)
                                            requestState(request.state)
                                        }
                                    }
                                    Text(request.value?.displayValue ?? "Unknown change")
                                        .font(LeafType.body).textSelection(.enabled)
                                    Text(request.id).font(LeafType.micro).foregroundStyle(LeafTheme.inkMuted)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
                    }
                    .accessibilityElement(children: .contain)
                    .accessibilityIdentifier("engines.requests")
                    .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)

                    if displayedEngines.isEmpty {
                        if query.isFiltering && state.engines?.engines?.isEmpty == false {
                        ContentUnavailableView.search(text: query.text)
                            .accessibilityIdentifier("engines.empty")
                        }
                    } else if grouped {
                        ForEach(EngineCatalogGroup.grouped(displayedEngines)) { section in
                            catalogSection(section, now: context.date)
                        }
                    } else {
                        Section {
                            if !allCollapsed || !query.text.isEmpty {
                                ForEach(displayedEngines) { engine in
                                    engineRow(engine, now: context.date)
                                }
                            }
                        } header: {
                            Button { if query.text.isEmpty { allCollapsed.toggle() } } label: {
                                groupHeading("ALL ENGINES · \(displayedEngines.count)",
                                             expanded: !allCollapsed || !query.text.isEmpty)
                            }
                            .buttonStyle(.plain)
                            .accessibilityIdentifier("engines.catalog.group.all")
                            .accessibilityAddTraits(.isHeader)
                            .accessibilityValue(!allCollapsed || !query.text.isEmpty ? "Expanded" : "Collapsed")
                            .accessibilityHint(query.text.isEmpty ? "" : "Clear the search to collapse")
                            .listRowInsets(EdgeInsets())
                        }
                    }

                    RiskyBatmanSection(store: RiskyBatmanState(fixtureMode: state.fixtureMode),
                                       riskEnvelope: state.engines?.riskEnvelope)

                    if let lab = state.engineLab, !lab.candidates.isEmpty {
                        FlatCard(title: "Offline tuning (simulated)", trailing: "Not live results") {
                            BoundedList(maxHeight: 300, identifier: "engines.paper.rows") {
                                ForEach(lab.candidates) { candidate in
                                    paperLink(candidate)
                                    Divider().overlay(LeafTheme.line)
                                }
                            }
                            .frame(height: 300)
                            if lab.stale || state.engineLabError != nil {
                                Text("Offline tuning evidence is delayed.").font(LeafType.meta).foregroundStyle(LeafTheme.stale)
                            }
                        }
                        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                    } else {
                        Text("Offline tuning (simulated) unavailable. Open Engine Lab to refresh evidence.")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                            .listRowSeparator(.hidden)
                            .listRowBackground(Color.clear)
                    }

                    LeafCard { assignments }
                    .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)



                }
                .accessibilityIdentifier("engines.list")
                .listStyle(.plain)
                .contentMargins(.bottom, 80, for: .scrollContent)
                .refreshable {
                    await state.refreshEngines()
                    updateCatalog()
                }
                .searchable(text: $searchText, isPresented: $searchPresented, placement: .navigationBarDrawer(displayMode: .automatic),
                            prompt: "Name, ID, book, market or account")
                .navigationDestination(item: $route) { destination in
                    switch destination {
                    case .detail(let id):
                        if let engine = state.engines?.engines?.first(where: { $0.engineId == id }) {
                            engineDetail(engine)
                        } else {
                            EngineDetailView(engineId: id, scopedAccountId: scopedAccount?.id) { EmptyView() }
                        }
                    case .history(let id): EngineHistoryView(engineId: id)
                    case .settings(let id): EngineSettingsView(engineId: id, initialAccountId: scopedAccount?.id)
                    }
                }
                .leafScreenBackground()
                .font(LeafType.body)
                .foregroundStyle(LeafTheme.ink)
                .onChange(of: context.date) { _, _ in reconcileRequestedStates() }
                .onChange(of: suspensionFingerprint(now: context.date)) { _, _ in updateCatalog() }
                .toolbarBackground(LeafTheme.ground, for: .navigationBar)
                .toolbarBackground(.visible, for: .navigationBar)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) { catalogMenu }
                    ToolbarItem(placement: .principal) {
                        HStack(spacing: 12) {
                            Text("Engines").font(LeafType.title)
                            LiveDot(fresh: !enginesStale)
                        }
                    }
                }
            }
            .navigationTitle("Engines")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(item: $action) { EngineControlSheet(action: $0) }
            .onAppear { updateCatalog() }
            .onChange(of: query) { _, _ in updateCatalog() }
            .onChange(of: catalogControlFingerprint) { _, _ in updateCatalog() }
            .onChange(of: grouped) { _, _ in updateCatalog() }
            .onChange(of: errors) { _, _ in updateCatalog() }
            .onChange(of: latch.entries) { _, _ in updateCatalog() }
            .transaction { $0.animation = nil }
            .onChange(of: engineStateFingerprint) { _, _ in reconcileRequestedStates() }
        }
        .confirmationDialog(gate.pending?.title ?? "", isPresented: Binding(get: { gate.pending != nil }, set: { if !$0 { gate.dismiss() } }), titleVisibility: .visible, presenting: gate.pending) { c in
            Button(c.confirmLabel, role: c.isDestructive ? .destructive : nil) { Task { await send(c) } }
                .accessibilityIdentifier("engine.control.confirm")
            Button("Cancel", role: .cancel) { gate.cancel() }
                .accessibilityIdentifier("engine.control.cancel")
        } message: { c in
            Text(c.message)
        }
        .sensoryFeedback(.success, trigger: gate.successTick)
        .sensoryFeedback(.error, trigger: gate.failureTick)
    }

    private var query: EngineCatalogQuery {
        EngineCatalogQuery(text: searchText, sort: EngineCatalogQuery.Sort(rawValue: sortValue) ?? .runner,
                           show: show, accountId: accountId)
    }

    private func attentionReason(_ engine: Engine, now: Date) -> String? {
        EngineCatalogQuery.attentionReason(engine, now: now, error: errors[engine.engineId],
            pending: controlPending(engine) != nil || latch.entries[engine.engineId] != nil)
    }

    private func updateCatalog() {
        let engines = state.engines?.engines ?? []
        let now = Date()
        let labels = (state.engines?.accounts ?? []).reduce(into: [String: String]()) { $0[$1.id] = $1.label }
        orderedEngineIDs = query.apply(engines, accountLabels: labels, now: now, enabled: engineEnabled,
                                       attention: { attentionReason($0, now: now) != nil }).map(\.engineId)
    }

    private var displayedEngines: [Engine] {
        let current = (state.engines?.engines ?? []).reduce(into: [String: Engine]()) {
            $0[$1.engineId] = $1
        }
        return orderedEngineIDs.compactMap { current[$0] }
    }

    private var catalogControlFingerprint: String {
        let engines = state.engines?.engines ?? []
        let labels = (state.engines?.accounts ?? []).reduce(into: [String: String]()) { $0[$1.id] = $1.label }
        let telemetry = EngineCatalogQuery.fingerprint(engines, accountLabels: labels)
        let controls = engines.map { engine in
            "\(engine.engineId):\(String(describing: engineEnabled(engine))):\(String(describing: controlPending(engine)))"
        }.joined(separator: "|")
        return "\(telemetry)|\(controls)"
    }

    private func suspensionFingerprint(now: Date) -> [Bool] {
        (state.engines?.engines ?? []).map { ($0.lifecycle?.entriesSuspendedUntil ?? .distantPast) > now }
    }

    private func hiddenAttention(now: Date) -> Int {
        let visible = Set(displayedEngines.filter { engine in
            !query.text.isEmpty || (grouped ? !collapsedGroups.contains(EngineCatalogGroup.of(engine)) : !allCollapsed)
        }.map(\.engineId))
        return (state.engines?.engines ?? []).filter {
            !visible.contains($0.engineId) && attentionReason($0, now: now) != nil
        }.count
    }

    private var catalogMenu: some View {
        Menu {
            Picker("Sort", selection: $sortValue) {
                ForEach(EngineCatalogQuery.Sort.allCases, id: \.rawValue) { Text($0.title).tag($0.rawValue) }
            }
            .pickerStyle(.menu)
            Picker("Show", selection: $show) {
                ForEach(EngineCatalogQuery.Show.allCases, id: \.rawValue) { Text($0.title).tag($0) }
            }
            .pickerStyle(.menu)
            if (state.engines?.accounts?.count ?? 0) > 1 {
                Picker("Account", selection: $accountId) {
                    Text("All accounts").tag(Optional<String>.none)
                    ForEach((state.engines?.accounts ?? []).filter { $0.configurable && $0.id != "unassigned" }) {
                        Text($0.label).tag(Optional($0.id))
                    }
                    Text("Unassigned").tag(Optional("unassigned"))
                }
                .pickerStyle(.menu)
            }
            Toggle("Group by lifecycle", isOn: $grouped)
            Picker("Row detail", selection: $rowDetail) {
                Text("Compact").tag("compact")
                Text("Detailed").tag("detailed")
            }
            .pickerStyle(.menu)
            Button("Expand all") {
                collapsedGroups.removeAll()
                allCollapsed = false
            }
            Button("Collapse all") {
                collapsedGroups = Set(EngineCatalogGroup.allCases)
                allCollapsed = true
            }
        } label: {
            Label("Sort and filter", systemImage: "line.3.horizontal.decrease")
        }
        .accessibilityIdentifier("engines.sortMenu")
    }

    private func groupHeading(_ title: String, expanded: Bool) -> some View {
        HStack {
            Text(title).font(LeafType.micro)
            Spacer()
            Image(systemName: expanded ? "chevron.down" : "chevron.right").accessibilityHidden(true)
        }
        .foregroundStyle(LeafTheme.inkMuted)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 8)
        .padding(.horizontal, 16)
        .background(LeafTheme.ground)
        .contentShape(Rectangle())
    }

    @ViewBuilder private func catalogSection(_ section: EngineCatalogSection, now: Date) -> some View {
        let expanded = !collapsedGroups.contains(section.group) || !query.text.isEmpty
        Section {
            if expanded {
                ForEach(section.engines) { engine in
                    engineRow(engine, now: now)
                }
            }
        } header: {
            Button {
                guard query.text.isEmpty else { return }
                if !collapsedGroups.insert(section.group).inserted { collapsedGroups.remove(section.group) }
            } label: {
                groupHeading("\(section.group.title.uppercased()) · \(section.engines.count)", expanded: expanded)
            }
            .buttonStyle(.plain)
            .accessibilityAddTraits(.isHeader)
            .accessibilityIdentifier("engines.catalog.group.\(section.group.rawValue)")
            .accessibilityValue(expanded ? "Expanded" : "Collapsed")
            .accessibilityHint(query.text.isEmpty ? "" : "Clear the search to collapse")
            .listRowInsets(EdgeInsets())
        }
    }

    private var assignments: some View {
        let engines = state.engines?.engines ?? []
        let summary = EngineAccountChip.assignmentSummary(engines: engines, board: state.probeBoard)
        let assigned = engines.filter { $0.assignment?.accountId?.isEmpty == false }.count
        let probing = engines.filter { EngineCatalogGroup.of($0) == .probing }.count
        return VStack(alignment: .leading, spacing: 12) {
            SectionHeader("Assignments", trailing: engines.isEmpty ? nil : "\(assigned) assigned · \(probing) probing")
            if engines.isEmpty {
                Text("Assignments not reported.").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            ForEach(summary.engines) { engine in
                ViewThatFits(in: .horizontal) {
                    HStack(alignment: .center, spacing: 8) {
                        Text(engine.name ?? engine.engineId).font(LeafType.body)
                        Spacer(minLength: 8)
                        EngineAccountChip(engine: engine, accounts: state.engines?.accounts ?? [],
                                          boundAccountIds: summary.boundAccountIds[engine.engineId] ?? [])
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Text(engine.name ?? engine.engineId).font(LeafType.body)
                        EngineAccountChip(engine: engine, accounts: state.engines?.accounts ?? [],
                                          boundAccountIds: summary.boundAccountIds[engine.engineId] ?? [])
                    }
                }
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("engines.assignment.\(engine.engineId)")
            }
            if summary.unassignedCount > 0 {
                Text("\(summary.unassignedCount) unassigned")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("engines.assignments.unassigned")
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("engines.assignments")
    }

    private func accountChip(_ engine: Engine) -> EngineAccountChip {
        EngineAccountChip(engine: engine, accounts: state.engines?.accounts ?? [],
                          boundAccountIds: EngineAccountChip.boundAccountIds(engine: engine, board: state.probeBoard))
    }

    @ViewBuilder private func rowChips(_ engine: Engine, now: Date) -> some View {
        EngineLifecycleChip(lifecycle: engine.lifecycle, eligibility: engine.eligibleToProbe, now: now)
            .accessibilityIdentifier("engine.lifecycle.\(engine.engineId)")
        accountChip(engine)
            .accessibilityIdentifier("engine.account.\(engine.engineId)")
    }

    private func engineRow(_ engine: Engine, now: Date) -> some View {
        EngineCatalogRow(engine: engine, now: now, enabled: engineEnabled(engine),
                         detailed: rowDetail == "detailed", attention: attentionReason(engine, now: now),
                         open: { route = .detail(engine.engineId) },
                         detail: { detailedRow(engine, now: now) },
                         entryToggle: { engineToggle(engine) })
            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                Button("Performance") { route = .history(engine.engineId) }
                Button("Configure") { route = .settings(engine.engineId) }
            }
            .contextMenu {
                Button("Copy engine ID") { UIPasteboard.general.string = engine.engineId }
                Button("Performance") { route = .history(engine.engineId) }
                Button("Configure") { route = .settings(engine.engineId) }
            }
            .listRowBackground(LeafTheme.ground)
            .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
    }

    private func detailedRow(_ engine: Engine, now: Date) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            OneLine("\(engine.engineId) · \(number(engine.pnl?.ticketsPerHour)) / h · \(engine.pnl?.open.map(String.init) ?? "Unknown") open")
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            accountChip(engine)
                .accessibilityIdentifier("engine.account.\(engine.engineId)")
            Text(EngineRuntimeText.breaker(engine))
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("engine.breaker.\(engine.engineId)")
            Text(EngineRuntimeText.perContract(engine))
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("engine.perContract.\(engine.engineId)")
            if let day = EngineRuntimeText.probeDay(engine.probeToday) {
                Text(day)
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("engine.probeDay.\(engine.engineId)")
            }
            ViewThatFits(in: .horizontal) {
                HStack(spacing: 10) {
                    engineState(engine)
                    Spacer(minLength: 0)
                    EnginePnlValue(cents: engine.pnl?.netCents, numeral: .number)
                }
                VStack(alignment: .leading, spacing: 6) {
                    engineState(engine)
                    EnginePnlValue(cents: engine.pnl?.netCents, numeral: .number)
                }
            }
            EngineWinRateBar(rate: engineWinRate(engine), perTicket: signedCents(engine.pnl?.perTicketCents))
            engineGainSummary(engine)
            if let candidate = state.engineLab?.candidates.first(where: { $0.engineId == engine.engineId }) {
                Text("Live account results above. Offline tuning below is simulated.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                paperLink(candidate, showName: false)
            }
            Text(EngineCatalogQuery.entryText(engineEnabled(engine)))
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .accessibilityIdentifier("engine.entries.\(engine.engineId)")
            Text(profitDials(engine))
                .font(LeafType.meta)
                .foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("engine.profitDials.\(engine.engineId)")
            if let error = errors[engine.engineId] {
                Text(error).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
            }
        }
    }

    private func paperLink(_ candidate: EngineLab.Candidate, showName: Bool = true) -> some View {
        let results = candidate.paperResults
        return NavigationLink {
            EngineLabCandidateDetail(candidateId: candidate.id)
        } label: {
            VStack(alignment: .leading, spacing: 6) {
                if showName { Text(candidate.name).font(LeafType.heading) }
                Text("\(candidate.paperModeLabel) · \(results.statusLabel)")
                Text(results.countsLabel)
                Text(results.simulatedPnLLabel)
                Label("Offline tuning in Lab", systemImage: "testtube.2")
            }
            .font(LeafType.meta)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("engine.paper.\(showName ? "candidate" : "status").\(candidate.id)")
    }

    private func compactLabel(_ engine: Engine) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(engine.name ?? engine.engineId).font(LeafType.heading)
            OneLine("\(engine.engineId) · \(number(engine.pnl?.ticketsPerHour)) / h · \(engine.pnl?.open.map(String.init) ?? "Unknown") open")
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
    }

    private func engineState(_ engine: Engine) -> some View {
        StateInk(engineEnabled(engine).map { $0 ? "Accepting" : "Paused" } ?? "Unknown",
            tone: engineEnabled(engine) == true ? .gain : .stale,
            symbol: engineEnabled(engine).map { $0 ? "checkmark" : "pause" } ?? "questionmark")
    }

    private func engineWinRate(_ engine: Engine) -> Double? {
        guard let n = engine.pnl?.n, n > 0, let won = engine.pnl?.won else { return nil }
        return Double(won) / Double(n)
    }

    private func signedCents(_ value: Double?) -> String {
        guard let value, value.isFinite else { return "Unknown" }
        return (value > 0 ? "+" : "") + number(value) + "¢"
    }

    private func engineGainSummary(_ engine: Engine) -> some View {
        let pnl = engine.pnl
        let win = signedGainPercent(pnl?.avgWinGainPct)
        let closed = signedGainPercent(pnl?.avgClosedGainPct)
        let winCount = pnl?.winGainN.map(String.init) ?? "—"
        let closedCount = pnl?.closedGainN.map(String.init) ?? "—"
        let noClosedTrades = pnl?.winGainN == 0 && pnl?.closedGainN == 0
        return Group {
            if noClosedTrades {
                Text("No closed trades yet")
            } else {
                Text("Avg win ") +
                Text(win).foregroundColor(gainColor(pnl?.avgWinGainPct)) +
                Text(" (\(winCount)) · All trades ") +
                Text(closed).foregroundColor(gainColor(pnl?.avgClosedGainPct)) +
                Text(" (\(closedCount))")
            }
        }
        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
        .fixedSize(horizontal: false, vertical: true)
        .accessibilityLabel(noClosedTrades ? "No closed trades yet" :
            "Average gain on winning closed trades: \(win), \(pnl?.winGainN.map(String.init) ?? "unknown") winning trades. Average gain on all closed trades and cashouts: \(closed), \(pnl?.closedGainN.map(String.init) ?? "unknown") closed trades.")
        .accessibilityIdentifier("engine.gainSummary.\(engine.engineId)")
    }

    private func signedGainPercent(_ value: Double?) -> String {
        guard let value, value.isFinite else { return "Unavailable" }
        return String(format: "%+.1f%%", value)
    }

    private func gainColor(_ value: Double?) -> Color {
        guard let value, value.isFinite else { return LeafTheme.inkMuted }
        return value > 0 ? LeafTheme.gain : value < 0 ? LeafTheme.loss : LeafTheme.inkMuted
    }

    @ViewBuilder private func requestState(_ value: String?) -> some View {
        switch value?.lowercased() {
        case "applied": StateInk(value ?? "Applied", tone: .gain, symbol: "checkmark")
        case "rejected": StateInk(value ?? "Rejected", tone: .loss, symbol: "xmark")
        case "pending", "requested": StateInk(value ?? "Pending", tone: .warn, symbol: "clock")
        default: StateInk(value ?? "Unknown state", tone: .stale)
        }
    }

    /// The detail owns everything but the enable toggle, which shares this list's request latch.
    private func engineDetail(_ engine: Engine) -> some View {
        EngineDetailView(engineId: engine.engineId, scopedAccountId: scopedAccount?.id) {
            VStack(alignment: .leading, spacing: 8) {
                engineToggle(engine, labeled: true)
                Text(engineEnabled(engine).map { $0 ? "This engine can open new positions." : "New entries are paused. Existing positions keep their normal exit and risk handling." } ?? "Entry state unknown. Enabled telemetry has not been published.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                if let error = errors[engine.engineId] {
                    Text(error).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                }
            }
        }
    }

    private func profitDials(_ engine: Engine) -> String {
        let policy = accountConfiguration(engine)?.effective.policy ?? engine.configuration?.global.policy ?? engine.policy ?? [:]
        let groups: [(String, [(String, String)])] = [
            ("Position", [("size_fraction", "Size"), ("per_order_fraction", "Order cap")]),
            ("Entry", [("edge_threshold_cents", "Edge"), ("min_k", "Observations")]),
            ("Price", [("min_price_cents", "Min"), ("max_price_cents", "Max")]),
            ("Exit", [("exit_min_hold_s", "Hold"), ("exit_margin_cents", "Margin")]),
            ("Risk", [("daily_loss_fraction", "Daily loss"), ("drawdown_stop_fraction", "Drawdown stop")])
        ]
        return groups.map { title, fields in
            let values = fields.compactMap { key, label -> String? in
                guard let value = policy[key], let parameter = PolicyCatalog.parameter(for: key) else { return nil }
                return "\(label) \(PolicyValueFormatter.display(value, parameter: parameter))"
            }
            return "\(title): " + (values.isEmpty ? "Not published" : values.joined(separator: " · "))
        }.joined(separator: "\n")
    }

    @ViewBuilder private func engineToggle(_ engine: Engine, labeled: Bool = false) -> some View {
        let binding = Binding(get: { engineEnabled(engine) == true },
            set: { enabled in requestToggle(engine, enabled: enabled) })
        if engineEnabled(engine) == nil {
            Text("Unknown").font(LeafType.meta).foregroundStyle(LeafTheme.stale)
                .accessibilityLabel("\(engine.name ?? engine.engineId) entry state unknown")
                .accessibilityIdentifier("engine.enabledUnknown.\(engine.engineId)")
        } else if labeled {
            Toggle("Engine enabled", isOn: binding)
                .tint(LeafTheme.gain)
                .disabled(!canToggle(engine))
                .accessibilityIdentifier("engine.toggle.\(engine.engineId)")
        } else {
            Toggle("", isOn: binding).labelsHidden()
                .tint(LeafTheme.gain)
                .disabled(!canToggle(engine))
                .accessibilityLabel("\(engine.name ?? engine.engineId) enabled")
                .accessibilityIdentifier("engine.toggle.\(engine.engineId)")
        }
    }

    private func engineEnabled(_ engine: Engine) -> Bool? {
        if let entry = latch.entries[engine.engineId] { return entry.desired }
        if let account = accountConfiguration(engine) { return account.effective.enabled }
        return engine.configuration?.global.enabled
    }

    private var engineStateFingerprint: String {
        let engines = (state.engines?.engines ?? []).sorted { $0.engineId < $1.engineId }
            .map { engine in
                let observed = accountConfiguration(engine)?.effective.enabled ?? engine.configuration?.global.enabled
                return "\(engine.engineId):\(observed.map(String.init) ?? "unknown"):\(controlRevision(engine) ?? "unknown")"
            }
            .joined(separator: "|")
        let requests = state.pendingRequests.map {
            "\($0.clientRequestId ?? $0.id):\($0.state ?? "unknown")"
        }.joined(separator: "|")
        return "\(engines)|\(requests)|\(state.enginesObservedAt?.timeIntervalSince1970 ?? 0)"
    }

    private func reconcileRequestedStates() {
        for engine in state.engines?.engines ?? [] {
            guard let entry = latch.entries[engine.engineId] else { continue }
            let request = state.pendingRequests.first { $0.clientRequestId == entry.clientRequestId }
            let requestState: ToggleRequestLatch.RequestState
            if let request {
                switch request.state?.lowercased() {
                case "pending", "requested": requestState = .pending
                case "applied": requestState = .applied
                case "rejected": requestState = .rejected
                default: requestState = .unknown
                }
            } else {
                requestState = .missing
            }
            latch.reconcile(id: engine.engineId,
                observed: accountConfiguration(engine)?.effective.enabled ?? engine.configuration?.global.enabled,
                request: requestState, now: .now)
        }
    }

    private func canToggle(_ engine: Engine) -> Bool {
        (!state.fixtureMode.enabled || state.fixtureMode.controlWalk) && !state.submittingControl && !state.controlOutcomeUnknown &&
        (!hasAccountScope || scopedAccount != nil) &&
        engine.host?.isEmpty == false && controlRevision(engine)?.isEmpty == false && controlPending(engine) == nil
    }

    private func toggleSnapshot(_ engine: Engine) -> EngineToggleSnapshot {
        EngineToggleSnapshot(canToggle: canToggle(engine), outcomeUnknown: state.controlOutcomeUnknown,
            pending: controlPending(engine) != nil,
            observedEnabled: accountConfiguration(engine)?.effective.enabled ?? engine.configuration?.global.enabled,
            host: engine.host, revision: controlRevision(engine), scope: controlScope,
            scopeLabel: scopedAccount?.label ?? "every account")
    }

    private func requestToggle(_ engine: Engine, enabled: Bool) {
        if let reason = EngineControlConfirmation.requestToggle(engine: engine, enabled: enabled, current: toggleSnapshot(engine),
            clientRequestId: UUID().uuidString, gate: gate) {
            errors[engine.engineId] = reason
        }
    }

    private func send(_ c: EngineControlConfirmation) async {
        let outcome = await gate.confirm(c, recheck: { EngineControlConfirmation.toggleRefusal(held: c, current: state.engines?.engines?.first { $0.engineId == c.engineId }.map(toggleSnapshot)) }, willSend: { latch.request(id: c.engineId, desired: c.kind == .enable, clientRequestId: c.intent.clientRequestId ?? "", at: .now); errors[c.engineId] = nil }, submit: state.submit)
        switch outcome {
        case .refused(let reason): errors[c.engineId] = reason
        case .sent(let message?):
            latch.submissionFailed(id: c.engineId)
            errors[c.engineId] = message
        case .notSent, .sent(nil): break
        }
    }

    private var scopedAccount: EngineControlAccount? {
        let accounts = (state.engines?.accounts ?? []).filter { $0.configurable && $0.id != "unassigned" }
        return accounts.count == 1 ? accounts[0] : nil
    }

    private var hasAccountScope: Bool {
        (state.engines?.accounts ?? []).contains { $0.id != "unassigned" }
    }

    private var controlScope: ControlScope {
        guard let account = scopedAccount, let scope = try? ControlScope.account(account.id) else { return .global }
        return scope
    }

    private func accountConfiguration(_ engine: Engine) -> EngineAccountConfiguration? {
        guard let id = scopedAccount?.id else { return nil }
        return engine.configuration?.accounts.first { $0.accountId == id }
    }

    private func controlRevision(_ engine: Engine) -> String? {
        accountConfiguration(engine)?.revision ?? engine.configuration?.global.revision
    }

    private func controlPending(_ engine: Engine) -> EnginePendingRequest? {
        accountConfiguration(engine)?.pending ?? engine.configuration?.global.pending
    }

    private func number(_ value: Double?) -> String {
        value.map { String(format: "%g", $0) } ?? "Unknown"
    }
}

struct EnginePnlValue: View {
    let cents: Double?
    var font: Font = LeafType.number
    var numeral: LeafNumeralStyle? = nil

    static func tone(_ cents: Double?) -> LeafTone {
        guard let cents, cents.isFinite else { return .stale }
        return cents > 0 ? .gain : cents < 0 ? .loss : .neutral
    }

    var body: some View {
        if let numeral {
            value.leafNumeral(numeral)
        } else {
            value
        }
    }

    @ViewBuilder private var value: some View {
        if let cents, cents.isFinite, let wholeCents = Int(exactly: cents.rounded()) {
            PnlText(cents: wholeCents, font: numeral?.font ?? font)
        } else {
            Text("Unavailable").font(numeral?.font ?? font).foregroundStyle(LeafTheme.inkMuted)
        }
    }
}

struct EngineWinRateBar: View {
    let rate: Double?
    var perTicket: String? = nil

    private var fraction: Double? {
        guard let rate, rate.isFinite else { return nil }
        return min(1, max(0, rate))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            GeometryReader { geometry in
                HStack(spacing: 0) {
                    if let fraction {
                        LeafTheme.gain.frame(width: geometry.size.width * CGFloat(fraction))
                        LeafTheme.loss.opacity(0.4)
                    } else {
                        LeafTheme.line
                    }
                }
                .clipShape(Capsule())
            }
            .frame(height: 6)
            .accessibilityHidden(true)
            Text((fraction.map { "win \(LeafFormat.percent($0))" } ?? "Win rate unavailable") +
                (perTicket.map { " · \($0) / ticket" } ?? ""))
                .leafNumeral(.small).foregroundStyle(LeafTheme.inkMuted)
        }
        .accessibilityElement(children: .combine)
    }
}

private enum EngineAction: String, CaseIterable, Identifiable {
    case bind = "Bind", create = "Create"
    var id: String { rawValue }
}

@MainActor private struct EngineControlSheet: View {
    @Environment<AppState>(AppState.self) private var state
    @Environment(\.dismiss) private var dismiss
    let action: EngineAction
    @State private var engineId = ""
    @State private var symbol = "all"
    @State private var key = ""
    @State private var numericValue = ""
    @State private var newId = ""
    @State private var name = ""
    @State private var note = ""
    @State private var error: String?
    @State private var sending = false
    @State private var submitted = false
    @State private var gate = EngineControlGate()

    private var engines: [Engine] { state.engines?.engines ?? [] }
    private var selected: Engine? { engines.first { $0.engineId == engineId } }
    private var keys: [String] { selected.map { engineSetKeys(for: $0) } ?? [] }
    private var symbols: [String] {
        Array(Set(engines.flatMap { $0.boundBooks ?? [] })).filter { $0 != "all" }.sorted()
    }
    private var intentResult: Result<ControlIntent, Error> {
        Result {
            guard selected != nil else { throw ControlIntent.ValidationError.invalid("Choose an engine.") }
            switch action {
            case .bind: return try .bind(symbol: symbol == "all" ? nil : symbol, engineId: engineId)
            case .create: return try .create(engineId: newId, name: name.trimmingCharacters(in: .whitespacesAndNewlines), from: engineId)
            }
        }
    }
    private var intent: ControlIntent? { try? intentResult.get() }

    var body: some View {
        NavigationStack {
            Form {
                Section("Fields") {
                    Picker(action == .create ? "From engine" : "Engine", selection: $engineId) {
                        Text("Choose an engine").tag("")
                        ForEach(engines) { engine in Text(engine.name ?? engine.engineId).tag(engine.engineId) }
                    }
                    .accessibilityIdentifier("engine.control.enginePicker")
                    if action == .bind {
                        Picker("Symbol", selection: $symbol) {
                            Text("all").tag("all")
                            ForEach(symbols, id: \.self) { Text($0).tag($0) }
                        }
                        .accessibilityIdentifier("engine.control.symbolPicker")
                    }
                    if action == .create {
                        TextField("New engine ID", text: $newId).textInputAutocapitalization(.never).autocorrectionDisabled()
                            .accessibilityIdentifier("engine.control.newId")
                        TextField("Name", text: $name)
                            .accessibilityIdentifier("engine.control.name")
                    }
                    TextField("Note (optional)", text: $note, axis: .vertical)
                }.disabled(sending || submitted)
                Section("Exact value to send") {
                    if let intent { Text(intent.value.displayValue).font(.system(.body, design: .monospaced)).textSelection(.enabled) }
                    else if case let .failure(reason) = intentResult { Text(reason.localizedDescription).foregroundStyle(.secondary) }
                }
                Section {
                    if let error { Text(error).foregroundStyle(LeafTheme.loss).accessibilityAddTraits(.updatesFrequently) }
                    if submitted { Text("Request received. See Requests for its applied or rejected state.") }
                    Button("Review") {
                        guard let selected, !sending, !submitted else { return }
                        error = nil
                        let trimmedNote = note.isEmpty ? nil : note
                        do {
                            let confirmation: EngineControlConfirmation
                            switch action {
                            case .bind:
                                confirmation = try .bind(engine: selected, symbol: symbol == "all" ? nil : symbol, note: trimmedNote)
                            case .create:
                                confirmation = try .create(source: selected, newId: newId, name: name, note: trimmedNote)
                            }
                            gate.hold(confirmation)
                        } catch {
                            self.error = error.localizedDescription
                        }
                    }
                    .accessibilityIdentifier("engine.control.review")
                    .disabled(intent == nil || sending || submitted || state.submittingControl)
                }
            }
            .navigationTitle(action.rawValue + " engine")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() }.disabled(sending) } }
            .interactiveDismissDisabled(sending)
            .onChange(of: engineId) { _, _ in key = ""; numericValue = "" }
            .transaction { $0.animation = nil }
        }
        .confirmationDialog(gate.pending?.title ?? "", isPresented: Binding(get: { gate.pending != nil }, set: { if !$0 { gate.dismiss() } }), titleVisibility: .visible, presenting: gate.pending) { c in
            Button(c.confirmLabel) { Task { await confirmSheet(c) } }
                .accessibilityIdentifier("engine.control.confirm")
            Button("Cancel", role: .cancel) { gate.cancel() }
                .accessibilityIdentifier("engine.control.cancel")
        } message: { c in
            Text(c.message)
        }
        .sensoryFeedback(.success, trigger: gate.successTick)
        .sensoryFeedback(.error, trigger: gate.failureTick)
    }

    private func confirmSheet(_ c: EngineControlConfirmation) async {
        sending = true
        error = nil
        let outcome = await gate.confirm(c, recheck: { EngineControlConfirmation.sheetRefusal(engineListed: engines.contains { $0.engineId == c.engineId }, outcomeUnknown: state.controlOutcomeUnknown) }, submit: state.submit)
        switch outcome {
        case .refused(let reason): error = reason
        case .sent(let result):
            error = result
            submitted = result == nil
        case .notSent: break
        }
        sending = false
    }
}
