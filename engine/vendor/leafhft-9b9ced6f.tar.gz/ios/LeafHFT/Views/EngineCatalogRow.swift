import SwiftUI
import LeafHFTCore

/// Catalog presentation only. The parent owns navigation and the confirmed entry-change binding.
struct EngineCatalogRow<Detail: View, EntryToggle: View>: View {
    let engine: Engine
    let now: Date
    let enabled: Bool?
    let detailed: Bool
    let attention: String?
    let open: () -> Void
    @ViewBuilder var detail: () -> Detail
    @ViewBuilder var entryToggle: () -> EntryToggle

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            VStack(alignment: .leading, spacing: 4) {
                        HStack(alignment: .top, spacing: 8) {
                            Button(action: open) {
                                Text(engine.name ?? engine.engineId)
                                    .font(LeafType.heading).lineLimit(2).truncationMode(.middle)
                                    .foregroundStyle(LeafTheme.ink)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .contentShape(Rectangle())
                            }
                            .buttonStyle(.borderless)
                             .accessibilityLabel("\(engine.name ?? engine.engineId), \(EngineCatalogQuery.entryText(enabled))")
                            .accessibilityValue(accessibilityState)
                            .accessibilityIdentifier("engine.detail.\(engine.engineId)")
                            EngineLifecycleChip(lifecycle: engine.lifecycle, eligibility: engine.eligibleToProbe, now: now)
                                .accessibilityIdentifier("engine.lifecycle.\(engine.engineId)")
                                .contentShape(Rectangle())
                                .onTapGesture(perform: open)
                        }
                        .frame(minHeight: 31)
                    VStack(alignment: .leading, spacing: 4) {
                        ViewThatFits(in: .horizontal) {
                            summary(extras: 3)
                            summary(extras: 2)
                            summary(extras: 1)
                            summary(extras: 0)
                        }
                        .accessibilityElement(children: .combine)
                        .accessibilityIdentifier("engine.summary.\(engine.engineId)")
                        if let attention {
                            Text(attention).font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                                .fixedSize(horizontal: false, vertical: true)
                                .accessibilityIdentifier("engine.attention.\(engine.engineId)")
                        }
                        if detailed { detail() }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture(perform: open)
                    .accessibilityElement(children: .contain)
            }
                .frame(maxWidth: .infinity, minHeight: 48, alignment: .leading)
                .accessibilityElement(children: .contain)
                .accessibilityIdentifier("engine.row.\(engine.engineId)")
            entryToggle().fixedSize()
        }
    }

    private var accessibilityState: String {
        let pnl = (engine.pnl?.netCents).flatMap { cents -> String? in
            guard cents.isFinite, let wholeCents = Int(exactly: cents.rounded()) else { return nil }
            return LeafFormat.signedMoney(cents: wholeCents)
        }
        return [EngineLifecycleChip.text(engine.lifecycle, eligibility: engine.eligibleToProbe, now: now),
                pnl.map { "Net P&L \($0)" } ?? "P&L unavailable", attention]
            .compactMap { $0 }.joined(separator: ", ")
    }

    private func summary(extras: Int) -> some View {
        HStack(spacing: 4) {
            if enabled == nil { Text("Unknown ·") }
            else if enabled == false { Text("Paused ·") }
            if let cents = engine.pnl?.netCents, cents.isFinite {
                EnginePnlValue(cents: cents, font: LeafType.meta)
            } else {
                Text("P&L unavailable")
            }
            if let value = engine.live?.perContractCents, value.isFinite {
                Text("· \(value, specifier: "%+.1f")c / contract")
            }
            if extras >= 2, let win = EngineCatalogQuery.winRate(engine) {
                Text("· \(LeafFormat.percent(win)) win")
            }
            if extras >= 1, let open = engine.pnl?.open { Text("· \(open) open") }
            if extras >= 3, let rate = engine.pnl?.ticketsPerHour, rate.isFinite {
                Text("· \(rate, specifier: "%.1f") / h")
            }
        }
        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
        .fixedSize(horizontal: extras > 0, vertical: true)
    }
}
