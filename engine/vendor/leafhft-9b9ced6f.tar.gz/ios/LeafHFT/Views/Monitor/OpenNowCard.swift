import SwiftUI
import LeafHFTCore

struct OpenNowCard: View {
    let books: [Book]
    let engines: [Engine]

    private var nextClose: String {
        Self.nextCloseText(books: books)
    }

    static func nextCloseText(books: [Book]) -> String {
        MonitorPresentation.nextCloseText(MonitorPresentation.nextClose(books: books))
    }

    private var rows: [[BoundedTable.Cell]] {
        Self.bookRows(books: books, engines: engines)
    }

    static func bookRows(books: [Book], engines: [Engine]) -> [[BoundedTable.Cell]] {
        books.sorted { $0.bookId < $1.bookId }.compactMap { book in
            guard let candidate = book.kalshiBook.eval?.candidates?.first else { return nil }
            let cells = BookCandidateCells(book: book, candidate: candidate)
            let engine = engines.first { $0.boundBooks?.contains(book.bookId) == true }
            return [
                .init(text: candidate.ticker, mono: true),
                .init(text: cells.side),
                .init(text: cells.observations),
                .init(text: cells.edge, tone: Self.edgeTone(candidate)),
                .init(text: engine?.name ?? engine?.engineId ?? MonitorPresentation.notReported),
                .init(text: cells.closes)
            ]
        }
    }

    var body: some View {
        FlatCard(title: "Open now") {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], alignment: .leading, spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    stat("Next close", value: nextClose)
                    Caption("market close read off the ticker; settlement follows the close", expandable: false)
                }
            }
            Text("Books being evaluated".uppercased())
                .font(LeafType.micro)
                .foregroundStyle(LeafTheme.inkMuted)
            BoundedTable(columns: [
                .init(title: "Book", width: 180),
                .init(title: "Side", width: 70),
                .init(title: "Observations", width: 100, numeric: true),
                .init(title: "Edge", width: 160, numeric: true),
                .init(title: "Engine", width: 140),
                .init(title: "Closes", width: 90, numeric: true)
            ], rows: rows, maxHeight: 148, identifier: "books.openTable", minWidth: 740)
            .truncationMode(.middle)
            .frame(height: 148)
        }
    }

    private func stat(_ title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            Text(value).leafNumeral(.large).foregroundStyle(LeafTheme.ink)
                .lineLimit(1).minimumScaleFactor(0.5)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private static func edgeTone(_ candidate: Candidate) -> LeafTone {
        guard let edge = candidate.edgeCents, edge.isFinite,
              let required = candidate.edgeRequiredCents, required.isFinite else { return .stale }
        return edge >= required ? .gain : .loss
    }
}
