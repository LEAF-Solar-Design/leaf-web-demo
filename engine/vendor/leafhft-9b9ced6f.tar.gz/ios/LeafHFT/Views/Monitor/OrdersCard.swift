import SwiftUI
import LeafHFTCore

struct OrdersCard: View {
    let activity: RunnerActivity?

    private var openOrders: [RunnerActivityRow] {
        let openStates = Set(["open", "pending", "submitted", "resting", "partially_filled"])
        return (activity?.orders ?? []).filter { openStates.contains($0.state.lowercased()) }
    }

    struct ClosedPosition: Identifiable, Equatable {
        let id: String
        let trades: [RunnerActivityRow]
        /// Newest parseable trade time; nil when no trade carries one.
        let latest: Date?
    }

    /// Rows shown on the page's own scroll before the "All ... (N)" row; never a nested scroll box.
    static let previewLimit = 3

    struct Preview: Equatable {
        let shown: Int
        let allLabel: String?
    }

    /// The first `previewLimit` rows inline, with an optional full-list link for small ledgers too.
    static func preview(count: Int, noun: String, alwaysShowAll: Bool = false) -> Preview {
        let total = max(0, count)
        return Preview(shown: min(previewLimit, total), allLabel: total > previewLimit || (alwaysShowAll && total > 0) ? "All \(noun) (\(total))" : nil)
    }

    /// Closed fills grouped by ticker, most recent position first. Unparseable times sort last, in runner order.
    static func closedPositions(fills: [RunnerActivityRow]) -> [ClosedPosition] {
        var order: [String] = []
        var grouped: [String: [RunnerActivityRow]] = [:]
        for trade in fills where trade.pnlCents != nil {
            let ticker = trade.safeTicker
            if grouped[ticker] == nil { order.append(ticker) }
            grouped[ticker, default: []].append(trade)
        }
        let positions = order.compactMap { ticker in
            grouped[ticker].map { trades in
                ClosedPosition(id: ticker, trades: trades, latest: trades.compactMap { parseTime($0.occurredAt) }.max())
            }
        }
        return positions.enumerated().sorted { lhs, rhs in
            switch (lhs.element.latest, rhs.element.latest) {
            case let (left?, right?) where left != right: return left > right
            case (.some, nil): return true
            case (nil, .some): return false
            default: return lhs.offset < rhs.offset
            }
        }.map(\.element)
    }

    static func parseTime(_ value: String) -> Date? {
        let parser = ISO8601DateFormatter()
        parser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = parser.date(from: value) { return date }
        parser.formatOptions = [.withInternetDateTime]
        return parser.date(from: value)
    }

    private var closedPositions: [ClosedPosition] {
        Self.closedPositions(fills: activity?.fills ?? [])
    }

    private func money(_ value: Decimal?) -> String {
        guard let value else { return MonitorPresentation.notReported }
        return Cents(NSDecimalNumber(decimal: value).intValue).formatted()
    }

    private func signedMoney(_ value: Decimal) -> String {
        let cents = NSDecimalNumber(decimal: value).intValue
        return (cents > 0 ? "+" : "") + Cents(cents).formatted()
    }

    private func time(_ value: String) -> String {
        guard let date = Self.parseTime(value) else { return "Time unavailable" }
        return date.formatted(date: .abbreviated, time: .standard)
    }

    private func tone(_ row: RunnerActivityRow) -> LeafTone {
        guard let pnl = row.pnlCents else { return .stale }
        return pnl > 0 ? .gain : pnl < 0 ? .loss : .neutral
    }

    private func kindLabel(_ row: RunnerActivityRow) -> String {
        if let outcome = row.outcomeLabel { return outcome }
        switch row.kind.lowercased() {
        case "buy": return "Entry fill"
        case "exit": return "Cashout"
        case "settle": return "Settlement"
        case "adopt": return "Adopted position"
        default: return row.stateLabel
        }
    }

    private func economics(_ row: RunnerActivityRow) -> String {
        guard let pnl = row.pnlCents else {
            return "Fill P/L not reported · fee \(money(row.feeCents))"
        }
        return "Fill P/L \(signedMoney(pnl)) · fee \(money(row.feeCents))"
    }

    private func row(_ item: RunnerActivityRow, index: Int, prefix: String, showsTicker: Bool = true) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                if showsTicker {
                    OneLine(item.safeTicker, truncation: .middle).font(LeafType.ticker)
                        .accessibilityIdentifier("\(prefix).\(index)")
                } else {
                    Caption(time(item.occurredAt)).accessibilityIdentifier("\(prefix).\(index)")
                }
                Spacer(minLength: 4)
                StateInk(kindLabel(item), tone: tone(item))
            }
            HStack(spacing: 6) {
                if let engine = item.safeEngineLabel {
                    StateInk(engine, tone: .stale, symbol: "gearshape.2")
                        .accessibilityLabel("Engine \(engine)")
                        .accessibilityIdentifier("\(prefix).\(index).engine")
                } else {
                    StateInk("Engine unknown", tone: .warn, symbol: "questionmark.circle")
                        .accessibilityIdentifier("\(prefix).\(index).engine")
                }
                if showsTicker { Caption(time(item.occurredAt)) }
            }
            Caption(economics(item), tone: tone(item), expandable: true)
                .leafNumeral(.small)
            if let count = item.count, let price = item.priceCents {
                Caption("\(NSDecimalNumber(decimal: count).stringValue) contracts @ \(money(price))")
                    .leafNumeral(.small)
            }
        }
        .padding(.vertical, 2)
        .fixedSize(horizontal: false, vertical: true)
    }

    private func positionSummary(_ position: ClosedPosition) -> some View {
        HStack(spacing: 8) {
            VStack(alignment: .leading, spacing: 3) {
                OneLine(position.id, truncation: .middle).font(LeafType.ticker)
                Caption("\(position.trades.count) reported fills for this ticker · expand for runner P/L")
            }
            Spacer(minLength: 8)
        }
    }

    private func allRow(_ label: String, identifier: String) -> some View {
        HStack(spacing: 8) {
            OneLine(label).font(LeafType.body)
            Spacer(minLength: 8)
            Image(systemName: "chevron.right").font(LeafType.meta).accessibilityHidden(true)
        }
        .foregroundStyle(LeafTheme.ink)
        .frame(minHeight: 44)
        .contentShape(Rectangle())
        .accessibilityIdentifier(identifier)
    }

    private func orderRows(_ orders: [RunnerActivityRow]) -> some View {
        ForEach(Array(orders.enumerated()), id: \.offset) { entry in
            if entry.offset > 0 { Divider().overlay(LeafTheme.line) }
            row(entry.element, index: entry.offset, prefix: "account.trade.order")
        }
    }

    private func positionRows(_ positions: [ClosedPosition], prefix: String) -> some View {
        ForEach(Array(positions.enumerated()), id: \.element.id) { entry in
            if entry.offset > 0 { Divider().overlay(LeafTheme.line) }
            DisclosureGroup {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(Array(entry.element.trades.enumerated()), id: \.offset) { trade in
                        if trade.offset > 0 { Divider().overlay(LeafTheme.line) }
                        row(trade.element, index: trade.offset,
                            prefix: "\(prefix).\(entry.offset).trade", showsTicker: false)
                    }
                }
                .padding(.top, 8)
            } label: {
                positionSummary(entry.element)
            }
            .tint(LeafTheme.ink)
        }
    }

    /// The full list is a pushed page with its own single scroll, never a box inside the Monitor scroll.
    private func fullList<Rows: View>(title: String, identifier: String, @ViewBuilder rows: () -> Rows) -> some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 8) { rows() }
                .padding(16)
        }
        .accessibilityIdentifier(identifier)
        .leafScreenBackground()
        .foregroundStyle(LeafTheme.ink)
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
    }

    @ViewBuilder private var openOrderContents: some View {
        if activity != nil {
            let orders = openOrders
            if orders.isEmpty {
                OneLine("No open orders").font(LeafType.body)
                    .foregroundStyle(LeafTheme.inkMuted)
            } else {
                let preview = Self.preview(count: orders.count, noun: "open orders")
                VStack(alignment: .leading, spacing: 8) {
                    orderRows(Array(orders.prefix(preview.shown)))
                }
                .accessibilityElement(children: .contain)
                .accessibilityIdentifier("monitor.openOrders")
                if let label = preview.allLabel {
                    NavigationLink {
                        fullList(title: "Open orders", identifier: "account.openOrders.list") { orderRows(orders) }
                    } label: {
                        allRow(label, identifier: "account.openOrders.all")
                    }
                    .buttonStyle(.plain)
                }
            }
        } else {
            OneLine(MonitorPresentation.notReported).font(LeafType.body)
                .foregroundStyle(LeafTheme.inkMuted)
            Caption("The runner has not published its order and fill ledger.")
        }
    }

    @ViewBuilder private var closedPositionContents: some View {
        let positions = closedPositions
        if activity == nil {
            OneLine(MonitorPresentation.notReported).foregroundStyle(LeafTheme.inkMuted)
        } else if positions.isEmpty {
            OneLine("No closed positions").font(LeafType.body).foregroundStyle(LeafTheme.inkMuted)
        } else {
            let preview = Self.preview(count: positions.count, noun: "closed positions", alwaysShowAll: true)
            VStack(alignment: .leading, spacing: 8) {
                positionRows(Array(positions.prefix(preview.shown)), prefix: "account.closed")
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("monitor.closedPositions")
            if let label = preview.allLabel {
                NavigationLink {
                    fullList(title: "Closed positions", identifier: "account.closedPositions.list") {
                        positionRows(positions, prefix: "account.closed")
                    }
                } label: {
                    allRow(label, identifier: "account.closedPositions.all")
                }
                .buttonStyle(.plain)
            }
            Caption("Most recent first, from the runner's fill ledger", expandable: false)
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            FlatCard(title: "Open orders") {
                openOrderContents
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("account.openOrders")
            FlatCard(title: "Closed positions") {
                closedPositionContents
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("account.closedPositions")
        }
    }
}
