import SwiftUI
import LeafHFTCore

/// Fixed-format probe board text (no locale), so the breaker reads the same on every device.
/// Null is "Not reported", never zero; every figure is the runner's, never recomputed here.
enum ProbeBoardText {
    static let notReported = ProbePresentation.notReported
    /// Runner and ticket figures further apart than this ($1.00) raise the Reconcile chip.
    static let reconcileThresholdCents = 100

    static func dollars(_ cents: Int) -> String {
        let magnitude = cents.magnitude
        let fraction = magnitude % 100
        let digits = String(magnitude / 100)
        var grouped = ""
        for (index, digit) in digits.enumerated() {
            if index > 0, (digits.count - index) % 3 == 0 { grouped += "," }
            grouped.append(digit)
        }
        return "\(cents < 0 ? "-" : "")$\(grouped).\(fraction < 10 ? "0" : "")\(fraction)"
    }

    static func signedDollars(_ cents: Int) -> String { cents > 0 ? "+" + dollars(cents) : dollars(cents) }

    static func percent(_ pct: Double) -> String {
        if pct.rounded() == pct, abs(pct) < 1e15 { return "\(Int(pct))%" }
        return String(format: "%.1f%%", pct)
    }

    /// "-$12.40 of $1,250.00 (50% of $2,500.00) · UTC day". Loss is positive cents; a negative loss is a gain.
    static func meter(lossCents: Int?, limitCents: Int?, pct: Double?, dayStartCents: Int?) -> String {
        guard let lossCents, let limitCents, lossCents != .min else { return notReported }
        var text = "\(signedDollars(-lossCents)) of \(dollars(limitCents))"
        if let pct, pct.isFinite {
            text += dayStartCents.map { " (\(percent(pct)) of \(dollars($0)))" } ?? " (\(percent(pct)))"
        }
        return text + " · UTC day"
    }

    /// The breaker day ends at 00:00Z; shown in Central time.
    static func reset(now: Date) -> String {
        let day: TimeInterval = 86_400
        let next = Date(timeIntervalSince1970: (floor(now.timeIntervalSince1970 / day) + 1) * day)
        return "Resets at \(centralTime(next, format: "h:mm a")) CT"
    }

    static func expiry(_ value: String?) -> String {
        guard let value, let date = isoDate(value) else { return notReported }
        return centralTime(date, format: "MMM d, h:mm a") + " CT"
    }

    /// The runner's own words when sent; an older runner's bare code is spelled out, never invented.
    static func stopReasons(_ reasons: [EngineLifecycle.StopReason]?) -> String {
        guard let reasons else { return notReported }
        guard !reasons.isEmpty else { return "None" }
        return reasons.map { reason -> String in
            if let text = reason.text?.trimmingCharacters(in: .whitespacesAndNewlines), !text.isEmpty { return text }
            let words = reason.code.replacingOccurrences(of: "_", with: " ").replacingOccurrences(of: "-", with: " ")
            return words.prefix(1).uppercased() + words.dropFirst()
        }.joined(separator: "; ")
    }

    /// Runner day P&L (the breaker's loss, negated) against attributed ticket P&L; nil when either is missing.
    static func reconcileGap(engineLossCents: Int?, ticketCents: Int?) -> Int? {
        guard let engineLossCents, let ticketCents, engineLossCents != .min else { return nil }
        let (gap, overflow) = (-engineLossCents).subtractingReportingOverflow(ticketCents)
        return overflow ? Int.max : gap
    }

    static func needsReconcile(engineLossCents: Int?, ticketCents: Int?) -> Bool {
        guard let gap = reconcileGap(engineLossCents: engineLossCents, ticketCents: ticketCents) else { return false }
        return gap.magnitude > UInt(reconcileThresholdCents)
    }

    /// Probing or live lifecycles: the engines that enter positions and so owe a runner day-loss limit.
    static func entersPositions(_ lifecycle: EngineLifecycle?) -> Bool {
        switch lifecycle?.state {
        case .probe?, .probeSized?, .graduated?, .canary?: return true
        default: return false
        }
    }

    /// A probing or live row whose runner day-loss limit is null.
    static func dayLossLimitMissing(_ row: ProbeRow) -> Bool {
        entersPositions(row.lifecycle) && row.lifecycle?.breaker?.engineLimitCents == nil
    }

    /// True when the account meter prints a runner figure rather than "Not reported".
    static func accountMeterReported(_ account: AccountBreaker?) -> Bool {
        guard let loss = account?.lossCents, account?.limitCents != nil else { return false }
        return loss != .min
    }

    /// The card's first line, from which runner fields are present; it never recomputes a runner figure and
    /// never claims more than "reported". Tripped or halted states keep the card's loss wording and tone.
    static func protectionVerdict(accountBreakerReported: Bool, accountSuspended: Bool, rows: [ProbeRow],
                                  observedAge: String? = nil) -> (text: String, tone: LeafTone) {
        let enginesMissing = rows.reduce(0) { $0 + (dayLossLimitMissing($1) ? 1 : 0) }
        let engineNoun = enginesMissing == 1 ? "1 engine" : "\(enginesMissing) engines"
        let missing: String?
        switch (accountBreakerReported, enginesMissing) {
        case (true, 0): missing = nil
        case (false, 0): missing = "Account breaker is not reported by the runner."
        case (true, 1): missing = "Day-loss limit for 1 engine is not reported by the runner."
        case (true, _): missing = "Day-loss limits for \(engineNoun) are not reported by the runner."
        case (false, _): missing = "Account breaker and day-loss limit for \(engineNoun) are not reported by the runner."
        }
        let headline: (text: String, tone: LeafTone)
        if accountSuspended {
            headline = ("Account breaker tripped: entries suspended until 00:00 UTC.", .loss)
        } else if rows.contains(where: { $0.lifecycle?.state == .halted }) {
            headline = ("At least one engine: entries halted, settlement only.", .loss)
        } else if missing != nil {
            headline = ("Loss limits not reported.", .warn)
        } else {
            headline = ("Loss limits reported by the runner.", .neutral)
        }
        return ([headline.text, missing, observedAge].compactMap { $0 }.joined(separator: " "), headline.tone)
    }

    private static func isoDate(_ text: String) -> Date? {
        let parser = ISO8601DateFormatter()
        parser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = parser.date(from: text) { return date }
        parser.formatOptions = [.withInternetDateTime]
        return parser.date(from: text)
    }

    private static func centralTime(_ date: Date, format: String) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "America/Chicago")
        formatter.dateFormat = format
        return formatter.string(from: date)
    }
}

/// Monitor card for GET /api/leafhft/mobile/probes: the account breaker meter and one row per engine.
/// Hidden when the server has no probes route (404); "Not reported" when the body is unreadable.
/// Height is bounded: rows scroll inside a fixed viewport and at most `rowLimit` rows render.
@MainActor struct ProbeBoardCard: View {
    @Environment<AppState>(AppState.self) private var state
    let now: Date
    @State private var haltTarget: ProbeRow?
    @State private var haltErrors: [String: String] = [:]

    static let listHeight: CGFloat = 320
    private static let rowLimit = 20
    private static let haltReason = "Halted from the Monitor probe board"
    /// Fixture runs only: `-LEAFHFT_PROBES missing` answers like a 404, `unreadable` like an unreadable body.
    private static let fixtureOverride: String? = {
        let arguments = ProcessInfo.processInfo.arguments
        guard let index = arguments.firstIndex(of: "-LEAFHFT_PROBES"), arguments.indices.contains(index + 1) else {
            return nil
        }
        return arguments[index + 1]
    }()

    private enum Shown { case hidden, notReported, board(ProbeBoardResponse) }

    static func showsUnavailable(notReported: Bool, status: FeedStatus?) -> Bool {
        notReported || status?.lastError != nil
    }

    private var readError: String? {
        if state.fixtureMode.enabled && Self.fixtureOverride == "failed" {
            return "Could not refresh probes. Risk information is unavailable."
        }
        return state.feedStatuses[.probes]?.lastError ?? state.probeBoardError
    }

    private var shown: Shown {
        if state.fixtureMode.enabled {
            switch Self.fixtureOverride {
            case "missing"?: return .hidden
            case "unreadable"?: return .notReported
            case "failed"?: return .notReported
            default: break
            }
        }
        if let board = state.probeBoard { return .board(board) }
        return Self.showsUnavailable(notReported: state.probeBoardNotReported,
                                     status: state.feedStatuses[.probes]) || state.probeBoardError != nil ? .notReported : .hidden
    }

    private var controlsAvailable: Bool { !state.fixtureMode.enabled || state.fixtureMode.controlWalk }

    private func name(_ row: ProbeRow) -> String {
        let trimmed = row.name?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return trimmed.isEmpty ? row.engineId : trimmed
    }

    private func isHalt(_ request: ControlRequest, engineId: String) -> Bool {
        guard request.kind == ControlKind.halt.rawValue, case let .halt(value)? = request.value else { return false }
        return value.engineId == engineId
    }

    /// The newest halt request for this engine, from this device or another.
    private func haltRequest(_ engineId: String) -> ControlRequest? {
        state.pendingControls.last { isHalt($0, engineId: engineId) }
    }

    private func haltStatus(_ request: ControlRequest) -> (text: String, tone: LeafTone) {
        switch request.state?.lowercased() {
        case "requested"?: return ("Halt requested", .warn)
        case "applied"?: return ("Halt applied", .loss)
        case "rejected"?: return ("Halt rejected", .stale)
        case let other?: return ("Halt \(other)", .stale)
        case nil: return ("Halt state not reported", .stale)
        }
    }

    private func canHalt(_ row: ProbeRow) -> Bool {
        guard controlsAvailable, !state.submittingControl else { return false }
        switch row.lifecycle?.state {
        case .halted?, .retired?: return false
        default: break
        }
        switch haltRequest(row.engineId)?.state?.lowercased() {
        case "requested"?, "applied"?: return false
        default: return true
        }
    }

    private func lifecycleTone(_ lifecycle: EngineLifecycle?) -> LeafTone {
        switch lifecycle?.state {
        case .halted?: return .loss
        case .retired?, .unknown?, nil: return .stale
        default: return .neutral
        }
    }

    private func confirmHalt(_ row: ProbeRow) {
        haltTarget = nil
        haltErrors[row.engineId] = nil
        let intent: ControlIntent
        do {
            intent = try ControlIntent.halt(engineId: row.engineId, reason: Self.haltReason,
                                            clientRequestId: UUID().uuidString)
        } catch {
            haltErrors[row.engineId] = error.localizedDescription
            return
        }
        Task {
            if let message = await state.submit(intent, note: Self.haltReason) { haltErrors[row.engineId] = message }
        }
    }

    // MARK: Views

    private func stat(_ label: String, _ value: String, id: String, tone: LeafTone = .neutral) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            OneLine(label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            Text(value)
                .leafNumeral(.small)
                .foregroundStyle(value == ProbeBoardText.notReported ? LeafTheme.inkMuted : tone.color)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier(id)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func row(_ row: ProbeRow, dayStartCents: Int?) -> some View {
        let id = row.engineId
        let breaker = row.lifecycle?.breaker
        let ticketCents = row.probeToday?.realizedCents
        let request = haltRequest(id)
        return VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .center, spacing: 8) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(name(row)).font(LeafType.heading).lineLimit(2)
                    HStack(spacing: 6) {
                        StateInk(row.lifecycle?.label ?? "Lifecycle not reported", tone: lifecycleTone(row.lifecycle))
                            .accessibilityIdentifier("probes.row.\(id).lifecycle")
                        if ProbeBoardText.dayLossLimitMissing(row) {
                            StateInk("Limit not reported", tone: .warn, symbol: "exclamationmark.triangle")
                                .accessibilityIdentifier("probes.row.\(id).limitMissing")
                        }
                    }
                }
                Spacer(minLength: 8)
                Button { haltTarget = row } label: {
                    Text("Halt")
                        .font(LeafType.body)
                        .foregroundStyle(canHalt(row) ? LeafTheme.destructive : LeafTheme.inkMuted)
                        .padding(.horizontal, 14)
                        .frame(minWidth: 64, minHeight: 44)
                        .overlay {
                            Capsule().strokeBorder(canHalt(row) ? LeafTheme.destructive : LeafTheme.line, lineWidth: 1)
                                .allowsHitTesting(false)
                                .accessibilityHidden(true)
                        }
                        .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .disabled(!canHalt(row))
                    .accessibilityHint("Stops new entries. Open contracts settle normally.")
                    .accessibilityIdentifier("probes.halt.\(id)")
            }
            if let request {
                let status = haltStatus(request)
                HStack(spacing: 8) {
                    Text(status.text)
                        .font(LeafType.meta)
                        .foregroundStyle(status.tone.color)
                        .accessibilityIdentifier("probes.halt.\(id).status")
                    Spacer(minLength: 4)
                    if request.state?.lowercased() == "requested" {
                        Button { Task { await state.refreshDashboard() } } label: {
                            Text("Check status")
                                .font(LeafType.meta)
                                .padding(.horizontal, 8)
                                .frame(minWidth: 44, minHeight: 44)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityIdentifier("probes.halt.\(id).refresh")
                    }
                }
                if request.state?.lowercased() == "rejected", let note = request.note, !note.isEmpty {
                    Caption(note, tone: .warn)
                }
            }
            if let error = haltErrors[id] {
                Caption(error, tone: .warn).accessibilityIdentifier("probes.halt.\(id).error")
            }
            stat("Runner day loss", ProbeBoardText.meter(lossCents: breaker?.engineLossCents,
                                                         limitCents: breaker?.engineLimitCents,
                                                         pct: breaker?.enginePct,
                                                         dayStartCents: breaker?.dayStartMarkedCents ?? dayStartCents),
                 id: "probes.row.\(id).dayLoss")
            stat("Ticket P&L today", ticketCents.map(ProbeBoardText.signedDollars) ?? ProbeBoardText.notReported,
                 id: "probes.row.\(id).ticketPnl", tone: ticketCents.map { LeafTone.forDelta(cents: $0) } ?? .stale)
            stat("Tickets today", row.probeToday?.tickets.map { String($0) } ?? ProbeBoardText.notReported,
                 id: "probes.row.\(id).tickets")
            stat("Expires", ProbeBoardText.expiry(row.lifecycle?.expiresAt), id: "probes.row.\(id).expires")
            stat("Stop reasons", ProbeBoardText.stopReasons(row.lifecycle?.stopReasons), id: "probes.row.\(id).stops")
            if ProbeBoardText.needsReconcile(engineLossCents: breaker?.engineLossCents, ticketCents: ticketCents),
               let loss = breaker?.engineLossCents, let tickets = ticketCents {
                VStack(alignment: .leading, spacing: 4) {
                    StateInk("Reconcile", tone: .warn, symbol: "arrow.left.arrow.right")
                        .accessibilityIdentifier("probes.reconcile.\(id)")
                    Caption("Runner \(ProbeBoardText.signedDollars(-loss)) vs tickets \(ProbeBoardText.signedDollars(tickets))",
                            tone: .warn)
                }
            }
        }
        .padding(10)
        .overlay {
            RoundedRectangle(cornerRadius: LeafTheme.radiusSmall)
                .strokeBorder(LeafTheme.line, lineWidth: 1)
                .allowsHitTesting(false)
                .accessibilityHidden(true)
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("probes.row.\(id)")
    }

    private func meterBlock(_ text: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            OneLine("Account breaker").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            Text(text)
                .leafNumeral(.number)
                .foregroundStyle(text == ProbeBoardText.notReported ? LeafTheme.inkMuted : LeafTheme.ink)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("probes.meter")
            Caption(ProbeBoardText.reset(now: now), expandable: false)
        }
    }

    /// First line of the card: whether the runner reported its loss limits, and what it has not.
    private func verdictLine(account: AccountBreaker?, engines: [ProbeRow], observedAge: String?) -> some View {
        let verdict = ProbeBoardText.protectionVerdict(
            accountBreakerReported: ProbeBoardText.accountMeterReported(account),
            accountSuspended: account?.suspended == true, rows: engines, observedAge: observedAge)
        return Text(verdict.text)
            .font(LeafType.body)
            .foregroundStyle(verdict.tone.color)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityIdentifier("probes.verdict")
    }

    private func boardContents(_ board: ProbeBoardResponse) -> some View {
        let account = board.account
        let rows = Array(board.engines.prefix(Self.rowLimit))
        return VStack(alignment: .leading, spacing: 10) {
            // Every engine counts toward the verdict, including rows past the render limit.
            verdictLine(account: account, engines: board.engines,
                        observedAge: state.probeBoardObservedAt.map { ageDescription(observedAt: $0, now: now) })
            meterBlock(ProbeBoardText.meter(lossCents: account?.lossCents, limitCents: account?.limitCents,
                                            pct: account?.pct, dayStartCents: account?.dayStartMarkedCents))
            if account?.suspended == true {
                StateInk("Entries suspended until 00:00 UTC", tone: .loss)
                    .accessibilityIdentifier("probes.suspended")
            }
            if rows.isEmpty {
                OneLine("No engines reported").font(LeafType.body).foregroundStyle(LeafTheme.inkMuted)
            } else {
                ScrollView(.vertical) {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(rows) { item in row(item, dayStartCents: account?.dayStartMarkedCents) }
                    }
                }
                .scrollIndicators(.visible)
                .scrollBounceBehavior(.basedOnSize)
                .frame(height: Self.listHeight)
                .clipped()
                .accessibilityIdentifier("probes.list")
                if board.engines.count > rows.count {
                    Caption("\(board.engines.count - rows.count) more engines not shown", expandable: false)
                }
            }
        }
    }

    private func haltSheet(_ row: ProbeRow) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Halt \(name(row))?")
                .font(LeafType.title)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
            Text("Stops new entries. Open contracts settle normally.")
                .font(LeafType.body)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("probes.halt.message")
            Button { confirmHalt(row) } label: { Text("Halt entries").frame(maxWidth: .infinity) }
                .buttonStyle(.leafPrimary)
                .accessibilityIdentifier("probes.halt.confirm")
            Button { haltTarget = nil } label: { Text("Cancel").frame(maxWidth: .infinity) }
                .buttonStyle(.leafSecondary)
                .accessibilityIdentifier("probes.halt.cancel")
            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .foregroundStyle(LeafTheme.ink)
        .background(LeafTheme.card.ignoresSafeArea())
        .presentationDetents([.medium, .large])
    }

    var body: some View {
        Group {
            switch shown {
            case .hidden:
                EmptyView()
            case .notReported:
                FlatCard(title: "Probe board") {
                    verdictLine(account: nil, engines: [], observedAge: nil)
                    meterBlock(ProbeBoardText.notReported)
                    if let error = readError {
                        Caption(error, tone: .warn, expandable: true)
                            .accessibilityIdentifier("probes.error")
                    }
                    Button("Retry") { Task { await state.refreshDashboard() } }
                        .buttonStyle(.leafSecondary)
                        .accessibilityIdentifier("probes.retry")
                }
                .accessibilityElement(children: .contain)
                .accessibilityIdentifier("probes.board")
            case let .board(board):
                FlatCard(title: "Probe board") {
                    boardContents(board)
                    if let error = readError {
                        Caption(error, tone: .warn, expandable: true)
                            .accessibilityIdentifier("probes.error")
                    }
                    if let observed = state.probeBoardObservedAt {
                        Caption(ageDescription(observedAt: observed, now: now), expandable: false)
                    }
                }
                .accessibilityElement(children: .contain)
                .accessibilityIdentifier("probes.board")
            }
        }
        .sheet(item: $haltTarget) { row in haltSheet(row) }
    }
}
