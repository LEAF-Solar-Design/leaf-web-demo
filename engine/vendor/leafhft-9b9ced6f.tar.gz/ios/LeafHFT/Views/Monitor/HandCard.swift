import SwiftUI
import LeafHFTCore

struct HandCard: View {
    let books: [Book]
    let engines: [Engine]
    let requests: [ControlRequest]
    /// Request ages are measured against this; the Books timeline rebuilds the card every tick.
    var now: Date = Date()

    /// One on/off request, read top to bottom with no sideways scroll.
    struct HandRow: Equatable, Identifiable {
        let bookId: String
        let engine: String
        /// The published book state; not evidence of any particular request's outcome.
        let runnerState: String
        let runnerTone: LeafTone
        /// "Turn on" or "Turn off"; nil when no request for this book is on record.
        let requested: String?
        /// "Pending", "Applied", "Rejected" or the runner's other terminal word; nil with no request.
        let state: String?
        let stateTone: LeafTone
        /// "requested 4m ago", or "request time not reported"; nil with no request.
        let age: String?
        let note: String?
        let requestId: String?

        var id: String { requestId.map { "request:\($0)" } ?? "book:\(bookId)" }
        var needsAttention: Bool { state == "Pending" || state == "Rejected" }
    }

    static func bookRequests(bookId: String, requests: [ControlRequest]) -> [ControlRequest] {
        requests.filter { request in
            guard let value = request.value, case let .bookConfigure(change) = value else { return false }
            return change.bookId == bookId
        }.sorted { ($0.requestedDate ?? .distantPast) > ($1.requestedDate ?? .distantPast) }
    }

    static func stateWord(_ request: ControlRequest) -> String {
        guard let state = request.state?.trimmingCharacters(in: .whitespacesAndNewlines), !state.isEmpty else {
            return MonitorPresentation.notReported
        }
        if ["requested", "pending"].contains(state.lowercased()) { return "Pending" }
        return state.prefix(1).uppercased() + state.dropFirst().lowercased()
    }

    static func stateTone(_ word: String?) -> LeafTone {
        switch word {
        case "Applied"?: return .gain
        case "Pending"?: return .warn
        case "Rejected"?: return .loss
        default: return .stale
        }
    }

    /// Whole elapsed units since the request; do not invent an age for a future timestamp.
    static func ageText(requestedAt: Date?, now: Date) -> String {
        guard let requestedAt else { return "request time not reported" }
        guard requestedAt <= now else { return "request timestamp is in the future" }
        let seconds = Int(max(0, now.timeIntervalSince(requestedAt)))
        switch seconds {
        case ..<60: return "requested \(seconds)s ago"
        case ..<3_600: return "requested \(seconds / 60)m ago"
        case ..<86_400: return "requested \(seconds / 3_600)h ago"
        default: return "requested \(seconds / 86_400)d ago"
        }
    }

    static func row(bookId: String, bookEnabled: Bool?, engine: String?,
                    requests: [ControlRequest], now: Date) -> HandRow {
        let latest = bookRequests(bookId: bookId, requests: requests).first
        var requested: String?
        if let value = latest?.value, case let .bookConfigure(change) = value {
            requested = change.enabled ? "Turn on" : "Turn off"
        }
        let state = latest.map(stateWord)
        let note = latest?.note?.trimmingCharacters(in: .whitespacesAndNewlines)
        return HandRow(bookId: bookId,
                       engine: engine ?? MonitorPresentation.notReported,
                       runnerState: bookEnabled.map { $0 ? "On" : "Off" } ?? MonitorPresentation.notReported,
                       runnerTone: bookEnabled.map { $0 ? LeafTone.gain : .warn } ?? .stale,
                       requested: requested, state: state, stateTone: stateTone(state),
                       age: latest.map { ageText(requestedAt: $0.requestedDate, now: now) },
                       note: note?.isEmpty == false ? note : nil, requestId: latest?.id)
    }

    /// Exception first: pending, then rejected, then any other request, then books with none; book id within.
    static func ordered(_ rows: [HandRow]) -> [HandRow] {
        func rank(_ row: HandRow) -> Int {
            switch row.state {
            case "Pending"?: return 0
            case "Rejected"?: return 1
            case .some: return 2
            case nil: return 3
            }
        }
        return rows.sorted { rank($0) != rank($1) ? rank($0) < rank($1) : $0.bookId < $1.bookId }
    }

    static func rows(books: [Book], engines: [Engine], requests: [ControlRequest], now: Date) -> [HandRow] {
        let requestBooks = requests.compactMap { request -> String? in
            guard let value = request.value, case let .bookConfigure(change) = value else { return nil }
            return change.bookId
        }
        let bookIds = Set(books.map(\.bookId) + requestBooks)
        return ordered(bookIds.sorted().flatMap { bookId -> [HandRow] in
            let book = books.first { $0.bookId == bookId }
            let engine = engines.first { $0.boundBooks?.contains(bookId) == true }
            let history = bookRequests(bookId: bookId, requests: requests)
            if history.isEmpty {
                return [row(bookId: bookId, bookEnabled: book?.enabled, engine: engine?.name ?? engine?.engineId,
                            requests: [], now: now)]
            }
            return history.map { request in
                row(bookId: bookId, bookEnabled: book?.enabled, engine: engine?.name ?? engine?.engineId,
                    requests: [request], now: now)
            }
        })
    }

    static func summary(_ rows: [HandRow]) -> String {
        let pending = rows.filter { $0.state == "Pending" }.count
        let rejected = rows.filter { $0.state == "Rejected" }.count
        return "\(pending) pending · \(rejected) rejected · \(Set(rows.map(\.bookId)).count) books in this report"
    }

    private var cooldownCaption: String {
        let cooling = books.filter { book in
            book.kalshiBook.eval?.candidates?.contains { $0.gate == "skip_refire" } == true
        }
        return cooling.isEmpty ? "cooldowns for every book: none active"
            : "cooldowns active for \(cooling.count) books"
    }

    private func handRow(_ row: HandRow) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                OneLine(row.bookId, truncation: .middle).font(LeafType.ticker)
                Spacer(minLength: 4)
                if let state = row.state {
                    StateInk(state, tone: row.stateTone)
                        .accessibilityIdentifier("books.hand.\(row.bookId).state")
                }
            }
            VStack(alignment: .leading, spacing: 6) {
                StateInk(row.engine, tone: .stale, symbol: "gearshape.2")
                    .accessibilityLabel("Engine \(row.engine)")
                Text("Runner reports \(row.runnerState)")
                    .font(LeafType.meta)
                    .foregroundStyle(row.runnerState == MonitorPresentation.notReported
                                     ? LeafTheme.inkMuted : row.runnerTone.color)
                    .accessibilityIdentifier("books.hand.\(row.bookId).runner")
            }
            if let requested = row.requested {
                Text([requested, row.age].compactMap { $0 }.joined(separator: " · "))
                    .font(LeafType.meta)
                    .foregroundStyle(LeafTheme.inkMuted)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("books.hand.\(row.bookId).request")
            } else {
                Caption("No request on record", expandable: false)
            }
            if let note = row.note {
                Caption(note, tone: .warn)
            }
        }
        .padding(.vertical, 2)
        .fixedSize(horizontal: false, vertical: true)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("books.hand.\(row.bookId)")
    }

    private func rowList(_ rows: [HandRow]) -> some View {
        ForEach(Array(rows.enumerated()), id: \.element.id) { entry in
            if entry.offset > 0 { Divider().overlay(LeafTheme.line) }
            handRow(entry.element)
        }
    }

    var body: some View {
        let all = Self.rows(books: books, engines: engines, requests: requests, now: now)
        let preview = OrdersCard.preview(count: all.count, noun: "request and book rows")
        FlatCard(title: "Needs a hand", trailing: Self.summary(all)) {
            Caption(cooldownCaption, expandable: false)
            VStack(alignment: .leading, spacing: 8) {
                rowList(Array(all.prefix(preview.shown)))
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("books.handTable")
            if let label = preview.allLabel {
                NavigationLink {
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 8) { rowList(all) }
                            .padding(16)
                    }
                    .accessibilityIdentifier("books.hand.list")
                    .leafScreenBackground()
                    .foregroundStyle(LeafTheme.ink)
                    .navigationTitle("Needs a hand")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar(.visible, for: .navigationBar)
                } label: {
                    HStack(spacing: 8) {
                        OneLine(label).font(LeafType.body)
                        Spacer(minLength: 8)
                        Image(systemName: "chevron.right").font(LeafType.meta).accessibilityHidden(true)
                    }
                    .foregroundStyle(LeafTheme.ink)
                    .frame(minHeight: 44)
                    .contentShape(Rectangle())
                    .accessibilityIdentifier("books.hand.all")
                }
                .buttonStyle(.plain)
            }
            Caption("Runner reports is the published book state; it does not prove that a particular request was applied. Request outcomes are shown separately.",
                    expandable: true)
        }
    }
}
