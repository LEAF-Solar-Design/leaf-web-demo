import SwiftUI
import LeafHFTCore

@MainActor struct MoneyCard: View {
    @Environment<AppState>(AppState.self) private var state
    @Binding var range: LeafHFTCore.HistoryRange
    let now: Date
    @State private var lastSeen: Seen?
    @State private var shownSince: Seen?

    /// The realized P/L the owner saw when they last left Monitor.
    struct Seen: Equatable {
        let range: LeafHFTCore.HistoryRange
        let pnlCents: Decimal
        let at: Date
    }

    /// Period figures summed from runner-reported closed trades; nothing is recomputed from prices.
    struct Figures: Equatable {
        let pnlCents: Decimal?
        let returnPercent: Decimal?
        let feesCents: Decimal?
        let closedTrades: Int
        let basisTrades: Int
    }

    static func rangeSeconds(_ range: LeafHFTCore.HistoryRange) -> TimeInterval? {
        switch range {
        case .hour: return 3_600
        case .fourHours: return 4 * 3_600
        case .twelveHours: return 12 * 3_600
        case .day: return 86_400
        case .week: return 7 * 86_400
        case .month: return 30 * 86_400
        case .all: return nil
        }
    }

    static func periodText(_ range: LeafHFTCore.HistoryRange) -> String {
        range == .all ? "all reported history" : "the last \(range.label)"
    }

    private static let timeFormatters: (ISO8601DateFormatter, ISO8601DateFormatter) = {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let whole = ISO8601DateFormatter()
        whole.formatOptions = [.withInternetDateTime]
        return (fractional, whole)
    }()

    static func date(_ value: String) -> Date? {
        timeFormatters.0.date(from: value) ?? timeFormatters.1.date(from: value)
    }

    static func closedTrades(activity: RunnerActivity?, range: LeafHFTCore.HistoryRange, now: Date) -> [RunnerActivityRow] {
        let start = rangeSeconds(range).map { now.addingTimeInterval(-$0) }
        return (activity?.fills ?? []).filter { row in
            guard row.pnlCents != nil, let occurred = date(row.occurredAt), occurred <= now else { return false }
            return start.map { occurred >= $0 } ?? true
        }
    }

    static func figures(activity: RunnerActivity?, range: LeafHFTCore.HistoryRange, now: Date) -> Figures {
        guard activity != nil else {
            return Figures(pnlCents: nil, returnPercent: nil, feesCents: nil, closedTrades: 0, basisTrades: 0)
        }
        let trades = closedTrades(activity: activity, range: range, now: now)
        let pnl = trades.compactMap(\.pnlCents).reduce(0, +)
        let bases = trades.compactMap(\.costBasisCents)
        let basis = bases.reduce(0, +)
        let fees = trades.compactMap(\.feeCents)
        return Figures(pnlCents: pnl, returnPercent: bases.count == trades.count && basis > 0 ? pnl / basis * 100 : nil,
                       feesCents: fees.count == trades.count ? fees.reduce(0, +) : nil,
                       closedTrades: trades.count, basisTrades: bases.count)
    }

    static func realizedCaption(range: LeafHFTCore.HistoryRange, figures: Figures) -> String {
        guard figures.pnlCents != nil else {
            return "Realized P/L over \(periodText(range)) · runner trades not reported"
        }
        let count = figures.closedTrades
        return "Realized P/L over \(periodText(range)) · sum of \(count) reported closed trade\(count == 1 ? "" : "s"). Full-period trade coverage and fee inclusion are not reported."
    }

    /// Names what each figure is measured over, so period figures and balance figures are not confused.
    static func basisNote(range: LeafHFTCore.HistoryRange, figures: Figures) -> String {
        let returnPart: String
        if figures.pnlCents == nil {
            returnPart = "Return and fees: not reported."
        } else if figures.basisTrades < figures.closedTrades {
            returnPart = "Return for \(periodText(range)): not reported; cost basis is missing for some reported closed trades."
        } else if figures.returnPercent == nil {
            returnPart = "Return: not reported, these trades carry no positive total cost basis."
        } else {
            returnPart = "Return: realized P/L ÷ cost basis of the same \(figures.closedTrades) trade\(figures.closedTrades == 1 ? "" : "s")."
        }
        let feesPart = figures.pnlCents == nil ? "" : figures.feesCents == nil
            ? " Fees for the reported closed trades: not reported for every trade."
            : " Fees: reported on the same trades and shown beside P/L; this card neither adds nor subtracts them."
        return returnPart + feesPart
            + " Account value is cash plus open positions at market, frozen at close, not a \(range.label) figure."
            + " Cash is the latest Kalshi balance read, not a \(range.label) figure; \(KashbotTradingPocket.label) below is a separate breakdown field from that read. Its account name is not reported."
    }

    static func clockText(_ date: Date, now: Date, timeZone: TimeZone = .current) -> String {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = timeZone
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = timeZone
        formatter.dateFormat = calendar.isDate(date, inSameDayAs: now) ? "h:mm a" : "MMM d, h:mm a"
        return formatter.string(from: date)
    }

    /// Phone receipt time; do not substitute a producer timestamp for a read time.
    static func tradesTime(activity: RunnerActivity?, observedAt: Date?) -> Date? {
        guard activity != nil else { return nil }
        return observedAt
    }

    /// A single footer keeps independent source read times explicit.
    static func asOfText(tradesAt: Date?, balanceAt: Date?, now: Date, timeZone: TimeZone = .current) -> String {
        switch (tradesAt, balanceAt) {
        case let (trades?, balance?):
            return "As of reads: runner trades \(clockText(trades, now: now, timeZone: timeZone)); Kalshi balance \(clockText(balance, now: now, timeZone: timeZone)). Source update times may differ."
        case let (trades?, nil):
            return "As of read: runner trades \(clockText(trades, now: now, timeZone: timeZone)); Kalshi balance read time not reported"
        case let (nil, balance?):
            return "As of read: Kalshi balance \(clockText(balance, now: now, timeZone: timeZone)); runner trades read time not reported"
        case (nil, nil):
            return "As of: not reported"
        }
    }

    /// Keep the first displayed figure for this period, including on the first visit or after loading.
    static func comparisonBaseline(seen: Seen?, range: LeafHFTCore.HistoryRange,
                                   pnlCents: Decimal?, now: Date) -> Seen? {
        if let seen, seen.range == range { return seen }
        return pnlCents.map { Seen(range: range, pnlCents: $0, at: now) }
    }

    /// A change marker for the same period only; nil when nothing changed or the period differs.
    static func sinceLastLookedText(seen: Seen?, range: LeafHFTCore.HistoryRange, pnlCents: Decimal?,
                                    now: Date, timeZone: TimeZone = .current) -> String? {
        guard let seen, seen.range == range, let pnlCents, pnlCents != seen.pnlCents else { return nil }
        let delta = NSDecimalNumber(decimal: pnlCents - seen.pnlCents).intValue
        return "\(delta > 0 ? "+" : "")\(Cents(delta).formatted()) in \(range.label) realized P/L since you looked at \(clockText(seen.at, now: now, timeZone: timeZone)). The rolling window or reported trades may have changed."
    }

    private func percent(_ value: Decimal?) -> String? {
        guard let value else { return nil }
        return NSDecimalNumber(decimal: value).doubleValue
            .formatted(.number.precision(.fractionLength(0...1)).locale(Locale(identifier: "en_US"))) + "%"
    }

    private func money(_ value: Decimal?) -> String? {
        guard let value else { return nil }
        return Cents(NSDecimalNumber(decimal: value).intValue).formatted()
    }

    private var valuationBasis: String {
        var terms = ["Cash + positions at market"]
        let live = state.markedPortfolio?.counts[.live] ?? 0
        let frozen = state.markedPortfolio?.counts[.frozen] ?? 0
        if live > 0 { terms.append("\(live) live") }
        if frozen > 0 { terms.append("\(frozen) frozen at close") }
        return terms.joined(separator: " · ")
    }

    static func positionsReadNote(error: String?, observedAt: Date?, now: Date) -> String? {
        guard let error else { return nil }
        let age = observedAt.map { ageDescription(observedAt: $0, now: now) } ?? "read time not reported"
        return "Account value uses the last positions read (\(age)). \(error)"
    }

    private var positionsReadNote: String? {
        let fixtureFailure = state.fixtureMode.enabled
            && ProcessInfo.processInfo.arguments.contains("-LEAFHFT_POSITIONS_FAILURE")
        return Self.positionsReadNote(error: fixtureFailure ? "Could not refresh positions." : state.positionsError,
                                      observedAt: state.positionsObservedAt, now: now)
    }

    var body: some View {
        let figures = Self.figures(activity: state.runnerActivity, range: range, now: now)
        let pnl = figures.pnlCents.map { NSDecimalNumber(decimal: $0).intValue }
        let tradesAt = Self.tradesTime(activity: state.runnerActivity, observedAt: state.runnerActivityObservedAt)
        let balanceAt = state.balance == nil ? nil : state.balanceObservedAt
        return FlatCard(title: "Account P/L") {
            OneLine(pnl.map { LeafFormat.signedMoney(cents: $0) } ?? MonitorPresentation.notReported)
                .leafNumeral(.hero)
                .foregroundStyle(pnl.map { LeafTone.forDelta(cents: $0).color } ?? LeafTheme.inkMuted)
                .accessibilityIdentifier("account.tile.pnl")
            Caption(Self.realizedCaption(range: range, figures: figures), identifier: "account.money.period")
                .accessibilityIdentifier("account.money.period")
            if let change = Self.sinceLastLookedText(seen: shownSince, range: range, pnlCents: figures.pnlCents, now: now) {
                Caption(change, identifier: "account.money.sinceLastLooked")
                    .accessibilityIdentifier("account.money.sinceLastLooked")
            }
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], alignment: .leading, spacing: 10) {
                MonitorStat("Return on cost · \(range.label)", value: percent(figures.returnPercent), style: .large,
                            tone: pnl.map { LeafTone.forDelta(cents: $0) } ?? .stale)
                    .accessibilityIdentifier("account.tile.return")
                MonitorStat("Fees · \(range.label)", value: money(figures.feesCents), style: .large)
                    .accessibilityIdentifier("account.tile.fees")
                MonitorStat("Account value", value: state.markedPortfolio.map { Cents($0.totalCents).formatted() }
                            ?? state.balance?.accountValue?.formatted(), style: .large)
                    .accessibilityIdentifier("account.tile.value")
                MonitorStat("Cash · latest", value: state.balance?.cash?.formatted(), style: .large)
                    .accessibilityIdentifier("account.tile.cash")
            }
            Caption(valuationBasis)
                .accessibilityIdentifier("account.tile.value.basis")
            if let note = positionsReadNote {
                Text(note).font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("account.money.positionsError")
            }
            Caption(Self.basisNote(range: range, figures: figures), identifier: "account.money.basis")
                .accessibilityIdentifier("account.money.basis")
            EquityChart(range: $range, now: now)
            Text(Self.asOfText(tradesAt: tradesAt, balanceAt: balanceAt, now: now))
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("account.money.asOf")
            if let age = state.serverAccountAge(now: now) {
                Caption("via Kashbot · \(age)")
                    .accessibilityLabel("Account data via Kashbot, observed \(age)")
            }
            if let error = state.runnerActivityError {
                Text(error).font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("account.money.activityError")
            }
            if let error = state.kalshiError {
                Text(error).font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("account.money.balanceError")
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("monitor.money")
        .onAppear {
            shownSince = Self.comparisonBaseline(seen: lastSeen, range: range, pnlCents: figures.pnlCents, now: now)
        }
        .onChange(of: range) { _, _ in
            shownSince = Self.comparisonBaseline(seen: nil, range: range, pnlCents: figures.pnlCents, now: now)
        }
        .onChange(of: figures.pnlCents) { _, _ in
            shownSince = Self.comparisonBaseline(seen: shownSince, range: range, pnlCents: figures.pnlCents, now: now)
        }
        .onDisappear {
            if let value = figures.pnlCents { lastSeen = Seen(range: range, pnlCents: value, at: now) }
        }
    }
}

struct MonitorStat: View {
    let label: String
    let value: String?
    let style: LeafNumeralStyle
    let tone: LeafTone

    init(_ label: String, value: String?, style: LeafNumeralStyle = .number, tone: LeafTone = .neutral) {
        self.label = label
        self.value = value
        self.style = style
        self.tone = tone
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
            OneLine(value ?? MonitorPresentation.notReported)
                .leafNumeral(style)
                .foregroundStyle(value == nil ? LeafTheme.inkMuted : tone.color)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
    }
}
