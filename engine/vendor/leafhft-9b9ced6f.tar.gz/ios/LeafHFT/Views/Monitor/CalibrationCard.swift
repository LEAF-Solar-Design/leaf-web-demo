import SwiftUI
import LeafHFTCore

/// Opens the assistant with a prefilled draft in ask mode. It never sends.
private struct AskAssistantKey: EnvironmentKey {
    static let defaultValue = OpenStudioAction { _ in }
}
extension EnvironmentValues {
    var askAssistant: OpenStudioAction {
        get { self[AskAssistantKey.self] }
        set { self[AskAssistantKey.self] = newValue }
    }
}

struct CalibrationCard: View {
    let calibration: EntryCalibration?
    let error: String?
    @Environment(\.askAssistant) private var askAssistant
    @State private var showingAll = false

    static let topCellLimit = 5
    static let adviceLimit = 3

    static func adviceTone(_ advice: EntryCalibration.Advice) -> LeafTone {
        switch advice.verdict {
        case .candidate: return .gain
        case .noGain: return .neutral
        case .insufficientEvidence, .unknown: return .stale
        }
    }

    static func stateMessage(calibration: EntryCalibration?, error: String?) -> String? {
        if error != nil {
            return calibration == nil ? "Calibration is unavailable for this paired account."
                : "Could not refresh calibration. Showing the last result."
        }
        guard let calibration else { return "Loading calibration…" }
        return calibration.summary.entries == 0 ? "No entries in the last 30 days." : nil
    }

    /// Gain within 2 points of the model, loss at a gap of 5 points or more, warn between.
    static func headlineTone(_ summary: EntryCalibration.Summary) -> LeafTone {
        guard let model = summary.modelWinPct, let actual = summary.actualWinPct else { return .stale }
        if actual >= model - 2 { return .gain }
        return model - actual >= 5 ? .loss : .warn
    }

    static func edgeTone(_ summary: EntryCalibration.Summary) -> LeafTone {
        guard let edge = summary.edgeAfterPricePts else { return .stale }
        return edge >= 0 ? .gain : .loss
    }

    static func bucketTone(_ bucket: EntryCalibration.Bucket) -> LeafTone {
        bucket.edgeAfterPricePts >= 0 ? .gain : .loss
    }

    static func cellTone(_ cell: EntryCalibration.GridCell) -> LeafTone {
        cell.deltaCents > 0 ? .gain : cell.deltaCents < 0 ? .loss : .neutral
    }

    static func engineTone(_ engine: EntryCalibration.EngineRow) -> LeafTone {
        engine.realizedCents < 0 ? .loss : .gain
    }

    static func lessonTone(_ lesson: EntryCalibration.Lesson) -> LeafTone {
        switch lesson.severity {
        case .act: return .loss
        case .watch: return .warn
        case .good: return .gain
        case .unknown: return .stale
        }
    }

    private func line(_ text: String, tone: LeafTone = .neutral, identifier: String) -> some View {
        Caption(text, tone: tone, expandable: true, identifier: identifier)
            .accessibilityElement(children: .combine)
            .accessibilityIdentifier(identifier)
    }

    private func lesson(_ item: EntryCalibration.Lesson, identifier: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            line(item.title, tone: Self.lessonTone(item), identifier: identifier)
            line(item.detail, identifier: identifier + ".detail")
        }
    }

    private func fullCalibration(_ calibration: EntryCalibration) -> some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    FlatCard(title: "Lessons") {
                        ForEach(Array(calibration.lessons.enumerated()), id: \.offset) { entry in
                            lesson(entry.element, identifier: "calibration.lessons.\(entry.offset)")
                        }
                    }
                    FlatCard(title: "Probability bands") {
                        ForEach(Array(calibration.buckets.enumerated()), id: \.offset) { entry in
                            line(entry.element.line, tone: Self.bucketTone(entry.element),
                                 identifier: "calibration.bucket.\(entry.offset)")
                        }
                    }
                    FlatCard(title: "Stricter gates") {
                        if let best = calibration.grid.bestLine {
                            line(best, tone: .gain, identifier: "calibration.sheet.best")
                        }
                        line(calibration.grid.walkForwardLine, identifier: "calibration.sheet.walkForward")
                        ForEach(Array(calibration.grid.topCells(Self.topCellLimit).enumerated()), id: \.offset) { entry in
                            line(entry.element.line, tone: Self.cellTone(entry.element),
                                 identifier: "calibration.cell.\(entry.offset)")
                        }
                        line(calibration.grid.note, tone: .stale, identifier: "calibration.sheet.note")
                    }
                    FlatCard(title: "Engines · worst first") {
                        ForEach(Array(calibration.enginesWorstFirst.enumerated()), id: \.offset) { entry in
                            line(entry.element.line, tone: Self.engineTone(entry.element),
                                 identifier: "calibration.engine.\(entry.offset)")
                        }
                    }
                }
                .padding(16)
            }
            .accessibilityIdentifier("calibration.sheet.scroll")
            .leafScreenBackground()
            .foregroundStyle(LeafTheme.ink)
            .navigationTitle("Entry calibration")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { showingAll = false }
                }
            }
        }
    }

    var body: some View {
        FlatCard(title: "Entries") {
            if let message = Self.stateMessage(calibration: calibration, error: error) {
                line(message, tone: error == nil ? .stale : .warn, identifier: "calibration.state")
            }
            if let calibration, calibration.summary.entries > 0 {
                // Caption's initializer identifies More; group its content to expose the caption too.
                line(calibration.summary.headline, tone: Self.headlineTone(calibration.summary),
                     identifier: "calibration.headline")
                line(calibration.summary.edgeLine, tone: Self.edgeTone(calibration.summary),
                     identifier: "calibration.edge")
                line(calibration.summary.coverageLine, identifier: "calibration.coverage")
                if let top = calibration.topLesson { lesson(top, identifier: "calibration.lesson") }
                if let best = calibration.grid.bestLine {
                    line(best, tone: .gain, identifier: "calibration.best")
                }
                let advice = calibration.inlineAdvice(Self.adviceLimit)
                if !advice.isEmpty {
                    OneLine("Assistant advice").font(LeafType.meta)
                        .accessibilityAddTraits(.isHeader)
                        .accessibilityIdentifier("calibration.advice.title")
                    ForEach(Array(advice.enumerated()), id: \.offset) { entry in
                        line(entry.element.line, tone: Self.adviceTone(entry.element),
                             identifier: "calibration.advice.\(entry.offset)")
                    }
                }
                Button { askAssistant(calibration.askPrompt) } label: {
                    HStack(spacing: 8) {
                        OneLine("Ask the assistant").font(LeafType.body)
                        Spacer(minLength: 8)
                        Image(systemName: "bubble.left").font(LeafType.meta).accessibilityHidden(true)
                    }
                    .foregroundStyle(LeafTheme.ink)
                    .frame(minHeight: 44)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityHint("Opens the assistant with a draft question. Nothing is sent.")
                .accessibilityIdentifier("calibration.ask")
                Button { showingAll = true } label: {
                    HStack(spacing: 8) {
                        OneLine("Full calibration").font(LeafType.body)
                        Spacer(minLength: 8)
                        Image(systemName: "chevron.right").font(LeafType.meta).accessibilityHidden(true)
                    }
                    .foregroundStyle(LeafTheme.ink)
                    .frame(minHeight: 44)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityIdentifier("calibration.all")
                .sheet(isPresented: $showingAll) { fullCalibration(calibration) }
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("calibration.card")
    }
}
