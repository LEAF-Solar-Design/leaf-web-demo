import SwiftUI
import LeafHFTCore

@MainActor struct AliveRail: View {
    @Environment<AppState>(AppState.self) private var state
    let now: Date

    private var feeds: [MonitorPresentation.FeedAge] {
        [MonitorPresentation.feedAge(name: "runner", observedAt: state.runnerActivityObservedAt, now: now),
         MonitorPresentation.feedAge(name: "balance", observedAt: state.balanceObservedAt, now: now),
         MonitorPresentation.feedAge(name: "books", observedAt: state.booksObservedAt, now: now),
         MonitorPresentation.feedAge(name: "engines", observedAt: state.enginesObservedAt, now: now)]
    }

    private func tone(_ feed: MonitorPresentation.FeedAge) -> LeafTone {
        switch feed.state {
        case .fresh: return .gain
        case .aging: return .warn
        case .dead: return .loss
        case .absent: return .stale
        }
    }

    private func age(_ feed: MonitorPresentation.FeedAge) -> String {
        guard let seconds = feed.ageSeconds, seconds.isFinite else { return "unknown" }
        return seconds < 60 ? "\(Int(seconds)) s" : "\(Int(min(seconds / 60, Double(Int.max / 2)))) m"
    }

    private func sentence(_ runner: MonitorPresentation.FeedAge) -> String {
        switch runner.state {
        case .fresh: return "runner says live · last push \(age(runner)) ago"
        case .aging: return "not live: the runner's status push is aging"
        case .dead: return "not live: the runner's status push is past 10 m"
        case .absent: return "not live: the runner has not reported a status push"
        }
    }

    private var pairingTone: LeafTone {
        switch state.dashboardPairingState {
        case .paired: return .gain
        case .unpaired: return .loss
        case .unknown: return .stale
        }
    }

    var body: some View {
        let runner = feeds[0]
        FlatCard(title: "Alive") {
            OneLine(sentence(runner)).font(LeafType.body).foregroundStyle(tone(runner).color)
                .accessibilityLabel(sentence(runner))
            ChipRow(identifier: "monitor.feeds") {
                ForEach(feeds, id: \.name) { feed in
                    StateInk("\(feed.name) \(age(feed)) · \(feed.state.rawValue)", tone: tone(feed))
                        .leafNumeral(.small)
                }
            }
            ChipRow(identifier: "monitor.status") {
                StateInk(state.serverAccountAge(now: now) != nil ? "Account · via Kashbot" : "Account · \(state.accountReadability.label)",
                         tone: state.accountReadability == .readable ? .gain : .stale)
                    .accessibilityLabel("Account · \(state.accountReadability.label)\(state.serverAccountAge(now: now).map { ", via Kashbot, observed \($0)" } ?? "")")
                StateInk("Pairing · \(state.dashboardPairingState.label)", tone: pairingTone)
                StateInk("Runner · \(runner.state.rawValue)", tone: tone(runner))
                StateInk("Trading · \(state.automationLabel)",
                         tone: state.kashbotStatus?.automatedTrading == .live ? .gain : .stale)
                if let regime = state.kashbotStatus?.riskRegime {
                    StateInk("Regime · \(regime.label)", tone: regime.id == "owner" ? .warn : .stale)
                        .accessibilityIdentifier("monitor.regime")
                }
            }
            Caption("fresh under 90 s · dead past 10 m", expandable: false)
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("monitor.alive")
    }
}
