import SwiftUI
import Charts
import LeafHFTCore

@MainActor struct EquityChart: View {
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @Environment<AppState>(AppState.self) private var state
    @Binding var range: LeafHFTCore.HistoryRange
    let now: Date

    private struct Point: Identifiable {
        let id: String
        let date: Date
        let dollars: Double
        let metric: String
        let source: String
        let segment: String
    }

    private static let drawBudgetPerSeries = 600

    private struct Drawing {
        var points: [Point] = []
        var singletons: Set<String> = []
        var count = 0
        var minDate: Date?
        var maxDate: Date?
        var minDollars: Double?
        var maxDollars: Double?
        var dates: [Date] { [minDate, maxDate].compactMap { $0 } }
        var dollars: [Double] { [minDollars, maxDollars].compactMap { $0 } }
    }

    private func drawing(now: Date) -> Drawing {
        var result = Drawing()
        for series in [state.cash, state.accountValue, state.runnerCash, state.runnerAccountValue] {
            let metric = series.metric == AccountMetric.cash ? "Cash" : "Account value"
            let source = series.source == ObservationSource.phone ? "this phone" : "runner"
            var previous: Date?
            var segment = 0
            var runs: [(group: String, samples: [ChartReduction.Sample])] = []
            var seriesCount = 0
            for observation in series.selected(range, now: now) {
                let cents = series.metric == AccountMetric.cash ? observation.cashCents : observation.portfolioValueCents
                guard let cents else { previous = nil; segment += 1; continue }
                if let previous, observation.capturedAt.timeIntervalSince(previous) > 15 * 60 { segment += 1 }
                let group = "\(metric)-\(source)-\(segment)"
                let date = observation.capturedAt
                let dollars = Double(cents) / 100
                result.count += 1
                seriesCount += 1
                result.minDate = min(result.minDate ?? date, date)
                result.maxDate = max(result.maxDate ?? date, date)
                result.minDollars = min(result.minDollars ?? dollars, dollars)
                result.maxDollars = max(result.maxDollars ?? dollars, dollars)
                if runs.last?.group != group { runs.append((group, [])) }
                runs[runs.count - 1].samples.append(ChartReduction.Sample(date: date, value: dollars))
                previous = observation.capturedAt
            }
            let budgets = ChartReduction.budgets(runCounts: runs.map { $0.samples.count }, total: Self.drawBudgetPerSeries)
            for (index, run) in runs.enumerated() {
                if run.samples.count == 1 { result.singletons.insert(run.group) }
                let samples = seriesCount > Self.drawBudgetPerSeries
                    ? ChartReduction.reduce(run.samples, maxPoints: budgets[index]) : run.samples
                for sample in samples {
                    result.points.append(Point(id: "\(run.group)-\(sample.date.timeIntervalSince1970)",
                        date: sample.date, dollars: sample.value,
                        metric: metric, source: source, segment: run.group))
                }
            }
        }
        return result
    }

    private var rangePicker: some View {
        Picker("History range", selection: $range) {
            ForEach(LeafHFTCore.HistoryRange.allCases, id: \.self) { option in
                OneLine(option.label).tag(option)
            }
        }
        .pickerStyle(.menu)
        .tint(LeafTheme.ink)
        .font(LeafType.meta)
        .accessibilityIdentifier("account.range")
    }

    /// Says when the observations span less than the selected range, so a range P/L beside a flat chart is explained.
    static func coverageText(range: LeafHFTCore.HistoryRange, now: Date, dates: [Date],
                             timeZone: TimeZone = .current) -> String? {
        guard let seconds = MoneyCard.rangeSeconds(range) else { return nil }
        let selected = dates.filter { $0 >= now.addingTimeInterval(-seconds) && $0 <= now }
        guard let first = selected.min(), let last = selected.max() else {
            return "No chart observations in \(MoneyCard.periodText(range)). Trade coverage is independent of chart coverage."
        }
        guard first > now.addingTimeInterval(-seconds) || last < now else { return nil }
        let from = MoneyCard.clockText(first, now: now, timeZone: timeZone)
        let to = MoneyCard.clockText(last, now: now, timeZone: timeZone)
        return "Chart observations span \(from) to \(to), not the full \(range.label); gaps may remain within that span. Realized P/L uses reported closed trades in \(MoneyCard.periodText(range)), not chart movement."
    }

    static func floorCents(floors: [Int]) -> Int { floors.max() ?? CashFloorPolicy.fallbackCents }

    static func balanceAccessibility(cash: Int?, account: Int?) -> String {
        let cashText = cash.map { "\($0) cents" } ?? "not reported"
        let accountText = account.map { "\($0) cents" } ?? "not reported"
        return "latest Kalshi balance read: cash \(cashText); account value \(accountText)"
    }

    /// Names the floor and whether an engine published it or the app fell back to its default.
    static func floorLabel(floors: [Int]) -> String {
        let amount = Cents(floorCents(floors: floors)).formatted()
        if floors.isEmpty { return "Entry cash floor \(amount) (app default, no engine reports one)" }
        return Set(floors).count > 1 ? "Highest entry cash floor \(amount)" : "Entry cash floor \(amount)"
    }

    /// Legend entry only when the floor rule is drawn inside the chart.
    static func floorLegend(floors: [Int], drawn: Bool) -> String? {
        guard drawn else { return nil }
        return "Floor \(Cents(floorCents(floors: floors)).formatted())\(floors.isEmpty ? " default" : "") · dashed"
    }

    private var publishedCashFloors: [Int] {
        let accounts = (state.engines?.accounts ?? []).filter { $0.configurable && $0.id != "unassigned" }
        let accountId = accounts.count == 1 ? accounts[0].id : nil
        return (state.engines?.engines ?? []).compactMap { engine in
            let account = engine.configuration?.accounts.first { $0.accountId == accountId }
            let policy = account?.effective.policy ?? engine.configuration?.global.policy ?? engine.policy
            return CashFloorPolicy.cents(policy: policy)
        }
    }

    var body: some View {
        let drawing = self.drawing(now: now)
        let visiblePoints = drawing.points
        let domain = AccountChartDomain(dates: drawing.dates, dollars: drawing.dollars)
        let floors = publishedCashFloors
        let floorDollars = Double(Self.floorCents(floors: floors)) / 100
        let floorLabel = Self.floorLabel(floors: floors)
        let floorLegend = Self.floorLegend(floors: floors, drawn: domain.y.contains(floorDollars))
        let coverage = Self.coverageText(range: range, now: now, dates: drawing.dates)
        return Group {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 12) {
                    OneLine("Equity · USD").font(LeafType.micro).fixedSize()
                    Spacer(minLength: 0)
                    rangePicker
                }
                Chart {
                    ForEach(visiblePoints) { point in
                        LineMark(x: .value("Time", point.date), y: .value("Dollars", point.dollars),
                                 series: .value("Run", point.segment))
                            .foregroundStyle(by: .value("Metric", point.metric))
                            .lineStyle(StrokeStyle(lineWidth: 2, dash: point.metric == "Cash" ? [5, 3] : (point.source == "runner" ? [] : [2, 3])))
                            .interpolationMethod(.linear)
                        if visiblePoints.count <= 400 || drawing.singletons.contains(point.segment) {
                            PointMark(x: .value("Time", point.date), y: .value("Dollars", point.dollars))
                                .foregroundStyle(by: .value("Metric", point.metric))
                                .symbolSize(8)
                        }
                    }
                    if domain.y.contains(floorDollars) {
                        RuleMark(y: .value("Entry cash floor", floorDollars))
                            .foregroundStyle(LeafTheme.warn)
                            .lineStyle(StrokeStyle(dash: [3, 3]))
                            .annotation(position: .top, alignment: .leading) {
                                if !dynamicTypeSize.isAccessibilitySize {
                                    OneLine(floorLabel).font(LeafType.micro).foregroundStyle(LeafTheme.warn)
                                }
                            }
                    }
                }
                .chartXScale(domain: domain.x)
                .chartYScale(domain: domain.y)
                .chartForegroundStyleScale(["Account value": LeafTheme.series1, "Cash": LeafTheme.inkMuted])
                .chartXAxis {
                    AxisMarks { _ in
                        AxisGridLine().foregroundStyle(LeafTheme.line)
                        AxisTick().foregroundStyle(LeafTheme.line)
                        AxisValueLabel().foregroundStyle(LeafTheme.inkMuted)
                    }
                }
                .chartYAxis {
                    AxisMarks { _ in
                        AxisGridLine().foregroundStyle(LeafTheme.line)
                        AxisTick().foregroundStyle(LeafTheme.line)
                        AxisValueLabel().foregroundStyle(LeafTheme.inkMuted)
                    }
                }
                .chartXAxis(dynamicTypeSize.isAccessibilitySize ? .hidden : .automatic)
                .chartYAxis(dynamicTypeSize.isAccessibilitySize ? .hidden : .automatic)
                .chartLegend(.hidden)
                .chartYAxisLabel(dynamicTypeSize.isAccessibilitySize ? "" : "USD")
                .foregroundStyle(LeafTheme.inkMuted)
                .frame(height: 220)
                .accessibilityElement(children: .ignore)
                .accessibilityIdentifier("account.chart")
                .accessibilityLabel("Equity chart")
                .accessibilityValue(Text(verbatim: "\(range.rawValue): \(drawing.count) points; \(Self.balanceAccessibility(cash: state.balance?.balance, account: state.balance?.accountValue?.cents.rawValue)); x \(domain.x.lowerBound.timeIntervalSince1970)...\(domain.x.upperBound.timeIntervalSince1970); y \(domain.y.lowerBound)...\(domain.y.upperBound)"))
                if dynamicTypeSize.isAccessibilitySize {
                    Caption(domain.y.contains(floorDollars) ? "Cash and account value in USD. Dashed rule: \(floorLabel)." : "Cash and account value in USD.")
                    if let first = drawing.minDate, let last = drawing.maxDate {
                        Caption("\(first.formatted(date: .abbreviated, time: .shortened)) to \(last.formatted(date: .abbreviated, time: .shortened))")
                    }
                }
                if let coverage {
                    Caption(coverage, identifier: "account.chart.coverage")
                        .accessibilityIdentifier("account.chart.coverage")
                }
                ChipRow(identifier: "monitor.chartLegend") {
                    OneLine("Portfolio").foregroundStyle(LeafTheme.series1)
                    OneLine("Cash · dashed").foregroundStyle(LeafTheme.inkMuted)
                    if let floorLegend {
                        OneLine(floorLegend).foregroundStyle(LeafTheme.warn)
                            .accessibilityIdentifier("monitor.chartLegend.floor")
                    }
                }
                .font(LeafType.micro)
                Caption("Portfolio sources: runner (solid), this phone (dotted)")
                if state.balanceStale {
                    Caption("Delayed account data", tone: .warn)
                }
                if let error = state.accountHistoryError {
                    Caption("Runner chart history: \(error)", tone: .warn)
                        .accessibilityIdentifier("account.chart.historyError")
                }
                if let error = state.storeError {
                    Caption(error, tone: .warn)
                        .accessibilityIdentifier("account.chart.storeError")
                }
                if visiblePoints.isEmpty {
                    Caption("No observations in this range.")
                }
                MonitorStat(KashbotTradingPocket.label, value: state.balance?.tradingPocketCents?.formatted(), style: .small)
            }
        }
    }

}
