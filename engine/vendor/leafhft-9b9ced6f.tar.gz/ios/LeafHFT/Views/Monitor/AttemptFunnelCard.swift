import SwiftUI
import Charts
import LeafHFTCore

struct AttemptFunnelCard: View {
    let funnel: AttemptFunnel?
    let error: String?

    static let noDataText = "The runner starts reporting every attempt after its next deploy."

    static func stateMessage(funnel: AttemptFunnel?, error: String?) -> String? {
        if error != nil {
            return funnel == nil ? "Attempt funnel is unavailable for this paired account."
                : "Could not refresh the attempt funnel. Showing the last result."
        }
        return funnel == nil ? "Loading attempt funnel…" : nil
    }

    static func stageColor(_ stage: AttemptFunnel.Stage) -> Color {
        switch stage {
        case .halted: return LeafTheme.loss
        case .riskBlocked: return LeafTheme.loss.opacity(0.85)
        case .conflict: return LeafTheme.loss.opacity(0.7)
        case .tooLate: return LeafTheme.loss.opacity(0.55)
        case .unexplained, .unknown: return LeafTheme.stale
        case .sendError: return LeafTheme.warn
        case .zeroFill: return LeafTheme.warn.opacity(0.8)
        case .partial: return LeafTheme.warn.opacity(0.6)
        case .filled: return LeafTheme.gain
        }
    }

    private func line(_ text: String, identifier: String, warning: Bool = false) -> some View {
        Text(text)
            .font(LeafType.body)
            .foregroundStyle(warning ? LeafTheme.warn : LeafTheme.ink)
            .fixedSize(horizontal: false, vertical: true)
            .accessibilityIdentifier(identifier)
    }

    private func lossRow(_ row: AttemptFunnel.StageRow) -> some View {
        DisclosureGroup {
            ForEach(Array(row.reasons.enumerated()), id: \.offset) { entry in
                KeyValueRow(entry.element.reason, value: LeafFormat.count(entry.element.count))
            }
        } label: {
            VStack(alignment: .leading, spacing: 4) {
                Text(row.label).font(LeafType.body)
                Text("\(LeafFormat.count(row.count)) · \(AttemptFunnel.number(row.pct))%")
                    .leafNumeral(.small).foregroundStyle(LeafTheme.inkMuted)
            }
            .fixedSize(horizontal: false, vertical: true)
        }
        .tint(LeafTheme.inkMuted)
    }

    private func chart(_ funnel: AttemptFunnel) -> some View {
        Chart(funnel.stageRows, id: \.stage) { row in
            BarMark(x: .value("Attempts", row.count), y: .value("Window", funnel.windowLabel), stacking: .standard)
                .foregroundStyle(Self.stageColor(row.stage))
                .accessibilityLabel("\(row.label): \(row.count)")
                .accessibilityValue("\(AttemptFunnel.number(row.pct))%")
        }
        .chartXAxis(.hidden)
        .chartYAxis(.hidden)
        .chartLegend(.hidden)
        .frame(height: 32)
        .accessibilityIdentifier("attemptFunnel.chart")
    }

    var body: some View {
        LeafCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader("Where attempts die", trailing: funnel?.windowLabel)
                    .accessibilityIdentifier("attemptFunnel.title")
                if let message = Self.stateMessage(funnel: funnel, error: error) {
                    line(message, identifier: "attemptFunnel.state", warning: error != nil)
                }
                if let funnel {
                    line(funnel.headline, identifier: "attemptFunnel.headline")
                    if funnel.status == .noData {
                        line(Self.noDataText, identifier: "attemptFunnel.noData")
                        if let interim = funnel.interimLine {
                            line(interim, identifier: "attemptFunnel.interim")
                        }
                    } else {
                        line(funnel.fillRateText, identifier: "attemptFunnel.fillRate")
                        chart(funnel)
                        ForEach(funnel.lossRows, id: \.stage) { row in lossRow(row) }
                        Divider().overlay(LeafTheme.line)
                        VStack(alignment: .leading, spacing: 8) {
                            KeyValueRow("Decide to send", value: funnel.latencyLine(.decisionToSubmitMs))
                            KeyValueRow("Send to venue ack", value: funnel.latencyLine(.submitToAckMs))
                            KeyValueRow("Quote age at decision", value: funnel.latencyLine(.quoteAgeMs))
                        }
                        ForEach(Array(funnel.engines.prefix(3).enumerated()), id: \.offset) { entry in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(entry.element.engineId).font(LeafType.ticker)
                                Text(entry.element.fillText).font(LeafType.meta)
                                if let loss = entry.element.topLoss {
                                    Text(loss.stage.label).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                                }
                            }
                            .fixedSize(horizontal: false, vertical: true)
                            .accessibilityElement(children: .combine)
                        }
                    }
                }
            }
        }
        .foregroundStyle(LeafTheme.ink)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("attemptFunnel.card")
    }
}
