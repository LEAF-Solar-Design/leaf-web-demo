import SwiftUI
import LeafHFTCore

struct ExitsCard: View {
    let ledger: ExitLedger?
    let error: String?
    @State private var showingAll = false

    static func stateMessage(ledger: ExitLedger?, error: String?) -> String? {
        if error != nil {
            return ledger == nil ? "Cashouts are unavailable for this paired account."
                : "Could not refresh cashouts. Showing the last ledger."
        }
        guard let ledger else { return "Loading cashouts…" }
        return ledger.summary.exits == 0 ? "No cashouts in the last 30 days." : nil
    }

    static func headlineTone(_ summary: ExitLedger.Summary) -> LeafTone {
        guard summary.resolved > 0 else { return .stale }
        return summary.netVsHoldCents > 0 ? .gain : summary.netVsHoldCents < 0 ? .loss : .neutral
    }

    static func rowTone(_ row: ExitLedger.Row) -> LeafTone {
        switch row.verdict {
        case .saved: return .gain
        case .gaveBack: return .loss
        case .even: return .neutral
        case .pending, .unknown: return .stale
        }
    }

    static func priceTone(_ summary: ExitLedger.Summary) -> LeafTone {
        summary.worseThanLimitCount > 0 ? .loss : .gain
    }

    private func lessonTone(_ lesson: ExitLedger.Lesson) -> LeafTone {
        switch lesson.severity {
        case .act: return .loss
        case .watch: return .warn
        case .good: return .gain
        case .unknown: return .stale
        }
    }

    private func price(_ value: Decimal?) -> String {
        guard let value else { return "not reported" }
        return "\(NSDecimalNumber(decimal: value).stringValue)¢"
    }

    private func time(_ value: String?) -> String {
        guard let value, let date = OrdersCard.parseTime(value) else { return "Time unavailable" }
        return date.formatted(date: .abbreviated, time: .standard)
    }

    private func row(_ item: ExitLedger.Row, index: Int, prefix: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            OneLine(item.ticker, truncation: .middle).font(LeafType.ticker)
                .accessibilityIdentifier("\(prefix).\(index)")
            StateInk(item.engineId ?? "Engine unknown", tone: .stale, symbol: "gearshape.2")
            Caption(item.verdictLabel, tone: Self.rowTone(item), expandable: true,
                    identifier: "\(prefix).\(index).verdict")
                .leafNumeral(.small)
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("\(prefix).\(index).verdict")
            Caption("Exit \(price(item.exitPriceCents)) · limit \(price(item.limitPriceCents))",
                    identifier: "\(prefix).\(index).price")
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("\(prefix).\(index).price")
            Caption(time(item.filledAt), identifier: "\(prefix).\(index).time")
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("\(prefix).\(index).time")
        }
        .padding(.vertical, 2)
        .fixedSize(horizontal: false, vertical: true)
    }

    private func lesson(_ item: ExitLedger.Lesson, identifier: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Caption(item.title, tone: lessonTone(item), expandable: true, identifier: identifier)
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier(identifier)
            Caption(item.detail, expandable: true, identifier: identifier + ".detail")
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier(identifier + ".detail")
        }
    }

    private func percent(_ value: Double) -> String {
        String(format: "%.1f", value).replacingOccurrences(of: ".0", with: "")
    }

    private func fullLedger(_ ledger: ExitLedger) -> some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    FlatCard(title: "Lessons") {
                        ForEach(Array(ledger.lessons.enumerated()), id: \.offset) { entry in
                            lesson(entry.element, identifier: "exits.lessons.\(entry.offset)")
                        }
                    }
                    FlatCard(title: "Calibration") {
                        ForEach(Array(ledger.calibration.enumerated()), id: \.offset) { entry in
                            Caption("Model said \(percent(entry.element.modelWinPct))% · actually won \(percent(entry.element.actualWinPct))% · \(ExitLedger.money(entry.element.netVsHoldCents))", expandable: true,
                                    identifier: "exits.calibration.\(entry.offset)")
                                .accessibilityElement(children: .combine)
                                .accessibilityIdentifier("exits.calibration.\(entry.offset)")
                        }
                    }
                    FlatCard(title: "Engines · worst first") {
                        ForEach(Array(ledger.engines.sorted { $0.netVsHoldCents < $1.netVsHoldCents }.enumerated()), id: \.offset) { entry in
                            Caption("\(entry.element.engineId ?? "Engine unknown") · \(ExitLedger.money(entry.element.netVsHoldCents)) vs hold", tone: entry.element.netVsHoldCents < 0 ? .loss : .gain, expandable: true,
                                    identifier: "exits.engine.\(entry.offset)")
                                .accessibilityElement(children: .combine)
                                .accessibilityIdentifier("exits.engine.\(entry.offset)")
                        }
                    }
                    FlatCard(title: "Every cashout") {
                        ForEach(Array(ledger.rows.enumerated()), id: \.offset) { entry in
                            if entry.offset > 0 { Divider().overlay(LeafTheme.line) }
                            row(entry.element, index: entry.offset, prefix: "exits.sheet.row")
                        }
                    }
                }
                .padding(16)
            }
            .accessibilityIdentifier("exits.sheet.scroll")
            .leafScreenBackground()
            .foregroundStyle(LeafTheme.ink)
            .navigationTitle("Cashouts")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { showingAll = false }
                }
            }
        }
    }

    var body: some View {
        FlatCard(title: "Cashouts") {
            if let message = Self.stateMessage(ledger: ledger, error: error) {
                Caption(message, tone: error == nil ? .stale : .warn, expandable: true,
                        identifier: "exits.state")
                    .accessibilityElement(children: .combine)
                    .accessibilityIdentifier("exits.state")
            }
            if let ledger, ledger.summary.exits > 0 {
                // Caption's initializer identifies More; group its content to expose the caption too.
                Caption(ledger.summary.headline, tone: Self.headlineTone(ledger.summary), expandable: true,
                        identifier: "exits.headline")
                    .accessibilityElement(children: .combine)
                    .accessibilityIdentifier("exits.headline")
                Caption(ledger.summary.tally, expandable: true, identifier: "exits.tally")
                    .accessibilityElement(children: .combine)
                    .accessibilityIdentifier("exits.tally")
                Caption(ledger.summary.priceLine, tone: Self.priceTone(ledger.summary), expandable: true,
                        identifier: "exits.price")
                    .accessibilityElement(children: .combine)
                    .accessibilityIdentifier("exits.price")
                Caption(ledger.summary.timingLine, expandable: true, identifier: "exits.timing")
                    .accessibilityElement(children: .combine)
                    .accessibilityIdentifier("exits.timing")
                if let top = ledger.topLesson { lesson(top, identifier: "exits.lesson") }
                ForEach(Array(ledger.rows.prefix(OrdersCard.previewLimit).enumerated()), id: \.offset) { entry in
                    Divider().overlay(LeafTheme.line)
                    row(entry.element, index: entry.offset, prefix: "exits.row")
                }
                Button { showingAll = true } label: {
                    HStack(spacing: 8) {
                        OneLine("All cashouts (\(ledger.rows.count))").font(LeafType.body)
                        Spacer(minLength: 8)
                        Image(systemName: "chevron.right").font(LeafType.meta).accessibilityHidden(true)
                    }
                    .foregroundStyle(LeafTheme.ink)
                    .frame(minHeight: 44)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityIdentifier("exits.all")
                .sheet(isPresented: $showingAll) { fullLedger(ledger) }
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("exits.card")
    }
}
