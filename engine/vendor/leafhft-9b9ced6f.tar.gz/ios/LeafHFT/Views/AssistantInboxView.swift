import SwiftUI

@MainActor struct AssistantInboxView: View {
    @Environment(AssistantInbox.self) private var inbox
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    let onReview: (AssistantNomination) -> Void
    let onDiscussCard: (AssistantCard) -> Void
    let onDiscussNomination: (AssistantNomination) -> Void
    @State private var refreshRevision = 0

    private var openCards: [AssistantCard] { inbox.cards.filter { $0.state == .open } }

    private var actionLayout: AnyLayout {
        dynamicTypeSize.isAccessibilitySize
            ? AnyLayout(VStackLayout(alignment: .leading, spacing: 8))
            : AnyLayout(HStackLayout(spacing: 8))
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) {
                if inbox.loading {
                    ProgressView("Loading autotune…")
                        .accessibilityIdentifier("assistant.inbox.loading")
                }
                if let error = inbox.error {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(error).font(LeafType.body).foregroundStyle(LeafTheme.loss)
                        Button("Retry") { refreshRevision += 1 }
                            .frame(minWidth: 44, minHeight: 44)
                            .disabled(inbox.loading || inbox.approvingCardId != nil)
                            .accessibilityIdentifier("assistant.inbox.retry")
                    }
                    .accessibilityIdentifier("assistant.inbox.error")
                }
                if !openCards.isEmpty {
                    Text("Waiting for approval").font(LeafType.title)
                    ForEach(openCards) { card in cardRow(card) }
                }
                if !inbox.nominations.isEmpty {
                    Text("Suggestions").font(LeafType.title)
                    ForEach(inbox.nominations) { nomination in nominationRow(nomination) }
                }
                if openCards.isEmpty && inbox.nominations.isEmpty && !inbox.loading && inbox.error == nil {
                    Text("No autotune cards right now")
                        .font(LeafType.title)
                        .accessibilityIdentifier("assistant.inbox.empty")
                }
                if let time = inbox.lastRefreshedAt {
                    Text("Last refreshed \(time.formatted(date: .omitted, time: .shortened))")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        .accessibilityIdentifier("assistant.inbox.refreshed")
                }
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .accessibilityIdentifier("assistant.inbox.scroll")
        .safeAreaInset(edge: .top, spacing: 0) {
            if let notice = inbox.acceptNotice {
                Text(notice)
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16).padding(.vertical, 8)
                    .background(LeafTheme.ground)
                    .accessibilityIdentifier("assistant.inbox.acceptNotice")
            }
            if let notice = inbox.changedNotice {
                VStack(alignment: .leading, spacing: 8) {
                    Text(notice).accessibilityIdentifier("assistant.inbox.changed.notice")
                    Button("Dismiss") { inbox.dismissChangedNotice() }
                        .frame(minWidth: 44, minHeight: 44)
                }
                .font(LeafType.meta).foregroundStyle(LeafTheme.warn)
                .padding(16).frame(maxWidth: .infinity, alignment: .leading)
                .background(LeafTheme.ground)
            }
            if let title = inbox.approvedCardTitle {
                Text("Approved: " + title)
                    .font(LeafType.meta).foregroundStyle(LeafTheme.gain)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16).padding(.vertical, 8)
                    .background(LeafTheme.ground)
                    .accessibilityIdentifier("assistant.inbox.approved.notice")
            }
        }
        .refreshable { await refreshAndMarkSeen() }
        .task(id: refreshRevision) { await refreshAndMarkSeen() }
        .task(id: inbox.approvedCardTitle) {
            guard inbox.approvedCardTitle != nil else { return }
            do { try await Task.sleep(for: .seconds(5)) }
            catch { return }
            inbox.dismissApprovalNotice()
        }
        .alert("Confirm approval", isPresented: Binding(
            get: { inbox.pendingApproval != nil },
            set: { if !$0 { inbox.cancelApproval() } }), presenting: inbox.pendingApproval) { snapshot in
            Button("Approve") { Task { await inbox.approve(card: snapshot) } }
                .accessibilityIdentifier("assistant.inbox.approve.confirm.button")
            Button("Cancel", role: .cancel) { inbox.cancelApproval() }
        } message: { snapshot in
            Text(([snapshot.title] + snapshot.fields.map { $0.label + ": " + $0.value }).joined(separator: "\n"))
                .accessibilityIdentifier("assistant.inbox.approve.confirm")
        }
    }

    private func refreshAndMarkSeen() async {
        await inbox.refresh()
        guard !Task.isCancelled, inbox.error == nil else { return }
        await inbox.markSeen()
    }

    private func cardRow(_ card: AssistantCard) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            if let identity = card.identity { AssistantEngineIdentityView(identity: identity) }
            Text(card.title).font(LeafType.heading)
            AssistantCardFieldsView(fields: card.fields)
            if card.kind == .configDraft {
                Text("Applies after your runner confirms it.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
            Text([card.engineId, card.state == .open ? "Open" : card.stateLabel]
                .compactMap { $0 }.joined(separator: " · "))
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .accessibilityIdentifier("assistant.inbox.card.\(card.id).state")
            actionLayout {
                if inbox.canApprove && card.state == .open && card.hasReadableDetails {
                    Button { inbox.beginApproval(card) } label: {
                        HStack(spacing: 8) {
                            if inbox.approvingCardId == card.id {
                                ProgressView().controlSize(.small)
                            }
                            Text(card.kind.actionLabel)
                        }
                        .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(LeafTheme.accent)
                    .foregroundStyle(LeafTheme.primaryForeground)
                    .disabled(inbox.acceptingNominationId != nil || inbox.approvingCardId != nil || inbox.pendingApproval != nil || inbox.loading || inbox.approveCoolingDown)
                    .accessibilityIdentifier("assistant.inbox.card.\(card.id).approve")
                }
                if AssistantCard.validId(card.id) {
                    Button { onDiscussCard(card) } label: {
                        Text("Discuss").frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                    .disabled(inbox.approvingCardId != nil)
                    .accessibilityIdentifier("assistant.inbox.card.\(card.id).discuss")
                }
            }
            .font(LeafType.heading)
            if !card.hasReadableDetails {
                Text("This card has no readable details; open it in chat.")
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
            }
        }
        .inboxRow(identifier: "assistant.inbox.card.\(card.id)")
    }

    private func nominationRow(_ nomination: AssistantNomination) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            AssistantEngineIdentityView(identity: nomination.identity)
            Text(kindLabel(nomination.kind)).font(LeafType.heading)
            Text("Books: " + nomination.books.joined(separator: ", ")).font(LeafType.body)
            Text(String(format: "%.0f trades · return %.1f%% · LB90 %.1f%%",
                        nomination.evidence.n, nomination.evidence.returnPct, nomination.evidence.lb90))
                .font(LeafType.body)
            if !nomination.ownAccount {
                Text("Account: " + nomination.account)
                    .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("assistant.inbox.nomination.\(nomination.id).account")
            }
            if nomination.stale {
                Text("Stale").font(LeafType.meta).foregroundStyle(LeafTheme.warn)
            }
            if !nomination.actionable, let reason = nomination.reasonText {
                Text(reason)
                    .font(LeafType.body).foregroundStyle(LeafTheme.inkMuted)
                    .accessibilityIdentifier("assistant.inbox.nomination.\(nomination.id).reason")
            }
            Text(nomination.engineId + " · " + nomination.statusText)
                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .accessibilityIdentifier("assistant.inbox.nomination.\(nomination.id).state")
            actionLayout {
                if inbox.canAccept(nomination) {
                    Button { Task { await inbox.accept(nomination) } } label: {
                        HStack(spacing: 8) {
                            if inbox.acceptingNominationId == nomination.id {
                                ProgressView().controlSize(.small)
                            }
                            Text("Approve")
                        }
                        .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(LeafTheme.accent)
                    .foregroundStyle(LeafTheme.primaryForeground)
                    .disabled(inbox.acceptingNominationId != nil || inbox.approvingCardId != nil || inbox.pendingApproval != nil || inbox.loading)
                    .accessibilityIdentifier("assistant.inbox.nomination.\(nomination.id).approve")
                }
                if inbox.canReview(nomination) {
                    Button { onReview(nomination) } label: {
                        Text("Review").frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                    .disabled(inbox.approvingCardId != nil)
                    .accessibilityIdentifier("assistant.inbox.nomination.\(nomination.id).review")
                }
                if AssistantNomination.validId(nomination.id) {
                    Button { onDiscussNomination(nomination) } label: {
                        Text("Discuss").frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                    .disabled(inbox.approvingCardId != nil)
                    .accessibilityIdentifier("assistant.inbox.nomination.\(nomination.id).discuss")
                }
            }
            .font(LeafType.heading)
        }
        .inboxRow(identifier: "assistant.inbox.nomination.\(nomination.id)")
    }

    private func kindLabel(_ kind: String) -> String {
        switch kind {
        case "tune": return "Tune"
        case "promote_shadow": return "Promote"
        case "book_off": return "Book off"
        default: return kind
        }
    }
}

private extension View {
    func inboxRow(identifier: String) -> some View {
        self
            .fixedSize(horizontal: false, vertical: true)
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(LeafTheme.line))
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier(identifier)
    }
}

/// Draw the server's engine glyph, with a tint dot for malformed paths.
struct AssistantEngineIdentityView: View {
    let identity: AssistantEngineIdentity
    @ScaledMetric(relativeTo: .body) private var glyphSize: CGFloat = 18

    private var tint: Color {
        let hex = identity.tintHex.hasPrefix("#") ? String(identity.tintHex.dropFirst()) : identity.tintHex
        guard hex.count == 6, let rgb = UInt32(hex, radix: 16) else { return LeafTheme.inkMuted }
        return Color(red: Double((rgb >> 16) & 255) / 255,
                     green: Double((rgb >> 8) & 255) / 255, blue: Double(rgb & 255) / 255)
    }

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            EngineGlyphView(path: identity.glyphPath, tint: tint, size: min(glyphSize, 28)).padding(.top, 6)
                .accessibilityHidden(true)
            (Text(identity.ticker).bold() + Text(" " + identity.name))
                .font(LeafType.body)
                .fixedSize(horizontal: false, vertical: true)
        }
        .accessibilityElement(children: .combine)
    }
}

struct AssistantUnreadBadge: View {
    let count: Int
    let identifier: String

    var body: some View {
        // Fixed size: a badge that scales with Dynamic Type covers the control it annotates.
        Text(count > 9 ? "9+" : String(count))
            .font(.system(size: 12, weight: .semibold)).monospacedDigit()
            .foregroundStyle(LeafTheme.primaryForeground)
            .padding(.horizontal, 6)
            .frame(minWidth: 20, minHeight: 20)
            .background(LeafTheme.primary, in: Capsule())
            .fixedSize()
            .accessibilityLabel("\(count) unread autotune items")
            .accessibilityIdentifier(identifier)
    }
}
