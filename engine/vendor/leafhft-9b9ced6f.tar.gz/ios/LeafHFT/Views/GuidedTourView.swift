import SwiftUI

enum KashbotTab: Hashable {
    case account, books, engines, lab, settings
}

private struct GuidedTourStep {
    let tab: KashbotTab?
    let icon: String
    let title: String
    let message: String
    let cue: String
}

@MainActor struct GuidedTourOverlay: View {
    static let currentVersion = 6
    @Environment(MushyState.self) private var studio

    @Binding var step: Int
    @Binding var selectedTab: KashbotTab
    let onFinish: () -> Void

    private var steps: [GuidedTourStep] { allSteps.filter { $0.tab != nil || !studio.featureDisabled } }
    private let allSteps = [
        GuidedTourStep(
            tab: .account,
            icon: "chart.line.uptrend.xyaxis",
            title: "Monitor your account",
            message: "Start on Monitor for whether the runner is alive, cash and account value, current Kalshi positions, recent fills, and the runner's sizing summary.",
            cue: "Change the chart range, then scroll for account activity and runner limits."
        ),
        GuidedTourStep(
            tab: .books,
            icon: "square.grid.2x2",
            title: "Inspect live markets",
            message: "Books show the markets your runner is watching and how close each one is to a trade.",
            cue: "Tap a book to inspect its latest evaluation and candidates."
        ),
        GuidedTourStep(
            tab: .engines,
            icon: "cpu",
            title: "Compare your engines",
            message: "See engines published by the runner, compare performance, and open account-specific controls.",
            cue: "Tap an engine for history, settings, and its live enable switch."
        ),
        GuidedTourStep(
            tab: .lab,
            icon: "testtube.2",
            title: "Understand the system",
            message: "Engine Lab brings published engines, account lanes, pending work, and Kashbot research into one shared view.",
            cue: "Use Lab for Darkhorse, Dip Recovery, Relay Divergence, evidence, owners, and next actions."
        ),
        GuidedTourStep(
            tab: nil,
            icon: "bubble.left.fill",
            title: "Ask from anywhere",
            message: "Use the prompt for charts, account views, explanations, or a config draft. Your conversations are saved.",
            cue: "Tap the chat bubble at the bottom right of any tab. Close the prompt to return to your place."
        ),
        GuidedTourStep(
            tab: .settings,
            icon: "gearshape",
            title: "Connect and come back anytime",
            message: "Settings connects your Kalshi key and dashboard. The key is saved in this phone’s Keychain; non-owner account setup also encrypts and enrolls a runner copy for automated trading. Owner setup saves the key for read-only phone access.",
            cue: "Use Show me around here whenever you want to replay this tour."
        )
    ]

    private var item: GuidedTourStep { steps[min(step, steps.count - 1)] }

    var body: some View {
        VStack {
            tourCard
            Spacer(minLength: 120)
        }
        .padding(.horizontal, 16)
        .padding(.top, 8)
        .background(Color.black.opacity(0.16).allowsHitTesting(false))
        .ignoresSafeArea(edges: .bottom)
        .accessibilityIdentifier("tour.overlay")
        .onAppear { selectedTab = item.tab ?? .account }
        .onChange(of: step) { _, _ in selectedTab = item.tab ?? .account }
        .onChange(of: studio.featureDisabled) { _, _ in
            step = min(step, steps.count - 1)
            selectedTab = item.tab ?? .account
        }
    }

    private var tourCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center) {
                Label("Quick tour", systemImage: item.icon)
                    .font(.subheadline.weight(.semibold))
                Spacer()
                Text("\(step + 1) of \(steps.count)")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .accessibilityIdentifier("tour.progress")
                Button("Close", systemImage: "xmark", action: onFinish)
                    .labelStyle(.iconOnly)
                    .accessibilityIdentifier("tour.close")
                    .accessibilityLabel("Close tour")
            }

            Text(item.title)
                .font(.title2.bold())
                .accessibilityIdentifier("tour.title")
            Text(item.message)
                .font(.body)
                .accessibilityIdentifier("tour.message")
            Label(item.cue, systemImage: "hand.tap")
                .font(.callout)
                .foregroundStyle(.secondary)

            HStack {
                if step > 0 {
                    Button("Back") { move(to: step - 1) }
                        .accessibilityIdentifier("tour.back")
                }
                Spacer()
                if step == steps.count - 1 {
                    Button("Done", action: onFinish)
                        .buttonStyle(.borderedProminent)
                        .accessibilityIdentifier("tour.done")
                } else {
                    Button("Next") { move(to: step + 1) }
                        .buttonStyle(.borderedProminent)
                        .accessibilityIdentifier("tour.next")
                }
            }
        }
        .padding(16)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.secondary.opacity(0.25), lineWidth: 0.5))
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("tour.card")
    }

    private func move(to destination: Int) {
        guard steps.indices.contains(destination) else { return }
        step = destination
    }
}
