import SwiftUI

struct KashbotLiveSettingsSection: View {
    @AppStorage("kashbot.live.enabled") private var enabled = true
    @AppStorage("kashbot.live.buzzOnOdds") private var buzzOnOdds = false

    private var snapshot: KashbotBoardSnapshot? {
        if FixtureMode.current.enabled { return .sample }
        return KashbotBoardStore.load()
    }

    var body: some View {
        Section {
            Group {
                if let snapshot {
                    KashbotLockScreenBoard(state: snapshot.state,
                                           isStale: Date().timeIntervalSince1970 - TimeInterval(snapshot.state.asOf) > 180)
                } else {
                    Text("Shows after the next account refresh")
                        .font(.system(size: 13, design: .rounded))
                        .foregroundStyle(KashbotBrand.slate)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(KashbotBrand.ground)
                }
            }
            .frame(height: 160)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("kashbot-live-preview")
            .listRowInsets(EdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8))

            Group {
                if let snapshot, !snapshot.ledger.isEmpty {
                    KashbotLedgerList(entries: snapshot.ledger, limit: 4)
                } else {
                    Text("No settled results yet")
                        .font(.system(size: 13, design: .rounded))
                        .foregroundStyle(KashbotBrand.slate)
                }
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("kashbot-live-ledger")
            Toggle("Show on lock screen", isOn: $enabled)
                .accessibilityIdentifier("kashbot-live-toggle")
            Toggle("Buzz when odds cross 50%", isOn: $buzzOnOdds)
                .accessibilityIdentifier("kashbot-live-buzz-toggle")
        } header: {
            Text("Lock screen board")
                .accessibilityIdentifier("kashbot-live-section")
        } footer: {
            Text("Live P/L updates about every 10 seconds while Kashbot is open, and from the Kashbot server while your phone is locked. Buzzes when a position opens, closes or settles.")
        }
        .tint(KashbotBrand.leaf)
        .foregroundStyle(KashbotBrand.ink)
        .listRowBackground(KashbotBrand.panel)
    }
}
