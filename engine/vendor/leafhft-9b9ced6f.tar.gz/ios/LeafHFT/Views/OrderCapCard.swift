import Foundation
import SwiftUI
import LeafHFTCore

@MainActor struct OrderCapCard: View {
    @Environment(AppState.self) private var state
    @Environment(\.scenePhase) private var scenePhase
    @State private var percent = 25.0
    @State private var confirmation: Increase?

    private struct Increase: Identifiable {
        let id = UUID()
        let current: OrderCapResponse
        let fraction: Double
        let balanceCents: Int?
    }

    static func dollarText(fraction: Double, balanceCents: Int) -> String {
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "en_US")
        formatter.numberStyle = .currency
        formatter.currencyCode = "USD"
        formatter.maximumFractionDigits = 0
        formatter.minimumFractionDigits = 0
        return formatter.string(from: NSNumber(value: fraction * Double(balanceCents) / 100)) ?? "$0"
    }

    private var balanceCents: Int? {
        state.markedPortfolio?.totalCents ?? state.balance?.accountValue?.cents.rawValue
    }

    private func amount(_ fraction: Double, balance: Int?) -> String {
        guard let balance else { return "Account value unavailable" }
        return "about \(Self.dollarText(fraction: fraction, balanceCents: balance)) of \(Self.dollarText(fraction: 1, balanceCents: balance))"
    }

    var body: some View {
        FlatCard(title: "Max per trade") {
            if let cap = state.orderCap.value {
                let shown = state.orderCap.loading ? cap.maxOrderFraction * 100 : percent
                VStack(alignment: .leading, spacing: 8) {
                    OneLine("\(Int(shown.rounded()))%")
                        .leafNumeral(.hero)
                        .accessibilityIdentifier("account.orderCap.percent")
                    Text(amount(shown / 100, balance: balanceCents))
                        .font(LeafType.body)
                        .foregroundStyle(LeafTheme.inkMuted)
                    Slider(value: $percent, in: (cap.range.min * 100)...(cap.range.max * 100), step: 1)
                        .tint(LeafTheme.ink)
                        .accessibilityLabel("Max per trade percentage")
                        .accessibilityValue("\(Int(percent.rounded())) percent")
                        .accessibilityIdentifier("account.orderCap.slider")
                        .disabled(state.orderCap.loading || state.orderCap.saving || scenePhase != .active)
                }
                .opacity(state.orderCap.loading ? 0.5 : 1)
                Button(state.orderCap.saving ? "Saving…" : "Save") {
                    let fraction = percent / 100
                    if fraction > cap.maxOrderFraction {
                        confirmation = Increase(current: cap, fraction: fraction, balanceCents: balanceCents)
                    } else {
                        Task { await state.saveOrderCap(fraction, expectedRevision: cap.revision) }
                    }
                }
                .buttonStyle(.leafPrimary)
                .disabled(state.orderCap.loading || state.orderCap.saving || scenePhase != .active ||
                          abs(percent / 100 - cap.maxOrderFraction) < 0.000_001)
                .accessibilityLabel("Save Max per trade")
                .accessibilityIdentifier("account.orderCap.save")
            } else {
                Text(state.orderCap.loading ? "Loading Max per trade…" : "Max per trade unavailable")
                    .font(LeafType.body).foregroundStyle(LeafTheme.inkMuted)
            }
            if state.orderCap.loading { ProgressView() }
            if let error = state.orderCap.error {
                Text(error).font(LeafType.meta).foregroundStyle(LeafTheme.loss)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("account.orderCap.error")
                Button("Reload") { Task { await state.loadOrderCap() } }
                    .buttonStyle(.leafSecondary)
                    .disabled(state.orderCap.loading || state.orderCap.saving)
            }
        }
        .accessibilityIdentifier("account.orderCap")
        .task {
            await state.loadOrderCap()
            if let cap = state.orderCap.value { percent = cap.maxOrderFraction * 100 }
        }
        .onChange(of: state.orderCap.value) { _, cap in
            if let cap { percent = cap.maxOrderFraction * 100 }
            confirmation = nil
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { Task { await state.loadOrderCap() } }
            else { confirmation = nil }
        }
        .sheet(item: $confirmation) { increase in
            NavigationStack {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Raise Max per trade?").font(LeafType.body)
                    Text("From \(Int((increase.current.maxOrderFraction * 100).rounded()))% · \(amount(increase.current.maxOrderFraction, balance: increase.balanceCents))")
                    Text("To \(Int((increase.fraction * 100).rounded()))% · \(amount(increase.fraction, balance: increase.balanceCents))")
                    Text("This allows more of your portfolio in each trade.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    HStack {
                        Button("Cancel") { confirmation = nil }.buttonStyle(.leafSecondary)
                        Button("Save") {
                            confirmation = nil
                            Task { await state.saveOrderCap(increase.fraction, expectedRevision: increase.current.revision) }
                        }
                        .buttonStyle(.leafPrimary)
                        .disabled(scenePhase != .active || state.orderCap.loading || state.orderCap.saving)
                        .accessibilityLabel("Confirm and save higher Max per trade")
                    }
                }
                .padding(16)
                .foregroundStyle(LeafTheme.ink)
                .leafScreenBackground()
                .navigationTitle("Max per trade")
                .navigationBarTitleDisplayMode(.inline)
            }
            .presentationDetents([.medium, .large])
        }
    }
}
