import SwiftUI
import UIKit
import UniformTypeIdentifiers
import LeafHFTCore

enum PrivateKeyFileError: Error {
    case invalidText
}

// Shared by the system-picker callback and non-secret file rejection tests.
func validatedPrivateKeyFile(at url: URL) throws -> String {
    let scoped = url.startAccessingSecurityScopedResource()
    defer { if scoped { url.stopAccessingSecurityScopedResource() } }
    let file = try FileHandle(forReadingFrom: url)
    defer { try? file.close() }
    // Bound the read even when a file provider reports an incorrect size.
    let data = try file.read(upToCount: 65_537) ?? Data()
    guard data.count <= 65_536, let candidate = String(data: data, encoding: .utf8) else {
        throw PrivateKeyFileError.invalidText
    }
    let der = try decodeRSAPrivateKeyPEM(candidate)
    _ = try KalshiSigner(pkcs1DER: der)
    return candidate
}

@MainActor struct SettingsView: View {
    @Environment<AppState>(AppState.self) private var state
    @Environment(\.scenePhase) private var scenePhase
    // SwiftUI places the ObservableObject app delegate (LeafHFTApp's adaptor) in the environment.
    @EnvironmentObject private var pushRegistrar: PushRegistrar
    @AppStorage("kashbot.appearance") private var appearance = LeafAppearance.system
    @State private var keyID = ""
    @State private var pem = ""
    @State private var token = ""
    @State private var receiver = USBKeyDraftReceiver()
    @State private var receiveTask: Task<Void, Never>?
    @State private var receivingKey = false
    @State private var keyPresent = false
    @State private var message: String?
    @State private var openingKalshi = false
    @State private var awaitingKalshiBrowserReturn = false
    @State private var kalshiGuideExpanded = true
    @State private var choosingKeyFile = false
    @FocusState private var keyIDFocused: Bool
    @State private var connectionTask: Task<Void, Never>?
    @State private var checkingConnection = false
    @State private var connectionMessage: String?
    @State private var fixtureCheckCount = 0
    @State private var fixturePauseCount = 0
    @State private var fixtureMutationSequence: UInt64?
    @StateObject private var pairing = DevicePairingFlow()
    @State private var pairingTask: Task<Void, Never>?
    @State private var didAttemptAutomaticPairing = false
    @State private var advancedDashboard = false
    @State private var confirmingRevoke = false
    @State private var confirmedControlRevision: UUID?
    let autoStartPairing: Bool
    let onShowTour: () -> Void

    init(autoStartPairing: Bool = false, onShowTour: @escaping () -> Void = {}) {
        self.autoStartPairing = autoStartPairing
        self.onShowTour = onShowTour
    }
    private var connectionFixture: Bool {
        state.fixtureMode.enabled && ProcessInfo.processInfo.arguments.contains("-LEAFHFT_CONNECTION_WALK")
    }
    private var filePickerAllowed: Bool {
        !state.fixtureMode.enabled || ProcessInfo.processInfo.arguments.contains("-LEAFHFT_FILE_PICKER_WALK")
    }
    private let store = KeychainStore()
    // The dedicated handoff walk may open public pages while account traffic
    // and credential access stay blocked. Ordinary fixture runs stay offline.
    private var handoffAllowed: Bool {
        !state.fixtureMode.enabled || ProcessInfo.processInfo.arguments.contains("-LEAFHFT_HANDOFF_WALK")
    }
    // Fixture-only walks render a bound live or paused lane so the Pause scope copy can be
    // exercised. Only the Pause recorder is enabled; real account actions stay blocked.
    private var pauseScopeRecorder: Bool {
        state.fixtureMode.enabled && ProcessInfo.processInfo.arguments.contains("-LEAFHFT_PAUSE_SCOPE_WALK")
    }
    private func pauseTrading() {
        if pauseScopeRecorder {
            fixturePauseCount += 1
            return
        }
        guard !state.fixtureMode.enabled else { return }
        state.runAccountAction(.pause)
    }
    private var laneStatus: KashbotStatus? { state.kashbotStatus }
    // Pause stops only this phone's account lane unit (account_lane_agent.py "stop"), never the owner
    // runner Monitor labels, so name the lane from KashbotStatus. The status carries no human label.
    private var pauseScopeLabel: String {
        guard let id = laneStatus?.lane?.id.trimmingCharacters(in: .whitespacesAndNewlines), !id.isEmpty else {
            return "this phone's Kashbot account"
        }
        return "this phone's Kashbot account (lane \(id.prefix(8).lowercased()))"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Kashbot status") {
                    statusRow("Account readability", value: state.accountReadability.label,
                              tone: state.accountReadability == .readable ? .gain : state.accountReadability == .unknown ? .stale : .loss)
                    statusRow("Dashboard pairing", value: state.dashboardPairingState.label,
                              tone: state.dashboardPairingState == .paired ? .gain : state.dashboardPairingState == .unknown ? .stale : .loss)
                    let tradingLabel = Self.tradingStateLabel(status: laneStatus, fallback: state.automationLabel)
                    LabeledContent("Automated trading", value: tradingLabel)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel("Automated trading, \(tradingLabel)")
                        .accessibilityIdentifier("settings.laneState")
                    if !state.isOwnerExecution && state.enrolledKeyChanged {
                        Label("Enrolled key differs from this phone's key", systemImage: "exclamationmark.triangle.fill")
                            .font(LeafType.heading).foregroundStyle(LeafTheme.loss)
                            .accessibilityIdentifier("settings.enrolledKeyChanged")
                    }
                    if !state.isOwnerExecution {
                        if laneStatus?.hasActionableLane == true && laneStatus?.automatedTrading == .dryRun {
                            Text("Dry run passed. Start trading to allow real orders.")
                            Button("Start trading") {
                                state.runAccountAction(.startLive, confirmedRevision: state.accountControlRevision)
                            }
                                .buttonStyle(.leafPrimary)
                                .disabled(!state.canRunAccountAction(.startLive) || scenePhase != .active)
                                .accessibilityIdentifier("settings.enableLive")
                        }
                        if state.canPause {
                            // Emergency stop: one tap, no confirmation.
                            Button("Pause trading", action: pauseTrading)
                                .foregroundStyle(LeafTheme.loss)
                                .disabled(scenePhase != .active || (state.fixtureMode.enabled && !pauseScopeRecorder))
                                .accessibilityIdentifier("settings.pauseTrading")
                            if pauseScopeRecorder && fixturePauseCount > 0 {
                                Text("pause recorded")
                                    .accessibilityIdentifier("settings.pauseTrading.recorded")
                                    .accessibilityValue("\(fixturePauseCount)")
                            }
                            // Copy states only what the runner's stop action does (account_lane_agent.py "stop").
                            Text("Applies to \(pauseScopeLabel) only. Stops this account's lane, so Kashbot places no new live orders for it. Other runners, including the owner runner's books, keep running. Open positions are not sold.")
                                .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                                .accessibilityIdentifier("settings.pauseTrading.scope")
                        }
                        if laneStatus?.automatedTrading == .paused {
                            Text("Paused for \(pauseScopeLabel). No new live orders.")
                                .accessibilityIdentifier("settings.pauseTrading.pausedScope")
                            Button("Resume trading") {
                                Task { await state.resumeTrading() }
                            }
                                .buttonStyle(.leafPrimary)
                                .disabled(!state.canResume || scenePhase != .active)
                                .accessibilityIdentifier("settings.resumeTrading")
                        }
                    }
                }
                .listRowBackground(LeafTheme.card)
                Section {
                    Button {
                        onShowTour()
                    } label: {
                        Label("Show me around", systemImage: "sparkles")
                    }
                    .accessibilityIdentifier("settings.showTourShortcut")
                }
                .listRowBackground(LeafTheme.card)
                // Revoke lives in its own section, away from Pause, so a hurried stop cannot land on it.
                if !state.isOwnerExecution && laneStatus?.hasActionableLane == true && laneStatus?.allows(.revoke) == true {
                    Section {
                        Button("Revoke runner access", role: .destructive) {
                            confirmedControlRevision = state.accountControlRevision
                            confirmingRevoke = true
                        }
                            .foregroundStyle(LeafTheme.loss)
                            .disabled(!state.canRunAccountAction(.revoke) || scenePhase != .active)
                            .accessibilityIdentifier("settings.revokeRunner")
                    } header: {
                        Text("Runner access")
                            .accessibilityIdentifier("settings.revokeSection")
                    }
                    .listRowBackground(LeafTheme.card)
                }
                if state.fixtureMode.enabled {
                    Text("Fixture mode. Credentials are not read or saved.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        .accessibilityIdentifier("settings.fixtureNotice")
                        .listRowBackground(LeafTheme.card)
                }
                Section("Kalshi API connection") {
                    if state.isOwnerExecution {
                        Text("Control the owner books with Pause and Start on Monitor. Start requires this phone's presence key and Face ID. Exits and settlements continue while entries are paused.")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    } else {
                    Text("Connect your Kalshi key and validate a dry run. Real orders can be placed only after the dry run passes and you confirm Start trading and authenticate on this phone.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    if laneStatus?.accountBinding == .unbound {
                        Text("Dashboard paired. Account is not bound and trading is not configured.")
                    }
                    Button(state.settingUpDryRun ? "Connecting and starting…" : "Connect and start trading") {
                        Task { await state.setupDryRun(startLiveWhenReady: true) }
                    }
                    .buttonStyle(.leafPrimary)
                    .disabled(!state.canSetupDryRun || state.accountMutationInProgress || scenePhase != .active)
                    .accessibilityIdentifier("settings.setupDryRun")
                    }
                    Button(state.checkingSetupProgress ? "Checking progress…" : "Check progress") {
                        Task { await state.refreshAccountSetup() }
                    }
                        .disabled(state.fixtureMode.enabled || state.accountMutationInProgress || state.checkingSetupProgress || state.dashboardPairingState == .unpaired || scenePhase != .active)
                        .accessibilityIdentifier("settings.checkLaneProgress")
                    if !state.isOwnerExecution && !state.setupCredentialsPresent {
                        Text("Save your Kalshi key and pair the dashboard to set up a dry run.").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                    if state.settingUpDryRun { ProgressView("Setup in progress") }
                    if let progress = state.ownerControlProgress { ProgressView(progress) }
                    else if state.runnerAction != nil { ProgressView("Waiting for the account runner") }
                    if state.checkingSetupProgress { ProgressView("Checking account progress") }
                    if let result = state.setupMessage {
                        Text(result).accessibilityAddTraits(.updatesFrequently)
                            .accessibilityIdentifier("settings.setupResult")
                    }
                    if let error = state.setupError {
                        Text(error).foregroundStyle(LeafTheme.loss).accessibilityAddTraits(.updatesFrequently)
                            .accessibilityIdentifier("settings.setupError")
                    }
                    if !keyPresent {
                        Label("Use Kalshi’s website", systemImage: "desktopcomputer")
                            .font(LeafType.heading)
                        Text("The Kalshi iPhone app does not show API keys. Use Chrome, Safari, Edge, or Firefox on a Mac or PC. If you continue on this iPhone, open the website in Safari or Chrome and request the desktop site if API Keys is hidden.")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        DisclosureGroup("Setup steps", isExpanded: $kalshiGuideExpanded) {
                            Text("1. Sign in, select your profile picture, then open Account Settings → API Keys → Create New API Key.")
                            Text("2. Name the key “Kashbot HFT.” Copy the Key ID before leaving the page.")
                            Text("3. Download the private-key file. Kalshi shows the private key once and then cannot retrieve it again.")
                            Text("4. On Mac, AirDrop the downloaded file to this iPhone and save it in Files. On Windows, move it into iCloud Drive, OneDrive, or another Files location available on this iPhone. Do not email or message the private key.")
                            Text("5. Open Exchange indexes in Kalshi. Kashbot trades exchange index 2, so move or allocate trading cash there. A total balance in another index cannot fund Kashbot orders.")
                            if state.isOwnerExecution {
                                Text("6. Return to Kashbot. Select the downloaded file, paste the matching Key ID, then tap Save key for read-only phone access.")
                            } else {
                                Text("6. Return to Kashbot. Select the downloaded file, paste the matching Key ID, then tap Save, connect, and start trading. Kashbot validates the key and dry run, then asks you to confirm Start trading and authenticate before placing real orders.")
                            }
                        }
                        Button(openingKalshi ? "Opening browser…" : "Open Kalshi website in browser") {
                            Task { await openKalshi() }
                        }
                        .buttonStyle(.leafPrimary)
                        .accessibilityIdentifier("settings.openKalshi")
                        .disabled(!handoffAllowed || openingKalshi)
                        ShareLink(item: URL(string: "https://kalshi.com/account/profile")!) {
                            Label("Send setup link to a computer", systemImage: "square.and.arrow.up")
                        }
                        .disabled(!handoffAllowed)
                        Label("Grant only Read and Trade", systemImage: "lock.shield")
                            .font(LeafType.heading)
                        Text("Read is needed for balances, positions, markets, orders, fills, and settlements. Trade is needed to place and cancel orders.")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        Text("Leave Transfer funds, FCM risk, and Block Trade acceptance off. If Kalshi only offers Read-only or Read & write, choose Read & write because automated trading must place and cancel orders.")
                            .font(LeafType.meta)
                            .foregroundStyle(LeafTheme.warn)
                            .accessibilityIdentifier("settings.permissionWarning")
                    }
                    Label("Fund exchange index 2", systemImage: "dollarsign.arrow.circlepath")
                        .font(LeafType.heading)
                    Text("Kalshi can show money in your total balance while exchange index 2 still has $0 available for trading. Kashbot can scan markets in that state, but it cannot place an order.")
                        .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    Link("Open Kalshi exchange indexes", destination: URL(string: "https://kalshi.com/account/exchange-indexes")!)
                        .accessibilityIdentifier("settings.openExchangeIndexes")
                    Text("Move or allocate cash to exchange index 2 in Kalshi. Keep Transfer funds off for the Kashbot key, so Kashbot cannot move money between indexes for you.")
                        .font(LeafType.meta)
                        .foregroundStyle(LeafTheme.warn)
                    if keyPresent {
                        Label("Kalshi key saved", systemImage: "checkmark.circle.fill")
                        Text(Self.privateKeyStorageCopy(isOwnerExecution: state.isOwnerExecution))
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                            .accessibilityIdentifier("settings.keyStorage")
                    }
                    Button(receivingKey ? "Waiting for computer…" : "Receive key from computer", action: receiveKey)
                        .accessibilityIdentifier("settings.receiveKey")
                        .disabled(state.fixtureMode.enabled || checkingConnection || receivingKey)
                    if receivingKey {
                        Text("Keep this screen open. The key will be ready for you to import.")
                        Button("Cancel transfer") { cancelReceive(); message = "Transfer cancelled. Your entries are unchanged." }
                            .accessibilityIdentifier("settings.cancelReceive")
                    }
                    SecureField("Kalshi Key ID", text: $keyID)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .focused($keyIDFocused)
                        .accessibilityIdentifier("settings.keyID")
                    PasteButton(payloadType: String.self) { values in
                        if let value = values.first {
                            keyID = value.trimmingCharacters(in: .whitespacesAndNewlines)
                        }
                    }
                    .accessibilityIdentifier("settings.pasteKeyID")
                    Button(pem.isEmpty ? "Choose downloaded private-key file" : "Choose a different private-key file") {
                        choosingKeyFile = true
                    }
                        .accessibilityIdentifier("settings.chooseKeyFile")
                        .disabled(!filePickerAllowed)
                    if !pem.isEmpty {
                        Label("Private-key file selected", systemImage: "checkmark.circle")
                            .accessibilityIdentifier("settings.keyFileReady")
                    }
                    Text("Or paste the existing private key (PEM)").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    SecureField("Existing private key PEM", text: $pem)
                        .font(LeafType.numberSmall)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .accessibilityIdentifier("settings.pem")
                        .privacySensitive()
                        .accessibilityLabel("Existing private key PEM")
                    if state.isOwnerExecution {
                        Button("Save key", action: importKey).accessibilityIdentifier("settings.import")
                            .disabled(state.fixtureMode.enabled || checkingConnection || receivingKey || keyID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || pem.isEmpty)
                            .buttonStyle(.leafPrimary)
                    } else {
                    Button("Save, connect, and start trading", action: importKey).accessibilityIdentifier("settings.import").disabled(state.fixtureMode.enabled || state.accountMutationInProgress || scenePhase != .active || checkingConnection || receivingKey || keyID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || pem.isEmpty)
                        .buttonStyle(.leafPrimary)
                    }
                    if keyPresent {
                        Button(checkingConnection ? "Checking connection…" : "Check connection", action: { checkConnection() })
                            .buttonStyle(.leafPrimary)
                            .accessibilityIdentifier("settings.checkConnection")
                            .disabled((state.fixtureMode.enabled && !connectionFixture) || checkingConnection || receivingKey)
                        if let connectionMessage {
                            Text(connectionMessage).accessibilityAddTraits(.updatesFrequently)
                                .accessibilityIdentifier("settings.connectionStatus")
                        }
                        Text("Checks read-only account access using the saved key.").font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                    }
                    Button("Forget key", role: .destructive, action: forgetKey).disabled(state.fixtureMode.enabled || checkingConnection)
                        .foregroundStyle(LeafTheme.loss)
                }
                .listRowBackground(LeafTheme.card)
                Section("Dashboard access") {
                    if state.dashboardPairingState == .paired {
                        Label("This iPhone is paired", systemImage: "checkmark.circle.fill")
                            .accessibilityIdentifier("settings.pairedDevice")
                    } else if state.dashboardPairingState == .unpaired {
                        Button(pairing.phase.isRunning ? "Waiting for approval…" : "Pair this iPhone", action: startPairing)
                            .buttonStyle(.leafPrimary)
                            .accessibilityIdentifier("settings.pairDevice")
                            .disabled(state.fixtureMode.enabled || pairing.phase.isRunning || scenePhase != .active)
                    } else {
                        Label("Checking pairing…", systemImage: "arrow.triangle.2.circlepath")
                            .accessibilityIdentifier("settings.checkingPairing")
                    }
                    if case let .waiting(code, expiresAt) = pairing.phase {
                        Text(code)
                            .font(.system(.title2, design: .monospaced, weight: .semibold))
                            .textSelection(.enabled)
                            .accessibilityLabel("Pairing code \(code)")
                            .accessibilityIdentifier("settings.pairingCode")
                        Text("Approve this code in the Kashbot dashboard before \(expiresAt.formatted(date: .omitted, time: .shortened)).")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        Button("Cancel pairing", role: .cancel, action: cancelPairing)
                            .accessibilityIdentifier("settings.cancelPairing")
                    }
                    if let status = pairing.phase.userStatus {
                        Text(status)
                            .accessibilityAddTraits(.updatesFrequently)
                            .accessibilityIdentifier("settings.pairingStatus")
                    }
                    DisclosureGroup("Advanced", isExpanded: $advancedDashboard) {
                        Text("Use a dashboard token only for recovery.")
                            .font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                        SecureField("Dashboard token", text: $token)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                            .privacySensitive()
                        Button("Save token") {
                            guard !state.fixtureMode.enabled else { return }
                            do {
                                try store.save(Data(token.trimmingCharacters(in: .whitespacesAndNewlines).utf8), account: KeychainStore.dashboardTokenAccount)
                                token = ""
                                message = "Dashboard token saved."
                                Task { await state.refreshDashboard() }
                            } catch { message = "Could not save the dashboard token. Try again." }
                        }.disabled(state.fixtureMode.enabled || token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }
                .listRowBackground(LeafTheme.card)
                if let source = Bundle.main.object(forInfoDictionaryKey: "LeafHFTSourceSHA") as? String,
                   source.count == 40 {
                    Section("Build") {
                        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "Unknown"
                        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "Unknown"
                        LabeledContent("Version", value: "\(version) (\(build))")
                            .accessibilityIdentifier("settings.buildVersion")
                        Text(source).font(LeafType.micro)
                            .foregroundStyle(LeafTheme.inkMuted)
                            .accessibilityIdentifier("settings.sourceSha")
                    }
                    .listRowBackground(LeafTheme.card)
                }
                if let cold = state.coldLoadTimings {
                    Section("Loading") {
                        Text("Time from opening the app until live data arrived.")
                            .font(LeafType.micro)
                            .foregroundStyle(LeafTheme.inkMuted)
                        loadingRows(cold)
                        if let resume = state.resumeLoadTimings {
                            Text("Last resume").font(LeafType.micro)
                                .foregroundStyle(LeafTheme.inkMuted)
                            loadingRows(resume)
                        }
                    }
                    .listRowBackground(LeafTheme.card)
                }
                if let message {
                    Text(message).accessibilityAddTraits(.updatesFrequently)
                        .accessibilityIdentifier("settings.status")
                        .listRowBackground(LeafTheme.card)
                }
                KashbotLiveSettingsSection()
                Section("Notifications") {
                    Text(state.fixtureMode.enabled ? PushRegistrar.demoStatus : pushRegistrar.pushStatus)
                        .accessibilityAddTraits(.updatesFrequently)
                        .accessibilityIdentifier("settings.push.status")
                    Button("Retry notification setup") {
                        Task { await pushRegistrar.activate(force: true) }
                    }
                    .disabled(state.fixtureMode.enabled)
                    .accessibilityIdentifier("settings.push.retry")
                }
                .listRowBackground(LeafTheme.card)
                Section("Appearance") {
                    Picker("Appearance", selection: $appearance) {
                        ForEach(LeafAppearance.allCases, id: \.self) { option in
                            Text(option.label).tag(option)
                        }
                    }
                    .pickerStyle(.segmented)
                    .accessibilityIdentifier("settings.appearance")
                }
                .listRowBackground(LeafTheme.card)
                Section("Help") {
                    Button {
                        onShowTour()
                    } label: {
                        Label("Show me around", systemImage: "sparkles")
                    }
                    .accessibilityIdentifier("settings.showTour")
                    Text("See where to check performance, inspect markets, manage engines, and connect your account.")
                        .font(LeafType.meta)
                        .foregroundStyle(LeafTheme.inkMuted)
                }
                .listRowBackground(LeafTheme.card)
            }
            .accessibilityIdentifier("settings.form")
            .font(LeafType.body)
            .foregroundStyle(LeafTheme.ink)
            .listSectionSpacing(16)
            .leafScreenBackground()
            .disabled(scenePhase != .active)
            .alert("Revoke runner access?", isPresented: $confirmingRevoke) {
                Button("Revoke runner access", role: .destructive) {
                    state.runAccountAction(.revoke, confirmedRevision: confirmedControlRevision)
                }
                .foregroundStyle(LeafTheme.loss)
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("The runner copy is revoked. Your phone's saved key remains on this phone.")
            }
            .navigationTitle("Settings")
            .fileImporter(isPresented: $choosingKeyFile, allowedContentTypes: [.plainText, .data], allowsMultipleSelection: false,
                          onCompletion: readKeyFile)
            .onAppear {
                refresh()
                preparePauseScopeFixture()
                startAutomaticPairingIfNeeded()
            }
            .onDisappear {
                cancelReceive(); connectionTask?.cancel(); cancelPairing(); keyID = ""; pem = ""; token = ""
                if let sequence = fixtureMutationSequence {
                    state.finishAccountMutation(sequence: sequence)
                    fixtureMutationSequence = nil
                }
            }
            .onChange(of: autoStartPairing) { _, requested in
                if requested { startAutomaticPairingIfNeeded() }
            }
            .onChange(of: state.kashbotStatus) { _, _ in
                confirmedControlRevision = nil
                confirmingRevoke = false
            }
            .onChange(of: scenePhase) { _, phase in
                if phase != .active {
                    confirmedControlRevision = nil
                    confirmingRevoke = false
                }
                if phase != .active && receivingKey {
                    cancelReceive()
                    message = "Transfer stopped. Return here to receive the key again."
                }
                if phase != .active && pairing.phase.isRunning { cancelPairing() }
                if phase == .active {
                    startAutomaticPairingIfNeeded()
                    if awaitingKalshiBrowserReturn && filePickerAllowed && !keyPresent {
                        awaitingKalshiBrowserReturn = false
                        choosingKeyFile = true
                        message = "Select the private-key file Kalshi downloaded. Kashbot will validate it before anything is saved."
                    }
                }
            }
        }
    }

    static func tradingStateLabel(status: KashbotStatus?, fallback: String) -> String {
        status?.automationLabel ?? fallback
    }

    static func privateKeyStorageCopy(isOwnerExecution: Bool) -> String {
        isOwnerExecution
            ? "The private key is saved in this iPhone’s Keychain for read-only phone access. Kashbot never displays it after import."
            : "The private key is saved in this iPhone’s Keychain. Account setup also encrypts and enrolls a runner copy so Kashbot can trade while this phone is offline. Kashbot never displays it after import."
    }

    private func preparePauseScopeFixture() {
        guard pauseScopeRecorder else { return }
        let arguments = ProcessInfo.processInfo.arguments
        if arguments.contains("-LEAFHFT_SETTINGS_PENDING_WALK") {
            let json = """
            {"dashboard_pairing":"paired","account_binding":"bound","automated_trading":"live_pending",
             "tenant":{"id":"4f0c2a1e-8b7d-4c3a-9e21-6d5f0b1a2c3d","runner_host":"sample-runner"},
             "lane":{"id":"9a8b7c6d-5e4f-4a3b-8c2d-1e0f9a8b7c6d","state":"live_pending","live_enabled":true}}
            """
            if let status = try? accountJSONDecoder().decode(KashbotStatus.self, from: Data(json.utf8)) {
                let sequence = state.beginAccountMutation(.startLive)
                state.acceptAccountActionResult(status, sequence: sequence)
                state.finishAccountMutation(sequence: sequence)
            }
        }
        if arguments.contains("-LEAFHFT_SETTINGS_MUTATION_WALK"), fixtureMutationSequence == nil {
            fixtureMutationSequence = state.beginAccountMutation(.startLive)
        }
    }

    private func statusRow(_ key: String, value: String, tone: LeafTone) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: 12) {
                KeyValueRow(key, value: "").fixedSize(horizontal: true, vertical: true)
                Spacer(minLength: 0)
                StateChip(value, tone: tone)
            }
            VStack(alignment: .leading, spacing: 6) {
                KeyValueRow(key, value: "")
                StateChip(value, tone: tone)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(key), \(value)")
    }

    private func loadingRows(_ timings: LoadTimings) -> some View {
        Group {
            ForEach(timings.rows) { row in
                LabeledContent(row.label, value: LoadTimings.display(row))
                    .accessibilityIdentifier("settings.loading.\(timings.kind.rawValue).\(row.id)")
            }
            LabeledContent("First full refresh", value: timings.firstPollMs.map { "\($0) ms" } ?? "waiting")
                .accessibilityIdentifier("settings.loading.\(timings.kind.rawValue).firstPoll")
        }
    }

    private func startPairing() {
        guard !state.fixtureMode.enabled, scenePhase == .active, !pairing.phase.isRunning else { return }
        pairingTask = Task { @MainActor in
            await pairing.start(deviceName: String(UIDevice.current.name.prefix(80)),
                                replaceExistingToken: state.dashboardPairingState == .unpaired)
            pairingTask = nil
            if pairing.phase == .approved { await state.refreshDashboard() }
        }
    }

    private func startAutomaticPairingIfNeeded() {
        guard autoStartPairing, !didAttemptAutomaticPairing, scenePhase == .active else { return }
        didAttemptAutomaticPairing = true
        let existingCredential: Data?
        do {
            existingCredential = try store.load(account: KeychainStore.dashboardTokenAccount)
        } catch {
            return
        }
        guard DashboardPairingLaunchPolicy.shouldAutoStart(hasCredential: existingCredential != nil) else { return }
        startPairing()
    }

    private func cancelPairing() {
        pairingTask?.cancel()
        pairingTask = nil
        pairing.cancel()
    }

    private func receiveKey() {
        guard !state.fixtureMode.enabled, !checkingConnection, !receivingKey, scenePhase == .active else { return }
        do {
            try receiver.begin()
            receivingKey = true
            message = "Waiting for the connected computer."
            receiveTask = Task { @MainActor in
                do {
                    while !Task.isCancelled {
                        if let draft = try receiver.receive() {
                            try Task.checkCancellation()
                            keyID = draft.key_id
                            pem = draft.private_key_pem
                            receivingKey = false
                            receiveTask = nil
                            message = state.isOwnerExecution
                                ? "Key ready. Tap Save key for read-only phone access."
                                : "Key ready. Tap Save, connect, and start trading to finish setup."
                            return
                        }
                        try await Task.sleep(nanoseconds: 500_000_000)
                    }
                } catch {
                    if Task.isCancelled { return }
                    receiver.cancel()
                    receivingKey = false
                    receiveTask = nil
                    message = "Transfer stopped. Your entries are unchanged. Try receiving again."
                }
            }
        } catch { message = "Could not start the transfer. Try again." }
    }

    private func cancelReceive() {
        receiveTask?.cancel()
        receiveTask = nil
        receiver.cancel()
        receivingKey = false
    }

    private func readKeyFile(_ result: Result<[URL], Error>) {
        // The explicit picker walk permits draft validation only. Saving and
        // live connection checks retain their independent fixture guards.
        guard filePickerAllowed else { return }
        switch result {
        case .failure(let error):
            // Cancellation leaves an existing draft intact. Never display a provider's
            // error text, which may contain the private file name or URL.
            if (error as NSError).code != CocoaError.userCancelled.rawValue {
                message = "Could not open the file. Try choosing it again, or paste the private key."
            }
        case .success(let urls):
            guard let url = urls.first else { return }
            do {
                pem = try validatedPrivateKeyFile(at: url)
                keyIDFocused = true
                message = state.isOwnerExecution
                    ? "Private-key file ready. Paste its matching Key ID, then tap Save key for read-only phone access."
                    : "Private-key file ready. Paste its matching Key ID, then tap Save, connect, and start trading."
            } catch PrivateKeyFileError.invalidText {
                message = "Choose a text PEM private-key file smaller than 64 KB. Your previous entry is unchanged."
            } catch {
                message = "Could not read a valid RSA private key. Choose the existing unencrypted PEM file, or paste it. Your previous entry is unchanged."
            }
        }
    }

    private func openKalshi() async {
        guard handoffAllowed, !openingKalshi else { return }
        openingKalshi = true
        defer { openingKalshi = false }
        let profile = URL(string: "https://kalshi.com/account/profile")!
        awaitingKalshiBrowserReturn = true
        if await UIApplication.shared.open(profile) {
            message = "Kalshi opened in your default browser. Create the key on the website, copy its Key ID, and download the private-key file."
        } else {
            awaitingKalshiBrowserReturn = false
            message = "Could not open the browser. Send the setup link to a computer instead."
        }
    }

    private func refresh() {
        state.refreshSetupCredentials()
        if connectionFixture {
            keyPresent = true
            return
        }
        guard !state.fixtureMode.enabled else { return }
        do {
            keyPresent = try store.load(account: KeychainStore.keyDERAccount) != nil && store.load(account: KeychainStore.keyIDAccount) != nil
        } catch { message = "Could not read the Keychain." }
    }

    private func importKey() {
        guard !state.fixtureMode.enabled, !checkingConnection else { return }
        guard scenePhase == .active,
              state.isOwnerExecution || !state.accountMutationInProgress else { return }
        do {
            let der = try decodeRSAPrivateKeyPEM(pem)
            _ = try KalshiSigner(pkcs1DER: der)
            let id = keyID.trimmingCharacters(in: .whitespacesAndNewlines)
            let previousDER = try store.load(account: KeychainStore.keyDERAccount)
            let previousID = try store.load(account: KeychainStore.keyIDAccount)
            do {
                try store.save(der, account: KeychainStore.keyDERAccount)
                try store.save(Data(id.utf8), account: KeychainStore.keyIDAccount)
            } catch {
                // Restore the credential pair if the second write fails.
                do {
                    if let previousDER { try store.save(previousDER, account: KeychainStore.keyDERAccount) }
                    else { try store.delete(account: KeychainStore.keyDERAccount) }
                    if let previousID { try store.save(previousID, account: KeychainStore.keyIDAccount) }
                    else { try store.delete(account: KeychainStore.keyIDAccount) }
                } catch {
                    message = "Key import was incomplete. Forget the key, then import again."
                    refresh()
                    return
                }
                throw error
            }
            pem = ""
            keyID = ""
            refresh()
            message = state.isOwnerExecution ? "Key saved on this device for read-only access." : "Key saved on this device. Connecting and checking the dry run; live trading requires confirmation and authentication."
            checkConnection(startLiveWhenReady: !state.isOwnerExecution)
        } catch is KeychainStoreError {
            message = "Could not save the key in this device's Keychain. Unlock the phone and try again; the PEM was valid."
            refresh()
        } catch { message = "Could not import the key. Check the key id and unencrypted RSA PEM, then try again." }
    }

    private func checkConnection(startLiveWhenReady: Bool = false) {
        guard (!state.fixtureMode.enabled || connectionFixture), keyPresent, !checkingConnection else { return }
        checkingConnection = true
        fixtureCheckCount += 1
        let fixtureAttempt = fixtureCheckCount
        connectionMessage = "Checking the saved key with Kalshi…"
        connectionTask = Task { @MainActor in
            defer { checkingConnection = false; connectionTask = nil }
            do {
                if connectionFixture {
                    // Exercise the same pending, error, retry and cancellation UI
                    // without constructing a client or reading the Keychain.
                    try await Task.sleep(nanoseconds: fixtureAttempt == 3 ? 30_000_000_000 : 2_000_000_000)
                    if fixtureAttempt == 1 { throw KalshiClientError.transport }
                } else {
                    _ = try await KalshiClient(fixtureMode: state.fixtureMode).get(.balance, as: AccountBalance.self)
                }
                try Task.checkCancellation()
                if connectionFixture {
                    connectionMessage = "Connected."
                    return
                }
                connectionMessage = "Connected. Preparing your account…"
                await state.refreshAccountSetup()
                if state.isOwnerExecution {
                    connectionMessage = "Connected. Owner book controls are on Monitor."
                    return
                }
                if state.canSetupDryRun { await state.setupDryRun(startLiveWhenReady: startLiveWhenReady) }
                if state.kashbotStatus?.automatedTrading == .live {
                    connectionMessage = "Connected."
                } else if state.kashbotStatus?.automatedTrading == .dryRun {
                    connectionMessage = "Connected. Dry run passed. Tap Start trading to finish."
                } else if state.setupError != nil {
                    connectionMessage = "Connected. Account setup needs attention below."
                } else {
                    connectionMessage = "Connected. Account setup is continuing below."
                }
            } catch {
                guard !Task.isCancelled else {
                    connectionMessage = "Check stopped. Try again."
                    return
                }
                switch error as? KalshiClientError {
                case .noCredential:
                    connectionMessage = "Key unreadable. Import your existing key again."
                case .unauthorized:
                    connectionMessage = "Key rejected. Match the key ID and file, then import again."
                case .rateLimited:
                    connectionMessage = "Kalshi is busy. Retry in a minute."
                default:
                    connectionMessage = "Connection failed. Check internet, then retry."
                }
            }
        }
    }

    private func forgetKey() {
        guard !state.fixtureMode.enabled else { return }
        var failed = false
        do { try store.delete(account: KeychainStore.keyDERAccount) } catch { failed = true }
        do { try store.delete(account: KeychainStore.keyIDAccount) } catch { failed = true }
        pem = ""
        keyID = ""
        refresh()
        connectionMessage = nil
        message = failed ? "Could not fully remove the key. Try Forget key again." : "Runner key removed."
    }
}
