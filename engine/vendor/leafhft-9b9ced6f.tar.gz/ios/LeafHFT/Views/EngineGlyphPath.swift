import SwiftUI

/// A bounded SVG path reader for the server's 256-point engine symbols.
enum EngineGlyphPath {
    static func parse(_ d: String, viewBox: CGFloat = 256) -> Path? {
        guard viewBox.isFinite, viewBox > 0, d.utf8.count <= 16_384 else { return nil }
        var reader = Reader(bytes: Array(d.utf8))
        var path = Path()
        var current = CGPoint.zero
        var start = CGPoint.zero
        var cubicControl: CGPoint?
        var quadControl: CGPoint?
        var command: UInt8?
        var count = 0

        while true {
            reader.skipWhitespace()
            if reader.index == reader.bytes.count { return count == 0 ? nil : path }
            let byte = reader.bytes[reader.index]
            if (65...90).contains(byte) || (97...122).contains(byte) {
                command = byte
                reader.index += 1
                reader.allowComma = false
            }
            guard let active = command else { return nil }
            let upper = active >= 97 ? active - 32 : active
            let relative = active >= 97
            guard count > 0 || upper == 77 else { return nil }
            count += 1
            guard count <= 4_096 else { return nil }
            let origin = relative ? current : .zero
            let oldCubic = cubicControl
            let oldQuad = quadControl
            cubicControl = nil
            quadControl = nil

            switch upper {
            case 77, 76: // M, L; subsequent coordinate pairs after M are lines.
                guard let end = reader.point(origin: origin) else { return nil }
                if upper == 77 {
                    path.move(to: end)
                    start = end
                    command = relative ? 108 : 76
                } else {
                    path.addLine(to: end)
                }
                current = end
            case 72: // H
                guard let x = reader.number() else { return nil }
                current.x = x + origin.x
                guard finite(current) else { return nil }
                path.addLine(to: current)
            case 86: // V
                guard let y = reader.number() else { return nil }
                current.y = y + origin.y
                guard finite(current) else { return nil }
                path.addLine(to: current)
            case 67: // C
                guard let c1 = reader.point(origin: origin),
                      let c2 = reader.point(origin: origin),
                      let end = reader.point(origin: origin) else { return nil }
                path.addCurve(to: end, control1: c1, control2: c2)
                cubicControl = c2
                current = end
            case 83: // S
                let c1 = oldCubic.map { reflected($0, around: current) } ?? current
                guard finite(c1), let c2 = reader.point(origin: origin),
                      let end = reader.point(origin: origin) else { return nil }
                path.addCurve(to: end, control1: c1, control2: c2)
                cubicControl = c2
                current = end
            case 81: // Q
                guard let control = reader.point(origin: origin),
                      let end = reader.point(origin: origin) else { return nil }
                path.addQuadCurve(to: end, control: control)
                quadControl = control
                current = end
            case 84: // T
                let control = oldQuad.map { reflected($0, around: current) } ?? current
                guard finite(control), let end = reader.point(origin: origin) else { return nil }
                path.addQuadCurve(to: end, control: control)
                quadControl = control
                current = end
            case 65: // A
                guard let rx = reader.number(), let ry = reader.number(),
                      let rotation = reader.number(), let large = reader.flag(),
                      let sweep = reader.flag(), let end = reader.point(origin: origin),
                      arc(&path, from: current, to: end, rx: rx, ry: ry,
                          rotation: rotation, large: large, sweep: sweep) else { return nil }
                current = end
            case 90: // Z cannot be implicitly repeated.
                path.closeSubpath()
                current = start
                command = nil
            default:
                return nil
            }
        }
    }

    private static func finite(_ point: CGPoint) -> Bool {
        point.x.isFinite && point.y.isFinite
    }

    private static func reflected(_ point: CGPoint, around center: CGPoint) -> CGPoint {
        CGPoint(x: center.x + (center.x - point.x), y: center.y + (center.y - point.y))
    }

    /// SVG 1.1 F.6 endpoint-to-center conversion, split into at most quarter turns.
    private static func arc(_ path: inout Path, from start: CGPoint, to end: CGPoint,
                            rx inputRX: CGFloat, ry inputRY: CGFloat, rotation: CGFloat,
                            large: Bool, sweep: Bool) -> Bool {
        if start == end { return true }
        var rx = abs(inputRX)
        var ry = abs(inputRY)
        if rx == 0 || ry == 0 {
            path.addLine(to: end)
            return true
        }
        let phi = rotation.truncatingRemainder(dividingBy: 360) * .pi / 180
        let cosine = cos(phi)
        let sine = sin(phi)
        let dx = start.x / 2 - end.x / 2
        let dy = start.y / 2 - end.y / 2
        let x = cosine * dx + sine * dy
        let y = -sine * dx + cosine * dy
        let scale = hypot(x / rx, y / ry)
        guard scale.isFinite else { return false }
        if scale > 1 {
            rx *= scale
            ry *= scale
        }
        guard rx.isFinite, ry.isFinite else { return false }
        let nx = x / rx
        let ny = y / ry
        let squared = nx * nx + ny * ny
        guard squared.isFinite, squared > 0 else { return false }
        let sign: CGFloat = large == sweep ? -1 : 1
        let factor = sign * sqrt(max(0, (1 - squared) / squared))
        let cx = factor * rx * ny
        let cy = -factor * ry * nx
        let center = CGPoint(x: cosine * cx - sine * cy + start.x / 2 + end.x / 2,
                             y: sine * cx + cosine * cy + start.y / 2 + end.y / 2)
        let ux = (x - cx) / rx
        let uy = (y - cy) / ry
        let vx = (-x - cx) / rx
        let vy = (-y - cy) / ry
        let theta = atan2(uy, ux)
        var delta = atan2(ux * vy - uy * vx, ux * vx + uy * vy)
        if sweep && delta < 0 { delta += 2 * .pi }
        if !sweep && delta > 0 { delta -= 2 * .pi }
        guard finite(center), theta.isFinite, delta.isFinite else { return false }
        let segments = max(1, Int(ceil(abs(delta) / (.pi / 2))))
        let step = delta / CGFloat(segments)
        let k = 4 / CGFloat(3) * tan(step / 4)

        func point(_ angle: CGFloat) -> CGPoint {
            CGPoint(x: center.x + rx * cosine * cos(angle) - ry * sine * sin(angle),
                    y: center.y + rx * sine * cos(angle) + ry * cosine * sin(angle))
        }
        func tangent(_ angle: CGFloat) -> CGPoint {
            CGPoint(x: -rx * cosine * sin(angle) - ry * sine * cos(angle),
                    y: -rx * sine * sin(angle) + ry * cosine * cos(angle))
        }
        for segment in 0..<segments {
            let a = theta + CGFloat(segment) * step
            let b = a + step
            let p0 = segment == 0 ? start : point(a)
            let p1 = segment == segments - 1 ? end : point(b)
            let t0 = tangent(a)
            let t1 = tangent(b)
            let c1 = CGPoint(x: p0.x + k * t0.x, y: p0.y + k * t0.y)
            let c2 = CGPoint(x: p1.x - k * t1.x, y: p1.y - k * t1.y)
            guard finite(p1), finite(c1), finite(c2) else { return false }
            path.addCurve(to: p1, control1: c1, control2: c2)
        }
        return true
    }

    private struct Reader {
        let bytes: [UInt8]
        var index = 0
        var allowComma = false

        mutating func skipWhitespace() {
            while index < bytes.count && [9, 10, 13, 32].contains(bytes[index]) { index += 1 }
        }

        mutating func separator() -> Bool {
            skipWhitespace()
            if index < bytes.count && bytes[index] == 44 {
                guard allowComma else { return false }
                index += 1
                skipWhitespace()
            }
            allowComma = true
            return index < bytes.count
        }

        mutating func number() -> CGFloat? {
            guard separator() else { return nil }
            let start = index
            if bytes[index] == 43 || bytes[index] == 45 { index += 1 }
            var digits = 0
            while index < bytes.count && (48...57).contains(bytes[index]) {
                digits += 1
                index += 1
            }
            if index < bytes.count && bytes[index] == 46 {
                index += 1
                while index < bytes.count && (48...57).contains(bytes[index]) {
                    digits += 1
                    index += 1
                }
            }
            guard digits > 0 else { return nil }
            if index < bytes.count && (bytes[index] == 69 || bytes[index] == 101) {
                index += 1
                if index < bytes.count && (bytes[index] == 43 || bytes[index] == 45) { index += 1 }
                let exponentStart = index
                while index < bytes.count && (48...57).contains(bytes[index]) { index += 1 }
                guard index > exponentStart else { return nil }
            }
            guard let value = Double(String(decoding: bytes[start..<index], as: UTF8.self)),
                  value.isFinite else { return nil }
            let result = CGFloat(value)
            return result.isFinite ? result : nil
        }

        mutating func flag() -> Bool? {
            guard separator(), bytes[index] == 48 || bytes[index] == 49 else { return nil }
            let result = bytes[index] == 49
            index += 1
            return result
        }

        mutating func point(origin: CGPoint) -> CGPoint? {
            guard let x = number(), let y = number() else { return nil }
            let point = CGPoint(x: x + origin.x, y: y + origin.y)
            return EngineGlyphPath.finite(point) ? point : nil
        }
    }
}

struct EngineGlyphView: View {
    /// A glyph narrower or shorter than this many viewBox units fills nothing visible.
    static let minimumExtent: CGFloat = 4
    let parsed: Path?
    let tint: Color
    let size: CGFloat

    init(path: String, tint: Color, size: CGFloat) {
        // Valid SVG syntax can still describe an invisible, collapsed symbol.
        // Keep parsing geometry intact (including SVG's zero-radius lines), but
        // use the dot when there is no two-dimensional glyph to fill.
        if let candidate = EngineGlyphPath.parse(path), !candidate.isEmpty,
           candidate.boundingRect.width >= Self.minimumExtent,
           candidate.boundingRect.height >= Self.minimumExtent {
            parsed = candidate
        } else {
            parsed = nil
        }
        self.tint = tint
        self.size = size
    }

    var body: some View {
        Group {
            if let parsed {
                parsed.applying(CGAffineTransform(scaleX: size / 256, y: size / 256))
                    .fill(tint, style: FillStyle(eoFill: false))
            } else {
                Circle().fill(tint).frame(width: 12, height: 12)
            }
        }
        .frame(width: size, height: size)
    }
}
