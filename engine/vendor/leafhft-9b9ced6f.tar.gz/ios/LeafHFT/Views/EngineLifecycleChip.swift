import SwiftUI
import LeafHFTCore

/// Catalog groups in display order (D8). Retired renders collapsed. Pure mapping, no I/O.
enum EngineCatalogGroup: String, CaseIterable, Identifiable {
    case probing, live, notStarted, halted, retired

    var id: String { rawValue }

    var title: String {
        switch self {
        case .probing: return "Probing"
        case .live: return "Live"
        case .notStarted: return "Not started"
        case .halted: return "Halted"
        case .retired: return "Retired"
        }
    }

    static func of(_ engine: Engine) -> EngineCatalogGroup {
        switch engine.lifecycle?.state {
        case .probe?, .probeSized?: return .probing
        case .graduated?, .canary?: return .live
        case .halted?: return .halted
        case .retired?: return .retired
        default: return .notStarted
        }
    }

    /// One pass over the engines; groups keep the runner's engine order and empty groups are dropped.
    static func grouped(_ engines: [Engine]) -> [EngineCatalogSection] {
        var buckets: [EngineCatalogGroup: [Engine]] = [:]
        for engine in engines { buckets[of(engine), default: []].append(engine) }
        return allCases.compactMap { group in
            guard let members = buckets[group], !members.isEmpty else { return nil }
            return EngineCatalogSection(group: group, engines: members)
        }
    }
}

struct EngineCatalogSection: Identifiable {
    let group: EngineCatalogGroup
    let engines: [Engine]
    var id: EngineCatalogGroup { group }
}

/// The lifecycle chip from the rendering standard: draft slate, tested blue, probing amber, live green,
/// suspended amber with the reset time in CT, halted red with its reasons, retired muted.
/// The chip always carries its word; colour is never the only signal. A missing lifecycle reads
/// "No lifecycle" (the dashboard received none);
/// an unknown state reads "Lifecycle not reported".
struct EngineLifecycleChip: View {
    enum Kind: Equatable { case noLifecycle, notReported, draft, tested, probing, live, suspended, halted, retired }

    let lifecycle: EngineLifecycle?
    let eligibility: ProbeEligibility?
    var now: Date = Date()

    static func kind(_ lifecycle: EngineLifecycle?, eligibility: ProbeEligibility?, now: Date) -> Kind {
        guard let lifecycle else {
            if eligibility?.eligible == true { return .tested }
            return .noLifecycle
        }
        switch lifecycle.state {
        case .probe, .probeSized, .graduated, .canary:
            // A breaker trip suspends entries until 00:00Z; it is not a halt.
            if let until = lifecycle.entriesSuspendedUntil, until > now { return .suspended }
            return lifecycle.state == .graduated || lifecycle.state == .canary ? .live : .probing
        case .halted: return .halted
        case .retired: return .retired
        case .shadow: return eligibility?.eligible == true ? .tested : .draft
        case .unknown: return eligibility?.eligible == true ? .tested : .notReported
        }
    }

    static func text(_ lifecycle: EngineLifecycle?, eligibility: ProbeEligibility?, now: Date) -> String {
        switch kind(lifecycle, eligibility: eligibility, now: now) {
        case .noLifecycle: return "No lifecycle"
        case .notReported: return "Lifecycle not reported"
        case .draft: return "Draft"
        case .tested: return "Tested"
        case .probing: return lifecycle?.label ?? "Probing"
        case .live: return lifecycle?.state == .canary ? (lifecycle?.label ?? "Live") : "Live"
        case .suspended:
            guard let until = lifecycle?.entriesSuspendedUntil else { return "Suspended" }
            return "Suspended until \(centralTime(until))"
        case .halted: return "Halted: " + stopReasons(lifecycle)
        case .retired: return "Retired"
        }
    }

    /// The runner's reason text as sent, else its code; never a sentence composed here.
    static func stopReasons(_ lifecycle: EngineLifecycle?) -> String {
        let reasons = (lifecycle?.stopReasons ?? []).compactMap { reason -> String? in
            if let text = reason.text, !text.isEmpty { return text }
            return reason.code.isEmpty ? nil : reason.code
        }
        return reasons.isEmpty ? "reason not reported" : reasons.joined(separator: ", ")
    }

    /// Reset times print in Central time; the probe day itself stays the UTC day.
    static func centralTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "America/Chicago")
        formatter.dateFormat = "MMM d, h:mm a"
        return formatter.string(from: date) + " CT"
    }

    private var kind: Kind { Self.kind(lifecycle, eligibility: eligibility, now: now) }
    private var text: String { Self.text(lifecycle, eligibility: eligibility, now: now) }

    private var foreground: Color {
        switch kind {
        case .notReported, .draft: return LeafTheme.stale
        case .noLifecycle: return LeafTheme.inkMuted
        case .tested: return LeafTheme.series1
        case .probing, .suspended: return LeafTheme.warn
        case .live: return LeafTheme.gain
        case .halted: return LeafTheme.loss
        case .retired: return LeafTheme.inkFaint
        }
    }

    private var background: Color {
        switch kind {
        case .notReported, .draft: return LeafTheme.staleSoft
        case .noLifecycle: return LeafTheme.cardRaised
        case .tested: return LeafTheme.series1.opacity(0.14)
        case .probing, .suspended: return LeafTheme.warnSoft
        case .live: return LeafTheme.gainSoft
        case .halted: return LeafTheme.lossSoft
        case .retired: return LeafTheme.cardRaised
        }
    }

    private var symbol: String {
        switch kind {
        case .noLifecycle: return "circle.dashed"
        case .notReported: return "questionmark"
        case .draft: return "pencil"
        case .tested: return "checkmark.seal"
        case .probing: return "scope"
        case .live: return "bolt.fill"
        case .suspended: return "pause.circle"
        case .halted: return "hand.raised.fill"
        case .retired: return "archivebox"
        }
    }

    var body: some View {
        Label(text, systemImage: symbol)
            .labelStyle(.titleAndIcon)
            .font(LeafType.micro)
            .foregroundStyle(foreground)
            .fixedSize(horizontal: false, vertical: true)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .frame(minHeight: 24)
            .background(background, in: Capsule())
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(text)
    }
}

/// The account chip beside every engine: its account, "Unassigned", or a red "Bound on N accounts"
/// when the runner reports the engine under more than one account.
struct EngineAccountChip: View {
    let engine: Engine
    let accounts: [EngineControlAccount]
    let boundAccountIds: [String]

    /// Distinct account ids the engines route and the probes board report for this engine, in order.
    static func boundAccountIds(engine: Engine, board: ProbeBoardResponse?) -> [String] {
        var ids: [String] = []
        var candidates: [String?] = [engine.assignment?.accountId]
        for row in board?.engines ?? [] where row.engineId == engine.engineId {
            candidates.append(row.assignment?.accountId)
        }
        for case let id? in candidates where !id.isEmpty && !ids.contains(id) { ids.append(id) }
        return ids
    }

    static func boundAccountIds(engine: Engine, lookup: [String: [String]]) -> [String] {
        var ids: [String] = []
        let candidates = [engine.assignment?.accountId].compactMap { $0 } + (lookup[engine.engineId] ?? [])
        for id in candidates where !id.isEmpty && !ids.contains(id) { ids.append(id) }
        return ids
    }

    /// Scan the board once, then omit engines whose account chip would read Unassigned.
    static func assignmentSummary(engines: [Engine], board: ProbeBoardResponse?)
        -> (engines: [Engine], boundAccountIds: [String: [String]], unassignedCount: Int) {
        var lookup: [String: [String]] = [:]
        for row in board?.engines ?? [] {
            if let id = row.assignment?.accountId, !id.isEmpty {
                lookup[row.engineId, default: []].append(id)
            }
        }
        var listed: [Engine] = []
        var bindings: [String: [String]] = [:]
        for engine in engines {
            let ids = boundAccountIds(engine: engine, lookup: lookup)
            if !ids.isEmpty || engine.assignment?.account == "other" {
                listed.append(engine)
                bindings[engine.engineId] = ids
            }
        }
        return (listed, bindings, engines.count - listed.count)
    }

    static func text(engine: Engine, accounts: [EngineControlAccount],
                     boundAccountIds: [String]) -> (text: String, tone: LeafTone) {
        if boundAccountIds.count > 1 { return ("Bound on \(boundAccountIds.count) accounts", .loss) }
        if let id = boundAccountIds.first {
            return (accounts.first { $0.id == id }?.label ?? id, .neutral)
        }
        if engine.assignment?.account == "other" { return ("Another account", .stale) }
        return ("Unassigned", .stale)
    }

    private var presentation: (text: String, tone: LeafTone) {
        Self.text(engine: engine, accounts: accounts, boundAccountIds: boundAccountIds)
    }

    var body: some View {
        StateChip(presentation.text, tone: presentation.tone,
                  symbol: presentation.tone == .loss ? "exclamationmark.triangle.fill" : "person.crop.square")
    }
}

/// Runner numbers as text. Null renders "Not reported", never zero; the probe day is always labelled UTC.
enum EngineRuntimeText {
    static func breaker(_ engine: Engine) -> String {
        "Breaker: " + ProbePresentation.breakerMeter(engine.lifecycle?.breaker)
    }

    static func perContract(_ engine: Engine) -> String {
        "Live: " + ProbePresentation.perContract(engine.live) +
            (engine.live.map { " over \($0.days) \($0.days == 1 ? "day" : "days")" } ?? "")
    }

    static func probeDay(_ day: ProbeDay?) -> String? {
        guard let day else { return nil }
        let realized = day.realizedCents.map { LeafFormat.signedMoney(cents: $0) } ?? ProbePresentation.notReported
        let tickets = (day.tickets ?? day.entries).map { "\($0) \($0 == 1 ? "ticket" : "tickets")" } ?? "tickets not reported"
        return "Probe day \(day.utcDay ?? ProbePresentation.notReported) (UTC): \(realized) · \(tickets)"
    }

    static func utc(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "UTC")
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        return formatter.string(from: date) + " UTC"
    }
}
