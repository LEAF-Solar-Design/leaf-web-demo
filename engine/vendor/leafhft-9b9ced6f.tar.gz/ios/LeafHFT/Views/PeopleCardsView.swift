import SwiftUI
import LeafHFTCore

@MainActor struct PeopleScreenView: View {
    @Environment(AppState.self) private var state

    var body: some View {
        Group {
            if state.peopleLoading {
                ProgressView("Loading people")
            } else {
                switch state.peopleResult {
                case .success(let response):
                    PeopleCardsView(people: response.people, referenceTime: response.generatedAt, isFixture: false)
                case .notAuthorized, .unavailable:
                    Text("People unavailable")
                case nil:
                    ProgressView("Loading people")
                }
            }
        }
        .navigationTitle("People")
        .task(id: state.peopleRequestID) { await state.loadPeople() }
    }
}

/// A read-only rendering of supplied presentation values. No app state or transport dependency.
@MainActor struct PeopleCardsView: View {
    let people: [PeopleCards.Person]
    let referenceTime: Date
    var isFixture = true
    @State private var timelineStartedAt = Date()
    @State private var timelineNow = Date()
    @State private var fixtureEvidenceExpired = false

    private var advancesFixtureForUITest: Bool {
        #if DEBUG
        isFixture && ProcessInfo.processInfo.arguments.contains("-LEAFHFT_PEOPLE_ADVANCE_TIME")
        #else
        false
        #endif
    }

    var body: some View {
        // Keep the identified List as the root so accessibility and scrolling stay stable.
        let elapsed = max(0, timelineNow.timeIntervalSince(timelineStartedAt))
        let fixtureElapsed = fixtureEvidenceExpired ? PeopleCards.sixHours + 1 : elapsed
        list(now: isFixture ? referenceTime.addingTimeInterval(fixtureElapsed) : timelineNow)
            .navigationTitle(isFixture ? "People preview" : "People")
            .task {
                timelineNow = Date()
                while !Task.isCancelled {
                    do { try await Task.sleep(for: .seconds(60)) }
                    catch { return }
                    guard !Task.isCancelled else { return }
                    timelineNow = Date()
                }
            }
            .task {
                // A single DEBUG clock jump exercises expiry without a fast refresh schedule.
                guard advancesFixtureForUITest else { return }
                do { try await Task.sleep(for: .seconds(30)) }
                catch { return }
                guard !Task.isCancelled else { return }
                fixtureEvidenceExpired = true
            }
    }

    private func list(now: Date) -> some View {
        List {
            Section {
                if isFixture {
                    Text("Fixture data, not live accounts")
                        .font(.headline)
                        .accessibilityIdentifier("people.fixture")
                    Text("Synthetic examples illustrate supplied evidence. They do not claim the current endpoint supplies live orders, refusals or projections.")
                        .font(.caption)
                } else {
                    Text("Live people data").font(.headline)
                    Text("Missing evidence remains unknown. Recorded activity alone does not prove live trading.").font(.caption)
                }
                Text(Self.responseTimeText(referenceTime, now: now)).font(.caption)
                    .accessibilityIdentifier("people.responseTime")
                if !isFixture && people.isEmpty { Text("No people reported") }
            }
            ForEach(people) { person in
                Section {
                    Text(Self.laneReference(person)).font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("people.laneRef.\(person.id)")
                    Text(person.lane.verdict(at: now).rawValue)
                        .font(.title2.bold())
                        .accessibilityIdentifier("people.verdict.\(person.id)")
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text("Current cash: \(person.funds.currentCash?.text ?? "no data")")
                            .accessibilityIdentifier("people.cash.\(person.id)")
                        if let age = Self.cashAgeText(person.funds, now: now) {
                            Spacer(minLength: 4)
                            Text(age).font(.caption).foregroundStyle(.secondary)
                                .multilineTextAlignment(.trailing)
                                .accessibilityIdentifier("people.cashAge.\(person.id)")
                        }
                    }
                    Text("Refusal: \(person.lane.refusal.currentReason(at: now) ?? "unknown")")
                        .accessibilityIdentifier("people.refusal.\(person.id)")
                    Text(Self.coverageText(person)).font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("people.coverage.\(person.id)")
                    Text(person.lane.killText)
                    if person.lane.verdict(at: now) == .off {
                        Text(PeopleCards.Lane.offExplanation).font(.caption)
                    }
                    DisclosureGroup("Evidence details") {
                        laneDetails(person.lane)
                        activity(person.orders, title: "Orders")
                        activity(person.fills, title: "Fills")
                        funds(person.funds)
                    }.accessibilityIdentifier("people.evidence.\(person.id)")
                    let engines = person.scopedEngines
                    ForEach(Array(engines.prefix(Self.inlineEngineLimit))) { engine in
                        engineCard(engine, personID: person.id)
                    }
                    if engines.count > Self.inlineEngineLimit {
                        NavigationLink("All engines (\(engines.count))") {
                            List {
                                ForEach(engines) { engine in engineCard(engine, personID: person.id) }
                            }.navigationTitle(Self.identityText(person))
                        }.accessibilityIdentifier("people.engines.all.\(person.id)")
                    }
                    if let text = person.emptyEnginesText { Text(text) }
                } header: {
                    // The owner identity leads the card; the lane id is the secondary caption beneath it.
                    Text(Self.identityText(person)).font(.headline).textCase(nil)
                        .foregroundStyle(.primary)
                        .accessibilityIdentifier("people.person.\(person.id)")
                }
            }
        }
        .accessibilityIdentifier("people.list")
    }

    @ViewBuilder private func engineCard(_ engine: PeopleCards.EngineCard, personID: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(engine.name).font(.headline)
            Text("Assignment: \(engine.assignment)")
            Text(engine.sharing.text)
            Text("Reported realized P&L: \(engine.performance.realizedText)")
                .accessibilityIdentifier("people.performance.\(personID).\(engine.id)")
            Text(engine.projection?.text ?? "Daily projection: not estimable")
                .accessibilityIdentifier("people.projection.\(personID).\(engine.id)")
            performance(engine.performance)
        }
    }

    /// Engines shown inline before the "All engines (N)" drill-down.
    static let inlineEngineLimit = 2
    static let identityMissing = "Identity not reported"

    /// The human owner or account label when the data has one. A label that only restates the lane or
    /// account id ("Lane 4383ed19") is not an identity, so the card says so instead of inventing one.
    static func identityText(_ person: PeopleCards.Person) -> String {
        let label = person.label.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !label.isEmpty else { return identityMissing }
        let lowered = label.lowercased()
        for id in [person.laneID, person.accountID] where !id.isEmpty {
            let key = id.lowercased()
            if lowered == key { return identityMissing }
            for prefix in ["lane ", "account "] where lowered.hasPrefix(prefix) {
                let rest = lowered.dropFirst(prefix.count).trimmingCharacters(in: .whitespaces)
                if rest.count >= 4 && key.hasPrefix(rest) { return identityMissing }
            }
        }
        return label
    }

    /// The raw lane id, secondary to the identity; the supplied label is kept when it was not used as identity.
    static func laneReference(_ person: PeopleCards.Person) -> String {
        let label = person.label.trimmingCharacters(in: .whitespacesAndNewlines)
        var text = "Lane id: \(person.laneID.isEmpty ? "not reported" : person.laneID)"
        if identityText(person) == identityMissing && !label.isEmpty && label != person.laneID {
            text += " · supplied label: \(label)"
        }
        return text
    }

    /// Cash freshness is its own observation, separate from the response generation time.
    static func cashAgeText(_ funds: PeopleCards.Funds, now: Date, timeZone: TimeZone = .current) -> String? {
        guard funds.currentCash != nil else { return nil }
        guard let observedAt = funds.observedAt else { return "Cash time not reported" }
        return "Cash as of " + LabTime.stamp(observedAt, now: now, timeZone: timeZone)
    }

    static func responseTimeText(_ referenceTime: Date, now: Date, timeZone: TimeZone = .current) -> String {
        "Response generated " + LabTime.stamp(referenceTime, now: now, timeZone: timeZone)
    }

    /// How many of this lane's headline evidence fields the response supplied, named once instead of row by row.
    static func coverageText(_ person: PeopleCards.Person) -> String {
        let fields: [(String, Bool)] = [
            ("lane state", person.lane.state != .unknown),
            ("refusal", person.lane.refusal.reason != nil),
            ("cash", person.funds.currentCash != nil),
            ("orders", person.orders.recorded24h.value != nil),
            ("fills", person.fills.recorded24h.value != nil),
            ("last order", person.lane.lastOrder.time != nil),
            ("last fill", person.lane.lastFill.time != nil)]
        let missing = fields.filter { !$0.1 }.map(\.0)
        let summary = "Evidence in this response: \(fields.count - missing.count) of \(fields.count) lane fields supplied"
        return missing.isEmpty ? summary : summary + "; not supplied: " + missing.joined(separator: ", ")
    }

    @ViewBuilder private func laneDetails(_ lane: PeopleCards.Lane) -> some View {
        Text("Lane state: \(lane.state == .unknown ? "no data" : lane.state.rawValue)")
        if let observedAt = lane.observedAt {
            Text("Lane observed: \(PeopleCards.timeText(observedAt))")
        }
        Text("Revoked: \(lane.revoked.map { $0 ? "yes" : "no" } ?? "no data")")
        Text("Last supplied order: \(PeopleCards.timeText(lane.lastOrder.time))")
        Text("Order provenance: \(lane.lastOrder.provenance.rawValue); observed: \(PeopleCards.timeText(lane.lastOrder.observedAt))")
        Text("Last supplied fill: \(PeopleCards.timeText(lane.lastFill.time))")
        Text("Fill provenance: \(lane.lastFill.provenance.rawValue); observed: \(PeopleCards.timeText(lane.lastFill.observedAt))")
        Text("Six-hour history: \(lane.history.complete ? "complete as supplied" : "incomplete or unavailable"); orders: \(lane.history.orders.text)")
        Text("History from \(PeopleCards.timeText(lane.history.from)) through \(PeopleCards.timeText(lane.history.through)); provenance: \(lane.history.provenance.rawValue)")
        Text("Refusal support: \(lane.refusal.supported ? "supported as supplied" : "unknown or unsupported")")
        if let observedAt = lane.refusal.observedAt {
            Text("Refusal observed: \(PeopleCards.timeText(observedAt)); valid from \(PeopleCards.timeText(lane.refusal.validFrom ?? observedAt)) through \(PeopleCards.timeText(lane.refusal.validUntil))")
        }
    }

    @ViewBuilder private func activity(_ activity: PeopleCards.Activity, title: String) -> some View {
        Text(title).font(.headline)
        Text("Recorded 24-hour count: \(activity.recorded24h.value == nil ? "no data" : activity.recorded24h.text)")
        Text("Recorded seven-day count: \(activity.recorded7d.value == nil ? "no data" : activity.recorded7d.text)")
        Text("Complete 24-hour total: \(activity.total24h.value == nil ? "no data" : activity.total24h.text)")
        Text("Complete seven-day total: \(activity.total7d.value == nil ? "no data" : activity.total7d.text)")
        Text("Coverage: \(activity.coverage)")
        if let observedAt = activity.observedAt {
            Text("Observed: \(PeopleCards.timeText(observedAt))").font(.caption)
        }
    }

    @ViewBuilder private func funds(_ funds: PeopleCards.Funds) -> some View {
        Text("Money as reported").font(.headline)
        Text("Activation-budget cash: \(funds.activationBudgetCash?.text ?? "no data")")
        Text("Reported stake: \(funds.reportedStake?.text ?? "no data")")
        Text("Turnover used: \(funds.turnoverUsed?.text ?? "no data")")
        Text("Reported cap: \(funds.reportedCap?.text ?? "no data")")
        Text("Turnover has no asserted daily period. A reported cap is not an independently verified enforcement limit.").font(.caption)
        if let observedAt = funds.observedAt {
            Text("Observed: \(PeopleCards.timeText(observedAt))").font(.caption)
        }
    }

    @ViewBuilder private func performance(_ performance: PeopleCards.Performance) -> some View {
        Text("\(performance.days.count == 14 ? "14-day engine results" : "Engine results"): \(performance.observedDayCount) of \(performance.days.count) supplied date slots observed")
        Text("Coverage: \(performance.coverage); date basis: \(performance.dateBasis)").font(.caption)
        Text("Reported realized P&L is not asserted to be settlement-only, net after fees or verified live-only.").font(.caption)
        DisclosureGroup("Supplied daily results") {
            ForEach(Array(performance.days.enumerated()), id: \.offset) { _, day in
                VStack(alignment: .leading, spacing: 4) {
                    Text(day.dateSlot).font(.headline)
                    Text(day.isObserved ? "Reported day" : "No observation")
                    Text("Reported realized P&L: \(day.metrics.realized?.text ?? "no data")")
                    Text(day.metrics.countText)
                    if let observedAt = day.observedAt {
                        Text("Observed: \(PeopleCards.timeText(observedAt))").font(.caption)
                    }
                }
            }
        }
    }
}
