import Foundation
import CoreFoundation
import CryptoKit
import Combine

// Tuning inbox v1, the phone half (docs/contracts/tuning-inbox-v1.md). The phone is a presence device:
// it renders the exact frozen plan bytes, hashes them with CryptoKit and, only then, lets Face ID sign
// the decision bytes. Every parser here is bounded and fails closed; nothing the server claims about a
// plan is signed unless it was derived from the bytes this phone hashed.

enum TuningInboxLimits {
    /// Decoded plan bound (contract, Plan v1: total canonical plan size 256 KiB).
    static let maxPlanBytes = 262_144
    /// Single-id read: base64 plan (<= 349,528 bytes) plus bounded metadata.
    static let maxItemResponseBytes = 524_288
    /// List read: at most 50 summaries, which omit raw plan bytes.
    static let maxListResponseBytes = 131_072
    static let maxDecisionResponseBytes = 16_384
    /// Mobile decision route: request body 16 KiB, decoded assertion 8 KiB.
    static let maxDecisionBodyBytes = 16_384
    static let maxAssertionBytes = 8_192
    static let maxSafeInteger: Int64 = 9_007_199_254_740_991
    /// Mirrors leafhft.engine_registry.MAX_CONCURRENT_PROBES, the registry's own ceiling.
    static let maxProbeCap: Int64 = 1024
    /// runner_sync is stale past three planner intervals (contract, Clocks).
    static let runnerSyncStaleMs: Int64 = 180_000
    /// A sync stamp this far ahead of the phone clock is treated as unreadable, not fresh.
    static let runnerSyncFutureToleranceMs: Int64 = 60_000
    static let planLifetimeMs: Int64 = 86_400_000
    static let listPageSize = 20
    static let maxListPageSize = 50
}

/// Identifier grammar from the contract's "Encoding and identifiers". Byte checks, no regex.
enum TuningSyntax {
    static func isLowerHex(_ value: String, count: Int) -> Bool {
        let bytes = Array(value.utf8)
        return bytes.count == count && bytes.allSatisfy { (0x30...0x39).contains($0) || (0x61...0x66).contains($0) }
    }

    static func isSHA256(_ value: String) -> Bool { isLowerHex(value, count: 64) }
    static func isAccount(_ value: String) -> Bool { isLowerHex(value, count: 8) }
    static func isNonce(_ value: String) -> Bool { isLowerHex(value, count: 32) }
    static func isCodeSHA(_ value: String) -> Bool { isLowerHex(value, count: 40) }

    /// Canonical lowercase hyphenated UUID, 8-4-4-4-12.
    static func isUUID(_ value: String) -> Bool {
        let bytes = Array(value.utf8)
        guard bytes.count == 36 else { return false }
        for (index, byte) in bytes.enumerated() {
            if [8, 13, 18, 23].contains(index) {
                guard byte == 0x2D else { return false }
            } else if !((0x30...0x39).contains(byte) || (0x61...0x66).contains(byte)) {
                return false
            }
        }
        return true
    }

    /// `^ap-\d{8}(-h\d{2})?$`
    static func isCycleID(_ value: String) -> Bool {
        let bytes = Array(value.utf8)
        guard bytes.count == 11 || bytes.count == 15, bytes.starts(with: Array("ap-".utf8)) else { return false }
        func digits(_ range: Range<Int>) -> Bool { bytes[range].allSatisfy { (0x30...0x39).contains($0) } }
        guard digits(3..<11) else { return false }
        if bytes.count == 11 { return true }
        return bytes[11] == 0x2D && bytes[12] == 0x68 && digits(13..<15)
    }

    /// Engine ids, card and step request ids: `[A-Za-z0-9][A-Za-z0-9._:-]{0,127}`.
    static func isIdentifier(_ value: String) -> Bool {
        let bytes = Array(value.utf8)
        guard (1...128).contains(bytes.count) else { return false }
        func alnum(_ byte: UInt8) -> Bool {
            (0x30...0x39).contains(byte) || (0x41...0x5A).contains(byte) || (0x61...0x7A).contains(byte)
        }
        guard alnum(bytes[0]) else { return false }
        return bytes.dropFirst().allSatisfy { alnum($0) || $0 == 0x2E || $0 == 0x5F || $0 == 0x3A || $0 == 0x2D }
    }

    /// Printable ASCII (0x20...0x7E), bounded in bytes.
    static func isPrintable(_ value: String, maxBytes: Int, allowEmpty: Bool = false) -> Bool {
        let bytes = Array(value.utf8)
        guard bytes.count <= maxBytes, allowEmpty || !bytes.isEmpty else { return false }
        return bytes.allSatisfy { (0x20...0x7E).contains($0) }
    }

    /// Result and refusal codes are short snake case; anything else is shown as a generic refusal.
    static func isCode(_ value: String) -> Bool {
        let bytes = Array(value.utf8)
        return (1...64).contains(bytes.count) && bytes.allSatisfy { (0x61...0x7A).contains($0) || (0x30...0x39).contains($0) || $0 == 0x5F }
    }

    static func sha256Hex(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    /// Standard padded RFC 4648, verified by decode and re-encode, bounded before decoding.
    static func strictBase64(_ value: String, maxDecodedBytes: Int) -> Data? {
        guard value.utf8.count <= (maxDecodedBytes + 2) / 3 * 4,
              let data = Data(base64Encoded: value), data.count <= maxDecodedBytes,
              data.base64EncodedString() == value else { return nil }
        return data
    }

    static func milliseconds(_ date: Date) -> Int64 {
        Int64((date.timeIntervalSince1970 * 1000).rounded(.down))
    }
}

// MARK: - Canonical JSON

/// The contract's JSON domain: printable-ASCII strings, safe integers, booleans, null, arrays, objects.
indirect enum TuningJSON: Equatable {
    case null
    case bool(Bool)
    case int(Int64)
    case string(String)
    case array([TuningJSON])
    case object([String: TuningJSON])

    enum Failure: Error, Equatable { case tooLarge, notCanonical(Int), unsupported }

    /// Canonical bytes: `json.dumps(sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)`.
    /// Fails closed on anything outside the contract's domain instead of escaping it.
    func canonicalBytes() throws -> Data {
        var out: [UInt8] = []
        out.reserveCapacity(256)
        try write(into: &out, depth: 0)
        return Data(out)
    }

    private func write(into out: inout [UInt8], depth: Int) throws {
        guard depth <= TuningCanonicalParser.maxDepth else { throw Failure.unsupported }
        switch self {
        case .null: out.append(contentsOf: Array("null".utf8))
        case .bool(let value): out.append(contentsOf: Array((value ? "true" : "false").utf8))
        case .int(let value):
            guard value >= -TuningInboxLimits.maxSafeInteger, value <= TuningInboxLimits.maxSafeInteger else {
                throw Failure.unsupported
            }
            out.append(contentsOf: Array(String(value).utf8))
        case .string(let value): try Self.writeString(value, into: &out)
        case .array(let values):
            out.append(0x5B)
            for (index, value) in values.enumerated() {
                if index > 0 { out.append(0x2C) }
                try value.write(into: &out, depth: depth + 1)
            }
            out.append(0x5D)
        case .object(let map):
            out.append(0x7B)
            let keys = map.keys.sorted { $0.utf8.lexicographicallyPrecedes($1.utf8) }
            for (index, key) in keys.enumerated() {
                if index > 0 { out.append(0x2C) }
                try Self.writeString(key, into: &out)
                out.append(0x3A)
                try map[key]!.write(into: &out, depth: depth + 1)
            }
            out.append(0x7D)
        }
    }

    private static func writeString(_ value: String, into out: inout [UInt8]) throws {
        out.append(0x22)
        for byte in value.utf8 {
            guard (0x20...0x7E).contains(byte) else { throw Failure.unsupported }
            if byte == 0x22 || byte == 0x5C { out.append(0x5C) }
            out.append(byte)
        }
        out.append(0x22)
    }

    var objectValue: [String: TuningJSON]? { if case .object(let value) = self { return value }; return nil }
    var arrayValue: [TuningJSON]? { if case .array(let value) = self { return value }; return nil }
    var stringValue: String? { if case .string(let value) = self { return value }; return nil }
    var intValue: Int64? { if case .int(let value) = self { return value }; return nil }
    var boolValue: Bool? { if case .bool(let value) = self { return value }; return nil }
}

/// One-pass O(n) parser that accepts only the canonical form the runner freezes: no whitespace, keys
/// strictly ascending (so duplicates are refused), integers without sign games, fractions or exponents,
/// strings of printable ASCII with only `\"` and `\\` escapes. Rendering never reserializes the plan;
/// this parser proves the bytes it hashed are the bytes it shows.
struct TuningCanonicalParser {
    static let maxDepth = 16
    static let maxContainerCount = 4_096
    private let bytes: [UInt8]
    private var index = 0

    private init(bytes: [UInt8]) { self.bytes = bytes }

    static func parse(_ data: Data, maxBytes: Int) throws -> TuningJSON {
        guard data.count <= maxBytes else { throw TuningJSON.Failure.tooLarge }
        var parser = TuningCanonicalParser(bytes: [UInt8](data))
        let value = try parser.value(depth: 0)
        guard parser.index == parser.bytes.count else { throw TuningJSON.Failure.notCanonical(parser.index) }
        return value
    }

    private func fail() -> TuningJSON.Failure { .notCanonical(index) }

    private mutating func expect(_ byte: UInt8) throws {
        guard index < bytes.count, bytes[index] == byte else { throw fail() }
        index += 1
    }

    private mutating func value(depth: Int) throws -> TuningJSON {
        guard depth <= Self.maxDepth, index < bytes.count else { throw fail() }
        switch bytes[index] {
        case UInt8(ascii: "{"): return try object(depth: depth)
        case UInt8(ascii: "["): return try array(depth: depth)
        case UInt8(ascii: "\""): return .string(try string())
        case UInt8(ascii: "t"): try literal("true"); return .bool(true)
        case UInt8(ascii: "f"): try literal("false"); return .bool(false)
        case UInt8(ascii: "n"): try literal("null"); return .null
        case UInt8(ascii: "-"), UInt8(ascii: "0")...UInt8(ascii: "9"): return .int(try integer())
        default: throw fail()
        }
    }

    private mutating func literal(_ text: String) throws {
        for byte in text.utf8 { try expect(byte) }
    }

    private mutating func object(depth: Int) throws -> TuningJSON {
        try expect(UInt8(ascii: "{"))
        var map: [String: TuningJSON] = [:]
        if index < bytes.count, bytes[index] == UInt8(ascii: "}") {
            index += 1
            return .object(map)
        }
        var previous: String?
        while true {
            guard map.count < Self.maxContainerCount else { throw fail() }
            let key = try string()
            if let previous, !previous.utf8.lexicographicallyPrecedes(key.utf8) { throw fail() }
            try expect(UInt8(ascii: ":"))
            map[key] = try value(depth: depth + 1)
            previous = key
            guard index < bytes.count else { throw fail() }
            if bytes[index] == UInt8(ascii: ",") { index += 1; continue }
            try expect(UInt8(ascii: "}"))
            return .object(map)
        }
    }

    private mutating func array(depth: Int) throws -> TuningJSON {
        try expect(UInt8(ascii: "["))
        var values: [TuningJSON] = []
        if index < bytes.count, bytes[index] == UInt8(ascii: "]") {
            index += 1
            return .array(values)
        }
        while true {
            guard values.count < Self.maxContainerCount else { throw fail() }
            values.append(try value(depth: depth + 1))
            guard index < bytes.count else { throw fail() }
            if bytes[index] == UInt8(ascii: ",") { index += 1; continue }
            try expect(UInt8(ascii: "]"))
            return .array(values)
        }
    }

    private mutating func string() throws -> String {
        try expect(UInt8(ascii: "\""))
        var out: [UInt8] = []
        while index < bytes.count {
            let byte = bytes[index]
            index += 1
            if byte == UInt8(ascii: "\"") { return String(decoding: out, as: UTF8.self) }
            if byte == UInt8(ascii: "\\") {
                guard index < bytes.count, bytes[index] == UInt8(ascii: "\"") || bytes[index] == UInt8(ascii: "\\") else {
                    throw fail()
                }
                out.append(bytes[index])
                index += 1
                continue
            }
            guard (0x20...0x7E).contains(byte) else { throw fail() }
            out.append(byte)
        }
        throw fail()
    }

    private mutating func integer() throws -> Int64 {
        var negative = false
        if bytes[index] == UInt8(ascii: "-") {
            negative = true
            index += 1
        }
        let start = index
        while index < bytes.count, (UInt8(ascii: "0")...UInt8(ascii: "9")).contains(bytes[index]) { index += 1 }
        let digits = bytes[start..<index]
        guard !digits.isEmpty, digits.count <= 16 else { throw fail() }
        if digits.count > 1, digits.first == UInt8(ascii: "0") { throw fail() }
        if negative, digits.count == 1, digits.first == UInt8(ascii: "0") { throw fail() }
        if index < bytes.count, [UInt8(ascii: "."), UInt8(ascii: "e"), UInt8(ascii: "E")].contains(bytes[index]) {
            throw fail()
        }
        guard let magnitude = Int64(String(decoding: digits, as: UTF8.self)),
              magnitude <= TuningInboxLimits.maxSafeInteger else { throw fail() }
        return negative ? -magnitude : magnitude
    }
}

// MARK: - Plan v1

enum TuningPlanError: Error, Equatable {
    case base64
    case tooLarge
    case notCanonical
    case schema(String)
}

/// The decoded plan, restricted to what the phone renders and binds. The runner re-validates the full
/// closed grammar authoritatively (H1/H4); this parse refuses anything it cannot show faithfully.
struct TuningPlanDocument: Equatable {
    struct Engine: Equatable {
        let id: String
        let parent: String
        let settings: [(key: String, value: String)]
        let symbols: [String]
        let sizing: String
        let summary: String
        let novelty: String
        let hasActivation: Bool

        static func == (lhs: Engine, rhs: Engine) -> Bool {
            lhs.id == rhs.id && lhs.parent == rhs.parent && lhs.symbols == rhs.symbols && lhs.sizing == rhs.sizing
                && lhs.summary == rhs.summary && lhs.novelty == rhs.novelty && lhs.hasActivation == rhs.hasActivation
                && lhs.settings.map(\.key) == rhs.settings.map(\.key) && lhs.settings.map(\.value) == rhs.settings.map(\.value)
        }
    }

    struct Manifest: Equatable {
        let requestID: String
        let sha256: String
        let byteCount: Int
    }

    struct Step: Equatable {
        let stepID: String
        let op: String
        let argv: [String]
        let engineID: String?
        let requestID: String?
        let cardRequestID: String?
        let symbol: String?
        let unit: String?
        let configDigest: String?
        let ackSentence: String?
    }

    struct Gate: Equatable {
        let gate: String
        let verdict: String
        let generatedAtMs: Int64?
    }

    struct Waiver: Equatable {
        let waiverID: String
        let capTotal: Int64
    }

    struct Deferred: Equatable {
        let engineID: String
        let reason: String
    }

    static let schema = "leafhft.tuning-plan.v1"
    static let fields: Set<String> = [
        "schema", "proposal_id", "account", "registry_account", "cycle_id", "cycle_kind", "generated_at_ms",
        "plan_seq", "wave", "runner_host", "code_sha", "grid_sha256", "runner_nonce", "frozen_at_ms",
        "expires_at_ms", "engines", "manifests", "steps", "gates", "gate_waiver", "n_max_total", "deferred", "retire",
    ]
    static let cycleKinds: Set<String> = ["owner_daily", "owner_starve", "tenant_planned"]
    static let stepExtras: [String: Set<String>] = [
        "init": ["engine_id"],
        "try": ["engine_id"],
        "mint": ["request_id"],
        "probe": ["engine_id", "request_id", "card_request_id"],
        "restart": ["symbol", "unit", "config_digest", "ack_sentence"],
        "probe-activate": ["engine_id", "request_id"],
    ]

    let proposalID: String
    let account: String
    let registryAccount: String
    let cycleID: String
    let cycleKind: String
    let generatedAtMs: Int64
    let planSeq: Int64
    let wave: Int64
    let runnerHost: String
    let codeSHA: String
    let gridSHA256: String
    let runnerNonce: String
    let frozenAtMs: Int64
    let expiresAtMs: Int64
    let engines: [Engine]
    let manifests: [Manifest]
    let steps: [Step]
    let gates: [Gate]
    let gateWaiver: Waiver?
    let nMaxTotal: Int64
    let deferred: [Deferred]
    let retire: [String]

    var restartSteps: [Step] { steps.filter { $0.op == "restart" } }

    init(json: TuningJSON) throws {
        let top = try Fields(json, exactly: Self.fields, "plan")
        guard try top.string("schema") == Self.schema else { throw TuningPlanError.schema("schema") }
        proposalID = try top.string("proposal_id", TuningSyntax.isUUID)
        account = try top.string("account", TuningSyntax.isAccount)
        registryAccount = try top.string("registry_account") { $0 == "owner" || TuningSyntax.isIdentifier($0) }
        cycleID = try top.string("cycle_id", TuningSyntax.isCycleID)
        cycleKind = try top.string("cycle_kind") { Self.cycleKinds.contains($0) }
        generatedAtMs = try top.int("generated_at_ms", min: 0)
        planSeq = try top.int("plan_seq", min: 1)
        wave = try top.int("wave", min: 1)
        runnerHost = try top.string("runner_host") { value in
            guard let first = value.utf8.first, (1...64).contains(value.utf8.count),
                  (0x30...0x39).contains(first) || (0x41...0x5A).contains(first) || (0x61...0x7A).contains(first) else { return false }
            return value.utf8.allSatisfy { (0x30...0x39).contains($0) || (0x41...0x5A).contains($0) || (0x61...0x7A).contains($0) || $0 == 0x2E || $0 == 0x2D }
        }
        codeSHA = try top.string("code_sha", TuningSyntax.isCodeSHA)
        gridSHA256 = try top.string("grid_sha256", TuningSyntax.isSHA256)
        runnerNonce = try top.string("runner_nonce", TuningSyntax.isNonce)
        frozenAtMs = try top.int("frozen_at_ms", min: 0)
        expiresAtMs = try top.int("expires_at_ms", min: 0)
        guard expiresAtMs == frozenAtMs + TuningInboxLimits.planLifetimeMs else { throw TuningPlanError.schema("expires_at_ms") }
        nMaxTotal = try top.int("n_max_total", min: 0, max: TuningInboxLimits.maxProbeCap)

        let engineValues = try top.array("engines", count: 1...36)
        var engineIDs = Set<String>()
        engines = try engineValues.map { value in
            let engine = try Fields(value, exactly: ["id", "parent", "set", "symbols", "sizing", "summary", "novelty",
                                                     "request_ids", "activation"], "engine")
            let id = try engine.string("id", TuningSyntax.isIdentifier)
            guard engineIDs.insert(id).inserted else { throw TuningPlanError.schema("engine duplicate") }
            guard case .object(let set) = try engine.value("set"), set.count <= 64 else { throw TuningPlanError.schema("set") }
            let keys = set.keys.sorted { $0.utf8.lexicographicallyPrecedes($1.utf8) }
            let settings: [(key: String, value: String)] = try keys.map { key -> (key: String, value: String) in
                guard TuningSyntax.isPrintable(key, maxBytes: 128) else { throw TuningPlanError.schema("set key") }
                switch set[key]! {
                case .string(let text) where TuningSyntax.isPrintable(text, maxBytes: 300, allowEmpty: true): return (key, text)
                case .int(let number): return (key, String(number))
                case .bool(let flag): return (key, flag ? "true" : "false")
                default: throw TuningPlanError.schema("set value")
                }
            }
            let symbols = try engine.array("symbols", count: 1...36).map { value -> String in
                guard let symbol = value.stringValue, TuningSyntax.isIdentifier(symbol) else { throw TuningPlanError.schema("symbols") }
                return symbol
            }
            guard symbols == Array(Set(symbols)).sorted(by: { $0.utf8.lexicographicallyPrecedes($1.utf8) }) else {
                throw TuningPlanError.schema("symbols order")
            }
            let requestIDs = try Fields(try engine.value("request_ids"), exactly: ["probe", "activate"], "request_ids")
            _ = try requestIDs.string("probe", TuningSyntax.isIdentifier)
            _ = try requestIDs.string("activate", TuningSyntax.isIdentifier)
            let activation = try engine.value("activation")
            if activation != .null {
                let fields = try Fields(activation, exactly: ["bytes", "sha256"], "activation")
                let digest = try fields.string("sha256", TuningSyntax.isSHA256)
                guard let bytes = TuningSyntax.strictBase64(try fields.string("bytes"), maxDecodedBytes: 65_536),
                      TuningSyntax.sha256Hex(bytes) == digest else { throw TuningPlanError.schema("activation") }
            }
            return Engine(id: id, parent: try engine.string("parent", TuningSyntax.isIdentifier), settings: settings,
                          symbols: symbols,
                          sizing: try engine.string("sizing") { TuningSyntax.isPrintable($0, maxBytes: 32) },
                          summary: try engine.string("summary") { TuningSyntax.isPrintable($0, maxBytes: 300, allowEmpty: true) },
                          novelty: try engine.string("novelty") { TuningSyntax.isPrintable($0, maxBytes: 300, allowEmpty: true) },
                          hasActivation: activation != .null)
        }

        var manifestIDs = Set<String>()
        manifests = try top.array("manifests", count: 1...36).map { value in
            let manifest = try Fields(value, exactly: ["request_id", "bytes", "sha256"], "manifest")
            let requestID = try manifest.string("request_id", TuningSyntax.isIdentifier)
            guard manifestIDs.insert(requestID).inserted else { throw TuningPlanError.schema("manifest duplicate") }
            let digest = try manifest.string("sha256", TuningSyntax.isSHA256)
            guard let bytes = TuningSyntax.strictBase64(try manifest.string("bytes"), maxDecodedBytes: 65_536),
                  TuningSyntax.sha256Hex(bytes) == digest else { throw TuningPlanError.schema("manifest bytes") }
            return Manifest(requestID: requestID, sha256: digest, byteCount: bytes.count)
        }

        steps = try top.array("steps", count: 1...252).enumerated().map { offset, value in
            guard let map = value.objectValue, let op = map["op"]?.stringValue, let extras = Self.stepExtras[op] else {
                throw TuningPlanError.schema("step op")
            }
            let step = try Fields(value, exactly: extras.union(["step_id", "op", "argv"]), "step")
            guard try step.string("step_id") == String(format: "s%03d", offset + 1) else { throw TuningPlanError.schema("step_id") }
            let argv = try step.array("argv", count: 1...64).map { item -> String in
                guard let text = item.stringValue, TuningSyntax.isPrintable(text, maxBytes: 512) else {
                    throw TuningPlanError.schema("argv")
                }
                return text
            }
            func extra(_ key: String, _ valid: (String) -> Bool) throws -> String? {
                guard extras.contains(key) else { return nil }
                return try step.string(key, valid)
            }
            let configDigest = try extra("config_digest", TuningSyntax.isSHA256)
            let ackSentence = try extra("ack_sentence") { TuningSyntax.isPrintable($0, maxBytes: 300) }
            if let configDigest, let ackSentence,
               !ackSentence.hasPrefix("I authorize live trading with config " + configDigest) {
                throw TuningPlanError.schema("ack_sentence")
            }
            return Step(stepID: try step.string("step_id"), op: op, argv: argv,
                        engineID: try extra("engine_id", TuningSyntax.isIdentifier),
                        requestID: try extra("request_id", TuningSyntax.isIdentifier),
                        cardRequestID: try extra("card_request_id", TuningSyntax.isIdentifier),
                        symbol: try extra("symbol", TuningSyntax.isIdentifier),
                        unit: try extra("unit") { TuningSyntax.isPrintable($0, maxBytes: 128) },
                        configDigest: configDigest, ackSentence: ackSentence)
        }

        let gateValues = try top.array("gates", count: 0...3)
        gates = try gateValues.map { value in
            guard let map = value.objectValue, let gate = map["gate"]?.stringValue, let verdict = map["verdict"]?.stringValue,
                  TuningSyntax.isPrintable(gate, maxBytes: 16), TuningSyntax.isPrintable(verdict, maxBytes: 32) else {
                throw TuningPlanError.schema("gate")
            }
            return Gate(gate: gate, verdict: verdict, generatedAtMs: map["generated_at_ms"]?.intValue)
        }
        let waiver = try top.value("gate_waiver")
        if waiver == .null {
            gateWaiver = nil
            guard gates.count == 3 else { throw TuningPlanError.schema("gates") }
        } else {
            let fields = try Fields(waiver, exactly: ["waiver_id", "cap_total"], "gate_waiver")
            gateWaiver = Waiver(waiverID: try fields.string("waiver_id") { TuningSyntax.isPrintable($0, maxBytes: 128) },
                                capTotal: try fields.int("cap_total", min: 0, max: TuningInboxLimits.maxProbeCap))
            guard gates.isEmpty else { throw TuningPlanError.schema("gates") }
        }
        deferred = try top.array("deferred", count: 0...36).map { value in
            let row = try Fields(value, exactly: ["engine_id", "reason"], "deferred")
            return Deferred(engineID: try row.string("engine_id", TuningSyntax.isIdentifier),
                            reason: try row.string("reason") { TuningSyntax.isPrintable($0, maxBytes: 300, allowEmpty: true) })
        }
        retire = try top.array("retire", count: 0...36).map { value in
            guard let id = value.stringValue, TuningSyntax.isIdentifier(id) else { throw TuningPlanError.schema("retire") }
            return id
        }
        guard Set(retire).count == retire.count else { throw TuningPlanError.schema("retire duplicate") }
    }
}

/// Closed-object accessor used by the plan parser. Every miss is a named schema refusal.
private struct Fields {
    let map: [String: TuningJSON]
    let context: String

    init(_ value: TuningJSON, exactly keys: Set<String>, _ context: String) throws {
        guard let map = value.objectValue, Set(map.keys) == keys else { throw TuningPlanError.schema(context) }
        self.map = map
        self.context = context
    }

    func value(_ key: String) throws -> TuningJSON {
        guard let value = map[key] else { throw TuningPlanError.schema(context + "." + key) }
        return value
    }

    func string(_ key: String, _ valid: (String) -> Bool = { _ in true }) throws -> String {
        guard let text = try value(key).stringValue, valid(text) else { throw TuningPlanError.schema(context + "." + key) }
        return text
    }

    func int(_ key: String, min: Int64, max: Int64 = TuningInboxLimits.maxSafeInteger) throws -> Int64 {
        guard let number = try value(key).intValue, number >= min, number <= max else {
            throw TuningPlanError.schema(context + "." + key)
        }
        return number
    }

    func array(_ key: String, count: ClosedRange<Int>) throws -> [TuningJSON] {
        guard let values = try value(key).arrayValue, count.contains(values.count) else {
            throw TuningPlanError.schema(context + "." + key)
        }
        return values
    }
}

// MARK: - Plan v2 (offline authorization checks)

struct TuningPlanV2Error: Error, Equatable, LocalizedError, CustomStringConvertible {
    let code: String
    var errorDescription: String? { code }
    var description: String { code }
}

private func v2Require(_ condition: Bool, _ code: String = "invalid_plan") throws {
    if !condition { throw TuningPlanV2Error(code: code) }
}

private struct V2Fields {
    let map: [String: TuningJSON]
    init(_ value: TuningJSON, _ fields: String? = nil) throws {
        guard let map = value.objectValue else { throw TuningPlanV2Error(code: "invalid_plan") }
        if let fields {
            try v2Require(Set(map.keys) == Set(fields.split(separator: " ").map(String.init)))
        }
        self.map = map
    }
    subscript(_ key: String) -> TuningJSON { map[key] ?? .null }
    func string(_ key: String, _ valid: (String) -> Bool = { _ in true }) throws -> String {
        guard let value = self[key].stringValue, valid(value) else {
            throw TuningPlanV2Error(code: "invalid_plan")
        }
        return value
    }
    func int(_ key: String, low: Int64 = 0) throws -> Int64 {
        guard let value = self[key].intValue, (low...TuningInboxLimits.maxSafeInteger).contains(value) else {
            throw TuningPlanV2Error(code: "invalid_plan")
        }
        return value
    }
    func bool(_ key: String) throws -> Bool {
        guard let value = self[key].boolValue else { throw TuningPlanV2Error(code: "invalid_plan") }
        return value
    }
    func array(_ key: String, limit: Int) throws -> [TuningJSON] {
        guard let value = self[key].arrayValue else { throw TuningPlanV2Error(code: "invalid_plan") }
        try v2Require(value.count <= limit, "plan_too_large")
        return value
    }
}

/// Unlike v1, v2 accepts whitespace and key-order differences. Numbers are tokenized before
/// conversion; duplicate keys and unsafe numbers cannot disappear in Foundation bridging.
/// Policy fractional tokens are preserved as strings, including their exact decimal spelling.
struct TuningV2JSONParser {
    private let bytes: [UInt8]
    private let policy: Bool
    private var index = 0

    static func parse(_ data: Data, policy: Bool = false) throws -> TuningJSON {
        guard String(data: data, encoding: .utf8) != nil else {
            throw TuningPlanV2Error(code: "invalid_json")
        }
        var parser = TuningV2JSONParser(bytes: Array(data), policy: policy)
        let result = try parser.value(depth: 0)
        parser.whitespace()
        try v2Require(parser.index == parser.bytes.count, "invalid_json")
        return result
    }

    private mutating func whitespace() {
        while index < bytes.count, [UInt8(9), 10, 13, 32].contains(bytes[index]) { index += 1 }
    }
    private mutating func expect(_ byte: UInt8) throws {
        whitespace()
        try v2Require(index < bytes.count && bytes[index] == byte, "invalid_json")
        index += 1
    }
    private mutating func literal(_ text: String) throws {
        for byte in text.utf8 {
            try v2Require(index < bytes.count && bytes[index] == byte, "invalid_json")
            index += 1
        }
    }
    private mutating func value(depth: Int) throws -> TuningJSON {
        try v2Require(depth <= 64)
        whitespace()
        try v2Require(index < bytes.count, "invalid_json")
        switch bytes[index] {
        case 123:
            index += 1
            whitespace()
            var map: [String: TuningJSON] = [:]
            if index < bytes.count, bytes[index] == 125 { index += 1; return .object(map) }
            while true {
                let key = try string()
                try v2Require(map[key] == nil, "invalid_json")
                try expect(58)
                map[key] = try value(depth: depth + 1)
                whitespace()
                try v2Require(index < bytes.count, "invalid_json")
                if bytes[index] == 44 { index += 1; continue }
                try expect(125)
                return .object(map)
            }
        case 91:
            index += 1
            whitespace()
            var list: [TuningJSON] = []
            if index < bytes.count, bytes[index] == 93 { index += 1; return .array(list) }
            while true {
                list.append(try value(depth: depth + 1))
                whitespace()
                try v2Require(index < bytes.count, "invalid_json")
                if bytes[index] == 44 { index += 1; continue }
                try expect(93)
                return .array(list)
            }
        case 34: return .string(try string())
        case 116: try literal("true"); return .bool(true)
        case 102: try literal("false"); return .bool(false)
        case 110: try literal("null"); return .null
        case 45, 48...57: return try number()
        default: throw TuningPlanV2Error(code: "invalid_json")
        }
    }
    private mutating func string() throws -> String {
        whitespace()
        try expect(34)
        var output: [UInt8] = []
        var nonASCII = false
        while index < bytes.count {
            let byte = bytes[index]
            index += 1
            if byte == 92 {
                try v2Require(index < bytes.count, "invalid_json")
                let escape = bytes[index]
                index += 1
                switch escape {
                case 34, 47, 92: output.append(escape)
                case 98: output.append(8)
                case 102: output.append(12)
                case 110: output.append(10)
                case 114: output.append(13)
                case 116: output.append(9)
                case 117:
                    var scalar: UInt32 = 0
                    for _ in 0..<4 {
                        try v2Require(index < bytes.count, "invalid_json")
                        let digit = bytes[index]
                        index += 1
                        let nibble: UInt32
                        switch digit {
                        case 48...57: nibble = UInt32(digit - 48)
                        case 65...70: nibble = UInt32(digit - 65 + 10)
                        case 97...102: nibble = UInt32(digit - 97 + 10)
                        default: throw TuningPlanV2Error(code: "invalid_json")
                        }
                        scalar = scalar * 16 + nibble
                    }
                    if scalar <= 127 { output.append(UInt8(scalar)) } else { nonASCII = true }
                default: throw TuningPlanV2Error(code: "invalid_json")
                }
            } else if byte == 34 {
                try v2Require(!nonASCII && output.allSatisfy { (32...126).contains($0) })
                return String(decoding: output, as: UTF8.self)
            } else {
                try v2Require(byte >= 32, "invalid_json")
                output.append(byte)
            }
        }
        throw TuningPlanV2Error(code: "invalid_json")
    }
    private mutating func number() throws -> TuningJSON {
        let start = index
        while index < bytes.count, ![UInt8(9), 10, 13, 32, 44, 93, 125].contains(bytes[index]) { index += 1 }
        let token = String(decoding: bytes[start..<index], as: UTF8.self)
        let pattern = #"^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$"#
        try v2Require(token.range(of: pattern, options: .regularExpression) != nil, "invalid_json")
        if token.contains(".") || token.contains("e") || token.contains("E") {
            try v2Require(policy, "invalid_json")
            return .string(token)
        }
        guard let number = Int64(token), number >= -TuningInboxLimits.maxSafeInteger,
              number <= TuningInboxLimits.maxSafeInteger else {
            throw TuningPlanV2Error(code: "invalid_plan")
        }
        return .int(number)
    }
}

/// V2's canonical digest domain has a 64-level bound, independent of the v1 parser's bound.
enum TuningV2Canonical {
    static func bytes(_ json: TuningJSON) throws -> Data {
        var output = Data()
        try append(json, into: &output, depth: 0)
        return output
    }
    private static func append(_ json: TuningJSON, into output: inout Data, depth: Int) throws {
        try v2Require(depth <= 64)
        switch json {
        case .object(let map):
            output.append(123)
            for (index, key) in map.keys.sorted().enumerated() {
                if index > 0 { output.append(44) }
                try v2Require(TuningSyntax.isPrintable(key, maxBytes: Int.max, allowEmpty: true))
                output.append(try TuningJSON.string(key).canonicalBytes())
                output.append(58)
                try append(map[key]!, into: &output, depth: depth + 1)
            }
            output.append(125)
        case .array(let values):
            output.append(91)
            for (index, value) in values.enumerated() {
                if index > 0 { output.append(44) }
                try append(value, into: &output, depth: depth + 1)
            }
            output.append(93)
        default:
            do { output.append(try json.canonicalBytes()) }
            catch { throw TuningPlanV2Error(code: "invalid_plan") }
        }
    }
}

enum TuningV2Sizing {
    static let fractionFields = ["daily_loss_fraction", "per_order_fraction", "cluster_fraction",
                                 "drawdown_brake_fraction", "drawdown_stop_fraction"]
    static let moneyFields = ["cash_floor_cents", "per_book_stake_cents",
                              "reversal_max_open_cents", "reversal_budget_cents"]

    static func decimal(_ value: TuningJSON, fraction: Bool = false) throws -> Decimal {
        guard let text = value.stringValue, TuningSyntax.isPrintable(text, maxBytes: 24),
              text.range(of: #"^(0|[1-9][0-9]*)(\.[0-9]{1,6})?$"#, options: .regularExpression) != nil,
              let number = Decimal(string: text, locale: Locale(identifier: "en_US_POSIX")) else {
            throw TuningPlanV2Error(code: "invalid_plan")
        }
        try v2Require(!fraction || number <= 1)
        return number
    }
    static func validateEnvelope(_ json: TuningJSON) throws {
        let doc = try V2Fields(json, (["schema"] + fractionFields + moneyFields).joined(separator: " "))
        try v2Require(try doc.string("schema") == "leafhft.account-envelope.v1")
        for field in fractionFields { _ = try decimal(doc[field], fraction: true) }
        for field in moneyFields { _ = try doc.int(field) }
        try v2Require(try decimal(doc["drawdown_brake_fraction"]) <= decimal(doc["drawdown_stop_fraction"]))
    }
    static func validateBasis(_ json: TuningJSON) throws {
        let basis = try V2Fields(json, "free_balance_cents day_open_cents observed_at_ms")
        for field in basis.map.keys { _ = try basis.int(field) }
    }
    private static func policySizing(_ json: TuningJSON) throws -> (order: Decimal, loss: Decimal, stake: Int64?) {
        _ = try TuningV2Canonical.bytes(json)
        let policy = try V2Fields(json)
        let order = try decimal(policy.map["per_order_fraction"] ?? .string("0.10"), fraction: true)
        let loss = try decimal(policy.map["daily_loss_fraction"] ?? .string("0.15"), fraction: true)
        func decimalScalar(_ json: TuningJSON) throws -> Decimal {
            if let value = json.intValue { return try decimal(.string(String(value))) }
            return try decimal(json)
        }
        if let fixed = policy.map["fixed_count"], fixed != .null {
            try v2Require(try decimalScalar(fixed) == 0)
        }
        var stake: Int64?
        if let value = policy.map["stake_ceiling_usd"] {
            let cents = try decimalScalar(value) * 100
            let rounded = floorDecimal(cents)
            try v2Require(cents == rounded && cents <= Decimal(TuningInboxLimits.maxSafeInteger))
            stake = NSDecimalNumber(decimal: rounded).int64Value
        }
        return (order, loss, stake)
    }
    private static func floorDecimal(_ value: Decimal) -> Decimal {
        var input = value
        var result = Decimal()
        NSDecimalRound(&result, &input, 0, .down)
        return result
    }
    static func floorCents(_ value: Decimal) -> Int64 {
        NSDecimalNumber(decimal: floorDecimal(value)).int64Value
    }
    static func newSCents(resolvedPolicy: TuningJSON, envelope: TuningJSON, leverage: Int64,
                          sizingBasis: TuningJSON) throws -> Int64 {
        try validateEnvelope(envelope)
        try validateBasis(sizingBasis)
        try v2Require(TuningPlanV2.leverages.contains(leverage))
        let policy = try policySizing(resolvedPolicy)
        let doc = try V2Fields(envelope)
        let basis = try V2Fields(sizingBasis)
        // Inputs have at most 6 fractional places and 16 integer digits; Decimal's 38 digits
        // represent every intermediate exactly. The only division is terminating (/250).
        return try floorCents(min(policy.loss, decimal(doc["daily_loss_fraction"])) *
                              Decimal(leverage) * Decimal(basis.int("free_balance_cents")) / 250)
    }
    static func maxEntryCents(resolvedPolicy: TuningJSON, envelope: TuningJSON, newSCents: Int64,
                              sizingBasis: TuningJSON) throws -> Int64 {
        try validateEnvelope(envelope)
        try validateBasis(sizingBasis)
        try v2Require((0...TuningInboxLimits.maxSafeInteger).contains(newSCents))
        let policy = try policySizing(resolvedPolicy)
        let doc = try V2Fields(envelope)
        let balance = try Decimal(V2Fields(sizingBasis).int("free_balance_cents"))
        var terms = [floorCents(balance * policy.order),
                     try floorCents(balance * decimal(doc["per_order_fraction"])),
                     try doc.int("per_book_stake_cents"), newSCents]
        if let stake = policy.stake { terms.append(stake) }
        return max(0, terms.min()!)
    }
    static func policyBytes(_ encoded: TuningJSON, digest: TuningJSON) throws -> TuningJSON {
        guard let sha = digest.stringValue, TuningSyntax.isSHA256(sha), let text = encoded.stringValue else {
            throw TuningPlanV2Error(code: "invalid_plan")
        }
        try v2Require(text.utf8.count <= (65_536 + 2) / 3 * 4, "plan_too_large")
        guard let data = Data(base64Encoded: text) else { throw TuningPlanV2Error(code: "create_policy_mismatch") }
        try v2Require(data.count <= 65_536, "plan_too_large")
        try v2Require(data.base64EncodedString() == text && TuningSyntax.sha256Hex(data) == sha,
                      "create_policy_mismatch")
        do {
            let json = try TuningV2JSONParser.parse(data, policy: true)
            _ = try policySizing(json)
            return json
        } catch { throw TuningPlanV2Error(code: "create_policy_mismatch") }
    }
}

struct TuningPlanV2: Equatable {
    static let schema = "leafhft.tuning-plan.v2"
    static let leverages: Set<Int64> = [1, 5, 20, 50, 100, 250]
    static let books: Set<String> = ["BTC-15M", "ETH-15M", "BTC-1H", "ETH-1H", "BNB-15M", "DOGE-15M",
                                   "HYPE-15M", "NEAR-15M", "SOL-15M", "XRP-15M", "ZEC-15M", "BNB-1H",
                                   "HYPE-1H", "XRP-1H"]
    static let cycleKinds: Set<String> = ["deployment_change", "migration"]
    let json: TuningJSON
    let effects: [TuningJSON]
    var fields: [String: TuningJSON] { json.objectValue! }
    var proposalID: String { fields["proposal_id"]!.stringValue! }
    var account: String { fields["account"]!.stringValue! }
    var cycleID: String { fields["cycle_id"]!.stringValue! }
    var cycleKind: String { fields["cycle_kind"]!.stringValue! }
    var planSeq: Int64 { fields["plan_seq"]!.intValue! }
    var runnerNonce: String { fields["runner_nonce"]!.stringValue! }
    var runnerHost: String { fields["runner_host"]!.stringValue! }
    var codeSHA: String { fields["code_sha"]!.stringValue! }
    var frozenAtMs: Int64 { fields["frozen_at_ms"]!.intValue! }
    var expiresAtMs: Int64 { fields["expires_at_ms"]!.intValue! }
    var origin: String { fields["origin"]!.stringValue! }
    var envelopeDocument: TuningJSON { fields["envelope"]!.objectValue!["document"]! }
    var sizingBasis: TuningJSON { fields["sizing_basis"]! }
    var migration: TuningJSON? { fields["migration"] == .null ? nil : fields["migration"] }
    var items: [TuningJSON] { fields["items"]!.arrayValue! }

    static func isCycleID(_ value: String, kind: String) -> Bool {
        let prefix = kind == "deployment_change" ? "dc-" : "mg-"
        return cycleKinds.contains(kind) && value.hasPrefix(prefix) &&
            TuningSyntax.isLowerHex(String(value.dropFirst(3)), count: 16)
    }
    static func decode(_ bytes: Data) throws -> TuningPlanV2 {
        try v2Require(bytes.count <= TuningInboxLimits.maxPlanBytes, "plan_too_large")
        let json = try TuningV2JSONParser.parse(bytes)
        try v2Require(try TuningV2Canonical.bytes(json).count <= TuningInboxLimits.maxPlanBytes, "plan_too_large")
        let effects = try computeEffects(json)
        let plan = try V2Fields(json)
        let claimed = try plan.array("effects", limit: 1088)
        try v2Require(.array(claimed) == TuningJSON.array(effects), "effects_mismatch")
        try v2Require(effects.contains { ["raises", "sizing_law"].contains($0.objectValue!["effect"]!.stringValue!) },
                      "approval_not_required")
        return TuningPlanV2(json: json, effects: effects)
    }
    private static func uniqueSorted(_ keys: [[String]]) throws {
        try v2Require(Set(keys).count == keys.count, "duplicate_transition")
        try v2Require(keys == keys.sorted { $0.lexicographicallyPrecedes($1) })
    }
    private static func state(_ row: TuningJSON?, paused: Bool, off: Bool) -> [String: TuningJSON] {
        let row = row?.objectValue
        let on = row?["on"]?.boolValue ?? false
        return ["entering": .bool(row != nil && on && !paused && !off),
                "leverage": row?["leverage"] ?? .null, "on": .bool(on),
                "paused": .bool(paused), "book_off": .bool(off)]
    }

    /// Structural checks and evidence arithmetic deliberately ignore the claimed effects.
    static func computeEffects(_ json: TuningJSON) throws -> [TuningJSON] {
        _ = try TuningV2Canonical.bytes(json)
        let plan = try V2Fields(json, "schema proposal_id account registry_account plan_seq runner_host code_sha runner_nonce frozen_at_ms expires_at_ms cycle_kind cycle_id change_sha256 origin kind expected_generation resulting_generation baseline controls items catalog envelope sizing_basis migration effects tuner_evidence")
        try v2Require(try plan.string("schema") == schema)
        _ = try plan.string("proposal_id", TuningSyntax.isUUID)
        _ = try plan.string("account", TuningSyntax.isAccount)
        let registry = try plan.string("registry_account", TuningSyntax.isIdentifier)
        try v2Require(registry == "owner", "tenant_v2_deferred")
        _ = try plan.int("plan_seq", low: 1)
        _ = try plan.string("runner_host") {
            $0.range(of: #"^[A-Za-z0-9][A-Za-z0-9.-]{0,63}$"#, options: .regularExpression) != nil
        }
        _ = try plan.string("code_sha", TuningSyntax.isCodeSHA)
        _ = try plan.string("runner_nonce", TuningSyntax.isNonce)
        _ = try plan.string("change_sha256", TuningSyntax.isSHA256)
        let frozen = try plan.int("frozen_at_ms")
        try v2Require(try plan.int("expires_at_ms") == frozen + TuningInboxLimits.planLifetimeMs)
        let generation = try plan.int("expected_generation")
        try v2Require(try plan.int("resulting_generation") == generation + 1)
        let kind = try plan.string("kind") { ["change", "migration"].contains($0) }
        let origin = try plan.string("origin") { ["operator", "tuner"].contains($0) }
        let cycleKind = try plan.string("cycle_kind")
        try v2Require(cycleKind == (kind == "change" ? "deployment_change" : "migration"))
        _ = try plan.string("cycle_id") { isCycleID($0, kind: cycleKind) }
        try TuningV2Sizing.validateBasis(plan["sizing_basis"])
        let basis = try V2Fields(plan["sizing_basis"])
        let observed = try basis.int("observed_at_ms")
        try v2Require(frozen - 900_000 <= observed && observed <= frozen, "sizing_basis_stale")
        let envelope = try V2Fields(plan["envelope"], "version digest document")
        try v2Require(try envelope.int("version") == 1)
        let digest = try envelope.string("digest", TuningSyntax.isSHA256)
        try TuningV2Sizing.validateEnvelope(envelope["document"])
        try v2Require(try TuningSyntax.sha256Hex(TuningV2Canonical.bytes(envelope["document"])) == digest,
                      "envelope_mismatch")
        let baseline = try V2Fields(plan["baseline"], "paused books rows")
        let pausedBefore = try baseline.bool("paused")
        let bookValues = try baseline.array("books", limit: 14)
        let rowValues = try baseline.array("rows", limit: 1024)
        let controls = try plan.array("controls", limit: 15)
        let items = try plan.array("items", limit: 64)
        let catalogValues = try plan.array("catalog", limit: 1088)
        var off: [String: Bool] = [:]
        var bookKeys: [[String]] = []
        for value in bookValues {
            let book = try V2Fields(value, "book book_off")
            let id = try book.string("book") { books.contains($0) }
            off[id] = try book.bool("book_off")
            bookKeys.append([id])
        }
        try uniqueSorted(bookKeys)
        var catalog: [String: String] = [:]
        var catalogKeys: [[String]] = []
        for value in catalogValues {
            let row = try V2Fields(value, "engine engine_policy_digest")
            let engine = try row.string("engine", TuningSyntax.isIdentifier)
            catalog[engine] = try row.string("engine_policy_digest", TuningSyntax.isSHA256)
            catalogKeys.append([engine])
        }
        try uniqueSorted(catalogKeys)
        var usedCatalog: Set<String> = []
        var rows: [[String]: TuningJSON] = [:]
        var rowKeys: [[String]] = []
        for value in rowValues {
            let row = try V2Fields(value, "book engine engine_policy_digest leverage on")
            let book = try row.string("book") { books.contains($0) }
            let engine = try row.string("engine", TuningSyntax.isIdentifier)
            let sha = try row.string("engine_policy_digest", TuningSyntax.isSHA256)
            try v2Require(try leverages.contains(row.int("leverage")))
            _ = try row.bool("on")
            try v2Require(off[book] != nil && catalog[engine] != nil, "dangling_reference")
            try v2Require(sha == catalog[engine], "immutable_engine")
            usedCatalog.insert(engine)
            rows[[book, engine]] = value
            rowKeys.append([book, engine])
        }
        try uniqueSorted(rowKeys)
        var pausedAfter = pausedBefore
        var afterOff = off
        var touched: Set<String> = []
        var accountControl = false
        var controlKeys: [[String]] = []
        for value in controls {
            let control = try V2Fields(value, "kind scope book field from to")
            try v2Require(try control.string("kind") == "control")
            let from = try control.bool("from")
            let to = try control.bool("to")
            let scope = try control.string("scope")
            let field = try control.string("field")
            var book = ""
            if scope == "account" {
                try v2Require(control["book"] == .null && field == "paused")
                try v2Require(from == pausedBefore, "baseline_mismatch")
                pausedAfter = to
                accountControl = true
            } else {
                try v2Require(scope == "book" && field == "book_off")
                book = try control.string("book") { books.contains($0) }
                try v2Require(off[book] != nil, "dangling_reference")
                try v2Require(from == off[book], "baseline_mismatch")
                afterOff[book] = to
                touched.insert(book)
            }
            controlKeys.append([scope, book, field])
        }
        try uniqueSorted(controlKeys)
        var creates: [String: String] = [:]
        var final = rows
        var itemKeys: [[String]] = []
        var deployKeys: [[String]] = []
        for value in items {
            let item = try V2Fields(value)
            let itemKind = try item.string("kind")
            if itemKind == "create" {
                _ = try V2Fields(value, "kind engine parent parent_policy_digest policy_bytes policy_digest set summary")
                let engine = try item.string("engine") { $0.count <= 32 && TuningSyntax.isIdentifier($0) }
                let parent = try item.string("parent", TuningSyntax.isIdentifier)
                let parentDigest = try item.string("parent_policy_digest", TuningSyntax.isSHA256)
                try v2Require(creates[engine] == nil, "duplicate_transition")
                try v2Require(catalog[engine] == nil, "immutable_engine")
                try v2Require(catalog[parent] != nil, "dangling_reference")
                try v2Require(parentDigest == catalog[parent], "immutable_engine")
                _ = try item.string("summary") { (1...300).contains($0.count) }
                let settings = try V2Fields(item["set"])
                for (key, setting) in settings.map {
                    try v2Require(key.range(of: #"^[A-Za-z_][A-Za-z0-9_]{0,127}$"#,
                                            options: .regularExpression) != nil)
                    switch setting { case .string, .int, .bool: break; default: try v2Require(false) }
                }
                _ = try TuningV2Sizing.policyBytes(item["policy_bytes"], digest: item["policy_digest"])
                creates[engine] = try item.string("policy_digest", TuningSyntax.isSHA256)
                usedCatalog.insert(parent)
                itemKeys.append(["0", engine, ""])
            } else {
                try v2Require(itemKind == "deploy")
                _ = try V2Fields(value, "kind book engine engine_policy_digest from to")
                let book = try item.string("book") { books.contains($0) }
                let engine = try item.string("engine", TuningSyntax.isIdentifier)
                let sha = try item.string("engine_policy_digest", TuningSyntax.isSHA256)
                try v2Require(off[book] != nil, "dangling_reference")
                let to = try V2Fields(item["to"], "leverage on")
                try v2Require(try leverages.contains(to.int("leverage")))
                _ = try to.bool("on")
                let key = [book, engine]
                let old = rows[key]?.objectValue
                if item["from"] != .null {
                    let from = try V2Fields(item["from"], "leverage on")
                    try v2Require(try leverages.contains(from.int("leverage")))
                    _ = try from.bool("on")
                }
                let expectedFrom: TuningJSON = old.map { .object(["leverage": $0["leverage"]!, "on": $0["on"]!]) } ?? .null
                try v2Require(item["from"] == expectedFrom, "baseline_mismatch")
                try v2Require(creates[engine] != nil || catalog[engine] != nil, "dangling_reference")
                try v2Require(sha == (creates[engine] ?? catalog[engine]), "immutable_engine")
                if catalog[engine] != nil { usedCatalog.insert(engine) }
                var new = to.map
                new["engine_policy_digest"] = .string(sha)
                final[key] = .object(new)
                touched.insert(book)
                deployKeys.append(key)
                itemKeys.append(["1", book, engine])
            }
        }
        try uniqueSorted(itemKeys)
        try uniqueSorted(deployKeys)
        try v2Require(usedCatalog == Set(catalog.keys), "dangling_reference")
        let migrationRows = try validateMigration(plan, rows: rows, final: final, catalog: catalog)
        if plan["migration"] != .null {
            touched.insert(try V2Fields(plan["migration"]).string("book"))
        }
        try v2Require(accountControl || touched == Set(off.keys), "baseline_mismatch")
        try v2Require(!controls.isEmpty || !items.isEmpty || plan["migration"] != .null)
        var computed: [TuningJSON] = creates.keys.sorted().map {
            .object(["book": .string(""), "engine": .string($0), "effect": .string("raises"),
                     "before": .null, "after": .object(["engine_policy_digest": .string(creates[$0]!)])])
        }
        for key in final.keys.sorted(by: { $0.lexicographicallyPrecedes($1) }) {
            let book = key[0], engine = key[1]
            let old = rows[key]
            let new = final[key]!
            var before = state(old, paused: pausedBefore, off: off[book]!)
            var after = state(new, paused: pausedAfter, off: afterOff[book]!)
            let raise = old == nil || creates[engine] != nil ||
                new.objectValue!["engine_policy_digest"] != old?.objectValue?["engine_policy_digest"] ||
                (after["leverage"]!.intValue! > (before["leverage"]!.intValue ?? 0)) ||
                (after["entering"] == .bool(true) && before["entering"] == .bool(false))
            let lower = (before["entering"] == .bool(true) && after["entering"] == .bool(false)) ||
                (old != nil && after["leverage"]!.intValue! < before["leverage"]!.intValue!)
            var effect = raise ? "raises" : lower ? "lowers" : "neutral"
            if let row = migrationRows[engine] {
                if !raise { effect = "sizing_law" }
                before["sizing_law"] = .string("legacy")
                for field in ["today_contracts", "today_cents_at_median_fill", "window_start_ms", "window_end_ms"] {
                    before[field] = row[field]
                }
                after["sizing_law"] = .string("cells-v3")
                after["new_S_cents"] = row["new_S_cents"]
                after["new_per_entry_cap_cents"] = row["new_per_entry_cap_cents"]
            }
            computed.append(.object(["book": .string(book), "engine": .string(engine), "effect": .string(effect),
                                     "before": .object(before), "after": .object(after)]))
        }
        let evidence = try plan.array("tuner_evidence", limit: 1088)
        var evidenceKeys: [[String]] = []
        for value in evidence {
            let receipt = try V2Fields(value, "book engine leverage receipt_sha256")
            let book = try receipt.string("book") { books.contains($0) }
            let engine = try receipt.string("engine", TuningSyntax.isIdentifier)
            let leverage = try receipt.int("leverage")
            try v2Require(leverages.contains(leverage))
            _ = try receipt.string("receipt_sha256", TuningSyntax.isSHA256)
            evidenceKeys.append([book, engine, String(format: "%03lld", leverage)])
        }
        try uniqueSorted(evidenceKeys)
        var needed: Set<[String]> = []
        if origin == "tuner" {
            for value in computed {
                let effect = value.objectValue!
                let book = effect["book"]!.stringValue!
                if !book.isEmpty, effect["effect"] == .string("raises"),
                   let leverage = effect["after"]!.objectValue!["leverage"]?.intValue, leverage > 1 {
                    needed.insert([book, effect["engine"]!.stringValue!, String(format: "%03lld", leverage)])
                }
            }
        }
        try v2Require(Set(evidenceKeys) == needed, "tuner_evidence_required")
        return computed
    }

    private static func validateMigration(_ plan: V2Fields, rows: [[String]: TuningJSON],
                                          final: [[String]: TuningJSON], catalog: [String: String])
        throws -> [String: [String: TuningJSON]] {
        if plan["kind"] == .string("change") {
            try v2Require(plan["migration"] == .null)
            return [:]
        }
        let migration = try V2Fields(plan["migration"], "book law_from law_to rows policies source_digest generation small_rows_today_slice_cents small_rows_sum_S_cents small_rows_exceed_slice book_sum_S_cents rounding")
        let book = try migration.string("book") { books.contains($0) }
        try v2Require(migration["law_from"] == .string("legacy") && migration["law_to"] == .string("cells-v3"))
        try v2Require(migration["rounding"] == .string("ceil_to_cent"))
        _ = try migration.string("source_digest", TuningSyntax.isSHA256)
        try v2Require(try migration.int("generation") == plan.int("expected_generation"), "migration_mismatch")
        let baseline = try V2Fields(plan["baseline"])
        let baselineBooks = try baseline.array("books", limit: 14).map { $0.objectValue!["book"]!.stringValue! }
        try v2Require(baselineBooks == [book], "migration_mismatch")
        let rowValues = try migration.array("rows", limit: 1024)
        let policyValues = try migration.array("policies", limit: 1024)
        var policies: [String: TuningJSON] = [:]
        var policyKeys: [[String]] = []
        for value in policyValues {
            let policy = try V2Fields(value, "engine policy_bytes policy_digest")
            let engine = try policy.string("engine", TuningSyntax.isIdentifier)
            try v2Require(catalog[engine] != nil, "dangling_reference")
            try v2Require(policy["policy_digest"] == catalog[engine].map(TuningJSON.string), "immutable_engine")
            policies[engine] = try TuningV2Sizing.policyBytes(policy["policy_bytes"], digest: policy["policy_digest"])
            policyKeys.append([engine])
        }
        try uniqueSorted(policyKeys)
        for value in try plan.array("items", limit: 64) {
            let item = try V2Fields(value)
            try v2Require(item["kind"] == .string("deploy"), "migration_mismatch")
            let key = [try item.string("book"), try item.string("engine")]
            try v2Require(rows[key] != nil, "migration_mismatch")
        }
        var result: [String: [String: TuningJSON]] = [:]
        var keys: [[String]] = []
        // Decimal sums avoid Int64 overflow before checking the safe signed-money range.
        var total: Decimal = 0
        var smallTotal: Decimal = 0
        let envelope = try V2Fields(plan["envelope"])["document"]
        for value in rowValues {
            let row = try V2Fields(value, "engine leverage_before leverage_after today_contracts today_cents_at_median_fill new_per_entry_cap_cents new_S_cents small role window_start_ms window_end_ms")
            let engine = try row.string("engine", TuningSyntax.isIdentifier)
            let before = try row.int("leverage_before")
            let after = try row.int("leverage_after")
            try v2Require(leverages.contains(before) && leverages.contains(after))
            _ = try TuningV2Sizing.decimal(row["today_contracts"])
            let small = try row.bool("small")
            let role = try row.string("role") { ["probe", "other"].contains($0) }
            try v2Require(small == (role == "probe"), "migration_mismatch")
            for field in ["today_cents_at_median_fill", "new_per_entry_cap_cents", "new_S_cents",
                          "window_start_ms", "window_end_ms"] { _ = try row.int(field) }
            let start = try row.int("window_start_ms")
            let end = try row.int("window_end_ms")
            try v2Require(try start < end && end <= plan.int("frozen_at_ms"), "migration_mismatch")
            let key = [book, engine]
            try v2Require(rows[key] != nil && policies[engine] != nil, "dangling_reference")
            try v2Require(rows[key]!.objectValue!["leverage"] == .int(before) &&
                          final[key]!.objectValue!["leverage"] == .int(after), "migration_mismatch")
            let stake = try TuningV2Sizing.newSCents(resolvedPolicy: policies[engine]!, envelope: envelope,
                                                    leverage: after, sizingBasis: plan["sizing_basis"])
            let cap = try TuningV2Sizing.maxEntryCents(resolvedPolicy: policies[engine]!, envelope: envelope,
                                                      newSCents: stake, sizingBasis: plan["sizing_basis"])
            try v2Require(row["new_S_cents"] == .int(stake) && row["new_per_entry_cap_cents"] == .int(cap),
                          "migration_mismatch")
            total += Decimal(stake)
            if small { smallTotal += Decimal(stake) }
            result[engine] = row.map
            keys.append([engine])
        }
        try uniqueSorted(keys)
        try v2Require(!keys.isEmpty && Set(result.keys) == Set(policies.keys) &&
                      Set(result.keys) == Set(rows.keys.map { $0[1] }), "migration_mismatch")
        let dayOpen = try V2Fields(plan["sizing_basis"]).int("day_open_cents")
        let slice = TuningV2Sizing.floorCents(min(5000, Decimal(string: "0.045")! * Decimal(dayOpen)))
        try v2Require(try migration.int("small_rows_today_slice_cents") == slice &&
                      Decimal(migration.int("small_rows_sum_S_cents")) == smallTotal &&
                      Decimal(migration.int("book_sum_S_cents")) == total, "migration_mismatch")
        try v2Require(try migration.bool("small_rows_exceed_slice") == (smallTotal > Decimal(slice)),
                      "migration_mismatch")
        return result
    }
}

/// Plain words built exclusively from the validated document and its recomputed effects.
struct TuningV2Review {
    enum EffectRank: Int, CaseIterable {
        case raises, sizingLaw, lowers, neutral
        init(effect: String) {
            switch effect {
            case "raises": self = .raises
            case "sizing_law": self = .sizingLaw
            case "lowers": self = .lowers
            default: self = .neutral
            }
        }
        var label: String {
            switch self {
            case .raises: return "Raises risk"
            case .sizingLaw: return "Sizing changes"
            case .lowers: return "Lowers risk"
            case .neutral: return "No risk change"
            }
        }
    }
    struct Row: Identifiable, Equatable {
        let book: String
        let engine: String
        let sentence: String
        let finalState: String
        let effectRank: EffectRank
        var id: String { book + "/" + engine }
    }
    let plan: TuningPlanV2

    static func displayOrder(_ rows: [Row]) -> [Row] {
        rows.sorted {
            if $0.effectRank != $1.effectRank { return $0.effectRank.rawValue < $1.effectRank.rawValue }
            if $0.book != $1.book { return $0.book < $1.book }
            return $0.engine < $1.engine
        }
    }
    var displayRows: [Row] { Self.displayOrder(rows) }
    var raisedRowCount: Int { rows.filter { $0.effectRank == .raises }.count }
    var riskSummary: String { Self.riskSummary(raisedRowCount: raisedRowCount) }
    static func riskSummary(raisedRowCount: Int) -> String {
        raisedRowCount == 0 ? "No change raises risk" : "\(raisedRowCount) change(s) raise risk"
    }

    var rows: [Row] {
        let creates = Dictionary(uniqueKeysWithValues: plan.items.compactMap { value -> (String, String)? in
            let item = value.objectValue!
            guard item["kind"] == .string("create") else { return nil }
            return (item["engine"]!.stringValue!, item["parent"]!.stringValue!)
        })
        return plan.effects.compactMap { value in
            let effect = value.objectValue!
            let book = effect["book"]!.stringValue!
            let engine = effect["engine"]!.stringValue!
            let tuner = plan.origin == "tuner" && effect["effect"] == .string("raises") ? "Tuner raise: " : ""
            if book.isEmpty {
                return Row(book: book, engine: engine, sentence: tuner + "new engine from " + creates[engine]!,
                           finalState: "Creates this policy; deployment is reviewed separately.", effectRank: .raises)
            }
            let before = effect["before"]!.objectValue!
            let after = effect["after"]!.objectValue!
            guard before != after else { return nil }
            let old = before["leverage"]!.intValue
            let leverage = after["leverage"]!.intValue!
            let entering = after["entering"] == .bool(true)
            var words: [String] = []
            if let parent = creates[engine] { words.append("new engine from " + parent) }
            if let old, leverage > old {
                words.append("raises \(old)x to \(leverage)x" +
                             (entering ? "" : " while off; it trades at \(leverage)x when turned on"))
            } else if old == nil {
                words.append(entering ? "turns ON at \(leverage)x" :
                             "starts at \(leverage)x while off; it trades at \(leverage)x when turned on")
            } else {
                if let old, leverage < old { words.append("lowers \(old)x to \(leverage)x") }
                if before["entering"] == .bool(false) && entering {
                    words.append("turns ON at \(leverage)x")
                } else if before["entering"] == .bool(true) && !entering {
                    words.append("turns OFF")
                } else if before["on"] != after["on"] {
                    words.append(after["on"] == .bool(true) ? "switches ON at \(leverage)x" : "turns OFF")
                }
            }
            if after["sizing_law"] == .string("cells-v3") { words.append("changes sizing from legacy to cells-v3") }
            if words.isEmpty { words.append("changes the trading controls") }
            var reasons: [String] = []
            if after["on"] == .bool(false) { reasons.append("engine switched off") }
            if after["paused"] == .bool(true) { reasons.append("account paused") }
            if after["book_off"] == .bool(true) { reasons.append("book switched off") }
            let final = entering ? "Final state: trading at \(leverage)x." :
                "Final state: off (\(reasons.joined(separator: ", "))); selected leverage \(leverage)x."
            return Row(book: book, engine: engine, sentence: tuner + words.joined(separator: "; "),
                       finalState: final, effectRank: EffectRank(effect: effect["effect"]!.stringValue!))
        }
    }

    var controlSentences: [String] {
        plan.fields["controls"]!.arrayValue!.map { value in
            let control = value.objectValue!
            let to = control["to"] == .bool(true)
            if control["scope"] == .string("account") { return to ? "Pause the account." : "Resume the account." }
            let book = control["book"]!.stringValue!
            return to ? "Switch \(book) off." : "Switch \(book) on."
        }
    }

    static func dollars(_ cents: Int64) -> String {
        "$\(cents / 100)." + String(format: "%02lld", cents % 100)
    }
    static func percent(_ fraction: TuningJSON) -> String {
        // The caller passes validated decimal strings. No binary floating-point conversion.
        let number = Decimal(string: fraction.stringValue!, locale: Locale(identifier: "en_US_POSIX"))! * 100
        return NSDecimalNumber(decimal: number).stringValue + "%"
    }
    static func fractionAtBalance(_ fraction: TuningJSON, balanceCents: Int64) -> String {
        let value = Decimal(string: fraction.stringValue!, locale: Locale(identifier: "en_US_POSIX"))!
        return percent(fraction) + " · " + dollars(TuningV2Sizing.floorCents(value * Decimal(balanceCents))) + " of B"
    }
}

/// Common decision identity; v1-specific projections remain available to existing v1 callers.
/// The review switches on the actual schema and never synthesizes v1 cards for a v2 plan.
enum TuningReviewedDocument: Equatable {
    case v1(TuningPlanDocument)
    case v2(TuningPlanV2)
    var legacy: TuningPlanDocument? { if case .v1(let value) = self { return value }; return nil }
    var v2Plan: TuningPlanV2? { if case .v2(let value) = self { return value }; return nil }
    var proposalID: String { legacy?.proposalID ?? v2Plan!.proposalID }
    var account: String { legacy?.account ?? v2Plan!.account }
    var cycleID: String { legacy?.cycleID ?? v2Plan!.cycleID }
    var cycleKind: String { legacy?.cycleKind ?? v2Plan!.cycleKind }
    var planSeq: Int64 { legacy?.planSeq ?? v2Plan!.planSeq }
    var runnerNonce: String { legacy?.runnerNonce ?? v2Plan!.runnerNonce }
    var runnerHost: String { legacy?.runnerHost ?? v2Plan!.runnerHost }
    var codeSHA: String { legacy?.codeSHA ?? v2Plan!.codeSHA }
    var frozenAtMs: Int64 { legacy?.frozenAtMs ?? v2Plan!.frozenAtMs }
    var expiresAtMs: Int64 { legacy?.expiresAtMs ?? v2Plan!.expiresAtMs }
    var engines: [TuningPlanDocument.Engine] { legacy?.engines ?? [] }
    var steps: [TuningPlanDocument.Step] { legacy?.steps ?? [] }
    var restartSteps: [TuningPlanDocument.Step] { legacy?.restartSteps ?? [] }
    var gateWaiver: TuningPlanDocument.Waiver? { legacy?.gateWaiver }
    var nMaxTotal: Int64 { legacy?.nMaxTotal ?? 0 }
    var retire: [String] { legacy?.retire ?? [] }
}

/// Exact frozen plan bytes, their locally computed SHA-256 and the decoded document. plan_sha256 is
/// computed with CryptoKit over the decoded bytes; the server's value is only compared, never trusted.
struct VerifiedTuningPlan: Equatable {
    let bytes: Data
    let sha256: String
    let advertisedSHA256: String
    let document: TuningReviewedDocument

    var hashMatches: Bool { sha256 == advertisedSHA256 }

    static func verify(planB64: String, advertisedSHA256: String) throws -> VerifiedTuningPlan {
        let maxEncodedBytes = (TuningInboxLimits.maxPlanBytes + 2) / 3 * 4
        let encodedCount = planB64.utf8.prefix(maxEncodedBytes + 1).count
        guard encodedCount <= maxEncodedBytes else { throw TuningPlanError.tooLarge }
        // The final quartet can encode one, two or three bytes at the same encoded length.
        let padding = planB64.utf8.reversed().prefix(2).prefix(while: { $0 == 0x3D }).count
        let decodedUpperBound = (encodedCount + 3) / 4 * 3 - padding
        guard decodedUpperBound <= TuningInboxLimits.maxPlanBytes else { throw TuningPlanError.tooLarge }
        guard let bytes = TuningSyntax.strictBase64(planB64, maxDecodedBytes: TuningInboxLimits.maxPlanBytes) else {
            throw TuningPlanError.base64
        }
        return try verify(bytes: bytes, advertisedSHA256: advertisedSHA256)
    }

    static func verify(bytes: Data, advertisedSHA256: String) throws -> VerifiedTuningPlan {
        guard bytes.count <= TuningInboxLimits.maxPlanBytes else { throw TuningPlanError.tooLarge }
        // This probe only selects a reader. It never supplies fields for rendering or signing.
        // The selected v2 reader independently rejects duplicates, numbers and malformed trees.
        let schemaProbe = (try? JSONSerialization.jsonObject(with: bytes)) as? [String: Any]
        if schemaProbe?["schema"] as? String == TuningPlanV2.schema {
            let document = try TuningPlanV2.decode(bytes)
            return VerifiedTuningPlan(bytes: bytes, sha256: TuningSyntax.sha256Hex(bytes),
                                      advertisedSHA256: advertisedSHA256, document: .v2(document))
        }
        let json: TuningJSON
        do { json = try TuningCanonicalParser.parse(bytes, maxBytes: TuningInboxLimits.maxPlanBytes) }
        catch { throw TuningPlanError.notCanonical }
        let document = try TuningPlanDocument(json: json)
        return VerifiedTuningPlan(bytes: bytes, sha256: TuningSyntax.sha256Hex(bytes),
                                  advertisedSHA256: advertisedSHA256, document: .v1(document))
    }
}

// MARK: - Wire types (mobile tuning inbox route)

enum TuningInboxState: Equatable {
    case proposed, planning, ready, accepted, executing, waitingWindow, held
    case executed, rejected, superseded, revoked, expired, planRefused, failed
    case approved, applying, live
    case unknown(String)

    init(wire: String) {
        switch wire {
        case "proposed": self = .proposed
        case "planning": self = .planning
        case "ready": self = .ready
        case "accepted": self = .accepted
        case "executing": self = .executing
        case "waiting_window": self = .waitingWindow
        case "held": self = .held
        case "executed": self = .executed
        case "rejected": self = .rejected
        case "superseded": self = .superseded
        case "revoked": self = .revoked
        case "expired": self = .expired
        case "plan_refused": self = .planRefused
        case "failed": self = .failed
        case "approved": self = .approved
        case "applying": self = .applying
        case "live": self = .live
        default: self = .unknown(TuningSyntax.isCode(wire) ? wire : "unreadable")
        }
    }

    var label: String {
        switch self {
        case .proposed: return "Proposed"
        case .planning: return "Planning"
        case .ready: return "Ready for your decision"
        case .accepted: return "Accepted"
        case .executing: return "Placing"
        case .waitingWindow: return "Waiting for a restart window"
        case .held: return "Held"
        case .executed: return "Placed"
        case .rejected: return "Rejected"
        case .superseded: return "Superseded"
        case .revoked: return "Revoked"
        case .expired: return "Expired"
        case .planRefused: return "Plan refused"
        case .failed: return "Failed"
        case .approved: return "Approved, waiting"
        case .applying: return "Applied, waiting for the book to confirm"
        case .live: return "Live"
        case .unknown(let wire): return "Unknown state (\(wire))"
        }
    }

    var isTerminal: Bool {
        switch self {
        case .executed, .live, .rejected, .superseded, .revoked, .expired, .planRefused, .failed: return true
        default: return false
        }
    }
}

struct TuningInboxSummary: Equatable, Identifiable {
    let id: String
    let account: String
    let cycleID: String
    let cycleKind: String
    let state: TuningInboxState
    let version: Int64
    let generatedAtMs: Int64
    let planSeq: Int64?
    let resultCode: String?

    var isV2: Bool { TuningPlanV2.cycleKinds.contains(cycleKind) }
    var isOwner: Bool { cycleKind.hasPrefix("owner_") || isV2 }
    var stateLabel: String {
        guard isV2 else { return state.label }
        switch state {
        case .accepted, .approved: return "Approved, waiting"
        case .executing, .executed, .applying, .live: return "Applied, waiting for the book to confirm"
        default: return state.label
        }
    }
}

struct TuningPlanEnvelope: Equatable {
    let planSeq: Int64
    let planB64: String
    let planSHA256: String
}

struct TuningInboxDetail: Equatable {
    let summary: TuningInboxSummary
    let plan: TuningPlanEnvelope?
    let runnerSyncAtMs: Int64?
}

struct TuningInboxPage: Equatable {
    let items: [TuningInboxSummary]
    let nextCursor: String?
    var pending: TuningInboxPending = .init()
}

struct TuningInboxPending: Decodable, Equatable {
    var count: Int = 0
    var newest: KashbotLiveAttributes.Approval? = nil

    init() {}

    private enum CodingKeys: String, CodingKey { case count, newest }
    private enum NewestKeys: String, CodingKey { case account, proposalId, planSeq, planSha256 }

    init(from decoder: Decoder) throws {
        guard let values = try? decoder.container(keyedBy: CodingKeys.self) else { return }
        if let value = try? values.decode(Int.self, forKey: .count), value >= 0 { count = value }
        guard let item = try? values.nestedContainer(keyedBy: NewestKeys.self, forKey: .newest),
              let account = try? item.decode(String.self, forKey: .account), TuningSyntax.isAccount(account),
              let id = try? item.decode(String.self, forKey: .proposalId), TuningSyntax.isUUID(id),
              let seq = try? item.decode(Int64.self, forKey: .planSeq), seq >= 1,
              let hash = try? item.decode(String.self, forKey: .planSha256), TuningSyntax.isSHA256(hash) else { return }
        newest = .init(account: account, proposalId: id, planSeq: seq, planSha256: hash)
    }
}

/// Shared by list screens and live-board refreshes. No stale count survives ten minutes.
@MainActor final class TuningPendingCache {
    static let shared = TuningPendingCache()
    private var latest: (pending: TuningInboxPending, at: Date)?
    private var inFlight: Task<Void, Never>?
    private var listInFlight: Task<TuningInboxPage, Error>?

    func list(client: TuningInboxClient) async throws -> TuningInboxPage {
        if let listInFlight { return try await listInFlight.value }
        let task = Task { try await client.listUncached(cursor: nil) }
        listInFlight = task
        defer { listInFlight = nil }
        return try await task.value
    }

    func record(_ pending: TuningInboxPending, now: Date = Date()) { latest = (pending, now) }

    func pending(fixtureMode: FixtureMode, now: Date) async -> TuningInboxPending? {
        guard !fixtureMode.enabled else { return nil }
        if let latest, (0..<600).contains(now.timeIntervalSince(latest.at)) { return latest.pending }
        if inFlight == nil {
            inFlight = Task {
                _ = try? await TuningInboxClient(fixtureMode: fixtureMode).list(cursor: nil)
            }
        }
        await inFlight?.value
        inFlight = nil
        guard let latest, (0..<600).contains(Date().timeIntervalSince(latest.at)) else { return nil }
        return latest.pending
    }
}

/// Decodable mirrors of the mobile route's JSON (snake case). Validation turns them into the models above.
struct TuningInboxWire {
    struct Summary: Decodable {
        let id: String
        let account: String
        let cycleId: String
        let cycleKind: String
        let state: String
        let version: Int64
        let generatedAtMs: Int64
        let planSeq: Int64?
        let resultCode: String?

        func validated() throws -> TuningInboxSummary {
            let cycleValid = TuningPlanDocument.cycleKinds.contains(cycleKind)
                ? TuningSyntax.isCycleID(cycleId) : TuningPlanV2.isCycleID(cycleId, kind: cycleKind)
            guard TuningSyntax.isUUID(id), TuningSyntax.isAccount(account), cycleValid,
                  (0...TuningInboxLimits.maxSafeInteger).contains(version),
                  (0...TuningInboxLimits.maxSafeInteger).contains(generatedAtMs),
                  planSeq.map({ (1...TuningInboxLimits.maxSafeInteger).contains($0) }) ?? true,
                  resultCode.map(TuningSyntax.isCode) ?? true else { throw DashboardClientError.decoding }
            return TuningInboxSummary(id: id, account: account, cycleID: cycleId, cycleKind: cycleKind,
                                      state: TuningInboxState(wire: state), version: version,
                                      generatedAtMs: generatedAtMs, planSeq: planSeq, resultCode: resultCode)
        }
    }

    struct Plan: Decodable {
        let planSeq: Int64
        let planB64: String
        let planSha256: String
    }

    struct Item: Decodable {
        let id: String
        let account: String
        let cycleId: String
        let cycleKind: String
        let state: String
        let version: Int64
        let generatedAtMs: Int64
        let planSeq: Int64?
        let resultCode: String?
        let plan: Plan?
        let runnerSyncAtMs: Int64?

        func validated() throws -> TuningInboxDetail {
            let summary = try Summary(id: id, account: account, cycleId: cycleId, cycleKind: cycleKind, state: state,
                                      version: version, generatedAtMs: generatedAtMs, planSeq: planSeq,
                                      resultCode: resultCode).validated()
            var envelope: TuningPlanEnvelope?
            if let plan {
                guard (1...TuningInboxLimits.maxSafeInteger).contains(plan.planSeq), TuningSyntax.isSHA256(plan.planSha256),
                      plan.planB64.utf8.count <= (TuningInboxLimits.maxPlanBytes + 2) / 3 * 4 else {
                    throw DashboardClientError.decoding
                }
                envelope = TuningPlanEnvelope(planSeq: plan.planSeq, planB64: plan.planB64, planSHA256: plan.planSha256)
            }
            if let runnerSyncAtMs, !(0...TuningInboxLimits.maxSafeInteger).contains(runnerSyncAtMs) {
                throw DashboardClientError.decoding
            }
            return TuningInboxDetail(summary: summary, plan: envelope, runnerSyncAtMs: runnerSyncAtMs)
        }
    }

    struct ListResponse: Decodable {
        let success: Bool
        let items: [Summary]
        let nextCursor: String?
        let pending: TuningInboxPending

        private enum CodingKeys: String, CodingKey { case success, items, nextCursor, pending }

        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            success = try values.decode(Bool.self, forKey: .success)
            items = try values.decode([Summary].self, forKey: .items)
            nextCursor = try values.decodeIfPresent(String.self, forKey: .nextCursor)
            pending = (try? values.decode(TuningInboxPending.self, forKey: .pending)) ?? .init()
        }
    }

    struct ItemResponse: Decodable {
        let success: Bool
        let item: Item
    }

    struct DecisionResponse: Decodable {
        let success: Bool
        let code: String?
        let state: String?
    }
}

// MARK: - Accept gating

/// Accept is enabled only when every reason is absent. Pure, so each condition has a test.
struct TuningAcceptGate: Equatable {
    enum Reason: String, CaseIterable {
        case planUnavailable
        case hashMismatch
        case bindingMismatch
        case notRendered
        case notReady
        case planExpired
        case runnerNotSyncing
        case outcomeUnknown
        case fixtureWithoutControlWalk
        case submitInFlight
        case alreadyDecided

        var message: String {
            switch self {
            case .planUnavailable: return "The frozen plan has not loaded."
            case .hashMismatch: return "The plan bytes do not match their advertised hash. Do not accept."
            case .bindingMismatch: return "The plan does not belong to this inbox item. Do not accept."
            case .notRendered: return "Review the plan below before accepting."
            case .notReady: return "This item is not ready for a decision."
            case .planExpired: return "This plan has expired. The runner will freeze a new one."
            case .runnerNotSyncing: return "The runner has not synced in the last 3 minutes."
            case .outcomeUnknown: return "The last Accept may have reached Kashbot. Tap Retry to confirm it."
            case .fixtureWithoutControlWalk: return "Decisions are disabled in demo mode."
            case .submitInFlight: return "Sending your decision."
            case .alreadyDecided: return "Your decision was recorded."
            }
        }
    }

    let reasons: [Reason]
    var enabled: Bool { reasons.isEmpty }
    var message: String? { reasons.first?.message }

    static func evaluate(detail: TuningInboxDetail?, plan: VerifiedTuningPlan?, renderedSHA256: String?, nowMs: Int64,
                         phase: TuningSubmitPhase, fixtureMode: FixtureMode) -> TuningAcceptGate {
        var reasons: [Reason] = []
        if let plan, let detail, let envelope = detail.plan {
            if !plan.hashMatches || plan.advertisedSHA256 != envelope.planSHA256 { reasons.append(.hashMismatch) }
            let document = plan.document
            if document.proposalID != detail.summary.id || document.account != detail.summary.account
                || document.planSeq != envelope.planSeq || document.cycleID != detail.summary.cycleID
                || document.cycleKind != detail.summary.cycleKind
                || (detail.summary.planSeq.map { $0 != document.planSeq } ?? false) {
                reasons.append(.bindingMismatch)
            }
            if renderedSHA256 != plan.sha256 { reasons.append(.notRendered) }
            if nowMs >= document.expiresAtMs { reasons.append(.planExpired) }
        } else {
            reasons.append(.planUnavailable)
        }
        if detail?.summary.state != .ready { reasons.append(.notReady) }
        if !runnerSyncing(detail?.runnerSyncAtMs, nowMs: nowMs) { reasons.append(.runnerNotSyncing) }
        switch phase {
        case .outcomeUnknown: reasons.append(.outcomeUnknown)
        case .signing, .submitting: reasons.append(.submitInFlight)
        case .accepted: reasons.append(.alreadyDecided)
        case .idle, .failed: break
        }
        if fixtureMode.enabled && !fixtureMode.controlWalk { reasons.append(.fixtureWithoutControlWalk) }
        return TuningAcceptGate(reasons: reasons)
    }

    static func runnerSyncing(_ at: Int64?, nowMs: Int64) -> Bool {
        guard let at else { return false }
        return nowMs - at <= TuningInboxLimits.runnerSyncStaleMs && at - nowMs <= TuningInboxLimits.runnerSyncFutureToleranceMs
    }
}

enum TuningSubmitPhase: Equatable {
    case idle
    case signing
    case submitting
    case accepted(code: String)
    /// A definite answer that recorded nothing. Retry reloads the item; a new Accept needs a new Face ID.
    case failed(message: String)
    /// The request may have reached Kashbot. Retry replays the identical request id and bytes.
    case outcomeUnknown(message: String)

    var showsRetry: Bool {
        switch self {
        case .failed, .outcomeUnknown: return true
        default: return false
        }
    }
}

// MARK: - Routing from notifications

struct TuningInboxTarget: Hashable, Identifiable {
    let proposalID: String
    let category: String
    let planSeq: Int64?
    let planSHA256: String?
    private(set) var account: String? = nil
    var id: String { proposalID }

    /// Only a well-formed proposal id opens an item. The payload carries no authority.
    init?(proposalID: String?, category: String) {
        guard let proposalID else { return nil }
        self.init(userInfo: ["proposal_id": proposalID], category: category)
    }

    init?(userInfo: [AnyHashable: Any], category: String) {
        let proposalID = userInfo["proposal_id"] as? String
        guard let proposalID, TuningSyntax.isUUID(proposalID) else { return nil }
        self.proposalID = proposalID
        self.category = category
        if let number = userInfo["plan_seq"] as? NSNumber,
           CFGetTypeID(number) != CFBooleanGetTypeID(), number.doubleValue.isFinite, number.int64Value >= 1,
           number.decimalValue == Decimal(number.int64Value) {
            planSeq = number.int64Value
        } else {
            planSeq = nil
        }
        if let hash = userInfo["plan_sha256"] as? String, TuningSyntax.isSHA256(hash) {
            planSHA256 = hash
        } else {
            planSHA256 = nil
        }
    }

    func planChanged(fetchedSeq: Int64, fetchedSHA256: String) -> Bool {
        guard let planSeq, let planSHA256 else { return false }
        return planSeq != fetchedSeq || planSHA256 != fetchedSHA256
    }

    func accountMismatch(fetchedAccount: String) -> Bool {
        account.map { $0 != fetchedAccount } ?? false
    }

    static func reviewURL(_ url: URL) -> TuningInboxTarget? {
        guard let parts = URLComponents(url: url, resolvingAgainstBaseURL: false),
              parts.scheme == "leafhft", parts.host == "tuning", parts.path == "/review",
              parts.user == nil, parts.password == nil, parts.port == nil, parts.fragment == nil,
              let items = parts.queryItems, items.count == 4,
              Set(items.map(\.name)) == Set(["account", "proposal_id", "plan_seq", "plan_sha256"]) else { return nil }
        let values = items.reduce(into: [String: String]()) { if let value = $1.value { $0[$1.name] = value } }
        guard let account = values["account"], TuningSyntax.isAccount(account),
              let id = values["proposal_id"], TuningSyntax.isUUID(id),
              let rawSeq = values["plan_seq"], !rawSeq.isEmpty,
              rawSeq.utf8.allSatisfy({ (0x30...0x39).contains($0) }),
              let seq = Int64(rawSeq), seq >= 1,
              let hash = values["plan_sha256"], TuningSyntax.isSHA256(hash),
              var target = TuningInboxTarget(userInfo: ["proposal_id": id, "plan_seq": NSNumber(value: seq),
                                                       "plan_sha256": hash], category: "tuning") else { return nil }
        target.account = account
        return target
    }
}

/// Hands a notification's target to whichever Autopilot screen is showing. Opening is all it does.
@MainActor final class TuningInboxRouter: ObservableObject {
    static let shared = TuningInboxRouter()
    @Published var target: TuningInboxTarget?
    @Published private(set) var openCount = 0

    func open(_ target: TuningInboxTarget?) {
        self.target = target
        openCount += 1
    }

    func consume() -> TuningInboxTarget? {
        defer { target = nil }
        return target
    }
}

// MARK: - Unknown-outcome ledger

/// Keeps a request whose outcome is unknown for the life of the process, so reopening the item cannot
/// re-enable Accept and mint a second signed request beside one that may already have landed.
@MainActor final class TuningSubmissionLedger {
    static let shared = TuningSubmissionLedger()
    static let capacity = 64
    private var pending: [String: TuningDecisionRequest] = [:]
    private var order: [String] = []

    private static func key(_ proposalID: String, _ planSeq: Int64) -> String { proposalID + "#" + String(planSeq) }

    func record(_ request: TuningDecisionRequest) {
        let key = Self.key(request.proposalID, request.planSeq)
        if pending.updateValue(request, forKey: key) == nil { order.append(key) }
        while order.count > Self.capacity { pending.removeValue(forKey: order.removeFirst()) }
    }

    func unresolved(proposalID: String, planSeq: Int64) -> TuningDecisionRequest? {
        pending[Self.key(proposalID, planSeq)]
    }

    func unresolved(proposalID: String) -> [TuningDecisionRequest] {
        pending.values.filter { $0.proposalID == proposalID }
    }

    func resolve(proposalID: String, planSeq: Int64) {
        let key = Self.key(proposalID, planSeq)
        pending.removeValue(forKey: key)
        order.removeAll { $0 == key }
    }
}

// MARK: - Item model

/// One inbox item: load and verify the frozen bytes, gate Accept, sign with Face ID, submit once.
/// There is no timer and no automatic resubmission anywhere in this type.
@MainActor final class TuningInboxItemModel: ObservableObject {
    @Published private(set) var detail: TuningInboxDetail?
    @Published private(set) var plan: VerifiedTuningPlan?
    @Published private(set) var planError: String?
    @Published private(set) var loadError: String?
    @Published private(set) var loading = false
    @Published private(set) var phase: TuningSubmitPhase = .idle
    @Published private(set) var renderedSHA256: String?
    @Published private(set) var submitCount = 0

    let proposalID: String
    private let fixtureMode: FixtureMode
    private let transport: TuningInboxTransport
    private let signingKey: () throws -> DecisionSigningKey?
    private let now: () -> Date
    private let ledger: TuningSubmissionLedger
    private var pending: TuningDecisionRequest?

    init(proposalID: String, fixtureMode: FixtureMode, transport: TuningInboxTransport,
         signingKey: @escaping () throws -> DecisionSigningKey?, now: @escaping () -> Date = Date.init,
         ledger: TuningSubmissionLedger? = nil) {
        self.proposalID = proposalID
        self.fixtureMode = fixtureMode
        self.transport = transport
        self.signingKey = signingKey
        self.now = now
        self.ledger = ledger ?? .shared
    }

    var gate: TuningAcceptGate {
        TuningAcceptGate.evaluate(detail: detail, plan: plan, renderedSHA256: renderedSHA256,
                                  nowMs: TuningSyntax.milliseconds(now()), phase: phase, fixtureMode: fixtureMode)
    }

    /// Fetches the exact frozen bytes and hashes them. Never submits anything.
    func load() async {
        guard TuningSyntax.isUUID(proposalID) else {
            loadError = "This inbox link is not valid."
            return
        }
        guard !loading else { return }
        loading = true
        defer { loading = false }
        loadError = nil
        do {
            let fetched = try await transport.item(id: proposalID)
            guard fetched.summary.id == proposalID else { throw DashboardClientError.decoding }
            apply(fetched)
        } catch {
            if !(error is CancellationError) { loadError = Self.loadMessage(error) }
        }
    }

    private func apply(_ fetched: TuningInboxDetail) {
        if fetched.plan?.planSHA256 != detail?.plan?.planSHA256 || fetched.plan?.planB64 != detail?.plan?.planB64 {
            renderedSHA256 = nil
        }
        detail = fetched
        planError = nil
        plan = nil
        if let envelope = fetched.plan {
            do { plan = try VerifiedTuningPlan.verify(planB64: envelope.planB64, advertisedSHA256: envelope.planSHA256) }
            catch { planError = Self.planMessage(error) }
        }
        reconcileUnresolved(with: fetched)
    }

    /// A replan or a state change settles an unknown outcome; while the same plan is still ready it stays unknown.
    private func reconcileUnresolved(with fetched: TuningInboxDetail) {
        let unresolved = ledger.unresolved(proposalID: proposalID)
        for request in unresolved where fetched.summary.state != .ready || fetched.plan?.planSeq != request.planSeq {
            ledger.resolve(proposalID: request.proposalID, planSeq: request.planSeq)
            if pending == request {
                pending = nil
                if case .outcomeUnknown = phase { phase = .idle }
            }
        }
        if let planSeq = fetched.plan?.planSeq, fetched.summary.state == .ready,
           let request = ledger.unresolved(proposalID: proposalID, planSeq: planSeq) {
            pending = request
            if case .outcomeUnknown = phase {} else {
                phase = .outcomeUnknown(message: TuningAcceptGate.Reason.outcomeUnknown.message)
            }
        }
    }

    /// Called by the plan view once it has drawn the verified document on screen.
    func markRendered(sha256: String) {
        guard let plan, plan.sha256 == sha256 else { return }
        renderedSHA256 = sha256
    }

    /// One tap, one Face ID prompt, one request. Refuses unless every gate condition holds.
    func accept() async {
        guard gate.enabled, case .idle = phase, let plan, let detail, let envelope = detail.plan else { return }
        phase = .signing
        if fixtureMode.enabled {
            // controlWalk only (the gate refuses plain fixture mode): no key, no network, a local sample result.
            phase = .accepted(code: "fixture_sample")
            return
        }
        let key: DecisionSigningKey
        do {
            guard let loaded = try signingKey() else {
                phase = .failed(message: "Create this phone's presence key in Presence key before accepting.")
                return
            }
            key = loaded
        } catch {
            phase = .failed(message: DecisionSigner.message(for: error))
            return
        }
        let signed: SignedTuningAssertion
        do {
            let reason = "Accept tuning plan \(plan.document.cycleID) for account \(plan.document.account)"
            signed = try await DecisionSigner(key: key).signAccept(plan: plan, issuedAtMs: TuningSyntax.milliseconds(now()),
                                                                    reason: reason)
        } catch {
            phase = .failed(message: DecisionSigner.message(for: error))
            return
        }
        // Face ID can take a while; the plan must still be live when the request leaves the phone.
        guard TuningSyntax.milliseconds(now()) < plan.document.expiresAtMs else {
            phase = .failed(message: TuningAcceptGate.Reason.planExpired.message)
            return
        }
        let request: TuningDecisionRequest
        do {
            request = try TuningDecisionRequest.accept(requestID: UUID().uuidString.lowercased(), proposalID: proposalID,
                                                       planSeq: envelope.planSeq, version: detail.summary.version,
                                                       assertion: signed)
        } catch {
            phase = .failed(message: "The decision could not be encoded. Nothing was sent.")
            return
        }
        pending = request
        await send(request)
    }

    /// Retry never happens on its own. Unknown outcome: replay the identical request. Definite failure: reload.
    func retry() async {
        switch phase {
        case .outcomeUnknown:
            guard let request = pending else {
                phase = .idle
                await load()
                return
            }
            await send(request)
        case .failed:
            phase = .idle
            await load()
        default:
            return
        }
    }

    private func send(_ request: TuningDecisionRequest) async {
        phase = .submitting
        submitCount += 1
        let outcome: TuningDecisionOutcome
        do { outcome = try await transport.submitDecision(request) }
        catch {
            // Thrown before the request left the phone (no credential, fixture): nothing was recorded.
            pending = nil
            ledger.resolve(proposalID: request.proposalID, planSeq: request.planSeq)
            phase = .failed(message: error is DecisionSignerError ? DecisionSigner.message(for: error) : Self.loadMessage(error))
            return
        }
        switch outcome {
        case .accepted(let code):
            pending = nil
            ledger.resolve(proposalID: request.proposalID, planSeq: request.planSeq)
            phase = .accepted(code: code)
        case .refused(let status, let code):
            pending = nil
            ledger.resolve(proposalID: request.proposalID, planSeq: request.planSeq)
            phase = .failed(message: Self.refusalMessage(status: status, code: code))
        case .unknown:
            ledger.record(request)
            phase = .outcomeUnknown(message: TuningAcceptGate.Reason.outcomeUnknown.message)
        }
    }

    static func refusalMessage(status: Int, code: String) -> String {
        switch code {
        case "refused_signature": return "The signature was refused. Retry to reload, then accept again with Face ID."
        case "decision_attempts_exhausted": return "This plan has used all three decision attempts."
        case "state_conflict", "idempotency_conflict": return "The item changed on Kashbot. Retry to reload it."
        case "runner_stale": return "The runner is not syncing. Nothing was accepted."
        case "plan_expired": return "This plan expired before Kashbot recorded the decision."
        case "inbox_disabled": return "The tuning inbox is switched off on Kashbot."
        case "account_disabled": return "Autotuning is switched off for this account."
        case "presence_unconfigured", "credential_unknown":
            return "This phone's presence key is not pinned on the runner yet."
        case "rate_limited": return "Kashbot is rate limiting decisions. Retry in a minute."
        default:
            return "Kashbot refused the decision (HTTP \(status), \(TuningSyntax.isCode(code) ? code : "unreadable"))."
        }
    }

    static func loadMessage(_ error: Error) -> String {
        switch error as? DashboardClientError {
        case .http(404): return "This inbox item is not available to this device."
        case .noCredential: return "Connect the dashboard in Settings to load the tuning inbox."
        case .unauthorized, .forbidden: return "Dashboard access is unavailable. Check Settings."
        case .decoding: return "Kashbot's reply could not be read."
        default:
            if error is FixtureAccessError { return "Not available in demo mode." }
            return "The tuning inbox could not be loaded. Try again."
        }
    }

    static func planMessage(_ error: Error) -> String {
        if let refusal = error as? TuningPlanV2Error {
            return "The frozen change cannot be reviewed (\(refusal.code)). Do not accept."
        }
        switch error as? TuningPlanError {
        case .tooLarge: return "The frozen plan is larger than 256 KiB and cannot be reviewed here."
        case .base64: return "The frozen plan bytes are not valid base64."
        case .notCanonical: return "The frozen plan is not in canonical form. Do not accept."
        case .schema(let field): return "The frozen plan failed validation (\(field)). Do not accept."
        case nil: return "The frozen plan could not be read."
        }
    }
}

/// The inbox list. Reads only; accepting always happens on an item's own screen.
@MainActor final class TuningInboxListModel: ObservableObject {
    @Published private(set) var items: [TuningInboxSummary] = []
    @Published private(set) var nextCursor: String?
    @Published private(set) var loading = false
    @Published private(set) var error: String?
    private let transport: TuningInboxTransport

    init(transport: TuningInboxTransport) { self.transport = transport }

    func load() async {
        guard !loading else { return }
        loading = true
        defer { loading = false }
        error = nil
        do {
            let page = try await transport.list(cursor: nil)
            items = page.items
            nextCursor = page.nextCursor
        } catch {
            if error is CancellationError { return }
            self.error = (error as? DashboardClientError) == .http(404)
                ? "The tuning inbox is not available on this server yet."
                : TuningInboxItemModel.loadMessage(error)
        }
    }

    func loadMore() async {
        guard !loading, let cursor = nextCursor else { return }
        loading = true
        defer { loading = false }
        do {
            let page = try await transport.list(cursor: cursor)
            let known = Set(items.map(\.id))
            // The list stays bounded: at most 200 rows are kept on the phone.
            items = Array((items + page.items.filter { !known.contains($0.id) }).prefix(200))
            nextCursor = items.count >= 200 ? nil : page.nextCursor
        } catch {
            if !(error is CancellationError) { self.error = TuningInboxItemModel.loadMessage(error) }
        }
    }
}

// MARK: - Demo data

/// A small plan built at runtime in canonical form, so demo walks exercise the same parser and hash path.
enum TuningInboxSample {
    static let proposalID = "00000000-0000-4000-8000-00000000d3e0"

    static func planBytes(now: Date) -> Data {
        let frozen = TuningSyntax.milliseconds(now) - 60_000
        let manifest = Data(#"{"items":[{"account":"owner","engine":"sample-1","kind":"probe","sizing":"1.00","symbols":["BTC-15M"]}]}"#.utf8)
        let digest = String(repeating: "a", count: 64)
        let card = "ol-w1-owner-card-1-sample"
        let unit = "leafhft-live@kalshi-btc-15m.service"
        let engine: TuningJSON = .object([
            "id": .string("sample-1"), "parent": .string("sample-parent"),
            "set": .object(["entry_cents": .int(80), "exit_cents": .int(84)]), "symbols": .array([.string("BTC-15M")]),
            "sizing": .string("1.00"), "summary": .string("Sample placement"), "novelty": .string("Demo only"),
            "request_ids": .object(["probe": .string("sample-w1-probe-0"), "activate": .string("sample-w1-activate-0")]),
            "activation": .null,
        ])
        let manifestEntry: TuningJSON = .object([
            "request_id": .string(card), "bytes": .string(manifest.base64EncodedString()),
            "sha256": .string(TuningSyntax.sha256Hex(manifest)),
        ])
        let mintArgv: [String] = ["python3", "-m", "leafhft.engine_ops", "approve", "--kind", "wave", "--manifest",
                                  "@manifest:" + card, "--request-id", card, "--presence-decision", "@decision",
                                  "--presence-plan", "@plan"]
        let mint: TuningJSON = .object([
            "step_id": .string("s001"), "op": .string("mint"), "request_id": .string(card),
            "argv": .array(mintArgv.map { TuningJSON.string($0) }),
        ])
        let restartArgv: [String] = ["python3", "deploy/runner/rearm.py", "--apply", unit]
        let restart: TuningJSON = .object([
            "step_id": .string("s002"), "op": .string("restart"), "symbol": .string("BTC-15M"), "unit": .string(unit),
            "config_digest": .string(digest),
            "ack_sentence": .string("I authorize live trading with config " + digest + " and a stake of at most $10.00"),
            "argv": .array(restartArgv.map { TuningJSON.string($0) }),
        ])
        var fields: [String: TuningJSON] = [:]
        fields["schema"] = .string(TuningPlanDocument.schema)
        fields["proposal_id"] = .string(proposalID)
        fields["account"] = .string("00000001")
        fields["registry_account"] = .string("owner")
        fields["cycle_id"] = .string("ap-20260929-h12")
        fields["cycle_kind"] = .string("owner_daily")
        fields["generated_at_ms"] = .int(frozen - 60_000)
        fields["plan_seq"] = .int(1)
        fields["wave"] = .int(1)
        fields["runner_host"] = .string("sample-runner")
        fields["code_sha"] = .string(String(repeating: "0", count: 40))
        fields["grid_sha256"] = .string(String(repeating: "1", count: 64))
        fields["runner_nonce"] = .string(String(repeating: "2", count: 32))
        fields["frozen_at_ms"] = .int(frozen)
        fields["expires_at_ms"] = .int(frozen + TuningInboxLimits.planLifetimeMs)
        fields["engines"] = .array([engine])
        fields["manifests"] = .array([manifestEntry])
        fields["steps"] = .array([mint, restart])
        fields["gates"] = .array([])
        fields["gate_waiver"] = .object(["waiver_id": .string("sample-waiver"), "cap_total": .int(1)])
        fields["n_max_total"] = .int(1)
        fields["deferred"] = .array([])
        fields["retire"] = .array([.string("sample-old")])
        let document: TuningJSON = .object(fields)
        // Every value above is inside the contract's domain, so encoding cannot fail.
        return (try? document.canonicalBytes()) ?? Data()
    }

    static func detail(now: Date) -> TuningInboxDetail {
        let bytes = planBytes(now: now)
        let summary = TuningInboxSummary(id: proposalID, account: "00000001", cycleID: "ap-20260929-h12",
                                         cycleKind: "owner_daily", state: .ready, version: 3,
                                         generatedAtMs: TuningSyntax.milliseconds(now) - 120_000, planSeq: 1, resultCode: nil)
        return TuningInboxDetail(summary: summary,
                                 plan: TuningPlanEnvelope(planSeq: 1, planB64: bytes.base64EncodedString(),
                                                          planSHA256: TuningSyntax.sha256Hex(bytes)),
                                 runnerSyncAtMs: TuningSyntax.milliseconds(now))
    }
}
