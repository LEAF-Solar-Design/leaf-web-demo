import Foundation

struct AutopilotResponse: Decodable {
    let view: AutopilotDocument
    let toggles: AutopilotToggles
    var accountSwitches: [AutopilotAccountSwitch]? = nil

    static func decode(_ data: Data) throws -> Self {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return try decoder.decode(Self.self, from: data)
    }
}

enum AutopilotScope: String, Codable { case lane, owner }

struct AutopilotAccountSwitch: Decodable, Identifiable, Equatable {
    let scope: AutopilotScope
    let accountId: String
    let enabled: Bool
    let overridesOn: Int
    let overridesOff: Int
    var id: String { scope.rawValue + ":" + accountId }
    var label: String { scope == .owner ? "Autotuner (owner books)" : "Autotuner" }

    func confirmed(by document: AutopilotToggles) throws -> Self {
        guard document.accountId == accountId,
              document.schema == "leafhft.autopilot-toggles.v1" else {
            throw DashboardClientError.decoding
        }
        return Self(scope: scope, accountId: accountId, enabled: document.enabledDefault,
                    overridesOn: document.engines.values.filter { $0 == .on }.count,
                    overridesOff: document.engines.values.filter { $0 == .off }.count)
    }
}

struct AutopilotToggles: Decodable {
    let schema: String
    let accountId: String
    let enabledDefault: Bool
    let engines: [String: AutopilotOverrideState]
}

enum AutopilotOverrideState: String, Decodable { case on, off }
enum AutopilotToggle: String, Decodable { case on, off, `default` }
enum AutopilotDecision: String, Decodable, CaseIterable { case promote, keep, kill, insufficient }

enum AutopilotDial: Decodable, Equatable {
    case number(Double)
    case boolean(Bool)

    init(from decoder: Decoder) throws {
        let value = try decoder.singleValueContainer()
        if let flag = try? value.decode(Bool.self) { self = .boolean(flag) }
        else { self = .number(try value.decode(Double.self)) }
    }
}

enum AutopilotCount: Decodable, Equatable {
    case integer(Int)
    case grouped([String: Int])

    init(from decoder: Decoder) throws {
        let value = try decoder.singleValueContainer()
        if let count = try? value.decode(Int.self) { self = .integer(count) }
        else { self = .grouped(try value.decode([String: Int].self)) }
    }
}

struct AutopilotDocument: Decodable {
    let schema: String
    let generatedAt: String
    let accountId: String
    let truncated: Bool
    let autopilot: AutopilotState
    let cycles: [AutopilotCycle]
    let engines: [AutopilotEngine]
    let refused: [AutopilotRefusal]
    let kills: [AutopilotKill]
    let pending: AutopilotPending?
    let handoffs: [AutopilotHandoff]
}

struct AutopilotState: Decodable {
    enum Source: String, Decodable { case api, cache, `default` }
    enum Mirror: String, Decodable { case live, waitingForLedger = "waiting_for_ledger" }
    let togglesSource: Source
    let enabledDefault: Bool
    let mirrorStatus: Mirror
    let mirrorGeneratedAt: String?
    let waitingReason: String?
}

struct AutopilotCycle: Decodable, Identifiable {
    let cycleId: String
    let etDay: String
    let stage: String
    let status: String
    let detail: String
    let counts: [String: AutopilotCount]?
    let generation: String?
    let family: Family?
    let updatedAt: String
    var id: String { cycleId }

    struct Family: Decodable {
        let m: Int
        let adjustedQ: Double
    }
}

struct AutopilotEngine: Decodable, Identifiable {
    let engineId: String
    let parent: String?
    let lineageRoot: String
    let generation: Int
    let overrides: [String: AutopilotDial]
    let toggle: AutopilotToggle
    let toggleEffective: Bool
    let inPopulation: Bool
    let firstSeen: String?
    let staleReason: String?
    let lifecycleState: String?
    let size: String?
    let approvalSha12: String?
    let books: [String]
    let verdicts: [AutopilotVerdict]
    let cells: [AutopilotCell]
    let evidence: AutopilotEvidence
    // ISO 8601 UTC, optionally with fractional seconds; absent in views pushed before leaf-hft #805.
    let lastFillAt: String?
    var id: String { engineId }

    static let dormantAfter: TimeInterval = 24 * 60 * 60

    private static let fractionalParser: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()
    private static let plainParser: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter
    }()
    private static let relativeFormatter: RelativeDateTimeFormatter = {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .full
        formatter.locale = Locale(identifier: "en_US")
        return formatter
    }()

    static func parseFillTimestamp(_ text: String) -> Date? {
        if let date = fractionalParser.date(from: text) ?? plainParser.date(from: text) { return date }
        // Fallback for fraction lengths the fractional parser refuses: truncate to milliseconds, keep the zone.
        guard let dot = text.firstIndex(of: "."),
              let zone = text[dot...].firstIndex(where: { $0 == "Z" || $0 == "+" || $0 == "-" }) else { return nil }
        let fraction = text[text.index(after: dot)..<zone]
        guard !fraction.isEmpty, fraction.allSatisfy({ $0.isASCII && $0.isNumber }) else { return nil }
        return fractionalParser.date(from: String(text[...dot]) + String(fraction.prefix(3)) + String(text[zone...]))
    }

    /// Pure: label for the lineage list and whether the engine counts as dormant (nil when unknown).
    func lastFillStatus(now: Date = Date()) -> (label: String, dormant: Bool?) {
        guard let lastFillAt else {
            return books.isEmpty ? ("Last fill not reported", nil) : ("No fills yet", true)
        }
        guard let date = Self.parseFillTimestamp(lastFillAt) else { return ("Last fill not reported", nil) }
        let relative = Self.relativeFormatter.localizedString(for: date, relativeTo: now)
        return ("Last fill " + relative, now.timeIntervalSince(date) > Self.dormantAfter)
    }
}

struct AutopilotVerdict: Decodable {
    let cycleId: String
    let decision: AutopilotDecision
    let score: Double?
}

struct AutopilotCell: Decodable {
    let symbol: String
    let bucket: String
    let n: Int
    let nEff: Double
    let adjustedQuantile: Double?
    let sizeUpCandidate: Bool
}

struct AutopilotEvidence: Decodable {
    let maxCellN: Int
    let sumNEff: Double
    let nFloor: Int
    let neffFloor: Int
}

struct AutopilotRefusal: Decodable {
    let engineId: String
    let baseId: String
    let overrides: [String: AutopilotDial]
    let reason: String
    let cycleId: String
}

struct AutopilotKill: Decodable {
    let fingerprint: String
    let lineageRoot: String
    let overrides: [String: AutopilotDial]
    let reason: String
    let killedAt: String
}

struct AutopilotPending: Decodable {
    let cycleId: String
    let daysWaiting: Double
    let ol2GridKey: String
}

struct AutopilotHandoff: Decodable {
    let engineId: String
    let cycleId: String
    let atMs: Int64
}
