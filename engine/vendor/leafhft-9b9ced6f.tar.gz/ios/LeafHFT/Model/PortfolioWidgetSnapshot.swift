import Foundation

struct PortfolioWidgetValuePoint: Equatable {
    let observedAt: Date
    let totalCents: Int
}

struct PortfolioWidgetPositionSnapshot: Codable, Equatable, Identifiable {
    var id: String { ticker }
    let ticker: String
    let size: String
    let exposureCents: Int
}

struct PortfolioWidgetSnapshot: Codable, Equatable {
    static let appGroup = "group.com.evan.leafhft"
    static let storageKey = "kashbot.portfolio-widget.snapshot.v1"
    static let maximumAge: TimeInterval = 24 * 60 * 60

    let totalCents: Int
    let change15MinutesCents: Int?
    let observedAt: Date
    let positions: [PortfolioWidgetPositionSnapshot]

    func isExpired(now: Date) -> Bool {
        let age = now.timeIntervalSince(observedAt)
        return age > Self.maximumAge || age < -60
    }

    func deltaIsCurrent(now: Date) -> Bool {
        let age = now.timeIntervalSince(observedAt)
        return age >= 0 && age <= 20 * 60
    }

    static func make(totalCents: Int, history: [PortfolioWidgetValuePoint],
                     positions: [PortfolioWidgetPositionSnapshot], now: Date) -> Self {
        let cutoff = now.addingTimeInterval(-15 * 60)
        let earliest = now.addingTimeInterval(-30 * 60)
        let baseline = history
            .filter { $0.observedAt >= earliest && $0.observedAt <= cutoff }
            .max { $0.observedAt < $1.observedAt }
        return Self(
            totalCents: totalCents,
            change15MinutesCents: baseline.flatMap { subtracting(totalCents, $0.totalCents) },
            observedAt: now,
            positions: positions
                .filter { $0.exposureCents != 0 }
                .sorted { absMagnitude($0.exposureCents) > absMagnitude($1.exposureCents) }
                .prefix(3)
                .map { $0 }
        )
    }

    private static func subtracting(_ lhs: Int, _ rhs: Int) -> Int? {
        let result = lhs.subtractingReportingOverflow(rhs)
        return result.overflow ? nil : result.partialValue
    }

    private static func absMagnitude(_ value: Int) -> UInt {
        value.magnitude
    }
}

enum PortfolioWidgetSnapshotStore {
    static func load() -> PortfolioWidgetSnapshot? {
        guard let defaults = UserDefaults(suiteName: PortfolioWidgetSnapshot.appGroup),
              let data = defaults.data(forKey: PortfolioWidgetSnapshot.storageKey),
              let snapshot = try? JSONDecoder().decode(PortfolioWidgetSnapshot.self, from: data),
              !snapshot.isExpired(now: Date()) else { return nil }
        return snapshot
    }

    @discardableResult static func clear() -> Bool {
        guard let defaults = UserDefaults(suiteName: PortfolioWidgetSnapshot.appGroup) else { return false }
        let wasPresent = defaults.object(forKey: PortfolioWidgetSnapshot.storageKey) != nil
        defaults.removeObject(forKey: PortfolioWidgetSnapshot.storageKey)
        return wasPresent
    }

    static func save(_ snapshot: PortfolioWidgetSnapshot) {
        guard let defaults = UserDefaults(suiteName: PortfolioWidgetSnapshot.appGroup),
              let data = try? JSONEncoder().encode(snapshot) else { return }
        defaults.set(data, forKey: PortfolioWidgetSnapshot.storageKey)
    }
}
