import Foundation
import LeafHFTCore

extension AppState {
    func serverAccountAge(now: Date) -> String? {
        guard case let .server(observedAt, _) = accountSource else { return nil }
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .short
        return formatter.localizedString(for: observedAt, relativeTo: now)
    }

    var accountActivityError: String? {
        let errors = [positionsError, fillsError].compactMap { $0 }
        return errors.isEmpty ? nil : errors.joined(separator: " ")
    }

    var peopleNotAuthorized: Bool {
        if case .notAuthorized? = peopleResult { return true }
        return false
    }

    /// Every control walked requested -> applied|rejected, lifecycle kinds (probe, halt, breaker) included.
    var pendingControls: [ControlRequest] { pendingRequests }

    var execution: KashbotExecution? { kashbotStatus?.execution }

    var isOwnerExecution: Bool { kashbotStatus?.isOwnerExecution == true }

    var ownerControlProgress: String? {
        guard isOwnerExecution else { return nil }
        if let pending = execution?.pendingLabel { return pending }
        if accountMutationInProgress {
            return runnerAction == .pause ? "Pausing" : runnerAction == .startLive ? "Resuming" : nil
        }
        return nil
    }

    var settingUpDryRun: Bool { accountMutationInProgress && runnerAction == nil }

    var accountReadability: AccountReadability {
        if case let .server(observedAt, _) = accountSource,
           (-60...300).contains(Date().timeIntervalSince(observedAt)) { return .readable }
        if kalshiError != nil { return .unavailable }
        return balance != nil && !balanceStale ? .readable : .unknown
    }

    var automationLabel: String { kashbotStatus?.automationLabel ?? "Not checked" }

    var canSetupDryRun: Bool {
        !isOwnerExecution && setupCredentialsPresent && accountSceneActive && !fixtureMode.enabled && !accountMutationInProgress && !checkingSetupProgress &&
        dashboardPairingState == .paired &&
        (kashbotStatus?.automatedTrading == .notConfigured ||
         kashbotStatus?.automatedTrading == .credentialRequired ||
         kashbotStatus?.automatedTrading == .ready ||
         kashbotStatus?.automatedTrading == .provisioning)
    }
}
