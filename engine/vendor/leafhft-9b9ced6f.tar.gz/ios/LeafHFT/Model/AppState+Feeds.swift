import Foundation

struct FeedStatus: Equatable {
    var observedAt: Date?
    var attemptedAt: Date?
    var lastError: String?
}

enum Feed: String, CaseIterable, Hashable {
    case balance, positions, markets, settlements, fills, probes, engines, books
    case status, accountHistory, activity, exits, calibration, attemptFunnel, engineLab, controlRequests, people
}

extension AppState {
    func isStale(_ feed: Feed, budget: TimeInterval, now: Date) -> Bool {
        guard let observedAt = feedStatuses[feed]?.observedAt else { return true }
        return now.timeIntervalSince(observedAt) > budget
    }

    var boardObservedAt: Date? {
        let dates = [Feed.balance, .positions, .settlements].compactMap { feedStatuses[$0]?.observedAt }
        return dates.count == 3 ? dates.min() : nil
    }
}
