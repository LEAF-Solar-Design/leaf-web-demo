import Foundation
import Observation

@MainActor @Observable final class AssistantInbox {
    private(set) var cards: [AssistantCard] = []
    private(set) var nominations: [AssistantNomination] = []
    private(set) var canApprove = false
    private(set) var unreadCount = 0
    private(set) var openRequest = 0
    private(set) var loading = false
    private(set) var lastRefreshedAt: Date?
    private(set) var error: String?
    private(set) var approvingCardId: String?
    private(set) var approvedCardTitle: String?
    private(set) var pendingApproval: AssistantCard?
    private(set) var changedNotice: String?
    private(set) var reviewNotice: String?
    private(set) var acceptingNominationId: String?
    private(set) var acceptNotice: String?
    private(set) var approvalCooldownUntil: Date?
    var approveCoolingDown: Bool { approvalCooldownUntil.map { now() < $0 } ?? false }
    @ObservationIgnored private let client: MushyClient
    @ObservationIgnored private let now: () -> Date
    @ObservationIgnored private var approvalTask: Task<Void, Never>?
    @ObservationIgnored private var acceptTask: Task<Void, Never>?
    @ObservationIgnored private var cooldownTask: Task<Void, Never>?
    @ObservationIgnored private var refreshTask: Task<Void, Never>?
    @ObservationIgnored private var identity: String?
    @ObservationIgnored private var badgeRevision = 0
    @ObservationIgnored private var refreshingBadge = false
    @ObservationIgnored private var markingSeen = false
    @ObservationIgnored private var consumedOpenRequest = 0

    init(fixtureMode: FixtureMode = .current, client: MushyClient? = nil,
         now: @escaping () -> Date = Date.init) {
        self.client = client ?? MushyClient(fixtureMode: fixtureMode)
        self.now = now
    }

    func requestOpen() { openRequest &+= 1 }

    /// Consumption belongs to the inbox so a recreated sheet cannot replay an old push.
    func consumeOpenRequest() -> Bool {
        guard openRequest != consumedOpenRequest else { return false }
        consumedOpenRequest = openRequest
        return true
    }

    /// The full listing may renew cards; callers use this only while the tab is visible.
    func refresh() async {
        guard approvingCardId == nil, acceptingNominationId == nil else { return }
        if let refreshTask {
            await refreshTask.value
            return
        }
        let task = Task { @MainActor in
            defer { self.refreshTask = nil }
            await self.refreshInbox()
        }
        refreshTask = task
        await task.value
    }

    func dismissApprovalNotice() { approvedCardTitle = nil }
    func dismissChangedNotice() { changedNotice = nil }
    func dismissReviewNotice() { reviewNotice = nil }

    func beginApproval(_ card: AssistantCard) {
        guard canApprove, !loading, approvingCardId == nil, !approveCoolingDown,
              pendingApproval == nil, card.hasReadableDetails else { return }
        guard validateApprovalSnapshot(card) else { return }
        pendingApproval = card
    }

    func cancelApproval() { pendingApproval = nil }

    @discardableResult func validateApprovalSnapshot(_ card: AssistantCard) -> Bool {
        guard cards.contains(where: { $0.matchesApprovalSnapshot(card) }) else {
            pendingApproval = nil
            changedNotice = "That card changed. Read the updated values before approving."
            return false
        }
        return true
    }

    private func startApprovalCooldown() {
        let deadline = now().addingTimeInterval(1)
        approvalCooldownUntil = deadline
        cooldownTask?.cancel()
        cooldownTask = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(1)) } catch { return }
            guard let self, self.approvalCooldownUntil == deadline, self.now() >= deadline else { return }
            self.approvalCooldownUntil = nil
        }
    }

    private func refreshInbox() async {
        guard !loading else { return }
        loading = true
        error = nil
        badgeRevision += 1
        let priorOpenCards = cards.filter { $0.state == .open }
        defer { loading = false }
        do {
            let currentIdentity = try client.identity()
            if identity != currentIdentity {
                cards = []
                nominations = []
                canApprove = false
                unreadCount = 0
                lastRefreshedAt = nil
                identity = nil
                if let pendingApproval { _ = validateApprovalSnapshot(pendingApproval) }
            }
            let page = try await client.fetchInbox(identity: currentIdentity)
            identity = currentIdentity
            cards = page.cards
            nominations = page.nominations
            canApprove = page.canApprove
            unreadCount = page.unreadCount
            lastRefreshedAt = now()
            let openCards = cards.filter { $0.state == .open }
            if priorOpenCards.count != openCards.count
                || !zip(openCards, priorOpenCards).allSatisfy({ $0.0.matchesApprovalSnapshot($0.1) }) {
                startApprovalCooldown()
            }
            if let pendingApproval { _ = validateApprovalSnapshot(pendingApproval) }
        } catch {
            guard !Self.isCancellation(error) else { return }
            self.error = error.localizedDescription
        }
    }

    func refreshBadge() async {
        guard !refreshingBadge, !loading, !markingSeen else { return }
        refreshingBadge = true
        let revision = badgeRevision
        defer { refreshingBadge = false }
        do {
            let count = try await client.fetchInboxCount()
            if revision == badgeRevision { unreadCount = count.unreadCount }
        } catch {
            guard !Self.isCancellation(error) else { return }
            self.error = error.localizedDescription
        }
    }

    func markSeen() async {
        guard !markingSeen, !loading, !Task.isCancelled, let identity else { return }
        let timestamps = cards.compactMap(\.createdAt) + nominations.map(\.receivedAt)
        guard let newest = timestamps.compactMap({ value in
            MushyCoding.date(value).map { (value, $0) }
        }).max(by: { $0.1 < $1.1 }) else { return }
        badgeRevision += 1
        let revision = badgeRevision
        markingSeen = true
        defer { markingSeen = false }
        do {
            _ = try await client.markInboxSeen(through: newest.0, identity: identity)
            if revision == badgeRevision { unreadCount = 0 }
        } catch {
            guard !Self.isCancellation(error) else { return }
            self.error = error.localizedDescription
        }
    }

    func approve(card: AssistantCard) async {
        guard validateApprovalSnapshot(card) else { return }
        guard canApprove, !loading, approvingCardId == nil, acceptingNominationId == nil, !approveCoolingDown,
              card.hasReadableDetails, let identity else { return }
        pendingApproval = nil
        approvingCardId = card.id
        error = nil
        approvedCardTitle = nil
        // This unstructured task belongs to the model; cancellation of its caller cannot cancel the POST.
        let task = Task { await self.performApproval(card: card, identity: identity) }
        approvalTask = task
        await task.value
    }

    private func performApproval(card: AssistantCard, identity: String) async {
        defer {
            approvingCardId = nil
            approvalTask = nil
            startApprovalCooldown()
        }
        do {
            // MushyClient retains the digest-bound request id when the outcome is uncertain or retryable.
            try await client.approveCard(cardId: card.id, cardDigest: card.cardDigest, identity: identity)
            if let index = cards.firstIndex(where: { $0.id == card.id && $0.cardDigest == card.cardDigest }) {
                cards[index].state = .approved
            }
            await refreshInbox()
            approvedCardTitle = card.title
            changedNotice = nil
        } catch MushyClientError.http(let status) where status == 409 || status == 410 {
            // A replacement must be rendered and explicitly tapped. Never resend after a refetch.
            changedNotice = status == 409
                ? "That card changed. Read the updated values before approving."
                : "That card is no longer waiting."
            await refreshInbox()
        } catch {
            guard !Self.isCancellation(error) else { return }
            self.error = error.localizedDescription
        }
    }

    func canAccept(_ nomination: AssistantNomination) -> Bool {
        canApprove && AssistantNomination.validId(nomination.id) && nomination.acceptAvailable
            && nomination.ownAccount && nomination.kind == "tune" && !nomination.stale && nomination.cardId == nil
    }

    func accept(_ nomination: AssistantNomination) async {
        guard canAccept(nomination), !loading, acceptingNominationId == nil, approvingCardId == nil,
              pendingApproval == nil, let identity else { return }
        acceptingNominationId = nomination.id
        acceptNotice = nil
        error = nil
        // This unstructured task belongs to the model; cancellation of its caller cannot cancel the POST.
        let task = Task { await self.performAccept(nomination, identity: identity) }
        acceptTask = task
        await task.value
    }

    private func performAccept(_ nomination: AssistantNomination, identity: String) async {
        defer {
            acceptingNominationId = nil
            acceptTask = nil
        }
        do {
            let receipt = try await client.acceptNomination(id: nomination.id,
                packetAsOf: nomination.packetAsOf, identity: identity)
            await refreshInbox()
            if let card = cards.first(where: { $0.id == receipt.cardId && $0.state == .open && $0.hasReadableDetails }) {
                // A refreshed card list keeps its existing cooldown before confirmation can open.
                if let deadline = approvalCooldownUntil, deadline > now() {
                    try await Task.sleep(for: .seconds(deadline.timeIntervalSince(now())))
                }
                beginApproval(card)
            } else {
                acceptNotice = "The card is ready under Waiting for approval."
            }
        } catch MushyClientError.refused(let status, let code) {
            switch code {
            case "engine_has_open_card":
                acceptNotice = "This engine already has a card waiting. Approve or let that one expire first."
            case "nomination_stale", "nomination_changed", "nomination_not_ready", "nomination_not_found":
                acceptNotice = "This suggestion changed. The list has been refreshed."
            case "accept_in_progress":
                acceptNotice = "Still working on the last tap. Try again in a moment."
            case "accept_rate_limited":
                acceptNotice = "Too many suggestions accepted this hour. Try again later."
            case "nomination_other_account", "accept_admin_required":
                acceptNotice = "This suggestion cannot be approved from this account."
            case "autotune_action_not_available":
                acceptNotice = "This kind of suggestion cannot be approved here yet."
            default: break
            }
            await refreshInbox()
            if acceptNotice == nil {
                error = MushyClientError.refused(status: status, code: code).localizedDescription
            }
        } catch {
            guard !Self.isCancellation(error) else { return }
            self.error = error.localizedDescription
        }
    }

    private static func isCancellation(_ error: Error) -> Bool {
        if error is CancellationError { return true }
        if let error = error as? URLError, error.code == .cancelled { return true }
        let error = error as NSError
        return error.domain == NSURLErrorDomain && error.code == NSURLErrorCancelled
    }

    func canReview(_ nomination: AssistantNomination) -> Bool {
        canApprove && AssistantNomination.validId(nomination.id)
            && nomination.actionable && nomination.ownAccount && nomination.kind == "tune" && nomination.cardId == nil
    }

    func reviewText(for nomination: AssistantNomination) -> String {
        guard AssistantNomination.validId(nomination.id) else { return "" }
        return "Review autotune suggestion \(nomination.id)"
    }

    /// Returns false when a busy turn requires the user to send later or finish their draft.
    @discardableResult func review(_ nomination: AssistantNomination,
                                   conversation: AssistantConversation, studio: MushyState) async -> Bool {
        guard approvingCardId == nil, canReview(nomination) else { return true }
        reviewNotice = nil
        let text = reviewText(for: nomination)
        if conversation.isBusy {
            if conversation.draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                conversation.offerPrefill(text)
                reviewNotice = "The suggestion is in the composer; send it when the current reply finishes."
            } else {
                reviewNotice = "Finish or clear your draft, then tap Review again."
            }
            return false
        }
        await conversation.send(text, studio: studio)
        return true
    }

    func discuss(_ card: AssistantCard, conversation: AssistantConversation, currentSessionId: String? = nil) {
        guard approvingCardId == nil, AssistantCard.validId(card.id) else { return }
        conversation.offerPrefill(discussText(for: card, currentSessionId: currentSessionId))
    }

    func discuss(_ nomination: AssistantNomination, conversation: AssistantConversation) {
        guard approvingCardId == nil, AssistantNomination.validId(nomination.id) else { return }
        conversation.offerPrefill(discussText(for: nomination))
    }

    func discussText(for card: AssistantCard, currentSessionId: String? = nil) -> String {
        guard AssistantCard.validId(card.id) else { return "" }
        let text = discussText(kind: "card", id: card.id, ticker: card.identity?.ticker ?? "unknown")
        if let sessionId = card.sessionId, sessionId != currentSessionId {
            return text + " This card is from another conversation, so use its button in the Autotune tab to approve it."
        }
        return text
    }

    func discussText(for nomination: AssistantNomination) -> String {
        guard AssistantNomination.validId(nomination.id) else { return "" }
        return discussText(kind: "autotune suggestion", id: nomination.id, ticker: nomination.identity.ticker)
    }

    private func discussText(kind: String, id: String, ticker: String) -> String {
        let ticker = AssistantEngineIdentity.validTicker(ticker) ? ticker : "unknown"
        return "Discuss \(kind) \(id) for engine \(ticker)"
    }
}
