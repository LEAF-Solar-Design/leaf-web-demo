import Foundation
#if canImport(ActivityKit)
import ActivityKit
#endif

struct KashbotLiveAttributes: Codable {
    var v: Int = 1

    struct Row: Codable, Hashable {
        var ticker: String
        var label: String?
        var side: String
        var milli: Int
        var winCents: Int?
        var oddsPct: Int?
        var state: String
        var pnlCents: Int? = nil
    }

    struct Entry: Codable, Hashable {
        var ticker: String
        var pnlCents: Int
        var pnlBps: Int?
        var at: Int
    }

    struct Approval: Codable, Hashable {
        var account: String
        var proposalId: String
        var planSeq: Int64
        var planSha256: String

        var reviewURL: URL? {
            func hex(_ value: String, count: Int) -> Bool {
                value.utf8.count == count && value.utf8.allSatisfy {
                    (0x30...0x39).contains($0) || (0x61...0x66).contains($0)
                }
            }
            guard hex(account, count: 8), hex(planSha256, count: 64), planSeq >= 1,
                  let uuid = UUID(uuidString: proposalId), uuid.uuidString.lowercased() == proposalId else { return nil }
            var parts = URLComponents()
            parts.scheme = "leafhft"
            parts.host = "tuning"
            parts.path = "/review"
            parts.queryItems = [URLQueryItem(name: "account", value: account),
                                URLQueryItem(name: "proposal_id", value: proposalId),
                                URLQueryItem(name: "plan_seq", value: String(planSeq)),
                                URLQueryItem(name: "plan_sha256", value: planSha256)]
            return parts.url
        }
    }

    struct ContentState: Codable, Hashable {
        var v: Int = 1
        var asOf: Int
        var totalCents: Int
        var todayCents: Int
        var openCount: Int
        var rows: [Row]
        var ledger: [Entry]
        var approvalsWaiting: Int? = nil
        var approval: Approval? = nil

        private enum CodingKeys: String, CodingKey {
            case v, asOf, totalCents, todayCents, openCount, rows, ledger, approvalsWaiting, approval
        }

        var approvalCount: Int { max(0, approvalsWaiting ?? 0) }
        var approvalText: String? {
            approvalCount > 0 ? "\(approvalCount) \(approvalCount == 1 ? "approval" : "approvals") waiting" : nil
        }
        var reviewURL: URL? { approval?.reviewURL }

        func isMaterialChange(from old: ContentState?) -> Bool {
            guard let old else { return true }
            if approvalsWaiting != old.approvalsWaiting || approval != old.approval { return true }
            if openCount != old.openCount { return true }
            if ledger.first?.ticker != old.ledger.first?.ticker || ledger.first?.at != old.ledger.first?.at { return true }
            // A counted dictionary preserves duplicate holdings and ignores row ordering.
            struct Holding: Hashable {
                let ticker: String
                let side: String
                let milli: Int
            }
            func holdings(_ rows: [Row]) -> [Holding: Int] {
                rows.reduce(into: [:]) { counts, row in
                    counts[Holding(ticker: row.ticker, side: row.side, milli: row.milli), default: 0] += 1
                }
            }
            if holdings(rows) != holdings(old.rows) { return true }
            func states(_ rows: [Row]) -> [String: [String: Int]] {
                rows.reduce(into: [:]) { values, row in
                    values[row.ticker, default: [:]][row.state, default: 0] += 1
                }
            }
            return states(rows) != states(old.rows)
        }
    }
}

extension KashbotLiveAttributes.ContentState {
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        v = try values.decode(Int.self, forKey: .v)
        asOf = try values.decode(Int.self, forKey: .asOf)
        totalCents = try values.decode(Int.self, forKey: .totalCents)
        todayCents = try values.decode(Int.self, forKey: .todayCents)
        openCount = try values.decode(Int.self, forKey: .openCount)
        rows = try values.decode([KashbotLiveAttributes.Row].self, forKey: .rows)
        ledger = try values.decode([KashbotLiveAttributes.Entry].self, forKey: .ledger)
        approvalsWaiting = try values.decodeIfPresent(Int.self, forKey: .approvalsWaiting)
        approval = try values.decodeIfPresent(KashbotLiveAttributes.Approval.self, forKey: .approval)
    }
}

#if canImport(ActivityKit)
extension KashbotLiveAttributes: ActivityAttributes {}
#endif

struct KashbotBoardSnapshot: Codable, Equatable {
    static let appGroup = "group.com.evan.leafhft"
    static let storageKey = "kashbot.live-board.v1"
    static let maximumAge: TimeInterval = 24 * 60 * 60

    var state: KashbotLiveAttributes.ContentState
    var ledger: [KashbotLiveAttributes.Entry]
    var approvalsWaiting: Int? = nil
    var approval: KashbotLiveAttributes.Approval? = nil

    private enum CodingKeys: String, CodingKey { case state, ledger, approvalsWaiting, approval }

    func isExpired(now: Date) -> Bool {
        let age = now.timeIntervalSince1970 - TimeInterval(state.asOf)
        return age > Self.maximumAge || age < -60
    }
}

extension KashbotBoardSnapshot {
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        state = try values.decode(KashbotLiveAttributes.ContentState.self, forKey: .state)
        ledger = try values.decode([KashbotLiveAttributes.Entry].self, forKey: .ledger)
        approvalsWaiting = try values.decodeIfPresent(Int.self, forKey: .approvalsWaiting)
        approval = try values.decodeIfPresent(KashbotLiveAttributes.Approval.self, forKey: .approval)
    }
}

enum KashbotBoardStore {
    static func load(now: Date = Date()) -> KashbotBoardSnapshot? {
        guard let defaults = UserDefaults(suiteName: KashbotBoardSnapshot.appGroup),
              let data = defaults.data(forKey: KashbotBoardSnapshot.storageKey),
              let snapshot = try? JSONDecoder().decode(KashbotBoardSnapshot.self, from: data),
              snapshot.ledger.count <= 20,
              !snapshot.isExpired(now: now) else { return nil }
        return snapshot
    }

    @discardableResult static func clear() -> Bool {
        guard let defaults = UserDefaults(suiteName: KashbotBoardSnapshot.appGroup) else { return false }
        let wasPresent = defaults.object(forKey: KashbotBoardSnapshot.storageKey) != nil
        defaults.removeObject(forKey: KashbotBoardSnapshot.storageKey)
        return wasPresent
    }

    static func save(_ snapshot: KashbotBoardSnapshot) {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        var snapshot = snapshot
        snapshot.ledger = Array(snapshot.ledger.prefix(20))
        guard let defaults = UserDefaults(suiteName: KashbotBoardSnapshot.appGroup),
              let data = try? encoder.encode(snapshot) else { return }
        defaults.set(data, forKey: KashbotBoardSnapshot.storageKey)
    }
}
