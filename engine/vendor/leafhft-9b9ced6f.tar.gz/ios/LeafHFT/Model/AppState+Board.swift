import Foundation
import LeafHFTCore

extension AppState {
    static func shouldReloadBoardWidgets(previous: KashbotBoardSnapshot?, previousAt: Date?,
                                         next: KashbotBoardSnapshot, now: Date) -> Bool {
        guard var previous, let previousAt else { return true }
        previous.state.asOf = next.state.asOf
        return previous != next || now.timeIntervalSince(previousAt) >= 60
    }
}
