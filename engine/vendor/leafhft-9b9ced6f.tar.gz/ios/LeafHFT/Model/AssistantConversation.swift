import Foundation
import Observation

struct ToolChip: Identifiable {
    let id: String
    var label: String
    var state: String
}

struct AssistantViewCard: Identifiable {
    let id = UUID()
    let title: String
    let panels: [AssistantPanel]
}

struct AssistantReply {
    var text = ""
    var tools: [ToolChip] = []
    var views: [AssistantViewCard] = []
    var cards: [AssistantCard] = []
    var finished = false
    var failed: String?
    var stage: String?
}

@MainActor @Observable final class AssistantConversation {
    enum Item: Identifiable {
        case user(id: UUID, text: String)
        case assistant(id: UUID, reply: AssistantReply)
        case notice(id: UUID, text: String, tone: LeafTone)

        var id: UUID {
            switch self {
            case .user(let id, _), .assistant(let id, _), .notice(let id, _, _): return id
            }
        }
    }

    private(set) var items: [Item] = []
    private(set) var activeJobId: String?
    private(set) var sending = false
    var isBusy: Bool { sending || activeJobId != nil }
    private(set) var sentAt: Date?
    private(set) var cursor = 0
    private(set) var kitCursor = 0
    private(set) var offeredPrefill: String?
    private(set) var engineBuilding = false
    private(set) var restoredDraft = false
    private(set) var messageDates: [UUID: Date] = [:]
    var draft = "" {
        didSet { if draft != oldValue { restoredDraft = false } }
    }
    @ObservationIgnored private let client: MushyClient
    @ObservationIgnored private let kitRoutes: Bool
    @ObservationIgnored private var identity: String?
    @ObservationIgnored private var hasOpened = false
    private var replyId: UUID?
    private var cardsFetched: Set<UUID> = []
    private var cardTurns: [UUID: (turnId: String, identity: String)] = [:]
    private(set) var approvingCards: Set<String> = []

    init(fixtureMode: FixtureMode = .current, client: MushyClient? = nil, kitRoutes: Bool? = nil) {
        self.client = client ?? MushyClient(fixtureMode: fixtureMode)
        self.kitRoutes = !fixtureMode.enabled && (kitRoutes ?? KashbotKitFlag.enabled(fixtureMode: fixtureMode))
    }

    func setEngineBuilding(_ on: Bool) { engineBuilding = on }

    func selectStarter(_ text: String) { offerPrefill(text) }

    func clearDraft() {
        draft = ""
        restoredDraft = false
    }

    func open(studio: MushyState, now: Date = Date()) async {
        restoredDraft = hasOpened && !draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        hasOpened = true
        guard activeJobId == nil, !sending else { return }
        let newestLocal = messageDates.values.max()
        load(from: studio)
        let newest = [newestLocal, messageDates.values.max()].compactMap { $0 }.max()
        if let newest, now.timeIntervalSince(newest) > 6 * 3_600 {
            await newConversation(studio: studio, keepingDraft: true)
        }
    }

    func offerPrefill(_ text: String, engineBuilding: Bool = false) {
        if engineBuilding { setEngineBuilding(true) }
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        if draft == text || offeredPrefill == text { return }
        if draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            draft = text
            offeredPrefill = nil
        } else {
            offeredPrefill = text
        }
    }

    func acceptPrefill() {
        guard let text = offeredPrefill else { return }
        draft = text
        offeredPrefill = nil
    }

    func dismissPrefill() { offeredPrefill = nil }

    var activeReply: AssistantReply? {
        guard let replyId,
              let item = items.first(where: { $0.id == replyId }),
              case .assistant(_, let reply) = item else { return nil }
        return reply
    }

    var waitingTooLong: Bool { waitingTooLong(now: Date()) }

    func waitingTooLong(now: Date) -> Bool {
        guard sending || activeJobId != nil, let reply = activeReply, let sentAt else { return false }
        return reply.text.isEmpty && reply.tools.isEmpty && reply.stage == "queued"
            && now.timeIntervalSince(sentAt) > 8
    }

    func load(from studio: MushyState) {
        guard activeJobId == nil, !sending else { return }
        messageDates = [:]
        items = (studio.conversation?.messages ?? []).compactMap { message in
            let id = UUID()
            if let date = MushyCoding.date(message.createdAt) { messageDates[id] = date }
            if message.role == "user" { return .user(id: id, text: message.content) }
            guard message.role == "assistant" else { return nil }
            let text = message.content.trimmingCharacters(in: .whitespacesAndNewlines)
            if text.hasPrefix("Created "), !text.contains("\n"),
               !text.dropFirst("Created ".count).contains(where: { ".!?".contains($0) }) { return nil }
            return .assistant(id: id, reply: AssistantReply(text: message.content, finished: true))
        }
        replyId = items.last(where: { if case .assistant = $0 { return true }; return false })?.id
        cursor = 0
        kitCursor = 0
    }

    func send(_ text: String, studio: MushyState, now: Date = Date()) async {
        guard activeJobId == nil, !sending else { return }
        let input = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !input.isEmpty else { return }
        guard !MushyPromptLimit.exceeded(input) else {
            notice("Keep your question under 8,000 characters.")
            return
        }
        sending = true
        defer { sending = false }
        if studio.selections.sessionId == nil {
            if !studio.canMutate { await studio.refresh() }
            await studio.newSession()
        }
        guard !Task.isCancelled else { return }
        guard let sessionId = studio.selections.sessionId else {
            notice("Could not start a conversation. Pull to refresh and try again.")
            return
        }
        let id = UUID()
        let userId = UUID()
        messageDates[userId] = now
        // The reply stays undated until load() supplies its server created_at.
        items.append(.user(id: userId, text: input))
        items.append(.assistant(id: id, reply: AssistantReply(stage: "queued")))
        replyId = id
        let useKit = kitRoutes && KashbotKitTransport.fits(input)
            && !(studio.supports("assistant.engine") && engineBuilding)
        if !useKit { cursor = 0 }
        kitCursor = 0
        sentAt = now
        do {
            let currentIdentity = try client.identity()
            identity = currentIdentity
            if useKit {
                let transport = KashbotKitTransport(client: client, identity: currentIdentity)
                let turnId = try await transport.startTurn(sessionId: sessionId, text: input)
                activeJobId = turnId
                if draft.trimmingCharacters(in: .whitespacesAndNewlines) == input { draft = "" }
                await streamKit(turnId: turnId)
                return
            }
            let receipt = try await client.assistantTurn(.init(requestId: UUID().uuidString.lowercased(),
                sessionId: sessionId, input: input, effort: nil,
                mode: studio.supports("assistant.engine") ? (engineBuilding ? "engine" : "ask") : nil),
                identity: currentIdentity)
            activeJobId = receipt.jobId
            if draft.trimmingCharacters(in: .whitespacesAndNewlines) == input { draft = "" }
            await stream(jobId: receipt.jobId)
        } catch is CancellationError {
            // Closing a task must not turn an accepted question into an apparent failure.
        } catch {
            if !Task.isCancelled { updateReply { $0.failed = error.localizedDescription } }
        }
    }

    func streamKit(turnId: String) async {
        defer { activeJobId = nil }
        var retryStarted: Date?
        var retryDelay: TimeInterval = 1
        while !Task.isCancelled {
            do {
                if let retryStarted, Date().timeIntervalSince(retryStarted) >= 90 {
                    lostConnection()
                    return
                }
                guard let identity else { throw MushyClientError.authentication }
                let transport = KashbotKitTransport(client: client, identity: identity)
                let page = try await transport.turnEvents(turnId: turnId, after: kitCursor, wait: 15)
                try Task.checkCancellation()
                guard page.nextAfter >= kitCursor, page.nextAfter <= 8001,
                      page.updates.allSatisfy({ $0.seq <= page.nextAfter }) else { throw MushyClientError.response }
                var finished = false
                for update in page.updates where update.seq > kitCursor {
                    updateReply { reply in
                        switch update.value {
                        case .stage(let stage): reply.stage = stage
                        case .answer(let text): reply.text = text
                        case .tool(let id, let label, let state):
                            let chip = ToolChip(id: id, label: label, state: state)
                            if let index = reply.tools.firstIndex(where: { $0.id == id }) { reply.tools[index] = chip }
                            else { reply.tools.append(chip) }
                        case .finished(let failed):
                            reply.failed = failed
                            reply.finished = true
                            finished = true
                        }
                    }
                    if finished { break }
                }
                kitCursor = page.nextAfter
                retryStarted = nil
                retryDelay = 1
                if finished {
                    if activeReply?.failed == nil { await fetchFinishedCards(turnId: turnId) }
                    return
                }
            } catch is CancellationError {
                return
            } catch {
                guard !Task.isCancelled else { return }
                guard let clientError = error as? MushyClientError,
                      case .transport = clientError else {
                    updateReply { $0.failed = error.localizedDescription; $0.finished = true }
                    return
                }
                let start = retryStarted ?? Date()
                retryStarted = start
                let remaining = 90 - Date().timeIntervalSince(start)
                guard remaining > 0 else { lostConnection(); return }
                do { try await Task.sleep(nanoseconds: UInt64(min(retryDelay, remaining) * 1_000_000_000)) }
                catch { return }
                retryDelay = min(8, retryDelay * 2)
            }
        }
    }

    func stream(jobId: String) async {
        defer { activeJobId = nil }
        var retryStarted: Date?
        var retryDelay: TimeInterval = 1
        while !Task.isCancelled {
            do {
                if let retryStarted, Date().timeIntervalSince(retryStarted) >= 90 {
                    lostConnection()
                    return
                }
                guard let identity else { throw MushyClientError.authentication }
                let page = try await client.assistantEvents(jobId, after: cursor, wait: 15, identity: identity)
                try Task.checkCancellation()
                guard page.jobId == jobId, page.next >= cursor,
                      page.events.allSatisfy({ $0.seq <= page.next }) else { throw MushyClientError.response }
                for event in page.events.sorted(by: { $0.seq < $1.seq }) { apply(event) }
                cursor = page.next
                retryStarted = nil
                retryDelay = 1
                if activeReply?.finished == true, activeReply?.failed == nil, page.status != "failed" {
                    await fetchFinishedCards(turnId: jobId)
                    return
                }
                if page.status == "completed" || page.status == "failed" {
                    updateReply { reply in
                        if page.status == "failed", reply.failed == nil {
                            reply.failed = "The assistant could not answer. Try again."
                        }
                        reply.finished = true
                    }
                    if activeReply?.failed == nil { await fetchFinishedCards(turnId: jobId) }
                    return
                }
            } catch is CancellationError {
                return
            } catch {
                guard !Task.isCancelled else { return }
                guard let clientError = error as? MushyClientError,
                      case .transport = clientError else {
                    updateReply { $0.failed = error.localizedDescription }
                    return
                }
                let start = retryStarted ?? Date()
                retryStarted = start
                let remaining = 90 - Date().timeIntervalSince(start)
                guard remaining > 0 else { lostConnection(); return }
                do { try await Task.sleep(nanoseconds: UInt64(min(retryDelay, remaining) * 1_000_000_000)) }
                catch { return }
                retryDelay = min(8, retryDelay * 2)
            }
        }
    }

    func apply(_ event: AssistantEvent) {
        guard event.seq > cursor else { return }
        cursor = event.seq
        updateReply { reply in
            switch event.payload {
            case .status(let stage): reply.stage = stage
            case .text(let delta): reply.text += delta
            case .tool(let id, _, let label, let state):
                let chip = ToolChip(id: id, label: label, state: state)
                if let index = reply.tools.firstIndex(where: { $0.id == id }) { reply.tools[index] = chip }
                else { reply.tools.append(chip) }
            case .view(let title, let panels): reply.views.append(.init(title: title, panels: panels))
            case .error(let message): reply.failed = message
            case .done(let text): reply.text = text; reply.finished = true
            case .unknown: break
            }
        }
    }

    func newConversation(studio: MushyState, keepingDraft: Bool = false) async {
        guard activeJobId == nil, !sending else { return }
        sending = true
        defer { sending = false }
        if !studio.canMutate { await studio.refresh() }
        let prior = studio.selections.sessionId
        await studio.newSession()
        guard let sessionId = studio.selections.sessionId, sessionId != prior else {
            notice("Could not start a conversation. Pull to refresh and try again.")
            return
        }
        items = []
        messageDates = [:]
        replyId = nil
        cursor = 0
        kitCursor = 0
        sentAt = nil
        if !keepingDraft { clearDraft() }
    }

    private func fetchFinishedCards(turnId: String) async {
        guard let replyId, let identity, cardsFetched.insert(replyId).inserted else { return }
        cardTurns[replyId] = (turnId, identity)
        await refreshCards(replyId: replyId)
    }

    private func refreshCards(replyId: UUID) async {
        guard let context = cardTurns[replyId] else { return }
        do {
            let page = try await client.turnCards(turnId: context.turnId, identity: context.identity)
            try Task.checkCancellation()
            updateReply(id: replyId) { $0.cards = page.cards }
        } catch {
            // Cards are optional: a failed fetch never replaces the answer or adds a banner.
            updateReply(id: replyId) { $0.cards = [] }
        }
    }

    func approve(card: AssistantCard) async {
        guard card.kind != .control, card.state == .open, !approvingCards.contains(card.id),
              let item = items.first(where: {
                  if case .assistant(_, let reply) = $0 {
                      return reply.cards.contains { $0.id == card.id && $0.cardDigest == card.cardDigest && $0.state == .open }
                  }
                  return false
              }), let context = cardTurns[item.id] else { return }
        approvingCards.insert(card.id)
        defer { approvingCards.remove(card.id) }
        do {
            try await client.approveCard(cardId: card.id, cardDigest: card.cardDigest, identity: context.identity)
            updateReply(id: item.id) { reply in
                if let index = reply.cards.firstIndex(where: { $0.id == card.id && $0.cardDigest == card.cardDigest }) {
                    reply.cards[index].state = .approved
                }
            }
        } catch MushyClientError.http(let status) where status == 409 || status == 410 {
            await refreshCards(replyId: item.id)
        } catch {
            // Leave the open card available for an explicit retry using the retained request id.
        }
    }

    private func updateReply(id targetId: UUID? = nil, _ update: (inout AssistantReply) -> Void) {
        guard let index = items.firstIndex(where: { $0.id == (targetId ?? replyId) }),
              case .assistant(let id, var reply) = items[index] else { return }
        update(&reply)
        items[index] = .assistant(id: id, reply: reply)
    }

    private func notice(_ text: String) { items.append(.notice(id: UUID(), text: text, tone: .warn)) }

    private func lostConnection() {
        updateReply {
            $0.failed = "Lost connection to the assistant. Your question was received; pull to refresh to see the answer."
        }
    }
}

enum AssistantFormat {
    static func messageTime(_ date: Date?, now: Date = Date(), locale: Locale = .current,
                            timeZone: TimeZone = .current, calendar: Calendar = .current) -> String? {
        guard let date else { return nil }
        var calendar = calendar
        calendar.timeZone = timeZone
        let formatter = DateFormatter()
        formatter.locale = locale
        formatter.calendar = calendar
        formatter.timeZone = timeZone
        formatter.setLocalizedDateFormatFromTemplate("HHmm")
        let time = formatter.string(from: date)
        if calendar.isDate(date, inSameDayAs: now) { return time }
        if let yesterday = calendar.date(byAdding: .day, value: -1, to: now),
           calendar.isDate(date, inSameDayAs: yesterday) { return "Yesterday " + time }
        formatter.setLocalizedDateFormatFromTemplate("MMMd")
        return formatter.string(from: date) + ", " + time
    }

    static func display(_ value: MushyValue?, format: String, now: Date, locale: Locale = .current) -> String {
        guard let value, value != .null else { return "Unavailable" }
        switch format {
        case "usd", "usd_signed":
            guard let cents = value.number else { return "Unavailable" }
            let formatter = NumberFormatter()
            formatter.locale = Locale(identifier: "en_US")
            formatter.numberStyle = .currency
            formatter.currencyCode = "USD"
            formatter.minimumFractionDigits = 2
            formatter.maximumFractionDigits = 2
            let amount = formatter.string(from: NSNumber(value: abs(cents) / 100)) ?? "Unavailable"
            return (cents < 0 ? "-" : (format == "usd_signed" && cents > 0 ? "+" : "")) + amount
        case "count", "percent":
            guard let number = value.number else { return "Unavailable" }
            let formatter = NumberFormatter()
            formatter.locale = Locale(identifier: "en_US")
            formatter.numberStyle = .decimal
            formatter.maximumFractionDigits = format == "count" ? 0 : 1
            let text = formatter.string(from: NSNumber(value: number)) ?? "Unavailable"
            return text + (format == "percent" ? "%" : "")
        case "time":
            guard let date = date(value, format: format) else { return "Unavailable" }
            let elapsed = max(0, now.timeIntervalSince(date))
            if elapsed < 60 { return "just now" }
            if elapsed < 3_600 { return "\(Int(elapsed / 60)) min ago" }
            if elapsed < 86_400 { return "\(Int(elapsed / 3_600)) h ago" }
            let formatter = DateFormatter()
            formatter.locale = locale
            formatter.dateStyle = .medium
            formatter.timeStyle = .short
            return formatter.string(from: date)
        case "date":
            guard let date = date(value, format: format) else { return "Unavailable" }
            let formatter = DateFormatter()
            formatter.locale = locale
            formatter.timeZone = TimeZone(secondsFromGMT: 0)
            formatter.setLocalizedDateFormatFromTemplate("MMMd")
            return formatter.string(from: date)
        default: return value.text
        }
    }

    static func date(_ value: MushyValue?, format: String) -> Date? {
        guard let value, case .string(let text) = value else { return nil }
        if format == "time" { return MushyCoding.date(text) }
        guard format == "date" else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.isLenient = false
        return formatter.date(from: text)
    }
}
