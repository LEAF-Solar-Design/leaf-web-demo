import Foundation
import LeafHFTCore

extension AppState {
    /// Fills I1's additive engine fields the engines route left out from the probes-board row with the
    /// same engine id. Never overwrites a field the engines route sent; rows for unknown engines are ignored.
    /// O(engines + rows).
    nonisolated static func mergingProbeBoard(_ board: ProbeBoardResponse, into response: EnginesResponse) -> EnginesResponse {
        guard var engines = response.engines, !board.engines.isEmpty else { return response }
        var rows: [String: ProbeRow] = [:]
        for row in board.engines where rows[row.engineId] == nil { rows[row.engineId] = row }
        for index in engines.indices {
            guard let row = rows[engines[index].engineId] else { continue }
            if engines[index].lifecycle == nil { engines[index].lifecycle = row.lifecycle }
            if engines[index].assignment == nil { engines[index].assignment = row.assignment }
            if engines[index].probeToday == nil { engines[index].probeToday = row.probeToday }
            if engines[index].live == nil { engines[index].live = row.live }
        }
        var merged = response
        merged.engines = engines
        return merged
    }
}
