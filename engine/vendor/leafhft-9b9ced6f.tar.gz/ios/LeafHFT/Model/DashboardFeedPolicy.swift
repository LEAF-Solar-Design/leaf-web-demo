import Foundation

enum DashboardFeed: CaseIterable, Hashable, Sendable {
    case status
    // Engines and control requests form one feed, fetched sequentially.
    case engines
    case probes, activity, accountHistory, exits, calibration, books, engineLab
}

enum DashboardFeedPolicy {
    static let visibleInterval: TimeInterval = 30
    static let offscreenInterval: TimeInterval = 120
    static let alwaysFeeds: Set<DashboardFeed> = [.status, .engines]

    static func feedsRead(by tab: KashbotTab) -> Set<DashboardFeed> {
        switch tab {
        case .account:
            return alwaysFeeds.union([.probes, .activity, .accountHistory, .exits, .calibration])
        case .books:
            return alwaysFeeds.union([.books])
        case .engines:
            return alwaysFeeds.union([.probes, .activity, .engineLab])
        case .lab:
            return alwaysFeeds.union([.engineLab])
        case .settings:
            return alwaysFeeds
        }
    }

    static func due(visibleTab: KashbotTab, lastFetched: [DashboardFeed: Date], now: Date) -> Set<DashboardFeed> {
        let visible = feedsRead(by: visibleTab)
        return Set(DashboardFeed.allCases.filter { feed in
            visible.contains(feed) || isStale(feed, lastFetched: lastFetched, now: now, interval: offscreenInterval)
        })
    }

    static func dueOnTabSwitch(to tab: KashbotTab, lastFetched: [DashboardFeed: Date], now: Date) -> Set<DashboardFeed> {
        Set(feedsRead(by: tab).filter {
            isStale($0, lastFetched: lastFetched, now: now, interval: visibleInterval)
        })
    }

    static func visibleWave(visibleTab: KashbotTab, lastFetched: [DashboardFeed: Date], now: Date) -> Set<DashboardFeed> {
        due(visibleTab: visibleTab, lastFetched: lastFetched, now: now).intersection(feedsRead(by: visibleTab))
    }

    static func offscreenWave(visibleTab: KashbotTab, lastFetched: [DashboardFeed: Date], now: Date) -> Set<DashboardFeed> {
        due(visibleTab: visibleTab, lastFetched: lastFetched, now: now).subtracting(feedsRead(by: visibleTab))
    }

    private static func isStale(_ feed: DashboardFeed, lastFetched: [DashboardFeed: Date], now: Date,
                                interval: TimeInterval) -> Bool {
        guard let fetchedAt = lastFetched[feed] else { return true }
        return now.timeIntervalSince(fetchedAt) >= interval
    }
}
