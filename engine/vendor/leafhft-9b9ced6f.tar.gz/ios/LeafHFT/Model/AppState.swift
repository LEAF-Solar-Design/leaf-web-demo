import Foundation
import Observation
import SwiftUI
import WidgetKit
import LeafHFTCore
import CryptoKit
import os

@MainActor @Observable final class AppState {
    enum AccountSource: Equatable {
        case phone
        case server(observedAt: Date, source: ServerAccountSnapshot.Source)
    }
    private(set) var accountSource: AccountSource = .phone
    @ObservationIgnored private var directBalanceTransportFailed = false
    @ObservationIgnored private var savedDirectAccount: (balance: AccountBalance?, balanceAt: Date?, positions: [Position], positionsAt: Date?, markedPortfolio: MarkedPortfolio?)?


    private static let unresolvedControlKey = "leafhft.unresolved-control.v1"
    private static let autoLiveIntentKey = "leafhft.auto-live-intent.v1"
    private static let enrolledKeyKey = "leafhft.enrolled-key.v1"
    private static let pauseScopeWalkStatus: KashbotStatus? = {
        let arguments = ProcessInfo.processInfo.arguments
        let trading: String
        let ownerIndex = arguments.firstIndex(of: "-LEAFHFT_OWNER_EXECUTION_WALK")
        if let ownerIndex {
            guard ownerIndex + 1 < arguments.count,
                  ["live", "dry_run", "paused"].contains(arguments[ownerIndex + 1]) else { return nil }
            trading = arguments[ownerIndex + 1]
        }
        else if arguments.contains("-LEAFHFT_PAUSED_SCOPE_WALK") { trading = "paused" }
        else if arguments.contains("-LEAFHFT_PAUSE_SCOPE_WALK") { trading = "live" }
        else { return nil }
        let paused = trading == "paused"
        let execution = ownerIndex == nil ? "null" : #"{"capabilities":{"owner_domain_control":true}}"#
        let json = """
        {"dashboard_pairing":"paired","account_binding":"bound","automated_trading":"\(trading)",
         "tenant":{"id":"4f0c2a1e-8b7d-4c3a-9e21-6d5f0b1a2c3d","runner_host":"sample-runner"},
         "lane":{"id":"9a8b7c6d-5e4f-4a3b-8c2d-1e0f9a8b7c6d","state":"\(trading)",
                  "kill_requested":\(paused),"live_enabled":\(trading == "live")},
          "request":null,"risk_regime":null,"execution":\(execution)}
        """
        return try? accountJSONDecoder().decode(KashbotStatus.self, from: Data(json.utf8))
    }()
    private struct StoredUnresolvedControl: Codable { let intent: ControlIntent; let startedAt: Date }
    private struct StoredAutoLiveIntent: Codable { let credentialIdentity: String; let requestedAt: Date }
    let fixtureMode: FixtureMode
    private(set) var feedStatuses: [Feed: FeedStatus] = [:]
    private(set) var pendingConfirmation: RiskConfirmation?
    private(set) var confirmationInProgress = false
    @ObservationIgnored private let riskAuthenticator: any RiskAuthenticator
    @ObservationIgnored private var accountRequestSequence: UInt64 = 0
    private(set) var fixtureFilesLoaded = 0
    private(set) var coldLoadTimings: LoadTimings?
    private(set) var resumeLoadTimings: LoadTimings?
    @ObservationIgnored private var loadActivation: UUID?
    private static let loadingLogger = Logger(subsystem: "com.evan.leafhft", category: "loading")
    private(set) var balance: AccountBalance?
    private(set) var markedPortfolio: MarkedPortfolio?
    private(set) var marketQuotes: [String: KalshiMarket] = [:]
    private struct MarkedMarketsResponse: Decodable {
        var markets: [KalshiMarket]?
    }
    private struct LiveMarketsResponse: Decodable {
        let board: MarketsResponse
        let marks: PositionMarksMarketsResponse

        init(from decoder: Decoder) throws {
            board = try MarketsResponse(from: decoder)
            marks = try PositionMarksMarketsResponse(from: decoder)
        }
    }
    private(set) var balanceObservedAt: Date?
    private(set) var positions: [Position] = []
    private(set) var positionsObservedAt: Date?
    private(set) var recentFills: [Fill] = []
    private(set) var liveBoard: KashbotBoardSnapshot?
    private(set) var settlements: [Settlement] = []
    private(set) var markets: [Market] = []
    @ObservationIgnored private let liveActivity: LiveActivityController?
    @ObservationIgnored private var liveBoardRevision = 0
    /// True once settlements have been read since launch; until then no board is built from the empty list.
    @ObservationIgnored private var settlementsLoaded = false
    @ObservationIgnored private let clock: () -> Date
    private(set) var fillsObservedAt: Date?
    private(set) var positionsError: String?
    private(set) var fillsError: String?
    private(set) var runnerActivity: RunnerActivity?
    private(set) var runnerActivityObservedAt: Date?
    private(set) var runnerActivityError: String?
    private(set) var exitLedger: ExitLedger?
    private(set) var exitLedgerObservedAt: Date?
    private(set) var exitLedgerError: String?
    private(set) var entryCalibration: EntryCalibration?
    private(set) var entryCalibrationObservedAt: Date?
    private(set) var entryCalibrationError: String?
    private(set) var attemptFunnel: AttemptFunnel?
    private(set) var attemptFunnelObservedAt: Date?
    private(set) var attemptFunnelError: String?
    private(set) var cash = Series(source: .phone, metric: .cash)
    private(set) var accountValue = Series(source: .phone, metric: .portfolioValue)
    private(set) var runnerCash = Series(source: .runner, metric: .cash)
    private(set) var runnerAccountValue = Series(source: .runner, metric: .portfolioValue)
    private(set) var books: MobileBooks?
    private(set) var booksObservedAt: Date?
    private(set) var restoredDashboardFeeds: Set<DashboardFeed> = []
    @ObservationIgnored private let dashboardSnapshots = DashboardSnapshotStore()
    @ObservationIgnored private var dashboardSnapshotIdentity: String?
    @ObservationIgnored private var dashboardSnapshotScopeKnown = false
    @ObservationIgnored private var dashboardSnapshotWork: Task<Void, Never>?
    @ObservationIgnored private var dashboardRestoreStarted = false
    @ObservationIgnored private var dashboardRestoreTask: Task<Void, Never>?
    private(set) var engines: EnginesResponse?
    private(set) var enginesObservedAt: Date?
    private(set) var enginesError: String?
    private(set) var peopleResult: PeopleCardsFetch?
    private(set) var peopleLoading = false
    private(set) var peopleRequestID = UUID()
    // AppState owns the fetch; caller cancellation cannot cancel it, and only the current request may settle state.
    @ObservationIgnored private var peopleTask: Task<Void, Never>?
    @ObservationIgnored private let peopleClient: (any PeopleCardsLoading)?
    @ObservationIgnored private var peopleCredentialIdentity: [Data?]?
    /// Nil when the server has no probes route (404) or has not answered yet; the Monitor card hides.
    private(set) var probeBoard: ProbeBoardResponse?
    /// The probes route answered with a body this build cannot read; the card reads "Not reported".
    private(set) var probeBoardNotReported = false
    private(set) var probeBoardObservedAt: Date?
    private(set) var probeBoardError: String?
    private(set) var engineLab: EngineLab.Response?
    private(set) var engineLabObservedAt: Date?
    private(set) var engineLabError: String?
    private(set) var engineLabLoading = false
    private(set) var engineLabSending = false
    private(set) var pendingEngineLabEvent: EngineLab.EventInput?
    private(set) var pendingRequests: [ControlRequest] = []
    private(set) var submittingControl = false
    private(set) var accountControlRevision = UUID()
    private(set) var kashbotStatus: KashbotStatus? {
        didSet {
            if oldValue != kashbotStatus { accountControlRevision = UUID() }
        }
    }
    private(set) var dashboardPairingState: DashboardPairingState = .unknown
    private(set) var accountMutationInProgress = false
    private(set) var runnerAction: KashbotRunnerAction?
    private(set) var accountSceneActive = false
    @ObservationIgnored private var runnerTask: Task<Void, Never>?
    private(set) var checkingSetupProgress = false
    private(set) var setupMessage: String?
    private(set) var setupError: String?
    private(set) var setupCredentialsPresent = false
    private(set) var enrolledKeyChanged = false
    @ObservationIgnored private var currentKeyScope: String?
    @ObservationIgnored private var setupCredentialIdentity: String?
    @ObservationIgnored private var setupBearerIdentity: Data?

    private(set) var orderCap = OrderCapState()

    func loadOrderCap() async {
        guard !orderCap.loading, !orderCap.saving, !fixtureMode.enabled else { return }
        orderCap.loading = true
        orderCap.error = nil
        defer { orderCap.loading = false }
        do {
            let identity = try dashboard.snapshotIdentity()
            if orderCap.identity != identity { orderCap.value = nil }
            orderCap.identity = identity
            let value = try await dashboard.orderCap()
            try Task.checkCancellation()
            guard identity == (try? dashboard.snapshotIdentity()) else {
                orderCap = OrderCapState()
                return
            }
            orderCap.value = value
        } catch OrderCapError.rejected(let message) {
            orderCap.error = message
        } catch {
            if !Task.isCancelled { orderCap.error = dashboardMessage(error) }
        }
    }

    func saveOrderCap(_ fraction: Double, expectedRevision: OrderCapRevision) async {
        guard !orderCap.loading, !orderCap.saving, !fixtureMode.enabled,
              let current = orderCap.value else { return }
        guard current.revision == expectedRevision else {
            orderCap.error = "Max per trade changed. Review the current value before saving."
            return
        }
        guard fraction.isFinite, (current.range.min...current.range.max).contains(fraction) else {
            orderCap.error = "Value is outside the allowed range."
            return
        }
        orderCap.saving = true
        orderCap.error = nil
        defer { orderCap.saving = false }
        do {
            let identity = try dashboard.snapshotIdentity()
            guard orderCap.identity == identity else {
                orderCap.saving = false
                await loadOrderCap()
                orderCap.error = "Account changed. Review Max per trade before saving."
                return
            }
            let revision = try await dashboard.putOrderCap(maxOrderFraction: fraction, expectedRevision: expectedRevision)
            guard identity == (try? dashboard.snapshotIdentity()) else {
                orderCap = OrderCapState()
                return
            }
            orderCap.value = OrderCapResponse(maxOrderFraction: fraction, revision: revision, source: "set", range: current.range)
        } catch OrderCapError.conflict {
            orderCap.saving = false
            await loadOrderCap()
            orderCap.error = orderCap.error.map { "Max per trade changed. " + $0 }
                ?? "Max per trade changed. Showing the current value; review it before saving."
        } catch OrderCapError.rejected(let message) {
            orderCap.error = message
        } catch {
            if !Task.isCancelled { orderCap.error = dashboardMessage(error) }
        }
    }

    func canRunAccountAction(_ action: KashbotRunnerAction) -> Bool {
        if action == .pause { return canPause }
        return accountSceneActive && (isOwnerExecution || setupCredentialsPresent) && !fixtureMode.enabled &&
        !accountMutationInProgress && !checkingSetupProgress &&
        (kashbotStatus?.allows(action) == true || (action == .startLive && canResume))
    }
    var controlOutcomeUnknown: Bool { uncertainIntent != nil }
    @ObservationIgnored private var requestFirstSeen: [String: Date] = [:]
    @ObservationIgnored private var uncertainIntent: ControlIntent?
    @ObservationIgnored private var uncertainSince: Date?
    @ObservationIgnored private var fixtureControlCount = 0
    @ObservationIgnored private var fixtureSettledCounts: [String: Int] = [:]
    /// Kinds the fixture walk holds at requested until `settleFixtureControls()`, so both edges show.
    private static let fixtureLifecycleKinds: Set<ControlKind> = [.probe, .halt, .breaker]
    private(set) var kalshiError: String?
    private(set) var booksError: String?
    private(set) var accountHistoryError: String?
    private(set) var storeError: String?
    @ObservationIgnored private var kalshiTask: Task<Void, Never>?
    @ObservationIgnored private var marketsTask: Task<Void, Never>?
    @ObservationIgnored private(set) var kalshiPollInFlight = false
    @ObservationIgnored private var marketsPollInFlight = false
    static let marketsRefreshInterval: UInt64 = 10_000_000_000
    var visibleTab: KashbotTab = .account
    @ObservationIgnored private var dashboardLastFetched: [DashboardFeed: Date] = [:]
    @ObservationIgnored private var dashboardFetchGeneration = UUID()
    @ObservationIgnored private var dashboardFeedsInFlight: Set<DashboardFeed> = []
    @ObservationIgnored private var dashboardTabTasks: [UUID: Task<Void, Never>] = [:]
    @ObservationIgnored private var dashboardTask: Task<Void, Never>?
    @ObservationIgnored private lazy var kalshi = KalshiClient(fixtureMode: fixtureMode)
    @ObservationIgnored private lazy var dashboard = DashboardClient(fixtureMode: fixtureMode)
    @ObservationIgnored private var store: ObservationStore?
    @ObservationIgnored private var restored = false

    init(fixtureMode: FixtureMode = .current, bundle: Bundle = .main, now: Date = Date(),
         dashboard: DashboardClient? = nil, peopleClient: (any PeopleCardsLoading)? = nil,
         liveActivity: LiveActivityController? = nil, kalshi: KalshiClient? = nil,
         clock: @escaping () -> Date = Date.init, riskAuthenticator: (any RiskAuthenticator)? = nil) {
        self.fixtureMode = fixtureMode
        self.riskAuthenticator = riskAuthenticator ?? DeviceOwnerRiskAuthenticator(fixtureMode: fixtureMode)
        self.liveActivity = liveActivity
        self.peopleClient = peopleClient
        self.clock = clock
        if let dashboard { self.dashboard = dashboard }
        if let kalshi { self.kalshi = kalshi }
        guard fixtureMode.enabled else {
            if let data = UserDefaults.standard.data(forKey: Self.unresolvedControlKey),
               let stored = try? JSONDecoder().decode(StoredUnresolvedControl.self, from: data) {
                if UnresolvedControlPolicy.isExpired(since: stored.startedAt, now: now) {
                    UserDefaults.standard.removeObject(forKey: Self.unresolvedControlKey)
                } else {
                    uncertainIntent = stored.intent
                    uncertainSince = stored.startedAt
                }
            }
            return
        }
        do {
            let corpus = try FixtureCorpus(bundle: bundle)
            // Keep the account-corpus readback stable; market quotes supplement that corpus.
            fixtureFilesLoaded = corpus.data.keys.filter { $0 != "markets" }.count
            let statusFixture = #"""
            {"dashboard_pairing":"paired","account_binding":"unbound","automated_trading":"not_configured",
             "tenant":null,"lane":null,
             "risk_regime":{"id":"owner","label":"risky_batman"}}
            """#
            kashbotStatus = try accountJSONDecoder().decode(KashbotStatus.self, from: Data(statusFixture.utf8))
            if let status = Self.pauseScopeWalkStatus {
                kashbotStatus = status
                dashboardPairingState = status.dashboardPairing
                updateSetupMessage()
            }
            books = try corpus.decode("books", as: MobileBooks.self)
            engines = try corpus.decode("engines", as: EnginesResponse.self)
            probeBoard = try corpus.decode("probes", as: ProbeBoardResponse.self)
            probeBoardObservedAt = now
            mergeProbeBoard()
            if !ProcessInfo.processInfo.arguments.contains("-LEAFHFT_LAB_OFFLINE") {
                engineLab = try EngineLab.decodeResponse(Data(EngineLab.previewResponseJSON.utf8))
                engineLabObservedAt = now
            } else { engineLabError = "Engine Lab is offline. Showing bundled fallback only." }
            if ProcessInfo.processInfo.arguments.contains("-LEAFHFT_LAB_CONTROLS") {
                let fixture = #"""
                {"engine_id":"darkhorse","name":"Darkhorse","host":"sample-runner",
                 "description":"Host-trained cheap-side models","darkhorse":{"available":true,"pending":false,"stale":false,
                   "models":[{"offset":120,"sha":"fixture-model-120","trained_threshold":0.6,"score_p99":0.9,"score_threshold":0.65},
                             {"offset":45,"sha":"fixture-model-45","trained_threshold":0.55,"score_p99":0.95,"score_threshold":0.6}]},
                 "configuration":{"global":{"enabled":false,"policy":{"base_count":0.5,"max_mult":10,"score_threshold_120":0.6,"score_threshold_45":0.55}},
                   "accounts":[{"account_id":"sample-main","override":{"enabled":false,"policy":{"base_count":0.1,"max_mult":2,"score_threshold_120":0.65,"score_threshold_45":0.6}},
                     "effective":{"enabled":false,"policy":{"base_count":0.1,"max_mult":2,"score_threshold_120":0.65,"score_threshold_45":0.6}},
                     "revision":"darkhorse-fixture-r1","freshness":"fresh"}]}}
                """#
                engines?.engines?.append(try accountJSONDecoder().decode(Engine.self, from: Data(fixture.utf8)))
            }
            let arguments = ProcessInfo.processInfo.arguments
            if let flag = arguments.firstIndex(of: "-LEAFHFT_ENGINE_COUNT"),
               arguments.indices.contains(flag + 1), let requested = Int(arguments[flag + 1]),
               let originals = engines?.engines, !originals.isEmpty {
                let count = min(64, max(1, requested))
                let states = ["probe", "graduated", "unknown", "halted", "retired"]
                engines?.engines = try (0..<count).map { index in
                    var engine = originals[index % originals.count]
                    let suffix = String(format: "%03d", index + 1)
                    engine.engineId += "-" + suffix
                    engine.name = (engine.name ?? engine.engineId) + " " + suffix
                    let lifecycle = """
                    {"state":"\(states[index % states.count])","stop_reasons":\(index % 5 == 3 ? "[\"Fixture halt\"]" : "[]")}
                    """
                    engine.lifecycle = try accountJSONDecoder().decode(EngineLifecycle.self, from: Data(lifecycle.utf8))
                    engine.pnl?.netCents = Double(count - index) * 100
                    return engine
                }
            }
            recentFills = try corpus.decode("fills", as: FillsResponse.self).fills ?? []
            positions = try corpus.decode("positions", as: PositionsResponse.self).marketPositions ?? []
            runnerActivity = try corpus.decode("activity", as: RunnerActivity.self)
            exitLedger = try corpus.decode("exits", as: ExitLedger.self)
            exitLedgerError = nil
            do {
                entryCalibration = try corpus.decode("calibration", as: EntryCalibration.self)
                entryCalibrationObservedAt = now
                entryCalibrationError = nil
            } catch { entryCalibrationError = "Calibration is unavailable for this paired account." }
            do {
                attemptFunnel = try corpus.decode("attempt-funnel", as: AttemptFunnel.self)
                attemptFunnelObservedAt = now
                attemptFunnelError = nil
            } catch { attemptFunnelError = "Attempt funnel is unavailable for this paired account." }
            settlements = try corpus.decode("settlements", as: SettlementsResponse.self).settlements ?? []
            markets = try corpus.decode("markets", as: MarketsResponse.self).markets ?? []
            booksObservedAt = now
            enginesObservedAt = now
            positionsObservedAt = now
            fillsObservedAt = now
            runnerActivityObservedAt = now
            exitLedgerObservedAt = now
            for feed in [Feed.positions, .fills, .markets, .settlements, .books, .engines, .probes, .activity, .exits] {
                recordFeedSuccess(feed, now: now)
            }
            if entryCalibration != nil { recordFeedSuccess(.calibration, now: now) }
            if attemptFunnel != nil { recordFeedSuccess(.attemptFunnel, now: now) }
            if engineLab != nil { recordFeedSuccess(.engineLab, now: now) }
            guard !fixtureMode.noKey else {
                kalshiError = "Import your runner key in Settings."
                recordFeedFailure(.balance, error: kalshiError!, now: now)
                return
            }
            let latest = try corpus.decode("balance", as: AccountBalance.self)
            balance = latest
            balanceObservedAt = now
            recordFeedSuccess(.balance, now: now)
            // Stable values from the balance fixture, dated relative to this launch.
            if let markets = try? corpus.decode("markets", as: MarkedMarketsResponse.self).markets {
                for market in markets { marketQuotes[market.ticker] = market }
            }
            if let cashCents = latest.balance {
                markedPortfolio = PositionMarks.marked(cashCents: cashCents, positions: positions,
                                                       markets: marketQuotes, now: now)
            }
            liveBoard = KashbotLiveStateBuilder.build(balance: balance, positions: positions,
                markets: markets, settlements: settlements, now: now)
            // Three pairs ensure each frozen HistoryRange selects different data.
            let ages: [TimeInterval] = [14 * 86400, 14 * 86400 - 60, 3 * 86400, 3 * 86400 - 60, 120, 60]
            for age in ages {
                let observation = AccountObservation(capturedAt: now.addingTimeInterval(-age), source: .phone,
                    cashCents: latest.balance, portfolioValueCents: markedPortfolio?.totalCents ?? latest.accountValue?.cents.rawValue)
                cash.merge(observation)
                accountValue.merge(observation)
            }
        } catch { kalshiError = "Fixture data could not be loaded. Live access remains disabled." }
    }

    func recordFeedSuccess(_ feed: Feed, now: Date? = nil) {
        let observed = now ?? clock()
        feedStatuses[feed] = FeedStatus(observedAt: observed, attemptedAt: observed, lastError: nil)
    }

    func recordFeedFailure(_ feed: Feed, error: String, now: Date? = nil) {
        var status = feedStatuses[feed] ?? FeedStatus()
        status.attemptedAt = now ?? clock()
        status.lastError = error
        feedStatuses[feed] = status
    }

    private func restoreFeedObservation(_ feed: Feed, observedAt: Date) {
        var status = feedStatuses[feed] ?? FeedStatus()
        status.observedAt = observedAt
        feedStatuses[feed] = status
    }

    func requestRaisesRisk(title: String, detail: String, actionLabel: String,
                           perform: @escaping @MainActor () async -> Void) {
        pendingConfirmation = RiskConfirmation(title: title, detail: detail, actionLabel: actionLabel, perform: perform)
    }

    func confirmPending() async {
        guard !confirmationInProgress, let confirmation = pendingConfirmation else { return }
        confirmationInProgress = true
        defer { confirmationInProgress = false }
        let authenticated = await riskAuthenticator.authenticate(reason: confirmation.title)
        guard pendingConfirmation?.id == confirmation.id else { return }
        pendingConfirmation = nil
        if authenticated { await confirmation.perform() }
    }

    func cancelPending() { pendingConfirmation = nil }

    var balanceStale: Bool { balanceObservedAt.map { transportStale(observedAt: $0, now: Date()) } ?? true }

    func sceneChanged(_ phase: ScenePhase) {
        accountSceneActive = phase == .active
        guard !fixtureMode.enabled else { return }
        guard phase == .active else {
            loadActivation = nil
            runnerTask?.cancel()
            kashbotStatus = nil
            kalshiTask?.cancel()
            marketsTask?.cancel()
            marketsTask = nil
            dashboardTask?.cancel()
            for task in dashboardTabTasks.values { task.cancel() }
            dashboardTabTasks.removeAll()
            dashboardLastFetched.removeAll()
            dashboardFetchGeneration = UUID()
            kalshiTask = nil
            dashboardTask = nil
            return
        }
        if kalshiTask == nil && dashboardTask == nil {
            loadActivation = UUID()
            let activatedAt = clock()
            if coldLoadTimings == nil {
                coldLoadTimings = LoadTimings(kind: .cold, activatedAt: activatedAt)
            } else {
                resumeLoadTimings = LoadTimings(kind: .resume, activatedAt: activatedAt)
            }
        }
        if kalshiTask == nil {
            kalshiTask = Task { [weak self] in
                await self?.restore()
                while !Task.isCancelled {
                    await self?.pollKalshi()
                    do { try await Task.sleep(nanoseconds: 60_000_000_000) } catch { break }
                }
            }
        }
        if marketsTask == nil {
            marketsTask = Task { [weak self] in
                while !Task.isCancelled {
                    do { try await Task.sleep(nanoseconds: Self.marketsRefreshInterval) } catch { break }
                    await self?.refreshLiveMarketsOnce()
                }
            }
        }
        if dashboardTask == nil {
            dashboardTask = Task { [weak self] in
                await self?.pollDashboard(forceAll: true)
                do { try await Task.sleep(nanoseconds: 30_000_000_000) } catch { return }
                while !Task.isCancelled {
                    await self?.pollDashboard()
                    do { try await Task.sleep(nanoseconds: 30_000_000_000) } catch { break }
                }
            }
        }
    }

    func refreshEngines() async {
        guard !fixtureMode.enabled else {
            enginesObservedAt = Date()
            return
        }
        await pollEngines()
        await pollProbes()
        await refreshEngineLab(resetPeople: false)
    }

    func refreshDashboard() async {
        guard !fixtureMode.enabled else { settleFixtureControls(); return }
        invalidatePeople()
        await pollDashboard(forceAll: true)
    }

    func refreshEngineLab(resetPeople: Bool = true) async {
        if resetPeople { invalidatePeople() }
        guard !fixtureMode.enabled, !engineLabLoading else { return }
        let loadStartedAt = clock()
        let activation = loadActivation
        engineLabLoading = true
        dashboardFeedsInFlight.insert(.engineLab)
        let generation = dashboardFetchGeneration
        defer {
            engineLabLoading = false
            dashboardFeedsInFlight.remove(.engineLab)
            if !Task.isCancelled, generation == dashboardFetchGeneration { dashboardLastFetched[.engineLab] = clock() }
            recordLoadLive(id: "engineLab", startedAt: loadStartedAt, finishedAt: clock(),
                           failed: engineLabError != nil, activation: activation)
        }
        let eventsAtStart = Set(engineLab?.events.map(\.id) ?? [])
        do {
            var latest = try await dashboard.engineLab()
            try Task.checkCancellation()
            // Preserve events acknowledged while this GET was in flight.
            for event in engineLab?.events ?? [] where !latest.events.contains(where: { $0.id == event.id }) {
                if !eventsAtStart.contains(event.id) { latest.events.append(event) }
            }
            engineLab = latest
            if let pending = pendingEngineLabEvent,
               latest.events.contains(where: { $0.clientRequestId.lowercased() == pending.clientRequestId.lowercased() }) {
                pendingEngineLabEvent = nil
            }
            disableShadowEngineControls()
            engineLabObservedAt = Date()
            engineLabError = nil
            recordFeedSuccess(.engineLab)
        } catch {
            guard !Task.isCancelled else { return }
            engineLabError = engineLab == nil ? "Live Engine Lab unavailable. " + dashboardMessage(error) :
                "Could not refresh Engine Lab. Showing the last fetched evidence. " + dashboardMessage(error)
            recordFeedFailure(.engineLab, error: engineLabError!)
        }
    }

    func loadPeople() async {
        guard !fixtureMode.enabled else { return }
        let task = peopleTask ?? startPeopleLoad()
        await task.value
    }

    private func startPeopleLoad() -> Task<Void, Never> {
        let requestID = peopleRequestID
        peopleLoading = true
        peopleResult = nil
        let task = Task { [self] in
            let result = await (peopleClient ?? dashboard).people()
            guard peopleRequestID == requestID else { return }
            peopleResult = result
            switch result {
            case .success: recordFeedSuccess(.people)
            case .notAuthorized: recordFeedFailure(.people, error: "People cards are not authorized.")
            case let .unavailable(error): recordFeedFailure(.people, error: dashboardMessage(error))
            }
            peopleLoading = false
            peopleTask = nil
        }
        peopleTask = task
        return task
    }

    private func invalidatePeople() {
        let wasLoading = peopleTask != nil
        peopleTask?.cancel()
        peopleTask = nil
        peopleRequestID = UUID()
        peopleResult = nil
        peopleLoading = false
        if wasLoading, !fixtureMode.enabled { _ = startPeopleLoad() }
    }

    func submitEngineLabEvent(_ input: EngineLab.EventInput) async -> String? {
        guard !engineLabSending else { return "An Engine Lab note is already being sent." }
        guard engineLab != nil else { return "Connect to Engine Lab before posting." }
        guard !fixtureMode.enabled else { return "Posting is disabled in fixture mode." }
        if let pending = pendingEngineLabEvent, pending != input {
            return "Another note has an unknown result. Reopen that candidate's note and retry it first."
        }
        pendingEngineLabEvent = input
        engineLabSending = true
        defer { engineLabSending = false }
        do {
            let event = try await dashboard.engineLabEvent(input)
            if engineLab?.events.contains(where: { $0.id == event.id }) != true { engineLab?.events.insert(event, at: 0) }
            pendingEngineLabEvent = nil
            return nil
        } catch {
            switch error as? DashboardClientError {
            case .http(400), .http(409), .http(422):
                pendingEngineLabEvent = nil
                return "The note was declined. Check its content before retrying. Your draft is kept."
            case .unauthorized, .forbidden, .noCredential:
                pendingEngineLabEvent = nil
                return "Pair this device to post to Engine Lab. Your draft is kept."
            default: return "The note could not be confirmed. Retry uses the same request ID to prevent duplicates. Your draft is kept."
            }
        }
    }

    func refreshAccountSetup() async {
        invalidatePeople()
        guard !fixtureMode.enabled, !accountMutationInProgress, !checkingSetupProgress else { return }
        checkingSetupProgress = true
        defer { checkingSetupProgress = false }
        await pollBindingStatus()
    }

    static func ownerCredentialSetup(isOwnerExecution: Bool, bearer: Data?) -> (identity: String, bearerIdentity: Data)? {
        guard isOwnerExecution, let bearer, !bearer.isEmpty else { return nil }
        let digest = Data(SHA256.hash(data: bearer))
        return ("owner:" + digest.map { String(format: "%02x", $0) }.joined(), digest)
    }

    func refreshSetupCredentials() {
        defer { reconcileEnrolledKey() }
        guard !fixtureMode.enabled else { setupCredentialsPresent = false; return }
        let snapshotBearer = try? KeychainStore().load(account: KeychainStore.dashboardTokenAccount)
        updateDashboardSnapshotScope(snapshotBearer.flatMap { bytes in
            bytes.isEmpty ? nil : SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined()
        })
        var kalshiKeyPresent = false
        defer {
            if !kalshiKeyPresent && PortfolioWidgetSnapshotStore.clear() {
                WidgetCenter.shared.reloadTimelines(ofKind: "KashbotPortfolioWidget")
            }
            if !kalshiKeyPresent {
                liveBoardRevision += 1
                liveBoard = nil
                settlements = []
                settlementsLoaded = false
                markets = []
                KashbotBoardStore.clear()
                reloadLiveBoardWidgets()
                liveActivity?.endAll()
            }
        }
        do {
            let store = KeychainStore()
            let key = try store.load(account: KeychainStore.keyDERAccount)
            let id = try store.load(account: KeychainStore.keyIDAccount)
            let bearer = try store.load(account: KeychainStore.dashboardTokenAccount)
            let peopleIdentity = [key, id, bearer].map { $0.map { Data(SHA256.hash(data: $0)) } }
            if peopleCredentialIdentity != peopleIdentity {
                invalidatePeople()
                peopleCredentialIdentity = peopleIdentity
            }
            kalshiKeyPresent = key != nil && id?.isEmpty == false
            if let owner = Self.ownerCredentialSetup(isOwnerExecution: isOwnerExecution, bearer: bearer) {
                // Domain controls need the device bearer and presence key, not lane enrollment.
                setupCredentialIdentity = owner.identity
                setupBearerIdentity = owner.bearerIdentity
                setupCredentialsPresent = true
                return
            }
            guard let key, let id, kalshiKeyPresent,
                  let bearer, !bearer.isEmpty else {
                currentKeyScope = nil
                setupCredentialsPresent = false
                UserDefaults.standard.removeObject(forKey: Self.autoLiveIntentKey)
                kashbotStatus = nil
                dashboardPairingState = .unknown
                setupCredentialIdentity = nil
                setupBearerIdentity = nil
                setupMessage = nil
                setupError = nil
                return
            }
            let publicDER = try KalshiSigner(pkcs1DER: key).publicKeyDER()
            currentKeyScope = (try? BindingChallenge.normalizedKeyID(String(decoding: id, as: UTF8.self))).map {
                $0 + ":" + SHA256.hash(data: publicDER).map { String(format: "%02x", $0) }.joined()
            }
            // Only a digest is persisted. No key or bearer bytes leave the Keychain here.
            let identity = SHA256.hash(data: bearer + Data([0]) + id + Data([0]) + publicDER)
                .map { String(format: "%02x", $0) }.joined()
            if setupCredentialIdentity != identity {
                UserDefaults.standard.removeObject(forKey: Self.autoLiveIntentKey)
                kashbotStatus = nil
                dashboardPairingState = .unknown
                setupMessage = nil
                setupError = nil
            }
            setupCredentialIdentity = identity
            setupBearerIdentity = Data(SHA256.hash(data: bearer))
            setupCredentialsPresent = true
        } catch {
            invalidatePeople()
            peopleCredentialIdentity = nil
            currentKeyScope = nil
            setupCredentialsPresent = false
            UserDefaults.standard.removeObject(forKey: Self.autoLiveIntentKey)
            setupCredentialIdentity = nil
            setupBearerIdentity = nil
            kashbotStatus = nil
            dashboardPairingState = .unknown
            setupMessage = nil
            setupError = nil
        }
    }

    func setupDryRun(startLiveWhenReady: Bool = false) async {
        guard !accountMutationInProgress else { return }
        guard canSetupDryRun else { return }
        accountRequestSequence += 1
        let sequence = accountRequestSequence
        accountMutationInProgress = true
        setupError = nil
        setupMessage = "Checking dashboard binding…"
        let credentialIdentity = setupCredentialIdentity
        if let credentialIdentity, startLiveWhenReady {
            let intent = StoredAutoLiveIntent(credentialIdentity: credentialIdentity, requestedAt: Date())
            if let data = try? JSONEncoder().encode(intent) {
                UserDefaults.standard.set(data, forKey: Self.autoLiveIntentKey)
            }
        } else {
            UserDefaults.standard.removeObject(forKey: Self.autoLiveIntentKey)
        }
        defer { if sequence == accountRequestSequence { accountMutationInProgress = false } }
        do {
            // Existing enrolled lanes never enter the private-key enrollment path.
            var status = try await dashboard.kashbotStatus()
            try Task.checkCancellation()
            guard sequence == accountRequestSequence, credentialIdentity == setupCredentialIdentity, accountSceneActive else {
                throw AccountEnrollmentError.scopeChanged
            }
            if status.isBound && !status.needsEnrollment {
                kashbotStatus = status
                reconcileEnrolledKey()
                dashboardPairingState = status.dashboardPairing
                try await finishSetupDryRun(status, identity: credentialIdentity)
                try await finishAutoLiveIfRequested(identity: credentialIdentity)
                updateSetupMessage()
                return
            }
            let store = KeychainStore()
            guard let der = try store.load(account: KeychainStore.keyDERAccount),
                  let idData = try store.load(account: KeychainStore.keyIDAccount),
                  let keyID = String(data: idData, encoding: .utf8),
                  let bearerData = try store.load(account: KeychainStore.dashboardTokenAccount),
                  let bearer = String(data: bearerData, encoding: .utf8), !bearer.isEmpty else {
                throw DashboardClientError.noCredential
            }
            // Keep every request in this attempt on the same device principal.
            let dashboard = DashboardClient(fixtureMode: fixtureMode, token: { bearer })
            func isCurrent() -> Bool {
                guard sequence == accountRequestSequence else { return false }
                refreshSetupCredentials()
                return sequence == accountRequestSequence && accountSceneActive && credentialIdentity != nil && credentialIdentity == setupCredentialIdentity
            }
            let enrollment = AccountEnrollmentFlow(
                readStatus: { try await dashboard.kashbotStatus() },
                readKey: { try await dashboard.enrollmentKey() },
                submit: { try await dashboard.enrollAccount($0) })
            let signer = try KalshiSigner(pkcs1DER: der)
            status = try await dashboard.kashbotStatus()
            try Task.checkCancellation()
            guard isCurrent() else { throw AccountEnrollmentError.scopeChanged }
            if !status.isBound {
                setupMessage = "Binding this account…"
                let challenge = try await dashboard.bindingChallenge()
                try Task.checkCancellation()
                guard isCurrent() else { throw AccountEnrollmentError.scopeChanged }
                let request = try signer.bindingRequest(challenge: challenge, keyID: keyID)
                _ = try await dashboard.bind(request)
                try Task.checkCancellation()
                guard isCurrent() else { throw AccountEnrollmentError.scopeChanged }
                status = try await dashboard.kashbotStatus()
            }
            try Task.checkCancellation()
            guard isCurrent() else { throw AccountEnrollmentError.scopeChanged }
            guard status.isBound, let tenant = status.tenant, let lane = status.lane else { throw DashboardClientError.decoding }
            kashbotStatus = status
            reconcileEnrolledKey()
            dashboardPairingState = status.dashboardPairing
            // The tenant and credential identify the enrollment across bearer rotation.
            let scope = try BindingChallenge.normalizedKeyID(keyID) + ":" +
                SHA256.hash(data: signer.publicKeyDER()).map { String(format: "%02x", $0) }.joined()
            let enrolledStatus = try await enrollment.enroll(keyID: keyID, privateDER: der, scope: scope,
                expectedTenantID: tenant.id, expectedLaneID: lane.id, isCurrent: isCurrent,
                progress: { if sequence == self.accountRequestSequence { self.setupMessage = $0 } })
            guard sequence == accountRequestSequence else { return }
            kashbotStatus = enrolledStatus
            let record = EnrolledKeyRecord(scope: scope, tenantId: tenant.id, laneId: lane.id)
            UserDefaults.standard.set(try JSONEncoder().encode(record), forKey: Self.enrolledKeyKey)
            reconcileEnrolledKey()
            guard let enrolled = kashbotStatus else { throw DashboardClientError.decoding }
            try await finishSetupDryRun(enrolled, identity: credentialIdentity)
            try await finishAutoLiveIfRequested(identity: credentialIdentity)
            updateSetupMessage()
        } catch {
            guard sequence == accountRequestSequence, credentialIdentity == setupCredentialIdentity else { return }
            setupMessage = nil
            if startLiveWhenReady && kashbotStatus?.automatedTrading == .dryRun {
                setupError = "Dry run passed. Live start is waiting and will retry automatically."
            } else if case AccountEnrollmentError.retryLimit = error {
                setupError = "Setup is still unconfirmed after three attempts. Check progress or contact support before trying another enrollment."
            } else {
                setupError = "Setup could not be confirmed. Your saved entries are unchanged. Retry to check the result with the same request."
            }
            if error as? DashboardClientError == .unauthorized { dashboardPairingState = .unpaired; kashbotStatus = nil }
        }
    }

    private func finishSetupDryRun(_ status: KashbotStatus, identity: String?) async throws {
        let sequence = accountRequestSequence
        guard !status.isOwnerExecution else { return }
        guard let identity, let tenant = status.tenant, let lane = status.lane else {
            throw AccountRunnerControlError.scopeChanged
        }
        let store = KeychainStore()
        guard let tokenData = try store.load(account: KeychainStore.dashboardTokenAccount),
              let bearer = String(data: tokenData, encoding: .utf8), !bearer.isEmpty,
              Data(SHA256.hash(data: tokenData)) == setupBearerIdentity else {
            throw DashboardClientError.noCredential
        }
        let client = DashboardClient(fixtureMode: fixtureMode, token: { bearer })
        @MainActor func currentIdentity() -> String? {
            guard sequence == accountRequestSequence, accountSceneActive, setupCredentialIdentity == identity,
                  kashbotStatus?.tenant?.id == tenant.id, kashbotStatus?.lane?.id == lane.id,
                  (try? store.load(account: KeychainStore.dashboardTokenAccount)) == tokenData else { return nil }
            return identity
        }
        setupMessage = "Preparing a dry run and waiting for confirmation. No live orders."
        let flow = AccountRunnerControlFlow(readStatus: { try await client.kashbotStatus() },
            submit: { action, requestID in
                guard action == .startDryRun else { throw AccountRunnerControlError.unavailable }
                _ = try await client.startDryRun(clientRequestId: requestID)
            }, credentialIdentity: currentIdentity)
        let result = try await flow.perform(.startDryRun, expectedTenantID: tenant.id, expectedLaneID: lane.id)
        try Task.checkCancellation()
        guard currentIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
        kashbotStatus = result
        reconcileEnrolledKey()
        dashboardPairingState = result.dashboardPairing
    }

    private func finishAutoLiveIfRequested(identity: String?) async throws {
        guard let identity,
              let data = UserDefaults.standard.data(forKey: Self.autoLiveIntentKey),
              let intent = try? JSONDecoder().decode(StoredAutoLiveIntent.self, from: data),
              intent.credentialIdentity == identity else { return }
        if enrolledKeyChanged || AutoLiveIntentPolicy.isExpired(requestedAt: intent.requestedAt, now: Date()) ||
            kashbotStatus?.isOwnerExecution == true || kashbotStatus?.automatedTrading == .live {
            UserDefaults.standard.removeObject(forKey: Self.autoLiveIntentKey)
            return
        }
        guard let status = kashbotStatus, status.allows(.startLive),
              let tenant = status.tenant, let lane = status.lane else { return }
        let revision = accountControlRevision
        UserDefaults.standard.removeObject(forKey: Self.autoLiveIntentKey)
        requestRaisesRisk(title: "Start trading", detail: "Dry run passed. Enable live trading for this account.",
                          actionLabel: "Start trading") { [weak self] in
            guard let self, !self.accountMutationInProgress, self.accountSceneActive,
                  self.setupCredentialIdentity == identity, self.accountControlRevision == revision else { return }
            let sequence = self.beginAccountMutation(.startLive)
            defer { self.finishAccountMutation(sequence: sequence) }
            do {
                let store = KeychainStore()
                guard let tokenData = try store.load(account: KeychainStore.dashboardTokenAccount),
                      let bearer = String(data: tokenData, encoding: .utf8), !bearer.isEmpty,
                      Data(SHA256.hash(data: tokenData)) == self.setupBearerIdentity else {
                    throw DashboardClientError.noCredential
                }
                let client = DashboardClient(fixtureMode: self.fixtureMode, token: { bearer })
                @MainActor func currentIdentity() -> String? {
                    guard sequence == self.accountRequestSequence, self.accountSceneActive,
                          self.setupCredentialIdentity == identity,
                          self.kashbotStatus?.tenant?.id == tenant.id, self.kashbotStatus?.lane?.id == lane.id,
                          (try? store.load(account: KeychainStore.dashboardTokenAccount)) == tokenData else { return nil }
                    return identity
                }
                self.setupMessage = "Dry run confirmed. Starting live trading…"
                let flow = AccountRunnerControlFlow(readStatus: { try await client.kashbotStatus() },
                    submit: { action, requestID in
                        guard action == .startLive else { throw AccountRunnerControlError.unavailable }
                        _ = try await client.startLive(clientRequestId: requestID)
                    }, credentialIdentity: currentIdentity)
                let result = try await flow.perform(.startLive, expectedTenantID: tenant.id, expectedLaneID: lane.id)
                try Task.checkCancellation()
                guard currentIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
                self.acceptAccountActionResult(result, sequence: sequence)
            } catch {
                guard sequence == self.accountRequestSequence else { return }
                self.setupMessage = nil
                self.setupError = "The runner action could not be confirmed. Check progress for a fresh status before trying again."
            }
        }
    }

    func runAccountAction(_ action: KashbotRunnerAction, confirmedRevision: UUID? = nil) {
        if action == .startLive, !isOwnerExecution {
            guard confirmedRevision == accountControlRevision, canRunAccountAction(action) else { return }
            requestRaisesRisk(title: "Start trading", detail: "Enable live trading for this account.", actionLabel: "Start trading") { [weak self] in
                self?.performAccountAction(action, confirmedRevision: confirmedRevision)
            }
            return
        }
        performAccountAction(action, confirmedRevision: confirmedRevision)
    }

    func beginAccountMutation(_ action: KashbotRunnerAction) -> UInt64 {
        accountRequestSequence += 1
        if action == .pause {
            runnerTask?.cancel()
            cancelPending()
            UserDefaults.standard.removeObject(forKey: Self.autoLiveIntentKey)
        }
        accountMutationInProgress = true
        runnerAction = action
        return accountRequestSequence
    }

    func finishAccountMutation(sequence: UInt64) {
        guard sequence == accountRequestSequence else { return }
        accountMutationInProgress = false
        runnerAction = nil
        runnerTask = nil
    }

    @discardableResult
    func acceptAccountActionResult(_ status: KashbotStatus, sequence: UInt64) -> Bool {
        guard sequence == accountRequestSequence else { return false }
        kashbotStatus = status
        reconcileEnrolledKey()
        dashboardPairingState = status.dashboardPairing
        updateSetupMessage()
        return true
    }

    func performAccountAction(_ action: KashbotRunnerAction, confirmedRevision: UUID? = nil) {
        guard action == .pause || confirmedRevision == accountControlRevision else { return }
        guard action != .startDryRun, canRunAccountAction(action) else { return }
        let pauseSequence = action == .pause ? beginAccountMutation(action) : nil
        guard let expectedTenantID = kashbotStatus?.tenant?.id,
              let expectedLaneID = kashbotStatus?.lane?.id,
              let identity = isOwnerExecution ? "owner-domain" : setupCredentialIdentity else {
            if let pauseSequence { finishAccountMutation(sequence: pauseSequence) }
            return
        }
        let ownerRequest = isOwnerExecution
        let sequence = pauseSequence ?? beginAccountMutation(action)
        let resumingTenant = !ownerRequest && action == .startLive && kashbotStatus?.automatedTrading == .paused
        accountMutationInProgress = true
        runnerAction = action
        setupError = nil
        setupMessage = "Checking account status and waiting for the runner."
        runnerTask = Task { [weak self] in
            guard let self else { return }
            defer {
                finishAccountMutation(sequence: sequence)
            }
            do {
                let store = KeychainStore()
                guard let tokenData = try store.load(account: KeychainStore.dashboardTokenAccount),
                      let bearer = String(data: tokenData, encoding: .utf8), !bearer.isEmpty,
                      ownerRequest || Data(SHA256.hash(data: tokenData)) == setupBearerIdentity else {
                    throw DashboardClientError.noCredential
                }
                // Pin this attempt to its bearer. Never load the Kalshi private key here.
                let client = DashboardClient(fixtureMode: fixtureMode, token: { bearer })
                @MainActor func currentIdentity() -> String? {
                    guard sequence == accountRequestSequence,
                          (action == .pause || accountSceneActive), isOwnerExecution == ownerRequest,
                          ownerRequest || setupCredentialIdentity == identity,
                          kashbotStatus?.tenant?.id == expectedTenantID,
                          kashbotStatus?.lane?.id == expectedLaneID,
                          (try? store.load(account: KeychainStore.dashboardTokenAccount)) == tokenData else { return nil }
                    return identity
                }
                let flow = AccountRunnerControlFlow(readStatus: {
                    let status = try await client.kashbotStatus()
                    guard status.isOwnerExecution == ownerRequest else { throw AccountRunnerControlError.scopeChanged }
                    return status
                },
                    submit: { action, requestID in
                        switch action {
                        case .startLive: _ = try await client.startLive(clientRequestId: requestID)
                        case .pause: _ = try await client.pauseTrading(clientRequestId: requestID)
                        case .revoke: _ = try await client.revokeRunner(clientRequestId: requestID)
                        case .startDryRun: throw AccountRunnerControlError.unavailable
                        }
                    }, credentialIdentity: currentIdentity,
                    submitOwner: { action, requestID, execution in
                        guard currentIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
                        if action == .pause {
                            try await client.ownerRunnerAction(.pause, clientRequestId: requestID)
                            return
                        }
                        guard action == .startLive else { throw AccountRunnerControlError.unavailable }
                        // The existing autotuner mapping supplies the same owner account the decision signer uses.
                        let response: AutopilotResponse
                        do {
                            response = try await AutopilotClient(fixtureMode: self.fixtureMode, token: { bearer }).fetch()
                        } catch let failure as DashboardClientError where failure == .transport || failure == .decoding {
                            // This was a read before signing, so no command can have been committed.
                            throw AccountRunnerControlError.unavailable
                        }
                        try Task.checkCancellation()
                        guard currentIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
                        let owners = (response.accountSwitches ?? []).filter { $0.scope == .owner }
                        guard owners.count == 1, let account = owners.first?.accountId, TuningSyntax.isAccount(account) else {
                            throw DecisionSignerError.invalidDecision("account")
                        }
                        guard let key = try SecureEnclaveDecisionKey.load(fixtureMode: self.fixtureMode) else {
                            throw DecisionSignerError.notEnrolled
                        }
                        let now = Date()
                        let plan = try OwnerDomainResumePlan(execution: execution, requestID: requestID, now: now)
                        let presence = try await DecisionSigner(key: key).signDomainResume(plan: plan, account: account,
                            issuedAtMs: TuningSyntax.milliseconds(now))
                        try Task.checkCancellation()
                        guard currentIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
                        try await client.ownerRunnerAction(.startLive, clientRequestId: requestID,
                                                          presence: presence, expectGeneration: plan.generation)
                    }, observeStatus: { status in
                        if sequence == self.accountRequestSequence, status.isOwnerExecution { self.kashbotStatus = status }
                    })
                let result: KashbotStatus
                if action == .pause {
                    // Send the stop before reading status: an in-flight start may still report dry_run.
                    guard currentIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
                    let requestID = UUID()
                    if ownerRequest {
                        try await client.ownerRunnerAction(.pause, clientRequestId: requestID)
                    } else {
                        _ = try await client.pauseTrading(clientRequestId: requestID)
                    }
                    var paused: KashbotStatus?
                    for _ in 0..<30 {
                        try Task.checkCancellation()
                        guard currentIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
                        let status = try await client.kashbotStatus()
                        guard status.tenant?.id == expectedTenantID, status.lane?.id == expectedLaneID,
                              status.isOwnerExecution == ownerRequest else { throw AccountRunnerControlError.scopeChanged }
                        if ownerRequest ? status.execution?.pause?.state == "paused" :
                            (status.automatedTrading == .paused && status.lane?.liveEnabled == false) {
                            paused = status
                            break
                        }
                        try await Task.sleep(nanoseconds: 2_000_000_000)
                    }
                    guard let paused else { throw AccountRunnerControlError.timedOut }
                    result = paused
                } else if resumingTenant {
                    let fresh = try await client.kashbotStatus()
                    guard currentIdentity() == identity, fresh.hasActionableLane, !fresh.isOwnerExecution,
                          fresh.tenant?.id == expectedTenantID, fresh.lane?.id == expectedLaneID,
                          fresh.automatedTrading == .paused, fresh.lane?.liveEnabled == false else {
                        throw AccountRunnerControlError.unavailable
                    }
                    let requestID = UUID()
                    _ = try await client.startLive(clientRequestId: requestID)
                    var resumed: KashbotStatus?
                    for _ in 0..<30 {
                        try Task.checkCancellation()
                        guard currentIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
                        let status = try await client.kashbotStatus()
                        guard status.hasActionableLane, !status.isOwnerExecution,
                              status.tenant?.id == expectedTenantID, status.lane?.id == expectedLaneID else {
                            throw AccountRunnerControlError.scopeChanged
                        }
                        if status.request?.clientRequestId.lowercased() == requestID.uuidString.lowercased() {
                            if status.request?.state == "failed" { throw AccountRunnerControlError.failed }
                            if status.request?.state == "applied", status.automatedTrading == .live,
                               status.lane?.liveEnabled == true, status.lane?.killRequested == false {
                                resumed = status
                                break
                            }
                        }
                        try await Task.sleep(nanoseconds: 2_000_000_000)
                    }
                    guard let resumed else { throw AccountRunnerControlError.timedOut }
                    result = resumed
                } else {
                    result = try await flow.perform(action, expectedTenantID: expectedTenantID,
                                                    expectedLaneID: expectedLaneID)
                }
                try Task.checkCancellation()
                guard currentIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
                acceptAccountActionResult(result, sequence: sequence)
            } catch {
                guard sequence == accountRequestSequence else { return }
                setupMessage = nil
                if ownerRequest, let message = DashboardClient.ownerControlMessage(for: error) {
                    setupError = message
                } else if ownerRequest, error is DecisionSignerError {
                    setupError = DecisionSigner.message(for: error)
                } else {
                    setupError = "The runner action could not be confirmed. Check progress for a fresh status before trying again."
                }
            }
        }
    }

    private func reconcileEnrolledKey() {
        var record = UserDefaults.standard.data(forKey: Self.enrolledKeyKey).flatMap {
            try? JSONDecoder().decode(EnrolledKeyRecord.self, from: $0)
        }
        if let stored = record, let status = kashbotStatus,
           EnrolledKeyPolicy.recordIsObsolete(record: stored, tenantId: status.tenant?.id,
                                             laneId: status.lane?.id, state: status.automatedTrading) {
            UserDefaults.standard.removeObject(forKey: Self.enrolledKeyKey)
            record = nil
        }
        enrolledKeyChanged = EnrolledKeyPolicy.keyChanged(record: record, currentScope: currentKeyScope,
            tenantId: kashbotStatus?.tenant?.id, laneId: kashbotStatus?.lane?.id,
            state: kashbotStatus?.automatedTrading ?? .notConfigured)
    }

    private func updateSetupMessage() {
        setupMessage = nil
        setupError = nil
        if isOwnerExecution {
            if let pending = execution?.pendingLabel { setupMessage = pending }
            else {
                switch execution?.pause?.state {
                case "paused": setupMessage = "Owner entries are paused. Exits and settlements continue."
                case "resumed", "absent": setupMessage = "Owner pause is clear. Other entry safeguards still apply."
                default: setupMessage = "Owner pause status is unavailable. Check progress again."
                }
            }
            return
        }
        if enrolledKeyChanged {
            setupError = "Your Kalshi key changed since this lane was enrolled. The runner still trades with the enrolled key. Import that key again, or ask support to re-enroll the lane."
            return
        }
        guard let status = kashbotStatus, status.isBound else { return }
        switch status.automatedTrading {
        case .ready: setupMessage = "Your account is ready. Setup does not enable live orders."
        case .dryRun: setupMessage = "Dry run active. No live orders."
        case .live: setupMessage = nil
        case .livePending: setupMessage = "Starting live trading. Pause is available if you need to stop."
        case .error:
            setupError = "The runner reported an error. Pause or revoke is available. Your saved key is unchanged."
        case .unknown:
            setupError = "The dashboard reported a status this version does not recognize. Pause and revoke remain available. Update the app."
        case .provisioning: setupMessage = "Your account is being prepared. Check progress again shortly."
        case .paused: setupMessage = "Paused. No new live orders."
        case .failed:
            setupError = "Setup needs attention. Check progress again or contact support. Your saved key is unchanged."
        case .revoked:
            setupError = "Account access was revoked. Contact support before preparing this account again."
        case .notConfigured, .credentialRequired:
            setupMessage = "Your account needs a protected key. Tap Prepare my account to send it or check an earlier attempt."
        }
    }

    private func pollBindingStatus() async {
        guard !accountMutationInProgress else { return }
        let sequence = accountRequestSequence
        refreshSetupCredentials()
        let credentialIdentity = setupCredentialIdentity
        do {
            let status = try await dashboard.kashbotStatus()
            try Task.checkCancellation()
            guard sequence == accountRequestSequence, !accountMutationInProgress, accountSceneActive else { return }
            guard credentialIdentity == setupCredentialIdentity else { return }
            kashbotStatus = status
            recordFeedSuccess(.status)
            reconcileEnrolledKey()
            dashboardPairingState = status.dashboardPairing
            try await finishAutoLiveIfRequested(identity: credentialIdentity)
            if !settingUpDryRun { updateSetupMessage() }
        } catch {
            guard !Task.isCancelled else { return }
            guard sequence == accountRequestSequence, !accountMutationInProgress, accountSceneActive else { return }
            guard credentialIdentity == setupCredentialIdentity else { return }
            if error as? DashboardClientError == .noCredential || error as? DashboardClientError == .unauthorized {
                kashbotStatus = nil
            }
            if !settingUpDryRun {
                setupMessage = nil
                setupError = "Account progress could not be checked. Try Check progress again."
            }
            dashboardPairingState = (error as? DashboardClientError == .noCredential ||
                                     error as? DashboardClientError == .unauthorized) ? .unpaired : .unknown
            recordFeedFailure(.status, error: dashboardMessage(error))
        }
    }

    /// Internal so tests can drive the cold-launch restore.
    func restore() async {
        guard !fixtureMode.enabled else { return }
        guard !restored else { return }
        restored = true
        // The last shown board stands until a poll with fresh positions and settlements replaces it.
        if liveBoard == nil { liveBoard = KashbotBoardStore.load(now: clock()) }
        do {
            let database = try ObservationStore()
            store = database
            cash.merge(try await database.load(metric: .cash, source: .phone))
            accountValue.merge(try await database.load(metric: .portfolioValue, source: .phone))
            runnerCash.merge(try await database.load(metric: .cash, source: .runner))
            runnerAccountValue.merge(try await database.load(metric: .portfolioValue, source: .runner))
        } catch { storeError = "Saved history is unavailable." }
    }

    private func save(_ observations: [AccountObservation]) async {
        guard let store else { return }
        do { try await store.append(observations); storeError = nil }
        catch { storeError = "Could not save account history." }
    }

    func refreshLiveBoardOnce() async {
        guard !fixtureMode.enabled else { return }
        await pollKalshi()
    }

    private func pollKalshi() async {
        guard !kalshiPollInFlight, !marketsPollInFlight else { return }
        let loadStartedAt = clock()
        let activation = loadActivation
        kalshiPollInFlight = true
        defer { kalshiPollInFlight = false }
        let boardRevision = liveBoardRevision
        do {
            let latest = try await kalshi.get(.balance, as: AccountBalance.self)
            try Task.checkCancellation()
            guard boardRevision == liveBoardRevision else { return }
            let now = clock()
            restoreDirectAccount()
            directBalanceTransportFailed = false
            balance = latest
            balanceObservedAt = now
            recordFeedSuccess(.balance)
            recordLoadLive(id: "kalshiBalance", startedAt: loadStartedAt, finishedAt: clock(),
                           failed: false, activation: activation)
            async let positionsRead = kalshi.get(.positions, as: PositionsResponse.self)
            async let fillsRead = kalshi.get(.fills(cursor: nil, limit: 50), as: FillsResponse.self)
            async let settlementsRead = fetchSettlements(now: now)
            var positionsFetched = false
            do {
                let latestPositions = try await positionsRead
                try Task.checkCancellation()
                guard boardRevision == liveBoardRevision else { return }
                positions = latestPositions.marketPositions ?? []
                positionsObservedAt = Date()
                positionsError = nil
                recordFeedSuccess(.positions)
                positionsFetched = true
            } catch is CancellationError {
                return
            } catch {
                guard !Task.isCancelled, boardRevision == liveBoardRevision else { return }
                positionsError = "Could not refresh positions. Showing the last account activity."
                recordFeedFailure(.positions, error: positionsError!)
            }
            try Task.checkCancellation()
            let tickers = Self.marketTickers(positions)
            let held = Set(tickers)
            marketQuotes = marketQuotes.filter { held.contains($0.key) }
            if !tickers.isEmpty {
                do {
                    let latestMarkets = try await kalshi.get(.markets(tickers: tickers), as: LiveMarketsResponse.self)
                    try Task.checkCancellation()
                    guard boardRevision == liveBoardRevision else { return }
                    applyLiveMarkets(latestMarkets, tickers: tickers)
                    recordFeedSuccess(.markets)
                } catch is CancellationError {
                    return
                } catch {
                    guard !Task.isCancelled, boardRevision == liveBoardRevision else { return }
                    recordFeedFailure(.markets, error: error.localizedDescription)
                    // Keep the last quotes when the venue cannot refresh them.
                }
            } else {
                try Task.checkCancellation()
                guard boardRevision == liveBoardRevision else { return }
                markets = []
                recordFeedSuccess(.markets)
            }
            markedPortfolio = positionsObservedAt == nil ? nil : latest.balance.map {
                PositionMarks.marked(cashCents: $0, positions: positions, markets: marketQuotes, now: now)
            }
            let observation = AccountObservation(capturedAt: now, source: .phone, cashCents: latest.balance,
                portfolioValueCents: markedPortfolio?.totalCents ?? latest.accountValue?.cents.rawValue)
            cash.merge(observation)
            accountValue.merge(observation)
            do {
                let latestFills = try await fillsRead
                try Task.checkCancellation()
                guard boardRevision == liveBoardRevision else { return }
                recentFills = latestFills.fills ?? []
                fillsObservedAt = Date()
                fillsError = nil
                recordFeedSuccess(.fills)
            } catch is CancellationError {
                return
            } catch {
                guard !Task.isCancelled, boardRevision == liveBoardRevision else { return }
                fillsError = "Could not refresh recent fills. Showing the last account activity."
                recordFeedFailure(.fills, error: fillsError!)
            }
            do {
                let latestSettlements = try await settlementsRead
                try Task.checkCancellation()
                guard boardRevision == liveBoardRevision else { return }
                settlements = latestSettlements
                settlementsLoaded = true
                recordFeedSuccess(.settlements)
            } catch is CancellationError {
                return
            } catch {
                guard !Task.isCancelled, boardRevision == liveBoardRevision else { return }
                recordFeedFailure(.settlements, error: error.localizedDescription)
                // Keep the last good settlements when the venue cannot refresh them.
            }
            guard boardRevision == liveBoardRevision else { return }
            // Empty positions or never-read settlements would overwrite the last good board and buzz a false close.
            if positionsFetched && settlementsLoaded {
                await updateLiveBoard(now: now)
                if liveBoard != nil {
                    recordLoadLive(id: "liveBoard", startedAt: loadStartedAt, finishedAt: clock(),
                                   failed: false, activation: activation)
                }
            }
            guard boardRevision == liveBoardRevision else { return }
            updatePortfolioWidget(now: now)
            kalshiError = nil
            await save([observation])
        } catch {
            guard !Task.isCancelled else { return }
            switch error as? KalshiClientError {
            case .noCredential: kalshiError = "Import your runner key in Settings."
            case .unauthorized: kalshiError = "Kalshi rejected this key. Check Settings."
            case .rateLimited: kalshiError = "Kalshi is busy. Retrying next minute."
            default: kalshiError = "Could not refresh Kalshi. Showing the last observation."
            }
            recordFeedFailure(.balance, error: kalshiError!)
            recordLoadLive(id: "kalshiBalance", startedAt: loadStartedAt, finishedAt: clock(),
                           failed: true, activation: activation)
            if case .transport? = error as? KalshiClientError {
                directBalanceTransportFailed = true
                applyServerAccountFallback(now: clock())
            } else {
                directBalanceTransportFailed = false
                restoreDirectAccount()
            }
        }
    }

    private func restoreDirectAccount() {
        if let saved = savedDirectAccount {
            balance = saved.balance
            balanceObservedAt = saved.balanceAt
            positions = saved.positions
            positionsObservedAt = saved.positionsAt
            markedPortfolio = saved.markedPortfolio
        }
        savedDirectAccount = nil
        accountSource = .phone
    }

    private func applyServerAccountFallback(now: Date) {
        guard directBalanceTransportFailed else { return }
        guard let snapshot = runnerActivity?.account,
              case let .useServer(serverBalance, serverPositions, observedAt) = AccountFallback.decide(
                directFailure: .transport, snapshot: snapshot, now: now) else {
            restoreDirectAccount()
            kalshiError = "Could not refresh Kalshi. Showing the last observation."
            return
        }
        if savedDirectAccount == nil {
            savedDirectAccount = (balance, balanceObservedAt, positions, positionsObservedAt, markedPortfolio)
        }
        balance = serverBalance
        balanceObservedAt = observedAt
        if let serverPositions {
            positions = serverPositions
            positionsObservedAt = observedAt
        }
        markedPortfolio = positionsObservedAt == nil ? nil : serverBalance.balance.map {
            PositionMarks.marked(cashCents: $0, positions: positions, markets: marketQuotes, now: now)
        }
        accountSource = .server(observedAt: observedAt, source: snapshot.source)
        updatePortfolioWidget(now: observedAt)
        // The Money card renders the snapshot age live; a relative age frozen into this string would go stale.
        kalshiError = "Kalshi is unreachable on this network. Showing Kashbot's copy."
    }

    /// One foreground tick; failed quotes leave the last snapshot untouched.
    func refreshLiveMarketsOnce() async {
        guard !fixtureMode.enabled, accountSceneActive, !kalshiPollInFlight,
              !marketsPollInFlight, settlementsLoaded, liveBoard != nil else { return }
        let tickers = Self.marketTickers(positions)
        guard !tickers.isEmpty else { return }
        marketsPollInFlight = true
        defer { marketsPollInFlight = false }
        let revision = liveBoardRevision
        do {
            let response = try await kalshi.get(.markets(tickers: tickers), as: LiveMarketsResponse.self)
            try Task.checkCancellation()
            guard accountSceneActive, revision == liveBoardRevision else { return }
            applyLiveMarkets(response, tickers: tickers)
            recordFeedSuccess(.markets)
            let now = clock()
            markedPortfolio = balance?.balance.map {
                PositionMarks.marked(cashCents: $0, positions: positions, markets: marketQuotes, now: now)
            }
            await updateLiveBoard(now: now)
        } catch {
            guard !Task.isCancelled else { return }
            recordFeedFailure(.markets, error: error.localizedDescription)
            // Keep positions, settlements, balance and the last good board.
        }
    }

    private func applyLiveMarkets(_ response: LiveMarketsResponse, tickers: [String]) {
        markets = response.board.markets ?? []
        // Match the endpoint's deduplicated 20-ticker cap; valuation shares this one board request.
        var seen = Set<String>()
        let requested = Set(tickers.filter { !$0.isEmpty && seen.insert($0).inserted }.prefix(20))
        // A successful response that omits a requested ticker falls back to its own cost.
        for ticker in requested { marketQuotes.removeValue(forKey: ticker) }
        for market in response.marks.markets ?? [] where requested.contains(market.ticker) {
            marketQuotes[market.ticker] = market
        }
    }

    @ObservationIgnored private var lastBoardWidgetReload: KashbotBoardSnapshot?
    @ObservationIgnored private var lastBoardWidgetReloadAt: Date?


    private func updateLiveBoard(now: Date) async {
        let revision = liveBoardRevision
        let pending = await TuningPendingCache.shared.pending(fixtureMode: fixtureMode, now: clock())
        guard revision == liveBoardRevision else { return }
        guard let snapshot = KashbotLiveStateBuilder.build(balance: balance, positions: positions,
            markets: markets, settlements: settlements, now: now,
            approvalsWaiting: pending?.count, approval: pending?.newest) else { return }
        liveBoard = snapshot
        guard !fixtureMode.enabled else { return }
        KashbotBoardStore.save(snapshot)
        let reloadAt = clock()
        if Self.shouldReloadBoardWidgets(previous: lastBoardWidgetReload, previousAt: lastBoardWidgetReloadAt,
                                         next: snapshot, now: reloadAt) {
            reloadLiveBoardWidgets()
            lastBoardWidgetReload = snapshot
            lastBoardWidgetReloadAt = reloadAt
        }
        await liveActivity?.apply(snapshot).value
    }

    static let settlementPageLimit = 200
    // Bound each refresh to 5,000 rows so a busy day is covered without unbounded requests.
    static let settlementPageCap = 25

    /// Reads settlements newest first, 200 a page, until a page reaches before the New York day start, the
    /// cursor ends, or 25 pages (5,000 rows); a capped read keeps what it has. Any page failure fails the read.
    private func fetchSettlements(now: Date) async throws -> [Settlement] {
        let dayStart = LiveBoardMath.easternDayStart(for: now)
        var collected: [Settlement] = []
        var cursor: String?
        for _ in 0..<Self.settlementPageCap {
            let page = try await kalshi.get(.settlements(cursor: cursor, limit: Self.settlementPageLimit),
                                            as: SettlementsResponse.self)
            try Task.checkCancellation()
            let rows = page.settlements ?? []
            collected.append(contentsOf: rows)
            let settledDates: [Date] = rows.compactMap { (row: Settlement) -> Date? in Self.settledDate(row.settledTime) }
            if let oldest = settledDates.min(), oldest < dayStart { break }
            guard let next = page.cursor, !next.isEmpty, !rows.isEmpty else { break }
            cursor = next
        }
        return collected
    }

    private static let settledTimeFormatters: [ISO8601DateFormatter] = {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let whole = ISO8601DateFormatter()
        whole.formatOptions = [.withInternetDateTime]
        return [fractional, whole]
    }()

    private static func settledDate(_ value: String?) -> Date? {
        guard let value else { return nil }
        return settledTimeFormatters.lazy.compactMap { $0.date(from: value) }.first
    }

    /// Open tickers by absolute exposure, largest first, then by ticker; the markets query keeps the first 20.
    static func marketTickers(_ positions: [Position]) -> [String] {
        var ranked: [RankedTicker] = []
        ranked.reserveCapacity(positions.count)
        for position in positions where LiveBoardMath.contracts(positionFp: position.positionFp) != nil {
            let exposure: Decimal = LiveBoardMath.decimal(position.marketExposureDollars) ?? Decimal.zero
            let magnitude: Decimal = exposure < Decimal.zero ? -exposure : exposure
            ranked.append(RankedTicker(ticker: position.ticker, exposure: magnitude))
        }
        ranked.sort(by: RankedTicker.byExposureThenTicker)
        var tickers: [String] = []
        tickers.reserveCapacity(ranked.count)
        for item in ranked { tickers.append(item.ticker) }
        return tickers
    }

    private struct RankedTicker {
        let ticker: String
        let exposure: Decimal

        static func byExposureThenTicker(_ lhs: RankedTicker, _ rhs: RankedTicker) -> Bool {
            if lhs.exposure != rhs.exposure { return lhs.exposure > rhs.exposure }
            return lhs.ticker < rhs.ticker
        }
    }

    private func reloadLiveBoardWidgets() {
        for kind in ["KashbotPortfolioWidget", "KashbotLockWidget", "KashbotLedgerWidget"] {
            WidgetCenter.shared.reloadTimelines(ofKind: kind)
        }
    }

    private func updatePortfolioWidget(now: Date) {
        guard let totalCents = markedPortfolio?.totalCents ?? balance?.accountValue?.cents.rawValue else { return }
        let history = accountValue.observations.compactMap { observation -> PortfolioWidgetValuePoint? in
            guard let value = observation.portfolioValueCents else { return nil }
            return PortfolioWidgetValuePoint(observedAt: observation.capturedAt, totalCents: value)
        }
        let compactPositions = positions.compactMap { position -> PortfolioWidgetPositionSnapshot? in
            guard let exposureCents = position.exposure?.cents.rawValue else { return nil }
            let size = position.positionFp?.trimmingCharacters(in: .whitespacesAndNewlines)
            return PortfolioWidgetPositionSnapshot(
                ticker: position.ticker,
                size: (size?.isEmpty == false ? size : nil) ?? "0",
                exposureCents: exposureCents
            )
        }
        let snapshot = PortfolioWidgetSnapshot.make(
            totalCents: totalCents,
            history: history,
            positions: compactPositions,
            now: now
        )
        PortfolioWidgetSnapshotStore.save(snapshot)
        WidgetCenter.shared.reloadTimelines(ofKind: "KashbotPortfolioWidget")
    }

    func tabBecameVisible(_ tab: KashbotTab) {
        visibleTab = tab
        guard accountSceneActive, !fixtureMode.enabled else { return }
        let due = DashboardFeedPolicy.dueOnTabSwitch(to: tab, lastFetched: dashboardLastFetched, now: clock())
        guard !due.subtracting(dashboardFeedsInFlight).isEmpty else { return }
        let id = UUID()
        dashboardTabTasks[id] = Task { [weak self] in
            guard let self else { return }
            defer { dashboardTabTasks[id] = nil }
            await pollDashboardWave(due)
        }
    }


    private func updateDashboardSnapshotScope(_ identity: String?) {
        guard !fixtureMode.enabled else { return }
        guard !dashboardSnapshotScopeKnown || dashboardSnapshotIdentity != identity else { return }
        let changed = dashboardSnapshotScopeKnown && dashboardSnapshotIdentity != identity
        dashboardSnapshotScopeKnown = true
        dashboardSnapshotIdentity = identity
        for feed in restoredDashboardFeeds {
            switch feed {
            case .books: books = nil; booksObservedAt = nil
            case .activity: runnerActivity = nil; runnerActivityObservedAt = nil
            case .exits: exitLedger = nil; exitLedgerObservedAt = nil
            case .calibration: entryCalibration = nil; entryCalibrationObservedAt = nil
            default: break
            }
        }
        restoredDashboardFeeds.removeAll()
        let previous = dashboardSnapshotWork
        let snapshots = dashboardSnapshots
        dashboardSnapshotWork = Task {
            await previous?.value
            if changed || identity == nil { await snapshots.clear() }
            if let identity { await snapshots.prepare(identity: identity) }
        }
    }

    private func restoreDashboardSnapshots() async {
        guard let identity = dashboardSnapshotIdentity, !fixtureMode.enabled else { return }
        let activation = loadActivation
        await dashboardSnapshotWork?.value
        for feed in [DashboardFeed.books, .activity, .exits, .calibration] {
            guard let saved = await dashboardSnapshots.load(feed: feed, identity: identity, now: clock()) else { continue }
            guard dashboardSnapshotIdentity == identity,
                  (try? dashboard.snapshotIdentity()) == identity else { return }
            do {
                switch feed {
                case .books:
                    guard books == nil else { continue }
                    books = try DashboardClient.decodeSnapshot(MobileBooks.self, from: saved.payload)
                    booksObservedAt = saved.savedAt
                    restoreFeedObservation(.books, observedAt: saved.savedAt)
                case .activity:
                    guard runnerActivity == nil else { continue }
                    runnerActivity = try DashboardClient.decodeSnapshot(RunnerActivity.self, from: saved.payload)
                    runnerActivityObservedAt = saved.savedAt
                    restoreFeedObservation(.activity, observedAt: saved.savedAt)
                case .exits:
                    guard exitLedger == nil else { continue }
                    exitLedger = try DashboardClient.decodeSnapshot(ExitLedger.self, from: saved.payload)
                    exitLedgerObservedAt = saved.savedAt
                    restoreFeedObservation(.exits, observedAt: saved.savedAt)
                case .calibration:
                    guard entryCalibration == nil else { continue }
                    entryCalibration = try DashboardClient.decodeSnapshot(EntryCalibration.self, from: saved.payload)
                    entryCalibrationObservedAt = saved.savedAt
                    restoreFeedObservation(.calibration, observedAt: saved.savedAt)
                default: continue
                }
                restoredDashboardFeeds.insert(feed)
                updateLoadTimings(activation: activation) { $0.recordRestored(id: String(describing: feed), at: clock()) }
            } catch { await dashboardSnapshots.remove(feed: feed) }
        }
    }

    private func saveDashboardSnapshot(_ feed: DashboardFeed, payload: Data, identity: String, now: Date) {
        guard !fixtureMode.enabled else { return }
        restoredDashboardFeeds.remove(feed)
        updateDashboardSnapshotScope(identity)
        let previous = dashboardSnapshotWork
        dashboardSnapshotWork = Task { [weak self] in
            await previous?.value
            guard let self, dashboardSnapshotIdentity == identity else { return }
            await dashboardSnapshots.save(feed: feed, payload: payload, identity: identity, now: now)
        }
    }

    private func pollDashboard(forceAll: Bool = false) async {
        guard !fixtureMode.enabled, !Task.isCancelled else { return }
        let activation = loadActivation
        if !dashboardRestoreStarted {
            dashboardRestoreStarted = true
            updateDashboardSnapshotScope(try? dashboard.snapshotIdentity())
            dashboardRestoreTask = Task { [weak self] in await self?.restoreDashboardSnapshots() }
        }
        await pollDashboardFeed(.status)
        guard !Task.isCancelled else { return }
        let now = clock()
        let due = forceAll ? Set(DashboardFeed.allCases) :
            DashboardFeedPolicy.due(visibleTab: visibleTab, lastFetched: dashboardLastFetched, now: now)
        let visible = DashboardFeedPolicy.feedsRead(by: visibleTab)
        await pollDashboardWave(due.intersection(visible).subtracting([.status]))
        guard !Task.isCancelled else { return }
        await pollDashboardWave(due.subtracting(visible))
        if forceAll {
            updateLoadTimings(activation: activation) { timings in
                guard timings.firstPollMs == nil else { return }
                timings.recordFirstPoll(finishedAt: clock())
                let logLine = timings.logLine
                Self.loadingLogger.info("\(logLine, privacy: .public)")
            }
        }
    }

    private func pollDashboardWave(_ feeds: Set<DashboardFeed>) async {
        async let status: Void = pollDashboardFeedIfDue(.status, feeds: feeds)
        async let engines: Void = pollDashboardFeedIfDue(.engines, feeds: feeds)
        async let probes: Void = pollDashboardFeedIfDue(.probes, feeds: feeds)
        async let lab: Void = pollDashboardFeedIfDue(.engineLab, feeds: feeds)
        async let books: Void = pollDashboardFeedIfDue(.books, feeds: feeds)
        async let history: Void = pollDashboardFeedIfDue(.accountHistory, feeds: feeds)
        async let activity: Void = pollDashboardFeedIfDue(.activity, feeds: feeds)
        async let exits: Void = pollDashboardFeedIfDue(.exits, feeds: feeds)
        async let calibration: Void = pollDashboardFeedIfDue(.calibration, feeds: feeds)
        _ = await (status, engines, probes, lab, books, history, activity, exits, calibration)
    }

    private func pollDashboardFeedIfDue(_ feed: DashboardFeed, feeds: Set<DashboardFeed>) async {
        guard feeds.contains(feed) else { return }
        await pollDashboardFeed(feed)
    }

    private func pollDashboardFeed(_ feed: DashboardFeed) async {
        guard !Task.isCancelled, !dashboardFeedsInFlight.contains(feed) else { return }
        // Direct Lab refreshes share the same in-flight reservation and completion stamp.
        if feed == .engineLab {
            await refreshEngineLab(resetPeople: false)
            return
        }
        let loadStartedAt = clock()
        let activation = loadActivation
        dashboardFeedsInFlight.insert(feed)
        let generation = dashboardFetchGeneration
        defer {
            dashboardFeedsInFlight.remove(feed)
            if !Task.isCancelled, generation == dashboardFetchGeneration { dashboardLastFetched[feed] = clock() }
        }
        switch feed {
        case .status: await pollBindingStatus()
        case .engines: await pollEngines()
        case .probes: await pollProbes()
        case .books: await pollBooks()
        case .accountHistory: await pollAccountHistory()
        case .activity: await pollActivity()
        case .exits: await pollExits()
        case .calibration: await pollCalibration()
        case .engineLab: break
        }
        let failed: Bool
        switch feed {
        case .status: failed = kashbotStatus == nil
        case .engines: failed = enginesError != nil
        case .probes: failed = probeBoardError != nil
        case .activity: failed = runnerActivityError != nil
        case .accountHistory: failed = accountHistoryError != nil
        case .exits: failed = exitLedgerError != nil
        case .calibration: failed = entryCalibrationError != nil
        case .books: failed = booksError != nil
        case .engineLab: failed = engineLabError != nil
        }
        recordLoadLive(id: String(describing: feed), startedAt: loadStartedAt, finishedAt: clock(),
                       failed: failed, activation: activation)
    }

    private func updateLoadTimings(activation: UUID?, _ update: (inout LoadTimings) -> Void) {
        guard !fixtureMode.enabled, !Task.isCancelled, let activation,
              activation == loadActivation else { return }
        if var timings = resumeLoadTimings {
            update(&timings)
            resumeLoadTimings = timings
        } else if var timings = coldLoadTimings {
            update(&timings)
            coldLoadTimings = timings
        }
    }

    private func recordLoadLive(id: String, startedAt: Date, finishedAt: Date,
                                failed: Bool, activation: UUID?) {
        updateLoadTimings(activation: activation) {
            $0.recordLive(id: id, startedAt: startedAt, finishedAt: finishedAt, failed: failed)
        }
    }

    private func pollBooks() async {
        do {
            let response = try await dashboard.booksWithBytes()
            try Task.checkCancellation()
            books = response.value
            booksObservedAt = Date()
            booksError = nil
            recordFeedSuccess(.books)
            saveDashboardSnapshot(.books, payload: response.payload, identity: response.identity, now: booksObservedAt!)
        } catch {
            guard !Task.isCancelled else { return }
            booksError = dashboardMessage(error)
            recordFeedFailure(.books, error: booksError!)
        }
    }

    private func pollAccountHistory() async {
        do {
            let history = try await dashboard.account()
            try Task.checkCancellation()
            let observations = history.balances.map { item -> AccountObservation in
                let value = item.portfolioValueCents.flatMap { mark -> Int? in
                    let sum = item.cashCents.addingReportingOverflow(mark)
                    return sum.overflow ? nil : sum.partialValue
                }
                return AccountObservation(capturedAt: item.capturedAt, source: .runner,
                    cashCents: item.cashCents, portfolioValueCents: value)
            }
            runnerCash.merge(observations)
            runnerAccountValue.merge(observations)
            await save(observations)
            accountHistoryError = nil
            recordFeedSuccess(.accountHistory)
        } catch {
            guard !Task.isCancelled else { return }
            accountHistoryError = dashboardMessage(error)
            recordFeedFailure(.accountHistory, error: accountHistoryError!)
        }
    }

    private func pollActivity() async {
        do {
            let response = try await dashboard.activityWithBytes()
            try Task.checkCancellation()
            runnerActivity = response.value
            runnerActivityObservedAt = Date()
            runnerActivityError = nil
            recordFeedSuccess(.activity)
            saveDashboardSnapshot(.activity, payload: response.payload, identity: response.identity, now: runnerActivityObservedAt!)
            applyServerAccountFallback(now: clock())
        } catch {
            guard !Task.isCancelled else { return }
            runnerActivityError = runnerActivity == nil
                ? "Runner activity is unavailable for this paired account."
                : "Could not refresh runner activity. Showing the last runner summary."
            recordFeedFailure(.activity, error: runnerActivityError!)
        }
    }

    private func pollExits() async {
        do {
            let response = try await dashboard.exitsWithBytes()
            try Task.checkCancellation()
            exitLedger = response.value
            exitLedgerObservedAt = Date()
            exitLedgerError = nil
            recordFeedSuccess(.exits)
            saveDashboardSnapshot(.exits, payload: response.payload, identity: response.identity, now: exitLedgerObservedAt!)
        } catch {
            guard !Task.isCancelled else { return }
            exitLedgerError = exitLedger == nil
                ? "Cashouts are unavailable for this paired account."
                : "Could not refresh cashouts. Showing the last ledger."
            recordFeedFailure(.exits, error: exitLedgerError!)
        }
    }

    private func pollCalibration() async {
        do {
            let response = try await dashboard.calibrationWithBytes()
            try Task.checkCancellation()
            entryCalibration = response.value
            entryCalibrationObservedAt = Date()
            entryCalibrationError = nil
            recordFeedSuccess(.calibration)
            saveDashboardSnapshot(.calibration, payload: response.payload, identity: response.identity, now: entryCalibrationObservedAt!)
        } catch {
            guard !Task.isCancelled else { return }
            entryCalibrationError = entryCalibration == nil
                ? "Calibration is unavailable for this paired account."
                : "Could not refresh calibration. Showing the last result."
            recordFeedFailure(.calibration, error: entryCalibrationError!)
        }
        do {
            let latest = try await dashboard.attemptFunnel()
            try Task.checkCancellation()
            attemptFunnel = latest
            attemptFunnelObservedAt = Date()
            attemptFunnelError = nil
            recordFeedSuccess(.attemptFunnel)
        } catch {
            guard !Task.isCancelled else { return }
            attemptFunnelError = attemptFunnel == nil
                ? "Attempt funnel is unavailable for this paired account."
                : "Could not refresh the attempt funnel. Showing the last result."
            recordFeedFailure(.attemptFunnel, error: attemptFunnelError!)
        }
    }

    private var enginesLoading = false

    private func pollEngines() async {
        guard !enginesLoading else { return }
        enginesLoading = true
        defer { enginesLoading = false }
        dropOldRequests()
        do {
            let latest = try await dashboard.engines()
            try Task.checkCancellation()
            engines = latest
            disableShadowEngineControls()
            mergeProbeBoard()
            enginesObservedAt = Date()
            enginesError = nil
            recordFeedSuccess(.engines)
        } catch {
            guard !Task.isCancelled else { return }
            enginesError = dashboardMessage(error)
            recordFeedFailure(.engines, error: enginesError!)
        }
        do {
            let requests = try await dashboard.controlRequests()
            try Task.checkCancellation()
            if let intent = uncertainIntent, let since = uncertainSince,
               let recovered = requests.first(where: {
                    request($0, matches: intent) &&
                    ($0.requestedDate.map { $0 >= since.addingTimeInterval(-5) } ?? false)
               }) {
                requestFirstSeen[recovered.id] = Date()
                if !pendingRequests.contains(where: { $0.id == recovered.id }) { pendingRequests.append(recovered) }
                if isTerminal(recovered) { clearUnresolvedControl() }
            }
            for request in requests {
                if let index = pendingRequests.firstIndex(where: { $0.id == request.id }) { pendingRequests[index] = request }
                else if !isTerminal(request) { pendingRequests.append(request); requestFirstSeen[request.id] = Date() }
            }
            if let intent = uncertainIntent,
               let finished = requests.first(where: { request($0, matches: intent) && isTerminal($0) }) {
                if !pendingRequests.contains(where: { $0.id == finished.id }) { pendingRequests.append(finished) }
                clearUnresolvedControl()
            }
            if let since = uncertainSince, UnresolvedControlPolicy.isExpired(since: since, now: Date()) {
                clearUnresolvedControl()
            }
            dropOldRequests()
            recordFeedSuccess(.controlRequests)
        } catch {
            guard !Task.isCancelled else { return }
            enginesError = "Request states could not be refreshed. " + dashboardMessage(error)
            recordFeedFailure(.controlRequests, error: enginesError!)
        }
    }

    /// Same 30 s visible cadence as the rest of the dashboard poll. A failed read keeps the last board.
    private func pollProbes() async {
        do {
            let fetched = try await dashboard.probes()
            try Task.checkCancellation()
            switch fetched {
            case let .reported(board)?:
                probeBoard = board
                probeBoardNotReported = false
                probeBoardObservedAt = Date()
                mergeProbeBoard()
                recordFeedSuccess(.probes)
            case .notReported?:
                probeBoard = nil
                probeBoardNotReported = true
                probeBoardObservedAt = nil
                recordFeedFailure(.probes, error: "The probes response could not be read.")
            case nil:
                probeBoard = nil
                probeBoardNotReported = false
                probeBoardObservedAt = nil
                recordFeedSuccess(.probes)
            }
            probeBoardError = nil
        } catch {
            guard !Task.isCancelled else { return }
            probeBoardError = dashboardMessage(error)
            recordFeedFailure(.probes, error: probeBoardError!)
        }
    }

    private func mergeProbeBoard() {
        guard let board = probeBoard, let current = engines else { return }
        engines = Self.mergingProbeBoard(board, into: current)
    }


    private func dropOldRequests() {
        let cutoff = Date().addingTimeInterval(-30 * 60)
        pendingRequests.removeAll { request in
            isTerminal(request) && (request.requestedDate ?? requestFirstSeen[request.id] ?? Date()) < cutoff
        }
        let ids = Set(pendingRequests.map(\.id))
        requestFirstSeen = requestFirstSeen.filter { ids.contains($0.key) }
    }

    private func disableShadowEngineControls() {
        guard let snapshot = engines else { return }
        engines = Self.applyShadowControls(to: snapshot, lab: engineLab)
    }

    /// Lab metadata is advisory; configuration from the engines route owns live switch state.
    nonisolated static func applyShadowControls(to response: EnginesResponse, lab: EngineLab.Response?) -> EnginesResponse {
        var snapshot = response
        snapshot.engines = snapshot.engines?.map { original in
            var engine = original
            let candidate = lab?.candidates.first { $0.engineId == engine.engineId }
            if engine.shadowOnly == true || (engine.configuration == nil && candidate?.shadowOnly == true) {
                engine.shadowOnly = true
                engine.reason = candidate?.reason ?? engine.reason ?? "Shadow-only engine. Trading controls are disabled."
                engine.description = engine.reason
                // The existing card disables its toggle when no control revision is available.
                engine.configuration = nil
            }
            return engine
        }
        return snapshot
    }

    nonisolated static func labShadowReason(engineId: String, engines: EnginesResponse?, lab: EngineLab.Response?) -> String? {
        guard let candidate = lab?.candidates.first(where: { $0.engineId == engineId }), candidate.shadowOnly,
              engines?.engines?.first(where: { $0.engineId == engineId })?.configuration == nil else { return nil }
        return candidate.reason
    }

    func submit(_ intent: ControlIntent, note: String?) async -> String? {
        if case let .configure(value) = intent.value {
            if let reason = Self.labShadowReason(engineId: value.engineId, engines: engines, lab: engineLab) {
                return "Shadow-only engine. " + reason
            }
            if let engine = engines?.engines?.first(where: { $0.engineId == value.engineId }) {
                if let reason = engine.controlDisabledReason { return reason }
                if value.engineId == "darkhorse" {
                    for (key, value) in value.set ?? [:] {
                        if let reason = DarkhorsePolicy.validateThreshold(key: key, value: value, models: engine.darkhorse?.models ?? []) { return reason }
                    }
                }
            }
        }
        guard !fixtureMode.enabled || fixtureMode.controlWalk else { return "Controls are disabled in fixture mode." }
        guard !submittingControl else { return "A request is already being sent." }
        if uncertainIntent == intent {
            return "The previous result is still unknown. Wait for Requests to refresh before submitting it again."
        }
        submittingControl = true
        let started = Date()
        defer { submittingControl = false }
        if fixtureMode.controlWalk { return simulateFixtureControl(intent, note: note) }
        do {
            let response = try await dashboard.control(intent, note: note)
            guard let request = response.request else {
                storeUnresolved(intent, since: started)
                return "The result is unknown. Check Requests before submitting again."
            }
            dropOldRequests()
            requestFirstSeen[request.id] = Date()
            pendingRequests.removeAll { $0.id == request.id }
            pendingRequests.append(request)
            if isTerminal(request) { clearUnresolvedControl() } else { storeUnresolved(intent, since: started) }
            dropOldRequests()
            return nil
        } catch DashboardClientError.transport {
            storeUnresolved(intent, since: started)
            return "The result is unknown. Check Requests before submitting again."
        } catch DashboardClientError.decoding {
            storeUnresolved(intent, since: started)
            return "The result is unknown. Check Requests before submitting again."
        } catch { return dashboardMessage(error) }
    }

    private func simulateFixtureControl(_ intent: ControlIntent, note: String?) -> String? {
        fixtureControlCount += 1
        let number = fixtureControlCount
        let now = ISO8601DateFormatter().string(from: Date())
        if Self.fixtureLifecycleKinds.contains(intent.kind) {
            let request = ControlRequest(id: "fixture-request-\(number)", kind: intent.kind.rawValue,
                value: intent.value, scope: intent.scope, clientRequestId: intent.clientRequestId,
                state: "requested", note: note, requestedAt: now, appliedAt: nil)
            pendingRequests.removeAll { $0.id == request.id }
            pendingRequests.append(request)
            requestFirstSeen[request.id] = Date()
            return nil
        }
        let rejected = intent.kind == .configure && number % 2 == 1
        let request = ControlRequest(id: "fixture-request-\(number)", kind: intent.kind.rawValue,
            value: intent.value, scope: intent.scope, clientRequestId: intent.clientRequestId,
            state: rejected ? "rejected" : "applied",
            note: rejected ? "Sample rejection: the runner refused this change." : note,
            requestedAt: now, appliedAt: rejected ? nil : now)
        if !rejected, case let .configure(value) = intent.value, let scope = intent.scope {
            let engine = engines?.engines?.first { $0.engineId == value.engineId }
            let oldRevision = scope.kind == .global ? engine?.configuration?.global.revision
                : engine?.configuration?.accounts.first { $0.accountId == scope.accountId }?.revision
            engines = engines?.applyingConfigure(value, scope: scope,
                newRevision: "\(oldRevision ?? "sample")-applied-\(number)", observedAt: now)
            enginesObservedAt = Date()
        }
        pendingRequests.removeAll { $0.id == request.id }
        pendingRequests.append(request)
        requestFirstSeen[request.id] = Date()
        // Fixture terminal results never write or clear the live unresolved-request store.
        return nil
    }

    /// Fixture control walk only: settles every requested lifecycle request, as a dashboard refresh would.
    /// Per kind, odd settlements are rejected and even ones applied: requested -> rejected -> requested -> applied.
    func settleFixtureControls() {
        guard fixtureMode.enabled, fixtureMode.controlWalk else { return }
        let now = ISO8601DateFormatter().string(from: Date())
        for index in pendingRequests.indices where pendingRequests[index].state == "requested" {
            guard let kind = pendingRequests[index].kind,
                  let known = ControlKind(rawValue: kind), Self.fixtureLifecycleKinds.contains(known) else { continue }
            let settled = (fixtureSettledCounts[kind] ?? 0) + 1
            fixtureSettledCounts[kind] = settled
            let rejected = settled % 2 == 1
            pendingRequests[index].state = rejected ? "rejected" : "applied"
            if rejected { pendingRequests[index].note = "Sample rejection: the runner refused this change." }
            pendingRequests[index].appliedAt = rejected ? nil : now
        }
    }

    private func isTerminal(_ request: ControlRequest) -> Bool {
        ControlRequestLifecycle.isTerminal(state: request.state)
    }

    private func request(_ request: ControlRequest, matches intent: ControlIntent) -> Bool {
        if let clientRequestId = intent.clientRequestId { return request.clientRequestId == clientRequestId }
        return request.kind == intent.kind.rawValue && request.value == intent.value
    }

    private func storeUnresolved(_ intent: ControlIntent, since: Date) {
        uncertainIntent = intent
        uncertainSince = since
        if let data = try? JSONEncoder().encode(StoredUnresolvedControl(intent: intent, startedAt: since)) {
            UserDefaults.standard.set(data, forKey: Self.unresolvedControlKey)
        }
    }

    private func clearUnresolvedControl() {
        uncertainIntent = nil
        uncertainSince = nil
        UserDefaults.standard.removeObject(forKey: Self.unresolvedControlKey)
    }

    private func dashboardMessage(_ error: Error) -> String {
        switch error as? DashboardClientError {
        case let .refused(reason): return ControlRefusalMessage.text(for: reason)
        case .noCredential: return "Save your dashboard token in Settings."
        case .unauthorized: return "Dashboard access was denied. Check Settings."
        case .forbidden: return "This dashboard view is temporarily unavailable for your paired account."
        case .rateLimited: return "Dashboard is busy. Retrying shortly."
        default: return "Could not refresh the runner. Showing saved telemetry."
        }
    }
}
