import Foundation
import LocalAuthentication
import LeafHFTCore

struct RiskConfirmation: Identifiable {
    let id = UUID()
    let title: String
    let detail: String
    let actionLabel: String
    let perform: @MainActor () async -> Void
}

@MainActor protocol RiskAuthenticator {
    func authenticate(reason: String) async -> Bool
}

struct DeviceOwnerRiskAuthenticator: RiskAuthenticator {
    let fixtureMode: FixtureMode
    func authenticate(reason: String) async -> Bool {
        if fixtureMode.enabled { return true }
        do {
            return try await LAContext().evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason)
        } catch { return false }
    }
}

extension AppState {
    var canPause: Bool {
        if isOwnerExecution, execution?.capabilities?.pause == true { return true }
        return kashbotStatus?.automatedTrading == .live || kashbotStatus?.automatedTrading == .livePending ||
        runnerAction == .startLive || settingUpDryRun
    }
    var canResume: Bool {
        guard accountSceneActive, !fixtureMode.enabled, !accountMutationInProgress, !checkingSetupProgress,
              let status = kashbotStatus else { return false }
        if isOwnerExecution {
            return execution?.pause?.state == "paused" && status.allows(.startLive)
        }
        return status.automatedTrading == .paused && setupCredentialsPresent && status.hasActionableLane &&
            status.lane?.liveEnabled == false && status.tenant?.runnerHost?.isEmpty == false
    }
    func resumeTrading() async {
        guard canResume else { return }
        let revision = accountControlRevision
        requestRaisesRisk(title: "Resume trading", detail: "Resume live trading for this account.", actionLabel: "Resume trading") { [weak self] in
            guard let self, self.canResume, self.accountControlRevision == revision else { return }
            self.performAccountAction(.startLive, confirmedRevision: revision)
        }
    }
}
