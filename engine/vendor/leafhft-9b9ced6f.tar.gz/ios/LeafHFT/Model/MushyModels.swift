import Foundation

enum MushyCoding {
    static func encoder() -> JSONEncoder {
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        encoder.outputFormatting = [.sortedKeys]
        return encoder
    }
    static func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return decoder
    }
    static func date(_ value: String) -> Date? {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter.date(from: value) ?? ISO8601DateFormatter().date(from: value)
    }
}

enum MushyPromptLimit {
    static let maxUTF8Bytes = 8_000
    static func exceeded(_ text: String) -> Bool { text.utf8.count > maxUTF8Bytes }
}

struct MushyCatalog: Codable {
    struct Model: Codable, Identifiable { let id: String; let reasoningIds: [String] }
    struct Readiness: Codable { let providerId: String; let ready: Bool; let status: String }
    let schemaVersion: Int
    let models: [Model]
    let defaultModelId: String
    let defaultReasoningId: String
    let sources: [String: [String]]
    let sourceScopes: [String: String]
    let providerReadiness: Readiness
    let panelKinds: [String]
    let capabilities: [String]
    let assistantReadiness: AssistantReadiness?

    init(schemaVersion: Int, models: [Model], defaultModelId: String, defaultReasoningId: String,
         sources: [String: [String]], sourceScopes: [String: String], providerReadiness: Readiness,
         panelKinds: [String], capabilities: [String], assistantReadiness: AssistantReadiness? = nil) {
        self.schemaVersion = schemaVersion
        self.models = models
        self.defaultModelId = defaultModelId
        self.defaultReasoningId = defaultReasoningId
        self.sources = sources
        self.sourceScopes = sourceScopes
        self.providerReadiness = providerReadiness
        self.panelKinds = panelKinds
        self.capabilities = capabilities
        self.assistantReadiness = assistantReadiness
    }

    func reconciled(_ saved: MushySelections) -> MushySelections {
        let compatible = models.filter { !$0.reasoningIds.isEmpty }
        let model = compatible.first { $0.id == saved.modelId }
            ?? compatible.first { $0.id == defaultModelId } ?? compatible.first
        let reasoning = model?.reasoningIds.contains(saved.reasoningId) == true ? saved.reasoningId :
            (model?.reasoningIds.contains(defaultReasoningId) == true ? defaultReasoningId : model?.reasoningIds.first ?? "")
        let selected = Array(Set(saved.sources.filter { sources[$0] != nil })).sorted()
        return MushySelections(sessionId: saved.sessionId, modelId: model?.id ?? "", reasoningId: reasoning,
            sources: selected.isEmpty ? Array(sources.keys.sorted().prefix(1)) : selected)
    }
}

struct MushySelections: Codable, Equatable {
    var sessionId: String? = nil
    var modelId = ""
    var reasoningId = ""
    var sources: [String] = []
}
struct MushyMessage: Codable, Identifiable {
    let role: String
    let content: String
    let jobId: String
    let createdAt: String
    var id: String { jobId + ":" + role }
}
struct MushySession: Codable, Identifiable {
    let id: String
    let createdAt: String
    let updatedAt: String
    var messages: [MushyMessage]
}
struct MushyJob: Codable, Identifiable {
    let id: String
    var status: String
    let createdAt: String?
    let completedAt: String?
    let artifactId: String?
    let error: String?
    var isTerminal: Bool { ["completed", "failed", "cancelled", "expired"].contains(status) }
    static let staleActiveInterval: TimeInterval = 15 * 60
    func age(now: Date) -> TimeInterval? {
        guard let createdAt else { return nil }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let fractionalDate = formatter.date(from: createdAt)
        formatter.formatOptions = [.withInternetDateTime]
        guard let date = fractionalDate ?? formatter.date(from: createdAt) else { return nil }
        return now.timeIntervalSince(date)
    }
    func isStaleActive(now: Date) -> Bool {
        !isTerminal && (age(now: now) ?? -1) > Self.staleActiveInterval
    }
}
struct MushyBinding: Codable {
    let artifactId: String
    let artifactVersion: Int
    let digest: String
}
struct MushySlot: Codable {
    let artifactId: String
    let artifactVersion: Int
    let digest: String
    let revision: Int
    let history: [MushyBinding]
    var rollbackTarget: MushyBinding? { history.last { $0.artifactId != artifactId } }
}
struct MushyProposal: Codable, Identifiable {
    let id: String
    let artifactId: String
    let digest: String
    let targetSlot: String
    let rationale: String
    let state: String
}
struct MushySnapshot: Codable {
    var sessions: [MushySession] = []
    var jobs: [MushyJob] = []
    var slots: [String: MushySlot] = [:]
    var proposals: [MushyProposal] = []
    var selections = MushySelections()
    var assistantJobs: [AssistantJobSummary]? = nil
}
struct MushySessionRequest: Codable { let requestId: String }
struct AssistantReadiness: Codable {
    let ready: Bool
    let status: String
    let observedAt: String?
}
struct AssistantJobSummary: Codable { let id: String; let status: String }
struct AssistantTurnRequest: Codable {
    let requestId: String
    let sessionId: String
    let input: String
    let effort: String?
    let mode: String?

    init(requestId: String, sessionId: String, input: String, effort: String?, mode: String? = nil) {
        self.requestId = requestId
        self.sessionId = sessionId
        self.input = input
        self.effort = effort
        self.mode = mode
    }
}
struct AssistantTurnReceipt: Codable { let jobId: String; let status: String }
struct AssistantCard: Decodable, Identifiable {
    enum State: String, Decodable { case open, approved, expired, failed }
    enum Kind: String, Decodable {
        case slotPromotion = "slot_promotion"
        case configDraft = "config_draft"
        case control

        var actionLabel: String { self == .slotPromotion ? "Save" : "Approve" }
        var approvedLabel: String { self == .slotPromotion ? "Saved" : "Approved" }
        var failedLabel: String { self == .slotPromotion ? "Could not save" : "Could not apply" }
        var actionAccessibilityIdentifier: String {
            self == .slotPromotion ? "assistant.card.save" : "assistant.card.approve"
        }
    }
    struct Field: Decodable, Equatable {
        let key: String
        let label: String
        let value: String
    }
    let cardId: String
    let cardDigest: String
    let kind: Kind
    let title: String
    let fields: [Field]
    var state: State
    let expiresAt: String
    let engineId: String?
    let identity: AssistantEngineIdentity?
    let nominationId: String?
    let turnId: String?
    let sessionId: String?
    let createdAt: String?
    var id: String { cardId }

    var hasReadableDetails: Bool {
        !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !fields.isEmpty
    }

    func matchesApprovalSnapshot(_ snapshot: AssistantCard) -> Bool {
        id == snapshot.id && cardDigest == snapshot.cardDigest && state == .open
            && snapshot.state == .open && title == snapshot.title && fields == snapshot.fields
    }

    private static func displayText(_ text: String, limit: Int) -> String {
        text.count > limit ? String(text.prefix(limit)) + "…" : text
    }

    var stateLabel: String {
        switch state {
        case .open: return kind.actionLabel
        case .approved: return kind.approvedLabel
        case .expired: return "Expired"
        case .failed: return kind.failedLabel
        }
    }

    static func validId(_ value: String) -> Bool {
        value.range(of: "^card-[A-Za-z0-9._:-]{1,120}$", options: .regularExpression) != nil
            && !value.contains("\n") && !value.contains("\r")
    }

    fileprivate struct Wire: Decodable {
        let cardId: String
        let cardDigest: String
        let kind: String
        let title: String
        let fields: [Field]
        let state: String
        let expiresAt: String
        let engineId: String?
        let identity: AssistantEngineIdentity?
        let nominationId: String?
        let turnId: String?
        let sessionId: String?
        let createdAt: String?

        func card() throws -> AssistantCard? {
            guard let kind = Kind(rawValue: kind), let state = State(rawValue: state) else { return nil }
            guard AssistantCard.validId(cardId), cardDigest.count == 64,
                  cardDigest.allSatisfy({ "0123456789abcdefABCDEF".contains($0) }),
                  MushyCoding.date(expiresAt) != nil else { throw MushyClientError.response }
            return AssistantCard(cardId: cardId, cardDigest: cardDigest, kind: kind,
                title: AssistantCard.displayText(title, limit: 160), fields: fields.map {
                    Field(key: $0.key, label: AssistantCard.displayText($0.label, limit: 80),
                          value: AssistantCard.displayText($0.value, limit: 500))
                }, state: state, expiresAt: expiresAt, engineId: engineId, identity: identity,
                nominationId: nominationId, turnId: turnId, sessionId: sessionId, createdAt: createdAt)
        }
    }

    private init(cardId: String, cardDigest: String, kind: Kind, title: String,
                 fields: [Field], state: State, expiresAt: String, engineId: String?,
                 identity: AssistantEngineIdentity?, nominationId: String?, turnId: String?,
                 sessionId: String?, createdAt: String?) {
        self.cardId = cardId
        self.cardDigest = cardDigest
        self.kind = kind
        self.title = title
        self.fields = fields
        self.state = state
        self.expiresAt = expiresAt
        self.engineId = engineId
        self.identity = identity
        self.nominationId = nominationId
        self.turnId = turnId
        self.sessionId = sessionId
        self.createdAt = createdAt
    }

    init(from decoder: Decoder) throws {
        guard let card = try Wire(from: decoder).card() else { throw MushyClientError.response }
        self = card
    }
}

struct AssistantCardsPage: Decodable {
    let schema: String
    let cards: [AssistantCard]
    private enum CodingKeys: String, CodingKey { case schema, cards }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        schema = try container.decode(String.self, forKey: .schema)
        guard schema == "kashbot.assistant.cards.v1" else { throw MushyClientError.response }
        let wire = try container.decode([AssistantCard.Wire].self, forKey: .cards)
        cards = Array(try wire.compactMap { try $0.card() }.prefix(10))
        guard Set(cards.map(\.id)).count == cards.count else { throw MushyClientError.response }
    }
}

struct AssistantEngineIdentity: Decodable {
    let name: String
    let ticker: String
    let symbol: String
    let tint: String
    let tintHex: String
    let glyphPath: String
    let source: String

    static func validTicker(_ value: String) -> Bool {
        value.range(of: "^[A-Z][A-Z0-9]{1,4}$", options: .regularExpression) != nil
            && value.unicodeScalars.allSatisfy { CharacterSet.alphanumerics.contains($0) }
    }
}

struct AssistantNomination: Decodable, Identifiable {
    static func validId(_ value: String) -> Bool {
        value.count == 16 && value.allSatisfy { "0123456789abcdef".contains($0) }
    }

    struct Evidence: Decodable {
        let n: Double
        let returnPct: Double
        let lb90: Double
        let days: Double
        let markets: Double
    }
    let id: String
    let account: String
    let kind: String
    let status: String
    let engineId: String
    let books: [String]
    let evidence: Evidence
    let packetAsOf: String
    let receivedAt: String
    let stale: Bool
    let ownAccount: Bool
    let actionable: Bool
    let acceptAvailable: Bool
    let reason: String?
    let cardId: String?
    let identity: AssistantEngineIdentity

    var reasonText: String? {
        guard let reason else { return nil }
        switch reason {
        case "not available yet":
            return kind != "tune"
                ? "Promotions and book changes cannot be approved here yet."
                : "This suggestion cannot be approved yet."
        case "nomination_other_account":
            return "This suggestion belongs to account " + account + ". Approve it from that account's phone."
        case "open card already linked":
            return "Already waiting for your approval above."
        default:
            return "This suggestion cannot be approved here."
        }
    }

    var statusText: String {
        let text = status.replacingOccurrences(of: "_", with: " ").lowercased()
        guard let first = text.first else { return "Unknown" }
        return String(first).uppercased() + text.dropFirst()
    }

    private enum CodingKeys: String, CodingKey {
        case id, account, kind, status, engineId, books, evidence, packetAsOf, receivedAt
        case stale, ownAccount, actionable, acceptAvailable, reason, cardId, identity
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        account = try c.decode(String.self, forKey: .account)
        kind = try c.decode(String.self, forKey: .kind)
        status = try c.decode(String.self, forKey: .status)
        engineId = try c.decode(String.self, forKey: .engineId)
        books = try c.decode([String].self, forKey: .books)
        evidence = try c.decode(Evidence.self, forKey: .evidence)
        packetAsOf = try c.decode(String.self, forKey: .packetAsOf)
        receivedAt = try c.decode(String.self, forKey: .receivedAt)
        stale = try c.decode(Bool.self, forKey: .stale)
        ownAccount = try c.decode(Bool.self, forKey: .ownAccount)
        actionable = try c.decode(Bool.self, forKey: .actionable)
        acceptAvailable = try c.decodeIfPresent(Bool.self, forKey: .acceptAvailable) ?? false
        reason = try c.decodeIfPresent(String.self, forKey: .reason)
        cardId = try c.decodeIfPresent(String.self, forKey: .cardId)
        identity = try c.decode(AssistantEngineIdentity.self, forKey: .identity)
    }
}

struct AssistantNominationAccept: Decodable {
    let schema: String
    let nominationId: String
    let cardId: String
    let created: Bool
    private enum CodingKeys: String, CodingKey { case schema, nominationId, cardId, created }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        schema = try c.decode(String.self, forKey: .schema)
        nominationId = try c.decode(String.self, forKey: .nominationId)
        cardId = try c.decode(String.self, forKey: .cardId)
        created = try c.decode(Bool.self, forKey: .created)
        guard schema == "kashbot.assistant.inbox-accept.v1",
              AssistantNomination.validId(nominationId), AssistantCard.validId(cardId) else {
            throw MushyClientError.response
        }
    }
}

struct AssistantInboxPage: Decodable {
    let schema: String
    let generatedAt: String
    let canApprove: Bool
    let seenThrough: String?
    let unreadCount: Int
    let cards: [AssistantCard]
    let nominations: [AssistantNomination]
    private enum CodingKeys: String, CodingKey {
        case schema, generatedAt, canApprove, seenThrough, unreadCount, cards, nominations
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        schema = try c.decode(String.self, forKey: .schema)
        guard schema == "kashbot.assistant.inbox.v1" else { throw MushyClientError.response }
        generatedAt = try c.decode(String.self, forKey: .generatedAt)
        canApprove = try c.decode(Bool.self, forKey: .canApprove)
        seenThrough = try c.decodeIfPresent(String.self, forKey: .seenThrough)
        unreadCount = try c.decode(Int.self, forKey: .unreadCount)
        let wire = try c.decode([AssistantCard.Wire].self, forKey: .cards)
        cards = Array(try wire.compactMap { try $0.card() }.prefix(20))
        nominations = try c.decode([AssistantNomination].self, forKey: .nominations)
        guard unreadCount >= 0, MushyCoding.date(generatedAt) != nil,
              Set(cards.map(\.id)).count == cards.count else { throw MushyClientError.response }
    }
}

struct AssistantInboxCount: Decodable {
    let schema: String
    let unreadCount: Int
    private enum CodingKeys: String, CodingKey { case schema, unreadCount }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        schema = try c.decode(String.self, forKey: .schema)
        unreadCount = try c.decode(Int.self, forKey: .unreadCount)
        guard schema == "kashbot.assistant.inbox-count.v1", unreadCount >= 0 else {
            throw MushyClientError.response
        }
    }
}

struct AssistantInboxSeen: Decodable { let seenThrough: String }

struct AssistantColumn: Codable, Hashable {
    let key: String
    let label: String
    let format: String
}
struct AssistantPanel: Codable {
    let kind: String
    let title: String
    let columns: [AssistantColumn]
    let rows: [[String: MushyValue]]
}
enum AssistantEventPayload {
    case status(stage: String)
    case text(delta: String)
    case tool(id: String, name: String, label: String, state: String)
    case view(title: String, panels: [AssistantPanel])
    case error(message: String)
    case done(text: String)
    case unknown
}
struct AssistantEvent: Decodable {
    let seq: Int
    let type: String
    let payload: AssistantEventPayload

    init(seq: Int, type: String, payload: AssistantEventPayload) {
        self.seq = seq
        self.type = type
        self.payload = payload
    }

    private enum CodingKeys: String, CodingKey { case seq, type, payload }
    private enum PayloadKeys: String, CodingKey { case stage, delta, id, name, label, state, title, panels, message, text }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        seq = try container.decode(Int.self, forKey: .seq)
        type = try container.decode(String.self, forKey: .type)
        do {
            let value = try container.nestedContainer(keyedBy: PayloadKeys.self, forKey: .payload)
            switch type {
            case "status": payload = .status(stage: try value.decode(String.self, forKey: .stage))
            case "text": payload = .text(delta: try value.decode(String.self, forKey: .delta))
            case "tool":
                payload = .tool(id: try value.decode(String.self, forKey: .id),
                    name: try value.decode(String.self, forKey: .name),
                    label: try value.decode(String.self, forKey: .label),
                    state: try value.decode(String.self, forKey: .state))
            case "view":
                payload = .view(title: try value.decode(String.self, forKey: .title),
                    panels: try value.decode([AssistantPanel].self, forKey: .panels))
            case "error": payload = .error(message: try value.decode(String.self, forKey: .message))
            case "done": payload = .done(text: try value.decode(String.self, forKey: .text))
            default: payload = .unknown
            }
        } catch { payload = .unknown }
    }
}
struct AssistantEventsPage: Decodable {
    let jobId: String
    let status: String
    let events: [AssistantEvent]
    let next: Int
}

struct MushySessionReceipt: Codable { let sessionId: String; let session: MushySession }
struct MushyTurnRequest: Codable {
    let requestId: String
    let sessionId: String
    let input: String
    let modelId: String
    let reasoningId: String
    let sources: [String]
}
struct MushyTurnReceipt: Codable { let jobId: String; let status: String }
enum MushySlotAction: String, Codable { case publish, rollback }
struct MushySlotRequest: Codable {
    let requestId: String
    let slot: String
    let action: MushySlotAction
    let artifactId: String
    let expectedRevision: Int
}
struct MushyProposalRequest: Codable {
    let requestId: String
    let artifactId: String
    let targetSlot: String
    let rationale: String
}
struct MushyProposalReceipt: Codable { let proposal: MushyProposal }
struct MushySlots: Codable { let slots: [String: MushySlot] }
struct MushyProposals: Codable { let proposals: [MushyProposal] }
struct MushyEvent: Codable, Identifiable {
    let sequence: Int
    let type: String
    let jobId: String
    let attempt: Int
    let at: String
    var id: Int { sequence }
}
struct MushyEvents: Codable { let jobId: String; let events: [MushyEvent]; let nextCursor: Int }

/// JSON data stays data. Nested values are rejected by panel validation.
indirect enum MushyValue: Codable, Equatable {
    case string(String), number(Double), bool(Bool), null, object([String: MushyValue]), array([MushyValue])
    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { self = .null }
        else if let value = try? c.decode(Bool.self) { self = .bool(value) }
        else if let value = try? c.decode(Double.self) { self = .number(value) }
        else if let value = try? c.decode(String.self) { self = .string(value) }
        else if let value = try? c.decode([String: MushyValue].self) { self = .object(value) }
        else { self = .array(try c.decode([MushyValue].self)) }
    }
    func encode(to encoder: Encoder) throws {
        var c = encoder.singleValueContainer()
        switch self {
        case .null: try c.encodeNil()
        case .string(let value): try c.encode(value)
        case .number(let value): try c.encode(value)
        case .bool(let value): try c.encode(value)
        case .object(let value): try c.encode(value)
        case .array(let value): try c.encode(value)
        }
    }
    var text: String {
        switch self {
        case .string(let value): return value
        case .number(let value): return value.isFinite ? value.formatted() : "Invalid number"
        case .bool(let value): return value ? "Yes" : "No"
        case .null: return "Unavailable"
        case .object, .array: return "Unsupported value"
        }
    }
    var number: Double? { if case .number(let value) = self, value.isFinite { return value }; return nil }
    var boundedScalar: Bool {
        switch self {
        case .string(let value): return value.count <= 256
        case .number(let value): return value.isFinite
        case .bool, .null: return true
        case .object, .array: return false
        }
    }
}

struct ArtifactSpec: Codable {
    struct Panel: Codable {
        let kind: String
        let title: String
        let source: String
        let fields: [String]
    }
    let schemaVersion: Int
    let title: String
    let panels: [Panel]
}
struct MushyArtifact: Codable, Identifiable {
    struct Lineage: Codable { let sessionId: String?; let jobId: String; let sourceCommit: String }
    struct Telemetry: Codable { let capturedAt: String; let data: [String: [[String: MushyValue]]] }
    struct Generation: Codable {
        let selectedSources: [String]
        let sourceDigest: String
        let upstreamMushyCommit: String
    }
    let id: String
    let version: Int
    let mediaType: String
    let digest: String
    let artifactDigest: String
    let producingJobId: String
    let sourceParser: String
    let sourceDigest: String
    let lineage: Lineage
    let generationReceipt: Generation
    let artifact: ArtifactSpec
    let telemetry: Telemetry
    let configDraft: MushyDraftContents?

    func validationMessage(catalog: MushyCatalog?) -> String? {
        guard version == 1, artifact.schemaVersion == 1 else { return "This artifact version is not supported. Update the app to view it." }
        let hex = { (value: String) in value.count == 64 && value.allSatisfy { "0123456789abcdef".contains($0) } }
        guard mediaType == "application/vnd.kashbot.artifact+json", hex(digest), digest == artifactDigest,
              hex(sourceDigest), sourceDigest == generationReceipt.sourceDigest,
              sourceParser == "kashbot.telemetry.fixed.v1", producingJobId == id, lineage.jobId == id,
              UUID(uuidString: id) != nil,
              lineage.sessionId.flatMap({ UUID(uuidString: $0) }) != nil, !lineage.sourceCommit.isEmpty,
              lineage.sourceCommit == generationReceipt.upstreamMushyCommit,
              MushyCoding.date(telemetry.capturedAt) != nil else { return "This artifact has invalid source lineage." }
        guard let catalog, catalog.schemaVersion == 1,
              catalog.capabilities.contains("visualization.native"),
              catalog.capabilities.contains("telemetry.parse.fixed") else {
            return "Refresh Studio to validate this view's capabilities."
        }
        guard !artifact.title.isEmpty, artifact.title.count <= 100, (1...12).contains(artifact.panels.count),
              telemetry.data.count <= catalog.sources.count else { return "This dashboard exceeds the supported bounds." }
        for panel in artifact.panels {
            guard ["line", "table", "metric"].contains(panel.kind), catalog.panelKinds.contains(panel.kind) else {
                return "This panel kind is not supported on this device."
            }
            guard !panel.title.isEmpty, panel.title.count <= 100,
                  let allowed = catalog.sources[panel.source], generationReceipt.selectedSources.contains(panel.source),
                  !panel.fields.isEmpty, panel.fields.count <= allowed.count,
                  Set(panel.fields).count == panel.fields.count, panel.fields.allSatisfy({ allowed.contains($0) }),
                  let rows = telemetry.data[panel.source], rows.count <= 1000 else {
                return "This panel uses unsupported telemetry fields or sources."
            }
            guard rows.allSatisfy({ row in row.count <= allowed.count && row.keys.allSatisfy { allowed.contains($0) }
                && panel.fields.allSatisfy { row[$0]?.boundedScalar == true } }) else {
                return "This panel contains an unsupported field shape."
            }
            if panel.kind == "line" {
                guard panel.fields.count >= 2,
                      rows.allSatisfy({ row in panel.fields.dropFirst().allSatisfy { field in
                          row[field] == .null || row[field]?.number != nil
                      } }) else { return "Line panels need a label and finite numeric series." }
            }
        }
        return nil
    }
}

struct MushyDraftContents: Codable {
    struct Value: Codable { let engineId: String; let enabled: Bool? }
    let value: Value
    let expectedRevision: String
    let summary: String
    let summaryDigest: String
    let before: [String: MushyValue]
    let after: [String: MushyValue]
    let practicalEffect: String
    let risk: String
    let createdAt: String
    let expiresAt: String
    let consumedAt: String?
}
struct MushyConfigDraft: Decodable, Identifiable {
    let id: String
    let contents: MushyDraftContents
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(String.self, forKey: .id)
        contents = try MushyDraftContents(from: decoder)
    }
    enum CodingKeys: String, CodingKey { case id }
    func blocker(now: Date = Date()) -> String? {
        guard contents.summaryDigest.count == 64,
              contents.summaryDigest.allSatisfy({ "0123456789abcdef".contains($0) }),
              !contents.before.isEmpty, !contents.after.isEmpty else { return "This draft summary is incomplete. Ask for a new draft." }
        if contents.consumedAt != nil { return "This draft has already been used." }
        guard let expiry = MushyCoding.date(contents.expiresAt), expiry > now else { return "This draft expired. Ask Studio for a new draft." }
        return nil
    }
}
struct MushyConfigApplyRequest: Codable { let requestId: String; let summaryDigest: String }
struct MushyConfigReceipt: Codable { let draftId: String; let controlRequestId: String; let state: String }

/// Only recovery data is persisted. Server snapshots and telemetry remain in memory.
struct MushyPendingRequest: Codable, Equatable {
    enum Kind: String, Codable { case session, turn, slot, proposal, config }
    let requestId: String
    let kind: Kind
    let path: String
    let body: Data
}
struct MushyRecovery: Codable {
    var pending: MushyPendingRequest?
    var input = ""
    var admittedInputs: [String: String] = [:]
    var configReceipts: [String: MushyConfigReceipt] = [:]
    mutating func boundAdmittedInputs(keeping jobIds: Set<String>, artifactIds: Set<String>, limit: Int = 50) {
        let inputKeys = Set(admittedInputs.keys.filter { jobIds.contains($0) }.sorted().prefix(max(0, limit)))
        admittedInputs = admittedInputs.filter { inputKeys.contains($0.key) }
        let receiptKeys = Set(configReceipts.keys.filter { artifactIds.contains($0) }.sorted().prefix(max(0, limit)))
        configReceipts = configReceipts.filter { receiptKeys.contains($0.key) }
    }
}
