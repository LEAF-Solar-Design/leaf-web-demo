import Foundation
import LeafHFTCore

/// Fixture runs are entirely local and never fall back to live services.
struct FixtureMode {
    let enabled: Bool
    let noKey: Bool
    let controlWalk: Bool
    let oneAccount: Bool
    static var current: FixtureMode { FixtureMode(arguments: ProcessInfo.processInfo.arguments) }
    /// Hosted unit tests must not start the app's live polling loops.
    /// Individual client tests still select their own stub transport explicitly.
    static var appLaunch: FixtureMode {
        if current.enabled { return current }
        if ProcessInfo.processInfo.environment["XCTestConfigurationFilePath"] != nil {
            return FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])
        }
        return current
    }
    init(arguments: [String]) {
        func flag(_ name: String) -> Bool {
            guard let index = arguments.firstIndex(of: name), arguments.indices.contains(index + 1) else { return false }
            return arguments[index + 1] == "1"
        }
        enabled = flag("-LEAFHFT_FIXTURES")
        noKey = enabled && flag("-LEAFHFT_NO_KEY")
        controlWalk = enabled && flag("-LEAFHFT_CONTROL_WALK")
        oneAccount = controlWalk && flag("-LEAFHFT_ONE_ACCOUNT")
    }
    func requireLiveAccess() throws {
        if enabled { throw FixtureAccessError.disabled }
    }
}

enum FixtureAccessError: Error { case disabled, missingResource(String) }

extension FixtureMode {
    /// Autotune uses the same local-only launch switch as the assistant conversation fixtures.
    /// The catalog crown glyph (Phosphor), split so the entropy scan reads short pieces.
    static let assistantGlyphPath = "M248,80a28,28,0,1,0-51.12,15.77l-26.79,33L146,73.4a28,28"
        + ",0,1,0-36.06,0L85.91,128.74l-26.79-33a28,28,0,1,0-26.6,1"
        + "2L47,194.63A16,16,0,0,0,62.78,208H193.22A16,16,0,0,0,209"
        + ",194.63l14.47-86.85A28,28,0,0,0,248,80ZM128,40a12,12,0,1"
        + ",1-12,12A12,12,0,0,1,128,40ZM24,80A12,12,0,1,1,36,92,12,"
        + "12,0,0,1,24,80ZM220,92a12,12,0,1,1,12-12A12,12,0,0,1,220"
        + ",92Z"

    static func assistantInboxData(approved: Set<String> = [], seenThrough: String? = nil) throws -> Data {
        let identity: [String: Any] = ["name": "Gold Scout", "ticker": "GOLD", "symbol": "G",
            "tint": "gold", "tint_hex": "#D4AF37", "glyph_path": assistantGlyphPath, "source": "derived"]
        func card(_ id: String, kind: String, nominationId: String?) -> [String: Any] {
            var value: [String: Any] = ["card_id": id, "card_digest": String(repeating: "a", count: 64),
                "kind": kind, "title": kind == "config_draft" ? "Tune Gold Scout" : "Save Gold Scout view",
                "fields": [["key": "risk", "label": "Risk limit", "value": "10 → 8"]],
                "state": "open", "expires_at": "2099-10-01T13:00:00Z",
                "created_at": "2026-10-01T12:00:00Z", "turn_id": MushyClient.fixtureArtifactId,
                "session_id": MushyClient.fixtureSessionId, "engine_id": "fixture-gold", "identity": identity]
            if let nominationId { value["nomination_id"] = nominationId }
            return value
        }
        func nomination(_ id: String, own: Bool, kind: String) -> [String: Any] {
            ["id": id, "account": own ? "owner" : "other-account", "kind": kind, "status": "pending",
             "engine_id": "fixture-gold", "books": ["gold-15m"],
             "evidence": ["n": 42, "return_pct": 3.2, "lb90": 1.1, "days": 7, "markets": 12],
             "packet_as_of": "2099-10-01T12:00:00Z", "received_at": "2026-10-01T12:05:00Z",
             "stale": false, "own_account": own, "actionable": own && kind == "tune",
             "accept_available": own && kind == "tune",
             "reason": own && kind == "tune" ? NSNull() :
                (kind == "promote_shadow" ? "not available yet" : "This suggestion is read-only."), "identity": identity]
        }
        return try JSONSerialization.data(withJSONObject: ["schema": "kashbot.assistant.inbox.v1",
            "generated_at": "2026-10-01T12:10:00Z", "can_approve": true,
            "seen_through": seenThrough as Any? ?? NSNull(), "unread_count": seenThrough == nil ? 5 : 0,
            "cards": [card("card-fixture-tune", kind: "config_draft", nominationId: "0000000000000001"),
                card("card-fixture-slot", kind: "slot_promotion", nominationId: nil)]
                .filter { !approved.contains($0["card_id"] as? String ?? "") },
            "nominations": [nomination("0000000000000001", own: true, kind: "tune"),
                nomination("0000000000000002", own: false, kind: "tune"),
                nomination("0000000000000003", own: true, kind: "promote_shadow")]])
    }

    static func assistantNominationAcceptData(id: String, packetAsOf: String) throws -> Data {
        guard id == "0000000000000001" else {
            throw MushyClientError.refused(status: 403, code: "autotune_action_not_available")
        }
        guard packetAsOf == "2099-10-01T12:00:00Z" else {
            throw MushyClientError.refused(status: 409, code: "nomination_changed")
        }
        return try JSONSerialization.data(withJSONObject: ["schema": "kashbot.assistant.inbox-accept.v1",
            "nomination_id": id, "card_id": "card-fixture-tune", "created": false])
    }
}

/// Captures every URL, including arbitrary real hosts, before DNS or transport.
final class FixtureNetworkBlocker: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        client?.urlProtocol(self, didFailWithError: URLError(.notConnectedToInternet))
    }
    override func stopLoading() {}
}

struct FixtureCorpus {
    static let names = ["activity", "balance", "books", "engines", "fills", "markets", "positions", "settlements", "signature-fixture", "exits", "calibration", "attempt-funnel"]
    /// Probe-paradigm fixtures (D3 probes board). Required like `names`, counted apart from the account corpus.
    static let lifecycleNames = ["probes"]
    let data: [String: Data]
    let lifecycle: [String: Data]
    init(bundle: Bundle = .main, mode: FixtureMode = .current) throws {
        func load(_ names: [String]) throws -> [String: Data] {
            var loaded: [String: Data] = [:]
            for name in names {
                guard let url = bundle.url(forResource: name, withExtension: "json", subdirectory: "Fixtures") else {
                    throw FixtureAccessError.missingResource(name)
                }
                let bytes = try Data(contentsOf: url)
                _ = try JSONSerialization.jsonObject(with: bytes)
                loaded[name] = bytes
            }
            return loaded
        }
        var loaded = try load(Self.names)
        lifecycle = try load(Self.lifecycleNames)
        if mode.oneAccount {
            guard let engines = loaded["engines"] else { throw FixtureAccessError.missingResource("engines one-account") }
            loaded["engines"] = try Self.oneAccountEngines(engines)
        }
        data = loaded
    }
    // Fixture control walk only: one configurable account, so the engine toggle can be walked; engines.json on disk is unchanged
    private static func oneAccountEngines(_ bytes: Data) throws -> Data {
        guard var object = try JSONSerialization.jsonObject(with: bytes) as? [String: Any],
              let accounts = object["accounts"] as? [[String: Any]] else {
            throw FixtureAccessError.missingResource("engines one-account")
        }
        let main = accounts.filter { $0["id"] as? String == "sample-main" }
        guard main.count == 1 else { throw FixtureAccessError.missingResource("engines one-account") }
        object["accounts"] = main
        return try JSONSerialization.data(withJSONObject: object, options: .sortedKeys)
    }
    func decode<T: Decodable>(_ name: String, as type: T.Type) throws -> T {
        guard let bytes = data[name] ?? lifecycle[name] else { throw FixtureAccessError.missingResource(name) }
        return try accountJSONDecoder().decode(type, from: bytes)
    }
}
