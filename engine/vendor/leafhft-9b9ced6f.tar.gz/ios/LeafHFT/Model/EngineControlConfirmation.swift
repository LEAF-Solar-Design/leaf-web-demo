import Foundation
import Observation
import LeafHFTCore

struct EngineControlConfirmation: Identifiable, Equatable {
    enum Kind: Equatable { case enable, disable, bind, create }
    let id: UUID
    let kind: Kind
    let engineId: String
    let title: String
    let message: String
    let confirmLabel: String
    let isDestructive: Bool
    let intent: ControlIntent
    let note: String?

    static func toggle(engine: Engine, enabled: Bool, host: String, scope: ControlScope, scopeLabel: String, expectedRevision: String, clientRequestId: String) throws -> Self {
        let name = engine.name ?? engine.engineId
        let label = enabled ? "Turn on \(name)" : "Pause \(name)"
        return Self(id: UUID(), kind: enabled ? .enable : .disable, engineId: engine.engineId,
            title: label + "?",
            message: enabled ? "\(name) can open new positions with real money in \(scopeLabel)." :
                "\(name) stops opening new positions in \(scopeLabel). Open positions keep their normal exit and risk handling.",
            confirmLabel: label, isDestructive: !enabled,
            intent: try .configure(engineId: engine.engineId, host: host, scope: scope,
                enabled: .value(enabled), expectedRevision: expectedRevision, clientRequestId: clientRequestId),
            note: enabled ? "Enabled from Engines" : "Disabled from Engines")
    }

    static func bind(engine: Engine, symbol: String?, note: String?) throws -> Self {
        let name = engine.name ?? engine.engineId
        let label = "Bind \(name) to \(symbol ?? "all books")"
        return Self(id: UUID(), kind: .bind, engineId: engine.engineId, title: label + "?",
            message: symbol.map { "The \($0) book switches to \(name) right away. New entries on \($0) use \(name) with real money." }
                ?? "Every book switches to \(name) right away. New entries use \(name) with real money.",
            confirmLabel: label, isDestructive: false,
            intent: try .bind(symbol: symbol, engineId: engine.engineId), note: note)
    }

    static func create(source: Engine, newId: String, name: String, note: String?) throws -> Self {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return Self(id: UUID(), kind: .create, engineId: source.engineId, title: "Create \(trimmed)?",
            message: "Creates engine \(trimmed) (\(newId)) from \(source.name ?? source.engineId)'s settings. It starts disabled and not bound to any book.",
            confirmLabel: "Create \(trimmed)", isDestructive: false,
            intent: try ControlIntent.create(engineId: newId, name: trimmed, from: source.engineId), note: note)
    }

    static let refusedNotListed = "Nothing was sent. This engine is no longer listed."
    static let refusedOutcomeUnknown = "Nothing was sent. An earlier request's result is still unknown. Check Requests first."
    static let refusedPending = "Nothing was sent. This engine already has a request pending. Check Requests first."
    static let refusedNotReported = "Nothing was sent. This engine's current state is not reported. Refresh before changing it."
    static let refusedChanged = "Nothing was sent. This engine changed while the confirmation was open. Check it and try again."
    static let notReported = "This engine's current state is not reported. Refresh before changing it."
    static let unavailable = "This engine cannot be changed right now."
    static let busy = "A request is already being sent."

    static func toggleRefusal(held: EngineControlConfirmation, current: EngineToggleSnapshot?) -> String? {
        guard let current else { return refusedNotListed }
        if current.outcomeUnknown { return refusedOutcomeUnknown }
        if current.pending { return refusedPending }
        if current.observedEnabled == nil { return refusedNotReported }
        if !current.canToggle || current.host != held.intent.host ||
            current.revision != held.intent.expectedRevision || current.scope != held.intent.scope {
            return refusedChanged
        }
        return nil
    }

    static func sheetRefusal(engineListed: Bool, outcomeUnknown: Bool) -> String? {
        if outcomeUnknown { return refusedOutcomeUnknown }
        if !engineListed { return refusedNotListed }
        return nil
    }

    // Builds and holds only; it has no path to submit
    @MainActor @discardableResult
    static func requestToggle(engine: Engine, enabled: Bool, current: EngineToggleSnapshot, clientRequestId: String, gate: EngineControlGate) -> String? {
        if gate.sending { return busy }
        if current.observedEnabled == nil { return notReported }
        guard current.canToggle, !current.outcomeUnknown, !current.pending,
              let host = current.host, !host.isEmpty,
              let revision = current.revision, !revision.isEmpty else { return unavailable }
        do {
            let c = try toggle(engine: engine, enabled: enabled, host: host, scope: current.scope,
                scopeLabel: current.scopeLabel, expectedRevision: revision, clientRequestId: clientRequestId)
            return gate.hold(c) ? nil : busy
        } catch {
            return error.localizedDescription
        }
    }
}

struct EngineToggleSnapshot: Equatable {
    let canToggle: Bool
    let outcomeUnknown: Bool
    let pending: Bool
    let observedEnabled: Bool?
    let host: String?
    let revision: String?
    let scope: ControlScope
    let scopeLabel: String
}

// Nothing reaches submit without hold then confirm of the same id, and confirm re-checks live state first
@MainActor @Observable final class EngineControlGate {
    private(set) var pending: EngineControlConfirmation?
    private(set) var sending = false
    // Haptic ticks move only after the server answered; they never gate a send
    private(set) var successTick = 0
    private(set) var failureTick = 0
    private var heldId: UUID?

    @discardableResult func hold(_ c: EngineControlConfirmation) -> Bool {
        guard !sending else { return false }
        pending = c
        heldId = c.id
        return true
    }

    func dismiss() { pending = nil }

    func cancel() {
        pending = nil
        heldId = nil
    }

    enum Outcome: Equatable { case notSent, refused(String), sent(String?) }

    func confirm(_ c: EngineControlConfirmation, recheck: () -> String?, willSend: () -> Void = {}, submit: (ControlIntent, String?) async -> String?) async -> Outcome {
        guard !sending, heldId == c.id else { return .notSent }
        if let reason = recheck() {
            heldId = nil
            pending = nil
            return .refused(reason)
        }
        heldId = nil
        pending = nil
        sending = true
        willSend()
        let result = await submit(c.intent, c.note)
        sending = false
        if result == nil { successTick += 1 } else { failureTick += 1 }
        return .sent(result)
    }
}
