import Foundation
import LeafHFTCore

extension AppState {
    var booksRestored: Bool { restoredDashboardFeeds.contains(.books) }

    var booksStale: Bool { booksObservedAt.map { transportStale(observedAt: $0, now: Date()) } ?? true }

    /// The most recent books refresh failed (set on failure, cleared on the next success); the books shown are saved.
    var booksRefreshFailed: Bool { booksError != nil }

    var dashboardError: String? {
        let errors = [booksError, accountHistoryError].compactMap { $0 }
        return errors.isEmpty ? nil : errors.joined(separator: " ")
    }
}
