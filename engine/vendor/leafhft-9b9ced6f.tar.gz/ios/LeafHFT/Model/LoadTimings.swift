import Foundation

struct LoadTimings: Equatable {
    enum Kind: String { case cold, resume }

    struct Row: Equatable, Identifiable {
        let id: String
        let label: String
        var liveAfterMs: Int?
        var requestMs: Int?
        var failed = false
        var restoredAfterMs: Int?
    }

    let kind: Kind
    let activatedAt: Date
    private(set) var rows: [Row]
    private(set) var firstPollMs: Int?

    init(kind: Kind, activatedAt: Date) {
        self.kind = kind
        self.activatedAt = activatedAt
        rows = [
            Row(id: "status", label: "Status"),
            Row(id: "engines", label: "Engines"),
            Row(id: "probes", label: "Probes"),
            Row(id: "activity", label: "Activity"),
            Row(id: "accountHistory", label: "Account history"),
            Row(id: "exits", label: "Exits"),
            Row(id: "calibration", label: "Calibration"),
            Row(id: "books", label: "Books"),
            Row(id: "engineLab", label: "Engine Lab"),
            Row(id: "kalshiBalance", label: "Kalshi balance"),
            Row(id: "liveBoard", label: "Live board")
        ]
    }

    private static func milliseconds(from start: Date, to finish: Date) -> Int {
        Int(max(0, finish.timeIntervalSince(start) * 1000).rounded())
    }

    mutating func recordLive(id: String, startedAt: Date, finishedAt: Date, failed: Bool) {
        guard let index = rows.firstIndex(where: { $0.id == id }), rows[index].liveAfterMs == nil else { return }
        rows[index].liveAfterMs = Self.milliseconds(from: activatedAt, to: finishedAt)
        rows[index].requestMs = id == "liveBoard" ? nil : Self.milliseconds(from: startedAt, to: finishedAt)
        rows[index].failed = failed
    }

    mutating func recordRestored(id: String, at: Date) {
        guard let index = rows.firstIndex(where: { $0.id == id }), rows[index].restoredAfterMs == nil else { return }
        rows[index].restoredAfterMs = Self.milliseconds(from: activatedAt, to: at)
    }

    mutating func recordFirstPoll(finishedAt: Date) {
        guard firstPollMs == nil else { return }
        firstPollMs = Self.milliseconds(from: activatedAt, to: finishedAt)
    }

    var logLine: String {
        var parts = ["loading kind=\(kind.rawValue)"]
        if let firstPollMs { parts.append("firstPoll=\(firstPollMs)") }
        for row in rows {
            guard let live = row.liveAfterMs else { continue }
            if row.failed { parts.append("\(row.id)=fail") }
            else if let request = row.requestMs { parts.append("\(row.id)=\(live)/\(request)") }
            else { parts.append("\(row.id)=\(live)") }
        }
        let restored = rows.compactMap { row in row.restoredAfterMs.map { "\(row.id):\($0)" } }
        if !restored.isEmpty { parts.append("restored=" + restored.joined(separator: ",")) }
        return parts.joined(separator: " ")
    }

    static func display(_ row: Row) -> String {
        var text: String
        if let live = row.liveAfterMs {
            if row.failed { text = "failed after \(live) ms" }
            else if let request = row.requestMs { text = "\(live) ms (request \(request) ms)" }
            else { text = "\(live) ms" }
        } else { text = "waiting" }
        if let restored = row.restoredAfterMs { text += " · saved data at \(restored) ms" }
        return text
    }
}
