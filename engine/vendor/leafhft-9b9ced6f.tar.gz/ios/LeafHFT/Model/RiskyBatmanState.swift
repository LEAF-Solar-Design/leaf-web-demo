import Foundation
import Observation
import LeafHFTCore

@MainActor @Observable final class RiskyBatmanState {
    var riskEnvelope: RiskEnvelope?
    private(set) var engines: [RiskyBatman.Engine] = []
    private(set) var warnings: [String] = []
    private(set) var loading = false
    private(set) var error: String?
    private(set) var messages: [String: String] = [:]
    private(set) var restarted: Set<String> = []
    private(set) var pending: [String: Pending] = [:]
    /// The runner's view of each Risky engine (lifecycle, breaker, markets, eligibility), keyed by engine id.
    private(set) var runtime: [String: LeafHFTCore.Engine] = [:]
    private(set) var runtimeError: String?
    /// The last probe or halt request per engine; `isOpen` until the dashboard reports a terminal state.
    private(set) var controls: [String: Control] = [:]
    private(set) var controlMessages: [String: String] = [:]
    let fixtureMode: FixtureMode
    @ObservationIgnored private let fixtureTuningPending: Bool
    @ObservationIgnored private lazy var client = DashboardClient(fixtureMode: fixtureMode)
    @ObservationIgnored private var fixtureSettled: [String: Int] = [:]

    struct Pending {
        let clientRequestId: UUID
        let enabled: Bool
        let generation: Int?
        let set: [String: Double]
        let unset: [String]
        var submittedAt = Date()
        var changesSettings: Bool { !set.isEmpty || !unset.isEmpty }
    }

    static let tuningTimeout: TimeInterval = 120

    /// A terminal request record settles waiting even if the variant read has not caught up.
    static func tuningResult(found: Bool, state: String?, note: String?, enabled: Bool) -> String? {
        guard found else { return "Tuning request not found. Check status and Requests before sending another change." }
        switch state?.lowercased() {
        case "applied"?:
            return enabled ? "Tuning request applied. Refresh status to see the runner's settings. No real orders are placed."
                : "Tuning stop request applied. Refresh status to see the runner's settings."
        case "rejected"?: return "Tuning request rejected. " + (note ?? "Refresh and try again.")
        default: return nil
        }
    }

    func trackTuning(_ requests: [ControlRequest]) {
        for (engineId, change) in pending {
            let record = requests.first { $0.clientRequestId?.lowercased() == change.clientRequestId.uuidString.lowercased() }
            if let result = Self.tuningResult(found: record != nil, state: record?.state, note: record?.note,
                                               enabled: change.enabled) {
                pending[engineId] = nil
                messages[engineId] = result
            }
        }
    }

    func expireTuning(now: Date = Date()) {
        for (engineId, change) in pending where now.timeIntervalSince(change.submittedAt) >= Self.tuningTimeout {
            pending[engineId] = nil
            messages[engineId] = "Tuning status timed out. Outcome unknown. Check status and Requests before sending another change."
        }
    }

    struct Control {
        let kind: ControlKind
        let action: String
        let clientRequestId: String
        var state: String
        var note: String?
        /// Request-list reads that did not contain this request; after three the outcome is reported unknown.
        var misses = 0
        var isOpen: Bool { !ControlRequestLifecycle.isTerminal(state: state) }
    }

    init(fixtureMode: FixtureMode, fixtureTuningPending: Bool = ProcessInfo.processInfo.arguments.contains("-LEAFHFT_TUNING_PENDING")) {
        self.fixtureMode = fixtureMode
        self.fixtureTuningPending = fixtureTuningPending
    }

    func probeControl(for engine: RiskyBatman.Engine) -> RiskyBatman.ProbeControl {
        let row = runtime[engine.id]
        return RiskyBatman.ProbeControl(lifecycle: row?.lifecycle, markets: row?.markets,
                                        eligibility: row?.eligibleToProbe, frozen: engine.isFrozen)
    }

    func load() async {
        expireTuning()
        guard !loading else { return }
        loading = true
        defer { loading = false }
        do {
            if fixtureMode.enabled {
                if engines.isEmpty {
                    let response = try RiskyBatman.decoder().decode(RiskyBatman.Response.self, from: Data(Self.fixture.utf8))
                    engines = response.engines
                    warnings = response.warnings
                    let board = try accountJSONDecoder().decode(EnginesResponse.self, from: Data(Self.runtimeFixture.utf8))
                    runtime = Dictionary((board.engines ?? []).map { ($0.engineId, $0) }, uniquingKeysWith: { first, _ in first })
                } else {
                    settleFixtureControls()
                    if fixtureTuningPending { trackTuning([]) }
                }
            } else {
                let response = try await client.riskyEngines()
                engines = Array(response.engines.filter { RiskyBatman.isListed($0) }.prefix(64))
                warnings = Array(response.warnings.prefix(16))
                reconcile()
                await loadRuntime()
                if !pending.isEmpty || controls.values.contains(where: \.isOpen) {
                    let requests = try await client.controlRequests()
                    trackTuning(requests)
                    track(requests)
                }
            }
            error = nil
        } catch is CancellationError {
            return
        } catch {
            self.error = "Could not refresh Risky Batman status. " + Self.message(error)
        }
    }

    /// The lifecycle comes from the runner through /mobile/engines. A failed read keeps the last reading and says so.
    private func loadRuntime() async {
        do {
            let response = try await client.engines()
            let ids = Set(engines.map(\.id))
            var rows: [String: LeafHFTCore.Engine] = [:]
            for row in response.engines ?? [] where ids.contains(row.engineId) && rows[row.engineId] == nil {
                rows[row.engineId] = row
            }
            runtime = rows
            runtimeError = nil
        } catch is CancellationError {
            return
        } catch {
            runtimeError = "Lifecycle not refreshed. Showing the last reading. " + Self.message(error)
        }
    }

    private func track(_ requests: [ControlRequest]) {
        for (engineId, control) in controls where control.isOpen {
            guard let request = requests.first(where: {
                $0.clientRequestId?.lowercased() == control.clientRequestId.lowercased()
            }) else {
                controls[engineId]?.misses += 1
                if (controls[engineId]?.misses ?? 0) >= 3 {
                    controls[engineId]?.state = "unknown"
                    controlMessages[engineId] = "\(control.action) request not found. Check Requests before sending it again."
                }
                continue
            }
            controls[engineId]?.misses = 0
            controls[engineId]?.state = request.state ?? "requested"
            controls[engineId]?.note = request.note
            controlMessages[engineId] = RiskyBatman.controlMessage(action: control.action, state: request.state, note: request.note)
        }
    }

    /// Owner probe: 1 contract per entry. A POST is a request, never proof the runner is probing.
    @discardableResult
    func requestProbe(engineId: String) async -> Bool {
        guard controls[engineId]?.isOpen != true, let engine = engines.first(where: { $0.id == engineId }) else { return false }
        let control = probeControl(for: engine)
        guard control.canProbe else {
            controlMessages[engineId] = control.probeBlockedReason ?? "Probe is not available for this engine."
            return false
        }
        do {
            let intent = try RiskyBatman.probeIntent(engineId: engineId, markets: control.markets, now: Date(),
                                                     clientRequestId: UUID())
            return await send(intent, engineId: engineId, action: "Probe")
        } catch {
            controlMessages[engineId] = error.localizedDescription
            return false
        }
    }

    /// Halt stops new entries; open contracts settle normally. Allowed while a probe request is still open.
    @discardableResult
    func requestHalt(engineId: String) async -> Bool {
        guard controls[engineId].map({ !($0.isOpen && $0.kind == .halt) }) ?? true,
              engines.contains(where: { $0.id == engineId }) else { return false }
        do {
            let intent = try RiskyBatman.haltIntent(engineId: engineId, clientRequestId: UUID())
            return await send(intent, engineId: engineId, action: "Halt")
        } catch {
            controlMessages[engineId] = error.localizedDescription
            return false
        }
    }

    private func send(_ intent: ControlIntent, engineId: String, action: String) async -> Bool {
        let clientRequestId = intent.clientRequestId ?? UUID().uuidString
        controls[engineId] = Control(kind: intent.kind, action: action, clientRequestId: clientRequestId,
                                     state: "requested", note: nil)
        if fixtureMode.enabled {
            // Fixture walk: the request settles on the next refresh, as a dashboard poll would.
            controlMessages[engineId] = RiskyBatman.controlMessage(action: action, state: "requested", note: nil)
            return true
        }
        controlMessages[engineId] = "Sending \(action.lowercased()) request..."
        do {
            let response = try await client.control(intent, note: nil)
            guard let request = response.request else {
                controlMessages[engineId] = "\(action) request outcome unknown. Refresh status before sending another."
                return true
            }
            controls[engineId]?.state = request.state ?? "requested"
            controls[engineId]?.note = request.note
            controlMessages[engineId] = RiskyBatman.controlMessage(action: action, state: request.state, note: request.note)
            return true
        } catch {
            switch error as? DashboardClientError {
            case .noCredential, .unauthorized, .forbidden, .rateLimited:
                controls[engineId] = nil
                controlMessages[engineId] = Self.message(error)
            case .refused(let reason):
                controls[engineId]?.state = "rejected"
                controls[engineId]?.note = reason
                controlMessages[engineId] = RiskyBatman.controlMessage(action: action, state: "rejected", note: reason)
            case .http(let code) where (400..<500).contains(code):
                controls[engineId] = nil
                controlMessages[engineId] = Self.message(error)
            default:
                // A lost response can follow an accepted POST. Keep it open so no duplicate is sent.
                controlMessages[engineId] = "\(action) request outcome unknown. Refresh status to check it before sending another."
            }
            return false
        }
    }

    /// Fixture only. Probe settlements alternate rejected then applied, so both outcomes are walkable; halt applies.
    private func settleFixtureControls() {
        for (engineId, control) in controls where control.isOpen {
            let settled = (fixtureSettled[control.kind.rawValue] ?? 0) + 1
            fixtureSettled[control.kind.rawValue] = settled
            let rejected = control.kind == .probe && settled % 2 == 1
            let note: String? = rejected ? "Sample rejection: the signed owner approval arrives with KM5." : nil
            controls[engineId]?.state = rejected ? "rejected" : "applied"
            controls[engineId]?.note = note
            controlMessages[engineId] = RiskyBatman.controlMessage(action: control.action,
                                                                   state: rejected ? "rejected" : "applied", note: note)
            guard !rejected else { continue }
            let lifecycle = control.kind == .halt ? Self.fixtureHalted : Self.fixtureProbing
            runtime[engineId]?.lifecycle = try? accountJSONDecoder().decode(EngineLifecycle.self, from: Data(lifecycle.utf8))
        }
    }

    /// A successful POST is a queued request, not proof that tuning started.
    @discardableResult
    func request(engineId: String, enabled: Bool, set: [String: Double] = [:], unset: [String] = []) async -> Bool {
        guard pending[engineId] == nil, let index = engines.firstIndex(where: { $0.id == engineId }) else { return false }
        let engine = engines[index]
        do {
            _ = try RiskyBatman.ShadowRequest(engineId: engineId, enabled: enabled, set: set, unset: unset,
                                            envelope: riskEnvelope)
            for (key, value) in set {
                guard let bound = engine.editableBound(for: key, envelope: riskEnvelope), value >= bound.min, value <= bound.max,
                      !bound.isInt || value.rounded() == value else {
                    throw ControlIntent.ValidationError.invalid("This value is outside the published tuning bounds.")
                }
            }
            guard unset.allSatisfy({ engine.policyBounds[$0] != nil }) else {
                throw ControlIntent.ValidationError.invalid("This setting is not published for tuning.")
            }
        } catch {
            messages[engineId] = error.localizedDescription
            return false
        }
        let clientRequestId = UUID()
        pending[engineId] = Pending(clientRequestId: clientRequestId, enabled: enabled,
                                    generation: engine.variant?.generation, set: set, unset: unset)
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(Self.tuningTimeout))
            guard self?.pending[engineId]?.clientRequestId == clientRequestId else { return }
            self?.expireTuning()
        }
        messages[engineId] = "Sending tuning request..."
        do {
            if fixtureMode.enabled {
                if fixtureTuningPending {
                    messages[engineId] = "Tuning request received. Waiting for the runner."
                    return true
                }
                try simulate(index: index, enabled: enabled, set: set, unset: unset)
                reconcile()
            } else {
                let response = try await client.requestShadow(engineId: engineId, enabled: enabled, set: set, unset: unset,
                                                               clientRequestId: clientRequestId, envelope: riskEnvelope)
                if let result = Self.tuningResult(found: true, state: response.request.state,
                                                  note: response.request.note, enabled: enabled) {
                    pending[engineId] = nil
                    messages[engineId] = result
                    return response.request.state?.lowercased() != "rejected"
                }
                messages[engineId] = "Tuning request received. Waiting for the runner."
                await load()
            }
            return true
        } catch {
            switch error as? DashboardClientError {
            case .noCredential, .unauthorized, .forbidden, .rateLimited, .refused:
                pending[engineId] = nil
                messages[engineId] = Self.message(error)
            case .http(let code) where (400..<500).contains(code):
                pending[engineId] = nil
                messages[engineId] = Self.message(error)
            default:
                // A lost response can follow an accepted POST. Do not send a duplicate.
                messages[engineId] = "Tuning request outcome unknown. Refresh status to check it before sending another change."
            }
            return false
        }
    }

    private func reconcile() {
        for engine in engines {
            guard let request = pending[engine.id], let variant = engine.variant,
                  variant.generation != request.generation else { continue }
            if variant.state == "refused" {
                pending[engine.id] = nil
                messages[engine.id] = "Tuning request refused. " + variant.reasons.joined(separator: " ")
                continue
            }
            let matchesSettings = variant.overrides.map { overrides in
                request.set.allSatisfy { overrides[$0.key] == $0.value }
                    && request.unset.allSatisfy { overrides[$0] == nil }
            } ?? true
            let matchesState = request.enabled ? ["running", "delayed"].contains(variant.state) : variant.state == "stopped"
            guard matchesSettings, matchesState else { continue }
            pending[engine.id] = nil
            messages[engine.id] = request.enabled ? "Tuning request applied. No real orders are placed." : "Tuning stopped."
            if request.changesSettings { restarted.insert(engine.id) }
            else { restarted.remove(engine.id) }
        }
    }

    private func simulate(index: Int, enabled: Bool, set: [String: Double], unset: [String]) throws {
        let engine = engines[index]
        var variant = try engine.variant ?? RiskyBatman.decoder().decode(RiskyBatman.Variant.self,
            from: Data(Self.newVariant(engineId: engine.id).utf8))
        variant.generation += 1
        variant.state = enabled ? "running" : "stopped"
        var overrides = variant.overrides ?? [:]
        overrides.merge(set) { _, new in new }
        for key in unset { overrides.removeValue(forKey: key) }
        variant.overrides = overrides
        if enabled {
            variant.liveTailSeconds = 0
            variant.eligibleMinutesRemaining = 60
            variant.decisions = 0
            variant.entries = 0
            variant.wins = 0
            variant.losses = 0
            variant.paperPnlCents = 0
            variant.maxDrawdownCents = 0
            variant.worstTradeCents = 0
            variant.effectivePolicyDigest = "fixture-generation-\(variant.generation)"
        }
        engines[index].variant = variant
    }

    private static func message(_ error: Error) -> String {
        switch error as? DashboardClientError {
        case .noCredential, .unauthorized: return "Pair this phone with your dashboard account, then refresh."
        case .forbidden: return "This account cannot request this change."
        case .rateLimited: return "Too many requests. Wait before trying again."
        case .refused(let reason): return reason
        case .http(let code): return "The dashboard declined the request (\(code))."
        default: return "Check your connection and try refreshing."
        }
    }

    private static func newVariant(engineId: String) -> String {
        """
        {"schema":"leafhft.account-shadow-summary.v1","account_id":"fixture-account",
        "engine_id":"\(engineId)","generation":0,"effective_policy_digest":"fixture-new",
        "state":"running","started_at":"2026-09-22T07:00:00Z","updated_at":"2026-09-22T07:00:00Z",
        "live_tail_seconds":0,"decisions":0,"entries":0,"wins":0,"losses":0,"paper_pnl_cents":0,
        "max_drawdown_cents":0,"worst_trade_cents":0,"capital_basis_cents":10000,"reasons":[],
        "overrides":{},"eligible_minutes_remaining":60}
        """
    }

    private static let fixture = """
    {"engines":[
      {"engine_id":"risky-batman-15m","name":"Risky Batman 15m","gate_minutes":60,
       "default_enabled":false,"live_available":false,
       "policy_bounds":{"size_fraction":{"min":0,"max":0.5,"is_int":false},"min_k":[0,59,true]},
       "base_policy":{"size_fraction":0.3,"min_k":30},"variant":null},
      {"engine_id":"risky-batman-1h","name":"Risky Batman 1h","gate_minutes":60,
       "default_enabled":false,"live_available":false,
       "policy_bounds":{"size_fraction":{"min":0,"max":0.5,"is_int":false},"min_k":[0,59,true]},
       "base_policy":{"size_fraction":0.3,"min_k":12},
       "variant":{"schema":"leafhft.account-shadow-summary.v1","account_id":"fixture-account",
        "engine_id":"risky-batman-1h","generation":1,"effective_policy_digest":"fixture-running",
        "state":"running","started_at":"2026-09-22T07:00:00Z","updated_at":"2026-09-22T07:13:00Z",
        "live_tail_seconds":780,"decisions":24,"entries":7,"wins":2,"losses":4,"paper_pnl_cents":-840,
        "max_drawdown_cents":1250,"worst_trade_cents":-600,"capital_basis_cents":10000,"reasons":[],
        "overrides":{},"eligible_minutes_remaining":47}}
    ],"warnings":[]}
    """

    /// The runner's rows for the fixture engines, as /mobile/engines carries them (plan D8).
    private static let runtimeFixture = """
    {"engines":[
      {"engine_id":"risky-batman-15m","name":"Risky Batman 15m","markets":["BTC-15M","ETH-15M"],
       "eligible_to_probe":{"eligible":true,"reasons":[]}},
      {"engine_id":"risky-batman-1h","name":"Risky Batman 1h","markets":["BTC-1H"],
       "lifecycle":{"state":"probe","entries_enabled":true,"probe_started_at":"2026-09-21T04:00:00Z",
        "expires_at":"2026-10-12T04:00:00Z","stop_reasons":[],
        "breaker":{"engine_pct":50,"inherited":true,"account_pct":50,"engine_loss_cents":1240,
         "engine_limit_cents":125000,"day_start_marked_cents":250000}},
       "eligible_to_probe":{"eligible":false,"reasons":["Already probing"]}}
    ]}
    """

    private static let fixtureProbing = """
    {"state":"probe","entries_enabled":true,"stop_reasons":[],
     "breaker":{"engine_pct":50,"inherited":true,"engine_loss_cents":0,"engine_limit_cents":125000}}
    """

    private static let fixtureHalted = """
    {"state":"halted","entries_enabled":false,
     "stop_reasons":[{"code":"owner_halt","text":"Halted by the owner. Open contracts settle normally."}],
     "breaker":{"engine_pct":50,"inherited":true,"engine_loss_cents":0,"engine_limit_cents":125000}}
    """
}
