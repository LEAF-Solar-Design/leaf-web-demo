import Foundation
import LeafHFTCore

enum KashbotLiveStateBuilder {
    static func build(balance: AccountBalance?, positions: [Position], markets: [Market],
                      settlements: [Settlement], now: Date, approvalsWaiting: Int? = nil,
                      approval: KashbotLiveAttributes.Approval? = nil) -> KashbotBoardSnapshot? {
        guard let balance, let total = balance.accountValue?.cents.rawValue,
              let asOf = Int(exactly: now.timeIntervalSince1970.rounded(.down)) else { return nil }
        let open = positions.filter { LiveBoardMath.contracts(positionFp: $0.positionFp) != nil }
        let ordered = open.sorted {
            let lhs = LiveBoardMath.decimal($0.marketExposureDollars) ?? 0
            let rhs = LiveBoardMath.decimal($1.marketExposureDollars) ?? 0
            let lhsMagnitude = lhs < 0 ? -lhs : lhs
            let rhsMagnitude = rhs < 0 ? -rhs : rhs
            return lhsMagnitude == rhsMagnitude ? $0.ticker < $1.ticker : lhsMagnitude > rhsMagnitude
        }
        let rows: [KashbotLiveAttributes.Row] = ordered.prefix(3).compactMap { position in
            guard let holding = LiveBoardMath.contracts(positionFp: position.positionFp),
                  let contracts = LiveBoardMath.decimal(position.positionFp) else { return nil }
            let market = markets.first { $0.ticker == position.ticker }
            let result = market?.result
            let state = result == "yes" || result == "no" ? (result == holding.side ? "won" : "lost") : "open"
            let mark: Decimal? = state == "won" ? 1 : state == "lost" ? 0
                : market.flatMap { LiveBoardMath.markDollars(market: $0, side: holding.side) }
            return .init(ticker: String(position.ticker.prefix(40)),
                         label: market?.yesSubTitle.map { String($0.prefix(32)) },
                         side: holding.side, milli: holding.milli,
                         winCents: LiveBoardMath.winCents(contracts: contracts,
                             exposure: LiveBoardMath.decimal(position.marketExposureDollars),
                             fees: LiveBoardMath.decimal(position.feesPaidDollars)),
                         oddsPct: market.flatMap { LiveBoardMath.oddsPct(market: $0, side: holding.side) },
                         state: state,
                         pnlCents: LiveBoardMath.pnlCents(contracts: contracts,
                             exposure: LiveBoardMath.decimal(position.marketExposureDollars),
                             fees: LiveBoardMath.decimal(position.feesPaidDollars), mark: mark))
        }
        let entries = settlements.compactMap { LiveBoardMath.ledgerEntry(settlement: $0) }
            .sorted { $0.at == $1.at ? $0.ticker < $1.ticker : $0.at > $1.at }
        let start = LiveBoardMath.easternDayStart(for: now)
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "America/New_York")!
        guard let end = calendar.date(byAdding: .day, value: 1, to: start) else { return nil }
        let today = entries.filter {
            let date = Date(timeIntervalSince1970: TimeInterval($0.at))
            return date >= start && date < end
        }.reduce(Decimal.zero) { $0 + Decimal($1.pnlCents) }
        guard let todayCents = LiveBoardMath.integer(today, rounding: .plain) else { return nil }
        let ledger: [KashbotLiveAttributes.Entry] = entries.prefix(20).map {
            .init(ticker: String($0.ticker.prefix(40)), pnlCents: $0.pnlCents, pnlBps: $0.pnlBps, at: $0.at)
        }
        return .init(state: .init(asOf: asOf, totalCents: total, todayCents: todayCents,
                                  openCount: open.count, rows: rows, ledger: Array(ledger.prefix(4)),
                                  approvalsWaiting: approvalsWaiting, approval: approval),
                     ledger: ledger, approvalsWaiting: approvalsWaiting, approval: approval)
    }
}
