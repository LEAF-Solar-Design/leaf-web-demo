import Foundation
import Observation

@MainActor @Observable final class MushyState {
    static let overviewSlot = "overview"
    static let pollNanoseconds: UInt64 = 5_000_000_000
    static let recoveryKey = "kashbot.studio.request-recovery.v3"
    private(set) var catalog: MushyCatalog?
    private(set) var snapshot = MushySnapshot()
    private(set) var recovery = MushyRecovery()
    private(set) var pendingLooksUnsendable = false
    private(set) var artifacts: [String: MushyArtifact] = [:]
    private(set) var artifactErrors: [String: String] = [:]
    private(set) var drafts: [String: MushyConfigDraft] = [:]
    private(set) var configReceipts: [String: MushyConfigReceipt] = [:]
    private(set) var eventCursors: [String: Int] = [:]
    private(set) var busy = false
    private(set) var polling = false
    private(set) var sending = false
    private(set) var error: String?
    private(set) var result: String?
    private(set) var catalogNotice: String?
    private(set) var featureDisabled = false
    private(set) var selectedArtifactId: String?
    private(set) var offeredPrefill: String?
    var selections = MushySelections()
    var rationale = ""
    var studioVisible = false
    let fixtureMode: FixtureMode
    @ObservationIgnored private let client: MushyClient
    @ObservationIgnored private let defaults: UserDefaults
    @ObservationIgnored private let now: () -> Date
    @ObservationIgnored private var consecutiveRefreshFailures = 0
    @ObservationIgnored private var nextAutomaticRefreshAt: Date?
    @ObservationIgnored private var lastIdleTickAt: Date?
    @ObservationIgnored private var jobFirstSeenAt: [String: Date] = [:]
    @ObservationIgnored private var identity: String?
    @ObservationIgnored private var storageBlocked = false
    @ObservationIgnored private var hydrated = false
    private var storageKey: String { Self.recoveryKey + (fixtureMode.enabled ? ".preview" : "") }

    init(fixtureMode: FixtureMode = .current, client: MushyClient? = nil, defaults: UserDefaults = .standard,
         now: @escaping () -> Date = Date.init) {
        self.fixtureMode = fixtureMode
        self.client = client ?? MushyClient(fixtureMode: fixtureMode)
        self.defaults = defaults
        self.now = now
        if let data = defaults.data(forKey: storageKey) {
            do { recovery = try MushyCoding.decoder().decode(MushyRecovery.self, from: data) }
            catch { storageBlocked = true; self.error = "Saved recovery data could not be read. Sending is disabled." }
        }
        if fixtureMode.enabled {
            catalog = MushyClient.fixtureCatalog
            snapshot = MushyClient.fixtureSnapshot
            noteJobsSeen()
            selections = snapshot.selections
            artifacts[MushyClient.fixtureArtifactId] = MushyClient.fixtureArtifact()
            selectedArtifactId = MushyClient.fixtureArtifactId
        }
    }

    var visible: Bool { !featureDisabled && (fixtureMode.enabled || catalog != nil) }
    var pending: MushyPendingRequest? { recovery.pending }
    var prompt: String {
        get { recovery.input }
        set { recovery.input = newValue; saveRecovery() }
    }
    func offerPrefill(_ text: String) {
        if prompt == text || offeredPrefill == text {
            if prompt == text { offeredPrefill = nil }
            return
        }
        guard pending == nil, prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            offeredPrefill = text
            return
        }
        prompt = text
        offeredPrefill = nil
    }
    func acceptPrefill() {
        guard pending == nil, let text = offeredPrefill else { return }
        prompt = text
        offeredPrefill = nil
    }
    func dismissPrefill() { offeredPrefill = nil }
    var model: String {
        get { selections.modelId }
        set {
            selections.modelId = newValue
            if let catalog { selections = catalog.reconciled(selections) }
        }
    }
    var reasoning: String {
        get { selections.reasoningId }
        set { selections.reasoningId = newValue }
    }
    var selectedSessionId: String? {
        get { selections.sessionId }
        set {
            selections.sessionId = newValue
            selectedArtifactId = sessionArtifacts.first?.id
        }
    }
    var conversation: MushySession? { snapshot.sessions.first { $0.id == selections.sessionId } }
    var sessionArtifacts: [MushyArtifact] {
        snapshot.jobs.compactMap { artifacts[$0.artifactId ?? ""] }
            .filter { $0.lineage.sessionId == selections.sessionId }
    }
    var selectedArtifact: MushyArtifact? { selectedArtifactId.flatMap { artifacts[$0] } }
    var slot: MushySlot? { snapshot.slots[Self.overviewSlot] }
    var compatibleReasoning: [String] { catalog?.models.first { $0.id == model }?.reasoningIds ?? [] }
    func supports(_ capability: String) -> Bool { visible && catalog?.capabilities.contains(capability) == true }
    var canMutate: Bool { !busy && !storageBlocked && pending == nil && hydrated && identity != nil }
    // Readiness can be repaired by Send. Local safety guards cannot be bypassed.
    var canSend: Bool { !sending && sendSafetyBlocker == nil }
    private var sendSafetyBlocker: String? {
        if storageBlocked { return "The assistant could not save recovery data. Sending is disabled." }
        if pending != nil { return "Recover the saved request before sending another." }
        if busy { return "Wait for the assistant to finish updating." }
        if snapshot.jobs.contains(where: { !$0.isTerminal && !isStale($0) }) { return "Wait for the active generation to finish." }
        if MushyPromptLimit.exceeded(prompt) { return "Keep your request under 8,000 characters (emoji and accents count more than one)." }
        if prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return "Enter a request to send." }
        return nil
    }
    var staleActiveJobNotice: String? {
        snapshot.jobs.contains(where: { isStale($0) })
            ? "A generation started over 15 minutes ago is still marked active. You can send; it will be superseded."
            : nil
    }
    var sendBlocker: String? {
        if let blocker = sendSafetyBlocker { return blocker }
        if featureDisabled { return "Assistant is unavailable on this dashboard. Refresh to try again." }
        if !hydrated || identity == nil { return error ?? "Send will refresh the assistant before submitting your request." }
        if catalog?.providerReadiness.ready != true { return "Provider unavailable. Send will refresh once and retry readiness." }
        if !supports("ask") || !supports("telemetry.data") || !supports("visualization.native") {
            return "This dashboard does not support assistant requests with native telemetry views."
        }
        if !compatibleReasoning.contains(reasoning) { return "Select an available model and reasoning option." }
        if selections.sources.isEmpty { return "Select at least one telemetry source." }
        return nil
    }
    func setSource(_ source: String, selected: Bool) {
        guard catalog?.sources[source] != nil else { return }
        selections.sources.removeAll { $0 == source }
        if selected { selections.sources.append(source) }
        selections.sources.sort()
    }
    func selectArtifact(_ id: String) { if artifacts[id] != nil { selectedArtifactId = id } }

    private func persist() throws {
        guard !storageBlocked else { throw MushyClientError.response }
        let data = try MushyCoding.encoder().encode(recovery)
        defaults.set(data, forKey: storageKey)
        guard defaults.data(forKey: storageKey) == data else {
            storageBlocked = true
            throw MushyClientError.response
        }
    }
    private func saveRecovery() {
        do { try persist() }
        catch { self.error = "The assistant could not save recovery data. Sending is disabled."; storageBlocked = true }
    }
    private func prepare<T: Encodable>(_ body: T, id: String, kind: MushyPendingRequest.Kind, path: String) throws {
        guard pending == nil, !storageBlocked else { throw MushyClientError.response }
        let encoded = try MushyCoding.encoder().encode(body)
        guard encoded.count <= 16_384 else { throw MushyClientError.response }
        recovery.pending = MushyPendingRequest(requestId: id, kind: kind, path: path, body: encoded)
        pendingLooksUnsendable = false
        try persist() // Exact bytes and UUID are durable before any POST.
    }
    private func settle(_ pending: MushyPendingRequest) throws {
        guard recovery.pending == pending else { throw MushyClientError.response }
        recovery.pending = nil
        do { try persist() }
        catch { recovery.pending = pending; throw error }
        pendingLooksUnsendable = false
    }
    func discardPending() {
        guard !busy, let pending else { return }
        let priorInput = recovery.input
        if pending.kind == .turn, prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
           let body = try? MushyCoding.decoder().decode(MushyTurnRequest.self, from: pending.body) {
            recovery.input = body.input
        }
        recovery.pending = nil
        do {
            try persist()
            pendingLooksUnsendable = false
            result = "Saved request discarded. If it had already been accepted it will still appear after a refresh."
            error = nil
        } catch {
            recovery.pending = pending
            recovery.input = priorInput
            storageBlocked = true
            self.error = "The assistant could not save recovery data. Sending is disabled."
        }
    }
    private func resetRemoteState() {
        snapshot = MushySnapshot()
        jobFirstSeenAt = [:]
        catalog = nil
        artifacts = [:]; artifactErrors = [:]; drafts = [:]; configReceipts = [:]; eventCursors = [:]
        selections = MushySelections(); selectedArtifactId = nil
        hydrated = false; result = nil
    }

    private func noteJobsSeen() {
        for job in snapshot.jobs where !job.isTerminal {
            jobFirstSeenAt[job.id] = jobFirstSeenAt[job.id] ?? now()
        }
        let jobIds = Set(snapshot.jobs.map(\.id))
        jobFirstSeenAt = jobFirstSeenAt.filter { jobIds.contains($0.key) }
    }

    private func isStale(_ job: MushyJob) -> Bool {
        job.isStaleActive(now: now()) || (job.age(now: now()) == nil && !job.isTerminal &&
            (jobFirstSeenAt[job.id].map { now().timeIntervalSince($0) > MushyJob.staleActiveInterval } ?? false))
    }

    private func boundRecovery() {
        let pendingIds = pending.map { [$0.requestId] } ?? []
        let jobIds = Set(snapshot.jobs.map(\.id)).union(pendingIds)
        let artifactIds = Set(snapshot.jobs.compactMap(\.artifactId)).union(artifacts.keys).union(pendingIds)
        let recoveryCount = recovery.admittedInputs.count + recovery.configReceipts.count
        recovery.boundAdmittedInputs(keeping: jobIds, artifactIds: artifactIds)
        if recovery.admittedInputs.count + recovery.configReceipts.count < recoveryCount { try? persist() }
    }

    private func recordRefreshFailure() {
        // Bounded retry, never faster than 5 s, never slower than 5 min.
        consecutiveRefreshFailures = min(consecutiveRefreshFailures + 1, 6)
        nextAutomaticRefreshAt = now().addingTimeInterval(min(300, 5 * pow(2, Double(consecutiveRefreshFailures))))
    }

    func refresh() async {
        guard !busy else { return }
        busy = true
        let priorSelections = hydrated ? selections : nil
        hydrated = false
        defer { busy = false }
        do {
            let current = try client.identity()
            let sameIdentity = identity == current
            if identity != current { resetRemoteState(); identity = current }
            let freshCatalog: MushyCatalog
            do { freshCatalog = try await client.catalog(identity: current) }
            catch MushyClientError.http(404) {
                recordRefreshFailure()
                featureDisabled = true; resetRemoteState(); error = nil; return
            }
            guard freshCatalog.schemaVersion == 1 else { throw MushyClientError.response }
            featureDisabled = false
            catalog = freshCatalog
            let remote = try await client.snapshot(identity: current)
            snapshot = remote
            noteJobsSeen()
            boundRecovery()
            let reconciled = freshCatalog.reconciled(sameIdentity ? (priorSelections ?? remote.selections) : remote.selections)
            if reconciled != remote.selections {
                catalogNotice = "Available options changed. The assistant selected compatible defaults."
            }
            selections = reconciled
            if !remote.sessions.contains(where: { $0.id == selections.sessionId }) {
                selections.sessionId = remote.sessions.first?.id
            }
            hydrated = true
            error = nil
            await loadCompletedArtifacts(identity: current)
            consecutiveRefreshFailures = 0
            nextAutomaticRefreshAt = nil
        } catch is CancellationError { }
        catch MushyClientError.authentication {
            resetRemoteState(); identity = nil
            self.error = MushyClientError.authentication.localizedDescription
            recordRefreshFailure()
        }
        catch MushyClientError.notBound {
            resetRemoteState()
            self.error = MushyClientError.notBound.localizedDescription
            recordRefreshFailure()
        }
        catch {
            if (try? client.identity()) != identity { resetRemoteState(); identity = nil }
            self.error = error.localizedDescription
            recordRefreshFailure()
        }
    }

    /// Called by the app while active, including when Studio is hidden or Settings is open.
    func tick() async {
        guard !busy && !polling else { return }
        polling = true
        defer { polling = false }
        guard (try? client.identity()) == identity, hydrated else {
            if let nextAutomaticRefreshAt, now() < nextAutomaticRefreshAt { return }
            await refresh(); return
        }
        if !studioVisible, pending == nil, !snapshot.jobs.contains(where: { !$0.isTerminal }) {
            if let last = lastIdleTickAt, now().timeIntervalSince(last) < 60 { return }
            lastIdleTickAt = now()
        }
        guard let identity else { return }
        do {
            let freshCatalog = try await client.catalog(identity: identity)
            guard freshCatalog.schemaVersion == 1 else { throw MushyClientError.response }
            catalog = freshCatalog
            let reconciled = freshCatalog.reconciled(selections)
            if reconciled != selections {
                selections = reconciled
                catalogNotice = "Available options changed. The assistant selected compatible defaults."
            }
            for old in snapshot.jobs where !old.isTerminal {
                if let events = try? await client.events(old.id, after: eventCursors[old.id] ?? 0, identity: identity),
                   events.jobId == old.id, events.nextCursor >= (eventCursors[old.id] ?? 0),
                   events.events.allSatisfy({ $0.jobId == old.id && $0.sequence <= events.nextCursor }) {
                    eventCursors[old.id] = events.nextCursor
                }
                let job = try await client.job(old.id, identity: identity)
                guard job.id == old.id else { throw MushyClientError.response }
                if let index = snapshot.jobs.firstIndex(where: { $0.id == job.id }) { snapshot.jobs[index] = job }
                if job.isTerminal {
                    let remote = try await client.snapshot(identity: identity)
                    snapshot = remote
                    noteJobsSeen()
                    boundRecovery()
                    if job.status != "completed" { result = "Generation failed. Your prior view is kept. Restore your request to try again." }
                }
            }
            await loadCompletedArtifacts(identity: identity)
        } catch MushyClientError.http(404) {
            // Only catalog 404 disables the feature; job failures are handled below on refresh.
            await verifyFeatureAvailability(identity: identity)
        } catch is CancellationError { }
        catch MushyClientError.authentication {
            resetRemoteState(); self.identity = nil
            self.error = MushyClientError.authentication.localizedDescription
            recordRefreshFailure()
        }
        catch MushyClientError.notBound {
            resetRemoteState()
            self.error = MushyClientError.notBound.localizedDescription
            recordRefreshFailure()
        }
        catch { self.error = error.localizedDescription }
    }
    private func verifyFeatureAvailability(identity: String) async {
        do { catalog = try await client.catalog(identity: identity) }
        catch MushyClientError.http(404) { featureDisabled = true; resetRemoteState() }
        catch { self.error = error.localizedDescription }
    }

    private func loadCompletedArtifacts(identity: String) async {
        // State can contain 500 jobs. Load only the current conversation, recovery
        // jobs and published view; switching conversations loads their own views.
        var relevantIds = Set(conversation?.messages.map(\.jobId) ?? [])
        relevantIds.formUnion(recovery.admittedInputs.keys)
        if let published = slot?.artifactId { relevantIds.insert(published) }
        for job in snapshot.jobs where job.status == "completed" {
            guard let id = job.artifactId, relevantIds.contains(job.id) else { continue }
            do {
                let artifact: MushyArtifact
                if let cached = artifacts[id] { artifact = cached }
                else { artifact = try await client.artifact(id, identity: identity) }
                guard artifact.id == id, artifact.producingJobId == job.id else { throw MushyClientError.response }
                if let failure = artifact.validationMessage(catalog: catalog) {
                    artifactErrors[id] = failure
                    continue
                }
                artifacts[id] = artifact
                artifactErrors[id] = nil
                if artifact.lineage.sessionId == selections.sessionId && selectedArtifactId == nil { selectedArtifactId = id }
                if let input = recovery.admittedInputs[id] {
                    // A valid completed artifact is the only point that clears the recovered input.
                    if recovery.input == input { recovery.input = "" }
                    recovery.admittedInputs[id] = nil
                    selectedArtifactId = artifact.lineage.sessionId == selections.sessionId ? id : selectedArtifactId
                    try persist()
                }
                if supports("config.draft"), artifact.configDraft != nil, drafts[id] == nil {
                    drafts[id] = try await client.draft(id, identity: identity)
                    configReceipts[id] = recovery.configReceipts[id]
                }
            } catch is CancellationError { return }
            catch { artifactErrors[id] = error.localizedDescription }
        }
        // A draft fetch can recover independently of an already fetched immutable artifact.
        if supports("config.draft") {
            for artifact in artifacts.values where artifact.configDraft != nil && drafts[artifact.id] == nil {
                do {
                    drafts[artifact.id] = try await client.draft(artifact.id, identity: identity)
                    configReceipts[artifact.id] = recovery.configReceipts[artifact.id]
                }
                catch { artifactErrors[artifact.id] = error.localizedDescription }
            }
        }
    }

    func newSession() async {
        guard canMutate, supports("ask") else { return }
        do {
            let id = UUID().uuidString.lowercased()
            try prepare(MushySessionRequest(requestId: id), id: id, kind: .session, path: "/session")
            await recover()
        } catch { self.error = error.localizedDescription }
    }
    func send() async {
        guard canSend else {
            if !sending { error = sendBlocker }
            return
        }
        sending = true
        defer { sending = false }
        if !hydrated || identity == nil || (try? client.identity()) != identity ||
            catalog?.providerReadiness.ready != true || error != nil {
            await refresh()
        }
        guard !Task.isCancelled else { return }
        if let blocker = sendBlocker {
            error = catalog?.providerReadiness.ready == false && sendSafetyBlocker == nil && hydrated
                ? "Provider is still unavailable after refreshing. Your request is kept. Try Send again later."
                : blocker
            return
        }
        if selections.sessionId == nil { await newSession() }
        if let blocker = sendBlocker { error = blocker; return }
        guard !Task.isCancelled, let sessionId = selections.sessionId else { return }
        do {
            let id = UUID().uuidString.lowercased()
            let body = MushyTurnRequest(requestId: id, sessionId: sessionId, input: prompt,
                modelId: model, reasoningId: reasoning, sources: selections.sources.sorted())
            try prepare(body, id: id, kind: .turn, path: "/turn")
            await recover()
        } catch { self.error = error.localizedDescription }
    }
    func publish(_ artifact: MushyArtifact) async {
        await changeSlot(.publish, artifactId: artifact.id)
    }
    func rollback() async {
        guard let target = slot?.rollbackTarget else { return }
        await changeSlot(.rollback, artifactId: target.artifactId)
    }
    private func changeSlot(_ action: MushySlotAction, artifactId: String) async {
        guard canMutate, supports("account.publish") else { return }
        if action == .publish {
            guard let artifact = artifacts[artifactId], artifact.validationMessage(catalog: catalog) == nil else { return }
        }
        do {
            let id = UUID().uuidString.lowercased()
            try prepare(MushySlotRequest(requestId: id, slot: Self.overviewSlot, action: action,
                artifactId: artifactId, expectedRevision: slot?.revision ?? 0), id: id, kind: .slot, path: "/slots")
            await recover()
        } catch { self.error = error.localizedDescription }
    }
    func suggest(_ artifact: MushyArtifact) async {
        let note = rationale.trimmingCharacters(in: .whitespacesAndNewlines)
        guard canMutate, supports("global.propose"), artifact.validationMessage(catalog: catalog) == nil,
              !note.isEmpty, note.count <= 1000 else { return }
        do {
            let id = UUID().uuidString.lowercased()
            try prepare(MushyProposalRequest(requestId: id, artifactId: artifact.id, targetSlot: Self.overviewSlot,
                rationale: note), id: id, kind: .proposal, path: "/proposals")
            await recover()
        } catch { self.error = error.localizedDescription }
    }
    func configBlocker(_ draft: MushyConfigDraft, now: Date = Date()) -> String? {
        if !supports("config.draft") { return "Configuration drafts are unavailable." }
        if fixtureMode.enabled { return "Preview only. Runner changes are disabled." }
        if configReceipts[draft.id] != nil { return "Request sent. The runner must acknowledge it." }
        if !canMutate { return "Recover the saved request or wait for the assistant to finish." }
        return draft.blocker(now: now)
    }
    func apply(_ draft: MushyConfigDraft) async {
        guard configBlocker(draft) == nil else { return }
        do {
            let id = UUID().uuidString.lowercased()
            try prepare(MushyConfigApplyRequest(requestId: id, summaryDigest: draft.contents.summaryDigest),
                id: id, kind: .config, path: "/config-drafts/" + draft.id)
            await recover()
        } catch { self.error = error.localizedDescription }
    }
    func restoreInput(for job: MushyJob) {
        if let input = recovery.admittedInputs[job.id] { prompt = input }
        else if let message = snapshot.sessions.flatMap(\.messages).first(where: { $0.jobId == job.id && $0.role == "user" }) {
            prompt = message.content
        }
    }

    func recover() async {
        guard !busy, !storageBlocked, hydrated, let pending, let identity else { return }
        busy = true
        defer { busy = false }
        do {
            guard try client.identity() == identity else { throw MushyClientError.mismatch }
            switch pending.kind {
            case .session:
                let receipt = try await client.createSession(pending, identity: identity)
                guard receipt.sessionId == receipt.session.id, UUID(uuidString: receipt.sessionId) != nil else { throw MushyClientError.response }
                let remote = try await client.snapshot(identity: identity)
                guard remote.sessions.contains(where: { $0.id == receipt.sessionId }) else { throw MushyClientError.response }
                snapshot = remote
                noteJobsSeen()
                boundRecovery()
                selections.sessionId = receipt.sessionId
                selectedArtifactId = nil
                result = "Conversation created."
            case .turn:
                let body = try MushyCoding.decoder().decode(MushyTurnRequest.self, from: pending.body)
                guard snapshot.sessions.contains(where: { $0.id == body.sessionId }) else { throw MushyClientError.mismatch }
                let receipt = try await client.turn(pending, identity: identity)
                let job = try await client.job(receipt.jobId, identity: identity)
                let remote = try await client.snapshot(identity: identity)
                guard job.id == receipt.jobId,
                      remote.sessions.first(where: { $0.id == body.sessionId })?.messages.contains(where: {
                          $0.jobId == job.id && $0.role == "user" && $0.content == body.input.trimmingCharacters(in: .whitespacesAndNewlines)
                      }) == true else { throw MushyClientError.response }
                snapshot = remote
                noteJobsSeen()
                boundRecovery()
                selections.sessionId = body.sessionId
                recovery.admittedInputs[job.id] = body.input
                result = "Request admitted. Waiting for generation."
            case .slot:
                guard supports("account.publish") else { throw MushyClientError.response }
                let body = try MushyCoding.decoder().decode(MushySlotRequest.self, from: pending.body)
                let receipt = try await client.updateSlot(pending, identity: identity)
                guard receipt.artifactId == body.artifactId, receipt.revision == body.expectedRevision + 1 else { throw MushyClientError.response }
                snapshot.slots = try await client.slots(identity: identity).slots
                result = fixtureMode.enabled ? "Preview publication only." : "Account view updated."
            case .proposal:
                guard supports("global.propose") else { throw MushyClientError.response }
                let body = try MushyCoding.decoder().decode(MushyProposalRequest.self, from: pending.body)
                let receipt = try await client.propose(pending, identity: identity)
                guard receipt.proposal.artifactId == body.artifactId, receipt.proposal.targetSlot == body.targetSlot,
                      receipt.proposal.rationale == body.rationale, receipt.proposal.state == "proposed" else { throw MushyClientError.response }
                snapshot.proposals = try await client.proposals(identity: identity).proposals
                result = "Suggestion pending review. Your account view has not changed."
            case .config:
                // Exact replay remains valid after consumption or expiry; the server owns that decision.
                guard supports("config.draft"), !fixtureMode.enabled else { throw MushyClientError.response }
                let receipt = try await client.applyDraft(pending, identity: identity)
                guard pending.path == "/config-drafts/" + receipt.draftId, !receipt.controlRequestId.isEmpty else { throw MushyClientError.response }
                configReceipts[receipt.draftId] = receipt
                recovery.configReceipts[receipt.draftId] = receipt
                result = "Control request \(receipt.controlRequestId): \(receipt.state). Waiting for runner acknowledgement."
            }
            try settle(pending)
            error = nil
            await loadCompletedArtifacts(identity: identity)
        } catch is CancellationError { }
        catch MushyClientError.http(let code) where (400..<500).contains(code) && code != 408 && code != 429 {
            pendingLooksUnsendable = true
            self.error = "This saved request can no longer be sent. Discard it to continue."
        }
        catch MushyClientError.notBound {
            pendingLooksUnsendable = true
            self.error = "This saved request can no longer be sent. Discard it to continue."
        }
        catch { self.error = error.localizedDescription }
    }
}
