import SwiftUI
import LeafAssistantUI

// KM3 (K-D10): the one mapping from LeafTheme onto the Kit's injected tokens.
// LeafAssistantThemeMappingTests pins every token hex for hex in both appearances.
// userBubble is accentFill, not primary: the Kit draws user text in textPrimary (ink).
extension LeafAssistantTheme {
    static var leaf: LeafAssistantTheme {
        LeafAssistantTheme(
            accent: LeafTheme.primary,
            surface: LeafTheme.card,
            userBubble: LeafTheme.accentFill,
            assistantBubble: LeafTheme.ground,
            textPrimary: LeafTheme.ink,
            textSecondary: LeafTheme.inkMuted,
            danger: LeafTheme.loss,
            warning: LeafTheme.warn,
            success: LeafTheme.gain,
            border: LeafTheme.line,
            cornerRadius: LeafTheme.radius,
            minimumTarget: 44
        )
    }
}

extension View {
    /// Every Kit view below this point renders in the Leaf look.
    func leafKitThemed() -> some View { leafAssistantTheme(.leaf) }
}
