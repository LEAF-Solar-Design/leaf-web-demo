import SwiftUI

struct BoundedOverflowKey: PreferenceKey {
    static var defaultValue = false

    static func reduce(value: inout Bool, nextValue: () -> Bool) {
        value = value || nextValue()
    }
}

struct BoundedList<Content: View>: View {
    let maxHeight: CGFloat
    let identifier: String
    let spacing: CGFloat
    private let content: Content
    @State private var overflowing = false

    init(maxHeight: CGFloat, identifier: String, spacing: CGFloat = 8,
         @ViewBuilder content: () -> Content) {
        self.maxHeight = maxHeight
        self.identifier = identifier
        self.spacing = spacing
        self.content = content()
    }

    var body: some View {
        GeometryReader { viewport in
            ScrollView(.vertical) {
                LazyVStack(alignment: .leading, spacing: spacing) {
                    content
                }
                .background {
                    GeometryReader { geometry in
                        Color.clear.preference(key: BoundedOverflowKey.self,
                                               value: geometry.size.height > viewport.size.height)
                    }
                }
            }
            .scrollIndicators(.visible)
            .accessibilityIdentifier(identifier)
            .overlay(alignment: .bottom) {
                if overflowing {
                    LinearGradient(colors: [LeafTheme.card.opacity(0), LeafTheme.card],
                                   startPoint: .top, endPoint: .bottom)
                        .frame(height: 12)
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                }
            }
        }
        .frame(maxHeight: max(0, maxHeight))
        .clipped()
        .onPreferenceChange(BoundedOverflowKey.self) { overflowing = $0 }
    }
}

struct BoundedTable: View {
    struct Column {
        let title: String
        var width: CGFloat? = nil
        var numeric: Bool = false
    }

    struct Cell {
        let text: String
        var tone: LeafTone = .neutral
        var mono: Bool = false
    }

    let columns: [Column]
    let rows: [[Cell]]
    let maxHeight: CGFloat
    let identifier: String
    let minWidth: CGFloat
    var rowTint: ((Int) -> Color?)? = nil

    private func width(for column: Column) -> CGFloat {
        let fixedWidth = columns.compactMap(\.width).reduce(0, +)
        let flexibleCount = max(1, columns.filter { $0.width == nil }.count)
        return max(0, column.width ?? max(80, (minWidth - fixedWidth) / CGFloat(flexibleCount)))
    }

    private var header: some View {
        HStack(spacing: 0) {
            ForEach(columns.indices, id: \.self) { index in
                let column = columns[index]
                Text(column.title)
                    .font(LeafType.micro)
                    .foregroundStyle(LeafTheme.inkMuted)
                    .lineLimit(1)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 8)
                    .frame(width: width(for: column), alignment: column.numeric ? .trailing : .leading)
            }
        }
        .frame(minWidth: minWidth, alignment: .leading)
        .background(LeafTheme.card)
        .overlay(alignment: .bottom) { LeafTheme.line.frame(height: 1) }
        .accessibilityAddTraits(.isHeader)
    }

    @ViewBuilder private func cellText(_ cell: Cell, numeric: Bool) -> some View {
        if numeric || cell.mono {
            Text(cell.text).leafNumeral(.table)
        } else {
            Text(cell.text).font(LeafType.meta)
        }
    }

    private func row(at index: Int) -> some View {
        let tint = rowTint?(index)
        return HStack(spacing: 0) {
            ForEach(columns.indices, id: \.self) { columnIndex in
                let column = columns[columnIndex]
                let cell = rows[index].indices.contains(columnIndex)
                    ? rows[index][columnIndex] : Cell(text: "")
                cellText(cell, numeric: column.numeric)
                    .foregroundStyle(cell.tone.color)
                    .lineLimit(1)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 8)
                    .frame(width: width(for: column), alignment: column.numeric ? .trailing : .leading)
            }
        }
        .frame(minWidth: minWidth, alignment: .leading)
        .background(tint?.opacity(0.08) ?? Color.clear)
        .overlay(alignment: .leading) {
            if let tint { tint.frame(width: 4).allowsHitTesting(false) }
        }
        .overlay(alignment: .bottom) { LeafTheme.line.frame(height: 1) }
    }

    var body: some View {
        ScrollView([.horizontal, .vertical]) {
            LazyVStack(alignment: .leading, spacing: 0, pinnedViews: [.sectionHeaders]) {
                Section {
                    ForEach(rows.indices, id: \.self) { index in row(at: index) }
                } header: {
                    header
                }
            }
            .frame(minWidth: minWidth, alignment: .leading)
        }
        .scrollIndicators(.visible)
        .frame(maxHeight: max(0, maxHeight))
        .clipped()
        .accessibilityIdentifier(identifier)
    }
}

struct ChipRow<Content: View>: View {
    let identifier: String
    private let content: Content

    init(identifier: String, @ViewBuilder content: () -> Content) {
        self.identifier = identifier
        self.content = content()
    }

    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 6) { content }
                .fixedSize(horizontal: true, vertical: true)
        }
        .fixedSize(horizontal: false, vertical: true)
        .accessibilityIdentifier(identifier)
    }
}

struct OneLine: View {
    let text: String
    let truncation: Text.TruncationMode

    init(_ text: String, truncation: Text.TruncationMode = .tail) {
        self.text = text
        self.truncation = truncation
    }

    var body: some View {
        Text(text).lineLimit(1).truncationMode(truncation)
    }
}

private struct CaptionHeights: Equatable {
    var collapsed: CGFloat = 0
    var full: CGFloat = 0
}

private struct CaptionHeightsKey: PreferenceKey {
    static var defaultValue = CaptionHeights()

    static func reduce(value: inout CaptionHeights, nextValue: () -> CaptionHeights) {
        let next = nextValue()
        value.collapsed = max(value.collapsed, next.collapsed)
        value.full = max(value.full, next.full)
    }
}

struct Caption: View {
    let text: String
    let tone: LeafTone
    let expandable: Bool
    let identifier: String?
    @State private var expanded = false
    @State private var heights = CaptionHeights()

    init(_ text: String, tone: LeafTone = .neutral, expandable: Bool = true,
         identifier: String? = nil) {
        self.text = text
        self.tone = tone
        self.expandable = expandable
        self.identifier = identifier
    }

    private func measurement(collapsed: Bool) -> some View {
        Text(text)
            .font(LeafType.meta)
            .lineLimit(collapsed ? 2 : nil)
            .fixedSize(horizontal: false, vertical: true)
            .hidden()
            .background {
                GeometryReader { geometry in
                    Color.clear.preference(key: CaptionHeightsKey.self,
                        value: CaptionHeights(collapsed: collapsed ? geometry.size.height : 0,
                                              full: collapsed ? 0 : geometry.size.height))
                }
            }
            .accessibilityHidden(true)
    }

    private var moreButton: some View {
        Button { expanded = true } label: {
            Text("More")
                .font(LeafType.meta)
                .frame(minWidth: 44, minHeight: 44)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(text)
                .font(LeafType.meta)
                .lineLimit(expandable && expanded ? nil : 2)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(alignment: .topLeading) { measurement(collapsed: true) }
                .background(alignment: .topLeading) { measurement(collapsed: false) }
            if expandable && !expanded && heights.full > heights.collapsed + 0.5 {
                if let identifier {
                    moreButton.accessibilityIdentifier(identifier + ".more")
                } else {
                    moreButton
                }
            }
        }
        .foregroundStyle(tone == .neutral ? LeafTheme.inkMuted : tone.color)
        .onPreferenceChange(CaptionHeightsKey.self) { heights = $0 }
        .onChange(of: text) { _, _ in expanded = false }
    }
}

struct StateInk: View {
    let text: String
    let tone: LeafTone
    let symbol: String?

    init(_ text: String, tone: LeafTone, symbol: String? = nil) {
        self.text = text
        self.tone = tone
        self.symbol = symbol
    }

    var body: some View {
        HStack(spacing: 4) {
            if let glyph = symbol ?? tone.stateGlyph {
                Image(systemName: glyph).accessibilityHidden(true)
            }
            Text(text.uppercased()).lineLimit(1)
        }
        .font(LeafType.micro)
        .foregroundStyle(tone.color)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(tone.soft, in: RoundedRectangle(cornerRadius: 999))
        .overlay {
            RoundedRectangle(cornerRadius: 999)
                .strokeBorder(tone.line, lineWidth: 1)
                .allowsHitTesting(false)
                .accessibilityHidden(true)
        }
        .accessibilityElement(children: .combine)
    }
}

struct FlatCard<Content: View>: View {
    let title: String
    let trailing: String?
    private let content: Content

    init(title: String, trailing: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.trailing = trailing
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(title)
                    .font(LeafType.sans(13, weight: .semibold, relativeTo: .headline))
                    .foregroundStyle(LeafTheme.ink)
                    .lineLimit(1)
                    .accessibilityAddTraits(.isHeader)
                Spacer(minLength: 0)
                if let trailing {
                    Text(trailing)
                        .font(LeafType.meta)
                        .foregroundStyle(LeafTheme.inkMuted)
                        .lineLimit(1)
                }
            }
            content
        }
        .padding(LeafTheme.cardPadding)
        .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: LeafTheme.radius))
        .overlay {
            RoundedRectangle(cornerRadius: LeafTheme.radius)
                .strokeBorder(LeafTheme.line, lineWidth: 1)
                .allowsHitTesting(false)
                .accessibilityHidden(true)
        }
    }
}
