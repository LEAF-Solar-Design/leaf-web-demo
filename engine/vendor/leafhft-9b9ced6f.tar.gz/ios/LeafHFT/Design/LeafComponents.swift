import SwiftUI

enum LeafNumeralStyle: CaseIterable {
    case hero, large, number, small, table

    var size: CGFloat {
        switch self {
        case .hero: return 40
        case .large: return 28
        case .number: return 17
        case .small: return 13
        case .table: return 11
        }
    }

    var weight: Font.Weight {
        switch self {
        case .hero, .large: return .semibold
        case .number: return .medium
        case .small, .table: return .regular
        }
    }

    var relativeTo: Font.TextStyle {
        switch self {
        case .hero: return .largeTitle
        case .large: return .title
        case .number: return .body
        case .small: return .footnote
        case .table: return .caption
        }
    }

    var tracking: CGFloat { -0.03 * size }
    var font: Font { LeafType.mono(size, weight: weight, relativeTo: relativeTo) }
}

struct LeafNumeral: ViewModifier {
    let size: CGFloat
    let weight: Font.Weight
    let relativeTo: Font.TextStyle
    @ScaledMetric private var scaledSize: CGFloat

    init(size: CGFloat, weight: Font.Weight, relativeTo: Font.TextStyle) {
        self.size = size
        self.weight = weight
        self.relativeTo = relativeTo
        _scaledSize = ScaledMetric(wrappedValue: size, relativeTo: relativeTo)
    }

    func body(content: Content) -> some View {
        content
            .font(LeafType.mono(size, weight: weight, relativeTo: relativeTo))
            .monospacedDigit()
            .tracking(-0.03 * scaledSize)
    }
}

extension View {
    func leafNumeral(_ style: LeafNumeralStyle) -> some View {
        modifier(LeafNumeral(size: style.size, weight: style.weight, relativeTo: style.relativeTo))
    }
}

struct LeafCard<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(LeafTheme.cardPadding)
            .background(LeafTheme.card, in: RoundedRectangle(cornerRadius: LeafTheme.radius))
            .overlay {
                RoundedRectangle(cornerRadius: LeafTheme.radius)
                    .strokeBorder(LeafTheme.line, lineWidth: 1)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
    }
}

struct Eyebrow: View {
    private let text: String

    init(_ text: String) { self.text = text }

    var body: some View {
        Text(text.uppercased())
            .font(LeafType.micro)
            .tracking(0.8)
            .foregroundStyle(LeafTheme.inkMuted)
            .fixedSize(horizontal: false, vertical: true)
    }
}

struct StatTile: View {
    let label: String
    let value: String
    let delta: String?
    let tone: LeafTone
    let symbol: String?

    init(label: String, value: String, delta: String? = nil,
         tone: LeafTone = .neutral, symbol: String? = nil) {
        self.label = label
        self.value = value
        self.delta = delta
        self.tone = tone
        self.symbol = symbol
    }

    var body: some View {
        LeafCard {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    if let symbol {
                        Image(systemName: symbol)
                            .font(LeafType.micro)
                            .foregroundStyle(LeafTheme.inkMuted)
                            .accessibilityHidden(true)
                    }
                    Eyebrow(label)
                }
                Text(value)
                    .font(LeafType.numberLarge)
                    .foregroundStyle(LeafTheme.ink)
                    .fixedSize(horizontal: false, vertical: true)
                if let delta {
                    Label(delta, systemImage: tone.glyph)
                        .labelStyle(.titleAndIcon)
                        .font(LeafType.meta)
                        .foregroundStyle(tone.color)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        .accessibilityElement(children: .combine)
    }
}

struct PnlText: View {
    let cents: Int
    let font: Font

    init(cents: Int, font: Font = LeafType.number) {
        self.cents = cents
        self.font = font
    }

    var body: some View {
        Label(LeafFormat.signedMoney(cents: cents), systemImage: LeafTone.forDelta(cents: cents).glyph)
            .labelStyle(.titleAndIcon)
            .font(font)
            .foregroundStyle(LeafTone.forDelta(cents: cents).color)
            .fixedSize(horizontal: false, vertical: true)
            .accessibilityElement(children: .combine)
            .accessibilityLabel(LeafFormat.signedMoney(cents: cents))
    }
}

struct StateChip: View {
    let text: String
    let tone: LeafTone
    let symbol: String?

    init(_ text: String, tone: LeafTone, symbol: String? = nil) {
        self.text = text
        self.tone = tone
        self.symbol = symbol
    }

    var body: some View {
        Group {
            if let glyph = symbol ?? tone.stateGlyph {
                Label(text.uppercased(), systemImage: glyph)
            } else {
                Text(text.uppercased())
            }
        }
            .labelStyle(.titleAndIcon)
            .font(LeafType.micro)
            .tracking(0.8)
            .foregroundStyle(tone.color)
            .fixedSize(horizontal: false, vertical: true)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .frame(minHeight: 24)
            .background(tone.soft, in: Capsule())
            .accessibilityElement(children: .combine)
            .accessibilityLabel(text)
    }
}

/// What a freshness dot may claim. Only `.live` earns the gain tone; every other state reads stale.
enum LiveState: Equatable {
    case live, saved, delayed, noQuote, closed

    var label: String {
        switch self {
        case .live: return "LIVE"
        case .saved: return "SAVED"
        case .delayed: return "DELAYED"
        case .noQuote: return "NO QUOTE"
        case .closed: return "CLOSED"
        }
    }

    var accessibilityText: String {
        switch self {
        case .live: return "Live"
        case .saved: return "Showing saved data"
        case .delayed: return "Delayed"
        case .noQuote: return "No quote"
        case .closed: return "Market closed"
        }
    }
}

struct LiveDot: View {
    let state: LiveState
    let ageText: String?

    /// Two-state form kept for existing callers: fresh maps to LIVE, otherwise DELAYED.
    init(fresh: Bool, ageText: String? = nil) {
        self.init(state: fresh ? .live : .delayed, ageText: ageText)
    }

    init(state: LiveState, ageText: String? = nil) {
        self.state = state
        self.ageText = ageText
    }

    private var age: String? {
        guard let text = ageText?.trimmingCharacters(in: .whitespacesAndNewlines),
              !text.isEmpty else { return nil }
        return text
    }

    private var status: some View {
        HStack(spacing: 6) {
            Circle().fill(state == .live ? LeafTheme.gain : LeafTheme.stale)
                .frame(width: 8, height: 8)
                .accessibilityHidden(true)
            Text(state.label)
                .font(LeafType.micro)
                .tracking(0.8)
                .foregroundStyle(LeafTheme.ink)
        }
    }

    @ViewBuilder private var ageLabel: some View {
        if let age {
            Text(age).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) { status; ageLabel }
                .fixedSize(horizontal: true, vertical: true)
            VStack(alignment: .leading, spacing: 4) { status; ageLabel }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(state.accessibilityText + (age.map { ", updated \($0)" } ?? ""))
    }
}

struct RangeStrip<T: Hashable>: View {
    let options: [(T, String)]
    @Binding var selection: T

    init(options: [(T, String)], selection: Binding<T>) {
        self.options = options
        self._selection = selection
    }

    private var buttons: some View {
        ForEach(options.indices, id: \.self) { index in
            let option = options[index]
            Button { selection = option.0 } label: {
                Text(option.1)
                    .font(LeafType.meta)
                    .foregroundStyle(selection == option.0 ? LeafTheme.ink : LeafTheme.inkMuted)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .frame(minWidth: 44, minHeight: 44)
                    .background(selection == option.0 ? LeafTheme.cardRaised : Color.clear, in: Capsule())
            }
            .buttonStyle(.plain)
            .accessibilityAddTraits(selection == option.0 ? .isSelected : [])
        }
    }

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 6) { buttons }.fixedSize(horizontal: true, vertical: true)
            VStack(alignment: .leading, spacing: 6) { buttons }
        }
    }
}

struct YesNoPair: View {
    let yesText: String
    let noText: String
    let yesActive: Bool?

    init(yesText: String, noText: String, yesActive: Bool? = nil) {
        self.yesText = yesText
        self.noText = noText
        self.yesActive = yesActive
    }

    private func pill(_ word: String, text: String, tone: LeafTone, active: Bool) -> some View {
        VStack(spacing: 4) {
            Text(word.uppercased()).font(LeafType.micro).tracking(0.8)
            Text(text).font(LeafType.numberSmall)
        }
        .fixedSize(horizontal: false, vertical: true)
        .foregroundStyle(tone.color)
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity, minHeight: 44)
        .background(tone.soft, in: Capsule())
        .opacity(active ? 1 : 0.55)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(word), \(text)")
    }

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            pill("Yes", text: yesText, tone: .gain, active: yesActive != false)
            pill("No", text: noText, tone: .loss, active: yesActive != true)
        }
        .accessibilityElement(children: .combine)
    }
}

struct ProgressBar: View {
    let value: Double
    let tone: LeafTone

    private var clampedValue: Double { value.isNaN ? 0 : min(1, max(0, value)) }

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Capsule().fill(LeafTheme.line)
                Capsule().fill(tone.color)
                    .frame(width: geometry.size.width * CGFloat(clampedValue))
            }
        }
        .frame(height: 6)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Progress")
        .accessibilityValue(LeafFormat.percent(clampedValue))
    }
}

struct KeyValueRow: View {
    let key: String
    let value: String
    let tone: LeafTone

    init(_ key: String, value: String, tone: LeafTone = .neutral) {
        self.key = key
        self.value = value
        self.tone = tone
    }

    var body: some View {
        LabeledContent {
            Group {
                if tone == .neutral {
                    Text(value)
                } else {
                    Label(value, systemImage: tone.glyph).labelStyle(.titleAndIcon)
                }
            }
            .font(LeafType.number)
            .foregroundStyle(tone.color)
            .fixedSize(horizontal: false, vertical: true)
        } label: {
            Text(key).font(LeafType.body).foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .labeledContentStyle(LeafKeyValueStyle())
        .accessibilityElement(children: .combine)
    }
}

private struct LeafKeyValueStyle: LabeledContentStyle {
    func makeBody(configuration: Configuration) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: 12) {
                configuration.label.fixedSize()
                Spacer(minLength: 0)
                configuration.content.fixedSize()
            }
            VStack(alignment: .leading, spacing: 4) {
                configuration.label
                configuration.content
            }
        }
    }
}

struct SectionHeader: View {
    let title: String
    let trailing: String?

    init(_ title: String, trailing: String? = nil) {
        self.title = title
        self.trailing = trailing
    }

    private var titleLabel: some View {
        Text(title).font(LeafType.heading).foregroundStyle(LeafTheme.ink)
            .fixedSize(horizontal: false, vertical: true)
            .accessibilityAddTraits(.isHeader)
    }

    @ViewBuilder private var trailingLabel: some View {
        if let trailing {
            Text(trailing).font(LeafType.meta).foregroundStyle(LeafTheme.inkMuted)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: 12) {
                titleLabel.fixedSize()
                Spacer(minLength: 0)
                trailingLabel.fixedSize()
            }
            VStack(alignment: .leading, spacing: 4) { titleLabel; trailingLabel }
        }
        .accessibilityElement(children: .combine)
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(LeafType.heading)
            .foregroundStyle(LeafTheme.ground)
            .fixedSize(horizontal: false, vertical: true)
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .frame(minHeight: 48)
            .background(LeafTheme.ink, in: Capsule())
            .contentShape(Capsule())
            .opacity(isEnabled ? (configuration.isPressed ? 0.8 : 1) : 0.45)
    }
}

struct SecondaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(LeafType.heading)
            .foregroundStyle(LeafTheme.ink)
            .fixedSize(horizontal: false, vertical: true)
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .frame(minHeight: 48)
            .background(LeafTheme.cardRaised, in: Capsule())
            .contentShape(Capsule())
            .opacity(isEnabled ? (configuration.isPressed ? 0.8 : 1) : 0.45)
    }
}

extension ButtonStyle where Self == PrimaryButtonStyle {
    static var leafPrimary: PrimaryButtonStyle { PrimaryButtonStyle() }
}

extension ButtonStyle where Self == SecondaryButtonStyle {
    static var leafSecondary: SecondaryButtonStyle { SecondaryButtonStyle() }
}

struct LeafScreenBackground: ViewModifier {
    func body(content: Content) -> some View {
        content
            .scrollContentBackground(.hidden)
            .background(LeafTheme.ground.ignoresSafeArea())
    }
}

struct StudioLauncherHiddenKey: PreferenceKey {
    static var defaultValue = false

    static func reduce(value: inout Bool, nextValue: () -> Bool) {
        value = value || nextValue()
    }
}

extension View {
    func leafCard() -> some View { LeafCard { self } }
    func leafScreenBackground() -> some View { modifier(LeafScreenBackground()) }
    func hidesStudioLauncher(_ hidden: Bool = true) -> some View {
        preference(key: StudioLauncherHiddenKey.self, value: hidden)
    }
}
