import SwiftUI
import UIKit
import CoreText

public enum LeafTheme {
    static let ground = Color(dark: 0x0c0e12, light: 0xf7f8fa)
    static let card = Color(dark: 0x15181e, light: 0xffffff)
    static let cardRaised = Color(dark: 0x1c2027, light: 0xf1f3f5)
    static let accentFill = Color(dark: 0x232830, light: 0xf1f3f5)
    static let line = Color(dark: 0x262b33, light: 0xe2e5ea)
    static let input = Color(dark: 0x2f353f, light: 0xd2d6dd)
    static let ring = Color(dark: 0xaeb4bd, light: 0x0b0d12)
    static let ink = Color(dark: 0xe6e8ec, light: 0x0b0d12)
    static let inkMuted = Color(dark: 0x9aa1ac, light: 0x6b7280)
    static let inkFaint = Color(dark: 0x6b7280, light: 0x9aa1ac)

    static let primary = Color(dark: 0xe6e8ec, light: 0x0b0d12)
    static let primaryForeground = Color(dark: 0x0c0e12, light: 0xffffff)
    static let gain = Color(dark: 0x4cc38a, light: 0x146c43)
    static let loss = Color(dark: 0xf27a72, light: 0xb3261e)
    static let warn = Color(dark: 0xe0a94b, light: 0x95590a)
    static let stale = Color(dark: 0x9aa1ac, light: 0x5b6470)
    static let gainSoft = Color(dark: 0x10251b, light: 0xe9f6ef)
    static let lossSoft = Color(dark: 0x2a1615, light: 0xfdecec)
    static let warnSoft = Color(dark: 0x2a2110, light: 0xfdf3e2)
    static let staleSoft = Color(dark: 0x1c2129, light: 0xeef0f3)
    static let gainLine = Color(dark: 0x1f4a37, light: 0xbfe3cf)
    static let lossLine = Color(dark: 0x532825, light: 0xf3c9c7)
    static let warnLine = Color(dark: 0x574526, light: 0xf0dcae)
    static let staleLine = Color(dark: 0x333a44, light: 0xdce0e6)
    static let destructive = Color(dark: 0xdc4c48, light: 0xb3261e)
    static let series1 = Color(dark: 0x5b9bd5, light: 0x2f6f9f)
    static let series2 = Color(dark: 0x4cc38a, light: 0x146c43)
    static let series3 = Color(dark: 0xe0a94b, light: 0x95590a)
    static let series4 = Color(dark: 0x9b87e8, light: 0x6d5bd0)
    static let series5 = Color(dark: 0x9aa1ac, light: 0x64748b)
    static let accent = ink
    static let radius: CGFloat = 12
    static let radiusSmall: CGFloat = 8
    static let cardPadding: CGFloat = 12
}

extension Color {
    /// Resolves per appearance through a UIColor provider; each hex is 0xRRGGBB.
    init(dark: UInt32, light: UInt32) {
        self.init(uiColor: UIColor { traits in
            UIColor(hex: traits.userInterfaceStyle == .dark ? dark : light)
        })
    }
}

private extension UIColor {
    convenience init(hex: UInt32) {
        self.init(red: CGFloat((hex >> 16) & 0xff) / 255,
                  green: CGFloat((hex >> 8) & 0xff) / 255,
                  blue: CGFloat(hex & 0xff) / 255,
                  alpha: 1)
    }
}

enum LeafFonts {
    @MainActor static func registerIfNeeded() {
        let fonts = [
            (name: "Geist-Regular", resource: "Geist-Variable"),
            (name: "GeistMono-Regular", resource: "GeistMono-Variable")
        ]
        for font in fonts {
            guard UIFont(name: font.name, size: 12) == nil,
                  let url = Bundle.main.url(forResource: font.resource,
                                            withExtension: "ttf", subdirectory: "Fonts") else { continue }
            _ = CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
        }
    }
}

enum LeafType {
    static func sans(_ size: CGFloat, weight: Font.Weight = .regular,
                     relativeTo: Font.TextStyle) -> Font {
        Font.custom("Geist", size: size, relativeTo: relativeTo).weight(weight)
    }

    static func mono(_ size: CGFloat, weight: Font.Weight = .regular,
                     relativeTo: Font.TextStyle) -> Font {
        Font.custom("Geist Mono", size: size, relativeTo: relativeTo).weight(weight)
    }

    static let display = mono(34, weight: .bold, relativeTo: .largeTitle).monospacedDigit()
    static let title = sans(22, weight: .semibold, relativeTo: .title2)
    static let heading = sans(17, weight: .semibold, relativeTo: .headline)
    static let body = sans(15, relativeTo: .body)
    static let meta = sans(13, relativeTo: .footnote)
    static let micro = sans(11, weight: .semibold, relativeTo: .caption2)
    static let numberLarge = mono(28, weight: .semibold, relativeTo: .title).monospacedDigit()
    static let number = mono(17, weight: .medium, relativeTo: .body).monospacedDigit()
    static let numberSmall = mono(13, relativeTo: .footnote).monospacedDigit()
    static let ticker = mono(15, relativeTo: .body)
    static let tickerSmall = mono(13, relativeTo: .footnote)
}

enum LeafAppearance: String, CaseIterable {
    case system, dark, light

    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .dark: return .dark
        case .light: return .light
        }
    }

    var label: String {
        switch self {
        case .system: return "System"
        case .dark: return "Dark"
        case .light: return "Light"
        }
    }
}

enum LeafFormat {
    static func money(cents: Int) -> String {
        // Integer arithmetic preserves cents, including at the limits of Int.
        let magnitude = cents.magnitude
        let fraction = magnitude % 100
        let amount = "$\(magnitude / 100).\(fraction < 10 ? "0" : "")\(fraction)"
        return cents < 0 ? "−" + amount : amount
    }

    static func signedMoney(cents: Int) -> String {
        (cents > 0 ? "+" : "") + money(cents: cents)
    }

    /// Formats a fraction, so 0.125 is 12.5%.
    static func percent(_ value: Double) -> String {
        guard value.isFinite else { return "Unknown" }
        return value.formatted(.percent.precision(.fractionLength(0...1))
            .locale(Locale(identifier: "en_US")))
            .replacingOccurrences(of: "-", with: "−")
    }

    static func count(_ value: Int) -> String {
        value.formatted(.number.grouping(.automatic).locale(Locale(identifier: "en_US")))
    }
}

enum LeafTone: Equatable {
    case gain, loss, warn, stale, neutral

    static func forDelta(cents: Int) -> LeafTone {
        cents > 0 ? .gain : cents < 0 ? .loss : .neutral
    }

    var color: Color {
        switch self {
        case .gain: return LeafTheme.gain
        case .loss: return LeafTheme.loss
        case .warn: return LeafTheme.warn
        case .stale: return LeafTheme.stale
        case .neutral: return LeafTheme.ink
        }
    }

    var soft: Color {
        switch self {
        case .gain: return LeafTheme.gainSoft
        case .loss: return LeafTheme.lossSoft
        case .warn: return LeafTheme.warnSoft
        case .stale: return LeafTheme.staleSoft
        case .neutral: return LeafTheme.cardRaised
        }
    }

    var line: Color {
        switch self {
        case .gain: return LeafTheme.gainLine
        case .loss: return LeafTheme.lossLine
        case .warn: return LeafTheme.warnLine
        case .stale: return LeafTheme.staleLine
        case .neutral: return LeafTheme.line
        }
    }

    var glyph: String {
        switch self {
        case .gain: return "arrow.up.right"
        case .loss: return "arrow.down.right"
        case .warn: return "clock"
        case .stale: return "questionmark"
        case .neutral: return "minus"
        }
    }

    var stateGlyph: String? {
        switch self {
        case .gain: return "checkmark"
        case .loss: return "xmark"
        case .warn: return "clock"
        case .stale: return "questionmark"
        case .neutral: return nil
        }
    }
}
