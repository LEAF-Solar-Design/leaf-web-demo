import Foundation
import Security

enum KeychainStoreError: Error { case status(OSStatus), unexpectedData }

struct KeychainStore {
    static let keyDERAccount = "kalshi.key.der"
    static let keyIDAccount = "kalshi.key.id"
    static let dashboardTokenAccount = "dashboard.token"
    let service: String
    init(service: String = "com.evan.leafhft") { self.service = service }

    private func query(account: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account,
         kSecAttrSynchronizable as String: false]
    }
    /// Store decoded DER, key ID, or token bytes. Never pass PEM entry text.
    func save(_ data: Data, account: String) throws {
        try FixtureMode.current.requireLiveAccess()
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        let existing = query(account: account)
        var status = SecItemUpdate(existing as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            let item = existing.merging(attributes) { _, new in new }
            status = SecItemAdd(item as CFDictionary, nil)
            if status == errSecDuplicateItem {
                status = SecItemUpdate(existing as CFDictionary, attributes as CFDictionary)
            }
        }
        guard status == errSecSuccess else { throw KeychainStoreError.status(status) }
    }
    func load(account: String) throws -> Data? {
        try FixtureMode.current.requireLiveAccess()
        var request = query(account: account)
        request[kSecReturnData as String] = true
        request[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(request as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess else { throw KeychainStoreError.status(status) }
        guard let data = result as? Data else { throw KeychainStoreError.unexpectedData }
        return data
    }
    func delete(account: String) throws {
        try FixtureMode.current.requireLiveAccess()
        let status = SecItemDelete(query(account: account) as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw KeychainStoreError.status(status)
        }
    }
}
