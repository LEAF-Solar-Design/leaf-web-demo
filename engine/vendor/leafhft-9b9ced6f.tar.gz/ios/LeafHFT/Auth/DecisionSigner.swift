import CryptoKit
import Foundation
import LocalAuthentication
import Security

// se-p256 presence for the tuning inbox (docs/contracts/tuning-inbox-v1.md, "Decision bytes and
// cryptography"). The key is born in the Secure Enclave with .privateKeyUsage and .biometryCurrentSet,
// so the enclave itself refuses every signature without a fresh Face ID match. The private key has no
// export path: only the public SPKI and its SHA-256 fingerprint ever leave this file.

/// A P-256 key that signs decision bytes. Every call to `signMessage` must be gated on user presence.
protocol DecisionSigningKey: AnyObject {
    /// DER SubjectPublicKeyInfo of the P-256 public key.
    func publicKeySPKI() throws -> Data
    /// ECDSA P-256 over SHA-256(message), ASN.1 DER. The message is signed as-is, never pre-hashed.
    func signMessage(_ message: Data, reason: String) async throws -> Data
}

enum DecisionSignerError: Error, Equatable {
    case fixtureMode
    case secureEnclaveUnavailable
    case faceIDNotConfigured
    case alreadyEnrolled
    case notEnrolled
    case userCancelled
    case authenticationFailed
    case keychain(Int32)
    case invalidPublicKey
    case invalidSignature
    case invalidDecision(String)
    case planHashMismatch
    case assertionTooLarge
}

/// The decision object and its exact signed ASCII bytes: eight LF-terminated lines, in contract order.
struct TuningDecision: Equatable {
    static let header = "leafhft.tuning-decision.v1"
    let verb: String
    let proposalID: String
    let planSeq: Int64
    let planSHA256: String
    let runnerNonce: String
    let account: String
    let issuedAtMs: Int64

    /// Binds values read from the verified plan bytes plus the hash this phone computed over them.
    /// The server's metadata never reaches the signed bytes.
    static func accept(plan: VerifiedTuningPlan, issuedAtMs: Int64) -> TuningDecision {
        TuningDecision(verb: "accept", proposalID: plan.document.proposalID, planSeq: plan.document.planSeq,
                       planSHA256: plan.sha256, runnerNonce: plan.document.runnerNonce,
                       account: plan.document.account, issuedAtMs: issuedAtMs)
    }

    func validate() throws {
        let verbBytes = Array(verb.utf8)
        guard (1...32).contains(verbBytes.count), verbBytes.allSatisfy({ (0x61...0x7A).contains($0) }) else {
            throw DecisionSignerError.invalidDecision("verb")
        }
        guard TuningSyntax.isUUID(proposalID) else { throw DecisionSignerError.invalidDecision("proposal_id") }
        guard (1...TuningInboxLimits.maxSafeInteger).contains(planSeq) else { throw DecisionSignerError.invalidDecision("plan_seq") }
        guard TuningSyntax.isSHA256(planSHA256) else { throw DecisionSignerError.invalidDecision("plan_sha256") }
        guard TuningSyntax.isNonce(runnerNonce) else { throw DecisionSignerError.invalidDecision("runner_nonce") }
        guard TuningSyntax.isAccount(account) else { throw DecisionSignerError.invalidDecision("account") }
        guard (0...TuningInboxLimits.maxSafeInteger).contains(issuedAtMs) else {
            throw DecisionSignerError.invalidDecision("issued_at_ms")
        }
    }

    /// The ASCII message. Integers are base-10 with no sign, padding or exponent.
    func messageBytes() throws -> Data {
        try validate()
        let lines = [
            Self.header, "verb=" + verb, "proposal_id=" + proposalID, "plan_seq=" + String(planSeq),
            "plan_sha256=" + planSHA256, "runner_nonce=" + runnerNonce, "account=" + account,
            "issued_at_ms=" + String(issuedAtMs),
        ]
        return Data(lines.map { $0 + "\n" }.joined().utf8)
    }

    func json() throws -> TuningJSON {
        try validate()
        return .object([
            "verb": .string(verb), "proposal_id": .string(proposalID), "plan_seq": .int(planSeq),
            "plan_sha256": .string(planSHA256), "runner_nonce": .string(runnerNonce), "account": .string(account),
            "issued_at_ms": .int(issuedAtMs),
        ])
    }
}

/// Assertion JSON has exactly kind, credential_id, decision and signature_b64; kind is se-p256 only.
struct TuningAssertion: Equatable {
    static let kind = "se-p256"
    let credentialID: String
    let decision: TuningDecision
    let signatureDER: Data

    /// Canonical assertion bytes. Evidence SHA-256 hashes exactly these, signature included.
    func canonicalBytes() throws -> Data {
        guard TuningSyntax.isSHA256(credentialID) else { throw DecisionSignerError.invalidDecision("credential_id") }
        let decisionJSON = try decision.json()
        return try TuningJSON.object([
            "kind": .string(Self.kind), "credential_id": .string(credentialID), "decision": decisionJSON,
            "signature_b64": .string(signatureDER.base64EncodedString()),
        ]).canonicalBytes()
    }
}

struct SignedTuningAssertion: Equatable {
    let assertion: TuningAssertion
    let message: Data
    let canonicalJSON: Data
    let evidenceSHA256: String

    /// assertion_b64 on the mobile decision route: base64 of the canonical assertion JSON.
    var assertionB64: String { canonicalJSON.base64EncodedString() }
}

/// DER SubjectPublicKeyInfo for secp256r1 only. The prefix pins the curve; nothing else is accepted.
enum PresenceSPKI {
    static let p256Prefix: [UInt8] = [
        0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x02, 0x01,
        0x06, 0x08, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x03, 0x01, 0x07, 0x03, 0x42, 0x00,
    ]

    static func spki(x963 point: Data) throws -> Data {
        guard point.count == 65, point.first == 0x04 else { throw DecisionSignerError.invalidPublicKey }
        _ = try publicKey(spki: Data(p256Prefix) + point)
        return Data(p256Prefix) + point
    }

    static func publicKey(spki: Data) throws -> P256.Signing.PublicKey {
        guard spki.count == p256Prefix.count + 65, Array(spki.prefix(p256Prefix.count)) == p256Prefix else {
            throw DecisionSignerError.invalidPublicKey
        }
        do { return try P256.Signing.PublicKey(x963Representation: Data(spki.suffix(65))) }
        catch { throw DecisionSignerError.invalidPublicKey }
    }

    /// credential_id: lowercase SHA-256 of the DER SPKI, the value the reviewed runner pin names.
    static func credentialID(spki: Data) -> String { TuningSyntax.sha256Hex(spki) }

    static func signatureValid(spki: Data, signatureDER: Data, message: Data) -> Bool {
        guard (8...72).contains(signatureDER.count), let key = try? publicKey(spki: spki),
              let signature = try? P256.Signing.ECDSASignature(derRepresentation: signatureDER) else { return false }
        return key.isValidSignature(signature, for: message)
    }
}

/// Signs verb=accept over a verified plan and checks its own work before anything leaves the phone.
struct DecisionSigner {
    let key: DecisionSigningKey

    func signAccept(plan: VerifiedTuningPlan, issuedAtMs: Int64, reason: String) async throws -> SignedTuningAssertion {
        // The hash is recomputed here, immediately before Face ID, over the exact bytes that were rendered.
        guard plan.hashMatches, TuningSyntax.sha256Hex(plan.bytes) == plan.sha256 else {
            throw DecisionSignerError.planHashMismatch
        }
        let decision = TuningDecision.accept(plan: plan, issuedAtMs: issuedAtMs)
        let message = try decision.messageBytes()
        let spki = try key.publicKeySPKI()
        _ = try PresenceSPKI.publicKey(spki: spki)
        let signature = try await key.signMessage(message, reason: reason)
        return try Self.assemble(decision: decision, message: message, spki: spki, signatureDER: signature)
    }

    /// Refuses a signature that does not verify under the key's own SPKI, so a broken signer fails here.
    static func assemble(decision: TuningDecision, message: Data, spki: Data, signatureDER: Data) throws -> SignedTuningAssertion {
        guard try decision.messageBytes() == message,
              PresenceSPKI.signatureValid(spki: spki, signatureDER: signatureDER, message: message) else {
            throw DecisionSignerError.invalidSignature
        }
        let assertion = TuningAssertion(credentialID: PresenceSPKI.credentialID(spki: spki), decision: decision,
                                        signatureDER: signatureDER)
        let json = try assertion.canonicalBytes()
        guard json.count <= TuningInboxLimits.maxAssertionBytes else { throw DecisionSignerError.assertionTooLarge }
        return SignedTuningAssertion(assertion: assertion, message: message, canonicalJSON: json,
                                     evidenceSHA256: TuningSyntax.sha256Hex(json))
    }

    static func message(for error: Error) -> String {
        switch error as? DecisionSignerError {
        case .fixtureMode: return "The presence key is not available in demo mode."
        case .secureEnclaveUnavailable: return "This device has no Secure Enclave, so it cannot sign decisions."
        case .faceIDNotConfigured: return "This build cannot ask for Face ID. Nothing was signed."
        case .alreadyEnrolled: return "A presence key already exists on this phone."
        case .notEnrolled: return "Create this phone's presence key in Presence key before accepting."
        case .userCancelled: return "Face ID was cancelled. Nothing was signed or sent."
        case .authenticationFailed: return "Face ID did not match. Nothing was signed or sent."
        case .keychain(let status): return "The Secure Enclave refused the key operation (\(status)). Nothing was sent."
        case .invalidPublicKey: return "The presence key is not a P-256 key. Replace it in Presence key."
        case .invalidSignature: return "The signature did not verify on this phone. Nothing was sent."
        case .invalidDecision(let field): return "The decision could not be built (\(field)). Nothing was signed."
        case .planHashMismatch: return "The plan bytes do not match their hash. Nothing was signed."
        case .assertionTooLarge: return "The signed decision is too large to send. Nothing was sent."
        case nil: return "The decision could not be signed. Nothing was sent."
        }
    }
}

/// The Secure Enclave key. Its private half is created inside the enclave and never exported; the
/// keychain holds only a reference, and every use requires Face ID against the current enrollment.
final class SecureEnclaveDecisionKey: DecisionSigningKey {
    static let applicationTag = Data("com.evan.leafhft.tuning-presence.p256.v1".utf8)
    static let accessControlFlags: SecAccessControlCreateFlags = [.privateKeyUsage, .biometryCurrentSet]
    static let maxMessageBytes = 1_024

    private init() {}

    static var hardwareAvailable: Bool { SecureEnclave.isAvailable }

    /// Returns the enrolled key without prompting, or nil when this phone has none.
    static func load(fixtureMode: FixtureMode = .current) throws -> SecureEnclaveDecisionKey? {
        guard !fixtureMode.enabled else { throw DecisionSignerError.fixtureMode }
        return try copyPrivateKey(context: silentContext()) == nil ? nil : SecureEnclaveDecisionKey()
    }

    /// Creates the key once. Rotation is an explicit replace, because the runner pin must change with it.
    static func create(fixtureMode: FixtureMode = .current) throws -> SecureEnclaveDecisionKey {
        guard !fixtureMode.enabled else { throw DecisionSignerError.fixtureMode }
        guard hardwareAvailable else { throw DecisionSignerError.secureEnclaveUnavailable }
        guard try copyPrivateKey(context: silentContext()) == nil else { throw DecisionSignerError.alreadyEnrolled }
        var error: Unmanaged<CFError>?
        guard let access = SecAccessControlCreateWithFlags(kCFAllocatorDefault, kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly,
                                                           accessControlFlags, &error) else {
            throw map(error?.takeRetainedValue())
        }
        let attributes: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
            kSecAttrKeySizeInBits as String: 256,
            kSecAttrTokenID as String: kSecAttrTokenIDSecureEnclave,
            kSecPrivateKeyAttrs as String: [
                kSecAttrIsPermanent as String: true,
                kSecAttrApplicationTag as String: applicationTag,
                kSecAttrAccessControl as String: access,
                kSecAttrLabel as String: "Kashbot tuning presence",
            ] as [String: Any],
        ]
        guard SecKeyCreateRandomKey(attributes as CFDictionary, &error) != nil else {
            throw map(error?.takeRetainedValue())
        }
        return SecureEnclaveDecisionKey()
    }

    static func delete(fixtureMode: FixtureMode = .current) throws {
        guard !fixtureMode.enabled else { throw DecisionSignerError.fixtureMode }
        let query: [String: Any] = [
            kSecClass as String: kSecClassKey,
            kSecAttrKeyClass as String: kSecAttrKeyClassPrivate,
            kSecAttrApplicationTag as String: applicationTag,
            kSecAttrTokenID as String: kSecAttrTokenIDSecureEnclave,
        ]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw DecisionSignerError.keychain(status) }
    }

    func publicKeySPKI() throws -> Data {
        guard let key = try Self.copyPrivateKey(context: Self.silentContext()) else { throw DecisionSignerError.notEnrolled }
        guard let publicKey = SecKeyCopyPublicKey(key) else { throw DecisionSignerError.invalidPublicKey }
        var error: Unmanaged<CFError>?
        guard let point = SecKeyCopyExternalRepresentation(publicKey, &error) as Data? else {
            throw Self.map(error?.takeRetainedValue())
        }
        return try PresenceSPKI.spki(x963: point)
    }

    /// A fresh LAContext per call with zero reuse, so Face ID is asked for every signature.
    func signMessage(_ message: Data, reason: String) async throws -> Data {
        guard Bundle.main.object(forInfoDictionaryKey: "NSFaceIDUsageDescription") != nil else {
            throw DecisionSignerError.faceIDNotConfigured
        }
        guard !message.isEmpty, message.count <= Self.maxMessageBytes else {
            throw DecisionSignerError.invalidDecision("message")
        }
        let prompt = TuningSyntax.isPrintable(reason, maxBytes: 160) ? reason : "Accept tuning plan"
        // SecKeyCreateSignature blocks while Face ID runs, so it never runs on the main actor.
        return try await Task.detached(priority: .userInitiated) {
            let context = LAContext()
            context.localizedReason = prompt
            context.touchIDAuthenticationAllowableReuseDuration = 0
            guard let key = try SecureEnclaveDecisionKey.copyPrivateKey(context: context) else {
                throw DecisionSignerError.notEnrolled
            }
            guard SecKeyIsAlgorithmSupported(key, .sign, .ecdsaSignatureMessageX962SHA256) else {
                throw DecisionSignerError.invalidPublicKey
            }
            var error: Unmanaged<CFError>?
            guard let signature = SecKeyCreateSignature(key, .ecdsaSignatureMessageX962SHA256, message as CFData,
                                                        &error) as Data? else {
                throw SecureEnclaveDecisionKey.map(error?.takeRetainedValue())
            }
            return signature
        }.value
    }

    private static func silentContext() -> LAContext {
        let context = LAContext()
        context.interactionNotAllowed = true
        return context
    }

    private static func copyPrivateKey(context: LAContext) throws -> SecKey? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassKey,
            kSecAttrKeyClass as String: kSecAttrKeyClassPrivate,
            kSecAttrApplicationTag as String: applicationTag,
            kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
            kSecAttrTokenID as String: kSecAttrTokenIDSecureEnclave,
            kSecUseAuthenticationContext as String: context,
            kSecMatchLimit as String: kSecMatchLimitOne,
            kSecReturnRef as String: true,
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let result, CFGetTypeID(result) == SecKeyGetTypeID() else {
            throw DecisionSignerError.keychain(status)
        }
        return (result as! SecKey)
    }

    private static func map(_ error: CFError?) -> DecisionSignerError {
        guard let error else { return .keychain(errSecInternalError) }
        let code = (error as Error as NSError).code
        switch code {
        case Int(errSecUserCanceled), LAError.userCancel.rawValue, LAError.systemCancel.rawValue, LAError.appCancel.rawValue:
            return .userCancelled
        case Int(errSecAuthFailed), LAError.authenticationFailed.rawValue, LAError.biometryLockout.rawValue:
            return .authenticationFailed
        case Int(errSecItemNotFound):
            return .notEnrolled
        default:
            return .keychain(Int32(clamping: code))
        }
    }
}
