import Foundation
import Security
import LeafHFTCore

enum KalshiSignerError: Error {
    case invalidKey
    case unsupportedAlgorithm
    case signingFailed
}

struct KalshiSigner {
    private let key: SecKey
    init(pkcs1DER: Data) throws {
        let attributes: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeyClass as String: kSecAttrKeyClassPrivate,
            kSecAttrKeySizeInBits as String: 2048
        ]
        var error: Unmanaged<CFError>?
        guard let imported = SecKeyCreateWithData(pkcs1DER as CFData, attributes as CFDictionary, &error) else {
            _ = error?.takeRetainedValue()
            throw KalshiSignerError.invalidKey
        }
        guard SecKeyIsAlgorithmSupported(imported, .sign, .rsaSignatureMessagePSSSHA256) else {
            throw KalshiSignerError.unsupportedAlgorithm
        }
        key = imported
    }
    var publicKey: SecKey? { SecKeyCopyPublicKey(key) }
    /// Export only public material, wrapped as canonical RSA SubjectPublicKeyInfo DER.
    func publicKeyDER() throws -> Data {
        guard let publicKey else { throw KalshiSignerError.invalidKey }
        var error: Unmanaged<CFError>?
        guard let representation = SecKeyCopyExternalRepresentation(publicKey, &error) else {
            _ = error?.takeRetainedValue()
            throw KalshiSignerError.invalidKey
        }
        func der(_ tag: UInt8, _ body: Data) -> Data {
            var size = body.count
            var length: [UInt8] = []
            repeat { length.insert(UInt8(size & 0xff), at: 0); size >>= 8 } while size > 0
            return Data([tag] + (body.count < 128 ? length : [0x80 | UInt8(length.count)] + length)) + body
        }
        let rsaAlgorithm = Data([0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48, 0x86,
                                 0xf7, 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00])
        return der(0x30, rsaAlgorithm + der(0x03, Data([0]) + (representation as Data)))
    }

    func bindingRequest(challenge: BindingChallenge, keyID: String, now: Date = Date()) throws -> BindingRequest {
        let publicDER = try publicKeyDER()
        let message = try challenge.canonicalMessage(keyID: keyID, publicKeyDER: publicDER, now: now)
        return BindingRequest(challengeId: challenge.challengeId,
                              keyId: try BindingChallenge.normalizedKeyID(keyID),
                              publicKeyDer: publicDER.base64EncodedString(), signature: try sign(message))
    }

    func signature(timestampMs: Int64, path: String) throws -> String {
        let message = canonicalSigningMessage(timestampMs: timestampMs, path: path)
        return try sign(message)
    }

    private func sign(_ message: Data) throws -> String {
        var error: Unmanaged<CFError>?
        guard let signature = SecKeyCreateSignature(key, .rsaSignatureMessagePSSSHA256,
                                                    message as CFData, &error) else {
            _ = error?.takeRetainedValue()
            throw KalshiSignerError.signingFailed
        }
        return (signature as Data).base64EncodedString()
    }
}
