import Foundation
import CryptoKit
import Darwin
import LeafHFTCore

enum USBKeyDraftError: Error { case unavailable, invalid, expired }

/// Only encrypted files cross Documents. Plaintext exists only in a Settings draft.
final class USBKeyDraftReceiver {
    struct Request: Codable {
        let version: Int
        let request_id: String
        let public_key: String
        let expires_at: Int
    }
    struct Envelope: Codable {
        let version: Int
        let request_id: String
        let sender_public_key: String
        let nonce: String
        let ciphertext: String
    }
    struct Draft: Codable {
        let key_id: String
        let private_key_pem: String
    }
    private let documents: URL
    private let now: () -> Date
    private var directory: Int32 = -1
    private var key: P256.KeyAgreement.PrivateKey?
    private var request: Request?
    private var deadline: TimeInterval = 0
    private var uptimeDeadline: TimeInterval = 0

    init(documents: URL? = nil, now: @escaping () -> Date = Date.init) {
        self.documents = documents ?? FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        self.now = now
    }

    deinit { cancel() }

    @discardableResult func begin() throws -> Request {
        cancel()
        do {
            let parent = open(documents.path, O_RDONLY | O_DIRECTORY | O_NOFOLLOW)
            guard parent >= 0 else { throw USBKeyDraftError.unavailable }
            defer { close(parent) }
            guard mkdirat(parent, "KashbotPairing", 0o700) == 0 || errno == EEXIST else {
                throw USBKeyDraftError.unavailable
            }
            directory = openat(parent, "KashbotPairing", O_RDONLY | O_DIRECTORY | O_NOFOLLOW)
            guard directory >= 0 else { throw USBKeyDraftError.unavailable }
            var folder = documents.appendingPathComponent("KashbotPairing", isDirectory: true)
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            try folder.setResourceValues(values)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: folder.path)
            try removeFiles()
            let privateKey = P256.KeyAgreement.PrivateKey()
            let expiry = Int(now().timeIntervalSince1970) + 120
            let newRequest = Request(version: 1, request_id: UUID().uuidString.lowercased(),
                                     public_key: privateKey.publicKey.x963Representation.base64EncodedString(),
                                     expires_at: expiry)
            let data = try JSONEncoder().encode(newRequest)
            guard data.count <= 4096 else { throw USBKeyDraftError.invalid }
            let fd = openat(directory, "request.tmp", O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0o600)
            guard fd >= 0 else { throw USBKeyDraftError.unavailable }
            defer { close(fd) }
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete],
                ofItemAtPath: folder.appendingPathComponent("request.tmp").path)
            try data.withUnsafeBytes { buffer in
                var offset = 0
                while offset < buffer.count {
                    let count = write(fd, buffer.baseAddress!.advanced(by: offset), buffer.count - offset)
                    guard count > 0 else { throw USBKeyDraftError.unavailable }
                    offset += count
                }
            }
            guard fsync(fd) == 0, renameat(directory, "request.tmp", directory, "request.json") == 0 else {
                throw USBKeyDraftError.unavailable
            }
            key = privateKey
            request = newRequest
            deadline = TimeInterval(expiry)
            uptimeDeadline = ProcessInfo.processInfo.systemUptime + 120
            return newRequest
        } catch {
            cancel()
            throw USBKeyDraftError.unavailable
        }
    }

    /// nil means no envelope yet. Any rejection consumes the session, leaving caller drafts untouched.
    func receive() throws -> Draft? {
        guard let request, let key, directory >= 0 else { throw USBKeyDraftError.unavailable }
        do {
            guard now().timeIntervalSince1970 < deadline,
                  ProcessInfo.processInfo.systemUptime < uptimeDeadline else { throw USBKeyDraftError.expired }
            let fd = openat(directory, "envelope.json", O_RDONLY | O_NOFOLLOW | O_NONBLOCK)
            if fd < 0 && errno == ENOENT { return nil }
            guard fd >= 0 else { throw USBKeyDraftError.invalid }
            let handle = FileHandle(fileDescriptor: fd, closeOnDealloc: true)
            defer { try? handle.close() }
            var metadata = stat()
            guard fstat(fd, &metadata) == 0, (metadata.st_mode & S_IFMT) == S_IFREG,
                  metadata.st_size <= 100_000 else { throw USBKeyDraftError.invalid }
            let data = try handle.read(upToCount: 100_001) ?? Data()
            guard data.count <= 100_000 else { throw USBKeyDraftError.invalid }
            let envelope = try JSONDecoder().decode(Envelope.self, from: data)
            guard envelope.version == 1, envelope.request_id == request.request_id,
                  let publicData = Data(base64Encoded: envelope.sender_public_key), publicData.count == 65,
                  let nonce = Data(base64Encoded: envelope.nonce), nonce.count == 12,
                  let ciphertext = Data(base64Encoded: envelope.ciphertext), ciphertext.count >= 16,
                  ciphertext.count <= 65_552 else { throw USBKeyDraftError.invalid }
            let sender = try P256.KeyAgreement.PublicKey(x963Representation: publicData)
            let secret = try key.sharedSecretFromKeyAgreement(with: sender)
            let symmetric = secret.hkdfDerivedSymmetricKey(using: SHA256.self,
                salt: Data(request.request_id.utf8), sharedInfo: Data("Kashbot HFT USB import v1".utf8), outputByteCount: 32)
            let box = try AES.GCM.SealedBox(nonce: AES.GCM.Nonce(data: nonce),
                ciphertext: ciphertext.dropLast(16), tag: ciphertext.suffix(16))
            let plaintext = try AES.GCM.open(box, using: symmetric, authenticating: Data(request.request_id.utf8))
            guard plaintext.count <= 65_536 else { throw USBKeyDraftError.invalid }
            let draft = try JSONDecoder().decode(Draft.self, from: plaintext)
            guard !draft.key_id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  draft.key_id.utf8.count <= 256 else { throw USBKeyDraftError.invalid }
            _ = try KalshiSigner(pkcs1DER: decodeRSAPrivateKeyPEM(draft.private_key_pem))
            // Clean up before returning anything that the UI could publish as a draft.
            try removeFiles()
            cancel()
            return draft
        } catch {
            cancel()
            throw USBKeyDraftError.invalid
        }
    }

    func cancel() {
        key = nil
        request = nil
        deadline = 0
        uptimeDeadline = 0
        if directory >= 0 {
            try? removeFiles()
            close(directory)
            directory = -1
        }
    }

    private func removeFiles() throws {
        for name in ["request.json", "request.tmp", "envelope.pending", "envelope.json"] {
            guard unlinkat(directory, name, 0) == 0 || errno == ENOENT else {
                throw USBKeyDraftError.unavailable
            }
        }
    }
}
