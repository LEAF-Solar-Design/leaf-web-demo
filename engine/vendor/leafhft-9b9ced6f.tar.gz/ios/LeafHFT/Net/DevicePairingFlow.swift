import Foundation
import Combine
import LeafHFTCore

@MainActor protocol DevicePairingClientProtocol {
    func requestPairing(deviceName: String) async throws -> DevicePairingRequest
    func pollPairing(id: String, pollToken: String) async throws -> DevicePairingPoll
}

enum DevicePairingPhase: Equatable {
    case idle
    case requesting
    case waiting(code: String, expiresAt: Date)
    case approved
    case expired
    case cancelled
    case failed

    var userStatus: String? {
        switch self {
        case .idle: return nil
        case .requesting: return "Creating a secure pairing code…"
        case .waiting: return "Waiting for approval in the dashboard."
        case .approved: return "Paired. Dashboard access is ready."
        case .expired: return "This code expired. Tap Pair this iPhone to get a new one."
        case .cancelled: return "Pairing stopped. Tap Pair this iPhone to try again."
        case .failed: return "Could not pair this iPhone. Check the connection and try again."
        }
    }

    var isRunning: Bool {
        switch self {
        case .requesting, .waiting: return true
        default: return false
        }
    }
}

@MainActor
final class DevicePairingFlow: ObservableObject {
    @Published private(set) var phase: DevicePairingPhase = .idle

    private struct Session {
        let id: String
        let pollToken: String
        let expiresAt: Date
    }

    private let client: DevicePairingClientProtocol
    private let saveToken: (Data) throws -> Void
    private let hasToken: () -> Bool
    private let sleep: (UInt64) async throws -> Void
    private let now: () -> Date
    private var session: Session?

    init(client: DevicePairingClientProtocol = DashboardClient(),
         saveToken: @escaping (Data) throws -> Void = {
             try KeychainStore().save($0, account: KeychainStore.dashboardTokenAccount)
         },
         hasToken: @escaping () -> Bool = {
             (try? KeychainStore().load(account: KeychainStore.dashboardTokenAccount)) != nil
         },
         sleep: @escaping (UInt64) async throws -> Void = { try await Task.sleep(nanoseconds: $0) },
         now: @escaping () -> Date = Date.init) {
        self.client = client
        self.saveToken = saveToken
        self.hasToken = hasToken
        self.sleep = sleep
        self.now = now
    }

    func start(deviceName: String, replaceExistingToken: Bool = false) async {
        guard !phase.isRunning else { return }
        guard replaceExistingToken || !hasToken() else {
            phase = .approved
            return
        }
        phase = .requesting
        session = nil
        do {
            let pairing = try await client.requestPairing(deviceName: deviceName)
            try Task.checkCancellation()
            guard pairing.expiresAt > now() else {
                phase = .expired
                return
            }
            session = Session(id: pairing.id, pollToken: pairing.pollToken, expiresAt: pairing.expiresAt)

            while let current = session {
                try Task.checkCancellation()
                guard current.expiresAt > now() else {
                    session = nil
                    phase = .expired
                    return
                }
                let result = try await client.pollPairing(id: current.id, pollToken: current.pollToken)
                switch result.state {
                case .pending:
                    if let expiresAt = result.expiresAt, expiresAt <= now() {
                        session = nil
                        phase = .expired
                        return
                    }
                    phase = .waiting(code: pairing.code, expiresAt: pairing.expiresAt)
                    try await sleep(2_000_000_000)
                case .approved:
                    guard let token = result.token, !token.isEmpty else {
                        session = nil
                        phase = .failed
                        return
                    }
                    try saveToken(Data(token.utf8))
                    NotificationCenter.default.post(name: PushRegistrar.pairingCompleted, object: nil)
                    session = nil
                    phase = .approved
                    return
                case .terminal:
                    session = nil
                    phase = .expired
                    return
                }
            }
        } catch is CancellationError {
            session = nil
            if phase != .approved { phase = .cancelled }
        } catch {
            session = nil
            phase = .failed
        }
    }

    func cancel() {
        session = nil
        if phase.isRunning { phase = .cancelled }
    }
}
