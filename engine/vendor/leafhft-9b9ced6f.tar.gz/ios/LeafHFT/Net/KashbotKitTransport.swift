import Foundation
import LeafAssistantCore

enum KashbotKitFlag {
    static let defaultsKey = "kashbot.assistant.kit_v1"

    static func enabled(fixtureMode: FixtureMode, defaults: UserDefaults = .standard) -> Bool {
        guard !fixtureMode.enabled else { return false }
        #if DEBUG
        return defaults.bool(forKey: defaultsKey)
        #else
        return false
        #endif
    }
}

struct KashbotKitPage {
    let nextAfter: Int
    let updates: [KashbotKitUpdate]
}

struct KashbotKitUpdate {
    enum Value {
        case stage(String)
        case answer(String)
        case tool(id: String, label: String, state: String)
        case finished(failed: String?)
    }

    let seq: Int
    let value: Value
}

/// Keeps Kit wire types at the network boundary of the existing transcript.
struct KashbotKitTransport: AssistantTransport, @unchecked Sendable {
    let client: MushyClient
    let identity: String

    func send(_ request: TransportRequest) async throws -> TransportResponse {
        let response = try await client.kitSend(method: request.method.rawValue, path: request.path,
            query: request.query.map { URLQueryItem(name: $0.name, value: $0.value) },
            body: request.body, identity: identity)
        return TransportResponse(status: response.status, body: response.body)
    }

    static func fits(_ text: String) -> Bool {
        (1...TurnRequestV1.maxTextLength).contains(text.utf16.count)
    }

    func startTurn(sessionId: String, text: String) async throws -> String {
        do {
            guard let session = UUID(uuidString: sessionId) else { throw MushyClientError.response }
            let event = try await AssistantClient(transport: self).sendTurn(
                sessionId: session.uuidString.lowercased(), TurnRequestV1(text: text))
            guard case .turn(let turn) = event, let id = UUID(uuidString: turn.turnId) else {
                throw MushyClientError.response
            }
            return id.uuidString.lowercased()
        } catch { throw Self.mapped(error) }
    }

    func turnEvents(turnId: String, after: Int, wait: Int) async throws -> KashbotKitPage {
        do {
            guard let id = UUID(uuidString: turnId), (0...8001).contains(after), (0...15).contains(wait) else {
                throw MushyClientError.response
            }
            let request = TransportRequest(method: .get, path: "/turns/" + id.uuidString.lowercased() + "/events",
                query: [.init(name: "after", value: String(after)), .init(name: "wait", value: String(wait))])
            let response = try await send(request)
            guard response.status == 200 else {
                if let error = try? AssistantDecoding.decode(ErrorV1.self, from: response.body) {
                    throw AssistantClientError.refused(status: response.status, reason: error.reason)
                }
                throw AssistantClientError.unexpectedStatus(response.status)
            }
            let page = try AssistantDecoding.decode(EventsPageV1.self, from: response.body)
            guard page.nextAfter >= after, page.nextAfter <= 8001,
                  page.events.allSatisfy({ ($0.seq ?? 0) <= page.nextAfter }) else {
                throw MushyClientError.response
            }
            // Validate the page before exposing any of its updates to the transcript.
            for event in page.events {
                switch event {
                case .turn(let turn):
                    guard UUID(uuidString: turn.turnId) == id else { throw MushyClientError.response }
                case .item(let item):
                    guard UUID(uuidString: item.item.turnId) == id else { throw MushyClientError.response }
                case .unknown: break
                }
            }
            var updates: [KashbotKitUpdate] = []
            for event in page.events.sorted(by: { ($0.seq ?? 0) < ($1.seq ?? 0) }) {
                guard let seq = event.seq, seq > after else { continue }
                switch event {
                case .turn(let turn):
                    switch turn.state {
                    case .queued: updates.append(.init(seq: seq, value: .stage("queued")))
                    case .running: updates.append(.init(seq: seq, value: .stage("thinking")))
                    case .done:
                        updates.append(.init(seq: seq, value: .finished(failed: nil)))
                        return KashbotKitPage(nextAfter: page.nextAfter, updates: updates)
                    case .failed, .expired, .stopped:
                        updates.append(.init(seq: seq, value: .finished(failed:
                            turn.reason?.text ?? "The assistant could not answer. Try again.")))
                        return KashbotKitPage(nextAfter: page.nextAfter, updates: updates)
                    case .unknown: break
                    }
                case .item(let event):
                    for block in event.item.blocks {
                        switch block {
                        case .text(let text) where event.item.itemId == turnId + ":answer":
                            updates.append(.init(seq: seq, value: .answer(text.text)))
                        case .tools(let block):
                            for tool in block.tools {
                                let state: String
                                switch tool.state {
                                case .running: state = "started"
                                case .done: state = "finished"
                                case .failed: state = "failed"
                                case .unknown: continue
                                }
                                updates.append(.init(seq: seq, value: .tool(id: tool.invocationId,
                                    label: tool.label, state: state)))
                            }
                        default: break
                        }
                    }
                case .unknown: break
                }
            }
            return KashbotKitPage(nextAfter: page.nextAfter, updates: updates)
        } catch { throw Self.mapped(error) }
    }

    private static func mapped(_ error: Error) -> Error {
        if error is CancellationError || error is MushyClientError { return error }
        guard let error = error as? AssistantClientError else { return MushyClientError.response }
        switch error {
        case .refused(let status, let reason):
            switch reason.code {
            case .workerOffline: return MushyClientError.assistantUnavailable
            case .busy: return MushyClientError.assistantBusy
            case .unpaired: return MushyClientError.authentication
            case .refused where status == 403: return MushyClientError.notBound
            default: return MushyClientError.http(status)
            }
        case .unexpectedStatus(let status): return MushyClientError.http(status)
        case .offline, .timedOut: return MushyClientError.transport
        case .invalidIdentifier, .textOutOfBounds, .parameterOutOfRange: return MushyClientError.response
        }
    }
}
