import Foundation
import CryptoKit
import LeafHFTCore

struct AccountHistoryResponse: Decodable {
    struct Balance: Decodable {
        let capturedAt: Date
        let cashCents: Int
        /// Runner account history reports the positions mark, as Kalshi does.
        let portfolioValueCents: Int?
    }
    let balances: [Balance]
    let floorCents: Int
}

enum DashboardClientError: Error, Equatable {
    case unauthorized, forbidden, rateLimited, http(Int), transport, decoding, noCredential
    case refused(String)
}

/// Order-cap failures stay separate from the shared dashboard error contract.
enum OrderCapError: Error, Equatable {
    case conflict
    case rejected(String)
}

/// Preserve the server's opaque revision, including numeric revisions, on the next write.
enum OrderCapRevision: Codable, Equatable {
    case text(String), number(Int), unset

    init(from decoder: Decoder) throws {
        let value = try decoder.singleValueContainer()
        if value.decodeNil() { self = .unset }
        else if let number = try? value.decode(Int.self) { self = .number(number) }
        else { self = .text(try value.decode(String.self)) }
    }

    func encode(to encoder: Encoder) throws {
        var value = encoder.singleValueContainer()
        switch self {
        case let .text(text): try value.encode(text)
        case let .number(number): try value.encode(number)
        case .unset: try value.encodeNil()
        }
    }
}

struct OrderCapResponse: Decodable, Equatable {
    struct Range: Decodable, Equatable {
        let min: Double
        let max: Double
    }
    let maxOrderFraction: Double
    let revision: OrderCapRevision
    let source: String
    let range: Range

    func validated() throws -> Self {
        guard range.min.isFinite, range.max.isFinite, maxOrderFraction.isFinite,
              range.min >= 0.01, range.max <= 1, range.min < range.max,
              (range.min...range.max).contains(maxOrderFraction),
              ["default", "set"].contains(source) else { throw DashboardClientError.decoding }
        return self
    }
}

struct OrderCapState {
    var value: OrderCapResponse?
    var loading = false
    var saving = false
    var error: String?
    var identity: String?
}

private struct OrderCapRefusal: Decodable {
    let error: String?
    let message: String?
}

/// GET /api/leafhft/mobile/probes as the Monitor card reads it. A server without the route answers
/// 404 and `probes()` returns nil so the card hides; a body this build cannot read is `.notReported`.
enum ProbeBoardFetch: Equatable {
    case reported(ProbeBoardResponse)
    case notReported
}

enum PeopleCardsFetch {
    case success(PeopleCards.Response)
    case notAuthorized
    case unavailable(DashboardClientError)
}

protocol PeopleCardsLoading {
    func people() async -> PeopleCardsFetch
}

final class DashboardRedirectDelegate: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

final class DashboardClient: PeopleCardsLoading {
    static let baseURL = URL(string: "https://ops-dashboard-seven.vercel.app")!
    private let fixtureMode: FixtureMode
    private let session: URLSession
    private let token: () throws -> String
    private let sleep: (UInt64) async throws -> Void

    init(fixtureMode: FixtureMode = .current, protocolClasses: [AnyClass]? = nil,
         token: @escaping () throws -> String = {
             guard let data = try KeychainStore().load(account: KeychainStore.dashboardTokenAccount),
                   let value = String(data: data, encoding: .utf8), !value.isEmpty else {
                 throw DashboardClientError.noCredential
             }
             return value
         },
         sleep: @escaping (UInt64) async throws -> Void = { try await Task.sleep(nanoseconds: $0) }) {
        self.fixtureMode = fixtureMode
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 10
        configuration.timeoutIntervalForResource = 10
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.protocolClasses = fixtureMode.enabled ? [FixtureNetworkBlocker.self] : protocolClasses
        session = URLSession(configuration: configuration, delegate: DashboardRedirectDelegate(), delegateQueue: nil)
        self.token = token
        self.sleep = sleep
    }

    deinit { session.invalidateAndCancel() }

    func snapshotIdentity() throws -> String {
        let bearer = try token()
        guard !bearer.isEmpty else { throw DashboardClientError.noCredential }
        return SHA256.hash(data: Data(bearer.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    func booksWithBytes() async throws -> (value: MobileBooks, payload: Data, identity: String) {
        try await getWithBytes(path: "/api/leafhft/mobile/books")
    }

    func activityWithBytes() async throws -> (value: RunnerActivity, payload: Data, identity: String) {
        try await getWithBytes(path: "/api/leafhft/mobile/activity", query: [URLQueryItem(name: "limit", value: "50")])
    }

    func exitsWithBytes() async throws -> (value: ExitLedger, payload: Data, identity: String) {
        try await getWithBytes(path: "/api/leafhft/mobile/exits", query: [
            URLQueryItem(name: "days", value: "30"), URLQueryItem(name: "limit", value: "100")
        ])
    }

    func calibrationWithBytes() async throws -> (value: EntryCalibration, payload: Data, identity: String) {
        try await getWithBytes(path: "/api/leafhft/mobile/calibration", query: [URLQueryItem(name: "days", value: "30")])
    }

    static func decodeSnapshot<T: Decodable>(_ type: T.Type, from data: Data) throws -> T {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let text = try container.decode(String.self)
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = formatter.date(from: text) { return date }
            formatter.formatOptions = [.withInternetDateTime]
            guard let date = formatter.date(from: text) else {
                throw DecodingError.dataCorruptedError(in: container, debugDescription: "Invalid observation date")
            }
            return date
        }
        do { return try decoder.decode(T.self, from: data) }
        catch { throw DashboardClientError.decoding }
    }

    func account() async throws -> AccountHistoryResponse {
        try await get(path: "/api/leafhft/mobile/account", query: [URLQueryItem(name: "limit", value: "2000")])
    }

    func activity() async throws -> RunnerActivity {
        try await get(path: "/api/leafhft/mobile/activity", query: [URLQueryItem(name: "limit", value: "50")])
    }

    func exits() async throws -> ExitLedger {
        try await get(path: "/api/leafhft/mobile/exits", query: [
            URLQueryItem(name: "days", value: "30"), URLQueryItem(name: "limit", value: "100")
        ])
    }

    func calibration() async throws -> EntryCalibration {
        try await get(path: "/api/leafhft/mobile/calibration", query: [URLQueryItem(name: "days", value: "30")])
    }

    func attemptFunnel(hours: Int = 24) async throws -> AttemptFunnel {
        try await get(path: "/api/leafhft/mobile/attempt-funnel", query: [URLQueryItem(name: "hours", value: String(hours))])
    }

    func books() async throws -> MobileBooks { try await get(path: "/api/leafhft/mobile/books") }

    func bindingChallenge() async throws -> BindingChallenge {
        struct Empty: Encodable {}
        return try await kashbotPost(path: "/api/kashbot/bind/challenge", body: Empty())
    }

    func bind(_ request: BindingRequest) async throws -> KashbotBindResponse {
        try await kashbotPost(path: "/api/kashbot/bind", body: request)
    }

    func kashbotStatus() async throws -> KashbotStatus { try await get(path: "/api/kashbot/status") }

    func orderCap() async throws -> OrderCapResponse {
        let value: OrderCapResponse = try await get(path: "/api/kashbot/account/order-cap")
        return try value.validated()
    }

    func putOrderCap(maxOrderFraction: Double, expectedRevision: OrderCapRevision) async throws -> OrderCapRevision {
        struct Body: Encodable {
            let maxOrderFraction: Double
            let expectedRevision: OrderCapRevision
        }
        struct Receipt: Decodable { let revision: OrderCapRevision }
        let receipt: Receipt = try await kashbotPost(path: "/api/kashbot/account/order-cap",
            body: Body(maxOrderFraction: maxOrderFraction, expectedRevision: expectedRevision))
        return receipt.revision
    }

    func enrollmentKey() async throws -> AccountEnrollmentKey {
        try await get(path: "/api/kashbot/credentials")
    }

    func enrollAccount(_ request: AccountEnrollmentRequest) async throws -> KashbotStatus {
        try await kashbotPost(path: "/api/kashbot/credentials", body: request)
    }

    func startDryRun(clientRequestId: UUID) async throws -> KashbotRunnerResponse {
        try await runnerAction(.startDryRun, clientRequestId: clientRequestId)
    }

    func startLive(clientRequestId: UUID) async throws -> KashbotRunnerResponse {
        try await runnerAction(.startLive, clientRequestId: clientRequestId)
    }

    func pauseTrading(clientRequestId: UUID) async throws -> KashbotRunnerResponse {
        try await runnerAction(.pause, clientRequestId: clientRequestId)
    }

    func revokeRunner(clientRequestId: UUID) async throws -> KashbotRunnerResponse {
        try await runnerAction(.revoke, clientRequestId: clientRequestId)
    }

    private func runnerAction(_ action: KashbotRunnerAction, clientRequestId: UUID) async throws -> KashbotRunnerResponse {
        try await kashbotPost(path: "/api/kashbot/runner",
            body: KashbotRunnerActionRequest(clientRequestId: clientRequestId, action: action))
    }

    /// Owner acknowledgements contain a control row id, not the parked lane's runner request.
    /// Completion is proved by execution generation readback, never by this receipt.
    func ownerRunnerAction(_ action: KashbotRunnerAction, clientRequestId: UUID,
                           presence: KashbotDomainPresence? = nil, expectGeneration: Int64? = nil) async throws {
        guard action == .pause || (action == .startLive && presence != nil && expectGeneration != nil) else {
            throw DashboardClientError.refused("owner_lane_parked")
        }
        struct Receipt: Decodable { let id: String? }
        let _: Receipt = try await kashbotPost(path: "/api/kashbot/runner",
            body: KashbotRunnerActionRequest(clientRequestId: clientRequestId, action: action,
                                            presence: presence, expectGeneration: expectGeneration), ownerControl: true)
    }

    static func ownerControlMessage(for error: Error) -> String? {
        switch error as? DashboardClientError {
        case .refused("presence_required"):
            return "Start requires Face ID with this phone's presence key. Nothing was resumed."
        case .refused("owner_lane_parked"):
            return "This phone controls the owner books. Its account lane is parked."
        case .refused("request_pending"):
            return "An owner request is already waiting. Check progress before trying again."
        default: return nil
        }
    }

    private struct RunnerRefusal: Decodable { let error: String }

    private func kashbotPost<Response: Decodable, Body: Encodable>(path: String, body: Body,
                                                                 ownerControl: Bool = false) async throws -> Response {
        try fixtureMode.requireLiveAccess()
        try Task.checkCancellation()
        var request = URLRequest(url: Self.baseURL.appendingPathComponent(path), timeoutInterval: 10)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        do {
            let bearer = try token()
            guard !bearer.isEmpty else { throw DashboardClientError.noCredential }
            request.setValue("Bearer " + bearer, forHTTPHeaderField: "Authorization")
        } catch { throw DashboardClientError.noCredential }
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        request.httpBody = try encoder.encode(body)
        guard (request.httpBody?.count ?? 0) <= 65_536 else { throw DashboardClientError.decoding }
        let data: Data
        let response: URLResponse
        do { (data, response) = try await session.data(for: request) }
        catch {
            if Task.isCancelled { throw CancellationError() }
            throw DashboardClientError.transport
        }
        guard let http = response as? HTTPURLResponse else { throw DashboardClientError.transport }
        if http.statusCode == 401 { throw DashboardClientError.unauthorized }
        if http.statusCode == 429 { throw DashboardClientError.rateLimited }
        if path == "/api/kashbot/account/order-cap" {
            if http.statusCode == 409 { throw OrderCapError.conflict }
            guard data.count <= 65_536 else { throw DashboardClientError.decoding }
            if http.statusCode == 400 || http.statusCode == 403 {
                let refusal = try? JSONDecoder().decode(OrderCapRefusal.self, from: data)
                throw OrderCapError.rejected(refusal?.message ?? refusal?.error ??
                    (http.statusCode == 403 ? "This is not your account." : "Value is outside the allowed range."))
            }
        }
        if http.statusCode == 403 { throw DashboardClientError.forbidden }
        if ownerControl, path == "/api/kashbot/runner", http.statusCode == 409, data.count <= 65_536 {
            if let refusal = try? JSONDecoder().decode(RunnerRefusal.self, from: data),
               ["presence_required", "owner_lane_parked", "request_pending"].contains(refusal.error) {
                throw DashboardClientError.refused(refusal.error)
            }
        }
        guard (200..<300).contains(http.statusCode) else { throw DashboardClientError.http(http.statusCode) }
        guard data.count <= 65_536 else { throw DashboardClientError.decoding }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = Self.iso8601DateStrategy
        do { return try decoder.decode(Response.self, from: data) }
        catch { throw DashboardClientError.decoding }
    }

    func engines() async throws -> EnginesResponse {
        try await get(path: "/api/leafhft/mobile/engines", headers: ["x-kashbot-engine-runtime": "1"])
    }

    func people() async -> PeopleCardsFetch {
        do {
            let response: PeopleCards.Response = try await get(path: "/api/leafhft/mobile/people")
            return .success(response)
        } catch DashboardClientError.forbidden {
            return .notAuthorized
        } catch let error as DashboardClientError {
            return .unavailable(error)
        } catch {
            return .unavailable(.transport)
        }
    }

    /// Device-authenticated like every mobile read. 404 is nil (route not deployed), an unreadable
    /// or oversized body is `.notReported`; auth, transport and rate-limit failures still throw.
    func probes() async throws -> ProbeBoardFetch? {
        do {
            let board: ProbeBoardResponse = try await get(path: "/api/leafhft/mobile/probes")
            return .reported(board)
        } catch DashboardClientError.http(404) { return nil }
        catch DashboardClientError.decoding { return .notReported }
    }

    func riskyEngines() async throws -> RiskyBatman.Response {
        try await get(path: "/api/leafhft/mobile/risky")
    }

    func requestShadow(engineId: String, enabled: Bool, set: [String: Double] = [:],
                       unset: [String] = [], clientRequestId: UUID = UUID(),
                       envelope: RiskEnvelope? = nil) async throws -> RiskyBatman.ShadowResponse {
        let body = try RiskyBatman.ShadowRequest(engineId: engineId, enabled: enabled, set: set, unset: unset,
                                               clientRequestId: clientRequestId, envelope: envelope)
        return try await kashbotPost(path: "/api/leafhft/mobile/control", body: body)
    }

    func engineLab() async throws -> EngineLab.Response {
        let response: EngineLab.Response = try await get(path: "/api/leafhft/mobile/engine-lab")
        do { return try response.validated() }
        catch { throw DashboardClientError.decoding }
    }

    func engineLabEvent(_ input: EngineLab.EventInput) async throws -> EngineLab.Event {
        let response: EngineLab.EventResponse = try await kashbotPost(path: "/api/leafhft/mobile/engine-lab", body: input)
        guard response.advisory, response.event.advisory,
              response.event.clientRequestId.lowercased() == input.clientRequestId.lowercased(),
              response.event.engineId == input.engineId, response.event.kind == input.kind,
              response.event.payload == input.payload else { throw DashboardClientError.decoding }
        return response.event
    }

    func engineHistory(range: EngineHistoryRange, engineId: String? = nil) async throws -> EngineHistoryResponse {
        var query = [URLQueryItem(name: "range", value: range.rawValue)]
        if let engineId { query.append(URLQueryItem(name: "engine_id", value: engineId)) }
        return try await get(path: "/api/leafhft/mobile/engine-history", query: query)
    }

    func requestPairing(deviceName: String) async throws -> DevicePairingRequest {
        try fixtureMode.requireLiveAccess()
        let normalized = deviceName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty, normalized.count <= 80 else { throw DashboardClientError.transport }
        struct Body: Encodable { let deviceName: String }
        let envelope: DevicePairingEnvelope = try await pairingRequest(method: "POST", query: [], body: Body(deviceName: normalized))
        return envelope.pairing
    }

    func pollPairing(id: String, pollToken: String) async throws -> DevicePairingPoll {
        try fixtureMode.requireLiveAccess()
        let envelope: DevicePairingPollEnvelope = try await pairingRequest(method: "GET", query: [
            URLQueryItem(name: "id", value: id),
            URLQueryItem(name: "poll_token", value: pollToken)
        ], body: Optional<Int>.none)
        return envelope.pairing
    }

    func controlRequests() async throws -> [ControlRequest] {
        struct Requests: Decodable { let requests: [ControlRequest] }
        let response: Requests = try await get(path: "/api/leafhft/mobile/control")
        return response.requests
    }

    func control(_ intent: ControlIntent, note: String?) async throws -> ControlResponse {
        try fixtureMode.requireLiveAccess()
        struct Body: Encodable {
            let host: String?
            let venue: String?
            let scope: ControlScope?
            let kind: ControlKind
            let value: ControlValue
            let note: String?
            let clientRequestId: String?
            let expectedRevision: String?
        }
        struct Refusal: Decodable {
            let error: String
            let retryAfterMs: Int?
            enum CodingKeys: String, CodingKey {
                case error
                case retryAfterMs = "retry_after_ms"
            }
        }
        try Task.checkCancellation()
        var controlRequest = URLRequest(url: Self.baseURL.appendingPathComponent("/api/leafhft/mobile/control"), timeoutInterval: 10)
        controlRequest.httpMethod = "POST"
        controlRequest.setValue("application/json", forHTTPHeaderField: "Accept")
        controlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        do { controlRequest.setValue("Bearer " + (try token()), forHTTPHeaderField: "Authorization") }
        catch { throw DashboardClientError.noCredential }
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        // Sorted keys make every kind's body byte-stable, so golden tests pin probe, halt and breaker exactly.
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        controlRequest.httpBody = try encoder.encode(Body(host: intent.host, venue: intent.venue, scope: intent.scope,
            kind: intent.kind, value: intent.value, note: note, clientRequestId: intent.clientRequestId,
            expectedRevision: intent.expectedRevision))
        let data: Data
        let response: URLResponse
        do { (data, response) = try await session.data(for: controlRequest) }
        catch { throw DashboardClientError.transport }
        guard let http = response as? HTTPURLResponse else { throw DashboardClientError.transport }
        if http.statusCode == 401 { throw DashboardClientError.unauthorized }
        if (400..<500).contains(http.statusCode),
           let refusal = try? JSONDecoder().decode(Refusal.self, from: data) {
            if http.statusCode == 429, let retryAfterMs = refusal.retryAfterMs {
                let minutes = retryAfterMs / 60_000 + (retryAfterMs % 60_000 > 0 ? 1 : 0)
                throw DashboardClientError.refused("\(refusal.error) (retry in \(minutes) min)")
            }
            throw DashboardClientError.refused(refusal.error)
        }
        if http.statusCode == 403 { throw DashboardClientError.forbidden }
        guard (200..<300).contains(http.statusCode) else { throw DashboardClientError.http(http.statusCode) }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        do { return try decoder.decode(ControlResponse.self, from: data) }
        catch { throw DashboardClientError.decoding }
    }

    private func get<T: Decodable>(path: String, query: [URLQueryItem] = [], headers: [String: String] = [:]) async throws -> T {
        let result: (value: T, payload: Data, identity: String) = try await getWithBytes(path: path, query: query, headers: headers)
        return result.value
    }

    private func getWithBytes<T: Decodable>(path: String, query: [URLQueryItem] = [], headers: [String: String] = [:]) async throws -> (value: T, payload: Data, identity: String) {
        try fixtureMode.requireLiveAccess()
        for attempt in 0...3 {
            try Task.checkCancellation()
            var components = URLComponents(url: Self.baseURL, resolvingAgainstBaseURL: false)!
            components.path = path
            components.queryItems = query.isEmpty ? nil : query
            guard let url = components.url else { throw DashboardClientError.transport }
            var request = URLRequest(url: url, timeoutInterval: 10)
            for (name, value) in headers { request.setValue(value, forHTTPHeaderField: name) }
            if path.hasPrefix("/api/kashbot/") || path.hasSuffix("/engine-lab") {
                request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
                request.setValue("no-cache, no-store", forHTTPHeaderField: "Cache-Control")
            }
            request.httpMethod = "GET"
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let identity: String
            do {
                let bearer = try token()
                request.setValue("Bearer " + bearer, forHTTPHeaderField: "Authorization")
                identity = SHA256.hash(data: Data(bearer.utf8)).map { String(format: "%02x", $0) }.joined()
            }
            catch { throw DashboardClientError.noCredential }
            let data: Data
            let response: URLResponse
            do { (data, response) = try await session.data(for: request) }
            catch {
                if Task.isCancelled { throw CancellationError() }
                throw DashboardClientError.transport
            }
            guard let http = response as? HTTPURLResponse else { throw DashboardClientError.transport }
            if http.statusCode == 429 {
                guard attempt < 3 else { throw DashboardClientError.rateLimited }
                try await sleep(UInt64(2 << attempt) * 1_000_000_000)
                continue
            }
            if http.statusCode == 401 { throw DashboardClientError.unauthorized }
            if path == "/api/kashbot/account/order-cap", http.statusCode == 400 || http.statusCode == 403,
               data.count <= 65_536 {
                let refusal = try? JSONDecoder().decode(OrderCapRefusal.self, from: data)
                throw OrderCapError.rejected(refusal?.message ?? refusal?.error ??
                    (http.statusCode == 403 ? "This is not your account." : "Value is outside the allowed range."))
            }
            if http.statusCode == 403 { throw DashboardClientError.forbidden }
            guard (200..<300).contains(http.statusCode) else { throw DashboardClientError.http(http.statusCode) }
            guard !path.hasPrefix("/api/kashbot/") || data.count <= 65_536 else { throw DashboardClientError.decoding }
            guard !path.hasSuffix("/engine-lab") || data.count <= 1_048_576 else { throw DashboardClientError.decoding }
            guard !path.hasSuffix("/probes") || data.count <= 262_144 else { throw DashboardClientError.decoding }
            return (try Self.decodeSnapshot(T.self, from: data), data, identity)
        }
        throw DashboardClientError.rateLimited
    }

    private func pairingRequest<Response: Decodable, Body: Encodable>(method: String,
                                                                       query: [URLQueryItem],
                                                                       body: Body?) async throws -> Response {
        try Task.checkCancellation()
        var components = URLComponents(url: Self.baseURL, resolvingAgainstBaseURL: false)!
        components.path = "/api/leafhft/mobile/pair"
        components.queryItems = query.isEmpty ? nil : query
        guard let url = components.url else { throw DashboardClientError.transport }
        var request = URLRequest(url: url, timeoutInterval: 10)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let encoder = JSONEncoder()
            encoder.keyEncodingStrategy = .convertToSnakeCase
            request.httpBody = try encoder.encode(body)
        }
        let data: Data
        let response: URLResponse
        do { (data, response) = try await session.data(for: request) }
        catch {
            if Task.isCancelled { throw CancellationError() }
            throw DashboardClientError.transport
        }
        guard let http = response as? HTTPURLResponse else { throw DashboardClientError.transport }
        if http.statusCode == 429 { throw DashboardClientError.rateLimited }
        guard (200..<300).contains(http.statusCode) else { throw DashboardClientError.http(http.statusCode) }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = Self.iso8601DateStrategy
        do { return try decoder.decode(Response.self, from: data) }
        catch { throw DashboardClientError.decoding }
    }

    private static let iso8601DateStrategy: JSONDecoder.DateDecodingStrategy = .custom { decoder in
        let container = try decoder.singleValueContainer()
        let text = try container.decode(String.self)
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = formatter.date(from: text) { return date }
        formatter.formatOptions = [.withInternetDateTime]
        guard let date = formatter.date(from: text) else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Invalid pairing date")
        }
        return date
    }
}

extension DashboardClient: DevicePairingClientProtocol {}
