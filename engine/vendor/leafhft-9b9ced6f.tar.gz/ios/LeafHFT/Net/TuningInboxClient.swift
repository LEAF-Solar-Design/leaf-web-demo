import Foundation
import LeafHFTCore

/// The mobile tuning inbox routes (docs/contracts/tuning-inbox-v1.md, "Routes, authentication and bounds"):
///   GET  /api/leafhft/mobile/tuning-inbox?limit=N[&cursor=C]   summaries, no raw plan bytes
///   GET  /api/leafhft/mobile/tuning-inbox?id=<uuid>             one item with the exact plan_b64
///   POST /api/leafhft/mobile/tuning-inbox/<uuid>/decision        signed accept, 16 KiB body bound
protocol TuningInboxTransport {
    func list(cursor: String?) async throws -> TuningInboxPage
    func item(id: String) async throws -> TuningInboxDetail
    /// Sends frozen request bytes. Throws only when nothing left the phone; every reply is an outcome.
    func submitDecision(_ request: TuningDecisionRequest) async throws -> TuningDecisionOutcome
}

/// One accept request, frozen at signing time. A retry after an unknown outcome sends these exact
/// bytes under the same request_id, which the server replays idempotently.
struct TuningDecisionRequest: Equatable {
    let requestID: String
    let proposalID: String
    let planSeq: Int64
    let body: Data

    static func accept(requestID: String, proposalID: String, planSeq: Int64, version: Int64,
                       assertion: SignedTuningAssertion) throws -> TuningDecisionRequest {
        let decision = assertion.assertion.decision
        guard TuningSyntax.isUUID(requestID), TuningSyntax.isUUID(proposalID), decision.verb == "accept",
              decision.proposalID == proposalID, decision.planSeq == planSeq,
              (0...TuningInboxLimits.maxSafeInteger).contains(version) else {
            throw DecisionSignerError.invalidDecision("request")
        }
        let body = try TuningJSON.object([
            "request_id": .string(requestID), "proposal_id": .string(proposalID), "plan_seq": .int(planSeq),
            "version": .int(version), "verb": .string("accept"), "assertion_b64": .string(assertion.assertionB64),
        ]).canonicalBytes()
        guard body.count <= TuningInboxLimits.maxDecisionBodyBytes else { throw DecisionSignerError.assertionTooLarge }
        return TuningDecisionRequest(requestID: requestID, proposalID: proposalID, planSeq: planSeq, body: body)
    }
}

enum TuningDecisionOutcome: Equatable {
    /// Kashbot recorded the accept (or replayed a stored accept for this request_id).
    case accepted(code: String)
    /// A definite refusal that recorded no acceptance.
    case refused(status: Int, code: String)
    /// The request may have been recorded: transport loss, timeout, 5xx or an unreadable success.
    case unknown(reason: String)
}

final class TuningInboxClient: TuningInboxTransport {
    static let path = "/api/leafhft/mobile/tuning-inbox"
    private let fixtureMode: FixtureMode
    private let session: URLSession
    private let token: () throws -> String

    init(fixtureMode: FixtureMode = .current, protocolClasses: [AnyClass]? = nil,
         token: @escaping () throws -> String = {
             guard let data = try KeychainStore().load(account: KeychainStore.dashboardTokenAccount),
                   let value = String(data: data, encoding: .utf8), !value.isEmpty else {
                 throw DashboardClientError.noCredential
             }
             return value
         }) {
        self.fixtureMode = fixtureMode
        self.token = token
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 20
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.protocolClasses = fixtureMode.enabled ? [FixtureNetworkBlocker.self] : protocolClasses
        session = URLSession(configuration: configuration, delegate: DashboardRedirectDelegate(), delegateQueue: nil)
    }

    deinit { session.invalidateAndCancel() }

    func list(cursor: String?) async throws -> TuningInboxPage {
        try fixtureMode.requireLiveAccess()
        if cursor == nil { return try await TuningPendingCache.shared.list(client: self) }
        return try await listUncached(cursor: cursor)
    }

    func listUncached(cursor: String?) async throws -> TuningInboxPage {
        var query = [URLQueryItem(name: "limit", value: String(TuningInboxLimits.listPageSize))]
        if let cursor {
            guard TuningSyntax.isPrintable(cursor, maxBytes: 512) else { throw DashboardClientError.decoding }
            query.append(URLQueryItem(name: "cursor", value: cursor))
        }
        let data = try await read(query: query, limit: TuningInboxLimits.maxListResponseBytes)
        let wire: TuningInboxWire.ListResponse
        do { wire = try Self.decoder().decode(TuningInboxWire.ListResponse.self, from: data) }
        catch { throw DashboardClientError.decoding }
        guard wire.success, wire.items.count <= TuningInboxLimits.maxListPageSize,
              wire.nextCursor.map({ TuningSyntax.isPrintable($0, maxBytes: 512) }) ?? true else {
            throw DashboardClientError.decoding
        }
        let page = TuningInboxPage(items: try wire.items.map { try $0.validated() }, nextCursor: wire.nextCursor,
                                   pending: wire.pending)
        await TuningPendingCache.shared.record(page.pending)
        return page
    }

    func item(id: String) async throws -> TuningInboxDetail {
        guard TuningSyntax.isUUID(id) else { throw DashboardClientError.decoding }
        let data = try await read(query: [URLQueryItem(name: "id", value: id)], limit: TuningInboxLimits.maxItemResponseBytes)
        let wire: TuningInboxWire.ItemResponse
        do { wire = try Self.decoder().decode(TuningInboxWire.ItemResponse.self, from: data) }
        catch { throw DashboardClientError.decoding }
        guard wire.success else { throw DashboardClientError.decoding }
        let detail = try wire.item.validated()
        guard detail.summary.id == id else { throw DashboardClientError.decoding }
        return detail
    }

    func submitDecision(_ request: TuningDecisionRequest) async throws -> TuningDecisionOutcome {
        try fixtureMode.requireLiveAccess()
        guard TuningSyntax.isUUID(request.proposalID), TuningSyntax.isUUID(request.requestID),
              !request.body.isEmpty, request.body.count <= TuningInboxLimits.maxDecisionBodyBytes else {
            throw DecisionSignerError.invalidDecision("request")
        }
        var urlRequest = URLRequest(url: DashboardClient.baseURL.appendingPathComponent(Self.path + "/" + request.proposalID + "/decision"),
                                    cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 15)
        urlRequest.httpMethod = "POST"
        urlRequest.httpBody = request.body
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        try authorize(&urlRequest)
        let status: Int
        let data: Data
        do { (status, data) = try await perform(urlRequest, limit: TuningInboxLimits.maxDecisionResponseBytes) }
        catch {
            // The body may have reached Kashbot before the connection, the timeout or the size bound failed.
            return .unknown(reason: error is CancellationError ? "cancelled" : "transport")
        }
        return Self.outcome(status: status, data: data)
    }

    /// Classifies a decision reply. Only a definite answer clears the unknown state.
    static func outcome(status: Int, data: Data) -> TuningDecisionOutcome {
        let reply = try? decoder().decode(TuningInboxWire.DecisionResponse.self, from: data)
        let code = reply?.code.flatMap { TuningSyntax.isCode($0) ? $0 : nil }
        switch status {
        case 200..<300:
            guard let reply else { return .unknown(reason: "unreadable_reply") }
            return reply.success ? .accepted(code: code ?? "accepted") : .refused(status: status, code: code ?? "refused")
        case 408:
            return .unknown(reason: "http_408")
        case 400..<500:
            return .refused(status: status, code: code ?? "http_\(status)")
        default:
            return .unknown(reason: "http_\(status)")
        }
    }

    private static func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return decoder
    }

    private func authorize(_ request: inout URLRequest) throws {
        let bearer: String
        do { bearer = try token() } catch { throw DashboardClientError.noCredential }
        guard !bearer.isEmpty else { throw DashboardClientError.noCredential }
        request.setValue("Bearer " + bearer, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")
    }

    private func read(query: [URLQueryItem], limit: Int) async throws -> Data {
        try fixtureMode.requireLiveAccess()
        try Task.checkCancellation()
        guard var components = URLComponents(url: DashboardClient.baseURL.appendingPathComponent(Self.path),
                                             resolvingAgainstBaseURL: false) else { throw DashboardClientError.decoding }
        components.queryItems = query
        guard let url = components.url else { throw DashboardClientError.decoding }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 15)
        request.httpMethod = "GET"
        try authorize(&request)
        let status: Int
        let data: Data
        do { (status, data) = try await perform(request, limit: limit) }
        catch let error as DashboardClientError { throw error }
        catch {
            if Task.isCancelled || error is CancellationError { throw CancellationError() }
            throw DashboardClientError.transport
        }
        if status == 401 { throw DashboardClientError.unauthorized }
        if status == 403 { throw DashboardClientError.forbidden }
        if status == 429 { throw DashboardClientError.rateLimited }
        guard (200..<300).contains(status) else { throw DashboardClientError.http(status) }
        return data
    }

    /// Streams the body and stops at `limit` bytes, so an oversized reply never lands in memory whole.
    private func perform(_ request: URLRequest, limit: Int) async throws -> (Int, Data) {
        let (stream, response) = try await session.bytes(for: request)
        guard let http = response as? HTTPURLResponse else { throw DashboardClientError.transport }
        if http.expectedContentLength > Int64(limit) { throw DashboardClientError.decoding }
        var buffer: [UInt8] = []
        buffer.reserveCapacity(min(limit, 65_536))
        for try await byte in stream {
            guard buffer.count < limit else { throw DashboardClientError.decoding }
            buffer.append(byte)
        }
        return (http.statusCode, Data(buffer))
    }
}

/// Demo transport: the runtime-built sample plan, never the network, and no decision path at all.
final class TuningInboxFixtureTransport: TuningInboxTransport {
    private let now: () -> Date

    init(now: @escaping () -> Date = Date.init) { self.now = now }

    func list(cursor: String?) async throws -> TuningInboxPage {
        TuningInboxPage(items: cursor == nil ? [TuningInboxSample.detail(now: now()).summary] : [], nextCursor: nil)
    }

    func item(id: String) async throws -> TuningInboxDetail {
        guard id == TuningInboxSample.proposalID else { throw DashboardClientError.http(404) }
        return TuningInboxSample.detail(now: now())
    }

    func submitDecision(_ request: TuningDecisionRequest) async throws -> TuningDecisionOutcome {
        throw FixtureAccessError.disabled
    }
}
