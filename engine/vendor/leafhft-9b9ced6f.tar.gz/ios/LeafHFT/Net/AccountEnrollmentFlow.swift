import Foundation
import CryptoKit
import Security
import LeafHFTCore

enum AccountEnrollmentError: Error {
    case invalidKey, invalidCredential, scopeChanged, retryLimit, storage
}

enum AccountCredentialSealer {
    static func associatedData(tenantID: String, laneID: String) throws -> Data {
        guard UUID(uuidString: tenantID) != nil, UUID(uuidString: laneID) != nil else {
            throw AccountEnrollmentError.scopeChanged
        }
        return try JSONSerialization.data(withJSONObject: [
            "lane_id": laneID, "subaccount": 0, "tenant_id": tenantID,
            "venue": "kalshi", "version": 1
        ], options: [.sortedKeys])
    }

    // Security imports RSA public keys as PKCS#1, not SubjectPublicKeyInfo.
    private static func rsaPublicKey(_ spki: Data) throws -> Data {
        var offset = 0
        func element(_ tag: UInt8, limit: Int) throws -> Range<Int> {
            guard offset + 2 <= limit, spki[offset] == tag else { throw AccountEnrollmentError.invalidKey }
            offset += 1
            let first = Int(spki[offset])
            offset += 1
            var length = first
            if first >= 128 {
                let count = first & 0x7f
                guard (1...2).contains(count), offset + count <= limit, spki[offset] != 0 else {
                    throw AccountEnrollmentError.invalidKey
                }
                length = 0
                for _ in 0..<count { length = (length << 8) | Int(spki[offset]); offset += 1 }
                guard length >= 128 else { throw AccountEnrollmentError.invalidKey }
            }
            guard length <= limit - offset else { throw AccountEnrollmentError.invalidKey }
            let range = offset..<(offset + length)
            offset += length
            return range
        }
        let sequence = try element(0x30, limit: spki.count)
        guard offset == spki.count else { throw AccountEnrollmentError.invalidKey }
        offset = sequence.lowerBound
        let algorithm = try element(0x30, limit: sequence.upperBound)
        let rsaOID = Data([0x06, 0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01])
        let algorithmBytes = spki.subdata(in: algorithm)
        guard algorithmBytes == rsaOID || algorithmBytes == rsaOID + Data([0x05, 0x00]) else {
            throw AccountEnrollmentError.invalidKey
        }
        let bits = try element(0x03, limit: sequence.upperBound)
        guard offset == sequence.upperBound, bits.count > 1, spki[bits.lowerBound] == 0 else {
            throw AccountEnrollmentError.invalidKey
        }
        return spki.subdata(in: (bits.lowerBound + 1)..<bits.upperBound)
    }

    static func seal(keyID: String, privateDER: Data, runnerKey: AccountEnrollmentKey,
                     tenantID: String, laneID: String, now: Date = Date()) throws -> SealedAccountCredential {
        let aad = try associatedData(tenantID: tenantID, laneID: laneID)
        guard runnerKey.algorithm == "RSA-OAEP-256+A256GCM", runnerKey.expiresAt.map({ $0 > now }) ?? true,
              !runnerKey.enrollmentKeyId.isEmpty, runnerKey.enrollmentKeyId.utf8.count <= 128,
              let publicDER = Data(base64Encoded: runnerKey.publicKeyDer),
              publicDER.base64EncodedString() == runnerKey.publicKeyDer,
              (256...2048).contains(publicDER.count) else { throw AccountEnrollmentError.invalidKey }
        guard (256...16_384).contains(privateDER.count) else { throw AccountEnrollmentError.invalidCredential }
        _ = try KalshiSigner(pkcs1DER: privateDER)
        let normalized = try BindingChallenge.normalizedKeyID(keyID)
        let attributes: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
                                       kSecAttrKeyClass as String: kSecAttrKeyClassPublic]
        let rsaDER = try rsaPublicKey(publicDER)
        guard let publicKey = SecKeyCreateWithData(rsaDER as CFData, attributes as CFDictionary, nil),
              SecKeyGetBlockSize(publicKey) >= 256,
              SecKeyIsAlgorithmSupported(publicKey, .encrypt, .rsaEncryptionOAEPSHA256) else {
            throw AccountEnrollmentError.invalidKey
        }
        // Build JSON-escaped PEM bytes directly. No private-key String is created.
        var encodedDER = privateDER.base64EncodedData()
        defer { encodedDER.resetBytes(in: 0..<encodedDER.count) }
        var plaintext = Data(("{\"key_id\":\"" + normalized + "\",\"private_key_pem\":\"").utf8)
        defer { plaintext.resetBytes(in: 0..<plaintext.count) }
        let pemLabel = "RSA PRIVATE KEY"
        plaintext.append(contentsOf: ("-----BEGIN " + pemLabel + "-----\\n").utf8)
        for start in stride(from: 0, to: encodedDER.count, by: 64) {
            plaintext.append(contentsOf: encodedDER[start..<min(start + 64, encodedDER.count)])
            plaintext.append(contentsOf: "\\n".utf8)
        }
        plaintext.append(contentsOf: ("-----END RSA PRIVATE KEY-----\\n\"}").utf8)
        let symmetricKey = SymmetricKey(size: .bits256)
        let sealed = try AES.GCM.seal(plaintext, using: symmetricKey,
            authenticating: aad)
        var keyBytes = symmetricKey.withUnsafeBytes { Data($0) }
        defer { keyBytes.resetBytes(in: 0..<keyBytes.count) }
        guard let wrapped = SecKeyCreateEncryptedData(publicKey, .rsaEncryptionOAEPSHA256,
                                                      keyBytes as CFData, nil) else {
            throw AccountEnrollmentError.invalidKey
        }
        return SealedAccountCredential(enrollmentKeyId: runnerKey.enrollmentKeyId,
            wrappedKey: (wrapped as Data).base64EncodedString(),
            nonce: Data(sealed.nonce).base64EncodedString(),
            ciphertext: (sealed.ciphertext + sealed.tag).base64EncodedString())
    }
}

/// One submission per user attempt, three submissions total, with readback before
/// every retry. The durable record contains ciphertext and opaque metadata only.
@MainActor final class AccountEnrollmentFlow {
    private struct Pending: Codable {
        let request: AccountEnrollmentRequest
        var submissions: Int
        var firstAttemptAt: Date?
    }
    private let defaults: UserDefaults
    private let readStatus: () async throws -> KashbotStatus
    private let readKey: () async throws -> AccountEnrollmentKey
    private let submit: (AccountEnrollmentRequest) async throws -> KashbotStatus
    private let sleep: (UInt64) async throws -> Void
    private let now: () -> Date
    private(set) var running = false

    init(defaults: UserDefaults = .standard,
         readStatus: @escaping () async throws -> KashbotStatus,
         readKey: @escaping () async throws -> AccountEnrollmentKey,
         submit: @escaping (AccountEnrollmentRequest) async throws -> KashbotStatus,
         sleep: @escaping (UInt64) async throws -> Void = { try await Task.sleep(nanoseconds: $0) },
         now: @escaping () -> Date = Date.init) {
        self.defaults = defaults
        self.readStatus = readStatus
        self.readKey = readKey
        self.submit = submit
        self.sleep = sleep
        self.now = now
    }

    func enroll(keyID: String, privateDER: Data, scope: String, expectedTenantID: String? = nil,
                expectedLaneID: String? = nil,
                isCurrent: () -> Bool, progress: (String) -> Void) async throws -> KashbotStatus {
        guard !running else { throw AccountEnrollmentError.scopeChanged }
        running = true
        defer { running = false }
        func checkCurrent() throws {
            try Task.checkCancellation()
            guard isCurrent() else { throw AccountEnrollmentError.scopeChanged }
        }
        try checkCurrent()
        progress("Checking your account setup…")
        var status = try await readStatus()
        try checkCurrent()
        guard status.isBound, let tenant = status.tenant, let lane = status.lane else {
            throw AccountEnrollmentError.scopeChanged
        }
        _ = try AccountCredentialSealer.associatedData(tenantID: tenant.id, laneID: lane.id)
        guard (expectedTenantID == nil || expectedTenantID == tenant.id),
              (expectedLaneID == nil || expectedLaneID == lane.id) else {
            throw AccountEnrollmentError.scopeChanged
        }
        let digest = SHA256.hash(data: Data((scope + "\n" + tenant.id + "\n" + lane.id).utf8))
            .map { String(format: "%02x", $0) }.joined()
        let storageKey = "leafhft.enrollment.v2." + digest
        if status.needsEnrollment {
            var pending: Pending
            var restoredPending: Pending?
            if let data = defaults.data(forKey: storageKey) {
                guard let restored = try? JSONDecoder().decode(Pending.self, from: data),
                      (0...3).contains(restored.submissions) else { throw AccountEnrollmentError.storage }
                if restored.firstAttemptAt.map({ now().timeIntervalSince($0) > 24 * 60 * 60 }) ??
                    (restored.submissions >= 3) {
                    defaults.removeObject(forKey: storageKey)
                } else {
                    restoredPending = restored
                }
            }
            if let restored = restoredPending {
                pending = restored
            } else {
                progress("Protecting your key for your account runner…")
                let runnerKey = try await readKey()
                try checkCurrent()
                let requestID = UUID()
                let sealed = try AccountCredentialSealer.seal(keyID: keyID, privateDER: privateDER,
                    runnerKey: runnerKey, tenantID: tenant.id, laneID: lane.id)
                pending = Pending(request: AccountEnrollmentRequest(clientRequestId: requestID, credential: sealed),
                    submissions: 0, firstAttemptAt: now())
            }
            guard pending.submissions < 3 else { throw AccountEnrollmentError.retryLimit }
            if pending.firstAttemptAt == nil { pending.firstAttemptAt = now() }
            pending.submissions += 1
            let data = try JSONEncoder().encode(pending)
            defaults.set(data, forKey: storageKey)
            guard defaults.data(forKey: storageKey) == data else { throw AccountEnrollmentError.storage }
            try checkCurrent()
            progress("Sending your protected key…")
            do {
                status = try await submit(pending.request)
            } catch {
                try checkCurrent()
                // A lost response may have committed. Never submit again here.
                status = try await readStatus()
                try checkCurrent()
                guard status.isBound, status.tenant?.id == tenant.id, status.lane?.id == lane.id else {
                    throw AccountEnrollmentError.scopeChanged
                }
                if status.needsEnrollment {
                    if (error as? DashboardClientError) == .transport {
                        pending.submissions = max(0, pending.submissions - 1)
                        let data = try JSONEncoder().encode(pending)
                        defaults.set(data, forKey: storageKey)
                        guard defaults.data(forKey: storageKey) == data else { throw AccountEnrollmentError.storage }
                    }
                    throw error
                }
            }
        }
        try checkCurrent()
        guard status.isBound, status.tenant?.id == tenant.id, status.lane?.id == lane.id else {
            throw AccountEnrollmentError.scopeChanged
        }
        // Confirm the mutation with independent status readback, even after a 2xx.
        if !status.needsEnrollment { defaults.removeObject(forKey: storageKey) }
        for _ in 0..<6 {
            progress("Checking progress. You can leave this screen and check again later.")
            status = try await readStatus()
            try checkCurrent()
            guard status.isBound, status.tenant?.id == tenant.id, status.lane?.id == lane.id else {
                throw AccountEnrollmentError.scopeChanged
            }
            if !status.needsEnrollment { defaults.removeObject(forKey: storageKey) }
            if status.automatedTrading != .provisioning { return status }
            try await sleep(2_000_000_000)
            try checkCurrent()
        }
        return status
    }
}
