import Foundation
import LeafHFTCore

enum KalshiClientError: Error, Equatable {
    case unauthorized, rateLimited, http(Int), transport, decoding, noCredential
}

final class KalshiRedirectDelegate: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

final class KalshiClient {
    private let fixtureMode: FixtureMode
    private let session: URLSession
    private let credential: () throws -> (String, KalshiSigner)
    private let sleep: (UInt64) async throws -> Void

    init(fixtureMode: FixtureMode = .current, protocolClasses: [AnyClass]? = nil,
         credential: @escaping () throws -> (String, KalshiSigner) = {
             let store = KeychainStore()
             guard let idData = try store.load(account: KeychainStore.keyIDAccount),
                   let id = String(data: idData, encoding: .utf8), !id.isEmpty,
                   let der = try store.load(account: KeychainStore.keyDERAccount) else {
                 throw KalshiClientError.noCredential
             }
             return (id, try KalshiSigner(pkcs1DER: der))
         },
         sleep: @escaping (UInt64) async throws -> Void = { try await Task.sleep(nanoseconds: $0) }) {
        self.fixtureMode = fixtureMode
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 10
        configuration.timeoutIntervalForResource = 10
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.protocolClasses = fixtureMode.enabled ? [FixtureNetworkBlocker.self] : protocolClasses
        session = URLSession(configuration: configuration, delegate: KalshiRedirectDelegate(), delegateQueue: nil)
        self.credential = credential
        self.sleep = sleep
    }

    deinit { session.invalidateAndCancel() }

    func get<T: Decodable>(_ endpoint: KalshiGETEndpoint, as: T.Type) async throws -> T {
        try fixtureMode.requireLiveAccess()
        for attempt in 0...3 {
            try Task.checkCancellation()
            let id: String
            let signer: KalshiSigner
            do { (id, signer) = try credential() }
            catch { throw KalshiClientError.noCredential }
            var components = URLComponents(url: KalshiGETEndpoint.origin, resolvingAgainstBaseURL: false)!
            components.path = endpoint.path
            components.queryItems = endpoint.queryItems.isEmpty ? nil : endpoint.queryItems
            guard let url = components.url else { throw KalshiClientError.transport }
            var request = URLRequest(url: url, timeoutInterval: 10)
            request.httpMethod = "GET"
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let timestamp = Int64(Date().timeIntervalSince1970 * 1000)
            request.setValue(id, forHTTPHeaderField: "KALSHI-ACCESS-KEY")
            request.setValue(String(timestamp), forHTTPHeaderField: "KALSHI-ACCESS-TIMESTAMP")
            do {
                request.setValue(try signer.signature(timestampMs: timestamp, path: endpoint.path),
                                 forHTTPHeaderField: "KALSHI-ACCESS-SIGNATURE")
            } catch { throw KalshiClientError.noCredential }
            let data: Data
            let response: URLResponse
            do { (data, response) = try await session.data(for: request) }
            catch {
                if Task.isCancelled { throw CancellationError() }
                throw KalshiClientError.transport
            }
            guard let http = response as? HTTPURLResponse else { throw KalshiClientError.transport }
            if http.statusCode == 429 {
                guard attempt < 3 else { throw KalshiClientError.rateLimited }
                try await sleep(UInt64(2 << attempt) * 1_000_000_000)
                continue
            }
            if http.statusCode == 401 || http.statusCode == 403 { throw KalshiClientError.unauthorized }
            guard (200..<300).contains(http.statusCode) else { throw KalshiClientError.http(http.statusCode) }
            do { return try accountJSONDecoder().decode(T.self, from: data) }
            catch { throw KalshiClientError.decoding }
        }
        throw KalshiClientError.rateLimited
    }
}
