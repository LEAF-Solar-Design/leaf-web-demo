import Foundation
import Combine
import LeafHFTCore

/// The device's bound account only. This client has no write operations.
final class AutopilotClient {
    private let fixtureMode: FixtureMode
    private let session: URLSession
    private let token: () throws -> String

    init(fixtureMode: FixtureMode = .current, protocolClasses: [AnyClass]? = nil,
         token: @escaping () throws -> String = {
             guard let data = try KeychainStore().load(account: KeychainStore.dashboardTokenAccount),
                   let value = String(data: data, encoding: .utf8), !value.isEmpty else {
                 throw DashboardClientError.noCredential
             }
             return value
         }) {
        self.fixtureMode = fixtureMode
        self.token = token
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 10
        configuration.timeoutIntervalForResource = 10
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.protocolClasses = fixtureMode.enabled ? [FixtureNetworkBlocker.self] : protocolClasses
        session = URLSession(configuration: configuration, delegate: DashboardRedirectDelegate(), delegateQueue: nil)
    }

    deinit { session.invalidateAndCancel() }

    func fetch() async throws -> AutopilotResponse {
        try fixtureMode.requireLiveAccess()
        try Task.checkCancellation()
        var request = URLRequest(url: DashboardClient.baseURL.appendingPathComponent("/api/leafhft/mobile/autopilot"),
                                 cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 10)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")
        let bearer: String
        do { bearer = try token() } catch { throw DashboardClientError.noCredential }
        guard !bearer.isEmpty else { throw DashboardClientError.noCredential }
        request.setValue("Bearer " + bearer, forHTTPHeaderField: "Authorization")
        let data: Data
        let response: URLResponse
        do { (data, response) = try await session.data(for: request) }
        catch {
            if Task.isCancelled { throw CancellationError() }
            throw DashboardClientError.transport
        }
        guard let http = response as? HTTPURLResponse else { throw DashboardClientError.transport }
        if http.statusCode == 401 { throw DashboardClientError.unauthorized }
        if http.statusCode == 403 { throw DashboardClientError.forbidden }
        guard (200..<300).contains(http.statusCode) else { throw DashboardClientError.http(http.statusCode) }
        // The view is capped at 256 KiB; the envelope also contains the toggles document.
        guard data.count <= 524_288 else { throw DashboardClientError.decoding }
        do { return try AutopilotResponse.decode(data) }
        catch { throw DashboardClientError.decoding }
    }
}

/// Retains server-confirmed state through failures and serializes each account's writes.
@MainActor final class AutopilotSwitchState: ObservableObject {
    @Published private(set) var confirmed: AutopilotAccountSwitch
    @Published private(set) var pending = false
    @Published private(set) var error: String?
    private var retryValue: Bool?
    private let fixtureMode: FixtureMode
    private let write: (Bool, AutopilotScope) async throws -> AutopilotToggles

    init(confirmed: AutopilotAccountSwitch, fixtureMode: FixtureMode,
         write: @escaping (Bool, AutopilotScope) async throws -> AutopilotToggles = { enabled, scope in
             try await PushClient().toggle(enabled: enabled, scope: scope)
         }) {
        self.confirmed = confirmed
        self.fixtureMode = fixtureMode
        self.write = write
    }

    func setEnabled(_ enabled: Bool) async {
        guard !fixtureMode.enabled, !pending else { return }
        pending = true
        error = nil
        retryValue = enabled
        defer { pending = false }
        do {
            let document = try await write(enabled, confirmed.scope)
            confirmed = try confirmed.confirmed(by: document)
            retryValue = nil
        } catch {
            self.error = "Could not confirm the autotuner change. Last confirmed state is shown. Try again."
        }
    }

    func retry() async {
        guard let retryValue else { return }
        await setEnabled(retryValue)
    }

    func receive(_ entry: AutopilotAccountSwitch) {
        guard !pending, entry.id == confirmed.id else { return }
        confirmed = entry
    }
}
