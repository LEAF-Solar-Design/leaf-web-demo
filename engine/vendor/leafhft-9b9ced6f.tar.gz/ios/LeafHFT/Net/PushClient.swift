import Foundation
import LeafHFTCore

protocol PushClientProtocol {
    func register(apnsToken: String) async throws
    func registerCapabilities(planContractMax: Int, buildNumber: Int?) async throws -> Int
    func toggle(enabled: Bool, scope: AutopilotScope, eventID: String?) async throws -> AutopilotToggles
}

/// Device-authenticated push operations. No account selector is sent.
final class PushClient: PushClientProtocol {
    // The v2 reader (TuningInboxModels) ships in this build.
    static let maxPlanContract = 2
    private let fixtureMode: FixtureMode
    private let session: URLSession
    private let token: () throws -> String

    init(fixtureMode: FixtureMode = .current, protocolClasses: [AnyClass]? = nil,
         token: @escaping () throws -> String = {
             guard let data = try KeychainStore().load(account: KeychainStore.dashboardTokenAccount),
                   let value = String(data: data, encoding: .utf8), !value.isEmpty else {
                 throw DashboardClientError.noCredential
             }
             return value
         }) {
        self.fixtureMode = fixtureMode
        self.token = token
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 15
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.protocolClasses = fixtureMode.enabled ? [FixtureNetworkBlocker.self] : protocolClasses
        session = URLSession(configuration: configuration, delegate: DashboardRedirectDelegate(), delegateQueue: nil)
    }

    deinit { session.invalidateAndCancel() }

    func register(apnsToken: String) async throws {
        try fixtureMode.requireLiveAccess()
        var request = URLRequest(url: DashboardClient.baseURL.appendingPathComponent("/api/leafhft/mobile/push-token"),
                                 cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 15)
        request.httpMethod = "POST"
        request.httpBody = try JSONEncoder().encode(Registration(apns_token: apnsToken))
        let result: RegistrationResponse = try await perform(request)
        guard result.registered, result.delivered >= 0 else { throw DashboardClientError.decoding }
    }

    func registerCapabilities(planContractMax: Int, buildNumber: Int?) async throws -> Int {
        try fixtureMode.requireLiveAccess()
        guard (1...2).contains(planContractMax),
              buildNumber.map({ (0...2_147_483_647).contains($0) }) ?? true else {
            throw DashboardClientError.decoding
        }
        var request = URLRequest(url: DashboardClient.baseURL.appendingPathComponent("/api/leafhft/mobile/capabilities"),
                                 cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 15)
        request.httpMethod = "POST"
        request.httpBody = try JSONEncoder().encode(Capabilities(plan_contract_max: planContractMax, build_number: buildNumber))
        let result: CapabilitiesResponse = try await perform(request)
        guard result.success, (1...2).contains(result.planContractMax) else { throw DashboardClientError.decoding }
        return result.planContractMax
    }

    func toggle(enabled: Bool, scope: AutopilotScope, eventID: String? = nil) async throws -> AutopilotToggles {
        try fixtureMode.requireLiveAccess()
        if let eventID, UUID(uuidString: eventID) == nil { throw DashboardClientError.decoding }
        var request = URLRequest(url: DashboardClient.baseURL.appendingPathComponent("/api/leafhft/mobile/autopilot/toggle"),
                                 cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 15)
        request.httpMethod = "POST"
        request.httpBody = try JSONEncoder().encode(Toggle(enabled: enabled, scope: scope, event_id: eventID))
        let result: AutopilotToggles = try await perform(request)
        guard result.schema == "leafhft.autopilot-toggles.v1" else { throw DashboardClientError.decoding }
        return result
    }

    func registerLiveActivityToken(kind: String, token: String, activityId: String?) async throws {
        try fixtureMode.requireLiveAccess()
        guard kind == "update" || kind == "start" else { throw DashboardClientError.decoding }
        var request = URLRequest(url: DashboardClient.baseURL.appendingPathComponent("/api/leafhft/mobile/live-activity-token"),
                                 cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 15)
        request.httpMethod = "POST"
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "kind": kind, "token": token, "activityId": activityId.map { $0 as Any } ?? NSNull()
        ])
        let result: LiveActivityRegistrationResponse = try await perform(request)
        guard result.registered else { throw DashboardClientError.decoding }
    }

    private struct LiveActivityRegistrationResponse: Decodable { let registered: Bool }
    private struct Registration: Encodable {
        let apns_token: String
        let environment = "production"
    }
    private struct RegistrationResponse: Decodable { let registered: Bool; let delivered: Int }
    private struct Capabilities: Encodable {
        let plan_contract_max: Int
        let build_number: Int?
    }
    private struct CapabilitiesResponse: Decodable { let success: Bool; let planContractMax: Int }
    private struct Toggle: Encodable {
        let enabled: Bool
        let scope: AutopilotScope
        let event_id: String?
    }

    private func perform<T: Decodable>(_ input: URLRequest) async throws -> T {
        try fixtureMode.requireLiveAccess()
        try Task.checkCancellation()
        var request = input
        let bearer: String
        do { bearer = try token() } catch { throw DashboardClientError.noCredential }
        guard !bearer.isEmpty else { throw DashboardClientError.noCredential }
        request.setValue("Bearer " + bearer, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")
        let data: Data
        let response: URLResponse
        do { (data, response) = try await session.data(for: request) }
        catch {
            if Task.isCancelled { throw CancellationError() }
            throw DashboardClientError.transport
        }
        guard let http = response as? HTTPURLResponse else { throw DashboardClientError.transport }
        if http.statusCode == 401 { throw DashboardClientError.unauthorized }
        if http.statusCode == 403 { throw DashboardClientError.forbidden }
        guard (200..<300).contains(http.statusCode) else { throw DashboardClientError.http(http.statusCode) }
        guard data.count <= 524_288 else { throw DashboardClientError.decoding }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        do { return try decoder.decode(T.self, from: data) }
        catch { throw DashboardClientError.decoding }
    }
}
