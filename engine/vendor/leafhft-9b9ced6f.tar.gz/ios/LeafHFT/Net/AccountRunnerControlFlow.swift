import Foundation
import LeafHFTCore

enum AccountRunnerControlError: Error, Equatable {
    case unavailable, scopeChanged, timedOut, failed
}

/// The exact compact, sorted JSON is both hashed for presence and sent unchanged to the runner.
struct OwnerDomainResumePlan {
    let bytes: Data
    let generation: Int64
    let resumeNonce: String
    let requestID: String

    init(execution: KashbotExecution, requestID: UUID, now: Date = Date()) throws {
        guard execution.capabilities?.ownerDomainControl == true,
              execution.capabilities?.resume == true, execution.pause?.state == "paused",
              execution.domain == "legacy-owner", execution.memberKey == "owner",
              let host = execution.host, TuningSyntax.isPrintable(host, maxBytes: 255), !host.isEmpty,
              let generation = execution.pause?.generation,
              (1...TuningInboxLimits.maxSafeInteger).contains(generation),
              let nonce = execution.pause?.resumeNonce, TuningSyntax.isNonce(nonce) else {
            throw AccountRunnerControlError.unavailable
        }
        self.generation = generation
        resumeNonce = nonce
        self.requestID = requestID.uuidString.lowercased()
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        let frozen = Date(timeIntervalSince1970: floor(now.timeIntervalSince1970))
        bytes = try TuningJSON.object([
            "kind": .string("domain-resume-v1"), "domain": .string("legacy-owner"),
            "member_key": .string("owner"), "expect_generation": .int(generation),
            "resume_nonce": .string(nonce), "request_id": .string(self.requestID), "host": .string(host),
            "frozen_at": .string(formatter.string(from: frozen)),
            "expires_at": .string(formatter.string(from: frozen.addingTimeInterval(600))),
        ]).canonicalBytes()
    }

    func decision(account: String, issuedAtMs: Int64) -> TuningDecision {
        TuningDecision(verb: "accept", proposalID: requestID, planSeq: generation,
                       planSHA256: TuningSyntax.sha256Hex(bytes), runnerNonce: resumeNonce,
                       account: account, issuedAtMs: issuedAtMs)
    }
}

extension DecisionSigner {
    func signDomainResume(plan: OwnerDomainResumePlan, account: String,
                          issuedAtMs: Int64) async throws -> KashbotDomainPresence {
        let decision = plan.decision(account: account, issuedAtMs: issuedAtMs)
        let message = try decision.messageBytes()
        let spki = try key.publicKeySPKI()
        _ = try PresenceSPKI.publicKey(spki: spki)
        let signature = try await key.signMessage(message, reason: "Resume new entries on the owner books")
        let signed = try Self.assemble(decision: decision, message: message, spki: spki, signatureDER: signature)
        guard signed.canonicalJSON.count <= 8_192, plan.bytes.count <= 16_384 else {
            throw DecisionSignerError.assertionTooLarge
        }
        return KashbotDomainPresence(assertion: String(decoding: signed.canonicalJSON, as: UTF8.self),
                                     plan: String(decoding: plan.bytes, as: UTF8.self))
    }
}

/// A user attempt sends one command. An ambiguous reply only permits status reads.
@MainActor final class AccountRunnerControlFlow {
    private let readStatus: () async throws -> KashbotStatus
    private let submit: (KashbotRunnerAction, UUID) async throws -> Void
    private let submitOwner: ((KashbotRunnerAction, UUID, KashbotExecution) async throws -> Void)?
    private let observeStatus: (KashbotStatus) -> Void
    private let credentialIdentity: () -> String?
    private let sleep: (UInt64) async throws -> Void
    private let now: () -> TimeInterval
    private let defaults: UserDefaults
    private(set) var running = false

    init(readStatus: @escaping () async throws -> KashbotStatus,
         submit: @escaping (KashbotRunnerAction, UUID) async throws -> Void,
         credentialIdentity: @escaping () -> String?,
         sleep: @escaping (UInt64) async throws -> Void = { try await Task.sleep(nanoseconds: $0) },
         now: @escaping () -> TimeInterval = { ProcessInfo.processInfo.systemUptime },
         defaults: UserDefaults = .standard,
         submitOwner: ((KashbotRunnerAction, UUID, KashbotExecution) async throws -> Void)? = nil,
         observeStatus: @escaping (KashbotStatus) -> Void = { _ in }) {
        self.readStatus = readStatus
        self.submit = submit
        self.submitOwner = submitOwner
        self.observeStatus = observeStatus
        self.credentialIdentity = credentialIdentity
        self.sleep = sleep
        self.now = now
        self.defaults = defaults
    }

    func perform(_ action: KashbotRunnerAction, expectedTenantID: String,
                 expectedLaneID: String) async throws -> KashbotStatus {
        guard !running else { throw AccountRunnerControlError.unavailable }
        running = true
        defer { running = false }
        guard let identity = credentialIdentity(), !identity.isEmpty else {
            throw AccountRunnerControlError.scopeChanged
        }
        func checkCurrent() throws {
            try Task.checkCancellation()
            guard credentialIdentity() == identity else { throw AccountRunnerControlError.scopeChanged }
        }
        var expectedOwner: Bool?
        var expectedExecution: KashbotExecution?
        func checkScope(_ status: KashbotStatus) throws {
            try checkCurrent()
            guard status.isBound, status.tenant?.id == expectedTenantID,
                  status.lane?.id == expectedLaneID else { throw AccountRunnerControlError.scopeChanged }
            if let expectedOwner {
                guard status.isOwnerExecution == expectedOwner else { throw AccountRunnerControlError.scopeChanged }
                if expectedOwner {
                    guard status.execution?.domain == expectedExecution?.domain,
                          status.execution?.memberKey == expectedExecution?.memberKey,
                          status.execution?.host == expectedExecution?.host else {
                        throw AccountRunnerControlError.scopeChanged
                    }
                }
            }
        }
        try checkCurrent()
        var fresh = try await readStatus()
        try checkScope(fresh)
        expectedOwner = fresh.isOwnerExecution
        expectedExecution = fresh.isOwnerExecution ? fresh.execution : nil
        observeStatus(fresh)
        if fresh.isOwnerExecution, action == .startDryRun || action == .revoke {
            throw AccountRunnerControlError.unavailable
        }
        if fresh.isOwnerExecution, fresh.execution?.pendingRequest?.state == "requested" {
            throw DashboardClientError.refused("request_pending")
        }
        let dryRunKey = "leafhft.dry-run.v1." + expectedTenantID + "." + expectedLaneID
        let dryRunStampKey = dryRunKey + ".at"
        func clearDryRun() {
            defaults.removeObject(forKey: dryRunKey)
            defaults.removeObject(forKey: dryRunStampKey)
        }
        func dryRunComplete(_ status: KashbotStatus) -> Bool {
            // The runner acknowledges dry_run only after validating all zero-order receipts.
            status.hasActionableLane && status.automatedTrading == .dryRun &&
                status.lane?.liveEnabled == false && status.lane?.killRequested == false &&
                status.request?.state != "failed" && status.request?.action == .startDryRun &&
                (defaults.string(forKey: dryRunKey).map {
                    status.request?.clientRequestId.lowercased() == $0.lowercased()
                } ?? true)
        }
        if action == .startDryRun {
            // Enrollment can still be provisioning when its bounded readback ends.
            for _ in 0..<30 where fresh.automatedTrading == .provisioning && fresh.request?.action != .startDryRun {
                try await sleep(2_000_000_000)
                try checkCurrent()
                fresh = try await readStatus()
                try checkScope(fresh)
            }
            if dryRunComplete(fresh) {
                clearDryRun()
                return fresh
            }
            if let marker = defaults.string(forKey: dryRunKey),
               fresh.request?.clientRequestId.lowercased() != marker.lowercased(),
               fresh.automatedTrading == .ready,
               defaults.object(forKey: dryRunStampKey) == nil ||
                Date().timeIntervalSince1970 - defaults.double(forKey: dryRunStampKey) > 120 {
                // The server never stored that request, so a read-back can never complete.
                clearDryRun()
            }
        }
        let resumeDryRun = !fresh.isOwnerExecution && action == .startDryRun &&
            (defaults.string(forKey: dryRunKey) != nil || fresh.request?.action == .startDryRun)
        guard fresh.allows(action) || (resumeDryRun &&
            [.ready, .provisioning].contains(fresh.automatedTrading) &&
            fresh.hasActionableLane && fresh.lane?.liveEnabled == false) else {
            throw AccountRunnerControlError.unavailable
        }
        try checkCurrent()
        let requestID = UUID()
        let submissionExecution = expectedExecution
        let submit: (KashbotRunnerAction, UUID) async throws -> Void = { action, id in
            if let execution = submissionExecution {
                guard let ownerSubmit = self.submitOwner else { throw AccountRunnerControlError.unavailable }
                try await ownerSubmit(action, id, execution)
            } else {
                try await self.submit(action, id)
            }
            try checkCurrent()
        }
        if action == .startDryRun && !resumeDryRun {
            // Persist before sending. An interrupted or ambiguous attempt may only read back.
            defaults.set(requestID.uuidString, forKey: dryRunKey)
            defaults.set(Date().timeIntervalSince1970, forKey: dryRunStampKey)
            guard defaults.string(forKey: dryRunKey) == requestID.uuidString else {
                throw AccountRunnerControlError.unavailable
            }
        } else if action == .startDryRun && defaults.string(forKey: dryRunKey) == nil {
            guard let existing = fresh.request, existing.action == .startDryRun,
                  UUID(uuidString: existing.clientRequestId) != nil else {
                throw AccountRunnerControlError.unavailable
            }
            defaults.set(existing.clientRequestId, forKey: dryRunKey)
            defaults.set(Date().timeIntervalSince1970, forKey: dryRunStampKey)
            guard defaults.string(forKey: dryRunKey) == existing.clientRequestId else {
                throw AccountRunnerControlError.unavailable
            }
        }
        do { if !resumeDryRun { try await submit(action, requestID) } }
        catch {
            try checkCurrent()
            // A 2xx with an unreadable body may also have committed the command.
            guard let failure = error as? DashboardClientError,
                  failure == .transport || failure == .decoding else {
                if action == .startDryRun && !resumeDryRun { clearDryRun() }
                throw error
            }
        }
        try checkCurrent()
        let readbackSeconds: TimeInterval = fresh.isOwnerExecution ? 120 : 60
        let deadline = now() + readbackSeconds
        let readback = Task { @MainActor in
            for _ in 0..<Int(readbackSeconds / 2) {
                try checkCurrent()
                guard self.now() < deadline else { throw AccountRunnerControlError.timedOut }
                let status = try await self.readStatus()
                try checkScope(status)
                guard self.now() < deadline else { throw AccountRunnerControlError.timedOut }
                self.observeStatus(status)
                if let initial = submissionExecution {
                    guard let execution = status.execution else { throw AccountRunnerControlError.unavailable }
                    if execution.pendingRequest?.state == "rejected" { throw AccountRunnerControlError.failed }
                    let target = action == .pause ? "paused" : "resumed"
                    if let generation = execution.pause?.generation,
                       generation > (initial.pause?.generation ?? 0), execution.pause?.state == target,
                       execution.pendingRequest == nil || execution.pendingRequest?.state == "applied" {
                        return status
                    }
                    let remaining = min(2, deadline - self.now())
                    guard remaining > 0 else { throw AccountRunnerControlError.timedOut }
                    try await self.sleep(UInt64(remaining * 1_000_000_000))
                    continue
                }
                guard status.hasActionableLane else { throw AccountRunnerControlError.unavailable }
                guard status.request?.state != "failed" else { throw AccountRunnerControlError.failed }
                switch action {
                case .startDryRun where dryRunComplete(status):
                    return status
                case .startLive where status.automatedTrading == .live && status.lane?.liveEnabled == true && status.lane?.killRequested == false:
                    return status
                case .pause where status.automatedTrading == .paused && status.lane?.liveEnabled == false:
                    return status
                case .revoke where status.automatedTrading == .revoked && status.lane?.liveEnabled == false:
                    return status
                default: break
                }
                guard ![.failed, .revoked, .notConfigured, .credentialRequired, .error].contains(status.automatedTrading) else {
                    throw AccountRunnerControlError.failed
                }
                if action == .startLive && (status.lane?.killRequested == true || status.automatedTrading == .paused) {
                    throw AccountRunnerControlError.failed
                }
                let remaining = min(2, deadline - self.now())
                guard remaining > 0 else { throw AccountRunnerControlError.timedOut }
                try await self.sleep(UInt64(remaining * 1_000_000_000))
            }
            throw AccountRunnerControlError.timedOut
        }
        // Cancel an in-flight status request too, not just the delay between reads.
        let timeout = Task {
            try await Task.sleep(nanoseconds: UInt64(readbackSeconds * 1_000_000_000))
            readback.cancel()
        }
        defer { timeout.cancel(); readback.cancel() }
        let result: KashbotStatus
        do {
            result = try await withTaskCancellationHandler {
                try await readback.value
            } onCancel: {
                readback.cancel()
            }
        } catch is CancellationError {
            if submissionExecution != nil, !Task.isCancelled, self.now() >= deadline {
                throw AccountRunnerControlError.timedOut
            }
            throw CancellationError()
        }
        try checkScope(result)
        if action == .startDryRun || action == .pause || action == .revoke { clearDryRun() }
        return result
    }
}
