import Foundation
import CryptoKit
import LeafAssistantCore

enum MushyClientError: LocalizedError {
    case authentication, notBound, transport, response, http(Int), mismatch, assistantUnavailable, assistantBusy
    case refused(status: Int, code: String)
    var errorDescription: String? {
        switch self {
        case .authentication: return "Connect your dashboard in Settings to use Studio."
        case .notBound: return "Finish account setup in Settings to use the assistant."
        case .transport: return "Studio could not be reached. Your exact request is saved. Retry to recover it."
        case .response: return "Studio returned unsupported data. Your prior view and input are kept."
        case .http(let code): return "Studio request failed (\(code)). Refresh or retry the saved request."
        case .refused(let status, let code): return "Studio request refused (\(status)): \(code)."
        case .mismatch: return "Dashboard access changed. Refresh Studio before recovering the saved request."
        case .assistantUnavailable: return "The assistant is offline right now. It runs on the Leaf desktop, so try again in a minute."
        case .assistantBusy: return "The assistant is still answering your last question."
        }
    }
}

/// The dashboard bearer is the only credential this transport reads.
final class MushyClient {
    private struct AssistantFailure: Decodable { let error: String }
    static let root = "/api/leafhft/mobile/mushy"
    private let fixtureMode: FixtureMode
    private let token: () throws -> String
    private let session: URLSession
    private var preview = MushyClient.fixtureSnapshot
    private var previewReceipts: [String: Data] = [:]
    private var previewAssistantModes: [String: String] = [:]
    private var cardRequests: [String: String] = [:]
    private var cardRequestOrder: [String] = []
    private var previewInboxApproved: Set<String> = []
    private var previewInboxSeenThrough: String?

    init(fixtureMode: FixtureMode = .current, protocolClasses: [AnyClass]? = nil,
         token: @escaping () throws -> String = {
             guard let data = try KeychainStore().load(account: KeychainStore.dashboardTokenAccount),
                   let value = String(data: data, encoding: .utf8), !value.isEmpty else {
                 throw MushyClientError.authentication
             }
             return value
         }) {
        self.fixtureMode = fixtureMode
        self.token = token
        let config = URLSessionConfiguration.ephemeral
        config.urlCache = nil
        config.httpCookieStorage = nil
        config.httpShouldSetCookies = false
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.timeoutIntervalForRequest = 20
        config.timeoutIntervalForResource = 30
        config.protocolClasses = fixtureMode.enabled ? [FixtureNetworkBlocker.self] : protocolClasses
        session = URLSession(configuration: config, delegate: DashboardRedirectDelegate(), delegateQueue: nil)
    }
    deinit { session.invalidateAndCancel() }

    // In-memory race guard only. It is never a durable account-state key.
    func identity() throws -> String {
        if fixtureMode.enabled { return "fixture" }
        let bearer = try token()
        guard !bearer.isEmpty else { throw MushyClientError.authentication }
        return Self.digest(bearer)
    }
    private static func digest(_ bearer: String) -> String {
        SHA256.hash(data: Data(bearer.utf8)).map { String(format: "%02x", $0) }.joined()
    }
    func catalog(identity: String) async throws -> MushyCatalog { try await request(path: "/catalog", identity: identity) }
    func snapshot(identity: String) async throws -> MushySnapshot { try await request(path: "/state", identity: identity) }
    func createSession(_ pending: MushyPendingRequest, identity: String) async throws -> MushySessionReceipt {
        try await request(path: "/session", body: pending.body, identity: identity)
    }
    func turn(_ pending: MushyPendingRequest, identity: String) async throws -> MushyTurnReceipt {
        try await request(path: "/turn", body: pending.body, identity: identity)
    }
    func assistantTurn(_ body: AssistantTurnRequest, identity: String) async throws -> AssistantTurnReceipt {
        try await request(path: "/assistant/turn", body: MushyCoding.encoder().encode(body), identity: identity)
    }
    func assistantEvents(_ jobId: String, after: Int, wait: Int, identity: String) async throws -> AssistantEventsPage {
        try await request(path: "/assistant/jobs/" + component(jobId) + "/events",
            after: max(0, after), wait: min(15, max(0, wait)), identity: identity)
    }
    func job(_ id: String, identity: String) async throws -> MushyJob {
        try await request(path: "/jobs/" + component(id), identity: identity)
    }
    func events(_ id: String, after: Int, identity: String) async throws -> MushyEvents {
        try await request(path: "/jobs/" + component(id) + "/events", after: max(0, after), identity: identity)
    }
    func artifact(_ id: String, identity: String) async throws -> MushyArtifact {
        try await request(path: "/artifacts/" + component(id), identity: identity)
    }
    func slots(identity: String) async throws -> MushySlots { try await request(path: "/slots", identity: identity) }
    func updateSlot(_ pending: MushyPendingRequest, identity: String) async throws -> MushySlot {
        try await request(path: "/slots", body: pending.body, identity: identity)
    }
    func proposals(identity: String) async throws -> MushyProposals { try await request(path: "/proposals", identity: identity) }
    func propose(_ pending: MushyPendingRequest, identity: String) async throws -> MushyProposalReceipt {
        try await request(path: "/proposals", body: pending.body, identity: identity)
    }
    func draft(_ id: String, identity: String) async throws -> MushyConfigDraft {
        try await request(path: "/config-drafts/" + component(id), identity: identity)
    }
    func applyDraft(_ pending: MushyPendingRequest, identity: String) async throws -> MushyConfigReceipt {
        guard pending.kind == .config, pending.path.hasPrefix("/config-drafts/") else { throw MushyClientError.response }
        let id = String(pending.path.dropFirst("/config-drafts/".count))
        return try await request(path: "/config-drafts/" + component(id), body: pending.body, identity: identity)
    }
    private func component(_ id: String) throws -> String {
        guard UUID(uuidString: id) != nil else { throw MushyClientError.response }
        return id.lowercased()
    }

    func turnCards(turnId: String, identity: String) async throws -> AssistantCardsPage {
        let path = "/turns/" + (try component(turnId)) + "/cards"
        let response = try await kitSend(method: "GET", path: path, query: [], body: nil, identity: identity)
        try checkCardResponse(response)
        do { return try MushyCoding.decoder().decode(AssistantCardsPage.self, from: response.body) }
        catch { throw MushyClientError.response }
    }

    func fetchInbox(identity: String? = nil) async throws -> AssistantInboxPage {
        let identity = try identity ?? self.identity()
        let data: Data
        if fixtureMode.enabled {
            guard try self.identity() == identity else { throw MushyClientError.mismatch }
            data = try FixtureMode.assistantInboxData(approved: previewInboxApproved, seenThrough: previewInboxSeenThrough)
        } else {
            let response = try await kitSend(method: "GET", path: "/inbox", query: [], body: nil, identity: identity)
            try checkCardResponse(response)
            data = response.body
        }
        do { return try MushyCoding.decoder().decode(AssistantInboxPage.self, from: data) }
        catch { throw MushyClientError.response }
    }

    func fetchInboxCount(identity: String? = nil) async throws -> AssistantInboxCount {
        let identity = try identity ?? self.identity()
        let data: Data
        if fixtureMode.enabled {
            guard try self.identity() == identity else { throw MushyClientError.mismatch }
            data = try JSONSerialization.data(withJSONObject: ["schema": "kashbot.assistant.inbox-count.v1",
                "unread_count": previewInboxSeenThrough == nil ? 5 : 0])
        } else {
            let response = try await kitSend(method: "GET", path: "/inbox",
                query: [URLQueryItem(name: "count", value: "1")], body: nil, identity: identity)
            try checkCardResponse(response)
            data = response.body
        }
        do { return try MushyCoding.decoder().decode(AssistantInboxCount.self, from: data) }
        catch { throw MushyClientError.response }
    }

    func markInboxSeen(through: String, identity: String? = nil) async throws -> AssistantInboxSeen {
        guard let date = MushyCoding.date(through) else { throw MushyClientError.response }
        let identity = try identity ?? self.identity()
        if fixtureMode.enabled {
            guard try self.identity() == identity else { throw MushyClientError.mismatch }
            if previewInboxSeenThrough.flatMap(MushyCoding.date).map({ date > $0 }) ?? true {
                previewInboxSeenThrough = through
            }
            return AssistantInboxSeen(seenThrough: previewInboxSeenThrough ?? through)
        }
        let body = try JSONSerialization.data(withJSONObject: ["seen_through": through])
        let response = try await kitSend(method: "POST", path: "/inbox/seen", query: [], body: body, identity: identity)
        try checkCardResponse(response)
        do { return try MushyCoding.decoder().decode(AssistantInboxSeen.self, from: response.body) }
        catch { throw MushyClientError.response }
    }

    func acceptNomination(id: String, packetAsOf: String, identity: String) async throws -> AssistantNominationAccept {
        guard AssistantNomination.validId(id) else { throw MushyClientError.response }
        let body = try JSONSerialization.data(withJSONObject: ["packet_as_of": packetAsOf])
        let data: Data
        if fixtureMode.enabled {
            guard try self.identity() == identity else { throw MushyClientError.mismatch }
            data = try FixtureMode.assistantNominationAcceptData(id: id, packetAsOf: packetAsOf)
        } else {
            let response = try await kitSend(method: "POST", path: "/inbox/nominations/" + id + "/accept",
                query: [], body: body, identity: identity)
            if !(200..<300).contains(response.status) {
                if let refusal = try? JSONDecoder().decode(AssistantFailure.self, from: response.body),
                   !refusal.error.isEmpty, refusal.error.count <= 64,
                   refusal.error.allSatisfy({ "abcdefghijklmnopqrstuvwxyz_".contains($0) }) {
                    throw MushyClientError.refused(status: response.status, code: refusal.error)
                }
                throw MushyClientError.http(response.status)
            }
            data = response.body
        }
        do { return try MushyCoding.decoder().decode(AssistantNominationAccept.self, from: data) }
        catch { throw MushyClientError.response }
    }

    @MainActor func approveCard(cardId: String, cardDigest: String, identity: String) async throws {
        guard AssistantCard.validId(cardId), cardDigest.count == 64,
              cardDigest.allSatisfy({ "0123456789abcdefABCDEF".contains($0) }) else {
            throw MushyClientError.response
        }
        if fixtureMode.enabled {
            guard try self.identity() == identity else { throw MushyClientError.mismatch }
            let page = try await fetchInbox(identity: identity)
            guard page.cards.contains(where: { $0.id == cardId && $0.cardDigest == cardDigest && $0.state == .open }) else {
                throw MushyClientError.http(409)
            }
            previewInboxApproved.insert(cardId)
            return
        }
        // The chat and inbox share this client. For the same identity, card and digest, retries reuse the
        // in-memory request id until a terminal response, eviction from the 32-entry store, or app relaunch.
        // Thrown errors, 429 and 5xx retain it; 2xx, 400, 401, 403, 404, 409 and 410 forget it.
        let key = identity + "/" + cardId + "/" + cardDigest
        let requestId = cardRequests[key] ?? UUID().uuidString.lowercased()
        rememberCardRequest(key, requestId)
        let body = try JSONSerialization.data(withJSONObject: ["card_digest": cardDigest, "request_id": requestId])
        let response = try await kitSend(method: "POST", path: "/cards/" + cardId + "/approve",
            query: [], body: body, identity: identity)
        if Self.cardApprovalIsTerminal(response.status) { forgetCardRequest(key) }
        try checkCardResponse(response)
    }

    /// 2xx and the terminal refusals end an approval; 429 and 5xx are retryable and keep the request id.
    static func cardApprovalIsTerminal(_ status: Int) -> Bool {
        (200..<300).contains(status) || [400, 401, 403, 404, 409, 410].contains(status)
    }

    /// Bounded to 32 approvals; the oldest is evicted first.
    private func rememberCardRequest(_ key: String, _ requestId: String) {
        if cardRequests[key] == nil {
            cardRequestOrder.append(key)
            while cardRequestOrder.count > 32 { cardRequests[cardRequestOrder.removeFirst()] = nil }
        }
        cardRequests[key] = requestId
    }

    private func forgetCardRequest(_ key: String) {
        cardRequests[key] = nil
        cardRequestOrder.removeAll { $0 == key }
    }

    private func checkCardResponse(_ response: (status: Int, body: Data)) throws {
        guard !(200..<300).contains(response.status) else { return }
        if response.status == 409 || response.status == 410 { throw MushyClientError.http(response.status) }
        if let error = try? AssistantDecoding.decode(ErrorV1.self, from: response.body) {
            switch error.reason.code {
            case .workerOffline: throw MushyClientError.assistantUnavailable
            case .busy: throw MushyClientError.assistantBusy
            case .unpaired: throw MushyClientError.authentication
            case .refused where response.status == 403: throw MushyClientError.notBound
            default: break
            }
        }
        throw MushyClientError.http(response.status)
    }

    func kitSend(method: String, path: String, query: [URLQueryItem], body: Data?, identity: String) async throws -> (status: Int, body: Data) {
        try Task.checkCancellation()
        guard try self.identity() == identity else { throw MushyClientError.mismatch }
        try fixtureMode.requireLiveAccess()
        let bearer = try token()
        guard !bearer.isEmpty else { throw MushyClientError.authentication }
        guard Self.digest(bearer) == identity else { throw MushyClientError.mismatch }
        let parts = path.split(separator: "/", omittingEmptySubsequences: false)
        let inboxRoute = method == "GET" && path == "/inbox" && (query.isEmpty
            || (query.count == 1 && query[0].name == "count" && query[0].value == "1"))
        let seenRoute = method == "POST" && path == "/inbox/seen" && query.isEmpty
        let acceptRoute = method == "POST" && parts.count == 5 && parts[0].isEmpty
            && parts[1] == "inbox" && parts[2] == "nominations" && parts[4] == "accept"
            && AssistantNomination.validId(String(parts[3])) && query.isEmpty
        let uuidRoute = parts.count == 4 && parts[0].isEmpty && UUID(uuidString: String(parts[2])) != nil && (
              (method == "POST" && parts[1] == "sessions" && parts[3] == "turns")
                || (method == "GET" && parts[1] == "turns" && parts[3] == "events")
                || (method == "GET" && parts[1] == "turns" && parts[3] == "cards"))
        let approveRoute = parts.count == 4 && parts[0].isEmpty && method == "POST" && parts[1] == "cards" && parts[3] == "approve"
            && AssistantCard.validId(String(parts[2])) && query.isEmpty
        guard uuidRoute || approveRoute || inboxRoute || seenRoute || acceptRoute else {
            throw MushyClientError.response
        }
        var components = URLComponents(url: DashboardClient.baseURL.appendingPathComponent(
            "/api/kashbot/assistant/v1" + path), resolvingAgainstBaseURL: false)
        components?.queryItems = query.isEmpty ? nil : query
        guard let url = components?.url else { throw MushyClientError.response }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.httpBody = body
        request.setValue("Bearer " + bearer, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")
        if body != nil { request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        let data: Data
        let response: URLResponse
        do { (data, response) = try await session.data(for: request) }
        catch { if Task.isCancelled { throw CancellationError() }; throw MushyClientError.transport }
        try Task.checkCancellation()
        guard try self.identity() == identity else { throw MushyClientError.mismatch }
        guard let http = response as? HTTPURLResponse else { throw MushyClientError.transport }
        guard data.count <= 4_000_000 else { throw MushyClientError.response }
        return (http.statusCode, data)
    }

    private func request<T: Decodable>(path: String, body: Data? = nil, after: Int? = nil, wait: Int? = nil, identity: String) async throws -> T {
        try Task.checkCancellation()
        guard try self.identity() == identity else { throw MushyClientError.mismatch }
        if fixtureMode.enabled {
            if path.hasPrefix("/assistant/jobs/") {
                try await Task.sleep(nanoseconds: 250_000_000)
            }
            let data = try fixtureResponse(path: path, body: body, after: after)
            return try MushyCoding.decoder().decode(T.self, from: data)
        }
        try fixtureMode.requireLiveAccess()
        let bearer = try token()
        guard !bearer.isEmpty else { throw MushyClientError.authentication }
        guard Self.digest(bearer) == identity else { throw MushyClientError.mismatch }
        let endpoint = path == "/catalog" ? "/api/leafhft/mobile/engines" : Self.root + path
        var components = URLComponents(url: DashboardClient.baseURL.appendingPathComponent(endpoint),
            resolvingAgainstBaseURL: false)
        var items: [URLQueryItem] = []
        if path == "/catalog" {
            items.append(URLQueryItem(name: "__kashbot", value: "mushy-catalog"))
        } else if let after {
            items.append(URLQueryItem(name: "after", value: String(after)))
        }
        if let wait {
            items.append(URLQueryItem(name: "wait", value: String(min(15, max(0, wait)))))
        }
        components?.queryItems = items.isEmpty ? nil : items
        guard let url = components?.url else { throw MushyClientError.response }
        var request = URLRequest(url: url)
        request.httpMethod = body == nil ? "GET" : "POST"
        request.httpBody = body
        request.setValue("Bearer " + bearer, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")
        if path == "/catalog" { request.setValue("mushy-catalog", forHTTPHeaderField: "X-Kashbot-Route") }
        if body != nil { request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        let data: Data
        let response: URLResponse
        do { (data, response) = try await session.data(for: request) }
        catch { if Task.isCancelled { throw CancellationError() }; throw MushyClientError.transport }
        try Task.checkCancellation()
        guard try self.identity() == identity else { throw MushyClientError.mismatch }
        guard let http = response as? HTTPURLResponse else { throw MushyClientError.transport }
        if http.statusCode == 401 { throw MushyClientError.authentication }
        if http.statusCode == 403 { throw MushyClientError.notBound }
        if http.statusCode == 409,
           let failure = try? JSONDecoder().decode(AssistantFailure.self, from: data) {
            if failure.error == "ASSISTANT_UNAVAILABLE" { throw MushyClientError.assistantUnavailable }
            if failure.error == "ASSISTANT_BUSY" { throw MushyClientError.assistantBusy }
        }
        guard (200..<300).contains(http.statusCode) else { throw MushyClientError.http(http.statusCode) }
        guard data.count <= 4_000_000 else { throw MushyClientError.response }
        do { return try MushyCoding.decoder().decode(T.self, from: data) }
        catch { throw MushyClientError.response }
    }

    static let fixtureSessionId = "00000000-0000-4000-8000-000000000001"
    static let fixtureArtifactId = "00000000-0000-4000-8000-000000000002"
    // -LEAFHFT_ASSISTANT_V2 remains accepted as an ignored launch argument.
    static var fixtureCatalog: MushyCatalog {
        MushyCatalog(schemaVersion: 1,
            models: [.init(id: "preview-model", reasoningIds: ["disabled", "medium"])],
            defaultModelId: "preview-model", defaultReasoningId: "medium",
            sources: ["account.history": ["captured_at", "cash_cents", "portfolio_value_cents"]],
            sourceScopes: ["account.history": "account"],
            providerReadiness: .init(providerId: "preview", ready: true, status: "ready"),
            panelKinds: ["line", "table", "metric"],
            capabilities: ["ask", "telemetry.data", "telemetry.parse.fixed", "visualization.native",
                "account.publish", "global.propose", "platform.change.protected", "assistant.v2", "assistant.engine"],
            assistantReadiness: .init(ready: true, status: "ready", observedAt: nil))
    }
    static func fixtureArtifact(id: String = fixtureArtifactId, sessionId: String = fixtureSessionId) -> MushyArtifact {
        let digest = String(repeating: "a", count: 64)
        let fields = ["captured_at", "cash_cents", "portfolio_value_cents"]
        return MushyArtifact(id: id, version: 1, mediaType: "application/vnd.kashbot.artifact+json",
            digest: digest, artifactDigest: digest, producingJobId: id, sourceParser: "kashbot.telemetry.fixed.v1",
            sourceDigest: digest, lineage: .init(sessionId: sessionId, jobId: id, sourceCommit: "preview"),
            generationReceipt: .init(selectedSources: ["account.history"], sourceDigest: digest, upstreamMushyCommit: "preview"),
            artifact: ArtifactSpec(schemaVersion: 1, title: "Account preview", panels: [
                .init(kind: "line", title: "Account value", source: "account.history", fields: fields),
                .init(kind: "table", title: "Account history", source: "account.history", fields: fields),
                .init(kind: "metric", title: "Latest balance", source: "account.history", fields: Array(fields.dropFirst()))
            ]), telemetry: .init(capturedAt: "2026-09-19T12:00:00Z", data: ["account.history": [
                ["captured_at": .string("Monday"), "cash_cents": .number(10000), "portfolio_value_cents": .number(12000)],
                ["captured_at": .string("Tuesday"), "cash_cents": .number(10400), "portfolio_value_cents": .number(12400)]
            ]]), configDraft: nil)
    }
    static var fixtureSnapshot: MushySnapshot {
        MushySnapshot(sessions: [.init(id: fixtureSessionId, createdAt: "", updatedAt: "", messages: [])],
            jobs: [.init(id: fixtureArtifactId, status: "completed", createdAt: nil, completedAt: nil,
            artifactId: fixtureArtifactId, error: nil)], selections: .init(sessionId: fixtureSessionId,
                modelId: "preview-model", reasoningId: "medium", sources: ["account.history"]))
    }
    private func fixtureResponse(path: String, body: Data?, after: Int?) throws -> Data {
        let encoder = MushyCoding.encoder()
        let decoder = MushyCoding.decoder()
        let raw = body.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
        let requestId = raw?["request_id"] as? String
        if let requestId, let receipt = previewReceipts[requestId] { return receipt }
        let data: Data
        switch path {
        case "/catalog":
            if ProcessInfo.processInfo.arguments.contains("-MUSHY_DISABLED") { throw MushyClientError.http(404) }
            data = try encoder.encode(Self.fixtureCatalog)
        case "/state": data = try encoder.encode(preview)
        case "/slots" where body == nil: data = try encoder.encode(MushySlots(slots: preview.slots))
        case "/proposals" where body == nil: data = try encoder.encode(MushyProposals(proposals: preview.proposals))
        case "/session":
            let id = UUID().uuidString.lowercased()
            let value = MushySession(id: id, createdAt: "", updatedAt: "", messages: [])
            preview.sessions.append(value); preview.selections.sessionId = id
            data = try encoder.encode(MushySessionReceipt(sessionId: id, session: value))
        case "/assistant/turn":
            let turn = try decoder.decode(AssistantTurnRequest.self, from: body ?? Data())
            let id = UUID().uuidString.lowercased()
            previewAssistantModes[id] = turn.mode ?? "ask"
            if let index = preview.sessions.firstIndex(where: { $0.id == turn.sessionId }) {
                preview.sessions[index].messages.append(.init(role: "user", content: turn.input, jobId: id, createdAt: ""))
            }
            data = try encoder.encode(AssistantTurnReceipt(jobId: id, status: "pending"))
        case "/turn":
            let turn = try decoder.decode(MushyTurnRequest.self, from: body ?? Data())
            let id = UUID().uuidString.lowercased()
            if let index = preview.sessions.firstIndex(where: { $0.id == turn.sessionId }) {
                preview.sessions[index].messages.append(.init(role: "user", content: turn.input, jobId: id, createdAt: ""))
            }
            preview.selections = .init(sessionId: turn.sessionId, modelId: turn.modelId,
                reasoningId: turn.reasoningId, sources: turn.sources)
            preview.jobs.insert(.init(id: id, status: "completed", createdAt: nil, completedAt: nil, artifactId: id, error: nil), at: 0)
            data = try encoder.encode(MushyTurnReceipt(jobId: id, status: "pending"))
        case "/slots":
            let value = try decoder.decode(MushySlotRequest.self, from: body ?? Data())
            let prior = preview.slots[value.slot]
            guard value.expectedRevision == (prior?.revision ?? 0) else { throw MushyClientError.http(409) }
            var history = prior?.history ?? []
            if let prior { history.append(.init(artifactId: prior.artifactId, artifactVersion: prior.artifactVersion, digest: prior.digest)) }
            let slot = MushySlot(artifactId: value.artifactId, artifactVersion: 1, digest: String(repeating: "a", count: 64),
                revision: value.expectedRevision + 1, history: history)
            preview.slots[value.slot] = slot
            data = try encoder.encode(slot)
        case "/proposals":
            let value = try decoder.decode(MushyProposalRequest.self, from: body ?? Data())
            let proposal = MushyProposal(id: UUID().uuidString.lowercased(), artifactId: value.artifactId,
                digest: String(repeating: "a", count: 64), targetSlot: value.targetSlot, rationale: value.rationale, state: "proposed")
            preview.proposals.append(proposal)
            data = try encoder.encode(MushyProposalReceipt(proposal: proposal))
        default:
            let parts = path.split(separator: "/").map(String.init)
            if parts.count == 4, parts[0] == "assistant", parts[1] == "jobs", parts[3] == "events" {
                data = try Self.assistantFixtureEvents(jobId: parts[2], after: after ?? 0,
                    engineBuilding: previewAssistantModes[parts[2]] == "engine")
            } else if parts.first == "artifacts", let id = parts.last {
                let sessionId = preview.sessions.first { $0.messages.contains { $0.jobId == id } }?.id ?? Self.fixtureSessionId
                data = try encoder.encode(Self.fixtureArtifact(id: id, sessionId: sessionId))
            } else if parts.first == "jobs", parts.count == 3 {
                data = try encoder.encode(MushyEvents(jobId: parts[1], events: [], nextCursor: after ?? 0))
            } else if parts.first == "jobs", let id = parts.last, let job = preview.jobs.first(where: { $0.id == id }) {
                data = try encoder.encode(job)
            } else { throw MushyClientError.http(404) }
        }
        if let requestId { previewReceipts[requestId] = data }
        return data
    }

    private static func assistantFixtureEvents(jobId: String, after: Int, engineBuilding: Bool) throws -> Data {
        if engineBuilding {
            let fullText = "Built paper engine fixture-engine. Nothing trades."
            let events: [[String: Any]] = [
                ["seq": 1, "type": "status", "payload": ["stage": "thinking"]],
                ["seq": 2, "type": "text", "payload": ["delta": fullText]],
                ["seq": 3, "type": "view", "payload": ["title": "Paper engine fixture-engine", "panels": [
                    ["kind": "table", "title": "Paper engine", "columns": [
                        ["key": "engine", "label": "Engine", "format": "text"],
                        ["key": "mode", "label": "Mode", "format": "text"]
                    ], "rows": [["engine": "fixture-engine", "mode": "Paper only"]]]
                ]]],
                ["seq": 4, "type": "done", "payload": ["text": fullText]]
            ]
            let batch = Array(events.filter { ($0["seq"] as? Int ?? 0) > after }.prefix(3))
            let next = batch.last?["seq"] as? Int ?? after
            return try JSONSerialization.data(withJSONObject: ["job_id": jobId,
                "status": next >= 4 ? "completed" : "processing", "events": batch, "next": next])
        }
        let fullText = "You have **$238.81** in cash and $412.10 in total. Here is your account this week."
        let columns: [[String: Any]] = [
            ["key": "time", "label": "Date", "format": "time"],
            ["key": "total", "label": "Total", "format": "usd"],
            ["key": "cash", "label": "Cash", "format": "usd"]
        ]
        let totals = [40_100, 40_350, 40_620, 40_900, 41_210]
        let rows: [[String: Any]] = totals.enumerated().map { index, total in
            ["time": ISO8601DateFormatter().string(from: Date().addingTimeInterval(Double(index - 4) * 86_400)),
             "total": total, "cash": 23_881]
        }
        let events: [[String: Any]] = [
            ["seq": 1, "type": "status", "payload": ["stage": "queued"]],
            ["seq": 2, "type": "status", "payload": ["stage": "claimed"]],
            ["seq": 3, "type": "status", "payload": ["stage": "thinking"]],
            ["seq": 4, "type": "tool", "payload": ["id": "t1", "name": "account_summary", "label": "Checking your balance", "state": "started"]],
            ["seq": 5, "type": "tool", "payload": ["id": "t1", "name": "account_summary", "label": "Checking your balance", "state": "finished"]],
            ["seq": 6, "type": "status", "payload": ["stage": "answering"]],
            ["seq": 7, "type": "text", "payload": ["delta": "You have **$238.81**"]],
            ["seq": 8, "type": "text", "payload": ["delta": " in cash and $412.10 in total."]],
            ["seq": 9, "type": "text", "payload": ["delta": " Here is your account this week."]],
            ["seq": 10, "type": "view", "payload": ["title": "Account value this week", "panels": [
                ["kind": "line", "title": "Account value", "columns": columns, "rows": rows],
                ["kind": "metric", "title": "Current balance", "columns": [columns[2], columns[1]],
                 "rows": [["cash": 23_881, "total": 41_210]]]
            ]]],
            ["seq": 11, "type": "done", "payload": ["text": fullText]]
        ]
        let batch = Array(events.filter { ($0["seq"] as? Int ?? 0) > after }.prefix(3))
        let next = batch.last?["seq"] as? Int ?? after
        return try JSONSerialization.data(withJSONObject: ["job_id": jobId,
            "status": next >= 11 ? "completed" : "processing", "events": batch, "next": next])
    }
}
