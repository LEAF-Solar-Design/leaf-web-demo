import Foundation
import SQLite3
import LeafHFTCore

enum ObservationStoreError: Error { case open, statement, binding, step, invalidRow }

actor ObservationStore {
    private let database: OpaquePointer

    init(url: URL? = nil) throws {
        try FixtureMode.current.requireLiveAccess()
        let location: URL
        if let url { location = url }
        else {
            do {
                let directory = try FileManager.default.url(for: .applicationSupportDirectory,
                    in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("LeafHFT", isDirectory: true)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                location = directory.appendingPathComponent("observations.sqlite")
            } catch { throw ObservationStoreError.open }
        }
        var handle: OpaquePointer?
        guard sqlite3_open_v2(location.path, &handle, SQLITE_OPEN_CREATE | SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX, nil) == SQLITE_OK,
              let opened = handle else {
            if let handle { sqlite3_close(handle) }
            throw ObservationStoreError.open
        }
        do {
            try Self.execute(opened, "PRAGMA journal_mode=WAL")
            try Self.execute(opened, """
                CREATE TABLE IF NOT EXISTS observations (
                  captured_at_ms INTEGER NOT NULL, source TEXT NOT NULL,
                  exchange_index INTEGER NOT NULL, metric TEXT NOT NULL, cents INTEGER NOT NULL,
                  PRIMARY KEY(captured_at_ms, source, exchange_index, metric))
                """)
        } catch {
            sqlite3_close(opened)
            throw error
        }
        database = opened
    }

    deinit { sqlite3_close(database) }

    private static func execute(_ db: OpaquePointer, _ sql: String) throws {
        var statement: OpaquePointer?
        defer { sqlite3_finalize(statement) }
        guard sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK else { throw ObservationStoreError.statement }
        var result = sqlite3_step(statement)
        while result == SQLITE_ROW { result = sqlite3_step(statement) }
        guard result == SQLITE_DONE else { throw ObservationStoreError.step }
    }

    private func bind(_ text: String, to statement: OpaquePointer?, at index: Int32) throws {
        let transient = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
        guard text.withCString({ sqlite3_bind_text(statement, index, $0, -1, transient) }) == SQLITE_OK else {
            throw ObservationStoreError.binding
        }
    }

    private func bind(_ number: Int64, to statement: OpaquePointer?, at index: Int32) throws {
        guard sqlite3_bind_int64(statement, index, number) == SQLITE_OK else { throw ObservationStoreError.binding }
    }

    func append(_ observations: [AccountObservation]) throws {
        try Self.execute(database, "BEGIN IMMEDIATE")
        do {
            var statement: OpaquePointer?
            defer { sqlite3_finalize(statement) }
            guard sqlite3_prepare_v2(database,
                "INSERT OR IGNORE INTO observations VALUES (?, ?, ?, ?, ?)", -1, &statement, nil) == SQLITE_OK else {
                throw ObservationStoreError.statement
            }
            for item in observations {
                let milliseconds = item.capturedAt.timeIntervalSince1970 * 1000
                guard milliseconds.isFinite, milliseconds > Double(Int64.min), milliseconds < Double(Int64.max) else {
                    throw ObservationStoreError.invalidRow
                }
                for (metric, cents) in [("cash", item.cashCents), ("portfolioValue", item.portfolioValueCents)] {
                    guard let cents else { continue }
                    sqlite3_reset(statement)
                    sqlite3_clear_bindings(statement)
                    try bind(Int64(milliseconds), to: statement, at: 1)
                    try bind(item.source.rawValue, to: statement, at: 2)
                    // A nonnullable sentinel makes aggregate observations deduplicate in SQLite.
                    try bind(Int64(item.exchangeIndex ?? -1), to: statement, at: 3)
                    try bind(metric, to: statement, at: 4)
                    try bind(Int64(cents), to: statement, at: 5)
                    guard sqlite3_step(statement) == SQLITE_DONE else { throw ObservationStoreError.step }
                }
            }
            try prune()
            try Self.execute(database, "COMMIT")
        } catch {
            try? Self.execute(database, "ROLLBACK")
            throw error
        }
    }

    func append(_ observation: AccountObservation) throws { try append([observation]) }

    func load(metric: AccountMetric, source: ObservationSource, since: Date = .distantPast) throws -> [AccountObservation] {
        var statement: OpaquePointer?
        defer { sqlite3_finalize(statement) }
        guard sqlite3_prepare_v2(database, """
            SELECT captured_at_ms, exchange_index, cents FROM observations
            WHERE metric = ? AND source = ? AND captured_at_ms >= ? ORDER BY captured_at_ms ASC
            """, -1, &statement, nil) == SQLITE_OK else { throw ObservationStoreError.statement }
        try bind(metric == .cash ? "cash" : "portfolioValue", to: statement, at: 1)
        try bind(source.rawValue, to: statement, at: 2)
        try bind(Int64(since.timeIntervalSince1970 * 1000), to: statement, at: 3)
        var result: [AccountObservation] = []
        var status = sqlite3_step(statement)
        while status == SQLITE_ROW {
            let capturedAt = Date(timeIntervalSince1970: Double(sqlite3_column_int64(statement, 0)) / 1000)
            let exchange = Int(sqlite3_column_int64(statement, 1))
            let cents = Int(sqlite3_column_int64(statement, 2))
            result.append(AccountObservation(capturedAt: capturedAt, source: source, exchangeIndex: exchange == -1 ? nil : exchange,
                cashCents: metric == .cash ? cents : nil, portfolioValueCents: metric == .portfolioValue ? cents : nil))
            status = sqlite3_step(statement)
        }
        guard status == SQLITE_DONE else { throw ObservationStoreError.step }
        return result
    }

    func prune(olderThan age: TimeInterval = 90 * 86400, keepingAtMost limit: Int = 100_000,
               now: Date = Date()) throws {
        var statement: OpaquePointer?
        defer { sqlite3_finalize(statement) }
        guard sqlite3_prepare_v2(database, "DELETE FROM observations WHERE captured_at_ms < ?", -1, &statement, nil) == SQLITE_OK else {
            throw ObservationStoreError.statement
        }
        try bind(Int64(now.addingTimeInterval(-max(0, age)).timeIntervalSince1970 * 1000), to: statement, at: 1)
        guard sqlite3_step(statement) == SQLITE_DONE else { throw ObservationStoreError.step }
        var cap: OpaquePointer?
        defer { sqlite3_finalize(cap) }
        guard sqlite3_prepare_v2(database, """
            DELETE FROM observations WHERE rowid IN
            (SELECT rowid FROM observations ORDER BY captured_at_ms DESC, rowid DESC LIMIT -1 OFFSET ?)
            """, -1, &cap, nil) == SQLITE_OK else { throw ObservationStoreError.statement }
        try bind(Int64(max(0, limit)), to: cap, at: 1)
        guard sqlite3_step(cap) == SQLITE_DONE else { throw ObservationStoreError.step }
    }
}
