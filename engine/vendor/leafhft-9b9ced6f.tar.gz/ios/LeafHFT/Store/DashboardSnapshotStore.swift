import Foundation

/// Only display feeds belong here. All disk work is isolated from the main actor.
actor DashboardSnapshotStore {
    private struct Envelope: Codable {
        let schema: Int
        let feed: String
        let savedAt: Date
        let identity: String
        let payload: Data
    }

    private let directory: URL
    private var lastWritten: [DashboardFeed: (identity: String, payload: Data)] = [:]
    private(set) var writeCount = 0

    init(directory: URL? = nil) {
        self.directory = directory ?? FileManager.default.urls(for: .applicationSupportDirectory,
            in: .userDomainMask)[0].appendingPathComponent("DashboardSnapshots", isDirectory: true)
    }

    private func name(_ feed: DashboardFeed) -> String? {
        switch feed {
        case .books: return "books"
        case .activity: return "activity"
        case .exits: return "exits"
        case .calibration: return "calibration"
        default: return nil
        }
    }

    private func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let text = try container.decode(String.self)
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = formatter.date(from: text) { return date }
            formatter.formatOptions = [.withInternetDateTime]
            guard let date = formatter.date(from: text) else {
                throw DecodingError.dataCorruptedError(in: container, debugDescription: "Invalid snapshot date")
            }
            return date
        }
        return decoder
    }

    /// Before restoring a new credential scope, remove snapshots from any previous scope.
    func prepare(identity: String) {
        for feed in [DashboardFeed.books, .activity, .exits, .calibration] {
            guard let name = name(feed),
                  let bytes = try? Data(contentsOf: directory.appendingPathComponent(name + ".json")),
                  let envelope = try? decoder().decode(Envelope.self, from: bytes) else { continue }
            if envelope.identity != identity { clear(); return }
        }
    }

    func save(feed: DashboardFeed, payload: Data, identity: String, now: Date = Date()) {
        guard let name = name(feed), payload.count <= 1_048_576 else { return }
        if let last = lastWritten[feed], last.identity == identity, last.payload == payload { return }
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            var folder = directory
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            try folder.setResourceValues(values)
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .custom { date, encoder in
                let formatter = ISO8601DateFormatter()
                formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
                var container = encoder.singleValueContainer()
                try container.encode(formatter.string(from: date))
            }
            let bytes = try encoder.encode(Envelope(schema: 1, feed: name, savedAt: now,
                identity: identity, payload: payload))
            var file = directory.appendingPathComponent(name + ".json")
            try bytes.write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            try file.setResourceValues(values)
            lastWritten[feed] = (identity, payload)
            writeCount += 1
        } catch { /* A display snapshot must never interrupt a live read. */ }
    }

    func load(feed: DashboardFeed, identity: String, now: Date = Date()) -> (payload: Data, savedAt: Date)? {
        guard let name = name(feed) else { return nil }
        let file = directory.appendingPathComponent(name + ".json")
        guard let bytes = try? Data(contentsOf: file),
              let envelope = try? decoder().decode(Envelope.self, from: bytes),
              envelope.schema == 1, envelope.feed == name, envelope.identity == identity,
              envelope.payload.count <= 1_048_576,
              envelope.savedAt.timeIntervalSince(now) <= 60,
              now.timeIntervalSince(envelope.savedAt) <= 7 * 86400 else {
            remove(feed: feed)
            return nil
        }
        return (envelope.payload, envelope.savedAt)
    }

    func remove(feed: DashboardFeed) {
        guard let name = name(feed) else { return }
        try? FileManager.default.removeItem(at: directory.appendingPathComponent(name + ".json"))
        lastWritten[feed] = nil
    }

    func clear() {
        try? FileManager.default.removeItem(at: directory)
        lastWritten.removeAll()
    }
}
