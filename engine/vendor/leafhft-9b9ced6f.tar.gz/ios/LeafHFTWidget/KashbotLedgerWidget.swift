import SwiftUI
import WidgetKit

struct KashbotLedgerWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "KashbotLedgerWidget", provider: KashbotBoardProvider()) { entry in
            KashbotLedgerWidgetView(entry: entry)
                .containerBackground(KashbotBrand.ground, for: .widget)
        }
        .configurationDisplayName("Settlement ledger")
        .description("Recent symbols and cash profit or loss.")
        .supportedFamilies([.systemMedium, .systemLarge])
    }
}

struct KashbotLedgerWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: KashbotBoardEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "leaf.fill")
                Text("LEDGER").tracking(1.5)
                Spacer(minLength: 0)
                if let snapshot = entry.snapshot {
                    Text(KashbotBoardFormat.money(snapshot.state.totalCents, signed: false))
                        .font(.system(size: 20, weight: .semibold, design: .rounded))
                        .monospacedDigit()
                        .contentTransition(.numericText(value: Double(snapshot.state.totalCents)))
                        .animation(.default, value: snapshot.state.totalCents)
                        .foregroundStyle(KashbotBrand.ink)
                        .lineLimit(1)
                        .fixedSize()
                }
            }
            .font(.system(size: 13, weight: .heavy, design: .rounded))
            .foregroundStyle(KashbotBrand.leaf)
            if let snapshot = entry.snapshot, !snapshot.ledger.isEmpty {
                KashbotLedgerList(entries: snapshot.ledger, limit: family == .systemLarge ? 9 : 4)
            } else {
                Text("No settled results yet")
                    .font(.system(size: 13, design: .rounded))
                    .foregroundStyle(KashbotBrand.slate)
            }
            Spacer(minLength: 0)
        }
    }
}
