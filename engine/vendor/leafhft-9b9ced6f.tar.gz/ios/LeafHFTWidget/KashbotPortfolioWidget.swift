import SwiftUI
import WidgetKit

private let portfolioWidgetKind = "KashbotPortfolioWidget"

struct PortfolioEntry: TimelineEntry {
    let date: Date
    let snapshot: PortfolioWidgetSnapshot?
}

struct PortfolioProvider: TimelineProvider {
    func placeholder(in context: Context) -> PortfolioEntry {
        PortfolioEntry(date: Date(), snapshot: .preview)
    }

    func getSnapshot(in context: Context, completion: @escaping (PortfolioEntry) -> Void) {
        completion(PortfolioEntry(date: Date(), snapshot: context.isPreview ? .preview : PortfolioWidgetSnapshotStore.load()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<PortfolioEntry>) -> Void) {
        let now = Date()
        let entry = PortfolioEntry(date: now, snapshot: PortfolioWidgetSnapshotStore.load())
        completion(Timeline(entries: [entry], policy: .after(now.addingTimeInterval(15 * 60))))
    }
}

struct PortfolioWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: PortfolioEntry

    var body: some View {
        if family == .systemSmall {
            smallContent
                .foregroundStyle(KashbotBrand.ink)
                .fontDesign(.rounded)
                .monospacedDigit()
                .containerBackground(KashbotBrand.ground, for: .widget)
        } else if let snapshot = entry.snapshot {
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline) {
                    Label("PORTFOLIO", systemImage: "leaf.fill")
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(KashbotBrand.leaf)
                    Spacer()
                    (Text(snapshot.observedAt, style: .relative) + Text(" ago"))
                        .font(.caption2)
                        .foregroundStyle(KashbotBrand.inkMuted)
                }
                Text(currency(snapshot.totalCents))
                    .font(.system(size: family == .systemSmall ? 25 : 30, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.72)
                    .lineLimit(1)
                delta(snapshot.deltaIsCurrent(now: entry.date) ? snapshot.change15MinutesCents : nil)
                if family == .systemMedium {
                    Divider()
                    if snapshot.positions.isEmpty {
                        Text("No open positions")
                            .font(.caption)
                            .foregroundStyle(KashbotBrand.inkMuted)
                    } else {
                        ForEach(snapshot.positions) { position in
                            HStack(spacing: 8) {
                                Text(position.ticker)
                                    .font(.caption.weight(.semibold))
                                    .lineLimit(1)
                                Spacer()
                                Text(position.size + " contracts")
                                    .font(.caption2)
                                    .foregroundStyle(KashbotBrand.inkMuted)
                                Text(currency(position.exposureCents))
                                    .font(.caption.monospacedDigit())
                            }
                        }
                    }
                }
                Spacer(minLength: 0)
            }
            .foregroundStyle(KashbotBrand.ink)
            .fontDesign(.rounded)
            .monospacedDigit()
            .containerBackground(KashbotBrand.ground, for: .widget)
        } else {
            VStack(alignment: .leading, spacing: 8) {
                Label("Kashbot HFT", systemImage: "leaf.fill")
                    .font(.headline)
                    .foregroundStyle(KashbotBrand.leaf)
                Text("Open the app to load your portfolio.")
                    .font(.caption)
                    .foregroundStyle(KashbotBrand.inkMuted)
                Spacer()
            }
            .foregroundStyle(KashbotBrand.ink)
            .fontDesign(.rounded)
            .containerBackground(KashbotBrand.ground, for: .widget)
        }
    }

    // Keep the small family glanceable on the Home Screen, CarPlay, and StandBy.
    private var smallContent: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("PORTFOLIO", systemImage: "leaf.fill")
                .font(.headline)
                .foregroundStyle(KashbotBrand.leaf)
            if let snapshot = entry.snapshot {
                Text(currency(snapshot.totalCents))
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.7)
                    .lineLimit(1)
                delta(snapshot.deltaIsCurrent(now: entry.date) ? snapshot.change15MinutesCents : nil, font: .headline)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                (Text(snapshot.observedAt, style: .relative) + Text(" ago"))
                    .font(.subheadline)
                    .foregroundStyle(KashbotBrand.inkMuted)
            } else {
                Text("No portfolio data")
                    .font(.title2.bold())
                Text("Open Kashbot on iPhone when parked.")
                    .font(.headline)
                    .foregroundStyle(KashbotBrand.inkMuted)
            }
            Spacer(minLength: 0)
        }
    }

    @ViewBuilder private func delta(_ cents: Int?, font: Font = .caption) -> some View {
        if let cents {
            let positive = cents >= 0
            Label(KashbotBoardFormat.money(cents) + " in 15 min",
                  systemImage: positive ? "arrow.up.right" : "arrow.down.right")
                .font(font.weight(.semibold))
                .foregroundStyle(KashbotBrand.tone(cents))
        } else {
            Text("15 min change collecting")
                .font(font)
                .foregroundStyle(KashbotBrand.inkMuted)
        }
    }

    private func currency(_ cents: Int) -> String {
        let amount = Decimal(cents) / 100
        return amount.formatted(.currency(code: "USD").precision(.fractionLength(2)))
    }
}

struct KashbotPortfolioWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: portfolioWidgetKind, provider: PortfolioProvider()) { entry in
            PortfolioWidgetView(entry: entry)
        }
        .configurationDisplayName("Portfolio pulse")
        .description("See total value, 15 minute change, and your largest open positions.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

private extension PortfolioWidgetSnapshot {
    static let preview = PortfolioWidgetSnapshot(
        totalCents: 12_436,
        change15MinutesCents: 184,
        observedAt: Date(),
        positions: [
            .init(ticker: "KXBTC", size: "4", exposureCents: 312),
            .init(ticker: "KXFED", size: "2", exposureCents: 144)
        ]
    )
}
