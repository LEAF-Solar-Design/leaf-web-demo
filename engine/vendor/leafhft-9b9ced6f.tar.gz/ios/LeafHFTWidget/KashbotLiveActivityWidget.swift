import ActivityKit
import SwiftUI
import WidgetKit

struct KashbotLiveActivityWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: KashbotLiveAttributes.self) { context in
            VStack(spacing: 2) {
                if let text = context.state.approvalText {
                    Text(text).font(.caption).foregroundStyle(KashbotBrand.ink)
                }
                KashbotLockScreenBoard(state: context.state, isStale: context.isStale)
            }
                .frame(height: 160)
                .widgetURL(context.state.reviewURL)
                .activityBackgroundTint(.black)
                .activitySystemActionForegroundColor(KashbotBrand.leaf)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Text(KashbotBoardFormat.money(context.state.totalCents, signed: false))
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                        .contentTransition(.numericText(value: Double(context.state.totalCents)))
                        .animation(.default, value: context.state.totalCents)
                        .monospacedDigit()
                        .foregroundStyle(context.isStale ? KashbotBrand.slate : KashbotBrand.ink)
                        .lineLimit(1)
                        .fixedSize()
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Image(systemName: "leaf.fill").foregroundStyle(KashbotBrand.leaf)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 6) {
                        if let text = context.state.approvalText {
                            Text(text).font(.caption).foregroundStyle(KashbotBrand.ink)
                        }
                        KashbotBoardRows(state: context.state, limit: 3, isStale: context.isStale)
                        KashbotLedgerStrip(entries: context.state.ledger, isStale: context.isStale)
                    }
                }
            } compactLeading: {
                KashbotIslandCompactLeading(state: context.state, isStale: context.isStale)
            } compactTrailing: {
                KashbotIslandCompactTrailing(state: context.state, isStale: context.isStale)
            } minimal: {
                KashbotIslandMinimal(state: context.state)
            }
            .keylineTint(KashbotBrand.leaf)
            .widgetURL(context.state.reviewURL)
        }
    }
}
