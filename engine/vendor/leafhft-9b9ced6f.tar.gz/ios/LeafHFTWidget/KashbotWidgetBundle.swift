import SwiftUI
import WidgetKit

@main
struct KashbotWidgetBundle: WidgetBundle {
    var body: some Widget {
        KashbotPortfolioWidget()
        KashbotLockWidget()
        KashbotLedgerWidget()
        KashbotLiveActivityWidget()
    }
}
