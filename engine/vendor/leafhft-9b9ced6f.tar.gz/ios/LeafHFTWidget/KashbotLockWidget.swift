import SwiftUI
import WidgetKit

struct KashbotBoardEntry: TimelineEntry {
    let date: Date
    let snapshot: KashbotBoardSnapshot?
}

struct KashbotBoardProvider: TimelineProvider {
    func placeholder(in context: Context) -> KashbotBoardEntry {
        KashbotBoardEntry(date: Date(), snapshot: .sample)
    }

    func getSnapshot(in context: Context, completion: @escaping (KashbotBoardEntry) -> Void) {
        completion(KashbotBoardEntry(date: Date(), snapshot: context.isPreview ? .sample : KashbotBoardStore.load()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<KashbotBoardEntry>) -> Void) {
        let now = Date()
        completion(Timeline(entries: [KashbotBoardEntry(date: now, snapshot: KashbotBoardStore.load(now: now))],
                            policy: .after(now.addingTimeInterval(15 * 60))))
    }
}

struct KashbotLockWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "KashbotLockWidget", provider: KashbotBoardProvider()) { entry in
            KashbotLockWidgetView(entry: entry)
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("Lock screen board")
        .description("Portfolio value and live profit or loss at a glance.")
        .supportedFamilies([.accessoryRectangular, .accessoryInline, .accessoryCircular])
    }
}

struct KashbotLockWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: KashbotBoardEntry

    var body: some View {
        Group {
            if let snapshot = entry.snapshot {
                switch family {
                case .accessoryInline:
                    Text(snapshot.state.approvalText ?? ("\(snapshot.state.openCount) open · " + KashbotBoardFormat.money(openPnl(snapshot.state))))
                        .contentTransition(.numericText(value: Double(openPnl(snapshot.state))))
                        .animation(.default, value: openPnl(snapshot.state))
                        .fontWeight(.semibold)
                        .widgetAccentable()
                case .accessoryCircular:
                    if snapshot.state.openCount > 0 {
                        Text(KashbotBoardFormat.money(openPnl(snapshot.state), compact: true))
                            .font(.system(size: 15, weight: .semibold))
                            .minimumScaleFactor(0.5)
                            .contentTransition(.numericText(value: Double(openPnl(snapshot.state))))
                            .animation(.default, value: openPnl(snapshot.state))
                            .widgetAccentable()
                    } else {
                        Image(systemName: "leaf.fill")
                            .font(.title)
                            .widgetAccentable()
                    }
                default:
                    VStack(alignment: .leading, spacing: 2) {
                        if let text = snapshot.state.approvalText {
                            Text(text).font(.caption2).fontWeight(.semibold)
                        }
                        Text(KashbotBoardFormat.money(snapshot.state.totalCents, signed: false))
                            .contentTransition(.numericText(value: Double(snapshot.state.totalCents)))
                            .animation(.default, value: snapshot.state.totalCents)
                            .font(.system(.caption, design: .rounded, weight: .bold))
                            .widgetAccentable()
                        let rows = Array(snapshot.state.rows.prefix(2))
                        let symbols = KashbotSymbol.displayed(tickers: rows.map(\.ticker))
                        ForEach(Array(rows.enumerated()), id: \.offset) { index, row in
                            Text(symbols[index] + " " + (row.pnlCents.map { KashbotBoardFormat.money($0) } ?? "--"))
                                .contentTransition(.numericText(value: Double(row.pnlCents ?? 0)))
                                .animation(.default, value: row.pnlCents)
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                        }
                    }
                    .lineLimit(1)
                    .minimumScaleFactor(0.65)
                }
            } else {
                Text("Open Kashbot")
                    .font(.system(.caption, design: .rounded, weight: .semibold))
                    .minimumScaleFactor(0.7)
            }
        }
        .fontDesign(.rounded)
        .monospacedDigit()
        .widgetURL(entry.snapshot?.state.reviewURL)
    }

    private func openPnl(_ state: KashbotLiveAttributes.ContentState) -> Int {
        state.rows.reduce(0) { $0 + ($1.pnlCents ?? 0) }
    }
}
