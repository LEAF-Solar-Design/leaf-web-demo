# Leaf HFT iOS ladder: rung 5

Run from the committed repository on Windows:

```powershell
python ios/scripts/live_smoke.py --execute
```

To use the already-running LAN Mac and its installed simulator runtime:

```powershell
python ios/scripts/live_smoke.py --execute --host frogdev@10.0.0.212 --runtime 26.5
```

Host selection never starts a stopped machine. The receipt records the selected
host and runtime. Use `--evidence-root` for a separate diagnostic run so the
previous acceptance receipt remains available.

Without `--execute`, the command checks credential readiness only. If the named
`LEAFHFT_MOBILE_TOKEN` credential is absent, both forms write an `UNAVAILABLE`
receipt and exit nonzero before any Mac or live call. Configure the credential
through the existing credential owner and resolver, never through a command argument.

The command archives the exact committed `ios` source into a unique job on
`exzachly-aws-mac`. It builds an unsigned test host and creates a dedicated iPhone 16
simulator on iOS 26.2. It then pipes the bearer to the Mac helper's stdin once.
The bearer stays in Mac process memory and never enters the simulator, a file,
an environment variable, a command argument, a log, or an XCTest attachment.

The Mac relay binds loopback on an ephemeral port. It permits one attempt each
to the fixed production dashboard GET books and GET engines routes. It rejects
other paths, methods, redirects, oversized responses, and an echoed bearer. It
closes after two route attempts or a five minute deadline. Only its port enters
the test environment. Local HTTP permission is added to the disposable unsigned
simulator host product after building, leaving the production source plist intact.

The opt-in XCTest uses the production decoders and raw JSON checks. It requires
14 books with an eval object and a nonempty engine list whose rows all contain
bound_books arrays. It never invokes Kalshi or the control route. Both route checks
run even when books fail. Books failures report only decoded count, raw count, and
eval count, never response bodies. Ordinary unit test runs skip this test.
A rung 5 pass requires exit zero, its explicit completion
marker, and both accepted relay routes, so a skipped test cannot pass the rung.

Evidence goes to `C:/tmp/leafhft-ios/evidence/<UTC date>/rung-5.json`. The receipt
records the source SHA, job, simulator, duration, accepted-route count, and retained
xcresult. The command copies the xcresult locally when transport permits.
No performance budget was specified for this rung; the number is two accepted routes.

Preparation retries SSH transport failures before any token transfer. Live execution
has an atomic one-shot marker and is never retried automatically. After an unknown
outcome, inspect the existing job's result receipt before starting another command.
A failed prepare retains its directory and source archive. A failed live run retains
its receipt and result bundle when produced. The helper deletes only its dedicated
simulator. Compilation, simulator transport, and live acceptance must be confirmed
by the actual run; implementation alone provides no passing evidence.
