# Kashbot visual overhaul walk

This recipe reproduces the fixture renders of every restyled screen. It uses bundled sample data
only. No key, no dashboard token and no runner write is involved, and fixture mode blocks Bind,
Create and every engine configure request.

## What you need

- A Windows or Mac shell with `ssh mac-mini` working. The Mac mini is the only Mac build host.
- Xcode 27 with the iOS 27 simulator runtime and XcodeGen on the mini.
- A checkout of the branch under test. `scripts/mac_verify.py` copies the working tree to a
  per-checkout folder on the mini, so two checkouts never share a build folder.

## Run it

From the repository root, run the serial proof wrapper:

```sh
python ios/scripts/verify_ops_overhaul.py --out C:/tmp/kashbot-ops-proof
```

The wrapper syncs once, runs core and hosted unit tests plus the frozen four-screen fixture test,
then Account, Books, Engines, EngineHistory, EngineSettings, EngineLab and MushyStudio UI suites
in light and dark. It finishes with OpsLayoutUITests in both appearances at
`accessibility-extra-large`. All runs are serial. Regular runs use `LEAFHFT_SIM_NAME` (default
`iPhone 17`); accessibility runs use `iPhone 17e`. `--sim NAME` overrides both choices. `--dry-run`
prints the exact plan without syncing, running tests or replacing evidence.

Each run exports to `<out>/<class>-<appearance>[-ax]`. The wrapper stops on the first failed run
and names its log. When tests pass, each folder must contain a PNG; missing images are reported
as `evidence missing` with exit 3. The terminal table reports exit code, test count and PNG count.
`<out>/summary.json` records source SHA, simulator, appearance, text size and evidence paths per
run. Existing screenshot folders are retained under a `.previous-<timestamp>` suffix, so stale
images cannot satisfy a new run. Keep the logs, summary, attachment manifests and full images.

## What to look for

1. Account: four equal-height tiles, three status chips with a word and a glyph each, the equity
   chart with a range menu, positions, fills and runner sizing as cards.
2. Books: four count tiles, one full-width card per book with the condition chip, observation
   progress, edge line and the Yes and No pair. Detail hides the tab bar and Back returns to Books.
3. Engines: one card per engine with state chip, net P&L, win-rate bar and dials. Detail shows
   bound books, Configure and Performance. History shows daily bars coloured by sign.
4. Engine settings: grouped rows, help that expands in place, an account override with Use global
   value, a validation warning, the sticky action bar and the Review sheet listing old and new
   values. The assistant launcher is absent on this screen.
5. Settings: connection chips, the Appearance control and the Build section.
6. Every gain is green with an up arrow or a plus sign, every loss is red with a down arrow or a
   minus sign, pending is amber with a clock, unknown is slate with a question mark.
7. At accessibility-extra-large in both appearances, each bounded viewport stays within its
   declared height plus 2 pt and inside the window width. Wide tables scroll inside their box.
   Reach the last fixture row using only inner drags, with no movement of the containing page.
8. On Engine settings, Review and Discard stay clear of bounded content. The blocking reason is
   fully inside the sticky action bar. More, when offered for a clamped caption, exposes more
   rendered text without changing its meaning. SwiftUI may already expose the full accessibility
   label while collapsed, so an increase in rendered height also proves expansion.
9. Inspect the named `<Screen> layout <appearance> <content size>` screenshots at native size.
   Full screenshots must show navigation, tabs and the target viewport; cropping cannot hide
   clipping or overlap. Monitor's shadow card wraps the capped `monitor.shadowList` viewport.

## Known limits

- At accessibility text sizes XCUITest does not expose the SwiftUI stepper, so the settings test
  taps it by coordinate.
- The renders prove layout and colour on sample data. They prove nothing about a live connection,
  a live engine change or runner behaviour.
