# Leaf HFT physical iPhone rung

This is rung 4 of the Leaf HFT iOS test ladder. It proves a development build on a USB iPhone through the installed `cadwalk_core.mcps.ios_walk.physical_device` rail. It does not operate the live runner or submit engine controls.

Run the command on the Windows or Mac host with the phone attached. The signing Mac may be reached over SSH while the phone stays on Windows. Transfer the development IPA, WDA artifact and their immutable producer receipts to the USB host. Connect the intended iPhone, unlock it, and trust that computer. When other devices are attached, configure the canonical rail's server-owned `IOS_DEVICE_UDID` to the exact intended iPhone. Each device command stays pinned to that selection. Without a selector, only one USB device may be attached. Windows requires OpenSSL on PATH to verify and decode the embedded provisioning profile. Building and signing still happen on the Mac.

## Prerequisites

The installed rail must allow recipe `leafhft-read-only` and bundle `com.evan.leafhft`. Its `IOS_DEVICE_PROJECT_BUNDLES` configuration must map this exact resolved checkout to that bundle. Use the existing approved WDA runner and its artifact and producer receipt. Do not substitute another runner or change a lease held by another task.

Before holding the Mac or phone, post the fleet board notice required by the parent ladder. Expire the notice when finished. A development identity must already exist in the signing Mac's Keychain. Its SHA-1 belongs in the identity file. Supply an existing, unexpired development provisioning profile that includes that identity, covers `com.evan.leafhft`, and contains the attached device. The helper creates no certificate, changes no Keychain, and never enables provisioning updates. A missing development identity requires the operator's certificate decision.

The checkout must have the fixture UI and `settings.sourceSha` marker. `Info.plist` must define `LeafHFTSourceSHA` from `$(LEAFHFT_SOURCE_SHA)`. Commit the exact source before building.

## Build the development IPA

On the signing Mac, from the repository root:

```sh
bash ios/scripts/build_development_ipa.sh --project "$PWD" --identity-file /path/to/existing-identity-sha1.txt --profile /path/to/existing-development.mobileprovision --source-sha COMMIT_SHA --output /path/to/development-output
```

The helper builds without signing, embeds the supplied development profile, signs with the existing Apple Development identity, verifies the signature, and packages a USB-installable IPA. It refuses a distribution profile and writes an immutable IPA digest and producer receipt. This is not the App Store export IPA.

## One command for rung 4

Without artifact arguments, this records `UNAVAILABLE` and the physical handoff steps:

```sh
python ios/scripts/device_rung.py
```

With the prepared development IPA and existing WDA evidence:

```sh
python ios/scripts/device_rung.py --source-sha COMMIT_SHA --ipa /path/LeafHFT-development.ipa --ipa-receipt /path/LeafHFT-development.receipt.json --ipa-sha256 IPA_SHA256 --ipa-receipt-sha256 IPA_RECEIPT_SHA256 --wda-artifact /path/existing-wda-artifact.zip --wda-receipt /path/existing-wda-receipt.json --wda-sha256 WDA_SHA256 --wda-receipt-sha256 WDA_RECEIPT_SHA256 --wda-runner-bundle-id EXISTING_RUNNER.xctrunner
```

All four file digests are checked before installation. The rail runs status, bound install, install-status polling, WDA start, screenshot, allowlisted recipe, and WDA stop. Before the initial screenshot, the repository driver launches with `-LEAFHFT_FIXTURES 1` and verifies the visible fixture marker so an unknown live screen is not photographed.

The recipe checks the Account chart, fourteen Books and actual scroll movement, Engines bound books, and Settings. It enters no key, taps no control, and resets no permissions. It reads the installed source marker from WDA, compares that observed value to the requested SHA, and retains the raw source and screenshots with SHA-256 hashes. Copying an input SHA into the receipt is not installed-source proof.

The physical receipt is under this checkout's `_marathon/evidence`. The rung receipt defaults to `C:/tmp/leafhft-ios/evidence/<UTC date>/rung-4.json` on Windows, and `~/leafhft-ios/evidence/<UTC date>/rung-4.json` on the Mac. Copy the Mac receipt and evidence into the Windows ladder evidence directory after completion. `--evidence-root` selects another receipt root. The eight-minute budget includes installation and the walk. A missing device, missing rail, failed stage, or unperformed run is never a pass.

## Manual TestFlight build 1

The operator must finish internal-tester enrollment, install build 1 through the TestFlight app, and repeat the four-tab read-only walk by hand. No key is entered by automation. Record screenshot/layout/data differences and whether a source marker is present. Build 1 predates the fixture/source-marker test changes, so do not claim parity or source verification unless actually observed. The automated receipt records this manual comparison as `UNAVAILABLE` until the operator performs it.
