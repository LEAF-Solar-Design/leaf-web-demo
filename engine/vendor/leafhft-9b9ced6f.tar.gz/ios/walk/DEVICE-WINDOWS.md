# Leaf HFT rung 4 from Windows

For a phone attached to the Mac, run `python ios/scripts/test_device.py --config C:/path/device-config.json` from the committed Leaf HFT checkout. Missing configuration writes a rung 4 `UNAVAILABLE` receipt without SSH or device access.

The controller uses an existing SSH alias and trusted host key. The Mac must already have the exact committed source, installed physical rail, and server-owned bundle mapping for that exact checkout. Keep the lid open, attach and unlock the iPhone, and trust the computer. Coordinate the Mac and phone hold using the fleet notice described in `DEVICE.md`.

Prepare the development IPA once using the existing-identity helper in `DEVICE.md`. This Windows command consumes that source-bound IPA and never creates signing assets, changes a Keychain, configures bindings, or rebuilds. Rebuild through that helper when the source SHA changes. The identity fingerprint file and development profile stay on the signing Mac and are not controller inputs.

The configuration contains only the following nonsecret fields. All paths refer to existing files on the phone Mac. Replace the digest placeholders with the actual lowercase SHA-256 values from the producer. Do not put credentials, tokens, identity values, shell commands, or passwords in this file.

```json
{
  "host": "phone-mac",
  "remote_project": "/Users/operator/leaf-hft",
  "ipa": "/Users/operator/artifacts/LeafHFT-development.ipa",
  "ipa_receipt": "/Users/operator/artifacts/LeafHFT-development.receipt.json",
  "ipa_sha256": "IPA_SHA256",
  "ipa_receipt_sha256": "IPA_RECEIPT_SHA256",
  "wda_artifact": "/Users/operator/artifacts/existing-wda.zip",
  "wda_receipt": "/Users/operator/artifacts/existing-wda-receipt.json",
  "wda_sha256": "WDA_SHA256",
  "wda_receipt_sha256": "WDA_RECEIPT_SHA256",
  "wda_runner_bundle_id": "existing.runner.xctrunner"
}
```

The controller checks local tracked iOS and driver cleanliness, then pipes JSON over SSH stdin to a fixed Python program. The Mac checks its HEAD and tracked source, runs canonical recipe preflight, and delegates to `device_rung.py`. No configuration field becomes a shell command. The canonical rail checks artifact digests, development provisioning, source markers, and device readiness before installation and the fixture walk.

After a terminal result, the controller downloads the rung receipt and available physical evidence into `C:/tmp/leafhft-ios/evidence/<UTC date>`. The Windows receipt links local screenshots and the preserved Mac receipt. The eight-minute controller budget includes transfer. A failed connection or missing evidence records `UNAVAILABLE`; there is no automatic retry of the device command. Inspect the Mac's `_marathon/evidence/windows-*` and bound-install job receipts before rerunning an unknown outcome. The manual TestFlight comparison remains a separate operator action.

## Phone attached to Windows

Keep the phone on this Windows host and use the signing Mac over SSH for the development build. Transfer the IPA, WDA artifact and both producer receipts to Windows without changing their bytes. Run the complete `python ios/scripts/device_rung.py` command in `DEVICE.md` with those local paths and expected digests. This is the single rung command for a Windows USB phone; `test_device.py` remains the controller for a Mac USB phone.

Install OpenSSL on PATH before using the Windows runner. It verifies the embedded profile's CMS content signature and parses its plist; existing checks still reject distribution profiles. The installed physical rail must contain the Leaf HFT allowlist and exact Windows project-to-bundle mapping. Configure its server-owned `IOS_DEVICE_UDID` to the intended iPhone when an iPad or other device remains attached. Without that selector, the rail requires a single USB device. Status reports the actual device count and selected-device readiness separately. The command preserves the same source, artifact, receipt and eight-minute checks. It creates no signing assets.
