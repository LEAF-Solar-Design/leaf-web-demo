import XCTest
@testable import LeafHFT

final class DashboardPairingLaunchPolicyTests: XCTestCase {
    func testRouteSetupFiresOnlyOnTransition() {
        XCTAssertTrue(DashboardPairingLaunchPolicy.shouldRouteSetup(previous: false, current: true))
        XCTAssertFalse(DashboardPairingLaunchPolicy.shouldRouteSetup(previous: true, current: true))
        XCTAssertFalse(DashboardPairingLaunchPolicy.shouldRouteSetup(previous: false, current: false))
        XCTAssertFalse(DashboardPairingLaunchPolicy.shouldRouteSetup(previous: true, current: false))
    }

    func testMissingCredentialStartsAutomaticPairing() {
        XCTAssertTrue(DashboardPairingLaunchPolicy.shouldAutoStart(hasCredential: false))
    }

    func testExistingCredentialIsPreserved() {
        XCTAssertFalse(DashboardPairingLaunchPolicy.shouldAutoStart(hasCredential: true))
    }

    func testPairedPhoneWithoutKalshiKeyOpensSettings() {
        XCTAssertTrue(DashboardPairingLaunchPolicy.shouldOpenSettings(
            hasDashboardCredential: true, hasKalshiCredential: false))
    }

    func testCompleteCredentialsDoNotForceSettings() {
        XCTAssertFalse(DashboardPairingLaunchPolicy.shouldOpenSettings(
            hasDashboardCredential: true, hasKalshiCredential: true))
    }

    func testPairedUnboundStatusRoutesToSetup() {
        XCTAssertTrue(DashboardPairingLaunchPolicy.shouldRouteSetup(
            dashboardPairing: .paired, accountBinding: .unbound))
        XCTAssertFalse(DashboardPairingLaunchPolicy.shouldRouteSetup(
            dashboardPairing: .paired, accountBinding: .bound))
    }
}
