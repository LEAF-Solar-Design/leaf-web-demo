import Foundation
import Security
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class SignerTests: XCTestCase {
    private func generatedKey() throws -> (Data, SecKey) {
        let attributes: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeySizeInBits as String: 2048,
            kSecAttrIsPermanent as String: false
        ]
        var error: Unmanaged<CFError>?
        let generated = SecKeyCreateRandomKey(attributes as CFDictionary, &error)
        _ = error?.takeRetainedValue()
        let key = try XCTUnwrap(generated)
        error = nil
        let exported = SecKeyCopyExternalRepresentation(key, &error)
        _ = error?.takeRetainedValue()
        return (try XCTUnwrap(exported) as Data, try XCTUnwrap(SecKeyCopyPublicKey(key)))
    }
    private func der(_ tag: UInt8, _ body: [UInt8]) -> [UInt8] {
        var length = body.count
        var bytes: [UInt8] = []
        repeat {
            bytes.insert(UInt8(length & 0xff), at: 0)
            length >>= 8
        } while length > 0
        return [tag] + (body.count < 128 ? bytes : [0x80 | UInt8(bytes.count)] + bytes) + body
    }
    private func pem(_ label: String, _ bytes: [UInt8]) -> String {
        let body = Array(Data(bytes).base64EncodedString())
        let lines = stride(from: 0, to: body.count, by: 64).map {
            String(body[$0..<min($0 + 64, body.count)])
        }
        return "-----BEGIN \(label)-----\n" + lines.joined(separator: "\n") + "\n-----END \(label)-----"
    }
    private func hex(_ text: String) throws -> Data {
        let chars = Array(text)
        XCTAssertEqual(chars.count % 2, 0)
        guard chars.count % 2 == 0 else { throw KalshiSignerError.invalidKey }
        return Data(try stride(from: 0, to: chars.count, by: 2).map {
            try XCTUnwrap(UInt8(String(chars[$0..<($0 + 2)]), radix: 16))
        })
    }
    private func verify(_ signature: Data, message: Data, key: SecKey) -> Bool {
        var error: Unmanaged<CFError>?
        let valid = SecKeyVerifySignature(key, .rsaSignatureMessagePSSSHA256,
                                         message as CFData, signature as CFData, &error)
        _ = error?.takeRetainedValue()
        return valid
    }
    private func assertSigns(_ bytes: Data, publicKey: SecKey) throws {
        let message = canonicalSigningMessage(timestampMs: 1757800000000, path: KalshiGETEndpoint.balance.path)
        let signer = try KalshiSigner(pkcs1DER: bytes)
        let signature = try XCTUnwrap(Data(base64Encoded: signer.signature(timestampMs: 1757800000000,
                                                                          path: KalshiGETEndpoint.balance.path)))
        XCTAssertTrue(verify(signature, message: message, key: publicKey))
        XCTAssertFalse(verify(signature, message: Data("changed".utf8), key: publicKey))
    }
    func testNativeSignature() throws {
        let (bytes, publicKey) = try generatedKey()
        try assertSigns(bytes, publicKey: publicKey)
    }

    func testBindingUsesPublicSPKIAndPSSProof() throws {
        let (bytes, publicKey) = try generatedKey()
        let signer = try KalshiSigner(pkcs1DER: bytes)
        let exported = try signer.publicKeyDER()
        var error: Unmanaged<CFError>?
        let raw = try XCTUnwrap(SecKeyCopyExternalRepresentation(publicKey, &error)) as Data
        _ = error?.takeRetainedValue()
        let algorithm = [UInt8]([0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 1, 1, 1, 5, 0])
        XCTAssertEqual(exported, Data(der(0x30, algorithm + der(0x03, [0] + Array(raw)))))
        XCTAssertNotEqual(exported, bytes)
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .iso8601
        let challenge = try decoder.decode(BindingChallenge.self, from: Data(#"{"challenge_id":"abcdefab-1234-4234-9234-123456789abc","device_id":"fedcbafe-1234-4234-9234-123456789abc","challenge":"abc","challenge_hash":"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","expires_at":"2030-01-01T00:00:00Z","binding_version":"kashbot-bind-v1"}"#.utf8))
        let now = Date(timeIntervalSince1970: 0)
        let request = try signer.bindingRequest(challenge: challenge, keyID: " KEY_1 ", now: now)
        XCTAssertEqual(request.keyId, "key_1")
        XCTAssertEqual(Data(base64Encoded: request.publicKeyDer), exported)
        let signature = try XCTUnwrap(Data(base64Encoded: request.signature))
        let message = try challenge.canonicalMessage(keyID: "key_1", publicKeyDER: exported, now: now)
        XCTAssertTrue(verify(signature, message: message, key: publicKey))
        XCTAssertFalse(verify(signature, message: Data("changed".utf8), key: publicKey))
    }
    func testPEMRoundTrip() throws {
        let (bytes, publicKey) = try generatedKey()
        let oid: [UInt8] = [0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 1, 1, 1]
        let algorithm = der(0x30, der(0x06, oid) + der(0x05, []))
        let wrapped = der(0x30, der(0x02, [0]) + algorithm + der(0x04, Array(bytes)))
        XCTAssertEqual(try decodeRSAPrivateKeyPEM(pem("RSA PRIVATE KEY", Array(bytes))), bytes)
        let decoded = try decodeRSAPrivateKeyPEM(pem("PRIVATE KEY", wrapped))
        XCTAssertEqual(decoded, bytes)
        try assertSigns(decoded, publicKey: publicKey)
    }
    func testSaltConvention() throws {
        let url = try XCTUnwrap(Bundle(for: SignerTests.self).url(forResource: "signature-fixture",
                                                                withExtension: "json", subdirectory: "Fixtures"))
        let json = try JSONSerialization.jsonObject(with: Data(contentsOf: url))
        let record = try XCTUnwrap(json as? [String: String])
        let signature = try hex(XCTUnwrap(record["signature_hex"]))
        let timestamp = try XCTUnwrap(Int64(try XCTUnwrap(record["timestamp_ms"])))
        let message = canonicalSigningMessage(timestampMs: timestamp, path: try XCTUnwrap(record["path"]))
        let der = try hex(XCTUnwrap(record["public_key_pkcs1_der_hex"]))
        let attributes: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
                                         kSecAttrKeyClass as String: kSecAttrKeyClassPublic,
                                         kSecAttrKeySizeInBits as String: 2048]
        var error: Unmanaged<CFError>?
        let imported = SecKeyCreateWithData(der as CFData, attributes as CFDictionary, &error)
        _ = error?.takeRetainedValue()
        let publicKey = try XCTUnwrap(imported)
        XCTAssertTrue(verify(signature, message: message, key: publicKey))
    }
}
