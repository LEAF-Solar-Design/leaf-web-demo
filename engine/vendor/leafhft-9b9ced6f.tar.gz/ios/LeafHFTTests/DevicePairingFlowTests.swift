import Foundation
import Combine
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor
private final class PairingClientMock: DevicePairingClientProtocol {
    let request: DevicePairingRequest
    var polls: [DevicePairingPoll]
    private(set) var pollCount = 0
    private(set) var requestCount = 0

    init(request: DevicePairingRequest, polls: [DevicePairingPoll]) {
        self.request = request
        self.polls = polls
    }

    func requestPairing(deviceName: String) async throws -> DevicePairingRequest { requestCount += 1; return request }

    func pollPairing(id: String, pollToken: String) async throws -> DevicePairingPoll {
        pollCount += 1
        return polls.removeFirst()
    }
}

@MainActor
final class DevicePairingFlowTests: XCTestCase {
    func testApprovedFirstPollSavesBearerWithoutSleepingOrWaiting() async {
        let expiry = Date(timeIntervalSince1970: 20)
        let client = PairingClientMock(
            request: DevicePairingRequest(id: "pair-id", code: "ABC123", pollToken: "private-poll", expiresAt: expiry),
            polls: [DevicePairingPoll(state: .approved, token: "device-bearer")])
        var saved: Data?
        let flow = DevicePairingFlow(client: client, saveToken: { saved = $0 }, hasToken: { false },
                                     sleep: { _ in XCTFail("an approved first poll must not sleep") },
                                     now: { Date(timeIntervalSince1970: 10) })
        var phases: [DevicePairingPhase] = []
        let observation = flow.$phase.sink { phases.append($0) }
        defer { observation.cancel() }

        await flow.start(deviceName: "Alex’s iPhone")

        XCTAssertEqual(client.requestCount, 1)
        XCTAssertEqual(client.pollCount, 1)
        XCTAssertEqual(saved, Data("device-bearer".utf8))
        XCTAssertEqual(phases, [.idle, .requesting, .approved])
    }

    func testPendingThenApprovedSavesOnlyBearerAndKeepsItOutOfStatus() async {
        let expiry = Date(timeIntervalSince1970: 2_000_000_000)
        let client = PairingClientMock(
            request: DevicePairingRequest(id: "pair-id", code: "ABC123", pollToken: "private-poll", expiresAt: expiry),
            polls: [
                DevicePairingPoll(state: .pending, expiresAt: expiry),
                DevicePairingPoll(state: .pending, expiresAt: expiry),
                DevicePairingPoll(state: .approved, token: "device-bearer")
            ])
        var saved: Data?
        var sleepCount = 0
        let flow = DevicePairingFlow(client: client, saveToken: { saved = $0 }, hasToken: { false }, sleep: { duration in
            sleepCount += 1
            XCTAssertEqual(duration, 2_000_000_000)
            XCTAssertEqual(client.pollCount, sleepCount)
            XCTAssertNil(saved)
        },
                                     now: { Date(timeIntervalSince1970: 1_900_000_000) })
        var phases: [DevicePairingPhase] = []
        let observation = flow.$phase.sink { phases.append($0) }
        defer { observation.cancel() }

        await flow.start(deviceName: "Alex’s iPhone")

        XCTAssertEqual(flow.phase, .approved)
        XCTAssertEqual(saved, Data("device-bearer".utf8))
        XCTAssertEqual(client.pollCount, 3)
        XCTAssertEqual(sleepCount, 2)
        XCTAssertEqual(phases, [.idle, .requesting,
                                .waiting(code: "ABC123", expiresAt: expiry),
                                .waiting(code: "ABC123", expiresAt: expiry), .approved])
        XCTAssertFalse(flow.phase.userStatus?.contains("device-bearer") ?? false)
        XCTAssertFalse(flow.phase.userStatus?.contains("private-poll") ?? false)
    }

    func testExpiredRequestDoesNotPollOrSave() async {
        let client = PairingClientMock(
            request: DevicePairingRequest(id: "pair-id", code: "ABC123", pollToken: "private-poll",
                                          expiresAt: Date(timeIntervalSince1970: 10)),
            polls: [])
        var didSave = false
        let flow = DevicePairingFlow(client: client, saveToken: { _ in didSave = true }, hasToken: { false }, sleep: { _ in },
                                     now: { Date(timeIntervalSince1970: 11) })

        await flow.start(deviceName: "Alex’s iPhone")

        XCTAssertEqual(flow.phase, .expired)
        XCTAssertEqual(client.pollCount, 0)
        XCTAssertFalse(didSave)
    }

    func testPendingPairingExpiresBeforeNextPoll() async {
        let expiry = Date(timeIntervalSince1970: 20)
        let client = PairingClientMock(
            request: DevicePairingRequest(id: "pair-id", code: "ABC123", pollToken: "private-poll", expiresAt: expiry),
            polls: [DevicePairingPoll(state: .pending, expiresAt: expiry)])
        var currentTime = Date(timeIntervalSince1970: 19)
        var sleepCount = 0
        let flow = DevicePairingFlow(client: client, saveToken: { _ in XCTFail("expired pairing must not save") },
                                     hasToken: { false }, sleep: { duration in
            sleepCount += 1
            XCTAssertEqual(duration, 2_000_000_000)
            XCTAssertEqual(client.pollCount, 1)
            currentTime = Date(timeIntervalSince1970: 21)
        }, now: { currentTime })

        await flow.start(deviceName: "Alex’s iPhone")

        XCTAssertEqual(flow.phase, .expired)
        XCTAssertEqual(client.pollCount, 1)
        XCTAssertEqual(sleepCount, 1)
    }

    func testCancellationStopsBeforeNextPollOrSaving() async {
        let expiry = Date(timeIntervalSince1970: 20)
        let client = PairingClientMock(
            request: DevicePairingRequest(id: "pair-id", code: "ABC123", pollToken: "private-poll", expiresAt: expiry),
            polls: [DevicePairingPoll(state: .pending, expiresAt: expiry)])
        var didSave = false
        let flow = DevicePairingFlow(client: client, saveToken: { _ in didSave = true }, hasToken: { false },
                                     sleep: { _ in throw CancellationError() },
                                     now: { Date(timeIntervalSince1970: 10) })

        await flow.start(deviceName: "Alex’s iPhone")

        XCTAssertEqual(flow.phase, .cancelled)
        XCTAssertEqual(client.pollCount, 1)
        XCTAssertFalse(didSave)
    }

    func testReplacementKeepsExistingBearerUntilApproval() async {
        let expiry = Date(timeIntervalSince1970: 20)
        let client = PairingClientMock(
            request: DevicePairingRequest(id: "pair-id", code: "ABC123", pollToken: "private-poll", expiresAt: expiry),
            polls: [
                DevicePairingPoll(state: .pending, expiresAt: expiry),
                DevicePairingPoll(state: .approved, token: "replacement-bearer")
            ])
        var saved = Data("stale-bearer".utf8)
        var saveCount = 0
        let flow = DevicePairingFlow(client: client, saveToken: {
            saved = $0
            saveCount += 1
        }, hasToken: { true }, sleep: { _ in
            XCTAssertEqual(saved, Data("stale-bearer".utf8))
            XCTAssertEqual(saveCount, 0)
        }, now: { Date(timeIntervalSince1970: 10) })

        await flow.start(deviceName: "Alex’s iPhone", replaceExistingToken: true)

        XCTAssertEqual(flow.phase, .approved)
        XCTAssertEqual(client.requestCount, 1)
        XCTAssertEqual(client.pollCount, 2)
        XCTAssertEqual(saveCount, 1)
        XCTAssertEqual(saved, Data("replacement-bearer".utf8))
    }

    func testCancelledReplacementKeepsExistingBearer() async {
        let client = PairingClientMock(
            request: DevicePairingRequest(id: "pair-id", code: "ABC123", pollToken: "private-poll",
                                          expiresAt: Date(timeIntervalSince1970: 20)),
            polls: [DevicePairingPoll(state: .pending, expiresAt: Date(timeIntervalSince1970: 20))])
        var saved = Data("stale-bearer".utf8)
        let flow = DevicePairingFlow(client: client, saveToken: {
            saved = $0
            XCTFail("must not save before approval")
        }, hasToken: { true }, sleep: { _ in throw CancellationError() },
                                     now: { Date(timeIntervalSince1970: 10) })

        await flow.start(deviceName: "Alex’s iPhone", replaceExistingToken: true)

        XCTAssertEqual(flow.phase, .cancelled)
        XCTAssertEqual(client.requestCount, 1)
        XCTAssertEqual(client.pollCount, 1)
        XCTAssertEqual(saved, Data("stale-bearer".utf8))
    }

    func testExistingBearerNeverCreatesAnotherPairing() async {
        let client = PairingClientMock(
            request: DevicePairingRequest(id: "unused", code: "UNUSED", pollToken: "unused",
                                          expiresAt: Date(timeIntervalSince1970: 20)),
            polls: [])
        let flow = DevicePairingFlow(client: client, saveToken: { _ in XCTFail("must not save") },
                                     hasToken: { true }, sleep: { _ in }, now: { Date(timeIntervalSince1970: 10) })

        await flow.start(deviceName: "Alex’s iPhone")

        XCTAssertEqual(flow.phase, .approved)
        XCTAssertEqual(client.requestCount, 0)
        XCTAssertEqual(client.pollCount, 0)
    }
}

