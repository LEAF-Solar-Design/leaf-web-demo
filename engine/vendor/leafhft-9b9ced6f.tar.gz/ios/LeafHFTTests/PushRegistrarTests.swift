import Foundation
import XCTest
import UserNotifications
@testable import LeafHFT

private final class PushRecorder: PushClientProtocol {
    var registrations: [String] = []
    var capabilities: [(planContractMax: Int, buildNumber: Int?)] = []
    var failCapabilities = false
    var capabilityFailure = DashboardClientError.http(404)
    var capabilityResult = 1
    var actions: [(Bool, AutopilotScope, String?)] = []
    var failRegistration = false
    var registrationFailure = DashboardClientError.transport
    var failToggle = false
    var onRegistration: ((String) async -> Void)?

    func register(apnsToken: String) async throws {
        registrations.append(apnsToken)
        await onRegistration?(apnsToken)
        if failRegistration { throw registrationFailure }
    }

    func registerCapabilities(planContractMax: Int, buildNumber: Int?) async throws -> Int {
        capabilities.append((planContractMax, buildNumber))
        if failCapabilities { throw capabilityFailure }
        return capabilityResult
    }

    func toggle(enabled: Bool, scope: AutopilotScope, eventID: String?) async throws -> AutopilotToggles {
        actions.append((enabled, scope, eventID))
        if failToggle { throw DashboardClientError.transport }
        return AutopilotToggles(schema: "leafhft.autopilot-toggles.v1", accountId: "owner",
                                enabledDefault: enabled, engines: [:])
    }
}

@MainActor final class PushRegistrarTests: XCTestCase {
    private let live = FixtureMode(arguments: [])
    private let eventID = "12345678-1234-1234-1234-123456789abc"

    func testSuccessfulRegistrationAdvertisesCapabilitiesAndRecordsServerValue() async {
        for returnedValue in [1, 2] {
            let client = PushRecorder()
            client.capabilityResult = returnedValue
            let registrar = makeRegistrar(client: client)
            XCTAssertNil(registrar.planContractMax)
            await registrar.receivedDeviceToken(apnsData)
            XCTAssertEqual(client.capabilities.count, 1)
            XCTAssertEqual(client.capabilities.first?.planContractMax, 2)
            XCTAssertEqual(client.capabilities.first?.buildNumber, PushRegistrar.bundleBuildNumber())
            XCTAssertEqual(registrar.planContractMax, returnedValue)
        }
    }

    func testCapabilityFailurePreservesPushSuccessAndCache() async {
        let plainClient = PushRecorder()
        let plain = makeRegistrar(client: plainClient)
        await plain.receivedDeviceToken(apnsData)
        for failure in [DashboardClientError.http(404), .transport, .decoding] {
            let client = PushRecorder()
            client.failCapabilities = true
            client.capabilityFailure = failure
            let registrar = makeRegistrar(client: client)
            await registrar.receivedDeviceToken(apnsData)
            XCTAssertEqual(client.capabilities.count, 1)
            XCTAssertEqual(registrar.pushStatus, plain.pushStatus)
            XCTAssertEqual(registrar.registrationError, plain.registrationError)
            XCTAssertNil(registrar.planContractMax)
            await registrar.activate()
            XCTAssertEqual(client.registrations.count, 1)
            XCTAssertEqual(client.capabilities.count, 1)
        }
    }

    func testFailedPushRegistrationDoesNotAdvertiseCapabilities() async {
        let client = PushRecorder()
        client.failRegistration = true
        let registrar = makeRegistrar(client: client)
        await registrar.receivedDeviceToken(apnsData)
        XCTAssertTrue(client.capabilities.isEmpty)
        XCTAssertNil(registrar.planContractMax)
    }

    func testCachedRegistrationDoesNotAdvertiseCapabilitiesAgain() async {
        let client = PushRecorder()
        var time = Date(timeIntervalSince1970: 1_000)
        let registrar = makeRegistrar(client: client, now: { time })
        await registrar.receivedDeviceToken(apnsData)
        client.capabilities.removeAll()
        time.addTimeInterval(23 * 60 * 60)
        await registrar.activate()
        await registrar.receivedDeviceToken(apnsData)
        XCTAssertTrue(client.capabilities.isEmpty)
        XCTAssertEqual(client.registrations.count, 1)
    }

    func testFixtureRegistrationDoesNotAdvertiseCapabilities() async {
        let client = PushRecorder()
        let registrar = PushRegistrar(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
                                      client: client, dashboardToken: { "device-token" })
        await registrar.receivedDeviceToken(apnsData)
        await registrar.activate(force: true)
        XCTAssertTrue(client.capabilities.isEmpty)
        XCTAssertNil(registrar.planContractMax)
    }

    func testBuildNumberParserAcceptsOnlyIntegerStringsInRange() {
        XCTAssertEqual(PushRegistrar.parseBuildNumber("120"), 120)
        XCTAssertEqual(PushRegistrar.parseBuildNumber("0"), 0)
        XCTAssertEqual(PushRegistrar.parseBuildNumber("2147483647"), 2_147_483_647)
        for value in ["1.2", "", " 7", "99999999999", "-1", "2147483648"] {
            XCTAssertNil(PushRegistrar.parseBuildNumber(value), value)
        }
        XCTAssertNil(PushRegistrar.parseBuildNumber(nil))
        XCTAssertNil(PushRegistrar.parseBuildNumber(120))
    }

    func testTokenHexPreservesLeadingZeros() {
        XCTAssertEqual(PushRegistrar.hexToken(Data([0, 1, 15, 16, 128, 255])), "00010f1080ff")
        XCTAssertEqual(PushRegistrar.hexToken(Data()), "")
    }

    func testTuningReviewActionRequiresUnlockAndForeground() throws {
        let category = try XCTUnwrap(PushRegistrar.notificationCategories().first {
            $0.identifier == PushRegistrar.tuningConfirmRequest
        })
        XCTAssertEqual(category.actions.map(\.identifier), ["tuning_review"])
        let action = try XCTUnwrap(category.actions.first)
        XCTAssertEqual(action.title, "Review and approve")
        XCTAssertTrue(action.options.contains(.authenticationRequired))
        XCTAssertTrue(action.options.contains(.foreground))
    }

    func testInboxCategoryHasNoActions() throws {
        let categories = PushRegistrar.notificationCategories()
        let inbox = try XCTUnwrap(categories.first { $0.identifier == PushRegistrar.assistantInbox })
        XCTAssertEqual(inbox.identifier, "ASSISTANT_INBOX")
        XCTAssertTrue(inbox.actions.isEmpty)
        let autopilot = try XCTUnwrap(categories.first { $0.identifier == PushRegistrar.category })
        XCTAssertEqual(autopilot.actions.map(\.identifier), [PushRegistrar.keepOn, PushRegistrar.turnOff])
    }

    func testInboxTapIgnoresPayload() async throws {
        let payloads: [[AnyHashable: Any]] = [
            [:],
            ["nomination_id": "another-suggestion", "account_id": "another-account", "event_id": eventID],
            ["nomination_id": "", "account_id": "", "event_id": "invalid"],
            ["nomination_id": String(repeating: "x", count: 5_000),
             "account_id": String(repeating: "y", count: 5_000)],
            ["nomination_id": 5, "account_id": ["owner"]]
        ]
        for payload in payloads {
            let client = PushRecorder()
            let registrar = PushRegistrar(fixtureMode: live, client: client,
                openTuningItem: { _ in XCTFail("Inbox tap opened a tuning item") })
            registrar.showAutopilot = true
            try await registrar.handleAction(UNNotificationDefaultActionIdentifier,
                userInfo: payload, category: PushRegistrar.assistantInbox)
            XCTAssertTrue(registrar.showAssistantInbox)
            XCTAssertFalse(registrar.showAutopilot)
            XCTAssertTrue(client.actions.isEmpty)
            XCTAssertTrue(client.registrations.isEmpty)
            XCTAssertNil(registrar.actionError)
        }
    }

    func testInboxIgnoresOtherActions() async throws {
        for identifier in [PushRegistrar.keepOn, PushRegistrar.turnOff, UNNotificationDismissActionIdentifier] {
            let client = PushRecorder()
            let registrar = makeRegistrar(client: client)
            try await registrar.handleAction(identifier,
                userInfo: ["account_id": "owner", "event_id": eventID], category: PushRegistrar.assistantInbox)
            XCTAssertFalse(registrar.showAssistantInbox)
            XCTAssertFalse(registrar.showAutopilot)
            XCTAssertTrue(client.actions.isEmpty)
            XCTAssertTrue(client.registrations.isEmpty)
            XCTAssertNil(registrar.actionError)
        }
    }

    func testDefaultAutopilotTapStillOpens() async throws {
        let categories: [String?] = [PushRegistrar.category, nil]
        for category in categories {
            let client = PushRecorder()
            let registrar = makeRegistrar(client: client)
            try await registrar.handleAction(UNNotificationDefaultActionIdentifier, userInfo: [:], category: category)
            XCTAssertTrue(registrar.showAutopilot)
            XCTAssertFalse(registrar.showAssistantInbox)
            XCTAssertTrue(client.actions.isEmpty)
            XCTAssertTrue(client.registrations.isEmpty)
        }
    }

    func testTuningTapStillOpensItem() async throws {
        for category in PushRegistrar.tuningCategories {
            let client = PushRecorder()
            var opened = false
            let registrar = PushRegistrar(fixtureMode: live, client: client, openTuningItem: { target in
                opened = true
                XCTAssertEqual(target, TuningInboxTarget(proposalID: self.eventID, category: category))
            })
            try await registrar.handleAction(UNNotificationDefaultActionIdentifier,
                userInfo: ["proposal_id": eventID], category: category)
            XCTAssertTrue(opened)
            XCTAssertTrue(registrar.showAutopilot)
            XCTAssertFalse(registrar.showAssistantInbox)
            XCTAssertTrue(client.actions.isEmpty)
        }
    }

    func testFixtureInboxTapStaysLocal() async throws {
        let client = PushRecorder()
        let registrar = PushRegistrar(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
            client: client, openTuningItem: { _ in XCTFail("Fixture tap opened a tuning item") })
        try await registrar.handleAction(UNNotificationDefaultActionIdentifier,
            userInfo: ["account_id": "owner", "event_id": eventID], category: PushRegistrar.assistantInbox)
        XCTAssertFalse(registrar.showAssistantInbox)
        XCTAssertFalse(registrar.showAutopilot)
        XCTAssertTrue(client.actions.isEmpty)
        XCTAssertTrue(client.registrations.isEmpty)
    }

    func testNoCredentialSkipsAuthorizationAndRegistrationThenPairingRetries() async {
        let client = PushRecorder()
        var token: String?
        var prompts = 0
        var apnsCalls = 0
        let registrar = PushRegistrar(fixtureMode: live, client: client, dashboardToken: { token },
            authorize: { prompts += 1; return true }, registerRemote: { apnsCalls += 1 })
        await registrar.activate()
        await registrar.receivedDeviceToken(Data([0, 255]))
        XCTAssertEqual(prompts, 0)
        XCTAssertEqual(apnsCalls, 0)
        XCTAssertTrue(client.registrations.isEmpty)
        token = "device-token"
        await registrar.activate(force: true)
        XCTAssertEqual(prompts, 1)
        XCTAssertEqual(apnsCalls, 1)
        XCTAssertEqual(client.registrations, ["00ff"])
    }

    func testFixtureModeSkipsEverySideEffect() async throws {
        let client = PushRecorder()
        let registrar = PushRegistrar(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
            client: client, dashboardToken: { XCTFail("Fixture read credentials"); return "device-token" },
            authorize: { XCTFail("Fixture requested permission"); return true },
            registerRemote: { XCTFail("Fixture registered for APNs") })
        await registrar.activate(force: true)
        await registrar.receivedDeviceToken(Data([1]))
        try await registrar.handleAction(PushRegistrar.keepOn, userInfo: ["event_id": eventID])
        XCTAssertTrue(client.registrations.isEmpty)
        XCTAssertTrue(client.actions.isEmpty)
    }

    func testRefreshAt24HoursRotationAndFailuresRetryOnlyOnTrigger() async {
        let client = PushRecorder()
        var time = Date(timeIntervalSince1970: 1_000)
        let registrar = PushRegistrar(fixtureMode: live, client: client, dashboardToken: { "device-token" },
            authorize: { true }, registerRemote: {}, now: { time })
        await registrar.receivedDeviceToken(Data([1]))
        await registrar.activate()
        XCTAssertEqual(client.registrations, ["01"])
        time.addTimeInterval(24 * 60 * 60)
        client.failRegistration = true
        await registrar.activate()
        XCTAssertEqual(client.registrations, ["01", "01"])
        XCTAssertNotNil(registrar.registrationError)
        client.failRegistration = false
        await registrar.activate()
        XCTAssertEqual(client.registrations, ["01", "01", "01"])
        XCTAssertNil(registrar.registrationError)
        await registrar.receivedDeviceToken(Data([2]))
        XCTAssertEqual(client.registrations.last, "02")
        XCTAssertEqual(client.registrations.count, 4)
        await registrar.activate(force: true)
        XCTAssertEqual(client.registrations.count, 5)
    }

    func testCredentialRotationRegistersAgainBefore24Hours() async {
        let client = PushRecorder()
        var token = "first-device"
        let registrar = PushRegistrar(fixtureMode: live, client: client, dashboardToken: { token },
            authorize: { true }, registerRemote: {})
        await registrar.receivedDeviceToken(Data([1]))
        token = "second-device"
        await registrar.activate()
        XCTAssertEqual(client.registrations.count, 2)
    }

    func testRotationWhileRegistrationIsPendingUsesTheNewToken() async throws {
        let client = PushRecorder()
        let entered = expectation(description: "Old registration pending")
        let rotated = expectation(description: "New registration attempted")
        var release: CheckedContinuation<Void, Never>?
        client.onRegistration = { token in
            if token == "01" {
                await withCheckedContinuation { continuation in
                    release = continuation
                    entered.fulfill()
                }
            } else { rotated.fulfill() }
        }
        let registrar = PushRegistrar(fixtureMode: live, client: client, dashboardToken: { "device-token" },
            authorize: { true }, registerRemote: {})
        let first = Task { await registrar.receivedDeviceToken(Data([1])) }
        await fulfillment(of: [entered], timeout: 2)
        await registrar.receivedDeviceToken(Data([2]))
        XCTAssertEqual(client.registrations, ["01"])
        try XCTUnwrap(release).resume()
        await first.value
        await fulfillment(of: [rotated], timeout: 2)
        XCTAssertEqual(client.registrations, ["01", "02"])
    }

    func testActionsPassEnabledScopeAndEventThrough() async throws {
        let client = PushRecorder()
        let registrar = PushRegistrar(fixtureMode: live, client: client)
        try await registrar.handleAction(PushRegistrar.keepOn, userInfo: ["account_id": "owner", "event_id": eventID])
        try await registrar.handleAction(PushRegistrar.turnOff, userInfo: ["account_id": "aabbccdd", "event_id": eventID])
        XCTAssertEqual(client.actions.count, 2)
        XCTAssertTrue(client.actions[0].0)
        XCTAssertEqual(client.actions[0].1, .owner)
        XCTAssertEqual(client.actions[0].2, eventID)
        XCTAssertFalse(client.actions[1].0)
        XCTAssertEqual(client.actions[1].1, .lane)
        XCTAssertEqual(client.actions[1].2, eventID)
        try await registrar.handleAction(UNNotificationDefaultActionIdentifier, userInfo: [:])
        XCTAssertTrue(registrar.showAutopilot)
        try await registrar.handleAction(UNNotificationDismissActionIdentifier, userInfo: [:])
        XCTAssertEqual(client.actions.count, 2)
    }

    // Push status diagnostics: one test per branch, each proving the text carries no secret.
    private let credential = "device-token"
    private let apnsData = Data([0xde, 0xad, 0xbe, 0xef])

    private func assertNoSecret(_ status: String, file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertFalse(status.contains(credential), "credential in status", file: file, line: line)
        XCTAssertFalse(status.lowercased().contains(PushRegistrar.hexToken(apnsData)), "APNs token in status",
                       file: file, line: line)
        XCTAssertFalse(status.contains("Bearer"), "authorization header in status", file: file, line: line)
        XCTAssertLessThanOrEqual(status.count, 120, file: file, line: line)
    }

    private func makeRegistrar(client: PushRecorder, token: String? = "device-token",
                           authorize: @escaping () async throws -> Bool = { true },
                           label: @escaping () async -> String = { "denied" },
                           now: @escaping () -> Date = { Date(timeIntervalSince1970: 1_000) }) -> PushRegistrar {
        PushRegistrar(fixtureMode: live, client: client, dashboardToken: { token }, authorize: authorize,
                      registerRemote: {}, now: now, authorizationLabel: label)
    }

    func testStatusNotSignedIn() async {
        let client = PushRecorder()
        let registrar = makeRegistrar(client: client, token: nil)
        await registrar.activate()
        XCTAssertEqual(registrar.pushStatus, "Not signed in")
        XCTAssertTrue(client.registrations.isEmpty)
        assertNoSecret(registrar.pushStatus)
    }

    func testStatusPermissionNotAllowedNamesAuthorizationStatus() async {
        let client = PushRecorder()
        let registrar = makeRegistrar(client: client, authorize: { false }, label: { "denied" })
        await registrar.activate()
        XCTAssertEqual(registrar.pushStatus, "Notifications not allowed (denied)")
        XCTAssertTrue(client.registrations.isEmpty)
        assertNoSecret(registrar.pushStatus)
    }

    func testStatusPermissionCheckThrows() async {
        let client = PushRecorder()
        let registrar = makeRegistrar(client: client, authorize: {
            throw NSError(domain: "test", code: 1, userInfo: [NSLocalizedDescriptionKey: "Settings unavailable"])
        })
        await registrar.activate()
        XCTAssertEqual(registrar.pushStatus, "Permission check failed: Settings unavailable")
        XCTAssertNotNil(registrar.registrationError)
        assertNoSecret(registrar.pushStatus)
    }

    func testStatusAppleRefusedFromFailCallback() async {
        let client = PushRecorder()
        let registrar = makeRegistrar(client: client)
        await registrar.activate()
        XCTAssertEqual(registrar.pushStatus, "Asking Apple for a push token")
        registrar.appleRefused(NSError(domain: "NSCocoaErrorDomain", code: 3010,
            userInfo: [NSLocalizedDescriptionKey: "remote notifications are not supported in the simulator"]))
        XCTAssertEqual(registrar.pushStatus,
                       "Apple refused: NSCocoaErrorDomain 3010 remote notifications are not supported in the simulator")
        XCTAssertNotNil(registrar.registrationError)
        XCTAssertTrue(client.registrations.isEmpty)
        assertNoSecret(registrar.pushStatus)
    }

    func testStatusServerForbidden() async {
        let client = PushRecorder()
        client.failRegistration = true
        client.registrationFailure = .forbidden
        let registrar = makeRegistrar(client: client)
        await registrar.receivedDeviceToken(apnsData)
        XCTAssertEqual(registrar.pushStatus, "Kashbot refused: HTTP 403")
        XCTAssertNotNil(registrar.registrationError)
        assertNoSecret(registrar.pushStatus)
        client.registrationFailure = .http(502)
        await registrar.receivedDeviceToken(apnsData)
        XCTAssertEqual(registrar.pushStatus, "Kashbot refused: HTTP 502")
        client.registrationFailure = .decoding
        await registrar.receivedDeviceToken(apnsData)
        XCTAssertEqual(registrar.pushStatus, "Kashbot reply unreadable")
    }

    func testStatusServerTransportError() async {
        let client = PushRecorder()
        client.failRegistration = true
        client.registrationFailure = .transport
        let registrar = makeRegistrar(client: client)
        await registrar.receivedDeviceToken(apnsData)
        XCTAssertEqual(registrar.pushStatus, "Kashbot unreachable")
        XCTAssertNotNil(registrar.registrationError)
        assertNoSecret(registrar.pushStatus)
    }

    func testStatusSuccess() async {
        let client = PushRecorder()
        let registrar = makeRegistrar(client: client)
        await registrar.activate()
        await registrar.receivedDeviceToken(apnsData)
        XCTAssertEqual(client.registrations, [PushRegistrar.hexToken(apnsData)])
        XCTAssertEqual(registrar.pushStatus, "Registered just now")
        XCTAssertNil(registrar.registrationError)
        assertNoSecret(registrar.pushStatus)
    }

    func testStatusLastSuccessShortcutSkipsPost() async {
        let client = PushRecorder()
        var time = Date(timeIntervalSince1970: 1_000)
        let registrar = makeRegistrar(client: client, now: { time })
        await registrar.receivedDeviceToken(apnsData)
        XCTAssertEqual(registrar.pushStatus, "Registered just now")
        time.addTimeInterval(60 * 60)
        await registrar.activate()
        XCTAssertEqual(client.registrations.count, 1)
        XCTAssertEqual(registrar.pushStatus, "Registered earlier today")
        assertNoSecret(registrar.pushStatus)
    }

    func testFixtureStatusSaysDemoMode() {
        let registrar = PushRegistrar(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
            client: PushRecorder())
        XCTAssertEqual(registrar.pushStatus, "Notifications are off in demo mode")
    }

    func testMalformedEventAndNetworkFailureAreSurfaced() async {
        let client = PushRecorder()
        let registrar = PushRegistrar(fixtureMode: live, client: client)
        do {
            try await registrar.handleAction(PushRegistrar.keepOn, userInfo: ["event_id": "invalid"])
            XCTFail("Malformed event accepted")
        } catch {}
        XCTAssertTrue(client.actions.isEmpty)
        client.failToggle = true
        do {
            try await registrar.handleAction(PushRegistrar.turnOff, userInfo: ["event_id": eventID])
            XCTFail("Write error swallowed")
        } catch {}
    }

    func testFailedActionPostsOneLocalNotification() async {
        let client = PushRecorder()
        client.failToggle = true
        var notices: [String] = []
        let registrar = PushRegistrar(fixtureMode: live, client: client, notifyFailure: { notices.append($0) })
        await registrar.performAction(PushRegistrar.turnOff, userInfo: ["event_id": eventID])
        XCTAssertEqual(client.actions.count, 1)
        XCTAssertEqual(notices.count, 1)
        XCTAssertNotNil(registrar.actionError)
        XCTAssertEqual(notices.first, registrar.actionError)
        XCTAssertTrue(registrar.showAutopilot)
    }

    func testMalformedEventPostsOneLocalNotification() async {
        let client = PushRecorder()
        var notices: [String] = []
        let registrar = PushRegistrar(fixtureMode: live, client: client, notifyFailure: { notices.append($0) })
        await registrar.performAction(PushRegistrar.keepOn, userInfo: ["event_id": "invalid"])
        XCTAssertTrue(client.actions.isEmpty)
        XCTAssertEqual(notices.count, 1)
        XCTAssertNotNil(registrar.actionError)
        XCTAssertEqual(notices.first, registrar.actionError)
        XCTAssertTrue(registrar.showAutopilot)
    }

    func testSuccessfulActionPostsNothing() async {
        let client = PushRecorder()
        var notices: [String] = []
        let registrar = PushRegistrar(fixtureMode: live, client: client, notifyFailure: { notices.append($0) })
        await registrar.performAction(PushRegistrar.turnOff, userInfo: ["event_id": eventID])
        XCTAssertEqual(client.actions.count, 1)
        XCTAssertTrue(notices.isEmpty)
        XCTAssertNil(registrar.actionError)
    }

    func testFixtureModeActionPostsNothing() async {
        let client = PushRecorder()
        client.failToggle = true
        var notices: [String] = []
        let registrar = PushRegistrar(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
            client: client, notifyFailure: { notices.append($0) })
        await registrar.performAction(PushRegistrar.turnOff, userInfo: ["event_id": "invalid"])
        XCTAssertTrue(client.actions.isEmpty)
        XCTAssertTrue(notices.isEmpty)
        XCTAssertNil(registrar.actionError)
    }
}
