import Foundation
import XCTest
@testable import LeafHFT

private final class AutopilotHTTPStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                                                       httpVersion: nil, headerFields: nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

final class AutopilotClientTests: XCTestCase {
    private let live = FixtureMode(arguments: [])
    override func tearDown() { AutopilotHTTPStub.handler = nil; super.tearDown() }

    private func pushClient(token: @escaping () throws -> String = { "device-token" }) -> PushClient {
        PushClient(fixtureMode: live, protocolClasses: [AutopilotHTTPStub.self], token: token)
    }

    private func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open()
            defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 1024)
            while true {
                let count = stream.read(&buffer, maxLength: buffer.count)
                if count < 0 { throw URLError(.cannotDecodeContentData) }
                if count == 0 { break }
                data.append(contentsOf: buffer.prefix(count))
            }
        }
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    }

    private func toggles(account: String = "owner", enabled: Bool = false) throws -> Data {
        try JSONSerialization.data(withJSONObject: ["schema": "leafhft.autopilot-toggles.v1",
            "account_id": account, "enabled_default": enabled, "engines": [:]] as [String: Any])
    }

    func testRegistrationUsesStrictProductionBodyBearerAndTimeout() async throws {
        let apns = String(repeating: "ab", count: 32)
        AutopilotHTTPStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/push-token")
            XCTAssertNil(request.url?.query)
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Content-Type"), "application/json")
            XCTAssertEqual(request.timeoutInterval, 15)
            let body = try self.body(request)
            XCTAssertEqual(Set(body.keys), ["apns_token", "environment"])
            XCTAssertEqual(body["apns_token"] as? String, apns)
            XCTAssertEqual(body["environment"] as? String, "production")
            return (200, Data(#"{"registered":true,"delivered":2}"#.utf8))
        }
        try await pushClient().register(apnsToken: apns)
    }

    func testToggleUsesStrictScopeEnabledAndOptionalEventBody() async throws {
        let event = "12345678-1234-1234-1234-123456789abc"
        var calls = 0
        AutopilotHTTPStub.handler = { request in
            calls += 1
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/autopilot/toggle")
            XCTAssertNil(request.url?.query)
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            XCTAssertEqual(request.timeoutInterval, 15)
            let body = try self.body(request)
            if calls == 1 {
                XCTAssertEqual(Set(body.keys), ["enabled", "scope", "event_id"])
                XCTAssertEqual(body["event_id"] as? String, event)
                XCTAssertEqual(body["scope"] as? String, "owner")
                XCTAssertEqual(body["enabled"] as? Bool, false)
            } else {
                XCTAssertEqual(Set(body.keys), ["enabled", "scope"])
                XCTAssertEqual(body["scope"] as? String, "lane")
                XCTAssertEqual(body["enabled"] as? Bool, true)
            }
            return (200, try self.toggles(account: calls == 1 ? "owner" : "aabbccdd", enabled: calls != 1))
        }
        let client = pushClient()
        let owner = try await client.toggle(enabled: false, scope: .owner, eventID: event)
        XCTAssertFalse(owner.enabledDefault)
        XCTAssertEqual(owner.accountId, "owner")
        let lane = try await client.toggle(enabled: true, scope: .lane)
        XCTAssertTrue(lane.enabledDefault)
        XCTAssertEqual(lane.accountId, "aabbccdd")
        XCTAssertEqual(calls, 2)
    }

    func testGetKeepsReadOnlyRouteAndDecodesAccountSwitches() async throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "autopilot", withExtension: "json", subdirectory: "Fixtures"))
        var envelope = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
        envelope["account_switches"] = [["scope": "owner", "account_id": "owner", "enabled": true,
                                           "overrides_on": 2, "overrides_off": 1]]
        let data = try JSONSerialization.data(withJSONObject: envelope)
        AutopilotHTTPStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/autopilot")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            XCTAssertNil(request.httpBody)
            XCTAssertNil(request.url?.query)
            return (200, data)
        }
        let client = AutopilotClient(fixtureMode: live, protocolClasses: [AutopilotHTTPStub.self], token: { "device-token" })
        let result = try await client.fetch()
        XCTAssertEqual(result.accountSwitches?.first?.scope, .owner)
        XCTAssertEqual(result.accountSwitches?.first?.overridesOff, 1)
    }

    func testHTTPAndDecodeErrorsAreSurfaced() async {
        for status in [401, 403, 503] {
            AutopilotHTTPStub.handler = { _ in (status, Data()) }
            do {
                _ = try await pushClient().toggle(enabled: false, scope: .lane)
                XCTFail("HTTP error swallowed")
            } catch {
                guard let error = error as? DashboardClientError else { XCTFail("Wrong error"); continue }
                switch (status, error) {
                case (401, .unauthorized), (403, .forbidden), (503, .http(503)): break
                default: XCTFail("Wrong HTTP error mapping")
                }
            }
        }
        for response in ["not json", "{}", #"{"registered":false,"delivered":0}"#] {
            AutopilotHTTPStub.handler = { _ in (200, Data(response.utf8)) }
            do {
                try await pushClient().register(apnsToken: String(repeating: "ab", count: 32))
                XCTFail("Registration decode failure swallowed")
            } catch {
                guard case DashboardClientError.decoding = error else { return XCTFail("Expected decoding error") }
            }
        }
        AutopilotHTTPStub.handler = { _ in (200, Data(#"{"enabled_default":false}"#.utf8)) }
        do {
            _ = try await pushClient().toggle(enabled: false, scope: .owner)
            XCTFail("Incomplete toggle document accepted")
        } catch {
            guard case DashboardClientError.decoding = error else { return XCTFail("Expected decoding error") }
        }
    }

    func testTransportAndCredentialErrorsSurfaceWithoutFallback() async {
        AutopilotHTTPStub.handler = { _ in throw URLError(.timedOut) }
        do {
            _ = try await pushClient().toggle(enabled: false, scope: .lane)
            XCTFail("Transport error swallowed")
        } catch {
            guard case DashboardClientError.transport = error else { return XCTFail("Expected transport error") }
        }
        AutopilotHTTPStub.handler = { _ in XCTFail("Missing credential reached transport"); return (200, Data()) }
        do {
            try await pushClient(token: { "" }).register(apnsToken: String(repeating: "ab", count: 32))
            XCTFail("Missing credential accepted")
        } catch {
            guard case DashboardClientError.noCredential = error else { return XCTFail("Expected credential error") }
        }
    }

    func testFixtureWritesStopBeforeCredentialsAndTransport() async {
        let client = PushClient(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
            protocolClasses: [AutopilotHTTPStub.self], token: { XCTFail("Read fixture credentials"); return "device-token" })
        AutopilotHTTPStub.handler = { _ in XCTFail("Fixture network write"); return (200, Data()) }
        do {
            try await client.register(apnsToken: String(repeating: "ab", count: 32))
            XCTFail("Fixture registered")
        } catch { XCTAssertTrue(error is FixtureAccessError) }
        do {
            _ = try await client.toggle(enabled: true, scope: .owner)
            XCTFail("Fixture toggled")
        } catch { XCTAssertTrue(error is FixtureAccessError) }
    }
}
