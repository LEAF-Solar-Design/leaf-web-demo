import Foundation
import XCTest
@testable import LeafHFT
import LeafHFTCore

@MainActor final class BooksLiveStateTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_790_000_000)

    private func quoted(closesIn seconds: Double) -> Candidate {
        var candidate = Candidate(ticker: "KXBTC15M-26SEP291915-15")
        candidate.expiryMs = Int64((now.timeIntervalSince1970 + seconds) * 1000)
        candidate.askCents = 42
        candidate.gate = "skip_edge"
        return candidate
    }

    func testFreshAndRefreshedIsLive() {
        XCTAssertEqual(BooksView.booksLiveState(stale: false, refreshFailed: false), .live)
        XCTAssertEqual(BooksView.marketLiveState(books: .live, candidate: quoted(closesIn: 300), now: now), .live)
    }

    func testFailedRefreshIsSaved() {
        let books = BooksView.booksLiveState(stale: false, refreshFailed: true)
        XCTAssertEqual(books, .saved)
        XCTAssertEqual(BooksView.marketLiveState(books: books, candidate: quoted(closesIn: 300), now: now), .saved)
        XCTAssertEqual(LiveState.saved.label, "SAVED")
        XCTAssertEqual(LiveState.saved.accessibilityText, "Showing saved data")
    }

    func testStaleIsDelayed() {
        XCTAssertEqual(BooksView.booksLiveState(stale: true, refreshFailed: false), .delayed)
        XCTAssertEqual(BooksView.booksLiveState(stale: true, refreshFailed: true), .delayed)
        XCTAssertEqual(BooksView.marketLiveState(books: .delayed, candidate: quoted(closesIn: 300), now: now), .delayed)
    }

    func testMissingQuoteIsNoQuote() {
        var noAsk = quoted(closesIn: 300)
        noAsk.askCents = nil
        XCTAssertEqual(BooksView.marketLiveState(books: .live, candidate: noAsk, now: now), .noQuote)
        var gated = quoted(closesIn: 300)
        gated.gate = "skip_no_quote"
        XCTAssertEqual(BooksView.marketLiveState(books: .live, candidate: gated, now: now), .noQuote)
        XCTAssertEqual(BooksView.marketLiveState(books: .live, candidate: nil, now: now), .noQuote)
        XCTAssertEqual(LiveState.noQuote.label, "NO QUOTE")
    }

    func testPastCloseIsClosed() {
        XCTAssertEqual(BooksView.marketLiveState(books: .live, candidate: quoted(closesIn: -60), now: now), .closed)
        var countdown = Candidate(ticker: "KXETH1H-26SEP221700")
        countdown.askCents = 40
        countdown.evalAtMs = Int64((now.timeIntervalSince1970 - 7 * 86400) * 1000)
        countdown.secondsToClose = 1800
        XCTAssertEqual(BooksView.marketLiveState(books: .live, candidate: countdown, now: now), .closed)
        XCTAssertEqual(LiveState.closed.label, "CLOSED")
    }

    func testFreshInitKeepsTwoStates() {
        XCTAssertEqual(LiveDot(fresh: true).state, .live)
        XCTAssertEqual(LiveDot(fresh: false).state, .delayed)
        XCTAssertEqual(LiveDot(fresh: true, ageText: "1m").state.label, "LIVE")
        XCTAssertEqual(LiveDot(fresh: false).state.label, "DELAYED")
    }
}
