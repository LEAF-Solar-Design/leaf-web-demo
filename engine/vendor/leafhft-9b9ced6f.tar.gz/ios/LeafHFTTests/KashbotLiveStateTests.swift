import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class KashbotLiveStateTests: XCTestCase {
    func testApprovalCompatibilityAndWidgetValues() throws {
        let oldState = Data(#"{"v":1,"asOf":0,"totalCents":1250,"todayCents":0,"openCount":1,"rows":[],"ledger":[]}"#.utf8)
        let decoder = JSONDecoder()
        var state = try decoder.decode(KashbotLiveAttributes.ContentState.self, from: oldState)
        XCTAssertEqual(state.v, 1)
        XCTAssertEqual(state.totalCents, 1250)
        XCTAssertNil(state.approvalsWaiting)
        XCTAssertNil(state.approval)
        XCTAssertEqual(state.approvalCount, 0)
        XCTAssertNil(state.reviewURL)
        let oldSnapshot = Data(("{\"state\":" + String(decoding: oldState, as: UTF8.self) + ",\"ledger\":[]}").utf8)
        let snapshot = try decoder.decode(KashbotBoardSnapshot.self, from: oldSnapshot)
        XCTAssertEqual(snapshot.state, state)
        XCTAssertNil(snapshot.approvalsWaiting)
        XCTAssertNil(snapshot.approval)
        let old = state
        state.approvalsWaiting = 2
        state.approval = .init(account: "00000001", proposalId: UUID().uuidString.lowercased(),
                               planSeq: 1, planSha256: String(repeating: "a", count: 64))
        XCTAssertEqual(state.approvalCount, 2)
        XCTAssertEqual(state.approvalText, "2 approvals waiting")
        XCTAssertNotNil(state.reviewURL)
        XCTAssertTrue(state.isMaterialChange(from: old))
        XCTAssertEqual(try decoder.decode(KashbotLiveAttributes.ContentState.self,
                                         from: JSONEncoder().encode(state)), state)
        let updated = KashbotBoardSnapshot(state: state, ledger: [], approvalsWaiting: 2, approval: state.approval)
        XCTAssertEqual(try decoder.decode(KashbotBoardSnapshot.self, from: JSONEncoder().encode(updated)), updated)
        state.approvalsWaiting = 1
        XCTAssertEqual(state.approvalText, "1 approval waiting")
        state.approvalsWaiting = 0
        XCTAssertNil(state.approvalText)
        state.approval?.account = "INVALID"
        XCTAssertNil(state.reviewURL)
    }

    private typealias State = KashbotLiveAttributes.ContentState
    private typealias Row = KashbotLiveAttributes.Row
    private typealias Entry = KashbotLiveAttributes.Entry

    private func decode<T: Decodable>(_ type: T.Type, _ json: String) throws -> T {
        try accountJSONDecoder().decode(type, from: Data(json.utf8))
    }

    private func fixture(_ name: String) throws -> Data {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: name,
            withExtension: "json", subdirectory: "Fixtures"))
        return try Data(contentsOf: url)
    }

    private func sample() -> State {
        .init(asOf: 0, totalCents: 1250, todayCents: 0, openCount: 1,
              rows: [.init(ticker: "RAIN", label: "Rain tomorrow", side: "yes", milli: 250,
                           winCents: 15, oddsPct: 45, state: "open")], ledger: [])
    }

    func testGoldenBuilderAndRoundTrip() throws {
        let balance = try decode(AccountBalance.self, #"{"balance":1200000,"portfolio_value":34567}"#)
        let positions = try [
            #"{"ticker":"RAIN","position_fp":"4","market_exposure_dollars":"1.00"}"#,
            #"{"ticker":"WIND","position_fp":"-0.01","market_exposure_dollars":"0.20"}"#,
            #"{"ticker":"WON","position_fp":"1","market_exposure_dollars":"0.10"}"#,
            #"{"ticker":"HIDDEN","position_fp":"1","market_exposure_dollars":"0.01"}"#
        ].map { try decode(Position.self, $0) }
        let markets = try [
            #"{"ticker":"RAIN","yes_sub_title":"Rain tomorrow","status":"active","yes_bid_dollars":"0.40","yes_ask_dollars":"0.50"}"#,
            #"{"ticker":"WON","yes_sub_title":"Settled winner","status":"settled","result":"yes"}"#
        ].map { try decode(Market.self, $0) }
        let settlements = try [
            #"{"ticker":"A-WIN","yes_total_cost_dollars":"0.10","revenue":25,"settled_time":"2026-09-29T04:00:00Z"}"#,
            #"{"ticker":"B-LOSS","no_total_cost_dollars":"1.00","revenue":0,"settled_time":"2026-09-29T04:00:00Z"}"#,
            #"{"ticker":"C-FREE","revenue":5,"settled_time":"2026-09-29T04:00:00Z"}"#
        ].map { try decode(Settlement.self, $0) }
        let snapshot = try XCTUnwrap(KashbotLiveStateBuilder.build(balance: balance,
            positions: positions, markets: markets, settlements: settlements,
            now: Date(timeIntervalSince1970: 1790712000)))
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        let golden = String(decoding: try fixture("kashbot-live-golden"), as: UTF8.self)
        let encoded = String(decoding: try encoder.encode(snapshot.state), as: UTF8.self)
        XCTAssertEqual(encoded.trimmingCharacters(in: .whitespacesAndNewlines),
                       golden.trimmingCharacters(in: .whitespacesAndNewlines))
        XCTAssertEqual(snapshot.state, State(asOf: 1790712000, totalCents: 1234567,
            todayCents: -80, openCount: 4, rows: [
                .init(ticker: "RAIN", label: "Rain tomorrow", side: "yes", milli: 4000,
                      winCents: 300, oddsPct: 45, state: "open", pnlCents: 80),
                .init(ticker: "WIND", label: nil, side: "no", milli: 10,
                      winCents: -19, oddsPct: nil, state: "open"),
                .init(ticker: "WON", label: "Settled winner", side: "yes", milli: 1000,
                      winCents: 90, oddsPct: nil, state: "won", pnlCents: 90)
            ], ledger: [
                .init(ticker: "A-WIN", pnlCents: 15, pnlBps: 15000, at: 1790654400),
                .init(ticker: "B-LOSS", pnlCents: -100, pnlBps: -10000, at: 1790654400),
                .init(ticker: "C-FREE", pnlCents: 5, pnlBps: nil, at: 1790654400)
            ]))
        XCTAssertEqual(try JSONDecoder().decode(KashbotBoardSnapshot.self,
            from: encoder.encode(snapshot)), snapshot)
        XCTAssertEqual(String(data: try encoder.encode(KashbotLiveAttributes()), encoding: .utf8), "{\"v\":1}")
        XCTAssertNil(KashbotLiveStateBuilder.build(balance: nil, positions: [], markets: [],
                                                  settlements: [], now: Date()))
    }

    func testLegacyRowDecodesAndOmitsUnknownPnl() throws {
        let row = try decode(Row.self, #"{"ticker":"OLD","side":"yes","milli":1000,"state":"open"}"#)
        XCTAssertNil(row.pnlCents)
        let encoded = try JSONEncoder().encode(row)
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
        XCTAssertNil(object["pnlCents"])
    }

    func testOrderingCapsTruncationAndTodayBeforeLedgerCap() throws {
        let balance = try decode(AccountBalance.self, #"{"balance":1000,"portfolio_value":250}"#)
        var positions: [Position] = try ["D", "C", "B", "A"].map {
            try decode(Position.self, "{\"ticker\":\"\($0)\",\"position_fp\":\"-0.25\",\"market_exposure_dollars\":\"0.20\"}")
        }
        positions.append(try decode(Position.self, #"{"ticker":"ZERO","position_fp":"0"}"#))
        let settlements: [Settlement] = try (0..<25).map { index in
            try decode(Settlement.self, "{\"ticker\":\"S\(String(format: "%02d", index))\",\"yes_total_cost_dollars\":\"0.10\",\"no_total_cost_dollars\":\"0\",\"revenue\":25,\"settled_time\":\"2026-09-29T04:00:00Z\"}")
        }
        let now = try XCTUnwrap(ISO8601DateFormatter().date(from: "2026-09-29T12:00:00Z"))
        let snapshot = try XCTUnwrap(KashbotLiveStateBuilder.build(balance: balance,
            positions: positions, markets: [], settlements: settlements, now: now))
        XCTAssertEqual(snapshot.state.openCount, 4)
        XCTAssertEqual(snapshot.state.rows.map(\.ticker), ["A", "B", "C"])
        XCTAssertEqual(snapshot.state.ledger.map(\.ticker), ["S00", "S01", "S02", "S03"])
        XCTAssertEqual(snapshot.ledger.count, 20)
        XCTAssertEqual(snapshot.state.todayCents, 375)
        positions[0].marketExposureDollars = "0.30"
        let longTicker = String(repeating: "T", count: 50)
        positions[0].ticker = longTicker
        let market = try decode(Market.self, "{\"ticker\":\"\(longTicker)\",\"yes_sub_title\":\"\(String(repeating: "L", count: 40))\",\"result\":\"no\",\"status\":\"settled\"}")
        let changed = try XCTUnwrap(KashbotLiveStateBuilder.build(balance: balance,
            positions: positions, markets: [market], settlements: [], now: now))
        XCTAssertEqual(changed.state.rows.first?.ticker.count, 40)
        XCTAssertEqual(changed.state.rows.first?.label?.count, 32)
        XCTAssertEqual(changed.state.rows.first?.state, "won")
        XCTAssertEqual(changed.state.rows.first?.pnlCents, -5)
        var losing = market
        losing.result = "yes"
        XCTAssertEqual(KashbotLiveStateBuilder.build(balance: balance, positions: positions,
            markets: [losing], settlements: [], now: now)?.state.rows.first?.state, "lost")
        XCTAssertEqual(KashbotLiveStateBuilder.build(balance: balance, positions: positions,
            markets: [losing], settlements: [], now: now)?.state.rows.first?.pnlCents, -30)
    }

    func testRowsOrderByAbsoluteExposureBeforeTopThreeCap() throws {
        let balance = try decode(AccountBalance.self, #"{"balance":1000,"portfolio_value":250}"#)
        let positions = try [
            #"{"ticker":"YES1","position_fp":"1","market_exposure_dollars":"1.00"}"#,
            #"{"ticker":"YES2","position_fp":"2","market_exposure_dollars":"2.00"}"#,
            #"{"ticker":"YES3","position_fp":"3","market_exposure_dollars":"3.00"}"#,
            #"{"ticker":"NO5","position_fp":"-5","market_exposure_dollars":"-5.00"}"#
        ].map { try decode(Position.self, $0) }
        let snapshot = try XCTUnwrap(KashbotLiveStateBuilder.build(balance: balance,
            positions: positions, markets: [], settlements: [], now: Date(timeIntervalSince1970: 1790712000)))
        XCTAssertEqual(snapshot.state.openCount, 4)
        XCTAssertEqual(snapshot.state.rows.map(\.ticker), ["NO5", "YES3", "YES2"])
        XCTAssertEqual(snapshot.state.rows.first?.side, "no")
    }

    func testMaterialChangeRules() {
        let old = sample()
        XCTAssertTrue(old.isMaterialChange(from: nil))
        XCTAssertFalse(old.isMaterialChange(from: old))
        let mutations: [(inout State) -> Void] = [
            { $0.rows[0].ticker = "OTHER" }, { $0.rows[0].side = "no" },
            { $0.rows[0].milli += 1 }, { $0.openCount += 1 },
            { $0.rows[0].state = "won" },
            { $0.ledger = [.init(ticker: "A", pnlCents: 1, pnlBps: nil, at: 1)] },
            { $0.rows.append($0.rows[0]) }
        ]
        for mutate in mutations {
            var changed = old
            mutate(&changed)
            XCTAssertTrue(changed.isMaterialChange(from: old))
            XCTAssertTrue(old.isMaterialChange(from: changed))
        }
        var cosmetic = old
        cosmetic.rows[0].oddsPct = 60
        cosmetic.rows[0].winCents = -10
        cosmetic.rows[0].pnlCents = -12
        cosmetic.rows[0].label = "Updated label"
        cosmetic.totalCents += 1
        cosmetic.todayCents += 1
        cosmetic.asOf += 1
        XCTAssertFalse(cosmetic.isMaterialChange(from: old))
        var ledger = old
        ledger.ledger = [.init(ticker: "A", pnlCents: 1, pnlBps: 1, at: 1)]
        var changed = ledger
        changed.ledger[0].pnlCents = 2
        changed.ledger[0].pnlBps = 2
        changed.ledger.append(.init(ticker: "B", pnlCents: 1, pnlBps: nil, at: 0))
        XCTAssertFalse(changed.isMaterialChange(from: ledger))
        changed.ledger[0].at = 2
        XCTAssertTrue(changed.isMaterialChange(from: ledger))
        changed = ledger
        changed.ledger[0].ticker = "B"
        XCTAssertTrue(changed.isMaterialChange(from: ledger))
        var multiple = old
        var second = old.rows[0]
        second.ticker = "WIND"
        multiple.rows.append(second)
        var reversed = multiple
        reversed.rows.reverse()
        XCTAssertFalse(reversed.isMaterialChange(from: multiple))
    }

    func testMaximumPayloadSize() throws {
        let row = Row(ticker: String(repeating: "🟢", count: 40),
                      label: String(repeating: "🟢", count: 32), side: "yes", milli: Int.max,
                      winCents: Int.min, oddsPct: 99, state: "open", pnlCents: Int.min)
        let entry = Entry(ticker: String(repeating: "🟢", count: 40), pnlCents: Int.min,
                          pnlBps: Int.min, at: Int.max)
        let state = State(asOf: Int.max, totalCents: Int.min, todayCents: Int.min,
                          openCount: Int.max, rows: Array(repeating: row, count: 3),
                          ledger: Array(repeating: entry, count: 4))
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        XCTAssertLessThan(try encoder.encode(state).count + encoder.encode(KashbotLiveAttributes()).count, 4096)
    }

    func testStoreSaveLoadClearAndExpiry() throws {
        let defaults = try XCTUnwrap(UserDefaults(suiteName: KashbotBoardSnapshot.appGroup))
        let previous = defaults.object(forKey: KashbotBoardSnapshot.storageKey)
        defer {
            if let previous { defaults.set(previous, forKey: KashbotBoardSnapshot.storageKey) }
            else { defaults.removeObject(forKey: KashbotBoardSnapshot.storageKey) }
        }
        KashbotBoardStore.clear()
        XCTAssertNil(KashbotBoardStore.load())
        var state = sample()
        state.asOf = 100000
        let snapshot = KashbotBoardSnapshot(state: state, ledger: [])
        KashbotBoardStore.save(snapshot)
        XCTAssertEqual(KashbotBoardStore.load(now: Date(timeIntervalSince1970: 100000)), snapshot)
        XCTAssertNotNil(KashbotBoardStore.load(now: Date(timeIntervalSince1970: 186400)))
        XCTAssertNil(KashbotBoardStore.load(now: Date(timeIntervalSince1970: 186401)))
        XCTAssertNotNil(KashbotBoardStore.load(now: Date(timeIntervalSince1970: 99940)))
        XCTAssertNil(KashbotBoardStore.load(now: Date(timeIntervalSince1970: 99939)))
        XCTAssertTrue(KashbotBoardStore.clear())
        XCTAssertFalse(KashbotBoardStore.clear())
    }
}
