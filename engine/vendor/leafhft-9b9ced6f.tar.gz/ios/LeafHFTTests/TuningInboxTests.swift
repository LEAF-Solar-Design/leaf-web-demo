import Foundation
import UserNotifications
import XCTest
@testable import LeafHFT

extension TuningInboxTests {
    private func page(_ pending: Any?) throws -> TuningInboxWire.ListResponse {
        var object: [String: Any] = ["success": true, "items": []]
        if let pending { object["pending"] = pending }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return try decoder.decode(TuningInboxWire.ListResponse.self, from: JSONSerialization.data(withJSONObject: object))
    }

    func testMissingValidAndMalformedPending() throws {
        XCTAssertEqual(try page(nil).pending.count, 0)
        XCTAssertNil(try page(nil).pending.newest)
        let newest: [String: Any] = ["account": "00000001", "proposal_id": UUID().uuidString.lowercased(),
                                    "plan_seq": 1, "plan_sha256": String(repeating: "a", count: 64),
                                    "expires_at_ms": 123]
        let valid = try page(["count": 3, "newest": newest]).pending
        XCTAssertEqual(valid.count, 3)
        XCTAssertEqual(valid.newest?.account, "00000001")
        XCTAssertEqual(valid.newest?.planSeq, 1)
        for malformed in [NSNull(), "bad", true, 2, []] as [Any] {
            XCTAssertEqual(try page(malformed).pending.count, 0)
            XCTAssertNil(try page(malformed).pending.newest)
        }
        for count in [-1, 1.5, "3", true, NSNull()] as [Any] {
            let pending = try page(["count": count, "newest": newest]).pending
            XCTAssertEqual(pending.count, 0)
            XCTAssertEqual(pending.newest, valid.newest)
        }
        let invalid: [String: [Any]] = [
            "account": ["0000000A", "short", 1, NSNull()],
            "proposal_id": ["bad", UUID().uuidString.uppercased(), 1, NSNull()],
            "plan_seq": [0, -1, 1.5, "1", true, NSNull()],
            "plan_sha256": [String(repeating: "A", count: 64), "short", 1, NSNull()]
        ]
        for (field, values) in invalid {
            for value in values {
                var item = newest
                item[field] = value
                let pending = try page(["count": 3, "newest": item]).pending
                XCTAssertEqual(pending.count, 3, field)
                XCTAssertNil(pending.newest, field)
            }
            var item = newest
            item.removeValue(forKey: field)
            XCTAssertNil(try page(["count": 3, "newest": item]).pending.newest, field)
        }
        XCTAssertNil(try page(["count": 3, "newest": NSNull()]).pending.newest)
        XCTAssertNil(try page(["count": 3, "newest": "bad"]).pending.newest)
    }
}

private final class TuningHTTPStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                                                       httpVersion: nil, headerFields: nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

private final class EventLog { var events: [String] = [] }

private final class FakeTuningTransport: TuningInboxTransport {
    var detail: TuningInboxDetail
    var outcomes: [TuningDecisionOutcome] = []
    var submitted: [TuningDecisionRequest] = []
    var itemCalls = 0
    var itemError: Error?
    var itemSuspension: (@MainActor () async -> Void)?
    let log: EventLog

    init(detail: TuningInboxDetail, log: EventLog) {
        self.detail = detail
        self.log = log
    }

    func list(cursor: String?) async throws -> TuningInboxPage { TuningInboxPage(items: [detail.summary], nextCursor: nil) }

    func item(id: String) async throws -> TuningInboxDetail {
        itemCalls += 1
        log.events.append("fetch")
        if let itemSuspension { await itemSuspension() }
        if let itemError { throw itemError }
        return detail
    }

    func submitDecision(_ request: TuningDecisionRequest) async throws -> TuningDecisionOutcome {
        submitted.append(request)
        log.events.append("submit")
        return outcomes.isEmpty ? .accepted(code: "accepted") : outcomes.removeFirst()
    }
}

private final class PushActionRecorder: PushClientProtocol {
    var actions: [(Bool, AutopilotScope, String?)] = []
    func register(apnsToken: String) async throws {}
    func registerCapabilities(planContractMax: Int, buildNumber: Int?) async throws -> Int { 1 }
    func toggle(enabled: Bool, scope: AutopilotScope, eventID: String?) async throws -> AutopilotToggles {
        actions.append((enabled, scope, eventID))
        return AutopilotToggles(schema: "leafhft.autopilot-toggles.v1", accountId: "owner", enabledDefault: enabled, engines: [:])
    }
}

@MainActor final class TuningInboxTests: XCTestCase {
    private let live = FixtureMode(arguments: [])
    /// owner-accept-1's issued_at: plan-1 is frozen at ...200000 and expires 24 h later.
    private let issuedAt: Int64 = 1_790_683_201_000
    private var nowMs: Int64 = 1_790_683_201_000

    override func tearDown() {
        TuningHTTPStub.handler = nil
        super.tearDown()
    }

    // MARK: fixtures

    private func planEntry(_ id: String) throws -> [String: Any] { try TuningVectors.entry("plans", id) }

    private func detail(_ planID: String = "plan-1", state: TuningInboxState = .ready, syncAt: Int64? = 1_790_683_190_000,
                        advertised: String? = nil, version: Int64 = 7) throws -> TuningInboxDetail {
        let entry = try planEntry(planID)
        let document = try XCTUnwrap(entry["document"] as? [String: Any])
        let planSHA256 = try advertised ?? XCTUnwrap(entry["plan_sha256"] as? String)
        let summary = TuningInboxSummary(id: try XCTUnwrap(document["proposal_id"] as? String),
                                         account: try XCTUnwrap(document["account"] as? String),
                                         cycleID: try XCTUnwrap(document["cycle_id"] as? String),
                                         cycleKind: try XCTUnwrap(document["cycle_kind"] as? String),
                                         state: state, version: version,
                                         generatedAtMs: try TuningVectors.int(document["generated_at_ms"]),
                                         planSeq: try TuningVectors.int(document["plan_seq"]), resultCode: nil)
        return TuningInboxDetail(summary: summary,
                                 plan: TuningPlanEnvelope(planSeq: try TuningVectors.int(document["plan_seq"]),
                                                          planB64: try XCTUnwrap(entry["plan_b64"] as? String),
                                                          planSHA256: planSHA256),
                                 runnerSyncAtMs: syncAt)
    }

    private func date(_ ms: Int64) -> Date { Date(timeIntervalSince1970: TimeInterval(ms) / 1000) }

    func testV1LiveStateKeepsLiveWording() throws {
        let summary = try detail(state: .live).summary
        XCTAssertFalse(summary.isV2)
        XCTAssertEqual(summary.stateLabel, "Live")
        XCTAssertEqual(TuningInboxState(wire: "live").label, "Live")
    }

    func testDetailPollingIncludesLegacyNonterminalStatesAndPreservesV2Readback() throws {
        XCTAssertFalse(TuningInboxItemView.shouldPoll(summary: nil))
        for kind in ["owner_daily", "tenant_planned", "deployment_change"] {
            for state in [.proposed, .planning, .ready, .accepted, .executing,
                          .waitingWindow, .held, .approved, .applying] as [TuningInboxState] {
                let base = try detail(state: state).summary
                let summary = TuningInboxSummary(id: base.id, account: base.account, cycleID: base.cycleID,
                    cycleKind: kind, state: state, version: base.version, generatedAtMs: base.generatedAtMs,
                    planSeq: base.planSeq, resultCode: nil)
                XCTAssertTrue(TuningInboxItemView.shouldPoll(summary: summary), "\(kind): \(state)")
            }
            for state in [.executed, .live, .rejected, .superseded, .revoked,
                          .expired, .planRefused, .failed] as [TuningInboxState] {
                let base = try detail(state: state).summary
                let summary = TuningInboxSummary(id: base.id, account: base.account, cycleID: base.cycleID,
                    cycleKind: kind, state: state, version: base.version, generatedAtMs: base.generatedAtMs,
                    planSeq: base.planSeq, resultCode: nil)
                XCTAssertEqual(TuningInboxItemView.shouldPoll(summary: summary),
                               summary.isV2 && state == .executed, "\(kind): \(state)")
            }
        }
    }

    func testLegacyDetailReloadShowsPlanningReadinessAndExecutionWithoutWriting() async throws {
        let planning = try detail(state: .planning)
        let transport = FakeTuningTransport(detail: TuningInboxDetail(summary: planning.summary, plan: nil,
            runnerSyncAtMs: planning.runnerSyncAtMs), log: EventLog())
        let signer = SoftwareDecisionKey(scalar: 1)
        let model = makeModel(transport, signer: signer)
        await model.load()
        XCTAssertNil(model.plan)
        XCTAssertTrue(TuningInboxItemView.shouldPoll(summary: model.detail?.summary))
        for state in [.ready, .accepted, .executing, .executed] as [TuningInboxState] {
            transport.detail = try detail(state: state)
            await model.load()
            XCTAssertEqual(model.detail?.summary.state, state)
            XCTAssertNotNil(model.plan)
            XCTAssertEqual(TuningInboxItemView.shouldPoll(summary: model.detail?.summary), state != .executed)
        }
        XCTAssertEqual(transport.itemCalls, 5)
        XCTAssertTrue(transport.submitted.isEmpty)
        XCTAssertTrue(signer.signedMessages.isEmpty)
    }

    func testLegacyDetailPollingUsesFiveSecondClockAndStopsAtTerminalReadback() async throws {
        let transport = FakeTuningTransport(detail: try detail(state: .planning), log: EventLog())
        let signer = SoftwareDecisionKey(scalar: 1)
        let model = makeModel(transport, signer: signer)
        let loader = TuningInboxDetailLoader(model: model)
        await model.load()
        var states: [TuningInboxState] = [.ready, .accepted, .executing, .executed]
        var ticks = 0
        await loader.pollDetail { interval in
            XCTAssertEqual(interval, .seconds(5))
            XCTAssertEqual(transport.itemCalls, ticks + 1)
            guard !states.isEmpty else { throw CancellationError() }
            self.nowMs += 5_000
            transport.detail = try self.detail(state: states.removeFirst(), syncAt: self.nowMs)
            ticks += 1
        }
        XCTAssertTrue(states.isEmpty)
        XCTAssertEqual(ticks, 4)
        XCTAssertEqual(transport.itemCalls, 5)
        XCTAssertEqual(model.detail?.summary.state, .executed)
        await loader.pollDetail { _ in XCTFail("Terminal legacy details must not schedule another tick") }
        XCTAssertEqual(transport.itemCalls, 5)
        XCTAssertTrue(transport.submitted.isEmpty)
        XCTAssertTrue(signer.signedMessages.isEmpty)
    }

    func testDetailPollingCancelledSleepDoesNotFetch() async throws {
        let transport = FakeTuningTransport(detail: try detail(state: .planning), log: EventLog())
        let model = makeModel(transport, signer: nil)
        let loader = TuningInboxDetailLoader(model: model)
        await model.load()
        await loader.pollDetail { _ in throw CancellationError() }
        XCTAssertEqual(transport.itemCalls, 1)
    }

    func testManualRefreshReadsTerminalDetailAndReportsFailureWithoutWriting() async throws {
        let transport = FakeTuningTransport(detail: try detail(state: .executed), log: EventLog())
        let signer = SoftwareDecisionKey(scalar: 1)
        let model = makeModel(transport, signer: signer)
        let loader = TuningInboxDetailLoader(model: model)
        await model.load()
        self.nowMs += 1_000
        transport.detail = try detail(state: .executed, syncAt: nowMs, version: 8)
        let refreshed = await loader.refreshDetail()
        XCTAssertTrue(refreshed)
        XCTAssertEqual(model.detail?.summary.version, 8)
        XCTAssertEqual(model.detail?.runnerSyncAtMs, nowMs)
        XCTAssertEqual(transport.itemCalls, 2)
        transport.itemError = URLError(.notConnectedToInternet)
        let failed = await loader.refreshDetail()
        XCTAssertFalse(failed)
        XCTAssertNotNil(model.loadError)
        XCTAssertEqual(model.detail?.summary.version, 8, "Failed refresh preserves the last observed detail")
        XCTAssertEqual(transport.itemCalls, 3)
        transport.itemError = nil
        let recovered = await loader.refreshDetail()
        XCTAssertTrue(recovered)
        XCTAssertNil(model.loadError)
        XCTAssertEqual(transport.itemCalls, 4)
        XCTAssertTrue(transport.submitted.isEmpty)
        XCTAssertTrue(signer.signedMessages.isEmpty)
    }

    func testRefreshDuringInFlightLoadReportsSuccess() async throws {
        try await checkOverlappingDetailReads(shouldFail: false, initialIsRefresh: false)
    }

    func testRefreshDuringInFlightLoadReportsFailure() async throws {
        try await checkOverlappingDetailReads(shouldFail: true, initialIsRefresh: false)
    }

    func testOverlappingRefreshesRunOneLoad() async throws {
        try await checkOverlappingDetailReads(shouldFail: false, initialIsRefresh: true)
    }

    func testCancelledRefreshCallerStillReportsSuccessfulLoad() async throws {
        try await checkOverlappingDetailReads(shouldFail: false, initialIsRefresh: false, cancelRefresh: true)
    }

    private func checkOverlappingDetailReads(shouldFail: Bool, initialIsRefresh: Bool,
                                           cancelRefresh: Bool = false) async throws {
        let transport = FakeTuningTransport(detail: try detail(), log: EventLog())
        if shouldFail { transport.itemError = URLError(.notConnectedToInternet) }
        var finishRead: CheckedContinuation<Void, Never>?
        transport.itemSuspension = {
            await withCheckedContinuation { finishRead = $0 }
        }
        let model = makeModel(transport, signer: nil)
        let loader = TuningInboxDetailLoader(model: model)
        let first = Task {
            if initialIsRefresh { return await loader.refreshDetail() }
            return await loader.load()
        }
        while finishRead == nil { await Task.yield() }
        XCTAssertTrue(model.loading)
        XCTAssertEqual(transport.itemCalls, 1)
        var refreshStarted = false
        var refreshFinished = false
        let refresh = Task {
            refreshStarted = true
            let result = await loader.refreshDetail()
            refreshFinished = true
            return result
        }
        while !refreshStarted { await Task.yield() }
        XCTAssertFalse(refreshFinished, "Refresh must await the active read's outcome")
        XCTAssertEqual(transport.itemCalls, 1)
        if cancelRefresh { refresh.cancel() }
        finishRead?.resume()
        let firstResult = await first.value
        let refreshResult = await refresh.value
        XCTAssertEqual(firstResult, !shouldFail)
        XCTAssertEqual(refreshResult, !shouldFail)
        XCTAssertEqual(model.loadError != nil, shouldFail)
        XCTAssertFalse(model.loading)
        XCTAssertEqual(transport.itemCalls, 1)
        XCTAssertTrue(transport.submitted.isEmpty)
    }

    private func makeModel(_ transport: FakeTuningTransport, signer: SoftwareDecisionKey?, fixtureMode: FixtureMode? = nil,
                           ledger: TuningSubmissionLedger? = nil) -> TuningInboxItemModel {
        TuningInboxItemModel(proposalID: transport.detail.summary.id, fixtureMode: fixtureMode ?? live, transport: transport,
                             signingKey: { signer }, now: { [unowned self] in self.date(self.nowMs) },
                             ledger: ledger ?? TuningSubmissionLedger())
    }

    private func loadedModel(_ transport: FakeTuningTransport, signer: SoftwareDecisionKey?, fixtureMode: FixtureMode? = nil,
                             ledger: TuningSubmissionLedger? = nil) async throws -> TuningInboxItemModel {
        let model = makeModel(transport, signer: signer, fixtureMode: fixtureMode, ledger: ledger)
        await model.load()
        let plan = try XCTUnwrap(model.plan)
        model.markRendered(sha256: plan.sha256)
        return model
    }

    private func decodedBody(_ request: TuningDecisionRequest) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: request.body) as? [String: Any])
    }

    // MARK: plan bytes

    func testEveryVectorPlanHashesWithCryptoKitAndParsesCanonically() throws {
        for entry in try TuningVectors.entries("plans") {
            let id = try XCTUnwrap(entry["id"] as? String)
            let plan = try TuningVectors.verifiedPlan(id)
            XCTAssertTrue(plan.hashMatches, id)
            XCTAssertEqual(plan.sha256, entry["plan_sha256"] as? String, id)
            XCTAssertEqual(try TuningCanonicalParser.parse(plan.bytes, maxBytes: TuningInboxLimits.maxPlanBytes).canonicalBytes(),
                           plan.bytes, id)
            let document = try XCTUnwrap(entry["document"] as? [String: Any])
            XCTAssertEqual(plan.document.proposalID, document["proposal_id"] as? String, id)
            XCTAssertEqual(plan.document.runnerNonce, document["runner_nonce"] as? String, id)
            XCTAssertEqual(plan.document.account, document["account"] as? String, id)
            XCTAssertEqual(plan.document.expiresAtMs, try TuningVectors.int(document["expires_at_ms"]), id)
            XCTAssertEqual(plan.document.steps.count, (document["steps"] as? [Any])?.count, id)
            XCTAssertEqual(plan.document.engines.count, (document["engines"] as? [Any])?.count, id)
        }
        XCTAssertEqual(try TuningVectors.verifiedPlan("plan-1").document.restartSteps.count, 2)
        XCTAssertEqual(try TuningVectors.verifiedPlan("plan-3").document.restartSteps.count, 0, "tenants have no restarts")
    }

    private func planWithProbeCaps(nMaxTotal: Int64, waiverCapTotal: Int64) throws -> VerifiedTuningPlan {
        let original = try TuningVectors.verifiedPlan("plan-1").bytes
        var fields = try XCTUnwrap(TuningCanonicalParser.parse(original, maxBytes: TuningInboxLimits.maxPlanBytes).objectValue)
        fields["n_max_total"] = .int(nMaxTotal)
        fields["gates"] = .array([])
        fields["gate_waiver"] = .object(["waiver_id": .string("test-waiver"), "cap_total": .int(waiverCapTotal)])
        let bytes = try TuningJSON.object(fields).canonicalBytes()
        return try VerifiedTuningPlan.verify(bytes: bytes, advertisedSHA256: TuningSyntax.sha256Hex(bytes))
    }

    func testRegistryProbeCap512Decodes() throws {
        let plan = try planWithProbeCaps(nMaxTotal: 512, waiverCapTotal: 512)
        XCTAssertTrue(plan.hashMatches)
        XCTAssertEqual(plan.document.nMaxTotal, 512)
        XCTAssertEqual(try XCTUnwrap(plan.document.gateWaiver).capTotal, 512)
    }

    func testRegistryProbeCapCeiling1024Decodes() throws {
        let plan = try planWithProbeCaps(nMaxTotal: 1024, waiverCapTotal: 1024)
        XCTAssertEqual(plan.document.nMaxTotal, 1024)
        XCTAssertEqual(try XCTUnwrap(plan.document.gateWaiver).capTotal, 1024)
    }

    func testNMaxTotalAboveRegistryCeilingIsRefused() throws {
        XCTAssertThrowsError(try planWithProbeCaps(nMaxTotal: 1025, waiverCapTotal: 512)) {
            XCTAssertEqual($0 as? TuningPlanError, .schema("plan.n_max_total"))
        }
    }

    func testWaiverCapTotalAboveRegistryCeilingIsRefused() throws {
        XCTAssertThrowsError(try planWithProbeCaps(nMaxTotal: 512, waiverCapTotal: 1025)) {
            XCTAssertEqual($0 as? TuningPlanError, .schema("gate_waiver.cap_total"))
        }
    }

    func testNonCanonicalPlanBytesAreRefused() throws {
        let bytes = try TuningVectors.verifiedPlan("plan-1").bytes
        let text = String(decoding: bytes, as: UTF8.self)
        let mutations: [String] = [
            text.replacingOccurrences(of: "\"plan_seq\":1,", with: "\"plan_seq\":1.0,"),
            text.replacingOccurrences(of: "\"plan_seq\":1,", with: "\"plan_seq\":1e0,"),
            text.replacingOccurrences(of: "\"plan_seq\":1,", with: "\"plan_seq\":01,"),
            text.replacingOccurrences(of: "\"plan_seq\":1,", with: "\"plan_seq\": 1,"),
            text.replacingOccurrences(of: "{\"account\":", with: "{\"account\":\"00000001\",\"account\":"),
            text.replacingOccurrences(of: "\"wave\":1", with: "\"wave\":true"),
            text + " ",
            text.replacingOccurrences(of: "Test-only placement", with: "Test\\nonly placement"),
            text.replacingOccurrences(of: "Test-only placement", with: "Test\u{e9}only placement"),
        ]
        for mutated in mutations {
            XCTAssertNotEqual(mutated, text)
            XCTAssertThrowsError(try VerifiedTuningPlan.verify(bytes: Data(mutated.utf8),
                                                               advertisedSHA256: TuningSyntax.sha256Hex(Data(mutated.utf8))))
        }
        // Keys out of order are refused even when every value is valid.
        let swapped = text.replacingOccurrences(of: "{\"account\":\"00000001\",\"code_sha\":",
                                                with: "{\"code_sha\":\"1234567890abcdef1234567890abcdef12345678\",\"account\":\"00000001\",\"x\":")
        XCTAssertThrowsError(try VerifiedTuningPlan.verify(bytes: Data(swapped.utf8), advertisedSHA256: ""))
    }

    func testAFlippedPlanByteKeepsParsingButFailsTheHash() throws {
        let entry = try planEntry("plan-1")
        var bytes = try TuningVectors.verifiedPlan("plan-1").bytes
        let text = String(decoding: bytes, as: UTF8.self)
        let range = try XCTUnwrap(text.range(of: "Fixed fixture 1/1"))
        let offset = text.utf8.distance(from: text.startIndex, to: range.lowerBound)
        bytes[offset] = UInt8(ascii: "G")
        let plan = try VerifiedTuningPlan.verify(bytes: bytes, advertisedSHA256: try XCTUnwrap(entry["plan_sha256"] as? String))
        XCTAssertFalse(plan.hashMatches)
        XCTAssertNotEqual(plan.sha256, plan.advertisedSHA256)
    }

    func testOversizedAndMalformedBase64AreRefused() {
        XCTAssertThrowsError(try VerifiedTuningPlan.verify(planB64: "not base64!", advertisedSHA256: "")) {
            XCTAssertEqual($0 as? TuningPlanError, .base64)
        }
        let huge = Data(repeating: 0x20, count: TuningInboxLimits.maxPlanBytes + 1).base64EncodedString()
        XCTAssertThrowsError(try VerifiedTuningPlan.verify(planB64: huge, advertisedSHA256: "")) {
            XCTAssertEqual($0 as? TuningPlanError, .tooLarge)
        }
        let malformedHuge = "!" + huge.dropFirst()
        XCTAssertThrowsError(try VerifiedTuningPlan.verify(planB64: malformedHuge, advertisedSHA256: "")) {
            XCTAssertEqual($0 as? TuningPlanError, .tooLarge)
        }
        let oversizedEncoding = String(repeating: "!", count: huge.utf8.count + 1)
        XCTAssertThrowsError(try VerifiedTuningPlan.verify(planB64: oversizedEncoding, advertisedSHA256: "")) {
            XCTAssertEqual($0 as? TuningPlanError, .tooLarge)
        }
        let atLimit = Data(repeating: 0x20, count: TuningInboxLimits.maxPlanBytes).base64EncodedString()
        XCTAssertThrowsError(try VerifiedTuningPlan.verify(planB64: atLimit, advertisedSHA256: "")) {
            XCTAssertEqual($0 as? TuningPlanError, .notCanonical, "the size limit must allow decoding")
        }
    }

    func testDemoSamplePlanUsesTheSameVerifiedPath() throws {
        let detail = TuningInboxSample.detail(now: date(nowMs))
        let envelope = try XCTUnwrap(detail.plan)
        let plan = try VerifiedTuningPlan.verify(planB64: envelope.planB64, advertisedSHA256: envelope.planSHA256)
        XCTAssertTrue(plan.hashMatches)
        XCTAssertEqual(plan.document.proposalID, TuningInboxSample.proposalID)
        XCTAssertEqual(plan.document.retire, ["sample-old"])
        XCTAssertNotNil(plan.document.gateWaiver)
    }

    // MARK: accept gating

    private func gate(_ detail: TuningInboxDetail, rendered: Bool = true, now: Int64? = nil,
                      phase: TuningSubmitPhase = .idle, fixtureMode: FixtureMode? = nil) throws -> TuningAcceptGate {
        let envelope = try XCTUnwrap(detail.plan)
        let plan = try VerifiedTuningPlan.verify(planB64: envelope.planB64, advertisedSHA256: envelope.planSHA256)
        return TuningAcceptGate.evaluate(detail: detail, plan: plan, renderedSHA256: rendered ? plan.sha256 : nil,
                                         nowMs: now ?? nowMs, phase: phase, fixtureMode: fixtureMode ?? live)
    }

    func testAcceptIsEnabledOnlyWhenEveryConditionHolds() throws {
        XCTAssertTrue(try gate(try detail()).enabled)
        XCTAssertEqual(try gate(try detail(advertised: String(repeating: "0", count: 64))).reasons, [.hashMismatch])
        XCTAssertEqual(try gate(try detail(state: .accepted)).reasons, [.notReady])
        XCTAssertEqual(try gate(try detail(state: .proposed)).reasons, [.notReady])
        XCTAssertEqual(try gate(try detail(state: .unknown("new_state"))).reasons, [.notReady])
        XCTAssertEqual(try gate(try detail(), now: 1_790_769_600_000, phase: .idle).reasons.first, .planExpired)
        XCTAssertTrue(try gate(try detail(syncAt: nil), now: 1_790_683_201_000).reasons.contains(.runnerNotSyncing))
        XCTAssertEqual(try gate(try detail(syncAt: nowMs - 180_001)).reasons, [.runnerNotSyncing])
        XCTAssertTrue(try gate(try detail(syncAt: nowMs - 180_000)).enabled)
        XCTAssertEqual(try gate(try detail(syncAt: nowMs + 60_001)).reasons, [.runnerNotSyncing])
        XCTAssertEqual(try gate(try detail(), phase: .outcomeUnknown(message: "x")).reasons, [.outcomeUnknown])
        XCTAssertEqual(try gate(try detail(), phase: .signing).reasons, [.submitInFlight])
        XCTAssertEqual(try gate(try detail(), phase: .submitting).reasons, [.submitInFlight])
        XCTAssertEqual(try gate(try detail(), phase: .accepted(code: "accepted")).reasons, [.alreadyDecided])
        XCTAssertTrue(try gate(try detail(), phase: .failed(message: "x")).enabled)
        XCTAssertEqual(try gate(try detail(), rendered: false).reasons, [.notRendered])
        XCTAssertEqual(try gate(try detail(), fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])).reasons,
                       [.fixtureWithoutControlWalk])
        XCTAssertTrue(try gate(try detail(), fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1",
                                                                                  "-LEAFHFT_CONTROL_WALK", "1"])).enabled)
        let noPlan = TuningAcceptGate.evaluate(detail: nil, plan: nil, renderedSHA256: nil, nowMs: nowMs, phase: .idle,
                                               fixtureMode: live)
        XCTAssertFalse(noPlan.enabled)
        XCTAssertTrue(noPlan.reasons.contains(.planUnavailable))
    }

    func testAPlanForAnotherItemIsABindingMismatch() throws {
        let own = try detail("plan-1")
        let other = try detail("plan-2")
        let swapped = TuningInboxDetail(summary: own.summary, plan: other.plan, runnerSyncAtMs: own.runnerSyncAtMs)
        XCTAssertTrue(try gate(swapped).reasons.contains(.bindingMismatch))
    }

    // MARK: submit state machine

    func testAcceptFetchesAndHashesBeforeFaceIDThenSendsTheVectorDecisionBytes() async throws {
        let log = EventLog()
        let transport = FakeTuningTransport(detail: try detail(), log: log)
        let signer = SoftwareDecisionKey(scalar: 1)
        signer.onSign = { log.events.append("faceid") }
        let model = try await loadedModel(transport, signer: signer)
        XCTAssertTrue(model.gate.enabled)
        await model.accept()
        XCTAssertEqual(log.events, ["fetch", "faceid", "submit"])
        XCTAssertEqual(model.phase, .accepted(code: "accepted"))
        XCTAssertEqual(signer.reasons.count, 1)
        let vector = try TuningVectors.entry("decisions", "owner-accept-1")
        XCTAssertEqual(signer.signedMessages, [Data(try XCTUnwrap(vector["decision_ascii"] as? String).utf8)])
        let request = try XCTUnwrap(transport.submitted.first)
        let body = try decodedBody(request)
        XCTAssertEqual(Set(body.keys), ["request_id", "proposal_id", "plan_seq", "version", "verb", "assertion_b64"])
        XCTAssertEqual(body["verb"] as? String, "accept")
        XCTAssertEqual(body["version"] as? Int, 7)
        XCTAssertEqual(body["plan_seq"] as? Int, 1)
        XCTAssertEqual(body["proposal_id"] as? String, transport.detail.summary.id)
        XCTAssertEqual(body["request_id"] as? String, request.requestID)
        XCTAssertTrue(TuningSyntax.isUUID(request.requestID))
        let assertionData = try XCTUnwrap(Data(base64Encoded: try XCTUnwrap(body["assertion_b64"] as? String)))
        let assertion = try XCTUnwrap(JSONSerialization.jsonObject(with: assertionData) as? [String: Any])
        XCTAssertEqual(assertion["credential_id"] as? String, try TuningVectors.credentialID("operator"))
        let decision = try TuningVectors.decision(try XCTUnwrap(assertion["decision"] as? [String: Any]))
        XCTAssertEqual(try decision.messageBytes(), Data(try XCTUnwrap(vector["decision_ascii"] as? String).utf8))
        let signature = try XCTUnwrap(Data(base64Encoded: try XCTUnwrap(assertion["signature_b64"] as? String)))
        XCTAssertTrue(PresenceSPKI.signatureValid(spki: try TuningVectors.spki("operator"), signatureDER: signature,
                                                  message: try decision.messageBytes()))
        await model.accept()
        XCTAssertEqual(transport.submitted.count, 1, "a recorded decision cannot be sent again")
    }

    func testAcceptWaitsForTheRenderedPlan() async throws {
        let transport = FakeTuningTransport(detail: try detail(), log: EventLog())
        let signer = SoftwareDecisionKey(scalar: 1)
        let model = makeModel(transport, signer: signer)
        await model.load()
        XCTAssertEqual(model.gate.reasons, [.notRendered])
        await model.accept()
        XCTAssertTrue(signer.signedMessages.isEmpty)
        model.markRendered(sha256: String(repeating: "0", count: 64))
        XCTAssertEqual(model.gate.reasons, [.notRendered], "only the verified hash can arm Accept")
    }

    func testUnknownOutcomeShowsRetryAndNeverResubmitsOnItsOwn() async throws {
        let transport = FakeTuningTransport(detail: try detail(), log: EventLog())
        transport.outcomes = [.unknown(reason: "transport")]
        let signer = SoftwareDecisionKey(scalar: 1)
        let model = try await loadedModel(transport, signer: signer)
        await model.accept()
        XCTAssertEqual(model.phase, .outcomeUnknown(message: TuningAcceptGate.Reason.outcomeUnknown.message))
        XCTAssertTrue(model.phase.showsRetry)
        XCTAssertEqual(model.gate.reasons, [.outcomeUnknown])
        await model.accept()
        await model.load()
        try await Task.sleep(nanoseconds: 300_000_000)
        XCTAssertEqual(transport.submitted.count, 1, "no automatic resubmission")
        XCTAssertEqual(signer.signedMessages.count, 1)
        XCTAssertEqual(model.gate.reasons, [.outcomeUnknown], "a reload of the same ready plan keeps Accept disabled")
        await model.retry()
        XCTAssertEqual(transport.submitted.count, 2)
        XCTAssertEqual(transport.submitted[0], transport.submitted[1], "Retry replays the same request id and bytes")
        XCTAssertEqual(signer.signedMessages.count, 1, "a replay needs no second signature")
        XCTAssertEqual(model.phase, .accepted(code: "accepted"))
    }

    func testDefiniteRefusalShowsRetryWhichOnlyReloads() async throws {
        let transport = FakeTuningTransport(detail: try detail(), log: EventLog())
        transport.outcomes = [.refused(status: 409, code: "refused_signature")]
        let signer = SoftwareDecisionKey(scalar: 1)
        let model = try await loadedModel(transport, signer: signer)
        await model.accept()
        guard case .failed(let message) = model.phase else { return XCTFail("expected a failure, got \(model.phase)") }
        XCTAssertTrue(message.contains("signature was refused"))
        XCTAssertTrue(model.phase.showsRetry)
        let loads = transport.itemCalls
        await model.retry()
        XCTAssertEqual(transport.itemCalls, loads + 1)
        XCTAssertEqual(transport.submitted.count, 1, "Retry after a refusal never sends")
        XCTAssertEqual(model.phase, .idle)
        await model.accept()
        XCTAssertEqual(signer.signedMessages.count, 2, "a new accept asks Face ID again")
        XCTAssertEqual(transport.submitted.count, 2)
        XCTAssertNotEqual(transport.submitted[0].requestID, transport.submitted[1].requestID)
    }

    func testUnknownOutcomeSurvivesReopeningTheItem() async throws {
        let ledger = TuningSubmissionLedger()
        let transport = FakeTuningTransport(detail: try detail(), log: EventLog())
        transport.outcomes = [.unknown(reason: "http_503")]
        let first = try await loadedModel(transport, signer: SoftwareDecisionKey(scalar: 1), ledger: ledger)
        await first.accept()
        let reopened = try await loadedModel(transport, signer: SoftwareDecisionKey(scalar: 1), ledger: ledger)
        XCTAssertEqual(reopened.gate.reasons, [.outcomeUnknown])
        await reopened.retry()
        XCTAssertEqual(transport.submitted.count, 2)
        XCTAssertEqual(transport.submitted[0], transport.submitted[1])
        // Once the server shows the item moved on, the unknown outcome is settled.
        transport.outcomes = [.unknown(reason: "transport")]
        let again = try await loadedModel(transport, signer: SoftwareDecisionKey(scalar: 1), ledger: ledger)
        XCTAssertEqual(again.phase, .idle)
        await again.accept()
        transport.detail = try detail(state: .accepted)
        await again.load()
        XCTAssertEqual(again.phase, .idle)
        XCTAssertNil(ledger.unresolved(proposalID: transport.detail.summary.id, planSeq: 1))
    }

    func testMissingKeyOrHashMismatchNeverSigns() async throws {
        let missing = FakeTuningTransport(detail: try detail(), log: EventLog())
        let noKey = try await loadedModel(missing, signer: nil)
        await noKey.accept()
        guard case .failed = noKey.phase else { return XCTFail("expected a failure") }
        XCTAssertTrue(missing.submitted.isEmpty)

        let tampered = FakeTuningTransport(detail: try detail(advertised: String(repeating: "0", count: 64)), log: EventLog())
        let signer = SoftwareDecisionKey(scalar: 1)
        let model = try await loadedModel(tampered, signer: signer)
        XCTAssertTrue(model.gate.reasons.contains(.hashMismatch))
        await model.accept()
        XCTAssertTrue(signer.signedMessages.isEmpty)
        XCTAssertTrue(tampered.submitted.isEmpty)
    }

    func testDemoModeWithoutControlWalkCannotAcceptAndControlWalkNeverSigns() async throws {
        let transport = FakeTuningTransport(detail: try detail(), log: EventLog())
        let signer = SoftwareDecisionKey(scalar: 1)
        let demo = try await loadedModel(transport, signer: signer, fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]))
        await demo.accept()
        XCTAssertEqual(demo.phase, .idle)
        let walk = try await loadedModel(transport, signer: signer,
                                         fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_CONTROL_WALK", "1"]))
        await walk.accept()
        XCTAssertEqual(walk.phase, .accepted(code: "fixture_sample"))
        XCTAssertTrue(signer.signedMessages.isEmpty)
        XCTAssertTrue(transport.submitted.isEmpty)
    }

    // MARK: client wire

    private func client() -> TuningInboxClient {
        TuningInboxClient(fixtureMode: live, protocolClasses: [TuningHTTPStub.self], token: { "device-token" })
    }

    private func itemJSON(_ detail: TuningInboxDetail) throws -> Data {
        let plan = try XCTUnwrap(detail.plan)
        let sync: NSObject = detail.runnerSyncAtMs.map { NSNumber(value: $0) } ?? NSNull()
        let item: [String: Any] = [
            "id": detail.summary.id, "account": detail.summary.account, "cycle_id": detail.summary.cycleID,
            "cycle_kind": detail.summary.cycleKind, "state": "ready", "version": detail.summary.version,
            "generated_at_ms": detail.summary.generatedAtMs, "plan_seq": plan.planSeq,
            "plan": ["plan_seq": plan.planSeq, "plan_b64": plan.planB64, "plan_sha256": plan.planSHA256],
            "runner_sync_at_ms": sync,
        ]
        return try JSONSerialization.data(withJSONObject: ["success": true, "code": "ok", "item": item])
    }

    func testItemReadIsAScopedGetWithBearerAndDecodesTheExactBytes() async throws {
        let expected = try detail()
        TuningHTTPStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/tuning-inbox")
            XCTAssertEqual(request.url?.query, "id=" + expected.summary.id)
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            XCTAssertNil(request.httpBody)
            return (200, try self.itemJSON(expected))
        }
        let fetched = try await client().item(id: expected.summary.id)
        XCTAssertEqual(fetched, expected)
    }

    func testListAsksForABoundedPage() async throws {
        let expected = try detail()
        TuningHTTPStub.handler = { request in
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/tuning-inbox")
            XCTAssertEqual(request.url?.query, "limit=20")
            let summary: [String: Any] = [
                "id": expected.summary.id, "account": expected.summary.account, "cycle_id": expected.summary.cycleID,
                "cycle_kind": expected.summary.cycleKind, "state": "ready", "version": 7,
                "generated_at_ms": expected.summary.generatedAtMs,
            ]
            return (200, try JSONSerialization.data(withJSONObject: ["success": true, "items": [summary], "next_cursor": NSNull()]))
        }
        let page = try await client().list(cursor: nil)
        XCTAssertEqual(page.items.map(\.id), [expected.summary.id])
        XCTAssertNil(page.nextCursor)
    }

    func testOversizedOrMalformedItemRepliesAreRefused() async throws {
        let id = try detail().summary.id
        TuningHTTPStub.handler = { _ in (200, Data(repeating: 0x20, count: TuningInboxLimits.maxItemResponseBytes + 1)) }
        do { _ = try await client().item(id: id); XCTFail("oversized reply accepted") }
        catch { XCTAssertEqual(error as? DashboardClientError, .decoding) }
        TuningHTTPStub.handler = { _ in (200, Data(#"{"success":true,"item":{"id":"not-a-uuid"}}"#.utf8)) }
        do { _ = try await client().item(id: id); XCTFail("malformed reply accepted") }
        catch { XCTAssertEqual(error as? DashboardClientError, .decoding) }
        do { _ = try await client().item(id: "../../etc"); XCTFail("path id accepted") }
        catch { XCTAssertEqual(error as? DashboardClientError, .decoding) }
    }

    func testDecisionPostCarriesTheFrozenBytesAndClassifiesOutcomes() async throws {
        let signer = SoftwareDecisionKey(scalar: 1)
        let plan = try TuningVectors.verifiedPlan("plan-1")
        let signed = try await DecisionSigner(key: signer).signAccept(plan: plan, issuedAtMs: issuedAt, reason: "x")
        let request = try TuningDecisionRequest.accept(requestID: "11111111-1111-4111-8111-111111111111",
                                                       proposalID: plan.document.proposalID, planSeq: 1, version: 7,
                                                       assertion: signed)
        var replies: [(Int, Data)] = [
            (200, Data(#"{"success":true,"code":"accepted","state":"accepted"}"#.utf8)),
            (409, Data(#"{"success":false,"code":"refused_signature"}"#.utf8)),
            (503, Data(#"{"success":false,"code":"runner_unconfigured"}"#.utf8)),
            (200, Data("not json".utf8)),
            (408, Data()),
        ]
        TuningHTTPStub.handler = { urlRequest in
            XCTAssertEqual(urlRequest.httpMethod, "POST")
            XCTAssertEqual(urlRequest.url?.path, "/api/leafhft/mobile/tuning-inbox/\(plan.document.proposalID)/decision")
            XCTAssertEqual(urlRequest.value(forHTTPHeaderField: "Content-Type"), "application/json")
            XCTAssertEqual(urlRequest.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            return replies.removeFirst()
        }
        let client = client()
        let accepted = try await client.submitDecision(request)
        XCTAssertEqual(accepted, .accepted(code: "accepted"))
        let refused = try await client.submitDecision(request)
        XCTAssertEqual(refused, .refused(status: 409, code: "refused_signature"))
        let unavailable = try await client.submitDecision(request)
        XCTAssertEqual(unavailable, .unknown(reason: "http_503"))
        let unreadable = try await client.submitDecision(request)
        XCTAssertEqual(unreadable, .unknown(reason: "unreadable_reply"))
        let timedOut = try await client.submitDecision(request)
        XCTAssertEqual(timedOut, .unknown(reason: "http_408"))
        TuningHTTPStub.handler = { _ in throw URLError(.networkConnectionLost) }
        let lost = try await client.submitDecision(request)
        XCTAssertEqual(lost, .unknown(reason: "transport"))
        XCTAssertLessThanOrEqual(request.body.count, TuningInboxLimits.maxDecisionBodyBytes)
    }

    func testDemoClientNeverReachesTheNetwork() async throws {
        let demo = TuningInboxClient(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
                                     protocolClasses: [TuningHTTPStub.self], token: { "device-token" })
        TuningHTTPStub.handler = { _ in XCTFail("demo mode reached the network"); return (500, Data()) }
        do { _ = try await demo.list(cursor: nil); XCTFail("demo list reached the network") } catch {}
        let fixture = TuningInboxFixtureTransport(now: { [unowned self] in self.date(self.nowMs) })
        let page = try await fixture.list(cursor: nil)
        XCTAssertEqual(page.items.map(\.id), [TuningInboxSample.proposalID])
    }

    // MARK: notifications

    func testTuningReviewCategoryAndAutopilotDecisionStillRegister() {
        let categories = Dictionary(uniqueKeysWithValues: PushRegistrar.notificationCategories().map { ($0.identifier, $0) })
        XCTAssertEqual(Set(categories.keys), ["ASSISTANT_INBOX", "AUTOPILOT_DECISION", "candidate_ready", "tuning_confirm_request"])
        XCTAssertEqual(categories["AUTOPILOT_DECISION"]?.actions.map(\.identifier),
                       [PushRegistrar.keepOn, PushRegistrar.turnOff])
        XCTAssertEqual(categories["candidate_ready"]?.actions.count, 0)
        XCTAssertEqual(categories["tuning_confirm_request"]?.actions.map(\.identifier), [PushRegistrar.reviewTuning])
    }

    func testTuningPushesOnlyOpenTheirItem() async throws {
        let id = try detail().summary.id
        for category in [PushRegistrar.candidateReady, PushRegistrar.tuningConfirmRequest] {
            let client = PushActionRecorder()
            var opened: [TuningInboxTarget?] = []
            let registrar = PushRegistrar(fixtureMode: live, client: client, openTuningItem: { opened.append($0) })
            try await registrar.handleAction(UNNotificationDefaultActionIdentifier,
                                             userInfo: ["proposal_id": id, "event_id": "12345678-1234-1234-1234-123456789abc"],
                                             category: category)
            XCTAssertEqual(opened, [TuningInboxTarget(proposalID: id, category: category)])
            XCTAssertTrue(registrar.showAutopilot)
            // No action identifier on a tuning push can write anything, even one borrowed from AUTOPILOT_DECISION.
            try await registrar.handleAction(PushRegistrar.keepOn, userInfo: ["event_id": "12345678-1234-1234-1234-123456789abc"],
                                             category: category)
            try await registrar.handleAction(PushRegistrar.turnOff, userInfo: ["event_id": "12345678-1234-1234-1234-123456789abc"],
                                             category: category)
            XCTAssertTrue(client.actions.isEmpty)
            XCTAssertEqual(opened.count, 1)
        }
    }

    func testReviewAndDefaultTuningActionsOpenTheSamePayloadTargetWithoutClientCalls() async throws {
        let id = TuningInboxSample.proposalID
        let hash = String(repeating: "a", count: 64)
        for category in PushRegistrar.tuningCategories {
            for seq in [2, NSNumber(value: 2), NSNumber(value: 2.0)] as [Any] {
                let client = PushActionRecorder()
                var opened: [TuningInboxTarget?] = []
                let registrar = PushRegistrar(fixtureMode: live, client: client, openTuningItem: { opened.append($0) })
                let payload: [AnyHashable: Any] = ["proposal_id": id, "plan_seq": seq, "plan_sha256": hash]
                for action in [UNNotificationDefaultActionIdentifier, PushRegistrar.reviewTuning] {
                    try await registrar.handleAction(action, userInfo: payload, category: category)
                }
                XCTAssertEqual(opened.count, 2)
                XCTAssertEqual(opened[0], opened[1])
                let target = try XCTUnwrap(opened[0])
                XCTAssertEqual(target.proposalID, id)
                XCTAssertEqual(target.category, category)
                XCTAssertEqual(target.planSeq, 2)
                XCTAssertEqual(target.planSHA256, hash)
                XCTAssertTrue(client.actions.isEmpty)
                XCTAssertTrue(registrar.showAutopilot)
            }
        }
    }

    func testMalformedNotificationMetadataStillOpensReview() async throws {
        for category in PushRegistrar.tuningCategories {
            for action in [UNNotificationDefaultActionIdentifier, PushRegistrar.reviewTuning] {
                let client = PushActionRecorder()
                var opened: [TuningInboxTarget?] = []
                let registrar = PushRegistrar(fixtureMode: live, client: client, openTuningItem: { opened.append($0) })
                try await registrar.handleAction(action,
                    userInfo: ["proposal_id": TuningInboxSample.proposalID, "plan_seq": 1.5, "plan_sha256": "BAD"],
                    category: category)
                let target = try XCTUnwrap(opened[0])
                XCTAssertNil(target.planSeq)
                XCTAssertNil(target.planSHA256)
                try await registrar.handleAction(action, userInfo: ["proposal_id": "invalid"], category: category)
                XCTAssertEqual(opened.count, 2)
                XCTAssertNil(opened[1])
                XCTAssertTrue(client.actions.isEmpty)
            }
        }
    }

    func testNotificationTargetDropsMalformedOptionalFieldsIndependently() throws {
        let hash = String(repeating: "a", count: 64)
        for seq in [0, -1, "2", NSNumber(value: 1.5), NSNumber(value: true), NSNumber(value: Double.infinity)] as [Any] {
            let target = try XCTUnwrap(TuningInboxTarget(userInfo: ["proposal_id": TuningInboxSample.proposalID,
                "plan_seq": seq, "plan_sha256": hash], category: "x"))
            XCTAssertNil(target.planSeq)
            XCTAssertEqual(target.planSHA256, hash)
        }
        for badHash in [String(repeating: "A", count: 64), String(repeating: "a", count: 63), 42] as [Any] {
            let target = try XCTUnwrap(TuningInboxTarget(userInfo: ["proposal_id": TuningInboxSample.proposalID,
                "plan_seq": 2, "plan_sha256": badHash], category: "x"))
            XCTAssertEqual(target.planSeq, 2)
            XCTAssertNil(target.planSHA256)
        }
    }

    func testNotificationPlanChangedUsesBothFetchedValues() throws {
        let hash = String(repeating: "a", count: 64)
        let otherHash = String(repeating: "b", count: 64)
        let target = try XCTUnwrap(TuningInboxTarget(userInfo: ["proposal_id": TuningInboxSample.proposalID,
            "plan_seq": 2, "plan_sha256": hash], category: "x"))
        XCTAssertEqual(target.id, target.proposalID)
        XCTAssertFalse(target.planChanged(fetchedSeq: 2, fetchedSHA256: hash))
        XCTAssertTrue(target.planChanged(fetchedSeq: 3, fetchedSHA256: hash))
        XCTAssertTrue(target.planChanged(fetchedSeq: 2, fetchedSHA256: otherHash))
        XCTAssertTrue(target.planChanged(fetchedSeq: 3, fetchedSHA256: otherHash))
        let plain = try XCTUnwrap(TuningInboxTarget(proposalID: target.proposalID, category: "x"))
        XCTAssertFalse(plain.planChanged(fetchedSeq: 3, fetchedSHA256: otherHash))
        XCTAssertNotEqual(target, plain)
        let changed = try XCTUnwrap(TuningInboxTarget(userInfo: ["proposal_id": target.proposalID,
            "plan_seq": 3, "plan_sha256": hash], category: "x"))
        let changedHash = try XCTUnwrap(TuningInboxTarget(userInfo: ["proposal_id": target.proposalID,
            "plan_seq": 2, "plan_sha256": otherHash], category: "x"))
        XCTAssertEqual(Set([target, plain, changed, changedHash]).count, 4)
    }

    func testMalformedTuningPushOpensTheInboxWithoutATarget() async throws {
        var opened: [TuningInboxTarget?] = []
        let registrar = PushRegistrar(fixtureMode: live, client: PushActionRecorder(), openTuningItem: { opened.append($0) })
        await registrar.performAction(UNNotificationDefaultActionIdentifier, userInfo: ["proposal_id": "../x"],
                                      category: PushRegistrar.tuningConfirmRequest)
        XCTAssertEqual(opened.count, 1)
        XCTAssertNil(opened[0])
        XCTAssertTrue(registrar.showAutopilot)
        XCTAssertNil(registrar.actionError)
    }

    func testAutopilotDecisionActionsStillToggleWithACategory() async throws {
        let client = PushActionRecorder()
        var opened = 0
        let registrar = PushRegistrar(fixtureMode: live, client: client, openTuningItem: { _ in opened += 1 })
        try await registrar.handleAction(PushRegistrar.turnOff, userInfo: ["account_id": "owner",
                                         "event_id": "12345678-1234-1234-1234-123456789abc"], category: PushRegistrar.category)
        XCTAssertEqual(client.actions.count, 1)
        XCTAssertEqual(opened, 0)
    }

    func testDemoModeIgnoresTuningPushes() async throws {
        var opened = 0
        let registrar = PushRegistrar(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
                                      client: PushActionRecorder(), openTuningItem: { _ in opened += 1 })
        try await registrar.handleAction(UNNotificationDefaultActionIdentifier,
                                         userInfo: ["proposal_id": try detail().summary.id],
                                         category: PushRegistrar.candidateReady)
        XCTAssertEqual(opened, 0)
        XCTAssertFalse(registrar.showAutopilot)
    }

    func testRouterHandsATargetToOneScreen() {
        let router = TuningInboxRouter()
        let target = TuningInboxTarget(proposalID: "00000000-0000-4000-8000-000000000001", category: PushRegistrar.candidateReady)
        router.open(target)
        XCTAssertEqual(router.consume(), target)
        XCTAssertNil(router.consume())
        XCTAssertNil(TuningInboxTarget(proposalID: "00000000-0000-4000-8000-00000000000G", category: "x"))
    }
}
