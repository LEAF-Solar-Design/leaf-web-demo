import Foundation
import XCTest
@testable import LeafHFT

@MainActor final class KashbotKitTransportTests: XCTestCase {
    private let mode = FixtureMode(arguments: [])
    private let sessionId = MushyClient.fixtureSessionId
    private let turnId = MushyClient.fixtureArtifactId
    private let root = "/api/kashbot/assistant/v1"
    private let prompt = "How much cash do I have?"
    private let answer = "You have **$238.81** in cash and $412.10 in total. Here is your account this week."
    private let at = "2026-09-26T12:00:00.000Z"

    override func tearDown() { MushyStub.handler = nil; super.tearDown() }

    private func data(_ object: Any) throws -> Data {
        try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
    }

    private func reason(_ code: String, text: String = "Try again.") -> [String: Any] {
        ["code": code, "text": text, "next": ["label": "Try again", "action": "retry"]]
    }

    private func turn(_ seq: Int, _ state: String, id: String? = nil,
                      reason: [String: Any]? = nil) -> [String: Any] {
        var event: [String: Any] = ["type": "turn", "session_id": sessionId, "seq": seq,
            "at": at, "requires_action": false, "turn_id": id ?? turnId, "state": state]
        if let reason { event["reason"] = reason }
        return event
    }

    private func item(_ seq: Int, suffix: String, itemSeq: Int? = nil,
                      blocks: [[String: Any]], id: String? = nil) -> [String: Any] {
        ["type": "item", "session_id": sessionId, "seq": seq, "at": at, "requires_action": false,
         "item": ["seq": itemSeq ?? seq, "item_id": (id ?? turnId) + suffix,
                  "turn_id": id ?? turnId, "role": "assistant", "at": at, "blocks": blocks]]
    }

    private func textItem(_ seq: Int, _ text: String, itemSeq: Int = 14) -> [String: Any] {
        item(seq, suffix: ":answer", itemSeq: itemSeq, blocks: [["type": "text", "text": text]])
    }

    private func toolItem(_ seq: Int, suffix: String, state: String) -> [String: Any] {
        item(seq, suffix: suffix, blocks: [["type": "tools", "tools": [[
            "invocation_id": "legacy-tool-1", "name": "account_summary",
            "label": "Checking your balance", "state": state
        ]]]])
    }

    private func page(_ events: [[String: Any]], next: Int) throws -> Data {
        try data(["events": events, "next_after": next])
    }

    private func fixturePage(after: Int) throws -> Data {
        switch after {
        case 0: return try page([turn(2, "queued"), turn(4, "running"), turn(6, "running")], next: 7)
        case 7: return try page([toolItem(8, suffix: ":4", state: "running"),
            toolItem(10, suffix: ":5", state: "done"), turn(12, "running")], next: 13)
        case 13: return try page([textItem(14, "You have **$238.81**"), textItem(18, answer)], next: 19)
        case 19: return try page([textItem(22, answer), turn(23, "done")], next: 23)
        default: XCTFail("Unexpected Kit cursor \(after)"); return try page([turn(24, "done")], next: 24)
        }
    }

    private func after(_ request: URLRequest) -> Int {
        let query = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems
        return Int(query?.first(where: { $0.name == "after" })?.value ?? "-1") ?? -1
    }

    private func legacyData(_ page: AssistantEventsPage) throws -> Data {
        let events: [[String: Any]] = try page.events.map { event in
            let payload: [String: Any]
            switch event.payload {
            case .status(let stage): payload = ["stage": stage]
            case .text(let delta): payload = ["delta": delta]
            case .tool(let id, let name, let label, let state):
                payload = ["id": id, "name": name, "label": label, "state": state]
            case .view(let title, let panels):
                payload = ["title": title, "panels": try JSONSerialization.jsonObject(with: MushyCoding.encoder().encode(panels))]
            case .error(let message): payload = ["message": message]
            case .done(let text): payload = ["text": text]
            case .unknown: payload = [:]
            }
            return ["seq": event.seq, "type": event.type, "payload": payload]
        }
        return try data(["job_id": page.jobId, "status": page.status, "events": events, "next": page.next])
    }

    private func run(kit: Bool, text: String = "How much cash do I have?", engine: Bool = false,
                     supportsEngine: Bool = true, token: @escaping () throws -> String = { "test-device" },
                     respond: @escaping (URLRequest) throws -> (Int, Data)? = { _ in nil }) async throws
        -> (conversation: AssistantConversation, requests: [URLRequest]) {
        let suite = "kit-transport-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite); MushyStub.handler = nil }
        let encoder = MushyCoding.encoder()
        var snapshot = MushyClient.fixtureSnapshot
        snapshot.jobs = []
        var catalog = try XCTUnwrap(JSONSerialization.jsonObject(with: encoder.encode(MushyClient.fixtureCatalog)) as? [String: Any])
        if !supportsEngine {
            catalog["capabilities"] = MushyClient.fixtureCatalog.capabilities.filter { $0 != "assistant.engine" }
        }
        let catalogData = try data(catalog)
        // Obtain the legacy wire pages from the existing fixture implementation.
        let fixture = MushyClient(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]))
        var legacyPages: [Int: Data] = [:]
        if !kit || engine || !KashbotKitTransport.fits(text) {
            for cursor in [0, 3, 6, 9] {
                let page = try await fixture.assistantEvents(turnId, after: cursor, wait: 15, identity: "fixture")
                legacyPages[cursor] = try legacyData(page)
            }
        }
        var requests: [URLRequest] = []
        MushyStub.handler = { request in
            requests.append(request)
            guard requests.count <= 30 else { XCTFail("Polling did not terminate"); return (500, Data()) }
            if let response = try respond(request) { return response }
            switch request.url?.path {
            case "/api/leafhft/mobile/engines": return (200, catalogData)
            case MushyClient.root + "/state": return (200, try encoder.encode(snapshot))
            case MushyClient.root + "/assistant/turn":
                return (200, try encoder.encode(AssistantTurnReceipt(jobId: self.turnId, status: "pending")))
            case MushyClient.root + "/assistant/jobs/" + self.turnId + "/events":
                return (200, try XCTUnwrap(legacyPages[self.after(request)]))
            case self.root + "/sessions/" + self.sessionId + "/turns":
                return (202, try self.data(self.turn(2, "queued")))
            case self.root + "/turns/" + self.turnId + "/events":
                return (200, try self.fixturePage(after: self.after(request)))
            case self.root + "/turns/" + self.turnId + "/cards":
                XCTAssertEqual(request.httpMethod, "GET")
                return (200, try self.data(["schema": "kashbot.assistant.cards.v1", "cards": [[
                    "card_id": "card-home", "card_digest": String(repeating: "a", count: 64),
                    "kind": "slot_promotion", "title": "Save view to slot home",
                    "fields": [["key": "slot", "label": "Slot", "value": "home"]],
                    "state": "open", "expires_at": "2026-09-28T21:00:00.000Z"
                ]]]))
            default: XCTFail("Unexpected route \(request.url?.path ?? "nil")"); return (404, Data())
            }
        }
        let client = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: token)
        let studio = MushyState(fixtureMode: mode, client: client, defaults: defaults)
        await studio.refresh()
        let conversation = AssistantConversation(fixtureMode: mode, client: client, kitRoutes: kit)
        conversation.setEngineBuilding(engine)
        await conversation.send(text, studio: studio)
        return (conversation, requests)
    }

    func testFlagDefaultsOffAndFixtureModeForcesOff() async throws {
        let suite = "kit-flag-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        XCTAssertFalse(KashbotKitFlag.enabled(fixtureMode: mode, defaults: defaults))
        defaults.set(true, forKey: KashbotKitFlag.defaultsKey)
        #if DEBUG
        XCTAssertTrue(KashbotKitFlag.enabled(fixtureMode: mode, defaults: defaults))
        #else
        XCTAssertFalse(KashbotKitFlag.enabled(fixtureMode: mode, defaults: defaults))
        #endif
        let fixtureMode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])
        XCTAssertFalse(KashbotKitFlag.enabled(fixtureMode: fixtureMode, defaults: defaults))
        MushyStub.handler = { _ in XCTFail("Fixture opened a network route"); return (500, Data()) }
        let client = MushyClient(fixtureMode: fixtureMode, protocolClasses: [MushyStub.self],
            token: { XCTFail("Fixture read bearer"); return "" })
        let studio = MushyState(fixtureMode: fixtureMode, client: client, defaults: defaults)
        let conversation = AssistantConversation(fixtureMode: fixtureMode, client: client, kitRoutes: true)
        await conversation.send(prompt, studio: studio)
        XCTAssertEqual(conversation.activeReply?.text, answer)
        XCTAssertEqual(conversation.activeReply?.finished, true)
        XCTAssertEqual(conversation.activeReply?.views.count, 1)
        XCTAssertEqual(conversation.cursor, 11)
        XCTAssertEqual(conversation.kitCursor, 0)
    }

    func testFlagOffUsesLegacyTurnsAndOnlyFetchesKitCardsAfterDone() async throws {
        let result = try await run(kit: false)
        let kitRequests = result.requests.filter { $0.url!.path.contains("/api/kashbot/") }
        XCTAssertEqual(kitRequests.map { $0.url!.path }, [root + "/turns/" + turnId + "/cards"])
        XCTAssertEqual(kitRequests.map { $0.httpMethod }, ["GET"])
        XCTAssertEqual(result.requests.last?.url?.path, root + "/turns/" + turnId + "/cards")
        let events = result.requests.filter { $0.url!.path == MushyClient.root + "/assistant/jobs/" + turnId + "/events" }
        XCTAssertEqual(events.map(after), [0, 3, 6, 9])
        XCTAssertTrue(result.requests.contains { $0.url!.path == MushyClient.root + "/assistant/turn" })
        XCTAssertEqual(result.conversation.activeReply?.text, answer)
        XCTAssertEqual(result.conversation.activeReply?.finished, true)
        XCTAssertEqual(result.conversation.activeReply?.cards.first?.state, .open)
    }

    func testFlagOffApprovesKitCardOnlyAfterExplicitTap() async throws {
        let result = try await run(kit: false)
        XCTAssertEqual(result.requests.filter { $0.httpMethod == "POST" }.map { $0.url!.path },
                       [MushyClient.root + "/assistant/turn"])
        let card = try XCTUnwrap(result.conversation.activeReply?.cards.first)
        var requests: [URLRequest] = []
        MushyStub.handler = { request in
            requests.append(request)
            XCTAssertEqual(request.url?.path, self.root + "/cards/card-home/approve")
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-device")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Content-Type"), "application/json")
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: MushyStub.body(request)) as? [String: String])
            XCTAssertEqual(Set(body.keys), ["card_digest", "request_id"])
            XCTAssertEqual(body["card_digest"], card.cardDigest)
            let id = try XCTUnwrap(body["request_id"])
            XCTAssertNotNil(UUID(uuidString: id))
            XCTAssertEqual(id, id.lowercased())
            return (200, Data())
        }
        await result.conversation.approve(card: card)
        XCTAssertEqual(requests.count, 1)
        XCTAssertEqual(result.conversation.activeReply?.cards.first?.state, .approved)
        await result.conversation.approve(card: card)
        XCTAssertEqual(requests.count, 1)
    }

    func testFlagOnPostsTurnToV1AndPagesTurnEventsFromNextAfter() async throws {
        var bodies: [[String: Any]] = []
        let result = try await run(kit: true) { request in
            if request.httpMethod == "POST" {
                bodies.append(try XCTUnwrap(JSONSerialization.jsonObject(with: MushyStub.body(request)) as? [String: Any]))
            }
            return nil
        }
        let posts = result.requests.filter { $0.httpMethod == "POST" }
        XCTAssertEqual(posts.map { $0.url!.path }, [root + "/sessions/" + sessionId + "/turns"])
        let body = try XCTUnwrap(bodies.first)
        XCTAssertEqual(Set(body.keys), ["request_id", "text"])
        XCTAssertNotNil(UUID(uuidString: try XCTUnwrap(body["request_id"] as? String)))
        XCTAssertEqual(body["text"] as? String, prompt)
        let gets = result.requests.filter { $0.url!.path.hasPrefix(root + "/turns/") }
        XCTAssertEqual(gets.map { $0.url!.path }, Array(repeating: root + "/turns/" + turnId + "/events", count: 4)
            + [root + "/turns/" + turnId + "/cards"])
        XCTAssertEqual(gets.map { $0.url!.query }, ["after=0&wait=15", "after=7&wait=15", "after=13&wait=15", "after=19&wait=15", nil])
        XCTAssertTrue(gets.allSatisfy { $0.httpMethod == "GET" })
        for request in posts + gets {
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-device")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Accept"), "application/json")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Cache-Control"), "no-store")
        }
        XCTAssertEqual(posts.first?.value(forHTTPHeaderField: "Content-Type"), "application/json")
        XCTAssertEqual(result.conversation.cursor, 0)
        XCTAssertEqual(result.conversation.kitCursor, 23)
    }

    func testFlagOnRendersTextToolsAndDoneLikeLegacyFixture() async throws {
        let legacy = try await run(kit: false)
        let kit = try await run(kit: true)
        let expected = try XCTUnwrap(legacy.conversation.activeReply)
        let actual = try XCTUnwrap(kit.conversation.activeReply)
        XCTAssertEqual(actual.text, expected.text)
        XCTAssertEqual(actual.finished, expected.finished)
        XCTAssertEqual(actual.failed, expected.failed)
        XCTAssertEqual(actual.tools.map(\.label), expected.tools.map(\.label))
        XCTAssertEqual(actual.tools.map(\.state), expected.tools.map(\.state))
        XCTAssertEqual(actual.tools.map(\.label), ["Checking your balance"])
        XCTAssertEqual(actual.tools.map(\.state), ["finished"])
        XCTAssertTrue(actual.views.isEmpty)
        XCTAssertEqual(expected.views.count, 1)
        XCTAssertNil(kit.conversation.activeJobId)
    }

    func testFlagOnMapsV1RefusalsToExistingCopy() async throws {
        let cases: [(Int, String, MushyClientError)] = [
            (409, "worker_offline", .assistantUnavailable), (409, "busy", .assistantBusy),
            (401, "unpaired", .authentication), (403, "refused", .notBound), (500, "internal", .http(500))
        ]
        for onPage in [false, true] {
            for (status, code, expected) in cases {
                let result = try await run(kit: true) { request in
                    if request.url!.path.hasPrefix(self.root),
                       request.httpMethod == (onPage ? "GET" : "POST") {
                        return (status, try self.data(["reason": self.reason(code)]))
                    }
                    return nil
                }
                XCTAssertEqual(result.conversation.activeReply?.failed, expected.localizedDescription)
                XCTAssertNil(result.conversation.activeJobId)
            }
        }
    }

    func testFlagOnFailedAndExpiredTurnsFinishWithReasonText() async throws {
        for state in ["failed", "expired", "stopped"] {
            for withReason in [true, false] {
                let result = try await run(kit: true) { request in
                    if request.url!.path.hasPrefix(self.root + "/turns/") {
                        return (200, try self.page([self.turn(2, state,
                            reason: withReason ? self.reason("turn_expired", text: "Please ask again.") : nil),
                            self.textItem(3, "Must not render after termination")], next: 3))
                    }
                    return nil
                }
                let reply = try XCTUnwrap(result.conversation.activeReply)
                XCTAssertTrue(reply.finished)
                XCTAssertEqual(reply.failed, withReason ? "Please ask again." : "The assistant could not answer. Try again.")
                XCTAssertEqual(reply.text, "")
                XCTAssertEqual(result.requests.filter { $0.url!.path.hasPrefix(self.root + "/turns/") }.count, 1)
            }
        }
    }

    func testFlagOnRejectsMalformedPages() async throws {
        let foreign = "00000000-0000-4000-8000-000000000099"
        let malformed = [
            try page([], next: 6), try page([], next: 8002),
            try page([turn(9, "done")], next: 8),
            try page([turn(8, "done", id: foreign)], next: 8),
            try page([item(8, suffix: ":answer", blocks: [["type": "text", "text": "Other turn"]], id: foreign)], next: 8),
            Data("{broken".utf8),
            try page([["type": "future", "seq": 9]], next: 8)
        ]
        for bad in malformed {
            let result = try await run(kit: true) { request in
                if request.url!.path.hasPrefix(self.root + "/turns/"), self.after(request) == 7 {
                    return (200, bad)
                }
                return nil
            }
            XCTAssertEqual(result.conversation.activeReply?.failed, MushyClientError.response.localizedDescription)
            XCTAssertEqual(result.conversation.activeReply?.finished, true)
            XCTAssertEqual(result.conversation.kitCursor, 7)
            XCTAssertEqual(result.conversation.cursor, 0)
        }
    }

    func testFlagOnRetriesTransportErrorsFromTheSameKitCursor() async throws {
        var failed = false
        let result = try await run(kit: true) { request in
            if request.url!.path.hasPrefix(self.root + "/turns/"), self.after(request) == 7, !failed {
                failed = true
                throw URLError(.networkConnectionLost)
            }
            return nil
        }
        XCTAssertEqual(result.requests.filter { $0.url!.path == root + "/turns/" + turnId + "/events" }.map(after), [0, 7, 7, 13, 19])
        XCTAssertEqual(result.requests.filter { $0.url!.path == root + "/turns/" + turnId + "/cards" }.count, 1)
        XCTAssertEqual(result.requests.last?.url?.path, root + "/turns/" + turnId + "/cards")
        XCTAssertEqual(result.conversation.activeReply?.text, answer)
        XCTAssertEqual(result.conversation.activeReply?.finished, true)
        XCTAssertNil(result.conversation.activeReply?.failed)
        XCTAssertEqual(result.conversation.kitCursor, 23)
        XCTAssertEqual(result.conversation.cursor, 0)
    }

    func testFlagOnEngineModeAndOverlongTextUseLegacyRoutes() async throws {
        let overlong = String(repeating: "a", count: 7001)
        XCTAssertEqual(overlong.utf16.count, 7001)
        XCTAssertLessThan(overlong.utf8.count, 8000)
        for (text, engine, expectedMode) in [(prompt, true, "engine"), (overlong, false, "ask")] {
            var posted: [String: Any] = [:]
            let result = try await run(kit: true, text: text, engine: engine) { request in
                if request.httpMethod == "POST" {
                    posted = try XCTUnwrap(JSONSerialization.jsonObject(with: MushyStub.body(request)) as? [String: Any])
                }
                return nil
            }
            let kitRequests = result.requests.filter { $0.url!.path.contains("/api/kashbot/") }
            XCTAssertEqual(kitRequests.map { $0.url!.path }, [root + "/turns/" + turnId + "/cards"])
            XCTAssertEqual(kitRequests.map { $0.httpMethod }, ["GET"])
            XCTAssertEqual(result.requests.filter { $0.httpMethod == "POST" }.map { $0.url!.path },
                           [MushyClient.root + "/assistant/turn"])
            XCTAssertEqual(posted["mode"] as? String, expectedMode)
            XCTAssertEqual(posted["input"] as? String, text)
            XCTAssertEqual(result.conversation.activeReply?.finished, true)
        }
        let unsupported = try await run(kit: true, engine: true, supportsEngine: false)
        XCTAssertTrue(unsupported.requests.contains { $0.url!.path == root + "/sessions/" + sessionId + "/turns" })
        XCTAssertEqual(unsupported.conversation.activeReply?.finished, true)
    }

    func testFlagOnRefusesBearerChangeMidTurn() async throws {
        var bearer = "test-device"
        let result = try await run(kit: true, token: { bearer }) { request in
            if request.url!.path.hasPrefix(self.root + "/turns/"), self.after(request) == 7 {
                bearer = "rotated-device"
            }
            return nil
        }
        XCTAssertEqual(result.conversation.activeReply?.failed, MushyClientError.mismatch.localizedDescription)
        XCTAssertEqual(result.conversation.kitCursor, 7)
        XCTAssertEqual(result.conversation.cursor, 0)
        XCTAssertEqual(result.requests.filter { $0.url!.path.hasPrefix(root + "/turns/") }.map(after), [0, 7])
    }

    func testTransportRefusesInvalidRoutesAndParametersWithoutSending() async throws {
        MushyStub.handler = { _ in XCTFail("Invalid route reached URLSession"); return (500, Data()) }
        let client = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: { "test-device" })
        let identity = try client.identity()
        let transport = KashbotKitTransport(client: client, identity: identity)
        for (method, path) in [("GET", "/sessions/" + sessionId + "/turns"),
                               ("POST", "/turns/" + turnId + "/events"),
                               ("GET", "/turns/not-a-uuid/events"),
                               ("GET", "/turns/" + turnId + "/events/"),
                               ("GET", "//turns/" + turnId + "/events"),
                               ("GET", "/turns/" + turnId + "/events?after=0")] {
            do {
                _ = try await client.kitSend(method: method, path: path, query: [], body: nil, identity: identity)
                XCTFail("Invalid route accepted")
            } catch { XCTAssertEqual(error.localizedDescription, MushyClientError.response.localizedDescription) }
        }
        for (id, after, wait) in [("bad", 0, 15), (turnId, -1, 15), (turnId, 8002, 15),
                                  (turnId, 0, -1), (turnId, 0, 16)] {
            do {
                _ = try await transport.turnEvents(turnId: id, after: after, wait: wait)
                XCTFail("Invalid parameter accepted")
            } catch { XCTAssertEqual(error.localizedDescription, MushyClientError.response.localizedDescription) }
        }
        for text in ["", String(repeating: "a", count: 7001)] {
            do {
                _ = try await transport.startTurn(sessionId: sessionId, text: text)
                XCTFail("Invalid text accepted")
            } catch { XCTAssertEqual(error.localizedDescription, MushyClientError.response.localizedDescription) }
        }
        XCTAssertFalse(KashbotKitTransport.fits(""))
        XCTAssertTrue(KashbotKitTransport.fits(String(repeating: "😀", count: 3500)))
        XCTAssertFalse(KashbotKitTransport.fits(String(repeating: "😀", count: 3501)))
    }

    func testOldEventsAreSkippedAndUnknownContentIsIgnored() async throws {
        let result = try await run(kit: true) { request in
            if request.url!.path.hasPrefix(self.root + "/turns/"), self.after(request) == 19 {
                return (200, try self.page([self.toolItem(10, suffix: ":5", state: "failed"),
                    self.textItem(18, "Stale answer"),
                    self.item(20, suffix: ":future", blocks: [["type": "future_block"]]),
                    ["type": "future_event", "seq": 21], self.turn(23, "done"),
                    self.textItem(24, "Too late")], next: 24))
            }
            return nil
        }
        XCTAssertEqual(result.conversation.activeReply?.text, answer)
        XCTAssertEqual(result.conversation.activeReply?.tools.map(\.state), ["finished"])
        XCTAssertEqual(result.conversation.activeReply?.finished, true)
        XCTAssertEqual(result.conversation.kitCursor, 24)
    }

    func testTransportBoundsBodiesAndPreservesStatusAndErrors() async throws {
        let client = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: { "test-device" })
        let identity = try client.identity()
        let transport = KashbotKitTransport(client: client, identity: identity)
        let path = "/turns/" + turnId + "/events"
        MushyStub.handler = { _ in (418, Data("refusal".utf8)) }
        let raw = try await client.kitSend(method: "GET", path: path, query: [], body: nil, identity: identity)
        XCTAssertEqual(raw.status, 418)
        XCTAssertEqual(raw.body, Data("refusal".utf8))
        do {
            _ = try await transport.turnEvents(turnId: turnId, after: 0, wait: 15)
            XCTFail("Unexpected status accepted")
        } catch { XCTAssertEqual(error.localizedDescription, MushyClientError.http(418).localizedDescription) }
        MushyStub.handler = { _ in (200, Data(repeating: 32, count: 4_000_001)) }
        do {
            _ = try await transport.turnEvents(turnId: turnId, after: 0, wait: 15)
            XCTFail("Oversized body accepted")
        } catch { XCTAssertEqual(error.localizedDescription, MushyClientError.response.localizedDescription) }
        MushyStub.handler = { _ in throw URLError(.timedOut) }
        do {
            _ = try await transport.startTurn(sessionId: sessionId, text: prompt)
            XCTFail("Transport failure swallowed")
        } catch { XCTAssertEqual(error.localizedDescription, MushyClientError.transport.localizedDescription) }
        for body in [try data(turn(2, "queued", id: "bad")), try data(["type": "future", "seq": 2]), Data("broken".utf8)] {
            MushyStub.handler = { _ in (202, body) }
            do {
                _ = try await transport.startTurn(sessionId: sessionId, text: prompt)
                XCTFail("Malformed admission accepted")
            } catch { XCTAssertEqual(error.localizedDescription, MushyClientError.response.localizedDescription) }
        }
    }
}
