import Foundation
import XCTest
@testable import LeafHFT

final class PrivateKeyFileTests: XCTestCase {
    private func reject(_ data: Data, invalidText: Bool) throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try data.write(to: url)
        defer { try? FileManager.default.removeItem(at: url) }
        var draft = "non-secret draft"
        do {
            // Match the callback's assignment: a failed read must not replace input.
            draft = try validatedPrivateKeyFile(at: url)
            XCTFail("Invalid file was accepted")
        } catch {
            XCTAssertEqual(error is PrivateKeyFileError, invalidText)
        }
        XCTAssertEqual(draft, "non-secret draft")
    }

    func testInvalidFileRetainsDraft() throws {
        try reject(Data("This is not a key".utf8), invalidText: false)
    }

    func testOversizeRetainsDraft() throws {
        try reject(Data(repeating: 65, count: 65_537), invalidText: true)
    }

    func testNonUTF8RetainsDraft() throws {
        try reject(Data([0xff, 0xfe, 0xff]), invalidText: true)
    }

    func testSizeLimitStillRequiresRSAValidation() throws {
        try reject(Data(repeating: 65, count: 65_536), invalidText: false)
    }
}
