import XCTest
@testable import LeafHFT

final class ConfigureFlowTests: XCTestCase {
    @MainActor func testAccountPickerRequiresAnAccountChoice() {
        XCTAssertTrue(EngineSettingsView.accountPickerUnavailable(accountCount: 0))
        XCTAssertFalse(EngineSettingsView.accountPickerUnavailable(accountCount: 1))
        XCTAssertFalse(EngineSettingsView.accountPickerUnavailable(accountCount: 2))
    }

    @MainActor func testMissingAccountsAndControlsAreNamedSeparately() {
        XCTAssertEqual(EngineSettingsView.prerequisiteMessages(noAccounts: true, needsAccount: true,
            configurationMissing: true, scopeFresh: false, transportFresh: false), [
                "No configurable accounts received", "Account controls not reported",
                "Engine observation delayed or not reported"
            ])
    }

    @MainActor func testDelayedControlsAreNotMisreportedAsMissing() {
        XCTAssertEqual(EngineSettingsView.prerequisiteMessages(noAccounts: false, needsAccount: false,
            configurationMissing: false, scopeFresh: nil, transportFresh: true), ["Control freshness not reported"])
        XCTAssertEqual(EngineSettingsView.prerequisiteMessages(noAccounts: false, needsAccount: true,
            configurationMissing: false, scopeFresh: false, transportFresh: true), [
                "Choose an account", "Control data delayed"
            ])
        XCTAssertEqual(EngineSettingsView.prerequisiteMessages(noAccounts: false, needsAccount: false,
            configurationMissing: false, scopeFresh: true, transportFresh: true), [])
    }

    @MainActor func testSearchRestoresFullControlsWhenKeyboardCloses() {
        XCTAssertTrue(EngineSettingsView.compactSearchResults(query: "loss", focused: true, keyboardVisible: true))
        XCTAssertTrue(EngineSettingsView.compactSearchResults(query: "", focused: true, keyboardVisible: true))
        XCTAssertTrue(EngineSettingsView.compactSearchResults(query: "loss", focused: false, keyboardVisible: true))
        XCTAssertFalse(EngineSettingsView.compactSearchResults(query: "loss", focused: false, keyboardVisible: false))
        XCTAssertFalse(EngineSettingsView.compactSearchResults(query: "  \n", focused: false, keyboardVisible: true))
    }

    @MainActor func testProblemSummaryNamesSavedPolicyAndDraftErrors() {
        XCTAssertEqual(EngineSettingsView.problemSummary(savedNames: ["Order cap", "Cluster cap"],
            problems: ["Drawdown stop must exceed slowdown."]),
            "Saved values above the runner's maximum: Order cap, Cluster cap. Drawdown stop must exceed slowdown.")
        XCTAssertEqual(EngineSettingsView.problemSummary(savedNames: [], problems: ["Invalid draft value"]),
            "Invalid draft value")
        XCTAssertEqual(EngineSettingsView.problemSummary(savedNames: [], problems: []), "")
    }
}
