import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

/// w4-F08: every result figure on engine detail names its period and source, and an empty or P&L-less
/// history beside status-feed trades gets one bridge sentence built only from what the payloads carry.
final class EngineDetailReconcileTests: XCTestCase {
    private func live(_ json: String) throws -> EngineLiveStats {
        try JSONDecoder().decode(EngineLiveStats.self, from: Data(json.utf8))
    }

    private func probeDay(_ json: String) throws -> ProbeDay {
        try JSONDecoder().decode(ProbeDay.self, from: Data(json.utf8))
    }

    private func entry(_ engineId: String?, pnl: String = "250", settled: Int = 6, exits: Int = 1, open: Int = 2,
                       series: String = #"[{"day": "2026-09-15", "pnl_cents": 250, "settlements_n": 6, "exits_n": 1}]"#) -> String {
        let id = engineId.map { "\"\($0)\"" } ?? "null"
        return """
        {"engine_id": \(id), "host": "sample-runner", "name": "Sample",
         "summary": {"realized_pnl_cents": \(pnl), "settlements_n": \(settled), "won_n": 0, "exits_n": \(exits), "open_n": \(open)},
         "series": \(series), "accounts": []}
        """
    }

    private func history(_ entries: [String], dropped: String = "false", truncated: Bool = false,
                         missingPnl: Int = 0) throws -> EngineHistoryResponse {
        let json = """
        {"schema_version": 1, "generated_at": "2026-09-16T08:00:00Z", "venue": "kalshi", "range": "week",
         "since": "2026-09-09T08:00:00Z", "until": "2026-09-16T08:00:00Z",
         "coverage": {"scope": "ingested_tickets", "tickets_dropped": \(dropped), "truncated": \(truncated),
                      "unassigned_n": 0, "missing_pnl_n": \(missingPnl)},
         "accounts": [], "engines": [\(entries.joined(separator: ","))]}
        """
        let decoder = accountJSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(EngineHistoryResponse.self, from: Data(json.utf8))
    }

    private var walkLive: String { #"{"perContractCents": 10, "n": 3, "days": 2}"# }
    private var walkProbeDay: String { #"{"utcDay": "2026-09-23", "realizedCents": 30, "entries": 2}"# }

    func testLiveLineNamesSourceAndPeriod() throws {
        XCTAssertEqual(EngineDetailReconcile.liveLine(try live(walkLive)),
                       "Live, engine status feed: +10.0c per contract · n 3 over 2 days")
        XCTAssertEqual(EngineDetailReconcile.liveLine(try live(#"{"perContractCents": -3.25, "n": 1, "days": 1}"#)),
                       "Live, engine status feed: -3.3c per contract · n 1 over 1 day")
        XCTAssertEqual(EngineDetailReconcile.liveLine(nil), "Live, engine status feed: Not reported")
    }

    func testProbeDayLineKeepsUTCAndNamesSource() throws {
        let line = try XCTUnwrap(EngineDetailReconcile.probeDayLine(try probeDay(walkProbeDay)))
        XCTAssertEqual(line, "Probe day 2026-09-23 (UTC): +$0.30 · 2 tickets · engine status feed")
        XCTAssertNil(EngineDetailReconcile.probeDayLine(nil))
    }

    func testStatusAsOfUsesTheFeedTimeOrSaysNotReported() {
        let cases: [(String?, String)] = [
            ("2026-09-16T08:00:00Z", "Live and probe-day figures: engine status feed, as of 2026-09-16 08:00 UTC."),
            ("2026-09-16T08:00:00.500Z", "Live and probe-day figures: engine status feed, as of 2026-09-16 08:00 UTC."),
            ("yesterday", "Live and probe-day figures: engine status feed, as of yesterday."),
            ("", "Live and probe-day figures: engine status feed, as-of time not reported."),
            (nil, "Live and probe-day figures: engine status feed, as-of time not reported.")
        ]
        for (input, expected) in cases {
            XCTAssertEqual(EngineDetailReconcile.statusAsOf(input), expected, String(describing: input))
        }
    }

    func testHistoryHeaderAndSourceNamePeriodScopeAndCoverage() throws {
        XCTAssertEqual(EngineDetailReconcile.historyHeader, "7d · All accounts")
        XCTAssertEqual(EngineDetailReconcile.historyRange, .week)
        XCTAssertEqual(EngineDetailReconcile.historySource(try history([entry("default")])),
                       "Engine history (ingested tickets) · 7d · All accounts · UTC days · through 2026-09-16 08:00 UTC")
    }

    func testHistoryHasRecords() throws {
        let full = try history([entry("aggressive")])
        XCTAssertTrue(EngineDetailReconcile.historyHasRecords(full.performance(engineId: "aggressive")))
        XCTAssertFalse(EngineDetailReconcile.historyHasRecords(full.performance(engineId: "absent")))
        let openOnly = try history([entry("aggressive", pnl: "null", settled: 0, exits: 0, open: 1, series: "[]")])
        XCTAssertTrue(EngineDetailReconcile.historyHasRecords(openOnly.performance(engineId: "aggressive")))
    }

    func testStatusTradeFiguresOnlyListFiguresThatReportTrades() throws {
        XCTAssertEqual(EngineDetailReconcile.statusTradeFigures(live: try live(walkLive), probeDay: try probeDay(walkProbeDay)),
                       ["the live sample (n 3 over 2 days)", "probe day 2026-09-23 (UTC, 2 tickets)"])
        XCTAssertEqual(EngineDetailReconcile.statusTradeFigures(live: try live(#"{"n": 0, "days": 0}"#),
                                                                probeDay: try probeDay(#"{"utcDay": "2026-09-23", "tickets": 0}"#)), [])
        XCTAssertEqual(EngineDetailReconcile.statusTradeFigures(live: nil, probeDay: try probeDay(#"{"tickets": 1}"#)),
                       ["probe day Not reported (UTC, 1 ticket)"])
        XCTAssertEqual(EngineDetailReconcile.statusTradeFigures(live: nil, probeDay: nil), [])
    }

    /// The walk's screen: live n=3 over 2 days and a 2-ticket probe day while 7d All accounts history is empty.
    func testBridgeTable() throws {
        let emptyForEngine = try history([entry("default")])
        let withRecords = try history([entry("aggressive")])
        let noPnl = try history([entry("aggressive", pnl: "null")])
        let walk = (live: try live(walkLive), day: try probeDay(walkProbeDay))
        let through = "7d, All accounts (through 2026-09-16 08:00 UTC)"

        let cases: [(name: String, live: EngineLiveStats?, day: ProbeDay?, history: EngineHistoryResponse?,
                     failed: Bool, expected: String?)] = [
            ("walk: empty history beside status trades", walk.live, walk.day, emptyForEngine, false,
             "History has no records for this engine for \(through); the live sample (n 3 over 2 days) and probe day " +
                "2026-09-23 (UTC, 2 tickets) come from the engine status feed. History does not report why they are absent."),
            ("live only", walk.live, nil, emptyForEngine, false,
             "History has no records for this engine for \(through); the live sample (n 3 over 2 days) comes from the " +
                "engine status feed. History does not report why they are absent."),
            ("history has P&L", walk.live, walk.day, withRecords, false, nil),
            ("history records without P&L", walk.live, nil, noPnl, false,
             "History P&L for this engine for \(through) is not reported; the live sample (n 3 over 2 days) comes from " +
                "the engine status feed."),
            ("no status trades", nil, nil, emptyForEngine, false, nil),
            ("status sample of zero", try live(#"{"n": 0, "days": 0}"#), nil, emptyForEngine, false, nil),
            ("history still loading", walk.live, walk.day, nil, false, nil),
            ("history failed", walk.live, nil, nil, true,
             "History for 7d · All accounts could not be loaded; the live sample (n 3 over 2 days) comes from the engine status feed.")
        ]
        for item in cases {
            XCTAssertEqual(EngineDetailReconcile.bridge(engineId: "aggressive", live: item.live, probeDay: item.day,
                                                        history: item.history, historyFailed: item.failed),
                           item.expected, item.name)
        }
    }

    func testBridgeStatesCoverageFactsAsSent() throws {
        let unattributed = entry(nil, pnl: "40", settled: 3, exits: 0, open: 1)
        let flagged = try history([entry("default"), unattributed], dropped: "null", truncated: true, missingPnl: 2)
        let text = try XCTUnwrap(EngineDetailReconcile.bridge(engineId: "aggressive", live: try live(walkLive),
                                                              probeDay: nil, history: flagged, historyFailed: false))
        XCTAssertTrue(text.hasPrefix("History has no records for this engine for 7d, All accounts"), text)
        XCTAssertTrue(text.contains(" History coverage for 7d may be incomplete (records dropped or truncated)."), text)
        XCTAssertTrue(text.contains(" 4 tickets in 7d history carry no engine attribution."), text)
        XCTAssertTrue(text.hasSuffix(" 2 results in 7d history are missing P&L."), text)

        let clean = try history([entry("default")])
        XCTAssertEqual(EngineDetailReconcile.coverageNotes(clean), "")
        let one = try history([entry(nil, settled: 1, exits: 0, open: 0)], missingPnl: 1)
        XCTAssertEqual(EngineDetailReconcile.coverageNotes(one),
                       " 1 ticket in 7d history carries no engine attribution. 1 result in 7d history is missing P&L.")
    }

    func testPnlPrefixSaysThePeriodIsNotReported() {
        XCTAssertEqual(EngineDetailReconcile.pnlPrefix, "Engine status feed, period not reported: ")
    }
}
