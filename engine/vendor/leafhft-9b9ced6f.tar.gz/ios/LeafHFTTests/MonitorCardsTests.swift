import Foundation
import XCTest
@testable import LeafHFT
import LeafHFTCore

/// Decisions behind the Monitor and Books cards (walk findings w2-F02, w2-F05, w2-F06).
@MainActor final class MonitorCardsTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_790_550_000)

    private func exitsFixture() throws -> ExitLedger {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "exits", withExtension: "json", subdirectory: "Fixtures"))
        return try accountJSONDecoder().decode(ExitLedger.self, from: Data(contentsOf: url))
    }

    func testCashoutLedgerStringsAndTones() throws {
        var ledger = try exitsFixture()
        XCTAssertEqual(ledger.summary.headline, "Cashouts beat holding by +$1,154.85")
        XCTAssertEqual(ledger.summary.tally, "193 saved · 125 gave back · 8 pending")
        XCTAssertEqual(ledger.summary.priceLine, "3 fills below their limit")
        XCTAssertEqual(ledger.summary.timingLine, "Filled in 103 ms (median) · 47 s before close")
        XCTAssertEqual(ExitsCard.headlineTone(ledger.summary), .gain)
        XCTAssertEqual(ExitsCard.priceTone(ledger.summary), .loss)
        ledger.summary.worseThanLimitCount = 0
        XCTAssertEqual(ExitsCard.priceTone(ledger.summary), .gain)
        XCTAssertEqual(ExitsCard.rowTone(ledger.rows[0]), .gain)
        XCTAssertEqual(ExitsCard.rowTone(ledger.rows[1]), .loss)
        XCTAssertEqual(ExitsCard.rowTone(ledger.rows[2]), .stale)
        XCTAssertEqual(ledger.topLesson?.severity, .act)
        ledger.summary.netVsHoldCents = -1230
        ledger.summary.worseThanLimitCount = 3
        XCTAssertEqual(ExitsCard.headlineTone(ledger.summary), .loss)
        XCTAssertEqual(ExitsCard.priceTone(ledger.summary), .loss)
        ledger.summary.netVsHoldCents = 0
        XCTAssertEqual(ExitsCard.headlineTone(ledger.summary), .neutral)
        ledger.summary.resolved = 0
        XCTAssertEqual(ExitsCard.headlineTone(ledger.summary), .stale)
    }

    func testCashoutEmptyAndErrorStates() throws {
        var ledger = try exitsFixture()
        XCTAssertEqual(ExitsCard.stateMessage(ledger: nil, error: nil), "Loading cashouts…")
        XCTAssertEqual(ExitsCard.stateMessage(ledger: nil, error: "offline"),
                       "Cashouts are unavailable for this paired account.")
        XCTAssertEqual(ExitsCard.stateMessage(ledger: ledger, error: "offline"),
                       "Could not refresh cashouts. Showing the last ledger.")
        XCTAssertNil(ExitsCard.stateMessage(ledger: ledger, error: nil))
        ledger.summary.exits = 0
        ledger.rows = []
        XCTAssertEqual(ExitsCard.stateMessage(ledger: ledger, error: nil), "No cashouts in the last 30 days.")
    }

    private func calibrationFixture() throws -> EntryCalibration {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "calibration", withExtension: "json", subdirectory: "Fixtures"))
        return try accountJSONDecoder().decode(EntryCalibration.self, from: Data(contentsOf: url))
    }

    private func attemptFunnelFixture() throws -> AttemptFunnel {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "attempt-funnel", withExtension: "json", subdirectory: "Fixtures"))
        return try accountJSONDecoder().decode(AttemptFunnel.self, from: Data(contentsOf: url))
    }

    func testAttemptFunnelHeadlineAndRows() throws {
        let funnel = try attemptFunnelFixture()
        XCTAssertEqual(funnel.headline, "Most attempts that did not fill were sent but got no fill (250 of 512)")
        XCTAssertEqual(funnel.fillRateText, "40% of 812 engine yeses filled")
        XCTAssertEqual(funnel.lossRows.first?.label, "Sent, nothing filled")
        XCTAssertNil(AttemptFunnelCard.stateMessage(funnel: funnel, error: nil))
    }

    func testAttemptFunnelNoDataAndErrorStates() throws {
        var funnel = try attemptFunnelFixture()
        XCTAssertEqual(AttemptFunnelCard.stateMessage(funnel: nil, error: nil), "Loading attempt funnel…")
        XCTAssertEqual(AttemptFunnelCard.stateMessage(funnel: nil, error: "offline"),
                       "Attempt funnel is unavailable for this paired account.")
        XCTAssertEqual(AttemptFunnelCard.stateMessage(funnel: funnel, error: "offline"),
                       "Could not refresh the attempt funnel. Showing the last result.")
        funnel.status = .noData
        funnel.headline = "The runner has not reported attempts yet"
        XCTAssertEqual(funnel.headline, "The runner has not reported attempts yet")
        XCTAssertEqual(AttemptFunnelCard.noDataText,
                       "The runner starts reporting every attempt after its next deploy.")
        XCTAssertEqual(funnel.interimLine, "372 order claims, 165 fills (44%)")
        XCTAssertNil(AttemptFunnelCard.stateMessage(funnel: funnel, error: nil))
    }

    func testEntryCalibrationStringsAndTones() throws {
        var calibration = try calibrationFixture()
        XCTAssertEqual(calibration.summary.headline, "Model said 93.4%, entries won 81.9%")
        XCTAssertEqual(calibration.summary.edgeLine, "+1.2 points after price")
        XCTAssertEqual(calibration.summary.coverageLine, "913 scored of 1,008 entries · 87 open")
        XCTAssertEqual(calibration.grid.bestLine, "Cap price at 95c: +$123.45 by skipping 60 entries (in-sample)")
        XCTAssertEqual(calibration.grid.walkForwardLine, "Held-out test: +$12.00 over 40 entries")
        XCTAssertEqual(calibration.topLesson?.id, "calibration")
        let top = try XCTUnwrap(calibration.topLesson)
        XCTAssertEqual(CalibrationCard.lessonTone(top), .loss)
        XCTAssertEqual(calibration.grid.topCells(CalibrationCard.topCellLimit).count, 5)
        XCTAssertEqual(CalibrationCard.headlineTone(calibration.summary), .loss)
        XCTAssertEqual(CalibrationCard.edgeTone(calibration.summary), .gain)
        XCTAssertEqual(CalibrationCard.bucketTone(calibration.buckets[0]), .gain)
        XCTAssertEqual(CalibrationCard.bucketTone(calibration.buckets[4]), .loss)
        XCTAssertEqual(CalibrationCard.cellTone(calibration.grid.cells[0]), .neutral)
        XCTAssertEqual(CalibrationCard.cellTone(calibration.grid.cells[4]), .gain)
        XCTAssertEqual(CalibrationCard.cellTone(calibration.grid.cells[6]), .loss)
        XCTAssertEqual(CalibrationCard.engineTone(calibration.enginesWorstFirst[0]), .loss)
        XCTAssertEqual(CalibrationCard.engineTone(calibration.enginesWorstFirst[2]), .gain)
        // Gain within 2 points of the model, warn under a 5 point gap, loss at 5 or more.
        calibration.summary.actualWinPct = 92
        XCTAssertEqual(CalibrationCard.headlineTone(calibration.summary), .gain)
        calibration.summary.actualWinPct = 95
        XCTAssertEqual(CalibrationCard.headlineTone(calibration.summary), .gain)
        calibration.summary.actualWinPct = 90
        XCTAssertEqual(CalibrationCard.headlineTone(calibration.summary), .warn)
        calibration.summary.actualWinPct = 88
        XCTAssertEqual(CalibrationCard.headlineTone(calibration.summary), .loss)
        calibration.summary.actualWinPct = nil
        XCTAssertEqual(CalibrationCard.headlineTone(calibration.summary), .stale)
        XCTAssertEqual(calibration.summary.headline, "Not enough settled entries yet")
        calibration.summary.edgeAfterPricePts = -0.5
        XCTAssertEqual(CalibrationCard.edgeTone(calibration.summary), .loss)
        XCTAssertEqual(calibration.summary.edgeLine, "-0.5 points after price")
        calibration.summary.edgeAfterPricePts = 0
        XCTAssertEqual(CalibrationCard.edgeTone(calibration.summary), .gain)
        calibration.summary.edgeAfterPricePts = nil
        XCTAssertEqual(CalibrationCard.edgeTone(calibration.summary), .stale)
        calibration.grid.best = nil
        XCTAssertNil(calibration.grid.bestLine)
    }

    func testEntryCalibrationAdviceLinesTonesAndAskPrompt() throws {
        var calibration = try calibrationFixture()
        let advice = calibration.inlineAdvice(CalibrationCard.adviceLimit)
        XCTAssertEqual(CalibrationCard.adviceLimit, 3)
        XCTAssertEqual(advice.map(\.line), [
            "atlas: Cap price at 95c · held-out +$12.00 on 48 entries · Candidate",
            "vega: Quote age at most 1500 ms · held-out +$1.50 on 12 entries · Not enough data",
            "orion: Cap price at 97c and minimum depth 5 · held-out -$3.00 on 52 entries · No gain"
        ])
        XCTAssertEqual(advice.map(CalibrationCard.adviceTone), [.gain, .stale, .neutral])
        var unknown = advice[0]
        unknown.verdict = .unknown
        XCTAssertEqual(CalibrationCard.adviceTone(unknown), .stale)
        XCTAssertEqual(calibration.askPrompt,
                       "Run a held-out check of Cap price at 95c on my engines, then tell me which engine it helps.")
        calibration.grid.best = nil
        XCTAssertEqual(calibration.askPrompt, "Which stricter entry gate would help my engines? Check it held-out.")
        calibration.advice = []
        XCTAssertTrue(calibration.inlineAdvice(CalibrationCard.adviceLimit).isEmpty)
    }

    func testEntryCalibrationEmptyAndErrorStates() throws {
        var calibration = try calibrationFixture()
        XCTAssertEqual(CalibrationCard.stateMessage(calibration: nil, error: nil), "Loading calibration…")
        XCTAssertEqual(CalibrationCard.stateMessage(calibration: nil, error: "offline"),
                       "Calibration is unavailable for this paired account.")
        XCTAssertEqual(CalibrationCard.stateMessage(calibration: calibration, error: "offline"),
                       "Could not refresh calibration. Showing the last result.")
        XCTAssertNil(CalibrationCard.stateMessage(calibration: calibration, error: nil))
        calibration.summary.entries = 0
        calibration.buckets = []
        calibration.engines = []
        calibration.lessons = []
        XCTAssertEqual(CalibrationCard.stateMessage(calibration: calibration, error: nil),
                       "No entries in the last 30 days.")
    }

    private func iso(_ offset: TimeInterval) -> String {
        ISO8601DateFormatter().string(from: now.addingTimeInterval(offset))
    }

    private func fill(_ ticker: String, at occurredAt: String, pnl: Int?) throws -> RunnerActivityRow {
        var payload: [String: Any] = [
            "ticker": ticker, "kind": "settle", "state": "filled", "side": "yes", "count": 1,
            "price_cents": 40, "cost_cents": 40, "fee_cents": 1, "cost_basis_cents": 40,
            "engine_id": "fixture-engine", "occurred_at": occurredAt
        ]
        if let pnl { payload["pnl_cents"] = pnl }
        let data = try JSONSerialization.data(withJSONObject: payload)
        return try accountJSONDecoder().decode(RunnerActivityRow.self, from: data)
    }

    private func engine(_ id: String, name: String? = nil, books: [String] = []) throws -> Engine {
        var payload: [String: Any] = ["engine_id": id, "bound_books": books]
        if let name { payload["name"] = name }
        let data = try JSONSerialization.data(withJSONObject: payload)
        return try accountJSONDecoder().decode(Engine.self, from: data)
    }

    private func book(_ shape: String) throws -> Book {
        let data = try JSONSerialization.data(withJSONObject: PausedBookPayload.dictionary(shape))
        return try accountJSONDecoder().decode(Book.self, from: data)
    }

    private func request(_ bookId: String, enabled: Bool, state: String?, at offset: TimeInterval?,
                         note: String? = nil, id: String = UUID().uuidString) -> ControlRequest {
        ControlRequest(id: id, kind: ControlKind.bookConfigure.rawValue,
                       value: .bookConfigure(BookConfigureValue(bookId: bookId, enabled: enabled)),
                       scope: nil, clientRequestId: nil, state: state, note: note,
                       requestedAt: offset.map(iso), appliedAt: nil)
    }

    // MARK: w2-F02 Closed positions: natural-height preview, then "All (N)"

    func testPreviewShowsThreeInlineAndAllRowOnlyWhenMoreExist() {
        XCTAssertEqual(OrdersCard.previewLimit, 3)
        XCTAssertEqual(OrdersCard.preview(count: 0, noun: "closed positions"),
                       OrdersCard.Preview(shown: 0, allLabel: nil))
        XCTAssertEqual(OrdersCard.preview(count: 1, noun: "closed positions"),
                       OrdersCard.Preview(shown: 1, allLabel: nil))
        XCTAssertEqual(OrdersCard.preview(count: 3, noun: "closed positions"),
                       OrdersCard.Preview(shown: 3, allLabel: nil))
        XCTAssertEqual(OrdersCard.preview(count: 4, noun: "closed positions"),
                       OrdersCard.Preview(shown: 3, allLabel: "All closed positions (4)"))
        XCTAssertEqual(OrdersCard.preview(count: 40, noun: "open orders"),
                       OrdersCard.Preview(shown: 3, allLabel: "All open orders (40)"))
        XCTAssertEqual(OrdersCard.preview(count: -2, noun: "books"), OrdersCard.Preview(shown: 0, allLabel: nil))
    }

    func testClosedPositionsGroupByTickerMostRecentFirst() throws {
        let fills = [
            try fill("KX-A", at: iso(-3_600), pnl: 120),
            try fill("KX-B", at: iso(-60), pnl: -40),
            try fill("KX-A", at: iso(-600), pnl: 10),
            try fill("KX-C", at: "not a time", pnl: 5),
            try fill("KX-D", at: iso(0), pnl: nil)
        ]
        let positions = OrdersCard.closedPositions(fills: fills)
        XCTAssertEqual(positions.map(\.id), ["KX-B", "KX-A", "KX-C"])
        XCTAssertEqual(positions.map { $0.trades.count }, [1, 2, 1])
        XCTAssertEqual(positions.first?.latest, OrdersCard.parseTime(iso(-60)))
        XCTAssertEqual(positions.dropFirst().first?.latest, OrdersCard.parseTime(iso(-600)))
        XCTAssertNil(positions.last?.latest)
    }

    func testClosedPositionsKeepRunnerOrderWhenTimesTie() throws {
        let fills = [try fill("KX-Z", at: iso(-5), pnl: 1), try fill("KX-Y", at: iso(-5), pnl: 2),
                     try fill("KX-X", at: "", pnl: 3), try fill("KX-W", at: "", pnl: 4)]
        XCTAssertEqual(OrdersCard.closedPositions(fills: fills).map(\.id), ["KX-Z", "KX-Y", "KX-X", "KX-W"])
        XCTAssertTrue(OrdersCard.closedPositions(fills: []).isEmpty)
    }

    func testParseTimeAcceptsFractionalSeconds() {
        XCTAssertNotNil(OrdersCard.parseTime("2026-09-20T11:58:01Z"))
        XCTAssertNotNil(OrdersCard.parseTime("2026-09-20T11:58:01.250Z"))
        XCTAssertNil(OrdersCard.parseTime("yesterday"))
    }


    // MARK: w2-F05 Needs a hand: one vertical row per request

    func testAgeTextNamesElapsedTimeAndNeverGoesNegative() {
        XCTAssertEqual(HandCard.ageText(requestedAt: nil, now: now), "request time not reported")
        XCTAssertEqual(HandCard.ageText(requestedAt: now.addingTimeInterval(-30), now: now), "requested 30s ago")
        XCTAssertEqual(HandCard.ageText(requestedAt: now.addingTimeInterval(-240), now: now), "requested 4m ago")
        XCTAssertEqual(HandCard.ageText(requestedAt: now.addingTimeInterval(-7_300), now: now), "requested 2h ago")
        XCTAssertEqual(HandCard.ageText(requestedAt: now.addingTimeInterval(-200_000), now: now), "requested 2d ago")
        XCTAssertEqual(HandCard.ageText(requestedAt: now.addingTimeInterval(90), now: now), "request timestamp is in the future")
    }

    func testRowCarriesIdentityRequestStateAndAgeTogether() {
        let requests = [
            request("BTC-15M", enabled: true, state: "applied", at: -3_600),
            request("BTC-15M", enabled: false, state: "requested", at: -300),
            request("ETH-15M", enabled: true, state: "requested", at: -10)
        ]
        let row = HandCard.row(bookId: "BTC-15M", bookEnabled: true, engine: "Atlas", requests: requests, now: now)
        XCTAssertEqual(row.bookId, "BTC-15M")
        XCTAssertEqual(row.engine, "Atlas")
        XCTAssertEqual(row.runnerState, "On")
        XCTAssertEqual(row.runnerTone, .gain)
        XCTAssertEqual(row.requested, "Turn off")
        XCTAssertEqual(row.state, "Pending")
        XCTAssertEqual(row.stateTone, .warn)
        XCTAssertEqual(row.age, "requested 5m ago")
        XCTAssertNil(row.note)
        XCTAssertTrue(row.needsAttention)
    }

    func testRowStatesForAppliedRejectedAndNoRequest() {
        let applied = HandCard.row(bookId: "B", bookEnabled: false, engine: nil,
                                   requests: [request("B", enabled: false, state: "applied", at: -120)], now: now)
        XCTAssertEqual(applied.state, "Applied")
        XCTAssertEqual(applied.stateTone, .gain)
        XCTAssertEqual(applied.requested, "Turn off")
        XCTAssertEqual(applied.runnerState, "Off")
        XCTAssertEqual(applied.runnerTone, .warn)
        XCTAssertEqual(applied.engine, "Not reported")
        XCTAssertFalse(applied.needsAttention)

        let rejected = HandCard.row(bookId: "B", bookEnabled: nil, engine: nil,
                                    requests: [request("B", enabled: true, state: "REJECTED", at: nil,
                                                       note: " book is locked ")], now: now)
        XCTAssertEqual(rejected.state, "Rejected")
        XCTAssertEqual(rejected.stateTone, .loss)
        XCTAssertEqual(rejected.requested, "Turn on")
        XCTAssertEqual(rejected.age, "request time not reported")
        XCTAssertEqual(rejected.note, "book is locked")
        XCTAssertEqual(rejected.runnerState, "Not reported")
        XCTAssertEqual(rejected.runnerTone, .stale)

        let none = HandCard.row(bookId: "B", bookEnabled: true, engine: "Atlas", requests: [], now: now)
        XCTAssertNil(none.requested)
        XCTAssertNil(none.state)
        XCTAssertNil(none.age)
        XCTAssertEqual(none.stateTone, .stale)
        XCTAssertFalse(none.needsAttention)
    }

    func testRowsAreExceptionFirstThenByBook() {
        let rows = [
            HandCard.row(bookId: "A", bookEnabled: true, engine: nil, requests: [], now: now),
            HandCard.row(bookId: "B", bookEnabled: true, engine: nil,
                         requests: [request("B", enabled: true, state: "applied", at: -5)], now: now),
            HandCard.row(bookId: "C", bookEnabled: true, engine: nil,
                         requests: [request("C", enabled: true, state: "rejected", at: -5)], now: now),
            HandCard.row(bookId: "E", bookEnabled: true, engine: nil,
                         requests: [request("E", enabled: false, state: "requested", at: -5)], now: now),
            HandCard.row(bookId: "D", bookEnabled: true, engine: nil,
                         requests: [request("D", enabled: false, state: nil, at: -5)], now: now)
        ]
        XCTAssertEqual(HandCard.ordered(rows).map(\.bookId), ["E", "C", "B", "D", "A"])
        XCTAssertEqual(HandCard.summary(rows), "1 pending · 1 rejected · 5 books in this report")
    }

    func testRowsBindBooksToTheirEngine() throws {
        let books = [try book("E"), try book("P")]
        let engines = [try engine("atlas", name: "Atlas", books: ["ETH-15M"]), try engine("orion", books: ["BTC-15M"])]
        let rows = HandCard.rows(books: books, engines: engines,
                                 requests: [request("ETH-15M", enabled: false, state: "requested", at: -60)],
                                 now: now)
        XCTAssertEqual(rows.map(\.bookId), ["ETH-15M", "BTC-15M"])
        XCTAssertEqual(rows.map(\.engine), ["Atlas", "orion"])
        XCTAssertEqual(rows.map(\.runnerState), ["On", "Off"])
        XCTAssertEqual(rows.first?.requested, "Turn off")
        XCTAssertEqual(rows.first?.age, "requested 1m ago")
    }

    func testClosedPreviewAlwaysOffersFullListForNonemptyLedger() {
        XCTAssertEqual(OrdersCard.preview(count: 1, noun: "closed positions", alwaysShowAll: true),
                       OrdersCard.Preview(shown: 1, allLabel: "All closed positions (1)"))
        XCTAssertEqual(OrdersCard.preview(count: 3, noun: "closed positions", alwaysShowAll: true),
                       OrdersCard.Preview(shown: 3, allLabel: "All closed positions (3)"))
        XCTAssertNil(OrdersCard.preview(count: 0, noun: "closed positions", alwaysShowAll: true).allLabel)
    }

    func testMissingAndUnknownRequestStatesAreNotInvented() {
        for state in [nil, "", "  "] as [String?] {
            XCTAssertEqual(HandCard.stateWord(request("B", enabled: true, state: state, at: nil)), "Not reported")
        }
        XCTAssertEqual(HandCard.stateWord(request("B", enabled: true, state: "expired", at: -5)), "Expired")
        XCTAssertEqual(HandCard.stateWord(request("B", enabled: true, state: " REQUESTED ", at: -5)), "Pending")
    }

    func testEveryRequestSurvivesIncludingOlderPendingAndMissingBooks() throws {
        let rows = HandCard.rows(books: [try book("E")], engines: [], requests: [
            request("ETH-15M", enabled: false, state: "requested", at: -300, id: "older"),
            request("ETH-15M", enabled: true, state: "applied", at: -60, id: "newer"),
            request("MISSING", enabled: false, state: "requested", at: nil, id: "missing")
        ], now: now)
        XCTAssertEqual(rows.map(\.requestId), ["older", "missing", "newer"])
        XCTAssertEqual(Set(rows.map(\.id)).count, 3)
        XCTAssertEqual(rows.first?.requested, "Turn off")
        XCTAssertEqual(rows.first?.age, "requested 5m ago")
        XCTAssertEqual(rows[1].runnerState, "Not reported")
        XCTAssertEqual(rows[1].age, "request time not reported")
        XCTAssertEqual(HandCard.summary(rows), "2 pending · 0 rejected · 2 books in this report")
    }
}
