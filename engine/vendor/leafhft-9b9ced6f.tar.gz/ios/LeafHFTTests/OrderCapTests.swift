import Foundation
import XCTest
@testable import LeafHFT

final class OrderCapTests: XCTestCase {
    private let fixture = Data(#"{"max_order_fraction":0.25,"revision":"r1","source":"default","range":{"min":0.01,"max":0.5}}"#.utf8)

    override func tearDown() {
        DashboardStub.handler = nil
        super.tearDown()
    }

    private func client() -> DashboardClient {
        DashboardClient(protocolClasses: [DashboardStub.self], token: { "order-cap-device" })
    }

    private func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open()
            defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 1024)
            while true {
                let count = stream.read(&buffer, maxLength: buffer.count)
                guard count >= 0 else { throw URLError(.cannotDecodeContentData) }
                if count == 0 { break }
                data.append(contentsOf: buffer.prefix(count))
            }
        }
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    }

    func testGetDecodesServerRangeAndRevision() async throws {
        DashboardStub.handler = { request in
            XCTAssertEqual(request.url?.path, "/api/kashbot/account/order-cap")
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer order-cap-device")
            return (200, self.fixture)
        }
        let value = try await client().orderCap()
        XCTAssertEqual(value.maxOrderFraction, 0.25)
        XCTAssertEqual(value.revision, .text("r1"))
        XCTAssertEqual(value.source, "default")
        XCTAssertEqual(value.range.min, 0.01)
        XCTAssertEqual(value.range.max, 0.5)
    }

    func testPostEncodesFractionAndExpectedRevision() async throws {
        DashboardStub.handler = { request in
            XCTAssertEqual(request.url?.path, "/api/kashbot/account/order-cap")
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer order-cap-device")
            let body = try self.body(request)
            XCTAssertEqual(Set(body.keys), ["max_order_fraction", "expected_revision"])
            XCTAssertEqual(body["max_order_fraction"] as? Double, 0.4)
            XCTAssertEqual(body["expected_revision"] as? String, "r1")
            return (200, Data(#"{"revision":"r2"}"#.utf8))
        }
        let revision = try await client().putOrderCap(maxOrderFraction: 0.4, expectedRevision: .text("r1"))
        XCTAssertEqual(revision, .text("r2"))
    }

    func testConflictIsTypedAndRefusalsKeepServerMessage() async throws {
        let client = client()
        for (status, expected) in [(409, OrderCapError.conflict),
                                   (400, .rejected("Server range message")),
                                   (403, .rejected("Server range message"))] {
            DashboardStub.handler = { _ in (status, Data(#"{"error":"refused","message":"Server range message"}"#.utf8)) }
            do {
                _ = try await client.putOrderCap(maxOrderFraction: 0.4, expectedRevision: .text("r1"))
                XCTFail("Expected refusal")
            } catch { XCTAssertEqual(error as? OrderCapError, expected) }
        }
    }

    @MainActor func testStateLoadsAndSavesExpectedRevision() async throws {
        var puts = 0
        DashboardStub.handler = { request in
            if request.httpMethod == "GET" { return (200, self.fixture) }
            puts += 1
            let body = try self.body(request)
            XCTAssertEqual(body["expected_revision"] as? String, "r1")
            XCTAssertEqual(body["max_order_fraction"] as? Double, 0.2)
            return (200, Data(#"{"revision":"r2"}"#.utf8))
        }
        let state = AppState(dashboard: client())
        await state.loadOrderCap()
        let value = try XCTUnwrap(state.orderCap.value)
        XCTAssertEqual(value.maxOrderFraction, 0.25)
        XCTAssertEqual(value.revision, .text("r1"))
        XCTAssertEqual(value.range, OrderCapResponse.Range(min: 0.01, max: 0.5))
        await state.saveOrderCap(0.2, expectedRevision: value.revision)
        XCTAssertEqual(puts, 1)
        XCTAssertEqual(state.orderCap.value?.revision, .text("r2"))
        XCTAssertEqual(state.orderCap.value?.maxOrderFraction, 0.2)
        XCTAssertNil(state.orderCap.error)
        XCTAssertFalse(state.orderCap.saving)
    }

    @MainActor func testConflictReloadsCurrentValueAndDoesNotRetryWrite() async throws {
        var gets = 0
        var puts = 0
        DashboardStub.handler = { request in
            if request.httpMethod == "POST" {
                puts += 1
                XCTAssertEqual(try self.body(request)["expected_revision"] as? String, "r1")
                return (409, Data())
            }
            gets += 1
            return gets == 1 ? (200, self.fixture) :
                (200, Data(#"{"max_order_fraction":0.3,"revision":"r3","source":"set","range":{"min":0.01,"max":0.5}}"#.utf8))
        }
        let state = AppState(dashboard: client())
        await state.loadOrderCap()
        await state.saveOrderCap(0.4, expectedRevision: .text("r1"))
        XCTAssertEqual(gets, 2)
        XCTAssertEqual(puts, 1)
        XCTAssertEqual(state.orderCap.value?.maxOrderFraction, 0.3)
        XCTAssertEqual(state.orderCap.value?.revision, .text("r3"))
        XCTAssertNotNil(state.orderCap.error)
        XCTAssertFalse(state.orderCap.loading)
        XCTAssertFalse(state.orderCap.saving)
        await state.saveOrderCap(0.4, expectedRevision: .text("r1"))
        XCTAssertEqual(puts, 1, "A stale confirmation must not send another write")
    }

    @MainActor func testDollarTextRoundsToWholeDollars() {
        XCTAssertEqual(OrderCapCard.dollarText(fraction: 0.52, balanceCents: 193370), "$1,006")
    }

    @MainActor func testLoadFailureRetainsLastKnownValueAndServerMessage() async throws {
        let state = AppState(dashboard: client())
        DashboardStub.handler = { _ in (200, self.fixture) }
        await state.loadOrderCap()
        let previous = state.orderCap.value
        DashboardStub.handler = { _ in (403, Data(#"{"message":"Not your account"}"#.utf8)) }
        await state.loadOrderCap()
        XCTAssertEqual(state.orderCap.value, previous)
        XCTAssertEqual(state.orderCap.error, "Not your account")
        XCTAssertFalse(state.orderCap.loading)
    }
}
