import Foundation
import XCTest
import LeafHFTCore

final class LiveShapeSmokeTests: XCTestCase {
    func testLiveBooksAndEnginesShapes() async throws {
        #if targetEnvironment(simulator)
        guard let portText = ProcessInfo.processInfo.environment["LEAFHFT_LIVE_SMOKE_PORT"],
              let port = Int(portText), (1024...65535).contains(port) else {
            throw XCTSkip("Live smoke is opt-in through the Windows rung 5 command.")
        }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.urlCredentialStorage = nil
        configuration.timeoutIntervalForRequest = 40
        let session = URLSession(configuration: configuration, delegate: NoSmokeRedirects(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        var booksPassed = false
        var enginesPassed = false
        do {
            let booksData = try await fetch("books", port: port, session: session)
            let books = try accountJSONDecoder().decode(MobileBooks.self, from: booksData)
            let rawBooks = try JSONSerialization.jsonObject(with: booksData) as? [String: Any]
            let rows = rawBooks?["books"] as? [[String: Any]]
            let evalCount = rows?.filter { ($0["kalshi_book"] as? [String: Any])?["eval"] is [String: Any] }.count ?? 0
            booksPassed = books.books.count == 14 && books.books.allSatisfy({ $0.kalshiBook.eval != nil })
                && rows?.count == 14 && evalCount == 14
            XCTAssertTrue(booksPassed, "Live books contract: decoded count \(books.books.count), raw count \(rows?.count ?? -1), eval count \(evalCount); each must be 14.")
        } catch {
            XCTFail("Live books could not be fetched or decoded. Response details suppressed.")
        }
        // A books failure must not prevent the independent engines contract check.
        do {
            let enginesData = try await fetch("engines", port: port, session: session)
            let engines = try accountJSONDecoder().decode(EnginesResponse.self, from: enginesData)
            let decodedEngines = engines.engines
            let rawEngines = try JSONSerialization.jsonObject(with: enginesData) as? [String: Any]
            let engineRows = rawEngines?["engines"] as? [[String: Any]]
            enginesPassed = decodedEngines?.isEmpty == false
                && decodedEngines?.allSatisfy({ $0.boundBooks != nil }) == true
                && engineRows != nil && engineRows?.count == decodedEngines?.count
                && engineRows?.allSatisfy({ $0["bound_books"] is [String] }) == true
            XCTAssertTrue(enginesPassed, "Live engines did not satisfy the frozen bound_books contract.")
        } catch {
            // Never render server payloads, request details, or decoder exceptions.
            XCTFail("Live engines could not be fetched or decoded. Response details suppressed.")
        }
        if booksPassed && enginesPassed {
            // The runner also requires exit zero and two accepted relay requests.
            print("LEAFHFT_LIVE_SHAPES_PASSED")
        }
        #else
        throw XCTSkip("Live shape smoke is simulator-only.")
        #endif
    }

    private func fetch(_ route: String, port: Int, session: URLSession) async throws -> Data {
        guard ["books", "engines"].contains(route),
              let url = URL(string: "http://localhost:\(port)/api/leafhft/mobile/\(route)") else {
            throw SmokeError.invalid
        }
        let (data, response) = try await session.data(from: url)
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
            throw SmokeError.invalid
        }
        return data
    }
}

private enum SmokeError: Error { case invalid }
private final class NoSmokeRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}
