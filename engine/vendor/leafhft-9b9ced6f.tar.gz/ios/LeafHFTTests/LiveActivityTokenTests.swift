import Foundation
import XCTest
@testable import LeafHFT

private final class LiveActivityHTTPStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                                                       httpVersion: nil, headerFields: nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

final class LiveActivityTokenTests: XCTestCase {
    override func tearDown() { LiveActivityHTTPStub.handler = nil; super.tearDown() }

    private func client(token: @escaping () throws -> String = { "device-token" }) -> PushClient {
        PushClient(fixtureMode: FixtureMode(arguments: []), protocolClasses: [LiveActivityHTTPStub.self], token: token)
    }

    private func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open()
            defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 1024)
            while true {
                let count = stream.read(&buffer, maxLength: buffer.count)
                if count < 0 { throw URLError(.cannotDecodeContentData) }
                if count == 0 { break }
                data.append(contentsOf: buffer.prefix(count))
            }
        }
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    }

    func testUpdateAndStartUseExactRouteMethodAuthAndBodyIncludingNull() async throws {
        var calls = 0
        LiveActivityHTTPStub.handler = { request in
            calls += 1
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/live-activity-token")
            XCTAssertNil(request.url?.query)
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Content-Type"), "application/json")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Accept"), "application/json")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Cache-Control"), "no-store")
            XCTAssertEqual(request.timeoutInterval, 15)
            let body = try self.body(request)
            XCTAssertEqual(Set(body.keys), ["kind", "token", "activityId"])
            XCTAssertEqual(body["token"] as? String, "00abff")
            if calls == 1 {
                XCTAssertEqual(body["kind"] as? String, "update")
                XCTAssertEqual(body["activityId"] as? String, "activity-1")
            } else {
                XCTAssertEqual(body["kind"] as? String, "start")
                XCTAssertTrue(body["activityId"] is NSNull)
            }
            return (200, Data(#"{"registered":true}"#.utf8))
        }
        let client = client()
        try await client.registerLiveActivityToken(kind: "update", token: "00abff", activityId: "activity-1")
        try await client.registerLiveActivityToken(kind: "start", token: "00abff", activityId: nil)
        XCTAssertEqual(calls, 2)
    }

    func testHTTPAndResponseErrorsUsePushClientMapping() async {
        for status in [401, 403, 503] {
            LiveActivityHTTPStub.handler = { _ in (status, Data()) }
            do {
                try await client().registerLiveActivityToken(kind: "start", token: "ab", activityId: nil)
                XCTFail("HTTP error accepted")
            } catch {
                switch (status, error as? DashboardClientError) {
                case (401, .unauthorized?), (403, .forbidden?), (503, .http(503)?): break
                default: XCTFail("Wrong HTTP error mapping")
                }
            }
        }
        for response in ["not json", "{}", #"{"registered":false}"#] {
            LiveActivityHTTPStub.handler = { _ in (200, Data(response.utf8)) }
            do {
                try await client().registerLiveActivityToken(kind: "start", token: "ab", activityId: nil)
                XCTFail("Invalid response accepted")
            } catch {
                guard case DashboardClientError.decoding = error else { return XCTFail("Expected decoding error") }
            }
        }
    }

    func testFixtureAndMissingAuthStopBeforeTransport() async {
        LiveActivityHTTPStub.handler = { _ in XCTFail("Request reached transport"); return (200, Data()) }
        let fixture = PushClient(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
            protocolClasses: [LiveActivityHTTPStub.self], token: { XCTFail("Read fixture credential"); return "device-token" })
        do {
            try await fixture.registerLiveActivityToken(kind: "start", token: "ab", activityId: nil)
            XCTFail("Fixture upload accepted")
        } catch { XCTAssertTrue(error is FixtureAccessError) }
        do {
            try await client(token: { "" }).registerLiveActivityToken(kind: "start", token: "ab", activityId: nil)
            XCTFail("Missing credential accepted")
        } catch {
            guard case DashboardClientError.noCredential = error else { return XCTFail("Expected credential error") }
        }
    }
}
