import Foundation
import XCTest
@testable import LeafHFT

@MainActor final class BoardWidgetReloadPolicyTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_790_000_000)

    private func snapshot() -> KashbotBoardSnapshot {
        KashbotBoardSnapshot(state: .init(asOf: Int(now.timeIntervalSince1970), totalCents: 10500,
            todayCents: 50, openCount: 0, rows: [], ledger: []), ledger: [])
    }

    func testNoPreviousReload() {
        XCTAssertTrue(AppState.shouldReloadBoardWidgets(previous: nil, previousAt: nil,
            next: snapshot(), now: now))
    }

    func testNewerAsOfAloneDoesNotReloadInsideSixtySeconds() {
        let previous = snapshot()
        var next = previous
        next.state.asOf += 59
        XCTAssertFalse(AppState.shouldReloadBoardWidgets(previous: previous, previousAt: now,
            next: next, now: now.addingTimeInterval(59)))
    }

    func testIdenticalContentReloadsAtSixtySeconds() {
        let previous = snapshot()
        var next = previous
        next.state.asOf += 60
        XCTAssertTrue(AppState.shouldReloadBoardWidgets(previous: previous, previousAt: now,
            next: next, now: now.addingTimeInterval(60)))
    }

    func testChangedLedgerReloads() {
        let previous = snapshot()
        var next = previous
        next.ledger = [.init(ticker: "KXA", pnlCents: 50, pnlBps: nil, at: next.state.asOf)]
        XCTAssertTrue(AppState.shouldReloadBoardWidgets(previous: previous, previousAt: now,
            next: next, now: now.addingTimeInterval(10)))
    }

    func testChangedStateFieldReloads() {
        let previous = snapshot()
        var next = previous
        next.state.todayCents += 1
        XCTAssertTrue(AppState.shouldReloadBoardWidgets(previous: previous, previousAt: now,
            next: next, now: now.addingTimeInterval(10)))
    }
}
