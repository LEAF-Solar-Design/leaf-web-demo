import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor final class OwnerDomainFlowTests: XCTestCase {
    private let tenant = "11111111-1111-4111-8111-111111111111"
    private let lane = "22222222-2222-4222-8222-222222222222"
    private let requestID = UUID(uuidString: "AAAAAAAA-AAAA-4AAA-8AAA-AAAAAAAAAAAA")!
    private let nonce = "0123456789abcdef0123456789abcdef"

    private func execution(generation: Int = 3, state: String = "paused",
                           owner: Bool = true, pending: String? = nil,
                           kind: String = "domain.resume", host: String = "holder") -> [String: Any] {
        var fields: [String: Any] = [
            "schema": 1, "domain": "legacy-owner", "member_key": "owner", "host": host,
            "observed_at": "2026-09-30T12:00:00Z", "summary": state == "paused" ? "halted" : "running",
            "pause": ["state": state, "generation": generation, "resume_nonce": nonce,
                      "paused_at": NSNull(), "resumed_at": NSNull(), "requested_by": NSNull(),
                      "request_id": NSNull()] as [String: Any],
            "counts": ["expected": 14, "running": 14, "entry_enabled": state == "paused" ? 0 : 14,
                       "halted": state == "paused" ? 14 : 0, "missing": 0],
            "books": [["book_id": "btc-15m", "run_id": "run", "fresh": true,
                       "heartbeat_at": "2026-09-30T12:00:00Z", "observed_pause_generation": generation,
                       "entry_enabled": state != "paused", "blockers": state == "paused" ? ["operator_pause"] : []] as [String: Any]],
            "loss_breaker": ["future_field": true], "future_field": ["ignored": true],
            "capabilities": ["owner_domain_control": owner, "pause": state != "paused",
                             "resume": state == "paused", "resume_requires_presence": true]
        ]
        if let pending {
            fields["pending_request"] = ["id": "row", "kind": kind, "state": pending,
                                         "note": "", "requested_at": "2026-09-30T12:00:00Z"]
        }
        return fields
    }

    private func status(_ execution: [String: Any]? = nil, trading: String = "paused") throws -> KashbotStatus {
        var fields: [String: Any] = [
            "dashboard_pairing": "paired", "account_binding": "bound", "automated_trading": trading,
            "tenant": ["id": tenant, "runner_host": "parked"],
            "lane": ["id": lane, "state": trading, "kill_requested": false,
                     "live_enabled": trading == "live"] as [String: Any]
        ]
        if let execution { fields["execution"] = execution }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: fields))
    }

    func testExecutionDecodesAdditivelyAndKeepsParkedLaneTruthful() throws {
        let owner = try status(execution(state: "resumed"))
        XCTAssertTrue(owner.isOwnerExecution)
        XCTAssertEqual(owner.automatedTrading, .paused)
        XCTAssertEqual(owner.lane?.state, .paused)
        XCTAssertEqual(owner.execution?.summaryLabel, "Running")
        XCTAssertEqual(owner.execution?.counts?.expected, 14)
        XCTAssertEqual(owner.execution?.counts?.running, 14)
        XCTAssertEqual(owner.execution?.counts?.entryEnabled, 14)
        XCTAssertEqual(owner.execution?.books?.first?.bookId, "btc-15m")
        XCTAssertEqual(owner.execution?.books?.first?.observedPauseGeneration, 3)
        XCTAssertEqual(owner.execution?.lossBreaker?["future_field"], .bool(true))
        XCTAssertNotNil(owner.execution?.observedAt)
        XCTAssertEqual(owner.execution?.pause?.resumeNonce, nonce)
        XCTAssertNil(owner.execution?.pause?.pausedAt)
        XCTAssertFalse(owner.needsEnrollment)
        let tenantStatus = try status(nil, trading: "dry_run")
        XCTAssertNil(tenantStatus.execution)
        XCTAssertFalse(tenantStatus.isOwnerExecution)
        XCTAssertTrue(tenantStatus.allows(.startLive))
        XCTAssertEqual(tenantStatus.automationLabel, "Dry run only")
    }

    func testOwnerAccountSetupAcceptsDeviceBearerWithoutKalshiKey() throws {
        let bearer = Data("owner-device-token".utf8)
        let owner = try XCTUnwrap(AppState.ownerCredentialSetup(isOwnerExecution: true, bearer: bearer))
        let expectedDigest = TuningSyntax.sha256Hex(bearer)
        XCTAssertEqual(owner.identity, "owner:" + expectedDigest)
        XCTAssertEqual(owner.bearerIdentity.count, 32)
        XCTAssertEqual(owner.bearerIdentity.map { String(format: "%02x", $0) }.joined(), expectedDigest)
    }

    func testOwnerAccountSetupEmptyOrMissingBearerFallsThroughToNormalCredentialPath() {
        XCTAssertNil(AppState.ownerCredentialSetup(isOwnerExecution: true, bearer: Data()))
        XCTAssertNil(AppState.ownerCredentialSetup(isOwnerExecution: true, bearer: nil))
    }

    func testNonOwnerAccountSetupFallsThroughToNormalCredentialPath() {
        for bearer: Data? in [Data("device-token".utf8), Data(), nil] {
            XCTAssertNil(AppState.ownerCredentialSetup(isOwnerExecution: false, bearer: bearer))
        }
    }

    func testPartialExecutionAndMissingCapabilitiesFailClosed() throws {
        let variants: [[String: Any]] = [[:], ["capabilities": [:] as [String: Any]], ["capabilities": NSNull()],
                                       ["capabilities": ["owner_domain_control": false]]]
        for fields in variants {
            let partial = try status(fields, trading: "dry_run")
            XCTAssertFalse(partial.isOwnerExecution)
            XCTAssertTrue(partial.allows(.startLive), "Absent owner capability preserves tenant behaviour")
        }
        let partialOwner = try status(["capabilities": ["owner_domain_control": true],
                                       "pause": [:] as [String: Any], "counts": [:] as [String: Any],
                                       "books": [[:]] as [[String: Any]]])
        XCTAssertTrue(partialOwner.isOwnerExecution)
        XCTAssertEqual(partialOwner.automationLabel, "Unavailable")
        for action in KashbotRunnerAction.allCases { XCTAssertFalse(partialOwner.allows(action)) }
    }

    func testOwnerButtonTruthTableIgnoresParkedLaneState() throws {
        for pause in [false, true] {
            for resume in [false, true] {
                for trading in ["not_configured", "dry_run", "live", "paused", "future"] {
                    var fields = execution()
                    fields["capabilities"] = ["owner_domain_control": true, "pause": pause, "resume": resume]
                    let owner = try status(fields, trading: trading)
                    XCTAssertEqual(owner.allows(.pause), pause)
                    XCTAssertEqual(owner.allows(.startLive), resume)
                    XCTAssertFalse(owner.allows(.startDryRun))
                    XCTAssertFalse(owner.allows(.revoke))
                }
            }
        }
    }

    func testOwnerDryRunAndRevokeNeverSubmitEvenWhenParkedLaneAllowsThem() async throws {
        for action in [KashbotRunnerAction.startDryRun, .revoke] {
            var submissions = 0
            let flow = AccountRunnerControlFlow(readStatus: {
                try self.status(self.execution(), trading: "ready")
            }, submit: { _, _ in submissions += 1 }, credentialIdentity: { "device" },
                submitOwner: { _, _, _ in submissions += 1 })
            do {
                _ = try await flow.perform(action, expectedTenantID: tenant, expectedLaneID: lane)
                XCTFail("Owner lane-only action must refuse")
            } catch { XCTAssertEqual(error as? AccountRunnerControlError, .unavailable) }
            XCTAssertEqual(submissions, 0)
        }
    }

    func testResumePlanExactBytesAndSignatureBindGenerationNonceAndRequestID() async throws {
        let plan = try OwnerDomainResumePlan(execution: XCTUnwrap(status(execution()).execution),
                                            requestID: requestID, now: Date(timeIntervalSince1970: 0))
        let golden = #"{"domain":"legacy-owner","expect_generation":3,"expires_at":"1970-01-01T00:10:00Z","frozen_at":"1970-01-01T00:00:00Z","host":"holder","kind":"domain-resume-v1","member_key":"owner","request_id":"aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa","resume_nonce":"0123456789abcdef0123456789abcdef"}"#
        XCTAssertEqual(plan.bytes, Data(golden.utf8))
        let key = SoftwareDecisionKey(scalar: 1)
        let presence = try await DecisionSigner(key: key).signDomainResume(plan: plan, account: "00000001", issuedAtMs: 1234)
        XCTAssertEqual(Data(presence.plan.utf8), plan.bytes)
        let assertion = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(presence.assertion.utf8)) as? [String: Any])
        XCTAssertEqual(Set(assertion.keys), ["kind", "credential_id", "decision", "signature_b64"])
        XCTAssertEqual(assertion["kind"] as? String, "se-p256")
        let signed = try XCTUnwrap(assertion["decision"] as? [String: Any])
        XCTAssertEqual(signed["verb"] as? String, "accept")
        XCTAssertEqual(signed["proposal_id"] as? String, requestID.uuidString.lowercased())
        XCTAssertEqual((signed["plan_seq"] as? NSNumber)?.int64Value, 3)
        XCTAssertEqual(signed["runner_nonce"] as? String, nonce)
        XCTAssertEqual(signed["account"] as? String, "00000001")
        XCTAssertEqual(signed["plan_sha256"] as? String, TuningSyntax.sha256Hex(plan.bytes))
        let signature = try XCTUnwrap(Data(base64Encoded: try XCTUnwrap(assertion["signature_b64"] as? String)))
        let message = try plan.decision(account: "00000001", issuedAtMs: 1234).messageBytes()
        XCTAssertEqual(key.signedMessages, [message])
        XCTAssertTrue(PresenceSPKI.signatureValid(spki: try key.publicKeySPKI(), signatureDER: signature, message: message))
        var changedNonce = execution()
        changedNonce["pause"] = ["state": "paused", "generation": 3,
                                 "resume_nonce": String(repeating: "a", count: 32)] as [String: Any]
        for changed in [execution(generation: 4), changedNonce] {
            let other = try OwnerDomainResumePlan(execution: XCTUnwrap(status(changed).execution),
                                                 requestID: requestID, now: Date(timeIntervalSince1970: 0))
            let otherMessage = try other.decision(account: "00000001", issuedAtMs: 1234).messageBytes()
            XCTAssertFalse(PresenceSPKI.signatureValid(spki: try key.publicKeySPKI(), signatureDER: signature, message: otherMessage))
        }
        let other = try OwnerDomainResumePlan(execution: XCTUnwrap(status(execution()).execution),
                                             requestID: UUID(), now: Date(timeIntervalSince1970: 0))
        XCTAssertNotEqual(other.requestID, plan.requestID)
        XCTAssertFalse(PresenceSPKI.signatureValid(spki: try key.publicKeySPKI(), signatureDER: signature,
            message: try other.decision(account: "00000001", issuedAtMs: 1234).messageBytes()))
    }

    func testIncompleteResumeStatusCannotBuildAPresencePlan() throws {
        var invalid = [execution(generation: 0), execution(state: "resumed"), execution(host: "")]
        for key in ["generation", "resume_nonce"] {
            var fields = execution()
            var pause = try XCTUnwrap(fields["pause"] as? [String: Any])
            pause.removeValue(forKey: key)
            fields["pause"] = pause
            invalid.append(fields)
        }
        for fields in invalid {
            XCTAssertThrowsError(try OwnerDomainResumePlan(execution: XCTUnwrap(status(fields).execution), requestID: requestID))
        }
    }

    func testRegistryMemberNameIsNotAValidDecisionAccount() async throws {
        let key = SoftwareDecisionKey(scalar: 1)
        let plan = try OwnerDomainResumePlan(execution: XCTUnwrap(status(execution()).execution), requestID: requestID)
        do {
            _ = try await DecisionSigner(key: key).signDomainResume(plan: plan, account: "owner", issuedAtMs: 1234)
            XCTFail("Decisions require the server-mapped eight-character account id")
        } catch { XCTAssertEqual(error as? DecisionSignerError, .invalidDecision("account")) }
        XCTAssertTrue(key.signedMessages.isEmpty)
    }

    func testPauseAndResumeWaitForGenerationAndPendingState() async throws {
        for action in [KashbotRunnerAction.pause, .startLive] {
            var reads = 0
            var posts = 0
            var progress: [String] = []
            let target = action == .pause ? "paused" : "resumed"
            let initial = action == .pause ? "resumed" : "paused"
            let kind = action == .pause ? "domain.pause" : "domain.resume"
            let flow = AccountRunnerControlFlow(readStatus: {
                reads += 1
                return try self.status(self.execution(generation: reads < 3 ? 3 : 4,
                    state: reads == 1 ? initial : target,
                    pending: reads == 3 ? "requested" : reads == 4 ? "applied" : nil, kind: kind))
            }, submit: { _, _ in XCTFail("Owner must never submit a tenant command") },
                credentialIdentity: { "device" }, sleep: { _ in },
                submitOwner: { actual, id, execution in
                    XCTAssertEqual(actual, action)
                    XCTAssertEqual(execution.pause?.generation, 3)
                    XCTAssertNotNil(UUID(uuidString: id.uuidString))
                    posts += 1
                }, observeStatus: { if let label = $0.execution?.pendingLabel { progress.append(label) } })
            let result = try await flow.perform(action, expectedTenantID: tenant, expectedLaneID: lane)
            XCTAssertEqual(result.execution?.pause?.generation, 4)
            XCTAssertEqual(result.execution?.pause?.state, target)
            XCTAssertEqual(reads, 4, "Neither stale generation nor a still-requested row proves completion")
            XCTAssertEqual(posts, 1)
            XCTAssertTrue(progress.contains(action == .pause ? "Pausing" : "Resuming"))
            XCTAssertFalse(flow.running)
        }
    }

    func testOwnerDeadlineIs120SecondsAndTenantLiveCannotCompleteIt() async throws {
        var clock: TimeInterval = 0
        var reads = 0
        var posts = 0
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            return try self.status(self.execution(state: reads == 1 ? "paused" : "resumed"), trading: "live")
        }, submit: { _, _ in XCTFail("Tenant submission") }, credentialIdentity: { "device" },
            sleep: { clock += Double($0) / 1_000_000_000 }, now: { clock },
            submitOwner: { _, _, _ in posts += 1 })
        do {
            _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("A stale generation cannot complete owner resume")
        } catch { XCTAssertEqual(error as? AccountRunnerControlError, .timedOut) }
        XCTAssertEqual(clock, 120)
        XCTAssertEqual(reads, 61)
        XCTAssertEqual(posts, 1)
    }

    func testOwnerRefusalPendingAndScopeDriftDoNotRetry() async throws {
        for scenario in ["pending", "rejected", "host_changed", "owner_removed"] {
            var posts = 0
            var reads = 0
            let flow = AccountRunnerControlFlow(readStatus: {
                reads += 1
                var fields = self.execution(pending: scenario == "pending" ? "requested" : reads > 1 && scenario == "rejected" ? "rejected" : nil,
                                            host: reads > 1 && scenario == "host_changed" ? "other" : "holder")
                if reads > 1 && scenario == "owner_removed" { fields = self.execution(owner: false) }
                return try self.status(fields)
            }, submit: { _, _ in XCTFail("Tenant submission") }, credentialIdentity: { "device" },
                submitOwner: { _, _, _ in posts += 1 })
            do {
                _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
                XCTFail("Must refuse \(scenario)")
            } catch {
                if scenario == "pending" { XCTAssertEqual(error as? DashboardClientError, .refused("request_pending")) }
                else { XCTAssertEqual(error as? AccountRunnerControlError, scenario == "rejected" ? .failed : .scopeChanged) }
            }
            XCTAssertEqual(posts, scenario == "pending" ? 0 : 1)
        }
    }

    func testLostOwnerReplyOnlyReadsBack() async throws {
        for failure in [DashboardClientError.transport, .decoding] {
            var posts = 0
            let flow = AccountRunnerControlFlow(readStatus: {
                try self.status(self.execution(generation: posts == 0 ? 3 : 4, state: posts == 0 ? "paused" : "resumed"))
            }, submit: { _, _ in XCTFail("Tenant submission") }, credentialIdentity: { "device" },
                submitOwner: { _, _, _ in posts += 1; throw failure })
            let result = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTAssertEqual(result.execution?.pause?.generation, 4)
            XCTAssertEqual(posts, 1)
        }
    }

    func testPresenceCancellationSendsNothing() async throws {
        let key = SoftwareDecisionKey(scalar: 1)
        key.failure = DecisionSignerError.userCancelled
        var reads = 0
        var posts = 0
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            return try self.status(self.execution())
        }, submit: { _, _ in XCTFail("Tenant submission") }, credentialIdentity: { "device" },
            submitOwner: { _, id, execution in
                let plan = try OwnerDomainResumePlan(execution: execution, requestID: id)
                _ = try await DecisionSigner(key: key).signDomainResume(plan: plan, account: "00000001", issuedAtMs: 1234)
                posts += 1
            })
        do {
            _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Presence cancellation must stop")
        } catch { XCTAssertEqual(error as? DecisionSignerError, .userCancelled) }
        XCTAssertEqual(reads, 1)
        XCTAssertEqual(posts, 0)
    }

    func testTenantPathAndSixtySecondDeadlineRemainUnchanged() async throws {
        for completed in [false, true] {
            var clock: TimeInterval = 0
            var posts = 0
            let flow = AccountRunnerControlFlow(readStatus: {
                try self.status(self.execution(owner: false), trading: posts == 0 || !completed ? "dry_run" : "live")
            }, submit: { action, _ in XCTAssertEqual(action, .startLive); posts += 1 },
                credentialIdentity: { "device" }, sleep: { clock += Double($0) / 1_000_000_000 }, now: { clock },
                submitOwner: { _, _, _ in XCTFail("Tenant must not use owner presence") })
            do {
                let result = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
                XCTAssertTrue(completed)
                XCTAssertEqual(result.automatedTrading, .live)
            } catch {
                XCTAssertFalse(completed)
                XCTAssertEqual(error as? AccountRunnerControlError, .timedOut)
            }
            XCTAssertEqual(clock, completed ? 0 : 60)
            XCTAssertEqual(posts, 1)
        }
    }

    func testSignedPresenceReachesRunnerWithExactPlanAndGeneration() async throws {
        let plan = try OwnerDomainResumePlan(execution: XCTUnwrap(status(execution()).execution), requestID: requestID)
        let presence = try await DecisionSigner(key: SoftwareDecisionKey(scalar: 1)).signDomainResume(
            plan: plan, account: "00000001", issuedAtMs: TuningSyntax.milliseconds(Date()))
        var posts = 0
        OwnerDomainStub.handler = { request in
            posts += 1
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.url?.path, "/api/kashbot/runner")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: OwnerDomainStub.body(request)) as? [String: Any])
            XCTAssertEqual(Set(body.keys), ["action", "client_request_id", "expect_generation", "presence"])
            XCTAssertEqual(body["action"] as? String, "start_live")
            XCTAssertEqual(body["client_request_id"] as? String, plan.requestID)
            XCTAssertEqual((body["expect_generation"] as? NSNumber)?.int64Value, 3)
            let sent = try XCTUnwrap(body["presence"] as? [String: String])
            XCTAssertEqual(sent, ["assertion": presence.assertion, "plan": presence.plan])
            return (202, Data(#"{"id":"row"}"#.utf8))
        }
        defer { OwnerDomainStub.handler = nil }
        let client = DashboardClient(protocolClasses: [OwnerDomainStub.self], token: { "device-token" })
        try await client.ownerRunnerAction(.startLive, clientRequestId: requestID, presence: presence, expectGeneration: plan.generation)
        XCTAssertEqual(posts, 1)
    }

    func testOwnerPauseUsesExistingActionAndMaps409Codes() async throws {
        var posts = 0
        OwnerDomainStub.handler = { request in
            posts += 1
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: OwnerDomainStub.body(request)) as? [String: String])
            XCTAssertEqual(body, ["action": "pause", "client_request_id": self.requestID.uuidString.lowercased()])
            return (202, Data(#"{"request":{"id":"row","kind":"domain.pause"}}"#.utf8))
        }
        defer { OwnerDomainStub.handler = nil }
        let client = DashboardClient(protocolClasses: [OwnerDomainStub.self], token: { "device-token" })
        try await client.ownerRunnerAction(.pause, clientRequestId: requestID)
        XCTAssertEqual(posts, 1)
        for code in ["presence_required", "owner_lane_parked", "request_pending"] {
            OwnerDomainStub.handler = { _ in (409, Data("{\"error\":\"\(code)\"}".utf8)) }
            do {
                try await client.ownerRunnerAction(.pause, clientRequestId: requestID)
                XCTFail("Expected \(code)")
            } catch {
                XCTAssertEqual(error as? DashboardClientError, .refused(code))
                XCTAssertNotNil(DashboardClient.ownerControlMessage(for: error))
            }
        }
    }

    func testTenantRunnerKeepsItsExisting409ErrorType() async throws {
        defer { OwnerDomainStub.handler = nil }
        let client = DashboardClient(protocolClasses: [OwnerDomainStub.self], token: { "device-token" })
        for code in ["presence_required", "owner_lane_parked", "request_pending"] {
            OwnerDomainStub.handler = { _ in (409, Data("{\"error\":\"\(code)\"}".utf8)) }
            do {
                _ = try await client.pauseTrading(clientRequestId: requestID)
                XCTFail("Expected HTTP refusal")
            } catch { XCTAssertEqual(error as? DashboardClientError, .http(409)) }
        }
    }
}

private final class OwnerDomainStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                                                       httpVersion: nil, headerFields: nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}

    static func body(_ request: URLRequest) throws -> Data {
        if let data = request.httpBody { return data }
        let stream = try XCTUnwrap(request.httpBodyStream)
        stream.open()
        defer { stream.close() }
        var data = Data()
        var buffer = [UInt8](repeating: 0, count: 4096)
        while stream.hasBytesAvailable {
            let count = stream.read(&buffer, maxLength: 4096)
            guard count >= 0 else { throw DashboardClientError.decoding }
            if count == 0 { break }
            data.append(contentsOf: buffer.prefix(count))
        }
        return data
    }
}
