import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class FixtureModeTests: XCTestCase {
    private let fixtures = FixtureMode(arguments: ["app", "-LEAFHFT_FIXTURES", "1"])

    func testFlagRequiresExplicitOne() {
        XCTAssertFalse(FixtureMode(arguments: ["-LEAFHFT_FIXTURES"]).enabled)
        XCTAssertFalse(FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "0"]).enabled)
        XCTAssertTrue(fixtures.enabled)
    }

    @MainActor func testCorpusFixturesSeedAccountAndRunnerViewsWithoutPolling() async throws {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        let state = AppState(fixtureMode: fixtures, bundle: Bundle(for: Self.self), now: now)
        XCTAssertEqual(state.fixtureFilesLoaded, FixtureCorpus.names.filter { $0 != "markets" }.count)
        XCTAssertGreaterThanOrEqual(state.fixtureFilesLoaded, 10)
        XCTAssertEqual(state.balance?.balance, 2388)
        XCTAssertEqual(state.books?.books.count, 14)
        XCTAssertTrue(try XCTUnwrap(state.books).books.allSatisfy { $0.kalshiBook.eval != nil })
        XCTAssertEqual(state.engines?.engines?.count, 2)
        XCTAssertEqual(state.positions.first?.ticker, "FIXTURE-T")
        XCTAssertEqual(state.recentFills.first?.tradeId, "trade-fixture")
        XCTAssertEqual(state.runnerActivity?.budget?.aggregateStakeCents, 7_000)
        XCTAssertEqual(state.runnerActivity?.refusals.first?.refusalLabel, "Cash floor protected")
        for (range, count) in [(HistoryRange.hour, 2), (.fourHours, 2), (.twelveHours, 2),
                               (.day, 2), (.week, 4), (.month, 6), (.all, 6)] {
            let selected = state.cash.selected(range, now: now)
            XCTAssertEqual(selected.count, count)
            XCTAssertTrue(selected.allSatisfy { $0.cashCents == state.balance?.balance })
            XCTAssertEqual(state.accountValue.selected(range, now: now).count, count)
        }
        state.sceneChanged(.active)
        XCTAssertEqual(state.balanceObservedAt, now)
        let intent = try ControlIntent.bind(symbol: nil, engineId: "default")
        let refusal = await state.submit(intent, note: nil)
        XCTAssertEqual(refusal, "Controls are disabled in fixture mode.")
        XCTAssertTrue(state.pendingRequests.isEmpty)
    }

    @MainActor func testNoKeyShowsPromptAndDoesNotLoadAccount() {
        let mode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_NO_KEY", "1"])
        let state = AppState(fixtureMode: mode, bundle: Bundle(for: Self.self))
        XCTAssertNil(state.balance)
        XCTAssertTrue(state.cash.observations.isEmpty)
        XCTAssertEqual(state.kalshiError, "Import your runner key in Settings.")
    }

    func testFixtureClientsRefuseBeforeAnyCredentialRead() async throws {
        let kalshi = KalshiClient(fixtureMode: fixtures, credential: {
            XCTFail("Fixture client reached credential access")
            throw FixtureAccessError.disabled
        })
        let dashboard = DashboardClient(fixtureMode: fixtures, token: {
            XCTFail("Fixture client reached credential access")
            throw FixtureAccessError.disabled
        })
        do { let _: AccountBalance = try await kalshi.get(.balance, as: AccountBalance.self); XCTFail("Live access allowed") }
        catch { XCTAssertTrue(error is FixtureAccessError) }
        do { _ = try await dashboard.books(); XCTFail("Live access allowed") }
        catch { XCTAssertTrue(error is FixtureAccessError) }
        do { _ = try await dashboard.engines(); XCTFail("Live access allowed") }
        catch { XCTAssertTrue(error is FixtureAccessError) }
        do { _ = try await dashboard.activity(); XCTFail("Live access allowed") }
        catch { XCTAssertTrue(error is FixtureAccessError) }
        do {
            _ = try await dashboard.control(.bind(symbol: nil, engineId: "default"), note: nil)
            XCTFail("Live control allowed")
        } catch { XCTAssertTrue(error is FixtureAccessError) }
    }

    func testEveryRealHostIsRejectedBeforeTransport() async throws {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [FixtureNetworkBlocker.self]
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }
        // Arbitrary domains and IP literals must all be captured, not a host allowlist.
        for host in ["api.elections.kalshi.com", "ops-dashboard-seven.vercel.app", "example.com", "127.0.0.1", "192.0.2.1", "new-unlisted-host.example"] {
            let url = try XCTUnwrap(URL(string: "https://\(host)/fixture-boundary"))
            XCTAssertTrue(FixtureNetworkBlocker.canInit(with: URLRequest(url: url)))
            do { _ = try await session.data(from: url); XCTFail("Fixture request escaped for \(host)") }
            catch { XCTAssertEqual((error as? URLError)?.code, .notConnectedToInternet) }
        }
    }
}
