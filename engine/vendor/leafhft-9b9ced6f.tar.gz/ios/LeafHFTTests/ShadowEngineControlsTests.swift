import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class ShadowEngineControlsTests: XCTestCase {
    private func engines(configured: Bool = true, shadowOnly: Bool = false) throws -> EnginesResponse {
        let configuration = configured ? #"""
        {
          "global": {"enabled": true, "revision": "global-r1", "policy": {"min_k": 30}},
          "accounts": [{
            "account_id": "owner", "revision": "account-r1",
            "override": {"enabled": null, "policy": {}},
            "effective": {"enabled": true, "policy": {"min_k": 30}}
          }]
        }
        """# : "null"
        let json = """
        {
          "generated_at": "2026-10-03T02:00:00Z",
          "accounts": [{"id": "owner", "label": "Owner", "host": "runner", "configurable": true}],
          "engines": [{
            "engine_id": "15m-late-k30-9094-conv", "name": "15M Late K30 9094 Conv",
            "description": "Live engine description", "reason": "Catalog reason",
            "shadow_only": \(shadowOnly), "configuration": \(configuration)
          }]
        }
        """
        return try DashboardClient.decodeSnapshot(EnginesResponse.self, from: Data(json.utf8))
    }

    private func lab(shadowOnly: Bool = true) throws -> EngineLab.Response {
        let json = """
        {
          "schema_version": 3, "generated_at": "2026-10-03T02:00:00Z",
          "advisory": true, "stale": false, "missing_value": "not_reported",
          "evidence": [], "problems": [], "events": [], "events_truncated": false,
          "candidates": [{
            "id": "15m-late-k30-9094-conv", "engine_id": "15m-late-k30-9094-conv",
            "name": "15M Late K30 9094 Conv", "enabled": false, "shadow_only": \(shadowOnly),
            "reason": "Report input unavailable or invalid", "promotion_verdict": "not_reported",
            "live_profit_cents": "not_reported", "evidence": [],
            "source_timestamp": "not_reported", "provenance": "shadow"
          }]
        }
        """
        return try EngineLab.decodeResponse(Data(json.utf8))
    }

    private func bytes<T: Encodable>(_ value: T) throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return try encoder.encode(value)
    }

    func testLabShadowReasonIsNilForLiveConfiguration() throws {
        XCTAssertNil(AppState.labShadowReason(engineId: "15m-late-k30-9094-conv", engines: try engines(), lab: try lab()))
    }

    func testLabShadowReasonReturnsReasonForNullConfiguration() throws {
        let metadata = try lab()
        XCTAssertEqual(AppState.labShadowReason(engineId: "15m-late-k30-9094-conv", engines: try engines(configured: false), lab: metadata),
                       metadata.candidates.first?.reason)
    }

    func testLabShadowReasonReturnsReasonForAbsentEngine() throws {
        var response = try engines()
        response.engines = []
        let metadata = try lab()
        XCTAssertEqual(AppState.labShadowReason(engineId: "15m-late-k30-9094-conv", engines: response, lab: metadata),
                       metadata.candidates.first?.reason)
    }

    func testLabShadowReasonIsNilForNonShadowCandidate() throws {
        XCTAssertNil(AppState.labShadowReason(engineId: "15m-late-k30-9094-conv", engines: try engines(configured: false), lab: try lab(shadowOnly: false)))
    }

    func testLabShadowReasonIsNilWithoutLab() throws {
        XCTAssertNil(AppState.labShadowReason(engineId: "15m-late-k30-9094-conv", engines: try engines(configured: false), lab: nil))
    }

    func testLabShadowFlagPreservesLiveConfiguration() throws {
        let original = try engines()
        let result = AppState.applyShadowControls(to: original, lab: try lab())
        let before = try XCTUnwrap(original.engines?.first)
        let after = try XCTUnwrap(result.engines?.first)
        let configuration = try XCTUnwrap(after.configuration)
        XCTAssertEqual(try bytes(configuration), try bytes(XCTUnwrap(before.configuration)))
        XCTAssertEqual(configuration.global.enabled, true)
        XCTAssertEqual(configuration.accounts.first?.effective.enabled, true)
        XCTAssertEqual(configuration.global.revision, "global-r1")
        XCTAssertEqual(configuration.accounts.first?.revision, "account-r1")
        XCTAssertEqual(after.shadowOnly, false)
        XCTAssertEqual(after.reason, before.reason)
        XCTAssertEqual(after.description, before.description)
        XCTAssertEqual(try bytes(result), try bytes(original))
    }

    func testLabShadowFlagAppliesWhenConfigurationIsNull() throws {
        let original = try engines(configured: false)
        let metadata = try lab()
        let result = AppState.applyShadowControls(to: original, lab: metadata)
        let engine = try XCTUnwrap(result.engines?.first)
        XCTAssertNil(engine.configuration)
        XCTAssertEqual(engine.shadowOnly, true)
        XCTAssertEqual(engine.reason, metadata.candidates.first?.reason)
        XCTAssertEqual(engine.description, engine.reason)
    }

    func testEngineResponseShadowFlagStillDisablesConfiguration() throws {
        let original = try engines(shadowOnly: true)
        let metadata = try lab()
        let result = AppState.applyShadowControls(to: original, lab: metadata)
        let engine = try XCTUnwrap(result.engines?.first)
        XCTAssertNil(engine.configuration)
        XCTAssertEqual(engine.shadowOnly, true)
        XCTAssertEqual(engine.reason, metadata.candidates.first?.reason)
        XCTAssertEqual(engine.description, engine.reason)
    }

    func testNilLabLeavesResponseUnchanged() throws {
        let original = try engines()
        XCTAssertEqual(try bytes(AppState.applyShadowControls(to: original, lab: nil)), try bytes(original))
    }

    func testNonShadowCandidateLeavesEngineUnchanged() throws {
        for configured in [true, false] {
            let original = try engines(configured: configured)
            let result = AppState.applyShadowControls(to: original, lab: try lab(shadowOnly: false))
            XCTAssertEqual(try bytes(result), try bytes(original))
        }
    }
}
