import XCTest
@testable import LeafHFT

@MainActor final class BooksToggleRuleTests: XCTestCase {
    func testEveryToggleInputIncludingRestoredBooks() {
        for fixture in [false, true] {
            for submitting in [false, true] {
                for outcomeUnknown in [false, true] {
                    for hasHost in [false, true] {
                        for restored in [false, true] {
                            let allowed = BooksView.canToggle(fixture: fixture, submitting: submitting,
                                outcomeUnknown: outcomeUnknown, hasHost: hasHost, restored: restored)
                            let expected = !fixture && !submitting && !outcomeUnknown && hasHost && !restored
                            XCTAssertEqual(allowed, expected,
                                "fixture=\(fixture) submitting=\(submitting) unknown=\(outcomeUnknown) host=\(hasHost) restored=\(restored)")
                        }
                    }
                }
            }
        }
    }
}
