import Foundation
import XCTest
@testable import LeafHFT

final class DashboardSnapshotStoreTests: XCTestCase {
    private var directory: URL!
    private let now = Date(timeIntervalSince1970: 1_800_000_000.125)
    private var identity: String { String(repeating: "a", count: 64) }
    private let payload = Data([0, 1, 2, 127, 128, 255])

    override func setUpWithError() throws {
        directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
    }

    override func tearDownWithError() throws {
        if FileManager.default.fileExists(atPath: directory.path) {
            try FileManager.default.removeItem(at: directory)
        }
    }

    private func file(_ name: String = "books") -> URL { directory.appendingPathComponent(name + ".json") }

    func testRoundTripRawBytesAndSavedAtForEveryDisplayFeed() async throws {
        let store = DashboardSnapshotStore(directory: directory)
        for feed in [DashboardFeed.books, .activity, .exits, .calibration] {
            await store.save(feed: feed, payload: payload, identity: identity, now: now)
            let loaded = await store.load(feed: feed, identity: identity, now: now)
            let saved = try XCTUnwrap(loaded)
            XCTAssertEqual(saved.payload, payload)
            XCTAssertEqual(saved.savedAt, now)
        }
        let envelope = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: file())) as? [String: Any])
        XCTAssertEqual(envelope["schema"] as? Int, 1)
        XCTAssertEqual(envelope["feed"] as? String, "books")
        XCTAssertEqual(envelope["identity"] as? String, identity)
        XCTAssertEqual(envelope["payload"] as? String, payload.base64EncodedString())
        XCTAssertTrue(envelope["savedAt"] is String)
        XCTAssertEqual(try file().resourceValues(forKeys: [.isExcludedFromBackupKey]).isExcludedFromBackup, true)
        #if !targetEnvironment(simulator)
        let attributes = try FileManager.default.attributesOfItem(atPath: file().path)
        XCTAssertEqual(attributes[.protectionKey] as? FileProtectionType, .completeUntilFirstUserAuthentication)
        #endif
    }

    func testIdentityMismatchDeletesSnapshot() async {
        let store = DashboardSnapshotStore(directory: directory)
        await store.save(feed: .books, payload: payload, identity: identity, now: now)
        let loaded = await store.load(feed: .books, identity: String(repeating: "b", count: 64), now: now)
        XCTAssertNil(loaded)
        XCTAssertFalse(FileManager.default.fileExists(atPath: file().path))
    }

    func testExpiredAndFutureSnapshotsAreDeleted() async {
        let store = DashboardSnapshotStore(directory: directory)
        for savedAt in [now.addingTimeInterval(-7 * 86400 - 1), now.addingTimeInterval(61)] {
            await store.save(feed: .books, payload: payload, identity: identity, now: savedAt)
            let loaded = await store.load(feed: .books, identity: identity, now: now)
            XCTAssertNil(loaded)
            XCTAssertFalse(FileManager.default.fileExists(atPath: file().path))
        }
    }

    func testAgeAndFutureToleranceBoundariesRemainReadable() async {
        let store = DashboardSnapshotStore(directory: directory)
        for savedAt in [now.addingTimeInterval(-7 * 86400), now.addingTimeInterval(60)] {
            await store.clear()
            await store.save(feed: .books, payload: payload, identity: identity, now: savedAt)
            let loaded = await store.load(feed: .books, identity: identity, now: now)
            XCTAssertNotNil(loaded)
        }
    }

    func testCorruptJSONDeletesSnapshot() async throws {
        let store = DashboardSnapshotStore(directory: directory)
        await store.save(feed: .books, payload: payload, identity: identity, now: now)
        try Data("not JSON".utf8).write(to: file())
        let loaded = await store.load(feed: .books, identity: identity, now: now)
        XCTAssertNil(loaded)
        XCTAssertFalse(FileManager.default.fileExists(atPath: file().path))
    }

    func testWrongFeedAndSchemaDeleteSnapshot() async throws {
        let store = DashboardSnapshotStore(directory: directory)
        for (field, value) in [("feed", "engines" as Any), ("schema", 2 as Any)] {
            await store.save(feed: .books, payload: payload, identity: identity, now: now)
            var envelope = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: file())) as? [String: Any])
            envelope[field] = value
            try JSONSerialization.data(withJSONObject: envelope).write(to: file())
            let loaded = await store.load(feed: .books, identity: identity, now: now)
            XCTAssertNil(loaded)
            XCTAssertFalse(FileManager.default.fileExists(atPath: file().path))
        }
    }

    func testOversizedPayloadPreservesOlderSnapshot() async throws {
        let store = DashboardSnapshotStore(directory: directory)
        await store.save(feed: .books, payload: payload, identity: identity, now: now)
        let original = try Data(contentsOf: file())
        await store.save(feed: .books, payload: Data(repeating: 32, count: 1_048_577),
            identity: identity, now: now.addingTimeInterval(1))
        XCTAssertEqual(try Data(contentsOf: file()), original)
        let loaded = await store.load(feed: .books, identity: identity, now: now)
        XCTAssertEqual(loaded?.payload, payload)
    }

    func testIdenticalBytesAreNotRewrittenAndClearResetsDeduplication() async {
        let store = DashboardSnapshotStore(directory: directory)
        await store.save(feed: .books, payload: payload, identity: identity, now: now)
        await store.save(feed: .books, payload: payload, identity: identity, now: now.addingTimeInterval(20))
        let count = await store.writeCount
        let loaded = await store.load(feed: .books, identity: identity, now: now.addingTimeInterval(20))
        XCTAssertEqual(count, 1)
        XCTAssertEqual(loaded?.savedAt, now)
        await store.clear()
        await store.save(feed: .books, payload: payload, identity: identity, now: now)
        let afterClear = await store.writeCount
        XCTAssertEqual(afterClear, 2)
    }

    func testClearRemovesWholeDirectoryAndPrepareClearsPreviousIdentity() async throws {
        let store = DashboardSnapshotStore(directory: directory)
        await store.save(feed: .books, payload: payload, identity: identity, now: now)
        await store.save(feed: .activity, payload: payload, identity: identity, now: now)
        try Data("extra".utf8).write(to: directory.appendingPathComponent("extra"))
        await store.clear()
        XCTAssertFalse(FileManager.default.fileExists(atPath: directory.path))
        await store.save(feed: .books, payload: payload, identity: identity, now: now)
        await store.prepare(identity: String(repeating: "b", count: 64))
        XCTAssertFalse(FileManager.default.fileExists(atPath: directory.path))
    }

    func testControlAndAccountFeedsAreNeverSaved() async {
        let store = DashboardSnapshotStore(directory: directory)
        for feed in [DashboardFeed.engines, .status, .probes, .engineLab, .accountHistory] {
            await store.save(feed: feed, payload: payload, identity: identity, now: now)
            let loaded = await store.load(feed: feed, identity: identity, now: now)
            XCTAssertNil(loaded)
        }
        XCTAssertFalse(FileManager.default.fileExists(atPath: directory.path))
    }
}
