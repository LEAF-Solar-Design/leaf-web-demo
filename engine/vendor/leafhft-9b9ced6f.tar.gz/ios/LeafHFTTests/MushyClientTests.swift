import Foundation
import XCTest
@testable import LeafHFT

final class MushyStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                httpVersion: nil, headerFields: nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
    static func body(_ request: URLRequest) throws -> Data {
        if let body = request.httpBody { return body }
        let stream = try XCTUnwrap(request.httpBodyStream)
        stream.open()
        defer { stream.close() }
        var data = Data()
        var buffer = [UInt8](repeating: 0, count: 4096)
        while stream.hasBytesAvailable {
            let count = stream.read(&buffer, maxLength: buffer.count)
            if count < 0 { throw URLError(.cannotDecodeRawData) }
            if count == 0 { break }
            data.append(contentsOf: buffer.prefix(count))
        }
        return data
    }
}

@MainActor final class MushyClientTests: XCTestCase {
    override func tearDown() { MushyStub.handler = nil; super.tearDown() }
    private let mode = FixtureMode(arguments: [])
    private let root = "/api/leafhft/mobile/mushy"
    private let jobId = MushyClient.fixtureArtifactId

    private func client(token: @escaping () throws -> String = { "test-device" }) -> MushyClient {
        MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: token)
    }
    private func endpoint(_ request: URLRequest) -> String {
        let components = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)
        if components?.path == "/api/leafhft/mobile/engines",
           components?.queryItems == [URLQueryItem(name: "__kashbot", value: "mushy-catalog")],
           request.value(forHTTPHeaderField: "X-Kashbot-Route") == "mushy-catalog" {
            return "catalog"
        }
        return request.url!.lastPathComponent
    }
    private func pending<T: Encodable>(_ value: T, kind: MushyPendingRequest.Kind, path: String) throws -> MushyPendingRequest {
        let data = try MushyCoding.encoder().encode(value)
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        return MushyPendingRequest(requestId: try XCTUnwrap(object["request_id"] as? String), kind: kind, path: path, body: data)
    }

    func testCatalogDistinguishesUnboundAccountFromAuthentication() async throws {
        let transport = client()
        let identity = try transport.identity()
        for status in [403, 401] {
            MushyStub.handler = { request in
                XCTAssertEqual(self.endpoint(request), "catalog")
                return (status, Data())
            }
            do {
                _ = try await transport.catalog(identity: identity)
                XCTFail("Expected catalog access error")
            } catch let error as MushyClientError {
                switch (status, error) {
                case (403, .notBound):
                    XCTAssertEqual(error.localizedDescription, "Finish account setup in Settings to use the assistant.")
                case (401, .authentication):
                    XCTAssertEqual(error.localizedDescription, "Connect your dashboard in Settings to use Studio.")
                default: XCTFail("Unexpected catalog access error: \(error)")
                }
            }
        }
    }

    func testUnsendableTurnCanBeDiscardedDurablyWithoutReplacingNewInput() async throws {
        for input in [" \n", "A newer draft"] {
            let suite = "mushy-tests-" + UUID().uuidString
            let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
            defer { defaults.removePersistentDomain(forName: suite) }
            let encoder = MushyCoding.encoder()
            let turn = MushyTurnRequest(requestId: UUID().uuidString.lowercased(), sessionId: MushyClient.fixtureSessionId,
                input: "Restore this request", modelId: "preview-model", reasoningId: "medium", sources: ["account.history"])
            var recovery = MushyRecovery()
            recovery.input = input
            recovery.pending = try pending(turn, kind: .turn, path: "/turn")
            defaults.set(try encoder.encode(recovery), forKey: MushyState.recoveryKey)
            var remote = MushyClient.fixtureSnapshot
            remote.jobs = []
            MushyStub.handler = { request in
                switch self.endpoint(request) {
                case "catalog": return (200, try encoder.encode(MushyClient.fixtureCatalog))
                case "state": return (200, try encoder.encode(remote))
                case "turn":
                    XCTAssertEqual(try MushyStub.body(request), recovery.pending?.body)
                    return (409, Data())
                default: XCTFail("Unexpected request"); return (404, Data())
                }
            }
            let state = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
            await state.refresh()
            await state.recover()
            XCTAssertTrue(state.pendingLooksUnsendable)
            XCTAssertEqual(state.error, "This saved request can no longer be sent. Discard it to continue.")
            XCTAssertFalse(state.canMutate)
            state.discardPending()
            XCTAssertNil(state.pending)
            XCTAssertFalse(state.pendingLooksUnsendable)
            XCTAssertNil(state.error)
            XCTAssertEqual(state.result, "Saved request discarded. If it had already been accepted it will still appear after a refresh.")
            XCTAssertEqual(state.prompt, input == "A newer draft" ? input : turn.input)
            XCTAssertTrue(state.canMutate)
            let relaunched = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
            XCTAssertNil(relaunched.pending)
            XCTAssertEqual(relaunched.prompt, state.prompt)
        }
    }

    func testRecoveryMarksOnlyPermanentHTTPFailuresUnsendable() async throws {
        for status in [400, 403, 404, 410, 422, 408, 429, 500] {
            let suite = "mushy-tests-" + UUID().uuidString
            let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
            defer { defaults.removePersistentDomain(forName: suite) }
            let encoder = MushyCoding.encoder()
            var recovery = MushyRecovery()
            recovery.pending = try pending(MushySessionRequest(requestId: UUID().uuidString.lowercased()),
                kind: .session, path: "/session")
            defaults.set(try encoder.encode(recovery), forKey: MushyState.recoveryKey)
            MushyStub.handler = { request in
                switch self.endpoint(request) {
                case "catalog": return (200, try encoder.encode(MushyClient.fixtureCatalog))
                case "state": return (200, try encoder.encode(MushySnapshot()))
                case "session": return (status, Data())
                default: XCTFail("Unexpected request"); return (404, Data())
                }
            }
            let state = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
            await state.refresh()
            await state.recover()
            XCTAssertEqual(state.pendingLooksUnsendable, status < 500 && status != 408 && status != 429)
            XCTAssertEqual(state.pending, recovery.pending)
        }
    }

    func testAutomaticRefreshBackoffDoublesCapsAndAllowsManualRefresh() async throws {
        let suite = "mushy-tests-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let encoder = MushyCoding.encoder()
        var clock = Date(timeIntervalSince1970: 1000)
        var catalogs = 0
        var status = 403
        MushyStub.handler = { request in
            switch self.endpoint(request) {
            case "catalog":
                catalogs += 1
                return (status, status == 200 ? try encoder.encode(MushyClient.fixtureCatalog) : Data())
            case "state": return (200, try encoder.encode(MushySnapshot()))
            default: XCTFail("Unexpected request"); return (404, Data())
            }
        }
        let state = MushyState(fixtureMode: mode, client: client(), defaults: defaults, now: { clock })
        await state.tick()
        XCTAssertEqual(catalogs, 1)
        XCTAssertEqual(state.error, "Finish account setup in Settings to use the assistant.")
        for delay in [10.0, 20, 40, 80, 160, 300, 300] {
            let prior = catalogs
            await state.tick()
            XCTAssertEqual(catalogs, prior)
            clock = clock.addingTimeInterval(delay - 1)
            await state.tick()
            XCTAssertEqual(catalogs, prior)
            clock = clock.addingTimeInterval(1)
            await state.tick()
            XCTAssertEqual(catalogs, prior + 1)
        }
        let prior = catalogs
        await state.refresh()
        XCTAssertEqual(catalogs, prior + 1)
        status = 200
        await state.refresh()
        XCTAssertEqual(catalogs, prior + 2)
        XCTAssertNil(state.error)
        XCTAssertTrue(state.canMutate)
        status = 403
        await state.tick()
        XCTAssertEqual(catalogs, prior + 3)
        XCTAssertNil(state.catalog)
        XCTAssertFalse(state.canMutate)
        XCTAssertEqual(state.error, "Finish account setup in Settings to use the assistant.")
        clock = clock.addingTimeInterval(9)
        await state.tick()
        XCTAssertEqual(catalogs, prior + 3)
        clock = clock.addingTimeInterval(1)
        await state.tick()
        XCTAssertEqual(catalogs, prior + 4)
    }

    func testExactAuthenticatedPathsMethodsAndSnakeCaseBodies() async throws {
        var requests: [(String, String, [String: Any])] = []
        let encoder = MushyCoding.encoder()
        MushyStub.handler = { request in
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-device")
            XCTAssertNil(request.value(forHTTPHeaderField: "Cookie"))
            XCTAssertEqual(request.value(forHTTPHeaderField: "Cache-Control"), "no-store")
            let path = try XCTUnwrap(request.url?.path)
            let method = request.httpMethod ?? ""
            let body = method == "POST" ? try XCTUnwrap(JSONSerialization.jsonObject(with: MushyStub.body(request)) as? [String: Any]) : [:]
            requests.append((path, method, body))
            let logicalPath = self.endpoint(request) == "catalog" ? "/catalog" : String(path.dropFirst(self.root.count))
            switch logicalPath {
            case "/catalog":
                XCTAssertEqual(path, "/api/leafhft/mobile/engines")
                XCTAssertEqual(request.value(forHTTPHeaderField: "X-Kashbot-Route"), "mushy-catalog")
                XCTAssertEqual(URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems,
                    [URLQueryItem(name: "__kashbot", value: "mushy-catalog")])
                return (200, try encoder.encode(MushyClient.fixtureCatalog))
            case "/state": return (200, try encoder.encode(MushyClient.fixtureSnapshot))
            case "/session": return (200, try encoder.encode(MushySessionReceipt(sessionId: MushyClient.fixtureSessionId,
                session: MushyClient.fixtureSnapshot.sessions[0])))
            case "/turn": return (200, try encoder.encode(MushyTurnReceipt(jobId: self.jobId, status: "pending")))
            case "/slots":
                if method == "GET" { return (200, try encoder.encode(MushySlots(slots: [:]))) }
                return (200, try encoder.encode(MushySlot(artifactId: self.jobId, artifactVersion: 1,
                    digest: String(repeating: "a", count: 64), revision: 1, history: [])))
            case "/proposals":
                let proposal = MushyProposal(id: self.jobId, artifactId: self.jobId, digest: String(repeating: "a", count: 64),
                    targetSlot: "overview", rationale: "Useful overview", state: "proposed")
                return (200, method == "GET" ? try encoder.encode(MushyProposals(proposals: [proposal])) :
                    try encoder.encode(MushyProposalReceipt(proposal: proposal)))
            case "/jobs/" + self.jobId: return (200, try encoder.encode(MushyClient.fixtureSnapshot.jobs[0]))
            case "/jobs/" + self.jobId + "/events":
                XCTAssertEqual(URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems?.first?.value, "7")
                return (200, try encoder.encode(MushyEvents(jobId: self.jobId, events: [], nextCursor: 7)))
            case "/artifacts/" + self.jobId: return (200, try encoder.encode(MushyClient.fixtureArtifact()))
            case "/config-drafts/" + self.jobId:
                if method == "GET" { return (200, MushyModelsTests.draftData(id: self.jobId)) }
                return (200, try encoder.encode(MushyConfigReceipt(draftId: self.jobId, controlRequestId: "control-1", state: "queued")))
            default: XCTFail("Unexpected route \(path)"); return (404, Data())
            }
        }
        let client = client(), identity = try client.identity()
        let id = UUID().uuidString.lowercased()
        _ = try await client.catalog(identity: identity)
        _ = try await client.snapshot(identity: identity)
        _ = try await client.createSession(pending(MushySessionRequest(requestId: id), kind: .session, path: "/session"), identity: identity)
        _ = try await client.turn(pending(MushyTurnRequest(requestId: id, sessionId: MushyClient.fixtureSessionId,
            input: "Build a view", modelId: "catalog-model", reasoningId: "high", sources: ["account.history"]),
            kind: .turn, path: "/turn"), identity: identity)
        _ = try await client.job(jobId, identity: identity)
        _ = try await client.events(jobId, after: 7, identity: identity)
        _ = try await client.artifact(jobId, identity: identity)
        _ = try await client.slots(identity: identity)
        for action in [MushySlotAction.publish, .rollback] {
            _ = try await client.updateSlot(pending(MushySlotRequest(requestId: id, slot: "overview", action: action,
                artifactId: jobId, expectedRevision: 0), kind: .slot, path: "/slots"), identity: identity)
        }
        _ = try await client.proposals(identity: identity)
        _ = try await client.propose(pending(MushyProposalRequest(requestId: id, artifactId: jobId,
            targetSlot: "overview", rationale: "Useful overview"), kind: .proposal, path: "/proposals"), identity: identity)
        _ = try await client.draft(jobId, identity: identity)
        _ = try await client.applyDraft(pending(MushyConfigApplyRequest(requestId: id, summaryDigest: String(repeating: "a", count: 64)),
            kind: .config, path: "/config-drafts/" + jobId), identity: identity)
        XCTAssertEqual(requests.count, 14)
        let posts = requests.filter { $0.1 == "POST" }
        XCTAssertEqual(Set(posts[0].2.keys), ["request_id"])
        XCTAssertEqual(Set(posts[1].2.keys), ["request_id", "session_id", "input", "model_id", "reasoning_id", "sources"])
        XCTAssertEqual(Set(posts[2].2.keys), ["request_id", "slot", "action", "artifact_id", "expected_revision"])
        XCTAssertEqual(posts[2].2["expected_revision"] as? Int, 0)
        XCTAssertEqual(posts[3].2["action"] as? String, "rollback")
        XCTAssertEqual(Set(posts[4].2.keys), ["request_id", "artifact_id", "target_slot", "rationale"])
        XCTAssertEqual(Set(posts[5].2.keys), ["request_id", "summary_digest"])
    }

    func testSessionReplayAcrossRelaunchAndBearerRotation() async throws {
        let suite = "mushy-tests-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var remote = MushySnapshot()
        var bodies: [Data] = []
        var bearer = "first-device"
        let encoder = MushyCoding.encoder()
        let session = MushyClient.fixtureSnapshot.sessions[0]
        MushyStub.handler = { request in
            switch self.endpoint(request) {
            case "catalog": return (200, try encoder.encode(MushyClient.fixtureCatalog))
            case "state": return (200, try encoder.encode(remote))
            case "session":
                let body = try MushyStub.body(request)
                bodies.append(body)
                let saved = try MushyCoding.decoder().decode(MushyRecovery.self,
                    from: XCTUnwrap(defaults.data(forKey: MushyState.recoveryKey)))
                XCTAssertEqual(saved.pending?.body, body)
                remote.sessions = [session]
                remote.selections.sessionId = session.id
                if bodies.count == 1 { throw URLError(.timedOut) }
                return (200, try encoder.encode(MushySessionReceipt(sessionId: session.id, session: session)))
            default: return (404, Data())
            }
        }
        let transport = client(token: { bearer })
        let first = MushyState(fixtureMode: mode, client: transport, defaults: defaults)
        await first.refresh()
        first.prompt = "Keep this request"
        await first.newSession()
        XCTAssertNotNil(first.pending)
        bearer = "rotated-device"
        let second = MushyState(fixtureMode: mode, client: transport, defaults: defaults)
        await second.refresh()
        await second.recover()
        XCTAssertEqual(bodies.count, 2)
        XCTAssertEqual(bodies.first, bodies.last)
        XCTAssertNil(second.pending)
        XCTAssertEqual(second.selectedSessionId, session.id)
        XCTAssertEqual(second.prompt, "Keep this request")
        XCTAssertEqual(second.snapshot.sessions.count, 1)
    }

    func testTurnUnknownOutcomeRetainsInputAndExactBody() async throws {
        let suite = "mushy-tests-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var remote = MushyClient.fixtureSnapshot
        remote.jobs = []
        var bodies: [Data] = []
        let encoder = MushyCoding.encoder()
        MushyStub.handler = { request in
            switch self.endpoint(request) {
            case "catalog": return (200, try encoder.encode(MushyClient.fixtureCatalog))
            case "state": return (200, try encoder.encode(remote))
            case "turn":
                let body = try MushyStub.body(request)
                bodies.append(body)
                let turn = try MushyCoding.decoder().decode(MushyTurnRequest.self, from: body)
                remote.sessions[0].messages = [.init(role: "user", content: turn.input, jobId: self.jobId, createdAt: "")]
                remote.jobs = [.init(id: self.jobId, status: "pending", createdAt: nil, completedAt: nil, artifactId: nil, error: nil)]
                if bodies.count == 1 { throw URLError(.networkConnectionLost) }
                return (200, try encoder.encode(MushyTurnReceipt(jobId: self.jobId, status: "pending")))
            case self.jobId: return (200, try encoder.encode(remote.jobs[0]))
            default: return (404, Data())
            }
        }
        let transport = client()
        let first = MushyState(fixtureMode: mode, client: transport, defaults: defaults)
        await first.refresh()
        first.prompt = "Explain my balance"
        await first.send()
        XCTAssertNotNil(first.pending)
        let second = MushyState(fixtureMode: mode, client: transport, defaults: defaults)
        await second.refresh()
        await second.recover()
        XCTAssertNil(second.pending)
        XCTAssertEqual(bodies.first, bodies.last)
        XCTAssertEqual(second.prompt, "Explain my balance")
        XCTAssertFalse(second.canSend)
    }

    func testFiveSecondPollingUsesEventCursorAndPreservesViewOnFailure() async throws {
        let suite = "mushy-tests-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var remote = MushyClient.fixtureSnapshot
        let activeId = "00000000-0000-4000-8000-000000000003"
        remote.jobs.append(.init(id: activeId, status: "pending", createdAt: nil, completedAt: nil, artifactId: nil, error: nil))
        var cursors: [String] = []
        let encoder = MushyCoding.encoder()
        MushyStub.handler = { request in
            switch self.endpoint(request) {
            case "catalog": return (200, try encoder.encode(MushyClient.fixtureCatalog))
            case "state": return (200, try encoder.encode(remote))
            case "events":
                cursors.append(URLComponents(url: request.url!, resolvingAgainstBaseURL: false)!.queryItems!.first!.value!)
                let events: [MushyEvent] = cursors.count == 1 ? [
                    .init(sequence: 4, type: "processing", jobId: activeId, attempt: 1, at: "2026-09-19T12:00:00Z")
                ] : []
                return (200, try encoder.encode(MushyEvents(jobId: activeId, events: events, nextCursor: 4)))
            case activeId:
                if cursors.count == 2 {
                    remote.jobs[1] = .init(id: activeId, status: "failed", createdAt: nil, completedAt: nil,
                        artifactId: nil, error: "Generation failed")
                }
                return (200, try encoder.encode(remote.jobs[1]))
            case self.jobId: return (200, try encoder.encode(MushyClient.fixtureArtifact()))
            default: return (404, Data())
            }
        }
        let state = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
        await state.refresh()
        let prior = state.selectedArtifactId
        await state.tick()
        await state.tick()
        XCTAssertEqual(MushyState.pollNanoseconds, 5_000_000_000)
        XCTAssertEqual(cursors, ["0", "4"])
        XCTAssertEqual(state.selectedArtifactId, prior)
        XCTAssertEqual(state.snapshot.jobs[1].status, "failed")
    }

    func testConfigDigestReplayAfterLostResponse() async throws {
        let suite = "mushy-tests-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var bodies: [Data] = []
        let encoder = MushyCoding.encoder()
        var catalogObject = try XCTUnwrap(JSONSerialization.jsonObject(with: encoder.encode(MushyClient.fixtureCatalog)) as? [String: Any])
        catalogObject["capabilities"] = MushyClient.fixtureCatalog.capabilities + ["config.draft"]
        let catalogData = try JSONSerialization.data(withJSONObject: catalogObject)
        MushyStub.handler = { request in
            switch self.endpoint(request) {
            case "catalog": return (200, catalogData)
            case "state": return (200, try encoder.encode(MushySnapshot()))
            case self.jobId:
                let body = try MushyStub.body(request)
                bodies.append(body)
                if bodies.count == 1 { throw URLError(.timedOut) }
                return (200, try encoder.encode(MushyConfigReceipt(draftId: self.jobId, controlRequestId: "control-1", state: "queued")))
            default: return (404, Data())
            }
        }
        let transport = client()
        let first = MushyState(fixtureMode: mode, client: transport, defaults: defaults)
        await first.refresh()
        let draft = try MushyCoding.decoder().decode(MushyConfigDraft.self, from: MushyModelsTests.draftData(id: jobId))
        await first.apply(draft)
        XCTAssertNotNil(first.pending)
        let second = MushyState(fixtureMode: mode, client: transport, defaults: defaults)
        await second.refresh()
        await second.recover()
        XCTAssertEqual(bodies.count, 2)
        XCTAssertEqual(bodies.first, bodies.last)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: bodies[0]) as? [String: Any])
        XCTAssertEqual(Set(body.keys), ["request_id", "summary_digest"])
        XCTAssertEqual(body["summary_digest"] as? String, draft.contents.summaryDigest)
        XCTAssertEqual(second.configReceipts[jobId]?.state, "queued")
        XCTAssertNil(second.pending)
    }

    func testDisabledAndUnreadyCatalogAndFixtureIsolation() async throws {
        let suite = "mushy-tests-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        MushyStub.handler = { _ in (404, Data()) }
        let state = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
        await state.refresh()
        XCTAssertFalse(state.visible)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: MushyCoding.encoder().encode(MushyClient.fixtureCatalog)) as? [String: Any])
        object["provider_readiness"] = ["provider_id": "claude", "ready": false, "status": "unavailable"]
        let data = try JSONSerialization.data(withJSONObject: object)
        var catalogs = 0
        MushyStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            if self.endpoint(request) == "catalog" { catalogs += 1; return (200, data) }
            return (200, try MushyCoding.encoder().encode(MushySnapshot()))
        }
        await state.refresh()
        state.prompt = "Explain"
        XCTAssertTrue(state.visible)
        XCTAssertTrue(state.canSend)
        await state.send()
        XCTAssertEqual(catalogs, 2)
        XCTAssertEqual(state.error, "Provider is still unavailable after refreshing. Your request is kept. Try Send again later.")
        XCTAssertNil(state.pending)
        let preview = MushyClient(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
            token: { XCTFail("Fixture read credential"); return "" })
        _ = try await preview.catalog(identity: preview.identity())
    }

    func testSendRefreshesColdOrUnavailableReadinessOnceAndAdmitsOneTurn() async throws {
        for startsUnavailable in [false, true] {
            let suite = "mushy-tests-" + UUID().uuidString
            let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
            defer { defaults.removePersistentDomain(forName: suite) }
            let encoder = MushyCoding.encoder()
            var remote = MushyClient.fixtureSnapshot
            remote.jobs = []
            var catalogs = 0
            var turns = 0
            var object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoder.encode(MushyClient.fixtureCatalog)) as? [String: Any])
            object["provider_readiness"] = ["provider_id": "preview", "ready": false, "status": "unavailable"]
            let unavailable = try JSONSerialization.data(withJSONObject: object)
            MushyStub.handler = { request in
                switch self.endpoint(request) {
                case "catalog":
                    catalogs += 1
                    return (200, startsUnavailable && catalogs == 1 ? unavailable : try encoder.encode(MushyClient.fixtureCatalog))
                case "state": return (200, try encoder.encode(remote))
                case "turn":
                    turns += 1
                    let turn = try MushyCoding.decoder().decode(MushyTurnRequest.self, from: MushyStub.body(request))
                    XCTAssertEqual(turn.input, "Explain my balance")
                    remote.sessions[0].messages = [.init(role: "user", content: turn.input, jobId: self.jobId, createdAt: "")]
                    remote.jobs = [.init(id: self.jobId, status: "pending", createdAt: nil, completedAt: nil, artifactId: nil, error: nil)]
                    return (200, try encoder.encode(MushyTurnReceipt(jobId: self.jobId, status: "pending")))
                case self.jobId: return (200, try encoder.encode(remote.jobs[0]))
                default: XCTFail("Unexpected request"); return (404, Data())
                }
            }
            let state = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
            if startsUnavailable { await state.refresh() }
            state.prompt = "Explain my balance"
            XCTAssertTrue(state.canSend)
            let priorCatalogs = catalogs
            await state.send()
            XCTAssertEqual(catalogs, priorCatalogs + 1)
            XCTAssertEqual(turns, 1)
            XCTAssertNil(state.pending)
            XCTAssertNil(state.error)
            XCTAssertEqual(state.result, "Request admitted. Waiting for generation.")
            XCTAssertFalse(state.canSend)
            XCTAssertEqual(state.sendBlocker, "Wait for the active generation to finish.")
            await state.send()
            XCTAssertEqual(turns, 1)
        }
    }

    func testFailedReadinessRefreshDoesNotSendUsingCachedReadyCatalog() async throws {
        let suite = "mushy-tests-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let encoder = MushyCoding.encoder()
        var fail = false
        var catalogs = 0
        MushyStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            if self.endpoint(request) == "catalog" {
                catalogs += 1
                if fail { throw URLError(.notConnectedToInternet) }
                return (200, try encoder.encode(MushyClient.fixtureCatalog))
            }
            return (200, try encoder.encode(MushySnapshot()))
        }
        let state = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
        await state.refresh()
        fail = true
        await state.refresh()
        state.prompt = "Keep this request"
        XCTAssertTrue(state.canSend)
        let priorCatalogs = catalogs
        await state.send()
        XCTAssertEqual(catalogs, priorCatalogs + 1)
        XCTAssertNotNil(state.error)
        XCTAssertEqual(state.sendBlocker, state.error)
        XCTAssertNil(state.pending)
        XCTAssertEqual(state.prompt, "Keep this request")
    }

    func testSendSafetyGuardsDoNotRefreshOrPost() async throws {
        let suite = "mushy-tests-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        MushyStub.handler = { _ in XCTFail("Safety guard made a request"); return (500, Data()) }
        let state = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
        for input in ["   \n", String(repeating: "a", count: 8001)] {
            state.prompt = input
            XCTAssertFalse(state.canSend)
            XCTAssertNotNil(state.sendBlocker)
            await state.send()
            XCTAssertNil(state.pending)
        }
        var recovery = MushyRecovery()
        recovery.input = "Saved input"
        recovery.pending = try pending(MushySessionRequest(requestId: UUID().uuidString.lowercased()), kind: .session, path: "/session")
        defaults.set(try MushyCoding.encoder().encode(recovery), forKey: MushyState.recoveryKey)
        let recovering = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
        XCTAssertFalse(recovering.canSend)
        await recovering.send()
        XCTAssertEqual(recovering.pending, recovery.pending)
        defaults.set(Data("invalid recovery".utf8), forKey: MushyState.recoveryKey)
        let blocked = MushyState(fixtureMode: mode, client: client(), defaults: defaults)
        blocked.prompt = "Valid input"
        XCTAssertFalse(blocked.canSend)
        await blocked.send()
        XCTAssertEqual(blocked.sendBlocker, "The assistant could not save recovery data. Sending is disabled.")
    }
}
