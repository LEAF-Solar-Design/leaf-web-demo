import XCTest
@testable import LeafHFT

@MainActor final class NeedsYouCardTests: XCTestCase {
    func testUnknownAndZeroCountsNeverProduceRows() {
        let counts: [Int?] = [nil, 0, 2]
        for tuning in counts {
            for assistant in counts {
                for requests in counts {
                    let rows = NeedsYouCard.rows(tuning: tuning, assistant: assistant, requests: requests)
                    var expected: [NeedsYouCard.Kind] = []
                    if tuning == 2 { expected.append(.tuning) }
                    if assistant == 2 { expected.append(.assistant) }
                    if requests == 2 { expected.append(.requests) }
                    XCTAssertEqual(rows.map(\.kind), expected)
                    XCTAssertTrue(rows.allSatisfy { $0.count > 0 })
                }
            }
        }
        XCTAssertTrue(NeedsYouCard.rows(tuning: -1, assistant: -2, requests: -3).isEmpty)
    }

    func testRowsNameWaitingWorkAndHaveStableIdentifiers() {
        let rows = NeedsYouCard.rows(tuning: 2, assistant: 5, requests: 1)
        XCTAssertEqual(rows.map(\.text), ["2 tuning plans to approve", "5 assistant cards unread",
                                        "1 request waiting for the runner"])
        XCTAssertEqual(rows.map(\.count), [2, 5, 1])
        XCTAssertEqual(rows.map(\.id), ["monitor.needsYou.tuning", "monitor.needsYou.assistant",
                                      "monitor.needsYou.requests"])
        XCTAssertEqual(NeedsYouCard.rows(tuning: 1, assistant: 1, requests: 2).map(\.text),
                       ["1 tuning plan to approve", "1 assistant card unread", "2 requests waiting for the runner"])
    }

    func testRowsReflectNewCountsWithoutKeepingClearedWork() {
        XCTAssertEqual(NeedsYouCard.rows(tuning: nil, assistant: 5, requests: nil).map(\.kind), [.assistant])
        XCTAssertEqual(NeedsYouCard.rows(tuning: 2, assistant: 0, requests: 1).map(\.kind), [.tuning, .requests])
        XCTAssertTrue(NeedsYouCard.rows(tuning: 0, assistant: 0, requests: 0).isEmpty)
        XCTAssertTrue(NeedsYouCard.rows(tuning: nil, assistant: nil, requests: nil).isEmpty)
    }

    func testOnlyRequestedControlsAreWaitingForTheRunner() {
        XCTAssertEqual(NeedsYouCard.pendingRequestCount(states: ["requested", " REQUESTED ", "applied",
                                                                 "rejected", "expired", "unknown", "", nil]), 2)
        XCTAssertEqual(NeedsYouCard.pendingRequestCount(states: []), 0)
        XCTAssertEqual(NeedsYouCard.pendingRequestCount(states: ["applied", "rejected"]), 0)
    }
}
