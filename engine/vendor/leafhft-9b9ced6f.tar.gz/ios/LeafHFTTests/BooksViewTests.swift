import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor private final class BookRiskAuthenticator: RiskAuthenticator {
    var succeeds = false
    var reasons: [String] = []
    func authenticate(reason: String) async -> Bool {
        reasons.append(reason)
        return succeeds
    }
}

@MainActor final class BooksViewTests: XCTestCase {
    func testEnableRequiresConfirmationAndAuthenticationWhileDisableIsImmediate() async {
        let auth = BookRiskAuthenticator()
        let state = AppState(fixtureMode: FixtureMode(arguments: []), riskAuthenticator: auth)
        var submissions = 0
        await BooksView.requestBookChange(state: state, bookId: "BTC-15M", enabled: true) { submissions += 1 }
        XCTAssertEqual(submissions, 0)
        XCTAssertEqual(state.pendingConfirmation?.title, "Enable BTC-15M")
        XCTAssertEqual(state.pendingConfirmation?.detail, "Allow BTC-15M to open new positions with real money.")
        state.cancelPending()
        await state.confirmPending()
        XCTAssertEqual(submissions, 0)
        XCTAssertTrue(auth.reasons.isEmpty)

        await BooksView.requestBookChange(state: state, bookId: "BTC-15M", enabled: true) { submissions += 1 }
        await state.confirmPending()
        XCTAssertEqual(submissions, 0, "Failed authentication cannot enable the book")
        XCTAssertEqual(auth.reasons, ["Enable BTC-15M"])

        auth.succeeds = true
        await BooksView.requestBookChange(state: state, bookId: "BTC-15M", enabled: true) { submissions += 1 }
        await state.confirmPending()
        await state.confirmPending()
        XCTAssertEqual(submissions, 1)

        await BooksView.requestBookChange(state: state, bookId: "BTC-15M", enabled: false) { submissions += 1 }
        XCTAssertEqual(submissions, 2)
        XCTAssertNil(state.pendingConfirmation)
        XCTAssertEqual(auth.reasons.count, 2, "Disabling must not authenticate")
    }

    func testStaleFailedAndUnknownBooksCannotToggle() {
        for stale in [false, true] {
            for failed in [false, true] {
                for known in [false, true] {
                    XCTAssertEqual(BooksView.canToggle(fixture: false, submitting: false,
                        outcomeUnknown: false, hasHost: true, restored: false,
                        stale: stale, refreshFailed: failed, enabledKnown: known), !stale && !failed && known)
                }
            }
        }
    }

    func testBooksFeedBudgetAndFailureExplanationPreserveAge() throws {
        let state = AppState(fixtureMode: FixtureMode(arguments: []))
        let observed = Date(timeIntervalSince1970: 1000)
        state.recordFeedSuccess(.books, now: observed)
        XCTAssertFalse(state.isStale(.books, budget: 120, now: observed.addingTimeInterval(120)))
        XCTAssertTrue(state.isStale(.books, budget: 120, now: observed.addingTimeInterval(121)))
        XCTAssertNil(BooksView.booksFeedExplanation(status: state.feedStatuses[.books], stale: false, now: observed))
        state.recordFeedFailure(.books, error: "offline", now: observed.addingTimeInterval(30))
        let failure = try XCTUnwrap(BooksView.booksFeedExplanation(status: state.feedStatuses[.books],
            stale: false, now: observed.addingTimeInterval(30)))
        XCTAssertTrue(failure.contains("Refresh failed: offline"))
        XCTAssertTrue(failure.contains("Observed 30 s ago"))
        let stale = try XCTUnwrap(BooksView.booksFeedExplanation(status: FeedStatus(observedAt: observed),
            stale: true, now: observed.addingTimeInterval(180)))
        XCTAssertTrue(stale.contains("Telemetry delayed"))
        XCTAssertTrue(stale.contains("Observed 3 min ago"))
        XCTAssertTrue(BooksView.booksFeedExplanation(status: nil, stale: true, now: observed)?.contains("Never observed") == true)
    }

    func testMissingEnabledIsUnknownInsteadOfAcceptingOrPaused() throws {
        for json in [#"{"book_id":"unknown","kalshi_book":{}}"#,
                     #"{"book_id":"unknown","enabled":null,"kalshi_book":{}}"#] {
            let book = try accountJSONDecoder().decode(Book.self, from: Data(json.utf8))
            XCTAssertNil(book.enabled)
            XCTAssertEqual(BooksView.enabledStatus(book.enabled), "Unknown")
        }
        XCTAssertEqual(BooksView.enabledStatus(true), "Accepting new entries")
        XCTAssertEqual(BooksView.enabledStatus(false), "New entries paused")
    }

    func testQuoteShowsOnlyReportedSideAndAsk() {
        var candidate = Candidate(ticker: "quote")
        candidate.askCents = 42
        candidate.sideYes = true
        XCTAssertEqual(BooksView.reportedQuote(candidate), "YES ask 42.0¢")
        candidate.sideYes = false
        XCTAssertEqual(BooksView.reportedQuote(candidate), "NO ask 42.0¢")
        candidate.sideYes = nil
        XCTAssertNil(BooksView.reportedQuote(candidate))
        candidate.sideYes = true
        candidate.askCents = .nan
        XCTAssertNil(BooksView.reportedQuote(candidate))
        candidate.askCents = nil
        XCTAssertNil(BooksView.reportedQuote(candidate))
    }
}
