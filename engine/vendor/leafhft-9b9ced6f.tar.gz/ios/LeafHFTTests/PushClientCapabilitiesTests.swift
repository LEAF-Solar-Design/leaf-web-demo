import Foundation
import XCTest
@testable import LeafHFT

private final class CapabilitiesHTTPStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                                                       httpVersion: nil, headerFields: nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

final class PushClientCapabilitiesTests: XCTestCase {
    override func tearDown() { CapabilitiesHTTPStub.handler = nil; super.tearDown() }

    private func client() -> PushClient {
        PushClient(fixtureMode: FixtureMode(arguments: []), protocolClasses: [CapabilitiesHTTPStub.self],
                   token: { "device-token" })
    }

    private func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open()
            defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 1024)
            while true {
                let count = stream.read(&buffer, maxLength: buffer.count)
                if count < 0 { throw URLError(.cannotDecodeContentData) }
                if count == 0 { break }
                data.append(contentsOf: buffer.prefix(count))
            }
        }
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    }

    func testCapabilitiesPostUsesExactRouteBearerAndBody() async throws {
        var calls = 0
        CapabilitiesHTTPStub.handler = { request in
            calls += 1
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/capabilities")
            XCTAssertNil(request.url?.query)
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Content-Type"), "application/json")
            let body = try self.body(request)
            XCTAssertEqual(body as NSDictionary, ["plan_contract_max": 2, "build_number": 120] as NSDictionary)
            return (200, Data(#"{"success":true,"plan_contract_max":2}"#.utf8))
        }
        let result = try await client().registerCapabilities(planContractMax: 2, buildNumber: 120)
        XCTAssertEqual(result, 2)
        XCTAssertEqual(calls, 1)
    }

    func testNilBuildNumberIsOmittedAndServerContractOneIsRecorded() async throws {
        var calls = 0
        CapabilitiesHTTPStub.handler = { request in
            calls += 1
            let body = try self.body(request)
            XCTAssertEqual(body as NSDictionary, ["plan_contract_max": 2] as NSDictionary)
            XCTAssertFalse(body.keys.contains("build_number"))
            return (200, Data(#"{"success":true,"plan_contract_max":1}"#.utf8))
        }
        let result = try await client().registerCapabilities(planContractMax: 2, buildNumber: nil)
        XCTAssertEqual(result, 1)
        XCTAssertEqual(calls, 1)
    }

    func testInvalidResponsesThrowDecoding() async {
        for response in [
            #"{"success":true,"plan_contract_max":3}"#,
            #"{"success":true,"plan_contract_max":0}"#,
            #"{"success":false,"plan_contract_max":2}"#,
            "{}", "not json"
        ] {
            CapabilitiesHTTPStub.handler = { _ in (200, Data(response.utf8)) }
            do {
                _ = try await client().registerCapabilities(planContractMax: 2, buildNumber: nil)
                XCTFail("Invalid capability response accepted")
            } catch { XCTAssertEqual(error as? DashboardClientError, .decoding) }
        }
    }

    func testOlderServer404ThrowsHTTP404() async {
        CapabilitiesHTTPStub.handler = { _ in (404, Data()) }
        do {
            _ = try await client().registerCapabilities(planContractMax: 2, buildNumber: nil)
            XCTFail("Missing route accepted")
        } catch { XCTAssertEqual(error as? DashboardClientError, .http(404)) }
    }

    func testInvalidArgumentsThrowBeforeTransportOrCredentialAccess() async {
        var calls = 0
        CapabilitiesHTTPStub.handler = { _ in
            calls += 1
            return (200, Data(#"{"success":true,"plan_contract_max":2}"#.utf8))
        }
        let client = PushClient(fixtureMode: FixtureMode(arguments: []), protocolClasses: [CapabilitiesHTTPStub.self],
                               token: { XCTFail("Invalid arguments read credentials"); return "device-token" })
        let invalid: [(Int, Int?)] = [(3, nil), (0, nil), (2, -1), (2, 2_147_483_648)]
        for (planContractMax, buildNumber) in invalid {
            do {
                _ = try await client.registerCapabilities(planContractMax: planContractMax, buildNumber: buildNumber)
                XCTFail("Invalid capability arguments accepted")
            } catch { XCTAssertEqual(error as? DashboardClientError, .decoding) }
        }
        XCTAssertEqual(calls, 0)
    }

    func testFixtureModeRefusesCapabilitiesBeforeCredentialAccess() async {
        CapabilitiesHTTPStub.handler = { _ in XCTFail("Fixture reached transport"); return (500, Data()) }
        let client = PushClient(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
                               protocolClasses: [CapabilitiesHTTPStub.self],
                               token: { XCTFail("Fixture read credentials"); return "device-token" })
        do {
            _ = try await client.registerCapabilities(planContractMax: 2, buildNumber: 120)
            XCTFail("Fixture capability registration accepted")
        } catch { XCTAssertTrue(error is FixtureAccessError) }
    }
}
