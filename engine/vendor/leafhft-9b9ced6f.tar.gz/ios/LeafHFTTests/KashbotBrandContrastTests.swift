import Foundation
import SwiftUI
import UIKit
import XCTest
@testable import LeafHFT

final class KashbotBrandContrastTests: XCTestCase {
    func testEveryTextColorHasAAAContrastAgainstGround() throws {
        let colors: [(String, Color)] = [
            ("ink", KashbotBrand.ink), ("leaf", KashbotBrand.leaf),
            ("slate", KashbotBrand.slate), ("loss", KashbotBrand.loss),
            ("positive tone", KashbotBrand.tone(1)),
            ("negative tone", KashbotBrand.tone(-1)),
            ("neutral tone", KashbotBrand.tone(0))
        ]
        for style in [UIUserInterfaceStyle.light, .dark] {
            let traits = UITraitCollection(userInterfaceStyle: style)
            let ground = try luminance(KashbotBrand.ground, traits: traits)
            for (name, color) in colors {
                let text = try luminance(color, traits: traits)
                let ratio = (max(text, ground) + 0.05) / (min(text, ground) + 0.05)
                XCTAssertGreaterThanOrEqual(ratio, 7.0, "\(name) must remain AAA in \(style)")
            }
        }
    }

    private func luminance(_ color: Color, traits: UITraitCollection) throws -> Double {
        let resolved = UIColor(color).resolvedColor(with: traits)
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        XCTAssertTrue(resolved.getRed(&red, green: &green, blue: &blue, alpha: &alpha))
        XCTAssertEqual(alpha, 1, "Contrast tokens must be opaque")
        func linear(_ channel: CGFloat) -> Double {
            let value = Double(channel)
            return value <= 0.04045 ? value / 12.92 : pow((value + 0.055) / 1.055, 2.4)
        }
        return 0.2126 * linear(red) + 0.7152 * linear(green) + 0.0722 * linear(blue)
    }
}
