import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class DashboardStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                httpVersion: nil, headerFields: status == 301 ? ["Location": "https://example.invalid/redirect"] : nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

private actor ControlledPeopleClient: PeopleCardsLoading {
    private var pending: [Int: CheckedContinuation<PeopleCardsFetch, Never>] = [:]
    private var waiters: [(Int, CheckedContinuation<Void, Never>)] = []
    private(set) var requestCount = 0
    private(set) var completedCount = 0
    private(set) var cancelledCount = 0

    func people() async -> PeopleCardsFetch {
        requestCount += 1
        let id = requestCount
        let result = await withCheckedContinuation { continuation in
            pending[id] = continuation
            let ready = waiters.filter { $0.0 <= requestCount }
            waiters.removeAll { $0.0 <= requestCount }
            for (_, waiter) in ready { waiter.resume() }
        }
        completedCount += 1
        if Task.isCancelled { cancelledCount += 1 }
        return result
    }

    func waitForRequests(_ count: Int) async {
        guard requestCount < count else { return }
        await withCheckedContinuation { waiters.append((count, $0)) }
    }

    func complete(_ id: Int, with result: PeopleCardsFetch) {
        pending.removeValue(forKey: id)?.resume(returning: result)
    }
}

final class DashboardClientTests: XCTestCase {
    override func tearDown() { DashboardStub.handler = nil; super.tearDown() }

    func testBooksRawVariantMatchesLiveDecodeAndExactResponseBytes() async throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "books", withExtension: "json", subdirectory: "Fixtures"))
        let bytes = try Data(contentsOf: url)
        DashboardStub.handler = { request in
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/books")
            XCTAssertNil(request.url?.query)
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer snapshot-test")
            return (200, bytes)
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "snapshot-test" })
        let live = try await client.books()
        let raw = try await client.booksWithBytes()
        let saved = try DashboardClient.decodeSnapshot(MobileBooks.self, from: raw.payload)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        XCTAssertEqual(try encoder.encode(raw.value), try encoder.encode(live))
        XCTAssertEqual(try encoder.encode(saved), try encoder.encode(live))
        XCTAssertEqual(raw.payload, bytes)
        XCTAssertEqual(raw.identity, try client.snapshotIdentity())
    }

    func testActivityRawVariantMatchesLiveDecodeAndExactResponseBytes() async throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "activity", withExtension: "json", subdirectory: "Fixtures"))
        let bytes = try Data(contentsOf: url)
        DashboardStub.handler = { request in
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/activity")
            XCTAssertEqual(request.url?.query, "limit=50")
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer snapshot-test")
            return (200, bytes)
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "snapshot-test" })
        let live = try await client.activity()
        let raw = try await client.activityWithBytes()
        let saved = try DashboardClient.decodeSnapshot(RunnerActivity.self, from: raw.payload)
        XCTAssertEqual(raw.value, live)
        XCTAssertEqual(saved, live)
        XCTAssertEqual(raw.payload, bytes)
        XCTAssertEqual(raw.identity, try client.snapshotIdentity())
    }

    /// The getKashbotPeople wire shape uses evidence wrappers and integer cents, not card inputs.
    private func peopleBody(nonzeroActivity: Bool = false) throws -> Data {
        let at = "2026-09-26T12:00:00.000Z"
        func evidence(_ value: Any?) -> [String: Any] {
            ["value": value ?? NSNull(), "source": "test-producer", "observed_at": at]
        }
        let activity: [String: Any] = [
            "coverage": "recorded_only", "last_recorded_at": evidence(at),
            "observed_24h": evidence(nonzeroActivity ? 3 : 0), "observed_7d": evidence(nonzeroActivity ? 7 : 2),
            "exact_24h": evidence(nonzeroActivity ? 11 : nil), "exact_7d": evidence(nonzeroActivity ? 19 : nil)
        ]
        let day: [String: Any] = [
            "utc_day": "2026-09-26", "observed": true,
            "realized_cents": evidence(-30), "entries": evidence(0.01),
            "settled": evidence(0.01), "exits": evidence(0), "won": evidence(0),
            "lost": evidence(0.01), "voided": evidence(nil)
        ]
        let engine: [String: Any] = [
            "engine_id": "engine-1", "account_id": "account-1",
            "assignment": evidence("assigned"), "enabled": evidence(true),
            "execution_provenance": NSNull(),
            "sharing": ["status": "unknown", "truncated": false, "others": []] as [String: Any],
            "performance": ["days": [day], "projection": NSNull(), "unknown_future_field": true] as [String: Any]
        ]
        var foreignEngine = engine
        foreignEngine["account_id"] = "another-account"
        let person: [String: Any] = [
            "lane_id": "lane-1", "account_id": "account-1", "label": "owner",
            "lane": ["state": "live", "revoked_at": NSNull(), "kill_requested": false] as [String: Any],
            "activity": ["orders": activity, "fills": activity],
            "refusal": ["dominant": evidence(nil), "text": "unknown"] as [String: Any],
            "money": ["current_cash_cents": evidence(0), "activation_budget_cash_cents": evidence(1250),
                "reported_per_book_stake_cents": evidence(1), "reported_turnover_used_cents": evidence(200),
                "reported_cap_cents": evidence(nil)],
            "engines": ["available": true, "truncated": false, "items": [engine, foreignEngine]] as [String: Any]
        ]
        let section = ["available": true, "truncated": false]
        return try JSONSerialization.data(withJSONObject: [
            "success": true, "generated_at": at, "people": [person],
            "sections": ["roster": section, "assignments": section, "controls": section],
            "truncated": false, "unknown_future_field": "ignored"
        ])
    }

    func testPeopleUsesOwnerMobileRouteAndMapsEvidence() async throws {
        let body = try peopleBody()
        var requests = 0
        DashboardStub.handler = { request in
            requests += 1
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/people")
            XCTAssertNil(request.url?.query)
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            return (200, body)
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        guard case let .success(response) = await client.people() else { return XCTFail("Expected people") }
        XCTAssertEqual(requests, 1)
        XCTAssertEqual(response.people.count, 1)
        let person = try XCTUnwrap(response.people.first)
        XCTAssertEqual(person.id, "lane-1")
        XCTAssertEqual(person.accountID, "account-1")
        XCTAssertEqual(person.label, "owner")
        XCTAssertEqual(person.lane.verdict(at: response.generatedAt), .unknown)
        XCTAssertEqual(person.lane.lastOrder.time, response.generatedAt)
        XCTAssertEqual(person.lane.lastOrder.provenance, .unknown)
        XCTAssertNil(person.lane.refusal.currentReason(at: response.generatedAt))
        XCTAssertEqual(person.orders.recorded24h.value, 0)
        XCTAssertEqual(person.fills.recorded7d.value, 2)
        XCTAssertNil(person.orders.total24h.value)
        XCTAssertEqual(person.funds.currentCash?.text, "0 USD")
        XCTAssertEqual(person.funds.activationBudgetCash?.text, "12.5 USD")
        XCTAssertEqual(person.funds.reportedStake?.text, "0.01 USD")
        XCTAssertEqual(person.funds.turnoverUsed?.text, "2 USD")
        XCTAssertNil(person.funds.reportedCap)
        XCTAssertEqual(person.scopedEngines.count, 1, "Never display another account's engine results")
        let engine = try XCTUnwrap(person.scopedEngines.first)
        XCTAssertEqual(engine.assignment, "assigned")
        XCTAssertEqual(engine.sharing.status, .unknown)
        XCTAssertEqual(engine.performance.days.map(\.dateSlot), ["2026-09-26"])
        XCTAssertEqual(engine.performance.realizedText, "-0.3 USD")
        XCTAssertEqual(engine.performance.days.first?.metrics.entries.value, 0.01)
        XCTAssertNil(engine.projection)
    }

    /// wire-keys: use the production GET decoder with all four producer keys populated.
    func testPeopleActivityWireKeysRetainEveryNonzeroValue() async throws {
        let body = try peopleBody(nonzeroActivity: true)
        DashboardStub.handler = { _ in (200, body) }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        guard case let .success(response) = await client.people() else { return XCTFail("Expected people") }
        XCTAssertEqual(response.people.count, 1)
        let person = try XCTUnwrap(response.people.first)
        for activity in [person.orders, person.fills] {
            XCTAssertEqual(activity.recorded24h.value, 3)
            XCTAssertEqual(activity.recorded7d.value, 7)
            XCTAssertEqual(activity.total24h.value, 11)
            XCTAssertEqual(activity.total7d.value, 19)
        }
    }

    /// token-change: a denied principal cannot suppress the next owner's fetch.
    @MainActor func testPeopleReloadsAfterTokenChangeAndExplicitRefresh() async throws {
        let body = try peopleBody(nonzeroActivity: true)
        var token = "non-owner-token"
        var peopleRequests = 0
        DashboardStub.handler = { request in
            guard request.url?.path == "/api/leafhft/mobile/people" else { return (403, Data()) }
            peopleRequests += 1
            if request.value(forHTTPHeaderField: "Authorization") == "Bearer owner-token" {
                return (200, body)
            }
            return (403, Data())
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { token })
        let state = AppState(dashboard: client)
        await state.loadPeople()
        XCTAssertTrue(state.peopleNotAuthorized)
        XCTAssertEqual(peopleRequests, 1)

        token = "owner-token"
        // Settings saves the new token, then calls this refresh entry point.
        await state.refreshDashboard()
        XCTAssertNil(state.peopleResult)
        XCTAssertFalse(state.peopleNotAuthorized)
        await state.loadPeople()
        XCTAssertEqual(peopleRequests, 2)
        guard case let .success(response)? = state.peopleResult else { return XCTFail("Expected owner cards") }
        XCTAssertEqual(response.people.first?.label, "owner")
        XCTAssertFalse(state.peopleLoading)

        token = "non-owner-token"
        await state.loadPeople()
        XCTAssertTrue(state.peopleNotAuthorized)
        token = "owner-token"
        await state.loadPeople()
        XCTAssertEqual(peopleRequests, 4)
        guard case .success? = state.peopleResult else { return XCTFail("Denial must not suppress a new load") }

        await state.refreshEngineLab()
        XCTAssertNil(state.peopleResult)
        await state.loadPeople()
        XCTAssertEqual(peopleRequests, 5)
        guard case .success? = state.peopleResult else { return XCTFail("Expected cards after refresh") }
    }

    /// cancel-reappear: cancelling the first view caller must not strand the returning view.
    @MainActor func testPeopleCancelReappearCompletesOwnedRequest() async throws {
        let client = ControlledPeopleClient()
        let state = AppState(peopleClient: client)
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .custom { decoder in
            let text = try decoder.singleValueContainer().decode(String.self)
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            return try XCTUnwrap(formatter.date(from: text))
        }
        let response = try decoder.decode(PeopleCards.Response.self, from: peopleBody())
        let first = Task { await state.loadPeople() }
        await client.waitForRequests(1)
        XCTAssertTrue(state.peopleLoading)
        first.cancel()

        let entered = expectation(description: "Returning view calls loadPeople before A completes")
        let reappeared = Task {
            entered.fulfill()
            await state.loadPeople()
        }
        await fulfillment(of: [entered], timeout: 1)
        XCTAssertTrue(state.peopleLoading)
        XCTAssertNil(state.peopleResult)
        let requestsBeforeCompletion = await client.requestCount
        XCTAssertEqual(requestsBeforeCompletion, 1)

        await client.complete(1, with: .success(response))
        await first.value
        await reappeared.value
        let requests = await client.requestCount
        let completions = await client.completedCount
        let cancellations = await client.cancelledCount
        XCTAssertEqual(requests, 1)
        XCTAssertEqual(completions, 1)
        XCTAssertEqual(cancellations, 0)
        XCTAssertFalse(state.peopleLoading)
        guard case let .success(shown)? = state.peopleResult else { return XCTFail("Expected completed cards") }
        XCTAssertEqual(shown.people.first?.label, "owner")
    }

    func testPeopleForbiddenHidesEntryAndOtherFailuresAreUnavailable() async throws {
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        DashboardStub.handler = { _ in (403, Data("private server detail".utf8)) }
        guard case .notAuthorized = await client.people() else { return XCTFail("Expected not authorized") }
        for (status, expected) in [(500, DashboardClientError.http(500)), (401, .unauthorized)] {
            DashboardStub.handler = { _ in (status, Data("private server detail".utf8)) }
            guard case let .unavailable(error) = await client.people() else { return XCTFail("Expected unavailable") }
            XCTAssertEqual(error, expected)
            XCTAssertFalse(String(describing: error).contains("private server detail"))
        }
        DashboardStub.handler = { _ in throw URLError(.timedOut) }
        guard case let .unavailable(error) = await client.people() else { return XCTFail("Expected unavailable") }
        XCTAssertEqual(error, .transport)
    }

    func testPeopleMalformedBodyRetainsTypedDecodeFailure() async throws {
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        var malformedRow = try XCTUnwrap(JSONSerialization.jsonObject(with: peopleBody()) as? [String: Any])
        malformedRow["people"] = [["lane_id": "missing-evidence"]]
        var malformedDate = try XCTUnwrap(JSONSerialization.jsonObject(with: peopleBody()) as? [String: Any])
        malformedDate["generated_at"] = "not a date"
        for body in [Data("not json".utf8), Data("{}".utf8),
                     try JSONSerialization.data(withJSONObject: malformedRow),
                     try JSONSerialization.data(withJSONObject: malformedDate)] {
            DashboardStub.handler = { _ in (200, body) }
            guard case let .unavailable(error) = await client.people() else { return XCTFail("Expected unavailable") }
            XCTAssertEqual(error, .decoding)
        }
    }

    private func bodyData(_ request: URLRequest) throws -> Data {
        if let data = request.httpBody { return data }
        let stream = try XCTUnwrap(request.httpBodyStream)
        stream.open()
        defer { stream.close() }
        var data = Data()
        var buffer = [UInt8](repeating: 0, count: 1024)
        while true {
            let count = stream.read(&buffer, maxLength: buffer.count)
            guard count >= 0 else { throw URLError(.cannotDecodeContentData) }
            if count == 0 { return data }
            data.append(contentsOf: buffer.prefix(count))
        }
    }

    func testEnrollmentSendsOnlySealedEnvelopeAndRejectsForbidden() async throws {
        let envelope = SealedAccountCredential(enrollmentKeyId: "runner-key", wrappedKey: "d3JhcHBlZA==",
            nonce: "bm9uY2U=", ciphertext: "Y2lwaGVydGV4dA==")
        let enrollment = AccountEnrollmentRequest(clientRequestId: UUID(), credential: envelope)
        var count = 0
        DashboardStub.handler = { request in
            count += 1
            XCTAssertEqual(request.url?.path, "/api/kashbot/credentials")
            XCTAssertNil(request.url?.query)
            XCTAssertEqual(request.httpMethod, "POST")
            let bytes = try self.bodyData(request)
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: bytes) as? [String: Any])
            XCTAssertEqual(Set(body.keys), ["client_request_id", "enrollment_key_id", "algorithm",
                                            "wrapped_key", "nonce", "ciphertext"])
            XCTAssertEqual(body["algorithm"] as? String, "RSA-OAEP-256+A256GCM")
            XCTAssertEqual(body["enrollment_key_id"] as? String, "runner-key")
            XCTAssertEqual(body["client_request_id"] as? String, enrollment.clientRequestId)
            XCTAssertEqual(body["ciphertext"] as? String, "Y2lwaGVydGV4dA==")
            return (403, Data("private backend detail".utf8))
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        do { _ = try await client.enrollAccount(enrollment); XCTFail("Expected forbidden") }
        catch { XCTAssertEqual(error as? DashboardClientError, .forbidden) }
        XCTAssertEqual(count, 1)
    }

    func testEnrollmentKeyUsesAuthenticatedCredentialsEndpoint() async throws {
        DashboardStub.handler = { request in
            XCTAssertEqual(request.url?.path, "/api/kashbot/credentials")
            XCTAssertNil(request.url?.query)
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            return (200, Data(#"{"enrollment_key_id":"runner-key","public_key_der":"cHVibGlj","algorithm":"RSA-OAEP-256+A256GCM"}"#.utf8))
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        let key = try await client.enrollmentKey()
        XCTAssertEqual(key.enrollmentKeyId, "runner-key")
        XCTAssertEqual(key.algorithm, "RSA-OAEP-256+A256GCM")
        XCTAssertNil(key.expiresAt)
    }

    func testKashbotPathsBodiesAndDryRunIdempotency() async throws {
        let clientID = UUID(uuidString: "12345678-1234-4234-9234-123456789abc")!
        var paths: [String] = []
        var runnerBodies: [Data] = []
        DashboardStub.handler = { request in
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            let path = try XCTUnwrap(request.url?.path)
            paths.append(path)
            if path == "/api/kashbot/status" {
                XCTAssertEqual(request.httpMethod, "GET")
                XCTAssertEqual(request.cachePolicy, .reloadIgnoringLocalAndRemoteCacheData)
                XCTAssertEqual(request.value(forHTTPHeaderField: "Cache-Control"), "no-cache, no-store")
                return (200, Data(#"{"dashboard_pairing":"paired","account_binding":"unbound","automated_trading":"not_configured","tenant":null,"request":null}"#.utf8))
            }
            XCTAssertEqual(request.httpMethod, "POST")
            let bytes = try self.bodyData(request)
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: bytes) as? [String: String])
            switch path {
            case "/api/kashbot/bind/challenge":
                XCTAssertTrue(body.isEmpty)
                return (201, Data(#"{"challenge_id":"abcdefab-1234-4234-9234-123456789abc","device_id":"fedcbafe-1234-4234-9234-123456789abc","challenge":"abc","challenge_hash":"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","expires_at":"2030-01-01T00:00:00Z","binding_version":"kashbot-bind-v1"}"#.utf8))
            case "/api/kashbot/bind":
                XCTAssertEqual(body, ["challenge_id": "abcdefab-1234-4234-9234-123456789abc", "key_id": "key", "public_key_der": "public", "signature": "proof"])
                return (201, Data(#"{"tenant_id":"tenant","runner_host":"kashbot-tenant","automated_trading":"not_configured"}"#.utf8))
            case "/api/kashbot/runner":
                XCTAssertEqual(body, ["client_request_id": clientID.uuidString.lowercased(), "action": "start_dry_run"])
                runnerBodies.append(bytes)
                return (200, Data(#"{"request":{"id":"request","client_request_id":"12345678-1234-4234-9234-123456789abc","action":"start_dry_run","state":"provisioning","requested_at":"2026-09-19T00:00:00.000Z"}}"#.utf8))
            default: XCTFail("Unexpected endpoint"); return (500, Data())
            }
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        let status = try await client.kashbotStatus()
        XCTAssertFalse(status.isBound)
        let challenge = try await client.bindingChallenge()
        let bound = try await client.bind(BindingRequest(challengeId: challenge.challengeId, keyId: "key", publicKeyDer: "public", signature: "proof"))
        XCTAssertEqual(bound.automatedTrading, .notConfigured)
        let first = try await client.startDryRun(clientRequestId: clientID)
        let retry = try await client.startDryRun(clientRequestId: clientID)
        XCTAssertEqual(first.request, retry.request)
        XCTAssertEqual(runnerBodies.count, 2)
        XCTAssertEqual(paths, ["/api/kashbot/status", "/api/kashbot/bind/challenge", "/api/kashbot/bind", "/api/kashbot/runner", "/api/kashbot/runner"])
    }

    func testKashbotPostsDoNotRetryUnknownOutcomes() async throws {
        var count = 0
        DashboardStub.handler = { _ in count += 1; throw URLError(.timedOut) }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        do { _ = try await client.startDryRun(clientRequestId: UUID()); XCTFail("Expected transport failure") }
        catch { XCTAssertEqual(error as? DashboardClientError, .transport) }
        XCTAssertEqual(count, 1)
    }

    func testRunnerControlsUseExactBodiesAndOnePostWithFixedErrors() async throws {
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "secret-bearer" })
        let actions: [(String, (UUID) async throws -> KashbotRunnerResponse)] = [
            ("start_live", client.startLive), ("pause", client.pauseTrading), ("revoke", client.revokeRunner)
        ]
        for (wire, send) in actions {
            for (code, expected) in [(401, DashboardClientError.unauthorized), (403, .forbidden),
                                     (429, .rateLimited), (503, .http(503)), (301, .http(301)),
                                     (200, .decoding), (0, .transport)] {
                let requestID = UUID()
                var posts = 0
                DashboardStub.handler = { request in
                    posts += 1
                    XCTAssertEqual(request.httpMethod, "POST")
                    XCTAssertEqual(request.url?.path, "/api/kashbot/runner")
                    XCTAssertNil(request.url?.query)
                    XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer secret-bearer")
                    let bytes = try self.bodyData(request)
                    XCTAssertEqual(try JSONSerialization.jsonObject(with: bytes) as? [String: String],
                        ["action": wire, "client_request_id": requestID.uuidString.lowercased()])
                    XCTAssertFalse(String(decoding: bytes, as: UTF8.self).contains("secret"))
                    XCTAssertFalse(request.url!.absoluteString.contains("secret"))
                    for (name, value) in request.allHTTPHeaderFields ?? [:] where name.lowercased() != "authorization" {
                        XCTAssertFalse(value.contains("secret-bearer"))
                    }
                    if code == 0 { throw NSError(domain: "secret-transport-detail", code: 1) }
                    return (code, Data("secret-response-detail".utf8))
                }
                do { _ = try await send(requestID); XCTFail("Expected fixed failure") }
                catch {
                    XCTAssertEqual(error as? DashboardClientError, expected)
                    XCTAssertFalse(String(describing: error).contains("secret"))
                }
                XCTAssertEqual(posts, 1)
            }
        }
    }

    func testRunnerControlsDecodeAcceptedActionAndBoundResponse() async throws {
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        let requestID = UUID()
        var posts = 0
        DashboardStub.handler = { _ in
            posts += 1
            return (202, try JSONSerialization.data(withJSONObject: ["request": [
                "id": "request", "client_request_id": requestID.uuidString.lowercased(),
                "action": "start_live", "state": "provisioning", "requested_at": "2026-09-19T00:00:00Z"]]))
        }
        let result = try await client.startLive(clientRequestId: requestID)
        XCTAssertEqual(result.request.action, .startLive)
        XCTAssertEqual(posts, 1)
        DashboardStub.handler = { _ in posts += 1; return (200, Data(repeating: 32, count: 65_537)) }
        do { _ = try await client.pauseTrading(clientRequestId: UUID()); XCTFail("Expected body limit") }
        catch { XCTAssertEqual(error as? DashboardClientError, .decoding) }
        XCTAssertEqual(posts, 2)
    }

    func testControlPostDistinguishesUnauthorizedFromServerRefusals() async throws {
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        let intent = try ControlIntent.bind(symbol: "TEST", engineId: "test-engine")
        let cases: [(Int, String, DashboardClientError)] = [
            (401, #"{"error":"Token expired"}"#, .unauthorized),
            (403, #"{"error":"Account scope required"}"#, .refused("Account scope required")),
            (403, "", .forbidden),
            (409, #"{"error":"Revision changed"}"#, .refused("Revision changed")),
            (429, #"{"error":"Please wait","retry_after_ms":61000}"#, .refused("Please wait (retry in 2 min)"))
        ]
        for (status, body, expected) in cases {
            var posts = 0
            DashboardStub.handler = { request in
                posts += 1
                XCTAssertEqual(request.httpMethod, "POST")
                XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/control")
                return (status, Data(body.utf8))
            }
            do { _ = try await client.control(intent, note: nil); XCTFail("Expected control failure") }
            catch { XCTAssertEqual(error as? DashboardClientError, expected) }
            XCTAssertEqual(posts, 1)
        }
    }

    func testBooksBearerAndFixture() async throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "books", withExtension: "json", subdirectory: "Fixtures"))
        let fixture = try Data(contentsOf: url)
        DashboardStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/books")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-token")
            return (200, fixture)
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "test-token" })
        let books = try await client.books()
        XCTAssertFalse(books.books.isEmpty)
    }

    func testProbesDecodesFixtureWithDeviceAuth() async throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "probes", withExtension: "json", subdirectory: "Fixtures"))
        let fixture = try Data(contentsOf: url)
        var requests = 0
        DashboardStub.handler = { request in
            requests += 1
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/probes")
            XCTAssertNil(request.url?.query)
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            return (200, fixture)
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        guard case let .reported(board)? = try await client.probes() else { return XCTFail("Expected a reported board") }
        XCTAssertEqual(requests, 1)
        XCTAssertEqual(board.account?.pct, 50)
        XCTAssertEqual(board.account?.limitCents, 125000)
        XCTAssertEqual(board.observedAt, "2026-09-23T12:00:00Z")
        XCTAssertEqual(board.engines.map(\.engineId), ["aggr-2", "future-engine"])
        let probing = board.engines[0]
        XCTAssertEqual(probing.lifecycle?.state, .probe)
        XCTAssertEqual(probing.lifecycle?.breaker?.engineLossCents, 1240)
        XCTAssertEqual(probing.assignment?.accountId, "acct-probe")
        XCTAssertEqual(probing.probeToday?.realizedCents, -120)
        XCTAssertEqual(probing.live?.n, 41)
        XCTAssertEqual(probing.nextStep?.text, "Probing: day 3 of 14, 41 tickets, -$1.20; verdict due Oct 7")
        // A lifecycle state this build does not know decodes as unknown, never as a failure.
        XCTAssertEqual(board.engines[1].lifecycle?.state, .unknown)
        XCTAssertNil(board.engines[1].assignment)
    }

    func testProbesMissingRouteHidesCardButAuthStillThrows() async throws {
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        var requests = 0
        DashboardStub.handler = { _ in requests += 1; return (404, Data(#"{"error":"Not found"}"#.utf8)) }
        let missing = try await client.probes()
        XCTAssertNil(missing)
        XCTAssertEqual(requests, 1)
        for (status, expected) in [(401, DashboardClientError.unauthorized), (403, .forbidden), (503, .http(503))] {
            DashboardStub.handler = { _ in (status, Data()) }
            do { _ = try await client.probes(); XCTFail("Expected typed error") }
            catch { XCTAssertEqual(error as? DashboardClientError, expected) }
        }
    }

    func testProbesMalformedBodyIsNotReported() async throws {
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        for body in [Data("not json".utf8), Data(#"{"engines":"not a list"}"#.utf8),
                     Data(#"{"engines":[{"name":"row without an engine id"}]}"#.utf8),
                     Data(repeating: 32, count: 262_145)] {
            DashboardStub.handler = { _ in (200, body) }
            let result = try await client.probes()
            XCTAssertEqual(result, .notReported)
        }
        // An older server's empty board still decodes: every block is optional.
        DashboardStub.handler = { _ in (200, Data("{}".utf8)) }
        guard case let .reported(board)? = try await client.probes() else { return XCTFail("Expected a reported board") }
        XCTAssertTrue(board.engines.isEmpty)
        XCTAssertNil(board.account)
    }

    func testAccountHistoryDatesAndMissingMark() async throws {
        DashboardStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/account")
            XCTAssertEqual(request.url?.query, "limit=2000")
            return (200, Data(#"{"balances":[{"captured_at":"2026-09-13T00:00:00.123Z","cash_cents":2388},{"captured_at":"2026-09-13T00:01:00Z","cash_cents":2388,"portfolio_value_cents":0}],"floor_cents":1000}"#.utf8))
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "test-token" })
        let history = try await client.account()
        XCTAssertEqual(history.floorCents, 1000)
        XCTAssertEqual(history.balances.count, 2)
        XCTAssertNil(history.balances[0].portfolioValueCents)
        XCTAssertLessThan(history.balances[0].capturedAt, history.balances[1].capturedAt)
    }

    func testActivityUsesPairedDeviceEndpointAndSanitizedShape() async throws {
        let fixtureURL = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "activity", withExtension: "json", subdirectory: "Fixtures"))
        let fixture = try Data(contentsOf: fixtureURL)
        DashboardStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/activity")
            XCTAssertEqual(request.url?.query, "limit=50")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            return (200, fixture)
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "device-token" })
        let activity = try await client.activity()
        XCTAssertEqual(activity.schemaVersion, 1)
        XCTAssertEqual(activity.budget?.bookCount, 14)
        XCTAssertEqual(activity.orders.first?.safeTicker, "FIXTURE-T")
        XCTAssertEqual(activity.refusals.first?.stateLabel, "Refused")
    }

    func testRedirectRefusedAndRateLimitBounded() async throws {
        var requests = 0
        var waits: [UInt64] = []
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "test-token" }, sleep: { waits.append($0) })
        DashboardStub.handler = { _ in requests += 1; return (301, Data()) }
        do { let _ = try await client.books(); XCTFail("Expected redirect error") }
        catch { XCTAssertEqual(error as? DashboardClientError, .http(301)) }
        XCTAssertEqual(requests, 1)
        let session = URLSession(configuration: .ephemeral)
        defer { session.invalidateAndCancel() }
        let request = URLRequest(url: DashboardClient.baseURL)
        let response = try XCTUnwrap(HTTPURLResponse(url: DashboardClient.baseURL, statusCode: 301, httpVersion: nil, headerFields: nil))
        DashboardRedirectDelegate().urlSession(session, task: session.dataTask(with: request),
            willPerformHTTPRedirection: response, newRequest: request) { XCTAssertNil($0) }
        requests = 0
        DashboardStub.handler = { _ in requests += 1; return (429, Data()) }
        do { let _ = try await client.books(); XCTFail("Expected rate limit") }
        catch { XCTAssertEqual(error as? DashboardClientError, .rateLimited) }
        XCTAssertEqual(requests, 4)
        XCTAssertEqual(waits, [2_000_000_000, 4_000_000_000, 8_000_000_000])
    }

    func testTypedFailures() async throws {
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { "test-token" })
        for (status, expected) in [(401, DashboardClientError.unauthorized), (403, .forbidden),
                                   (503, .http(503)), (200, .decoding)] {
            DashboardStub.handler = { _ in (status, Data("invalid".utf8)) }
            do { let _ = try await client.books(); XCTFail("Expected typed error") }
            catch { XCTAssertEqual(error as? DashboardClientError, expected) }
        }
        DashboardStub.handler = { _ in throw URLError(.timedOut) }
        do { let _ = try await client.books(); XCTFail("Expected transport error") }
        catch { XCTAssertEqual(error as? DashboardClientError, .transport) }
        let missing = DashboardClient(protocolClasses: [DashboardStub.self], token: { throw DashboardClientError.noCredential })
        do { let _ = try await missing.books(); XCTFail("Expected missing token") }
        catch { XCTAssertEqual(error as? DashboardClientError, .noCredential) }
    }

    func testPairingCreateAndPollAreUnauthenticatedAndTyped() async throws {
        var requests = 0
        DashboardStub.handler = { request in
            requests += 1
            XCTAssertNil(request.value(forHTTPHeaderField: "Authorization"))
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/pair")
            if request.httpMethod == "POST" {
                XCTAssertEqual(try JSONSerialization.jsonObject(with: self.bodyData(request)) as? NSDictionary,
                               ["device_name": "Alex’s iPhone"] as NSDictionary)
                return (201, Data(#"{"pairing":{"id":"pair-1","code":"A1B2C3","poll_token":"poll-value","expires_at":"2026-09-18T12:10:00Z"}}"#.utf8))
            }
            XCTAssertEqual(request.httpMethod, "GET")
            let items = URLComponents(url: try XCTUnwrap(request.url), resolvingAgainstBaseURL: false)?.queryItems
            XCTAssertEqual(items?.first(where: { $0.name == "id" })?.value, "pair-1")
            XCTAssertEqual(items?.first(where: { $0.name == "poll_token" })?.value, "poll-value")
            if requests == 2 {
                return (200, Data(#"{"pairing":{"state":"pending","expires_at":"2026-09-18T12:10:00.000Z"}}"#.utf8))
            }
            return (200, Data(#"{"pairing":{"state":"approved","token":"device-bearer"}}"#.utf8))
        }
        let client = DashboardClient(protocolClasses: [DashboardStub.self], token: { XCTFail("Pairing must not read a bearer"); return "" })
        let created = try await client.requestPairing(deviceName: "  Alex’s iPhone  ")
        XCTAssertEqual(created.code, "A1B2C3")
        let polled = try await client.pollPairing(id: created.id, pollToken: created.pollToken)
        XCTAssertEqual(polled.state, .pending)
        let approved = try await client.pollPairing(id: created.id, pollToken: created.pollToken)
        XCTAssertEqual(approved.state, .approved)
        XCTAssertEqual(approved.token, "device-bearer")
        XCTAssertEqual(requests, 3)
    }
}
