import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor final class AccountRunnerControlFlowTests: XCTestCase {
    private let tenant = "11111111-1111-4111-8111-111111111111"
    private let lane = "22222222-2222-4222-8222-222222222222"
    private let other = "33333333-3333-4333-8333-333333333333"

    private func status(_ state: String, tenant: String? = nil, lane: String? = nil,
                        bound: Bool = true, kill: Bool = false, live: Bool? = nil,
                        laneState: String? = nil, flags: Bool = true,
                        requestState: String? = nil, requestAction: String = "start_live",
                        requestID: String = "attempt") throws -> KashbotStatus {
        var laneFields: [String: Any] = ["id": lane ?? self.lane, "state": laneState ?? state]
        if flags {
            laneFields["kill_requested"] = kill
            laneFields["live_enabled"] = live ?? (state == "live")
        }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .iso8601
        var fields: [String: Any] = [
            "dashboard_pairing": "paired", "account_binding": bound ? "bound" : "unbound",
            "automated_trading": state, "tenant": ["id": tenant ?? self.tenant], "lane": laneFields]
        if let requestState {
            fields["request"] = ["id": "request", "client_request_id": requestID,
                "action": requestAction, "state": requestState, "requested_at": "2026-09-19T00:00:00Z"]
        }
        return try decoder.decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: fields))
    }

    func testSetupWaitsForProvisioningThenSubmitsOnlyDryRun() async throws {
        let suite = "dry-run-test-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        var reads = 0
        var sent: [(KashbotRunnerAction, UUID)] = []
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            if reads == 1 { return try self.status("provisioning") }
            if reads == 2 { return try self.status("ready") }
            return try self.status(reads == 3 ? "provisioning" : "dry_run",
                requestState: reads == 3 ? "pending" : "applied", requestAction: "start_dry_run",
                requestID: sent[0].1.uuidString.lowercased())
        }, submit: { sent.append(($0, $1)) }, credentialIdentity: { "credential-a" },
            sleep: { _ in }, defaults: defaults)
        let result = try await flow.perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
        XCTAssertEqual(result.automatedTrading, .dryRun)
        XCTAssertEqual(result.lane?.liveEnabled, false)
        XCTAssertEqual(sent.count, 1)
        XCTAssertEqual(sent.first?.0, .startDryRun)
        XCTAssertEqual(reads, 4)
        let markerKey = "leafhft.dry-run.v1." + tenant + "." + lane
        XCTAssertNil(defaults.object(forKey: markerKey))
        XCTAssertNil(defaults.object(forKey: markerKey + ".at"))
        _ = try await flow.perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
        XCTAssertEqual(sent.count, 1)
    }

    func testDryRunLostReplyAndRestartOnlyReadBack() async throws {
        let suite = "dry-run-test-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        var sent: [UUID] = []
        var completed = false
        func makeFlow() -> AccountRunnerControlFlow {
            AccountRunnerControlFlow(readStatus: {
                if completed {
                    return try self.status("dry_run", requestState: "applied", requestAction: "start_dry_run",
                        requestID: sent[0].uuidString.lowercased())
                }
                return try self.status("ready")
            }, submit: { action, id in
                XCTAssertEqual(action, .startDryRun)
                sent.append(id)
                throw DashboardClientError.transport
            }, credentialIdentity: { "credential-a" }, sleep: { _ in throw CancellationError() }, defaults: defaults)
        }
        do {
            _ = try await makeFlow().perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Unconfirmed dry run must remain pending")
        } catch is CancellationError { }
        let markerKey = "leafhft.dry-run.v1." + tenant + "." + lane
        XCTAssertEqual(defaults.string(forKey: markerKey), sent.first?.uuidString)
        XCTAssertNotNil(defaults.object(forKey: markerKey + ".at"))
        // Even an unchanged ready status after restart cannot cause another command.
        do {
            _ = try await makeFlow().perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Unconfirmed retry must remain pending")
        } catch is CancellationError { }
        XCTAssertEqual(sent.count, 1)
        XCTAssertNotNil(defaults.object(forKey: markerKey))
        completed = true
        _ = try await makeFlow().perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
        XCTAssertEqual(sent.count, 1)
        XCTAssertNil(defaults.object(forKey: markerKey))
        XCTAssertNil(defaults.object(forKey: markerKey + ".at"))
    }

    func testExistingPendingDryRunIsAdoptedWithoutSubmission() async throws {
        let suite = "dry-run-test-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        var reads = 0
        var posts = 0
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            return try self.status(reads == 1 ? "provisioning" : "dry_run",
                requestState: reads == 1 ? "pending" : "applied", requestAction: "start_dry_run",
                requestID: self.other)
        }, submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" }, defaults: defaults)
        let result = try await flow.perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
        XCTAssertEqual(result.automatedTrading, .dryRun)
        XCTAssertEqual(posts, 0)
        let markerKey = "leafhft.dry-run.v1." + tenant + "." + lane
        XCTAssertNil(defaults.object(forKey: markerKey))
        XCTAssertNil(defaults.object(forKey: markerKey + ".at"))
    }

    func testDefinitivelyRejectedDryRunClearsMarkerAndCanSubmitAgain() async throws {
        let suite = "dry-run-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let markerKey = "leafhft.dry-run.v1." + tenant + "." + lane
        var sent: [UUID] = []
        let flow = AccountRunnerControlFlow(readStatus: {
            if sent.count < 2 { return try self.status("ready") }
            return try self.status("dry_run", requestState: "applied", requestAction: "start_dry_run",
                requestID: sent[1].uuidString)
        }, submit: { _, id in
            sent.append(id)
            XCTAssertEqual(defaults.string(forKey: markerKey), id.uuidString)
            XCTAssertNotNil(defaults.object(forKey: markerKey + ".at"))
            if sent.count == 1 { throw DashboardClientError.forbidden }
        }, credentialIdentity: { "credential-a" }, defaults: defaults)
        do {
            _ = try await flow.perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Expected definitive rejection")
        } catch { XCTAssertEqual(error as? DashboardClientError, .forbidden) }
        XCTAssertNil(defaults.object(forKey: markerKey))
        XCTAssertNil(defaults.object(forKey: markerKey + ".at"))
        _ = try await flow.perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
        XCTAssertEqual(sent.count, 2)
        XCTAssertNotEqual(sent.first, sent.last)
        XCTAssertNil(defaults.object(forKey: markerKey))
        XCTAssertNil(defaults.object(forKey: markerKey + ".at"))
    }

    func testOrphanedDryRunMarkerAllowsFreshSubmission() async throws {
        for hasStamp in [true, false] {
            let suite = "dry-run-test-" + UUID().uuidString
            let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
            defer { defaults.removePersistentDomain(forName: suite) }
            let markerKey = "leafhft.dry-run.v1." + tenant + "." + lane
            defaults.set(other, forKey: markerKey)
            if hasStamp {
                defaults.set(Date().addingTimeInterval(-121).timeIntervalSince1970, forKey: markerKey + ".at")
            }
            var sent: [UUID] = []
            let flow = AccountRunnerControlFlow(readStatus: {
                if sent.isEmpty {
                    return try self.status("ready", requestState: "applied", requestAction: "start_live",
                        requestID: self.tenant)
                }
                return try self.status("dry_run", requestState: "applied", requestAction: "start_dry_run",
                    requestID: sent[0].uuidString)
            }, submit: { action, id in
                XCTAssertEqual(action, .startDryRun)
                XCTAssertNotEqual(id.uuidString.lowercased(), self.other)
                XCTAssertEqual(defaults.string(forKey: markerKey), id.uuidString)
                XCTAssertGreaterThan(defaults.double(forKey: markerKey + ".at"), Date().timeIntervalSince1970 - 10)
                sent.append(id)
            }, credentialIdentity: { "credential-a" }, defaults: defaults)
            _ = try await flow.perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
            XCTAssertEqual(sent.count, 1)
            XCTAssertNil(defaults.object(forKey: markerKey))
            XCTAssertNil(defaults.object(forKey: markerKey + ".at"))
        }
    }

    func testSuccessfulPauseAndRevokeClearDryRunMarker() async throws {
        for action in [KashbotRunnerAction.pause, .revoke] {
            let suite = "dry-run-test-" + UUID().uuidString
            let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
            defer { defaults.removePersistentDomain(forName: suite) }
            let markerKey = "leafhft.dry-run.v1." + tenant + "." + lane
            defaults.set(other, forKey: markerKey)
            defaults.set(Date().timeIntervalSince1970, forKey: markerKey + ".at")
            var posts = 0
            let flow = AccountRunnerControlFlow(readStatus: {
                try self.status(posts == 0 ? "live" : (action == .pause ? "paused" : "revoked"))
            }, submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" }, defaults: defaults)
            _ = try await flow.perform(action, expectedTenantID: tenant, expectedLaneID: lane)
            XCTAssertEqual(posts, 1)
            XCTAssertNil(defaults.object(forKey: markerKey))
            XCTAssertNil(defaults.object(forKey: markerKey + ".at"))
        }
    }

    func testDryRunRequiresSafeMatchingAcknowledgement() async throws {
        for invalid in ["missing", "wrong-request", "live-enabled", "killed", "failed"] {
            let suite = "dry-run-test-" + UUID().uuidString
            let defaults = UserDefaults(suiteName: suite)!
            defer { defaults.removePersistentDomain(forName: suite) }
            var sent: [UUID] = []
            let flow = AccountRunnerControlFlow(readStatus: {
                if sent.isEmpty { return try self.status("ready") }
                return try self.status("dry_run", kill: invalid == "killed", live: invalid == "live-enabled",
                    requestState: invalid == "missing" ? nil : (invalid == "failed" ? "failed" : "applied"),
                    requestAction: "start_dry_run",
                    requestID: invalid == "wrong-request" ? self.other : sent[0].uuidString)
            }, submit: { _, id in sent.append(id) }, credentialIdentity: { "credential-a" },
                sleep: { _ in throw CancellationError() }, defaults: defaults)
            do {
                _ = try await flow.perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
                XCTFail("Unsafe or unrelated status must not finish setup")
            } catch { }
            XCTAssertEqual(sent.count, 1)
        }
    }

    func testDryRunRefusesLivePausedAndRevokedLanes() async throws {
        for state in ["live", "paused", "failed", "revoked", "credential_required"] {
            let suite = "dry-run-test-" + UUID().uuidString
            let defaults = UserDefaults(suiteName: suite)!
            defer { defaults.removePersistentDomain(forName: suite) }
            var posts = 0
            let flow = AccountRunnerControlFlow(readStatus: { try self.status(state) },
                submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" }, defaults: defaults)
            do {
                _ = try await flow.perform(.startDryRun, expectedTenantID: tenant, expectedLaneID: lane)
                XCTFail("Setup must not change this lane")
            } catch { XCTAssertEqual(error as? AccountRunnerControlError, .unavailable) }
            XCTAssertEqual(posts, 0)
        }
    }

    func testFailedRequestCannotBeReportedAsSuccessfulLive() async throws {
        var posts = 0
        let flow = AccountRunnerControlFlow(readStatus: {
            try self.status(posts == 0 ? "dry_run" : "live", requestState: posts == 0 ? nil : "failed")
        }, submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" })
        do {
            _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Failed request must not report success")
        } catch { XCTAssertEqual(error as? AccountRunnerControlError, .failed) }
        XCTAssertEqual(posts, 1)
    }

    func testFreshDryRunStartsLiveOnlyAfterAcknowledgement() async throws {
        var reads = 0
        var sent: [(KashbotRunnerAction, UUID)] = []
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            if reads == 1 { XCTAssertTrue(sent.isEmpty) }
            return try self.status(reads < 3 ? "dry_run" : "live")
        }, submit: { sent.append(($0, $1)) }, credentialIdentity: { "credential-a" }, sleep: { _ in })
        let result = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
        XCTAssertEqual(result.automatedTrading, .live)
        XCTAssertEqual(result.lane?.liveEnabled, true)
        XCTAssertEqual(reads, 3)
        XCTAssertEqual(sent.count, 1)
        XCTAssertEqual(sent.first?.0, .startLive)
        XCTAssertFalse(flow.running)
    }

    func testStartLiveWaitsThroughLivePendingForEnabledLive() async throws {
        var reads = 0
        var sent: [(KashbotRunnerAction, UUID)] = []
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            if reads == 1 { return try self.status("dry_run") }
            if reads == 2 { return try self.status("live_pending") }
            return try self.status("live", kill: false, live: true)
        }, submit: { sent.append(($0, $1)) }, credentialIdentity: { "credential-a" }, sleep: { _ in })
        let result = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
        XCTAssertEqual(result.automatedTrading, .live)
        XCTAssertEqual(result.lane?.liveEnabled, true)
        XCTAssertEqual(result.lane?.killRequested, false)
        XCTAssertEqual(reads, 3)
        XCTAssertEqual(sent.count, 1)
        XCTAssertEqual(sent.first?.0, .startLive)
        XCTAssertFalse(flow.running)
    }

    func testStartLiveReadbackErrorFails() async throws {
        var posts = 0
        var reads = 0
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            return try self.status(posts == 0 ? "dry_run" : "error")
        }, submit: { action, _ in
            XCTAssertEqual(action, .startLive)
            posts += 1
        }, credentialIdentity: { "credential-a" }, sleep: { _ in XCTFail("Runner error must stop readback") })
        do {
            _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Runner error must fail the action")
        } catch { XCTAssertEqual(error as? AccountRunnerControlError, .failed) }
        XCTAssertEqual(posts, 1)
        XCTAssertEqual(reads, 2)
        XCTAssertFalse(flow.running)
    }

    func testCachedDryRunCannotOverrideFreshUnsafeState() async throws {
        let cached = try status("dry_run")
        XCTAssertTrue(cached.allows(.startLive))
        for fresh in [try status("ready"), try status("provisioning"), try status("paused"),
                      try status("failed"), try status("revoked"), try status("live"),
                      try status("dry_run", bound: false), try status("dry_run", kill: true),
                      try status("dry_run", live: true), try status("dry_run", laneState: "ready"),
                      try status("dry_run", flags: false)] {
            var posts = 0
            let flow = AccountRunnerControlFlow(readStatus: { fresh }, submit: { _, _ in posts += 1 },
                                                credentialIdentity: { "credential-a" })
            do {
                _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
                XCTFail("Fresh state must refuse")
            } catch { }
            XCTAssertEqual(posts, 0)
        }
    }

    func testUnknownStatusAndReadFailureCannotMutate() async throws {
        var posts = 0
        for unknown in [true, false] {
            let flow = AccountRunnerControlFlow(readStatus: {
                if unknown { return try self.status("future") }
                throw DashboardClientError.transport
            }, submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" })
            do {
                _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
                XCTFail("Unavailable status must refuse")
            } catch { }
        }
        XCTAssertEqual(posts, 0)
    }

    func testLostOrUnreadableReplyReadsBackWithoutSecondPost() async throws {
        for failure in [DashboardClientError.transport, .decoding] {
            var posts = 0
            var reads = 0
            let flow = AccountRunnerControlFlow(readStatus: {
                reads += 1
                return try self.status(posts == 0 ? "dry_run" : "live")
            }, submit: { _, _ in posts += 1; throw failure }, credentialIdentity: { "credential-a" })
            let result = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTAssertEqual(result.automatedTrading, .live)
            XCTAssertEqual(posts, 1)
            XCTAssertEqual(reads, 2)
        }
    }

    func testDefiniteRefusalStopsWithoutRetry() async throws {
        var posts = 0
        var reads = 0
        let flow = AccountRunnerControlFlow(readStatus: { reads += 1; return try self.status("dry_run") },
            submit: { _, _ in posts += 1; throw DashboardClientError.forbidden },
            credentialIdentity: { "credential-a" })
        do {
            _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Expected refusal")
        } catch { XCTAssertEqual(error as? DashboardClientError, .forbidden) }
        XCTAssertEqual(posts, 1)
        XCTAssertEqual(reads, 1)
    }

    func testPauseAndRevokeAreStateGated() async throws {
        for action in [KashbotRunnerAction.pause, .revoke] {
            for state in ["not_configured", "credential_required", "provisioning", "ready", "dry_run", "live", "live_pending", "error", "quantum", "paused", "failed", "revoked"] {
                var posts = 0
                let allowed = action == .pause ? ["live", "live_pending", "error", "quantum"].contains(state)
                    : !["not_configured", "credential_required", "revoked"].contains(state)
                let terminal = action == .pause ? "paused" : "revoked"
                let flow = AccountRunnerControlFlow(readStatus: {
                    try self.status(posts == 0 ? state : terminal)
                }, submit: { actual, _ in XCTAssertEqual(actual, action); posts += 1 },
                    credentialIdentity: { "credential-a" })
                do {
                    let result = try await flow.perform(action, expectedTenantID: tenant, expectedLaneID: lane)
                    XCTAssertTrue(allowed)
                    XCTAssertEqual(result.automatedTrading.rawValue, terminal)
                } catch { XCTAssertFalse(allowed) }
                XCTAssertEqual(posts, allowed ? 1 : 0)
            }
        }
    }

    func testScopeDriftBeforeAndAfterPostFailsClosed() async throws {
        for driftBeforePost in [true, false] {
            for changeTenant in [true, false] {
                var posts = 0
                let flow = AccountRunnerControlFlow(readStatus: {
                    let drift = driftBeforePost || posts > 0
                    return try self.status(posts == 0 ? "dry_run" : "live",
                        tenant: drift && changeTenant ? self.other : self.tenant,
                        lane: drift && !changeTenant ? self.other : self.lane)
                }, submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" })
                do {
                    _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
                    XCTFail("Scope drift must refuse")
                } catch { XCTAssertEqual(error as? AccountRunnerControlError, .scopeChanged) }
                XCTAssertEqual(posts, driftBeforePost ? 0 : 1)
            }
        }
    }

    func testCredentialOrBearerDriftStopsBeforeCompletion() async throws {
        for driftBeforePost in [true, false] {
            var identity: String? = "credential-and-bearer-a"
            var posts = 0
            let flow = AccountRunnerControlFlow(readStatus: {
                if driftBeforePost { identity = "credential-and-bearer-b" }
                return try self.status("dry_run")
            }, submit: { _, _ in posts += 1; identity = nil }, credentialIdentity: { identity })
            do {
                _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
                XCTFail("Credential drift must refuse")
            } catch { XCTAssertEqual(error as? AccountRunnerControlError, .scopeChanged) }
            XCTAssertEqual(posts, driftBeforePost ? 0 : 1)
        }
    }

    func testCancellationStopsPolling() async throws {
        var reads = 0
        var posts = 0
        let flow = AccountRunnerControlFlow(readStatus: { reads += 1; return try self.status("dry_run") },
            submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" },
            sleep: { _ in throw CancellationError() })
        do {
            _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Expected cancellation")
        } catch is CancellationError { }
        XCTAssertEqual(reads, 2)
        XCTAssertEqual(posts, 1)
        XCTAssertFalse(flow.running)
    }

    func testLiveNeedsEnabledFlagAndPollingStopsAtSixtySeconds() async throws {
        var clock: TimeInterval = 0
        var posts = 0
        var reads = 0
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            return try self.status(posts == 0 ? "dry_run" : "live", live: false)
        }, submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" },
            sleep: { delay in clock += Double(delay) / 1_000_000_000 }, now: { clock })
        do {
            _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Live state alone is not acknowledgement")
        } catch { XCTAssertEqual(error as? AccountRunnerControlError, .timedOut) }
        XCTAssertEqual(clock, 60)
        XCTAssertEqual(posts, 1)
        XCTAssertEqual(reads, 31)
    }

    func testTaskCancellationInterruptsStatusReadback() async throws {
        let reading = expectation(description: "Reading after submission")
        var posts = 0
        var reads = 0
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            if posts > 0 {
                reading.fulfill()
                try await Task.sleep(nanoseconds: 60_000_000_000)
                XCTFail("Cancelled readback must not complete")
            }
            return try self.status("dry_run")
        }, submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" })
        let attempt = Task { try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane) }
        await fulfillment(of: [reading], timeout: 2)
        attempt.cancel()
        do { _ = try await attempt.value; XCTFail("Expected cancellation") }
        catch is CancellationError { }
        XCTAssertEqual(posts, 1)
        XCTAssertEqual(reads, 2)
        XCTAssertFalse(flow.running)
    }

    func testConcurrentAttemptCannotSubmitTwice() async throws {
        var posts = 0
        var flow: AccountRunnerControlFlow!
        flow = AccountRunnerControlFlow(readStatus: { try self.status(posts == 0 ? "dry_run" : "live") },
            submit: { _, _ in
                posts += 1
                do {
                    _ = try await flow.perform(.startLive, expectedTenantID: self.tenant, expectedLaneID: self.lane)
                    XCTFail("A running action owns the mutation")
                } catch { XCTAssertEqual(error as? AccountRunnerControlError, .unavailable) }
            }, credentialIdentity: { "credential-a" })
        _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
        XCTAssertEqual(posts, 1)
    }

    func testTerminalFailureStopsReadback() async throws {
        var posts = 0
        var reads = 0
        let flow = AccountRunnerControlFlow(readStatus: {
            reads += 1
            return try self.status(posts == 0 ? "dry_run" : "failed")
        }, submit: { _, _ in posts += 1 }, credentialIdentity: { "credential-a" })
        do {
            _ = try await flow.perform(.startLive, expectedTenantID: tenant, expectedLaneID: lane)
            XCTFail("Expected terminal failure")
        } catch { XCTAssertEqual(error as? AccountRunnerControlError, .failed) }
        XCTAssertEqual(posts, 1)
        XCTAssertEqual(reads, 2)
    }
}
