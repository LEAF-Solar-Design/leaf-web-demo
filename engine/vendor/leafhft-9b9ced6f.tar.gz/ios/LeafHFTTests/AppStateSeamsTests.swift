import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor private final class SeamAuthenticator: RiskAuthenticator {
    var succeeds = false
    var reasons: [String] = []
    func authenticate(reason: String) async -> Bool {
        reasons.append(reason)
        return succeeds
    }
}

@MainActor final class AppStateSeamsTests: XCTestCase {
    private func status(_ trading: String, owner: Bool = false) throws -> KashbotStatus {
        var fields: [String: Any] = [
            "dashboard_pairing": "paired", "account_binding": "bound", "automated_trading": trading,
            "tenant": ["id": "11111111-1111-4111-8111-111111111111", "runner_host": "runner"],
            "lane": ["id": "22222222-2222-4222-8222-222222222222", "state": trading,
                     "live_enabled": trading == "live", "kill_requested": trading == "paused"]]
        if owner {
            fields["execution"] = ["capabilities": ["owner_domain_control": true, "resume": true, "pause": true],
                                   "pause": ["state": "paused"]]
        }
        return try accountJSONDecoder().decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: fields))
    }

    func testFeedFailurePreservesObservationAndSuccessClearsError() {
        let state = AppState(fixtureMode: FixtureMode(arguments: []))
        let first = Date(timeIntervalSince1970: 100)
        let second = first.addingTimeInterval(20)
        XCTAssertTrue(state.isStale(.balance, budget: 30, now: first))
        state.recordFeedSuccess(.balance, now: first)
        XCTAssertFalse(state.isStale(.balance, budget: 30, now: second))
        XCTAssertTrue(state.isStale(.balance, budget: 10, now: second))
        state.recordFeedFailure(.balance, error: "offline", now: second)
        XCTAssertEqual(state.feedStatuses[.balance], FeedStatus(observedAt: first, attemptedAt: second, lastError: "offline"))
        state.recordFeedSuccess(.balance, now: second)
        XCTAssertEqual(state.feedStatuses[.balance], FeedStatus(observedAt: second, attemptedAt: second, lastError: nil))
        state.recordFeedFailure(.probes, error: "offline", now: first)
        XCTAssertNotNil(state.feedStatuses[.probes])
        XCTAssertEqual(state.feedStatuses[.probes]?.lastError, "offline")
        XCTAssertNil(state.feedStatuses[.probes]?.observedAt)
    }

    func testBoardObservationRequiresAllFeedsAndUsesOldest() {
        let state = AppState(fixtureMode: FixtureMode(arguments: []))
        let oldest = Date(timeIntervalSince1970: 100)
        state.recordFeedSuccess(.balance, now: oldest.addingTimeInterval(10))
        state.recordFeedSuccess(.positions, now: oldest)
        XCTAssertNil(state.boardObservedAt)
        state.recordFeedSuccess(.settlements, now: oldest.addingTimeInterval(20))
        XCTAssertEqual(state.boardObservedAt, oldest)
        state.recordFeedFailure(.positions, error: "offline", now: oldest.addingTimeInterval(30))
        XCTAssertEqual(state.boardObservedAt, oldest)
    }

    func testPausePreemptsStartAndRejectsLateCompletion() async throws {
        let state = AppState(fixtureMode: FixtureMode(arguments: []))
        let start = state.beginAccountMutation(.startLive)
        XCTAssertTrue(state.accountMutationInProgress)
        XCTAssertTrue(state.canPause)
        XCTAssertTrue(state.canRunAccountAction(.pause))
        XCTAssertFalse(state.canRunAccountAction(.startLive))
        var completion: CheckedContinuation<KashbotStatus, Never>?
        let ready = expectation(description: "Start is waiting for its reply")
        let lateStart = Task {
            let result = await withCheckedContinuation { (continuation: CheckedContinuation<KashbotStatus, Never>) in
                completion = continuation
                ready.fulfill()
            }
            return state.acceptAccountActionResult(result, sequence: start)
        }
        await fulfillment(of: [ready], timeout: 1)
        let pause = state.beginAccountMutation(.pause)
        XCTAssertTrue(state.acceptAccountActionResult(try status("paused"), sequence: pause))
        state.finishAccountMutation(sequence: start)
        XCTAssertTrue(state.accountMutationInProgress, "Old cleanup must not release the pause mutation")
        state.finishAccountMutation(sequence: pause)
        completion?.resume(returning: try status("live"))
        let accepted = await lateStart.value
        XCTAssertFalse(accepted)
        XCTAssertEqual(state.kashbotStatus?.automatedTrading, .paused)
        XCTAssertFalse(state.accountMutationInProgress)
        let pending = state.beginAccountMutation(.pause)
        state.acceptAccountActionResult(try status("live_pending"), sequence: pending)
        state.finishAccountMutation(sequence: pending)
        XCTAssertTrue(state.canPause)
    }

    func testResumeEligibilityAndHookForTenantAndOwner() async throws {
        let state = AppState(fixtureMode: FixtureMode(arguments: []))
        XCTAssertFalse(state.canResume)
        let initial = state.beginAccountMutation(.pause)
        state.acceptAccountActionResult(try status("paused"), sequence: initial)
        state.finishAccountMutation(sequence: initial)
        XCTAssertFalse(state.canResume, "A paused tenant without credentials cannot resume")
        // Owner capability is the existing start path's prerequisite. No action runs before confirmation.
        let owner = state.beginAccountMutation(.pause)
        state.acceptAccountActionResult(try status("paused", owner: true), sequence: owner)
        state.finishAccountMutation(sequence: owner)
        state.sceneChanged(.active)
        defer { state.sceneChanged(.inactive) }
        XCTAssertTrue(state.canResume)
        await state.resumeTrading()
        XCTAssertEqual(state.pendingConfirmation?.actionLabel, "Resume trading")
        XCTAssertFalse(state.accountMutationInProgress)
        state.cancelPending()
        XCTAssertNil(state.pendingConfirmation)
    }

    func testConfirmationDefersActionAndFailedAuthenticationDoesNothing() async {
        let auth = SeamAuthenticator()
        let state = AppState(fixtureMode: FixtureMode(arguments: []), riskAuthenticator: auth)
        var performed = 0
        state.requestRaisesRisk(title: "Start", detail: "Live orders", actionLabel: "Start") { performed += 1 }
        XCTAssertEqual(performed, 0)
        await state.confirmPending()
        XCTAssertEqual(auth.reasons, ["Start"])
        XCTAssertEqual(performed, 0)
        XCTAssertNil(state.pendingConfirmation)
        auth.succeeds = true
        state.requestRaisesRisk(title: "Resume", detail: "Live orders", actionLabel: "Resume") { performed += 1 }
        await state.confirmPending()
        XCTAssertEqual(performed, 1)
        XCTAssertNil(state.pendingConfirmation)
        await state.confirmPending()
        XCTAssertEqual(performed, 1)
        state.requestRaisesRisk(title: "Cancel", detail: "Live orders", actionLabel: "Start") { performed += 1 }
        state.cancelPending()
        await state.confirmPending()
        XCTAssertEqual(performed, 1)
        XCTAssertEqual(auth.reasons, ["Start", "Resume"])
    }

    func testDefaultFixtureAuthenticationSucceedsWithoutDevicePrompt() async {
        let mode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])
        let authenticated = await DeviceOwnerRiskAuthenticator(fixtureMode: mode).authenticate(reason: "Fixture")
        XCTAssertTrue(authenticated)
    }

    func testRefreshPopulatesProbesStatusOnFirstFetchFailure() async {
        DashboardStub.handler = { _ in (503, Data()) }
        defer { DashboardStub.handler = nil }
        let client = DashboardClient(fixtureMode: FixtureMode(arguments: []),
                                     protocolClasses: [DashboardStub.self], token: { "seam-test" }, sleep: { _ in })
        let state = AppState(fixtureMode: FixtureMode(arguments: []), dashboard: client)
        await state.refreshEngines()
        XCTAssertNil(state.probeBoard)
        XCTAssertNotNil(state.feedStatuses[.probes]?.lastError)
        XCTAssertNotNil(state.feedStatuses[.probes]?.attemptedAt)
        XCTAssertNil(state.feedStatuses[.probes]?.observedAt)
        XCTAssertNotNil(state.feedStatuses[.engines]?.lastError)
    }

    func testRefreshSuccessThenFailureRetainsFeedObservation() async throws {
        let bundle = Bundle(for: Self.self)
        let enginesURL = try XCTUnwrap(bundle.url(forResource: "engines", withExtension: "json", subdirectory: "Fixtures"))
        let probesURL = try XCTUnwrap(bundle.url(forResource: "probes", withExtension: "json", subdirectory: "Fixtures"))
        let engines = try Data(contentsOf: enginesURL)
        let probes = try Data(contentsOf: probesURL)
        var failing = false
        var now = Date(timeIntervalSince1970: 100)
        DashboardStub.handler = { request in
            if failing { return (503, Data()) }
            switch request.url?.path {
            case "/api/leafhft/mobile/engines": return (200, engines)
            case "/api/leafhft/mobile/probes": return (200, probes)
            default: return (404, Data())
            }
        }
        defer { DashboardStub.handler = nil }
        let mode = FixtureMode(arguments: [])
        let client = DashboardClient(fixtureMode: mode, protocolClasses: [DashboardStub.self],
                                     token: { "seam-test" }, sleep: { _ in })
        let state = AppState(fixtureMode: mode, dashboard: client, clock: { now })
        await state.refreshEngines()
        XCTAssertEqual(state.feedStatuses[.engines]?.observedAt, now)
        XCTAssertEqual(state.feedStatuses[.probes]?.observedAt, now)
        XCTAssertNil(state.feedStatuses[.engines]?.lastError, "Control-request errors have their own status")
        XCTAssertNil(state.feedStatuses[.probes]?.lastError)
        failing = true
        now = now.addingTimeInterval(60)
        await state.refreshEngines()
        XCTAssertEqual(state.feedStatuses[.engines]?.observedAt, now.addingTimeInterval(-60))
        XCTAssertEqual(state.feedStatuses[.probes]?.observedAt, now.addingTimeInterval(-60))
        XCTAssertEqual(state.feedStatuses[.probes]?.attemptedAt, now)
        XCTAssertNotNil(state.feedStatuses[.probes]?.lastError)
        XCTAssertTrue(state.isStale(.probes, budget: 30, now: now))
    }
}
