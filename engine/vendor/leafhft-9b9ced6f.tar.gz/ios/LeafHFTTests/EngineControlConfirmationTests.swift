import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor final class EngineControlConfirmationTests: XCTestCase {
    private let requestId = "00000000-0000-4000-8000-000000000001"

    private func state() -> AppState {
        AppState(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_CONTROL_WALK", "1"]),
            bundle: Bundle(for: Self.self))
    }

    private func engine(_ id: String, in state: AppState) throws -> Engine {
        try XCTUnwrap(state.engines?.engines?.first { $0.engineId == id })
    }

    private func confirmations() throws -> [EngineControlConfirmation] {
        let state = state()
        let standard = try engine("default", in: state)
        return [
            try .toggle(engine: standard, enabled: true, host: "sample-runner", scope: .global,
                scopeLabel: "every account", expectedRevision: "global-default-r1", clientRequestId: requestId),
            try .bind(engine: engine("aggressive", in: state), symbol: "BTC-15M", note: "Sample bind"),
            try .create(source: standard, newId: "default-copy", name: "Default copy", note: "Sample create")
        ]
    }

    private func snapshot(canToggle: Bool = true, outcomeUnknown: Bool = false, pending: Bool = false,
                          observedEnabled: Bool? = true, host: String? = "sample-runner",
                          revision: String? = "main-default-r0", scope: ControlScope? = nil) throws -> EngineToggleSnapshot {
        EngineToggleSnapshot(canToggle: canToggle, outcomeUnknown: outcomeUnknown, pending: pending,
            observedEnabled: observedEnabled, host: host, revision: revision,
            scope: try scope ?? ControlScope.account("sample-main"), scopeLabel: "Main subaccount (sample)")
    }

    private func heldToggle() throws -> EngineControlConfirmation {
        try .toggle(engine: engine("default", in: state()), enabled: false, host: "sample-runner",
            scope: ControlScope.account("sample-main"), scopeLabel: "Main subaccount (sample)",
            expectedRevision: "main-default-r0", clientRequestId: requestId)
    }

    func testCancelSendsZeroCallsForToggleBindAndCreate() throws {
        for c in try confirmations() {
            let gate = EngineControlGate()
            let stub = SubmitStub()
            XCTAssertTrue(gate.hold(c))
            XCTAssertEqual(gate.pending, c)
            gate.cancel()
            XCTAssertNil(gate.pending)
            XCTAssertEqual(stub.calls.count, 0)
            XCTAssertEqual(gate.successTick, 0)
            XCTAssertEqual(gate.failureTick, 0)
        }
    }

    func testConfirmSendsExactlyOneCallWithTheHeldIntent() async throws {
        for c in try confirmations() {
            let gate = EngineControlGate()
            let stub = SubmitStub()
            var rechecks = 0
            var preparations = 0
            XCTAssertTrue(gate.hold(c))
            let outcome = await gate.confirm(c, recheck: { rechecks += 1; return nil },
                willSend: { preparations += 1 }, submit: stub.submit)
            XCTAssertEqual(outcome, .sent(nil))
            XCTAssertEqual(stub.calls.count, 1)
            XCTAssertEqual(stub.calls.first?.0, c.intent)
            XCTAssertEqual(stub.calls.first?.1, c.note)
            XCTAssertNil(gate.pending)
            XCTAssertFalse(gate.sending)
            XCTAssertEqual(gate.successTick, 1)
            XCTAssertEqual(gate.failureTick, 0)
            XCTAssertEqual(rechecks, 1)
            XCTAssertEqual(preparations, 1)
        }
    }

    func testDismissThenConfirmSendsOnceAndCancelThenConfirmSendsNone() async throws {
        let c = try confirmations()[0]
        let dismissed = EngineControlGate()
        let sent = SubmitStub()
        dismissed.hold(c)
        dismissed.dismiss()
        XCTAssertNil(dismissed.pending)
        let outcome = await dismissed.confirm(c, recheck: { nil }, submit: sent.submit)
        XCTAssertEqual(outcome, .sent(nil))
        XCTAssertEqual(sent.calls.count, 1)

        let cancelled = EngineControlGate()
        let untouched = SubmitStub()
        cancelled.hold(c)
        cancelled.cancel()
        let cancelledOutcome = await cancelled.confirm(c, recheck: { XCTFail("Cancelled recheck"); return nil },
            willSend: { XCTFail("Cancelled preparation") }, submit: untouched.submit)
        XCTAssertEqual(cancelledOutcome, .notSent)
        XCTAssertEqual(untouched.calls.count, 0)
        XCTAssertEqual(cancelled.successTick, 0)
        XCTAssertEqual(cancelled.failureTick, 0)
    }

    func testUnheldStaleAndRepeatedConfirmsSendNothing() async throws {
        let values = try confirmations()
        let c1 = values[0], c2 = values[1], c3 = values[2]
        let gate = EngineControlGate()
        let stub = SubmitStub()
        let unheld = await gate.confirm(c1, recheck: { XCTFail("Unheld recheck"); return nil }, submit: stub.submit)
        XCTAssertEqual(unheld, .notSent)
        XCTAssertEqual(stub.calls.count, 0)
        XCTAssertTrue(gate.hold(c1))
        XCTAssertTrue(gate.hold(c2))
        let stale = await gate.confirm(c1, recheck: { XCTFail("Stale recheck"); return nil }, submit: stub.submit)
        XCTAssertEqual(stale, .notSent)
        XCTAssertEqual(gate.pending, c2)
        XCTAssertEqual(stub.calls.count, 0)

        let entered = expectation(description: "Submit is suspended")
        stub.onSuspended = { entered.fulfill() }
        let first = Task { await gate.confirm(c2, recheck: { nil }, submit: stub.submit) }
        await fulfillment(of: [entered], timeout: 3)
        XCTAssertTrue(gate.sending)
        XCTAssertEqual(stub.calls.count, 1)
        let duplicate = await gate.confirm(c2, recheck: { XCTFail("Duplicate recheck"); return nil }, submit: stub.submit)
        XCTAssertEqual(duplicate, .notSent)
        XCTAssertFalse(gate.hold(c3))
        XCTAssertNil(gate.pending)
        stub.resume()
        let firstOutcome = await first.value
        XCTAssertEqual(firstOutcome, .sent(nil))
        let repeated = await gate.confirm(c2, recheck: { XCTFail("Repeated recheck"); return nil }, submit: stub.submit)
        XCTAssertEqual(repeated, .notSent)
        XCTAssertEqual(stub.calls.count, 1)
        XCTAssertEqual(gate.successTick, 1)
        XCTAssertEqual(gate.failureTick, 0)
    }

    func testFeedbackTicksOnlyAfterSubmitReturns() async throws {
        let c = try confirmations()[0]
        let unknown = "The result is unknown. Check Requests before submitting again."
        let results: [String?] = [nil, unknown]
        for result in results {
            let gate = EngineControlGate()
            let stub = SubmitStub(result: result)
            stub.inspect = {
                XCTAssertTrue(gate.sending)
                XCTAssertNil(gate.pending)
                XCTAssertEqual(gate.successTick, 0)
                XCTAssertEqual(gate.failureTick, 0)
            }
            gate.hold(c)
            let outcome = await gate.confirm(c, recheck: { nil }, submit: stub.submit)
            XCTAssertEqual(outcome, .sent(result))
            XCTAssertEqual(stub.calls.count, 1)
            XCTAssertFalse(gate.sending)
            XCTAssertEqual(gate.successTick, result == nil ? 1 : 0)
            XCTAssertEqual(gate.failureTick, result == nil ? 0 : 1)
        }
        let gate = EngineControlGate()
        let stub = SubmitStub()
        let unheld = await gate.confirm(c, recheck: { nil }, submit: stub.submit)
        XCTAssertEqual(unheld, .notSent)
        gate.hold(c)
        let refused = await gate.confirm(c, recheck: { "reason" }, submit: stub.submit)
        XCTAssertEqual(refused, .refused("reason"))
        XCTAssertEqual(stub.calls.count, 0)
        XCTAssertEqual(gate.successTick, 0)
        XCTAssertEqual(gate.failureTick, 0)
    }

    func testSummariesNameTheEngineAndTheSymbol() throws {
        let aggressive = try engine("aggressive", in: state())
        let scope = try ControlScope.account("sample-main")
        let on = try EngineControlConfirmation.toggle(engine: aggressive, enabled: true, host: "sample-runner",
            scope: scope, scopeLabel: "Main subaccount (sample)", expectedRevision: "main-aggressive-r0", clientRequestId: requestId)
        let off = try EngineControlConfirmation.toggle(engine: aggressive, enabled: false, host: "sample-runner",
            scope: scope, scopeLabel: "Main subaccount (sample)", expectedRevision: "main-aggressive-r0", clientRequestId: requestId)
        let bind = try EngineControlConfirmation.bind(engine: aggressive, symbol: "BTC-15M", note: nil)
        let all = try EngineControlConfirmation.bind(engine: aggressive, symbol: nil, note: nil)
        let create = try EngineControlConfirmation.create(source: aggressive, newId: "aggressive-copy", name: " Aggressive copy ", note: nil)
        let rows: [(EngineControlConfirmation, String, String, String, Bool, ControlIntent)] = [
            (on, "Turn on Aggressive?", "Aggressive can open new positions with real money in Main subaccount (sample).",
             "Turn on Aggressive", false,
             try .configure(engineId: "aggressive", host: "sample-runner", scope: scope, enabled: .value(true), expectedRevision: "main-aggressive-r0", clientRequestId: requestId)),
            (off, "Pause Aggressive?", "Aggressive stops opening new positions in Main subaccount (sample). Open positions keep their normal exit and risk handling.",
             "Pause Aggressive", true,
             try .configure(engineId: "aggressive", host: "sample-runner", scope: scope, enabled: .value(false), expectedRevision: "main-aggressive-r0", clientRequestId: requestId)),
            (bind, "Bind Aggressive to BTC-15M?", "The BTC-15M book switches to Aggressive right away. New entries on BTC-15M use Aggressive with real money.",
             "Bind Aggressive to BTC-15M", false, try .bind(symbol: "BTC-15M", engineId: "aggressive")),
            (all, "Bind Aggressive to all books?", "Every book switches to Aggressive right away. New entries use Aggressive with real money.",
             "Bind Aggressive to all books", false, try .bind(symbol: nil, engineId: "aggressive")),
            (create, "Create Aggressive copy?", "Creates engine Aggressive copy (aggressive-copy) from Aggressive's settings. It starts disabled and not bound to any book.",
             "Create Aggressive copy", false, try .create(engineId: "aggressive-copy", name: "Aggressive copy", from: "aggressive"))
        ]
        for (c, title, message, label, destructive, intent) in rows {
            XCTAssertEqual(c.title, title)
            XCTAssertEqual(c.message, message)
            XCTAssertEqual(c.confirmLabel, label)
            XCTAssertEqual(c.isDestructive, destructive)
            XCTAssertEqual(c.intent, intent)
            XCTAssertEqual(c.engineId, "aggressive")
        }
        XCTAssertEqual(on.note, "Enabled from Engines")
        XCTAssertEqual(off.note, "Disabled from Engines")
        XCTAssertEqual(create.intent.value.displayValue, "{\"engine_id\":\"aggressive-copy\",\"from\":\"aggressive\",\"name\":\"Aggressive copy\"}")
        XCTAssertThrowsError(try EngineControlConfirmation.create(source: aggressive, newId: "Bad Id", name: "Copy", note: nil))
    }

    func testControlWalkReachesAppStateOnceOnlyAfterConfirm() async throws {
        let state = state()
        let c = try EngineControlConfirmation.bind(engine: engine("aggressive", in: state), symbol: "BTC-15M", note: nil)
        let gate = EngineControlGate()
        gate.hold(c)
        gate.cancel()
        XCTAssertTrue(state.pendingRequests.isEmpty)
        gate.hold(c)
        let bound = await gate.confirm(c, recheck: { nil }, submit: state.submit)
        XCTAssertEqual(bound, .sent(nil))
        XCTAssertEqual(state.pendingRequests.count, 1)
        XCTAssertEqual(state.pendingRequests.first?.id, "fixture-request-1")
        XCTAssertEqual(state.pendingRequests.first?.kind, "engine.bind")
        XCTAssertEqual(state.pendingRequests.first?.value?.displayValue, "BTC-15M=aggressive")
        let toggle = try EngineControlConfirmation.toggle(engine: engine("default", in: state), enabled: false,
            host: "sample-runner", scope: .global, scopeLabel: "every account",
            expectedRevision: "global-default-r1", clientRequestId: requestId)
        gate.hold(toggle)
        let configured = await gate.confirm(toggle, recheck: { nil }, submit: state.submit)
        XCTAssertEqual(configured, .sent(nil))
        XCTAssertEqual(state.pendingRequests.count, 2)
        XCTAssertEqual(state.pendingRequests.last?.kind, "engine.configure")
        XCTAssertEqual(state.pendingRequests.last?.clientRequestId, toggle.intent.clientRequestId)
    }

    func testStateChangedAtConfirmRefusesAndSendsNothing() async throws {
        let c = try heldToggle()
        let gate = EngineControlGate()
        let stub = SubmitStub()
        gate.hold(c)
        var rechecks = 0
        let outcome = await gate.confirm(c, recheck: { rechecks += 1; return "reason" },
            willSend: { XCTFail("Refused preparation") }, submit: stub.submit)
        XCTAssertEqual(outcome, .refused("reason"))
        XCTAssertEqual(rechecks, 1)
        XCTAssertEqual(stub.calls.count, 0)
        XCTAssertNil(gate.pending)
        XCTAssertFalse(gate.sending)
        XCTAssertEqual(gate.successTick, 0)
        XCTAssertEqual(gate.failureTick, 0)
        let repeated = await gate.confirm(c, recheck: { nil }, submit: stub.submit)
        XCTAssertEqual(repeated, .notSent)
        XCTAssertEqual(stub.calls.count, 0)

        typealias C = EngineControlConfirmation
        XCTAssertNil(C.toggleRefusal(held: c, current: try snapshot()))
        let cases: [(EngineToggleSnapshot?, String)] = [
            (nil, C.refusedNotListed),
            (try snapshot(outcomeUnknown: true), C.refusedOutcomeUnknown),
            (try snapshot(pending: true), C.refusedPending),
            (try snapshot(observedEnabled: nil), C.refusedNotReported),
            (try snapshot(canToggle: false), C.refusedChanged),
            (try snapshot(host: "other-runner"), C.refusedChanged),
            (try snapshot(revision: "main-default-r1"), C.refusedChanged),
            (try snapshot(scope: .global), C.refusedChanged),
            (try snapshot(canToggle: false, outcomeUnknown: true, pending: true, observedEnabled: nil), C.refusedOutcomeUnknown),
            (try snapshot(canToggle: false, pending: true, observedEnabled: nil), C.refusedPending),
            (try snapshot(canToggle: false, observedEnabled: nil), C.refusedNotReported)
        ]
        for (current, reason) in cases { XCTAssertEqual(C.toggleRefusal(held: c, current: current), reason) }
        XCTAssertNil(C.sheetRefusal(engineListed: true, outcomeUnknown: false))
        XCTAssertEqual(C.sheetRefusal(engineListed: true, outcomeUnknown: true), C.refusedOutcomeUnknown)
        XCTAssertEqual(C.sheetRefusal(engineListed: false, outcomeUnknown: false), C.refusedNotListed)
        XCTAssertEqual(C.sheetRefusal(engineListed: false, outcomeUnknown: true), C.refusedOutcomeUnknown)
    }

    func testToggleRequestOnlyHoldsAndNeverSends() async throws {
        let engine = try engine("default", in: state())
        let gate = EngineControlGate()
        let stub = SubmitStub()
        typealias C = EngineControlConfirmation
        let reason = C.requestToggle(engine: engine, enabled: false, current: try snapshot(), clientRequestId: requestId, gate: gate)
        XCTAssertNil(reason)
        XCTAssertEqual(gate.pending?.kind, .disable)
        XCTAssertEqual(gate.pending?.title, "Pause Default?")
        XCTAssertEqual(gate.pending?.message, "Default stops opening new positions in Main subaccount (sample). Open positions keep their normal exit and risk handling.")
        XCTAssertEqual(stub.calls.count, 0)
        XCTAssertEqual(gate.successTick, 0)
        XCTAssertEqual(gate.failureTick, 0)
        let cases: [(EngineToggleSnapshot, String)] = [
            (try snapshot(observedEnabled: nil), C.notReported),
            (try snapshot(canToggle: false), C.unavailable),
            (try snapshot(outcomeUnknown: true), C.unavailable),
            (try snapshot(pending: true), C.unavailable),
            (try snapshot(host: nil), C.unavailable),
            (try snapshot(host: ""), C.unavailable),
            (try snapshot(revision: nil), C.unavailable),
            (try snapshot(revision: ""), C.unavailable)
        ]
        for (current, expected) in cases {
            let refusedGate = EngineControlGate()
            XCTAssertEqual(C.requestToggle(engine: engine, enabled: false, current: current, clientRequestId: requestId, gate: refusedGate), expected)
            XCTAssertNil(refusedGate.pending)
            XCTAssertEqual(refusedGate.successTick, 0)
            XCTAssertEqual(refusedGate.failureTick, 0)
        }
        let base = try snapshot()
        let c = try XCTUnwrap(gate.pending)
        let sendingStub = SubmitStub()
        sendingStub.inspect = {
            XCTAssertTrue(gate.sending)
            XCTAssertEqual(C.requestToggle(engine: engine, enabled: false, current: base, clientRequestId: self.requestId, gate: gate), C.busy)
            XCTAssertNil(gate.pending)
        }
        let sent = await gate.confirm(c, recheck: { nil }, submit: sendingStub.submit)
        XCTAssertEqual(sent, .sent(nil))
        XCTAssertEqual(stub.calls.count, 0)
    }

    func testOneAccountFixtureVariantHasOneConfigurableAccount() throws {
        let normalArgs = ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_CONTROL_WALK", "1"]
        let normalMode = FixtureMode(arguments: normalArgs)
        let oneMode = FixtureMode(arguments: normalArgs + ["-LEAFHFT_ONE_ACCOUNT", "1"])
        let previewMode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_ONE_ACCOUNT", "1"])
        XCTAssertTrue(oneMode.oneAccount)
        XCTAssertFalse(normalMode.oneAccount)
        XCTAssertFalse(previewMode.oneAccount)
        let normal = try FixtureCorpus(bundle: Bundle(for: Self.self), mode: normalMode)
        let one = try FixtureCorpus(bundle: Bundle(for: Self.self), mode: oneMode)
        let preview = try FixtureCorpus(bundle: Bundle(for: Self.self), mode: previewMode)
        let original = try normal.decode("engines", as: EnginesResponse.self)
        let narrowed = try one.decode("engines", as: EnginesResponse.self)
        XCTAssertEqual(original.accounts?.count, 2)
        XCTAssertEqual(try preview.decode("engines", as: EnginesResponse.self).accounts?.count, 2)
        XCTAssertEqual(narrowed.accounts?.count, 1)
        let account = try XCTUnwrap(narrowed.accounts?.first)
        XCTAssertEqual(account.id, "sample-main")
        XCTAssertEqual(account.label, "Main subaccount (sample)")
        XCTAssertTrue(account.configurable)
        XCTAssertEqual(narrowed.engines?.map(\.engineId), original.engines?.map(\.engineId))
        XCTAssertEqual(narrowed.engines?.first { $0.engineId == "default" }?.configuration?.accounts.first { $0.accountId == "sample-main" }?.revision, "main-default-r0")
        for corpus in [normal, one, preview] { XCTAssertEqual(corpus.data.count, FixtureCorpus.names.count) }
        var originalJSON = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(normal.data["engines"])) as? [String: Any])
        var narrowedJSON = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(one.data["engines"])) as? [String: Any])
        originalJSON.removeValue(forKey: "accounts")
        narrowedJSON.removeValue(forKey: "accounts")
        XCTAssertEqual(NSDictionary(dictionary: narrowedJSON), NSDictionary(dictionary: originalJSON))
        for key in FixtureCorpus.names where key != "engines" { XCTAssertEqual(one.data[key], normal.data[key]) }
    }
}

@MainActor private final class SubmitStub {
    private(set) var calls: [(ControlIntent, String?)] = []
    let result: String?
    var inspect: (() -> Void)?
    var onSuspended: (() -> Void)?
    private var continuation: CheckedContinuation<Void, Never>?

    init(result: String? = nil) { self.result = result }

    func submit(_ intent: ControlIntent, _ note: String?) async -> String? {
        calls.append((intent, note))
        inspect?()
        if let onSuspended {
            await withCheckedContinuation { continuation in
                self.continuation = continuation
                onSuspended()
            }
        }
        return result
    }

    func resume() {
        continuation?.resume()
        continuation = nil
    }
}
