import Foundation
import XCTest
import Security
import CryptoKit
import LeafHFTCore
@testable import LeafHFT

@MainActor final class AccountEnrollmentFlowTests: XCTestCase {
    private var storageKey: String {
        let identity = "scope\n11111111-1111-4111-8111-111111111111\n22222222-2222-4222-8222-222222222222"
        return "leafhft.enrollment.v2." + SHA256.hash(data: Data(identity.utf8))
            .map { String(format: "%02x", $0) }.joined()
    }

    func testExistingLiveLaneDoesNotEnrollOrReadKey() async throws {
        let live = try status("live")
        let flow = AccountEnrollmentFlow(readStatus: { live },
            readKey: { XCTFail("Live lanes must not read the enrollment key"); throw AccountEnrollmentError.invalidKey },
            submit: { _ in XCTFail("Live lanes must not enroll"); return live })
        // No valid private key is supplied: an existing live lane must not use one.
        let result = try await flow.enroll(keyID: "unused", privateDER: Data(), scope: "existing",
            isCurrent: { true }, progress: { _ in })
        XCTAssertEqual(result.automatedTrading, .live)
        XCTAssertFalse(result.needsEnrollment)
    }

    private func status(_ state: String, tenant: String = "11111111-1111-4111-8111-111111111111",
                        lane: String = "22222222-2222-4222-8222-222222222222") throws -> KashbotStatus {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return try decoder.decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: [
            "dashboard_pairing": "paired", "account_binding": "bound", "automated_trading": state,
            "tenant": ["id": tenant, "runner_host": "routing-only"], "lane": ["id": lane]]))
    }

    private func keys() throws -> (SecKey, Data, AccountEnrollmentKey) {
        let attributes: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
                                       kSecAttrKeySizeInBits as String: 2048]
        let privateKey = try XCTUnwrap(SecKeyCreateRandomKey(attributes as CFDictionary, nil))
        let privateDER = try XCTUnwrap(SecKeyCopyExternalRepresentation(privateKey, nil)) as Data
        let publicDER = try KalshiSigner(pkcs1DER: privateDER).publicKeyDER()
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .iso8601
        let runner = try decoder.decode(AccountEnrollmentKey.self, from: JSONSerialization.data(withJSONObject: [
            "enrollment_key_id": "runner-key", "public_key_der": publicDER.base64EncodedString(),
            "algorithm": "RSA-OAEP-256+A256GCM", "expires_at": "2099-01-01T00:00:00Z"]))
        return (privateKey, privateDER, runner)
    }

    func testHybridSealRoundTripAndScopeAuthentication() throws {
        let (runnerPrivate, credentialDER, runnerKey) = try keys()
        let requestID = UUID()
        let envelope = try AccountCredentialSealer.seal(keyID: "my-key", privateDER: credentialDER,
            runnerKey: runnerKey, tenantID: "11111111-1111-4111-8111-111111111111", laneID: "22222222-2222-4222-8222-222222222222")
        let wrapped = try XCTUnwrap(Data(base64Encoded: envelope.wrappedKey))
        let unwrapped = try XCTUnwrap(SecKeyCreateDecryptedData(runnerPrivate, .rsaEncryptionOAEPSHA256, wrapped as CFData, nil)) as Data
        XCTAssertEqual(unwrapped.count, 32)
        let combined = try XCTUnwrap(Data(base64Encoded: envelope.ciphertext))
        let box = try AES.GCM.SealedBox(nonce: AES.GCM.Nonce(data: XCTUnwrap(Data(base64Encoded: envelope.nonce))),
            ciphertext: combined.dropLast(16), tag: combined.suffix(16))
        let key = SymmetricKey(data: unwrapped)
        let plaintext = try AES.GCM.open(box, using: key,
            authenticating: AccountCredentialSealer.associatedData(tenantID: "11111111-1111-4111-8111-111111111111", laneID: "22222222-2222-4222-8222-222222222222"))
        let fields = try XCTUnwrap(JSONSerialization.jsonObject(with: plaintext) as? [String: String])
        XCTAssertEqual(fields["key_id"], "my-key")
        XCTAssertEqual(Set(fields.keys), ["key_id", "private_key_pem"])
        let pem = try XCTUnwrap(fields["private_key_pem"])
        let pemLabel = "RSA PRIVATE KEY"
        XCTAssertTrue(pem.hasPrefix("-----BEGIN " + pemLabel + "-----\n"))
        XCTAssertTrue(try decodeRSAPrivateKeyPEM(pem) == credentialDER)
        XCTAssertThrowsError(try AES.GCM.open(box, using: key,
            authenticating: AccountCredentialSealer.associatedData(tenantID: "33333333-3333-4333-8333-333333333333", laneID: "22222222-2222-4222-8222-222222222222")))
        XCTAssertThrowsError(try AES.GCM.open(box, using: key,
            authenticating: AccountCredentialSealer.associatedData(tenantID: "11111111-1111-4111-8111-111111111111", laneID: "33333333-3333-4333-8333-333333333333")))
        let wire = try JSONEncoder().encode(AccountEnrollmentRequest(clientRequestId: requestID, credential: envelope))
        let wireText = try XCTUnwrap(String(data: wire, encoding: .utf8))
        XCTAssertFalse(wireText.contains("my-key"))
        XCTAssertFalse(wireText.contains(credentialDER.base64EncodedString()))
    }

    func testCanonicalLaneAADMatchesRunnerBytes() throws {
        let tenant = "11111111-1111-4111-8111-111111111111"
        let lane = "22222222-2222-4222-8222-222222222222"
        let expected = #"{"lane_id":""# + lane + #"","subaccount":0,"tenant_id":""# +
            tenant + #"","venue":"kalshi","version":1}"#
        XCTAssertEqual(try AccountCredentialSealer.associatedData(tenantID: tenant, laneID: lane),
                       Data(expected.utf8))
        XCTAssertThrowsError(try AccountCredentialSealer.associatedData(tenantID: "invalid", laneID: lane))
        XCTAssertThrowsError(try AccountCredentialSealer.associatedData(tenantID: tenant, laneID: "invalid"))
    }

    func testMissingLaneStopsBeforeKeyRead() async throws {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        let missing = try decoder.decode(KashbotStatus.self, from: JSONSerialization.data(withJSONObject: [
            "dashboard_pairing": "paired", "account_binding": "bound", "automated_trading": "credential_required",
            "tenant": ["id": "11111111-1111-4111-8111-111111111111"]]))
        let flow = AccountEnrollmentFlow(readStatus: { missing },
            readKey: { XCTFail("Missing lane must stop setup"); throw AccountEnrollmentError.invalidKey },
            submit: { _ in XCTFail("Missing lane must stop setup"); return missing })
        do {
            _ = try await flow.enroll(keyID: "my-key", privateDER: Data(), scope: "scope",
                                      isCurrent: { true }, progress: { _ in })
            XCTFail("Expected scope rejection")
        } catch AccountEnrollmentError.scopeChanged { }
    }

    func testLaneChangesAreRejectedDuringReadback() async throws {
        var reads = 0
        let flow = AccountEnrollmentFlow(readStatus: {
            reads += 1
            return try self.status("ready", lane: reads == 1 ?
                "22222222-2222-4222-8222-222222222222" : "33333333-3333-4333-8333-333333333333")
        }, readKey: { throw AccountEnrollmentError.invalidKey },
            submit: { _ in throw AccountEnrollmentError.scopeChanged })
        do {
            _ = try await flow.enroll(keyID: "my-key", privateDER: Data(), scope: "scope",
                                      isCurrent: { true }, progress: { _ in })
            XCTFail("Expected scope rejection")
        } catch AccountEnrollmentError.scopeChanged { }
        XCTAssertEqual(reads, 2)
    }

    func testLostResponseReadsBackWithoutSecondSubmission() async throws {
        let (_, der, runnerKey) = try keys()
        let suite = "enrollment-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var submissions = 0
        var reads = 0
        let flow = AccountEnrollmentFlow(defaults: defaults, readStatus: {
            reads += 1
            return try self.status(submissions == 0 ? "credential_required" : "ready")
        }, readKey: { runnerKey }, submit: { _ in
            submissions += 1
            throw DashboardClientError.transport
        }, sleep: { _ in })
        let result = try await flow.enroll(keyID: "my-key", privateDER: der, scope: "scope",
            isCurrent: { true }, progress: { _ in })
        XCTAssertEqual(result.automatedTrading, .ready)
        XCTAssertEqual(submissions, 1)
        XCTAssertEqual(reads, 3)
        XCTAssertNil(defaults.object(forKey: storageKey))
    }

    func testExpiredRunnerKeyCannotSealCredential() throws {
        let (_, der, runnerKey) = try keys()
        XCTAssertThrowsError(try AccountCredentialSealer.seal(keyID: "my-key", privateDER: der,
            runnerKey: runnerKey, tenantID: "11111111-1111-4111-8111-111111111111", laneID: "33333333-3333-4333-8333-333333333333",
            now: try XCTUnwrap(runnerKey.expiresAt).addingTimeInterval(1)))
    }

    func testUnsupportedKeyContractIsRejected() throws {
        let (privateKey, der, _) = try keys()
        let publicKey = try XCTUnwrap(SecKeyCopyPublicKey(privateKey))
        let pkcs1 = try XCTUnwrap(SecKeyCopyExternalRepresentation(publicKey, nil)) as Data
        let spki = try KalshiSigner(pkcs1DER: der).publicKeyDER()
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        for (publicDER, algorithm) in [(pkcs1, "RSA-OAEP-256+A256GCM"),
                                       (spki, "RSA-OAEP-256"),
                                       (spki + Data([0]), "RSA-OAEP-256+A256GCM")] {
            let runnerKey = try decoder.decode(AccountEnrollmentKey.self,
                from: JSONSerialization.data(withJSONObject: [
                    "enrollment_key_id": "runner-key", "public_key_der": publicDER.base64EncodedString(),
                    "algorithm": algorithm]))
            XCTAssertThrowsError(try AccountCredentialSealer.seal(keyID: "my-key", privateDER: der,
                runnerKey: runnerKey, tenantID: "11111111-1111-4111-8111-111111111111",
                laneID: "22222222-2222-4222-8222-222222222222"))
        }
    }

    func testExpectedLaneIsCheckedBeforeKeyRead() async throws {
        let flow = AccountEnrollmentFlow(readStatus: { try self.status("credential_required") },
            readKey: { XCTFail("Changed lane must stop setup"); throw AccountEnrollmentError.invalidKey },
            submit: { _ in XCTFail("Changed lane must stop setup"); throw AccountEnrollmentError.scopeChanged })
        do {
            _ = try await flow.enroll(keyID: "my-key", privateDER: Data(), scope: "scope",
                expectedLaneID: "33333333-3333-4333-8333-333333333333",
                isCurrent: { true }, progress: { _ in })
            XCTFail("Expected scope rejection")
        } catch AccountEnrollmentError.scopeChanged { }
    }

    func testStatusFromAnotherTenantIsRejectedAfterSubmission() async throws {
        let (_, der, runnerKey) = try keys()
        let suite = "enrollment-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let flow = AccountEnrollmentFlow(defaults: defaults,
            readStatus: { try self.status("credential_required") }, readKey: { runnerKey },
            submit: { _ in try self.status("ready", tenant: "33333333-3333-4333-8333-333333333333") })
        do {
            _ = try await flow.enroll(keyID: "my-key", privateDER: der, scope: "scope",
                isCurrent: { true }, progress: { _ in })
            XCTFail("Expected scope rejection")
        } catch AccountEnrollmentError.scopeChanged { }
    }

    func testRetryAcrossFlowRecreationUsesExactEnvelopeAndStopsAtThree() async throws {
        let (_, der, runnerKey) = try keys()
        let suite = "enrollment-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var sent: [AccountEnrollmentRequest] = []
        var keyReads = 0
        for attempt in 0..<4 {
            let flow = AccountEnrollmentFlow(defaults: defaults,
                readStatus: { try self.status("credential_required") },
                readKey: { keyReads += 1; return runnerKey },
                submit: { sent.append($0); throw DashboardClientError.forbidden }, sleep: { _ in })
            do {
                _ = try await flow.enroll(keyID: "my-key", privateDER: der, scope: "scope",
                    isCurrent: { true }, progress: { _ in })
                XCTFail("Expected unconfirmed enrollment")
            } catch AccountEnrollmentError.retryLimit {
                XCTAssertEqual(attempt, 3)
            } catch {
                XCTAssertLessThan(attempt, 3)
                XCTAssertEqual(error as? DashboardClientError, .forbidden)
            }
        }
        XCTAssertEqual(sent.count, 3)
        XCTAssertEqual(keyReads, 1)
        XCTAssertEqual(sent.first, sent.last)
        let stored = defaults.dictionaryRepresentation().values.compactMap { $0 as? Data }
        XCTAssertFalse(stored.contains { String(data: $0, encoding: .utf8)?.contains(der.base64EncodedString()) == true })
    }

    func testTransportFailuresWithEnrollmentStillNeededRefundBudget() async throws {
        let (_, der, runnerKey) = try keys()
        let suite = "enrollment-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var sent: [AccountEnrollmentRequest] = []
        var keyReads = 0
        for _ in 0..<4 {
            let flow = AccountEnrollmentFlow(defaults: defaults,
                readStatus: { try self.status("credential_required") },
                readKey: { keyReads += 1; return runnerKey },
                submit: { sent.append($0); throw DashboardClientError.transport })
            do {
                _ = try await flow.enroll(keyID: "my-key", privateDER: der, scope: "scope",
                    isCurrent: { true }, progress: { _ in })
                XCTFail("Expected unconfirmed enrollment")
            } catch { XCTAssertEqual(error as? DashboardClientError, .transport) }
            let data = try XCTUnwrap(defaults.data(forKey: storageKey))
            let record = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
            XCTAssertEqual(record["submissions"] as? Int, 0)
        }
        XCTAssertEqual(sent.count, 4)
        XCTAssertEqual(keyReads, 1)
        XCTAssertTrue(sent.allSatisfy { $0 == sent.first })
    }

    private func checkRestoredRecord(firstAttemptAt: Date?, submissions: Int,
                                     expectsFresh: Bool) async throws {
        let (_, der, runnerKey) = try keys()
        let suite = "enrollment-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let currentTime = Date(timeIntervalSince1970: 1_800_000_000)
        let sealed = try AccountCredentialSealer.seal(keyID: "my-key", privateDER: der,
            runnerKey: runnerKey, tenantID: "11111111-1111-4111-8111-111111111111",
            laneID: "22222222-2222-4222-8222-222222222222")
        let original = AccountEnrollmentRequest(clientRequestId: UUID(), credential: sealed)
        var record: [String: Any] = [
            "request": try JSONSerialization.jsonObject(with: JSONEncoder().encode(original)),
            "submissions": submissions
        ]
        if let firstAttemptAt { record["firstAttemptAt"] = firstAttemptAt.timeIntervalSinceReferenceDate }
        defaults.set(try JSONSerialization.data(withJSONObject: record), forKey: storageKey)
        var sent: [AccountEnrollmentRequest] = []
        var keyReads = 0
        let flow = AccountEnrollmentFlow(defaults: defaults,
            readStatus: { try self.status("credential_required") },
            readKey: { keyReads += 1; return runnerKey },
            submit: { sent.append($0); throw DashboardClientError.forbidden }, now: { currentTime })
        do {
            _ = try await flow.enroll(keyID: "my-key", privateDER: der, scope: "scope",
                isCurrent: { true }, progress: { _ in })
            XCTFail("Expected unconfirmed enrollment")
        } catch { XCTAssertEqual(error as? DashboardClientError, .forbidden) }
        XCTAssertEqual(sent.count, 1)
        XCTAssertEqual(keyReads, expectsFresh ? 1 : 0)
        let request = try XCTUnwrap(sent.first)
        if expectsFresh {
            XCTAssertNotEqual(request.clientRequestId, original.clientRequestId)
            XCTAssertNotEqual(request.ciphertext, original.ciphertext)
        } else {
            XCTAssertEqual(request, original)
        }
        let storedData = try XCTUnwrap(defaults.data(forKey: storageKey))
        let stored = try XCTUnwrap(JSONSerialization.jsonObject(with: storedData) as? [String: Any])
        XCTAssertEqual(stored["submissions"] as? Int, expectsFresh ? 1 : submissions + 1)
        XCTAssertEqual(stored["firstAttemptAt"] as? Double,
            (expectsFresh ? currentTime : (firstAttemptAt ?? currentTime)).timeIntervalSinceReferenceDate)
    }

    func testExpiredEnrollmentRecordIsResealedWithNewRequestID() async throws {
        try await checkRestoredRecord(
            firstAttemptAt: Date(timeIntervalSince1970: 1_800_000_000 - 25 * 60 * 60),
            submissions: 1, expectsFresh: true)
    }

    func testLegacyEnrollmentRecordAtCapIsReplaced() async throws {
        try await checkRestoredRecord(firstAttemptAt: nil, submissions: 3, expectsFresh: true)
    }

    func testLegacyEnrollmentRecordBelowCapIsRetainedAndStamped() async throws {
        try await checkRestoredRecord(firstAttemptAt: nil, submissions: 2, expectsFresh: false)
    }

    func testEnrollmentRecordAtTwentyFourHoursIsStillRetained() async throws {
        try await checkRestoredRecord(
            firstAttemptAt: Date(timeIntervalSince1970: 1_800_000_000 - 24 * 60 * 60),
            submissions: 1, expectsFresh: false)
    }

    func testSuccessfulEnrollmentRemovesStoredEnvelope() async throws {
        let (_, der, runnerKey) = try keys()
        let suite = "enrollment-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var submissions = 0
        let flow = AccountEnrollmentFlow(defaults: defaults,
            readStatus: { try self.status(submissions == 0 ? "credential_required" : "ready") },
            readKey: { runnerKey }, submit: { _ in
                XCTAssertNotNil(defaults.data(forKey: self.storageKey))
                submissions += 1
                return try self.status("ready")
            })
        let result = try await flow.enroll(keyID: "my-key", privateDER: der, scope: "scope",
            isCurrent: { true }, progress: { _ in })
        XCTAssertFalse(result.needsEnrollment)
        XCTAssertEqual(submissions, 1)
        XCTAssertNil(defaults.object(forKey: storageKey))
    }

    func testExistingEnrollmentRemovesStoredEnvelopeBeforeFurtherReadback() async throws {
        let suite = "enrollment-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        defaults.set(Data("spent envelope".utf8), forKey: storageKey)
        var reads = 0
        let flow = AccountEnrollmentFlow(defaults: defaults, readStatus: {
            reads += 1
            if reads > 1 {
                XCTAssertNil(defaults.object(forKey: self.storageKey))
                throw DashboardClientError.transport
            }
            return try self.status("ready")
        }, readKey: {
            XCTFail("An existing enrollment must not read a key")
            throw AccountEnrollmentError.invalidKey
        }, submit: { _ in
            XCTFail("An existing enrollment must not submit")
            throw AccountEnrollmentError.scopeChanged
        })
        do {
            _ = try await flow.enroll(keyID: "unused", privateDER: Data(), scope: "scope",
                isCurrent: { true }, progress: { _ in })
            XCTFail("Expected readback failure")
        } catch { XCTAssertEqual(error as? DashboardClientError, .transport) }
        XCTAssertEqual(reads, 2)
        XCTAssertNil(defaults.object(forKey: storageKey))
    }

    func testNewLaneNeverReusesPriorLaneEnvelope() async throws {
        let (_, der, runnerKey) = try keys()
        let suite = "enrollment-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var sent: [AccountEnrollmentRequest] = []
        var keyReads = 0
        for lane in ["22222222-2222-4222-8222-222222222222", "33333333-3333-4333-8333-333333333333"] {
            let flow = AccountEnrollmentFlow(defaults: defaults,
                readStatus: { try self.status("credential_required", lane: lane) },
                readKey: { keyReads += 1; return runnerKey },
                submit: { sent.append($0); throw DashboardClientError.transport })
            do {
                _ = try await flow.enroll(keyID: "my-key", privateDER: der, scope: "scope",
                    isCurrent: { true }, progress: { _ in })
                XCTFail("Expected unconfirmed enrollment")
            } catch DashboardClientError.transport { }
        }
        XCTAssertEqual(keyReads, 2)
        XCTAssertEqual(sent.count, 2)
        XCTAssertNotEqual(sent.first?.clientRequestId, sent.last?.clientRequestId)
        XCTAssertNotEqual(sent.first?.ciphertext, sent.last?.ciphertext)
    }

    func testChangingCredentialScopeStopsBeforeSubmission() async throws {
        let (_, der, runnerKey) = try keys()
        var current = true
        var sent = false
        let flow = AccountEnrollmentFlow(readStatus: { try self.status("credential_required") },
            readKey: { current = false; return runnerKey }, submit: { _ in sent = true; return try self.status("ready") })
        do {
            _ = try await flow.enroll(keyID: "my-key", privateDER: der, scope: UUID().uuidString,
                isCurrent: { current }, progress: { _ in })
            XCTFail("Expected scope rejection")
        } catch { }
        XCTAssertFalse(sent)
    }

    func testExpectedTenantIsCheckedBeforeReadingEnrollmentKey() async throws {
        let flow = AccountEnrollmentFlow(
            readStatus: { try self.status("credential_required", tenant: "33333333-3333-4333-8333-333333333333") },
            readKey: { XCTFail("Must not read a key for a different tenant"); throw AccountEnrollmentError.scopeChanged },
            submit: { _ in XCTFail("Must not submit to a different tenant"); throw AccountEnrollmentError.scopeChanged })
        do {
            _ = try await flow.enroll(keyID: "my-key", privateDER: Data(), scope: "scope",
                expectedTenantID: "11111111-1111-4111-8111-111111111111", isCurrent: { true }, progress: { _ in })
            XCTFail("Expected scope rejection")
        } catch AccountEnrollmentError.scopeChanged { }
    }

    func testSuccessfulSubmissionUsesIndependentReadback() async throws {
        let (_, der, runnerKey) = try keys()
        let suite = "enrollment-test-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        var reads = 0
        var submissions = 0
        let flow = AccountEnrollmentFlow(defaults: defaults, readStatus: {
            reads += 1
            return try self.status(reads == 1 ? "credential_required" : "failed")
        }, readKey: { runnerKey }, submit: { _ in
            submissions += 1
            return try self.status("ready")
        })
        let result = try await flow.enroll(keyID: "my-key", privateDER: der, scope: "scope",
            expectedTenantID: "11111111-1111-4111-8111-111111111111", isCurrent: { true }, progress: { _ in })
        XCTAssertEqual(result.automatedTrading, .failed)
        XCTAssertEqual(reads, 2)
        XCTAssertEqual(submissions, 1)
    }

    func testExistingLaneStatesOnlyReadStatus() async throws {
        for value in ["provisioning", "dry_run", "ready", "live", "paused", "failed", "revoked"] {
            var reads = 0
            var waits = 0
            let flow = AccountEnrollmentFlow(readStatus: {
                reads += 1
                return try self.status(value)
            }, readKey: {
                XCTFail("An existing lane must not require another key")
                throw AccountEnrollmentError.invalidKey
            }, submit: { _ in
                XCTFail("An existing lane must not enroll again")
                throw AccountEnrollmentError.scopeChanged
            }, sleep: { _ in waits += 1 })
            let result = try await flow.enroll(keyID: "my-key", privateDER: Data(), scope: "scope",
                expectedTenantID: "11111111-1111-4111-8111-111111111111", isCurrent: { true }, progress: { _ in })
            XCTAssertEqual(result.automatedTrading.rawValue, value)
            XCTAssertEqual(reads, value == "provisioning" ? 7 : 2)
            XCTAssertEqual(waits, value == "provisioning" ? 6 : 0)
        }
    }
}
