import Foundation
import XCTest
@testable import LeafHFT
import LeafHFTCore

@MainActor final class PausedBookViewBindingTests: XCTestCase {
    private func decodeBook(_ shape: String, empty: Bool = false, withoutEval: Bool = false) throws -> Book {
        let payload = PausedBookPayload.dictionary(shape, changes: ["k_source": NSNull()],
                                                  empty: empty, withoutEval: withoutEval)
        let data = try JSONSerialization.data(withJSONObject: payload)
        return try accountJSONDecoder().decode(Book.self, from: data)
    }

    private func assertRow(_ row: [BoundedTable.Cell], ticker: String, side: String,
                           observations: String, edge: String, engine: String, closes: String,
                           file: StaticString = #filePath, line: UInt = #line) throws {
        XCTAssertEqual(row.count, 6, file: file, line: line)
        XCTAssertEqual(try XCTUnwrap(row.first).text, ticker, file: file, line: line)
        XCTAssertEqual(try XCTUnwrap(row.dropFirst().first).text, side, file: file, line: line)
        XCTAssertEqual(try XCTUnwrap(row.dropFirst(2).first).text, observations, file: file, line: line)
        XCTAssertEqual(try XCTUnwrap(row.dropFirst(3).first).text, edge, file: file, line: line)
        XCTAssertEqual(try XCTUnwrap(row.dropFirst(4).first).text, engine, file: file, line: line)
        XCTAssertEqual(try XCTUnwrap(row.dropFirst(5).first).text, closes, file: file, line: line)
    }

    private func assertCard(_ actual: BooksView.CardText, chip: String, tone: LeafTone,
                            closes: String, edge: String?,
                            file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertEqual(actual.chip, chip, file: file, line: line)
        XCTAssertEqual(actual.chipTone, tone, file: file, line: line)
        XCTAssertEqual(actual.closes, closes, file: file, line: line)
        XCTAssertEqual(actual.edge, edge, file: file, line: line)
    }

    private func assertDetail(_ actual: BooksView.DetailText, chip: String, tone: LeafTone,
                              closes: String, observations: String, depth: String,
                              edge: String?, side: String?, gate: String?,
                              file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertEqual(actual.chip, chip, file: file, line: line)
        XCTAssertEqual(actual.chipTone, tone, file: file, line: line)
        XCTAssertEqual(actual.closesIn, closes, file: file, line: line)
        XCTAssertEqual(actual.observations, observations, file: file, line: line)
        XCTAssertEqual(actual.depth, depth, file: file, line: line)
        XCTAssertEqual(actual.edge, edge, file: file, line: line)
        XCTAssertEqual(actual.side, side, file: file, line: line)
        XCTAssertEqual(actual.gate, gate, file: file, line: line)
    }

    func testOpenNowRowsBindPresentation() throws {
        let p = try decodeBook("P")
        let p2 = try decodeBook("P2")
        let e = try decodeBook("E")
        let r = try decodeBook("R")
        let u = try decodeBook("U")
        let rows = OpenNowCard.bookRows(books: [u, r, e, p], engines: [])
        XCTAssertEqual(rows.count, 4)
        try assertRow(XCTUnwrap(rows.first), ticker: "KXBTC15M-26SEP271915-15",
                      side: "Book paused", observations: "Book paused", edge: "Book paused",
                      engine: "Not reported", closes: "Book paused")
        try assertRow(XCTUnwrap(rows.dropFirst().first), ticker: "KXBTC15M-26SEP271915-15",
                      side: "Entries off", observations: "Entries off", edge: "Entries off",
                      engine: "Not reported", closes: "Entries off")
        let reportedRow = try XCTUnwrap(rows.dropFirst(2).first)
        try assertRow(reportedRow, ticker: "KXBTC15M-26SEP271915-15",
                      side: "YES", observations: "4 of 5", edge: "1.5¢ / 2.0¢",
                      engine: "Not reported", closes: "1:00")
        XCTAssertEqual(try XCTUnwrap(reportedRow.dropFirst(3).first).tone, .loss)
        let unreportedRow = try XCTUnwrap(rows.dropFirst(3).first)
        try assertRow(unreportedRow, ticker: "KXBTC15M-26SEP271915-15",
                      side: "Not reported", observations: "? of 5", edge: "Not reported / Not reported",
                      engine: "Not reported", closes: "Not reported")
        XCTAssertEqual(try XCTUnwrap(unreportedRow.dropFirst(3).first).tone, .stale)
        XCTAssertTrue(OpenNowCard.bookRows(books: [try decodeBook("P", withoutEval: true)], engines: []).isEmpty)
        XCTAssertEqual(OpenNowCard.nextCloseText(books: [p]), "Book paused")
        XCTAssertEqual(OpenNowCard.nextCloseText(books: [p, p2]), "All books paused")
        XCTAssertEqual(OpenNowCard.nextCloseText(books: [p, e]), "Entries off")
        XCTAssertEqual(OpenNowCard.nextCloseText(books: [p, u]), "Not reported")
        XCTAssertEqual(OpenNowCard.nextCloseText(books: [p, r]), "1:00")
    }

    func testBookCardBindsPresentation() throws {
        assertCard(BooksView.cardText(book: try decodeBook("P")),
                   chip: "Book paused", tone: .warn, closes: "Book paused", edge: "Book paused")
        assertCard(BooksView.cardText(book: try decodeBook("E")),
                   chip: "Entries off", tone: .stale, closes: "Entries off", edge: "Entries off")
        assertCard(BooksView.cardText(book: try decodeBook("I")),
                   chip: "Intent emitted", tone: .gain, closes: "Book paused", edge: "Book paused")
        assertCard(BooksView.cardText(book: try decodeBook("R")),
                   chip: "Edge 0.5¢ below requirement", tone: .loss, closes: "1:00", edge: "1.5¢ / 2.0¢")
        assertCard(BooksView.cardText(book: try decodeBook("Q")),
                   chip: "No Quote", tone: .stale, closes: "Unknown", edge: "Unknown / Unknown")
        assertCard(BooksView.cardText(book: try decodeBook("P", withoutEval: true)),
                   chip: "Waiting for telemetry", tone: .stale, closes: "Unknown", edge: nil)
    }

    func testBookDetailBindsPresentation() throws {
        assertDetail(BooksView.detailText(book: try decodeBook("P")),
                     chip: "Book paused", tone: .warn, closes: "Book paused",
                     observations: "Book paused", depth: "Book paused", edge: "Book paused",
                     side: "Book paused", gate: "Book paused")
        assertDetail(BooksView.detailText(book: try decodeBook("E")),
                     chip: "Entries off", tone: .stale, closes: "Entries off",
                     observations: "Entries off", depth: "Entries off", edge: "Entries off",
                     side: "Entries off", gate: "Entries off")
        assertDetail(BooksView.detailText(book: try decodeBook("R")),
                     chip: "Edge 0.5¢ below requirement", tone: .loss, closes: "1:00",
                     observations: "4 of 5", depth: "40", edge: "+1.5¢ / 2.0¢ required",
                     side: "Yes · favorite", gate: "Edge Below Bar")
        assertDetail(BooksView.detailText(book: try decodeBook("PR")),
                     chip: "Book paused", tone: .warn, closes: "1:00",
                     observations: "Book paused", depth: "Book paused", edge: "Book paused",
                     side: "Yes", gate: "Book paused")
        assertDetail(BooksView.detailText(book: try decodeBook("Q")),
                     chip: "No Quote", tone: .stale, closes: "Unknown",
                     observations: "? of 5", depth: "Unknown", edge: "Unknown / Unknown required",
                     side: "Side unknown", gate: "No Quote")
        let emitted = BooksView.detailText(book: try decodeBook("I"))
        XCTAssertEqual(emitted.chip, "Intent emitted")
        XCTAssertEqual(emitted.chipTone, .gain)
        XCTAssertEqual(emitted.gate, "Book paused")
        assertDetail(BooksView.detailText(book: try decodeBook("P", empty: true)),
                     chip: "Waiting for telemetry", tone: .stale, closes: "Unknown",
                     observations: "? of 5", depth: "Unknown", edge: nil, side: nil, gate: nil)
    }

    func testFixtureBooksKeepTodaysText() throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "books", withExtension: "json", subdirectory: "Fixtures"))
        let books = try accountJSONDecoder().decode(MobileBooks.self, from: Data(contentsOf: url)).books
        XCTAssertEqual(books.count, 14)
        for book in books {
            XCTAssertNil(MonitorPresentation.entryHold(book: book), book.bookId)
        }
        let fixture = try XCTUnwrap(books.first { $0.bookId == "fixture-book" })
        assertCard(BooksView.cardText(book: fixture),
                   chip: "Edge 1.0¢ below requirement", tone: .loss, closes: "1:00", edge: "1.0¢ / 2.0¢")
        assertDetail(BooksView.detailText(book: fixture),
                     chip: "Edge 1.0¢ below requirement", tone: .loss, closes: "1:00",
                     observations: "12 of 10", depth: "20", edge: "+1.0¢ / 2.0¢ required",
                     side: "Yes", gate: "Edge Below Bar")
        let rows = OpenNowCard.bookRows(books: books, engines: [])
        try assertRow(XCTUnwrap(rows.first), ticker: "FIXTURE-T", side: "YES", observations: "12 of 10",
                      edge: "1.0¢ / 2.0¢", engine: "Not reported", closes: "1:00")
        XCTAssertEqual(OpenNowCard.nextCloseText(books: books), "1:00")
    }
}
