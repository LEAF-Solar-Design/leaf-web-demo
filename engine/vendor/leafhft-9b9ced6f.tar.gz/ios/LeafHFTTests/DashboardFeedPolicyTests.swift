import Foundation
import XCTest
@testable import LeafHFT

final class DashboardFeedPolicyTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)
    private let always: Set<DashboardFeed> = [.status, .engines]

    private func fetched(secondsAgo: TimeInterval) -> [DashboardFeed: Date] {
        Dictionary(uniqueKeysWithValues: DashboardFeed.allCases.map { ($0, now.addingTimeInterval(-secondsAgo)) })
    }

    func testMonitorColdStartSplitsVisibleAndOffscreenFeeds() {
        XCTAssertEqual(DashboardFeedPolicy.visibleWave(visibleTab: .account, lastFetched: [:], now: now),
                       always.union([.probes, .activity, .accountHistory, .exits, .calibration]))
        XCTAssertEqual(DashboardFeedPolicy.offscreenWave(visibleTab: .account, lastFetched: [:], now: now),
                       [.books, .engineLab])
    }

    func testBooksTickLeavesRecentOffscreenFeedsAlone() {
        XCTAssertEqual(DashboardFeedPolicy.due(visibleTab: .books, lastFetched: fetched(secondsAgo: 31), now: now),
                       always.union([.books]))
    }

    func testBooksTickReloadsOldOffscreenFeeds() {
        let times = fetched(secondsAgo: 121)
        XCTAssertEqual(DashboardFeedPolicy.due(visibleTab: .books, lastFetched: times, now: now),
                       Set(DashboardFeed.allCases))
        XCTAssertEqual(DashboardFeedPolicy.visibleWave(visibleTab: .books, lastFetched: times, now: now),
                       always.union([.books]))
        XCTAssertEqual(DashboardFeedPolicy.offscreenWave(visibleTab: .books, lastFetched: times, now: now),
                       Set(DashboardFeed.allCases).subtracting(always.union([.books])))
    }

    func testSettingsTickAlwaysRefreshesSharedFeeds() {
        XCTAssertEqual(DashboardFeedPolicy.due(visibleTab: .settings, lastFetched: fetched(secondsAgo: 5), now: now),
                       always)
    }

    func testLabSwitchOnlyRefreshesStaleOrMissingLab() {
        var times = fetched(secondsAgo: 5)
        times[.engineLab] = now.addingTimeInterval(-10)
        XCTAssertEqual(DashboardFeedPolicy.dueOnTabSwitch(to: .lab, lastFetched: times, now: now), [])
        times[.engineLab] = now.addingTimeInterval(-45)
        XCTAssertEqual(DashboardFeedPolicy.dueOnTabSwitch(to: .lab, lastFetched: times, now: now), [.engineLab])
        times[.engineLab] = nil
        XCTAssertEqual(DashboardFeedPolicy.dueOnTabSwitch(to: .lab, lastFetched: times, now: now), [.engineLab])
    }

    func testEnginesReadsProbesActivityAndLab() {
        XCTAssertEqual(DashboardFeedPolicy.visibleWave(visibleTab: .engines, lastFetched: [:], now: now),
                       always.union([.probes, .activity, .engineLab]))
    }

    func testEveryFeedHasAReader() {
        let tabs: [KashbotTab] = [.account, .books, .engines, .lab, .settings]
        for feed in DashboardFeed.allCases {
            XCTAssertTrue(DashboardFeedPolicy.alwaysFeeds.contains(feed) ||
                          tabs.contains { DashboardFeedPolicy.feedsRead(by: $0).contains(feed) })
        }
    }

    func testOffscreenIntervalIncludesExactlyOneHundredTwentySeconds() {
        XCTAssertEqual(DashboardFeedPolicy.due(visibleTab: .settings, lastFetched: fetched(secondsAgo: 119), now: now),
                       always)
        XCTAssertEqual(DashboardFeedPolicy.due(visibleTab: .settings, lastFetched: fetched(secondsAgo: 120), now: now),
                       Set(DashboardFeed.allCases))
    }

    func testTabSwitchIntervalIncludesExactlyThirtySecondsForAlwaysFeeds() {
        XCTAssertEqual(DashboardFeedPolicy.dueOnTabSwitch(to: .settings, lastFetched: fetched(secondsAgo: 29), now: now), [])
        XCTAssertEqual(DashboardFeedPolicy.dueOnTabSwitch(to: .settings, lastFetched: fetched(secondsAgo: 30), now: now), always)
    }
}
