import XCTest
@testable import LeafHFT

final class AssistantConversationTests: XCTestCase {
    @MainActor func testPendingReplyHasNoDeviceTimeAndReloadUsesServerTime() async throws {
        let mode = FixtureMode(arguments: [])
        let deviceTime = Date(timeIntervalSince1970: 1_800_000_000)
        let serverTime = deviceTime.addingTimeInterval(120)
        let iso = ISO8601DateFormatter()
        let suite = "assistant-server-time-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite); MushyStub.handler = nil }
        var snapshot = MushyClient.fixtureSnapshot
        snapshot.jobs = []
        snapshot.sessions[0].messages = []
        let encoder = MushyCoding.encoder()
        MushyStub.handler = { request in
            switch request.url?.lastPathComponent {
            case "engines": return (200, try encoder.encode(MushyClient.fixtureCatalog))
            case "state": return (200, try encoder.encode(snapshot))
            default: XCTFail("Unexpected history request"); return (404, Data())
            }
        }
        let historyClient = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: { "test-device" })
        let studio = MushyState(fixtureMode: mode, client: historyClient, defaults: defaults)
        await studio.refresh()
        // Stop before transport so the queued reply can be inspected without a device timestamp.
        let sendClient = MushyClient(fixtureMode: mode, token: { throw MushyClientError.authentication })
        let conversation = AssistantConversation(fixtureMode: mode, client: sendClient, kitRoutes: false)
        await conversation.send("Question", studio: studio, now: deviceTime)
        XCTAssertEqual(conversation.items.count, 2)
        let userId = try XCTUnwrap(conversation.items.first?.id)
        let replyId = try XCTUnwrap(conversation.items.last?.id)
        XCTAssertEqual(conversation.messageDates[userId], deviceTime)
        XCTAssertNil(conversation.messageDates[replyId])
        XCTAssertNotEqual(conversation.messageDates[replyId], deviceTime)
        XCTAssertEqual(conversation.activeReply?.stage, "queued")
        XCTAssertEqual(conversation.activeReply?.finished, false)
        conversation.apply(.init(seq: 1, type: "done", payload: .done(text: "Answer")))
        XCTAssertNil(conversation.messageDates[replyId], "Completion without a server timestamp must stay undated")
        XCTAssertEqual(conversation.activeReply?.finished, true)
        XCTAssertNotEqual(conversation.messageDates[replyId], deviceTime)
        snapshot.sessions[0].messages = [
            .init(role: "user", content: "Question", jobId: MushyClient.fixtureArtifactId,
                  createdAt: iso.string(from: serverTime.addingTimeInterval(-10))),
            .init(role: "assistant", content: "Answer", jobId: MushyClient.fixtureArtifactId,
                  createdAt: iso.string(from: serverTime))
        ]
        await studio.refresh()
        for _ in 0..<2 {
            conversation.load(from: studio)
            let loadedUserId = try XCTUnwrap(conversation.items.first?.id)
            let loadedReplyId = try XCTUnwrap(conversation.items.last?.id)
            XCTAssertEqual(conversation.messageDates[loadedUserId], serverTime.addingTimeInterval(-10))
            XCTAssertEqual(conversation.messageDates[loadedReplyId], serverTime)
            XCTAssertNotEqual(conversation.messageDates[loadedReplyId], deviceTime)
        }
    }

    func testMessageTimesUseTheirDateAndDeviceCalendar() throws {
        let locale = Locale(identifier: "en_GB")
        let zone = try XCTUnwrap(TimeZone(secondsFromGMT: 2 * 3_600))
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = zone
        let now = try XCTUnwrap(calendar.date(from: DateComponents(year: 2026, month: 9, day: 30, hour: 0, minute: 30)))
        func time(_ date: Date?) -> String? {
            AssistantFormat.messageTime(date, now: now, locale: locale, timeZone: zone, calendar: calendar)
        }
        XCTAssertEqual(time(now), "00:30")
        let yesterday = try XCTUnwrap(calendar.date(from: DateComponents(year: 2026, month: 9, day: 29, hour: 12, minute: 35)))
        XCTAssertEqual(time(yesterday), "Yesterday 12:35")
        let older = try XCTUnwrap(calendar.date(from: DateComponents(year: 2026, month: 9, day: 28, hour: 12, minute: 35)))
        let day = DateFormatter()
        day.locale = locale
        day.calendar = calendar
        day.timeZone = zone
        day.setLocalizedDateFormatFromTemplate("MMMd")
        XCTAssertEqual(time(older), day.string(from: older) + ", 12:35")
        XCTAssertNil(time(nil))
    }

    @MainActor func testOpeningUsesNewestMessageAndKeepsOldConversation() async throws {
        defer { MushyStub.handler = nil }
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        let iso = ISO8601DateFormatter()
        for hours in [7, 5, 6] {
            let mode = FixtureMode(arguments: [])
            let suite = "assistant-open-" + UUID().uuidString
            let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
            defer { defaults.removePersistentDomain(forName: suite) }
            let encoder = MushyCoding.encoder()
            var snapshot = MushyClient.fixtureSnapshot
            snapshot.jobs = []
            snapshot.sessions[0].messages = [
                .init(role: "assistant", content: "Older answer", jobId: MushyClient.fixtureArtifactId,
                      createdAt: iso.string(from: now.addingTimeInterval(-8 * 3_600))),
                .init(role: "user", content: "Newest question", jobId: MushyClient.fixtureArtifactId,
                      createdAt: iso.string(from: now.addingTimeInterval(-Double(hours) * 3_600)))
            ]
            let oldSession = snapshot.sessions[0]
            snapshot.selections.sessionId = oldSession.id
            let newSession = MushySession(id: UUID().uuidString.lowercased(), createdAt: iso.string(from: now),
                                         updatedAt: iso.string(from: now), messages: [])
            var creates = 0
            MushyStub.handler = { request in
                switch request.url?.lastPathComponent {
                case "engines": return (200, try encoder.encode(MushyClient.fixtureCatalog))
                case "state": return (200, try encoder.encode(snapshot))
                case "session":
                    XCTAssertEqual(request.httpMethod, "POST")
                    creates += 1
                    snapshot.sessions.append(newSession)
                    return (200, try encoder.encode(MushySessionReceipt(sessionId: newSession.id, session: newSession)))
                default: XCTFail("Unexpected opening request"); return (404, Data())
                }
            }
            let client = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: { "test-device" })
            let studio = MushyState(fixtureMode: mode, client: client, defaults: defaults)
            await studio.refresh()
            let conversation = AssistantConversation(fixtureMode: mode, client: client)
            conversation.draft = "Kept question"
            await conversation.open(studio: studio, now: now)
            XCTAssertEqual(creates, hours > 6 ? 1 : 0)
            XCTAssertEqual(studio.selections.sessionId, hours > 6 ? newSession.id : oldSession.id)
            XCTAssertEqual(studio.snapshot.sessions.first(where: { $0.id == oldSession.id })?.messages.map(\.content),
                           oldSession.messages.map(\.content))
            XCTAssertEqual(conversation.items.count, hours > 6 ? 0 : 2)
            XCTAssertEqual(conversation.messageDates.count, hours > 6 ? 0 : 2)
            if hours <= 6 {
                XCTAssertEqual(conversation.messageDates[conversation.items[1].id],
                               now.addingTimeInterval(-Double(hours) * 3_600))
            }
            XCTAssertEqual(conversation.draft, "Kept question")
            XCTAssertFalse(conversation.restoredDraft)
        }
    }

    @MainActor func testStarterFillsOrOffersDraftWithoutSending() async throws {
        defer { MushyStub.handler = nil }
        var requests = 0
        MushyStub.handler = { _ in
            requests += 1
            XCTFail("Starter selection reached the network")
            return (500, Data())
        }
        let mode = FixtureMode(arguments: [])
        let client = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: { "test-device" })
        let conversation = AssistantConversation(fixtureMode: mode, client: client)
        conversation.selectStarter("How much did I make today?")
        XCTAssertEqual(conversation.draft, "How much did I make today?")
        XCTAssertNil(conversation.offeredPrefill)
        XCTAssertFalse(conversation.restoredDraft)
        conversation.selectStarter("Show my account value this week")
        XCTAssertEqual(conversation.draft, "How much did I make today?")
        XCTAssertEqual(conversation.offeredPrefill, "Show my account value this week")
        conversation.acceptPrefill()
        XCTAssertEqual(conversation.draft, "Show my account value this week")
        await Task.yield()
        XCTAssertEqual(requests, 0)
        XCTAssertTrue(conversation.items.isEmpty)
        XCTAssertNil(conversation.activeJobId)
        XCTAssertFalse(conversation.sending)
    }

    @MainActor func testRestoredDraftIsLabelledUntilEditedOrCleared() async throws {
        let mode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])
        let suite = "assistant-draft-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let studio = MushyState(fixtureMode: mode, defaults: defaults)
        let conversation = AssistantConversation(fixtureMode: mode)
        conversation.offerPrefill("Initial suggestion")
        await conversation.open(studio: studio)
        XCTAssertFalse(conversation.restoredDraft)
        XCTAssertEqual(conversation.draft, "Initial suggestion")
        conversation.draft = "Fresh question\nSecond line"
        XCTAssertFalse(conversation.restoredDraft)
        await conversation.open(studio: studio)
        XCTAssertTrue(conversation.restoredDraft)
        XCTAssertEqual(conversation.draft, "Fresh question\nSecond line")
        conversation.draft += " edited"
        XCTAssertFalse(conversation.restoredDraft)
        await conversation.open(studio: studio)
        XCTAssertTrue(conversation.restoredDraft)
        conversation.clearDraft()
        XCTAssertEqual(conversation.draft, "")
        XCTAssertFalse(conversation.restoredDraft)
        await conversation.open(studio: studio)
        XCTAssertFalse(conversation.restoredDraft)
    }

    private func cardObject(state: String = "open", kind: String = "slot_promotion", id: String = "card-home") -> [String: Any] {
        ["card_id": id, "card_digest": String(repeating: "a", count: 64), "kind": kind,
         "title": kind == "config_draft" ? "Change a setting" : "Save view to slot home",
         "fields": kind == "config_draft"
            ? [["key": "shadow.enabled", "label": "Shadow enabled", "value": "true"]]
            : [["key": "slot", "label": "Slot", "value": "home"]],
         "state": state, "expires_at": "2026-09-28T21:00:00.000Z"]
    }

    private func cardsData(_ cards: [[String: Any]]) throws -> Data {
        try JSONSerialization.data(withJSONObject: ["schema": "kashbot.assistant.cards.v1", "cards": cards])
    }

    func testMixedCardPagePreservesServerTitleAndFields() throws {
        let page = try MushyCoding.decoder().decode(AssistantCardsPage.self, from: cardsData([
            cardObject(), cardObject(kind: "config_draft", id: "card-shadow"),
            cardObject(kind: "future", id: "card-future")
        ]))
        XCTAssertEqual(page.cards.map(\.id), ["card-home", "card-shadow"])
        XCTAssertEqual(page.cards.map(\.kind), [.slotPromotion, .configDraft])
        XCTAssertEqual(page.cards[0].title, "Save view to slot home")
        XCTAssertEqual(page.cards[1].title, "Change a setting")
        XCTAssertEqual(page.cards[1].fields.first?.key, "shadow.enabled")
        XCTAssertEqual(page.cards[1].fields.first?.label, "Shadow enabled")
        XCTAssertEqual(page.cards[1].fields.first?.value, "true")
    }

    func testCardActionAndStateWordingByKind() throws {
        for (kind, labels, identifier) in [
            ("slot_promotion", ["Save", "Saved", "Could not save", "Expired"], "assistant.card.save"),
            ("config_draft", ["Approve", "Approved", "Could not apply", "Expired"], "assistant.card.approve")
        ] {
            for (state, label) in zip(["open", "approved", "failed", "expired"], labels) {
                let card = try MushyCoding.decoder().decode(AssistantCard.self,
                    from: JSONSerialization.data(withJSONObject: cardObject(state: state, kind: kind)))
                XCTAssertEqual(card.stateLabel, label)
                XCTAssertEqual(card.kind.actionAccessibilityIdentifier, identifier)
            }
        }
    }

    func testCardPagesFailClosedAndBoundDisplay() throws {
        let decoder = MushyCoding.decoder()
        let unknowns = try cardsData([cardObject(kind: "future"), cardObject(state: "future"), cardObject()])
        XCTAssertEqual(try decoder.decode(AssistantCardsPage.self, from: unknowns).cards.map(\.id), ["card-home"])
        let many = try cardsData((0..<12).map { cardObject(id: "card-\($0)") })
        XCTAssertEqual(try decoder.decode(AssistantCardsPage.self, from: many).cards.count, 10)
        var long = cardObject()
        long["title"] = String(repeating: "t", count: 200)
        long["fields"] = [["key": "slot", "label": String(repeating: "l", count: 100),
                           "value": String(repeating: "v", count: 600)]]
        let card = try XCTUnwrap(decoder.decode(AssistantCardsPage.self, from: cardsData([long])).cards.first)
        XCTAssertEqual(card.title.count, 161)
        XCTAssertEqual(card.fields.first?.label.count, 81)
        XCTAssertEqual(card.fields.first?.value.count, 501)
        XCTAssertTrue(card.title.hasSuffix("…"))
        XCTAssertTrue(card.fields.first?.label.hasSuffix("…") == true)
        XCTAssertTrue(card.fields.first?.value.hasSuffix("…") == true)
        let malformedPages: [[String: Any]] = [[:], ["schema": "other", "cards": []],
            ["schema": "kashbot.assistant.cards.v1", "cards": "bad"]]
        for object in malformedPages {
            XCTAssertThrowsError(try decoder.decode(AssistantCardsPage.self, from: JSONSerialization.data(withJSONObject: object)))
        }
        for key in ["card_id", "card_digest", "title", "fields", "expires_at"] {
            var malformed = cardObject()
            malformed.removeValue(forKey: key)
            XCTAssertThrowsError(try decoder.decode(AssistantCardsPage.self, from: cardsData([malformed])))
        }
        var badDigest = cardObject()
        badDigest["card_digest"] = "invalid"
        XCTAssertThrowsError(try decoder.decode(AssistantCardsPage.self, from: cardsData([badDigest])))
    }

    @MainActor func testCardsFetchAndApprovalOnBothEventPaths() async throws {
        defer { MushyStub.handler = nil }
        for (kind, kit) in [
            ("slot_promotion", false), ("slot_promotion", true),
            ("config_draft", false), ("config_draft", true)
        ] {
            for outcome in [200, 409, 410, 503, -1] {
                let mode = FixtureMode(arguments: [])
                let suite = "cards-flow-" + UUID().uuidString
                let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
                defer { defaults.removePersistentDomain(forName: suite) }
                let encoder = MushyCoding.encoder()
                let turnId = MushyClient.fixtureArtifactId
                var snapshot = MushyClient.fixtureSnapshot
                snapshot.jobs = []
                var fetches = 0
                var approvalBodies: [[String: String]] = []
                let root = "/api/kashbot/assistant/v1"
                MushyStub.handler = { request in
                    let path = request.url!.path
                    switch request.url?.lastPathComponent {
                    case "engines": return (200, try encoder.encode(MushyClient.fixtureCatalog))
                    case "state": return (200, try encoder.encode(snapshot))
                    case "turn": return (200, try encoder.encode(AssistantTurnReceipt(jobId: turnId, status: "pending")))
                    case "turns":
                        return (202, try JSONSerialization.data(withJSONObject: ["type": "turn", "seq": 1,
                            "session_id": MushyClient.fixtureSessionId, "turn_id": turnId, "state": "queued",
                            "at": "2026-09-28T20:00:00.000Z", "requires_action": false]))
                    case "events":
                        if kit {
                            return (200, try JSONSerialization.data(withJSONObject: ["next_after": 3, "events": [
                                ["type": "item", "seq": 2, "session_id": MushyClient.fixtureSessionId,
                                 "at": "2026-09-28T20:00:00.000Z", "requires_action": false,
                                 "item": ["seq": 2, "item_id": turnId + ":answer", "turn_id": turnId,
                                          "role": "assistant", "at": "2026-09-28T20:00:00.000Z",
                                          "blocks": [["type": "text", "text": "Ready"]]]],
                                ["type": "turn", "seq": 3, "session_id": MushyClient.fixtureSessionId,
                                 "turn_id": turnId, "state": "done", "at": "2026-09-28T20:00:00.000Z",
                                 "requires_action": false]
                            ]]))
                        }
                        // A done event is terminal even before the legacy page status catches up.
                        return (200, try JSONSerialization.data(withJSONObject: ["job_id": turnId,
                            "status": "running", "next": 1,
                            "events": [["seq": 1, "type": "done", "payload": ["text": "Ready"]]]]))
                    case "cards":
                        XCTAssertEqual(path, root + "/turns/" + turnId + "/cards")
                        XCTAssertEqual(request.httpMethod, "GET")
                        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-device")
                        fetches += 1
                        if outcome == 503 { return (503, Data()) }
                        let state = fetches == 1 ? "open" : (outcome == 410 ? "expired" : "approved")
                        return (200, try self.cardsData([
                            self.cardObject(state: state, kind: kind),
                            self.cardObject(kind: kind == "config_draft" ? "slot_promotion" : "config_draft", id: "card-other"),
                            self.cardObject(kind: "future", id: "card-future")
                        ]))
                    case "approve":
                        XCTAssertEqual(path, root + "/cards/card-home/approve")
                        XCTAssertEqual(request.httpMethod, "POST")
                        approvalBodies.append(try XCTUnwrap(JSONSerialization.jsonObject(with: MushyStub.body(request)) as? [String: String]))
                        if outcome == -1 && approvalBodies.count == 1 { throw URLError(.networkConnectionLost) }
                        return (outcome == -1 ? 200 : outcome, Data())
                    default: XCTFail("Unexpected cards request"); return (404, Data())
                    }
                }
                let client = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: { "test-device" })
                let studio = MushyState(fixtureMode: mode, client: client, defaults: defaults)
                await studio.refresh()
                let conversation = AssistantConversation(fixtureMode: mode, client: client, kitRoutes: kit)
                let deviceTime = Date(timeIntervalSince1970: 1_800_000_000)
                await conversation.send("Save this view", studio: studio, now: deviceTime)
                let userId = try XCTUnwrap(conversation.items.first?.id)
                let replyId = try XCTUnwrap(conversation.items.last?.id)
                XCTAssertEqual(conversation.messageDates[userId], deviceTime)
                XCTAssertEqual(conversation.activeReply?.finished, true)
                XCTAssertNil(conversation.messageDates[replyId], "Both event paths stay undated until history is loaded")
                XCTAssertNotEqual(conversation.messageDates[replyId], deviceTime)
                XCTAssertEqual(fetches, 1)
                XCTAssertEqual(conversation.activeReply?.text, "Ready")
                XCTAssertNil(conversation.activeReply?.failed)
                XCTAssertTrue(approvalBodies.isEmpty)
                if outcome == 503 {
                    XCTAssertEqual(conversation.activeReply?.cards.count, 0)
                    continue
                }
                let card = try XCTUnwrap(conversation.activeReply?.cards.first)
                XCTAssertEqual(conversation.activeReply?.cards.map(\.id), ["card-home", "card-other"])
                XCTAssertEqual(card.kind.rawValue, kind)
                XCTAssertEqual(card.state, .open)
                await conversation.approve(card: card)
                if outcome == -1 {
                    XCTAssertEqual(conversation.activeReply?.cards.first?.state, .open)
                    await conversation.approve(card: card)
                    XCTAssertEqual(approvalBodies.count, 2)
                    XCTAssertEqual(approvalBodies[0], approvalBodies[1])
                }
                let body = try XCTUnwrap(approvalBodies.first)
                XCTAssertEqual(Set(body.keys), ["card_digest", "request_id"])
                XCTAssertEqual(body["card_digest"], card.cardDigest)
                let requestId = try XCTUnwrap(body["request_id"])
                XCTAssertNotNil(UUID(uuidString: requestId))
                XCTAssertEqual(requestId, requestId.lowercased())
                XCTAssertEqual(fetches, outcome == 409 || outcome == 410 ? 2 : 1)
                XCTAssertEqual(conversation.activeReply?.cards.first?.state, outcome == 410 ? .expired : .approved)
                let count = approvalBodies.count
                await conversation.approve(card: card)
                XCTAssertEqual(approvalBodies.count, count)
            }
        }
    }

    @MainActor func testCardApprovalUsesFreshIdsAfterCompletedRequests() async throws {
        defer { MushyStub.handler = nil }
        var ids: [String] = []
        MushyStub.handler = { request in
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: MushyStub.body(request)) as? [String: String])
            ids.append(try XCTUnwrap(body["request_id"]))
            return (200, Data())
        }
        let client = MushyClient(fixtureMode: FixtureMode(arguments: []), protocolClasses: [MushyStub.self], token: { "test-device" })
        let identity = try client.identity()
        for _ in 0..<2 {
            try await client.approveCard(cardId: "card-home", cardDigest: String(repeating: "a", count: 64), identity: identity)
        }
        XCTAssertEqual(ids.count, 2)
        XCTAssertEqual(Set(ids).count, 2)
    }

    @MainActor func testCardApprovalKeepsIdAcrossRetryableFailures() async throws {
        defer { MushyStub.handler = nil }
        var ids: [String] = []
        var statuses = [503, 429, 200]
        MushyStub.handler = { request in
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: MushyStub.body(request)) as? [String: String])
            ids.append(try XCTUnwrap(body["request_id"]))
            return (statuses.removeFirst(), Data())
        }
        let client = MushyClient(fixtureMode: FixtureMode(arguments: []), protocolClasses: [MushyStub.self], token: { "test-device" })
        let identity = try client.identity()
        let digest = String(repeating: "b", count: 64)
        for _ in 0..<2 {
            do { try await client.approveCard(cardId: "card-home", cardDigest: digest, identity: identity); XCTFail("retryable status succeeded") }
            catch {}
        }
        try await client.approveCard(cardId: "card-home", cardDigest: digest, identity: identity)
        XCTAssertEqual(ids.count, 3)
        XCTAssertEqual(Set(ids).count, 1, "503 and 429 must keep the request id for the next tap")
    }

    @MainActor func testCardApprovalKeepsIdWhenTheResponseCannotBeRead() async throws {
        defer { MushyStub.handler = nil }
        var ids: [String] = []
        var responses: [(Int, Data)] = [(503, Data(count: 4_000_001)), (200, Data())]
        MushyStub.handler = { request in
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: MushyStub.body(request)) as? [String: String])
            ids.append(try XCTUnwrap(body["request_id"]))
            return responses.removeFirst()
        }
        let client = MushyClient(fixtureMode: FixtureMode(arguments: []), protocolClasses: [MushyStub.self], token: { "test-device" })
        let identity = try client.identity()
        let digest = String(repeating: "e", count: 64)
        do { try await client.approveCard(cardId: "card-home", cardDigest: digest, identity: identity); XCTFail("oversized 503 succeeded") }
        catch {}
        try await client.approveCard(cardId: "card-home", cardDigest: digest, identity: identity)
        XCTAssertEqual(ids.count, 2)
        XCTAssertEqual(Set(ids).count, 1, "an unreadable response leaves the outcome unknown, so the id is reused")
    }

    @MainActor func testCardApprovalTerminalRefusalAndChangedDigestGetFreshIds() async throws {
        defer { MushyStub.handler = nil }
        var ids: [String] = []
        var statuses = [409, 200, 200]
        MushyStub.handler = { request in
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: MushyStub.body(request)) as? [String: String])
            ids.append(try XCTUnwrap(body["request_id"]))
            return (statuses.removeFirst(), Data())
        }
        let client = MushyClient(fixtureMode: FixtureMode(arguments: []), protocolClasses: [MushyStub.self], token: { "test-device" })
        let identity = try client.identity()
        let digest = String(repeating: "c", count: 64)
        do { try await client.approveCard(cardId: "card-home", cardDigest: digest, identity: identity); XCTFail("409 succeeded") }
        catch {}
        try await client.approveCard(cardId: "card-home", cardDigest: digest, identity: identity)
        try await client.approveCard(cardId: "card-home", cardDigest: String(repeating: "d", count: 64), identity: identity)
        XCTAssertEqual(ids.count, 3)
        XCTAssertEqual(Set(ids).count, 3, "a terminal refusal and a changed digest each start a new approval")
        XCTAssertTrue(MushyClient.cardApprovalIsTerminal(410))
        XCTAssertFalse(MushyClient.cardApprovalIsTerminal(503))
        XCTAssertFalse(MushyClient.cardApprovalIsTerminal(429))
    }

    @MainActor func testCardClientRejectsInvalidPathsBeforeNetwork() async throws {
        defer { MushyStub.handler = nil }
        MushyStub.handler = { _ in XCTFail("Invalid identifier reached network"); return (500, Data()) }
        let client = MushyClient(fixtureMode: FixtureMode(arguments: []), protocolClasses: [MushyStub.self], token: { "test-device" })
        let identity = try client.identity()
        for id in ["../events", "not-a-turn"] {
            do { _ = try await client.turnCards(turnId: id, identity: identity); XCTFail("Accepted invalid turn") }
            catch { XCTAssertTrue(error is MushyClientError) }
        }
        for id in ["card-../approve", "card-", "card-a\n", "card-" + String(repeating: "a", count: 121)] {
            do {
                try await client.approveCard(cardId: id, cardDigest: String(repeating: "a", count: 64), identity: identity)
                XCTFail("Accepted invalid card")
            } catch { XCTAssertTrue(error is MushyClientError) }
        }
    }

    @MainActor func testEngineBuildingDefaultsOffAndPrefillEnablesItWithoutReplacingDraft() async throws {
        let mode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])
        let suite = "assistant-toggle-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let studio = MushyState(fixtureMode: mode, defaults: defaults)
        let conversation = AssistantConversation(fixtureMode: mode)
        XCTAssertFalse(conversation.engineBuilding)
        conversation.offerPrefill("Workshop context")
        XCTAssertFalse(conversation.engineBuilding)
        conversation.offerPrefill("Workshop context", engineBuilding: true)
        XCTAssertTrue(conversation.engineBuilding)
        XCTAssertEqual(conversation.draft, "Workshop context")
        XCTAssertNil(conversation.offeredPrefill)
        conversation.setEngineBuilding(false)
        conversation.draft = "My draft"
        conversation.offerPrefill("Build an engine", engineBuilding: true)
        XCTAssertTrue(conversation.engineBuilding)
        XCTAssertEqual(conversation.draft, "My draft")
        XCTAssertEqual(conversation.offeredPrefill, "Build an engine")
        conversation.dismissPrefill()
        let priorSession = studio.selections.sessionId
        await conversation.newConversation(studio: studio)
        XCTAssertNotEqual(studio.selections.sessionId, priorSession)
        XCTAssertTrue(conversation.engineBuilding)
        XCTAssertTrue(conversation.items.isEmpty)
        XCTAssertEqual(conversation.draft, "")
        conversation.setEngineBuilding(false)
        await conversation.newConversation(studio: studio)
        XCTAssertFalse(conversation.engineBuilding)
    }

    @MainActor func testTurnModeIsCapabilityGatedOnTheWire() async throws {
        let mode = FixtureMode(arguments: [])
        let encoder = MushyCoding.encoder()
        let fixture = MushyClient.fixtureCatalog
        defer { MushyStub.handler = nil }
        for supported in [true, false] {
            let suite = "assistant-mode-" + UUID().uuidString
            let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
            defer { defaults.removePersistentDomain(forName: suite) }
            let catalog = MushyCatalog(schemaVersion: fixture.schemaVersion, models: fixture.models,
                defaultModelId: fixture.defaultModelId, defaultReasoningId: fixture.defaultReasoningId,
                sources: fixture.sources, sourceScopes: fixture.sourceScopes,
                providerReadiness: fixture.providerReadiness, panelKinds: fixture.panelKinds,
                capabilities: fixture.capabilities.filter { supported || $0 != "assistant.engine" },
                assistantReadiness: fixture.assistantReadiness)
            var snapshot = MushyClient.fixtureSnapshot
            snapshot.jobs = []
            var turns: [[String: Any]] = []
            let jobId = MushyClient.fixtureArtifactId
            MushyStub.handler = { request in
                switch request.url?.lastPathComponent {
                case "engines": return (200, try encoder.encode(catalog))
                case "state": return (200, try encoder.encode(snapshot))
                case "turn":
                    XCTAssertTrue(request.url?.path.hasSuffix("/assistant/turn") == true)
                    let data = try MushyStub.body(request)
                    turns.append(try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any]))
                    let decoded = try MushyCoding.decoder().decode(AssistantTurnRequest.self, from: data)
                    XCTAssertEqual(decoded.mode, turns.last?["mode"] as? String)
                    return (200, try encoder.encode(AssistantTurnReceipt(jobId: jobId, status: "pending")))
                case "events":
                    return (200, try JSONSerialization.data(withJSONObject: [
                        "job_id": jobId, "status": "completed", "next": 1,
                        "events": [["seq": 1, "type": "done", "payload": ["text": "Ready"]]]
                    ]))
                case "cards": return (200, try self.cardsData([]))
                default: XCTFail("Unexpected assistant request"); return (404, Data())
                }
            }
            let client = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: { "test-device" })
            let studio = MushyState(fixtureMode: mode, client: client, defaults: defaults)
            await studio.refresh()
            XCTAssertEqual(studio.supports("assistant.engine"), supported)
            let conversation = AssistantConversation(fixtureMode: mode, client: client)
            for on in [false, true] {
                conversation.setEngineBuilding(on)
                await conversation.send("Help with this engine", studio: studio)
                let turn = try XCTUnwrap(turns.last)
                XCTAssertEqual(turn["mode"] as? String, supported ? (on ? "engine" : "ask") : nil)
                if !supported { XCTAssertFalse(turn.keys.contains("mode")) }
                XCTAssertNil(conversation.activeReply?.failed)
            }
            XCTAssertEqual(turns.count, 2)
        }
    }

    @MainActor func testPrefillFillsEmptyDraftAndOffersOverExistingDraft() {
        let conversation = AssistantConversation(fixtureMode: FixtureMode(arguments: []))
        conversation.offerPrefill("Workshop context")
        XCTAssertEqual(conversation.draft, "Workshop context")
        XCTAssertNil(conversation.offeredPrefill)
        conversation.offerPrefill("Workshop context")
        XCTAssertEqual(conversation.draft, "Workshop context")
        XCTAssertNil(conversation.offeredPrefill)

        conversation.draft = "mine"
        conversation.offerPrefill("Workshop context")
        XCTAssertEqual(conversation.draft, "mine")
        XCTAssertEqual(conversation.offeredPrefill, "Workshop context")
        conversation.acceptPrefill()
        XCTAssertEqual(conversation.draft, "Workshop context")
        XCTAssertNil(conversation.offeredPrefill)

        conversation.draft = "mine"
        conversation.offerPrefill("Workshop context")
        conversation.dismissPrefill()
        XCTAssertEqual(conversation.draft, "mine")
        XCTAssertNil(conversation.offeredPrefill)
    }

    func testDecodesEventsAndSkipsUnknownOrMalformedPayloads() throws {
        let json = #"""
        {
          "job_id": "job-one", "status": "completed", "next": 8,
          "events": [
            {"seq": 1, "type": "status", "payload": {"stage": "thinking"}},
            {"seq": 2, "type": "text", "payload": {"delta": "Hello"}},
            {"seq": 3, "type": "tool", "payload": {"id": "t1", "name": "fills", "label": "Reading your fills", "state": "started"}},
            {"seq": 4, "type": "view", "payload": {"title": "Balance", "panels": [
              {"kind": "metric", "title": "Cash", "columns": [{"key": "cash_cents", "label": "Cash", "format": "usd"}], "rows": [{"cash_cents": 23881}]}
            ]}},
            {"seq": 5, "type": "error", "payload": {"message": "Please try again."}},
            {"seq": 6, "type": "done", "payload": {"text": "Final answer"}},
            {"seq": 7, "type": "future_event", "payload": {"new_field": true}},
            {"seq": 8, "type": "view", "payload": {"title": "Bad view", "panels": "not an array"}}
          ]
        }
        """#
        let page = try MushyCoding.decoder().decode(AssistantEventsPage.self, from: Data(json.utf8))
        XCTAssertEqual(page.jobId, "job-one")
        XCTAssertEqual(page.status, "completed")
        XCTAssertEqual(page.next, 8)
        XCTAssertEqual(page.events.count, 8)
        guard case .status(let stage) = page.events[0].payload,
              case .text(let delta) = page.events[1].payload,
              case .tool(let id, let name, let label, let state) = page.events[2].payload,
              case .view(let title, let panels) = page.events[3].payload,
              case .error(let message) = page.events[4].payload,
              case .done(let text) = page.events[5].payload,
              case .unknown = page.events[6].payload,
              case .unknown = page.events[7].payload else {
            return XCTFail("Each event must decode independently, including unknown payloads.")
        }
        XCTAssertEqual(stage, "thinking")
        XCTAssertEqual(delta, "Hello")
        XCTAssertEqual(id, "t1")
        XCTAssertEqual(name, "fills")
        XCTAssertEqual(label, "Reading your fills")
        XCTAssertEqual(state, "started")
        XCTAssertEqual(title, "Balance")
        XCTAssertEqual(panels.first?.rows.first?["cash_cents"], .number(23881))
        XCTAssertEqual(message, "Please try again.")
        XCTAssertEqual(text, "Final answer")
    }

    func testMoneyCountsPercentAndRelativeTimes() {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        func display(_ value: MushyValue?, _ format: String) -> String {
            AssistantFormat.display(value, format: format, now: now, locale: Locale(identifier: "en_US"))
        }
        XCTAssertEqual(display(.number(23881), "usd"), "$238.81")
        XCTAssertEqual(display(.number(1234567), "usd"), "$12,345.67")
        XCTAssertEqual(display(.number(-310), "usd_signed"), "-$3.10")
        XCTAssertEqual(display(.number(1240), "usd_signed"), "+$12.40")
        XCTAssertEqual(display(.number(0), "usd_signed"), "$0.00")
        XCTAssertEqual(display(.number(1869), "count"), "1,869")
        XCTAssertEqual(display(.number(12.5), "percent"), "12.5%")
        XCTAssertEqual(display(.null, "usd"), "Unavailable")
        XCTAssertEqual(display(nil, "text"), "Unavailable")
        XCTAssertEqual(display(.string("Kept as written"), "future-format"), "Kept as written")
        let iso = ISO8601DateFormatter()
        XCTAssertEqual(display(.string(iso.string(from: now.addingTimeInterval(-30))), "time"), "just now")
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        XCTAssertEqual(display(.string(iso.string(from: now.addingTimeInterval(-300))), "time"), "5 min ago")
        XCTAssertEqual(display(.string("2026-09-22"), "date"), "Sep 22")
    }

    @MainActor func testAppliesEventsOnceAndUsesAuthoritativeDoneText() async throws {
        let mode = FixtureMode(arguments: [])
        let suite = "assistant-events-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite); MushyStub.handler = nil }
        var snapshot = MushyClient.fixtureSnapshot
        snapshot.jobs = []
        snapshot.sessions[0].messages = [.init(role: "assistant", content: "Previous answer",
            jobId: MushyClient.fixtureArtifactId, createdAt: "")]
        MushyStub.handler = { request in
            let encoder = MushyCoding.encoder()
            switch request.url?.lastPathComponent {
            case "engines": return (200, try encoder.encode(MushyClient.fixtureCatalog))
            case "state": return (200, try encoder.encode(snapshot))
            default: XCTFail("Unexpected history request"); return (404, Data())
            }
        }
        let client = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: { "test-device" })
        let studio = MushyState(fixtureMode: mode, client: client, defaults: defaults)
        await studio.refresh()
        let conversation = AssistantConversation(fixtureMode: mode)
        conversation.load(from: studio)
        XCTAssertNotNil(conversation.activeReply)
        conversation.apply(.init(seq: 1, type: "done", payload: .done(text: "")))
        conversation.apply(.init(seq: 2, type: "text", payload: .text(delta: "Hello ")))
        conversation.apply(.init(seq: 3, type: "text", payload: .text(delta: "there")))
        XCTAssertEqual(conversation.activeReply?.text, "Hello there")
        conversation.apply(.init(seq: 3, type: "text", payload: .text(delta: "duplicate")))
        conversation.apply(.init(seq: 2, type: "text", payload: .text(delta: "old")))
        XCTAssertEqual(conversation.activeReply?.text, "Hello there")
        conversation.apply(.init(seq: 4, type: "tool", payload: .tool(id: "t1", name: "fills", label: "Reading your fills", state: "started")))
        XCTAssertEqual(conversation.activeReply?.tools.first?.state, "started")
        conversation.apply(.init(seq: 5, type: "tool", payload: .tool(id: "t1", name: "fills", label: "Read your fills", state: "finished")))
        XCTAssertEqual(conversation.activeReply?.tools.count, 1)
        XCTAssertEqual(conversation.activeReply?.tools.first?.state, "finished")
        let panel = AssistantPanel(kind: "metric", title: "Cash", columns: [.init(key: "cash", label: "Cash", format: "usd")],
            rows: [["cash": .number(23881)]])
        conversation.apply(.init(seq: 6, type: "view", payload: .view(title: "Balance", panels: [panel])))
        XCTAssertEqual(conversation.activeReply?.views.count, 1)
        conversation.apply(.init(seq: 7, type: "done", payload: .done(text: "The final answer")))
        XCTAssertEqual(conversation.activeReply?.text, "The final answer")
        XCTAssertEqual(conversation.activeReply?.finished, true)
        XCTAssertEqual(conversation.cursor, 7)
    }

    @MainActor func testFixtureTurnStreamsToolsTextAndPanels() async throws {
        let mode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])
        let conversation = AssistantConversation(fixtureMode: mode)
        let studio = MushyState(fixtureMode: mode)
        await conversation.send("How much cash do I have?", studio: studio)
        XCTAssertEqual(conversation.items.count, 2)
        guard conversation.items.count == 2,
              case .user(_, let question) = conversation.items[0],
              case .assistant(_, let reply) = conversation.items[1] else {
            return XCTFail("Expected one question and one answer.")
        }
        XCTAssertEqual(question, "How much cash do I have?")
        XCTAssertTrue(reply.finished)
        XCTAssertTrue(reply.text.contains("$238.81"))
        XCTAssertNil(reply.failed)
        XCTAssertEqual(reply.tools.count, 1)
        XCTAssertEqual(reply.tools.first?.state, "finished")
        XCTAssertEqual(reply.views.count, 1)
        XCTAssertEqual(reply.views.first?.panels.map(\.kind), ["line", "metric"])
        XCTAssertNil(conversation.activeJobId)
        XCTAssertFalse(conversation.sending)
    }

    @MainActor func testFixtureEngineTurnStreamsPaperEngineTableWithoutOptIn() async throws {
        let mode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_ASSISTANT_V2", "0"])
        let studio = MushyState(fixtureMode: mode)
        XCTAssertTrue(studio.supports("assistant.v2"))
        XCTAssertTrue(studio.supports("assistant.engine"))
        XCTAssertEqual(studio.catalog?.assistantReadiness?.ready, true)
        let conversation = AssistantConversation(fixtureMode: mode)
        conversation.load(from: studio)
        XCTAssertTrue(conversation.items.isEmpty)
        conversation.setEngineBuilding(true)
        await conversation.send("Build a paper engine for gold 15-minute markets", studio: studio)
        let reply = try XCTUnwrap(conversation.activeReply)
        XCTAssertTrue(reply.finished)
        XCTAssertNil(reply.failed)
        XCTAssertTrue(reply.text.contains("Nothing trades"))
        XCTAssertEqual(reply.views.count, 1)
        XCTAssertEqual(reply.views.first?.title, "Paper engine fixture-engine")
        XCTAssertEqual(reply.views.first?.panels.map(\.kind), ["table"])
        XCTAssertEqual(reply.views.first?.panels.first?.rows.first?["engine"], .string("fixture-engine"))
    }
}
