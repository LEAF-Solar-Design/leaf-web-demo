import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

/// The probe board's first-line protection verdict: computed only from which runner fields are present.
final class ProbeVerdictTests: XCTestCase {
    private func board(_ json: String) throws -> ProbeBoardResponse {
        try accountJSONDecoder().decode(ProbeBoardResponse.self, from: Data(json.utf8))
    }

    private func verdict(_ board: ProbeBoardResponse, observedAge: String? = nil) -> (text: String, tone: LeafTone) {
        ProbeBoardText.protectionVerdict(accountBreakerReported: ProbeBoardText.accountMeterReported(board.account),
                                         accountSuspended: board.account?.suspended == true,
                                         rows: board.engines, observedAge: observedAge)
    }

    private let reportedAccount = #""account":{"pct":50,"loss_cents":2000,"limit_cents":125000,"suspended":false}"#
    private let reportedEngine = #"""
        {"engine_id":"aggr-2","lifecycle":{"state":"probe","breaker":{"engine_loss_cents":1240,"engine_limit_cents":125000}}}
        """#

    func testAllReported() throws {
        // Inactive and unreported lifecycles do not count as probing or live rows.
        let reported = try board("""
            {\(reportedAccount),"engines":[\(reportedEngine),
              {"engine_id":"live-1","lifecycle":{"state":"graduated","breaker":{"engine_limit_cents":50000}}},
              {"engine_id":"stopped","lifecycle":{"state":"retired"}},
              {"engine_id":"draft","lifecycle":{"state":"shadow"}},
              {"engine_id":"future-engine","lifecycle":{"state":"quarantined"}}]}
            """)
        let plain = verdict(reported)
        XCTAssertEqual(plain.text, "Loss limits reported by the runner.")
        XCTAssertEqual(plain.tone, .neutral)
        XCTAssertEqual(verdict(reported, observedAge: "Observed 3 min ago").text,
                       "Loss limits reported by the runner. Observed 3 min ago")
        XCTAssertFalse(reported.engines.contains(where: ProbeBoardText.dayLossLimitMissing))
    }

    func testAccountMissing() throws {
        for account in [#""account":null"#, #""account":{"pct":50}"#, #""account":{"loss_cents":2000}"#,
                        #""account":{"limit_cents":125000}"#] {
            let missing = try board("{\(account),\"engines\":[\(reportedEngine)]}")
            let result = verdict(missing, observedAge: "Observed 2 h ago")
            XCTAssertEqual(result.text,
                           "Loss limits not reported. Account breaker is not reported by the runner. Observed 2 h ago",
                           account)
            XCTAssertEqual(result.tone, .warn, account)
        }
        // An unreadable board has neither the account nor any engine.
        let unreadable = ProbeBoardText.protectionVerdict(accountBreakerReported: false, accountSuspended: false, rows: [])
        XCTAssertEqual(unreadable.text, "Loss limits not reported. Account breaker is not reported by the runner.")
        XCTAssertEqual(unreadable.tone, .warn)
    }

    func testSomeEnginesMissing() throws {
        let engines = #"""
            {"engine_id":"a","lifecycle":{"state":"probe"}},
            {"engine_id":"b","lifecycle":{"state":"probe_sized","contracts":2,"breaker":{"engine_loss_cents":300}}},
            {"engine_id":"c","lifecycle":{"state":"canary","breaker":{"engine_pct":50}}}
            """#
        let three = try board("{\(reportedAccount),\"engines\":[\(reportedEngine),\(engines)]}")
        XCTAssertEqual(three.engines.filter(ProbeBoardText.dayLossLimitMissing).map(\.engineId), ["a", "b", "c"])
        let result = verdict(three)
        XCTAssertEqual(result.text, "Loss limits not reported. Day-loss limits for 3 engines are not reported by the runner.")
        XCTAssertEqual(result.tone, .warn)

        let one = try board("{\(reportedAccount),\"engines\":[{\"engine_id\":\"a\",\"lifecycle\":{\"state\":\"probe\"}}]}")
        XCTAssertEqual(verdict(one).text, "Loss limits not reported. Day-loss limit for 1 engine is not reported by the runner.")

        let both = try board("{\"account\":null,\"engines\":[\(engines)]}")
        let combined = verdict(both, observedAge: "Observed 12 s ago")
        XCTAssertEqual(combined.text, "Loss limits not reported. Account breaker and day-loss limit for 3 engines "
                       + "are not reported by the runner. Observed 12 s ago")
        XCTAssertEqual(combined.tone, .warn)
    }

    func testTrippedBreakerKeepsLossWording() throws {
        let tripped = try board(#"""
            {"account":{"pct":100,"loss_cents":125000,"limit_cents":125000,"suspended":true},"engines":[
            """# + reportedEngine + "]}")
        let result = verdict(tripped)
        XCTAssertEqual(result.text, "Account breaker tripped: entries suspended until 00:00 UTC.")
        XCTAssertEqual(result.tone, .loss)

        // Missing limits are still named, and the tripped wording and tone are never softened to warn.
        let trippedAndMissing = try board(#"""
            {"account":{"loss_cents":125000,"limit_cents":125000,"suspended":true},
             "engines":[{"engine_id":"a","lifecycle":{"state":"probe"}}]}
            """#)
        let both = verdict(trippedAndMissing)
        XCTAssertEqual(both.text, "Account breaker tripped: entries suspended until 00:00 UTC. "
                       + "Day-loss limit for 1 engine is not reported by the runner.")
        XCTAssertEqual(both.tone, .loss)
    }

    func testHaltedEngineKeepsLossWordingWithAndWithoutMissingLimits() throws {
        let halted = #"{"engine_id":"stopped","lifecycle":{"state":"halted"}}"#
        let reported = try board("{\(reportedAccount),\"engines\":[\(reportedEngine),\(halted)]}")
        XCTAssertFalse(ProbeBoardText.dayLossLimitMissing(reported.engines[1]))
        XCTAssertEqual(verdict(reported).text, "At least one engine: entries halted, settlement only.")
        XCTAssertEqual(verdict(reported).tone, .loss)

        let missing = try board("{\"account\":null,\"engines\":[\(halted)]}")
        let result = verdict(missing, observedAge: "Observed 12 s ago")
        XCTAssertEqual(result.text, "At least one engine: entries halted, settlement only. "
                       + "Account breaker is not reported by the runner. Observed 12 s ago")
        XCTAssertEqual(result.tone, .loss)
    }

    func testZeroLimitsAreReportedAndGraduatedRowsRequireLimits() throws {
        let zero = try board(#"""
            {"account":{"loss_cents":0,"limit_cents":0},"engines":[
              {"engine_id":"live","lifecycle":{"state":"graduated","breaker":{"engine_limit_cents":0}}}]}
            """#)
        XCTAssertEqual(verdict(zero).text, "Loss limits reported by the runner.")
        XCTAssertEqual(verdict(zero).tone, .neutral)
        XCTAssertFalse(ProbeBoardText.dayLossLimitMissing(zero.engines[0]))

        let missing = try board("""
            {\(reportedAccount),"engines":[
              {"engine_id":"live","lifecycle":{"state":"graduated","breaker":{"engine_limit_cents":null}}}]}
            """)
        XCTAssertTrue(ProbeBoardText.dayLossLimitMissing(missing.engines[0]))
        XCTAssertEqual(verdict(missing).text,
                       "Loss limits not reported. Day-loss limit for 1 engine is not reported by the runner.")
        XCTAssertEqual(verdict(missing).tone, .warn)
    }
}
