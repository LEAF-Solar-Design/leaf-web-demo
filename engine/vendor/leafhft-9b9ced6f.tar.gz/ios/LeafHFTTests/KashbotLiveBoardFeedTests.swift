import ActivityKit
import Foundation
import Security
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class KashbotFeedStub: URLProtocol {
    private static let lock = NSLock()
    private static var storedHandler: ((URLRequest) -> (Int, Data))?
    private static var storedRequests: [URL] = []
    private static var storedHold: ((KashbotFeedStub) -> Bool)?
    static var handler: ((URLRequest) -> (Int, Data))? {
        get { lock.lock(); defer { lock.unlock() }; return storedHandler }
        set { lock.lock(); defer { lock.unlock() }; storedHandler = newValue }
    }
    static var requests: [URL] {
        get { lock.lock(); defer { lock.unlock() }; return storedRequests }
        set { lock.lock(); defer { lock.unlock() }; storedRequests = newValue }
    }
    static var hold: ((KashbotFeedStub) -> Bool)? {
        get { lock.lock(); defer { lock.unlock() }; return storedHold }
        set { lock.lock(); defer { lock.unlock() }; storedHold = newValue }
    }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        if Self.hold?(self) == true { return }
        guard let url = request.url, let handler = Self.handler else {
            client?.urlProtocol(self, didFailWithError: URLError(.badServerResponse))
            return
        }
        let (status, data) = handler(request)
        guard let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: nil, headerFields: nil) else {
            client?.urlProtocol(self, didFailWithError: URLError(.badServerResponse))
            return
        }
        Self.lock.lock()
        Self.storedRequests.append(url)
        Self.lock.unlock()
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: data)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@MainActor private final class FeedActivityDriver: LiveActivityDriving {
    var areActivitiesEnabled = true
    var activities: [DrivenLiveActivity] = []
    var requests: [ActivityContent<KashbotLiveAttributes.ContentState>] = []
    var updates: [(String, ActivityContent<KashbotLiveAttributes.ContentState>, AlertConfiguration?)] = []
    var ended: [String] = []
    func request(_ content: ActivityContent<KashbotLiveAttributes.ContentState>) throws -> String {
        requests.append(content)
        let id = "feed-\(requests.count)"
        activities.append(.init(id: id, startDate: Date(), state: content.state))
        return id
    }
    func update(id: String, content: ActivityContent<KashbotLiveAttributes.ContentState>, alert: AlertConfiguration?) async {
        updates.append((id, content, alert))
    }
    func end(id: String) async {
        ended.append(id)
        activities.removeAll { $0.id == id }
    }
    func pushTokenUpdates(id: String) -> AsyncStream<Data> { AsyncStream { $0.finish() } }
    func pushToStartTokenUpdates() -> AsyncStream<Data> { AsyncStream { $0.finish() } }
}

final class KashbotLiveBoardFeedTests: XCTestCase {
    private let dayStart = LiveBoardMath.easternDayStart(for: Date(timeIntervalSince1970: 1_790_000_000))
    private var now: Date { dayStart.addingTimeInterval(12 * 3600) }
    private let iso = ISO8601DateFormatter()
    private var suites: [String] = []

    override func tearDown() {
        KashbotFeedStub.handler = nil
        KashbotFeedStub.requests = []
        KashbotFeedStub.hold = nil
        KashbotBoardStore.clear()
        PortfolioWidgetSnapshotStore.clear()
        for suite in suites { UserDefaults().removePersistentDomain(forName: suite) }
        suites = []
        super.tearDown()
    }

    private func signer() throws -> KalshiSigner {
        let attributes: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeySizeInBits as String: 2048, kSecAttrIsPermanent as String: false]
        var error: Unmanaged<CFError>?
        let generated = SecKeyCreateRandomKey(attributes as CFDictionary, &error)
        _ = error?.takeRetainedValue()
        let key = try XCTUnwrap(generated)
        error = nil
        let representation = SecKeyCopyExternalRepresentation(key, &error)
        _ = error?.takeRetainedValue()
        return try KalshiSigner(pkcs1DER: XCTUnwrap(representation) as Data)
    }

    @MainActor private func makeState(liveActivity: LiveActivityController? = nil,
                                      clock: @escaping () -> Date) throws -> AppState {
        let signer = try signer()
        let mode = FixtureMode(arguments: [])
        let client = KalshiClient(fixtureMode: mode, protocolClasses: [KashbotFeedStub.self],
                                  credential: { ("test-id", signer) })
        let dashboard = DashboardClient(fixtureMode: mode, protocolClasses: [KashbotFeedStub.self],
            token: { throw DashboardClientError.noCredential })
        return AppState(fixtureMode: mode, dashboard: dashboard, liveActivity: liveActivity, kalshi: client, clock: clock)
    }

    @MainActor private func makeController(_ driver: FeedActivityDriver) -> LiveActivityController {
        let suite = "KashbotLiveBoardFeedTests." + UUID().uuidString
        suites.append(suite)
        let at = now
        return LiveActivityController(driver: driver, defaults: UserDefaults(suiteName: suite)!,
            fixtureMode: FixtureMode(arguments: []), now: { at }, isActive: { true }, upload: { _, _, _ in })
    }

    private func body(_ object: Any) -> Data {
        (try? JSONSerialization.data(withJSONObject: object)) ?? Data()
    }

    /// Each settlement nets +50 cents: 100 revenue against a 0.50 cost.
    private func settlement(_ ticker: String, at date: Date) -> [String: Any] {
        ["ticker": ticker, "yes_total_cost_dollars": "0.50", "revenue": 100, "fee_cost": "0",
         "settled_time": iso.string(from: date)]
    }

    private func position(_ ticker: String, exposure: String, size: String = "2") -> [String: Any] {
        ["ticker": ticker, "position_fp": size, "market_exposure_dollars": exposure, "fees_paid_dollars": "0"]
    }

    private func settlementRequests() -> [URLComponents] {
        KashbotFeedStub.requests.filter { $0.path.hasSuffix("/portfolio/settlements") }
            .compactMap { URLComponents(url: $0, resolvingAgainstBaseURL: false) }
    }

    /// Routes each Kalshi path; `settlements` answers by the request's cursor and `nil` means HTTP 500.
    private func route(positions: [[String: Any]]? = [], positionsStatus: Int = 200,
                       settlements: @escaping (String?) -> (rows: [[String: Any]], cursor: String?)?) {
        let balance = body(["balance": 10000, "portfolio_value": 500])
        let positionsBody = body(["market_positions": positions ?? []])
        let empty = body(["fills": [Any](), "markets": [Any]()])
        KashbotFeedStub.handler = { [weak self] request in
            guard let self, let url = request.url else { return (500, Data()) }
            let path = url.path
            if path.hasSuffix("/portfolio/balance") { return (200, balance) }
            if path.hasSuffix("/portfolio/positions") { return (positionsStatus, positionsBody) }
            if path.hasSuffix("/portfolio/settlements") {
                let cursor = URLComponents(url: url, resolvingAgainstBaseURL: false)?
                    .queryItems?.first { $0.name == "cursor" }?.value
                guard let page = settlements(cursor) else { return (500, Data()) }
                var object: [String: Any] = ["settlements": page.rows]
                if let next = page.cursor { object["cursor"] = next }
                return (200, self.body(object))
            }
            return (200, empty)
        }
    }

    private func storedBoard() -> KashbotBoardSnapshot {
        let row = KashbotLiveAttributes.Row(ticker: "KXOLD", side: "yes", milli: 2000, winCents: 100,
                                            oddsPct: 50, state: "open")
        return KashbotBoardSnapshot(state: .init(asOf: Int(now.timeIntervalSince1970) - 60, totalCents: 10500,
            todayCents: 50, openCount: 1, rows: [row], ledger: []), ledger: [])
    }

    @MainActor func testMarketsAreRequestedWhileFillsAreHeld() async throws {
        route(positions: [position("KXA", exposure: "1.00")]) { _ in ([], nil) }
        let original = try XCTUnwrap(KashbotFeedStub.handler)
        let fillsHeld = expectation(description: "Fills response is held")
        let marketsRequested = expectation(description: "Markets request precedes fills response")
        let heldLock = NSLock()
        var held: KashbotFeedStub?
        KashbotFeedStub.hold = { stub in
            guard stub.request.url?.path.hasSuffix("/portfolio/fills") == true else { return false }
            heldLock.lock()
            held = stub
            heldLock.unlock()
            fillsHeld.fulfill()
            return true
        }
        KashbotFeedStub.handler = { request in
            if request.url?.path.hasSuffix("/markets") == true { marketsRequested.fulfill() }
            return original(request)
        }
        let at = now
        let state = try makeState(clock: { at })
        let poll = Task { await state.refreshLiveBoardOnce() }
        await fulfillment(of: [fillsHeld, marketsRequested], timeout: 3)
        XCTAssertTrue(state.kalshiPollInFlight)
        XCTAssertTrue(KashbotFeedStub.requests.contains { $0.path.hasSuffix("/markets") })
        KashbotFeedStub.hold = nil
        // Read the held protocol under the same lock used by its loading callback.
        let release = {
            heldLock.lock()
            defer { heldLock.unlock() }
            return held
        }
        if let stub = release(), let url = stub.request.url,
           let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: nil, headerFields: nil) {
            stub.client?.urlProtocol(stub, didReceive: response, cacheStoragePolicy: .notAllowed)
            stub.client?.urlProtocol(stub, didLoad: body(["fills": [Any]()]))
            stub.client?.urlProtocolDidFinishLoading(stub)
        }
        await poll.value
        XCTAssertNil(state.fillsError)
        XCTAssertNotNil(state.liveBoard)
    }

    @MainActor func testIndependentFillsAndSettlementsFailuresStillApplyPositionsAndMarkets() async throws {
        let today = dayStart.addingTimeInterval(600)
        route(positions: [position("KXA", exposure: "1.00")]) { _ in
            ([self.settlement("A0", at: today)], nil)
        }
        var at = now
        let state = try makeState(clock: { at })
        await state.refreshLiveBoardOnce()
        let fillsObservedAt = state.fillsObservedAt
        let goodSettlements = state.settlements
        let goodFills = state.recentFills
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]

        route(positions: [position("KXB", exposure: "1.00")]) { _ in
            ([self.settlement("A0", at: today)], nil)
        }
        let fillsFailureRoute = try XCTUnwrap(KashbotFeedStub.handler)
        KashbotFeedStub.handler = { request in
            if request.url?.path.hasSuffix("/portfolio/fills") == true { return (500, Data()) }
            if request.url?.path.hasSuffix("/markets") == true {
                return (200, self.body(["markets": [
                    ["ticker": "KXB", "status": "active", "last_price_dollars": "0.75"]
                ]]))
            }
            return fillsFailureRoute(request)
        }
        at += 60
        await state.refreshLiveBoardOnce()
        XCTAssertEqual(state.fillsError, "Could not refresh recent fills. Showing the last account activity.")
        XCTAssertEqual(state.fillsObservedAt, fillsObservedAt)
        XCTAssertEqual(try encoder.encode(state.recentFills), try encoder.encode(goodFills))
        XCTAssertEqual(state.positions.map(\.ticker), ["KXB"])
        XCTAssertEqual(state.markets.map(\.ticker), ["KXB"])
        XCTAssertEqual(state.liveBoard?.state.rows.first?.pnlCents, 50)

        route(positions: [position("KXC", exposure: "1.00")]) { _ in nil }
        let settlementsFailureRoute = try XCTUnwrap(KashbotFeedStub.handler)
        KashbotFeedStub.handler = { request in
            if request.url?.path.hasSuffix("/markets") == true {
                return (200, self.body(["markets": [
                    ["ticker": "KXC", "status": "active", "last_price_dollars": "0.60"]
                ]]))
            }
            return settlementsFailureRoute(request)
        }
        at += 60
        await state.refreshLiveBoardOnce()
        XCTAssertNil(state.fillsError)
        XCTAssertEqual(try encoder.encode(state.settlements), try encoder.encode(goodSettlements))
        XCTAssertEqual(state.positions.map(\.ticker), ["KXC"])
        XCTAssertEqual(state.markets.map(\.ticker), ["KXC"])
        XCTAssertEqual(state.liveBoard?.state.rows.first?.pnlCents, 20)
        XCTAssertEqual(state.liveBoard?.state.todayCents, 50)
    }

    @MainActor func testForegroundTenSecondMarketsLoopRebuildsPnl() async throws {
        route(positions: [position("KXA", exposure: "1.00")]) { _ in ([], nil) }
        let original = try XCTUnwrap(KashbotFeedStub.handler)
        var price = "0.60"
        let tick = expectation(description: "Markets-only foreground tick")
        var waitingForTick = false
        KashbotFeedStub.handler = { request in
            if request.url?.path.hasSuffix("/markets") == true {
                if waitingForTick { waitingForTick = false; tick.fulfill() }
                return (200, self.body(["markets": [
                    ["ticker": "KXA", "status": "active", "last_price_dollars": price]
                ]]))
            }
            return original(request)
        }
        var at = now
        let state = try makeState(clock: { at })
        state.sceneChanged(.active)
        defer { state.sceneChanged(.inactive) }
        for _ in 0..<300 where state.positionsObservedAt == nil || state.liveBoard?.state.rows.first?.pnlCents != 20 || state.kalshiPollInFlight {
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTAssertEqual(state.liveBoard?.state.rows.first?.pnlCents, 20)
        let baseline = KashbotFeedStub.requests.count
        price = "0.75"
        at += 10
        waitingForTick = true
        XCTAssertEqual(AppState.marketsRefreshInterval, 10_000_000_000)
        await fulfillment(of: [tick], timeout: 12)
        for _ in 0..<200 where state.liveBoard?.state.rows.first?.pnlCents != 50 {
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTAssertEqual(state.liveBoard?.state.rows.first?.pnlCents, 50)
        XCTAssertEqual(KashbotBoardStore.load(now: at), state.liveBoard)
        let requests = Array(KashbotFeedStub.requests.dropFirst(baseline))
        XCTAssertEqual(requests.count, 1)
        XCTAssertTrue(requests.allSatisfy { $0.path.hasSuffix("/markets") })
    }

    @MainActor func testMarketsTickSkipsAnInFlightFullPoll() async throws {
        route(positions: [position("KXA", exposure: "1.00")]) { _ in ([], nil) }
        let at = now
        let state = try makeState(clock: { at })
        await state.refreshLiveBoardOnce()
        let pending = expectation(description: "Full poll is in flight")
        var held: KashbotFeedStub?
        KashbotFeedStub.hold = { stub in
            guard stub.request.url?.path.hasSuffix("/portfolio/balance") == true else { return false }
            held = stub
            pending.fulfill()
            return true
        }
        state.sceneChanged(.active)
        defer {
            state.sceneChanged(.inactive)
            KashbotFeedStub.hold = nil
            if let held { held.client?.urlProtocol(held, didFailWithError: URLError(.cancelled)) }
        }
        await fulfillment(of: [pending], timeout: 3)
        let before = KashbotFeedStub.requests.count
        await state.refreshLiveMarketsOnce()
        XCTAssertEqual(KashbotFeedStub.requests.count, before)
    }

    @MainActor func testMarketsFailureKeepsLastBoard() async throws {
        route(positions: [position("KXA", exposure: "1.00")]) { _ in ([], nil) }
        let at = now
        let state = try makeState(clock: { at })
        state.sceneChanged(.active)
        defer { state.sceneChanged(.inactive) }
        for _ in 0..<300 where state.positionsObservedAt == nil || state.liveBoard == nil || state.kalshiPollInFlight {
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        let board = try XCTUnwrap(state.liveBoard)
        let original = try XCTUnwrap(KashbotFeedStub.handler)
        KashbotFeedStub.handler = { request in
            request.url?.path.hasSuffix("/markets") == true ? (500, Data()) : original(request)
        }
        XCTAssertFalse(state.kalshiPollInFlight)
        let before = KashbotFeedStub.requests.count
        await state.refreshLiveMarketsOnce()
        XCTAssertEqual(KashbotFeedStub.requests.count, before + 1)
        XCTAssertEqual(state.liveBoard, board)
        XCTAssertEqual(KashbotBoardStore.load(now: at), board)
    }

    @MainActor func testTwentyFiveSettlementsTodayAcrossTwoPagesSum() async throws {
        let today = dayStart.addingTimeInterval(3600)
        var first: [[String: Any]] = []
        for index in 0..<20 {
            let offset: TimeInterval = TimeInterval(3000 - index * 60)
            first.append(settlement("A\(index)", at: today.addingTimeInterval(offset)))
        }
        var second: [[String: Any]] = []
        for index in 0..<5 {
            let offset: TimeInterval = TimeInterval(100 - index * 10)
            second.append(settlement("B\(index)", at: today.addingTimeInterval(offset)))
        }
        route(positions: [position("KXA", exposure: "1.00")]) { cursor in
            switch cursor {
            case nil: return (first, "page-2")
            case "page-2"?: return (second, nil)
            default: return nil
            }
        }
        let at = now
        let state = try makeState(clock: { at })
        await state.refreshLiveBoardOnce()
        let board = try XCTUnwrap(state.liveBoard)
        XCTAssertEqual(board.state.todayCents, 25 * 50)
        XCTAssertEqual(board.ledger.count, 20)
        XCTAssertEqual(board.state.ledger.count, 4)
        let requests = settlementRequests()
        XCTAssertEqual(requests.count, 2)
        XCTAssertTrue(requests.allSatisfy { $0.queryItems?.contains(URLQueryItem(name: "limit", value: "200")) == true })
        XCTAssertEqual(KashbotBoardStore.load(now: now), board)
    }

    @MainActor func testSettlementPagingStopsAtDayStart() async throws {
        let today = dayStart.addingTimeInterval(600)
        route { cursor in
            switch cursor {
            case nil: return ([self.settlement("A0", at: today.addingTimeInterval(60)),
                               self.settlement("A1", at: today)], "page-2")
            case "page-2"?: return ([self.settlement("B0", at: today.addingTimeInterval(-60)),
                                    self.settlement("B1", at: self.dayStart.addingTimeInterval(-60))], "page-3")
            default: return ([self.settlement("C0", at: today)], "page-4")
            }
        }
        let at = now
        let state = try makeState(clock: { at })
        await state.refreshLiveBoardOnce()
        XCTAssertEqual(settlementRequests().count, 2)
        XCTAssertLessThan(settlementRequests().count, AppState.settlementPageCap)
        // The yesterday row is read but not counted in today's total.
        XCTAssertEqual(state.liveBoard?.state.todayCents, 3 * 50)
        XCTAssertEqual(state.liveBoard?.ledger.count, 4)
    }

    @MainActor func testSettlementPagingStopsAtTwentyFivePagesAndKeepsWhatItRead() async throws {
        let today = dayStart.addingTimeInterval(600)
        route { cursor in
            let digits: String = cursor?.replacingOccurrences(of: "page-", with: "") ?? "1"
            let page: Int = Int(digits) ?? 1
            let settledAt: Date = today.addingTimeInterval(TimeInterval(-page))
            let rows: [[String: Any]] = (0..<200).map { self.settlement("P\(page)-\($0)", at: settledAt) }
            return (rows, "page-\(page + 1)")
        }
        let at = now
        let state = try makeState(clock: { at })
        await state.refreshLiveBoardOnce()
        XCTAssertEqual(settlementRequests().count, AppState.settlementPageCap)
        XCTAssertEqual(AppState.settlementPageCap, 25)
        XCTAssertEqual(state.liveBoard?.state.todayCents, 5_000 * 50)
        XCTAssertEqual(state.settlements.count, 5_000)
        XCTAssertEqual(state.liveBoard?.ledger.count, 20)
        XCTAssertEqual(state.liveBoard?.ledger.first?.ticker, "P1-0")
    }

    @MainActor func testPositionsFailureAfterColdLaunchNeitherSavesNorAppliesBoard() async throws {
        let stored = storedBoard()
        KashbotBoardStore.save(stored)
        let driver = FeedActivityDriver()
        driver.activities = [.init(id: "running", startDate: now, state: stored.state)]
        let controller = makeController(driver)
        route(positionsStatus: 500) { _ in ([self.settlement("A0", at: self.dayStart.addingTimeInterval(60))], nil) }
        let at = now
        let state = try makeState(liveActivity: controller, clock: { at })
        await state.refreshLiveBoardOnce()
        XCTAssertNotNil(state.positionsError)
        XCTAssertNil(state.liveBoard)
        XCTAssertEqual(KashbotBoardStore.load(now: now), stored)
        XCTAssertTrue(driver.updates.isEmpty)
        XCTAssertTrue(driver.requests.isEmpty)
        XCTAssertTrue(driver.ended.isEmpty)
    }

    @MainActor func testSettlementsNeverReadSinceLaunchBlocksTheBoard() async throws {
        let stored = storedBoard()
        KashbotBoardStore.save(stored)
        let driver = FeedActivityDriver()
        driver.activities = [.init(id: "running", startDate: now, state: stored.state)]
        let controller = makeController(driver)
        route(positions: [position("KXOLD", exposure: "1.00")]) { _ in nil }
        let at = now
        let state = try makeState(liveActivity: controller, clock: { at })
        await state.refreshLiveBoardOnce()
        XCTAssertNil(state.liveBoard)
        XCTAssertEqual(KashbotBoardStore.load(now: now), stored)
        XCTAssertTrue(driver.updates.isEmpty)
        XCTAssertTrue(driver.requests.isEmpty)
    }

    @MainActor func testSettlementsFailureReusesLastGoodSettlements() async throws {
        let today = dayStart.addingTimeInterval(600)
        var failSettlements = false
        route(positions: [position("KXA", exposure: "1.00")]) { _ in
            if failSettlements { return nil }
            return ([self.settlement("A0", at: today.addingTimeInterval(60)), self.settlement("A1", at: today)], nil)
        }
        var at = now
        let state = try makeState(clock: { at })
        await state.refreshLiveBoardOnce()
        XCTAssertEqual(state.liveBoard?.state.todayCents, 100)
        failSettlements = true
        at = at.addingTimeInterval(60)
        await state.refreshLiveBoardOnce()
        let board = try XCTUnwrap(state.liveBoard)
        XCTAssertEqual(board.state.asOf, Int(at.timeIntervalSince1970))
        XCTAssertEqual(board.state.todayCents, 100)
        XCTAssertEqual(board.ledger.map(\.ticker), ["A0", "A1"])
        XCTAssertEqual(KashbotBoardStore.load(now: at), board)
    }

    @MainActor func testRestoreLoadsStoredBoard() async throws {
        let stored = storedBoard()
        KashbotBoardStore.save(stored)
        let at = now
        let state = try makeState(clock: { at })
        XCTAssertNil(state.liveBoard)
        await state.restore()
        XCTAssertEqual(state.liveBoard, stored)
    }

    @MainActor func testMarketTickersAreOrderedByExposure() async throws {
        let rows: [[String: Any]] = [
            position("KXA", exposure: "1.00"), position("KXC", exposure: "5.00"),
            position("KXB", exposure: "-5.00", size: "-3"), position("KXFLAT", exposure: "9.00", size: "0"),
            position("KXD", exposure: "2.50")]
        let wrapped: [String: Any] = ["market_positions": rows]
        let decoded: PositionsResponse = try accountJSONDecoder().decode(PositionsResponse.self, from: body(wrapped))
        let positions: [Position] = decoded.marketPositions ?? []
        XCTAssertEqual(AppState.marketTickers(positions), ["KXB", "KXC", "KXD", "KXA"])

        // The top exposure ticker sorts last by name but still reaches the capped markets query.
        var many: [[String: Any]] = []
        for index in 0..<20 {
            let ticker: String = String(format: "KXA%02d", index)
            many.append(position(ticker, exposure: "1.00"))
        }
        many.append(position("ZZTOP", exposure: "9.00"))
        route(positions: many) { _ in ([], nil) }
        let at = now
        let state = try makeState(clock: { at })
        await state.refreshLiveBoardOnce()
        let marketsURL: URL = try XCTUnwrap(KashbotFeedStub.requests.last { $0.path.hasSuffix("/markets") })
        let components: URLComponents? = URLComponents(url: marketsURL, resolvingAgainstBaseURL: false)
        let tickerItem: URLQueryItem? = components?.queryItems?.first { $0.name == "tickers" }
        let tickerValue: String = try XCTUnwrap(tickerItem?.value)
        let query: [String] = tickerValue.components(separatedBy: ",")
        XCTAssertEqual(query.count, 20)
        XCTAssertTrue(query.contains("ZZTOP"))
        XCTAssertFalse(query.contains("KXA19"))
    }
}
