import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor final class RiskyBatmanStateTests: XCTestCase {
    private let engineId = "risky-batman-15m"

    private func waitingStore() async throws -> RiskyBatmanState {
        let store = RiskyBatmanState(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
                                    fixtureTuningPending: true)
        await store.load()
        let accepted = await store.request(engineId: engineId, enabled: true)
        XCTAssertTrue(accepted)
        XCTAssertNotNil(store.pending[engineId])
        return store
    }

    private func record(_ id: UUID, state: String, note: String? = nil) -> ControlRequest {
        ControlRequest(id: "test-request", kind: "engine.shadow", value: nil, scope: nil,
                       clientRequestId: id.uuidString.lowercased(), state: state, note: note,
                       requestedAt: nil, appliedAt: nil)
    }

    func testMissingTuningRecordClearsWaitingWithoutChangingVariant() async throws {
        let store = try await waitingStore()
        store.trackTuning([])
        XCTAssertNil(store.pending[engineId])
        XCTAssertNil(store.engines.first { $0.id == engineId }?.variant)
        XCTAssertTrue(store.messages[engineId]?.contains("not found") == true)
        XCTAssertTrue(store.messages[engineId]?.contains("Check status") == true)
    }

    func testAppliedTuningRecordClearsWaitingBeforeVariantCatchesUp() async throws {
        let store = try await waitingStore()
        let id = try XCTUnwrap(store.pending[engineId]?.clientRequestId)
        store.trackTuning([record(id, state: "APPLIED")])
        XCTAssertNil(store.pending[engineId])
        XCTAssertNil(store.engines.first { $0.id == engineId }?.variant)
        XCTAssertTrue(store.messages[engineId]?.contains("applied") == true)
    }

    func testRejectedTuningRecordRetainsReasonAndRequestedRecordKeepsWaiting() async throws {
        let store = try await waitingStore()
        let id = try XCTUnwrap(store.pending[engineId]?.clientRequestId)
        store.trackTuning([record(id, state: "requested")])
        XCTAssertNotNil(store.pending[engineId])
        store.trackTuning([record(id, state: "rejected", note: "Published bound changed.")])
        XCTAssertNil(store.pending[engineId])
        XCTAssertEqual(store.messages[engineId], "Tuning request rejected. Published bound changed.")
    }

    func testTuningDeadlineClearsWaitingEvenWhenReadsNeverSucceed() async throws {
        let store = try await waitingStore()
        let submitted = try XCTUnwrap(store.pending[engineId]?.submittedAt)
        store.expireTuning(now: submitted.addingTimeInterval(RiskyBatmanState.tuningTimeout - 1))
        XCTAssertNotNil(store.pending[engineId])
        store.expireTuning(now: submitted.addingTimeInterval(RiskyBatmanState.tuningTimeout))
        XCTAssertNil(store.pending[engineId])
        XCTAssertTrue(store.messages[engineId]?.contains("Outcome unknown") == true)
        XCTAssertTrue(store.messages[engineId]?.contains("Check status") == true)
    }

    func testHedgeFailureWithoutControlRecordIsReadableInSheet() async {
        let store = RiskyBatmanState(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]))
        await store.load()
        let hedge = RiskyHedgeModeState()
        let accepted = await hedge.request(engineId: engineId, mode: .cashoutFirst, store: store,
                                           isOwner: true, laneId: nil)
        XCTAssertFalse(accepted)
        XCTAssertNil(hedge.controls[engineId])
        XCTAssertEqual(hedge.sheetMessage(engineId, attempted: true, sending: false),
                       "Controls are disabled in fixture mode.")
        XCTAssertNil(hedge.sheetMessage(engineId, attempted: false, sending: false))
        XCTAssertNil(hedge.sheetMessage(engineId, attempted: true, sending: true))
    }

    func testInitialProbeFailureShowsUnavailableButAbsentRouteStaysHidden() {
        XCTAssertTrue(ProbeBoardCard.showsUnavailable(notReported: false,
            status: FeedStatus(observedAt: nil, attemptedAt: Date(), lastError: "Offline")))
        XCTAssertTrue(ProbeBoardCard.showsUnavailable(notReported: true, status: nil))
        XCTAssertFalse(ProbeBoardCard.showsUnavailable(notReported: false,
            status: FeedStatus(observedAt: Date(), attemptedAt: Date(), lastError: nil)))
    }

    func testRetainedPositionsWarningIncludesErrorAndActualReadAge() throws {
        let now = Date(timeIntervalSince1970: 1_000_000)
        let observed = now.addingTimeInterval(-600)
        let note = try XCTUnwrap(MoneyCard.positionsReadNote(error: "Positions refresh failed.", observedAt: observed, now: now))
        XCTAssertTrue(note.contains("Positions refresh failed."))
        XCTAssertTrue(note.contains(ageDescription(observedAt: observed, now: now)))
        XCTAssertTrue(note.contains("last positions read"))
        XCTAssertNil(MoneyCard.positionsReadNote(error: nil, observedAt: observed, now: now))
        XCTAssertTrue(MoneyCard.positionsReadNote(error: "Offline", observedAt: nil, now: now)?.contains("read time not reported") == true)
    }
}
