import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class ObservationStoreTests: XCTestCase {
    func testDeduplicationOrderingAndSourceIsolation() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = try ObservationStore(url: directory.appendingPathComponent("history.sqlite"))
        let now = Date(timeIntervalSince1970: floor(Date().timeIntervalSince1970))
        let first = AccountObservation(capturedAt: now.addingTimeInterval(-10), source: .phone, cashCents: 100, portfolioValueCents: 120)
        let second = AccountObservation(capturedAt: now, source: .phone, cashCents: 200)
        try await store.append([second, first, first, AccountObservation(capturedAt: now, source: .runner, cashCents: 300)])
        let cash = try await store.load(metric: .cash, source: .phone)
        XCTAssertEqual(cash.map(\.cashCents), [100, 200])
        XCTAssertEqual(cash.map(\.capturedAt), [first.capturedAt, second.capturedAt])
        let value = try await store.load(metric: .portfolioValue, source: .phone)
        XCTAssertEqual(value.map(\.portfolioValueCents), [120])
        let runner = try await store.load(metric: .cash, source: .runner)
        XCTAssertEqual(runner.map(\.cashCents), [300])
        let recent = try await store.load(metric: .cash, source: .phone, since: now)
        XCTAssertEqual(recent.count, 1)
        let reopened = try ObservationStore(url: directory.appendingPathComponent("history.sqlite"))
        let persisted = try await reopened.load(metric: .cash, source: .phone)
        XCTAssertEqual(persisted, cash)
    }

    func testPruneAfterAppendAndExplicitCap() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = try ObservationStore(url: directory.appendingPathComponent("history.sqlite"))
        let now = Date()
        try await store.append(AccountObservation(capturedAt: now.addingTimeInterval(-91 * 86400), source: .phone, cashCents: 1))
        let expired = try await store.load(metric: .cash, source: .phone)
        XCTAssertTrue(expired.isEmpty)
        try await store.append((0..<5).map { AccountObservation(capturedAt: now.addingTimeInterval(Double($0 - 10)), source: .phone, cashCents: $0) })
        try await store.prune(keepingAtMost: 2, now: now)
        let retained = try await store.load(metric: .cash, source: .phone)
        XCTAssertEqual(retained.map(\.cashCents), [3, 4])
        try await store.prune(olderThan: 1, now: now)
        let removed = try await store.load(metric: .cash, source: .phone)
        XCTAssertTrue(removed.isEmpty)
    }
}
