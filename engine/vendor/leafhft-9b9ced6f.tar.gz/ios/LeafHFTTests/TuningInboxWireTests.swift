import Foundation
import XCTest
@testable import LeafHFT

// TuningInboxTests' helper is file-private. Keep the same URLProtocol harness here so
// the recorded responses exercise the real client without widening another file's scope.
private final class TuningHTTPStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                                                       httpVersion: nil, headerFields: nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

@MainActor final class TuningInboxWireTests: XCTestCase {
    override func tearDown() {
        TuningHTTPStub.handler = nil
        super.tearDown()
    }

    private func fixtureData() throws -> Data {
        let name = "tuning-wire-v1"
        let bundle = Bundle(for: TuningInboxWireTests.self)
        if let url = bundle.url(forResource: name, withExtension: "json")
            ?? bundle.url(forResource: name, withExtension: "json", subdirectory: "Fixtures") {
            return try Data(contentsOf: url)
        }
        // Same synced-source fallback as TuningVectors.data().
        let source = URL(fileURLWithPath: #filePath).deletingLastPathComponent()
            .appendingPathComponent("Fixtures").appendingPathComponent(name + ".json")
        return try Data(contentsOf: source)
    }

    private func response(_ name: String) throws -> [String: Any] {
        let data = try fixtureData()
        XCTAssertTrue(TuningSyntax.sha256Hex(data).hasPrefix("a115ae6942db53ee"), "recorded wire fixture drifted")
        let root = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        let responses = try XCTUnwrap(root["responses"] as? [String: Any])
        return try XCTUnwrap(responses[name] as? [String: Any])
    }

    private func body(_ name: String) throws -> Data {
        // List and detail are bare bodies; the refusal includes its HTTP status.
        let recorded = try response(name)
        return try JSONSerialization.data(withJSONObject: recorded["body"] ?? recorded)
    }

    private func decode<T: Decodable>(_ type: T.Type, from data: Data) throws -> T {
        // Matches TuningInboxClient.decoder(), which is private to the client.
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return try decoder.decode(type, from: data)
    }

    private func recordedDetail() throws -> TuningInboxDetail {
        let wire = try decode(TuningInboxWire.ItemResponse.self, from: body("mobile_detail"))
        XCTAssertTrue(wire.success)
        return try wire.item.validated()
    }

    func testRecordedMobileListDecodesAndValidatesEveryItem() throws {
        let wire = try decode(TuningInboxWire.ListResponse.self, from: body("mobile_list"))
        XCTAssertTrue(wire.success)
        XCTAssertFalse(wire.items.isEmpty)
        let items = try wire.items.map { try $0.validated() }
        XCTAssertEqual(items.count, wire.items.count)
        XCTAssertEqual(items.first?.id, "00000000-0000-4000-8000-000000000001")
        XCTAssertEqual(items.first?.state, .ready)
        XCTAssertNil(wire.nextCursor)
    }

    func testRecordedMobileDetailHasPlanAndRunnerSync() throws {
        let detail = try recordedDetail()
        XCTAssertNotNil(detail.plan)
        XCTAssertEqual(detail.runnerSyncAtMs, 1_790_683_202_000)
        XCTAssertEqual(detail.summary.resultCode, "ready")
    }

    func testRecordedPlanVerifiesAndAcceptGateBindsItToTheItem() throws {
        let detail = try recordedDetail()
        let envelope = try XCTUnwrap(detail.plan)
        let plan = try VerifiedTuningPlan.verify(planB64: envelope.planB64, advertisedSHA256: envelope.planSHA256)
        XCTAssertTrue(plan.hashMatches)
        XCTAssertEqual(plan.sha256, envelope.planSHA256)
        XCTAssertEqual(plan.bytes, try XCTUnwrap(Data(base64Encoded: envelope.planB64)))
        XCTAssertEqual(try TuningCanonicalParser.parse(plan.bytes, maxBytes: TuningInboxLimits.maxPlanBytes).canonicalBytes(),
                       plan.bytes)

        let syncAt = try XCTUnwrap(detail.runnerSyncAtMs)
        let now = syncAt + 1_000
        XCTAssertGreaterThan(now, plan.document.frozenAtMs)
        XCTAssertLessThan(now, plan.document.expiresAtMs)
        XCTAssertLessThanOrEqual(now - syncAt, TuningInboxLimits.runnerSyncStaleMs)
        let gate = TuningAcceptGate.evaluate(detail: detail, plan: plan, renderedSHA256: plan.sha256,
                                             nowMs: now, phase: .idle, fixtureMode: FixtureMode(arguments: []))
        XCTAssertFalse(gate.reasons.contains(.planUnavailable))
        XCTAssertFalse(gate.reasons.contains(.bindingMismatch))
        XCTAssertFalse(gate.reasons.contains(.runnerNotSyncing))
        XCTAssertTrue(gate.enabled)
    }

    func testRecordedAcceptRefusalDecodesAndShowsCredentialUnknownMessage() throws {
        let recorded = try response("mobile_accept_refusal")
        let status = try XCTUnwrap(recorded["status"] as? Int)
        let data = try body("mobile_accept_refusal")
        let wire = try decode(TuningInboxWire.DecisionResponse.self, from: data)
        XCTAssertFalse(wire.success)
        XCTAssertEqual(wire.code, "credential_unknown")
        let outcome = TuningInboxClient.outcome(status: status, data: data)
        XCTAssertEqual(outcome, .refused(status: 403, code: "credential_unknown"))
        guard case .refused(let refusalStatus, let code) = outcome else {
            return XCTFail("recorded refusal did not map to a definite refusal")
        }
        XCTAssertEqual(TuningInboxItemModel.refusalMessage(status: refusalStatus, code: code),
                       "This phone's presence key is not pinned on the runner yet.")
    }

    func testRecordedBodiesDecodeThroughRealClientListAndItemCalls() async throws {
        let listData = try body("mobile_list")
        let itemData = try body("mobile_detail")
        let listWire = try decode(TuningInboxWire.ListResponse.self, from: listData)
        let expectedItems = try listWire.items.map { try $0.validated() }
        let expectedDetail = try decode(TuningInboxWire.ItemResponse.self, from: itemData).item.validated()
        let client = TuningInboxClient(fixtureMode: FixtureMode(arguments: []),
                                      protocolClasses: [TuningHTTPStub.self], token: { "device-token" })
        TuningHTTPStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, TuningInboxClient.path)
            XCTAssertEqual(request.url?.query, "limit=20")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            return (200, listData)
        }
        let page = try await client.list(cursor: nil)
        XCTAssertEqual(page.items, expectedItems)
        XCTAssertEqual(page.nextCursor, listWire.nextCursor)

        TuningHTTPStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, TuningInboxClient.path)
            XCTAssertEqual(request.url?.query, "id=" + expectedDetail.summary.id)
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer device-token")
            return (200, itemData)
        }
        let detail = try await client.item(id: expectedDetail.summary.id)
        XCTAssertEqual(detail, expectedDetail)
    }
}
