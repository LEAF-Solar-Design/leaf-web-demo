import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

private final class EnginesStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    static var requests: [URLRequest] = []
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            Self.requests.append(request)
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                httpVersion: nil, headerFields: status == 301 ? ["Location": "https://example.invalid/redirect"] : nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

final class EnginesClientTests: XCTestCase {
    override func tearDown() {
        for request in EnginesStub.requests {
            let expectsRuntime = request.httpMethod == "GET" && request.url?.path == "/api/leafhft/mobile/engines"
            XCTAssertEqual(request.value(forHTTPHeaderField: "x-kashbot-engine-runtime"), expectsRuntime ? "1" : nil)
        }
        for request in EnginesStub.requests where request.httpMethod == "POST" {
            XCTAssertTrue(["/api/leafhft/mobile/control", "/api/leafhft/mobile/engine-lab"].contains(request.url?.path ?? ""))
            XCTAssertEqual(request.url?.host, DashboardClient.baseURL.host)
        }
        EnginesStub.handler = nil
        EnginesStub.requests = []
        super.tearDown()
    }

    private func client() -> DashboardClient {
        DashboardClient(protocolClasses: [EnginesStub.self], token: { "test-token" },
                        sleep: { _ in XCTFail("Control must not retry") })
    }

    private func bodyBytes(_ request: URLRequest) throws -> Data {
        if let bytes = request.httpBody { return bytes }
        let stream = try XCTUnwrap(request.httpBodyStream)
        stream.open()
        defer { stream.close() }
        var bytes = Data()
        var buffer = [UInt8](repeating: 0, count: 1024)
        while true {
            let count = stream.read(&buffer, maxLength: buffer.count)
            guard count >= 0 else { throw URLError(.cannotDecodeContentData) }
            if count == 0 { return bytes }
            bytes.append(contentsOf: buffer.prefix(count))
        }
    }

    private func body(_ request: URLRequest) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: bodyBytes(request)) as? [String: Any])
    }

    /// Posts `intent` once and returns the exact body bytes the control route received.
    private func postedBody(_ intent: ControlIntent, response: String) async throws -> String {
        var posted: Data?
        EnginesStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/control")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-token")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Content-Type"), "application/json")
            posted = try self.bodyBytes(request)
            return (200, Data(response.utf8))
        }
        _ = try await client().control(intent, note: nil)
        XCTAssertEqual(EnginesStub.requests.count, 1)
        return String(decoding: try XCTUnwrap(posted), as: UTF8.self)
    }

    private let goldenRequestId = "11111111-1111-4111-8111-111111111111"

    func testEnginesGETFixture() async throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "engines", withExtension: "json", subdirectory: "Fixtures"))
        let fixture = try Data(contentsOf: url)
        EnginesStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/engines")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-token")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Accept"), "application/json")
            XCTAssertEqual(request.value(forHTTPHeaderField: "x-kashbot-engine-runtime"), "1")
            XCTAssertNil(request.value(forHTTPHeaderField: "Cache-Control"))
            return (200, fixture)
        }
        let response = try await client().engines()
        XCTAssertEqual(response.engines?.count, 2)
        XCTAssertEqual(response.bindings?.symbols?["BTC-15M"], "aggressive")
        XCTAssertEqual(EnginesStub.requests.count, 1)
    }

    func testEngineLabGETUsesV3AndNoCache() async throws {
        let data = Data(EngineLab.previewResponseJSON.utf8)
        EnginesStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/engine-lab")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-token")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Cache-Control"), "no-cache, no-store")
            return (200, data)
        }
        let result = try await client().engineLab()
        XCTAssertEqual(result.schemaVersion, 3)
        XCTAssertTrue(result.candidates.contains { $0.id == "atlas-discovery" })
        XCTAssertEqual(result.owner(for: "dip-recovery"), "Research team")
        XCTAssertEqual(EnginesStub.requests.count, 1)
    }

    func testEngineLabAdvisoryPostKeepsIdentityAndNeverCallsControl() async throws {
        let input = try EngineLab.EventInput(engineId: "dip-recovery", kind: "decision",
            payload: ["action": "hold", "reason": "More holdout evidence needed"])
        EnginesStub.handler = { request in
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/engine-lab")
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-token")
            let body = try self.body(request)
            XCTAssertEqual(body["client_request_id"] as? String, input.clientRequestId)
            XCTAssertEqual(body["payload"] as? [String: String], input.payload)
            XCTAssertNil(body["actor"])
            let event: [String: Any] = ["id": UUID().uuidString, "client_request_id": input.clientRequestId,
                "engine_id": input.engineId, "kind": input.kind, "payload": input.payload,
                "actor": ["device_id": UUID().uuidString, "device_name": "Test phone"],
                "created_at": "2026-09-20T12:00:00Z", "advisory": true]
            return (200, try JSONSerialization.data(withJSONObject: ["advisory": true, "event": event]))
        }
        let result = try await client().engineLabEvent(input)
        XCTAssertEqual(result.payload["action"], "hold")
        XCTAssertTrue(result.advisory)
        XCTAssertEqual(EnginesStub.requests.count, 1)
    }

    func testEngineLabRejectsLegacySchemaAndDoesNotRetryPosts() async throws {
        EnginesStub.handler = { _ in (200, Data(EngineLab.bundledNotesJSON.utf8)) }
        do { _ = try await client().engineLab(); XCTFail("Expected v3 contract") }
        catch { XCTAssertEqual(error as? DashboardClientError, .decoding) }
        EnginesStub.requests = []
        EnginesStub.handler = { _ in (409, Data(#"{"error":"Conflict"}"#.utf8)) }
        let input = try EngineLab.EventInput(engineId: "dip-recovery", kind: "comment", payload: ["text": "Review this trial"])
        do { _ = try await client().engineLabEvent(input); XCTFail("Expected refusal") }
        catch { XCTAssertEqual(error as? DashboardClientError, .http(409)) }
        XCTAssertEqual(EnginesStub.requests.count, 1)
    }

    func testEngineHistoryGETPreservesScopeAndDecodesDates() async throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "engine-history", withExtension: "json", subdirectory: "Fixtures"))
        let fixture = try Data(contentsOf: url)
        EnginesStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/engine-history")
            let query = URLComponents(url: try XCTUnwrap(request.url), resolvingAgainstBaseURL: false)?.queryItems
            XCTAssertEqual(query?.first { $0.name == "range" }?.value, "month")
            XCTAssertEqual(query?.first { $0.name == "engine_id" }?.value, "default")
            return (200, fixture)
        }
        let response = try await client().engineHistory(range: .month, engineId: "default")
        XCTAssertEqual(response.schemaVersion, 1)
        XCTAssertEqual(response.performance().summary.realizedPnlCents, 300)
    }

    func testOnlyControlTargetReceivesPOST() async throws {
        let intents = [try ControlIntent.bind(symbol: "BTC-15M", engineId: "aggressive"),
                       try ControlIntent.set(engineId: "default", key: "min_k", value: 12),
                       try ControlIntent.create(engineId: "aggr-2", name: "Aggressive 2", from: "default")]
        let dashboard = client()
        for intent in intents {
            EnginesStub.handler = { request in
                XCTAssertEqual(request.httpMethod, "POST")
                XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/control")
                XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-token")
                XCTAssertEqual(request.value(forHTTPHeaderField: "Content-Type"), "application/json")
                let body = try self.body(request)
                XCTAssertEqual(body["kind"] as? String, intent.kind.rawValue)
                XCTAssertEqual(body["value"] as? String, intent.value.displayValue)
                XCTAssertEqual(body["note"] as? String, "Phone request")
                XCTAssertNil(body["scope"])
                XCTAssertNil(body["client_request_id"])
                XCTAssertNil(body["expected_revision"])
                return (200, Data(#"{"request":{"id":"request-1","state":"pending","requested_at":"2026-09-13T00:00:00Z"}}"#.utf8))
            }
            let response = try await dashboard.control(intent, note: "Phone request")
            XCTAssertEqual(response.request?.id, "request-1")
        }
        XCTAssertEqual(EnginesStub.requests.count, 3)
    }

    func testAccountConfigurePOSTUsesStructuredScopeAndIdempotency() async throws {
        let clientId = "11111111-1111-4111-8111-111111111111"
        let intent = try ControlIntent.configure(engineId: "default", host: "sample-runner",
            scope: try .account("sample-main"), enabled: .value(false),
            set: ["edge_threshold_cents": 4.5], expectedRevision: "opaque-r1", clientRequestId: clientId)
        EnginesStub.handler = { request in
            let body = try self.body(request)
            XCTAssertEqual(body["host"] as? String, "sample-runner")
            XCTAssertEqual(body["venue"] as? String, "kalshi")
            XCTAssertEqual(body["kind"] as? String, "engine.configure")
            XCTAssertEqual(body["client_request_id"] as? String, clientId)
            XCTAssertEqual(body["expected_revision"] as? String, "opaque-r1")
            let scope = try XCTUnwrap(body["scope"] as? [String: Any])
            XCTAssertEqual(scope["kind"] as? String, "account")
            XCTAssertEqual(scope["account_id"] as? String, "sample-main")
            let value = try XCTUnwrap(body["value"] as? [String: Any])
            XCTAssertEqual(value["engine_id"] as? String, "default")
            XCTAssertEqual(value["enabled"] as? Bool, false)
            XCTAssertEqual((value["set"] as? [String: Any])?["edge_threshold_cents"] as? Double, 4.5)
            return (200, Data("""
                {"request":{"id":"request-1","kind":"engine.configure","value":{"engine_id":"default","enabled":false,"set":{"edge_threshold_cents":4.5}},"scope":{"kind":"account","account_id":"sample-main"},"client_request_id":"\(clientId)","state":"requested","requested_at":"2026-09-16T12:00:00Z"}}
                """.utf8))
        }
        let response = try await client().control(intent, note: nil)
        XCTAssertEqual(response.request?.clientRequestId, clientId)
        XCTAssertEqual(response.request?.scope, try .account("sample-main"))
        XCTAssertEqual(EnginesStub.requests.count, 1)
    }

    func testRefusalsVerbatimWithoutRetry() async throws {
        let dashboard = client()
        let intent = try ControlIntent.bind(symbol: nil, engineId: "default")
        for status in [429, 409, 400, 422] {
            let before = EnginesStub.requests.count
            EnginesStub.handler = { _ in (status, Data(#"{"error":"cooldown: 11 min left"}"#.utf8)) }
            do { _ = try await dashboard.control(intent, note: nil); XCTFail("Expected refusal") }
            catch { XCTAssertEqual(error as? DashboardClientError, .refused("cooldown: 11 min left")) }
            XCTAssertEqual(EnginesStub.requests.count, before + 1)
        }
    }

    func testCooldownRetryAfterRoundsUpToMinutesWithoutRetry() async throws {
        let dashboard = client()
        let intent = try ControlIntent.bind(symbol: nil, engineId: "default")
        for retryAfterMs in [660000, 600001] {
            let before = EnginesStub.requests.count
            EnginesStub.handler = { _ in
                (429, Data("{\"error\":\"cooldown\",\"retry_after_ms\":\(retryAfterMs)}".utf8))
            }
            do { _ = try await dashboard.control(intent, note: nil); XCTFail("Expected refusal") }
            catch { XCTAssertEqual(error as? DashboardClientError, .refused("cooldown (retry in 11 min)")) }
            XCTAssertEqual(EnginesStub.requests.count, before + 1)
        }
    }

    func testControlRedirectRefused() async throws {
        EnginesStub.handler = { _ in (301, Data()) }
        do {
            _ = try await client().control(try .bind(symbol: nil, engineId: "default"), note: nil)
            XCTFail("Expected redirect refusal")
        } catch { XCTAssertEqual(error as? DashboardClientError, .http(301)) }
        XCTAssertEqual(EnginesStub.requests.count, 1)
        let session = URLSession(configuration: .ephemeral)
        defer { session.invalidateAndCancel() }
        let request = URLRequest(url: DashboardClient.baseURL)
        let response = try XCTUnwrap(HTTPURLResponse(url: DashboardClient.baseURL, statusCode: 301, httpVersion: nil, headerFields: nil))
        DashboardRedirectDelegate().urlSession(session, task: session.dataTask(with: request),
            willPerformHTTPRedirection: response, newRequest: request) { XCTAssertNil($0) }
    }

    func testRequestStatesUseGET() async throws {
        EnginesStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.url?.path, "/api/leafhft/mobile/control")
            return (200, Data(#"{"requests":[{"id":"request-1","state":"applied"}]}"#.utf8))
        }
        let requests = try await client().controlRequests()
        XCTAssertEqual(requests.first?.state, "applied")
    }

    func testEnginesGETDecodesAdditiveLifecycleFields() async throws {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "engines", withExtension: "json", subdirectory: "Fixtures"))
        let fixture = try Data(contentsOf: url)
        EnginesStub.handler = { _ in (200, fixture) }
        let response = try await client().engines()
        let probing = try XCTUnwrap(response.engines?.first { $0.engineId == "aggressive" })
        XCTAssertEqual(probing.lifecycle?.state, .probe)
        XCTAssertEqual(probing.lifecycle?.breaker?.enginePct, 50)
        XCTAssertEqual(probing.assignment?.role, "probe")
        XCTAssertEqual(probing.probeToday?.tickets, 41)
        XCTAssertEqual(probing.eligibleToProbe?.eligible, false)
        // An older engine row without any lifecycle block still decodes.
        XCTAssertNil(response.engines?.first { $0.engineId == "default" }?.lifecycle)
    }

    /// The engines route's exact shape with the runtime extension (header on), from the Core fixture corpus.
    private func serverRuntimeFixture() throws -> Data {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "engines-runtime-server", withExtension: "json", subdirectory: "Fixtures"))
        return try Data(contentsOf: url)
    }

    @MainActor func testEnginesGETDecodesServerRuntimeShape() async throws {
        let fixture = try serverRuntimeFixture()
        EnginesStub.handler = { _ in (200, fixture) }
        let response = try await client().engines()
        let engines = try XCTUnwrap(response.engines)
        XCTAssertEqual(engines.map(\.engineId), ["aggr-2", "fast", "default"])
        let now = try XCTUnwrap(ISO8601DateFormatter().date(from: "2026-09-27T15:04:05Z"))
        let accounts = response.accounts ?? []
        func chip(_ engine: Engine) -> String {
            EngineLifecycleChip.text(engine.lifecycle, eligibility: engine.eligibleToProbe, now: now)
        }
        func account(_ engine: Engine) -> (text: String, tone: LeafTone) {
            EngineAccountChip.text(engine: engine, accounts: accounts,
                boundAccountIds: EngineAccountChip.boundAccountIds(engine: engine, board: nil))
        }

        let aggr = engines[0]
        XCTAssertEqual(chip(aggr), "Halted: This engine's day loss reached 50% of the day-start portfolio., operator_halt")
        XCTAssertEqual(EngineRuntimeText.breaker(aggr), "Breaker: Not reported")
        XCTAssertEqual(account(aggr).text, "Subaccount 1 · opbox-1")
        XCTAssertEqual(account(aggr).tone, .neutral)
        XCTAssertEqual(EngineRuntimeText.perContract(aggr), "Live: +3.2c per contract · n 41 over 5 days")
        XCTAssertEqual(EngineRuntimeText.probeDay(aggr.probeToday), "Probe day 2026-09-27 (UTC): \u{2212}$12.40 · 11 tickets")
        XCTAssertEqual(aggr.eligibleToProbe?.eligible, true)

        let fast = engines[1]
        XCTAssertEqual(chip(fast), "Probing")
        XCTAssertEqual(account(fast).text, "Another account")
        XCTAssertEqual(account(fast).tone, .stale)
        XCTAssertEqual(EngineRuntimeText.breaker(fast), "Breaker: Not reported")
        XCTAssertEqual(EngineRuntimeText.perContract(fast), "Live: Not reported")
        XCTAssertNil(EngineRuntimeText.probeDay(fast.probeToday))
        XCTAssertEqual(fast.eligibleToProbe?.eligible, false)

        let baseline = engines[2]
        XCTAssertEqual(chip(baseline), "No lifecycle")
        XCTAssertEqual(account(baseline).text, "Unassigned")
        XCTAssertEqual(account(baseline).tone, .stale)
        XCTAssertEqual(EngineRuntimeText.perContract(baseline), "Live: Not reported")
        XCTAssertNil(baseline.eligibleToProbe)
    }

    @MainActor func testMissingAndUnknownLifecycleChips() throws {
        let unknown = try JSONDecoder().decode(EngineLifecycle.self, from: Data(#"{"state":"unknown"}"#.utf8))
        let now = Date()
        let ineligible = ProbeEligibility(eligible: false, reasons: [])
        let eligible = ProbeEligibility(eligible: true, reasons: [])
        XCTAssertEqual(EngineLifecycleChip.kind(nil, eligibility: ineligible, now: now), .noLifecycle)
        XCTAssertEqual(EngineLifecycleChip.text(nil, eligibility: ineligible, now: now), "No lifecycle")
        XCTAssertEqual(EngineLifecycleChip.kind(unknown, eligibility: ineligible, now: now), .notReported)
        XCTAssertEqual(EngineLifecycleChip.text(unknown, eligibility: ineligible, now: now), "Lifecycle not reported")
        XCTAssertEqual(EngineLifecycleChip.text(nil, eligibility: eligible, now: now), "Tested")
        XCTAssertEqual(EngineLifecycleChip.text(unknown, eligibility: eligible, now: now), "Tested")
    }

    @MainActor func testBoundLifecycleChipsPreserveEligibilityAndProbeLabel() throws {
        let probing = try JSONDecoder().decode(EngineLifecycle.self, from: Data(#"{"state":"probe","label":"Probing"}"#.utf8))
        let now = Date()
        let ineligible = ProbeEligibility(eligible: false, reasons: [])
        let eligible = ProbeEligibility(eligible: true, reasons: [])
        XCTAssertEqual(EngineLifecycleChip.kind(nil, eligibility: ineligible, now: now), .noLifecycle)
        XCTAssertEqual(EngineLifecycleChip.text(nil, eligibility: ineligible, now: now), "No lifecycle")
        XCTAssertEqual(EngineLifecycleChip.text(nil, eligibility: eligible, now: now), "Tested")
        XCTAssertEqual(EngineLifecycleChip.kind(probing, eligibility: ineligible, now: now), .probing)
        XCTAssertEqual(EngineLifecycleChip.text(probing, eligibility: ineligible, now: now), "Probing")
    }

    @MainActor func testAssignmentsSummaryUsesBoardBindingsAndCountsUnassigned() throws {
        let engines = try JSONDecoder().decode([Engine].self, from: Data(#"""
        [
          {"engineId":"assigned","assignment":{"accountId":"a"}},
          {"engineId":"board-only"},
          {"engineId":"other","assignment":{"account":"other"}},
          {"engineId":"unassigned"},
          {"engineId":"empty","assignment":{"accountId":""}}
        ]
        """#.utf8))
        let board = try JSONDecoder().decode(ProbeBoardResponse.self, from: Data(#"""
        {"engines":[
          {"engineId":"assigned","assignment":{"accountId":"a"}},
          {"engineId":"assigned","assignment":{"accountId":"b"}},
          {"engineId":"board-only","assignment":{"accountId":"b"}},
          {"engineId":"board-only","assignment":{"accountId":"b"}},
          {"engineId":"empty","assignment":{"accountId":""}}
        ]}
        """#.utf8))
        let summary = EngineAccountChip.assignmentSummary(engines: engines, board: board)
        XCTAssertEqual(summary.engines.map(\.engineId), ["assigned", "board-only", "other"])
        XCTAssertEqual(summary.unassignedCount, 2)
        XCTAssertEqual(summary.boundAccountIds["assigned"], ["a", "b"])
        XCTAssertEqual(summary.boundAccountIds["board-only"], ["b"])
        XCTAssertEqual(summary.boundAccountIds["other"], [])
        for engine in summary.engines {
            XCTAssertEqual(summary.boundAccountIds[engine.engineId],
                           EngineAccountChip.boundAccountIds(engine: engine, board: board))
        }
        let withoutBoard = EngineAccountChip.assignmentSummary(engines: engines, board: nil)
        XCTAssertEqual(withoutBoard.engines.map(\.engineId), ["assigned", "other"])
        XCTAssertEqual(withoutBoard.unassignedCount, 3)
    }

    func testEnginesGETSurvivesMalformedRuntime() async throws {
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: serverRuntimeFixture()) as? [String: Any])
        var engines = try XCTUnwrap(object["engines"] as? [[String: Any]])
        XCTAssertEqual(engines.first?["engine_id"] as? String, "aggr-2")
        engines[0]["lifecycle"] = "halted"
        engines[0]["assignment"] = 5
        engines[0]["inputs"] = [["kind": 1]]
        engines[0]["markets"] = "BTC-15M"
        engines[0]["probeToday"] = [Any]()
        engines[0]["live"] = ["n": NSNull(), "days": 5] as [String: Any]
        engines[0]["eligibleToProbe"] = "yes"
        object["engines"] = engines
        let malformed = try JSONSerialization.data(withJSONObject: object)
        EnginesStub.handler = { _ in (200, malformed) }
        let response = try await client().engines()
        XCTAssertEqual(response.engines?.count, 3)
        XCTAssertNil(response.engines?.first?.lifecycle)
        XCTAssertEqual(response.engines?.first?.name, "Aggressive 2")
    }

    func testProbeControlBodyIsByteExact() async throws {
        let intent = try ControlIntent.probe(engineId: "aggr-2", symbols: ["BTC-15M", "ETH-15M"],
            approval: "sig.v1/AbC+dEf=", expiresAt: "2026-10-14T04:00:00Z", bind: true,
            clientRequestId: goldenRequestId)
        let posted = try await postedBody(intent, response: #"{"request":{"id":"request-1","kind":"engine.probe","value":{"engine_id":"aggr-2","symbols":["BTC-15M","ETH-15M"],"approval":"sig.v1/AbC+dEf=","expires_at":"2026-10-14T04:00:00Z","bind":true},"state":"requested"}}"#)
        XCTAssertEqual(posted, #"{"client_request_id":"11111111-1111-4111-8111-111111111111","kind":"engine.probe","value":{"approval":"sig.v1/AbC+dEf=","bind":true,"engine_id":"aggr-2","expires_at":"2026-10-14T04:00:00Z","symbols":["BTC-15M","ETH-15M"]},"venue":"kalshi"}"#)
    }

    func testHaltControlBodyIsByteExact() async throws {
        let intent = try ControlIntent.halt(engineId: "aggr-2", reason: "  Operator halt: spread widened ",
                                            clientRequestId: goldenRequestId)
        let posted = try await postedBody(intent, response: #"{"request":{"id":"request-1","state":"requested"}}"#)
        XCTAssertEqual(posted, #"{"client_request_id":"11111111-1111-4111-8111-111111111111","kind":"engine.halt","value":{"engine_id":"aggr-2","reason":"Operator halt: spread widened"},"venue":"kalshi"}"#)
    }

    func testBreakerControlBodyIsByteExact() async throws {
        let intent = try ControlIntent.breaker(scope: .account, id: "sample-main", pct: 40, clientRequestId: goldenRequestId)
        let posted = try await postedBody(intent, response: #"{"request":{"id":"request-1","state":"requested"}}"#)
        XCTAssertEqual(posted, #"{"client_request_id":"11111111-1111-4111-8111-111111111111","kind":"risk.breaker","value":{"id":"sample-main","pct":40,"scope":"account"},"venue":"kalshi"}"#)
    }

    func testControlResponsesDecodeLifecycleKindsAndUnknownKinds() async throws {
        let intent = try ControlIntent.halt(engineId: "aggr-2", reason: "Operator halt", clientRequestId: goldenRequestId)
        let cases: [(String, (ControlValue?) -> Bool)] = [
            (#"{"request":{"id":"r-1","kind":"engine.halt","value":{"engine_id":"aggr-2","reason":"Operator halt"},"state":"applied"}}"#,
             { if case let .halt(value)? = $0 { return value.engineId == "aggr-2" }; return false }),
            (#"{"request":{"id":"r-2","kind":"engine.teleport","value":{"engine_id":"aggr-2","warp":9},"state":"requested"}}"#,
             { if case .unknown? = $0 { return true }; return false }),
            (#"{"request":{"id":"r-3","kind":"engine.halt","value":"not a halt body","state":"rejected"}}"#,
             { if case .unknown? = $0 { return true }; return false })
        ]
        for (response, matches) in cases {
            EnginesStub.requests = []
            EnginesStub.handler = { _ in (200, Data(response.utf8)) }
            let decoded = try await client().control(intent, note: nil)
            XCTAssertTrue(matches(decoded.request?.value), response)
            XCTAssertEqual(EnginesStub.requests.count, 1)
        }
    }
}
