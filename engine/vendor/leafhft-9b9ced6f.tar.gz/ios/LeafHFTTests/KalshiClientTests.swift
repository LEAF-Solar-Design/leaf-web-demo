import Foundation
import Security
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class KalshiStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, data) = try XCTUnwrap(Self.handler)(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: try XCTUnwrap(request.url), statusCode: status,
                httpVersion: nil, headerFields: status == 301 ? ["Location": "https://example.invalid/redirect"] : nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

final class KalshiClientTests: XCTestCase {
    override func tearDown() { KalshiStub.handler = nil; super.tearDown() }

    private func signer() throws -> KalshiSigner {
        let attributes: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeySizeInBits as String: 2048, kSecAttrIsPermanent as String: false]
        var error: Unmanaged<CFError>?
        let generated = SecKeyCreateRandomKey(attributes as CFDictionary, &error)
        _ = error?.takeRetainedValue()
        let key = try XCTUnwrap(generated)
        error = nil
        let representation = SecKeyCopyExternalRepresentation(key, &error)
        _ = error?.takeRetainedValue()
        return try KalshiSigner(pkcs1DER: XCTUnwrap(representation) as Data)
    }

    func testGETHeadersAndSignatureExcludeQuery() async throws {
        let signer = try signer()
        let publicKey = try XCTUnwrap(signer.publicKey)
        KalshiStub.handler = { request in
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Accept"), "application/json")
            XCTAssertEqual(request.value(forHTTPHeaderField: "KALSHI-ACCESS-KEY"), "test-key-id")
            let timestamp = try XCTUnwrap(request.value(forHTTPHeaderField: "KALSHI-ACCESS-TIMESTAMP"))
            let signature = try XCTUnwrap(Data(base64Encoded: XCTUnwrap(request.value(forHTTPHeaderField: "KALSHI-ACCESS-SIGNATURE"))))
            let path = try XCTUnwrap(request.url?.path)
            XCTAssertNotNil(request.url?.query)
            let message = Data((timestamp + "GET" + path).utf8)
            var error: Unmanaged<CFError>?
            XCTAssertTrue(SecKeyVerifySignature(publicKey, .rsaSignatureMessagePSSSHA256,
                message as CFData, signature as CFData, &error))
            _ = error?.takeRetainedValue()
            return (200, Data(#"{"fills":[]}"#.utf8))
        }
        let client = KalshiClient(protocolClasses: [KalshiStub.self], credential: { ("test-key-id", signer) })
        let response = try await client.get(.fills(cursor: "cursor with spaces", limit: 25), as: FillsResponse.self)
        XCTAssertEqual(response.fills?.count, 0)
    }

    func testRedirectIsErrorAndDelegateRefusesIt() async throws {
        let signer = try signer()
        var requests = 0
        KalshiStub.handler = { _ in requests += 1; return (301, Data()) }
        let client = KalshiClient(protocolClasses: [KalshiStub.self], credential: { ("test-id", signer) })
        do { let _ = try await client.get(.balance, as: AccountBalance.self); XCTFail("Expected redirect rejection") }
        catch { XCTAssertEqual(error as? KalshiClientError, .http(301)) }
        XCTAssertEqual(requests, 1)
        let session = URLSession(configuration: .ephemeral)
        defer { session.invalidateAndCancel() }
        let request = URLRequest(url: KalshiGETEndpoint.origin)
        let response = try XCTUnwrap(HTTPURLResponse(url: KalshiGETEndpoint.origin, statusCode: 301, httpVersion: nil, headerFields: nil))
        KalshiRedirectDelegate().urlSession(session, task: session.dataTask(with: request),
            willPerformHTTPRedirection: response, newRequest: request) { XCTAssertNil($0) }
    }

    func testRateLimitIsBounded() async throws {
        let signer = try signer()
        var waits: [UInt64] = []
        var requests = 0
        KalshiStub.handler = { _ in requests += 1; return (429, Data()) }
        let client = KalshiClient(protocolClasses: [KalshiStub.self], credential: { ("test-id", signer) }, sleep: { waits.append($0) })
        do { let _ = try await client.get(.balance, as: AccountBalance.self); XCTFail("Expected rate limit") }
        catch { XCTAssertEqual(error as? KalshiClientError, .rateLimited) }
        XCTAssertEqual(requests, 4)
        XCTAssertEqual(waits, [2_000_000_000, 4_000_000_000, 8_000_000_000])
    }

    func testTypedFailures() async throws {
        let signer = try signer()
        let client = KalshiClient(protocolClasses: [KalshiStub.self], credential: { ("test-id", signer) })
        for (status, expected) in [(401, KalshiClientError.unauthorized), (500, .http(500)), (200, .decoding)] {
            KalshiStub.handler = { _ in (status, Data("invalid".utf8)) }
            do { let _ = try await client.get(.balance, as: AccountBalance.self); XCTFail("Expected typed error") }
            catch { XCTAssertEqual(error as? KalshiClientError, expected) }
        }
        KalshiStub.handler = { _ in throw URLError(.notConnectedToInternet) }
        do { let _ = try await client.get(.balance, as: AccountBalance.self); XCTFail("Expected transport error") }
        catch { XCTAssertEqual(error as? KalshiClientError, .transport) }
        let missing = KalshiClient(protocolClasses: [KalshiStub.self], credential: { throw KalshiClientError.noCredential })
        do { let _ = try await missing.get(.balance, as: AccountBalance.self); XCTFail("Expected missing credential") }
        catch { XCTAssertEqual(error as? KalshiClientError, .noCredential) }
    }
}
