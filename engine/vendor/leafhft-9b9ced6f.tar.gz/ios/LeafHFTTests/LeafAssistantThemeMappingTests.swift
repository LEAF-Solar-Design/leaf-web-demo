import SwiftUI
import UIKit
import XCTest
import LeafAssistantUI
@testable import LeafHFT

final class LeafAssistantThemeMappingTests: XCTestCase {
    @MainActor func testLeafMappingMatchesLeafThemeTokens() {
        let theme = LeafAssistantTheme.leaf
        let tokens: [(String, Color, UInt32, UInt32)] = [
            ("accent", theme.accent, 0xe6e8ec, 0x0b0d12),
            ("surface", theme.surface, 0x15181e, 0xffffff),
            ("userBubble", theme.userBubble, 0x232830, 0xf1f3f5),
            ("assistantBubble", theme.assistantBubble, 0x0c0e12, 0xf7f8fa),
            ("textPrimary", theme.textPrimary, 0xe6e8ec, 0x0b0d12),
            ("textSecondary", theme.textSecondary, 0x9aa1ac, 0x6b7280),
            ("danger", theme.danger, 0xf27a72, 0xb3261e),
            ("warning", theme.warning, 0xe0a94b, 0x95590a),
            ("success", theme.success, 0x4cc38a, 0x146c43),
            ("border", theme.border, 0x262b33, 0xe2e5ea)
        ]
        for (name, token, dark, light) in tokens {
            for (style, expected) in [(UIUserInterfaceStyle.dark, dark), (.light, light)] {
                assertColor(token, equals: expected, name: name, style: style)
            }
        }
        XCTAssertEqual(theme.cornerRadius, LeafTheme.radius)
        XCTAssertEqual(theme.cornerRadius, 12)
        XCTAssertEqual(theme.minimumTarget, 44)
        XCTAssertEqual(LeafAssistantTheme(minimumTarget: 20).minimumTarget, 44)
    }

    @MainActor private func assertColor(_ token: Color, equals expected: UInt32,
                                         name: String, style: UIUserInterfaceStyle,
                                         file: StaticString = #filePath, line: UInt = #line) {
        let color = UIColor(token).resolvedColor(with: UITraitCollection(userInterfaceStyle: style))
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        let message = "\(name), \(style)"
        XCTAssertTrue(color.getRed(&red, green: &green, blue: &blue, alpha: &alpha), message, file: file, line: line)
        let hex = (UInt32((red * 255).rounded()) << 16)
            | (UInt32((green * 255).rounded()) << 8)
            | UInt32((blue * 255).rounded())
        XCTAssertEqual(hex, expected, message, file: file, line: line)
        XCTAssertEqual(alpha, 1, accuracy: 0.001, message, file: file, line: line)
    }
}
