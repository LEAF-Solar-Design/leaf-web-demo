import Foundation
import XCTest
@testable import LeafHFT

final class LoadTimingsTests: XCTestCase {
    private let activation = Date(timeIntervalSince1970: 1000)

    private func at(_ milliseconds: Int) -> Date {
        activation.addingTimeInterval(Double(milliseconds) / 1000)
    }

    func testFixedRowOrder() {
        let timings = LoadTimings(kind: .cold, activatedAt: activation)
        XCTAssertEqual(timings.rows.map(\.id), ["status", "engines", "probes", "activity",
            "accountHistory", "exits", "calibration", "books", "engineLab", "kalshiBalance", "liveBoard"])
        XCTAssertTrue(timings.rows.allSatisfy { !$0.label.isEmpty && $0.liveAfterMs == nil &&
            $0.requestMs == nil && !$0.failed && $0.restoredAfterMs == nil })
        XCTAssertNil(timings.firstPollMs)
    }

    func testFirstCallsWinIncludingFailure() throws {
        var timings = LoadTimings(kind: .resume, activatedAt: activation)
        timings.recordLive(id: "books", startedAt: at(321), finishedAt: at(611), failed: true)
        timings.recordRestored(id: "books", at: at(38))
        timings.recordFirstPoll(finishedAt: at(812))
        let first = timings
        timings.recordLive(id: "books", startedAt: at(900), finishedAt: at(1000), failed: false)
        timings.recordRestored(id: "books", at: at(100))
        timings.recordFirstPoll(finishedAt: at(2000))
        XCTAssertEqual(timings, first)
        let row = try XCTUnwrap(timings.rows.first { $0.id == "books" })
        XCTAssertEqual(row.liveAfterMs, 611)
        XCTAssertEqual(row.requestMs, 290)
        XCTAssertEqual(row.restoredAfterMs, 38)
        XCTAssertTrue(row.failed)
        XCTAssertEqual(timings.firstPollMs, 812)
    }

    func testNegativeIntervalsClampAndUnknownIDsAreIgnored() throws {
        var timings = LoadTimings(kind: .cold, activatedAt: activation)
        let empty = timings
        timings.recordLive(id: "unknown", startedAt: at(10), finishedAt: at(20), failed: true)
        timings.recordRestored(id: "unknown", at: at(10))
        XCTAssertEqual(timings, empty)
        timings.recordLive(id: "status", startedAt: at(10), finishedAt: at(-10), failed: false)
        timings.recordRestored(id: "status", at: at(-20))
        timings.recordFirstPoll(finishedAt: at(-30))
        let row = try XCTUnwrap(timings.rows.first)
        XCTAssertEqual(row.liveAfterMs, 0)
        XCTAssertEqual(row.requestMs, 0)
        XCTAssertEqual(row.restoredAfterMs, 0)
        XCTAssertEqual(timings.firstPollMs, 0)
    }

    func testLogLineUsesFixedOrderAndOnlyRecordedValues() {
        var timings = LoadTimings(kind: .cold, activatedAt: activation)
        timings.recordLive(id: "liveBoard", startedAt: at(50), finishedAt: at(700), failed: false)
        timings.recordLive(id: "books", startedAt: at(321), finishedAt: at(611), failed: false)
        timings.recordLive(id: "status", startedAt: at(2), finishedAt: at(140), failed: false)
        timings.recordLive(id: "engines", startedAt: at(1), finishedAt: at(10003), failed: true)
        timings.recordRestored(id: "books", at: at(38))
        timings.recordFirstPoll(finishedAt: at(10010))
        XCTAssertEqual(timings.logLine,
            "loading kind=cold firstPoll=10010 status=140/138 engines=fail books=611/290 liveBoard=700 restored=books:38")
        XCTAssertNil(timings.rows.last?.requestMs)
        XCTAssertEqual(LoadTimings(kind: .resume, activatedAt: activation).logLine, "loading kind=resume")
    }

    func testDisplay() {
        var row = LoadTimings.Row(id: "books", label: "Books")
        XCTAssertEqual(LoadTimings.display(row), "waiting")
        row.restoredAfterMs = 38
        XCTAssertEqual(LoadTimings.display(row), "waiting · saved data at 38 ms")
        row.liveAfterMs = 611
        row.requestMs = 290
        XCTAssertEqual(LoadTimings.display(row), "611 ms (request 290 ms) · saved data at 38 ms")
        row.restoredAfterMs = nil
        XCTAssertEqual(LoadTimings.display(row), "611 ms (request 290 ms)")
        row.failed = true
        row.liveAfterMs = 10003
        XCTAssertEqual(LoadTimings.display(row), "failed after 10003 ms")
        row.restoredAfterMs = 38
        XCTAssertEqual(LoadTimings.display(row), "failed after 10003 ms · saved data at 38 ms")
        row.failed = false
        row.liveAfterMs = 700
        row.requestMs = nil
        row.restoredAfterMs = nil
        XCTAssertEqual(LoadTimings.display(row), "700 ms")
    }
}
