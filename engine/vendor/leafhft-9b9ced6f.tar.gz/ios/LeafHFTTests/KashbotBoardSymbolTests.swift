import XCTest
@testable import LeafHFT

final class KashbotBoardSymbolTests: XCTestCase {
    func testShortUsesSeriesAndCapsAtTwelveCharacters() {
        XCTAssertEqual(KashbotSymbol.short(ticker: "KXBTC-26SEP30-T100"), "KXBTC")
        XCTAssertEqual(KashbotSymbol.short(ticker: "KXFED"), "KXFED")
        XCTAssertEqual(KashbotSymbol.short(ticker: ""), "")
        XCTAssertEqual(KashbotSymbol.short(ticker: "ABCDEFGHIJKLM-X"), "ABCDEFGHIJKL")
    }

    func testDisplayedDuplicatesAppendLastSegmentBeforeTruncation() {
        XCTAssertEqual(KashbotSymbol.displayed(tickers: ["KXBTC-DAY-T100", "KXBTC-DAY-T90", "KXFED-X"]),
                       ["KXBTC T100", "KXBTC T90", "KXFED"])
        XCTAssertEqual(KashbotSymbol.displayed(tickers: ["ABCDEFGHIJ-A123", "ABCDEFGHIJ-B123"]),
                       ["ABCDEFGHIJ A", "ABCDEFGHIJ B"])
        XCTAssertEqual(KashbotSymbol.displayed(tickers: ["KXBTC-DAY-T100"]), ["KXBTC"])
        XCTAssertEqual(KashbotSymbol.displayed(tickers: []), [])
    }
}
