import Foundation
import XCTest
@testable import LeafHFT

@MainActor final class MushyPrefillTests: XCTestCase {
    private func withState(_ body: (MushyState, UserDefaults) throws -> Void) rethrows {
        let suite = "MushyPrefillTests." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite); MushyStub.handler = nil }
        var calls = 0
        let mode = FixtureMode(arguments: [])
        let client = MushyClient(fixtureMode: mode, protocolClasses: [MushyStub.self], token: {
            calls += 1
            return "test-device"
        })
        MushyStub.handler = { _ in
            XCTFail("Prefill must not issue a network request")
            throw URLError(.unsupportedURL)
        }
        let state = MushyState(fixtureMode: mode, client: client, defaults: defaults)
        try body(state, defaults)
        XCTAssertEqual(calls, 0)
        XCTAssertNil(state.pending)
        XCTAssertNil(state.result)
        XCTAssertNil(state.error)
        XCTAssertTrue(state.snapshot.jobs.isEmpty)
    }

    func testEmptyPrefillPersistsWithoutClientCalls() throws {
        try withState { state, defaults in
            state.prompt = " \n "
            state.offerPrefill("Workshop context")
            XCTAssertEqual(state.prompt, "Workshop context")
            XCTAssertNil(state.offeredPrefill)
            let data = try XCTUnwrap(defaults.data(forKey: MushyState.recoveryKey))
            let recovery = try MushyCoding.decoder().decode(MushyRecovery.self, from: data)
            XCTAssertEqual(recovery.input, "Workshop context")
            XCTAssertNil(recovery.pending)
        }
    }

    func testRepeatedOfferOfSameTextShowsNoBanner() {
        withState { state, _ in
            state.prompt = ""
            state.offerPrefill("Workshop context")
            state.offerPrefill("Workshop context")
            XCTAssertEqual(state.prompt, "Workshop context")
            XCTAssertNil(state.offeredPrefill)
        }
    }

    func testExistingDraftRequiresExplicitReplacementWithoutClientCalls() {
        withState { state, _ in
            state.prompt = "My unsent draft"
            state.offerPrefill("Workshop context")
            XCTAssertEqual(state.prompt, "My unsent draft")
            XCTAssertEqual(state.offeredPrefill, "Workshop context")
            state.acceptPrefill()
            XCTAssertEqual(state.prompt, "Workshop context")
            XCTAssertNil(state.offeredPrefill)
        }
    }

    func testDismissPrefillKeepsDraftWithoutClientCalls() {
        withState { state, _ in
            state.prompt = "My unsent draft"
            state.offerPrefill("Workshop context")
            state.dismissPrefill()
            state.acceptPrefill()
            XCTAssertEqual(state.prompt, "My unsent draft")
            XCTAssertNil(state.offeredPrefill)
        }
    }

    func testPendingRequestAndExactBytesSurvivePrefill() throws {
        let suite = "MushyPrefillPending." + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let request = MushyPendingRequest(requestId: UUID().uuidString, kind: .turn,
            path: "/turn", body: Data("saved request bytes".utf8))
        var recovery = MushyRecovery()
        recovery.input = "Saved request"
        recovery.pending = request
        let saved = try MushyCoding.encoder().encode(recovery)
        defaults.set(saved, forKey: MushyState.recoveryKey)
        var calls = 0
        let mode = FixtureMode(arguments: [])
        let client = MushyClient(fixtureMode: mode, token: { calls += 1; return "test-device" })
        let state = MushyState(fixtureMode: mode, client: client, defaults: defaults)
        state.offerPrefill("Workshop context")
        state.acceptPrefill()
        XCTAssertEqual(state.offeredPrefill, "Workshop context")
        state.dismissPrefill()
        XCTAssertEqual(state.prompt, "Saved request")
        XCTAssertEqual(state.pending, request)
        XCTAssertEqual(defaults.data(forKey: MushyState.recoveryKey), saved)
        XCTAssertEqual(calls, 0)
    }
}
