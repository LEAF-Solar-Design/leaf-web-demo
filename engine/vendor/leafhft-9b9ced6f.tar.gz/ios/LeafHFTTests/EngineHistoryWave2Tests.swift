import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class EngineHistoryWave2Tests: XCTestCase {
    @MainActor func testCompleteCoverageHasNoCaveat() throws {
        XCTAssertNil(EngineHistoryView.coverageCaveat(try coverage()))
    }

    @MainActor func testUnassignedCoverageNamesPeriodAndPreservesCount() throws {
        XCTAssertEqual(EngineHistoryView.coverageCaveat(try coverage(unassigned: 76)),
            "Period coverage: 76 unassigned tickets; history may be incomplete.")
    }

    @MainActor func testMissingPnlIsPartial() throws {
        XCTAssertEqual(EngineHistoryView.coverageCaveat(try coverage(missing: 3)),
            "Period coverage: 3 results missing P&L; total is partial.")
    }

    @MainActor func testDroppedTruncatedAndUnknownCoverageStayVisible() throws {
        for value in [try coverage(dropped: "true"), try coverage(truncated: true),
                      try coverage(dropped: "null"), try coverage(unassigned: 1, missing: 2)] {
            XCTAssertNotNil(EngineHistoryView.coverageCaveat(value))
        }
    }

    @MainActor func testRowLabelsPreferReportedNameAndFallBackWithoutInventingOne() {
        XCTAssertEqual(EngineHistoryView.rowLabel(name: "Main subaccount", id: "raw-account", fallback: "Not reported"), "Main subaccount")
        XCTAssertEqual(EngineHistoryView.rowLabel(name: "Default", id: "default-id", fallback: "Not reported"), "Default")
        XCTAssertEqual(EngineHistoryView.rowLabel(name: nil, id: "raw-id", fallback: "Not reported"), "raw-id")
        XCTAssertEqual(EngineHistoryView.rowLabel(name: "  ", id: "raw-id", fallback: "Not reported"), "raw-id")
        XCTAssertEqual(EngineHistoryView.rowLabel(name: nil, id: nil, fallback: "Not reported"), "Not reported")
    }

    @MainActor func testAccountLabelsUseFixtureLabelsAndKeepUnassignedSeparate() async throws {
        let history = try await EngineHistoryView.fetch(range: .week, engineId: nil, fixture: true)
        XCTAssertEqual(EngineHistoryView.accountName("sample-main", history: history), "Main subaccount (sample)")
        XCTAssertEqual(EngineHistoryView.accountName("unknown-account", history: history), "unknown-account")
        XCTAssertEqual(EngineHistoryView.accountName(nil, history: history), "Unassigned")
    }

    private func coverage(unassigned: Int = 0, missing: Int = 0,
                          dropped: String = "false", truncated: Bool = false) throws -> EngineHistoryCoverage {
        let json = """
        {"scope":"ingested_tickets","ticketsDropped":\(dropped),"truncated":\(truncated),
         "unassignedN":\(unassigned),"missingPnlN":\(missing)}
        """
        return try JSONDecoder().decode(EngineHistoryCoverage.self, from: Data(json.utf8))
    }
}
