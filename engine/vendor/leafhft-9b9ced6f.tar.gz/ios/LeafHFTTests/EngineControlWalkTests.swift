import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class EngineControlWalkTests: XCTestCase {
    @MainActor func testConfigureRejectsThenAppliesWithoutLiveAccess() async throws {
        let mode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_CONTROL_WALK", "1"])
        let state = AppState(fixtureMode: mode, bundle: Bundle(for: Self.self))
        let original = try XCTUnwrap(state.engines?.engines?.first { $0.engineId == "default" })
        let revision = try XCTUnwrap(original.configuration?.global.revision)
        let first = try ControlIntent.configure(engineId: "default", host: "sample-runner", scope: .global,
            set: ["size_fraction": 0.2, "min_k": 15], expectedRevision: revision, clientRequestId: UUID().uuidString)
        let firstResult = await state.submit(first, note: nil)
        XCTAssertNil(firstResult)
        XCTAssertEqual(state.pendingRequests.count, 1)
        XCTAssertEqual(state.pendingRequests.last?.id, "fixture-request-1")
        XCTAssertEqual(state.pendingRequests.last?.state, "rejected")
        XCTAssertEqual(state.pendingRequests.last?.clientRequestId, first.clientRequestId)
        XCTAssertEqual(state.pendingRequests.last?.value, first.value)
        XCTAssertEqual(state.pendingRequests.last?.scope, .global)
        XCTAssertEqual(state.pendingRequests.last?.note, "Sample rejection: the runner refused this change.")
        XCTAssertEqual(state.engines?.engines?.first?.configuration?.global.revision, revision)
        XCTAssertFalse(state.submittingControl)
        XCTAssertFalse(state.controlOutcomeUnknown)

        let second = try ControlIntent.configure(engineId: "default", host: "sample-runner", scope: .global,
            set: ["size_fraction": 0.2, "min_k": 15], expectedRevision: revision, clientRequestId: UUID().uuidString)
        let secondResult = await state.submit(second, note: "Sample change")
        XCTAssertNil(secondResult)
        XCTAssertEqual(state.pendingRequests.count, 2)
        XCTAssertEqual(state.pendingRequests.last?.id, "fixture-request-2")
        XCTAssertEqual(state.pendingRequests.last?.state, "applied")
        XCTAssertEqual(state.pendingRequests.last?.clientRequestId, second.clientRequestId)
        XCTAssertNotNil(state.pendingRequests.last?.appliedAt)
        XCTAssertEqual(state.engines?.engines?.first?.configuration?.global.policy?["size_fraction"], 0.2)
        XCTAssertEqual(state.engines?.engines?.first?.configuration?.global.policy?["min_k"], 15)
        XCTAssertEqual(state.engines?.engines?.first?.configuration?.global.revision, "\(revision)-applied-2")
        XCTAssertNotNil(state.enginesObservedAt)
        XCTAssertFalse(state.submittingControl)
        XCTAssertFalse(state.controlOutcomeUnknown)
    }

    @MainActor func testProbeAndHaltWalkRequestedRejectedRequestedApplied() async throws {
        let mode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1", "-LEAFHFT_CONTROL_WALK", "1"])
        let state = AppState(fixtureMode: mode, bundle: Bundle(for: Self.self))
        let intents: [(String, () throws -> ControlIntent)] = [
            ("engine.probe", {
                try ControlIntent.probe(engineId: "aggr-2", symbols: ["BTC-15M"], approval: "fixture-approval",
                    expiresAt: "2026-10-14T04:00:00Z", bind: true, clientRequestId: UUID().uuidString)
            }),
            ("engine.halt", {
                try ControlIntent.halt(engineId: "aggressive", reason: "Sample halt", clientRequestId: UUID().uuidString)
            })
        ]
        var expectedCount = 0
        for (kind, make) in intents {
            for expectedTerminal in ["rejected", "applied"] {
                let intent = try make()
                let result = await state.submit(intent, note: "Sample \(kind)")
                XCTAssertNil(result)
                expectedCount += 1
                XCTAssertEqual(state.pendingControls.count, expectedCount)
                let requested = try XCTUnwrap(state.pendingControls.last)
                XCTAssertEqual(requested.kind, kind)
                XCTAssertEqual(requested.state, "requested")
                XCTAssertEqual(requested.clientRequestId, intent.clientRequestId)
                XCTAssertEqual(requested.value, intent.value)
                XCTAssertNil(requested.appliedAt)
                XCTAssertFalse(state.submittingControl)
                XCTAssertFalse(state.controlOutcomeUnknown)

                await state.refreshDashboard()
                let settled = try XCTUnwrap(state.pendingControls.last)
                XCTAssertEqual(settled.id, requested.id)
                XCTAssertEqual(settled.state, expectedTerminal)
                if expectedTerminal == "rejected" {
                    XCTAssertEqual(settled.note, "Sample rejection: the runner refused this change.")
                    XCTAssertNil(settled.appliedAt)
                } else {
                    XCTAssertEqual(settled.note, "Sample \(kind)")
                    XCTAssertNotNil(settled.appliedAt)
                }
                XCTAssertFalse(state.controlOutcomeUnknown)
            }
        }
        XCTAssertEqual(state.pendingControls.map(\.state), ["rejected", "applied", "rejected", "applied"])
        // A settled walk stays settled on the next refresh.
        await state.refreshDashboard()
        XCTAssertEqual(state.pendingControls.map(\.state), ["rejected", "applied", "rejected", "applied"])
    }

    @MainActor func testFixtureModeLoadsProbeBoardAndExtendedFixtures() throws {
        let state = AppState(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]), bundle: Bundle(for: Self.self))
        XCTAssertNil(state.kalshiError)
        let board = try XCTUnwrap(state.probeBoard)
        XCTAssertFalse(state.probeBoardNotReported)
        XCTAssertNotNil(state.probeBoardObservedAt)
        XCTAssertEqual(board.engines.map(\.engineId), ["aggr-2", "future-engine"])
        XCTAssertEqual(board.account?.dayStartMarkedCents, 250000)
        XCTAssertEqual(state.engines?.engines?.first { $0.engineId == "aggressive" }?.lifecycle?.state, .probe)
        let executor = try XCTUnwrap(state.books?.books.compactMap(\.kalshiBook.executor).first)
        XCTAssertEqual(executor.incumbentEngineId, "default")
        XCTAssertEqual(executor.engines.map(\.engineId), ["default", "aggressive"])
    }

    func testProbeBoardFillsOnlyMissingEngineFields() throws {
        let engines = try accountJSONDecoder().decode(EnginesResponse.self, from: Data(#"""
            {"engines":[{"engine_id":"aggr-2","name":"Aggressive 2"},
                        {"engine_id":"aggressive","lifecycle":{"state":"halted"}},
                        {"engine_id":"default"}]}
            """#.utf8))
        let board = try accountJSONDecoder().decode(ProbeBoardResponse.self, from: Data(#"""
            {"engines":[{"engine_id":"aggr-2","lifecycle":{"state":"probe"},"assignment":{"role":"probe"},
                         "probe_today":{"tickets":41},"live":{"n":41,"days":7}},
                        {"engine_id":"aggressive","lifecycle":{"state":"probe"},"assignment":{"role":"probe"}},
                        {"engine_id":"not-listed","lifecycle":{"state":"probe"}}]}
            """#.utf8))
        let merged = try XCTUnwrap(AppState.mergingProbeBoard(board, into: engines).engines)
        XCTAssertEqual(merged.map(\.engineId), ["aggr-2", "aggressive", "default"])
        XCTAssertEqual(merged[0].lifecycle?.state, .probe)
        XCTAssertEqual(merged[0].assignment?.role, "probe")
        XCTAssertEqual(merged[0].probeToday?.tickets, 41)
        XCTAssertEqual(merged[0].live?.days, 7)
        XCTAssertEqual(merged[1].lifecycle?.state, .halted, "the engines route wins over the board")
        XCTAssertEqual(merged[1].assignment?.role, "probe")
        XCTAssertNil(merged[2].lifecycle)
    }

    @MainActor func testPreviewStillBlocksControls() async throws {
        let mode = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])
        let state = AppState(fixtureMode: mode, bundle: Bundle(for: Self.self))
        let intent = try ControlIntent.configure(engineId: "default", host: "sample-runner", scope: .global,
            set: ["min_k": 15], expectedRevision: "global-default-r1", clientRequestId: UUID().uuidString)
        let result = await state.submit(intent, note: nil)
        XCTAssertEqual(result, "Controls are disabled in fixture mode.")
        XCTAssertTrue(state.pendingRequests.isEmpty)
        XCTAssertFalse(FixtureMode(arguments: ["-LEAFHFT_CONTROL_WALK", "1"]).controlWalk)
    }
}
