import Foundation
import SwiftUI
import UIKit
import XCTest
@testable import LeafHFT

private final class V2Transport: TuningInboxTransport {
    var detail: TuningInboxDetail
    var submitted: [TuningDecisionRequest] = []
    init(_ detail: TuningInboxDetail) { self.detail = detail }
    func list(cursor: String?) async throws -> TuningInboxPage { TuningInboxPage(items: [detail.summary], nextCursor: nil) }
    func item(id: String) async throws -> TuningInboxDetail { detail }
    func submitDecision(_ request: TuningDecisionRequest) async throws -> TuningDecisionOutcome {
        submitted.append(request)
        return .accepted(code: "approved")
    }
}

@MainActor final class TuningInboxV2Tests: XCTestCase {
    private static let fixtureSHA256 = "e10f8aff9d017f093d94bc9212406409d68b26e7fd45c8ad4845ab76c252c7a6"
    private func fixtureData() throws -> Data {
        let bundle = Bundle(for: TuningInboxV2Tests.self)
        let url = try XCTUnwrap(bundle.url(forResource: "tuning-inbox-v2-vectors", withExtension: "json")
            ?? bundle.url(forResource: "tuning-inbox-v2-vectors", withExtension: "json", subdirectory: "Fixtures"))
        return try Data(contentsOf: url)
    }
    private func root() throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData()) as? [String: Any])
    }
    private func vectors() throws -> [[String: Any]] { try XCTUnwrap(root()["vectors"] as? [[String: Any]]) }
    private func bytes(_ name: String) throws -> Data {
        let vector = try XCTUnwrap(vectors().first { $0["name"] as? String == name })
        return try XCTUnwrap(Data(base64Encoded: try XCTUnwrap(vector["plan_b64"] as? String)))
    }
    private func plan(_ name: String = "valid_leverage_raise") throws -> TuningPlanV2 {
        try TuningPlanV2.decode(bytes(name))
    }
    private func verified(_ name: String = "valid_leverage_raise") throws -> VerifiedTuningPlan {
        let data = try bytes(name)
        return try VerifiedTuningPlan.verify(bytes: data, advertisedSHA256: TuningSyntax.sha256Hex(data))
    }
    private func json(_ object: Any) throws -> TuningJSON {
        try TuningV2JSONParser.parse(JSONSerialization.data(withJSONObject: object))
    }
    private func replacing(_ value: TuningJSON, _ key: String, with replacement: TuningJSON) -> TuningJSON {
        var map = value.objectValue!
        map[key] = replacement
        return .object(map)
    }
    private func detail(_ verified: VerifiedTuningPlan, state: TuningInboxState = .ready) -> TuningInboxDetail {
        let document = verified.document
        return TuningInboxDetail(
            summary: TuningInboxSummary(id: document.proposalID, account: document.account,
                cycleID: document.cycleID, cycleKind: document.cycleKind, state: state, version: 1,
                generatedAtMs: document.frozenAtMs, planSeq: document.planSeq, resultCode: nil),
            plan: TuningPlanEnvelope(planSeq: document.planSeq, planB64: verified.bytes.base64EncodedString(),
                                     planSHA256: verified.sha256),
            runnerSyncAtMs: document.frozenAtMs)
    }
    private func refuses(_ data: Data, code: String, file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertThrowsError(try TuningPlanV2.decode(data), file: file, line: line) {
            XCTAssertEqual(($0 as? TuningPlanV2Error)?.code, code, file: file, line: line)
            XCTAssertEqual(($0 as? TuningPlanV2Error)?.errorDescription, code, file: file, line: line)
        }
    }

    func testSharedFixtureIsBundledVerbatim() throws {
        XCTAssertEqual(TuningSyntax.sha256Hex(try fixtureData()), Self.fixtureSHA256)
        XCTAssertEqual(try root()["schema"] as? String, "leafhft.tuning-plan-v2.vectors.v1")
    }

    func testEverySharedPlanVectorAndItsCompleteEffects() throws {
        for vector in try vectors() {
            let name = try XCTUnwrap(vector["name"] as? String)
            let data = try XCTUnwrap(Data(base64Encoded: try XCTUnwrap(vector["plan_b64"] as? String)))
            let expect = try XCTUnwrap(vector["expect"] as? [String: Any])
            if try XCTUnwrap(expect["ok"] as? Bool) {
                let decoded = try TuningPlanV2.decode(data)
                let expectedEffects = try json(XCTUnwrap(expect["effects"]))
                XCTAssertEqual(TuningJSON.array(decoded.effects), expectedEffects, name)
                XCTAssertEqual(try TuningPlanV2.computeEffects(decoded.json), decoded.effects, name)
                let dual = try VerifiedTuningPlan.verify(bytes: data, advertisedSHA256: TuningSyntax.sha256Hex(data))
                XCTAssertEqual(dual.document.v2Plan, decoded, name)
                XCTAssertEqual(dual.bytes, data, name)
                XCTAssertTrue(dual.hashMatches, name)
                if name == "valid_maximum_size" { XCTAssertEqual(data.count, 262_144) }
                if let migration = decoded.migration?.objectValue {
                    let policies = Dictionary(uniqueKeysWithValues: migration["policies"]!.arrayValue!.map { value in
                        let policy = value.objectValue!
                        return (policy["engine"]!.stringValue!, policy["policy_bytes"]!.stringValue!)
                    })
                    for row in migration["rows"]!.arrayValue!.map({ $0.objectValue! }) {
                        let policy = try TuningV2JSONParser.parse(
                            XCTUnwrap(Data(base64Encoded: policies[row["engine"]!.stringValue!]!)), policy: true)
                        let stake = try TuningV2Sizing.newSCents(resolvedPolicy: policy,
                            envelope: decoded.envelopeDocument, leverage: row["leverage_after"]!.intValue!,
                            sizingBasis: decoded.sizingBasis)
                        let cap = try TuningV2Sizing.maxEntryCents(resolvedPolicy: policy,
                            envelope: decoded.envelopeDocument, newSCents: stake, sizingBasis: decoded.sizingBasis)
                        XCTAssertEqual(stake, row["new_S_cents"]!.intValue, name)
                        XCTAssertEqual(cap, row["new_per_entry_cap_cents"]!.intValue, name)
                    }
                }
            } else {
                refuses(data, code: try XCTUnwrap(expect["code"] as? String))
                XCTAssertThrowsError(try VerifiedTuningPlan.verify(
                    bytes: data, advertisedSHA256: TuningSyntax.sha256Hex(data)), name)
            }
        }
    }

    func testEverySharedSizingVectorUsesExactDecimalArithmetic() throws {
        for vector in try XCTUnwrap(root()["sizing_vectors"] as? [[String: Any]]) {
            let name = try XCTUnwrap(vector["name"] as? String)
            let policy = try json(XCTUnwrap(vector["resolved_policy"]))
            let envelope = try json(XCTUnwrap(vector["envelope"]))
            let basis = try json(XCTUnwrap(vector["sizing_basis"]))
            let leverage = try XCTUnwrap((vector["leverage"] as? NSNumber)?.int64Value)
            let expect = try XCTUnwrap(vector["expect"] as? [String: NSNumber])
            let stake = try TuningV2Sizing.newSCents(resolvedPolicy: policy, envelope: envelope,
                                                    leverage: leverage, sizingBasis: basis)
            let cap = try TuningV2Sizing.maxEntryCents(resolvedPolicy: policy, envelope: envelope,
                                                      newSCents: stake, sizingBasis: basis)
            XCTAssertEqual(stake, expect["new_S_cents"]!.int64Value, name)
            XCTAssertEqual(cap, expect["max_entry_cents"]!.int64Value, name)
        }
    }

    func testEveryRaisedVectorDisplaysRaisedRowsFirstAndCountsThem() throws {
        var raisedVectors = 0
        for vector in try vectors() {
            let expect = try XCTUnwrap(vector["expect"] as? [String: Any])
            guard expect["ok"] as? Bool == true else { continue }
            let name = try XCTUnwrap(vector["name"] as? String)
            let decoded = try plan(name)
            let review = TuningV2Review(plan: decoded)
            let raisedEffects = decoded.effects.filter { $0.objectValue!["effect"] == .string("raises") }
            guard !raisedEffects.isEmpty else { continue }
            raisedVectors += 1
            let raised = review.rows.filter { $0.effectRank == .raises }
            XCTAssertEqual(review.raisedRowCount, raisedEffects.count, name)
            XCTAssertEqual(review.raisedRowCount, raised.count, name)
            XCTAssertEqual(Array(review.displayRows.prefix(raised.count)), TuningV2Review.displayOrder(raised), name)
            XCTAssertTrue(review.displayRows.dropFirst(raised.count).allSatisfy { $0.effectRank != .raises }, name)
            XCTAssertEqual(review.riskSummary, "\(raised.count) change(s) raise risk", name)
            XCTAssertEqual(review.displayRows.count, review.rows.count, name)
        }
        XCTAssertGreaterThan(raisedVectors, 0)
    }

    func testReviewOrdersLaterBookRaiseBeforeEarlierBookLower() {
        let lower = TuningV2Review.Row(book: "BNB-15M", engine: "alpha", sentence: "lowers 20x to 5x",
                                      finalState: "Final state: trading at 5x.", effectRank: .lowers)
        let raise = TuningV2Review.Row(book: "XRP-1H", engine: "beta", sentence: "raises 1x to 250x",
                                      finalState: "Final state: trading at 250x.", effectRank: .raises)
        let create = TuningV2Review.Row(book: "", engine: "gamma", sentence: "new engine from alpha",
                                       finalState: "Creates this policy.", effectRank: .raises)
        let sizing = TuningV2Review.Row(book: "BNB-15M", engine: "beta", sentence: "changes sizing",
                                       finalState: "Final state: trading.", effectRank: .sizingLaw)
        let neutral = TuningV2Review.Row(book: "BNB-15M", engine: "delta", sentence: "changes controls",
                                        finalState: "Final state: off.", effectRank: .neutral)
        let displayed = TuningV2Review.displayOrder([lower, neutral, raise, sizing, create])
        XCTAssertEqual(displayed, [create, raise, sizing, lower, neutral])
        XCTAssertEqual(TuningV2Review.riskSummary(raisedRowCount: displayed.filter { $0.effectRank == .raises }.count),
                       "2 change(s) raise risk")
        XCTAssertEqual(TuningV2Review.riskSummary(raisedRowCount: 0), "No change raises risk")
    }

    func testFormattingIsAcceptedButTheSignatureBindsReceivedBytes() throws {
        let original = try bytes("valid_leverage_raise")
        let object = try JSONSerialization.jsonObject(with: original)
        let formatted = try JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted])
        XCTAssertNotEqual(formatted, original)
        let verified = try VerifiedTuningPlan.verify(bytes: formatted, advertisedSHA256: TuningSyntax.sha256Hex(formatted))
        XCTAssertEqual(verified.document.v2Plan, try plan())
        XCTAssertEqual(verified.bytes, formatted)
        XCTAssertNotEqual(verified.sha256, TuningSyntax.sha256Hex(original))
        let message = try TuningDecision.accept(plan: verified, issuedAtMs: verified.document.frozenAtMs).messageBytes()
        let expected = [
            "leafhft.tuning-decision.v1", "verb=accept", "proposal_id=" + "12345678-1234-1234-1234-123456789abc",
            "plan_seq=1", "plan_sha256=" + verified.sha256, "runner_nonce=" + "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
            "account=1234abcd", "issued_at_ms=1791000000000",
        ].map { $0 + "\n" }.joined()
        XCTAssertEqual(message, Data(expected.utf8))
    }

    func testSafeIntegerBalanceKeepsAllSixFractionalPlacesBeforeFlooring() throws {
        let decoded = try plan()
        let basis = replacing(decoded.sizingBasis, "free_balance_cents", with: .int(9_007_199_254_740_991))
        var envelope = replacing(decoded.envelopeDocument, "daily_loss_fraction", with: .string("1"))
        envelope = replacing(envelope, "per_order_fraction", with: .string("1"))
        envelope = replacing(envelope, "per_book_stake_cents", with: .int(9_007_199_254_740_991))
        let policy: TuningJSON = .object(["daily_loss_fraction": .string("0.999999"),
                                          "per_order_fraction": .string("0.123456")])
        let stake = try TuningV2Sizing.newSCents(resolvedPolicy: policy, envelope: envelope,
                                                leverage: 250, sizingBasis: basis)
        // Exact integer products divided by 1,000,000, with the remainder discarded.
        XCTAssertEqual(stake, 9_007_190_247_541_736)
        XCTAssertEqual(try TuningV2Sizing.maxEntryCents(resolvedPolicy: policy, envelope: envelope,
                                                      newSCents: stake, sizingBasis: basis), 1_111_992_791_193_303)
    }

    func testDuplicateSchemaCannotRouteAroundStrictDecoding() throws {
        let original = String(decoding: try bytes("valid_leverage_raise"), as: UTF8.self)
        let schema = #""schema":"leafhft.tuning-plan.v2""#
        for replacement in [
            #""schema":"leafhft.tuning-plan.v1","schema":"leafhft.tuning-plan.v2""#,
            #""schema":"leafhft.tuning-plan.v2","schema":"leafhft.tuning-plan.v1""#,
        ] {
            let data = Data(original.replacingOccurrences(of: schema, with: replacement).utf8)
            refuses(data, code: "invalid_json")
            XCTAssertThrowsError(try VerifiedTuningPlan.verify(bytes: data,
                advertisedSHA256: TuningSyntax.sha256Hex(data)))
        }
    }

    func testJSONTokensAndClosedFieldsFailBeforeAuthorization() throws {
        let text = String(decoding: try bytes("valid_leverage_raise"), as: UTF8.self)
        for token in ["1.0", "1e0", "01"] {
            refuses(Data(text.replacingOccurrences(of: "\"plan_seq\":1,", with: "\"plan_seq\":" + token + ",").utf8),
                    code: "invalid_json")
        }
        refuses(Data(text.replacingOccurrences(of: "\"plan_seq\":1,", with: "\"plan_seq\":true,").utf8),
                code: "invalid_plan")
        refuses(Data(text.replacingOccurrences(of: "\"plan_seq\":1,", with: "\"plan_seq\":1,\"plan_seq\":1,").utf8),
                code: "invalid_json")
        refuses(Data([0xEF, 0xBB, 0xBF]) + Data(text.utf8), code: "invalid_json")
        refuses(Data(text.replacingOccurrences(of: "runner-1", with: "runner\u{0}1").utf8), code: "invalid_json")
        refuses(Data(text.replacingOccurrences(of: "runner-1", with: "runner\\u00001").utf8), code: "invalid_plan")
        refuses(Data(text.replacingOccurrences(of: "runner-1", with: "runnér-1").utf8), code: "invalid_plan")
        refuses(Data(text.replacingOccurrences(of: "runner-1", with: "runner\\ud800").utf8), code: "invalid_plan")
        refuses(Data([0xFF]), code: "invalid_json")
        let unknown = replacing(try plan().json, "wave", with: .int(1))
        refuses(try TuningV2Canonical.bytes(unknown), code: "invalid_plan")
    }

    func testEffectsCannotOmitNeutralRowsOrSubstituteBoolForInteger() throws {
        let decoded = try plan("valid_create_deploy_1x")
        let missingNeutral = decoded.effects.filter { $0.objectValue!["effect"] != .string("neutral") }
        refuses(try TuningV2Canonical.bytes(replacing(decoded.json, "effects", with: .array(missingNeutral))),
                code: "effects_mismatch")
        let simple = try plan()
        let effect = simple.effects[0]
        let after = replacing(effect.objectValue!["after"]!, "leverage", with: .bool(true))
        let corrupt = replacing(effect, "after", with: after)
        let tampered = replacing(simple.json, "effects", with: .array([corrupt]))
        XCTAssertEqual(try TuningPlanV2.computeEffects(tampered), simple.effects,
                       "the pure recomputation ignores producer effects")
        refuses(try TuningV2Canonical.bytes(tampered), code: "effects_mismatch")
        let extended = replacing(effect, "unreviewed", with: .bool(true))
        refuses(try TuningV2Canonical.bytes(replacing(simple.json, "effects", with: .array([extended]))),
                code: "effects_mismatch")
    }

    func testPolicyFractionalTokensArePreservedExactlyAndBoolIsNotZero() throws {
        let policy = try TuningV2JSONParser.parse(
            Data(#"{"daily_loss_fraction":0.123456,"per_order_fraction":0.987654,"fixed_count":null}"#.utf8), policy: true)
        XCTAssertEqual(policy.objectValue!["daily_loss_fraction"], .string("0.123456"))
        let decoded = try plan()
        let basis = replacing(decoded.sizingBasis, "free_balance_cents", with: .int(10_001))
        let stake = try TuningV2Sizing.newSCents(resolvedPolicy: policy, envelope: decoded.envelopeDocument,
                                                leverage: 5, sizingBasis: basis)
        XCTAssertEqual(stake, 24)
        XCTAssertEqual(try TuningV2Sizing.maxEntryCents(resolvedPolicy: policy, envelope: decoded.envelopeDocument,
                                                      newSCents: stake, sizingBasis: basis), 24)
        XCTAssertThrowsError(try TuningV2Sizing.newSCents(
            resolvedPolicy: replacing(policy, "fixed_count", with: .bool(false)),
            envelope: decoded.envelopeDocument, leverage: 5, sizingBasis: basis))
    }

    func testReviewSeparatesLeverageFromFinalEnteringAndLabelsTunerRaises() throws {
        let cleared = TuningV2Review(plan: try plan("valid_account_pause_clear")).rows
        XCTAssertEqual(cleared.first { $0.engine == "alpha" }?.sentence, "turns ON at 5x")
        XCTAssertEqual(cleared.first { $0.engine == "beta" }?.sentence,
                       "raises 20x to 250x while off; it trades at 250x when turned on")
        XCTAssertTrue(try TuningV2Review(plan: plan("valid_paused_leverage_raise")).rows[0].finalState.contains("account paused"))
        XCTAssertEqual(try TuningV2Review(plan: plan()).rows[0].sentence, "raises 5x to 20x")
        XCTAssertEqual(try TuningV2Review(plan: plan("valid_tuner_evidenced_raise")).rows[0].sentence,
                       "Tuner raise: raises 5x to 20x")
        let tunerCreate = TuningV2Review(plan: try plan("valid_tuner_default_1x")).rows
        XCTAssertEqual(tunerCreate.first { $0.book.isEmpty }?.sentence, "Tuner raise: new engine from alpha")
        XCTAssertEqual(tunerCreate.first { $0.book == "BTC-15M" }?.sentence,
                       "Tuner raise: new engine from alpha; turns ON at 1x")
        XCTAssertTrue(try TuningV2Review(plan: plan("valid_create_deployed_off")).rows
            .contains { $0.book == "BTC-15M" && $0.sentence.contains("new engine from alpha") && $0.finalState.contains("off") })
        XCTAssertEqual(TuningV2Review.dollars(9_007_199_254_740_991), "$90071992547409.91")
        XCTAssertEqual(TuningV2Review.percent(.string("0.123456")), "12.3456%")
        XCTAssertEqual(TuningV2Review.fractionAtBalance(.string("0.15"), balanceCents: 100_000),
                       "15% · $150.00 of B")
    }

    func testOneTo250WhileOffAndTurnOffReviewComeFromDecodedBytes() throws {
        func edited(_ name: String, engine: String, before: Int64, after: Int64) throws -> TuningPlanV2 {
            let original = try plan(name)
            var baseline = original.fields["baseline"]!.objectValue!
            baseline["rows"] = .array(baseline["rows"]!.arrayValue!.map { value in
                guard value.objectValue!["engine"] == .string(engine) else { return value }
                return replacing(replacing(value, "leverage", with: .int(before)), "on", with: .bool(before != 1))
            })
            let items = original.items.map { value -> TuningJSON in
                guard value.objectValue!["engine"] == .string(engine) else { return value }
                let from: TuningJSON = .object(["leverage": .int(before), "on": .bool(before != 1)])
                let to: TuningJSON = .object(["leverage": .int(after), "on": .bool(false)])
                return replacing(replacing(value, "from", with: from), "to", with: to)
            }
            var changed = replacing(original.json, "baseline", with: .object(baseline))
            changed = replacing(changed, "items", with: .array(items))
            changed = replacing(changed, "effects", with: .array(try TuningPlanV2.computeEffects(changed)))
            return try TuningPlanV2.decode(TuningV2Canonical.bytes(changed))
        }
        let off = try edited("valid_leverage_raise", engine: "alpha", before: 1, after: 250)
        XCTAssertEqual(TuningV2Review(plan: off).rows[0].sentence,
                       "raises 1x to 250x while off; it trades at 250x when turned on")
        let lower = try edited("valid_mixed_raise_lower", engine: "beta", before: 20, after: 5)
        XCTAssertEqual(TuningV2Review(plan: lower).rows.first { $0.engine == "beta" }?.sentence,
                       "lowers 20x to 5x; turns OFF")
    }

    func testV2MetadataStatesAndCycleGrammar() throws {
        for name in ["valid_leverage_raise", "valid_one_book_migration"] {
            let verified = try verified(name)
            let document = verified.document
            for state in ["approved", "applying", "live", "failed", "superseded", "executed"] {
                let wire: [String: Any] = [
                    "id": document.proposalID, "account": document.account, "cycle_id": document.cycleID,
                    "cycle_kind": document.cycleKind, "state": state, "version": 1,
                    "generated_at_ms": document.frozenAtMs, "plan_seq": document.planSeq,
                ]
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                let data = try JSONSerialization.data(withJSONObject: wire)
                let summary = try decoder.decode(TuningInboxWire.Summary.self, from: data).validated()
                XCTAssertTrue(summary.isOwner)
                XCTAssertTrue(summary.isV2)
                XCTAssertFalse(summary.stateLabel.contains("Placed"))
                if state == "live" {
                    XCTAssertEqual(summary.stateLabel, "Applied, waiting for the book to confirm")
                    XCTAssertEqual(summary.stateLabel, detail(verified, state: .applying).summary.stateLabel)
                }
                let item = try decoder.decode(TuningInboxWire.Item.self, from: data).validated()
                XCTAssertEqual(item.summary, summary)
            }
        }
        XCTAssertEqual(TuningInboxState(wire: "approved").label, "Approved, waiting")
        XCTAssertEqual(TuningInboxState(wire: "applying").label, "Applied, waiting for the book to confirm")
        XCTAssertTrue(TuningInboxState(wire: "live").isTerminal)
        XCTAssertFalse(TuningPlanV2.isCycleID("mg-0123456789abcdef", kind: "deployment_change"))
        XCTAssertFalse(TuningPlanV2.isCycleID("dc-0123456789ABCDEF", kind: "deployment_change"))
    }

    func testV2AcceptRequiresRenderedExactHashAndUsesExistingPresenceSigner() async throws {
        let verified = try verified()
        let transport = V2Transport(detail(verified))
        let signer = SoftwareDecisionKey(scalar: 1)
        let model = TuningInboxItemModel(proposalID: verified.document.proposalID,
            fixtureMode: FixtureMode(arguments: []), transport: transport, signingKey: { signer },
            now: { Date(timeIntervalSince1970: TimeInterval(verified.document.frozenAtMs + 1_000) / 1000) },
            ledger: TuningSubmissionLedger())
        await model.load()
        XCTAssertTrue(model.gate.reasons.contains(.notRendered))
        await model.accept()
        XCTAssertTrue(signer.signedMessages.isEmpty)
        model.markRendered(sha256: String(repeating: "0", count: 64))
        XCTAssertTrue(model.gate.reasons.contains(.notRendered))
        model.markRendered(sha256: verified.sha256)
        XCTAssertTrue(model.gate.enabled)
        await model.accept()
        XCTAssertEqual(signer.signedMessages.count, 1)
        XCTAssertEqual(transport.submitted.count, 1)
        XCTAssertEqual(signer.signedMessages.first,
                       try TuningDecision.accept(plan: verified, issuedAtMs: verified.document.frozenAtMs + 1_000).messageBytes())
        XCTAssertEqual(model.phase, .accepted(code: "approved"))
    }

    func testForgedEffectsCannotReachThePresenceSignerEvenWithMatchingAdvertisedHash() async throws {
        let verified = try verified()
        let forged = try TuningV2Canonical.bytes(replacing(try plan().json, "effects", with: .array([])))
        let validDetail = detail(verified)
        let transport = V2Transport(TuningInboxDetail(summary: validDetail.summary,
            plan: TuningPlanEnvelope(planSeq: verified.document.planSeq, planB64: forged.base64EncodedString(),
                                     planSHA256: TuningSyntax.sha256Hex(forged)),
            runnerSyncAtMs: verified.document.frozenAtMs))
        let signer = SoftwareDecisionKey(scalar: 1)
        let model = TuningInboxItemModel(proposalID: verified.document.proposalID,
            fixtureMode: FixtureMode(arguments: []), transport: transport, signingKey: { signer },
            now: { Date(timeIntervalSince1970: TimeInterval(verified.document.frozenAtMs + 1_000) / 1000) },
            ledger: TuningSubmissionLedger())
        await model.load()
        XCTAssertNil(model.plan)
        XCTAssertTrue(try XCTUnwrap(model.planError).contains("effects_mismatch"))
        model.markRendered(sha256: TuningSyntax.sha256Hex(forged))
        await model.accept()
        XCTAssertTrue(signer.signedMessages.isEmpty)
        XCTAssertTrue(transport.submitted.isEmpty)
    }

    func testV2ReviewActuallyRendersFromVerifiedBytes() async throws {
        for name in ["valid_create_deploy_1x", "valid_small_rows_exceed_slice"] {
            let verified = try verified(name)
            let rendered = expectation(description: "review renders " + name)
            var drawnHash: String?
            let controller = UIHostingController(rootView: TuningPlanDetailView(plan: verified) {
                drawnHash = $0
                rendered.fulfill()
            })
            let window = UIWindow(frame: CGRect(x: 0, y: 0, width: 390, height: 844))
            window.rootViewController = controller
            window.makeKeyAndVisible()
            controller.view.layoutIfNeeded()
            await fulfillment(of: [rendered], timeout: 3)
            XCTAssertEqual(drawnHash, verified.sha256)
            window.isHidden = true
        }
    }
}
