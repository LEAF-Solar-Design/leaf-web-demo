import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor final class SettingsStructureTests: XCTestCase {
    func testMissingStatusPreservesReportedFallback() {
        XCTAssertEqual(SettingsView.tradingStateLabel(status: nil, fallback: "Not reported"),
                       "Not reported")
    }

    func testLaneStatusTakesPrecedenceOverFallback() throws {
        for trading in ["live", "paused", "dry_run", "not_configured", "future_state"] {
            let json = """
            {"dashboard_pairing":"paired","account_binding":"bound","automated_trading":"\(trading)",
             "tenant":null,"lane":null,"request":null,"risk_regime":null}
            """
            let status = try accountJSONDecoder().decode(KashbotStatus.self, from: Data(json.utf8))
            XCTAssertEqual(SettingsView.tradingStateLabel(status: status, fallback: "Fallback"),
                           status.automationLabel, trading)
        }
    }
}
