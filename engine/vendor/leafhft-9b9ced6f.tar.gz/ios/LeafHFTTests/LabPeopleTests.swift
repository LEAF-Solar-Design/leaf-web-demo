import Foundation
import XCTest
@testable import LeafHFT
import LeafHFTCore

/// Engine Lab and People presentation decisions (walk findings w4-F10 to w4-F13).
@MainActor final class LabPeopleTests: XCTestCase {
    private let chicago = TimeZone(identifier: "America/Chicago")!
    private let generated = "2026-09-20T12:00:00Z"
    private var generatedDate: Date { LabTime.parse(generated)! }

    private func candidate(id: String = "cand", name: String = "Cand", shadowOnly: Bool = true,
                           reason: String = "Newly discovered trial awaiting review.",
                           verdict: String = "not_reported", provenance: String = "shadow",
                           sourceTimestamp: String = "not_reported",
                           evidence: [[String: Any]] = []) throws -> EngineLab.Candidate {
        let object: [String: Any] = [
            "id": id, "engine_id": id, "name": name, "enabled": false, "shadow_only": shadowOnly,
            "reason": reason, "promotion_verdict": verdict, "live_profit_cents": "not_reported",
            "evidence": evidence, "source_timestamp": sourceTimestamp, "provenance": provenance]
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return try decoder.decode(EngineLab.Candidate.self, from: JSONSerialization.data(withJSONObject: object))
    }

    private func row(_ id: String = "cand", kind: String = "report", status: String = "reported",
                     source: String = "TrialStore/cand", reason: String = "not_reported",
                     time: String = "2026-09-20T11:00:00Z") -> [String: Any] {
        ["candidate_id": id, "kind": kind, "source_timestamp": time, "provenance": "shadow",
         "source": source, "source_hash": "not_reported", "status": status, "reason": reason,
         "metrics": ["resolved": 1], "live_profit_cents": "not_reported"]
    }

    // MARK: w4-F10 landing

    func testBannerIsOneShortLine() {
        XCTAssertFalse(EngineLabView.bannerText.contains("\n"))
        XCTAssertLessThanOrEqual(EngineLabView.bannerText.count, 60)
        XCTAssertTrue(EngineLabView.bannerText.contains("cannot start trading"))
        XCTAssertGreaterThanOrEqual(EngineLabView.assistantReserve, 56)
    }

    func testEvidenceAgeIsRelativeAndLocalNeverRawUTC() {
        let text = EngineLabView.evidenceAgeText(generatedAt: generated,
            now: generatedDate.addingTimeInterval(5 * 60), timeZone: chicago)
        XCTAssertTrue(text.hasPrefix("Evidence generated 5 min ago · Sep 20, 7:00 AM"), text)
        XCTAssertFalse(text.contains(generated), text)
        XCTAssertEqual(EngineLabView.evidenceAgeText(generatedAt: "yesterday", now: generatedDate),
                       "Evidence time not reported")
    }

    func testAgeWordingCoversEveryRange() {
        let base = generatedDate
        XCTAssertEqual(LabTime.age(from: base, to: base.addingTimeInterval(30)), "just now")
        XCTAssertEqual(LabTime.age(from: base, to: base.addingTimeInterval(59 * 60)), "59 min ago")
        XCTAssertEqual(LabTime.age(from: base, to: base.addingTimeInterval(3 * 3_600)), "3 h ago")
        XCTAssertEqual(LabTime.age(from: base, to: base.addingTimeInterval(2 * 86_400)), "2 d ago")
        XCTAssertEqual(LabTime.age(from: base, to: base.addingTimeInterval(-600)), "ahead of this device's clock")
    }

    func testCandidateSummaryCountsOnlyThisResponse() throws {
        let lab = try EngineLab.decodeResponse(Data(EngineLab.previewResponseJSON.utf8))
        XCTAssertEqual(EngineLabView.candidateSummary(lab.candidates),
                       "3 candidates in this snapshot: 1 promotion passed, 2 shadow only")
        let failed = try candidate(reason: "Report input unavailable or invalid")
        XCTAssertEqual(EngineLabView.candidateSummary(lab.candidates + [failed]),
                       "4 candidates in this snapshot: 1 promotion passed, 3 shadow only, 1 evidence incomplete")
        XCTAssertEqual(EngineLabView.candidateSummary([failed]),
                       "1 candidate in this snapshot: 0 promotion passed, 1 shadow only, 1 evidence incomplete")
    }

    // MARK: w4-F12 evidence blocker

    func testInputFailureSaysTheSourceDidNotNameTheInput() throws {
        let value = try candidate(reason: "Report input unavailable or invalid",
            evidence: [row(kind: "trial_registration")])
        XCTAssertTrue(EngineLabCandidateDetail.evidenceIncomplete(value))
        let summary = EngineLabCandidateDetail.evidenceSummary(value,
            now: generatedDate, timeZone: chicago)
        XCTAssertEqual(summary.headline, "Evidence incomplete: Report input unavailable or invalid")
        XCTAssertEqual(summary.failedInput, "The source did not name the failed input.")
        XCTAssertTrue(summary.lastValid.hasPrefix("Last valid observation: trial registration, 1 h ago · Sep 20, 6:00 AM"),
                      summary.lastValid)
        XCTAssertEqual(EngineLabView.rowStatus(value), "Evidence incomplete: Report input unavailable or invalid")
    }

    func testHeldRowNamesItsSourceReasonAndObservedTime() throws {
        let value = try candidate(reason: "promotion verdict not_reported",
            evidence: [row(status: "held", source: "LaneRegistry/cand",
                reason: "lane implementation or document unavailable", time: "2026-09-20T11:30:00Z")])
        let summary = EngineLabCandidateDetail.evidenceSummary(value, now: generatedDate, timeZone: chicago)
        XCTAssertEqual(summary.headline, "Evidence incomplete: 1 of 1 evidence rows held")
        XCTAssertTrue(summary.failedInput.hasPrefix(
            "Held input: LaneRegistry/cand (lane implementation or document unavailable), observed 30 min ago · Sep 20, 6:30 AM"),
            summary.failedInput)
        XCTAssertEqual(summary.lastValid, "No valid observation reported.")
        XCTAssertEqual(EngineLabView.rowStatus(value), "Evidence incomplete. Promotion verdict not reported")
    }

    func testHeldRowWithoutSourceDoesNotInventOne() throws {
        let value = try candidate(evidence: [row(status: "held", source: "not_reported")])
        XCTAssertEqual(EngineLabCandidateDetail.evidenceSummary(value, now: generatedDate).failedInput,
                       "The source did not name the failed input.")
    }

    func testCompleteEvidenceKeepsTheServerReason() throws {
        let lab = try EngineLab.decodeResponse(Data(EngineLab.previewResponseJSON.utf8))
        let dip = try XCTUnwrap(lab.candidates.first { $0.id == "dip-recovery" })
        XCTAssertFalse(EngineLabCandidateDetail.evidenceIncomplete(dip))
        XCTAssertEqual(EngineLabView.rowStatus(dip), "Holdout evidence is not reported. Shadow only.")
    }

    func testMissingFieldsCollapseAndEnumsTranslate() throws {
        let value = try candidate()
        XCTAssertEqual(EngineLabCandidateDetail.missingFields(value, owner: EngineLabCandidateDetail.ownerMissing),
                       ["owner", "promotion verdict", "source time", "live profit"])
        let reported = try candidate(verdict: "SUCCESS", sourceTimestamp: generated)
        XCTAssertEqual(EngineLabCandidateDetail.missingFields(reported, owner: "Research team"), ["live profit"])
        XCTAssertEqual(EngineLabCandidateDetail.verdictText("SUCCESS"), "Success")
        XCTAssertEqual(EngineLabCandidateDetail.verdictText("not_reported"), "Not reported")
        XCTAssertEqual(EngineLabCandidateDetail.statusText("held"), "Held")
        XCTAssertEqual(EngineLabCandidateDetail.basisText("replay"), "Basis: Replay (simulated, not live fills)")
        XCTAssertEqual(EngineLabCandidateDetail.basisText("shadow"), "Basis: Shadow (simulated, not live fills)")
        XCTAssertEqual(EngineLabCandidateDetail.provenanceText("live_fill"), "Live fills")
        XCTAssertEqual(EngineLabCandidateDetail.provenanceText("not_reported"), "Not reported")
        XCTAssertEqual(EngineLabCandidateDetail.timeText(.text("not_reported"), now: generatedDate), "not reported")
    }

    // MARK: w4-F13 title

    func testCompactTitleKeepsTheDistinguishingSuffix() {
        let conv = EngineLabCandidateDetail.compactTitle("15M Late K30 9094 Conv")
        let base = EngineLabCandidateDetail.compactTitle("15M Late K30 9094 Base")
        XCTAssertEqual(conv, "15M Late K…9094 Conv")
        XCTAssertLessThanOrEqual(conv.count, 20)
        XCTAssertNotEqual(conv, base)
        XCTAssertEqual(EngineLabCandidateDetail.compactTitle("Dip Recovery"), "Dip Recovery")
    }

    // MARK: w4-F11 People

    private func person(label: String, laneID: String = "4383ed19c0de", accountID: String = "acct-77",
                        funds: PeopleCards.Funds = PeopleCards.Funds()) -> PeopleCards.Person {
        PeopleCards.Person(id: laneID, laneID: laneID, accountID: accountID, label: label,
                           lane: PeopleCards.Lane(), funds: funds)
    }

    func testIdentityLeadsOrSaysNotReported() {
        XCTAssertEqual(PeopleCardsView.identityText(person(label: "Evan")), "Evan")
        XCTAssertEqual(PeopleCardsView.identityText(person(label: "Lane 4383ed19")), "Identity not reported")
        XCTAssertEqual(PeopleCardsView.identityText(person(label: "  ")), "Identity not reported")
        XCTAssertEqual(PeopleCardsView.identityText(person(label: "acct-77")), "Identity not reported")
        XCTAssertEqual(PeopleCardsView.identityText(person(label: "Lane Alpha")), "Lane Alpha")
        XCTAssertEqual(PeopleCardsView.laneReference(person(label: "Lane 4383ed19")),
                       "Lane id: 4383ed19c0de · supplied label: Lane 4383ed19")
        XCTAssertEqual(PeopleCardsView.laneReference(person(label: "Evan")), "Lane id: 4383ed19c0de")
    }

    func testCashCarriesItsOwnAge() {
        let now = generatedDate
        let observed = PeopleCards.Funds(currentCash: PeopleCards.Money(688.06, currency: "USD"),
                                         observedAt: now.addingTimeInterval(-180))
        let text = PeopleCardsView.cashAgeText(observed, now: now, timeZone: chicago)
        XCTAssertTrue(text?.hasPrefix("Cash as of 3 min ago · Sep 20, 6:57 AM") == true, text ?? "nil")
        XCTAssertEqual(PeopleCardsView.cashAgeText(PeopleCards.Funds(
            currentCash: PeopleCards.Money(1, currency: "USD")), now: now), "Cash time not reported")
        XCTAssertNil(PeopleCardsView.cashAgeText(PeopleCards.Funds(observedAt: now), now: now))
        XCTAssertTrue(PeopleCardsView.responseTimeText(now.addingTimeInterval(-120), now: now, timeZone: chicago)
            .hasPrefix("Response generated 2 min ago · Sep 20, 6:58 AM"))
    }

    func testCoverageSummaryNamesWhatIsMissingOnce() {
        let cashOnly = person(label: "Evan", funds: PeopleCards.Funds(currentCash: PeopleCards.Money(5, currency: "USD")))
        XCTAssertEqual(PeopleCardsView.coverageText(cashOnly),
            "Evidence in this response: 1 of 7 lane fields supplied; not supplied: lane state, refusal, orders, fills, last order, last fill")
    }
}
