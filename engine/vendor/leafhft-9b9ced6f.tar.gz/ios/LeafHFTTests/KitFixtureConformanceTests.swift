import Foundation
import XCTest
import LeafAssistantCore

final class KitFixtureConformanceTests: XCTestCase {
    private let pin = "2c97b2133fcc9bed1abf333f3496e48c32abe9bd"
    private let pinFileDigest = "fb5fcba3c53a39cf1472256875655794d5849936b5336c5e608da1edce9f6e64"
    private let goldens: [String: String] = [
        "answer-with-view": "0f963b8a7e92a47404f7e7919c37c6919418b6b9bac0226b71ff8c48c12c9007",
        "card-approved": "3cb3d5b1c3ab1a75487ff2d1ba8ba5ed99530ad8617515898e4b7c5bbd62b388",
        "card-expired": "1d5c14818fe40c0d164e847a6c809acb549e2c936abb503d133598e326cb09f7",
        "idle": "b7770831e9667b616bf9f68bd79bea3f468a2133a17612d78d523be2e3dfd1e6",
        "rate-limited": "47a04f478c834fd1a7e508f23e070283b90248f242683fac9efea7856399ede9",
        "tool-failed": "81d5a5ebac1c5533b9a255a9cc3284bc3537ea50c64d90538d104f828450e541",
        "worker-offline": "202fb1aa28a6393c3818f838c11e2b1f8f58fa25150548abb60cc666168b487e"
    ]
    private var kitDir: URL {
        URL(fileURLWithPath: #filePath).deletingLastPathComponent()
            .deletingLastPathComponent().appendingPathComponent("Packages/LeafAssistantKit")
    }
    private var fixturesDir: URL {
        kitDir.appendingPathComponent("Tests/LeafAssistantCoreTests/Fixtures")
    }

    private func golden(_ name: String) throws -> GoldenConversationV1 {
        let bytes = try Data(contentsOf: fixturesDir.appendingPathComponent("\(name).json"))
        return try AssistantDecoding.decode(GoldenConversationV1.self, from: FixturePins.lfNormalized(bytes))
    }

    func testUpstreamRecordPinsTheKit() throws {
        let data = try Data(contentsOf: kitDir.appendingPathComponent("UPSTREAM.json"))
        let record = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        XCTAssertEqual(record["schema"] as? String, "leaf.assistant-kit.upstream.v1")
        XCTAssertEqual(record["upstream"] as? String, "LEAF-Solar-Design/mushy-code")
        XCTAssertEqual(record["package"] as? String, "LeafAssistantKit")
        XCTAssertEqual(record["path"] as? String, "swift/LeafAssistantKit")
        XCTAssertEqual(record["commit"] as? String, pin)
        let files = try XCTUnwrap(record["files"] as? [String: String])
        for (name, digest) in goldens {
            XCTAssertEqual(files["Tests/LeafAssistantCoreTests/Fixtures/\(name).json"], digest, name)
        }
        XCTAssertEqual(files["Tests/LeafAssistantCoreTests/Fixtures/FIXTURES.sha256"], pinFileDigest)
    }

    func testFixturePinRecomputesAtThePin() throws {
        let names = try FileManager.default.contentsOfDirectory(at: fixturesDir, includingPropertiesForKeys: nil)
            .filter { $0.pathExtension == "json" }.map { $0.lastPathComponent }.sorted()
        XCTAssertEqual(names, goldens.keys.map { "\($0).json" }.sorted())
        let pins = FixturePins.lfNormalized(try Data(contentsOf: fixturesDir.appendingPathComponent("FIXTURES.sha256")))
        let digest = CryptoKitDigest()
        XCTAssertEqual(digest.sha256Hex(pins), pinFileDigest)
        let text = try XCTUnwrap(String(data: pins, encoding: .utf8))
        let expected = Dictionary(uniqueKeysWithValues: goldens.map { ("\($0.key).json", $0.value) })
        XCTAssertEqual(try FixturePins.parse(text), expected)
        for (name, expectedDigest) in goldens {
            let bytes = try Data(contentsOf: fixturesDir.appendingPathComponent("\(name).json"))
            XCTAssertEqual(digest.sha256Hex(FixturePins.lfNormalized(bytes)), expectedDigest, name)
        }
    }

    func testEveryGoldenDecodesFoldsAndKeepsTheContract() throws {
        for name in goldens.keys.sorted() {
            let value = try golden(name)
            XCTAssertEqual(value.name, name)
            XCTAssertEqual(ContractCheck.violations(in: value), [], name)
            XCTAssertEqual(ThreadFold.fold(value.events), value.thread.items, name)
            for event in value.events {
                XCTAssertTrue(event.requiresActionIsConsistent, name)
            }
        }
    }

    func testTheShapesTheIosScreenWillRender() throws {
        let idle = try golden("idle")
        XCTAssertTrue(idle.thread.items.isEmpty)
        XCTAssertTrue(idle.events.isEmpty)
        let answer = try golden("answer-with-view")
        guard answer.thread.items.count > 1, answer.thread.items[1].blocks.count > 1 else {
            return XCTFail("answer-with-view is missing its view block")
        }
        guard case .view(let view) = answer.thread.items[1].blocks[1] else {
            return XCTFail("answer-with-view must contain a view")
        }
        XCTAssertEqual(view.origin, .server)
        let failed = try golden("tool-failed")
        guard failed.thread.items.count > 1, !failed.thread.items[1].blocks.isEmpty else {
            return XCTFail("tool-failed is missing its tools block")
        }
        guard case .tools(let tools) = failed.thread.items[1].blocks[0] else {
            return XCTFail("tool-failed must contain tools")
        }
        let tool = try XCTUnwrap(tools.tools.first)
        XCTAssertEqual(tool.state, .failed)
    }
}
