import CryptoKit
import SwiftUI
import XCTest
@testable import LeafHFT

final class EngineGlyphPathTests: XCTestCase {
    private struct Fixture: Decodable {
        let source: String
        let viewBox: String
        let sha256: String
        let symbols: [Symbol]
    }

    private struct Symbol: Decodable {
        let id: String
        let path: String
    }

    private func fixture() throws -> Fixture {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(
            forResource: "engine-glyphs", withExtension: "json", subdirectory: "Fixtures"))
        return try JSONDecoder().decode(Fixture.self, from: Data(contentsOf: url))
    }

    func testEveryCatalogSymbolParsesWithinViewBox() throws {
        let catalog = try fixture()
        XCTAssertEqual(catalog.symbols.count, 133)
        XCTAssertEqual(catalog.viewBox, "0 0 256 256")
        XCTAssertFalse(catalog.source.isEmpty)
        for symbol in catalog.symbols {
            let path = try XCTUnwrap(EngineGlyphPath.parse(symbol.path), symbol.id)
            let box = path.boundingRect
            XCTAssertFalse(path.isEmpty, symbol.id)
            XCTAssertGreaterThan(box.width, 0, symbol.id)
            XCTAssertGreaterThan(box.height, 0, symbol.id)
            XCTAssertGreaterThanOrEqual(box.minX, -1, symbol.id)
            XCTAssertGreaterThanOrEqual(box.minY, -1, symbol.id)
            XCTAssertLessThanOrEqual(box.maxX, 257, symbol.id)
            XCTAssertLessThanOrEqual(box.maxY, 257, symbol.id)
        }
    }

    func testFixtureCanonicalHashIsPinned() throws {
        let catalog = try fixture()
        // Preserve array order; sort object keys as Python's sort_keys=True does.
        let canonical = "[" + catalog.symbols.map {
            "{\"id\":" + jsonString($0.id) + ",\"path\":" + jsonString($0.path) + "}"
        }.joined(separator: ",") + "]"
        let digest = SHA256.hash(data: Data(canonical.utf8))
            .map { String(format: "%02x", $0) }.joined()
        let expected = "93ba3bca69f50bd45e11553b9b033d6cc" + "6558fa32e8a1dd289d9db430bfeb72a"
        XCTAssertEqual(catalog.sha256, expected)
        XCTAssertEqual(digest, catalog.sha256)
    }

    func testCollapsedGlyphsUseDotFallback() {
        for input in ["", "M10", "M0 0", "M0 0 Z", "M0 0 L0 0",
                      "M0 0 H20", "M0 0 V20", "M1 2 A10 10 0 1 1 1 2",
                      "M0 0L1 1", "M5 5H6", "M5 5V5.5"] {
            XCTAssertNil(EngineGlyphView(path: input, tint: .red, size: 18).parsed, input)
        }
        // A move-only SVG is valid syntax, but cannot provide a visible glyph.
        XCTAssertNotNil(EngineGlyphPath.parse("M0 0"))
    }

    func testFixtureIdentityGlyphIsALargeDrawableGlyph() throws {
        let path = try XCTUnwrap(EngineGlyphPath.parse(FixtureMode.assistantGlyphPath))
        XCTAssertGreaterThan(path.boundingRect.width, 100)
        XCTAssertGreaterThan(path.boundingRect.height, 100)
        XCTAssertNotNil(EngineGlyphView(path: FixtureMode.assistantGlyphPath, tint: .red, size: 18).parsed)
    }

    func testEveryCatalogSymbolHasDrawableGlyph() throws {
        for symbol in try fixture().symbols {
            XCTAssertNotNil(EngineGlyphView(path: symbol.path, tint: .red, size: 18).parsed,
                            symbol.id)
        }
    }

    func testMalformedAndUnboundedPathsFailClosed() {
        let malformed = [
            "", " ", "L10 10", "M10", "M10 10 X5", "M1e400 0", "MNaN 0",
            "M0 0 L", "M0 0 A1 1 0 2 0 1 1", "M0 0 A1 1 0 0 1 1",
            "M0 0 1", "M0 0 Z1 1", "M,0 0", "M0,,0", "M0 0,", "M1e- 0",
            String(repeating: "x", count: 20_000),
            "M0 0" + String(repeating: "L1 1", count: 5_000),
            // Exercise the command cap separately from the byte cap.
            "M0 0" + String(repeating: "z", count: 4_096),
            "M1e308 0 l1e308 0"
        ]
        for input in malformed {
            XCTAssertNil(EngineGlyphPath.parse(input), String(input.prefix(80)))
        }
        XCTAssertNil(EngineGlyphPath.parse("M0 0", viewBox: 0))
        XCTAssertNil(EngineGlyphPath.parse("M0 0", viewBox: .infinity))
        XCTAssertNotNil(EngineGlyphPath.parse("M0 0" + String(repeating: "z", count: 4_095)))
    }

    func testAbsoluteArcSweepAndRadiusScaleUp() throws {
        for input in ["M0 0 A10 10 0 0 1 20 0", "M0 0 A1 1 0 0 1 20 0"] {
            let box = try XCTUnwrap(EngineGlyphPath.parse(input)).boundingRect
            XCTAssertEqual(box.minX, 0, accuracy: 0.5)
            XCTAssertEqual(box.maxX, 20, accuracy: 0.5)
            XCTAssertEqual(box.minY, -10, accuracy: 0.5)
            XCTAssertEqual(box.maxY, 0, accuracy: 0.5)
        }
        let reversed = try XCTUnwrap(EngineGlyphPath.parse("M0 0 A10 10 0 0 0 20 0")).boundingRect
        XCTAssertEqual(reversed.minY, 0, accuracy: 0.5)
        XCTAssertEqual(reversed.maxY, 10, accuracy: 0.5)
    }

    func testRelativeAndLargeArcs() throws {
        let half = try XCTUnwrap(EngineGlyphPath.parse("M0 0 a10 10 0 1 1 0 20")).boundingRect
        // Opposite endpoints make a semicircle: its horizontal extent is one radius.
        XCTAssertEqual(half.minX, 0, accuracy: 0.5)
        XCTAssertEqual(half.width, 10, accuracy: 0.5)
        XCTAssertEqual(half.height, 20, accuracy: 0.5)
        let large = try XCTUnwrap(EngineGlyphPath.parse("M0 0 a10 10 0 1 1 10 10")).boundingRect
        XCTAssertEqual(large.width, 20, accuracy: 0.5)
        XCTAssertEqual(large.height, 20, accuracy: 0.5)
        let small = try XCTUnwrap(EngineGlyphPath.parse("M0 0 a10 10 0 0 1 10 10")).boundingRect
        XCTAssertEqual(small.width, 10, accuracy: 0.5)
        XCTAssertEqual(small.height, 10, accuracy: 0.5)
    }

    func testRotatedEllipseAndDegenerateArcs() throws {
        let rotated = try XCTUnwrap(EngineGlyphPath.parse("M0 0 A20 10 90 0 1 0 40")).boundingRect
        XCTAssertEqual(rotated.width, 10, accuracy: 0.5)
        XCTAssertEqual(rotated.height, 40, accuracy: 0.5)
        for input in ["M0 0 A0 10 0 0 1 20 5", "M0 0 A10 0 0 1 0 20 5"] {
            let path = try XCTUnwrap(EngineGlyphPath.parse(input))
            var lines: [CGPoint] = []
            path.forEach { if case let .line(to: point) = $0 { lines.append(point) } }
            XCTAssertEqual(lines, [CGPoint(x: 20, y: 5)])
        }
        let coincident = try XCTUnwrap(EngineGlyphPath.parse("M1 2 A10 10 0 1 1 1 2"))
        var elements = 0
        coincident.forEach { _ in elements += 1 }
        XCTAssertEqual(elements, 1)
    }

    func testPackedNumbersExponentsAndArcFlags() throws {
        let path = try XCTUnwrap(EngineGlyphPath.parse("M1.5.5L-1-2"))
        var points: [CGPoint] = []
        path.forEach {
            switch $0 {
            case let .move(to: point), let .line(to: point): points.append(point)
            default: XCTFail("Unexpected packed-number element")
            }
        }
        XCTAssertEqual(points, [CGPoint(x: 1.5, y: 0.5), CGPoint(x: -1, y: -2)])
        let exponent = try XCTUnwrap(EngineGlyphPath.parse("M1e-3-2E+1L.5+3"))
        XCTAssertEqual(exponent.boundingRect.minX, 0.001, accuracy: 0.00001)
        XCTAssertEqual(exponent.boundingRect.minY, -20, accuracy: 0.00001)
        let packed = try XCTUnwrap(EngineGlyphPath.parse("M0 0 a1 1 0 011 1"))
        let spaced = try XCTUnwrap(EngineGlyphPath.parse("M0 0 a1 1 0 0 1 1 1"))
        XCTAssertEqual(packed, spaced)
    }

    func testRelativeMoveImplicitLinesAndClose() throws {
        let path = try XCTUnwrap(EngineGlyphPath.parse("m10 10 10 0 0 10z"))
        XCTAssertEqual(path.boundingRect, CGRect(x: 10, y: 10, width: 10, height: 10))
        var closed = false
        path.forEach { if case .closeSubpath = $0 { closed = true } }
        XCTAssertTrue(closed)
        // Closing restores the subpath's starting point for the next relative command.
        let next = try XCTUnwrap(EngineGlyphPath.parse("m10 10 10 0 0 10z l-5-5"))
        XCTAssertEqual(next.boundingRect.minX, 5)
        XCTAssertEqual(next.boundingRect.minY, 5)
    }

    func testRelativeCommandsMatchAbsoluteGeometry() throws {
        let relative = "m10 10 h10 v10 c1 2 3 4 5 6 s3 4 5 6 q1 2 3 4 t3 4"
        let absolute = "M10 10 H20 V20 C21 22 23 24 25 26 S28 30 30 32 Q31 34 33 36 T36 40"
        XCTAssertEqual(try XCTUnwrap(EngineGlyphPath.parse(relative)),
                       try XCTUnwrap(EngineGlyphPath.parse(absolute)))
        let repeated = "M0 0 C1 2 3 4 5 6 7 8 9 10 11 12 S13 14 15 16 17 18 19 20"
        let explicit = "M0 0 C1 2 3 4 5 6 C7 8 9 10 11 12 S13 14 15 16 S17 18 19 20"
        XCTAssertEqual(try XCTUnwrap(EngineGlyphPath.parse(repeated)),
                       try XCTUnwrap(EngineGlyphPath.parse(explicit)))
    }

    func testSmoothControlsReflectAndReset() throws {
        let path = try XCTUnwrap(EngineGlyphPath.parse(
            "M0 0 C1 2 3 4 5 6 S7 8 9 10 L10 10 S11 12 13 14 Q15 16 17 18 T19 20 H21 T22 23"))
        var cubic: [CGPoint] = []
        var quadratic: [CGPoint] = []
        path.forEach {
            switch $0 {
            case let .curve(to: _, control1: c1, control2: _): cubic.append(c1)
            case let .quadCurve(to: _, control: control): quadratic.append(control)
            default: break
            }
        }
        XCTAssertEqual(cubic, [CGPoint(x: 1, y: 2), CGPoint(x: 7, y: 8), CGPoint(x: 10, y: 10)])
        XCTAssertEqual(quadratic, [CGPoint(x: 15, y: 16), CGPoint(x: 19, y: 20), CGPoint(x: 21, y: 20)])
    }

    private func jsonString(_ value: String) -> String {
        "\"" + value.replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"") + "\""
    }
}
