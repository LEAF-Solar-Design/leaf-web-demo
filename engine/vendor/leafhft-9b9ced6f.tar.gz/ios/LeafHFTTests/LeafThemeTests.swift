import SwiftUI
import UIKit
import XCTest
@testable import LeafHFT

final class LeafThemeTests: XCTestCase {
    @MainActor func testTokensMatchDashboardSource() {
        let tokens: [(String, Color, UInt32, UInt32)] = [
            ("ground", LeafTheme.ground, 0x0c0e12, 0xf7f8fa),
            ("card", LeafTheme.card, 0x15181e, 0xffffff),
            ("cardRaised", LeafTheme.cardRaised, 0x1c2027, 0xf1f3f5),
            ("accentFill", LeafTheme.accentFill, 0x232830, 0xf1f3f5),
            ("line", LeafTheme.line, 0x262b33, 0xe2e5ea),
            ("input", LeafTheme.input, 0x2f353f, 0xd2d6dd),
            ("ring", LeafTheme.ring, 0xaeb4bd, 0x0b0d12),
            ("ink", LeafTheme.ink, 0xe6e8ec, 0x0b0d12),
            ("inkMuted", LeafTheme.inkMuted, 0x9aa1ac, 0x6b7280),
            ("inkFaint", LeafTheme.inkFaint, 0x6b7280, 0x9aa1ac),
            ("primary", LeafTheme.primary, 0xe6e8ec, 0x0b0d12),
            ("primaryForeground", LeafTheme.primaryForeground, 0x0c0e12, 0xffffff),
            ("gain", LeafTheme.gain, 0x4cc38a, 0x146c43),
            ("gainSoft", LeafTheme.gainSoft, 0x10251b, 0xe9f6ef),
            ("gainLine", LeafTheme.gainLine, 0x1f4a37, 0xbfe3cf),
            ("loss", LeafTheme.loss, 0xf27a72, 0xb3261e),
            ("lossSoft", LeafTheme.lossSoft, 0x2a1615, 0xfdecec),
            ("lossLine", LeafTheme.lossLine, 0x532825, 0xf3c9c7),
            ("warn", LeafTheme.warn, 0xe0a94b, 0x95590a),
            ("warnSoft", LeafTheme.warnSoft, 0x2a2110, 0xfdf3e2),
            ("warnLine", LeafTheme.warnLine, 0x574526, 0xf0dcae),
            ("stale", LeafTheme.stale, 0x9aa1ac, 0x5b6470),
            ("staleSoft", LeafTheme.staleSoft, 0x1c2129, 0xeef0f3),
            ("staleLine", LeafTheme.staleLine, 0x333a44, 0xdce0e6),
            ("destructive", LeafTheme.destructive, 0xdc4c48, 0xb3261e),
            ("series1", LeafTheme.series1, 0x5b9bd5, 0x2f6f9f),
            ("series2", LeafTheme.series2, 0x4cc38a, 0x146c43),
            ("series3", LeafTheme.series3, 0xe0a94b, 0x95590a),
            ("series4", LeafTheme.series4, 0x9b87e8, 0x6d5bd0),
            ("series5", LeafTheme.series5, 0x9aa1ac, 0x64748b)
        ]
        for (name, token, dark, light) in tokens {
            for (style, expected) in [(UIUserInterfaceStyle.dark, dark), (.light, light)] {
                let color = UIColor(token)
                    .resolvedColor(with: UITraitCollection(userInterfaceStyle: style))
                var red: CGFloat = 0
                var green: CGFloat = 0
                var blue: CGFloat = 0
                var alpha: CGFloat = 0
                XCTAssertTrue(color.getRed(&red, green: &green, blue: &blue, alpha: &alpha), name)
                let hex = (UInt32((red * 255).rounded()) << 16)
                    | (UInt32((green * 255).rounded()) << 8)
                    | UInt32((blue * 255).rounded())
                XCTAssertEqual(hex, expected, "\(name), \(style)")
                XCTAssertEqual(alpha, 1, accuracy: 0.001, name)
            }
        }
        XCTAssertEqual(LeafTheme.radius, 12)
        XCTAssertEqual(LeafTheme.radiusSmall, 8)
        XCTAssertEqual(LeafTheme.cardPadding, 12)
        XCTAssertEqual(LeafTone.gain.line, LeafTheme.gainLine)
        XCTAssertEqual(LeafTone.loss.line, LeafTheme.lossLine)
        XCTAssertEqual(LeafTone.warn.line, LeafTheme.warnLine)
        XCTAssertEqual(LeafTone.stale.line, LeafTheme.staleLine)
        XCTAssertEqual(LeafTone.neutral.line, LeafTheme.line)
    }

    func testNumeralStylesAreMonoAndTracked() {
        let styles: [(LeafNumeralStyle, CGFloat, Font.Weight, Font.TextStyle)] = [
            (.hero, 40, .semibold, .largeTitle),
            (.large, 28, .semibold, .title),
            (.number, 17, .medium, .body),
            (.small, 13, .regular, .footnote),
            (.table, 11, .regular, .caption)
        ]
        XCTAssertEqual(styles.count, LeafNumeralStyle.allCases.count)
        for (style, size, weight, relativeTo) in styles {
            XCTAssertEqual(style.size, size)
            XCTAssertEqual(style.weight, weight)
            XCTAssertEqual(style.relativeTo, relativeTo)
            XCTAssertEqual(style.tracking, -0.03 * size, accuracy: 0.0001)
            XCTAssertEqual(style.font,
                           Font.custom("Geist Mono", size: size, relativeTo: relativeTo).weight(weight))
            let modifier = LeafNumeral(size: style.size, weight: style.weight, relativeTo: style.relativeTo)
            XCTAssertEqual(modifier.size, size)
            XCTAssertEqual(modifier.weight, weight)
            XCTAssertEqual(modifier.relativeTo, relativeTo)
        }
        XCTAssertEqual(LeafType.display,
                       LeafType.mono(34, weight: .bold, relativeTo: .largeTitle).monospacedDigit())
        XCTAssertEqual(LeafType.numberLarge,
                       LeafType.mono(28, weight: .semibold, relativeTo: .title).monospacedDigit())
        XCTAssertEqual(LeafType.number,
                       LeafType.mono(17, weight: .medium, relativeTo: .body).monospacedDigit())
        XCTAssertEqual(LeafType.numberSmall,
                       LeafType.mono(13, relativeTo: .footnote).monospacedDigit())
    }

    @MainActor func testBoundedPrimitivesCapHeight() {
        let listMeasured = expectation(description: "List rendered")
        let tableMeasured = expectation(description: "Table rendered")
        var listHeight: CGFloat = 0
        var tableHeight: CGFloat = 0
        let content = VStack(spacing: 12) {
            BoundedList(maxHeight: 120, identifier: "test.list") {
                ForEach(0..<40) { index in Text("Row \(index)").frame(height: 30) }
            }
            .background {
                GeometryReader { geometry in
                    Color.clear.onAppear {
                        listHeight = geometry.size.height
                        listMeasured.fulfill()
                    }
                }
            }
            BoundedTable(columns: [
                .init(title: "Account", width: 200),
                .init(title: "Value", width: 200, numeric: true)
            ], rows: (0..<50).map { index in
                [.init(text: "Account \(index)"), .init(text: "123.45", tone: .gain)]
            }, maxHeight: 160, identifier: "test.table", minWidth: 400)
            .background {
                GeometryReader { geometry in
                    Color.clear.onAppear {
                        tableHeight = geometry.size.height
                        tableMeasured.fulfill()
                    }
                }
            }
            Spacer(minLength: 0)
        }
        let host = UIHostingController(rootView: content)
        let window = UIWindow(frame: CGRect(x: 0, y: 0, width: 390, height: 844))
        window.rootViewController = host
        window.makeKeyAndVisible()
        defer { window.isHidden = true }
        host.view.frame = window.bounds
        host.view.setNeedsLayout()
        host.view.layoutIfNeeded()
        wait(for: [listMeasured, tableMeasured], timeout: 2)
        XCTAssertGreaterThan(listHeight, 0)
        XCTAssertLessThanOrEqual(listHeight, 120)
        XCTAssertGreaterThan(tableHeight, 0)
        XCTAssertLessThanOrEqual(tableHeight, 160)
    }

    @MainActor func testGeistFontsAreAvailable() {
        LeafFonts.registerIfNeeded()
        XCTAssertNotNil(UIFont(name: "Geist-Regular", size: 14))
        XCTAssertNotNil(UIFont(name: "GeistMono-Regular", size: 14))
    }

    func testMoneyFormatting() {
        XCTAssertEqual(LeafFormat.money(cents: 1234), "$12.34")
        XCTAssertEqual(LeafFormat.money(cents: -120), "−$1.20")
        XCTAssertEqual(LeafFormat.signedMoney(cents: 120), "+$1.20")
        XCTAssertEqual(LeafFormat.signedMoney(cents: -120), "−$1.20")
        XCTAssertEqual(LeafFormat.signedMoney(cents: 0), "$0.00")
        XCTAssertEqual(LeafTone.forDelta(cents: 5), .gain)
        XCTAssertEqual(LeafTone.forDelta(cents: -5), .loss)
        XCTAssertEqual(LeafTone.forDelta(cents: 0), .neutral)
    }

    func testStateGlyphsAreDistinctFromDeltaGlyphs() {
        XCTAssertEqual(LeafTone.gain.stateGlyph, "checkmark")
        XCTAssertEqual(LeafTone.loss.stateGlyph, "xmark")
        XCTAssertEqual(LeafTone.warn.stateGlyph, "clock")
        XCTAssertEqual(LeafTone.stale.stateGlyph, "questionmark")
        XCTAssertNil(LeafTone.neutral.stateGlyph)
        XCTAssertEqual(LeafTone.gain.glyph, "arrow.up.right")
        XCTAssertEqual(LeafTone.loss.glyph, "arrow.down.right")
        XCTAssertEqual(LeafTone.neutral.glyph, "minus")
    }

    func testAppearanceMapping() {
        XCTAssertNil(LeafAppearance.system.colorScheme)
        XCTAssertEqual(LeafAppearance.dark.colorScheme, .dark)
        XCTAssertEqual(LeafAppearance.light.colorScheme, .light)
        XCTAssertEqual(LeafAppearance.system.label, "System")
        XCTAssertEqual(LeafAppearance.dark.label, "Dark")
        XCTAssertEqual(LeafAppearance.light.label, "Light")
    }

    @MainActor func testTokensResolvePerAppearance() {
        for (style, hex) in [(UIUserInterfaceStyle.dark, UInt32(0x0c0e12)),
                             (.light, UInt32(0xf7f8fa))] {
            let color = UIColor(LeafTheme.ground)
                .resolvedColor(with: UITraitCollection(userInterfaceStyle: style))
            var red: CGFloat = 0
            var green: CGFloat = 0
            var blue: CGFloat = 0
            var alpha: CGFloat = 0
            XCTAssertTrue(color.getRed(&red, green: &green, blue: &blue, alpha: &alpha))
            XCTAssertEqual(red, CGFloat((hex >> 16) & 0xff) / 255, accuracy: 0.02)
            XCTAssertEqual(green, CGFloat((hex >> 8) & 0xff) / 255, accuracy: 0.02)
            XCTAssertEqual(blue, CGFloat(hex & 0xff) / 255, accuracy: 0.02)
            XCTAssertEqual(alpha, 1, accuracy: 0.02)
        }
    }
}
