import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

final class AutopilotModelTests: XCTestCase {
    private func fixtureData() throws -> Data {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "autopilot", withExtension: "json", subdirectory: "Fixtures"))
        return try Data(contentsOf: url)
    }

    private func fixtureObject() throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: fixtureData()) as? [String: Any])
    }

    func testDecodesOwnerFixtureAndFrozenFieldTypes() throws {
        let response = try AutopilotResponse.decode(fixtureData())
        XCTAssertEqual(response.view.schema, "leafhft.autopilot-view.v1")
        XCTAssertEqual(response.toggles.schema, "leafhft.autopilot-toggles.v1")
        XCTAssertEqual(response.view.accountId, "owner")
        XCTAssertEqual(response.toggles.accountId, response.view.accountId)
        XCTAssertEqual(response.view.cycles.count, 14)
        XCTAssertEqual(response.view.engines.count, 6)
        XCTAssertEqual(Set(response.view.engines.map(\.lineageRoot)).count, 2)
        XCTAssertEqual(response.view.pending?.daysWaiting, 1.4)
        XCTAssertEqual(response.view.autopilot.mirrorStatus, .live)
        XCTAssertEqual(response.view.autopilot.togglesSource, .api)
        XCTAssertEqual(response.view.cycles[0].counts?["engines"], .integer(6))
        XCTAssertEqual(response.view.cycles[0].counts?["decisions"],
                       .grouped(["promote": 1, "keep": 3, "kill": 1, "insufficient": 1]))
        XCTAssertEqual(response.view.cycles[0].family?.m, 6)
        XCTAssertEqual(response.view.cycles[0].family?.adjustedQ, 0.0083)
        let engine = response.view.engines[0]
        XCTAssertEqual(engine.overrides["edge_threshold_cents"], .number(3))
        XCTAssertEqual(engine.overrides["use_guard"], .boolean(true))
        XCTAssertEqual(engine.cells[0].nEff, 9.5)
        XCTAssertEqual(engine.evidence.sumNEff, 15.5)
        XCTAssertEqual(engine.evidence.neffFloor, 40)
        XCTAssertEqual(engine.approvalSha12, "abc123def456")
        XCTAssertTrue(response.view.engines.contains { $0.cells.contains { $0.n >= 20 } })
        XCTAssertEqual(response.toggles.engines["eth-hourly-g3"], .off)
        XCTAssertFalse(response.view.engines[5].toggleEffective)
        XCTAssertFalse(response.view.engines[5].inPopulation)
        XCTAssertEqual(response.view.kills.count, 2)
        XCTAssertEqual(response.view.refused.first?.baseId, "btc-hourly-g3")
        XCTAssertEqual(response.view.handoffs.first?.atMs, 1_790_344_800_000)
    }

    func testEveryFrozenKeyIsPresentInFixture() throws {
        let envelope = try fixtureObject()
        func object(_ value: Any?) throws -> [String: Any] { try XCTUnwrap(value as? [String: Any]) }
        func first(_ value: Any?) throws -> [String: Any] {
            try XCTUnwrap((value as? [[String: Any]])?.first)
        }
        func keys(_ value: [String: Any], _ expected: String, file: StaticString = #filePath, line: UInt = #line) {
            XCTAssertEqual(Set(value.keys), Set(expected.split(separator: " ").map(String.init)), file: file, line: line)
        }
        keys(envelope, "view toggles")
        let view = try object(envelope["view"])
        keys(view, "schema generated_at account_id truncated autopilot cycles engines refused kills pending handoffs")
        keys(try object(view["autopilot"]), "toggles_source enabled_default mirror_status mirror_generated_at waiting_reason")
        let cycle = try first(view["cycles"])
        keys(cycle, "cycle_id et_day stage status detail counts generation family updated_at")
        keys(try object(cycle["family"]), "m adjusted_q")
        let engine = try first(view["engines"])
        keys(engine, "engine_id parent lineage_root generation overrides toggle toggle_effective in_population first_seen stale_reason lifecycle_state size approval_sha12 books verdicts cells evidence")
        keys(try first(engine["verdicts"]), "cycle_id decision score")
        keys(try first(engine["cells"]), "symbol bucket n n_eff adjusted_quantile size_up_candidate")
        keys(try object(engine["evidence"]), "max_cell_n sum_n_eff n_floor neff_floor")
        keys(try first(view["refused"]), "engine_id base_id overrides reason cycle_id")
        keys(try first(view["kills"]), "fingerprint lineage_root overrides reason killed_at")
        keys(try object(view["pending"]), "cycle_id days_waiting ol2_grid_key")
        keys(try first(view["handoffs"]), "engine_id cycle_id at_ms")
        keys(try object(envelope["toggles"]), "schema account_id enabled_default engines")
    }

    func testUnknownKeysAreIgnoredAtEveryObjectLevel() throws {
        func addingUnknowns(_ value: Any) -> Any {
            if var dictionary = value as? [String: Any] {
                // Dictionaries whose keys are data (engine IDs, dial names, counts) stay intact.
                for (key, item) in dictionary where !["overrides", "counts"].contains(key) {
                    if key == "engines", item is [String: Any] { continue }
                    dictionary[key] = addingUnknowns(item)
                }
                dictionary["future_field"] = ["ignored": true]
                return dictionary
            }
            if let array = value as? [Any] { return array.map(addingUnknowns) }
            return value
        }
        let data = try JSONSerialization.data(withJSONObject: addingUnknowns(fixtureObject()))
        let response = try AutopilotResponse.decode(data)
        XCTAssertEqual(response.view.engines.count, 6)
        XCTAssertEqual(response.view.pending?.daysWaiting, 1.4)
    }

    func testNullPendingFamilyAndNullableFieldsDecode() throws {
        var envelope = try fixtureObject()
        var view = try XCTUnwrap(envelope["view"] as? [String: Any])
        view["pending"] = NSNull()
        var cycles = try XCTUnwrap(view["cycles"] as? [[String: Any]])
        cycles[0]["family"] = NSNull()
        cycles[0]["counts"] = NSNull()
        cycles[0]["generation"] = NSNull()
        view["cycles"] = cycles
        var autopilot = try XCTUnwrap(view["autopilot"] as? [String: Any])
        autopilot["mirror_status"] = "waiting_for_ledger"
        autopilot["mirror_generated_at"] = NSNull()
        autopilot["waiting_reason"] = NSNull()
        view["autopilot"] = autopilot
        envelope["view"] = view
        let response = try AutopilotResponse.decode(JSONSerialization.data(withJSONObject: envelope))
        XCTAssertNil(response.view.pending)
        XCTAssertNil(response.view.cycles[0].family)
        XCTAssertNil(response.view.cycles[0].counts)
        XCTAssertNil(response.view.cycles[0].generation)
        XCTAssertNil(response.view.autopilot.mirrorGeneratedAt)
        XCTAssertEqual(response.view.autopilot.mirrorStatus, .waitingForLedger)
        XCTAssertTrue(response.toggles.enabledDefault)
    }

    @MainActor func testFixtureFetchAndUnavailableMessage() async throws {
        let response = try await AutopilotView.fetch(fixture: true)
        XCTAssertEqual(response.view.engines.count, 6)
        XCTAssertEqual(AutopilotView.loadMessage(DashboardClientError.http(404)),
                       "Autopilot data is not available on this server yet")
    }

    func testFixtureClientRefusesBeforeCredentialRead() async {
        let client = AutopilotClient(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]), token: {
            XCTFail("Fixture mode reached the keychain boundary")
            throw FixtureAccessError.disabled
        })
        do {
            _ = try await client.fetch()
            XCTFail("Fixture client permitted live access")
        } catch { XCTAssertTrue(error is FixtureAccessError) }
    }

    func testAccountSwitchesAbsentIsUnknownAndOneOrTwoEntriesDecode() throws {
        XCTAssertNil(try AutopilotResponse.decode(fixtureData()).accountSwitches)
        var envelope = try fixtureObject()
        let lane: [String: Any] = ["scope": "lane", "account_id": "aabbccdd", "enabled": false,
                                   "overrides_on": 0, "overrides_off": 2]
        let owner: [String: Any] = ["scope": "owner", "account_id": "owner", "enabled": true,
                                    "overrides_on": 1, "overrides_off": 0]
        envelope["account_switches"] = [lane]
        let one = try AutopilotResponse.decode(JSONSerialization.data(withJSONObject: envelope))
        XCTAssertEqual(one.accountSwitches?.count, 1)
        XCTAssertEqual(one.accountSwitches?.first?.scope, .lane)
        XCTAssertEqual(one.accountSwitches?.first?.enabled, false)
        XCTAssertEqual(one.accountSwitches?.first?.overridesOff, 2)
        envelope["account_switches"] = [lane, owner]
        let two = try AutopilotResponse.decode(JSONSerialization.data(withJSONObject: envelope))
        XCTAssertEqual(two.accountSwitches?.map(\.scope), [.lane, .owner])
        XCTAssertEqual(two.accountSwitches?.map(\.label), ["Autotuner", "Autotuner (owner books)"])
        XCTAssertEqual(two.accountSwitches?.last?.overridesOn, 1)
    }

    @MainActor func testSwitchPendingBlocksDuplicatesAndErrorKeepsConfirmedThenRetries() async throws {
        let entry = AutopilotAccountSwitch(scope: .lane, accountId: "aabbccdd", enabled: true,
                                           overridesOn: 2, overridesOff: 0)
        var calls = 0
        var completion: CheckedContinuation<AutopilotToggles, Error>?
        let entered = expectation(description: "Write pending")
        let model = AutopilotSwitchState(confirmed: entry, fixtureMode: FixtureMode(arguments: [])) { enabled, scope in
            calls += 1
            XCTAssertFalse(enabled)
            XCTAssertEqual(scope, .lane)
            if calls == 1 {
                return try await withCheckedThrowingContinuation { continuation in
                    completion = continuation
                    entered.fulfill()
                }
            }
            return AutopilotToggles(schema: "leafhft.autopilot-toggles.v1", accountId: "aabbccdd",
                                    enabledDefault: false, engines: [:])
        }
        let task = Task { await model.setEnabled(false) }
        await fulfillment(of: [entered], timeout: 2)
        XCTAssertTrue(model.pending)
        XCTAssertTrue(model.confirmed.enabled)
        await model.setEnabled(true)
        XCTAssertEqual(calls, 1)
        try XCTUnwrap(completion).resume(throwing: DashboardClientError.transport)
        await task.value
        XCTAssertFalse(model.pending)
        XCTAssertNotNil(model.error)
        XCTAssertEqual(model.confirmed, entry)
        await model.retry()
        XCTAssertEqual(calls, 2)
        XCTAssertFalse(model.pending)
        XCTAssertNil(model.error)
        XCTAssertFalse(model.confirmed.enabled)
        XCTAssertEqual(model.confirmed.overridesOn, 0)
    }

    @MainActor func testSwitchUsesServerValueAndRejectsAnotherAccountsDocument() async {
        let entry = AutopilotAccountSwitch(scope: .owner, accountId: "owner", enabled: true,
                                           overridesOn: 0, overridesOff: 0)
        var account = "owner"
        let model = AutopilotSwitchState(confirmed: entry, fixtureMode: FixtureMode(arguments: [])) { _, _ in
            AutopilotToggles(schema: "leafhft.autopilot-toggles.v1", accountId: account,
                             enabledDefault: true, engines: ["engine": .on])
        }
        await model.setEnabled(false)
        XCTAssertTrue(model.confirmed.enabled, "Never display the requested value in place of server truth")
        XCTAssertEqual(model.confirmed.overridesOn, 1)
        account = "aabbccdd"
        await model.setEnabled(false)
        XCTAssertNotNil(model.error)
        XCTAssertEqual(model.confirmed.accountId, "owner")
        XCTAssertTrue(model.confirmed.enabled)
    }

    @MainActor func testFixtureSwitchRendersLocalStateAndCannotWrite() async throws {
        let response = try await AutopilotView.fetch(fixture: true)
        let entry = try XCTUnwrap(response.accountSwitches?.first)
        XCTAssertEqual(entry.scope, .owner)
        XCTAssertEqual(entry.enabled, response.toggles.enabledDefault)
        let model = AutopilotSwitchState(confirmed: entry,
            fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])) { _, _ in
                XCTFail("Fixture switch wrote")
                throw FixtureAccessError.disabled
            }
        await model.setEnabled(!entry.enabled)
        await model.retry()
        XCTAssertEqual(model.confirmed, entry)
        XCTAssertFalse(model.pending)
    }

    func testLastFillDecodesEveryShapeAndStatusCoversEveryBranch() throws {
        var envelope = try fixtureObject()
        var view = try XCTUnwrap(envelope["view"] as? [String: Any])
        var engines = try XCTUnwrap(view["engines"] as? [[String: Any]])
        XCTAssertGreaterThanOrEqual(engines.count, 5)
        engines[0]["last_fill_at"] = "2026-09-26T19:07:04.559000Z"
        engines[0]["books"] = ["KXBTC-1H"]
        engines[1]["last_fill_at"] = "2026-09-26T19:07:04Z"
        engines[1]["books"] = ["KXBTC-1H"]
        engines[2]["last_fill_at"] = NSNull()
        engines[2]["books"] = ["KXETH-1H"]
        engines[3].removeValue(forKey: "last_fill_at")
        engines[3]["books"] = [String]()
        engines[4]["last_fill_at"] = "not a timestamp"
        engines[4]["books"] = ["KXETH-1H"]
        view["engines"] = engines
        envelope["view"] = view
        let decoded = try AutopilotResponse.decode(JSONSerialization.data(withJSONObject: envelope)).view.engines

        let fillDate = try XCTUnwrap(AutopilotEngine.parseFillTimestamp("2026-09-26T19:07:04Z"))
        let fractionalDate = try XCTUnwrap(AutopilotEngine.parseFillTimestamp("2026-09-26T19:07:04.559000Z"))
        XCTAssertEqual(fractionalDate.timeIntervalSince(fillDate), 0.559, accuracy: 0.001)
        XCTAssertEqual(decoded[0].lastFillAt, "2026-09-26T19:07:04.559000Z")
        XCTAssertEqual(decoded[1].lastFillAt, "2026-09-26T19:07:04Z")
        XCTAssertNil(decoded[2].lastFillAt)
        XCTAssertNil(decoded[3].lastFillAt)
        XCTAssertNil(try AutopilotResponse.decode(fixtureData()).view.engines[0].lastFillAt)

        let now = fillDate.addingTimeInterval(3 * 60 * 60)
        let fractional = decoded[0].lastFillStatus(now: now)
        XCTAssertTrue(fractional.label.hasPrefix("Last fill "), fractional.label)
        XCTAssertTrue(fractional.label.hasSuffix(" ago"), fractional.label)
        XCTAssertEqual(fractional.dormant, false)
        let plain = decoded[1].lastFillStatus(now: now)
        XCTAssertEqual(plain.label, "Last fill 3 hours ago")
        XCTAssertEqual(plain.dormant, false)
        let noFills = decoded[2].lastFillStatus(now: now)
        XCTAssertEqual(noFills.label, "No fills yet")
        XCTAssertEqual(noFills.dormant, true)
        let unreported = decoded[3].lastFillStatus(now: now)
        XCTAssertEqual(unreported.label, "Last fill not reported")
        XCTAssertNil(unreported.dormant)
        let unparsable = decoded[4].lastFillStatus(now: now)
        XCTAssertEqual(unparsable.label, "Last fill not reported")
        XCTAssertNil(unparsable.dormant)

        XCTAssertEqual(AutopilotEngine.dormantAfter, 86_400)
        let atBoundary = decoded[1].lastFillStatus(now: fillDate.addingTimeInterval(AutopilotEngine.dormantAfter))
        XCTAssertEqual(atBoundary.dormant, false)
        let pastBoundary = decoded[1].lastFillStatus(now: fillDate.addingTimeInterval(AutopilotEngine.dormantAfter + 1))
        XCTAssertEqual(pastBoundary.dormant, true)
        XCTAssertTrue(pastBoundary.label.hasPrefix("Last fill "), pastBoundary.label)
    }
}
