import Foundation
import XCTest
@testable import LeafHFT

final class AutopilotSummaryTests: XCTestCase {
    private func fixture() throws -> AutopilotResponse {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "autopilot", withExtension: "json", subdirectory: "Fixtures"))
        return try AutopilotResponse.decode(Data(contentsOf: url))
    }

    private func cycle(_ id: String, updatedAt: String) -> AutopilotCycle {
        AutopilotCycle(cycleId: id, etDay: "2026-09-26", stage: "advanced", status: "done", detail: "",
                       counts: nil, generation: nil, family: nil, updatedAt: updatedAt)
    }

    private func date(_ stamp: String) throws -> Date {
        try XCTUnwrap(AutopilotEngine.parseFillTimestamp(stamp))
    }

    // w3-F04: the two counts carry different scopes and each says which.
    @MainActor func testScopeFiguresLabelPopulationAndAutotuningSeparately() {
        let figures = AutopilotSummary.scopeFigures(population: 6, autotuning: 84, total: 90, accountId: "owner")
        XCTAssertEqual(figures.population.value, "6")
        XCTAssertEqual(figures.population.label, "Research population")
        XCTAssertEqual(figures.population.scope,
                       "Research population: 6 of 90 engines in this snapshot (account owner) are variants in the current autopilot generation.")
        XCTAssertEqual(figures.autotuning.value, "84")
        XCTAssertEqual(figures.autotuning.label, "Autotuning on")
        XCTAssertEqual(figures.autotuning.scope,
                       "Autotuning on: 84 of 90 engines in this snapshot have the autotuner on, by their own switch or the account default.")
        XCTAssertNotEqual(figures.population.label, figures.autotuning.label)
        XCTAssertFalse([figures.population.label, figures.autotuning.label].contains("Enabled"))
    }

    // w3-F04: 'None yet' is a muted state, never a dominant value.
    @MainActor func testAdvanceFigureIsMutedWhenNoneOrUnreadable() {
        let snapshot = "2026-09-26T14:05:00Z"
        let none = AutopilotSummary.advanceFigure(advancedDays: [], generatedAt: snapshot)
        XCTAssertNil(none.value)
        XCTAssertEqual(none.missing, "None yet")
        XCTAssertEqual(none.scope, "No cycle has reached the advanced stage yet.")
        let badDay = AutopilotSummary.advanceFigure(advancedDays: ["not-a-day"], generatedAt: snapshot)
        XCTAssertNil(badDay.value)
        XCTAssertEqual(badDay.missing, "Not reported")
        let badSnapshot = AutopilotSummary.advanceFigure(advancedDays: ["2026-09-25"], generatedAt: "garbage")
        XCTAssertNil(badSnapshot.value)
        XCTAssertEqual(badSnapshot.missing, "Not reported")
    }

    @MainActor func testAdvanceFigureCountsDaysFromNewestAdvance() {
        let figure = AutopilotSummary.advanceFigure(advancedDays: ["2026-09-20", "2026-09-24"],
                                                    generatedAt: "2026-09-26T14:05:00Z")
        XCTAssertEqual(figure.value, "2")
        XCTAssertEqual(figure.scope, "Days since advance: from the last advanced cycle (2026-09-24) to this snapshot.")
        let fractional = AutopilotSummary.advanceFigure(advancedDays: ["2026-09-26"],
                                                        generatedAt: "2026-09-26T14:05:00.250Z")
        XCTAssertEqual(fractional.value, "0")
        let ahead = AutopilotSummary.advanceFigure(advancedDays: ["2026-09-28"], generatedAt: "2026-09-26T14:05:00Z")
        XCTAssertEqual(ahead.value, "0")
    }

    @MainActor func testFixtureFiguresComeFromTheDocument() throws {
        let document = try fixture().view
        let figures = AutopilotSummary.figures(document)
        XCTAssertEqual(figures.population.value, String(document.engines.filter(\.inPopulation).count))
        XCTAssertEqual(figures.autotuning.value, String(document.engines.filter(\.toggleEffective).count))
        XCTAssertTrue(figures.population.scope.contains("of \(document.engines.count) engines"))
        XCTAssertEqual(figures.advance.value, "1")
    }

    // w3-F05: the snapshot's own time and its age at check time.
    @MainActor func testSnapshotLineUsesTheSnapshotTime() {
        XCTAssertEqual(AutopilotView.snapshotLine(generatedAt: "2026-09-26T14:05:00Z"),
                       "Snapshot as of 2026-09-26 14:05 UTC")
        XCTAssertEqual(AutopilotView.snapshotLine(generatedAt: "2026-09-26T14:05:00.123Z"),
                       "Snapshot as of 2026-09-26 14:05 UTC")
        XCTAssertEqual(AutopilotView.snapshotLine(generatedAt: ""), "Snapshot time not reported")
        XCTAssertEqual(AutopilotView.retainedLine(generatedAt: "2026-09-26T14:05:00Z"),
                       "Still showing the snapshot as of 2026-09-26 14:05 UTC.")
        XCTAssertEqual(AutopilotView.retainedLine(generatedAt: "bad"),
                       "Still showing the last snapshot; its time is not reported.")
    }

    @MainActor func testAgeLineMeasuresAgeAtCheckTime() throws {
        let generated = "2026-09-26T14:05:00Z"
        XCTAssertEqual(AutopilotView.ageLine(generatedAt: generated, checkedAt: nil), "Not checked yet")
        let checked = try date(generated).addingTimeInterval(2 * 3600 + 5 * 60)
        XCTAssertEqual(AutopilotView.ageLine(generatedAt: generated, checkedAt: checked),
                       "2 h 5 min old when checked 2026-09-26 16:10 UTC")
        let skewed = try date(generated).addingTimeInterval(-120)
        XCTAssertEqual(AutopilotView.ageLine(generatedAt: generated, checkedAt: skewed),
                       "Age unknown: snapshot time is after this device's clock, checked 2026-09-26 14:03 UTC")
        XCTAssertEqual(AutopilotView.ageLine(generatedAt: "bad", checkedAt: checked),
                       "Age not reported, checked 2026-09-26 16:10 UTC")
    }

    @MainActor func testAgeTextBoundaries() {
        XCTAssertEqual(AutopilotView.ageText(seconds: -30), "Under 1 min")
        XCTAssertNil(AutopilotView.ageText(seconds: -61))
        XCTAssertEqual(AutopilotView.ageText(seconds: 0), "Under 1 min")
        XCTAssertEqual(AutopilotView.ageText(seconds: 59), "Under 1 min")
        XCTAssertEqual(AutopilotView.ageText(seconds: 60), "1 min")
        XCTAssertEqual(AutopilotView.ageText(seconds: 3599), "59 min")
        XCTAssertEqual(AutopilotView.ageText(seconds: 3600), "1 h")
        XCTAssertEqual(AutopilotView.ageText(seconds: 90_000), "1 d 1 h")
        XCTAssertEqual(AutopilotView.ageText(seconds: 172_800), "2 d")
    }

    // w3-F05: a refresh that returns the same cycle says so.
    @MainActor func testRefreshNoteNamesWhetherACycleArrived() {
        let first = cycle("ap-20260926", updatedAt: "2026-09-26T14:00:00Z")
        XCTAssertNil(AutopilotView.refreshNote(previous: nil, current: first, firstLoad: true))
        XCTAssertEqual(AutopilotView.refreshNote(previous: first, current: first, firstLoad: false),
                       "No new cycle since 2026-09-26 14:00 UTC.")
        let updated = cycle("ap-20260926", updatedAt: "2026-09-26T15:00:00Z")
        XCTAssertEqual(AutopilotView.refreshNote(previous: first, current: updated, firstLoad: false),
                       "Cycle ap-20260926 updated 2026-09-26 15:00 UTC; no new cycle.")
        let next = cycle("ap-20260927", updatedAt: "2026-09-27T14:00:00Z")
        XCTAssertEqual(AutopilotView.refreshNote(previous: first, current: next, firstLoad: false),
                       "New cycle ap-20260927, updated 2026-09-27 14:00 UTC.")
        XCTAssertEqual(AutopilotView.refreshNote(previous: nil, current: first, firstLoad: false),
                       "New cycle ap-20260926, updated 2026-09-26 14:00 UTC.")
        XCTAssertEqual(AutopilotView.refreshNote(previous: first, current: nil, firstLoad: false),
                       "No cycle has been reported yet.")
    }

    @MainActor func testRefreshNoteDoesNotUseTradingDayForMissingOrUnreadableUpdateTime() {
        for stamp in ["", "bad"] {
            let current = cycle("ap-20260926", updatedAt: stamp)
            let previous = cycle("ap-20260925", updatedAt: "2026-09-25T14:00:00Z")
            let earlier = cycle("ap-20260926", updatedAt: "2026-09-26T14:00:00Z")
            XCTAssertEqual(AutopilotView.refreshNote(previous: nil, current: current, firstLoad: false),
                           "New cycle ap-20260926. Update time not reported.")
            XCTAssertEqual(AutopilotView.refreshNote(previous: previous, current: current, firstLoad: false),
                           "New cycle ap-20260926. Update time not reported.")
            XCTAssertEqual(AutopilotView.refreshNote(previous: current, current: current, firstLoad: false),
                           "No new cycle. Update time not reported.")
            XCTAssertEqual(AutopilotView.refreshNote(previous: earlier, current: current, firstLoad: false),
                           "No new cycle. Update time not reported.")
        }
    }

    // w3-F06: the switch note separates the autotuner from the trading pause.
    @MainActor func testSwitchesNoteDistinguishesTradingPause() {
        XCTAssertTrue(AutopilotView.switchesNote.contains("not the trading pause"))
        XCTAssertTrue(AutopilotView.switchesNote.contains("Settings"))
    }
}
