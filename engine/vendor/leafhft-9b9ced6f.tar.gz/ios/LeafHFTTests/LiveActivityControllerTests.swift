import ActivityKit
import Foundation
import XCTest
@testable import LeafHFT

@MainActor private final class FakeLiveActivityDriver: LiveActivityDriving {
    var areActivitiesEnabled = true
    var activities: [DrivenLiveActivity] = []
    var time = Date(timeIntervalSince1970: 1_800_000_000)
    var requests: [ActivityContent<KashbotLiveAttributes.ContentState>] = []
    var updates: [(String, ActivityContent<KashbotLiveAttributes.ContentState>, AlertConfiguration?)] = []
    var ended: [String] = []
    var maximumCount = 0
    var updateTokens: [String: AsyncStream<Data>.Continuation] = [:]
    var startTokens: AsyncStream<Data>.Continuation?
    func request(_ content: ActivityContent<KashbotLiveAttributes.ContentState>) throws -> String {
        requests.append(content)
        let id = "activity-\(requests.count)"
        activities.append(.init(id: id, startDate: time, state: content.state))
        maximumCount = max(maximumCount, activities.count)
        return id
    }
    func update(id: String, content: ActivityContent<KashbotLiveAttributes.ContentState>, alert: AlertConfiguration?) async {
        updates.append((id, content, alert))
        if let index = activities.firstIndex(where: { $0.id == id }) {
            activities[index] = .init(id: id, startDate: activities[index].startDate, state: content.state)
        }
        await Task.yield()
    }
    func end(id: String) async {
        await Task.yield()
        ended.append(id)
        activities.removeAll { $0.id == id }
    }
    func pushTokenUpdates(id: String) -> AsyncStream<Data> {
        AsyncStream { updateTokens[id] = $0 }
    }
    func pushToStartTokenUpdates() -> AsyncStream<Data> {
        AsyncStream { startTokens = $0 }
    }
}

@MainActor private final class LiveActivityHarness {
    let driver = FakeLiveActivityDriver()
    let suite = "LiveActivityControllerTests." + UUID().uuidString
    let defaults: UserDefaults
    var active = true
    var controller: LiveActivityController!
    init(upload: LiveActivityController.Upload? = nil) {
        defaults = UserDefaults(suiteName: suite)!
        controller = LiveActivityController(driver: driver, defaults: defaults,
            fixtureMode: FixtureMode(arguments: []), now: { [driver] in driver.time },
            isActive: { [weak self] in self?.active == true }, upload: upload ?? { _, _, _ in })
    }
    deinit { defaults.removePersistentDomain(forName: suite) }
    func snapshot(rows: [KashbotLiveAttributes.Row] = [], ledger: [KashbotLiveAttributes.Entry] = []) -> KashbotBoardSnapshot {
        .init(state: .init(asOf: Int(driver.time.timeIntervalSince1970), totalCents: 10000,
                          todayCents: 0, openCount: rows.count, rows: rows, ledger: ledger), ledger: ledger)
    }
    func row(_ ticker: String = "KXBTC-X", odds: Int = 49) -> KashbotLiveAttributes.Row {
        .init(ticker: ticker, side: "yes", milli: 4000, winCents: 184, oddsPct: odds, state: "open")
    }
}

final class LiveActivityControllerTests: XCTestCase {
    @MainActor func testStartsWithStaleDateAndDoesNotStartWhenInactiveOrUnauthorized() async {
        let h = LiveActivityHarness()
        let snapshot = h.snapshot()
        h.active = false
        await h.controller.apply(snapshot).value
        XCTAssertTrue(h.driver.requests.isEmpty)
        h.active = true
        h.driver.areActivitiesEnabled = false
        await h.controller.apply(snapshot).value
        XCTAssertTrue(h.driver.requests.isEmpty)
        h.driver.areActivitiesEnabled = true
        await h.controller.apply(snapshot).value
        XCTAssertEqual(h.driver.requests.count, 1)
        XCTAssertEqual(h.driver.requests.first?.state, snapshot.state)
        XCTAssertEqual(h.driver.requests.first?.staleDate, h.driver.time.addingTimeInterval(180))
        await h.controller.endAll().value
    }

    @MainActor func testNonMaterialUpdateHasNoAlertAndThrottlesForTenSeconds() async {
        let h = LiveActivityHarness()
        await h.controller.apply(h.snapshot()).value
        h.driver.time += 9
        await h.controller.apply(h.snapshot()).value
        XCTAssertTrue(h.driver.updates.isEmpty)
        h.driver.time += 1
        await h.controller.apply(h.snapshot()).value
        XCTAssertEqual(h.driver.updates.count, 1)
        XCTAssertNil(h.driver.updates.last?.2)
        h.driver.time += 9
        await h.controller.apply(h.snapshot()).value
        XCTAssertEqual(h.driver.updates.count, 1)
        h.driver.time += 1
        await h.controller.apply(h.snapshot()).value
        XCTAssertEqual(h.driver.updates.count, 2)
        await h.controller.endAll().value
    }

    @MainActor func testOpenCloseAndSettlementAlertImmediatelyWithPlainReasons() async throws {
        let h = LiveActivityHarness()
        await h.controller.apply(h.snapshot()).value
        await h.controller.apply(h.snapshot(rows: [h.row()])).value
        XCTAssertEqual(String(localized: try XCTUnwrap(h.driver.updates.last?.2).body), "Opened KXBTC-X YES 4")
        await h.controller.apply(h.snapshot()).value
        XCTAssertEqual(String(localized: try XCTUnwrap(h.driver.updates.last?.2).body), "Closed KXBTC-X")
        let entry = KashbotLiveAttributes.Entry(ticker: "KXFED-Y", pnlCents: 184, pnlBps: 3700, at: 1_800_000_000)
        await h.controller.apply(h.snapshot(ledger: [entry])).value
        let alert = try XCTUnwrap(h.driver.updates.last?.2)
        XCTAssertEqual(String(localized: alert.title), "Kashbot")
        XCTAssertEqual(String(localized: alert.body), "Settled +$1.84 (+37%)")
        XCTAssertEqual(h.driver.updates.count, 3)
        await h.controller.endAll().value
    }

    @MainActor func testDisabledEndsAllAndDoesNotRequestAgain() async {
        let h = LiveActivityHarness()
        await h.controller.apply(h.snapshot()).value
        h.defaults.set(false, forKey: "kashbot.live.enabled")
        await h.controller.apply(h.snapshot()).value
        XCTAssertTrue(h.driver.activities.isEmpty)
        XCTAssertEqual(h.driver.ended, ["activity-1"])
        await h.controller.checkRestart().value
        XCTAssertEqual(h.driver.requests.count, 1)
    }

    @MainActor func testTurningSettingOffEndsActivityWithoutAnyApply() async throws {
        let h = LiveActivityHarness()
        await h.controller.apply(h.snapshot()).value
        XCTAssertEqual(h.driver.activities.count, 1)
        h.defaults.set(false, forKey: "kashbot.live.enabled")
        for _ in 0..<200 where !h.driver.activities.isEmpty {
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTAssertTrue(h.driver.activities.isEmpty)
        XCTAssertEqual(h.driver.ended, ["activity-1"])
        XCTAssertEqual(h.driver.requests.count, 1)
        XCTAssertTrue(h.driver.updates.isEmpty)
        h.defaults.set(true, forKey: "kashbot.live.enabled")
        await h.controller.apply(h.snapshot()).value
        XCTAssertEqual(h.driver.requests.count, 2)
        await h.controller.endAll().value
    }

    @MainActor func testOddsBuzzOnlyWhenSettingIsOnAndWorksInBothDirections() async throws {
        let h = LiveActivityHarness()
        await h.controller.apply(h.snapshot(rows: [h.row(odds: 49)])).value
        h.driver.time += 10
        await h.controller.apply(h.snapshot(rows: [h.row(odds: 51)])).value
        XCTAssertNil(h.driver.updates.last?.2)
        h.defaults.set(true, forKey: "kashbot.live.buzzOnOdds")
        await h.controller.apply(h.snapshot(rows: [h.row(odds: 49)])).value
        XCTAssertEqual(String(localized: try XCTUnwrap(h.driver.updates.last?.2).body), "Odds crossed 50%")
        await h.controller.apply(h.snapshot(rows: [h.row(odds: 50)])).value
        XCTAssertNotNil(h.driver.updates.last?.2)
        XCTAssertEqual(h.driver.updates.count, 3)
        await h.controller.endAll().value
    }

    @MainActor func testRestartsOnlyAfterSevenAndHalfHoursWhileActive() async {
        let h = LiveActivityHarness()
        await h.controller.apply(h.snapshot()).value
        h.driver.time += 7.5 * 3600 - 1
        await h.controller.checkRestart().value
        XCTAssertEqual(h.driver.requests.count, 1)
        h.driver.time += 1
        h.active = false
        await h.controller.apply(h.snapshot()).value
        await h.controller.checkRestart().value
        XCTAssertEqual(h.driver.requests.count, 1)
        XCTAssertTrue(h.driver.ended.isEmpty)
        h.active = true
        await h.controller.checkRestart().value
        XCTAssertEqual(h.driver.requests.count, 2)
        XCTAssertEqual(h.driver.ended, ["activity-1"])
        XCTAssertEqual(h.driver.activities.count, 1)
        XCTAssertEqual(h.driver.maximumCount, 1)
        await h.controller.endAll().value
    }

    @MainActor func testConcurrentAppliesAndRestoredDuplicatesLeaveOneActivity() async {
        let h = LiveActivityHarness()
        let first = h.controller.apply(h.snapshot())
        let second = h.controller.apply(h.snapshot(rows: [h.row()]))
        await first.value
        await second.value
        XCTAssertEqual(h.driver.requests.count, 1)
        XCTAssertEqual(h.driver.maximumCount, 1)
        h.driver.activities.append(.init(id: "restored", startDate: h.driver.time.addingTimeInterval(-10), state: h.snapshot().state))
        await h.controller.apply(h.snapshot()).value
        XCTAssertEqual(h.driver.activities.count, 1)
        XCTAssertTrue(h.driver.ended.contains("restored"))
        await h.controller.endAll().value
    }

    @MainActor func testUploadsBothTokenKindsAsLowercaseHex() async {
        let uploaded = expectation(description: "Both token kinds uploaded")
        uploaded.expectedFulfillmentCount = 2
        var tokens: [(String, String, String?)] = []
        let h = LiveActivityHarness { kind, token, id in
            tokens.append((kind, token, id))
            uploaded.fulfill()
        }
        await h.controller.apply(h.snapshot()).value
        h.driver.updateTokens["activity-1"]?.yield(Data([0, 171, 255]))
        h.driver.startTokens?.yield(Data([16, 205]))
        await fulfillment(of: [uploaded], timeout: 2)
        XCTAssertTrue(tokens.contains { $0.0 == "update" && $0.1 == "00abff" && $0.2 == "activity-1" })
        XCTAssertTrue(tokens.contains { $0.0 == "start" && $0.1 == "10cd" && $0.2 == nil })
        await h.controller.endAll().value
    }

    @MainActor func testFailedTokenRetriesOnForegroundAndDisabledStopsUpload() async {
        let attempted = expectation(description: "First upload attempted")
        var attempts = 0
        let h = LiveActivityHarness { _, _, _ in
            attempts += 1
            if attempts == 1 { attempted.fulfill(); throw URLError(.timedOut) }
        }
        await h.controller.apply(h.snapshot()).value
        h.driver.updateTokens["activity-1"]?.yield(Data([171]))
        await fulfillment(of: [attempted], timeout: 2)
        await h.controller.checkRestart().value
        XCTAssertEqual(attempts, 2)
        h.defaults.set(false, forKey: "kashbot.live.enabled")
        h.driver.startTokens?.yield(Data([1]))
        await h.controller.apply(h.snapshot()).value
        await h.controller.checkRestart().value
        XCTAssertEqual(attempts, 2)
    }

    @MainActor func testEndAllDismissesEveryActivity() async {
        let h = LiveActivityHarness()
        let state = h.snapshot().state
        h.driver.activities = ["one", "two"].map { .init(id: $0, startDate: h.driver.time, state: state) }
        h.driver.activities.append(.init(id: "finished", startDate: h.driver.time, state: state, isRunning: false))
        await h.controller.endAll().value
        XCTAssertEqual(Set(h.driver.ended), ["one", "two", "finished"])
        XCTAssertTrue(h.driver.activities.isEmpty)
    }

    @MainActor func testForegroundRestoresRemoteActivityWithoutReplacingNewerState() async {
        let h = LiveActivityHarness()
        await h.controller.apply(h.snapshot()).value
        h.driver.time += 30
        let remote = h.snapshot(rows: [h.row()]).state
        h.driver.activities = [.init(id: "activity-1", startDate: h.driver.time, state: remote)]
        await h.controller.checkRestart().value
        XCTAssertTrue(h.driver.updates.isEmpty)
        XCTAssertEqual(h.driver.activities.first?.state, remote)
        await h.controller.endAll().value
    }

    @MainActor func testFixtureModeNeverTouchesDriverOrUpload() async {
        let driver = FakeLiveActivityDriver()
        let controller = LiveActivityController(driver: driver,
            fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]),
            upload: { _, _, _ in XCTFail("Fixture token upload") })
        let snapshot = KashbotBoardSnapshot(state: .init(asOf: 1, totalCents: 0, todayCents: 0,
            openCount: 0, rows: [], ledger: []), ledger: [])
        await controller.apply(snapshot).value
        await controller.checkRestart().value
        await controller.endAll().value
        XCTAssertTrue(driver.requests.isEmpty)
        XCTAssertTrue(driver.ended.isEmpty)
        XCTAssertNil(driver.startTokens)
    }
}
