import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor final class MonitorMoneyTests: XCTestCase {
    private let utc = TimeZone(identifier: "UTC")!

    private func at(_ value: String) -> Date {
        ISO8601DateFormatter().date(from: value)!
    }

    private var now: Date { at("2026-09-29T13:30:00Z") }

    private func activity(_ fills: [String]) throws -> RunnerActivity {
        let json = """
        {"schema_version":1,"generated_at":"2026-09-29T13:29:00Z","host":"fixture","budget":null,
         "orders":[],"refusals":[],"fills":[\(fills.joined(separator: ","))]}
        """
        return try accountJSONDecoder().decode(RunnerActivity.self, from: Data(json.utf8))
    }

    private func fill(_ ticker: String, at time: String, pnl: Int? = nil, basis: Int? = nil, fee: Int? = nil) -> String {
        var fields = ["\"ticker\":\"\(ticker)\"", "\"kind\":\"fill\"", "\"state\":\"filled\"", "\"occurred_at\":\"\(time)\""]
        if let pnl { fields.append("\"pnl_cents\":\(pnl)") }
        if let basis { fields.append("\"cost_basis_cents\":\(basis)") }
        if let fee { fields.append("\"fee_cents\":\(fee)") }
        return "{" + fields.joined(separator: ",") + "}"
    }

    private func sample() throws -> RunnerActivity {
        try activity([
            fill("A", at: "2026-09-29T13:10:00Z", pnl: -500, basis: 2000, fee: 30),
            fill("B", at: "2026-09-29T12:50:00Z", pnl: 200, basis: 3000, fee: 20),
            fill("C", at: "2026-09-29T11:00:00Z", pnl: 900, basis: 1000, fee: 10),
            fill("D", at: "2026-09-29T13:15:00Z", fee: 5),
            fill("E", at: "2026-09-29T13:40:00Z", pnl: 100, basis: 100, fee: 1)
        ])
    }

    func testFiguresSumOnlyClosedTradesInsideTheSelectedPeriod() throws {
        let hour = MoneyCard.figures(activity: try sample(), range: .hour, now: now)
        XCTAssertEqual(hour, MoneyCard.Figures(pnlCents: -300, returnPercent: -6, feesCents: 50,
                                               closedTrades: 2, basisTrades: 2))
        let all = MoneyCard.figures(activity: try sample(), range: .all, now: now)
        XCTAssertEqual(all, MoneyCard.Figures(pnlCents: 600, returnPercent: 10, feesCents: 60,
                                              closedTrades: 3, basisTrades: 3))
    }

    func testMissingActivityIsNotReportedNotZero() {
        let figures = MoneyCard.figures(activity: nil, range: .day, now: now)
        XCTAssertNil(figures.pnlCents)
        XCTAssertNil(figures.returnPercent)
        XCTAssertNil(figures.feesCents)
        XCTAssertEqual(MoneyCard.realizedCaption(range: .day, figures: figures),
                       "Realized P/L over the last 1d · runner trades not reported")
        XCTAssertTrue(MoneyCard.basisNote(range: .day, figures: figures).hasPrefix("Return and fees: not reported."))
    }

    func testCaptionNamesPeriodAndBasis() throws {
        let figures = MoneyCard.figures(activity: try sample(), range: .hour, now: now)
        XCTAssertEqual(MoneyCard.realizedCaption(range: .hour, figures: figures),
                       "Realized P/L over the last 1h · sum of 2 reported closed trades. Full-period trade coverage and fee inclusion are not reported.")
        XCTAssertEqual(MoneyCard.realizedCaption(range: .all, figures: MoneyCard.figures(activity: try sample(), range: .all, now: now)),
                       "Realized P/L over all reported history · sum of 3 reported closed trades. Full-period trade coverage and fee inclusion are not reported.")
        let note = MoneyCard.basisNote(range: .hour, figures: figures)
        XCTAssertTrue(note.contains("Return: realized P/L ÷ cost basis of the same 2 trades."))
        XCTAssertTrue(note.contains("this card neither adds nor subtracts them"))
        XCTAssertTrue(note.contains("the latest Kalshi balance read, not a 1h figure"))
        XCTAssertTrue(note.contains(KashbotTradingPocket.label))
    }

    func testReturnNamesPartialCostBasis() throws {
        let partial = try activity([
            fill("A", at: "2026-09-29T13:10:00Z", pnl: -500, basis: 2000),
            fill("B", at: "2026-09-29T13:20:00Z", pnl: 100)
        ])
        let figures = MoneyCard.figures(activity: partial, range: .hour, now: now)
        XCTAssertEqual(figures.basisTrades, 1)
        XCTAssertEqual(figures.closedTrades, 2)
        XCTAssertNil(figures.returnPercent)
        XCTAssertNil(figures.feesCents)
        XCTAssertTrue(MoneyCard.basisNote(range: .hour, figures: figures)
            .hasPrefix("Return for the last 1h: not reported; cost basis is missing for some reported closed trades."))
        let none = MoneyCard.figures(activity: try activity([fill("B", at: "2026-09-29T13:20:00Z", pnl: 100)]),
                                     range: .hour, now: now)
        XCTAssertNil(none.returnPercent)
        XCTAssertTrue(MoneyCard.basisNote(range: .hour, figures: none)
            .contains("cost basis is missing"))
    }

    func testAsOfNamesEachReadAndMissingTimestamps() throws {
        let trades = at("2026-09-29T12:35:00Z")
        let balance = at("2026-09-29T12:34:00Z")
        XCTAssertEqual(MoneyCard.asOfText(tradesAt: trades, balanceAt: balance, now: now, timeZone: utc),
                       "As of reads: runner trades 12:35 PM; Kalshi balance 12:34 PM. Source update times may differ.")
        XCTAssertEqual(MoneyCard.asOfText(tradesAt: trades, balanceAt: nil, now: now, timeZone: utc),
                       "As of read: runner trades 12:35 PM; Kalshi balance read time not reported")
        XCTAssertEqual(MoneyCard.asOfText(tradesAt: nil, balanceAt: balance, now: now, timeZone: utc),
                       "As of read: Kalshi balance 12:34 PM; runner trades read time not reported")
        XCTAssertEqual(MoneyCard.asOfText(tradesAt: nil, balanceAt: nil, now: now, timeZone: utc), "As of: not reported")
        XCTAssertEqual(MoneyCard.clockText(at("2026-09-28T23:05:00Z"), now: now, timeZone: utc), "Sep 28, 11:05 PM")
        XCTAssertEqual(MoneyCard.tradesTime(activity: try sample(), observedAt: now), now)
        XCTAssertNil(MoneyCard.tradesTime(activity: try sample(), observedAt: nil))
        XCTAssertNil(MoneyCard.tradesTime(activity: nil, observedAt: now))
    }

    func testSinceLastLookedShowsOnlySamePeriodChanges() {
        let seen = MoneyCard.Seen(range: .day, pnlCents: -6_542, at: at("2026-09-29T12:20:00Z"))
        XCTAssertEqual(MoneyCard.sinceLastLookedText(seen: seen, range: .day, pnlCents: -12_642, now: now, timeZone: utc),
                       "-$61.00 in 1d realized P/L since you looked at 12:20 PM. The rolling window or reported trades may have changed.")
        XCTAssertEqual(MoneyCard.sinceLastLookedText(seen: seen, range: .day, pnlCents: -6_000, now: now, timeZone: utc),
                       "+$5.42 in 1d realized P/L since you looked at 12:20 PM. The rolling window or reported trades may have changed.")
        XCTAssertNil(MoneyCard.sinceLastLookedText(seen: seen, range: .day, pnlCents: -6_542, now: now, timeZone: utc))
        XCTAssertNil(MoneyCard.sinceLastLookedText(seen: seen, range: .hour, pnlCents: -100, now: now, timeZone: utc))
        XCTAssertNil(MoneyCard.sinceLastLookedText(seen: nil, range: .day, pnlCents: -100, now: now, timeZone: utc))
        XCTAssertNil(MoneyCard.sinceLastLookedText(seen: seen, range: .day, pnlCents: nil, now: now, timeZone: utc))
    }

    func testComparisonStartsAtFirstAvailableFigureAndResetsForAnotherPeriod() {
        XCTAssertNil(MoneyCard.comparisonBaseline(seen: nil, range: .day, pnlCents: nil, now: now))
        let first = MoneyCard.comparisonBaseline(seen: nil, range: .day, pnlCents: -100, now: now)
        XCTAssertEqual(first, MoneyCard.Seen(range: .day, pnlCents: -100, at: now))
        let later = now.addingTimeInterval(60)
        XCTAssertEqual(MoneyCard.comparisonBaseline(seen: first, range: .day, pnlCents: -200, now: later), first)
        XCTAssertEqual(MoneyCard.comparisonBaseline(seen: first, range: .day, pnlCents: nil, now: later), first)
        XCTAssertEqual(MoneyCard.comparisonBaseline(seen: first, range: .hour, pnlCents: -50, now: later),
                       MoneyCard.Seen(range: .hour, pnlCents: -50, at: later))
        XCTAssertNil(MoneyCard.comparisonBaseline(seen: first, range: .hour, pnlCents: nil, now: later))
    }

    func testChartAccessibilityDoesNotInventZeroBalances() {
        XCTAssertEqual(EquityChart.balanceAccessibility(cash: nil, account: nil),
                       "latest Kalshi balance read: cash not reported; account value not reported")
        XCTAssertEqual(EquityChart.balanceAccessibility(cash: 0, account: 81105),
                       "latest Kalshi balance read: cash 0 cents; account value 81105 cents")
        XCTAssertEqual(EquityChart.balanceAccessibility(cash: 81105, account: nil),
                       "latest Kalshi balance read: cash 81105 cents; account value not reported")
    }

    func testCoverageSaysWhenTheChartSpansLessThanTheRange() {
        let partial = [at("2026-09-29T13:08:00Z"), at("2026-09-29T13:13:00Z")]
        XCTAssertEqual(EquityChart.coverageText(range: .hour, now: now, dates: partial, timeZone: utc),
                       "Chart observations span 1:08 PM to 1:13 PM, not the full 1h; gaps may remain within that span. Realized P/L uses reported closed trades in the last 1h, not chart movement.")
        let full = [at("2026-09-29T12:30:00Z"), now]
        XCTAssertNil(EquityChart.coverageText(range: .hour, now: now, dates: full, timeZone: utc))
        XCTAssertNil(EquityChart.coverageText(range: .all, now: now, dates: partial, timeZone: utc))
        XCTAssertEqual(EquityChart.coverageText(range: .hour, now: now, dates: [], timeZone: utc),
                       "No chart observations in the last 1h. Trade coverage is independent of chart coverage.")
        XCTAssertNotNil(EquityChart.coverageText(range: .hour, now: now,
                            dates: [now.addingTimeInterval(-3599), now], timeZone: utc))
    }

    func testFloorLegendOnlyWhenDrawnAndNamesItsAmountAndSource() {
        XCTAssertNil(EquityChart.floorLegend(floors: [1500], drawn: false))
        XCTAssertEqual(EquityChart.floorLegend(floors: [1500], drawn: true), "Floor $15.00 · dashed")
        XCTAssertEqual(EquityChart.floorLegend(floors: [], drawn: true), "Floor $10.00 default · dashed")
        XCTAssertEqual(EquityChart.floorLabel(floors: [1500]), "Entry cash floor $15.00")
        XCTAssertEqual(EquityChart.floorLabel(floors: [1500, 2500]), "Highest entry cash floor $25.00")
        XCTAssertEqual(EquityChart.floorLabel(floors: []), "Entry cash floor $10.00 (app default, no engine reports one)")
    }

    func testSingleAccountIsAStaticLabelAndSeveralKeepTheChip() {
        XCTAssertEqual(AccountView.accountRail(labels: []), .init(label: "Main runner", isStatic: true))
        XCTAssertEqual(AccountView.accountRail(labels: [" Evan main "]), .init(label: "Evan main", isStatic: true))
        XCTAssertEqual(AccountView.accountRail(labels: ["  "]), .init(label: "Main runner", isStatic: true))
        XCTAssertEqual(AccountView.accountRail(labels: ["One", "Two"]), .init(label: "Main runner", isStatic: false))
    }

    func testReadOnlyExplanationSeparatesPhoneAccessFromRunnerActivity() {
        let lines = AccountView.readOnlyExplanation(automation: "Live")
        XCTAssertEqual(lines.count, 3)
        XCTAssertTrue(lines[0].hasPrefix("Phone access: read-only."))
        XCTAssertTrue(lines[0].contains("never places, changes or cancels a Kalshi order"))
        XCTAssertTrue(lines[1].hasPrefix("Runner status: Live."))
    }

    func testMissingFeesDoNotBecomeZeroAndReportedZeroRemainsZero() throws {
        let missing = MoneyCard.figures(activity: try activity([
            fill("A", at: "2026-09-29T13:10:00Z", pnl: 100, basis: 200, fee: 10),
            fill("B", at: "2026-09-29T13:20:00Z", pnl: 200, basis: 300)
        ]), range: .hour, now: now)
        XCTAssertNil(missing.feesCents)
        XCTAssertEqual(missing.pnlCents, 300)
        XCTAssertEqual(missing.returnPercent, 60)
        XCTAssertTrue(MoneyCard.basisNote(range: .hour, figures: missing).contains("not reported for every trade"))
        let zero = MoneyCard.figures(activity: try activity([
            fill("A", at: "2026-09-29T13:10:00Z", pnl: 100, basis: 200, fee: 0)
        ]), range: .hour, now: now)
        XCTAssertEqual(zero.feesCents, 0)
    }

    func testPeriodFilteringIncludesBoundariesAndRejectsInvalidDates() throws {
        let rows = try activity([
            fill("START", at: "2026-09-29T12:30:00Z", pnl: 10),
            fill("END", at: "2026-09-29T13:30:00Z", pnl: 20),
            fill("OLD", at: "2026-09-29T12:29:59Z", pnl: 40),
            fill("BAD", at: "not-a-date", pnl: 80)
        ])
        XCTAssertEqual(MoneyCard.closedTrades(activity: rows, range: .hour, now: now).map(\.ticker), ["START", "END"])
        XCTAssertEqual(MoneyCard.figures(activity: rows, range: .hour, now: now).pnlCents, 30)
    }
}
