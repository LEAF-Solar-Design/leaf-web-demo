import Foundation
import XCTest
import LeafHFTCore

enum PausedBookPayload {
    static func candidate(_ changes: [String: Any] = [:]) -> [String: Any] {
        let base: [String: Any] = [
            "ticker": "KXBTC15M-26SEP271915-15", "expiry_ms": 1790550900000,
            "status": "active", "quote_age_ms": 1200, "strike_set": true,
            "eval_at_ms": 1790550000000, "intent_sent": false,
            "gate": "skip_engine_disabled",
            "seconds_to_close": NSNull(), "k": NSNull(), "k_source": NSNull(),
            "side_yes": NSNull(), "ask_cents": NSNull(), "fair_cents": NSNull(),
            "fee_cents": NSNull(), "edge_cents": NSNull(), "edge_required_cents": NSNull(),
            "depth": NSNull(), "favorite": NSNull()
        ]
        return base.merging(changes) { _, new in new }
    }

    static func dictionary(_ shape: String, changes: [String: Any] = [:],
                           empty: Bool = false, withoutEval: Bool = false,
                           withoutMinK: Bool = false, mixed: Bool = false) -> [String: Any] {
        var bookId = "BTC-15M"
        var enabled = false
        var values: [String: Any] = [:]
        switch shape {
        case "P2": bookId = "ETH-15M"
        case "I": values["intent_sent"] = true
        case "E", "N":
            bookId = "ETH-15M"
            enabled = true
        case "R", "S":
            bookId = "SOL-15M"
            enabled = shape == "S"
            values = ["gate": "skip_edge_below_bar", "seconds_to_close": shape == "S" ? 125 : 59.2,
                      "k": 4, "side_yes": true, "edge_cents": 1.5,
                      "edge_required_cents": 2.0, "depth": 40, "favorite": true]
        case "PR": values = ["seconds_to_close": 59.2, "side_yes": true]
        case "Q", "U":
            bookId = "XRP-15M"
            enabled = shape == "U"
            values["gate"] = "skip_no_quote"
        default: break
        }
        values.merge(changes) { _, new in new }
        var candidates = [candidate(values)]
        if shape == "S" { candidates.append(candidate(values.merging(["seconds_to_close": -5]) { _, new in new })) }
        if mixed { candidates.append(candidate(["gate": "skip_no_quote"])) }
        if empty { candidates = [] }
        var evaluation: [String: Any] = ["min_k": 5, "window_s": 900, "candidates": candidates]
        if withoutMinK { evaluation.removeValue(forKey: "min_k") }
        let telemetry: [String: Any] = withoutEval ? [:] : ["eval": evaluation]
        var payload: [String: Any] = [
            "book_id": bookId, "host": "opbox-1", "enabled": enabled, "kalshi_book": telemetry
        ]
        if shape == "N" { payload.removeValue(forKey: "enabled") }
        return payload
    }
}

final class PausedStatePresentationTests: XCTestCase {
    private func decodeBook(_ shape: String, changes: [String: Any] = [:],
                            empty: Bool = false, withoutEval: Bool = false,
                            withoutMinK: Bool = false, mixed: Bool = false) throws -> Book {
        let payload = PausedBookPayload.dictionary(shape, changes: changes, empty: empty,
            withoutEval: withoutEval, withoutMinK: withoutMinK, mixed: mixed)
        let data = try JSONSerialization.data(withJSONObject: payload)
        return try accountJSONDecoder().decode(Book.self, from: data)
    }

    private func firstCandidate(_ book: Book) throws -> Candidate {
        try XCTUnwrap(book.kalshiBook.eval?.candidates?.first)
    }

    private func assertCells(_ cells: BookCandidateCells, hold: BookEntryHold?,
                             side: String, observations: String, edge: String, closes: String,
                             file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertEqual(cells.hold, hold, file: file, line: line)
        XCTAssertEqual(cells.side, side, file: file, line: line)
        XCTAssertEqual(cells.observations, observations, file: file, line: line)
        XCTAssertEqual(cells.edge, edge, file: file, line: line)
        XCTAssertEqual(cells.closes, closes, file: file, line: line)
    }

    func testEntryHoldReadsGateAndEnabledOnly() throws {
        XCTAssertEqual(MonitorPresentation.entryHold(bookEnabled: false, gate: "skip_engine_disabled"), .bookPaused)
        XCTAssertEqual(MonitorPresentation.entryHold(bookEnabled: true, gate: "skip_engine_disabled"), .entriesOff)
        XCTAssertEqual(MonitorPresentation.entryHold(bookEnabled: nil, gate: "skip_engine_disabled"), .entriesOff)
        XCTAssertNil(MonitorPresentation.entryHold(bookEnabled: false, gate: "skip_edge_below_bar"))
        XCTAssertNil(MonitorPresentation.entryHold(bookEnabled: false, gate: "skip_no_quote"))
        XCTAssertNil(MonitorPresentation.entryHold(bookEnabled: false, gate: "passed"))
        XCTAssertNil(MonitorPresentation.entryHold(bookEnabled: false, gate: nil))
        XCTAssertNil(MonitorPresentation.entryHold(bookEnabled: false, gate: ""))
        XCTAssertNil(MonitorPresentation.entryHold(bookEnabled: true, gate: "skip_edge_below_bar"))
        XCTAssertNil(MonitorPresentation.entryHold(bookEnabled: nil, gate: nil))
        let p = try decodeBook("P")
        let e = try decodeBook("E")
        let i = try decodeBook("I")
        let r = try decodeBook("R")
        let q = try decodeBook("Q")
        XCTAssertEqual(MonitorPresentation.chipHold(bookEnabled: p.enabled, candidate: try firstCandidate(p)), .bookPaused)
        XCTAssertEqual(MonitorPresentation.chipHold(bookEnabled: e.enabled, candidate: try firstCandidate(e)), .entriesOff)
        XCTAssertNil(MonitorPresentation.chipHold(bookEnabled: i.enabled, candidate: try firstCandidate(i)))
        XCTAssertNil(MonitorPresentation.chipHold(bookEnabled: r.enabled, candidate: try firstCandidate(r)))
        XCTAssertNil(MonitorPresentation.chipHold(bookEnabled: q.enabled, candidate: try firstCandidate(q)))
        XCTAssertEqual(MonitorPresentation.entryHold(book: p), .bookPaused)
        XCTAssertEqual(MonitorPresentation.entryHold(book: try decodeBook("PR")), .bookPaused)
        XCTAssertEqual(MonitorPresentation.entryHold(book: e), .entriesOff)
        XCTAssertEqual(MonitorPresentation.entryHold(book: try decodeBook("N")), .entriesOff)
        XCTAssertNil(MonitorPresentation.entryHold(book: r))
        XCTAssertNil(MonitorPresentation.entryHold(book: q))
        XCTAssertNil(MonitorPresentation.entryHold(book: try decodeBook("U")))
        XCTAssertNil(MonitorPresentation.entryHold(book: try decodeBook("P", empty: true)))
        XCTAssertNil(MonitorPresentation.entryHold(book: try decodeBook("P", withoutEval: true)))
        XCTAssertNil(MonitorPresentation.entryHold(book: try decodeBook("P", mixed: true)))
    }

    func testFieldReportedValueAlwaysWins() {
        XCTAssertEqual(MonitorPresentation.field("x", hold: .bookPaused), "x")
        XCTAssertEqual(MonitorPresentation.field("x", hold: .entriesOff), "x")
        XCTAssertEqual(MonitorPresentation.field(nil, hold: .bookPaused), "Book paused")
        XCTAssertEqual(MonitorPresentation.field(nil, hold: .entriesOff), "Entries off")
        XCTAssertEqual(MonitorPresentation.field(nil, hold: nil), "Not reported")
        XCTAssertEqual(MonitorPresentation.field(nil, hold: nil, missing: "Side unknown"), "Side unknown")
    }

    func testPausedBookCellsReadBookPaused() throws {
        let p = try decodeBook("P")
        let i = try decodeBook("I")
        assertCells(BookCandidateCells(book: p, candidate: try firstCandidate(p)), hold: .bookPaused,
                    side: "Book paused", observations: "Book paused", edge: "Book paused", closes: "Book paused")
        assertCells(BookCandidateCells(book: i, candidate: try firstCandidate(i)), hold: .bookPaused,
                    side: "Book paused", observations: "Book paused", edge: "Book paused", closes: "Book paused")
        assertCells(BookCandidateCells(book: p, candidate: try firstCandidate(p), missing: "Unknown"), hold: .bookPaused,
                    side: "Book paused", observations: "Book paused", edge: "Book paused", closes: "Book paused")
        assertCells(BookCandidateCells(book: i, candidate: try firstCandidate(i), missing: "Unknown"), hold: .bookPaused,
                    side: "Book paused", observations: "Book paused", edge: "Book paused", closes: "Book paused")
    }

    func testEngineOffCellsReadEntriesOff() throws {
        let e = try decodeBook("E")
        let n = try decodeBook("N")
        assertCells(BookCandidateCells(book: e, candidate: try firstCandidate(e)), hold: .entriesOff,
                    side: "Entries off", observations: "Entries off", edge: "Entries off", closes: "Entries off")
        assertCells(BookCandidateCells(book: n, candidate: try firstCandidate(n)), hold: .entriesOff,
                    side: "Entries off", observations: "Entries off", edge: "Entries off", closes: "Entries off")
    }

    func testReportedCellsWinOverPause() throws {
        let r = try decodeBook("R")
        let pr = try decodeBook("PR")
        let partial = try decodeBook("P", changes: ["edge_required_cents": 2.0])
        assertCells(BookCandidateCells(book: r, candidate: try firstCandidate(r)), hold: nil,
                    side: "YES", observations: "4 of 5", edge: "1.5¢ / 2.0¢", closes: "1:00")
        assertCells(BookCandidateCells(book: r, candidate: try firstCandidate(r), missing: "Unknown"), hold: nil,
                    side: "YES", observations: "4 of 5", edge: "1.5¢ / 2.0¢", closes: "1:00")
        assertCells(BookCandidateCells(book: pr, candidate: try firstCandidate(pr)), hold: .bookPaused,
                    side: "YES", observations: "Book paused", edge: "Book paused", closes: "1:00")
        XCTAssertEqual(BookCandidateCells(book: partial, candidate: try firstCandidate(partial)).edge, "Book paused / 2.0¢")
    }

    func testOtherMissingFieldsKeepTodaysCopy() throws {
        let q = try decodeBook("Q")
        let u = try decodeBook("U")
        assertCells(BookCandidateCells(book: q, candidate: try firstCandidate(q)), hold: nil,
                    side: "Not reported", observations: "? of 5", edge: "Not reported / Not reported", closes: "Not reported")
        assertCells(BookCandidateCells(book: u, candidate: try firstCandidate(u)), hold: nil,
                    side: "Not reported", observations: "? of 5", edge: "Not reported / Not reported", closes: "Not reported")
        assertCells(BookCandidateCells(book: q, candidate: try firstCandidate(q), missing: "Unknown"), hold: nil,
                    side: "Unknown", observations: "? of 5", edge: "Unknown / Unknown", closes: "Unknown")
        assertCells(BookCandidateCells(book: u, candidate: try firstCandidate(u), missing: "Unknown"), hold: nil,
                    side: "Unknown", observations: "? of 5", edge: "Unknown / Unknown", closes: "Unknown")
        let noMinimum = try decodeBook("U", changes: ["k": 3], withoutMinK: true)
        XCTAssertEqual(BookCandidateCells(book: noMinimum, candidate: try firstCandidate(noMinimum)).observations, "3 of ?")
    }

    func testNextCloseReportedHeldAndUnreported() throws {
        let p = try decodeBook("P")
        let p2 = try decodeBook("P2")
        let e = try decodeBook("E")
        let q = try decodeBook("Q")
        let u = try decodeBook("U")
        let s = try decodeBook("S")
        let pr = try decodeBook("PR")
        XCTAssertEqual(MonitorPresentation.nextClose(books: [p, s]), .seconds(125))
        XCTAssertEqual(MonitorPresentation.nextClose(books: [pr]), .seconds(59.2))
        XCTAssertEqual(MonitorPresentation.nextClose(books: [p]), .allPaused(books: 1))
        XCTAssertEqual(MonitorPresentation.nextClose(books: [p, p2]), .allPaused(books: 2))
        XCTAssertEqual(MonitorPresentation.nextClose(books: [p, e]), .entriesOff)
        XCTAssertEqual(MonitorPresentation.nextClose(books: [e]), .entriesOff)
        XCTAssertEqual(MonitorPresentation.nextClose(books: [p, q]), .notReported)
        XCTAssertEqual(MonitorPresentation.nextClose(books: [p, u]), .notReported)
        XCTAssertEqual(MonitorPresentation.nextClose(books: []), .notReported)
        XCTAssertEqual(MonitorPresentation.nextCloseText(.seconds(125)), "2:05")
        XCTAssertEqual(MonitorPresentation.nextCloseText(.allPaused(books: 1)), "Book paused")
        XCTAssertEqual(MonitorPresentation.nextCloseText(.allPaused(books: 2)), "All books paused")
        XCTAssertEqual(MonitorPresentation.nextCloseText(.entriesOff), "Entries off")
        XCTAssertEqual(MonitorPresentation.nextCloseText(.notReported), "Not reported")
        XCTAssertEqual(MonitorPresentation.nextCloseText(.seconds(Double(Int.max))), "Not reported")
        XCTAssertEqual(MonitorPresentation.clock(seconds: 59.2), "1:00")
        XCTAssertEqual(MonitorPresentation.clock(seconds: 125), "2:05")
        XCTAssertEqual(MonitorPresentation.clock(seconds: -3), "0:00")
        XCTAssertNil(MonitorPresentation.clock(seconds: nil))
        XCTAssertNil(MonitorPresentation.clock(seconds: .infinity))
        XCTAssertNil(MonitorPresentation.clock(seconds: .nan))
    }
}
