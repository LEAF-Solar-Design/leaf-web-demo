import Foundation
import XCTest
@testable import LeafHFT

final class TuningReviewURLTests: XCTestCase {
    private let id = UUID().uuidString.lowercased()
    private let planHash = String(repeating: "a", count: 64)

    private var valid: URL {
        KashbotLiveAttributes.Approval(account: "00000001", proposalId: id,
                                      planSeq: 2, planSha256: planHash).reviewURL!
    }

    func testValidReviewAndPureIdentityChecks() throws {
        let target = try XCTUnwrap(TuningInboxTarget.reviewURL(valid))
        XCTAssertEqual(target.proposalID, id)
        XCTAssertEqual(target.account, "00000001")
        XCTAssertEqual(target.planSeq, 2)
        XCTAssertEqual(target.planSHA256, planHash)
        XCTAssertFalse(target.accountMismatch(fetchedAccount: "00000001"))
        XCTAssertTrue(target.accountMismatch(fetchedAccount: "00000002"))
        XCTAssertFalse(target.planChanged(fetchedSeq: 2, fetchedSHA256: planHash))
        XCTAssertTrue(target.planChanged(fetchedSeq: 3, fetchedSHA256: planHash))
        XCTAssertTrue(target.planChanged(fetchedSeq: 2, fetchedSHA256: String(repeating: "b", count: 64)))
        let notification = try XCTUnwrap(TuningInboxTarget(proposalID: id, category: "test"))
        XCTAssertFalse(notification.accountMismatch(fetchedAccount: "00000002"))
        XCTAssertFalse(notification.planChanged(fetchedSeq: 3, fetchedSHA256: planHash))
    }

    func testWrongRouteAndAuthorityAreIgnored() throws {
        let original = try XCTUnwrap(URLComponents(url: valid, resolvingAgainstBaseURL: false))
        for field in ["scheme", "host", "path", "user", "password", "port", "fragment"] {
            var parts = original
            switch field {
            case "scheme": parts.scheme = "https"
            case "host": parts.host = "other"
            case "path": parts.path = "/review/"
            case "user": parts.user = "user"
            case "password": parts.password = "password"
            case "port": parts.port = 80
            default: parts.fragment = "extra"
            }
            XCTAssertNil(TuningInboxTarget.reviewURL(try XCTUnwrap(parts.url)), field)
        }
    }

    func testQueryMustBeExactAndEveryValueValid() throws {
        let original = try XCTUnwrap(URLComponents(url: valid, resolvingAgainstBaseURL: false))
        let items = try XCTUnwrap(original.queryItems)
        for index in items.indices {
            var parts = original
            parts.queryItems = items.enumerated().filter { $0.offset != index }.map(\.element)
            XCTAssertNil(TuningInboxTarget.reviewURL(try XCTUnwrap(parts.url)))
            parts.queryItems = items + [items[index]]
            XCTAssertNil(TuningInboxTarget.reviewURL(try XCTUnwrap(parts.url)))
        }
        var extra = original
        extra.queryItems = items + [URLQueryItem(name: "extra", value: "1")]
        XCTAssertNil(TuningInboxTarget.reviewURL(try XCTUnwrap(extra.url)))
        let invalid: [String: [String?]] = [
            "account": [nil, "", "0000000A", "000000001"],
            "proposal_id": [nil, "", "bad", id.uppercased()],
            "plan_seq": [nil, "", "0", "-1", "1.5", "+1", "true", String(Int64.max) + "0"],
            "plan_sha256": [nil, "", planHash.uppercased(), String(planHash.dropLast())]
        ]
        for (name, values) in invalid {
            for value in values {
                var parts = original
                parts.queryItems = items.map { $0.name == name ? URLQueryItem(name: name, value: value) : $0 }
                XCTAssertNil(TuningInboxTarget.reviewURL(try XCTUnwrap(parts.url)), name)
            }
        }
        var duplicate = original
        duplicate.queryItems = [items[0], items[0], items[2], items[3]]
        XCTAssertNil(TuningInboxTarget.reviewURL(try XCTUnwrap(duplicate.url)))
    }
}
