import Foundation
import XCTest
@testable import LeafHFT

final class MushyModelsTests: XCTestCase {
    static func draftData(id: String, expiry: String = "2099-01-01T00:00:00Z", consumed: String? = nil) -> Data {
        var object: [String: Any] = [
            "id": id, "value": ["engine_id": "engine-a", "enabled": false],
            "expected_revision": "r1", "summary": "Disable this account engine at revision r1",
            "summary_digest": String(repeating: "a", count: 64),
            "before": ["engine_id": "engine-a", "enabled": true, "revision": "r1"],
            "after": ["engine_id": "engine-a", "enabled": false, "revision": "r1"],
            "practical_effect": "Request disabling this account engine",
            "risk": "Existing positions are not closed.",
            "created_at": "2026-09-19T00:00:00Z", "expires_at": expiry, "consumed_at": NSNull()
        ]
        if let consumed { object["consumed_at"] = consumed }
        return try! JSONSerialization.data(withJSONObject: object)
    }
    func testCatalogCompatibilityUsesServerDefaultsThenFirstCompatible() throws {
        let catalog = MushyClient.fixtureCatalog
        let restored = catalog.reconciled(.init(sessionId: "session", modelId: "removed",
            reasoningId: "max", sources: ["removed"]))
        XCTAssertEqual(restored.modelId, catalog.defaultModelId)
        XCTAssertEqual(restored.reasoningId, catalog.defaultReasoningId)
        XCTAssertEqual(restored.sources, ["account.history"])
        let changed = MushyCatalog(schemaVersion: 1, models: [.init(id: "new", reasoningIds: ["disabled"])],
            defaultModelId: "missing", defaultReasoningId: "high", sources: catalog.sources,
            sourceScopes: catalog.sourceScopes, providerReadiness: catalog.providerReadiness,
            panelKinds: catalog.panelKinds, capabilities: catalog.capabilities)
        XCTAssertEqual(changed.reconciled(restored).modelId, "new")
        XCTAssertEqual(changed.reconciled(restored).reasoningId, "disabled")
    }
    func testNativePanelsAndUnknownVersionsKindsFieldsAndLineage() throws {
        let artifact = MushyClient.fixtureArtifact()
        XCTAssertNil(artifact.validationMessage(catalog: MushyClient.fixtureCatalog))
        XCTAssertEqual(artifact.artifact.panels.map(\.kind), ["line", "table", "metric"])
        let encoded = try MushyCoding.encoder().encode(artifact)
        let original = try XCTUnwrap(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
        for mutation in ["version", "kind", "field", "digest", "parser", "shape"] {
            var object = original
            var spec = object["artifact"] as! [String: Any]
            var panels = spec["panels"] as! [[String: Any]]
            switch mutation {
            case "version": object["version"] = 99
            case "kind": panels[0]["kind"] = "html"
            case "field": panels[0]["fields"] = ["arbitrary"]
            case "digest": object["digest"] = ""
            case "parser": object["source_parser"] = "unknown"
            default:
                var telemetry = object["telemetry"] as! [String: Any]
                telemetry["data"] = ["account.history": [["captured_at": ["nested": true],
                    "cash_cents": 1, "portfolio_value_cents": 2]]]
                object["telemetry"] = telemetry
            }
            spec["panels"] = panels
            object["artifact"] = spec
            let invalid = try MushyCoding.decoder().decode(MushyArtifact.self, from: JSONSerialization.data(withJSONObject: object))
            XCTAssertNotNil(invalid.validationMessage(catalog: MushyClient.fixtureCatalog), mutation)
        }
        XCTAssertFalse(MushyValue.number(.infinity).boundedScalar)
    }
    func testConfigSummaryIsExactAndExpiryAndConsumptionBlockNewConfirmation() throws {
        let draft = try MushyCoding.decoder().decode(MushyConfigDraft.self, from: Self.draftData(id: MushyClient.fixtureArtifactId))
        XCTAssertEqual(draft.contents.before["enabled"], .bool(true))
        XCTAssertEqual(draft.contents.after["enabled"], .bool(false))
        XCTAssertNil(draft.blocker())
        let expired = try MushyCoding.decoder().decode(MushyConfigDraft.self,
            from: Self.draftData(id: draft.id, expiry: "2000-01-01T00:00:00Z"))
        XCTAssertNotNil(expired.blocker())
        let consumed = try MushyCoding.decoder().decode(MushyConfigDraft.self,
            from: Self.draftData(id: draft.id, consumed: "2026-09-19T12:00:00Z"))
        XCTAssertNotNil(consumed.blocker())
    }

    func testStaleActiveJobUsesCreatedAt() throws {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        let formatter = ISO8601DateFormatter()
        func job(status: String = "running", createdAt: String?) throws -> MushyJob {
            var object: [String: Any] = ["id": "job", "status": status]
            if let createdAt { object["created_at"] = createdAt }
            return try MushyCoding.decoder().decode(MushyJob.self,
                from: JSONSerialization.data(withJSONObject: object))
        }
        let oldDate = formatter.string(from: now.addingTimeInterval(-16 * 60))
        let old = try job(createdAt: oldDate)
        XCTAssertEqual(try XCTUnwrap(old.age(now: now)), 16 * 60, accuracy: 0.001)
        XCTAssertTrue(old.isStaleActive(now: now))
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let recent = try job(createdAt: formatter.string(from: now.addingTimeInterval(-14 * 60)))
        XCTAssertEqual(try XCTUnwrap(recent.age(now: now)), 14 * 60, accuracy: 0.001)
        XCTAssertFalse(recent.isStaleActive(now: now))
        XCTAssertFalse(try job(status: "completed", createdAt: oldDate).isStaleActive(now: now))
        XCTAssertFalse(try job(createdAt: nil).isStaleActive(now: now))
        XCTAssertFalse(try job(createdAt: "invalid").isStaleActive(now: now))
        XCTAssertNil(try job(createdAt: nil).age(now: now))
        XCTAssertNil(try job(createdAt: "invalid").age(now: now))
    }

    func testPromptLimitCountsBytes() {
        XCTAssertFalse(MushyPromptLimit.exceeded(String(repeating: "a", count: 8_000)))
        XCTAssertTrue(MushyPromptLimit.exceeded(String(repeating: "a", count: 8_001)))
        XCTAssertFalse(MushyPromptLimit.exceeded(String(repeating: "é", count: 3_000)))
        XCTAssertTrue(MushyPromptLimit.exceeded(String(repeating: "é", count: 4_001)))
    }

    func testBoundAdmittedInputsKeepsLiveJobsAndCap() {
        var recovery = MushyRecovery()
        let ids = (0..<60).map { String(format: "job-%02d", $0) }
        let artifactIds = (0..<60).map { String(format: "artifact-%02d", $0) }
        for id in ids {
            recovery.admittedInputs[id] = "Request " + id
        }
        for id in artifactIds {
            recovery.configReceipts[id] = MushyConfigReceipt(draftId: id,
                controlRequestId: "control-" + id, state: "pending")
        }
        let keep = Set(ids.prefix(55))
        let artifactKeep = Set(artifactIds.prefix(55))
        recovery.configReceipts[ids[0]] = MushyConfigReceipt(draftId: ids[0],
            controlRequestId: "control-job", state: "pending")
        recovery.boundAdmittedInputs(keeping: keep, artifactIds: artifactKeep, limit: 50)
        XCTAssertEqual(recovery.admittedInputs.count, 50)
        XCTAssertTrue(Set(recovery.admittedInputs.keys).isSubset(of: keep))
        XCTAssertNil(recovery.admittedInputs[ids[59]])
        XCTAssertEqual(Set(recovery.admittedInputs.keys), Set(ids.prefix(50)))
        XCTAssertEqual(Set(recovery.configReceipts.keys), Set(artifactIds.prefix(50)))
        XCTAssertNotNil(recovery.configReceipts[artifactIds[0]])
        XCTAssertNil(recovery.configReceipts[artifactIds[59]])
        XCTAssertNil(recovery.configReceipts[ids[0]])
    }

    @MainActor func testPublishSuggestUndoRedoUseAccountSlotHistory() async throws {
        let suite = "mushy-tests-" + UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let state = MushyState(fixtureMode: FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"]), defaults: defaults)
        await state.refresh()
        state.prompt = "Initial dashboard"
        await state.send()
        let original = try XCTUnwrap(state.selectedArtifact)
        await state.publish(original)
        XCTAssertEqual(state.slot?.revision, 1)
        state.prompt = "Another dashboard"
        await state.send()
        let next = try XCTUnwrap(state.selectedArtifact)
        XCTAssertNotEqual(next.id, original.id)
        await state.publish(next)
        XCTAssertEqual(state.slot?.revision, 2)
        state.rationale = "This overview would help other accounts."
        await state.suggest(next)
        XCTAssertEqual(state.slot?.artifactId, next.id)
        XCTAssertEqual(state.snapshot.proposals.first?.state, "proposed")
        await state.rollback()
        XCTAssertEqual(state.slot?.artifactId, original.id)
        XCTAssertEqual(state.slot?.revision, 3)
        await state.rollback()
        XCTAssertEqual(state.slot?.artifactId, next.id)
        XCTAssertEqual(state.slot?.revision, 4)
        let data = try XCTUnwrap(defaults.data(forKey: MushyState.recoveryKey + ".preview"))
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        XCTAssertNil(object["snapshot"])
        XCTAssertNil(object["bearer"])
    }
}
