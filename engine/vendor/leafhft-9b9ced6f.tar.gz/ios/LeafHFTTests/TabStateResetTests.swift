import Foundation
import XCTest
@testable import LeafHFT

final class TabStateResetTests: XCTestCase {
    private let leftAt = Date(timeIntervalSince1970: 1_800_000_000)

    func testNilAbsenceNeverResets() {
        XCTAssertFalse(TabStatePolicy.shouldReset(awaySince: nil, now: leftAt))
    }

    func testTwentyNineMinutesFiftyNineSecondsPreservesState() {
        XCTAssertFalse(TabStatePolicy.shouldReset(
            awaySince: leftAt, now: leftAt.addingTimeInterval(29 * 60 + 59)))
    }

    func testExactlyThirtyMinutesPreservesState() {
        XCTAssertFalse(TabStatePolicy.shouldReset(
            awaySince: leftAt, now: leftAt.addingTimeInterval(30 * 60)))
    }

    func testThirtyMinutesOneSecondResetsState() {
        XCTAssertTrue(TabStatePolicy.shouldReset(
            awaySince: leftAt, now: leftAt.addingTimeInterval(30 * 60 + 1)))
    }

    func testBackgroundAbsenceResetsStateOnReturn() {
        // Backgrounding records the selected tab's departure just like leaving a tab.
        let backgroundedAt = leftAt
        let foregroundedAt = backgroundedAt.addingTimeInterval(2 * 60 * 60)
        XCTAssertTrue(TabStatePolicy.shouldReset(
            awaySince: backgroundedAt, now: foregroundedAt))
    }
}
