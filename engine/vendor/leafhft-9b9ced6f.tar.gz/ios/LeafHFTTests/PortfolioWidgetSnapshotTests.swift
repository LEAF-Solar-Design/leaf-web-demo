import Foundation
import XCTest
@testable import LeafHFT

final class PortfolioWidgetSnapshotTests: XCTestCase {
    func testFifteenMinuteChangeUsesLatestPointAtOrBeforeCutoff() {
        let now = Date(timeIntervalSince1970: 10_000)
        let snapshot = PortfolioWidgetSnapshot.make(
            totalCents: 1_250,
            history: [
                .init(observedAt: now.addingTimeInterval(-1_000), totalCents: 900),
                .init(observedAt: now.addingTimeInterval(-920), totalCents: 1_000),
                .init(observedAt: now.addingTimeInterval(-899), totalCents: 1_100)
            ],
            positions: [],
            now: now
        )
        XCTAssertEqual(snapshot.change15MinutesCents, 250)
    }

    func testMissingFifteenMinuteHistoryShowsCollecting() {
        let now = Date(timeIntervalSince1970: 10_000)
        let snapshot = PortfolioWidgetSnapshot.make(
            totalCents: 1_250,
            history: [.init(observedAt: now.addingTimeInterval(-899), totalCents: 1_100)],
            positions: [],
            now: now
        )
        XCTAssertNil(snapshot.change15MinutesCents)
    }

    func testBaselineMustBeBetweenFifteenAndThirtyMinutesOld() {
        let now = Date(timeIntervalSince1970: 100_000)
        let cases: [(TimeInterval, Int?)] = [
            (8 * 60 * 60, nil), (16 * 60, 250), (31 * 60, nil),
            (15 * 60, 250), (30 * 60, 250), (15 * 60 - 1, nil), (30 * 60 + 1, nil)
        ]
        for (age, expected) in cases {
            let snapshot = PortfolioWidgetSnapshot.make(
                totalCents: 1_250,
                history: [.init(observedAt: now.addingTimeInterval(-age), totalCents: 1_000)],
                positions: [], now: now
            )
            XCTAssertEqual(snapshot.change15MinutesCents, expected, "Baseline age: \(age)")
        }
    }

    func testSnapshotExpiryBoundaries() {
        let now = Date(timeIntervalSince1970: 100_000)
        let maximumAge = PortfolioWidgetSnapshot.maximumAge
        XCTAssertEqual(maximumAge, 24 * 60 * 60)
        let cases: [(TimeInterval, Bool)] = [
            (maximumAge - 1, false), (maximumAge, false), (maximumAge + 1, true),
            (-60, false), (-61, true)
        ]
        for (age, expired) in cases {
            let snapshot = PortfolioWidgetSnapshot(totalCents: 1_250, change15MinutesCents: 250,
                observedAt: now.addingTimeInterval(-age), positions: [])
            XCTAssertEqual(snapshot.isExpired(now: now), expired, "Snapshot age: \(age)")
        }
    }

    func testDeltaFreshnessBoundaries() {
        let now = Date(timeIntervalSince1970: 100_000)
        let cases: [(TimeInterval, Bool)] = [
            (-1, false), (0, true), (20 * 60 - 1, true), (20 * 60, true), (20 * 60 + 1, false)
        ]
        for (age, current) in cases {
            let snapshot = PortfolioWidgetSnapshot(totalCents: 1_250, change15MinutesCents: 250,
                observedAt: now.addingTimeInterval(-age), positions: [])
            XCTAssertEqual(snapshot.deltaIsCurrent(now: now), current, "Snapshot age: \(age)")
        }
    }

    func testPositionsUseThreeLargestAbsoluteExposures() {
        let now = Date(timeIntervalSince1970: 10_000)
        let snapshot = PortfolioWidgetSnapshot.make(
            totalCents: 1_250,
            history: [],
            positions: [
                .init(ticker: "SMALL", size: "1", exposureCents: 1),
                .init(ticker: "SHORT", size: "2", exposureCents: -400),
                .init(ticker: "ZERO", size: "0", exposureCents: 0),
                .init(ticker: "MID", size: "3", exposureCents: 200),
                .init(ticker: "BIG", size: "4", exposureCents: 500)
            ],
            now: now
        )
        XCTAssertEqual(snapshot.positions.map(\.ticker), ["BIG", "SHORT", "MID"])
    }
}
