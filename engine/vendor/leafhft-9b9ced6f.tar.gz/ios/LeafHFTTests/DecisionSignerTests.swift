import CryptoKit
import Foundation
import Security
import XCTest
@testable import LeafHFT

/// C0's golden vectors (tests/fixtures/tuning_inbox_v1/vectors.json), copied byte for byte.
enum TuningVectors {
    /// SHA-256 of the committed C0 blob; any drift in the copy fails every tuning test.
    static let c0SHA256 = "66ea3c602b91b5b5ec14856f34d24c9446b27dab7185b1f733009406a1aafdbf"
    static let name = "tuning-inbox-v1-vectors"

    static func data() throws -> Data {
        let bundle = Bundle(for: BundleToken.self)
        if let url = bundle.url(forResource: name, withExtension: "json")
            ?? bundle.url(forResource: name, withExtension: "json", subdirectory: "Fixtures") {
            return try Data(contentsOf: url)
        }
        // Simulator tests can read the synced source tree when the resource phase did not copy the file.
        let source = URL(fileURLWithPath: #filePath).deletingLastPathComponent()
            .appendingPathComponent("Fixtures").appendingPathComponent(name + ".json")
        return try Data(contentsOf: source)
    }

    static func root() throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: data()) as? [String: Any])
    }

    static func entries(_ section: String) throws -> [[String: Any]] {
        try XCTUnwrap(root()[section] as? [[String: Any]])
    }

    static func entry(_ section: String, _ id: String) throws -> [String: Any] {
        try XCTUnwrap(entries(section).first { $0["id"] as? String == id })
    }

    static func spki(_ keyID: String) throws -> Data {
        let keys = try XCTUnwrap(root()["keys"] as? [String: Any])
        let key = try XCTUnwrap(keys[keyID] as? [String: Any])
        return try XCTUnwrap(Data(base64Encoded: try XCTUnwrap(key["spki_b64"] as? String)))
    }

    static func credentialID(_ keyID: String) throws -> String {
        let keys = try XCTUnwrap(root()["keys"] as? [String: Any])
        return try XCTUnwrap((keys[keyID] as? [String: Any])?["credential_id"] as? String)
    }

    static func int(_ value: Any?) throws -> Int64 {
        try XCTUnwrap((value as? NSNumber)?.int64Value)
    }

    static func decision(_ object: [String: Any]) throws -> TuningDecision {
        TuningDecision(verb: try XCTUnwrap(object["verb"] as? String),
                       proposalID: try XCTUnwrap(object["proposal_id"] as? String),
                       planSeq: try int(object["plan_seq"]),
                       planSHA256: try XCTUnwrap(object["plan_sha256"] as? String),
                       runnerNonce: try XCTUnwrap(object["runner_nonce"] as? String),
                       account: try XCTUnwrap(object["account"] as? String),
                       issuedAtMs: try int(object["issued_at_ms"]))
    }

    static func verifiedPlan(_ id: String) throws -> VerifiedTuningPlan {
        let plan = try entry("plans", id)
        return try VerifiedTuningPlan.verify(planB64: try XCTUnwrap(plan["plan_b64"] as? String),
                                             advertisedSHA256: try XCTUnwrap(plan["plan_sha256"] as? String))
    }

    static let acceptCases = ["owner-accept-1", "owner-accept-2", "tenant-accept-1", "tenant-accept-2"]
}

private final class BundleToken {}

/// Software P-256 signer injected in place of the Secure Enclave. Test-only scalars from C0 (1 and 2).
final class SoftwareDecisionKey: DecisionSigningKey {
    let key: P256.Signing.PrivateKey
    var signingKey: P256.Signing.PrivateKey
    var reasons: [String] = []
    var signedMessages: [Data] = []
    var onSign: (() -> Void)?
    var failure: Error?

    init(scalar: UInt8) {
        key = try! P256.Signing.PrivateKey(rawRepresentation: Data(repeating: 0, count: 31) + [scalar])
        signingKey = key
    }

    func publicKeySPKI() throws -> Data { key.publicKey.derRepresentation }

    func signMessage(_ message: Data, reason: String) async throws -> Data {
        onSign?()
        reasons.append(reason)
        signedMessages.append(message)
        if let failure { throw failure }
        return try signingKey.signature(for: message).derRepresentation
    }
}

final class DecisionSignerTests: XCTestCase {
    func testHostedAppDeclaresFaceIDUsageDescription() throws {
        let description = try XCTUnwrap(Bundle.main.object(forInfoDictionaryKey: "NSFaceIDUsageDescription") as? String)
        XCTAssertFalse(description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
    }

    func testFixtureIsByteIdenticalToC0() throws {
        let data = try TuningVectors.data()
        XCTAssertEqual(TuningSyntax.sha256Hex(data), TuningVectors.c0SHA256)
        XCTAssertFalse(data.contains(0x0D), "fixture must keep LF line endings")
        XCTAssertEqual(try TuningVectors.root()["schema"] as? String, "leafhft.tuning-inbox-vectors.v1")
    }

    func testTestOnlyKeysMatchTheVectorSPKIsAndCredentialIDs() throws {
        for (keyID, scalar) in [("operator", UInt8(1)), ("other", UInt8(2))] {
            let signer = SoftwareDecisionKey(scalar: scalar)
            let spki = try signer.publicKeySPKI()
            XCTAssertEqual(spki, try TuningVectors.spki(keyID))
            XCTAssertEqual(PresenceSPKI.credentialID(spki: spki), try TuningVectors.credentialID(keyID))
            XCTAssertEqual(try PresenceSPKI.spki(x963: signer.key.publicKey.x963Representation), spki)
            XCTAssertEqual(try PresenceSPKI.publicKey(spki: spki).x963Representation, signer.key.publicKey.x963Representation)
        }
    }

    func testDecisionBytesAndDigestsReproduceEveryVector() throws {
        let cases = try TuningVectors.entries("decisions")
        XCTAssertGreaterThanOrEqual(cases.count, 9)
        for vector in cases {
            let id = try XCTUnwrap(vector["id"] as? String)
            let assertion = try XCTUnwrap(vector["assertion"] as? [String: Any])
            XCTAssertEqual(assertion["kind"] as? String, TuningAssertion.kind, id)
            let decision = try TuningVectors.decision(try XCTUnwrap(assertion["decision"] as? [String: Any]))
            let message = try decision.messageBytes()
            XCTAssertEqual(message, Data(try XCTUnwrap(vector["decision_ascii"] as? String).utf8), id)
            XCTAssertEqual(TuningSyntax.sha256Hex(message), vector["decision_sha256"] as? String, id)
            let signature = try XCTUnwrap(Data(base64Encoded: try XCTUnwrap(assertion["signature_b64"] as? String)))
            let rebuilt = TuningAssertion(credentialID: try XCTUnwrap(assertion["credential_id"] as? String),
                                          decision: decision, signatureDER: signature)
            XCTAssertEqual(TuningSyntax.sha256Hex(try rebuilt.canonicalBytes()), vector["evidence_sha256"] as? String, id)
            let trusted = try TuningVectors.spki(try XCTUnwrap(vector["trusted_key_id"] as? String))
            XCTAssertEqual(PresenceSPKI.signatureValid(spki: trusted, signatureDER: signature, message: message),
                           vector["signature_valid"] as? Bool, id)
        }
    }

    func testInjectedSignerProducesTheVectorDecisionBytesForEveryAcceptCase() async throws {
        for id in TuningVectors.acceptCases {
            let vector = try TuningVectors.entry("decisions", id)
            let assertion = try XCTUnwrap(vector["assertion"] as? [String: Any])
            let expected = try TuningVectors.decision(try XCTUnwrap(assertion["decision"] as? [String: Any]))
            let plan = try TuningVectors.verifiedPlan(try XCTUnwrap(vector["plan_id"] as? String))
            XCTAssertTrue(plan.hashMatches, id)
            let signer = SoftwareDecisionKey(scalar: 1)
            let signed = try await DecisionSigner(key: signer).signAccept(plan: plan, issuedAtMs: expected.issuedAtMs,
                                                                          reason: "Accept \(id)")
            XCTAssertEqual(signed.assertion.decision, expected, id)
            XCTAssertEqual(signed.message, Data(try XCTUnwrap(vector["decision_ascii"] as? String).utf8), id)
            XCTAssertEqual(signer.signedMessages, [signed.message], "the message is signed as-is, exactly once")
            XCTAssertEqual(signed.assertion.credentialID, assertion["credential_id"] as? String, id)
            XCTAssertTrue(PresenceSPKI.signatureValid(spki: try TuningVectors.spki("operator"),
                                                      signatureDER: signed.assertion.signatureDER, message: signed.message))
            XCTAssertEqual(signed.evidenceSHA256, TuningSyntax.sha256Hex(signed.canonicalJSON))
            // The assertion is the canonical closed object: exactly four keys, se-p256.
            let decoded = try XCTUnwrap(JSONSerialization.jsonObject(with: try XCTUnwrap(Data(base64Encoded: signed.assertionB64))) as? [String: Any])
            XCTAssertEqual(Set(decoded.keys), ["kind", "credential_id", "decision", "signature_b64"])
            XCTAssertEqual(decoded["kind"] as? String, "se-p256")
            XCTAssertEqual(try TuningCanonicalParser.parse(signed.canonicalJSON, maxBytes: 8_192).canonicalBytes(), signed.canonicalJSON)
        }
    }

    func testNonAcceptVerbReproducesTheVectorButTheSignerOnlyEmitsAccept() throws {
        let vector = try TuningVectors.entry("decisions", "non_accept_verb")
        let assertion = try XCTUnwrap(vector["assertion"] as? [String: Any])
        let decision = try TuningVectors.decision(try XCTUnwrap(assertion["decision"] as? [String: Any]))
        XCTAssertEqual(decision.verb, "cancel")
        XCTAssertEqual(try decision.messageBytes(), Data(try XCTUnwrap(vector["decision_ascii"] as? String).utf8))
        XCTAssertEqual(TuningDecision.accept(plan: try TuningVectors.verifiedPlan("plan-1"), issuedAtMs: 1).verb, "accept")
    }

    func testHashMismatchIsRefusedBeforeFaceID() async throws {
        let good = try TuningVectors.verifiedPlan("plan-1")
        let tampered = try VerifiedTuningPlan.verify(bytes: good.bytes, advertisedSHA256: String(repeating: "0", count: 64))
        XCTAssertFalse(tampered.hashMatches)
        let signer = SoftwareDecisionKey(scalar: 1)
        do {
            _ = try await DecisionSigner(key: signer).signAccept(plan: tampered, issuedAtMs: 1_790_683_201_000, reason: "x")
            XCTFail("a mismatched hash was signed")
        } catch {
            XCTAssertEqual(error as? DecisionSignerError, .planHashMismatch)
        }
        XCTAssertTrue(signer.signedMessages.isEmpty, "Face ID must not be asked for a mismatched plan")
    }

    func testSignatureFromAnotherKeyIsRefusedOnThePhone() async throws {
        let signer = SoftwareDecisionKey(scalar: 1)
        signer.signingKey = SoftwareDecisionKey(scalar: 2).key
        do {
            _ = try await DecisionSigner(key: signer).signAccept(plan: try TuningVectors.verifiedPlan("plan-1"),
                                                                 issuedAtMs: 1_790_683_201_000, reason: "x")
            XCTFail("a signature under the wrong key was accepted")
        } catch {
            XCTAssertEqual(error as? DecisionSignerError, .invalidSignature)
        }
    }

    func testCancelledFaceIDSurfacesAndSendsNothing() async throws {
        let signer = SoftwareDecisionKey(scalar: 1)
        signer.failure = DecisionSignerError.userCancelled
        do {
            _ = try await DecisionSigner(key: signer).signAccept(plan: try TuningVectors.verifiedPlan("plan-1"),
                                                                 issuedAtMs: 1_790_683_201_000, reason: "x")
            XCTFail("a cancelled Face ID produced an assertion")
        } catch {
            XCTAssertEqual(error as? DecisionSignerError, .userCancelled)
            XCTAssertTrue(DecisionSigner.message(for: error).contains("Nothing was signed"))
        }
    }

    func testDecisionValidationRefusesMalformedFields() throws {
        let base = try TuningVectors.decision(try XCTUnwrap(
            (try TuningVectors.entry("decisions", "owner-accept-1")["assertion"] as? [String: Any])?["decision"] as? [String: Any]))
        XCTAssertNoThrow(try base.messageBytes())
        let bad = [
            TuningDecision(verb: "Accept", proposalID: base.proposalID, planSeq: base.planSeq, planSHA256: base.planSHA256,
                           runnerNonce: base.runnerNonce, account: base.account, issuedAtMs: base.issuedAtMs),
            TuningDecision(verb: base.verb, proposalID: String(base.proposalID.dropLast()) + "A", planSeq: base.planSeq,
                           planSHA256: base.planSHA256, runnerNonce: base.runnerNonce, account: base.account,
                           issuedAtMs: base.issuedAtMs),
            TuningDecision(verb: base.verb, proposalID: base.proposalID, planSeq: 0, planSHA256: base.planSHA256,
                           runnerNonce: base.runnerNonce, account: base.account, issuedAtMs: base.issuedAtMs),
            TuningDecision(verb: base.verb, proposalID: base.proposalID, planSeq: base.planSeq,
                           planSHA256: base.planSHA256.uppercased(), runnerNonce: base.runnerNonce, account: base.account,
                           issuedAtMs: base.issuedAtMs),
            TuningDecision(verb: base.verb, proposalID: base.proposalID, planSeq: base.planSeq, planSHA256: base.planSHA256,
                           runnerNonce: "0101", account: base.account, issuedAtMs: base.issuedAtMs),
            TuningDecision(verb: base.verb, proposalID: base.proposalID, planSeq: base.planSeq, planSHA256: base.planSHA256,
                           runnerNonce: base.runnerNonce, account: "owner", issuedAtMs: base.issuedAtMs),
            TuningDecision(verb: base.verb, proposalID: base.proposalID, planSeq: base.planSeq, planSHA256: base.planSHA256,
                           runnerNonce: base.runnerNonce, account: base.account, issuedAtMs: -1),
            TuningDecision(verb: base.verb, proposalID: base.proposalID, planSeq: TuningInboxLimits.maxSafeInteger + 1,
                           planSHA256: base.planSHA256, runnerNonce: base.runnerNonce, account: base.account,
                           issuedAtMs: base.issuedAtMs),
        ]
        for decision in bad {
            XCTAssertThrowsError(try decision.messageBytes(), "\(decision)")
        }
    }

    func testSPKIAcceptsOnlyP256() throws {
        var spki = try TuningVectors.spki("operator")
        XCTAssertNoThrow(try PresenceSPKI.publicKey(spki: spki))
        spki[20] ^= 0x01
        XCTAssertThrowsError(try PresenceSPKI.publicKey(spki: spki))
        XCTAssertThrowsError(try PresenceSPKI.publicKey(spki: Data(spki.dropLast())))
        XCTAssertThrowsError(try PresenceSPKI.spki(x963: Data(repeating: 4, count: 64)))
        XCTAssertFalse(PresenceSPKI.signatureValid(spki: try TuningVectors.spki("operator"), signatureDER: Data(), message: Data()))
    }

    func testSecureEnclaveKeyIsBiometryCurrentSetAndPrivateKeyUsage() {
        XCTAssertTrue(SecureEnclaveDecisionKey.accessControlFlags.contains(.biometryCurrentSet))
        XCTAssertTrue(SecureEnclaveDecisionKey.accessControlFlags.contains(.privateKeyUsage))
        XCTAssertFalse(SecureEnclaveDecisionKey.accessControlFlags.contains(.userPresence),
                       "a passcode fallback would let a signature happen without Face ID")
    }

    func testSecureEnclaveKeyRefusesDemoMode() {
        let demo = FixtureMode(arguments: ["-LEAFHFT_FIXTURES", "1"])
        XCTAssertThrowsError(try SecureEnclaveDecisionKey.load(fixtureMode: demo)) {
            XCTAssertEqual($0 as? DecisionSignerError, .fixtureMode)
        }
        XCTAssertThrowsError(try SecureEnclaveDecisionKey.create(fixtureMode: demo)) {
            XCTAssertEqual($0 as? DecisionSignerError, .fixtureMode)
        }
    }
}
