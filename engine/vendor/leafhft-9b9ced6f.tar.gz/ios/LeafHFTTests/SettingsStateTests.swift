import Foundation
import XCTest
import LeafHFTCore
@testable import LeafHFT

@MainActor final class SettingsStateTests: XCTestCase {
    private func status(_ trading: String, hasLane: Bool = true) throws -> KashbotStatus {
        let lane = hasLane
            ? """
              {"id":"22222222-2222-4222-8222-222222222222","state":"\(trading)","live_enabled":false}
              """
            : "null"
        let json = """
        {"dashboard_pairing":"paired","account_binding":"bound","automated_trading":"\(trading)",
         "tenant":{"id":"11111111-1111-4111-8111-111111111111","runner_host":"runner"},"lane":\(lane)}
        """
        return try accountJSONDecoder().decode(KashbotStatus.self, from: Data(json.utf8))
    }

    private func load(_ status: KashbotStatus, into state: AppState) {
        let sequence = state.beginAccountMutation(.pause)
        XCTAssertTrue(state.acceptAccountActionResult(status, sequence: sequence))
        state.finishAccountMutation(sequence: sequence)
    }

    func testKeyStorageCopyDistinguishesRunnerEnrollmentFromOwnerPhoneAccess() {
        let tenant = SettingsView.privateKeyStorageCopy(isOwnerExecution: false)
        XCTAssertTrue(tenant.contains("Keychain"))
        XCTAssertTrue(tenant.contains("encrypts and enrolls a runner copy"))
        XCTAssertTrue(tenant.contains("while this phone is offline"))
        let owner = SettingsView.privateKeyStorageCopy(isOwnerExecution: true)
        XCTAssertTrue(owner.contains("read-only phone access"))
        XCTAssertFalse(owner.contains("enrolls"))
    }

    func testLivePendingPauseDoesNotRequireAnActionableLane() throws {
        let state = AppState(fixtureMode: FixtureMode(arguments: []))
        load(try status("live_pending", hasLane: false), into: state)
        XCTAssertTrue(state.canPause)
        XCTAssertTrue(state.canRunAccountAction(.pause))
        XCTAssertFalse(state.kashbotStatus?.hasActionableLane == true)
    }

    func testPauseRemainsAvailableDuringStartAndCancelsConfirmation() throws {
        let state = AppState(fixtureMode: FixtureMode(arguments: []))
        load(try status("dry_run"), into: state)
        state.requestRaisesRisk(title: "Start trading", detail: "Real orders", actionLabel: "Start trading") { }
        let start = state.beginAccountMutation(.startLive)
        XCTAssertTrue(state.accountMutationInProgress)
        XCTAssertTrue(state.canPause)
        XCTAssertFalse(state.canRunAccountAction(.startLive))
        let pause = state.beginAccountMutation(.pause)
        XCTAssertNil(state.pendingConfirmation)
        XCTAssertFalse(state.acceptAccountActionResult(try status("live"), sequence: start))
        state.finishAccountMutation(sequence: pause)
    }

    func testPausedAccountCannotResumeWithoutCredentialsOrWhileMutating() async throws {
        let state = AppState(fixtureMode: FixtureMode(arguments: []))
        load(try status("paused"), into: state)
        XCTAssertFalse(state.canPause)
        XCTAssertFalse(state.canResume)
        await state.resumeTrading()
        XCTAssertNil(state.pendingConfirmation)
        let sequence = state.beginAccountMutation(.revoke)
        XCTAssertFalse(state.canResume)
        await state.resumeTrading()
        XCTAssertNil(state.pendingConfirmation)
        state.finishAccountMutation(sequence: sequence)
    }
}
