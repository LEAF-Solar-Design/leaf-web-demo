import XCTest
import CryptoKit
import Security
@testable import LeafHFT

final class USBKeyDraftReceiverTests: XCTestCase {
    private var directory: URL!
    private var clock = Date()
    private var receiver: USBKeyDraftReceiver!

    override func setUpWithError() throws {
        directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        clock = Date()
        receiver = USBKeyDraftReceiver(documents: directory, now: { [unowned self] in self.clock })
    }

    override func tearDownWithError() throws {
        receiver.cancel()
        receiver = nil
        try FileManager.default.removeItem(at: directory)
    }

    private var envelopeURL: URL { directory.appendingPathComponent("KashbotPairing/envelope.json") }

    private func syntheticPayload() throws -> Data {
        // Runtime-only synthetic RSA material, never a stored credential fixture.
        let attributes: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeySizeInBits as String: 2048, kSecAttrIsPermanent as String: false]
        let key = try XCTUnwrap(SecKeyCreateRandomKey(attributes as CFDictionary, nil))
        let der = try XCTUnwrap(SecKeyCopyExternalRepresentation(key, nil)) as Data
        let label = "RSA PRIVATE KEY"
        let pem = "-----BEGIN \(label)-----\n" + der.base64EncodedString() + "\n-----END \(label)-----"
        return try JSONEncoder().encode(USBKeyDraftReceiver.Draft(key_id: "synthetic-only", private_key_pem: pem))
    }

    private func encrypted(_ payload: Data, for request: USBKeyDraftReceiver.Request,
                           requestID: String? = nil, tamper: Bool = false) throws -> Data {
        let sender = P256.KeyAgreement.PrivateKey()
        let publicData = try XCTUnwrap(Data(base64Encoded: request.public_key))
        let target = try P256.KeyAgreement.PublicKey(x963Representation: publicData)
        let secret = try sender.sharedSecretFromKeyAgreement(with: target)
        let key = secret.hkdfDerivedSymmetricKey(using: SHA256.self, salt: Data(request.request_id.utf8),
            sharedInfo: Data("Kashbot HFT USB import v1".utf8), outputByteCount: 32)
        let sealed = try AES.GCM.seal(payload, using: key, authenticating: Data(request.request_id.utf8))
        var ciphertext = sealed.ciphertext + sealed.tag
        // Data can retain a nonzero startIndex when supplied by CryptoKit.
        if tamper { ciphertext[ciphertext.startIndex] ^= 1 }
        return try JSONEncoder().encode(USBKeyDraftReceiver.Envelope(version: 1,
            request_id: requestID ?? request.request_id,
            sender_public_key: sender.publicKey.x963Representation.base64EncodedString(),
            nonce: sealed.nonce.withUnsafeBytes { Data($0) }.base64EncodedString(),
            ciphertext: ciphertext.base64EncodedString()))
    }

    func testRoundTripConsumesFilesAndRejectsReplay() throws {
        let request = try receiver.begin()
        XCTAssertEqual(request.version, 1)
        XCTAssertEqual(request.request_id, request.request_id.lowercased())
        XCTAssertEqual(request.expires_at, Int(clock.timeIntervalSince1970) + 120)
        let envelope = try encrypted(syntheticPayload(), for: request)
        try envelope.write(to: envelopeURL)
        let draft = try XCTUnwrap(receiver.receive())
        XCTAssertEqual(draft.key_id, "synthetic-only")
        XCTAssertFalse(draft.private_key_pem.isEmpty)
        XCTAssertFalse(FileManager.default.fileExists(atPath: envelopeURL.path))
        XCTAssertFalse(FileManager.default.fileExists(atPath: directory.appendingPathComponent("KashbotPairing/request.json").path))
        try envelope.write(to: envelopeURL)
        XCTAssertThrowsError(try receiver.receive())
    }

    func testWaitingThenExpiryDoesNotReturnDraft() throws {
        _ = try receiver.begin()
        XCTAssertNil(try receiver.receive())
        clock = clock.addingTimeInterval(121)
        XCTAssertThrowsError(try receiver.receive())
    }

    func testWrongRequestAndTamperingConsumeSession() throws {
        for tamper in [false, true] {
            let request = try receiver.begin()
            try encrypted(Data("{}".utf8), for: request,
                requestID: tamper ? nil : UUID().uuidString.lowercased(), tamper: tamper).write(to: envelopeURL)
            XCTAssertThrowsError(try receiver.receive())
            XCTAssertThrowsError(try receiver.receive())
        }
    }

    func testCancelAndReplacementRejectOldEnvelope() throws {
        let old = try receiver.begin()
        let envelope = try encrypted(Data("{}".utf8), for: old)
        receiver.cancel()
        XCTAssertThrowsError(try receiver.receive())
        _ = try receiver.begin()
        try envelope.write(to: envelopeURL)
        XCTAssertThrowsError(try receiver.receive())
    }

    func testWrongRecipientRejects() throws {
        let request = try receiver.begin()
        let other = P256.KeyAgreement.PrivateKey()
        let wrongTarget = USBKeyDraftReceiver.Request(version: 1, request_id: request.request_id,
            public_key: other.publicKey.x963Representation.base64EncodedString(), expires_at: request.expires_at)
        try encrypted(Data("{}".utf8), for: wrongTarget).write(to: envelopeURL)
        XCTAssertThrowsError(try receiver.receive())
    }

    func testEmptyOrOversizeKeyIDRejects() throws {
        for id in ["  ", String(repeating: "a", count: 257)] {
            let request = try receiver.begin()
            let payload = try JSONEncoder().encode(USBKeyDraftReceiver.Draft(key_id: id, private_key_pem: "not RSA"))
            try encrypted(payload, for: request).write(to: envelopeURL)
            XCTAssertThrowsError(try receiver.receive())
        }
    }

    func testMalformedKeyAndOversizePayloadReject() throws {
        let malformed = try JSONEncoder().encode(USBKeyDraftReceiver.Draft(key_id: "synthetic-only", private_key_pem: "not RSA"))
        for payload in [malformed, Data(repeating: 65, count: 65_537)] {
            let request = try receiver.begin()
            try encrypted(payload, for: request).write(to: envelopeURL)
            XCTAssertThrowsError(try receiver.receive())
        }
    }

    func testOversizeAndMalformedEnvelopeReject() throws {
        for envelope in [Data(repeating: 65, count: 100_001), Data("{}".utf8)] {
            _ = try receiver.begin()
            try envelope.write(to: envelopeURL)
            XCTAssertThrowsError(try receiver.receive())
        }
    }

    func testEnvelopeSymlinkRejectsWithoutReadingTarget() throws {
        _ = try receiver.begin()
        let target = directory.appendingPathComponent("unrelated.txt")
        try Data("non-secret sentinel".utf8).write(to: target)
        try FileManager.default.createSymbolicLink(at: envelopeURL, withDestinationURL: target)
        XCTAssertThrowsError(try receiver.receive())
        XCTAssertEqual(try Data(contentsOf: target), Data("non-secret sentinel".utf8))
    }

    func testPairingDirectorySymlinkRejects() throws {
        let target = directory.appendingPathComponent("unrelated", isDirectory: true)
        try FileManager.default.createDirectory(at: target, withIntermediateDirectories: true)
        try FileManager.default.createSymbolicLink(at: directory.appendingPathComponent("KashbotPairing"), withDestinationURL: target)
        XCTAssertThrowsError(try receiver.begin())
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: target.path).isEmpty)
    }
}
