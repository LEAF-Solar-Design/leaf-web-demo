# Kashbot release target

This decision governs the Kashbot iOS app in this repository's ios/ tree
(bundle com.evan.leafhft), built and shipped through TestFlight from the Mac mini.

## Decision

The release ceiling is TestFlight (internal and external beta groups); not the public App Store.

On 2026-09-28, the operator answered the ios-prod-todos board's fork 7
with this verbatim decision:

> KHF-R01: internal TestFlight

On 2026-09-28, the operator clarified which TestFlight group build 77 should
go to for Stasko, Zach and Jonah with this verbatim answer:

> External group

## What it means

- Every merged build reaches the internal TestFlight group automatically.
- The beta testers (Stasko, Zach, Jonah) get builds through the external beta group
  82d0e26c, which the operator adds each build to himself.
- The App Store Connect 1.0 version record stays unsubmitted.
- No public App Store metadata (screenshots, description, privacy nutrition
  labels, review notes) is planned.
- Board item KHF-R02 keeps its internal-TestFlight scope: device-prove the live
  control flows on the operator's phone and keep a VALID internal build no older
  than 75 days.

## How to change it

Only a fresh operator decision can move the ceiling to the App Store.
That path first needs a financial-app eligibility review, a reviewer fixture
account and screenshots, and re-scopes KHF-R02.
