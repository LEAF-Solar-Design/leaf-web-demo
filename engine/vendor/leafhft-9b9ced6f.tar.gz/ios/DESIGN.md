# Leaf HFT iOS design

The iOS app is the monitoring surface for Leaf HFT. This guide records the accepted
SwiftUI hierarchy at implementation source `4e4e934` and the recipe for its visual
proof. The proof uses fixture data on Xcode 27 and iOS 27, with portrait screenshots
at **1320x2868 pixels**. These are sample observations, not live trading results.

## Accepted hierarchy

The root has four native tabs: Account, Books, Engines and Settings. Each has its
own navigation stack. System typography, grouped lists and forms provide the
hierarchy; secondary captions carry provenance and supporting detail.

| Screen | Reading order and navigation |
| --- | --- |
| Account | Fixture notice, history range, equity chart, balances, observation age and source explanation. The range offers 1d, 7d and All. Cash and account value remain separate labels. |
| Books | Book count followed by a single list of books. Each row leads with its book ID, then the entry condition, then ticker and closing time. Selecting a row opens its detail screen with ticket and exit information. The tab bar is hidden in book detail and returns on Back. |
| Engines | Performance across accounts comes first. Engine rows expose history and settings, identity and bound books. Details and Policy are disclosures so supporting telemetry does not dominate the list. |
| Settings | Connection and credential setup remain in the Settings tab. The secure credential field redacts the non-secret fixture marker, and Import remains disabled. |

The accepted traversal covers Account, Books, Book detail, Engines and Settings.
Engine history, engine settings, guided-tour replay and accessibility text sizes
are outside this accepted visual evidence.

## Visual system

The ops-faithful overhaul uses the Ops dashboard's tokens and reading order: a dark-first near-black
ground, flat cards, compact state chips and large money figures. Green and red carry financial or
state meaning. The sections above record the first accepted hierarchy. This section governs the
current visual system; the expanded fixture proof recipe is `walk/OVERHAUL-WALK.md`.

Tokens live in `LeafHFT/Design/LeafTheme.swift` and resolve per appearance. Settings has an
Appearance control (System, Dark, Light) stored under `kashbot.appearance`.

| Token | Dark | Light | Use |
| --- | --- | --- | --- |
| ground | `#0c0e12` | `#f7f8fa` | Screen background |
| card | `#15181e` | `#ffffff` | Cards, tab bar |
| cardRaised | `#1c2027` | `#f1f3f5` | Tiles inside a card, neutral chips |
| accentFill | `#232830` | `#f1f3f5` | Neutral accent background |
| line | `#262b33` | `#e2e5ea` | Card strokes, rules |
| input | `#2f353f` | `#d2d6dd` | Input borders |
| ring | `#aeb4bd` | `#0b0d12` | Focus ring |
| ink | `#e6e8ec` | `#0b0d12` | Text, primary buttons, app tint |
| inkMuted | `#9aa1ac` | `#6b7280` | Captions, eyebrows, unknown values |
| inkFaint | `#6b7280` | `#9aa1ac` | Tertiary ink |
| primary | `#e6e8ec` | `#0b0d12` | Primary action background |
| primaryForeground | `#0c0e12` | `#ffffff` | Primary action text |
| gain | `#4cc38a` | `#146c43` | Money up, Yes, healthy, switches that are on |
| loss | `#f27a72` | `#b3261e` | Money down, No, rejected, critical |
| warn | `#e0a94b` | `#95590a` | Pending, aging, guidance |
| stale | `#9aa1ac` | `#5b6470` | Stale or unknown state |
| gainSoft / gainLine | `#10251b` / `#1f4a37` | `#e9f6ef` / `#bfe3cf` | Gain fill and border |
| lossSoft / lossLine | `#2a1615` / `#532825` | `#fdecec` / `#f3c9c7` | Loss fill and border |
| warnSoft / warnLine | `#2a2110` / `#574526` | `#fdf3e2` / `#f0dcae` | Warning fill and border |
| staleSoft / staleLine | `#1c2129` / `#333a44` | `#eef0f3` / `#dce0e6` | Stale fill and border |
| destructive | `#dc4c48` | `#b3261e` | Destructive actions |
| series1 | `#5b9bd5` | `#2f6f9f` | First chart series |
| series2 | `#4cc38a` | `#146c43` | Second chart series |
| series3 | `#e0a94b` | `#95590a` | Third chart series |
| series4 | `#9b87e8` | `#6d5bd0` | Fourth chart series |
| series5 | `#9aa1ac` | `#64748b` | Fifth chart series |

`accent` aliases `ink`. Card radius is 12 pt, small radius is 8 pt and card padding is 12 pt.

Colour rules:

- Green and red mean money or a Yes and No side, never decoration. A neutral fact stays in ink.
- Amber means waiting or aging. Slate (inkMuted) means stale or unknown. An unknown value reads
  "Unavailable" in slate, never a made-up number.
- Colour never carries meaning alone. A delta has a sign and an arrow. A state chip has a word and
  a glyph: check for healthy, x for rejected, clock for pending, question mark for unknown.

Type is Geist Sans for prose. Numerals use Geist Mono with tabular digits and tracking
**-0.03 x size** through `.leafNumeral`; market tickers and IDs also use Geist Mono
(`LeafType.ticker`). Both fonts ship in `LeafHFT/Fonts` under the SIL Open Font License.
Every style scales with Dynamic Type.

Shared pieces live in `LeafHFT/Design/LeafComponents.swift`: `LeafCard` (12 pt radius),
`Eyebrow`, `StatTile`, `PnlText`, `StateChip`, `LiveDot`, `YesNoPair`, `ProgressBar`,
`KeyValueRow`, `SectionHeader`, and the `.leafPrimary` and `.leafSecondary` button styles. A new
screen starts from these and adds no local colours or fonts.

Bounded primitives live in `LeafHFT/Design/LeafBounded.swift`:

| Primitive | Rule |
| --- | --- |
| `BoundedList` | Caller supplies a maximum height in points; vertical scrolling stays inside the clipped box. |
| `BoundedTable` | Caller supplies a maximum height; pinned header with vertical and horizontal scrolling inside the box. |
| `ChipRow` | One horizontal scrolling row. |
| `OneLine` | One line, with explicit truncation. |
| `Caption` | Two collapsed lines; More reveals the full text when expandable. Safety and validation captions retain that expansion path. |
| `StateInk` | One-line state text with a semantic fill, border and glyph. |
| `FlatCard` | Shared 12 pt padding and radius; content uses the bounded primitives. |

| Viewport identifier | Cap (pt) |
| --- | ---: |
| `monitor.openTable`, `monitor.evidence.positions` | 148 |
| `monitor.fillsList`, `monitor.evidence.fills` | 220 |
| `monitor.shadowList` inside the `monitor.shadow` card | 330 |
| `books.rows` | 420 |
| `books.openTable`, `books.handTable` | 148 |
| `books.tickets` in book detail | 260 |
| `engine.policySummary.<id>` in engine detail | 176 |
| `engine.history.accounts` | 160 |

**Bounded by rule.** Data growth scrolls within the declared viewport instead of growing a card.
The Engines catalog is an explicit exception: its lifecycle sections belong to the page List
(`engines.list`), with no nested catalog viewport. Pinned headers have an opaque background.
The page order is Tools (including Bind and Create), catalog status, Requests, lifecycle catalog
sections, Risky Batman, Offline tuning and Assignments. Pending requests precede the engine rows.
Compact rows show the name, lifecycle, entry toggle and available metrics, plus attention when needed.
The entry toggle occupies its own trailing column, separated from the content by 8 pt. The name
uses a borderless button in the List with explicit ink colour; the lifecycle chip and summary
retain their detail-opening tap gestures, separate from the toggle's confirmation flow.
Detailed rows retain the account, breaker, probe day, win bar, offline tuning link and profit dials.
Row detail, sort and grouping preferences may persist. Search, Show, account filters and group
collapse state never persist because they can hide an engine. Only Retired starts collapsed;
search expands every matching group. The bottom content margin clears the floating Studio launcher.
Catalog order caches engine IDs and resolves each row from current engine data. Plain telemetry
polls and clock ticks update values without reordering rows. The order is recomputed when the ID
set, lifecycle, entry control or pending state changes, when the query or grouping changes, or on
pull to refresh. Search-time header taps cannot change the stored session collapse state.
The page List's refresh gesture also reaches the nested Offline tuning and Risky Batman boxes;
those boxes move out in a later slice. A trailing swipe starting on the toggle thumb changes the
toggle through the KHF-D01 confirmation flow instead of opening row swipe actions.
Tables may scroll sideways internally; their viewport must stay inside the window. Height budgets
stay fixed at accessibility text sizes. The page may move to reveal a box, but reaching its last
row must scroll that box itself. Engine settings uses the available form viewport and a sticky
safe-area action bar, with Save/Review and Discard clear of bounded content and the full blocking
reason inside the bar. `OpsLayoutUITests` checks the listed overview viewports with a 2 pt height
tolerance, inner-scroll reachability and action-bar clearance in light and dark AX captures.

| Screen | What it shows now |
| --- | --- |
| Monitor | Paired-account lane, Alive states, Money and equity history, Open now, Recent fills, Runner sizing, Shadow engines, Placed orders and evidence. Unsupported dashboard fields read Not reported; fills never stand in for orders. |
| Books | Counts, bounded Open now and Needs a hand tables, then the bounded book list. Each book retains its condition, observation progress, edge and Yes/No prices. Detail keeps the quote strip, entry gate and bounded tickets. |
| Engines | Compact or detailed rows in the page List, with lifecycle groups, search, filters and stable metric sorting. Detailed rows include profit dials. Detail has Configure, Performance and bounded policy dials. History has daily bars and a bounded account table. |
| Engine settings | Grouped plain-language settings with help, global and per-account scope, a multi-change draft, and a sticky bar with the unsaved count, Discard and Review. The assistant launcher hides here so it cannot cover Review. |
| Settings | Connection status as chips, credential setup, Appearance, Help and Build. |

Identifiers, flows and strings asserted by the UI tests did not change. Fixture mode still blocks
every write, and the read-only proof boundary below still holds.

The replay recipe for these renders is `walk/OVERHAUL-WALK.md`.

## Read-only proof boundary

This design acceptance preserves the app's read-only monitoring role. Replay uses
the bundled fixtures and no real key or dashboard token. Bind and Create are
disabled in fixture mode, and no Set control is present. Changing a history range
or navigating the fixture screens does not authorize a runner change.

The source also contains live control flows. The fixture screenshots do not prove
their delivery, application or safety, and this guide does not authorize their use.
Likewise, connection messages produced by fixture walks are not proof of a live
connection.

## Replay recipe

Use an isolated checkout of `4e4e934` on the designated Mac build host. Keep the
documentation commit separate from this implementation baseline. Use Xcode 27
with an installed iOS 27 simulator runtime and XcodeGen. Record the full resolved
commit, Xcode build version, runtime version, simulator ID, appearance and text
size alongside the result. Do not substitute the simulator script's older default
runtime for iOS 27.

1. Generate the project with `xcodegen generate` from `ios/`.
2. Create a dedicated iPhone 17 Pro Max simulator on iOS 27. Record the returned
   UDID as `SIM_ID`; boot it and wait for boot completion. Use portrait orientation,
   light appearance and the default text size for the baseline screenshots.
3. From `ios/`, build and run the single accepted fixture test below. Use new output paths
   for each replay so existing evidence is retained.

```sh
xcodebuild test -project LeafHFT.xcodeproj -scheme LeafHFT \
  -destination "platform=iOS Simulator,id=$SIM_ID" \
  -derivedDataPath "$REPLAY_DIR/DerivedData" \
  -resultBundlePath "$REPLAY_DIR/design.xcresult" \
  -parallel-testing-enabled NO \
  -only-testing:LeafHFTUITests/FixtureUITests/testFourScreensAndFrozenFixtureValues \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO
xcrun xcresulttool export attachments \
  --path "$REPLAY_DIR/design.xcresult" \
  --output-path "$REPLAY_DIR/screenshots"
```

Set `REPLAY_DIR` to a new absolute directory owned by this replay before running
the commands. The test launches with `-LEAFHFT_FIXTURES 1`, English and `en_US`.
Its data comes from
`Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures`, included in the app bundle.
Do not import credentials to make the fixture walk work.

4. Inspect the five exported full-resolution attachments: Account, Books, Book
   detail, Engines and Settings. Confirm each baseline image is 1320x2868. Retain the attachment
   manifest so names remain tied to their test and result bundle.
5. Follow the accepted traversal: on Account, select 1d, 7d and All and check
   4, 8 and 12 chart points respectively, with cash and account values matching
   the balance fixture. Open Books, confirm the 14-book count and scroll through
   all 14 books, checking each ID and entry-condition distance against its fixture.
   Open book 14 and confirm the exact ticker `FIXTURE-T-14` and hidden tab bar.
   Use the native Books Back button to restore the Books list and selected Books
   tab. Then open Engines, check each engine's bound books and disabled Bind and
   Create controls, and confirm Set is absent. Finally open Settings, reveal the
   secure credential field, enter only the non-secret marker `fixture`, and check
   redaction and disabled Import. The Settings attachment includes this state.
6. Inspect screen fit at native resolution. The chart and target control must fit
   between navigation and tabs. Scroll to expose the whole target before capture;
   a partly visible but tappable control is insufficient. Keep full screenshots,
   rather than cropped images that hide clipping or navigation overlap.

## Verification and limitations

The documentation verification command, run from the repository root, is:

```sh
python ios/scripts/verify_core.py
```

Preserve its exact output separately from the native test log, `.xcresult` and
screenshots. A core verifier result does not establish rendered screen fit. Native
assertions check fixture values, navigation and disabled controls; visual inspection
checks hierarchy and readability. Record failures as failures and retain successful
evidence from earlier stages.

This recipe binds visual proof to `4e4e934`, Xcode 27, iOS 27 and the stated
resolution. It does not establish physical-device behavior, TestFlight delivery,
live telemetry, order execution, all screen sizes, all text sizes or both
appearances. A different appearance or accessibility text size is a separate
capture with its own recorded settings. Relative observation ages and system chrome
can vary between runs; fixtures do not imply byte-identical screenshots.

## Cleanup

After exporting and inspecting evidence, shut down and delete only the simulator
created for this replay, using its recorded UDID. Remove only this replay's generated
build products when no longer needed. Retain the source/environment record, logs,
result bundle and screenshots for review. Do not erase shared simulators, remove
credentials or alter the runner as part of cleanup.
