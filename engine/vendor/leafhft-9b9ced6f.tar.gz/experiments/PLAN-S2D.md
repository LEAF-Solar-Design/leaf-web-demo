# S2D: independent edge research (operator directive 2026-09-05 22:05 CT)

Operator's words: "do research to find and implement a winning plan that is independent of the bias on the
strategies I bestowed you (probably developing your own twists; if this was a solved problem, everyone would do
it)." This document is the research program's contract. It is written before any search and committed before any
measurement past the fence; the pair records that build the tools cite it.

## What "winning" means here, and what it cannot mean

A candidate wins when, net of the venue's costs (Binance.US maker 0 bps, taker 2 bps, plus the execution
allowance the fill model charges), its per-block or per-trade return has a positive one-sided lower bound at the
declared quantile on data it never saw, survives the haircut stress, and then reproduces in shadow on the runner.
It cannot mean a backtest that looks good on the same data that suggested it; that is the failure mode this
program is built to refuse. On $100 a winning maker earns cents a day; a winning slow signal earns a few percent a
month with drawdowns. Neither number is the point of this stage; the point is an instrument with a measured edge,
which is what the sizing law in S2C waits for.

## The fence (frozen now)

- Kline history (Binance.US 4h and 1m, plus Coinbase and Kraken 1m once fetched): development = everything before
  2023-01-01T00:00Z; holdout = 2023-01-01 to the venue suspension (2023-07-14) and 2025-02-19 onward. Development
  is where hypotheses are formed and tools are debugged; holdout is touched once per pre-registered candidate.
- Tick recordings: development = the workstation samples of 2026-09-04/05 and the runner's pre-window hours
  (2026-09-05 20:29Z to 23:59Z) for all three venues, plus Coinbase and Kraken recordings at any time (they are
  diagnostic in S2A); holdout = the runner's Binance.US recording inside the S2A window (2026-09-06 00:00Z to
  2026-09-19 00:00Z), untouched until S2A closes, and every Binance.US day after that until a candidate is registered
  against it.
- The tools enforce the fence in code: a manifest carries the fence timestamps, and the measurement subcommands
  refuse any input row past the fence unless a registered candidate id is passed.

## The budget (frozen now)

K counts every candidate evaluated on holdout across S2C and S2D: S2C spent 2. S2D pre-registers at most 3 more
(K_running 5, quantile 0.05 / 5 = 0.01 for each lower bound). Exploratory measurements on the development slice
do not count; they are not decisions. A candidate is a full specification (signal, sizing inside the conservative
box, execution assumptions, exit rules), registered in experiments/ before its holdout run, with the same fold,
purge, embargo, bootstrap and seed machinery as S2A/S2C.

## Hypotheses the planner brings (to be measured, not assumed)

H1 Lead-lag maker. Binance.US is thin and lags the liquid venues. Measure the cross-correlation of 1-second mid
returns Coinbase -> Binance.US and Kraken -> Binance.US at lags 1 to 30 s on the development ticks; if the leader's
last 1 to 5 s return predicts the next 5 to 30 s of Binance.US mid, a maker that skews or pulls its quote on the
leader's move captures spread with less adverse selection. The candidate would be the S2A maker plus one input.

H2 Toxicity-gated quoting. Adverse selection on thin venues arrives in bursts. Measure the markout of hypothetical
passive fills (touch-crossing events) conditional on trade-flow imbalance over the previous 10 and 60 s; if
adverse markout concentrates when imbalance is large, a maker that stops quoting during imbalance keeps the spread
it captures. Also a candidate built on the S2A maker.

H3 Hour-of-day and weekend structure. Measure spread, depth at touch, quote update rate and markout by UTC hour and
weekday. If spreads widen where toxicity does not, quoting only those hours raises capture per fill.

H4 Slow regime signal. Time-series momentum on daily closes (lookbacks 10, 20, 40, 60, 90 days; long or flat;
volatility-targeted position; taker entries at 2 bps plus 2 bps allowance) measured on development years only with
the fence enforced. This is a conviction-leg candidate with different logic from the breakouts: it trades a few
times a month and holds for weeks.

Both consult seats are asked for their own hypotheses under the same constraints and to critique these four.

## Process

1. Tools (pair records): scripts/edge_scan.py measures H1 to H4 on the development slice and writes reports/s2d/;
   scripts/klines_fetch.py gains Coinbase and Kraken 1m adapters so H1 can be checked at minute scale over years.
2. Consult round 7: both seats' independent hypotheses and critiques, with the measurements in hand.
3. Pre-register at most three candidates (experiments/s2d/manifest-<n>.json, rows in the ledger where prospective).
4. Holdout evaluation, one pass per candidate, with the S2C harness machinery (replay for maker candidates through
   scripts/s2a_bounds.py; walk-forward for slow signals through the conviction harness's fold code).
5. Any promoted candidate runs 14 days in shadow on the runner beside the four paper books before paper-live;
   real money stays behind the operator's yes per stage.

## What is refused

Parameter sweeps on holdout; choosing a candidate from holdout outcomes; resetting K; presenting development-slice
results as evidence; leverage, funding plays and cross-venue arbitrage that needs capital on two venues; anything
that quotes REST on Binance.US from more than one process (weight budget).

## Round 7 (2026-09-05 23:30 CT): the seats' own hypotheses, the convergent three, two fence amendments

Transcripts: consults/round7-astra.txt, consults/round7-kimi.txt. Astra brought H5, buy a temporary local
dislocation (Binance.US ask at least 15 bps below the Coinbase/Kraken mid adjusted by the trailing 30-minute median
basis, both leaders moved under 3 bps in 5 s, the discount persisting through two observations 500 ms apart; marketable
limit up to $10; exit when the discount is under 3 bps, after 120 s, or at a 15 bps executable loss; one position;
expected +2 to +6 bps per completed trade if supported; kill on a negative base-cost mean or fewer than 30 separated
events), and H6, absorption of selling (needs sequenced depth we do not record; parked). Kimi brought K1, take the
stale Binance.US quote during a quote gap over 10 s while the Coinbase mid moved over 6 bps (the same mechanism as
H5 seen from the gap side; the failure mode is a stale quote that is already gone at 350 ms), and K2, post-burst
spread replenishment as a maker (kimi's own prior, the 8b drift, argues against it; parked).

Critiques adopted: H1 becomes a defensive cancel (pull the resting quote when a leader moves against it by more than
2 bps within 5 s; no predictive skew, because our Binance.US view is a 0.5 s REST poll and the 1 to 5 s leader signal
is half-decayed by the time we see it), killed fastest by incremental liquidation P&L against identical ungated
quotes after a 350 ms cancel delay, requiring positive absolute net P&L, not only improvement. H2 becomes an
asymmetric gate (pull only the side the imbalance points at, keep the other; at 2.4 prints a minute full gating
throws away the scarce thing, fills), measured side-specifically relative to displayed queue with an explicit
no-trades state, killed if adverse markout is not concentrated in the top imbalance decile. H3 is unidentifiable on
3.5 hours of runner data (168 weekday-hour cells); it is a descriptive filter, not a candidate, and gets no K. H4
stays a development-only screen (one frozen lookback, indicators reset across the suspension, exposure-matched
against holding BTC); it does not touch K unless its development t-stat clears 2, and the round-6 stop on
breakout-style families stands.

The three that get the K budget, in order, if their development screens pass: H2 asymmetric gate on the S2A
maker; H1 defensive cancel on the S2A maker; H5/K1 dislocation taker. A failed development screen leaves its slot
unused. Astra's estimates: +0.3 to +1 bp per fill (H2), +0.5 to +2 bps per fill (H1), +2 to +6 bps per trade
(H5); all planning ranges, none measured.

Fence amendments (this supersedes the fence section above where they differ):
- Klines: development = before 2023-01-01T00:00Z plus 2025-02-19T12:00Z to 2026-06-30T23:59Z (the post-suspension
  regime is the one we trade; kimi); holdout = 2026-07-01T00:00Z onward, touched once per registered candidate.
- Ticks: a candidate's holdout is prospective: the 14 days after its registration, with the candidate replayed on
  that recording once and run in shadow on the runner over the same days. Everything readable before registration
  is development, with one standing exception: the Binance.US recording inside the S2A window (2026-09-06 to
  2026-09-19 00:00Z) is not read by anyone until S2A closes, after which it becomes development for S2D. This
  honours astra's embargo (no same-period cross-venue information reaches a holdout) without starving development.
- The tools enforce both: fence.json carries the kline windows and the S2A embargo interval for Binance.US ticks;
  holdout access needs a registered candidate id and a registration timestamp earlier than the data.

Data reality for the tick screens this week: development ticks are the workstation samples of 09-04/05 plus the
runner's pre-window hours (Binance.US 20:29Z to 00:00Z on 09-05) plus Coinbase and Kraken at any time. The
dislocation and lead-lag screens need synchronized venues, so their event counts will be thin until 09-19 opens
13 more days; a screen that reports fewer than 30 events reports insufficient evidence, never a verdict.

## First measurements and round 8 (2026-09-06 00:00 to 00:45 CT)

Tools landed (all astra): scripts/edge_scan.py (H1 to H4 on ticks and klines, fence in code; then the round-7
screens; then short candles, both kline windows and a cut at the embargo inside a straddling file);
scripts/klines_fetch.py venue adapters corrected from observed live payloads (Coinbase 301-candle inclusive windows,
JSON numbers; Kraken serves only its most recent 720 minutes, recorded as limited). Data on disk: Coinbase 1m
3,687,258 rows 2019-09-01 to 2026-09-06 (179 gaps); Kraken 1m 720 rows only. Receipts: reports/s2d/ticks-local.json,
ticks-runner.json, ticks-runner-r7.json (main 621b13e). The runner's earlier instances took their recordings with
them, so its development Binance.US data is the 22:28Z to 00:00Z stretch of 2026-09-05; the workstation adds two
short REST-polled samples.

What the development slice shows (1.5 hours synchronized, one afternoon, one regime; n as stated):
- Lead-lag is one-directional at 5 to 30 s: Coinbase's trailing 5 s log-mid return predicts Binance.US's next 10 s
  with slope 0.235, t 6.0 (Newey-West lag 10, n 5,461), next 30 s slope 0.294, t 4.8; trailing 10 s to next 5 s
  slope 0.114, t 5.8. Reverse direction slope 0.19, t 2.0 at 1 s and near zero at 10 s. Kraken pairs withheld
  (under 1,800 paired seconds).
- Binance.US 1 s returns autocorrelate +0.146 at lag 1 (n 5,504), +0.080 at lag 2, then zero; the workstation's
  REST-polled sample shows the same +0.14, which is evidence the grid or the sampler manufactures part of it.
- Toxicity is inverted on the thin venue: passive fills after heavy one-sided flow (10 s window) mark out +0.297
  bps at 30 s on Binance.US (n 209, hour-block bounds +0.228 to +0.834, but only 3 usable blocks) against -0.25 bps on
  Coinbase (n up to 41,178, bounds below zero) and -0.7 to -1.6 on Kraken. Coinbase's side-specific queue-relative
  buckets are cleanly ordered (-0.09 to -0.23 bps as opposing flow rises); Binance.US's have 3 to 41 events each.
- Round-7 screens: 0 dislocation events at 15 bps (30 times the 0.5 bps median spread) in 1.5 hours; the
  defensive cancel never triggered (no Coinbase 5 s move over 2 bps in the sample; A equals B at 12 fills);
  Binance.US structure in the observed hour: median spread 0.50 bps, touch depth about $2,200, 234 quote updates
  and 1.4 trades a minute.

Round 8 (consults/round8-astra.txt, round8-kimi.txt): both seats MEASURE MORE FIRST, narrowly, and both specify
the same candidate of the planner's own, the leader-anchored maker: fair value F = Coinbase mid x exp(B) with B
the trailing 30-minute median log-basis over paired 1 s boundaries (1,500 valid pairs, 30-minute warm-up); one
half-spread 0.5 bps (no grid) with S2A's volatility term and inventory skew; post-only quotes capped inside the
displayed touch and at least 0.25 bps from F; cancel the bid when Coinbase's 5 s return is under -2 bps and the ask
over +2 bps, cancel any quote within 0.25 bps of F, cancel both when either feed is over 2 s stale or the basis
window lacks coverage, re-post after 5 healthy seconds; everything else frozen from S2A (record s2d-anchor-mm builds
it as a fifth paper book, `anchor`, on the runner). Kimi kills the dislocation taker (0 events; a 30x-spread
threshold is structural; even a 2 bps version cannot clear 4 to 8 bps taker costs) and folds H2 into the cancel rule
(its premise is inverted here: the bursts are where the good fills are); astra leaves both slots unused and keeps a
descriptive 2 bps dislocation screen. Defects both seats named, fixed in record s2d-edge-scan-4 before any number is
trusted: the runner report merged five Binance.US captures (the recorder plus four paper books) with a receive-time
dedup key, so one exchange event can be counted several times; the 1 s grid can manufacture the lag-1
autocorrelation (recompute on update times); 120 s markouts; trigger counts; a decile screen for H2; raw t-statistics
under 5 hour blocks. Kimi's checkout lacked the reports (a stale consult clone), so kimi's numbers are conditional;
the clone is verified by HEAD before every round from now on.

Decision: no K slot is spent yet. The clean 72 hours both seats want are inside the S2A embargo, so the 13-day
Binance.US recording is measured once, in one pass, on 2026-09-19 with the corrected tool; the leader-anchored
maker is then registered (experiments/s2d/manifest-3.json, K_running 3, quantile 0.05 / 5 = 0.01) for a
prospective 14-day replay through scripts/s2a_bounds.py with the Coinbase feed merged causally, plus shadow on the
runner over the same days; minimum information 576 qualifying 30-minute blocks over 12 complete days with 1,500
jointly usable seconds per block (astra) and at least 150 fills (kimi); a win is positive conservative lower bounds
at 0, 1 and 2 bps haircuts, positive absolute shadow P&L, and a positive paired improvement over the frozen S2A
baseline. Until then the book runs in paper beside the four S2A books so its behaviour is observed live, and the
cancel-rule trigger counts and update-time statistics are reported daily from the runner's unembargoed Coinbase and
Kraken streams.

## Live comparison (2026-09-06, appended; the fence and the budget above are unchanged)

The operator's mandate of 2026-09-06 (18:20 CT, revised 19:30 CT) runs the S2A maker and the leader-anchored maker
(leafhft/strategy/anchor_mm.py, frozen parameters) in alternating four-hour blocks on the live Binance.US book at the
account's own size, with each block labeled in the ledger and in the fill tape. This is money and diagnosis, not
registration evidence: the anchored maker's live fills, P&L and markouts are reported beside its future registration
and never counted toward it; the registration still requires the one-pass measurement on the embargoed recording
after 2026-09-19 00:00Z and the prospective 14-day replay and shadow with the bounds stated above. Live fills are
read only from the live run directories (receipt, ledger, live-orders.jsonl) and never joined against the recording.
The scoreboard for the mandate is scripts/live_bound.py (astra's anytime-valid evidence product over operating
blocks with its five pass conditions, plus the hourly-blocked bootstrap diagnostic), pre-stated here before any of
its inputs existed: pass means E_n >= 100, at least 12 complete operating days, at least 150 fills, positive
aggregate net liquidation P&L, and positive execution P&L with drift attributed separately. Fills before the first
frozen configuration (main 177c45c, the two-sided maker) are diagnosis only.

## Kalshi convex book (2026-09-06 23:10 CT, appended before any Kalshi data exists)

Operator's ask: the most ambitious legal strategy with the stake at risk by consent; both consult seats (round 10)
picked Kalshi crypto up/down binaries with a settlement-aware fair value and excluded Coinbase perpetuals. Stake:
$100 in a separate Kalshi account, of which $20 is a perpetual-futures sleeve at 5x under a frozen breakout rule
bought for convexity, not expectancy. Pre-stated before the first recording:
- Mechanism: in the settlement minute, k of 60 index observations are known; YES settles if the remaining average
  clears (60K - S_k)/(60 - k); a quote that has not moved for the arrived observations is stale by arithmetic.
- Threshold: buy only when a conservative settlement probability exceeds the executable ask plus fees plus a
  measured latency penalty by at least 3 cents per contract; hold to settlement.
- Measurement gate before any order: a full day of recording; at least six gaps an hour at or above the threshold
  that survive three seconds with depth of at least five contracts; settlement reconstruction matching the official
  result for every expiry; the index delivery delay measured. Failing the gate keeps the money in cash.
- Caps: day 3 at most $1 loss per order, $3 correlated open, $5 realized plus worst case; day 4 at most $2, $5, $10;
  the two-week configuration $5 per order, $10 per correlated expiry cluster, $100 maximum net loss. The perp sleeve
  closes at a cumulative -$20. Never martingale, replenish, retry unreserved, or count correlated expiries as
  independent proof.
- Evidence rule: hundreds of quotes on one expiry are one outcome; the scoreboard for this book counts settled
  expiries, and nothing here counts toward any S2D registration.

## Kalshi measurement day 1 (2026-09-07, appended 06:50 CT; main 696f093)

- Tape: 34 recorder fragments, 24 KXBTC15M markets (11 YES, 13 NO), settlement reconstruction 60 of 60
  observations per market, labels checked against the venue's official results (5 of 5 match), index delivery
  delay p99 13.7 ms.
- Model: after the random-walk variance fix (record kalshi-fair-variance) the fair value is calibrated inside
  the settlement minute (Brier 0.0186 under 60 s, 0.0039 under 30 s) and biased before it (the remaining-average
  variance ignores the drift until the window opens; Brier 0.166 at 60 to 180 s).
- The gate, measured: the venue's own quotes are calibrated where the mechanism lives (Brier 0.0435 under 60 s,
  0.0022 under 30 s); 2 tickets in 24 markets ever cleared a 3-cent edge, both at the instant the window
  opened, 1 won 1 lost, net negative per dollar. Gaps per hour effectively zero against the bar of six.
- The lead, measured: our Coinbase recording against the BRTI index, 10-second returns, correlation 0.927 at
  lag 0, 0.52 at +/-5 s, ~0 beyond: no lead to sell.
- A frozen momentum rule (index 60 s move 2 to 5 bps, mid-priced ask, one ticket per market) loses on the same
  tape (1 to 3 tickets, 0 to 1 wins). Not a candidate.
- Outcome, as pre-stated: the binary book's stake stays cash; no ticket bought. Recorders for ETH-15M, BTC-1H and
  ETH-1H started 11:33Z for a four-series replay on day 2 (the hourly books were kimi's alternative). The
  pre-window variance is a known defect to fix before that replay so the model can be judged everywhere.
- The perp sleeve (item 8) went live 11:19Z at $20 under its own authorization after the rule fix (record
  perp-compression: the old comparison could never fire; the fixed rule shows 7 breakouts and 1 attempt on 5.8 h
  of tape). Operator asked to accelerate; the plan's full-day bar was shortened to 5.8 hours on that instruction.

## Kalshi: operator override, day 1 afternoon (2026-09-07 13:16Z to 13:19Z, appended)

- 13:16Z "pick the fastest time stop and re-arm the sleeve": the time-stop sweep (records perp-compression,
  sleeve-heartbeat; cells between -$1.31 and +$0.45 on about $100 notional over 7.7 h, i.e. noise) is decided on
  cadence by the operator: time stop 30 min, cooldown 15 min, entry 5/30/1.0 (record sleeve-fast-profile-30).
- 13:16Z "theres $65 on kalshi lets start trading already": the binaries book is armed under kalshi-experiment
  at a $40 stake (digest 0282044b0ff0..., $1 max loss per ticket, $3 per cluster, $5 per day) although the day-1
  gate failed; stated twice to the operator and reaffirmed. The book trades to buy live execution evidence
  (fills, reconciliation, settlement accounting) with the loss bounded at $5 per day; nothing here is edge
  evidence, and the two-week configuration ($5 per order) stays closed until a replay shows calibrated gaps.

## Kalshi day 1 evening: keys, fixes, recovery (2026-09-07 17:30Z to 19:50Z, appended)

- The perps exchange needs its own API key (the first live margin order with the predictions key returned 500;
  the SDK documents separate perps keys). A perps key was created and vaulted (secret leafhft-runner-kalshi-perps-key,
  record kalshi-perps-secret). Creating it revoked the predictions key (REST 401 on both), which silently starved
  every new websocket session: the sleeve died on the 60 s idle default at each start while the recorders and the
  binaries book lived on old connections. A replacement predictions key was created and vaulted; all units restarted
  19:39Z on main e24dc19 (records kalshi-live-idle: 300 s idle plus reconnects; live-reseed-maker: the Binance.US
  book reseeds as a maker bid and a per-order gate refusal is a journaled reject; perp-reply-capture: refusals keep
  the venue reply). Binance.US run 100711 had died at 15:50Z on the IOC reseed and looped two hours unnoticed.
- Rule kept from this: after any key creation on a venue, re-probe every other key with the reconcile command
  before trusting long-lived connections, and check NRestarts on every unit, since is-active reads active during a
  restart loop.

## Kalshi day 2 morning (2026-09-08 12:45Z, appended)

- Sleeve: six round trips since the first accepted fill (23:32Z), all closed by the 30-minute time stop, realized
  -0.42, +0.51, then four overnight netting -0.38; cumulative -$0.29 at about $0.01 fee per trade (the launch
  promotion is not zero-fee on this account). No stop-loss or liquidation; the rule fires 4 to 8 times a day.
- Binaries: live since 13:19Z day 1, no ticket in 23 hours (measured rate was two qualifying edges per six hours
  on day 1; day 2 has produced none).
- Binance.US: run 003823 died at 01:38Z on the first-hour probe (cash $1.46 below the venue-minimum buy) and the
  unit looped 1,340 refused restarts until 12:18Z; the probe now uses the inventory side (record
  live-probe-sell-side, main a48dac0); re-armed 12:44Z.
- Dashboard: the operator picked direction C on the design canvas; live on ops-dashboard master de1f4cd6.
