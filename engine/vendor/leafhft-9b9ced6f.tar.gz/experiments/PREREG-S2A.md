# S2A pre-registration (frozen text; rows are registered by `scripts/s2a_bounds.py register`)

Reviewed by both seats on 2026-09-05 (consult round 4, `consults/round4-{astra,kimi}.txt`): astra "do not
register until the analysis is executable and frozen", kimi "register with these edits". Both sets of edits are
folded in below; where the seats differed (bootstrap algorithm) the simpler fixed rule was chosen and the
alternative is named. Registration happens only after this text and `scripts/s2a_bounds.py` are committed, so the
rows' `code_digest` covers the analysis. Nobody reads the evaluation recording before the window closes.

## Frozen candidate family

Maker `leafhft/strategy/mm.py`, maker only. Frozen for every candidate: `vol_mult 1.5`, `order_frac 0.05`
(about $5 per quote, inside the $10 order cap; the code default 0.25 would request $25 and be rejected by the
conservative box, which is why the earlier draft described a strategy the code could not run), `seed_frac 0`,
`cost_rt_bps 0`, `min_edge_bps 0.25`, every other parameter at its code default and listed explicitly in the
row. Risk box `RiskLimits.conservative()`: $10 order, $25 inventory, halt at $2 daily loss or 5% drawdown.
Start cash $100.

Grid, K = 4: `half_spread_bps` in {0.25, 0.5, 1.0, 2.0}. No second axis (vol_mult is masked at tight spreads
and dominant at wide ones, a confounded axis; a size tier is pointless at the conservative box).

Venue: `binanceus:BTC-USD`, maker 0 bps, taker modeled 2 bps. Coinbase and Kraken recordings are diagnostic
only; no row is registered for them. Fees are isolated by paired re-accounting, not by a second venue: the
conservative run's own fills re-charged at Coinbase's schedule (maker 60, taker 120 bps) give
`conservative_fees_coinbase`, reported and never gating.

## Data and windows

Training, already seen: local recordings 2026-09-04 22:52Z to 2026-09-05 15:09Z (readout 8b).
Cutoff: the registration time. Embargo 3600 s. Evaluation window: from the first UTC midnight at least 3600 s
after the cutoff, 13 complete UTC days; never backdated. Recording exists on runner i-0aea5f579a4d9622a since
2026-09-05 20:29Z (hash-chained ticks.jsonl, 24-hour files); ticks before the window start are not evaluation
data and are not inspected.

Replay is continuous across recording files: inventory, orders and risk state carry across blocks and files,
risk epochs follow replay UTC time, a kill stays latched, terminal liquidation is charged once at window end.

## Blocks, coverage, metric

Fixed 30-minute UTC blocks. Reward per block = 10000 x change in liquidation equity / $100 start cash (bps).
Idle and no-fill blocks count. Coverage per block = quote-fresh seconds (last quote at most 2 s old). A block
qualifies with >= 1500 covered seconds; a UTC day qualifies when all 48 blocks qualify; 12 qualifying days are
the minimum information (576 blocks). Excluded periods are reported with their P&L, nothing is dropped silently.

Primary metric: mean per-block reward under `conservative_fees` (350 ms order latency, queue behind visible
size, adverse selection 2 bps, venue fees). `optimistic` (0 ms, touch, no adverse) is the rejection screen on
its point estimate. Haircuts 0, 1, 2 and 5 bps are extra cost per executed notional, terminal liquidation
included; 0, 1 and 2 gate, 5 is diagnostic.

## Dependence, multiplicity, power

Bound: circular block bootstrap over whole qualifying UTC days, block length fixed at one day, no length
randomization, 10,000 resamples, NumPy PCG64 seed 20260905, the same resampling indices for every candidate
and condition, one-sided lower bound at 98.75% by the inverted-CDF quantile, no studentization. (Astra's
alternative, a stationary bootstrap with geometric mean run length two days, was not chosen: one more parameter,
same honesty about 13 clusters.)

Multiplicity: Bonferroni over the K = 4 Binance.US candidates, alpha 0.0125 each.

Power, declared now and not revised after data: block SD 4 bps and within-day ICC 0.2 are planning assumptions,
not estimates (twenty-minute aggregates do not estimate 30-minute block variance). Design effect ~10.4 at 48
blocks per day, effective n ~55 at 576 blocks, SE ~0.54 bps. Minimum detectable effect at the 98.75% one-sided
bound: 1.2 bps per block (about +5.8% per week gross of drift; a +0.5 bps edge has roughly 16% power). A true
edge below 1.2 bps per block is not promotable in this window; the answer is then hold, never promote.

## Regimes (descriptive only)

For each complete UTC day, volatility = sqrt of the summed squared 5-minute log mid returns, using the last
quote at or before each grid boundary no older than 2 s (otherwise the day's regime is unavailable). Rank days by
volatility (ties by date); rank i of D goes to tercile floor(3(i-1)/D). Mean reward per tercile is reported per
candidate. Regimes never select candidates, exclude returns, or trigger extension.

## Decision, applied once at window close, coverage checked before any return is computed

1. Fewer than 12 qualifying days: `extend` once by 7 days (a new row, byte-identical except `evaluation_window`
   and `minimum_information`, registered before the window closes); at the extended close a second shortfall is
   `demote`. Returns are not inspected before extending.
2. `demote` if the optimistic point estimate <= 0 or the conservative_fees point estimate <= 0 on the full window.
3. `promote` if the conservative_fees lower bound is > 0 at haircut 0, 1 and 2 bps. Among promoted candidates the
   selected one has the greatest 2-bps lower bound, ties to the smaller half-spread.
4. Otherwise `hold`: frozen, not live, and not an S2B incumbent.

`promote_check` in the ledger records the decision; the statistical rules live in `scripts/s2a_bounds.py bounds`
and in the row strings verbatim, so the row is self-contained if the file is refactored.

## Ledger

`experiments/s2a.sqlite` plus its `.head` sidecar on leaf-hft main, one row per candidate as
`experiments/s2a/rows/<experiment_id>.json`, the ledger head hash in the registration commit message and in
PLAN-STAGE2.md 8g. The runner never writes to it (the machine that timestamps the data must not timestamp the
registration). A local hash chain proves internal consistency; the public commit before the window start is the
registration time.

## What S2B inherits from here

The incumbent is whichever candidate `promote` selects (none if all hold). Confidence-scaled sizing (fractional
Kelly on the calibrated fill and edge estimates, operator's ask 2026-09-05) is an S2B challenger against that
incumbent, evaluated by the same method on the following 14 complete UTC days; it is not part of S2A.
