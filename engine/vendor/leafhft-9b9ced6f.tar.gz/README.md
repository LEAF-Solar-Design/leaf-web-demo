# leafhft

Hardened, paper-first high-frequency crypto trading engine. Built 2026-09-05 as the Leaf
"ultimate systems test": load $100, trade it in quick succession, reach $1000.

The honest headline lives in `docs/archive/REPORT.md`. Short version: the platform is real and measured;
the tenfold objective is not reachable by unlevered spot trading at retail fee tiers, and the
math that says so is in `python -m leafhft goal`.

## What it does

* Live market data from Coinbase (WebSocket), Kraken (WebSocket v2) and Binance.US
  (WebSocket when reachable, REST polling otherwise), validated into fixed-point integers.
* An L1 book with rolling features (microprice, imbalance, order flow, z-score, volatility).
* A paper broker that fills against the live book with latency on orders and cancels, queue
  position known only once our price has been the touch, displayed-depth-only taker fills,
  print-evidence-only maker fills (a crossed snapshot is ambiguous by default), slippage and an
  adverse-selection haircut. Spot rules enforced: long-only, cash and base reserved and re-checked
  at fill. Every fill is attributed to its rule in the receipt.
* Three strategies: post-only market maker (`mm`), taker momentum (`momentum`),
  maker mean reversion (`meanrev`).
* A latching risk manager: order/position caps, rate limits, price band, stale-feed block,
  daily loss limit, drawdown kill, kill file.
* An append-only hash-chained SQLite ledger (tamper and truncation evident).
* Tick recording and deterministic replay, so every live run is a backtest fixture.
* Post-fill markouts at 1/5/30 s, the measurement that replaces the haircut guess.
* A live rail that fails closed unless the operator writes an ack naming the config digest,
  sets `LEAFHFT_LIVE=1`, provides venue credentials, and stakes at most $100. Arming consumes
  the ack (one yes, one run, time-boxed) and binds astra's conservative limits to the
  authorization the signed client requires for every order.

## Run

```
python -m pytest tests -q
python -m leafhft goal
python -m leafhft record --venue coinbase --symbol BTC-USD --seconds 600
python -m leafhft paper  --venue binanceus --symbol BTC-USD --strategy mm --seconds 900 --transport rest --haircut-bps 1
python -m leafhft replay --venue coinbase --symbol BTC-USD --strategy momentum --file runs/<run>/ticks.jsonl
python -m leafhft verify --ledger runs/<run>/ledger.sqlite
python scripts/sweep.py --recordings runs/<run>/ticks.jsonl --out runs/sweep
python scripts/ledger_summary.py runs/<run>/ledger.sqlite
```

`--haircut-bps` (default 1) is the provisional maker adverse-selection debit; `--snapshot-fills`
turns on the optimistic crossed-snapshot rule and is off by default; `--queue-model touch` is the
optimistic queue. The receipt's `fill_rules` and `markouts` say what the run actually did.

## UI

The iOS app's accepted SwiftUI hierarchy and fixture screenshot replay are documented in
[the iOS design guide](ios/DESIGN.md).

Local, read-only, loopback only:

```
python -m leafhft ui --runs runs --port 8811
```

Then open http://127.0.0.1:8811/. It lists every run directory, follows a live session by
ledger row (2 s polling), charts equity at mid against the cash and buy-and-hold baselines
with fills as dots, and shows fill rules, markouts, feed quality and risk rejects. Its one
write is the KILL button, which drops the file the risk manager polls.

The same runs appear on the ops dashboard at `/leafhft` once pushed:

```
python scripts/push_runs.py --url https://ops-dashboard-seven.vercel.app
python scripts/push_runs.py --url https://ops-dashboard-seven.vercel.app --run-dir runs/<run> --watch --every 5
```

The wrapper resolves `LEAFHFT_INGEST_TOKEN` from the fleet credential store inside the process;
`python -m leafhft push` does the same job when `LEAFHFT_DASHBOARD_TOKEN` is already in the
environment. Pushes are idempotent on ledger row ids, so re-pushing a run is always safe.

Every run writes `runs/<timestamp>-<tag>/receipt.json`, `ledger.sqlite` and (paper/record) `ticks.jsonl`.
Drop a file named `KILL` into a run directory to stop it.

## Kashbot engines

Kashbot runs named engines on Kalshi books. Paper, replay and shadow results are offline tuning
(simulated): they help choose parameters and are never a verdict. An engine is judged only by a
pre-registered live trial scored from its own fills, and the Engine Lab promotes only from `live_fill`
evidence. New engines start as a one-contract live probe under a signed approval and a UTC-day loss
breaker set as a percentage of the day-start portfolio.

[docs/ENGINES.md](docs/ENGINES.md) is the standard: the three-command recipe
(`engine_ops manifest init`, `engine_ops try`, `engine_ops probe`), the vocabulary, the manifest, kernels
and the policy adapter, the registry, the lifecycle and breaker, the build paths, the operator tooling, the
status object, the action vocabulary, the surfaces and the decision map.

## Layout

```
leafhft/types.py       fixed-point value types, fail-closed validation
leafhft/book.py        L1 book, anchored rolling stats
leafhft/fees.py        venue fee schedules (bps), fee-death arithmetic
leafhft/feeds/         coinbase, kraken, binanceus adapters; recorder/replay
leafhft/broker/        paper broker, live gate, Binance.US signed client (unexercised)
leafhft/strategy/      mm, momentum, meanrev
leafhft/risk.py        latching risk manager
leafhft/ledger.py      hash-chained SQLite
leafhft/engine.py      the loop, metrics, markouts, receipt
leafhft/sim/goal.py    required edge, Monte Carlo, fee death
docs/archive/          stage 1 report, stage 2 plan, budget ledger, experiment spec (historical)
```
