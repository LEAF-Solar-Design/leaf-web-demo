#!/usr/bin/env bash
# Native CodeBuild gate for leaf-hft. The stable loader reads this file from
# the DEFAULT BRANCH (main), never from a pull request head, so a pull
# request cannot rewrite the pipeline that judges it.
set -euo pipefail
# BEGIN SHARD ENV
case "${CI_SHARD_INDEX:-}:${CI_SHARD_TOTAL:-}" in
  :|:1|0:1) CI_SHARD_MODE=all ;;
  0:2) CI_SHARD_MODE=legs0 ;;
  1:2) CI_SHARD_MODE=legs1 ;;
  *)
    echo "ci.sh: refusing unsupported shard env CI_SHARD_INDEX=${CI_SHARD_INDEX:-} CI_SHARD_TOTAL=${CI_SHARD_TOTAL:-}" >&2
    exit 2
    ;;
esac
echo "LEAF_EVENT shard mode=$CI_SHARD_MODE index=${CI_SHARD_INDEX:-0} total=${CI_SHARD_TOTAL:-1}"
# END SHARD ENV
echo "LEAF_EVENT $(python3 -I -c '
import os, subprocess, sys, urllib.parse
e = os.environ
raw = e.get("CODEBUILD_WEBHOOK_EVENT", "")
allowed = {"PULL_REQUEST_CREATED", "PULL_REQUEST_UPDATED", "PULL_REQUEST_REOPENED", "PUSH"}
initiator = e.get("CODEBUILD_INITIATOR", "")
event = raw if raw in allowed else (
    "manual" if not raw and initiator and initiator != "GitHub-Hookshot"
    and not e.get("CODEBUILD_WEBHOOK_TRIGGER") else "unknown"
)
q = lambda value: urllib.parse.quote(value, safe="/:@._-+")
p = subprocess.run(
    ["git", "hash-object", "--no-filters", sys.argv[1]],
    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True
)
blob = p.stdout.strip() if p.returncode == 0 else "unknown"
fields = [
    ("event", event),
    ("head_ref", e.get("CODEBUILD_WEBHOOK_HEAD_REF", "")),
    ("base_ref", e.get("CODEBUILD_WEBHOOK_BASE_REF", "")),
    ("source_version", e.get("CODEBUILD_SOURCE_VERSION", "")),
    ("resolved", e.get("CODEBUILD_RESOLVED_SOURCE_VERSION", "")),
    ("ci_blob", blob),
    ("mode", "none"),
    ("workers", sys.argv[2]),
    ("image", e.get("CODEBUILD_BUILD_IMAGE", "")),
    ("compute", "unknown"),
]
print(" ".join(k + "=" + q(v) for k, v in fields))
' "${BASH_SOURCE[0]}" unknown)"

# Record the interpreter that judged the build.
echo "LEAF_T start pre-install $(date +%s%3N)"
python --version

# BEGIN PRE-INSTALL GATE (B-STD B3, amendment 10). SELF-CONTAINED: the gate is the python below,
# inline in this file (which the loader reads from main), run isolated (-I) with the standard
# library only. It imports nothing from the candidate checkout, reads no working-tree file, and
# reads git objects only (ls-tree, cat-file, diff-tree), so the first pull request that adds it
# gates itself and no later candidate can rewrite a helper before the gate runs. It runs before
# the candidate project is installed or any candidate test is collected. (a) pins.lock.json must
# be a RAW-BYTE append-only extension of the merge base's lock: the base's bytes before its footer
# line are an exact prefix, the footer bytes are unchanged, and the appended bytes are complete
# canonical entry lines; (b) every changed file under the library root must be a bounded regular
# non-executable data file at an approved path (manifest.json, tape.jsonl, fees.json, grid.json),
# never a symlink or a path escape. Any violation, or a base that cannot be read, exits 2 here.
if ! git rev-parse --verify --quiet 'origin/main^{commit}' >/dev/null; then
  git fetch --quiet --no-tags origin '+refs/heads/main:refs/remotes/origin/main' || true
fi
if ! gate_base="$(git merge-base origin/main HEAD)"; then
  if [ "$(git rev-parse --is-shallow-repository 2>/dev/null)" = true ]; then
    git fetch --quiet --no-tags --unshallow origin || true
  fi
  if ! gate_base="$(git merge-base origin/main HEAD)"; then
    echo "pre-install gate: no merge base with origin/main" >&2
    exit 2
  fi
fi
# On a push to main HEAD is its own merge base; judge HEAD's commit against its first parent.
if [ "$gate_base" = "$(git rev-parse HEAD)" ]; then
  if ! gate_base="$(git rev-parse --verify --quiet 'HEAD^1^{commit}')"; then
    echo "pre-install gate: HEAD is on origin/main and has no parent to judge it against" >&2
    exit 2
  fi
fi
gate_dir="$(mktemp -d)"
cat > "$gate_dir/pre_install_gate.py" <<'PRE_INSTALL_GATE_PY'
"""The self-contained pre-install gate: python -I -B <this> <base sha> <head sha|HEAD>. Standard
library and git objects only; never the working tree, never a module from the checkout. Exit 0
admits the candidate, exit 2 refuses it. Every read is bounded; anything malformed fails closed."""
import json
import re
import subprocess
import sys

LOCK = "pins.lock.json"
LOCK_HEADER = b'{"schema":1,"pins":['
LOCK_FOOTER = b"null]}"
MAX_LOCK_BYTES = 1 << 20
MAX_LOCK_PINS = 4096
REGULAR = "100644"
GIT_TIMEOUT_S = 120
LIBRARY_ROOT = "leafhft/library"
APPROVED = {"manifest.json": 16 * 1024, "fees.json": 64 * 1024, "grid.json": 64 * 1024, "tape.jsonl": 8 << 20}
LIBRARY_FILE = re.compile(r"leafhft/library/([a-z0-9][a-z0-9_-]{0,31})/([A-Za-z0-9][A-Za-z0-9-]{0,31})/"
                          r"(manifest\.json|fees\.json|grid\.json|tape\.jsonl)")
PART = rb"[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}"
ENTRY = re.compile(rb'\{"kind":"(?:book_fees|book_grid|book_manifest|book_tape|kernel)","path":"'
                   + PART + rb"(?:/" + PART + rb'){0,11}","sha256":"[0-9a-f]{64}"\},')
REV = re.compile(r"[0-9a-f]{40}|[0-9a-f]{64}|HEAD")
MODE_LABEL = {"100755": "executable", "120000": "a symlink", "160000": "a submodule"}


class Refused(Exception):
    pass


def git(*args) -> bytes:
    try:
        done = subprocess.run(["git", *args], capture_output=True, timeout=GIT_TIMEOUT_S)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise Refused(f"git {args[0]}: {type(exc).__name__}") from None
    if done.returncode:
        raise Refused(f"git {' '.join(args[:2])} exited {done.returncode}")
    return done.stdout


def read_blob(oid: str, limit: int):
    """The blob's bytes, or None when it is larger than `limit`; the size is read first."""
    size = int(git("cat-file", "-s", oid).strip() or b"-1")
    if not 0 <= size <= limit:
        return None
    data = git("cat-file", "blob", oid)
    if len(data) != size:
        raise Refused(f"blob {oid[:12]}: read {len(data)} bytes, expected {size}")
    return data


def lock_entry(rev: str):
    """(mode, type, oid) of the lock at `rev`, or None when it has none."""
    out = git("ls-tree", "-z", "--full-tree", rev, LOCK)
    if not out:
        return None
    meta, tab, path = out.rstrip(b"\0").partition(b"\t")
    fields = meta.decode("ascii", "replace").split(" ")
    if not tab or path != LOCK.encode("ascii") or len(fields) != 3:
        raise Refused(f"unexpected git ls-tree output for {LOCK} at {rev}")
    return tuple(fields)


def first_difference(a: bytes, b: bytes) -> int:
    """The first differing byte offset (binary search over zero-copy memoryview slices)."""
    left, right = memoryview(a), memoryview(b)
    lo, hi = 0, min(len(a), len(b))
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if left[:mid] == right[:mid]:
            lo = mid
        else:
            hi = mid - 1
    return lo


def lock_problems(base: str, head: str) -> list:
    """RAW BYTES, never normalized: the base lock before its footer line is an exact byte prefix of
    the head's, the head closes with the base's exact footer bytes, and every appended byte is a
    complete canonical entry line in the base's line ending."""
    old_entry, new_entry = lock_entry(base), lock_entry(head)
    if new_entry is None:
        return [f"{LOCK}: removed"] if old_entry is not None else []
    if new_entry[:2] != (REGULAR, "blob"):
        return [f"{LOCK}: mode {new_entry[0]}; the lock is a regular non-executable file"]
    new = read_blob(new_entry[2], MAX_LOCK_BYTES)
    if new is None:
        return [f"{LOCK}: more than {MAX_LOCK_BYTES} bytes"]
    if old_entry is None:
        old = LOCK_HEADER + b"\n" + LOCK_FOOTER + b"\n"  # no base lock: the empty canonical lock
    else:
        old = read_blob(old_entry[2], MAX_LOCK_BYTES) if old_entry[:2] == (REGULAR, "blob") else None
        if old is None or not old.endswith(b"\n"):
            raise Refused(f"the base {LOCK} cannot be read")
    body_end = old.rfind(b"\n", 0, len(old) - 1) + 1
    body, footer = old[:body_end], old[body_end:]
    newline = b"\r\n" if footer.endswith(b"\r\n") else b"\n"
    if footer[:-len(newline)] != LOCK_FOOTER or not body.startswith(LOCK_HEADER):
        raise Refused(f"the base {LOCK} has no header or footer line")
    if not new.startswith(body):
        return [f"{LOCK}: byte {first_difference(body, new)}: an existing byte was changed, removed or "
                "reordered; the lock is append-only"]
    tail = len(new) - len(footer)
    if tail < len(body) or not new.endswith(footer):
        offset = len(body) if tail < len(body) else tail + first_difference(footer, new[tail:])
        return [f"{LOCK}: byte {offset}: the footer line is not the base's exact bytes"]
    lines = new[len(body):tail].split(newline)
    offset = len(body)
    for line in lines[:-1]:
        if not ENTRY.fullmatch(line):
            return [f"{LOCK}: byte {offset}: an appended line is not one canonical pin entry"]
        offset += len(line) + len(newline)
    if lines[-1]:
        return [f"{LOCK}: byte {offset}: the appended bytes are not complete lines"]
    if body.count(b"\n") - 1 + len(lines) - 1 > MAX_LOCK_PINS:
        return [f"{LOCK}: more than {MAX_LOCK_PINS} entries"]
    return []


def _pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"duplicate key {key[:64]!r}")
        out[key] = value
    return out


def _refuse_number(text):
    raise ValueError(f"{text[:32]} is not an integer")


def strict_json(text: str):
    return json.loads(text, object_pairs_hook=_pairs, parse_float=_refuse_number, parse_constant=_refuse_number)


def data_problem(name: str, book: str, blob: bytes):
    """Strict UTF-8 JSON objects (a tape: one per line); a manifest's symbol is its directory."""
    try:
        text = blob.decode("utf-8")
    except UnicodeDecodeError:
        return "not UTF-8"
    try:
        if name == "tape.jsonl":
            for number, line in enumerate(text.split("\n"), start=1):
                if line and type(strict_json(line)) is not dict:
                    return f"line {number} is not a JSON object"
            return None
        doc = strict_json(text)
    except (ValueError, RecursionError) as exc:
        return f"not strict JSON ({type(exc).__name__}: {str(exc)[:80]})"
    if type(doc) is not dict:
        return "not a JSON object"
    if name == "manifest.json" and doc.get("symbol") != book:
        return f"manifest symbol {str(doc.get('symbol'))[:40]!r} does not match its directory {book}"
    return None


def touches_library(path: str) -> bool:
    """The library root or anything below it, whatever the letter case or separator."""
    folded = path.replace("\\", "/").lower()
    return folded == LIBRARY_ROOT or folded.startswith(LIBRARY_ROOT + "/")


def library_problems(base: str, head: str) -> list:
    raw = git("diff-tree", "-r", "-z", "--no-abbrev", "--no-renames", base, head)
    tokens = raw.split(b"\0")
    if tokens and tokens[-1] == b"":
        tokens.pop()
    if len(tokens) % 2:
        raise Refused("unexpected git diff-tree output")
    problems = []
    for meta, raw_path in zip(tokens[0::2], tokens[1::2]):
        fields = meta.decode("ascii", "replace").lstrip(":").split(" ")
        if len(fields) != 5:
            raise Refused("unexpected git diff-tree record")
        _old_mode, mode, _old_oid, oid, status = fields
        path = raw_path.decode("utf-8", "surrogateescape")
        if not touches_library(path) or status.startswith("D"):
            continue  # a deletion runs nothing
        if mode != REGULAR:
            problems.append(f"{path}: {MODE_LABEL.get(mode, 'mode ' + mode)}; the library takes regular "
                            "non-executable files only")
            continue
        match = LIBRARY_FILE.fullmatch(path)
        if match is None:
            problems.append(f"{path}: not an approved path ({LIBRARY_ROOT}/<integration>/<book>/"
                            f"{{{', '.join(APPROVED)}}})")
            continue
        limit = APPROVED[match.group(3)]
        blob = read_blob(oid, limit)
        if blob is None:
            problems.append(f"{path}: more than {limit} bytes")
            continue
        problem = data_problem(match.group(3), match.group(2), blob)
        if problem:
            problems.append(f"{path}: {problem}")
    return problems


def main(argv) -> int:
    if len(argv) != 2 or not all(REV.fullmatch(rev) for rev in argv):
        print("pre-install gate: refused, usage: <base sha> <head sha|HEAD>", file=sys.stderr)
        return 2
    base, head = argv
    try:
        problems = lock_problems(base, head) + library_problems(base, head)
    except (Refused, ValueError) as exc:
        print(f"pre-install gate: refused, {exc}", file=sys.stderr)
        return 2
    for problem in problems:
        print(f"pre-install gate: {problem}", file=sys.stderr)
    if problems:
        return 2
    print("pre-install gate: ok")
    return 0


sys.exit(main(sys.argv[1:]))
PRE_INSTALL_GATE_PY
if ! python -I -B "$gate_dir/pre_install_gate.py" "$gate_base" HEAD; then
  echo "pre-install gate: refused before any install (exit 2)" >&2
  exit 2
fi
rm -rf "$gate_dir"
echo "LEAF_T end pre-install $(date +%s%3N) rc=0"
# END PRE-INSTALL GATE

echo "LEAF_T start install $(date +%s%3N)"
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"

# scripts/populate_runner_secrets.py::_ensure_runtime_dir chowns to group
# "leafhft" on any non-Windows host, so a container without that group makes
# shutil.chown raise LookupError, which the loader's deliberately opaque
# except-Exception turns into an unrelated-looking exit 4/3. Windows skips
# this line entirely, which is why it never surfaced there. The production
# runner's systemd units already run under Group=leafhft, so creating the
# group here just matches CI to the real runner instead of skipping or
# weakening those tests.
getent group leafhft >/dev/null || groupadd leafhft
getent group leafhft >/dev/null || { echo "leafhft group missing after groupadd, cannot run secrets-loader tests at full strength" >&2; exit 1; }
echo "LEAF_T end install $(date +%s%3N) rc=0"

# Run the whole suite under xdist. Measured 2026-09-10: 41 to 65s under
# xdist -n 4 against 125 to 324s serial over three runs each, with an
# identical result set both ways. The whole suite runs because it is the
# only safety net on live money. Wall-clock latency budgets (@pytest.mark.bench) are deselected here
# and asserted alone in the serial bench step below.
# Workers follow the container's real CPU limit (cgroup quota, else affinity),
# clamped to 4..16: MEDIUM stays at 4, XLARGE (36 vCPU) runs 16. Measured on
# XLARGE 2026-09-24: 16 workers cut the suite step 664 s -> 373 s vs MEDIUM x4.
# LEAF_HFT_XDIST_WORKERS overrides. Never fails the build: any read error -> 4.
if [ "$CI_SHARD_MODE" = all ] || [ "$CI_SHARD_MODE" = legs0 ]; then
HFT_XDIST_WORKERS="${LEAF_HFT_XDIST_WORKERS:-$(python - <<'LEAF_HFT_XDIST'
import os
try:
    cpus = float(len(os.sched_getaffinity(0)))
except Exception:
    cpus = float(os.cpu_count() or 4)
try:
    quota, period = open("/sys/fs/cgroup/cpu.max").read().split()[:2]
    if quota != "max":
        cpus = min(cpus, int(quota) / int(period))
except Exception:
    pass
print(max(4, min(16, int(cpus))))
LEAF_HFT_XDIST
)}"
case "$HFT_XDIST_WORKERS" in ''|*[!0-9]*) HFT_XDIST_WORKERS=4 ;; esac
echo "xdist workers: $HFT_XDIST_WORKERS"
echo "LEAF_T start xdist $(date +%s%3N)"
# A hung test fails with its name after 300 s instead of running the build to its timeout.
python -m pytest tests/ -q -p no:cacheprovider --timeout=300 --timeout-method=thread -n "$HFT_XDIST_WORKERS" -m 'not bench'
echo "LEAF_T end xdist $(date +%s%3N) rc=0"
else
  echo "xdist and coverage: run on shard 0"
fi

# CI-BENCH: every @pytest.mark.bench latency budget runs here, alone, after the parallel suite. The one
# convention lives in tests/conftest.py: bench skips under xdist; -p no:xdist leaves PYTEST_XDIST_WORKER
# unset so it runs, and under CI=1 the hook never skips and every budget asserts at full strictness
# (the X1 DomainRole contract, cached p99 <= 50 us and re-parse p99 <= 2 ms, also needs this Linux
# runner). Marked today: test_account_risk.py, test_account_risk_breaker.py,
# test_account_risk_mixed_version.py, test_books_observer.py, test_calibration_map.py,
# test_canary.py, test_cli_probe_host.py, test_engine_registry.py, test_exposure_authority.py,
# test_exposure_conformance.py, test_kalshi_decision_record.py, test_kalshi_eval_block.py,
# test_kalshi_request_counter.py, test_loop_lag.py, test_probe_runner.py and test_push_exposure_control.py.
# tests/test_bench_convention.py refuses a hand-rolled xdist skip and an unmarked p99 test anywhere under tests/.
# test_darkhorse_live_lane.py is not a budget test and stays in the parallel suite.
if [ "$CI_SHARD_MODE" = all ] || [ "$CI_SHARD_MODE" = legs1 ]; then
echo "LEAF_T start bench $(date +%s%3N)"
CI=1 python -m pytest tests/ -m bench -q -p no:cacheprovider -p no:xdist
echo "LEAF_T end bench $(date +%s%3N) rc=0"
else
  echo "bench: runs on shard 1"
fi

# Suite coverage guard. This is the point of the file beyond just running
# pytest: fail the build if any tests/test_*.py file on disk was never
# collected by pytest. An orphaned test file that pytest never imports is a
# test that silently does not run, the same class of silent failure this
# gate exists to stop. The repo currently has zero orphans, so this guard
# starts green.
if [ "$CI_SHARD_MODE" = all ] || [ "$CI_SHARD_MODE" = legs0 ]; then
echo "LEAF_T start coverage $(date +%s%3N)"
python - <<'PYEOF'
import pathlib
import subprocess
import sys

on_disk = {
    p.as_posix()
    for p in pathlib.Path("tests").glob("test_*.py")
}

result = subprocess.run(
    [sys.executable, "-m", "pytest", "tests/", "-q", "--collect-only", "-p", "no:cacheprovider"],
    capture_output=True,
    text=True,
    check=True,
)

collected = set()
for line in result.stdout.splitlines():
    line = line.strip()
    if not line.startswith("tests/") and not line.startswith("tests\\"):
        continue
    path = line.split("::", 1)[0]
    collected.add(pathlib.PurePath(path).as_posix())

orphans = sorted(on_disk - collected)
if orphans:
    print("orphaned test files, never collected by pytest:")
    for orphan in orphans:
        print(f"  {orphan}")
    sys.exit(1)

print(f"suite coverage guard: {len(on_disk)} test files on disk, all collected")
PYEOF
echo "LEAF_T end coverage $(date +%s%3N) rc=0"
fi
