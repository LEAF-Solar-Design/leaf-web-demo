"""Generate the leafhft design artboards (Main, MainLight, Terminal) from real run data and the
ops-dashboard design tokens. Output: Main.dc.html, MainLight.dc.html, Terminal.dc.html, canvas.json.

Tokens are lifted from ops-dashboard src/app/globals.css (2026-09-05); series colors were validated
with the dataviz palette validator on both surfaces (#4f86e0 equity, #b8893a buy-and-hold).
"""
from __future__ import annotations

import json
import sqlite3
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from leafhft.ui.reader import list_runs  # noqa: E402

D = json.loads((HERE / "run-233633.json").read_text(encoding="utf-8"))
CT = ZoneInfo("America/Chicago")

DARK = dict(bg="#0c0e12", fg="#e6e8ec", card="#15181e", border="#262b33", muted="#9aa1ac", secondary="#1c2027", accent="#232830",
            sidebar="#0f1216", sidebar_fg="#cdd1d8", sidebar_border="#22272f", sidebar_active="#1c2027", sidebar_active_fg="#f2f4f7",
            destructive="#dc4c48", ring_stroke="#15181e", grid="#262b33", equity="#4f86e0", hold="#b8893a", cash="#9aa1ac",
            good="#3fb950", serious="#e5484d", warn="#d8a23b", tooltip_bg="#1c2027")
LIGHT = dict(bg="#f7f8fa", fg="#0b0d12", card="#ffffff", border="#e2e5ea", muted="#6b7280", secondary="#f1f3f5", accent="#f1f3f5",
             sidebar="#ffffff", sidebar_fg="#3c4149", sidebar_border="#e2e5ea", sidebar_active="#f1f3f5", sidebar_active_fg="#0b0d12",
             destructive="#b3261e", ring_stroke="#ffffff", grid="#e2e5ea", equity="#4f86e0", hold="#b8893a", cash="#6b7280",
             good="#0ca30c", serious="#d03b3b", warn="#b7791f", tooltip_bg="#ffffff")

SANS = "'Geist', system-ui, -apple-system, 'Segoe UI', sans-serif"
MONO = "'Geist Mono', ui-monospace, 'Cascadia Mono', Consolas, monospace"
FONT_LINK = '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&amp;family=Geist+Mono:wght@400;500;600&amp;display=swap">'


def ct(ns: int) -> str:
    return datetime.fromtimestamp(ns / 1e9, tz=CT).strftime("%H:%M:%S")


def icon(name: str, color: str, size: int = 16) -> str:
    paths = {
        "shield": '<path d="M12 3l7 3v5c0 5-3.5 8.5-7 10-3.5-1.5-7-5-7-10V6l7-3z"/><path d="M9 12l2 2 4-4"/>',
        "chevron": '<path d="M6 9l6 6 6-6"/>',
        "activity": '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
        "dot": '<circle cx="12" cy="12" r="4"/>',
        "grid": '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
        "bar": '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        "monitor": '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
        "kill": '<circle cx="12" cy="12" r="9"/><path d="M8 8l8 8M16 8l-8 8"/>',
    }
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="1.75" '
            f'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{paths[name]}</svg>')


def sidebar(t: dict) -> str:
    def item(label: str, active: bool = False, ic: str = "dot") -> str:
        bg = t["sidebar_active"] if active else "transparent"
        fg = t["sidebar_active_fg"] if active else t["sidebar_fg"]
        return (f'<div style="display: flex; align-items: center; gap: 10px; padding: 7px 10px; border-radius: 6px; background: {bg}; '
                f'color: {fg}; font-size: 13px; font-weight: {"500" if active else "400"};">{icon(ic, fg, 15)}<span>{label}</span></div>')

    def group(label: str) -> str:
        return f'<div style="padding: 14px 10px 6px 10px; font-size: 11px; letter-spacing: 0.06em; text-transform: uppercase; color: {t["muted"]};">{label}</div>'

    return (f'<aside style="width: 240px; flex: 0 0 240px; background: {t["sidebar"]}; border-right: 1px solid {t["sidebar_border"]}; '
            f'display: flex; flex-direction: column; padding: 0 12px 16px 12px;">'
            f'<div style="height: 56px; display: flex; align-items: center; padding: 0 6px; font-size: 16px; font-weight: 600; color: {t["fg"]}; border-bottom: 1px solid {t["sidebar_border"]}; margin: 0 -12px 4px -12px; padding-left: 18px;">Ops Dashboard</div>'
            f'{group("Home")}{item("Today", ic="grid")}{item("Attention", ic="activity")}'
            f'{group("Analytics")}{item("Plugin Analytics", ic="bar")}{item("Website Analytics", ic="bar")}{item("Sales Analytics", ic="bar")}{item("GPU Telemetry", ic="monitor")}{item("Model Training", ic="monitor")}{item("leafhft Paper Trading", True, ic="activity")}'
            f'{group("Monitoring")}{item("Mission Control", ic="activity")}{item("Error Monitoring", ic="activity")}'
            f'</aside>')


def chart_svg(t: dict, width: int = 984) -> str:
    e = D["end"]
    x1 = D["x1"]
    ticks = "".join(
        f'<line x1="{D["x0"]}" x2="{x1}" y1="{y}" y2="{y}" stroke="{t["grid"]}" stroke-width="1"/>'
        f'<text x="{D["x0"] + 2}" y="{y - 5}" fill="{t["muted"]}" font-size="11" font-family="{MONO}">{label}</text>'
        for y, label in D["ticks"]
    )
    dots = "".join(
        f'<circle cx="{f["x"]}" cy="{f["y"]}" r="5" fill="{t["good"] if f["side"] == 1 else t["serious"]}" stroke="{t["ring_stroke"]}" stroke-width="2"/>'
        for f in D["fills"]
    )
    sell = next(f for f in D["fills"] if f["side"] == -1)
    tip_x = sell["x"]
    tip_t = ct(D["t0"] + int((D["t1"] - D["t0"]) * (tip_x - D["x0"]) / (x1 - D["x0"])))
    tooltip = (
        f'<line x1="{tip_x}" x2="{tip_x}" y1="8" y2="276" stroke="{t["muted"]}" stroke-width="1" stroke-dasharray="3 3" opacity="0.7"/>'
        f'<g transform="translate({tip_x - 262}, 16)">'
        f'<rect width="250" height="92" rx="8" fill="{t["tooltip_bg"]}" stroke="{t["border"]}"/>'
        f'<text x="12" y="20" fill="{t["muted"]}" font-size="11" font-family="{MONO}">{tip_t}</text>'
        f'<text x="12" y="40" fill="{t["fg"]}" font-size="12" font-family="{MONO}"><tspan fill="{t["equity"]}">&#9632;</tspan> equity  $99.9558</text>'
        f'<text x="12" y="58" fill="{t["fg"]}" font-size="12" font-family="{MONO}"><tspan fill="{t["hold"]}">&#9632;</tspan> hold    $99.9682   <tspan fill="{t["muted"]}">cash $100.0000</tspan></text>'
        f'<text x="12" y="78" fill="{t["serious"]}" font-size="12" font-family="{MONO}">SELL 0.00031 @ 79522.39 · maker</text>'
        f'</g>'
    )
    end_labels = (
        f'<text x="{x1 + 8}" y="{e["eq_y"] + 4}" fill="{t["equity"]}" font-size="11.5" font-family="{MONO}" font-weight="500">equity ${e["equity"]:.3f}</text>'
        f'<text x="{x1 + 8}" y="{e["hold_y"] + 4}" fill="{t["hold"]}" font-size="11.5" font-family="{MONO}" font-weight="500">hold ${e["hold"]:.3f}</text>'
        f'<text x="{x1 + 8}" y="{D["cash_y"] + 4}" fill="{t["cash"]}" font-size="11.5" font-family="{MONO}" font-weight="500">cash ${e["cash"]:.3f}</text>'
    )
    h = round(300 * width / 1040)
    return (
        f'<svg viewBox="0 0 1040 300" width="{width}" height="{h}" preserveAspectRatio="xMinYMin meet" role="img" aria-label="Equity at mid against cash and buy and hold baselines">'
        f'{ticks}'
        f'<line x1="{D["x0"]}" x2="{x1}" y1="{D["cash_y"]}" y2="{D["cash_y"]}" stroke="{t["cash"]}" stroke-width="1.5" stroke-dasharray="5 5"/>'
        f'<path d="{D["hold"]}" fill="none" stroke="{t["hold"]}" stroke-width="1.5" stroke-dasharray="2 3"/>'
        f'<path d="{D["equity"]}" fill="none" stroke="{t["equity"]}" stroke-width="1.75"/>'
        f'{dots}{tooltip}{end_labels}'
        f'<text x="{D["x0"]}" y="296" fill="{t["muted"]}" font-size="11" font-family="{MONO}">{ct(D["t0"])}</text>'
        f'<text x="{x1}" y="296" fill="{t["muted"]}" font-size="11" font-family="{MONO}" text-anchor="end">{ct(D["t1"])}</text>'
        f'</svg>'
    )


def legend(t: dict) -> str:
    def sw(color: str, dash: str, label: str) -> str:
        return (f'<div style="display: flex; align-items: center; gap: 8px; color: {t["muted"]}; font-size: 12px;">'
                f'<svg width="22" height="8" aria-hidden="true"><line x1="0" x2="22" y1="4" y2="4" stroke="{color}" stroke-width="2" stroke-dasharray="{dash}"/></svg>{label}</div>')

    def dot(color: str, label: str) -> str:
        return (f'<div style="display: flex; align-items: center; gap: 8px; color: {t["muted"]}; font-size: 12px;">'
                f'<svg width="12" height="12" aria-hidden="true"><circle cx="6" cy="6" r="4.5" fill="{color}" stroke="{t["card"]}" stroke-width="2"/></svg>{label}</div>')

    return (f'<div style="display: flex; gap: 20px; align-items: center;">{sw(t["equity"], "", "equity at mid")}{sw(t["hold"], "2 3", "buy and hold")}'
            f'{sw(t["cash"], "5 5", "cash")}{dot(t["good"], "buy fill")}{dot(t["serious"], "sell fill")}</div>')


def card(t: dict, inner: str, extra_style: str = "") -> str:
    return (f'<section style="background: {t["card"]}; border: 1px solid {t["border"]}; border-radius: 12px; padding: 20px 24px; '
            f'box-shadow: 0 1px 2px rgba(0,0,0,0.06); display: flex; flex-direction: column; gap: 14px; {extra_style}">{inner}</section>')


def tile(t: dict, label: str, value: str, sub: str, value_color: str | None = None) -> str:
    vc = value_color or t["fg"]
    return (f'<div style="background: {t["card"]}; border: 1px solid {t["border"]}; border-radius: 12px; padding: 14px 18px; display: flex; flex-direction: column; gap: 6px; min-width: 0;">'
            f'<div style="font-size: 12.5px; font-weight: 500; color: {t["muted"]};">{label}</div>'
            f'<div style="font-size: 20px; font-weight: 600; font-family: {MONO}; color: {vc}; letter-spacing: -0.01em; white-space: nowrap;">{value}</div>'
            f'<div style="font-size: 12px; color: {t["muted"]}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{sub}</div></div>')


def pill(t: dict, text: str, color: str, filled: bool = False) -> str:
    bg = color if filled else "transparent"
    fg = t["bg"] if filled else color
    return (f'<span style="display: inline-flex; align-items: center; gap: 6px; border: 1px solid {color}; background: {bg}; color: {fg}; '
            f'border-radius: 999px; padding: 2px 9px; font-size: 11.5px; font-weight: 500; white-space: nowrap;">{text}</span>')


def header(t: dict) -> str:
    r = D["receipt"]
    picker = (f'<div style="display: flex; align-items: center; gap: 10px; height: 36px; padding: 0 12px; border: 1px solid {t["border"]}; '
              f'background: {t["card"]}; border-radius: 8px; color: {t["fg"]}; font-size: 13px; min-width: 420px;">'
              f'<span style="font-family: {MONO}; font-weight: 500;">20260904-233633</span>'
              f'<span style="color: {t["muted"]};">binanceus · BTC-USD · mm · paper</span>'
              f'{pill(t, "stopped · run_seconds elapsed", t["muted"])}'
              f'<span style="margin-left: auto; display: flex;">{icon("chevron", t["muted"], 16)}</span></div>')
    return (f'<div style="display: flex; align-items: flex-end; gap: 20px;">'
            f'<div style="display: flex; flex-direction: column; gap: 4px;"><div style="font-size: 22px; font-weight: 600; letter-spacing: -0.01em; color: {t["fg"]};">leafhft</div>'
            f'<div style="font-size: 13px; color: {t["muted"]};">Paper trading against live feeds. The live gate has never opened.</div></div>'
            f'<div style="margin-left: auto; display: flex; flex-direction: column; align-items: flex-end; gap: 6px;">{picker}'
            f'<div style="font-size: 12px; color: {t["muted"]}; font-family: {MONO};">host WORKSTATION · git {r["git_sha"][:7]} · 13 runs · hot path p50 419 us, p99 7.8 ms</div></div></div>')


def verdict(t: dict) -> str:
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 10px 14px; border: 1px solid {t["border"]}; background: {t["secondary"]}; border-radius: 8px; color: {t["fg"]}; font-size: 13px;">'
            f'{icon("shield", t["warn"], 16)}<span><strong style="font-weight: 600;">Paper only.</strong> Every fill below is simulated against a real feed; this page cannot place an order. '
            f'Report verdict, 2026-09-05: no positive net edge after fees. Fund $0.</span></div>')


def hero(t: dict) -> str:
    r = D["receipt"]
    pnl = r["pnl_usd"]
    pnl_bps = pnl / 100 * 1e4
    color = t["serious"] if pnl < 0 else t["good"]
    sign = "−" if pnl < 0 else "+"
    head = (f'<div style="display: flex; align-items: flex-start; gap: 28px;">'
            f'<div style="display: flex; flex-direction: column; gap: 4px;"><div style="font-size: 12.5px; font-weight: 500; color: {t["muted"]};">Equity at mid</div>'
            f'<div style="display: flex; align-items: baseline; gap: 14px;"><span style="font-size: 34px; font-weight: 600; font-family: {MONO}; letter-spacing: -0.02em; color: {t["fg"]};">${r["equity_end_usd"]:.4f}</span>'
            f'<span style="font-size: 15px; font-family: {MONO}; font-weight: 500; color: {color};">{sign}${abs(pnl):.4f} · {sign}{abs(pnl_bps):.1f} bps</span></div></div>'
            f'<div style="margin-left: auto;">{legend(t)}</div></div>')
    return card(t, head + chart_svg(t))


def kpis(t: dict) -> str:
    r = D["receipt"]
    c = D["counts"]
    q = D["quality"]
    tiles = [
        tile(t, "Liquidation value", f'${r["equity_liquidation_usd"]:.4f}', "sold at bid, net of fees"),
        tile(t, "Cash baseline", "$100.0000", "never traded"),
        tile(t, "Buy and hold", f'${r["baseline_buy_and_hold_usd"]:.4f}', "$100 of BTC at t0"),
        tile(t, "Fees", f'${r["fees_usd"]:.4f}', f'haircut ${r["slip_usd"]:.4f}'),
        tile(t, "Fills", f'{c["fills"]} <span style="font-size: 13px; color: {t["muted"]}; font-weight: 500;">{c["maker_fills"]}m · {c["taker_fills"]}t</span>', f'{c["orders"]} orders · {c["cancels"]} cancels'),
        tile(t, "Feed polls", f'{q["polls"]}', f'{q["poll_lat_mean_ms"]:.0f} ms mean · {q["poll_gaps"]} gaps'),
    ]
    return f'<div style="display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 12px;">{"".join(tiles)}</div>'


def signals(t: dict) -> str:
    def col(title: str, rows: list[tuple[str, str]], note: str = "", last: bool = False, extra: str = "") -> str:
        body = "".join(f'<div style="display: flex; justify-content: space-between; gap: 12px; font-size: 12.5px;"><span style="color: {t["muted"]}; white-space: nowrap;">{k}</span><span style="font-family: {MONO}; color: {t["fg"]}; white-space: nowrap;">{v}</span></div>' for k, v in rows)
        n = f'<div style="font-size: 11.5px; color: {t["muted"]}; margin-top: 2px;">{note}</div>' if note else ""
        border = "" if last else f"border-right: 1px solid {t['border']};"
        return f'<div style="display: flex; flex-direction: column; gap: 8px; padding-right: 20px; {border}"><div style="font-size: 12.5px; font-weight: 500; color: {t["fg"]};">{title}</div>{body}{extra}{n}</div>'

    fg_bar = (f'<div style="height: 6px; border-radius: 3px; background: {t["secondary"]}; position: relative; margin-top: 2px;">'
              f'<div style="position: absolute; left: 0; top: 0; height: 6px; width: 73%; border-radius: 3px; background: {t["warn"]};"></div></div>')
    cols = [
        col("Regime, this run", [("realized vol", "0.18 bps/s"), ("annualized", "9.9%"), ("mid move, 15 min", "−2.9 bps"), ("spread", "0.5 bps · $3.98")]),
        col("Pattern", [("autocorr, 1 s", "−0.06"), ("variance ratio, 10 s", "1.31"), ("mean-rev half-life", "86 s")], "from the recorded quotes, no fit"),
        col("Model, walk-forward", [("horizon", "30 s ahead"), ("OOS hit rate", "not yet run"), ("required edge", "0.23 to 23 bps")], "logistic on book features, time-blocked"),
        col("Sentiment", [("Fear and Greed", "73 · Greed"), ("source", "alternative.me")], "2026-09-05, daily", last=True, extra=fg_bar),
    ]
    head = f'<div style="display: flex; align-items: baseline; gap: 12px;"><div style="font-size: 14px; font-weight: 600; color: {t["fg"]};">Signals</div><div style="font-size: 12px; color: {t["muted"]};">context, not permission to trade</div></div>'
    return card(t, head + f'<div style="display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 20px;">{"".join(cols)}</div>')


def markouts(t: dict) -> str:
    m = D["markouts"]

    def cell(v: float | None) -> str:
        if v is None:
            return f'<td style="padding: 6px 8px; text-align: right; color: {t["muted"]}; font-family: {MONO};">—</td>'
        c = t["serious"] if v < 0 else t["good"]
        return f'<td style="padding: 6px 8px; text-align: right; color: {c}; font-family: {MONO};">{v:+.2f}</td>'

    rows = ""
    for h in ("1s", "5s", "30s"):
        for liq in ("maker", "taker"):
            x = m[h][liq]
            rows += (f'<tr style="border-top: 1px solid {t["border"]};"><td style="padding: 6px 8px; font-family: {MONO};">{h}</td><td style="padding: 6px 8px; color: {t["muted"]};">{liq}</td>'
                     f'<td style="padding: 6px 8px; text-align: right; font-family: {MONO};">{x["n"]}</td>{cell(x["vs_fill_bps"])}{cell(x["vs_mid_bps"])}</tr>')
    th = f'style="padding: 4px 8px; text-align: left; font-weight: 500; color: {t["muted"]}; font-size: 11.5px;"'
    thr = f'style="padding: 4px 8px; text-align: right; font-weight: 500; color: {t["muted"]}; font-size: 11.5px;"'
    table = (f'<table style="width: 100%; border-collapse: collapse; font-size: 12.5px; color: {t["fg"]};"><thead><tr><th {th}>horizon</th><th {th}>liq</th><th {thr}>n</th><th {thr}>vs fill, bps</th><th {thr}>vs mid, bps</th></tr></thead><tbody>{rows}</tbody></table>')
    chips = "".join(pill(t, f"{k} {v}", t["muted"]) for k, v in D["fill_rules"].items() if v)
    head = f'<div style="display: flex; align-items: baseline; gap: 12px;"><div style="font-size: 14px; font-weight: 600; color: {t["fg"]};">Markouts</div><div style="font-size: 12px; color: {t["muted"]};">positive means the market moved our way</div></div>'
    return card(t, head + table + f'<div style="display: flex; gap: 8px; align-items: center;"><span style="font-size: 12px; color: {t["muted"]};">fill rules</span>{chips}</div>')


def fills(t: dict) -> str:
    th = f'style="padding: 4px 8px; text-align: left; font-weight: 500; color: {t["muted"]}; font-size: 11.5px;"'
    thr = f'style="padding: 4px 8px; text-align: right; font-weight: 500; color: {t["muted"]}; font-size: 11.5px;"'
    rows = ""
    for f in sorted(D["fills"], key=lambda f: -f["x"]):
        side = "BUY" if f["side"] == 1 else "SELL"
        c = t["good"] if f["side"] == 1 else t["serious"]
        tt = ct(D["t0"] + int((D["t1"] - D["t0"]) * (f["x"] - D["x0"]) / (D["x1"] - D["x0"])))
        fee = f.get("fee", 0.0099 if f["liq"] == 2 else 0.0)
        rows += (f'<tr style="border-top: 1px solid {t["border"]};"><td style="padding: 6px 8px; font-family: {MONO};">{tt}</td><td style="padding: 6px 8px; color: {c}; font-weight: 500;">{side}</td>'
                 f'<td style="padding: 6px 8px; text-align: right; font-family: {MONO};">{f["px"]:.2f}</td><td style="padding: 6px 8px; text-align: right; font-family: {MONO};">{f["size"]:.6f}</td>'
                 f'<td style="padding: 6px 8px; text-align: right; font-family: {MONO};">{fee:.4f}</td><td style="padding: 6px 8px; color: {t["muted"]};">{"maker" if f["liq"] == 1 else "taker"}</td></tr>')
    table = (f'<table style="width: 100%; border-collapse: collapse; font-size: 12.5px; color: {t["fg"]};"><thead><tr><th {th}>time</th><th {th}>side</th><th {thr}>price</th><th {thr}>size BTC</th><th {thr}>fee</th><th {th}>liq</th></tr></thead><tbody>{rows}</tbody></table>')
    head = f'<div style="display: flex; align-items: baseline; gap: 12px;"><div style="font-size: 14px; font-weight: 600; color: {t["fg"]};">Fills</div><div style="font-size: 12px; color: {t["muted"]};">2 of 2 · the chart&#39;s table view</div></div>'
    return card(t, head + table)


def page(t: dict, layout: str = "main") -> str:
    content_w = 1440 - 240 - 24 - 144
    body = (f'<div style="display: flex; flex-direction: column; gap: 16px; width: {content_w}px;">'
            f'{header(t)}{verdict(t)}{hero(t)}{kpis(t)}{signals(t)}'
            f'<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px;">{markouts(t)}{fills(t)}</div></div>')
    if layout == "terminal":
        body = terminal_body(t)
    return (
        '<!doctype html>\n<html>\n<head>\n  <meta charset="utf-8">\n  <script src="./support.js"></script>\n</head>\n<body>\n<x-dc>\n<helmet>\n'
        f'  {FONT_LINK}\n'
        f'  <style>\n    body {{ margin: 0; font-family: {SANS}; -webkit-font-smoothing: antialiased; }}\n'
        f'    a {{ color: {t["equity"]}; }} a:hover {{ color: {t["fg"]}; }}\n  </style>\n</helmet>\n'
        f'<div style="width: 1440px; height: 1340px; display: flex; background: {t["bg"]}; color: {t["fg"]}; font-family: {SANS}; overflow: hidden;">'
        f'{sidebar(t)}'
        f'<main style="flex: 1 1 auto; padding: 24px 144px 32px 24px; overflow: hidden;">{body}</main>'
        '</div>\n</x-dc>\n</body>\n</html>\n'
    )


def terminal_body(t: dict) -> str:
    runs = [r for r in list_runs(ROOT / "runs") if r.get("has_ledger")][:9]
    rows = ""
    for i, r in enumerate(runs):
        active = r["run_id"].endswith("233633-paper-binanceus-mm")
        bg = t["accent"] if active else "transparent"
        eq = r.get("equity_end_usd")
        pnl = (eq - 100) if eq is not None else None
        pc = t["muted"] if pnl is None else (t["serious"] if pnl < 0 else (t["good"] if pnl > 0 else t["fg"]))
        rows += (f'<div style="display: grid; grid-template-columns: 1fr auto; gap: 4px 10px; padding: 8px 10px; border-radius: 6px; background: {bg}; border-top: 1px solid {t["border"]};">'
                 f'<div style="font-family: {MONO}; font-size: 12px; color: {t["fg"]};">{r["run_id"][9:15]} <span style="color: {t["muted"]};">{(r.get("venue") or "")}/{(r.get("strategy") or "")}</span></div>'
                 f'<div style="font-family: {MONO}; font-size: 12px; color: {pc}; text-align: right;">{"" if eq is None else f"${eq:.3f}"}</div>'
                 f'<div style="font-size: 11px; color: {t["muted"]};">{("LIVE" if r.get("live") else (r.get("stop_reason") or ""))[:28]}</div>'
                 f'<div style="font-size: 11px; color: {t["muted"]}; text-align: right;">{r.get("fills", "")} fills</div></div>')
    rail = (f'<aside style="width: 280px; flex: 0 0 280px; display: flex; flex-direction: column; gap: 0; background: {t["card"]}; border: 1px solid {t["border"]}; border-radius: 12px; overflow: hidden;">'
            f'<div style="padding: 12px 14px; font-size: 12.5px; font-weight: 500; color: {t["muted"]}; display: flex; justify-content: space-between;"><span>Runs</span><span style="font-family: {MONO};">13</span></div>{rows}</aside>')
    content_w = 1440 - 240 - 24 - 144 - 280 - 16
    main = (f'<div style="display: flex; flex-direction: column; gap: 14px; width: {content_w}px;">'
            f'{verdict(t)}{card(t, chart_head_compact(t) + chart_svg(t, 700))}{kpis_compact(t)}'
            f'<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px;">{markouts(t)}{fills(t)}</div></div>')
    return f'<div style="display: flex; gap: 16px; align-items: flex-start;">{rail}{main}</div>'


def chart_head_compact(t: dict) -> str:
    r = D["receipt"]
    pnl = r["pnl_usd"]
    color = t["serious"] if pnl < 0 else t["good"]
    return (f'<div style="display: flex; align-items: baseline; gap: 14px;"><span style="font-size: 12.5px; color: {t["muted"]};">20260904-233633 · binanceus mm</span>'
            f'<span style="font-size: 26px; font-weight: 600; font-family: {MONO}; color: {t["fg"]};">${r["equity_end_usd"]:.4f}</span>'
            f'<span style="font-size: 13px; font-family: {MONO}; color: {color};">{"−" if pnl < 0 else "+"}${abs(pnl):.4f}</span><div style="margin-left: auto;">{legend(t)}</div></div>')


def kpis_compact(t: dict) -> str:
    r = D["receipt"]
    c = D["counts"]
    q = D["quality"]
    items = [("liquidation", f'${r["equity_liquidation_usd"]:.4f}'), ("cash", "$100.0000"), ("buy and hold", f'${r["baseline_buy_and_hold_usd"]:.4f}'),
             ("fees / haircut", f'${r["fees_usd"]:.4f} / ${r["slip_usd"]:.4f}'), ("fills m/t", f'{c["fills"]} · {c["maker_fills"]}/{c["taker_fills"]}'), ("feed", f'{q["polls"]} · {q["poll_lat_mean_ms"]:.0f} ms · {q["poll_gaps"]} gaps')]
    cells = "".join(f'<div style="display: flex; flex-direction: column; gap: 3px; padding: 10px 14px; border-right: 1px solid {t["border"]};"><span style="font-size: 11.5px; color: {t["muted"]};">{k}</span><span style="font-family: {MONO}; font-size: 15px; font-weight: 500; color: {t["fg"]}; white-space: nowrap;">{v}</span></div>' for k, v in items)
    return f'<div style="display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); background: {t["card"]}; border: 1px solid {t["border"]}; border-radius: 12px; overflow: hidden;">{cells}</div>'


def main() -> None:
    (HERE / "Main.dc.html").write_text(page(DARK), encoding="utf-8")
    (HERE / "MainLight.dc.html").write_text(page(LIGHT), encoding="utf-8")
    (HERE / "Terminal.dc.html").write_text(page(DARK, "terminal"), encoding="utf-8")
    canvas = {
        "artboards": [
            {"file": "Main.dc.html", "x": 0, "y": 0, "w": 1440, "h": 1340, "title": "Main · dark (build this)"},
            {"file": "MainLight.dc.html", "x": 1560, "y": 0, "w": 1440, "h": 1340, "title": "Main · light theme"},
            {"file": "Terminal.dc.html", "x": 0, "y": 1500, "w": 1440, "h": 1340, "title": "Alternate · Terminal (left run rail)"},
        ],
        "annotations": [
            {"id": "note-brief", "x": 0, "y": -150, "w": 620, "text": "leafhft Paper Trading page, drawn in the ops-dashboard design system (Geist, its dark and light tokens, 12px cards).\nData is real: run 20260904-233633 (Binance.US, resting maker, haircut 0). Chart hues validated with the dataviz palette checker on both surfaces.\nMain (dark) is what gets built; Terminal is an alternate with a left run rail."},
        ],
        "launch": {"view": "canvas"},
    }
    (HERE / "canvas.json").write_text(json.dumps(canvas, indent=2), encoding="utf-8")
    print("wrote Main.dc.html MainLight.dc.html Terminal.dc.html canvas.json")


if __name__ == "__main__":
    main()
