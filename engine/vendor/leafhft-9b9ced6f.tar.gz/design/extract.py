"""Extract the mockup's real data from a run: equity and buy-and-hold SVG paths, ticks, fills, KPIs.
Output: design/run-<id>.json. Chart box is 1040x300 with a right margin wide enough for end labels."""
from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
run = ROOT / "runs" / (sys.argv[1] if len(sys.argv) > 1 else "20260904-233633-paper-binanceus-mm")
W, H, PL, PR, PT, PB = 1040, 300, 8, 150, 12, 24

c = sqlite3.connect("file:" + str(run / "ledger.sqlite").replace("\\", "/") + "?mode=ro", uri=True)
marks = [(ts, json.loads(b)) for ts, b in c.execute("SELECT ts_ns, body FROM events WHERE kind='mark' ORDER BY rowid")]
fills = [(ts, json.loads(b)) for ts, b in c.execute("SELECT ts_ns, body FROM events WHERE kind='fill' ORDER BY rowid")]
c.close()
rec = json.loads((run / "receipt.json").read_text(encoding="utf-8"))

t0, t1 = marks[0][0], marks[-1][0]
eq = [m["equity_q"] / 1e8 for _, m in marks]
mid = [m["mid_i"] / 1e8 for _, m in marks]
start = 100.0
hold = [start * mm / mid[0] for mm in mid]
ys = eq + hold + [start]
y0, y1 = min(ys), max(ys)
pad = (y1 - y0) * 0.12 or 0.01
y0 -= pad
y1 += pad


def sx(t: int) -> float:
    return PL + (t - t0) / (t1 - t0) * (W - PL - PR)


def sy(y: float) -> float:
    return PT + (1 - (y - y0) / (y1 - y0)) * (H - PT - PB)


def path(vals: list[float]) -> str:
    pts = [(sx(ts), sy(v)) for (ts, _), v in zip(marks, vals)]
    step = max(1, len(pts) // 400)
    pts = pts[::step] + [pts[-1]]
    return "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in pts)


def eq_at(ts: int) -> float:
    return next(m["equity_q"] / 1e8 for t, m in marks if t >= ts)


out = {
    "equity": path(eq),
    "hold": path(hold),
    "cash_y": round(sy(start), 1),
    "x0": PL,
    "x1": W - PR,
    "ticks": [(round(sy(v), 1), f"${v:.3f}") for v in (y0 + pad, (y0 + y1) / 2, y1 - pad)],
    "fills": [{"x": round(sx(ts), 1), "y": round(sy(eq_at(ts)), 1), "t": ts, "side": f["side"], "liq": f["liq"], "px": f["price_i"] / 1e8, "size": f["size_i"] / 1e8, "fee": f["fee_q"] / 1e8} for ts, f in fills],
    "end": {"equity": eq[-1], "hold": hold[-1], "cash": start, "eq_y": round(sy(eq[-1]), 1), "hold_y": round(sy(hold[-1]), 1)},
    "t0": t0,
    "t1": t1,
    "receipt": {k: rec[k] for k in ("equity_end_usd", "equity_liquidation_usd", "pnl_usd", "fees_usd", "slip_usd", "baseline_buy_and_hold_usd", "git_sha", "stop_reason", "started", "ended")},
    "counts": rec["counts"],
    "markouts": rec["markouts"],
    "quality": rec["feed"]["quality"],
    "latency": rec["latency"],
    "fill_rules": rec["fill_rules"],
}
(HERE / f"run-{run.name.split('-')[1]}.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
print("wrote", HERE / f"run-{run.name.split('-')[1]}.json", "marks", len(marks), "fills", len(fills))
