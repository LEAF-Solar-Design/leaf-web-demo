"""Optional, reduction-only execution experiments for verified dashboard members.

Assignment uses a member and engine, never a venue credential or subaccount.
No account identifier is retained in results or emitted as an audit feature.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import re
import sys
import time
from dataclasses import asdict, dataclass
from contextvars import ContextVar
from pathlib import Path

MAX_SPEC_BYTES = 16384
EXPERIMENT_OFF = Path("/var/lib/leafhft/EXPERIMENT_OFF")
_ID = re.compile(r"[a-z0-9-]{1,64}\Z")
_submission_guard = ContextVar("execution_experiment_guard", default=None)


class SubmissionRefused(ValueError):
    pass


class GuardedSendLock:
    """Check delayed tasks after the client's send lock, before journal or HTTP writes."""
    def __init__(self, lock):
        self.lock = lock

    async def __aenter__(self):
        value = await self.lock.__aenter__()
        try:
            check = _submission_guard.get()
            if check is not None:
                refusal = check()
                if refusal:
                    raise SubmissionRefused(refusal)
        except BaseException:
            await self.lock.__aexit__(*sys.exc_info())
            raise
        return value

    async def __aexit__(self, *args):
        return await self.lock.__aexit__(*args)

    def locked(self):
        """Preserve the asyncio.Lock inspection surface used by live-runner guards."""
        return self.lock.locked()


def _hash(*parts):
    return hashlib.sha256(json.dumps(parts, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate experiment key")
        result[key] = value
    return result


def _integer(value, low, high):
    return type(value) is int and low <= value <= high


def _id(value):
    return isinstance(value, str) and _ID.fullmatch(value) is not None


@dataclass(frozen=True)
class Variant:
    id: str
    weight_bps: int
    size_bps_min: int
    size_bps_max: int
    delay_ms_max: int


@dataclass(frozen=True)
class ExperimentSpec:
    enabled: bool
    experiment_id: str
    allocation_salt: str
    eligible_engine_ids: tuple[str, ...]
    deadline_guard_ms: int
    variants: tuple[Variant, ...]
    digest: str


def load_spec(path):
    with Path(path).open("rb") as stream:
        data = stream.read(MAX_SPEC_BYTES + 1)
    if len(data) > MAX_SPEC_BYTES:
        raise ValueError("experiment exceeds 16384 bytes")
    raw = json.loads(data, object_pairs_hook=_pairs)
    keys = {"schema_version", "enabled", "experiment_id", "allocation_salt",
            "eligible_engine_ids", "deadline_guard_ms", "variants"}
    if type(raw) is not dict or set(raw) != keys:
        raise ValueError("invalid experiment keys")
    if type(raw["schema_version"]) is not int or raw["schema_version"] != 1:
        raise ValueError("invalid experiment schema_version")
    if type(raw["enabled"]) is not bool or not _id(raw["experiment_id"]):
        raise ValueError("invalid experiment enabled or id")
    if not isinstance(raw["allocation_salt"], str) or not re.fullmatch(r"[0-9a-f]{64}", raw["allocation_salt"]):
        raise ValueError("invalid experiment allocation_salt")
    engines = raw["eligible_engine_ids"]
    if (type(engines) is not list or not engines or any(not _id(e) for e in engines)
            or len(set(engines)) != len(engines)):
        raise ValueError("invalid experiment eligible_engine_ids")
    if not _integer(raw["deadline_guard_ms"], 0, 86400000):
        raise ValueError("invalid experiment deadline_guard_ms")
    variants = raw["variants"]
    variant_keys = {"id", "weight_bps", "size_bps_min", "size_bps_max", "delay_ms_max"}
    if type(variants) is not list or not variants:
        raise ValueError("invalid experiment variants")
    for v in variants:
        if (type(v) is not dict or set(v) != variant_keys or not _id(v["id"])
                or not _integer(v["weight_bps"], 0, 10000)
                or not _integer(v["size_bps_min"], 1000, 10000)
                or not _integer(v["size_bps_max"], v["size_bps_min"], 10000)
                or not _integer(v["delay_ms_max"], 0, 5)):
            raise ValueError("invalid experiment variant bounds")
    if len({v["id"] for v in variants}) != len(variants) or sum(v["weight_bps"] for v in variants) != 10000:
        raise ValueError("experiment weights must total 10000 with distinct variant ids")
    return ExperimentSpec(raw["enabled"], raw["experiment_id"], raw["allocation_salt"],
                          tuple(engines), raw["deadline_guard_ms"],
                          tuple(Variant(**v) for v in variants), hashlib.sha256(data).hexdigest())


@dataclass(frozen=True)
class Assignment:
    experiment_id: str
    spec_digest: str
    variant: Variant
    cohort_digest: str
    seed: str


def assign(spec, account_id, engine_id):
    """Caller must obtain account_id from load_dashboard_account_identity."""
    seed = _hash(spec.experiment_id, spec.allocation_salt, account_id, engine_id)
    bucket = int(seed, 16) % 10000
    for variant in spec.variants:
        if bucket < variant.weight_bps:
            return Assignment(spec.experiment_id, spec.digest, variant, seed[:16], seed)
        bucket -= variant.weight_bps
    raise ValueError("invalid experiment allocation")


@dataclass
class ExecutionDraw:
    original_count: int
    applied_count: int
    experiment_id: str = ""
    spec_digest: str = ""
    variant: str = ""
    cohort_digest: str = ""
    size_bps: int = 10000
    intended_delay_ms: int = 0
    actual_delay_ms: int = 0
    skip_reason: str = ""
    delay_ms: int = 0

    def audit(self):
        result = asdict(self)
        result.pop("delay_ms")
        return result

    def reason(self, original):
        if not self.experiment_id:
            return original
        # Compact tokens go first: the ticket ledger retains at most 400 chars.
        audit = (f"exp={self.experiment_id} xs={self.spec_digest} xv={self.variant} "
                 f"xc={self.cohort_digest} xo={self.original_count} xa={self.applied_count} "
                 f"xb={self.size_bps} xd={self.intended_delay_ms} xt={self.actual_delay_ms} "
                 f"xr={self.skip_reason or 'none'}")
        tokens = original.split()
        tokens.sort(key=lambda token: not token.startswith("eng="))
        for token in tokens:
            if len(audit) + 1 + len(token) <= 400:
                audit += " " + token
        return audit


class ExecutionExperiment:
    def __init__(self, path="", *, off_path=EXPERIMENT_OFF):
        self.path = Path(path) if path else None
        self.off_path = Path(off_path)
        self.spec = None
        self.last_error = None
        self._stat = None
        self.poll()

    def poll(self):
        if self.path is None:
            return None
        try:
            stat = self.path.stat()
            key = (stat.st_mtime_ns, stat.st_ctime_ns, stat.st_size, stat.st_ino)
            if key == self._stat:
                return self.spec
            self._stat = key
            self.spec = load_spec(self.path)
            self.last_error = None
        except FileNotFoundError:
            self.spec, self._stat, self.last_error = None, None, None
        except (OSError, ValueError, TypeError, RecursionError) as exc:
            # Never retain the previous enabled spec after a malformed hot edit.
            self.spec = None
            error = "invalid execution experiment: " + type(exc).__name__
            if error != self.last_error:
                print(error, file=sys.stderr, flush=True)
            self.last_error = error
        return self.spec

    def off(self):
        try:
            return self.off_path.exists()
        except OSError:
            return True

    def draw(self, requested_count, *, account_id=None, engine_id=None, ticker="",
             cluster_id=0, decision_wall_ns=0, close_time_ms=None, now_ms=None, eligible=True):
        result = ExecutionDraw(requested_count, requested_count)
        spec = self.poll()
        if not eligible:
            result.skip_reason = "ineligible_entry"
        elif self.off():
            result.skip_reason = "experiment_off"
        elif spec is None:
            result.skip_reason = "invalid_spec" if self.last_error else "absent_spec"
        elif not spec.enabled:
            result.skip_reason = "disabled"
        elif not account_id:
            result.skip_reason = "unverified_account"
        elif engine_id not in spec.eligible_engine_ids:
            result.skip_reason = "ineligible_engine"
        elif type(requested_count) is not int or requested_count < 1:
            result.skip_reason = "ineligible_count"
        else:
            assignment = assign(spec, account_id, engine_id)
            variant = assignment.variant
            order_key = (assignment.seed, ticker, cluster_id, decision_wall_ns, requested_count)
            bps = variant.size_bps_min + int(_hash(*order_key, "size"), 16) % (
                variant.size_bps_max - variant.size_bps_min + 1)
            delay = int(_hash(*order_key, "delay"), 16) % (variant.delay_ms_max + 1)
            result = ExecutionDraw(requested_count, max(1, requested_count * bps // 10000),
                                   assignment.experiment_id, assignment.spec_digest, variant.id,
                                   assignment.cohort_digest, bps, delay, delay_ms=delay)
            if delay:
                if close_time_ms is None or now_ms is None:
                    result.delay_ms, result.skip_reason = 0, "missing_deadline"
                elif now_ms + delay >= close_time_ms - spec.deadline_guard_ms:
                    result.delay_ms, result.skip_reason = 0, "deadline_guard"
        return result


async def delayed_entry(draw, *, decisions, ticker, held, row, submit, guard, release):
    """Own one held decision until submission or refusal, without sleeping the feed."""
    started = time.monotonic_ns()
    activated = False

    def check():
        draw.actual_delay_ms = max(0, (time.monotonic_ns() - started) // 1_000_000)
        refusal = guard()
        if refusal:
            draw.skip_reason = refusal
        if row is not None:
            row["execution_experiment"] = draw.audit()
        return refusal

    try:
        await asyncio.sleep(draw.delay_ms / 1000)
        refusal = check()
        if refusal:
            draw.skip_reason = refusal
            if row is not None:
                row["execution_experiment"] = draw.audit()
            decisions.finish_buffered(held, refusal)
            release()
            return
        decisions.activate(held)
        activated = True
        token = _submission_guard.set(check)
        try:
            await submit()
        finally:
            _submission_guard.reset(token)
    except BaseException as exc:
        draw.skip_reason = (str(exc) if isinstance(exc, SubmissionRefused) else
                            "cancelled" if isinstance(exc, asyncio.CancelledError) else "submission_error")
        draw.actual_delay_ms = max(0, (time.monotonic_ns() - started) // 1_000_000)
        if row is not None:
            row["execution_experiment"] = draw.audit()
        if activated and decisions._pending.get(ticker) is row:
            decisions.refuse(ticker, draw.skip_reason)
        elif not activated:
            decisions.finish_buffered(held, draw.skip_reason)
        release()
        if isinstance(exc, SubmissionRefused):
            return
        raise
