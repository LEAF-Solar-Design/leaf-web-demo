"""C12: the runner control rail for the engine lifecycle control kinds (plan D7, v1.4 and C6c).

A dashboard control row of one of KINDS becomes exactly one `python -m leafhft.engine_ops <verb>`
argv and nothing else; this module never writes engine state itself. Checked in this order:

- a value that is not a bounded object, or a field outside its kind's shape, rejects with a note
  naming the field (malformed) before anything runs;
- ADMIN_ONLY kinds (probe, assign, graduate, retire) and a breaker raise refuse a tenant-scoped row
  `admin_only`; any one tenant marker is enough (tenant_scoped, fails closed);
- a risk-increasing row (probe, assign, graduate, or a breaker raise above the value the registry
  holds now) without an approval rejects `approval_required` before any argv is built. Its approval
  id is passed through and engine_ops resolves it in the root-only store (/var/lib/leafhft-approvals,
  C6c), so an engine_ops exit 2 is a rejected row carrying that named refusal, never retried; a
  probe row that also claims an account must name the approval's account (`account_mismatch`);
- a kind whose verb engine_ops's own parser does not register rejects `verb_unavailable` (read from
  engine_ops.build_parser() at first use, never a list kept here);
- engine.halt always applies: unsigned, never admin-only, never approval- or exposure-gated;
- engine.retire accepts the optional `reason` the dashboard sends (any value) and drops it: its argv
  never carries --reason, so engine_ops records its RETIRE_DEFAULT_REASON (`operator_retired`);
- the verb and the `status <engine> --json` read after it share one deadline, each stream is spooled
  to a temp file and read back to at most MAX_OUTPUT_BYTES, and the ack carries
  result {lifecycle_state, snapshot_digest} (D8 G) from that status read.

request_id is the row id, so a replayed row completes through engine_ops and never duplicates. That
is what makes an unknown outcome safe to retry: a killed engine_ops (timeout), a row deadline spent
before it started, or its `ops_busy` lock refusal leaves the row PENDING (apply() returns state
"pending", settle() counts it in the caller's persisted replay state) and the next sweep reruns the
same request id. A non-halt row is rejected after MAX_REPLAYS such replays (`timeout_unreconciled`,
with one alert, when any attempt was killed mid-run); halt is never rejected for them and alerts
once at MAX_REPLAYS.

A row whose engine_ops call was ever killed mid-run (reconciling()) is in RECONCILIATION: its
transaction may be half landed on the host, so no pre-dispatch refusal settles it. Expiry is
enforced before the first dispatch only; a reconciling row reruns the same request id whatever its
expires_at says, and any other refusal before engine_ops runs leaves it pending ("reconcile"). Only
engine_ops's own answer, or the MAX_REPLAYS limit (`timeout_unreconciled` plus the alert), settles it.
The replay counter is keyed by (row id, kind, requested_at) (replay_key), so a reused row id never
inherits another row's counter.

A reconciling request is UNRESOLVED until it settles, and its counter lives on whatever the batch
holds: the argv of its first timed-out dispatch (request id included) is captured beside the
counter (the "requests" table), and when the current batch carries its row malformed or not at all
(orphans()), reconcile_unresolved() replays that captured argv, never one rebuilt from a re-read
row, and alerts `reconcile_row_unreadable` once. Garbage collection (prune_replay_state) never drops
it; only settlement does. A counter whose row never reached engine_ops (a spent deadline, ops_busy)
has nothing half landed and goes with its row.

An unresolved request HOLDS its row id (held_key()) until it settles. A carried row with that id is
never validated or rebuilt, whatever its shape (a value of None, a changed approval): reconcile_row()
replays the captured argv. A carried row under another (kind, requested_at) is refused
`row_identity_changed` (alerted once) and never replaces or forgets the held request; only a settled
or never-ran key is replaced. The push hook runs this held-id check BEFORE its kind branch, so a row
re-read under a legacy kind (`min_k`, say) is held the same way: never dispatched through the legacy
applier, never carried as the held request's row, and the held request keeps replaying. The replay
table never evicts an unresolved entry: at MAX_REPLAY_ROWS the oldest never-ran entry goes, and a
table holding only unresolved entries refuses the new request `replay_table_full` with an alert.
That capacity refusal happens AFTER the dispatch that timed out: the refused request (the 257th)
executed once and is not tracked, so nothing replays it; its ack and alert name the recovery,
rerunning it by the same --request-id. Same-id replay is not resume-only: when the first
process was killed BEFORE engine_ops recorded the request, the replay creates a fresh transaction
(engine_ops's idempotency has nothing to resume), which is the intended first-dispatch-only expiry
semantics; the row's own expiry never reaches engine_ops, so a replayed probe can open after its
expires_at. A queued alert the rail failed to deliver is retried by
drain_alerts() on every sweep, at most ALERT_DRAIN_PER_SWEEP per sweep, each alert backing off
exponentially; the backoff persists with the replay state.

owner-domain-control v1 (the `domain` verbs). domain.pause is a stop, like halt: it never asks the
exposure authority (engine_ops judges its own domain), any failed or unknown apply stays PENDING and
is retried and reconciled from its captured snapshot (or, with none, rebuilt from its validated live
row), it is exempt from MAX_REPLAYS, and it settles applied only on a record (the verb's own stdout,
else one `domain show`) that reads `paused` under the row's request_id. domain.resume increases risk
and is NEVER replayed and NEVER pending: it needs a positive authority read, expires
RESUME_MAX_AGE_S after requested_at (or RESUME_MAX_SKEW_S ahead of the clock) without running, and
runs once. Exit 0 with this request's `resumed` record is applied; a named refusal in
RESUME_REFUSALS is rejected under that name; any other outcome runs one `domain show` under its own
DOMAIN_READBACK_TIMEOUT_S and settles applied (resumed under this request_id), rejected
`resume_not_applied` (still paused at expect_generation), or rejected `outcome_unknown` with the
TIMEOUT_UNRECONCILED alert. The presence strings live only in 0600 files in a private 0700 temp dir
for the one call; nothing about a resume is persisted.

The replay table holds at most MAX_REPLAY_ROWS entries of every kind; the last STOP_RESERVED_ROWS
are reserved for halt and pause. A stop the table cannot take stays pending untracked (it reruns from
its live row) with one REPLAY_TABLE_FULL alert; it is never rejected for capacity.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import time
import uuid
from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

PROBE, ASSIGN, RELEASE, HALT = "engine.probe", "engine.assign", "engine.release", "engine.halt"
GRADUATE, RETIRE, BREAKER = "engine.graduate", "engine.retire", "risk.breaker"
DOMAIN_PAUSE, DOMAIN_RESUME = "domain.pause", "domain.resume"
DOMAIN_KINDS = frozenset({DOMAIN_PAUSE, DOMAIN_RESUME})
STOP_KINDS = frozenset({HALT, DOMAIN_PAUSE})  # risk-reducing: never capped by MAX_REPLAYS, slots reserved
KINDS = frozenset({PROBE, ASSIGN, RELEASE, HALT, GRADUATE, RETIRE, BREAKER}) | DOMAIN_KINDS
ADMIN_ONLY = frozenset({PROBE, ASSIGN, GRADUATE, RETIRE})  # plus a risk.breaker raise
APPROVAL_KINDS = frozenset({PROBE, ASSIGN, GRADUATE})  # risk.breaker needs one only when it raises
VERB_PATHS = {PROBE: ("probe",), ASSIGN: ("assign",), RELEASE: ("release",), HALT: ("halt",),
              GRADUATE: ("graduate",), RETIRE: ("retire",), BREAKER: ("breaker", "set"),
              DOMAIN_PAUSE: ("domain", "pause"), DOMAIN_RESUME: ("domain", "resume")}

ENGINE_OPS_MODULE = "leafhft.engine_ops"
REGISTRY_DIR = "/var/lib/leafhft/engine-registry"  # engine_ops.DEFAULT_REGISTRY_DIR: the one the verb reads
APPROVALS_DIR = "/var/lib/leafhft-approvals"  # engine_ops.DEFAULT_APPROVALS_DIR: root-only (C6c)
TENANT_ENV = "LEAFHFT_TENANT_ID"  # a tenant push process: every row it applies is tenant-scoped
LANE_ENV = "LEAFHFT_ACCOUNT_LANE_ID"  # an account-lane push process is a tenant process too
TENANT_ORIGIN_PREFIX = "mobile-device:"  # named for the record; every non-operator origin is tenant
DEFAULT_BUDGET_S = 20.0
MAX_REPLAYS = 3  # outcome-unknown reruns of one request id before a non-halt row is rejected
MAX_REPLAY_ROWS = 256  # hard bound on the persisted replay table, every kind (the caller also prunes)
STOP_RESERVED_ROWS = 64  # of those, slots only a halt or a pause may take
EVICT_BATCH = 32  # never-ran entries one capacity pass evicts, so later inserts skip the pass
MAX_REPLAY_COUNT = 1_000_000  # a halt's unbounded retries saturate here, the table never grows
RETRY_TIMEOUT, RETRY_BUSY, RETRY_DEADLINE = "timeout", "ops_busy", "deadline"
RETRY_RECONCILE = "reconcile"  # a reconciling row refused before engine_ops ran: stays pending
TIMEOUT_UNRECONCILED = "timeout_unreconciled"
MAX_REQUESTED_AT_KEY = 64  # a longer requested_at enters the replay key as its sha256 prefix
RECONCILE_ROW_UNREADABLE = "reconcile_row_unreadable"  # an unresolved request's row is malformed or gone
ROW_IDENTITY_CHANGED = "row_identity_changed"  # a held row id re-read under another kind or requested_at
REPLAY_TABLE_FULL = "replay_table_full"  # MAX_REPLAY_ROWS unresolved entries: a new one is refused, never evicted
MAX_ARGV_ITEMS, MAX_ARGV_ITEM = 16, 1024  # bound on one captured argv (a probe builds at most 12 items)
ALERT_SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "leafhft_alert.py"
ALERT_KEY_PREFIX = "leafhft-control-row-"  # + the row id: one dedupe key per row
MAX_ALERT_PENDING, MAX_ALERT_SEEN = 64, 256
MAX_ALERT_DELIVERIES = 10  # leafhft_alert.MAX_MESSAGES: evaluate() sends at most this many per call
ALERT_DRAIN_PER_SWEEP = 4  # bound on drain_alerts() deliveries per sweep
ALERT_BACKOFF_BASE_S, ALERT_BACKOFF_MAX_S = 60.0, 3600.0  # a failed alert waits base * 2^(n-1), capped
alert_notify: Callable[[str, str], int] | None = None  # evaluate()'s notify seam; None is its rail
alert_clock: Callable[[], float] = time.time  # the alert backoff's clock seam (epoch seconds)
MAX_VALUE_BYTES = 4096
MAX_ASSERTION_BYTES, MAX_PLAN_BYTES = 8 * 1024, 16 * 1024
MAX_DOMAIN_VALUE_BYTES = 6 * (MAX_ASSERTION_BYTES + MAX_PLAN_BYTES) + MAX_VALUE_BYTES
MAX_DOMAIN_SNAPSHOT_BYTES = 1024  # one persisted pause snapshot (ids, domain, reason: about 300 bytes)
RESUME_MAX_AGE_S, RESUME_MAX_SKEW_S = 600, 60  # a resume runs only inside [requested_at - skew, + age]
RESUME_REFUSALS = frozenset({"generation_stale", "not_paused", "presence_invalid", "domain_mismatch",
                             "record_unreadable"})  # engine_ops cmd_domain refusals raised before any write
RESUME_NOT_APPLIED, OUTCOME_UNKNOWN = "resume_not_applied", "outcome_unknown"
DOMAIN_READBACK_TIMEOUT_S = 10.0  # its own bound: a resume killed at the deadline has spent the row's
MAX_OUTPUT_BYTES = 256 * 1024  # per stream, per call
NOTE_MAX = 2048
MAX_SYMBOLS = 64
HALT_DEFAULT_REASON = "operator_halt"  # a free-text phone reason is not an engine_ops reason code

_ENGINE_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,31}")  # engine_manifest.ENGINE_ID_RE
_APPROVAL_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")  # engine_ops._FILE_ID
_REASON = re.compile(r"[a-z][a-z0-9_]{0,63}")  # engine_ops._REASON
_DOMAIN = re.compile(r"[a-z0-9][a-z0-9:-]{0,63}")
_ACCOUNT_ID = re.compile(r"[A-Za-z0-9][\x21-\x7e]{0,159}")  # printable ASCII, no space, never an option
_LIFECYCLE_STATE = re.compile(r"[a-z_]{1,32}")
_MIN_PCT, _MAX_PCT = 1, 100  # engine_registry.MIN_BREAKER_PCT, MAX_BREAKER_PCT
_MIN_WINDOW_DAYS, _MAX_WINDOW_DAYS = 1, 90  # engine_ops probe --window-days
_EMPTY_RESULT = {"lifecycle_state": None, "snapshot_digest": None}


class Rejected(ValueError):
    """A row refused before engine_ops ran; str() is the ack note."""


def scope_accounts(row: dict[str, Any]) -> list[Any]:
    """Every account the row claims as its scope: a `scope_account` field and an account scope's
    account_id (raw, unvalidated: the caller only compares them)."""
    accounts, scope = [], row.get("scope")
    if row.get("scope_account") is not None:
        accounts.append(row["scope_account"])
    if isinstance(scope, dict) and scope.get("kind") == "account":
        accounts.append(scope.get("account_id"))
    return accounts


def _tenant_marked(row: dict[str, Any]) -> bool:
    """Every tenant marker but a scope account. Fails closed: any origin but absent, operator or
    admin (a `mobile-device:` origin included), any tenant id, any scope other than global or a
    well-formed account scope (so `scope="tenant"` and a tenant scope object count), or a tenant or
    account-lane push process."""
    origin, scope = row.get("origin"), row.get("scope")
    if not (origin is None or origin == "operator" or origin == "admin"):
        return True
    if row.get("tenant_id") is not None or os.environ.get(TENANT_ENV) or os.environ.get(LANE_ENV):
        return True
    if scope is None or scope == "global":
        return False
    if isinstance(scope, dict):
        return not (scope == {"kind": "global"}
                    or (scope.get("kind") == "account" and set(scope) == {"kind", "account_id"}))
    return True


def tenant_scoped(row: dict[str, Any], probe_account: str | None = None) -> bool:
    """True when ANY tenant marker says so: _tenant_marked, or a scope account that is not
    `probe_account` (the probe approval's account; None, the default, matches no account)."""
    return _tenant_marked(row) or any(probe_account is None or account != probe_account
                                      for account in scope_accounts(row))


def read_approval_account(approval_id: str) -> str | None:
    """The `account` the root-only approval store holds for `approval_id`, read the way engine_ops
    reads it (store chain checked, the file opened without following a symlink, bounded to
    MAX_APPROVAL_BYTES); None when absent or malformed. Raises when the store is unreadable."""
    from . import approve_presence, engine_ops

    store = Path(APPROVALS_DIR)
    approve_presence.check_store_chain(store)
    engine_ops._guard_dirs(store)
    data = engine_ops._read_bounded(store / f"{approval_id}.json", engine_ops.MAX_APPROVAL_BYTES)
    if data is None:
        return None
    doc = json.loads(data.decode("utf-8"))
    account = doc.get("account") if isinstance(doc, dict) and doc.get("approval_id") == approval_id else None
    return account if type(account) is str else None


def parser_verbs() -> frozenset[tuple[str, ...]]:
    """Every verb path engine_ops's own parser registers (('halt',), ('breaker', 'set'), ...), read
    from engine_ops.build_parser() once, at first use; raises when the parser cannot be built."""
    global _parser_verbs
    if _parser_verbs is None:
        from . import engine_ops

        paths: set[tuple[str, ...]] = set()

        def walk(parser: argparse.ArgumentParser, prefix: tuple[str, ...]) -> None:
            for action in parser._actions:
                if isinstance(action, argparse._SubParsersAction):
                    for name, sub in action.choices.items():
                        paths.add(prefix + (name,))
                        walk(sub, prefix + (name,))

        walk(engine_ops.build_parser(), ())
        _parser_verbs = frozenset(paths)
    return _parser_verbs


_parser_verbs: frozenset[tuple[str, ...]] | None = None


def verb_available(kind: str) -> bool:
    """Whether engine_ops's parser registers `kind`'s verb. An uninspectable parser fails closed for
    every kind but halt, which always goes to engine_ops (it judges its own argv)."""
    try:
        return VERB_PATHS[kind] in parser_verbs()
    except Exception:
        return kind == HALT


def registry_breaker_pct(scope: str, target: str) -> int | None:
    """The breaker percentage the registry holds now for `scope`/`target`; None when there is no
    registry, no such account, or no assignment (the caller then treats the row as a raise)."""
    from . import engine_registry as er

    registry = er.RegistryStore(REGISTRY_DIR).load()
    if registry is None:
        return None
    if scope == "account":
        return registry.effective_pct(target)[0] if target in registry.accounts else None
    assignment = registry.assignments.get(target)
    return None if assignment is None else registry.effective_pct(assignment["account_id"], target)[0]


# ---------------------------------------------------------------- validation (pure, no argv)

def _fields(value: dict[str, Any], kind: str, required: tuple[str, ...], optional: tuple[str, ...]) -> None:
    for key in required:
        if key not in value:
            raise Rejected(f"{key}: {kind} requires {', '.join(required)}")
    extra = sorted(str(key) for key in value if key not in required and key not in optional)
    if extra:
        raise Rejected(f"value: unknown field {extra[0][:64]}")


def _engine_id(raw: Any, field: str = "engine_id") -> str:
    if type(raw) is not str or not _ENGINE_ID.fullmatch(raw):
        raise Rejected(f"{field}: invalid engine id")
    return raw


def _account_id(raw: Any, field: str) -> str:
    if type(raw) is not str or not _ACCOUNT_ID.fullmatch(raw):
        raise Rejected(f"{field}: invalid account id")
    return raw


def _symbols(raw: Any) -> list[str]:
    if type(raw) is not list or not 1 <= len(raw) <= MAX_SYMBOLS or any(type(item) is not str for item in raw):
        raise Rejected(f"symbols: expected 1 to {MAX_SYMBOLS} symbols")
    from .engine_registry import normalize_symbols
    try:
        return normalize_symbols(raw)
    except ValueError:
        raise Rejected("symbols: unknown, duplicate or empty symbols") from None


def _approval(raw: Any) -> str | None:
    if raw is None or raw == "":
        return None
    if type(raw) is not str or not _APPROVAL_ID.fullmatch(raw):
        raise Rejected("approval: invalid approval id")
    return raw


def _bool(value: dict[str, Any], key: str) -> bool:
    raw = value.get(key, False)
    if type(raw) is not bool:
        raise Rejected(f"{key}: expected bool")
    return raw


def _utc(raw: Any, field: str) -> datetime:
    if type(raw) is not str or not 0 < len(raw) <= 64:
        raise Rejected(f"{field}: expected an ISO 8601 UTC time")
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        raise Rejected(f"{field}: expected an ISO 8601 UTC time") from None
    if parsed.tzinfo is None:
        raise Rejected(f"{field}: expected an ISO 8601 UTC time")
    return parsed.astimezone(timezone.utc)


def _require_approval(request: dict[str, Any], why: str) -> None:
    if request["approval"] is None:
        raise Rejected(f"approval_required: {why}"[:NOTE_MAX])


def _admin_only(kind: str) -> Rejected:
    return Rejected(f"admin_only: {kind} is refused for a tenant-scoped row")


def _bind_probe_account(row: dict[str, Any], value: dict[str, Any], request: dict[str, Any],
                        tenant: bool | None, approval_account: Callable[[str], str | None] | None) -> None:
    """A probe's account is the approval's. A scope account marker that is not that account makes
    the row tenant-scoped (admin_only), and an account_id the row or its value claims must equal it
    (account_mismatch). The store is read only when the row claims an account; an unreadable store
    fails closed."""
    scoped = scope_accounts(row) if tenant is None else []
    claims = [_account_id(claim, "account_id") for claim in (row.get("account_id"), value.get("account_id"))
              if claim is not None]
    if not scoped and not claims:
        return
    try:
        approved = (approval_account or read_approval_account)(request["approval"])
    except Exception:
        approved = None
    if type(approved) is not str:
        approved = None
    if tenant_scoped(row, approved) if tenant is None else tenant:
        raise _admin_only(PROBE)
    for claim in claims:
        if approved is None:
            raise Rejected(f"account_mismatch: approval {request['approval']} names no readable account")
        if claim != approved:
            raise Rejected(f"account_mismatch: account {claim} is not approval {request['approval']}'s "
                           f"account {approved}"[:NOTE_MAX])
    request["account_id"] = approved


def _uuid(raw: Any, field: str) -> str:
    if type(raw) is not str or len(raw) != 36:
        raise Rejected(f"{field}: expected a UUID")
    try:
        if str(uuid.UUID(raw)) != raw.lower():
            raise ValueError
    except ValueError:
        raise Rejected(f"{field}: expected a UUID") from None
    return raw


def _domain_value(kind: str, value: dict[str, Any]) -> dict[str, Any]:
    from .push import _control_exposure_domain

    fields = ("domain", "member_key", "request_id", "requested_by")
    fields += ("reason",) if kind == DOMAIN_PAUSE else ("expect_generation", "presence")
    _fields(value, kind, fields, ())
    domain = value["domain"]
    if type(domain) is not str or not _DOMAIN.fullmatch(domain) or domain != _control_exposure_domain():
        raise Rejected("domain_mismatch: invalid or foreign execution domain")
    if value["member_key"] != "owner":
        raise Rejected("domain_member_mismatch: expected owner")
    _uuid(value["request_id"], "request_id")
    who = value["requested_by"]
    if type(who) is not str or not who.startswith("device:"):
        raise Rejected("requested_by: expected device:<uuid>")
    _uuid(who[7:], "requested_by")
    if kind == DOMAIN_PAUSE:
        if type(value["reason"]) is not str or not _REASON.fullmatch(value["reason"]):
            raise Rejected("reason: invalid reason code")
    else:
        generation, presence = value["expect_generation"], value["presence"]
        if type(generation) is not int or generation < 0:
            raise Rejected("expect_generation: expected a non-negative integer")
        if type(presence) is not dict:
            raise Rejected("presence: expected an object")
        _fields(presence, kind, ("assertion", "plan"), ())
        for key, limit in (("assertion", MAX_ASSERTION_BYTES), ("plan", MAX_PLAN_BYTES)):
            raw = presence[key]
            try:
                valid = type(raw) is str and len(raw) <= limit and len(raw.encode("utf-8")) <= limit
            except UnicodeError:
                valid = False
            if not valid:
                raise Rejected(f"presence.{key}: expected a string within {limit} bytes")
    return {key: dict(value[key]) if key == "presence" else value[key] for key in fields}


def _unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    doc: dict[str, Any] = {}
    for key, value in pairs:
        if key in doc:
            raise ValueError("duplicate key")
        doc[key] = value
    return doc


def validate(row: dict[str, Any], *, now: datetime | None = None,
             current_pct: Callable[[str, str], int | None] | None = None,
             tenant: bool | None = None,
             approval_account: Callable[[str], str | None] | None = None,
             check_expiry: bool = True) -> dict[str, Any]:
    """The row as a request, or Rejected with the ack note. Builds no argv; the only I/O is the
    breaker's current-value read (`current_pct`, default registry_breaker_pct), and any failure of
    that read counts as a raise, so it needs an approval (fails closed), and a probe's approval
    account read (`approval_account`, default read_approval_account) when the row claims an
    account. `tenant` overrides the row's own tenant markers when not None. `check_expiry` False
    (a reconciling row only) still parses a probe's expires_at but never refuses it as past."""
    rid, kind, value = row.get("id"), row.get("kind"), row.get("value")
    if type(rid) is not int or rid < 0:
        raise Rejected("id: expected a non-negative integer row id")
    if kind not in KINDS:
        raise Rejected("kind: not a lifecycle control")
    # A probe's own scope account is judged against its approval's account, after the approval parses.
    if kind in ADMIN_ONLY and (tenant if tenant is not None
                               else _tenant_marked(row) if kind == PROBE else tenant_scoped(row)):
        raise _admin_only(kind)
    if kind in DOMAIN_KINDS and type(value) is str:
        if len(value) > MAX_DOMAIN_VALUE_BYTES:
            raise Rejected("value: domain control too large")
        try:
            value = json.loads(value, object_pairs_hook=_unique_pairs, parse_constant=_no_constant)
        except (ValueError, RecursionError):
            raise Rejected("value: invalid domain control JSON") from None
    if not isinstance(value, dict):
        raise Rejected("value: expected an object")
    try:
        size = len(json.dumps(value, default=str).encode("utf-8"))
    except (ValueError, TypeError, RecursionError):
        raise Rejected("value: not serializable") from None
    limit = MAX_DOMAIN_VALUE_BYTES if kind in DOMAIN_KINDS else MAX_VALUE_BYTES
    if size > limit:
        raise Rejected(f"value: over {limit} bytes")
    request: dict[str, Any] = {"id": rid, "kind": kind, "approval": None,
                               "risk_increasing": kind in APPROVAL_KINDS or kind == DOMAIN_RESUME}

    if kind in DOMAIN_KINDS:
        if kind == DOMAIN_RESUME and check_expiry:
            _check_resume_age(row.get("requested_at"), now)
        request.update(_domain_value(kind, value))
        return request

    if kind == HALT:  # always applies: only the engine id is judged, the reason falls back to a code
        reason = value.get("reason")
        request.update(engine_id=_engine_id(value.get("engine_id")),
                       reason=reason if type(reason) is str and _REASON.fullmatch(reason) else HALT_DEFAULT_REASON)
        return request
    if kind == PROBE:
        _fields(value, kind, ("engine_id", "symbols", "expires_at"), ("approval", "bind", "window_days", "account_id"))
        request.update(engine_id=_engine_id(value["engine_id"]), symbols=_symbols(value["symbols"]),
                       bind=_bool(value, "bind"), approval=_approval(value.get("approval")))
        expires_at = _utc(value["expires_at"], "expires_at")
        if check_expiry and expires_at <= (now or datetime.now(timezone.utc)):
            raise Rejected("expires_at: the probe request has expired")
        window = value.get("window_days")
        if window is not None and (type(window) is not int or not _MIN_WINDOW_DAYS <= window <= _MAX_WINDOW_DAYS):
            raise Rejected(f"window_days: expected {_MIN_WINDOW_DAYS} to {_MAX_WINDOW_DAYS}")
        request["window_days"] = window
        _require_approval(request, f"{kind} {request['engine_id']} needs an approval")
        _bind_probe_account(row, value, request, tenant, approval_account)
    elif kind == ASSIGN:
        _fields(value, kind, ("engine_id", "account_id", "symbols"), ("approval",))
        request.update(engine_id=_engine_id(value["engine_id"]), account_id=_account_id(value["account_id"], "account_id"),
                       symbols=_symbols(value["symbols"]), approval=_approval(value.get("approval")))
        _require_approval(request, f"{kind} {request['engine_id']} needs an approval")
    elif kind == RELEASE:
        _fields(value, kind, ("engine_id",), ("restore_bindings",))
        request.update(engine_id=_engine_id(value["engine_id"]), restore_bindings=_bool(value, "restore_bindings"))
    elif kind == GRADUATE:
        _fields(value, kind, ("engine_id",), ("approval",))
        request.update(engine_id=_engine_id(value["engine_id"]), approval=_approval(value.get("approval")))
        _require_approval(request, f"{kind} {request['engine_id']} needs an approval")
    elif kind == RETIRE:  # like halt, the dashboard's optional reason is accepted and never judged or forwarded
        _fields(value, kind, ("engine_id",), ("reason",))
        request["engine_id"] = _engine_id(value["engine_id"])
    else:  # BREAKER
        _fields(value, kind, ("scope", "id", "pct"), ("approval",))
        scope, pct = value["scope"], value["pct"]
        if scope not in ("account", "engine"):
            raise Rejected("scope: expected account or engine")
        target = _engine_id(value["id"], "id") if scope == "engine" else _account_id(value["id"], "id")
        if type(pct) is not int or not _MIN_PCT <= pct <= _MAX_PCT:
            raise Rejected(f"pct: expected an integer {_MIN_PCT} to {_MAX_PCT}")
        request.update(scope=scope, target=target, pct=pct, approval=_approval(value.get("approval")),
                       engine_id=target if scope == "engine" else None)
        try:
            current = (current_pct or registry_breaker_pct)(scope, target)
        except Exception:
            current = None
        if type(current) is not int:
            current = None
        request["risk_increasing"] = current is None or pct > current
        if request["risk_increasing"] and (tenant_scoped(row) if tenant is None else tenant):
            raise Rejected(f"admin_only: {kind} raise is refused for a tenant-scoped row")
        if request["risk_increasing"]:
            _require_approval(request, f"raising {scope} {target} breaker to {pct}% from "
                                       f"{'an unreadable value' if current is None else f'{current}%'} needs an approval")
    return request


# ---------------------------------------------------------------- argv (the only commands this runs)

def argv(request: dict[str, Any], *, presence_files: tuple[str, str] | None = None) -> list[str]:
    """The engine_ops argument vector for a validated request (after `python -m leafhft.engine_ops`)."""
    kind, engine, rid = request["kind"], request.get("engine_id"), str(request["id"])
    if kind in DOMAIN_KINDS:
        args = ["domain", "pause" if kind == DOMAIN_PAUSE else "resume", "--domain", request["domain"],
                "--member-key", "owner"]
        args += (["--reason", request["reason"]] if kind == DOMAIN_PAUSE else
                 ["--expect-generation", str(request["expect_generation"])])
        args += ["--request-id", request["request_id"], "--requested-by", request["requested_by"]]
        if kind == DOMAIN_RESUME:
            if presence_files is None:
                raise Rejected("presence: private files required")
            args += ["--presence-assertion-file", presence_files[0], "--presence-plan-file", presence_files[1]]
        return args
    if kind == PROBE:
        args = ["probe", engine, "--symbols", ",".join(request["symbols"]), "--approval", request["approval"],
                "--request-id", rid]
        if request["bind"]:
            args.append("--bind")
        if request["window_days"] is not None:
            args += ["--window-days", str(request["window_days"])]
        return args
    if kind == ASSIGN:
        return ["assign", engine, "--account", request["account_id"], "--symbols", ",".join(request["symbols"]),
                "--approval", request["approval"], "--request-id", rid]
    if kind == RELEASE:
        return ["release", engine, "--request-id", rid] + (["--restore-bindings"] if request["restore_bindings"] else [])
    if kind == HALT:
        return ["halt", engine, "--reason", request["reason"], "--request-id", rid]
    if kind == GRADUATE:
        return ["graduate", engine, "--approval", request["approval"], "--request-id", rid]
    if kind == RETIRE:
        return ["retire", engine, "--request-id", rid]
    args = ["breaker", "set", "--scope", request["scope"], "--id", request["target"], "--pct", str(request["pct"])]
    if request["approval"] is not None:
        args += ["--approval", request["approval"]]
    return args + ["--request-id", rid]


def argv_for(row: dict[str, Any], **kwargs: Any) -> list[str]:
    """validate() then argv(): the golden seam."""
    return argv(validate(row, **kwargs))


# ---------------------------------------------------------------- execution

@contextmanager
def _presence_files(request: dict[str, Any]):
    """owner-domain-control v1: presence travels only in private, short-lived files."""
    with ExitStack() as cleanup:
        paths = []
        if request["kind"] == DOMAIN_RESUME:
            directory = cleanup.enter_context(tempfile.TemporaryDirectory(prefix="leafhft-presence-"))
            os.chmod(directory, 0o700)
            for key in ("assertion", "plan"):
                with tempfile.NamedTemporaryFile(mode="wb", delete=False, dir=directory) as stream:
                    path = Path(stream.name)
                    cleanup.callback(path.unlink, missing_ok=True)
                    os.chmod(path, 0o600)
                    stream.write(request["presence"][key].encode("utf-8"))
                paths.append(str(path))
        yield tuple(paths) if paths else None


def _check_resume_age(requested_at: Any, now: datetime | None = None) -> None:
    """A resume older than RESUME_MAX_AGE_S, or more than RESUME_MAX_SKEW_S in the future, never runs."""
    age = ((now or datetime.now(timezone.utc)) - _utc(requested_at, "requested_at")).total_seconds()
    if not -RESUME_MAX_SKEW_S <= age <= RESUME_MAX_AGE_S:
        raise Rejected("resume_expired")


def _pause_snapshot(request: dict[str, Any]) -> dict[str, Any]:
    """The pause row as persisted for reconciliation: its id, kind and validated value (no secrets)."""
    return {"id": request["id"], "kind": DOMAIN_PAUSE,
            "value": {key: request[key] for key in ("domain", "member_key", "request_id", "requested_by", "reason")}}


_DOMAIN_STATES = frozenset({"paused", "resumed", "absent"})


def _domain_record(output: str) -> dict[str, Any] | None:
    """The one JSON document engine_ops `domain pause|resume|show` prints on stdout (ops.emit: the
    pause record, or {"state":"absent"} from show), else None. Fails closed: bounded, strict JSON (no
    duplicate keys, no NaN), a known state, and for a record an integer generation and a string
    request_id."""
    if len(output) > MAX_OUTPUT_BYTES:
        return None
    try:
        doc = json.loads(output, object_pairs_hook=_unique_pairs, parse_constant=_no_constant)
    except (ValueError, RecursionError):
        return None
    if type(doc) is not dict or type(doc.get("state")) is not str or doc["state"] not in _DOMAIN_STATES:
        return None
    if doc["state"] != "absent":
        generation, request_id = doc.get("generation"), doc.get("request_id")
        if type(generation) is not int or generation < 0 or type(request_id) is not str:
            return None
    return doc


def _domain_settled(record: dict[str, Any] | None, request: dict[str, Any], state: str) -> bool:
    return record is not None and record["state"] == state and record["request_id"] == request["request_id"]


def _show_domain(domain: str, timeout: float, cwd: str,
                 runner: Callable[..., tuple[int, str, str]]) -> dict[str, Any] | None:
    code, out, _ = runner(_command(["domain", "show", "--domain", domain]), timeout, cwd)
    return _domain_record(out) if code == 0 else None


def _domain_applied(rid: Any, record: dict[str, Any]) -> dict[str, Any]:
    return {"id": rid, "state": "applied", "note": f"generation={record['generation']}",
            "result": dict(_EMPTY_RESULT)}


def _apply_pause(request: dict[str, Any], *, cwd: str, remaining: Callable[[], float],
                 runner: Callable[..., tuple[int, str, str]]) -> dict[str, Any]:
    """A stop, like halt: applied on a `paused` record under this request_id (the verb's stdout, else
    one `domain show` inside the row deadline); every other outcome is pending, never rejected.
    Once engine_ops started it is pending "timeout" with the snapshot settle() captures."""
    rid, snapshot, started = request["id"], _pause_snapshot(request), False
    try:
        args = argv(request)
        left = remaining()
        started = True
        code, out, err = runner(_command(args), left, cwd)
        if code != 0:
            note = (_refusal_note(out, err) if code == 2 else
                    f"apply failed: exit {code}: {' '.join((err or out)[-300:].split())}")
            return {**_pending(rid, RETRY_TIMEOUT, f"domain pause pending: {note}"), "domain_request": snapshot}
        record = _domain_record(out)
        if not _domain_settled(record, request, "paused"):
            record = _show_domain(request["domain"], remaining(), cwd, runner)
        if _domain_settled(record, request, "paused"):
            return _domain_applied(rid, record)
        return {**_pending(rid, RETRY_TIMEOUT, "domain pause outcome unknown: no paused record for this request"),
                "domain_request": snapshot}
    except Exception as exc:
        if started:
            return {**_pending(rid, RETRY_TIMEOUT, f"domain pause outcome unknown: {type(exc).__name__}"),
                    "domain_request": snapshot}
        if isinstance(exc, subprocess.TimeoutExpired):
            return _pending(rid, RETRY_DEADLINE, "domain pause deferred: the row deadline was spent before engine_ops started")
        return _pending(rid, RETRY_RECONCILE, f"domain pause deferred: {type(exc).__name__}")


def _apply_resume(request: dict[str, Any], *, cwd: str, remaining: Callable[[], float],
                  runner: Callable[..., tuple[int, str, str]]) -> dict[str, Any]:
    """Risk-increasing, run at most once and always acked (never pending, never replayed): a
    refused authority read rejects before anything runs; exit 0 with this request's `resumed` record
    is applied; a RESUME_REFUSALS refusal rejects under its name; anything else goes to
    _resume_readback."""
    from .push import _control_domain_refusal

    rid = request["id"]
    refusal = _control_domain_refusal(DOMAIN_RESUME)
    if refusal is not None:
        return _rejected(rid, refusal)
    started = False
    try:
        with _presence_files(request) as files:
            args = argv(request, presence_files=files)
            left = remaining()
            started = True
            code, out, err = runner(_command(args), left, cwd)
        if code == 0:
            record = _domain_record(out)
            if _domain_settled(record, request, "resumed"):
                return _domain_applied(rid, record)
            cause = "exit 0 without this request's resumed record"
        else:
            name = _refusal_code(out, err)
            if name in RESUME_REFUSALS:
                note = _refusal_note(out, err)
                return _rejected(rid, note[len("refused: "):] if note.startswith("refused: ") else name)
            cause = f"exit {code}" + (f" ({name})" if name else "")
    except Exception as exc:
        if not started:
            return _rejected(rid, f"resume_not_started: {type(exc).__name__}")
        cause = type(exc).__name__  # TimeoutExpired: killed at the deadline, possibly after its write
    return _resume_readback(request, cause, cwd=cwd, runner=runner)


def _resume_readback(request: dict[str, Any], cause: str, *, cwd: str,
                     runner: Callable[..., tuple[int, str, str]]) -> dict[str, Any]:
    """One bounded `domain show` after a resume whose outcome is unknown: resumed under this
    request_id is applied; paused at expect_generation proves it never wrote (rejected
    resume_not_applied); anything else is a final `outcome_unknown` ack carrying the
    TIMEOUT_UNRECONCILED alert, which settle() raises."""
    rid = request["id"]
    try:
        record = _show_domain(request["domain"], DOMAIN_READBACK_TIMEOUT_S, cwd, runner)
    except Exception as exc:
        record, cause = None, f"{cause}; readback {type(exc).__name__}"
    if _domain_settled(record, request, "resumed"):
        return _domain_applied(rid, record)
    if record is not None and record["state"] == "paused" and record["generation"] == request["expect_generation"]:
        return _rejected(rid, f"{RESUME_NOT_APPLIED}: engine_ops {cause}; domain show reads paused at "
                              f"generation {record['generation']}")
    seen = ("unreadable" if record is None else
            record["state"] + ("" if record["state"] == "absent" else f" at generation {record['generation']}"))
    note = (f"{OUTCOME_UNKNOWN}: {TIMEOUT_UNRECONCILED}: resume request {request['request_id']} may be half "
            f"applied (engine_ops {cause}; domain show {seen}); run engine_ops domain show --domain {request['domain']}")
    alert = (f"Engine control row {rid} ({DOMAIN_RESUME}) {TIMEOUT_UNRECONCILED}: the outcome of engine_ops domain "
             f"resume request {request['request_id']} is unknown ({cause}; domain show {seen}); it may be half "
             f"applied and {request['domain']} may be trading. It is never replayed: run engine_ops domain show "
             f"--domain {request['domain']} on the runner.")
    return {**_rejected(rid, note), "alert": alert}


def _head(stream: Any) -> str:
    stream.seek(0)
    return stream.read(MAX_OUTPUT_BYTES).decode("utf-8", errors="replace")


def run_bounded(command: list[str], timeout: float, cwd: str) -> tuple[int, str, str]:
    """One engine_ops call: stdin closed, killed at `timeout` (subprocess.run kills the child and
    raises TimeoutExpired), each stream spooled to a temp file and read back to MAX_OUTPUT_BYTES, so a
    runaway writer never costs memory. The one subprocess seam for tests."""
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        proc = subprocess.run(command, cwd=cwd, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                              timeout=timeout, check=False)
        return proc.returncode, _head(out), _head(err)


def _command(args: list[str]) -> list[str]:
    return [sys.executable, "-m", ENGINE_OPS_MODULE, *args]


def _rejected(rid: Any, note: str) -> dict[str, Any]:
    return {"id": rid, "state": "rejected", "note": note[:NOTE_MAX]}


def _pending(rid: Any, retry: str, note: str) -> dict[str, Any]:
    """Not an ack: the outcome is unknown or the row never ran, and the same request id reruns."""
    return {"id": rid, "state": "pending", "retry": retry, "note": note[:NOTE_MAX]}


def _refusal_note(out: str, err: str) -> str:
    """engine_ops's named refusal (`refused: <code>: <detail>`), else its stripped output."""
    for line in (err + "\n" + out).splitlines():
        if line.startswith("refused: "):
            return line.strip()[:NOTE_MAX]
    return (err + out).strip()[:NOTE_MAX] or "refused"


def _refusal_code(out: str, err: str) -> str | None:
    """The code of engine_ops's refusal: its `refused: <code>` stderr line (Ops.refuse and main), or
    the `code` of a `{"ok": false, ...}` JSON line under --json."""
    for line in (err + "\n" + out).splitlines():
        if line.startswith("refused: "):
            return line[len("refused: "):].split(":", 1)[0].strip() or None
        if line.startswith("{") and '"ok": false' in line:
            try:
                doc = json.loads(line)
            except ValueError:
                continue
            if isinstance(doc, dict) and type(doc.get("code")) is str:
                return doc["code"]
    return None


def _applied_note(out: str) -> str:
    return "\n".join(line for line in out.splitlines() if line.startswith("hot: "))[:NOTE_MAX]


def _no_constant(token: str) -> Any:
    raise ValueError(f"non-finite number {token}")


def status_result(text: str) -> dict[str, Any]:
    """D8 G {lifecycle_state, snapshot_digest} from one `engine_ops status <engine> --json` document:
    the state is lifecycle.state, the digest is sha256 over the document's canonical JSON (sorted
    keys, compact). Anything unparseable yields nulls, never a guess."""
    try:
        doc = json.loads(text, parse_constant=_no_constant)
    except (ValueError, RecursionError):
        return dict(_EMPTY_RESULT)
    if not isinstance(doc, dict):
        return dict(_EMPTY_RESULT)
    lifecycle = doc.get("lifecycle")
    state = lifecycle.get("state") if isinstance(lifecycle, dict) else None
    if type(state) is not str or not _LIFECYCLE_STATE.fullmatch(state):
        state = None
    canonical = json.dumps(doc, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return {"lifecycle_state": state, "snapshot_digest": hashlib.sha256(canonical).hexdigest()}


def _remaining(budget: Callable[[], float] | None) -> Callable[[], float]:
    """One deadline taken from `budget`'s first reading (DEFAULT_BUDGET_S without one): the returned
    callable gives the seconds left, never more than `budget` says now, and raises TimeoutExpired
    once they are spent. The first reading itself may raise TimeoutExpired."""
    total = DEFAULT_BUDGET_S if budget is None else float(budget())
    deadline = time.monotonic() + total

    def remaining() -> float:
        left = deadline - time.monotonic()
        if budget is not None:
            left = min(left, float(budget()))
        if left <= 0:
            raise subprocess.TimeoutExpired([], total)
        return left

    return remaining


def apply(row: dict[str, Any], *, cwd: str, budget: Callable[[], float] | None = None,
          exposure_refusal: Callable[[], str | None] | None = None,
          current_pct: Callable[[str, str], int | None] | None = None,
          approval_account: Callable[[str], str | None] | None = None,
          now: datetime | None = None, run: Callable[..., tuple[int, str, str]] | None = None,
          reconcile: bool = False) -> dict[str, Any]:
    """One lifecycle row to one ack, or to a state "pending" outcome that is not an ack (settle()
    decides); never raises. `budget` is the row's remaining seconds (it may raise TimeoutExpired
    once spent); the verb and the status read share one deadline taken from its first reading. A
    risk-increasing row asks `exposure_refusal` first and a non-None answer rejects it; halt,
    release, retire and a breaker lowering never ask. Pending: a budget spent before engine_ops
    starts (deadline), engine_ops killed at the deadline (timeout: it may have written part of its
    transaction), or engine_ops's `ops_busy` lock refusal (nothing written). `reconcile` (the
    caller's reconciling() for this row) skips the expiry check, so the same request id reruns
    and engine_ops's idempotency completes or refuses it, and turns every other refusal or
    failure before engine_ops answers into pending "reconcile": a half-landed transaction is
    never settled by this side's own refusal."""
    rid = row.get("id") if isinstance(row, dict) else None
    runner = run or run_bounded
    started = False
    try:
        remaining = _remaining(budget)
        try:
            request = validate(row, now=now, current_pct=current_pct, approval_account=approval_account,
                               check_expiry=not reconcile)
            # A pause reaches engine_ops even when its parser cannot be inspected, like halt.
            if request["kind"] != DOMAIN_PAUSE and not verb_available(request["kind"]):
                raise Rejected(f"verb_unavailable: engine_ops has no {' '.join(VERB_PATHS[request['kind']])} verb")
            if request["kind"] == DOMAIN_PAUSE:
                return _apply_pause(request, cwd=cwd, remaining=remaining, runner=runner)
            if request["kind"] == DOMAIN_RESUME:
                return _apply_resume(request, cwd=cwd, remaining=remaining, runner=runner)
            if request["risk_increasing"] and exposure_refusal is not None:
                refusal = exposure_refusal()
                if refusal is not None:
                    raise Rejected(refusal)
            args = argv(request)
            command = _command(args)
        except Rejected as exc:
            if reconcile:
                return _pending(rid, RETRY_RECONCILE, f"reconcile deferred: {exc}")
            return _rejected(rid, str(exc))
        left = remaining()
        started = True
        code, out, err = runner(command, left, cwd)
    except subprocess.TimeoutExpired:
        if started:  # the argv rides the outcome so settle() can capture the request's identity
            return {**_pending(rid, RETRY_TIMEOUT, "apply outcome unknown: engine_ops timed out"), "argv": list(args)}
        if isinstance(row, dict) and row.get("kind") == DOMAIN_RESUME:  # a resume is never left pending
            return _rejected(rid, "resume_not_started: the row deadline was spent before engine_ops started")
        return _pending(rid, RETRY_DEADLINE, "apply deferred: the row deadline was spent before engine_ops started")
    except Exception as exc:
        if reconcile:
            return _pending(rid, RETRY_RECONCILE, f"reconcile deferred: {type(exc).__name__}: {exc}")
        return _rejected(rid, f"apply failed: {type(exc).__name__}: {exc}")
    return _answer(rid, code, out, err, request.get("engine_id"),
                   lambda engine: runner(_command(["status", engine, "--json"]), remaining(), cwd))


def _answer(rid: Any, code: int, out: str, err: str, engine_id: str | None,
            status: Callable[[str], tuple[int, str, str]]) -> dict[str, Any]:
    """engine_ops's answer to one dispatch as an outcome: exit 2 is its named refusal (ops_busy
    stays pending), another non-zero exit a rejected row, 0 an applied ack whose result is read
    by `status(engine_id)` after the verb (an unreadable status leaves the result null)."""
    if code == 2:
        if _refusal_code(out, err) == RETRY_BUSY:
            return _pending(rid, RETRY_BUSY, _refusal_note(out, err))
        return _rejected(rid, _refusal_note(out, err))
    if code != 0:
        tail = " ".join((err or out)[-300:].split())
        return _rejected(rid, f"apply failed: exit {code}: {tail}")
    result = dict(_EMPTY_RESULT)
    if engine_id is not None:
        try:
            status_code, status_out, _ = status(engine_id)
            if status_code == 0:
                result = status_result(status_out)
        except Exception:  # the verb applied; an unreadable status leaves the result null
            pass
    return {"id": rid, "state": "applied", "note": _applied_note(out), "result": result}


# ---------------------------------------------------------------- replay state and alerts

def _count(raw: Any) -> int | None:
    return raw if type(raw) is int and 0 <= raw <= MAX_REPLAY_COUNT else None


def replay_key(row: Any) -> str | None:
    """The replay counter's key, `<row id>|<kind>|<requested_at>`, so a reused row id with another
    kind or request time starts fresh; None for a row without a non-negative integer id. An
    unknown kind enters as `?`, a requested_at over MAX_REQUESTED_AT_KEY characters (or not a
    string) as its sha256 prefix (or empty), so the key stays bounded."""
    rid = row.get("id") if isinstance(row, dict) else None
    if type(rid) is not int or rid < 0:
        return None
    kind, at = row.get("kind"), row.get("requested_at")
    if type(at) is not str:
        at = ""
    elif len(at) > MAX_REQUESTED_AT_KEY:
        at = "sha256:" + hashlib.sha256(at.encode("utf-8", errors="replace")).hexdigest()[:32]
    return f"{rid}|{kind if kind in KINDS else '?'}|{at}"


def _replay_key_id(key: str) -> int | None:
    """The row id of a well-formed replay_key(), else None."""
    parts = key.split("|", 2)
    if (len(parts) != 3 or not (parts[0].isascii() and parts[0].isdigit()) or len(parts[0]) > 20
            or not (parts[1] in KINDS or parts[1] == "?") or len(parts[2]) > MAX_REQUESTED_AT_KEY):
        return None
    return int(parts[0])


def _dispatch_argv(raw: Any, key: str) -> list[str] | None:
    """`raw` as the captured engine_ops argv of the request under replay `key`: a bounded list of
    strings that opens with the key's kind's verb and carries `--request-id <the key's row id>`;
    else None (fails closed: an argv that is not this request's is never replayed)."""
    rid, parts = _replay_key_id(key), key.split("|", 2)
    path = VERB_PATHS.get(parts[1]) if rid is not None else None
    if (path is None or type(raw) is not list or not len(path) < len(raw) <= MAX_ARGV_ITEMS
            or any(type(item) is not str or not 0 < len(item) <= MAX_ARGV_ITEM for item in raw)
            or tuple(raw[:len(path)]) != path):
        return None
    if not any(raw[i] == "--request-id" and raw[i + 1] == str(rid) for i in range(len(raw) - 1)):
        return None
    return list(raw)


def _argv_engine(args: list[str]) -> str | None:
    """The engine a captured argv acts on (its status is read after it applies), else None."""
    if args[0] != "breaker":
        return args[1]
    pairs = dict(zip(args[2::2], args[3::2]))
    return pairs.get("--id") if pairs.get("--scope") == "engine" else None


def _alert_state(state: dict[str, Any]) -> dict[str, Any]:
    alert = state.setdefault("alert", {})
    alert.setdefault("pending", {})
    alert.setdefault("seen", [])
    alert.setdefault("retry", {})
    return alert


def load_replay_state(doc: Any) -> dict[str, Any]:
    """The applier's persisted replay state, validated and bounded: {"rows": {replay_key: {replays,
    timeouts, alerted}}, "requests": {replay_key: the argv of its first timed-out dispatch} (only
    for a key in rows), "alert": leafhft_alert.evaluate() state (pending, seen) plus each failed
    alert's backoff (retry: {key: {attempts, next_at}})}. Anything malformed is dropped entry by
    entry, never trusted."""
    rows: dict[str, Any] = {}
    ordinary, ordinary_cap = 0, _ordinary_cap()
    raw_rows = doc.get("rows") if isinstance(doc, dict) else None
    for key, entry in raw_rows.items() if isinstance(raw_rows, dict) else ():
        if len(rows) >= MAX_REPLAY_ROWS:
            break
        if (isinstance(key, str) and _replay_key_id(key) is not None and isinstance(entry, dict)
                and _count(entry.get("replays")) is not None and _count(entry.get("timeouts")) is not None
                and type(entry.get("alerted")) is bool):
            kind = _key_kind(key)
            if kind == DOMAIN_RESUME:  # a resume is never replayed, so never tracked
                continue
            if kind not in STOP_KINDS:
                if ordinary >= ordinary_cap:  # the reserved slots stay free for stops
                    continue
                ordinary += 1
            rows[key] = {"replays": entry["replays"], "timeouts": entry["timeouts"], "alerted": entry["alerted"]}
    raw_requests = doc.get("requests") if isinstance(doc, dict) else None
    requests: dict[str, list[str]] = {}
    for key in rows if isinstance(raw_requests, dict) else ():  # bounded by the rows cap
        args = _dispatch_argv(raw_requests.get(key), key)
        if args is not None:
            requests[key] = args
    domains: dict[str, Any] = {}
    raw_domains = doc.get("domains") if isinstance(doc, dict) else None
    for key in rows if isinstance(raw_domains, dict) else ():
        captured = raw_domains.get(key)
        try:
            if (type(captured) is dict and set(captured) == {"id", "kind", "value"}
                    and captured["id"] == _replay_key_id(key) and captured["kind"] == _key_kind(key) == DOMAIN_PAUSE
                    and len(json.dumps(captured).encode("utf-8")) <= MAX_DOMAIN_SNAPSHOT_BYTES):
                validate(captured, check_expiry=False)
                domains[key] = captured
        except (Rejected, ValueError, TypeError, RecursionError):
            pass
    # A pause that cannot be restored must be rebuilt from the live row on the next sweep.
    for key in list(rows):
        if _key_kind(key) == DOMAIN_PAUSE and key not in domains:
            rows.pop(key)
            requests.pop(key, None)
    raw_alert = doc.get("alert") if isinstance(doc, dict) else None
    alert: dict[str, Any] = {"pending": {}, "seen": [], "retry": {}}
    if isinstance(raw_alert, dict):
        pending, seen, retry = raw_alert.get("pending"), raw_alert.get("seen"), raw_alert.get("retry")
        if isinstance(pending, dict):
            alert["pending"] = {key: message[:1000] for key, message in list(pending.items())[:MAX_ALERT_PENDING]
                                if isinstance(key, str) and len(key) <= 128 and isinstance(message, str)}
        if isinstance(seen, list):
            alert["seen"] = [key for key in seen[-MAX_ALERT_SEEN:] if isinstance(key, str) and len(key) <= 128]
        for key in alert["pending"] if isinstance(retry, dict) else ():  # bounded by the pending cap
            entry = retry.get(key)
            if (isinstance(entry, dict) and _count(entry.get("attempts")) is not None
                    and type(entry.get("next_at")) in (int, float) and math.isfinite(entry["next_at"])):
                alert["retry"][key] = {"attempts": entry["attempts"], "next_at": float(entry["next_at"])}
    state = {"rows": rows, "requests": requests, "alert": alert}
    if domains:
        state["domains"] = domains
    return state


def _forget(state: dict[str, Any], key: str) -> None:
    """Settle `key`: its counter and its captured argv go together."""
    state.setdefault("rows", {}).pop(key, None)
    state.setdefault("requests", {}).pop(key, None)
    state.get("domains", {}).pop(key, None)


def _unresolved(entry: Any) -> bool:
    return isinstance(entry, dict) and bool(entry.get("timeouts"))


def _key_kind(key: str) -> str:
    """The kind field of a well-formed replay_key()."""
    return key.split("|", 2)[1]


def _ordinary_cap() -> int:
    """Entries the kinds other than halt and pause may hold: the table less the stops' reserve."""
    return max(0, MAX_REPLAY_ROWS - STOP_RESERVED_ROWS)


def _make_room(state: dict[str, Any], kind: Any) -> bool:
    """Whether one NEW replay entry of `kind` fits the hard cap (MAX_REPLAY_ROWS in all, at most
    _ordinary_cap() of them for kinds other than halt and pause), evicting never-ran entries to make
    room. O(1) below the ordinary cap; at it one pass bounded by MAX_REPLAY_ROWS evicts up to
    EVICT_BATCH of the oldest never-ran entries the new kind may displace (an ordinary request never
    displaces a stop; a stop displaces ordinary entries first), so the inserts after it take the
    O(1) path again. An unresolved entry is never evicted. False when no room can be made."""
    rows, cap = state.setdefault("rows", {}), _ordinary_cap()
    if len(rows) < cap:
        return True
    stop = kind in STOP_KINDS
    ordinary = [key for key in rows if _key_kind(key) not in STOP_KINDS]
    count = len(ordinary)
    if len(rows) < MAX_REPLAY_ROWS and (stop or count < cap):
        return True
    victims = [key for key in ordinary if not _unresolved(rows[key])]
    if stop:
        victims += [key for key in rows if _key_kind(key) in STOP_KINDS and not _unresolved(rows[key])]
    for key in victims[:EVICT_BATCH]:
        count -= _key_kind(key) not in STOP_KINDS
        _forget(state, key)
    return len(rows) < MAX_REPLAY_ROWS and (stop or count < cap)


def prune_replay_state(state: dict[str, Any], pending_ids: set[int]) -> bool:
    """Drop the replay entries of rows the dashboard no longer lists well formed as pending, except
    an unresolved request's (a timeout counted, not settled): only settlement removes that one, so
    a malformed or vanished re-read never abandons a possibly half-landed transaction. True if any
    went."""
    rows = state.setdefault("rows", {})
    stale = [key for key, entry in rows.items() if _replay_key_id(key) not in pending_ids and not _unresolved(entry)]
    for key in stale:
        _forget(state, key)
    return bool(stale)


def orphans(state: dict[str, Any], carried_ids: set[int]) -> list[tuple[str, int]]:
    """(replay key, row id) of every unresolved request whose row id the current batch does not
    carry well formed (`carried_ids`): the row arrived malformed or not at all. Oldest first;
    reconcile_unresolved() replays each one from its captured argv."""
    return [(key, rid) for key, entry in state.get("rows", {}).items()
            if _unresolved(entry) and (rid := _replay_key_id(key)) is not None and rid not in carried_ids]


def reconciling(row: Any, state: dict[str, Any]) -> bool:
    """Whether `row` is in reconciliation: an engine_ops call for its request id was killed mid-run
    (a timeout counted under its replay_key), so its transaction may be half landed. apply()'s
    `reconcile`. A spent deadline or an ops_busy refusal never ran the transaction, so it does not
    count, and expiry still holds for such a row."""
    key = replay_key(row)
    entry = state.get("rows", {}).get(key) if key is not None else None
    return isinstance(entry, dict) and bool(entry.get("timeouts"))


def held_key(row: Any, state: dict[str, Any]) -> str | None:
    """The unresolved request (a timeout counted, not settled) that holds `row`'s row id, whatever
    the row's kind or requested_at, else None. While one holds the id the row is never validated or
    dispatched: reconcile_row() replays the held request's captured argv. Bounded by MAX_REPLAY_ROWS."""
    rid = row.get("id") if isinstance(row, dict) else None
    if type(rid) is not int or rid < 0:
        return None
    return next((key for key, entry in state.get("rows", {}).items()
                 if _unresolved(entry) and _replay_key_id(key) == rid), None)


_alert_module: Any = None


def _load_alert_module() -> Any:
    """scripts/leafhft_alert.py, loaded once from this checkout (scripts/ is not a package)."""
    global _alert_module
    if _alert_module is None:
        spec = importlib.util.spec_from_file_location("_leafhft_alert_rail", ALERT_SCRIPT)
        if spec is None or spec.loader is None:
            raise ImportError(f"cannot load {ALERT_SCRIPT}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _alert_module = module
    return _alert_module


def deliver_alerts(state: dict[str, Any], keys: list[str] | None = None) -> bool:
    """Hand the queued alerts (`keys`, default every pending one; at most MAX_ALERT_DELIVERIES) to
    leafhft_alert.evaluate() with an empty snapshot: its delivery loop sends each through its notify
    rail (`alert_notify` when set) and moves the delivered ones to `seen`. A failed one stays
    pending and its retry entry {attempts, next_at} backs off ALERT_BACKOFF_BASE_S doubling to
    ALERT_BACKOFF_MAX_S (drain_alerts honours it). True when any delivery was attempted; never
    raises."""
    alert = _alert_state(state)
    pending = alert["pending"]
    batch = [key for key in (list(pending) if keys is None else keys) if key in pending][:MAX_ALERT_DELIVERIES]
    if not batch:
        return False
    failed = set(batch)
    try:
        module = _load_alert_module()
        scratch = {"pending": {key: pending[key] for key in batch}, "seen": list(alert["seen"])}
        if alert_notify is None:
            module.evaluate({}, scratch)
        else:
            module.evaluate({}, scratch, notify=alert_notify)
        failed = {key for key in batch if key in scratch["pending"]}
        alert["seen"] = list(scratch["seen"])[-MAX_ALERT_SEEN:]
    except Exception as exc:
        print(f"engine controls: alert delivery failed: {type(exc).__name__}", flush=True)
    now = alert_clock()
    for key in batch:
        if key in failed:
            attempts = min(alert["retry"].get(key, {}).get("attempts", 0) + 1, MAX_REPLAY_COUNT)
            delay = min(ALERT_BACKOFF_BASE_S * 2 ** min(attempts - 1, 16), ALERT_BACKOFF_MAX_S)
            alert["retry"][key] = {"attempts": attempts, "next_at": float(now + delay)}
        else:
            pending.pop(key, None)
            alert["retry"].pop(key, None)
    return True


def drain_alerts(state: dict[str, Any]) -> bool:
    """The applier's alert retry, run on EVERY sweep whatever the batch holds: at most
    ALERT_DRAIN_PER_SWEEP queued alerts whose backoff has passed (a never-attempted one is due at
    once), oldest first. True when any delivery was attempted; never raises."""
    alert = _alert_state(state)
    now = alert_clock()
    due = [key for key in alert["pending"]
           if alert["retry"].get(key, {}).get("next_at", 0.0) <= now][:ALERT_DRAIN_PER_SWEEP]
    return deliver_alerts(state, due) if due else False


def _alert_key(rid: int, tag: str | None = None) -> str:
    return f"{ALERT_KEY_PREFIX}{rid}" + (f"-{tag}" if tag else "")


def raise_alert(state: dict[str, Any], rid: int, message: str, tag: str | None = None) -> None:
    """One alert for row `rid`, deduplicated on its key (ALERT_KEY_PREFIX + rid, plus `-<tag>` when
    tagged, so a tagged alert never suppresses the row's terminal one): a key already pending or
    delivered is never queued again. That key is delivered at once through deliver_alerts; a
    failure is retried by drain_alerts. Never raises."""
    alert = _alert_state(state)
    pending, seen = alert["pending"], alert["seen"]
    key = _alert_key(rid, tag)
    if key not in pending and key not in seen and len(pending) < MAX_ALERT_PENDING:
        pending[key] = message[:1000]
    deliver_alerts(state, [key])


def _alert_once(state: dict[str, Any], rid: int, tag: str, message: str) -> None:
    """raise_alert() on the tagged key only while it is neither pending nor delivered, so a failed
    delivery is retried by drain_alerts' backoff, never once per sweep."""
    alert, tagged = _alert_state(state), _alert_key(rid, tag)
    if tagged not in alert["pending"] and tagged not in alert["seen"]:
        raise_alert(state, rid, message, tag=tag)


def _identity_changed(state: dict[str, Any], rid: int, held: str, key: str | None) -> None:
    _alert_once(state, rid, ROW_IDENTITY_CHANGED,
                f"Engine control row {rid} was re-read as {key} while engine_ops request {rid} ({held}) is "
                f"unresolved ({ROW_IDENTITY_CHANGED}); the new row is refused and the runner replays the "
                "original captured argv until engine_ops answers. Inspect the dashboard row and engine_ops status.")


def settle(row: dict[str, Any], outcome: dict[str, Any], state: dict[str, Any]) -> dict[str, Any] | None:
    """The ack for apply()'s `outcome`, or None while the row stays pending. `state` is the caller's
    persisted replay state (load_replay_state), updated in place, keyed by replay_key(row). An ack
    clears the row's entry. A pending outcome counts one replay (a "reconcile" deferral too):
    halt stays pending forever and alerts once at MAX_REPLAYS; any other kind stays pending through
    MAX_REPLAYS replays and is rejected on the next one, as `timeout_unreconciled` with one alert
    when any attempt was killed mid-run, else with the last outcome's note (nothing ran or
    engine_ops was busy, so nothing is half applied). A reused row id's older never-ran entry is
    dropped, so the new row starts fresh and one row id holds at most one entry; an older
    UNRESOLVED entry (held_key) is never dropped by a sibling: the new key is refused
    ROW_IDENTITY_CHANGED (alerted once), never counted, and None is returned while the held request
    stays live until it settles. The first timed-out dispatch's argv (the outcome's `argv`) is
    captured under the key for reconcile_unresolved()."""
    rows = state.setdefault("rows", {})
    rid = outcome.get("id")
    key = replay_key(row)
    if outcome.get("state") != "pending":
        if key is not None and rid == row.get("id"):
            _forget(state, key)
        if "alert" in outcome:  # a final ack that may be half applied (a resume's outcome_unknown)
            outcome = dict(outcome)
            message = outcome.pop("alert")
            if type(rid) is int and rid >= 0:
                raise_alert(state, rid, str(message))
        return outcome
    if type(rid) is not int or rid < 0 or key is None or rid != row.get("id"):
        return _rejected(rid, outcome.get("note", "apply failed"))
    held = held_key(row, state)
    if held is not None and held != key:
        _identity_changed(state, rid, held, key)
        return None
    for other in [other for other in rows if other != key and _replay_key_id(other) == rid]:
        _forget(state, other)  # a reused row id: the older never-ran row's counter never carries over
    return _count_replay(state, key, rid, row.get("kind") if isinstance(row, dict) else None, outcome)


def _count_replay(state: dict[str, Any], key: str, rid: int, kind: Any, outcome: dict[str, Any]) -> dict[str, Any] | None:
    """settle()'s pending half for the request under `key`: count one replay, capture the first
    timed-out dispatch's argv (a pause: its snapshot), and return None while it stays pending or its
    terminal ack. A new key takes a slot through _make_room (never-ran entries are evicted, an
    unresolved one never is); when none can be made, a stop stays pending untracked (its live row
    reruns it) and any other kind is refused REPLAY_TABLE_FULL, each with an alert."""
    rows, requests = state.setdefault("rows", {}), state.setdefault("requests", {})
    previous = rows.pop(key, None)
    entry = previous or {"replays": 0, "timeouts": 0, "alerted": False}
    entry = {"replays": min(entry["replays"] + 1, MAX_REPLAY_COUNT),
             "timeouts": min(entry["timeouts"] + (outcome.get("retry") == RETRY_TIMEOUT), MAX_REPLAY_COUNT),
             "alerted": entry["alerted"]}
    if kind in STOP_KINDS or entry["replays"] <= MAX_REPLAYS:
        if kind in STOP_KINDS and entry["replays"] >= MAX_REPLAYS and not entry["alerted"]:
            label = "Engine halt" if kind == HALT else kind
            raise_alert(state, rid, f"{label} row {rid} is still pending after {entry['replays']} attempts "
                                    f"({outcome.get('retry')}: {outcome.get('note', '')[:200]}); it keeps retrying; "
                                    "inspect the engine_ops lock holder on the runner.")
            entry["alerted"] = True
        if previous is None and not _make_room(state, kind):
            requests.pop(key, None)
            state.get("domains", {}).pop(key, None)
            if kind in STOP_KINDS:
                _alert_once(state, rid, REPLAY_TABLE_FULL,
                            f"Engine control row {rid} ({kind}) is not tracked ({REPLAY_TABLE_FULL}: "
                            f"{len(rows)} engine_ops requests hold the replay table); it stays pending and "
                            "reruns from its dashboard row each sweep. Inspect engine_ops status.")
                return None
            raise_alert(state, rid, f"Engine control row {rid} ({kind}) was refused {REPLAY_TABLE_FULL}: the "
                                    f"replay table holds {len(rows)} unresolved engine_ops requests; "
                                    f"request {rid} ({outcome.get('retry')}) may be half applied; rerun it "
                                    "with the same --request-id or inspect engine_ops status.")
            return _rejected(rid, f"{REPLAY_TABLE_FULL}: {len(rows)} unresolved engine_ops requests hold the "
                                  f"replay table; request {rid} ({outcome.get('retry')}) is not tracked; rerun "
                                  f"it with --request-id {rid}")
        rows[key] = entry
        if outcome.get("retry") == RETRY_TIMEOUT and key not in requests:  # captured once, at first dispatch
            args = _dispatch_argv(outcome.get("argv"), key)
            if args is not None:
                requests[key] = args
            if kind == DOMAIN_PAUSE and key not in state.get("domains", {}):
                captured = outcome.get("domain_request")
                if isinstance(captured, dict) and captured.get("id") == rid and captured.get("kind") == kind:
                    state.setdefault("domains", {})[key] = captured
        return None
    requests.pop(key, None)
    state.get("domains", {}).pop(key, None)
    if entry["timeouts"]:
        raise_alert(state, rid, f"Engine control row {rid} ({kind}) timed out {entry['timeouts']} time(s) and was "
                                f"rejected {TIMEOUT_UNRECONCILED}; engine_ops request {rid} may be half applied; "
                                "rerun it with the same --request-id or inspect engine_ops status.")
        return _rejected(rid, f"{TIMEOUT_UNRECONCILED}: engine_ops request {rid} timed out {entry['timeouts']} "
                              f"time(s) in {entry['replays']} attempts; rerun it with --request-id {rid} to finish it")
    return _rejected(rid, outcome.get("note", "apply failed"))


def _replay(rid: int, args: list[str] | None, *, cwd: str, budget: Callable[[], float] | None,
            run: Callable[..., tuple[int, str, str]] | None) -> dict[str, Any]:
    """One rerun of a captured argv inside `budget`, as apply()'s outcome in reconcile mode: a
    kill mid-run is pending "timeout", a spent deadline pending "deadline", any other failure
    before engine_ops answers pending "reconcile", and engine_ops's answer goes through _answer()."""
    if args is None:
        return _pending(rid, RETRY_RECONCILE, "reconcile deferred: no argv was captured for this request")
    runner = run or run_bounded
    started = False
    try:
        remaining = _remaining(budget)
        left = remaining()
        started = True
        code, out, err = runner(_command(args), left, cwd)
    except subprocess.TimeoutExpired:
        if started:
            return {**_pending(rid, RETRY_TIMEOUT, "reconcile outcome unknown: engine_ops timed out"), "argv": list(args)}
        return _pending(rid, RETRY_DEADLINE, "reconcile deferred: the row deadline was spent before engine_ops started")
    except Exception as exc:
        return _pending(rid, RETRY_RECONCILE, f"reconcile deferred: {type(exc).__name__}: {exc}")
    return _answer(rid, code, out, err, _argv_engine(args),
                   lambda engine: runner(_command(["status", engine, "--json"]), remaining(), cwd))


def _risk_increasing_argv(args: list[str] | None, kind: str) -> bool:
    """Whether a captured argv increases risk: an approval kind, or a breaker set that carries an
    approval (a raise needs one; fails closed on a lowering that also names one)."""
    return kind in APPROVAL_KINDS or (kind == BREAKER and args is not None and "--approval" in args)


def reconcile_unresolved(key: str, state: dict[str, Any], *, cwd: str, reason: str | None,
                         domain_row: dict[str, Any] | None = None,
                         budget: Callable[[], float] | None = None,
                         run: Callable[..., tuple[int, str, str]] | None = None,
                         exposure_refusal: Callable[[], str | None] | None = None) -> dict[str, Any] | None:
    """Reconcile the unresolved request under `key` (one of orphans(), or a held_key()) whose row
    the batch carries `reason` ("malformed" or "missing"; None for a carried row, which raises no
    unreadable alert): alert RECONCILE_ROW_UNREADABLE once (its own tagged key, queued only when
    neither pending nor delivered), rerun the argv captured at its first dispatch (the same request
    id, never rebuilt from a re-read row), and count that attempt exactly as settle() does. A
    risk-increasing argv asks `exposure_refusal` first, and a refusal (or a failed read) counts a
    "reconcile" deferral, as apply() does in reconcile mode. The ack once engine_ops answers or the
    replay limit settles it, else None while it stays pending; never raises. A key with no captured
    argv (state from before capture) counts a "reconcile" deferral per sweep, so it still settles
    with the timeout_unreconciled alert."""
    entry, rid = state.get("rows", {}).get(key), _replay_key_id(key)
    if rid is None or not _unresolved(entry):
        return None
    kind = _key_kind(key)
    if reason is not None:
        _alert_once(state, rid, RECONCILE_ROW_UNREADABLE,
                    f"Engine control row {rid} ({kind}) is {reason} in the dashboard batch while engine_ops "
                    f"request {rid} is unresolved after {entry['timeouts']} timeout(s) "
                    f"({RECONCILE_ROW_UNREADABLE}); the runner replays its captured argv until engine_ops "
                    "answers. Inspect the dashboard row and engine_ops status.")
    args = state.get("requests", {}).get(key)
    refusal = None
    if exposure_refusal is not None and _risk_increasing_argv(args, kind):
        try:
            refusal = exposure_refusal()
        except Exception as exc:
            refusal = f"{type(exc).__name__}: {exc}"
    if kind == DOMAIN_PAUSE:
        # The captured snapshot reruns; with none (state from before capture), the live row is
        # validated and rerun. Pause carries no secret, and engine_ops replays its request_id.
        captured = state.get("domains", {}).get(key)
        if captured is None and domain_row is not None:
            try:
                validate(domain_row)
                captured = domain_row
            except (Rejected, ValueError, TypeError, AttributeError):
                pass
        outcome = (apply(captured, cwd=cwd, budget=budget, run=run, reconcile=True) if captured is not None else
                   _pending(rid, RETRY_RECONCILE, "reconcile deferred: no domain request captured"))
    elif refusal is not None:
        outcome = _pending(rid, RETRY_RECONCILE, f"reconcile deferred: {refusal}")
    else:
        outcome = _replay(rid, args, cwd=cwd, budget=budget, run=run)
    if outcome.get("state") != "pending":
        _forget(state, key)
        return outcome
    return _count_replay(state, key, rid, kind, outcome)


def reconcile_row(row: dict[str, Any], state: dict[str, Any], *, cwd: str,
                  budget: Callable[[], float] | None = None,
                  run: Callable[..., tuple[int, str, str]] | None = None,
                  exposure_refusal: Callable[[], str | None] | None = None) -> dict[str, Any] | None:
    """A carried row whose id an unresolved request holds (held_key), else None (apply it as usual).
    The row is never validated or rebuilt, whatever its shape: the held request's captured argv
    reruns (reconcile_unresolved). A row whose replay_key is not the held one (another kind or
    requested_at) is refused ROW_IDENTITY_CHANGED, alerted once, and never replaces the held
    request, which keeps its counter and argv until it settles. The held request's ack once it
    settles, else a state "pending" outcome that is not an ack; never raises."""
    held = held_key(row, state)
    if held is None:
        return None
    rid, key = row["id"], replay_key(row)
    if key != held:
        _identity_changed(state, rid, held, key)
    ack = reconcile_unresolved(held, state, cwd=cwd, reason=None, budget=budget, run=run,
                               domain_row=row if key == held else None,
                               exposure_refusal=exposure_refusal)
    if ack is not None:
        return ack
    if key != held:
        return _pending(rid, ROW_IDENTITY_CHANGED, f"{ROW_IDENTITY_CHANGED}: row {rid} is refused while engine_ops "
                                                   f"request {held} is unresolved; its captured argv was replayed")
    return _pending(rid, RETRY_RECONCILE, f"reconcile pending: engine_ops request {rid} replayed its captured argv")
