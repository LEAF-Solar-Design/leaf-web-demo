"""Pre-registration and promotion evidence for leafhft stage-2 experiments.

JSON is limited to 32 KiB, 16 levels and 32,768 nodes. Integers use signed
64-bit bounds; timestamps and durations are nonnegative. Latest means last
appended, not the greatest caller-supplied timestamp. Writes inherit Ledger's
single-writer contract. A successful check records evidence, not live authority.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path

from .ledger import Ledger, LedgerFailed
from .ui.reader import _ro

REQUIRED_FIELDS = (
    "hypothesis", "incumbent_digest", "candidate_digest", "code_digest",
    "venue_symbol", "fee_snapshot", "data_cutoff", "train_window",
    "purge_embargo", "evaluation_window", "regime_definition", "grid",
    "reward", "prior", "bounds", "allocation_probability", "seed",
    "fill_model_version", "latency_model", "primary_metric", "dependence_method",
    "multiplicity_rule", "minimum_information", "promotion_rule", "demotion_rule",
    "approval_reference_if_live",
)
_RESULT_FIELDS = ("oos_metric", "lower95", "n_blocks", "decision", "note")
_MAX_BYTES = 32_768
_MAX_EVENTS = 100_000
_MAX_INT = 2**63 - 1
_ID = re.compile(r"exp-[0-9a-f]{12}")


class ExperimentRefused(ValueError):
    pass


def _integer(value, name, minimum=0):
    if type(value) is not int or not minimum <= value <= _MAX_INT:
        raise ExperimentRefused(f"{name}: integer out of range")


def _keys(value, fields, name):
    if type(value) is not dict or set(value) != set(fields):
        raise ExperimentRefused(f"{name}: keys must be exactly {', '.join(fields)}")


def _canonical(value):
    # Check before serializing: no coercion, nonfinite numbers, cycles, or
    # unbounded recursion. The node budget also bounds containers and keys.
    remaining = _MAX_BYTES
    characters = _MAX_BYTES

    def visit(item, depth):
        nonlocal remaining, characters
        remaining -= 1
        if remaining < 0 or depth > 16:
            raise ExperimentRefused("JSON structure exceeds bounds")
        kind = type(item)
        if kind is str:
            characters -= len(item)
            if characters < 0:
                raise ExperimentRefused("JSON exceeds 32768 bytes")
        elif kind is int:
            _integer(item, "JSON integer", -2**63)
        elif kind is float:
            if not math.isfinite(item):
                raise ExperimentRefused("JSON numbers must be finite")
        elif kind is dict:
            if len(item) > _MAX_BYTES:
                raise ExperimentRefused("JSON structure exceeds bounds")
            for key, child in item.items():
                if type(key) is not str:
                    raise ExperimentRefused("JSON keys must be strings")
                visit(key, depth + 1)
                visit(child, depth + 1)
        elif kind is list:
            if len(item) > _MAX_BYTES:
                raise ExperimentRefused("JSON structure exceeds bounds")
            for child in item:
                visit(child, depth + 1)
        elif item is not None and kind is not bool:
            raise ExperimentRefused("unsupported JSON type")

    visit(value, 0)
    try:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"),
                         allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, UnicodeError) as exc:
        raise ExperimentRefused("invalid JSON") from exc
    if len(raw) > _MAX_BYTES:
        raise ExperimentRefused("JSON exceeds 32768 bytes")
    return raw


def _validate_row(row):
    _keys(row, REQUIRED_FIELDS, "registration")
    raw = _canonical(row)
    strings = (
        "hypothesis", "regime_definition", "reward", "fill_model_version",
        "latency_model", "primary_metric", "dependence_method",
        "multiplicity_rule", "promotion_rule", "demotion_rule",
        "approval_reference_if_live",
    )
    for name in strings:
        if type(row[name]) is not str:
            raise ExperimentRefused(f"{name}: expected string")
    if not 1 <= len(row["hypothesis"]) <= 2000:
        raise ExperimentRefused("hypothesis: length must be 1..2000")
    for name, pattern in (("incumbent_digest", r"(?:[0-9a-fA-F]{64})?"),
                          ("candidate_digest", r"[0-9a-fA-F]{64}"),
                          ("code_digest", r"[0-9a-fA-F]{7,64}")):
        if type(row[name]) is not str or not re.fullmatch(pattern, row[name]):
            raise ExperimentRefused(f"{name}: invalid hex digest")
    venue = row["venue_symbol"]
    if type(venue) is not str or not re.fullmatch(r"[^\s:]+:[^\s:]+", venue):
        raise ExperimentRefused("venue_symbol: expected venue:SYMBOL")
    for name, fields in (("fee_snapshot", ("maker_bps", "taker_bps")),
                         ("purge_embargo", ("purge_s", "embargo_s")),
                         ("train_window", ("start_ns", "end_ns")),
                         ("evaluation_window", ("start_ns", "end_ns"))):
        _keys(row[name], fields, name)
        for field in fields:
            _integer(row[name][field], f"{name}.{field}")
        if name.endswith("window") and row[name]["start_ns"] >= row[name]["end_ns"]:
            raise ExperimentRefused(f"{name}: start must precede end")
    for name in ("grid", "prior", "bounds", "minimum_information"):
        if type(row[name]) is not dict:
            raise ExperimentRefused(f"{name}: expected dict")
    _integer(row["data_cutoff"], "data_cutoff", 1)
    _integer(row["seed"], "seed", -2**63)
    probability = row["allocation_probability"]
    if type(probability) is not float or not 0 <= probability <= 1:
        raise ExperimentRefused("allocation_probability: expected float in 0..1")
    if not row["train_window"]["end_ns"] <= row["data_cutoff"] <= row["evaluation_window"]["start_ns"]:
        raise ExperimentRefused("data_cutoff: must separate training and evaluation")
    return raw


def _validate_result(result):
    _keys(result, _RESULT_FIELDS, "result")
    _canonical(result)
    for name in ("oos_metric", "lower95"):
        if type(result[name]) is not float or not math.isfinite(result[name]):
            raise ExperimentRefused(f"{name}: expected finite float")
    _integer(result["n_blocks"], "n_blocks", 1)
    if type(result["decision"]) is not str or result["decision"] not in ("promote", "hold", "demote", "extend"):
        raise ExperimentRefused("decision: invalid decision")
    if type(result["note"]) is not str or len(result["note"]) > 2000:
        raise ExperimentRefused("note: expected string of at most 2000 characters")


def _experiment_id(raw):
    return "exp-" + hashlib.sha256(raw).hexdigest()[:12]


def _validate_id(experiment_id):
    if type(experiment_id) is not str or not _ID.fullmatch(experiment_id):
        raise ExperimentRefused("invalid experiment_id")


def _timestamp(now_ns):
    value = time.time_ns() if now_ns is None else now_ns
    _integer(value, "timestamp")
    return value


class _ReadLedger(Ledger):
    """Use Ledger's verification on a read-only, consistent SQLite snapshot."""

    def __init__(self, path):
        self.path = Path(path)
        self.head_path = self.path.with_suffix(self.path.suffix + ".head")
        self._conn = _ro(self.path)
        self._lock = threading.Lock()
        self._buf = []
        self.failed = ""
        try:
            self._conn.execute("BEGIN")
            ok, self._count, self._prev_hash = self._verify_locked()
            if not ok:
                raise LedgerFailed("chain broken")
            self._check_head_sidecar()
        except Exception:
            self._conn.close()
            raise

    def close(self):
        self._conn.close()


def _history(ledger):
    registrations, results = {}, {}
    cursor = ledger._conn.execute(
        "SELECT ts_ns, kind, body FROM events WHERE kind IN ('register','result') "
        "ORDER BY rowid LIMIT ?", (_MAX_EVENTS + 1,),
    )
    for index, (ts, kind, raw) in enumerate(cursor):
        if index >= _MAX_EVENTS:
            raise ExperimentRefused("experiment event limit exceeded")
        # The envelope adds a small, fixed amount to the bounded row.
        if type(raw) is not str or len(raw.encode("utf-8")) > _MAX_BYTES + 256:
            raise ExperimentRefused("invalid stored body size")
        try:
            body = json.loads(raw)
        except (ValueError, RecursionError) as exc:
            raise ExperimentRefused("invalid stored JSON") from exc
        fields = REQUIRED_FIELDS if kind == "register" else _RESULT_FIELDS
        stamp = "registered_ts" if kind == "register" else "decided_ts"
        _keys(body, (*fields, "experiment_id", stamp), "stored body")
        eid = body["experiment_id"]
        _validate_id(eid)
        _integer(body[stamp], stamp)
        if body[stamp] != ts:
            raise ExperimentRefused("stored timestamp mismatch")
        payload = {key: body[key] for key in fields}
        if kind == "register":
            if _experiment_id(_validate_row(payload)) != eid:
                raise ExperimentRefused("stored experiment_id mismatch")
            if eid in registrations:
                raise ExperimentRefused("duplicate registration")
            registrations[eid] = body
        else:
            _validate_result(payload)
            if eid not in registrations:
                raise ExperimentRefused("result without registration")
            results.setdefault(eid, []).append(body)
    return registrations, results


def register(ledger_path, row: dict, now_ns: int | None = None) -> str:
    raw = _validate_row(row)
    row = json.loads(raw)  # Own the validated snapshot, including nested values.
    ts = _timestamp(now_ns)
    if ts >= row["evaluation_window"]["start_ns"]:
        raise ExperimentRefused("registration must precede evaluation_window.start_ns")
    eid = _experiment_id(raw)
    try:
        with closing(Ledger(ledger_path)) as ledger:
            registrations, _ = _history(ledger)
            if eid in registrations:
                raise ExperimentRefused("duplicate experiment_id")
            if ledger.count("register") + ledger.count("result") >= _MAX_EVENTS:
                raise ExperimentRefused("experiment event limit exceeded")
            ledger.append(ts, "register", {"experiment_id": eid, "registered_ts": ts, **row})
    except (LedgerFailed, sqlite3.Error, OSError) as exc:
        raise ExperimentRefused(f"ledger: {exc}") from exc
    return eid


def record_result(ledger_path, experiment_id, result: dict, now_ns=None) -> None:
    _validate_id(experiment_id)
    _validate_result(result)
    result = json.loads(_canonical(result))
    ts = _timestamp(now_ns)
    if not Path(ledger_path).is_file():
        raise ExperimentRefused("missing registration")
    try:
        with closing(Ledger(ledger_path)) as ledger:
            registrations, results = _history(ledger)
            if experiment_id not in registrations:
                raise ExperimentRefused("missing registration")
            if result["decision"] == "promote" and any(
                r["decision"] == "promote" for r in results.get(experiment_id, [])
            ):
                raise ExperimentRefused("duplicate promote")
            if ledger.count("register") + ledger.count("result") >= _MAX_EVENTS:
                raise ExperimentRefused("experiment event limit exceeded")
            ledger.append(ts, "result", {"experiment_id": experiment_id, "decided_ts": ts, **result})
    except (LedgerFailed, sqlite3.Error, OSError) as exc:
        raise ExperimentRefused(f"ledger: {exc}") from exc


def promote_check(ledger_path, experiment_id) -> dict:
    reasons = []
    answer = {"ok": False, "reasons": reasons, "experiment_id": experiment_id}
    try:
        _validate_id(experiment_id)
    except ExperimentRefused:
        reasons.append("missing_registration")
        return answer
    if not Path(ledger_path).is_file():
        reasons.extend(("chain", "missing_registration", "missing_result"))
        return answer
    try:
        with closing(_ReadLedger(ledger_path)) as ledger:
            if not ledger.verify()[0]:
                reasons.append("chain")
            registrations, results = _history(ledger)
    except (LedgerFailed, sqlite3.Error, OSError):
        reasons.append("chain")
        return answer
    except (ExperimentRefused, ValueError, TypeError, RecursionError):
        reasons.append("invalid_stored_schema")
        return answer
    registration = registrations.get(experiment_id)
    if registration is None:
        reasons.append("missing_registration")
    elif registration["registered_ts"] >= registration["evaluation_window"]["start_ns"]:
        reasons.append("registration_after_window_start")
    history = results.get(experiment_id, [])
    if not history:
        reasons.append("missing_result")
    else:
        latest = history[-1]
        if latest["decision"] != "promote":
            reasons.append("decision_not_promote")
        if latest["lower95"] <= 0:
            reasons.append("lower95_not_positive")
        if registration and latest["decided_ts"] < registration["evaluation_window"]["end_ns"]:
            reasons.append("decided_before_window_end")
        if sum(r["decision"] == "promote" for r in history) > 1:
            reasons.append("duplicate_promote")
    answer["ok"] = not reasons
    return answer


def list_experiments(ledger_path, limit=10_000) -> list[dict]:
    if type(limit) is not int or not 1 <= limit <= 10_000:
        raise ExperimentRefused("limit: expected integer in 1..10000")
    if not Path(ledger_path).exists():
        return []
    try:
        with closing(_ReadLedger(ledger_path)) as ledger:
            registrations, results = _history(ledger)
    except (LedgerFailed, sqlite3.Error, OSError) as exc:
        raise ExperimentRefused(f"chain: {exc}") from exc
    return [
        {**row, "latest_result": results[eid][-1] if results.get(eid) else None,
         "results_n": len(results.get(eid, []))}
        for eid, row in list(registrations.items())[::-1][:limit]
    ]


class _Parser(argparse.ArgumentParser):
    def error(self, message):
        raise ExperimentRefused(message)


def _load_json(path):
    with open(path, "rb") as source:
        raw = source.read(_MAX_BYTES + 1)
    if len(raw) > _MAX_BYTES:
        raise ExperimentRefused("JSON file exceeds 32768 bytes")

    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ExperimentRefused("duplicate JSON key")
            result[key] = value
        return result

    return json.loads(raw, object_pairs_hook=unique)


def main(argv=None) -> int:
    parser = _Parser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("register", "result", "check", "list"):
        command = commands.add_parser(name)
        command.add_argument("--ledger", required=True)
        if name in ("result", "check"):
            command.add_argument("--id", required=True)
        if name == "register":
            command.add_argument("--row", required=True)
        if name == "result":
            command.add_argument("--result", required=True)
    try:
        args = parser.parse_args(argv)
        if args.command == "register":
            output = {"experiment_id": register(args.ledger, _load_json(args.row))}
        elif args.command == "result":
            record_result(args.ledger, args.id, _load_json(args.result))
            output = {"ok": True, "experiment_id": args.id}
        elif args.command == "check":
            output = promote_check(args.ledger, args.id)
        else:
            output = list_experiments(args.ledger)
        print(json.dumps(output, sort_keys=True, allow_nan=False))
        return 2 if args.command == "check" and not output["ok"] else 0
    except (ExperimentRefused, OSError, ValueError, TypeError, RecursionError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
