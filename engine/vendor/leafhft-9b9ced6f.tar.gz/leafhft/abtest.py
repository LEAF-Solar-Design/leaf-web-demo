"""Deterministic crossover schedules for existing, hot-bound policy engines."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import tempfile
import time
import warnings
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone

from .engines import Bindings, EngineRegistry, _id, _timestamp

MAX_BYTES = 16 * 1024
READBACK_SECONDS = 75


class Refusal(ValueError):
    exit_code = 2


def utc(value):
    if isinstance(value, datetime):
        if value.utcoffset() != timedelta(0):
            raise Refusal("time must be UTC")
        return value
    return _timestamp(value, "time")


def _read(path, limit):
    with Path(path).open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise Refusal(f"{path}: exceeds {limit} bytes")
    raw = json.loads(data)
    if not isinstance(raw, dict):
        raise Refusal(f"{path}: expected object")
    return raw


@dataclass
class Schedule:
    ab_id: str
    arms: dict
    books: list
    start_at: str
    phases_planned: int
    period_hours: int = 72
    applied_phase: int | None = None
    events: list = field(default_factory=list)
    trial_id: str | None = None
    path: Path | None = field(default=None, repr=False, compare=False)
    stopping: bool = False

    def __post_init__(self):
        self.validate()

    def validate(self):
        if type(self.stopping) is not bool:
            raise Refusal("stopping must be a bool")
        _id(self.ab_id, "ab_id")
        if not isinstance(self.arms, dict) or set(self.arms) != {"A", "B"}:
            raise Refusal("arms must contain A and B")
        for engine_id in self.arms.values():
            _id(engine_id)
        if self.arms["A"] == self.arms["B"]:
            raise Refusal("arms must differ")
        if not isinstance(self.books, list) or not 2 <= len(self.books) <= 14:
            raise Refusal("books must contain 2..14 symbols")
        for symbol in self.books:
            Bindings._symbol(symbol)
        if self.books != sorted(set(self.books)):
            raise Refusal("books must be sorted and unique")
        if type(self.period_hours) is not int or not 24 <= self.period_hours <= 168:
            raise Refusal("period_hours must be 24..168")
        if type(self.phases_planned) is not int or not 2 <= self.phases_planned <= 20 or self.phases_planned % 2:
            raise Refusal("phases_planned must be even, 2..20")
        start = utc(self.start_at)
        if start.minute % 15 != 6 or start.second or start.microsecond:
            raise Refusal("start_at must be on minute 6, 21, 36 or 51")
        if self.applied_phase is not None and (type(self.applied_phase) is not int or
                                              not 0 <= self.applied_phase < self.phases_planned):
            raise Refusal("invalid applied_phase")
        if self.trial_id is not None and (not isinstance(self.trial_id, str) or
                                         not re.fullmatch(r"[0-9a-f]{32}", self.trial_id)):
            raise Refusal("trial_id must be 32 lowercase hex characters")
        if not isinstance(self.events, list) or len(self.events) > 200:
            raise Refusal("events must contain at most 200 entries")
        for event in self.events:
            if not isinstance(event, dict) or set(event) != {"kind", "at", "phase", "assignment", "note"}:
                raise Refusal("invalid event")
            if event["kind"] not in {"applied", "apply_failed", "stop_requested", "stopped"}:
                raise Refusal("invalid event kind")
            utc(event["at"])
            if event["phase"] is not None and (type(event["phase"]) is not int or
                                               not 0 <= event["phase"] < self.phases_planned):
                raise Refusal("invalid event phase")
            if not isinstance(event["note"], str) or len(event["note"]) > 2000:
                raise Refusal("invalid event note")
            if not isinstance(event["assignment"], dict) or set(event["assignment"]) != set(self.books):
                raise Refusal("invalid event assignment")
            if any(value not in self.arms.values() for value in event["assignment"].values()):
                raise Refusal("invalid event engine")

    @classmethod
    def load(cls, path):
        path = Path(path)
        raw = _read(path, MAX_BYTES)
        if "path" in raw:
            raise Refusal("path is not a state field")
        result = cls(**raw, path=path)
        if path.stem != result.ab_id:
            raise Refusal("ab_id differs from filename")
        return result

    def document(self):
        result = asdict(self)
        result.pop("path")
        return result

    def save(self):
        self.validate()
        data = (json.dumps(self.document(), sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
        while len(data) > MAX_BYTES and len(self.events) > 1:
            self.events.pop(0)
            data = (json.dumps(self.document(), sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
        if len(data) > MAX_BYTES:
            raise Refusal("state too large")
        if self.path is None:
            raise Refusal("state path required")
        path = Path(self.path)
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix="." + path.name, dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def phase_at(self, now):
        elapsed = (utc(now) - utc(self.start_at)).total_seconds()
        if elapsed < 0:
            return None
        phase = int(elapsed // (self.period_hours * 3600))
        return phase if phase < self.phases_planned else "finished"

    def assignment(self, phase):
        if type(phase) is not int or not 0 <= phase < self.phases_planned:
            raise Refusal("invalid phase")
        split = (len(self.books) + 1) // 2
        return {book: self.arms["AB"[(int(index >= split) + phase) % 2]]
                for index, book in enumerate(self.books)}

    def boundaries(self):
        return [utc(self.start_at) + timedelta(hours=self.period_hours * k)
                for k in range(self.phases_planned + 1)]

    def plan(self):
        bounds = self.boundaries()
        return [{"phase": k, "start_at": bounds[k].isoformat(),
                 "end_at": bounds[k + 1].isoformat(), "assignment": self.assignment(k)}
                for k in range(self.phases_planned)]

    @property
    def stopped(self):
        return any(event["kind"] == "stopped" for event in self.events)

    def record(self, kind, now, phase, assignment, note):
        suffix = " ...[truncated]"
        if len(note) > 2000:
            note = note[:2000 - len(suffix)] + suffix
        event = dict(kind=kind, at=utc(now).isoformat(), phase=phase,
                     assignment=assignment, note=note)
        self.events.append(event)
        self.events = self.events[-200:]
        self.save()


def _window(now):
    offset = utc(now).timestamp() % 900
    if offset >= 780 or offset <= 2:
        raise Refusal("inside close window or boundary edge")


def _status(statuses, symbol, clock):
    path = statuses(symbol) if callable(statuses) else statuses[symbol]
    path = Path(path)
    limit = 1024 * 1024
    with path.open("rb") as stream:
        data = stream.read(limit + 1)
        metadata = os.fstat(stream.fileno())
    if len(data) > limit:
        raise Refusal(f"{path}: exceeds {limit} bytes")
    raw = json.loads(data)
    if not isinstance(raw, dict):
        raise Refusal(f"{path}: expected object")
    stamps = [metadata.st_mtime]
    if "generated_at" in raw:
        stamps.append(utc(raw["generated_at"]).timestamp())
    now = utc(clock())
    ages = [now.timestamp() - stamp for stamp in stamps]
    if any(not 0 <= age <= 240 for age in ages):
        def detail(value, spec=""):
            try:
                return " ".join(format(value, spec).split())[:512]
            except Exception:
                return "unavailable"

        generated_age = detail(ages[1], ".3f") if len(ages) > 1 else "absent"
        raise Refusal(f"{detail(symbol)}: stale or future status: now={detail(now.isoformat())} "
                      f"mtime_age_s={detail(ages[0], '.3f')} generated_at_age_s={generated_age} "
                      f"path={detail(path)} inode={detail(metadata.st_ino)} size={detail(metadata.st_size)}")
    for name in ("policy", "engine"):
        if not isinstance(raw.get(name), dict) or (name == "policy" and "error" not in raw[name]):
            raise Refusal(f"{symbol}: malformed {name} status")
        if raw[name].get("error") is not None:
            raise Refusal(f"{symbol}: {name} error: {raw[name]['error']}")
    _id(raw["engine"]["engine_id"])
    return raw["engine"]["engine_id"], stamps[-1]


def apply(schedule: Schedule, bindings: Bindings, registry: EngineRegistry, now, *, statuses,
          stop_reason=None, clock=None):
    """Return a receipt; refusals raise Refusal before any binding/state writes.

    statuses maps symbols to status paths, or is a callable resolving each path
    afresh. The CLI serializes all its writers with the AB directory lock.
    """
    now = utc(now)
    clock = clock or (lambda: datetime.now(timezone.utc))
    phase = schedule.phase_at(now)
    stopping = stop_reason is not None or schedule.stopping
    if schedule.stopped or (not stopping and (phase in (None, "finished") or phase == schedule.applied_phase)):
        return {"ab_id": schedule.ab_id, "result": "noop", "phase": phase}
    if stop_reason is not None and (not stop_reason.strip() or len(stop_reason) > 500):
        raise Refusal("stop reason must contain 1..500 characters")
    target = ({book: schedule.arms["A"] for book in schedule.books} if stopping
              else schedule.assignment(phase))
    try:
        schedule.validate()
        if schedule.path is None:
            raise Refusal("state path required")
        _window(clock())
        for engine_id in schedule.arms.values():
            if not registry.get(engine_id).enabled:
                raise Refusal(f"{engine_id}: engine disabled")
        for book in schedule.books:
            _status(statuses, book, clock)
            if bindings.resolve(book) not in schedule.arms.values():
                raise Refusal(f"{book}: foreign binding")
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise Refusal(str(exc)) from exc
    event_phase = phase if type(phase) is int else schedule.applied_phase
    if stopping and not schedule.stopping:
        schedule.stopping = True
        schedule.record("stop_requested", clock(), event_phase, target, stop_reason)
    written = {}
    changed, observed, errors = [], {}, {}
    for book, engine_id in target.items():
        try:
            _window(clock())
            current = bindings.resolve(book)
            if current not in schedule.arms.values():
                raise Refusal("foreign binding")
            if current != engine_id:
                bindings.bind(book, engine_id)
                written[book] = utc(clock()).timestamp()
                changed.append(book)
        except (OSError, ValueError) as exc:
            errors[book] = str(exc)
            break
    deadline = time.monotonic() + READBACK_SECONDS
    while True:
        observed = {}
        read_now = utc(clock())
        for book in schedule.books:
            try:
                engine_id, stamp = _status(statuses, book, clock)
                observed[book] = {"engine_id": engine_id, "stamp": stamp}
            except (OSError, ValueError, KeyError, TypeError) as exc:
                observed[book] = {"error": str(exc)}
        success = not errors and all(
            observed[book].get("engine_id") == engine_id and
            (book not in written or observed[book]["stamp"] > written[book])
            for book, engine_id in target.items())
        if success or time.monotonic() >= deadline or errors:
            break
        time.sleep(min(0.5, max(0, deadline - time.monotonic())))
    if success and not stopping:
        schedule.applied_phase = phase
    kind = ("stopped" if stopping else "applied") if success else "apply_failed"
    note = json.dumps({"changed": changed, "readback": observed, "errors": errors}, sort_keys=True)
    read_now = utc(clock())
    schedule.record(kind, read_now, event_phase, target, note)
    if schedule.trial_id:
        from .trials import TrialStore, TrialError
        try:
            TrialStore().append_event(schedule.trial_id, {
                "kind": "note", "at": read_now.isoformat(),
                "reason": f"AB {schedule.ab_id}: {kind}, phase {event_phase}; see crossover state",
            })
        except (TrialError, OSError) as exc:
            warnings.warn(f"trial note skipped: {exc}", RuntimeWarning)
    return {"ab_id": schedule.ab_id, "result": kind, "phase": phase,
            "changed": changed, "readback": observed, "errors": errors}
