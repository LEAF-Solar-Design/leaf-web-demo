"""Run one public Kalshi book: python -m leafhft.bookd.main --help."""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import signal
import sys
from pathlib import Path

from ..feeds.kalshi import KalshiFeed, symbol_to_series, uses_fast_index
from .publisher import Publisher


class CredentialError(ValueError):
    """A fixed, public reason only; never include credential contents."""


def load_credentials() -> tuple[str, str]:
    """Read the loader's quoted env-file locally, without changing the environment."""
    directory = os.environ.get("CREDENTIALS_DIRECTORY")
    if not directory:
        raise CredentialError("bookd credential directory missing")
    try:
        with (Path(directory) / "kalshi").open(encoding="utf-8") as stream:
            body = stream.read(65537)
    except (OSError, ValueError):
        raise CredentialError("bookd credential unreadable") from None
    names = {"LEAFHFT_KALSHI_KEY_ID", "LEAFHFT_KALSHI_PRIVATE_KEY_PEM"}
    values = {}
    if len(body) > 65536:
        raise CredentialError("bookd credential malformed")
    for line in body.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        name, separator, raw = line.partition("=")
        name = name.strip()
        if name == "LEAFHFT_LIVE":
            raise CredentialError("bookd trading flag forbidden")
        if not separator or name not in names or name in values:
            raise CredentialError("bookd credential malformed")
        # _quote in populate_runner_secrets emits double-quoted strings with
        # escaped backslashes and quotes. No shell evaluation or interpolation.
        try:
            value = json.loads(raw)
        except ValueError:
            raise CredentialError("bookd credential malformed") from None
        if not isinstance(value, str) or not value.strip() or "\x00" in value:
            raise CredentialError("bookd credential malformed")
        values[name] = value
    if values.keys() != names:
        raise CredentialError("bookd credential names missing")
    return values["LEAFHFT_KALSHI_KEY_ID"], values["LEAFHFT_KALSHI_PRIVATE_KEY_PEM"]


async def run(*, symbol: str, directory: str, build_sha: str, demo: bool = False,
              index_5hz: bool = False) -> None:
    key_id, private_key_pem = load_credentials()
    series, index_ids = symbol_to_series(symbol)
    feed = KalshiFeed(series=series, index_ids=index_ids, demo=demo,
                      index_5hz=uses_fast_index(symbol) or index_5hz,
                      key_id=key_id, private_key_pem=private_key_pem)
    publisher = Publisher(directory, symbol=symbol, series=series[0], index_id=index_ids[0],
                          venue=feed.venue, build_sha=build_sha, feed=feed)
    loop = asyncio.get_running_loop()
    stopped = asyncio.Event()
    installed = []
    waiter = stopper = None
    try:
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, stopped.set)
            installed.append(sig)
        # Bind/refuse uid/path before starting any authenticated upstream work.
        await publisher.start()
        await feed.start()
        waiter = asyncio.create_task(publisher.wait())
        stopper = asyncio.create_task(stopped.wait())
        done, _ = await asyncio.wait((waiter, stopper), return_when=asyncio.FIRST_COMPLETED)
        if waiter in done:
            await waiter
    finally:
        for task in (waiter, stopper):
            if task is not None:
                task.cancel()
        await asyncio.gather(*(task for task in (waiter, stopper) if task is not None),
                             return_exceptions=True)
        await publisher.close()
        await feed.stop()
        for sig in installed:
            loop.remove_signal_handler(sig)


def main() -> None:
    parser = argparse.ArgumentParser(description="Public per-symbol book_stream.v1 publisher")
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--directory", required=True, help="Per-symbol socket and health directory")
    parser.add_argument("--build-sha", required=True)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--index-5hz", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)
    try:
        asyncio.run(run(**vars(args)))
    except CredentialError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(2) from None


if __name__ == "__main__":
    main()
