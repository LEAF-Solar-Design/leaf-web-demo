"""Root-operated desired book sources; no running consumer uses this module."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import time
import uuid


SCHEMA = "leafhft.book-source.v1"
EFFECTIVE_SCHEMA = "leafhft.book-source-effective.v1"
DEFAULT_ROOT = "/etc/leafhft-accounts"
SELECTOR_LIMIT = 65_536
EFFECTIVE_LIMIT = 4_096
LANE_LIMIT = 4_096
TAKES_EFFECT = "at the lane's next start (daily renewal); a running book never changes source"


class SelectorError(ValueError):
    """A closed refusal with a stable, short machine-readable code."""

    def __init__(self, code: str, reason: str):
        self.code = code
        super().__init__(reason)


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise SelectorError("duplicate_key", "duplicate JSON key")
        result[key] = value
    return result


def _constant(value):
    raise SelectorError("json", "non-finite JSON constant")


def _json(data):
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs,
                          parse_constant=_constant)
    except (UnicodeError, ValueError, RecursionError) as exc:
        if isinstance(exc, SelectorError):
            raise
        raise SelectorError("json", "malformed JSON") from exc


def parse_selector(data, lane_id, symbols) -> dict[str, str]:
    """Validate the entire selector before returning shared entries only."""
    if data is None or data == b"off":
        return {}
    if not isinstance(data, bytes):
        raise SelectorError("data", "selector must be bytes")
    if len(data) > SELECTOR_LIMIT:
        raise SelectorError("oversize", "selector exceeds 65536 bytes")
    value = _json(data)
    if not isinstance(value, dict) or set(value) != {"schema", "lane_id", "sources"}:
        raise SelectorError("keys", "selector requires exactly schema, lane_id and sources")
    if value["schema"] != SCHEMA:
        raise SelectorError("schema", "wrong selector schema")
    if value["lane_id"] != lane_id or not isinstance(value["lane_id"], str):
        raise SelectorError("lane_id", "selector belongs to a different lane")
    sources = value["sources"]
    if not isinstance(sources, dict):
        raise SelectorError("sources", "sources must be an object")
    allowed = set(symbols)
    for symbol, source in sources.items():
        if symbol not in allowed:
            raise SelectorError("symbol", "unknown book symbol")
        if not isinstance(source, str) or source not in ("shared", "direct"):
            raise SelectorError("source", "source must be shared or direct")
    return {symbol: "shared" for symbol, source in sources.items() if source == "shared"}


def selector_bytes(lane_id, shared_symbols) -> bytes:
    return json.dumps({"schema": SCHEMA, "lane_id": lane_id,
                       "sources": {symbol: "shared" for symbol in shared_symbols}},
                      sort_keys=True, separators=(",", ":")).encode("utf-8")


def _read(path, limit):
    with Path(path).open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise SelectorError("oversize", "file exceeds size limit")
    return data


def read_effective(state_root, lane_id, symbol, *, pid_alive) -> dict | None:
    """Return a validated live process marker, or unknown for any bad marker."""
    try:
        marker = _json(_read(Path(state_root) / lane_id / "book-source" /
                             f"{symbol}.effective.json", EFFECTIVE_LIMIT))
        if not isinstance(marker, dict) or set(marker) != {
                "build_sha", "pid", "schema", "source", "started_at_ns", "symbol"}:
            return None
        if (marker["schema"] != EFFECTIVE_SCHEMA or marker["symbol"] != symbol
                or not isinstance(marker["build_sha"], str)
                or not isinstance(marker["source"], str)
                or marker["source"] not in ("direct", "shared")
                or type(marker["pid"]) is not int or marker["pid"] <= 0
                or type(marker["started_at_ns"]) is not int
                or marker["started_at_ns"] < 0):
            return None
        return marker if pid_alive(marker["pid"]) else None
    except (OSError, ValueError, RecursionError):
        return None


def pid_alive(pid):
    return (os.name == "posix" and type(pid) is int and pid > 0
            and os.path.exists(f"/proc/{pid}"))


def get_uid():
    """Kept separate so the root guard can be tested on every platform."""
    return os.getuid() if hasattr(os, "getuid") else None


def _lane(root, lane_id):
    if re.fullmatch(r"[A-Za-z0-9-]{1,64}", lane_id) is None:
        raise SelectorError("lane_id", "invalid lane identifier")
    path = Path(root) / lane_id
    if path.is_symlink() or not path.is_dir():
        raise SelectorError("lane_directory", "lane must be an existing non-symlink directory")
    return path


def _selector(path, lane_id, symbols):
    try:
        data = _read(path, SELECTOR_LIMIT)
    except FileNotFoundError:
        # A dangling symlink is not an absent selector we can safely replace.
        if path.is_symlink():
            raise SelectorError("unreadable", "selector is unreadable")
        return {}, "absent"
    except OSError as exc:
        raise SelectorError("unreadable", "selector is unreadable") from exc
    return parse_selector(data, lane_id, symbols), "ok"


def _publisher_live(root, symbol):
    try:
        health = _json(_read(Path(root) / symbol / "health.json", SELECTOR_LIMIT))
        updated = health.get("updated_at_ns") if isinstance(health, dict) else None
        age = time.time_ns() - updated if type(updated) is int else None
        return age is not None and 0 <= age <= 10_000_000_000
    except (OSError, ValueError, RecursionError):
        return False


def _atomic_write(path, data):
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    try:
        with os.fdopen(fd, "wb") as stream:
            if os.name == "posix":
                os.fchmod(stream.fileno(), 0o644)
                if get_uid() == 0:
                    os.fchown(stream.fileno(), 0, 0)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def _set(args, symbols):
    if Path(args.root) == Path(DEFAULT_ROOT) and get_uid() != 0:
        raise SelectorError("uid", "the default root requires uid 0")
    directory = _lane(args.root, args.lane)
    if args.symbol not in symbols:
        raise SelectorError("symbol", "unknown lane book symbol")
    path = directory / "book-source.json"
    desired, status = _selector(path, args.lane, symbols)
    source = args.source if args.command == "set" else "direct"
    force = getattr(args, "force", False)
    if source == "shared" and not force and not _publisher_live(args.bookd_root, args.symbol):
        raise SelectorError("publisher", "publisher health is missing, malformed or older than 10 seconds")
    before = dict(desired)
    if source == "shared":
        desired[args.symbol] = "shared"
    else:
        desired.pop(args.symbol, None)
    changed = desired != before or status == "absent"
    if not getattr(args, "dry_run", False):
        try:
            # Also canonicalize direct input, off, ownership and mode on a no-op.
            _atomic_write(path, selector_bytes(args.lane, desired))
            observed, _ = _selector(path, args.lane, symbols)
            if observed != desired:
                raise SelectorError("readback", "selector readback differs from requested sources")
        except (OSError, SelectorError) as exc:
            _print({"ok": False, "refusal": "readback", "reason": str(exc)})
            return 1
    output = {"ok": True, "lane_id": args.lane, "desired": desired,
              "changed": changed, "takes_effect": TAKES_EFFECT}
    if force:
        output["force"] = True
    _print(output)
    return 0


def _list(args, symbols, alive):
    if args.lane is not None:
        directories = [_lane(args.root, args.lane)]
    else:
        directories = []
        with os.scandir(args.root) as entries:
            for count, entry in enumerate(entries, 1):
                if count > LANE_LIMIT:
                    raise SelectorError("lane_limit", "lane listing exceeds 4096 entries")
                if not entry.is_symlink() and entry.is_dir(follow_symlinks=False):
                    directories.append(Path(entry.path))
        directories.sort(key=lambda path: path.name)
    lanes = []
    failed = False
    for directory in directories:
        lane_id = directory.name
        try:
            _lane(args.root, lane_id)
            desired, status = _selector(directory / "book-source.json", lane_id, symbols)
        except SelectorError as exc:
            desired, status = {}, f"error:{exc.code}"
            failed = True
        books = []
        for symbol in sorted(symbols):
            marker = read_effective(args.state_root, lane_id, symbol, pid_alive=alive)
            effective = marker["source"] if marker else "unknown"
            source = desired.get(symbol, "direct")
            books.append({"symbol": symbol, "desired": source, "effective": effective,
                          "pending": effective != "unknown" and effective != source,
                          "pid": marker["pid"] if marker else None,
                          "started_at_ns": marker["started_at_ns"] if marker else None})
        lanes.append({"lane_id": lane_id, "selector": status, "books": books})
    _print({"lanes": lanes})
    return int(failed)


def _print(value):
    print(json.dumps(value, separators=(",", ":"), sort_keys=True))


class _Parser(argparse.ArgumentParser):
    def error(self, message):
        raise SelectorError("arguments", message)


def main(argv=None, *, symbols=None, pid_alive=None):
    """CLI entry point; tests supply a catalog and a process liveness probe."""
    parser = _Parser(description=__doc__)

    def common(target, defaults):
        for flag, default in (("--root", DEFAULT_ROOT),
                              ("--state-root", "/var/lib/leafhft-accounts"),
                              ("--bookd-root", "/run/leafhft-bookd")):
            target.add_argument(flag, default=default if defaults else argparse.SUPPRESS)

    common(parser, True)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("set", "clear", "list"):
        command = commands.add_parser(name)
        common(command, False)
        command.add_argument("--lane", required=name != "list")
        if name != "list":
            command.add_argument("--symbol", required=True)
        if name == "set":
            command.add_argument("--source", required=True, choices=("shared", "direct"))
            command.add_argument("--force", action="store_true")
            command.add_argument("--dry-run", action="store_true")
    try:
        args = parser.parse_args(argv)
        if symbols is None:
            from leafhft.account_lane_agent import canonical_symbols

            symbols = canonical_symbols()
        symbols = tuple(symbols)
        if args.command == "list":
            return _list(args, symbols, pid_alive or globals()["pid_alive"])
        return _set(args, symbols)
    except SelectorError as exc:
        _print({"ok": False, "refusal": exc.code, "reason": str(exc)})
        return 1 if 'args' in locals() and args.command == "list" else 2
    except OSError:
        _print({"ok": False, "refusal": "io", "reason": "filesystem operation failed"})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
