"""book_stream.v1: bounded newline-delimited JSON containing public data only.

Every server frame has ``v``, ``kind`` and ``n``. Snapshot boundaries sb/se
carry a cutover watermark; cached snapshot records have n=0. After se every
live frame advances by exactly one. Event ``seq`` is the feed sequence, not n.
Versions 1 and 2 currently use the same schema, permitting rolling upgrades.
Client negotiation is a separate, bounded ``{kind: hello, versions: [1]}``.
All fields, including nullable event fields, are mandatory. Schemas are explicit:
adding an account or execution field to a Python type cannot put it on the wire.
"""
from __future__ import annotations

import json
from typing import Mapping

from ..feeds.base import IndexTick, IndexTickFast, Lifecycle
from ..types import MalformedInput, Quote, Side, Trade

PROTOCOL = "book_stream.v1"
MAX_FRAME_BYTES = 4096
MAX_HELLO_BYTES = 512
SUPPORTED_VERSIONS = (1, 2)


class ProtocolError(ValueError):
    """Invalid or unsupported public stream frame."""


# Validator tokens: integer, nullable integer, string, nullable string, boolean,
# and version list. Exact types exclude bool masquerading as an integer.
SCHEMAS = {
    "q": dict(venue="s", symbol="s", bid_i="i", bid_size_i="i", ask_i="i",
              ask_size_i="i", ts_exch_ns="i", ts_recv_ns="i", seq="i",
              ts_arrival_ns="i?", ts_venue_ns="i?"),
    "t": dict(venue="s", symbol="s", price_i="i", size_i="i", side="side",
              ts_exch_ns="i", ts_recv_ns="i", seq="i", trade_id="s?"),
    "l": dict(ticker="s", status="s", close_time_ms="i", expiration_time_ms="i",
              strike_i="i", strike_type="s", open_time_ms="i", ts_recv_ns="i?"),
    "i": dict(index_id="s", value_i="i", source_ts_ms="i", received_at_ms="i",
              local_ns="i", avg60_value_i="i?", avg60_window_size="i?",
              avg60_window_start_ms="i?"),
    "i5": dict(venue="s", index_id="s", value_i="i", source_ts_ms="i",
               received_at_ms="i", ts_recv_ns="i", seq="i"),
    "hello": dict(versions="versions", epoch="s", pid="i", build_sha="s",
                  symbol="s", series="s", index_id="s", venue="s"),
    "sb": {},
    "se": {},
    "bs": dict(ticker="s", ready="b"),
    "hb": dict(upstream_connected="b", upstream_age_ms="i?", seq_gaps="i",
               resnapshots="i", reconnects="i", dropped="i", build_sha="s"),
    "bye": dict(reason="s"),
}
EVENT_TYPES = {"q": Quote, "t": Trade, "l": Lifecycle, "i": IndexTick, "i5": IndexTickFast}
EVENT_KINDS = {cls: kind for kind, cls in EVENT_TYPES.items()}


def _value(value, token: str) -> bool:
    if token.endswith("?"):
        return value is None or _value(value, token[:-1])
    if token == "i":
        return type(value) is int and 0 <= value <= 2**63 - 1
    if token == "s":
        return type(value) is str and len(value) <= 256 and all(ord(c) >= 32 for c in value)
    if token == "b":
        return type(value) is bool
    if token == "side":
        return type(value) is int and value in (-1, 1)
    if token == "versions":
        return (type(value) is list and 1 <= len(value) <= 2
                and all(type(v) is int and v in SUPPORTED_VERSIONS for v in value)
                and len(set(value)) == len(value))
    return False


def _event(frame: Mapping):
    kind = frame["kind"]
    values = {key: frame[key] for key in SCHEMAS[kind]}
    if kind == "t":
        values["side"] = Side(values["side"])
    try:
        return EVENT_TYPES[kind](**values)
    except (MalformedInput, TypeError, ValueError) as exc:
        raise ProtocolError("invalid public event") from exc


def validate(frame: Mapping) -> None:
    if not isinstance(frame, Mapping):
        raise ProtocolError("frame must be an object")
    kind = frame.get("kind")
    if type(kind) is not str or kind not in SCHEMAS:
        raise ProtocolError("unknown kind")
    if set(frame) != {"v", "kind", "n"} | set(SCHEMAS[kind]):
        raise ProtocolError("missing or extra field")
    if type(frame["v"]) is not int or frame["v"] not in SUPPORTED_VERSIONS:
        raise ProtocolError("unsupported version")
    if not _value(frame["n"], "i"):
        raise ProtocolError("invalid sequence")
    for key, token in SCHEMAS[kind].items():
        if not _value(frame[key], token):
            raise ProtocolError(f"invalid {key}")
    if kind in EVENT_TYPES:
        _event(frame)
    if kind == "hello":
        if frame["v"] not in frame["versions"] or frame["pid"] == 0:
            raise ProtocolError("invalid hello version or pid")
        if any(not frame[k] for k in ("epoch", "build_sha", "symbol", "series", "index_id", "venue")):
            raise ProtocolError("missing stream identity")
    if kind == "bs" and not frame["ticker"]:
        raise ProtocolError("empty ticker")
    if kind == "bye" and frame["reason"] not in {
        "slow_consumer", "client_limit", "rate_limit", "bad_hello", "version", "shutdown"
    }:
        raise ProtocolError("unknown bye reason")


def encode(frame: Mapping) -> bytes:
    """Validate an exact allowlisted frame and append its newline delimiter."""
    validate(frame)
    raw = json.dumps(dict(frame), separators=(",", ":"), ensure_ascii=True,
                     allow_nan=False).encode("ascii") + b"\n"
    if len(raw) > MAX_FRAME_BYTES:
        raise ProtocolError("frame too large")
    return raw


def _pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ProtocolError("duplicate field")
        out[key] = value
    return out


def _load(raw: bytes, limit: int):
    if type(raw) is not bytes or len(raw) > limit or not raw:
        raise ProtocolError("invalid frame size or type")
    try:
        return json.loads(raw, object_pairs_hook=_pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ProtocolError("nonfinite value")))
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ProtocolError("invalid JSON") from exc


def decode(raw: bytes) -> dict:
    frame = _load(raw, MAX_FRAME_BYTES)
    validate(frame)
    return frame


def event_frame(event, n: int, version: int = 1) -> dict:
    kind = EVENT_KINDS.get(type(event))
    if kind is None:
        raise ProtocolError("not a public event")
    frame = {"v": version, "kind": kind, "n": n}
    frame.update({key: getattr(event, key) for key in SCHEMAS[kind]})
    if kind == "t":
        frame["side"] = int(event.side)
    return frame


def encode_event(event, n: int = 0, version: int = 1) -> bytes:
    return encode(event_frame(event, n, version))


def decode_event(raw: bytes):
    frame = decode(raw)
    if frame["kind"] not in EVENT_TYPES:
        raise ProtocolError("not an event frame")
    return _event(frame)


def encode_client_hello(versions=(1,)) -> bytes:
    frame = {"kind": "hello", "versions": list(versions)}
    raw = json.dumps(frame, separators=(",", ":")).encode("ascii") + b"\n"
    decode_client_hello(raw)
    return raw


def decode_client_hello(raw: bytes) -> list[int]:
    frame = _load(raw, MAX_HELLO_BYTES)
    if (type(frame) is not dict or set(frame) != {"kind", "versions"}
            or frame["kind"] != "hello" or not _value(frame["versions"], "versions")):
        raise ProtocolError("invalid client hello")
    return frame["versions"]
