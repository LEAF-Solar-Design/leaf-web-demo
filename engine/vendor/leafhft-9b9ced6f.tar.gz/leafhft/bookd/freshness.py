"""Process-local send claims, bound to the source selected at feed construction.

Factories can call bind_source(symbol, "direct") or expect_shared(symbol) before
constructing a feed. A shared binding is never disabled by a later config edit,
feed shutdown, or lost registration. Reader health and consumer lag are distinct.
"""
from __future__ import annotations

import json
import os
import re
import time
from collections import Counter, deque
from dataclasses import dataclass
from pathlib import Path

SHARED_OFF = Path("/etc/leafhft-bookd/SHARED_OFF")
HEARTBEAT_S = 2.0
UPSTREAM_S = 10.0
INDEX_S = 10.0
WATERMARK_S = 5.0
SOURCE_ENV = "LEAFHFT_BOOK_SOURCE"


class Freshness:
    def __init__(self, symbol: str, series: str, *, index_max_age_s: float = INDEX_S,
                 state_dir: str | Path | None = None, clock=time.monotonic):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", symbol):
            raise ValueError("invalid book symbol")
        if not 0 < index_max_age_s <= INDEX_S:
            raise ValueError("index freshness bound must be in (0, 10]")
        self.symbol, self.series = symbol, series
        self.index_max_age_s = index_max_age_s
        self.clock = clock
        self.path = Path(state_dir or os.environ.get("LEAFHFT_STATE_DIR", "state")) / "book-source" / (symbol + ".json")
        self.connected = False
        self.stale_reason = "disconnected"
        self.heartbeat_at: float | None = None
        self.upstream_age_s: float | None = None
        self.index_at: float | None = None
        self.ready: set[str] = set()
        self.pending: deque[tuple[int, float]] = deque()
        self.reader_head = 0
        self.consumer_head = 0
        self.generation = 0
        self.consumer_generation = -1
        self.claims_checked = 0
        self.refusals_by_reason: Counter = Counter()
        self._published_at = float("-inf")

    def stale(self, reason: str) -> None:
        self.stale_reason = reason

    def begin_snapshot(self) -> None:
        self.generation += 1
        self.ready.clear()
        self.index_at = None
        self.stale("snapshot")

    def queued(self) -> int:
        self.reader_head += 1
        self.pending.append((self.reader_head, self.clock()))
        return self.reader_head

    def applied(self, head: int) -> None:
        self.consumer_head = max(self.consumer_head, head)
        while self.pending and self.pending[0][0] <= head:
            self.pending.popleft()

    def consumer_lag_s(self) -> float:
        return max(0.0, self.clock() - self.pending[0][1]) if self.pending else 0.0

    def reason(self, ticker: str) -> str | None:
        now = self.clock()
        if self.stale_reason:
            return self.stale_reason
        if not self.connected:
            return "disconnected"
        if self.heartbeat_at is None:
            return "heartbeat"  # Await the first hb; the reader bounds that wait to 2 s.
        if now - self.heartbeat_at > HEARTBEAT_S:
            self.stale("heartbeat")
            return self.stale_reason
        if self.upstream_age_s is None or self.upstream_age_s + now - self.heartbeat_at > UPSTREAM_S:
            self.stale("upstream_age")
            return self.stale_reason
        if ticker not in self.ready:
            return "ticker_not_ready"
        if self.index_at is None or now - self.index_at > self.index_max_age_s:
            return "index_stale"
        if self.consumer_generation != self.generation:
            return "consumer_snapshot"
        if self.consumer_lag_s() > WATERMARK_S:
            return "consumer_lag"
        return None

    def publish(self) -> None:
        """Best-effort, at most one state write per second; never masks a refusal."""
        now = self.clock()
        if now - self._published_at < 1.0:
            return
        self._published_at = now
        payload = {"symbol": self.symbol, "source": "shared", "connected": self.connected,
                   "stale_reason": self.stale_reason, "claims_checked": self.claims_checked,
                   "refusals_by_reason": dict(self.refusals_by_reason),
                   "consumer_lag_s": self.consumer_lag_s(), "reader_head": self.reader_head,
                   "consumer_head": self.consumer_head, "updated_at_ns": time.time_ns()}
        temporary = self.path.with_suffix(f".{os.getpid()}.tmp")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
            os.replace(temporary, self.path)
        except OSError:
            pass


@dataclass(frozen=True)
class SourceBinding:
    source: str
    freshness: Freshness | None = None


_sources: dict[str, SourceBinding] = {}


def bind_source(symbol: str, source: str) -> SourceBinding:
    """Pin a factory's effective choice. Reconfiguration requires a new process."""
    if source not in ("direct", "shared"):
        raise ValueError("book source must be direct or shared")
    previous = _sources.get(symbol)
    if previous is not None:
        if previous.source != source:
            raise ValueError("book source already bound")
        return previous
    binding = SourceBinding(source)
    _sources[symbol] = binding
    return binding


def expect_shared(symbol: str) -> SourceBinding:
    return bind_source(symbol, "shared")


def pin_configured_source(symbol: str) -> None:
    """Adapter startup fallback; an effective factory binding always takes precedence."""
    if symbol not in _sources and os.environ.get(SOURCE_ENV, "") not in ("", "direct"):
        expect_shared(symbol)


def register_shared(state: Freshness) -> None:
    binding = expect_shared(state.symbol)
    if binding.freshness is not None and binding.freshness is not state:
        raise ValueError("shared feed already registered")
    _sources[state.symbol] = SourceBinding("shared", state)


def _refuse(reason: str) -> None:
    # This adapter-only code deliberately does not enlarge account_risk's ledger codes.
    from ..broker.account_risk import AccountRiskRefused

    exc = AccountRiskRefused("shared book refused: " + reason, code="domain_not_exposure_authority")
    exc.code = "book_stale"
    raise exc


def require_fresh(ticker: str, *, symbol: str | None = None) -> None:
    """Synchronous send fence. No await may separate this from the write claim."""
    binding = _sources.get(symbol) if symbol is not None else None
    if symbol is None:
        shared = [b for b in _sources.values() if b.source == "shared"]
        matches = [b for b in shared if b.freshness is not None
                   and ticker.startswith(b.freshness.series + "-")]
        if len(matches) == 1:
            binding = matches[0]
        elif shared:
            _refuse("unknown ticker")
    if binding is None:
        source = os.environ.get(SOURCE_ENV, "")
        if source in ("", "direct"):
            return
        if symbol is not None:
            binding = expect_shared(symbol)
        else:
            _refuse("shared feed not registered")
    if binding.source == "direct":
        return
    state = binding.freshness
    if state is None:
        _refuse("shared feed not registered")
    state.claims_checked += 1
    try:
        disabled = SHARED_OFF.lstat() is not None
    except FileNotFoundError:
        disabled = False
    except OSError:
        disabled = True
    reason = "shared_off" if disabled else state.reason(ticker)
    if reason:
        state.refusals_by_reason[reason] += 1
    state.publish()
    if reason:
        _refuse(reason)
