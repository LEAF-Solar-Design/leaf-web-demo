"""Compare a recorder run with one public book socket, without execution imports.

Run ``python -m leafhft.bookd.compare --tape RUN --socket DIR/book.sock`` while
the shadow recorder is running. Receipt clocks must share the host wall clock.
Quote prices must fall within the socket's 500 ms envelope; lifecycle fields
actually recorded and index values must converge within 250 ms. Continuous quote
disagreement and median size scale drift are bounded separately.
Transport/feed sequence numbers and clocks need not match.
The CLI compares only the capture interval, reading all rotated tape parts after
capture. Malformed input, transport gaps, and an empty comparison fail closed.
"""
from __future__ import annotations

import argparse
import asyncio
import bisect
import contextlib
import json
import math
import time
from collections import defaultdict
from pathlib import Path

from ..feeds.tape_parts import tape_parts
from .stream import MAX_FRAME_BYTES, ProtocolError, decode, encode_client_hello

CONVERGENCE_NS = 250_000_000
MISSING_NS = 5_000_000_000
MAX_CAPTURE_FRAMES = 1_000_000
MAX_SIZE_CANDIDATES = 4096
STATE_FIELDS = {
    "q": ("venue", "symbol", "bid_i", "bid_size_i", "ask_i", "ask_size_i"),
    "l": ("ticker", "status", "close_time_ms", "expiration_time_ms", "strike_i",
          "strike_type", "open_time_ms"),
    "i": ("index_id", "value_i", "source_ts_ms", "avg60_value_i",
          "avg60_window_size", "avg60_window_start_ms"),
    "i5": ("index_id", "value_i", "source_ts_ms"),
}


def tape_row(row: dict) -> dict | None:
    """Normalize recorder rows, retaining absent optional lifecycle/index fields."""
    kind = row.get("t")
    if kind in ("x", "t"):
        return None  # trades are not persistent book state
    if kind == "q":
        fields = dict(zip(STATE_FIELDS["q"], (row[k] for k in ("v", "s", "b", "bs", "a", "as"))))
        stamp = row["tr"]
    elif kind in ("l", "i", "i5"):
        fields = {key: row[key] for key in STATE_FIELDS[kind] if key in row}
        required = STATE_FIELDS[kind][:5] if kind == "l" else STATE_FIELDS[kind][:3]
        if any(key not in fields for key in required):
            raise ValueError("missing tape state field")
        stamp = row.get("local_ns", row.get("ts_recv_ns"))
    else:
        raise ValueError(f"unknown tape kind {kind!r}")
    if type(stamp) is not int or stamp < 0:
        raise ValueError("invalid tape receipt clock")
    text_fields = {"venue", "symbol", "ticker", "status", "index_id", "strike_type"}
    for key, value in fields.items():
        if key in text_fields:
            if type(value) is not str or (not value and key != "strike_type"):
                raise ValueError(f"invalid tape {key}")
        elif value is not None or not key.startswith("avg60_"):
            if type(value) is not int or value < 0:
                raise ValueError(f"invalid tape {key}")
    return {"kind": kind, "observed_ns": stamp, **fields}


def read_tape(path: str | Path):
    """Fail on corrupt lines; never silently raise the apparent match rate."""
    parts = tape_parts(path)
    if not parts:
        raise ValueError("no tape parts")
    for part in parts:
        with part.open("rb") as handle:
            number = 0
            while raw := handle.readline(MAX_FRAME_BYTES + 1):
                number += 1
                try:
                    if len(raw) > MAX_FRAME_BYTES or not raw.endswith(b"\n"):
                        raise ValueError("oversize or incomplete tape line")
                    row = json.loads(raw)
                    if not isinstance(row, dict):
                        raise ValueError("non-object tape row")
                    normalized = tape_row(row)
                except (ValueError, KeyError, TypeError) as exc:
                    raise ValueError(f"{part.name}:{number}: {exc}") from exc
                if normalized is not None:
                    yield normalized


def _key(row):
    if row["kind"] == "q":
        return "q", row["symbol"], row["venue"]
    return row["kind"], row.get("symbol", row.get("ticker", row.get("index_id")))


def compare(expected, observed, *, min_match=0.97, start_ns=None, end_ns=None,
            sample_limit=10, window_ns=500_000_000, max_mismatch_run_ms=2000.0,
            max_size_ratio_drift=0.05) -> dict:
    """Compare time-indexed state observations; independent of wire ordering.

    A socket quote is in force until the next quote or bs row for its ticker.
    ``deltas_per_quote`` is socket quote updates / recorded quote observations.
    Missing tickers list outages longer than five seconds (including recoveries).
    Size diagnostics use exact price candidates; scale uses the quote at t.
    Percentiles use nearest rank. Interval overlap work is bounded per quote.
    """
    if not math.isfinite(min_match) or not 0 <= min_match <= 1:
        raise ValueError("min_match must be in [0, 1]")
    if not math.isfinite(window_ns) or not 1_000_000 <= window_ns <= 5_000_000_000:
        raise ValueError("window_ns must be in [1000000, 5000000000]")
    for name, bound in (("max_mismatch_run_ms", max_mismatch_run_ms),
                        ("max_size_ratio_drift", max_size_ratio_drift)):
        if not math.isfinite(bound) or bound < 0:
            raise ValueError(f"{name} must be finite and nonnegative")
    if start_ns is not None and (end_ns is None or end_ns < start_ns):
        raise ValueError("capture interval requires end_ns >= start_ns")
    expected = [r for r in expected if start_ns is None or
                start_ns <= r["observed_ns"] <= end_ns]
    observed = list(observed)
    hello = next((r for r in observed if r["kind"] == "hello"), None)
    foreign_lifecycle_ignored = 0
    if hello is not None and hello["venue"] == "kalshi":
        prefix = hello["series"] + "-"
        foreign_lifecycle_ignored = sum(r["kind"] == "l" and
                                        not r["ticker"].startswith(prefix) for r in expected)
        expected = [r for r in expected if r["kind"] != "l" or
                    r["ticker"].startswith(prefix)]
    index_5hz_missing = (any(r["kind"] == "i5" for r in expected) and
                         not any(r["kind"] == "i5" for r in observed))
    times = [r["observed_ns"] for r in expected]
    start = start_ns if start_ns is not None else min(times, default=0)
    end = end_ns if end_ns is not None else max(times, default=start)
    indexed = defaultdict(list)
    invalidations = defaultdict(list)
    quote_updates = defaultdict(list)
    for row in observed:
        if row["kind"] in STATE_FIELDS:
            indexed[_key(row)].append(row)
        if row["kind"] == "q":
            quote_updates[row["symbol"]].append(row)
        elif row["kind"] == "bs":
            quote_updates[row["ticker"]].append(row)
            invalidations[row["ticker"]].append(row)
    for key, rows in indexed.items():
        if key[0] == "q":
            rows.extend(r for r in invalidations[key[1]] if not r["ready"])
        rows.sort(key=lambda r: r["observed_ns"])
    for rows in quote_updates.values():
        rows.sort(key=lambda r: r["observed_ns"])
    quote_intervals = {}
    final_quote_keys = set()
    capture_end = max(end, max((r["observed_ns"] for r in observed
                                if r["kind"] in STATE_FIELDS or r["kind"] == "bs"),
                               default=end))
    for key, rows in indexed.items():
        if key[0] == "q":
            rows = sorted([r for r in rows if r["kind"] == "q"] + invalidations[key[1]],
                          key=lambda r: r["observed_ns"])
            if rows[-1]["kind"] == "q":
                final_quote_keys.add(key)
            intervals = [(r["observed_ns"],
                          rows[i + 1]["observed_ns"] if i + 1 < len(rows) else capture_end, r)
                         for i, r in enumerate(rows) if r["kind"] == "q"]
            quote_intervals[key] = ([p[0] for p in intervals], [p[1] for p in intervals],
                                    [p[2] for p in intervals])
    # Group once by expected field shape: older tapes omit fields the socket knows.
    signatures = {}
    matched = 0
    diffs = {"l": 0, "i": 0, "i5": 0}
    samples = []
    size_relative = []
    size_exact = 0
    exact_quotes = 0
    size_ratios = []
    quote_results = defaultdict(list)
    for row in expected:
        key = _key(row)
        fields = tuple(k for k in STATE_FIELDS[row["kind"]] if k in row and
                       (row["kind"] != "q" or k not in ("bid_size_i", "ask_size_i")))
        shape = key, fields
        if shape not in signatures:
            table = defaultdict(list)
            rows = indexed[key]
            for i, other in enumerate(rows):
                if other["kind"] == "bs":
                    continue
                until = rows[i + 1]["observed_ns"] if i + 1 < len(rows) else math.inf
                table[tuple(other.get(k) for k in fields)].append((other["observed_ns"], until, other))
            table = {signature: ([p[0] for p in intervals], [p[1] for p in intervals],
                                 [p[2] for p in intervals])
                     for signature, intervals in table.items()}
            signatures[shape] = table
        stamps, ends, candidates = signatures[shape].get(tuple(row[k] for k in fields), ((), (), ()))
        t = row["observed_ns"]
        pos = bisect.bisect_right(stamps, t + CONVERGENCE_NS) - 1
        ok = pos >= 0 and ends[pos] >= t - CONVERGENCE_NS
        if row["kind"] == "q":
            exact_quotes += int(ok)
            starts, stops, quotes = quote_intervals.get(key, ((), (), ()))
            lo = bisect.bisect_left(stops, t - window_ns)
            hi = bisect.bisect_right(starts, t + window_ns)
            # Bisect once-built interval arrays, never scan the capture per quote.
            # Fail closed before slicing: MAX_SIZE_CANDIDATES bounds all overlap work.
            if hi - lo > MAX_SIZE_CANDIDATES:
                raise ValueError("quote convergence candidate limit exceeded")
            overlap = quotes[lo:hi]
            ok = bool(overlap) and all(min(q[side] for q in overlap) <= row[side] <=
                                       max(q[side] for q in overlap)
                                       for side in ("bid_i", "ask_i"))
            quote_results[row["symbol"]].append((t, ok))
            same_price = [q for q in overlap if (q["bid_i"], q["ask_i"]) ==
                          (row["bid_i"], row["ask_i"])]
            if ok and same_price:
                relative = min(max(abs(q[side] - row[side]) / max(row[side], 1)
                                   for side in ("bid_size_i", "ask_size_i"))
                               for q in same_price)
                size_relative.append(relative)
                size_exact += int(relative == 0)
            at = bisect.bisect_right(starts, t) - 1
            if at >= 0 and (stops[at] > t or
                            (t == capture_end and at == len(quotes) - 1 and
                             key in final_quote_keys)):
                q = quotes[at]
                if (q["bid_i"], q["ask_i"]) == (row["bid_i"], row["ask_i"]):
                    size_ratios.extend(q[side] / row[side]
                                       for side in ("bid_size_i", "ask_size_i")
                                       if q[side] > 0 and row[side] > 0)
        matched += int(ok)
        if not ok and row["kind"] in diffs:
            diffs[row["kind"]] += 1
        if len(samples) < sample_limit:
            samples.append({"kind": key[0], "identity": key[1], "matched": ok,
                            "receipt_ns": t})
    first = {}
    last = {}
    for row in expected:
        if row["kind"] == "q":
            first[row["symbol"]] = min(first.get(row["symbol"], row["observed_ns"]),
                                       row["observed_ns"])
            last[row["symbol"]] = max(last.get(row["symbol"], row["observed_ns"]),
                                      row["observed_ns"])
    missing = []
    for ticker, stamp in sorted(first.items()):
        last_tape = last[ticker]
        absent_since = max(start, stamp)
        outage = 0
        updates = quote_updates[ticker]
        for update in updates:
            t = min(end, update["observed_ns"])
            if update["observed_ns"] > end:
                break
            if update["kind"] == "q":
                if absent_since is not None:
                    outage = max(outage, min(t, last_tape) - absent_since)
                absent_since = None
            elif not update["ready"] and absent_since is None:
                absent_since = max(start, t)
        if absent_since is not None:
            outage = max(outage, min(end, last_tape) - absent_since)
        if outage > MISSING_NS:
            missing.append(ticker)
    count = len(expected)
    quote_count = sum(r["kind"] == "q" for r in expected)
    rate = matched / count if count else 0.0
    size_relative.sort()
    size_count = len(size_relative)
    size_rel_p50 = size_relative[math.ceil(0.5 * size_count) - 1] if size_count else 0.0
    size_rel_p90 = size_relative[math.ceil(0.9 * size_count) - 1] if size_count else 0.0
    longest_run = 0
    for results in quote_results.values():
        run_start = None
        for t, ok in sorted(results, key=lambda result: result[0]):
            if ok:
                run_start = None
            else:
                if run_start is None:
                    run_start = t
                longest_run = max(longest_run, t - run_start)
    longest_mismatch_run_ms = longest_run / 1_000_000
    size_ratios.sort()
    ratio_count = len(size_ratios)
    ratio = size_ratios[math.ceil(0.5 * ratio_count) - 1] if ratio_count >= 20 else None
    ratio_ok = ratio is None or 1 / (1 + max_size_ratio_drift) <= ratio <= 1 + max_size_ratio_drift
    return {"samples": samples, "matched": matched, "total": count,
            "match_rate": rate, "missing_tickers": missing,
            "foreign_lifecycle_ignored": foreign_lifecycle_ignored,
            "index_5hz_missing": index_5hz_missing,
            "size_exact_rate": size_exact / size_count if size_count else 0.0,
            "size_rel_p50": size_rel_p50, "size_rel_p90": size_rel_p90,
            "exact_rate": exact_quotes / quote_count if quote_count else 0.0,
            "longest_mismatch_run_ms": longest_mismatch_run_ms,
            "size_ratio_p50": ratio, "size_ratio_samples": ratio_count,
            "lifecycle_diff": diffs["l"], "index_diff": diffs["i"] + diffs["i5"],
            "deltas_per_quote": (sum(r["kind"] == "q" for r in observed) / quote_count
                                 if quote_count else 0.0),
            "passed": bool(count and rate >= min_match and not missing and
                           not index_5hz_missing and
                           longest_mismatch_run_ms <= max_mismatch_run_ms and ratio_ok)}


async def capture(socket_path, seconds, window_ns=500_000_000):
    """Read one bounded, negotiated socket; sequence errors are divergences."""
    reader, writer = await asyncio.wait_for(
        asyncio.open_unix_connection(str(socket_path), limit=MAX_FRAME_BYTES), 2)
    rows = []
    start = time.time_ns()
    end = start + int(seconds * 1_000_000_000)
    # The final expected state gets the same convergence allowance as the first.
    deadline = asyncio.get_running_loop().time() + seconds + max(CONVERGENCE_NS, window_ns) / 1e9
    phase, watermark, version = "hello", None, None
    try:
        writer.write(encode_client_hello())
        await writer.drain()
        while True:
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                break
            try:
                raw = await asyncio.wait_for(reader.readline(), remaining)
            except asyncio.TimeoutError:
                break
            if not raw:
                raise ProtocolError("socket closed during comparison")
            frame = decode(raw)
            kind = frame["kind"]
            if kind == "bye":
                raise ProtocolError(f"socket refused: {frame['reason']}")
            if phase == "hello":
                if kind != "hello":
                    raise ProtocolError("missing server hello")
                version = frame["v"]
                phase = "sb"
            elif frame["v"] != version:
                raise ProtocolError("stream version changed")
            elif phase == "sb":
                if kind != "sb":
                    raise ProtocolError("missing snapshot start")
                watermark = frame["n"]
                phase = "snapshot"
            elif phase == "snapshot":
                if kind == "se":
                    if frame["n"] != watermark:
                        raise ProtocolError("snapshot watermark changed")
                    phase = "live"
                elif kind not in (*STATE_FIELDS, "bs") or frame["n"] != 0:
                    raise ProtocolError("invalid snapshot record")
            else:
                if kind in ("hello", "sb", "se") or frame["n"] != watermark + 1:
                    raise ProtocolError("live sequence gap")
                watermark = frame["n"]
            if kind in (*STATE_FIELDS, "bs", "hello"):
                rows.append({**frame, "observed_ns": time.time_ns()})
                if len(rows) > MAX_CAPTURE_FRAMES:
                    raise ProtocolError("capture frame limit exceeded")
        if phase != "live":
            raise ProtocolError("incomplete snapshot")
        return rows, start, end
    finally:
        writer.close()
        with contextlib.suppress(OSError):
            await writer.wait_closed()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tape", required=True, type=Path)
    parser.add_argument("--socket", required=True, type=Path)
    parser.add_argument("--seconds", type=float, default=10.0)
    parser.add_argument("--min-match", type=float, default=0.97)
    parser.add_argument("--window-ms", type=float, default=500)
    parser.add_argument("--max-mismatch-run-ms", type=float, default=2000.0)
    parser.add_argument("--max-size-ratio-drift", type=float, default=0.05)
    args = parser.parse_args(argv)
    if not math.isfinite(args.seconds) or args.seconds <= 0:
        parser.error("--seconds must be finite and positive")
    if not math.isfinite(args.min_match) or not 0 <= args.min_match <= 1:
        parser.error("--min-match must be in [0, 1]")
    if not math.isfinite(args.window_ms) or not 1 <= args.window_ms <= 5000:
        parser.error("--window-ms must be in [1, 5000]")
    for name in ("max_mismatch_run_ms", "max_size_ratio_drift"):
        if not math.isfinite(getattr(args, name)) or getattr(args, name) < 0:
            parser.error(f"--{name.replace('_', '-')} must be finite and nonnegative")
    try:
        window_ns = int(args.window_ms * 1_000_000)
        rows, start, end = asyncio.run(capture(args.socket, args.seconds, window_ns))
        report = compare(read_tape(args.tape), rows, min_match=args.min_match,
                         start_ns=start, end_ns=end, window_ns=window_ns,
                         max_mismatch_run_ms=args.max_mismatch_run_ms,
                         max_size_ratio_drift=args.max_size_ratio_drift)
    except (OSError, ValueError, KeyError, TypeError, asyncio.TimeoutError) as exc:
        print(json.dumps({"passed": False, "error": str(exc)}))
        return 1
    print(json.dumps(report, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
