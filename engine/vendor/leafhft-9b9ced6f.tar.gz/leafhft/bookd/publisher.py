"""One Linux AF_UNIX publisher per symbol, with bounded nonblocking fanout.

All mutations run on one asyncio selector loop. A handshake never awaits a
snapshot: immutable encoded snapshot records are shared between clients. Only
sb/se carry the cutover watermark; cached snapshot records have n=0. An epoch
change requires a new snapshot. An upstream gap invalidates its cached quote.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import socket
import stat
import struct
import sys
import tempfile
import time
import uuid
from collections import OrderedDict, deque
from dataclasses import dataclass, field
from pathlib import Path

from ..feeds.base import IndexTick, IndexTickFast, Lifecycle
from ..types import Quote, Trade
from .stream import (
    MAX_FRAME_BYTES, MAX_HELLO_BYTES, ProtocolError, decode_client_hello,
    encode, event_frame,
)

MAX_CLIENT_BYTES = 1 << 20
MAX_CLIENT_FRAMES = 1024
MAX_CLIENTS = 64
MAX_TENANT_CLIENTS = 2
MAX_OWNER_CLIENTS = 8
CONNECT_BURST = 4
CONNECT_RATE = 1.0
MAX_UID_BUCKETS = 4096
HELLO_TIMEOUT_S = 1.0
HEARTBEAT_S = 0.5
POLL_S = 0.01
ACCEPT_BUDGET = 16
WRITE_BUDGET = 64 * 1024
MAX_SNAPSHOT_RECORDS = 512
LOG = logging.getLogger(__name__)


def process_uid() -> int:
    return os.geteuid()


def peer_uid(sock: socket.socket) -> int:
    """Kernel credentials, never a client-supplied account/tenant identifier."""
    return struct.unpack("3i", sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))[1]


def sd_notify(message: str) -> None:
    address = os.environ.get("NOTIFY_SOCKET")
    if not address:
        return
    if address.startswith("@"):
        address = "\0" + address[1:]
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as sock:
            sock.setblocking(False)
            sock.sendto(message.encode("ascii"), address)
    except OSError:
        LOG.warning("bookd supervisor notification failed")


@dataclass(eq=False)
class Client:
    sock: socket.socket
    uid: int
    version: int | None = None
    incoming: bytearray = field(default_factory=bytearray)
    queue: deque[bytes] = field(default_factory=deque)
    queued_bytes: int = 0
    offset: int = 0
    timeout: asyncio.TimerHandle | None = None
    closing: bool = False


class Publisher:
    def __init__(self, directory: str | Path, *, symbol: str, series: str,
                 index_id: str, build_sha: str, venue: str = "kalshi", feed=None,
                 current_version: int = 1, owner_client_cap: int = MAX_OWNER_CLIENTS):
        if type(current_version) is not int or current_version not in (1, 2):
            raise ValueError("unsupported current version")
        if type(owner_client_cap) is not int or not 1 <= owner_client_cap <= MAX_CLIENTS:
            raise ValueError("invalid publisher-owner cap")
        self.directory = Path(directory)
        self.socket_path = self.directory / "book.sock"
        self.health_path = self.directory / "health.json"
        self.symbol, self.series, self.index_id = symbol, series, index_id
        self.venue, self.build_sha = venue, build_sha
        self.versions = tuple(range(current_version, max(0, current_version - 2), -1))
        self.owner_client_cap = owner_client_cap
        self.feed = feed
        self.epoch = uuid.uuid4().hex
        self.pid = os.getpid()
        self.n = 0
        self.dropped = 0
        self.foreign_lifecycle_dropped = 0
        self.foreign_trade_dropped = 0
        self.clients: dict[socket.socket, Client] = {}
        self._buckets: OrderedDict[int, tuple[float, float]] = OrderedDict()
        self._cache: dict[tuple[str, str], dict[int, bytes]] = {}
        self._snapshot: dict[int, tuple[bytes, ...]] = {v: () for v in self.versions}
        self._ready: frozenset[str] = frozenset()
        self._listener: socket.socket | None = None
        self._bound_identity: tuple[int, int] | None = None
        self._loop = None
        self._owner_uid = None
        self._tasks: list[asyncio.Task] = []
        self._closed = False
        # Validate identity at construction, before binding a public endpoint.
        encode(self._hello(self.versions[0]))

    def _frame(self, kind: str, version: int, **data) -> dict:
        return {"v": version, "kind": kind, "n": self.n, **data}

    def _hello(self, version: int) -> dict:
        return self._frame("hello", version, versions=list(self.versions), epoch=self.epoch,
                           pid=self.pid, build_sha=self.build_sha, symbol=self.symbol,
                           series=self.series, index_id=self.index_id, venue=self.venue)

    async def start(self) -> None:
        if sys.platform != "linux" or not hasattr(socket, "SO_PEERCRED"):
            raise RuntimeError("bookd requires Linux AF_UNIX and SO_PEERCRED")
        if process_uid() == 0:
            raise PermissionError("bookd refuses uid 0")
        if self._listener is not None or self._closed:
            raise RuntimeError("publisher cannot be started twice")
        self._owner_uid = process_uid()
        self._loop = asyncio.get_running_loop()
        self.directory.mkdir(parents=True, exist_ok=True)
        # lexists also refuses dangling symlinks. Never unlink a pre-existing path.
        if os.path.lexists(self.socket_path):
            raise FileExistsError(self.socket_path)
        listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            listener.setblocking(False)
            listener.bind(str(self.socket_path))
            info = self.socket_path.lstat()
            self._bound_identity = (info.st_dev, info.st_ino)
            os.chmod(self.socket_path, 0o666)
            if stat.S_IMODE(self.socket_path.stat().st_mode) != 0o666:
                raise PermissionError("book.sock must be mode 0666")
            listener.listen(MAX_CLIENTS)
            self._listener = listener
            self._loop.add_reader(listener.fileno(), self._accept)
            self.sync_readiness()
            self._tasks = [asyncio.create_task(self._heartbeat_loop(), name="bookd-heartbeat")]
            if self.feed is not None:
                self._tasks.append(asyncio.create_task(self._feed_loop(), name="bookd-feed"))
            sd_notify("READY=1")
        except BaseException:
            self._loop.remove_reader(listener.fileno())
            listener.close()
            self._listener = None
            self._unlink_owned_socket()
            raise

    def _admit(self, uid: int, now: float) -> str | None:
        previous = self._buckets.pop(uid, None)
        if previous is None:
            if len(self._buckets) >= MAX_UID_BUCKETS:
                oldest, (_, stamp) = next(iter(self._buckets.items()))
                if now - stamp < CONNECT_BURST / CONNECT_RATE:
                    return "rate_limit"
                del self._buckets[oldest]
            tokens = float(CONNECT_BURST)
        else:
            tokens = min(CONNECT_BURST, previous[0] + (now - previous[1]) * CONNECT_RATE)
        self._buckets[uid] = (max(0.0, tokens - 1), now)
        if tokens < 1:
            # A rejected attempt does not consume a fractional refill.
            self._buckets[uid] = (tokens, now)
            return "rate_limit"
        if len(self.clients) >= MAX_CLIENTS:
            return "client_limit"
        cap = self.owner_client_cap if uid == self._owner_uid else MAX_TENANT_CLIENTS
        if sum(client.uid == uid for client in self.clients.values()) >= cap:
            return "client_limit"
        return None

    def _reject(self, sock: socket.socket, reason: str) -> None:
        with contextlib.suppress(OSError):
            sock.send(encode(self._frame("bye", self.versions[0], reason=reason)))
        sock.close()

    def _accept(self) -> None:
        for _ in range(ACCEPT_BUDGET):
            try:
                sock, _ = self._listener.accept()
            except (BlockingIOError, InterruptedError):
                return
            sock.setblocking(False)
            try:
                uid = peer_uid(sock)
            except OSError:
                sock.close()
                continue
            reason = self._admit(uid, time.monotonic())
            if reason:
                self._reject(sock, reason)
                continue
            client = Client(sock, uid)
            self.clients[sock] = client
            client.timeout = self._loop.call_later(HELLO_TIMEOUT_S, self._bye, client, "bad_hello")
            self._loop.add_reader(sock.fileno(), self._read_hello, client)

    def _read_hello(self, client: Client) -> None:
        try:
            part = client.sock.recv(MAX_HELLO_BYTES - len(client.incoming))
            if not part:
                self._close_client(client)
                return
            client.incoming.extend(part)
            if b"\n" not in client.incoming:
                if len(client.incoming) == MAX_HELLO_BYTES:
                    self._bye(client, "bad_hello")
                return
            if client.incoming.index(10) != len(client.incoming) - 1:
                raise ProtocolError("data after hello")
            versions = decode_client_hello(bytes(client.incoming))
            version = next((v for v in self.versions if v in versions), None)
            if version is None:
                self._bye(client, "version")
                return
            self._loop.remove_reader(client.sock.fileno())
            client.sock.shutdown(socket.SHUT_RD)
            client.timeout.cancel()
            client.timeout = None
            client.version = version
            client.incoming.clear()
            # No await: se and registration for live fanout are one atomic turn.
            frames = (encode(self._hello(version)), encode(self._frame("sb", version)),
                      *self._snapshot[version], encode(self._frame("se", version)))
            for frame in frames:
                self._enqueue(client, frame)
        except (BlockingIOError, InterruptedError):
            return
        except (OSError, ProtocolError):
            self._bye(client, "bad_hello")

    def _enqueue(self, client: Client, raw: bytes) -> None:
        if client.closing or client.sock not in self.clients:
            return
        if (len(client.queue) >= MAX_CLIENT_FRAMES
                or client.queued_bytes + len(raw) > MAX_CLIENT_BYTES):
            self.dropped += 1
            self._bye(client, "slow_consumer")
            return
        client.queue.append(raw)
        client.queued_bytes += len(raw)
        self._loop.add_writer(client.sock.fileno(), self._flush, client)

    def _flush(self, client: Client) -> None:
        budget = WRITE_BUDGET
        try:
            while client.queue and budget > 0:
                raw = client.queue[0]
                sent = client.sock.send(memoryview(raw)[client.offset:client.offset + budget])
                if sent == 0:
                    self._close_client(client)
                    return
                client.offset += sent
                client.queued_bytes -= sent
                budget -= sent
                if client.offset == len(raw):
                    client.queue.popleft()
                    client.offset = 0
            if not client.queue:
                self._loop.remove_writer(client.sock.fileno())
                if client.closing:
                    self._close_client(client)
        except (BlockingIOError, InterruptedError):
            pass
        except OSError:
            self._close_client(client)

    def _bye(self, client: Client, reason: str) -> None:
        if client.sock not in self.clients or client.closing:
            return
        client.closing = True
        self._loop.remove_reader(client.sock.fileno())
        if client.timeout is not None:
            client.timeout.cancel()
        # Finish any partially sent JSON before bye. Discard unsent records.
        # A peer that never reads cannot be guaranteed a bye; close after 100ms.
        remainder = client.queue[0][client.offset:] if client.offset else b""
        client.queue.clear()
        client.offset = 0
        if remainder:
            client.queue.append(remainder)
        client.queue.append(encode(self._frame("bye", client.version or self.versions[0], reason=reason)))
        client.queued_bytes = sum(map(len, client.queue))
        client.timeout = self._loop.call_later(0.1, self._close_client, client)
        self._loop.add_writer(client.sock.fileno(), self._flush, client)

    def _close_client(self, client: Client) -> None:
        if self.clients.pop(client.sock, None) is None:
            return
        self._loop.remove_reader(client.sock.fileno())
        self._loop.remove_writer(client.sock.fileno())
        if client.timeout is not None:
            client.timeout.cancel()
        client.sock.close()
        client.queue.clear()
        client.queued_bytes = 0

    def _cache_frame(self, key: tuple[str, str], frame: dict) -> None:
        encoded = {v: encode({**frame, "v": v, "n": 0}) for v in self.versions}
        candidate = {**self._cache, key: encoded}
        # Markets rotate indefinitely. Retire the oldest inactive market records
        # before hitting the cap; never evict a ready quote or an index identity.
        if len(candidate) > MAX_SNAPSHOT_RECORDS:
            retired = next((k[1] for k in candidate
                            if k[0] in ("bs", "l") and k[1] not in self._ready
                            and k[1] != key[1]), None)
            if retired is not None:
                candidate = {k: row for k, row in candidate.items()
                             if k[1] != retired or k[0] not in ("bs", "l", "q")}
        if len(candidate) > MAX_SNAPSHOT_RECORDS:
            raise ProtocolError("snapshot record cap exceeded")
        snapshots = {v: tuple(candidate[k][v] for k in sorted(candidate)) for v in self.versions}
        if any(sum(map(len, rows)) > MAX_CLIENT_BYTES - 3 * MAX_FRAME_BYTES
               for rows in snapshots.values()):
            raise ProtocolError("snapshot byte cap exceeded")
        self._cache = candidate
        self._snapshot = snapshots

    def _remove_quote(self, ticker: str) -> None:
        self._cache.pop(("q", ticker), None)
        self._snapshot = {v: tuple(self._cache[k][v] for k in sorted(self._cache)) for v in self.versions}

    def _broadcast(self, frame: dict) -> None:
        # Encode once per protocol, never once per client.
        encoded = {v: encode({**frame, "v": v}) for v in self.versions}
        for client in tuple(self.clients.values()):
            if client.version is not None:
                self._enqueue(client, encoded[client.version])

    def publish(self, event) -> None:
        if isinstance(event, Trade):
            if event.venue != self.venue:
                raise ProtocolError("wrong venue")
            matches = (event.symbol.startswith(self.series + "-") if self.venue == "kalshi"
                       else event.symbol == self.symbol)
            if not matches:
                self.foreign_trade_dropped += 1
                return
        if isinstance(event, Lifecycle):
            matches = (event.ticker.startswith(self.series + "-") if self.venue == "kalshi"
                       else event.ticker == self.symbol)
            if not matches:
                self.foreign_lifecycle_dropped += 1
                return
        frame = event_frame(event, self.n + 1, self.versions[0])
        encode(frame)  # fail before changing sequence/cache
        if isinstance(event, (Quote, Trade, IndexTickFast)) and event.venue != self.venue:
            raise ProtocolError("wrong venue")
        if isinstance(event, (IndexTick, IndexTickFast)) and event.index_id != self.index_id:
            raise ProtocolError("wrong index identity")
        if isinstance(event, (Quote, Trade, Lifecycle)):
            ticker = event.ticker if isinstance(event, Lifecycle) else event.symbol
            matches = (ticker.startswith(self.series + "-") if self.venue == "kalshi"
                       else ticker == self.symbol)
            if not matches:
                raise ProtocolError("wrong market identity")
        if isinstance(event, Quote) and self.feed is not None and event.symbol not in self._ready:
            return  # queued pre-gap quote must not revive an invalid book
        if not isinstance(event, Trade):
            key = (frame["kind"], getattr(event, "symbol", None)
                   or getattr(event, "ticker", None) or event.index_id)
            self._cache_frame(key, frame)
        self.n += 1
        self._broadcast(frame)

    def upstream_connected(self) -> bool:
        if self.feed is None:
            return False
        # Kalshi retains a closed websocket after exceptional exits; presence alone
        # is not connectivity. Read the websocket's actual public state.
        ws = getattr(self.feed, "_ws", None)
        return getattr(getattr(ws, "state", None), "name", None) == "OPEN"

    def sync_readiness(self) -> None:
        if self.feed is None:
            return
        ready = self.feed.ready_tickers() if self.upstream_connected() else frozenset()
        for ticker in sorted(self._ready ^ ready):
            is_ready = ticker in ready
            if not is_ready:
                self._remove_quote(ticker)
            frame = self._frame("bs", self.versions[0], ticker=ticker, ready=is_ready)
            frame["n"] = self.n + 1
            self._cache_frame(("bs", ticker), frame)
            self.n += 1
            self._broadcast(frame)
        self._ready = frozenset(ready)

    def health(self) -> dict:
        feed = self.feed
        age = feed.last_message_age_s() if feed is not None else None
        stats = getattr(feed, "stats", None)
        return self._frame("hb", self.versions[0], upstream_connected=self.upstream_connected(),
                           upstream_age_ms=None if age is None else int(max(0.0, age) * 1000),
                           seq_gaps=getattr(feed, "seq_gaps", 0),
                           resnapshots=getattr(feed, "resnapshots", 0),
                           reconnects=getattr(stats, "reconnects", 0),
                           dropped=getattr(stats, "dropped", 0) + self.dropped,
                           build_sha=self.build_sha)

    def _write_health(self, frame: dict) -> None:
        payload = {**frame, "epoch": self.epoch, "pid": self.pid, "symbol": self.symbol,
                   "series": self.series, "index_id": self.index_id, "venue": self.venue,
                   "foreign_lifecycle_dropped": self.foreign_lifecycle_dropped,
                   "foreign_trade_dropped": self.foreign_trade_dropped,
                   "updated_at_ns": time.time_ns()}
        fd, name = tempfile.mkstemp(prefix=".health-", dir=self.directory)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                os.fchmod(handle.fileno(), 0o644)
                json.dump(payload, handle, separators=(",", ":"))
                handle.write("\n")
            os.replace(name, self.health_path)
        finally:
            with contextlib.suppress(FileNotFoundError):
                os.unlink(name)

    async def _heartbeat_loop(self) -> None:
        deadline = self._loop.time()
        while True:
            self.sync_readiness()
            self.n += 1
            frame = self.health()
            self._broadcast(frame)
            write = asyncio.create_task(asyncio.to_thread(self._write_health, frame))
            try:
                await asyncio.shield(write)
            except asyncio.CancelledError:
                # Do not leave a health writer mutating the directory after close.
                await write
                raise
            sd_notify("WATCHDOG=1")
            deadline += HEARTBEAT_S
            await asyncio.sleep(max(0.0, deadline - self._loop.time()))

    async def _feed_loop(self) -> None:
        while True:
            self.sync_readiness()
            for _ in range(128):
                event = self.feed.try_get()
                if event is None:
                    break
                self.publish(event)
            await asyncio.sleep(POLL_S)

    async def wait(self) -> None:
        """Propagate producer/health failures to the service supervisor."""
        if not self._tasks:
            raise RuntimeError("publisher not started")
        await asyncio.gather(*self._tasks)

    def _unlink_owned_socket(self) -> None:
        if self._bound_identity is not None:
            with contextlib.suppress(FileNotFoundError):
                info = self.socket_path.lstat()
                if (info.st_dev, info.st_ino) == self._bound_identity and stat.S_ISSOCK(info.st_mode):
                    self.socket_path.unlink()
            self._bound_identity = None

    async def close(self) -> None:
        self._closed = True
        for task in self._tasks:
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()
        for client in tuple(self.clients.values()):
            self._close_client(client)
        if self._listener is not None:
            self._loop.remove_reader(self._listener.fileno())
            self._listener.close()
            self._listener = None
        self._unlink_owned_socket()
