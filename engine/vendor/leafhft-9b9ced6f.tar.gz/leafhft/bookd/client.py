"""Unprivileged, reconnecting reader for book_stream.v1 (no venue connection).

The network task owns health. The consumer owns a separate bounded watermark;
handing an event to the strategy counts as applying it, as in Feed.try_get().
Snapshot completion is a queued barrier, so a reader cannot authorize entries
before its consumer has received the snapshot. Local sequences survive reconnects.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import os
import random
import socket
import stat
import struct
import sys
import time
from dataclasses import replace
from pathlib import Path

from ..feeds.base import Feed, QUEUE_MAX
from .freshness import Freshness, HEARTBEAT_S, UPSTREAM_S, register_shared
from .stream import MAX_FRAME_BYTES, ProtocolError, decode, decode_event, encode_client_hello

BACKOFF_MIN_S = 0.050
BACKOFF_MAX_S = 1.0
CLEAN_RESET_S = 10.0
_SNAPSHOT = object()


class ControlWakeup(TimeoutError):
    """Wake the consumer's control loop without reporting venue silence."""

    wakeup_only = True


def bookd_uid() -> int:
    # pwd is unavailable on Windows; startup still returns immediately there.
    import pwd

    return pwd.getpwnam("leafhft-bookd").pw_uid


def peer_uid(sock) -> int:
    return struct.unpack("3i", sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))[1]


def validate_directory(directory: Path, uid: int) -> None:
    """Never resolve a symlink before checking it. Check the entire parent chain."""
    if ".." in Path(directory).parts:
        raise PermissionError("parent traversal in bookd directory")
    directory = Path(os.path.abspath(directory))
    for path in (directory, *directory.parents):
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
            raise PermissionError("symlinked or invalid bookd parent")
        if info.st_mode & 0o022:
            raise PermissionError("writable bookd parent")
        if path == directory and info.st_uid != uid:
            raise PermissionError("bookd directory owner")
    info = (directory / "book.sock").lstat()
    if not stat.S_ISSOCK(info.st_mode) or info.st_uid != uid:
        raise PermissionError("bookd socket identity")


class SharedKalshiBookFeed(Feed):
    venue = "kalshi"

    def __init__(self, symbol: str, *, series: str, index_id: str,
                 directory: str | Path | None = None, venue: str = "kalshi",
                 index_max_age_s: float = 10.0, state_dir: str | Path | None = None,
                 clock=time.monotonic):
        super().__init__(symbol, heartbeat_s=HEARTBEAT_S,
                         backoff_min_s=BACKOFF_MIN_S, backoff_max_s=BACKOFF_MAX_S)
        if not series or not index_id or not venue:
            raise ValueError("complete shared book identity required")
        self.series, self.index_id, self.venue = series, index_id, venue
        self.directory = Path(directory) if directory is not None else Path("/run/leafhft-bookd") / symbol
        self.freshness = Freshness(symbol, series, index_max_age_s=index_max_age_s,
                                   state_dir=state_dir, clock=clock)
        register_shared(self.freshness)
        self._clock = clock
        self._writer = None
        self._epoch = None
        self._version = None
        self._build_sha = None
        self._n = None
        self._snapshot_n = None
        self._snapshot_complete = False
        self._hello_seen = False
        self._dropped = None
        self._seq_gaps = None
        self._invalidations = 0
        self._venue_silence = False
        self._changed = asyncio.Event()
        self._backoff = BACKOFF_MIN_S
        self._clean_since = None

    @property
    def effective_source(self) -> str:
        return "shared"

    async def start(self) -> None:
        if self._task is None or self._task.done():
            self._stop.clear()
            self._task = asyncio.create_task(self._supervise(), name=f"shared-book-{self.symbol}")

    def _clear_queue(self) -> None:
        while not self._q.empty():
            self._q.get_nowait()
        self.freshness.pending.clear()

    def _invalidate(self, reason: str) -> None:
        self._invalidations += 1
        self.freshness.stale(reason)
        self._clean_since = None

    async def stop(self) -> None:
        self._stop.set()
        self._invalidate("disconnected")
        self.freshness.connected = False
        if self._writer is not None:
            self._writer.close()
        task, self._task = self._task, None
        if task is not None:
            task.cancel()
            # Our reader has no unbounded cleanup or cancellation suppression.
            with contextlib.suppress(asyncio.CancelledError):
                await task
        self._clear_queue()
        self._changed.set()

    async def reconnect(self) -> None:
        self.stats.reconnects += 1
        await self.stop()
        await self.start()

    async def _connect(self):
        if sys.platform != "linux" or not hasattr(socket, "SO_PEERCRED"):
            raise PermissionError("shared book requires Linux AF_UNIX peer credentials")
        uid = bookd_uid()
        validate_directory(self.directory, uid)
        reader, writer = await asyncio.open_unix_connection(
            str(self.directory / "book.sock"), limit=MAX_FRAME_BYTES)
        try:
            if peer_uid(writer.get_extra_info("socket")) != uid:
                raise PermissionError("bookd peer identity")
            # Recheck path ownership and modes after the connection await.
            validate_directory(self.directory, uid)
        except BaseException:
            writer.close()
            raise
        return reader, writer

    async def _supervise(self) -> None:
        while not self._stop.is_set():
            try:
                await self._run_once()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.stats.disconnects += 1
                self.stats.note_error(f"{type(exc).__name__}: {exc}")
                if isinstance(exc, PermissionError):
                    self._invalidate("identity")
                elif not self.freshness.stale_reason:
                    self._invalidate("disconnected")
            finally:
                self.freshness.connected = False
                self._clean_since = None
                if self._writer is not None:
                    self._writer.close()
                    self._writer = None
                self.freshness.publish()
            await asyncio.sleep(random.uniform(BACKOFF_MIN_S, self._backoff))
            self._backoff = min(BACKOFF_MAX_S, self._backoff * 2)

    async def _run_once(self) -> None:
        self._hello_seen = False
        self._snapshot_n = None
        self._snapshot_complete = False
        self._n = None
        self._clear_queue()
        self.freshness.heartbeat_at = None
        self.freshness.upstream_age_s = None
        async with asyncio.timeout(0.8):
            reader, self._writer = await self._connect()
            self._writer.write(encode_client_hello())
            await self._writer.drain()
        self.stats.connects += 1
        self.freshness.connected = True
        connected_at = self._clock()
        while True:
            deadline = (self.freshness.heartbeat_at if self.freshness.heartbeat_at is not None
                        else connected_at) + HEARTBEAT_S
            try:
                raw = await asyncio.wait_for(reader.readline(), max(0.001, deadline - self._clock()))
            except TimeoutError:
                self._invalidate("heartbeat")
                raise ConnectionError("publisher heartbeat absent") from None
            except ValueError:
                self._invalidate("malformed")
                raise ProtocolError("oversize frame") from None
            if not raw:
                self._invalidate("disconnected")
                raise ConnectionError("publisher EOF")
            if self._clock() > deadline:
                self._invalidate("heartbeat")
                raise ConnectionError("publisher heartbeat absent")
            self._accept_raw(raw)
            if self._snapshot_complete and self.freshness.stale_reason in ("heartbeat", "upstream_age"):
                # The send fence can detect an age failure before the reader wakes.
                raise ConnectionError("fresh snapshot required")

    def _accept_raw(self, raw: bytes) -> None:
        try:
            if not raw.endswith(b"\n"):
                raise ProtocolError("unterminated frame")
            frame = decode(raw)
        except ProtocolError:
            reason = "malformed"
            if len(raw) <= MAX_FRAME_BYTES:
                try:
                    candidate = json.loads(raw)
                    if isinstance(candidate, dict) and candidate.get("kind") == "hello":
                        reason = "identity"
                except (ValueError, UnicodeError, RecursionError):
                    pass
            self._invalidate(reason)
            self.stats.malformed += 1
            raise
        previous = self._invalidations
        try:
            self._accept_frame(frame, raw)
        except ProtocolError:
            if self._invalidations == previous:
                self._invalidate("malformed")
            self.stats.malformed += 1
            raise

    def _accept_frame(self, frame: dict, raw: bytes) -> None:
        kind, n = frame["kind"], frame["n"]
        now = self._clock()
        if kind == "hello":
            if self._hello_seen:
                self._invalidate("epoch_change" if frame["epoch"] != self._epoch else "malformed")
                raise ProtocolError("unexpected hello")
            if any(frame[k] != getattr(self, k) for k in ("symbol", "series", "index_id", "venue")):
                self._invalidate("identity")
                raise ProtocolError("stream identity mismatch")
            self._hello_seen = True
            self._snapshot_complete = False
            if self._epoch != frame["epoch"]:
                self._dropped = None
                self._seq_gaps = None
                self._invalidate("epoch_change")
            self._epoch, self._version, self._build_sha = frame["epoch"], frame["v"], frame["build_sha"]
            self._n = n
            return
        if not self._hello_seen or frame["v"] != self._version:
            raise ProtocolError("missing hello or version changed")
        if kind == "bye":
            self._invalidate("disconnected")
            raise ConnectionError("publisher " + frame["reason"])
        if kind == "sb":
            if self._snapshot_n is not None or n != self._n:
                raise ProtocolError("invalid snapshot begin")
            self._snapshot_n = n
            self._snapshot_complete = False
            self._clear_queue()
            self.freshness.begin_snapshot()
            return
        if kind == "se":
            if self._snapshot_n is None or n != self._snapshot_n:
                raise ProtocolError("invalid snapshot end")
            self._snapshot_n = None
            self._snapshot_complete = True
            self._n = n
            self.freshness.stale_reason = ""
            self._enqueue(_SNAPSHOT)
            return
        if self._snapshot_n is not None:
            if n != 0 or kind not in ("q", "l", "i", "i5", "bs"):
                raise ProtocolError("invalid snapshot record")
        elif not self._snapshot_complete:
            raise ProtocolError("missing snapshot")
        elif n != self._n + 1:
            self._invalidate("seq_gap")
            raise ProtocolError("sequence gap")
        else:
            self._n = n
        if kind == "hb":
            if frame["build_sha"] != self._build_sha:
                self._invalidate("identity")
                raise ProtocolError("heartbeat identity")
            self.freshness.heartbeat_at = now
            age = frame["upstream_age_ms"]
            self.freshness.upstream_age_s = None if age is None else age / 1000
            self._venue_silence = age is not None and age > UPSTREAM_S * 1000
            reason = None
            if self._dropped is not None and frame["dropped"] > self._dropped:
                reason = "dropped"
            elif self._seq_gaps is not None and frame["seq_gaps"] > self._seq_gaps:
                reason = "seq_gap"
            elif not frame["upstream_connected"]:
                reason = "upstream_down"
            elif age is None or age > UPSTREAM_S * 1000:
                reason = "upstream_age"
            self._dropped = frame["dropped"]
            self._seq_gaps = frame["seq_gaps"]
            if reason:
                self._invalidate(reason)
            elif not self.freshness.stale_reason:
                if self._clean_since is None:
                    self._clean_since = now
                elif now - self._clean_since >= CLEAN_RESET_S:
                    self._backoff = BACKOFF_MIN_S
            self._changed.set()
            self.freshness.publish()
            if reason:
                # Publisher only sends snapshots at handshake: obtain a new se.
                raise ConnectionError(reason)
            return
        if kind == "bs":
            self._check_ticker(frame["ticker"])
            if frame["ready"]:
                self.freshness.ready.add(frame["ticker"])
            else:
                self.freshness.ready.discard(frame["ticker"])
            return
        if kind in ("i", "i5"):
            if frame["index_id"] != self.index_id:
                self._invalidate("identity")
                raise ProtocolError("index identity")
            if kind == "i":
                # A cached or repeated tick never gets a new freshness lease.
                age = max(0.0, time.time() - min(frame["source_ts_ms"], frame["received_at_ms"]) / 1000)
                self.freshness.index_at = now - age
        else:
            self._check_ticker(frame["ticker"] if kind == "l" else frame["symbol"])
        if "venue" in frame and frame["venue"] != self.venue:
            self._invalidate("identity")
            raise ProtocolError("event venue identity")
        event = decode_event(raw)
        if hasattr(event, "seq"):
            event = replace(event, seq=self.next_seq())
        self._enqueue(event)
        self.stats.messages += 1
        field = {"q": "quotes", "t": "trades", "l": "lifecycles", "i": "index_ticks", "i5": "index_fast_ticks"}[kind]
        setattr(self.stats, field, getattr(self.stats, field) + 1)

    def _check_ticker(self, ticker: str) -> None:
        if not ticker.startswith(self.series + "-"):
            self._invalidate("identity")
            raise ProtocolError("ticker identity")

    def _enqueue(self, event) -> None:
        if self._q.qsize() >= QUEUE_MAX:
            self.stats.dropped += 1
            self._invalidate("consumer_overflow")
            raise ConnectionError("consumer queue full")
        self._q.put_nowait((event, self.freshness.queued(), self.freshness.generation))
        self._changed.set()

    def try_get(self):
        while not self._q.empty():
            event, head, generation = self._q.get_nowait()
            self.freshness.applied(head)
            if event is _SNAPSHOT:
                self.freshness.consumer_generation = generation
                continue
            return event
        return None

    async def events(self, idle_timeout_s: float = 60.0):
        # Local EOF/idle wakes control checks without consuming the venue reconnect budget.
        while not self._stop.is_set():
            if self._venue_silence:
                self._venue_silence = False
                raise TimeoutError("publisher reports venue silence")
            event = self.try_get()
            if event is not None:
                yield event
                continue
            self._changed.clear()
            try:
                await asyncio.wait_for(self._changed.wait(), timeout=idle_timeout_s)
            except TimeoutError:
                # A stop, venue-silence report or event may race the wait's expiry.
                if not self._stop.is_set() and not self._venue_silence and self._q.empty():
                    raise ControlWakeup("shared book control wakeup") from None

    def ready_tickers(self) -> frozenset[str]:
        return frozenset(self.freshness.ready) if not self.freshness.stale_reason else frozenset()

    def last_message_age_s(self) -> float | None:
        stamp = self.freshness.heartbeat_at
        return None if stamp is None else max(0.0, self._clock() - stamp)
