"""Choose and pin the live Kalshi book source at feed construction."""
import json
import os
from pathlib import Path
import time

from .freshness import SOURCE_ENV, bind_source, expect_shared


def live_kalshi_feed(symbol, *, make_direct, demo=False, **feed_kwargs):
    source = os.environ.get(SOURCE_ENV, "")
    if source in ("", "direct"):
        source = "direct"
        bind_source(symbol, source)
        feed = make_direct("kalshi", symbol, demo=demo, **feed_kwargs)
    elif source == "shared":
        if demo:
            raise ValueError(f"{SOURCE_ENV}=shared has no demo publisher")
        expect_shared(symbol)
        from .client import SharedKalshiBookFeed
        from ..feeds.kalshi import symbol_to_series

        series, index_ids = symbol_to_series(symbol)
        feed = SharedKalshiBookFeed(symbol, series=series[0], index_id=index_ids[0])
    else:
        raise ValueError(f"invalid {SOURCE_ENV}: {source!r}")

    # One startup write only with a non-empty LEAFHFT_STATE_DIR, never on the hot path.
    state_dir = os.environ.get("LEAFHFT_STATE_DIR")
    if not state_dir:
        return feed
    path = Path(state_dir) / "book-source" / (symbol + ".effective.json")
    temporary = path.with_suffix(f".{os.getpid()}.tmp")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary.write_text(json.dumps({
            "build_sha": os.environ.get("LEAFHFT_BUILD_SHA", ""),
            "pid": os.getpid(),
            "schema": "leafhft.book-source-effective.v1",
            "source": source,
            "started_at_ns": time.time_ns(),
            "symbol": symbol,
        }, separators=(",", ":")), encoding="utf-8")
        os.replace(temporary, path)
    except OSError:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
    return feed
