"""Gold adapter for the continuous paper fleet. Paper only.

Collector rows supply observed evidence. The versioned artifacts in
gold_artifacts supply the model, calibration, account, fee, calendar,
stability, settlement and rules inputs the frozen evaluator requires; fields
carried on rows are never trusted as those inputs. Outcomes come only from
Kalshi's official settlement, the strike of the contiguous next market; a
settled lifecycle row alone still proves nothing.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from . import gold_artifacts as artifacts
from . import paper_results as results
from .strategy.kalshi_gold import DecisionJournal, evaluate_snapshot
from .types import PRICE_UNIT, SIZE_UNIT

KIND = 'kalshi-gold-paper'
SYMBOL = 'GOLD-15M'
SERIES = 'KXGOLD15M'
REFERENCE = 'Metal.Index.1OZGOLD/USD'
REQUIRED_ARTIFACTS = tuple(artifacts.ARTIFACTS)
CONTRACT = dict(schema_version=3, engine_id=KIND, symbol=SYMBOL,
                series_ticker=SERIES, reference_ticker=REFERENCE,
                evaluation='frozen-evaluator-setup-a', artifacts=dict(artifacts.DIGESTS),
                capital_basis_cents=artifacts.ACCOUNT['capital_basis_cents'])
ARTIFACTS_SHA256 = results.sha256(artifacts.DIGESTS)
DURATION_MS = artifacts.RULES['market_duration_ms']
MAX_MISMATCHES = 64
MAX_REASONS = 256
MAX_STREAMS = 4096
MAX_RETIRED = 512
MAX_CLOSE_AHEAD_MS = 4 * artifacts.RULES['market_duration_ms']
DISPUTABLE = ('reconstructed', 'unverified')


def frozen_generation(source_sha256):
    results.hash_value(source_sha256)
    return dict(kind=KIND, source_sha256=source_sha256,
                contract=dict(CONTRACT, artifacts=dict(artifacts.DIGESTS)))


# The observed-only contract that ran before the artifacts existed (schema 2).
LEGACY_CONTRACTS = (dict(
    schema_version=2, engine_id=KIND, symbol=SYMBOL, series_ticker=SERIES,
    reference_ticker=REFERENCE, evaluation='collecting-only-missing-contract-artifacts',
    required_artifacts=list(REQUIRED_ARTIFACTS), capital_basis_cents=5000),)


def validate_generation(value):
    """Accept this build's exact contract, the legacy observed-only one, or this schema with
    other artifact digests. Relay must keep reading a still-active generation frozen by other
    source during a deploy; the worker separately refuses any generation whose source hash is
    not its own, so it only ever runs this build's exact contract."""
    if not isinstance(value, dict) or set(value) != {'kind', 'source_sha256', 'contract'}:
        raise ValueError('invalid Gold generation contract')
    expected = frozen_generation(value.get('source_sha256'))
    contract = value['contract']
    if value == expected or (value['kind'] == KIND and contract in LEGACY_CONTRACTS):
        return value
    digests = contract.get('artifacts') if isinstance(contract, dict) else None
    if (value['kind'] == KIND and isinstance(digests, dict)
            and set(digests) == set(REQUIRED_ARTIFACTS)
            and all(isinstance(d, str) and len(d) == 64 and not d.strip('0123456789abcdef')
                    for d in digests.values())
            and dict(contract, artifacts=None) == dict(expected['contract'], artifacts=None)):
        return value
    raise ValueError('invalid Gold generation contract')


def _integer(value, low=0):
    return type(value) is int and low <= value <= results.LIMIT


def _nanos(value):
    return type(value) is int and 0 < value < 2**64


def _market(value):
    return isinstance(value, str) and value.startswith(SERIES + '-') and len(value) <= 256


def _empty_state(generation, source_sha256):
    return dict(generation=generation, source_sha256=source_sha256, streams={}, epoch=None,
                markets={}, reference=None, last_ns=0, history=[], last_disruption_ms=None,
                last_mismatch_ms=None, closes={}, positions={}, entries={}, probes={}, windows={},
                retired={},
                calibration=dict(resolved=0, tiers={}, chain='0' * 64),
                realized=dict(total_cents=0, days={}), last_reason={},
                unresolved=dict(reserved_cents=0, positions=[]),
                counters=dict(settled=0, reconstructed=0, mismatched=0, expired=0), mismatches=[])


class GoldPaperLive:
    """Private attempt state; only the fleet's fenced checkpoint is durable.

    Envelope sequence watermarks and journal request IDs survive checkpoints.
    A failed attempt is discarded in full, including its journal and summaries.
    """
    def __init__(self, out, generation, source_sha256):
        self.out = Path(out)
        self.out.mkdir(parents=True, exist_ok=True)
        self.generation = results.hash_value(generation)
        self.source_sha256 = results.hash_value(source_sha256)
        self.state_path = self.out / 'gold-state.json'
        self.journal_path = self.out / 'decisions.jsonl'
        self.state = _empty_state(generation, source_sha256)
        if self.state_path.exists():
            self.state = results.parse(results.read_bytes(self.state_path, 16 * 1024 * 1024))
            if (self.state['generation'] != generation
                    or self.state['source_sha256'] != source_sha256):
                raise ValueError('Gold checkpoint binding mismatch')
        self.journal_path.touch(exist_ok=True)
        self.journal = DecisionJournal(self.journal_path, max_records=results.MAX_RECORDS)
        self.processed = 0

    def _clear(self, ns=None):
        """Forget cached observations after any discontinuity; it also marks a disruption."""
        self.state['markets'] = {}
        self.state['reference'] = None
        self.state['history'] = []
        self.state['last_disruption_ms'] = (ns if ns is not None else self.state['last_ns']) // 1000000
        for entry in self.state['closes'].values():
            # Even a latched close may have come from the far side of this discontinuity.
            entry['broken'] = True

    async def consume(self, envelope):
        if envelope.get('symbol') != SYMBOL:
            return
        if envelope.get('v') != 1:
            raise ValueError('invalid Gold envelope version')
        epoch = envelope.get('epoch')
        if not isinstance(epoch, str) or not 1 <= len(epoch) <= 256:
            raise ValueError('invalid Gold epoch')
        if envelope.get('kind') == 'gap':
            if self.state['epoch'] in (None, epoch):
                self._clear()
            return
        seq, ns = envelope.get('seq'), envelope.get('t_recv_ns')
        if type(seq) is not int or seq < 1 or type(ns) is not int or not 0 < ns < 2**64:
            raise ValueError('invalid Gold envelope sequence or timestamp')
        identity = results.sha256(epoch)
        streams = self.state['streams']
        previous = streams.get(identity)
        digest = results.sha256(envelope)
        if previous and seq <= previous['seq']:
            if seq == previous['seq'] and digest != previous['digest']:
                raise ValueError('conflicting Gold envelope replay')
            return
        if self.state['epoch'] != epoch:
            if previous:
                return  # A retired epoch cannot replace the current source.
            if len(streams) >= MAX_STREAMS:
                # Each recorder run mints an epoch; forget the oldest retired ones.
                current = results.sha256(self.state['epoch']) if self.state['epoch'] else None
                oldest = sorted((key for key in streams if key != current),
                                key=lambda key: (streams[key].get('since', 0), key))
                for old in oldest[:len(streams) - MAX_STREAMS + 1]:
                    del streams[old]
            self._clear(ns)
            self.state['epoch'] = epoch
        if ((previous and seq != previous['seq'] + 1)
                or envelope.get('dropped_since_last', 0)):
            self._clear(ns)
        streams[identity] = dict(seq=seq, digest=digest,
                                 since=previous.get('since', ns) if previous else ns)
        if ns < self.state['last_ns']:
            self._clear(ns)
            return
        self.state['last_ns'] = ns
        now_ms = ns // 1000000
        row = envelope.get('row')
        if not isinstance(row, dict) or row.get('truncated'):
            self._clear(ns)
            return
        kind = envelope.get('kind')
        if kind == 'pause':
            self._clear(ns)
        elif kind == 'lifecycle' and row.get('t') == 'l' and _market(row.get('ticker')):
            ticker = row['ticker']
            if row.get('status') == 'settled':
                # Status alone contains neither a winner nor a resolved outcome.
                self.state['markets'].pop(ticker, None)
            elif row.get('status') in ('active', 'open') and _integer(row.get('close_time_ms'), 1):
                # Its strike is evidence of the previous market's close even after this market
                # has closed, but only a live, never-settled market is tracked for itself.
                self._sight_predecessor(row, now_ms)
                if (ticker not in self.state['retired']
                        and now_ms < row['close_time_ms'] <= now_ms + MAX_CLOSE_AHEAD_MS):
                    markets = {key: value for key, value in self.state['markets'].items()
                               if value['lifecycle']['close_time_ms'] > now_ms}
                    if len(markets) >= 4096 and ticker not in markets:
                        raise ValueError('Gold market capacity exceeded')
                    old = markets.get(ticker, {})
                    lifecycle = {key: row[key] for key in ('t', 'ticker', 'status',
                        'close_time_ms', 'expiration_time_ms', 'strike_i', 'local_ns') if key in row}
                    markets[ticker] = dict(lifecycle=lifecycle, lifecycle_sha256=digest,
                                          cycles=old.get('cycles', []), quote_ns=old.get('quote_ns'))
                    self.state['markets'] = markets
                    self._track_close(ticker, row, now_ms)
                self._settle_ready(now_ms)
            else:
                self.state['markets'].pop(ticker, None)
        elif kind == 'index' and row.get('t') == 'i':
            if (row.get('index_id') != REFERENCE or not _integer(row.get('value_i'), 1)
                    or not _integer(row.get('source_ts_ms'), 1)
                    or not _integer(row.get('received_at_ms'), 1)):
                self.state['reference'] = None
            else:
                observed = {key: row[key] for key in ('t', 'index_id', 'value_i',
                    'source_ts_ms', 'received_at_ms', 'local_ns') if key in row}
                self.state['reference'] = dict(row=observed, envelope_sha256=digest, ns=ns)
                self._observe_reference(observed['source_ts_ms'], observed['value_i'])
                self._settle_ready(now_ms)
        elif kind == 'quote' and row.get('t') == 'q' and _market(row.get('s')):
            self._quote(envelope, digest)

    # -- reference history and settlement ---------------------------------------------------

    def _observe_reference(self, source_ts_ms, value_i):
        second, history = source_ts_ms // 1000, self.state['history']
        if history and history[-1][0] == second:
            history[-1][1] = value_i
        elif not history or second > history[-1][0]:
            history.append([second, value_i])
        floor = second - artifacts.MODEL['history_window_s']
        while history and history[0][0] < floor:
            history.pop(0)
        for entry in self.state['closes'].values():
            if entry['broken']:
                continue
            seen = entry.get('last_source_ts_ms')
            if seen is not None and source_ts_ms < seen:
                entry['broken'] = True  # out of order: the reconstruction is no longer trustworthy
                continue
            entry['last_source_ts_ms'] = source_ts_ms
            if entry['candle_closed']:
                continue
            if source_ts_ms < entry['close_ms']:
                if entry['before'] is None or source_ts_ms > entry['before'][0]:
                    entry['before'] = [source_ts_ms, value_i]
            else:
                entry['candle_closed'] = True

    def _track_close(self, ticker, row, now_ms):
        closes = self.state['closes']
        entry = closes.setdefault(ticker, dict(
            close_ms=row['close_time_ms'], strike_i=0, before=None, candle_closed=False,
            broken=False, sightings=[], last_source_ts_ms=None, reports=[]))
        if entry['close_ms'] != row['close_time_ms']:
            # A revised close (an early close, say) restarts reconstruction around the new time.
            entry.update(close_ms=row['close_time_ms'], before=None, candle_closed=False,
                         broken=True, sightings=[])
        strike = row.get('strike_i')
        if _integer(strike, 1):
            entry['reports'] = (entry['reports'] + [strike])[-8:]
            agreed = next((value for value in entry['reports'] if value != entry['strike_i']
                           and entry['reports'].count(value) >= 2), None)
            if not entry['strike_i']:
                entry['strike_i'] = strike
            elif agreed is not None:
                # Two later reports overrule the first; record it and stand the lane down.
                self._record_mismatch(ticker, entry, now_ms, kind='strike_revised',
                                      reported_i=agreed)
                entry['strike_i'] = agreed

    def _sight_predecessor(self, row, now_ms):
        """A market's strike is the official close of the contiguous previous market."""
        strike = row.get('strike_i')
        if not _integer(strike, 1):
            return
        previous_close = row['close_time_ms'] - DURATION_MS
        for other in self.state['closes'].values():
            if other['close_ms'] == previous_close:
                other['sightings'] = (other['sightings'] + [strike])[-8:]
        for prior, record in sorted(self.state['retired'].items()):
            if (record.get('basis') in DISPUTABLE and not record.get('disputed')
                    and record['close_ms'] == previous_close):
                self._check_settled(prior, record, strike, now_ms)

    def _check_settled(self, ticker, record, reported_i, now_ms):
        """A settlement made without a corroborated official close stays open to dispute.

        A later report that disagrees proves neither side, since reports echo one snapshot,
        so the outcome becomes disputed and counts as a loss: journal corrections, P&L and
        calibration all take the pessimistic side, and the lane stands down.
        """
        if artifacts.settle(record['strike_i'], reported_i, None)[0] == record['result']:
            return
        record['disputed'] = True
        self._record_mismatch(ticker, dict(close_ms=record['close_ms'], strike_i=record['strike_i'],
                                           sightings=[reported_i]), now_ms,
                              kind='settlement_disputed', reported_i=reported_i)
        realized = self.state['realized']
        for outcome in record['outcomes']:
            if outcome['profit_cents'] <= -outcome['cost_cents']:
                continue  # already booked as a full loss
            self.journal.append_correction(dict(
                correction_id='correction-' + outcome['outcome_id'], target_id=outcome['outcome_id'],
                reason='settlement disputed by a later official report; counted as a loss',
                corrected_fields=dict(outcome_label='disputed', payout_cents=0,
                                      profit_cents=-outcome['cost_cents'])))
            realized['total_cents'] += -outcome['cost_cents'] - outcome['profit_cents']
        calibration = record.get('calibration')
        if calibration and calibration['side'] == record['result']:
            tier = self.state['calibration']['tiers'].get(calibration['tier'])
            if tier is not None:
                tier['wins'] -= 1  # a disputed win no longer counts as one

    def _crosscheck(self, entry):
        """The reconstructed candle close, only when intact and fresh at the close."""
        before = entry['before']
        if (entry['candle_closed'] and not entry['broken'] and before
                and entry['close_ms'] - before[0] <= artifacts.RULES['reconstruct_max_age_ms']):
            return before[1]
        return None

    def _settle_ready(self, now_ms):
        """Resolve a close only with corroboration: a fresh reconstructed close agreeing with an
        official sighting, or two agreeing official sightings. Anything else waits, then fails
        closed as a mismatch or an expiry that leaves positions reserved."""
        closes, rules = self.state['closes'], artifacts.RULES
        # Sorted, not insertion order: a checkpoint round trip reorders dicts by key.
        for ticker, entry in sorted(closes.items()):
            age = now_ms - entry['close_ms']
            strike, sightings = entry['strike_i'], entry['sightings']
            if not strike:
                if age > rules['unsettled_expiry_ms']:
                    self._retire(ticker, 'expired')
                continue
            if not (entry['candle_closed'] or entry['broken']) and age <= rules['settle_grace_ms']:
                continue  # a fresh reconstructed close may still arrive
            crosscheck = self._crosscheck(entry)
            if not sightings:
                # A session break has no contiguous successor; settle only an unambiguous close.
                if (crosscheck is not None and age > rules['reconstructed_after_ms']
                        and abs(crosscheck - strike) >= rules['reconstructed_margin_cents'] * artifacts.CENT_I):
                    self._resolve(ticker, 'yes' if crosscheck >= strike else 'no', now_ms,
                                  basis='reconstructed')
                elif age > rules['unsettled_expiry_ms']:
                    self._retire(ticker, 'expired')
                continue
            # Reports are echoes of one discovery snapshot; only the reconstruction is independent.
            agreed = next((value for value in sightings if crosscheck is not None
                           and artifacts.settle(strike, value, crosscheck)[1]), None)
            unanimous = sightings[0] if len(set(sightings)) == 1 else None
            if agreed is not None:
                self._resolve(ticker, artifacts.settle(strike, agreed, None)[0], now_ms)
            elif age <= rules['mismatch_after_ms']:
                continue  # give a corrected report time to appear before settling unverified
            elif unanimous is not None:
                # Settle on Kalshi's value, but an unverified close stands the lane down.
                self._record_mismatch(
                    ticker, entry, now_ms, reported_i=unanimous, reconstructed_i=crosscheck,
                    kind='uncrosschecked_official' if crosscheck is None else 'crosscheck_disagreed')
                self._resolve(ticker, artifacts.settle(strike, unanimous, None)[0], now_ms,
                              basis='unverified')
            elif age > rules['mismatch_after_ms']:
                self._record_mismatch(ticker, entry, now_ms, kind='unsettled',
                                      reported_i=sightings[0], reconstructed_i=crosscheck)
                self._retire(ticker, 'mismatched')  # positions stay reserved: fail closed

    def _record_mismatch(self, ticker, entry, now_ms, *, kind, reported_i, reconstructed_i=None):
        self.state['last_mismatch_ms'] = now_ms
        self.state['mismatches'] = (self.state['mismatches'] + [dict(
            kind=kind, ticker=ticker, close_ms=entry['close_ms'], strike_i=entry['strike_i'],
            official_i=reported_i, sightings=list(entry['sightings']),
            reconstructed_i=reconstructed_i, at_ms=now_ms)])[-MAX_MISMATCHES:]

    def _resolve(self, ticker, result, now_ms, basis='official'):
        realized = self.state['realized']
        settled = []
        for request, position in sorted(self.state['positions'].items()):
            if position['ticker'] != ticker:
                continue
            won = position['side'] == result
            payout = 100 * position['count'] if won else 0
            profit = payout - position['cost_cents']
            label = ('win' if won else 'loss') + ('' if basis == 'official' else '-' + basis)
            self.journal.append_outcome(dict(
                outcome_id='outcome-' + request, request_id=request,
                outcome_label=label, resolved_at_ms=now_ms,
                payout_cents=payout, profit_cents=profit))
            realized['total_cents'] += profit
            settled.append(dict(outcome_id='outcome-' + request, side=position['side'],
                                count=position['count'], cost_cents=position['cost_cents'],
                                profit_cents=profit))
            day = str(now_ms // 86_400_000)
            realized['days'][day] = realized['days'].get(day, 0) + profit
            del self.state['positions'][request]
        realized['days'] = dict(sorted(realized['days'].items(), key=lambda item: int(item[0]))[-7:])
        calibration = self._calibrate(ticker, result, basis)
        self._retire(ticker, 'reconstructed' if basis == 'reconstructed' else 'settled',
                     record=dict(basis=basis, result=result, outcomes=settled, calibration=calibration))

    def _calibrate(self, ticker, result, basis):
        """Fold a finished window into calibration. An unknown result counts as a loss."""
        probe = self.state['probes'].pop(ticker, None)
        calibration = self.state['calibration']
        if self.state['windows'].pop(ticker, None) is not None:
            calibration['resolved'] += 1
        if probe is None:
            return None
        key = artifacts.ask_tier(probe['ask_cents'], probe['q_low'])
        tier = calibration['tiers'].setdefault(key, dict(n=0, wins=0, cost_cents=0, days=[]))
        tier['n'] += 1
        tier['wins'] += int(probe['side'] == result)
        tier['cost_cents'] += (probe['ask_cents'] + probe['fee_cents']
                               + artifacts.CALIBRATION['overhead_cents'])
        day = probe['close_ms'] // 86_400_000
        if day not in tier.setdefault('days', []):
            tier['days'] = sorted(tier['days'] + [day])[-artifacts.CALIBRATION['max_tier_days']:]
        calibration['chain'] = results.sha256([calibration['chain'], ticker, probe, result, basis])
        return dict(tier=key, side=probe['side'])

    def _retire(self, ticker, how, record=None):
        self.state['counters'][how] += 1
        close = self.state['closes'].get(ticker)
        retired = self.state['retired']
        retired[ticker] = dict(record or {}, close_ms=close['close_ms'] if close else 0,
                               strike_i=close['strike_i'] if close else 0)
        if len(retired) > MAX_RETIRED:
            order = sorted(retired, key=lambda key: (retired[key]['close_ms'], key))
            for old in order[:len(retired) - MAX_RETIRED]:
                del retired[old]
        if how in ('mismatched', 'expired'):
            self._calibrate(ticker, None, how)  # an unknown outcome must not flatter calibration
            # The outcome is unknown: keep the capital reserved as if lost, but bound the state.
            unresolved = self.state['unresolved']
            for request in sorted(r for r, p in self.state['positions'].items() if p['ticker'] == ticker):
                position = self.state['positions'].pop(request)
                unresolved['reserved_cents'] += position['cost_cents']
                unresolved['positions'] = (unresolved['positions'] + [
                    dict(position, request_id=request, how=how)])[-MAX_MISMATCHES:]
        self.state['closes'].pop(ticker, None)
        self.state['probes'].pop(ticker, None)
        self.state['windows'].pop(ticker, None)
        self.state['entries'].pop(ticker, None)
        self.state['last_reason'].pop(ticker, None)

    # -- decisions --------------------------------------------------------------------------

    def _quote(self, envelope, digest):
        row, ns = envelope['row'], envelope['t_recv_ns']
        now_ms, ticker = ns // 1000000, row['s']
        request = 'gold-' + results.sha256([self.generation, envelope['epoch'], envelope['seq']])
        inputs = dict(request_id=request, now_ms=now_ms, market_ticker=ticker,
                      series_ticker=SERIES, reference_ticker=REFERENCE,
                      envelope_sha256=digest, artifacts_sha256=ARTIFACTS_SHA256)
        market, reference = self.state['markets'].get(ticker), self.state['reference']
        reason = None
        if not market:
            reason = 'missing_active_lifecycle'
        elif not reference:
            reason = 'missing_gold_reference'
        elif (row.get('v') != 'kalshi' or any(not _integer(row.get(k)) for k in ('b', 'a', 'bs', 'as'))
              or not 0 < row['b'] <= row['a'] < PRICE_UNIT or not _nanos(row.get('te'))
              or not _nanos(row.get('tr'))):
            reason = 'invalid_observed_quote'
        inputs['quote'] = {key: row[key] for key in
            ('t', 'v', 's', 'b', 'a', 'bs', 'as', 'te', 'tr', 'ta', 'n') if key in row}
        # Decisions fire on this quote's own arrival, and the export stamps the envelope with
        # the same collector receipt it writes to tr, so this age is zero by construction.
        # Kalshi quote te is the collector's flush time, not venue time, and ta is the local
        # arrival of the last frame that changed the book; neither measures feed lag. Pyth
        # arrives on the same Kalshi socket, so a lagging socket shows up as reference age,
        # and stability trips on a 5 s quote stall or a 20 s reference gap. The receipt-time
        # check is ordering only, and gap and epoch clears cover lost envelopes and restarts,
        # not lag. Venue lag needs a venue-time field and a skew policy. te is only checked
        # for presence and kept for audit, never used as a time basis.
        if _nanos(row.get('tr')):
            inputs.update(quote_ts_ms=row['tr'] // 1000000, quote_ts_basis='collector_receipt')
        if market:
            prior_ns = market['quote_ns']
            if prior_ns is not None and ns > prior_ns:
                market['cycles'] = (market['cycles'] + [(ns - prior_ns) / 1000000])[-20:]
            market['quote_ns'] = ns
            inputs.update(lifecycle=dict(market['lifecycle']),
                          lifecycle_sha256=market['lifecycle_sha256'],
                          browser_cycle_ms=list(market['cycles']))
        if reference:
            inputs.update(reference_source_ts_ms=reference['row']['source_ts_ms'],
                          reference_received_at_ms=reference['row']['received_at_ms'],
                          reference_value_i=reference['row']['value_i'],
                          reference_envelope_sha256=reference['envelope_sha256'])
        snapshot = None
        if reason is None:
            reason, snapshot = self._snapshot(ticker, market, row, now_ms, inputs)
        if snapshot is not None:
            decision = evaluate_snapshot(snapshot)
        else:
            decision = dict(schema_version=1, strategy='kalshi_gold_paper', mode='paper',
                            request_id=request, market_ticker=ticker, inputs=inputs,
                            action='skip', reason=reason, count=0)
        if decision['action'] == 'paper_candidate':
            self._open(decision, market, now_ms)
        # Journal state changes, not every quote, so the bounded journal lasts.
        last = self.state['last_reason']
        if decision['action'] == 'paper_candidate' or last.get(ticker, [None])[0] != decision['reason']:
            self.journal.append_decision(decision)
        last[ticker] = [decision['reason'], ns]  # refreshed on every quote: least recently seen goes
        if len(last) > MAX_REASONS:
            for old in sorted(last, key=lambda key: (last[key][1], key))[:len(last) - MAX_REASONS]:
                del last[old]

    def _snapshot(self, ticker, market, row, now_ms, inputs):
        """Build the evaluator's full input from evidence plus artifacts, or name what is missing."""
        close_ms = market['lifecycle']['close_time_ms']
        # The same first-nonzero strike that will grade the position, never a later row's.
        close = self.state['closes'].get(ticker)
        strike_i = close['strike_i'] if close and close['close_ms'] == close_ms else 0
        if not _integer(strike_i, 1):
            return 'missing_strike', None
        scales = artifacts.history_variance(self.state['history'])
        if scales is None:
            return 'model_insufficient_history', None
        reference_i = inputs['reference_value_i']
        age_s = max(0, now_ms - inputs['reference_source_ts_ms']) / 1000
        left_s = (close_ms - now_ms) / 1000
        sides = {}
        for side in ('yes', 'no'):
            if side == 'yes':
                ask = artifacts.price_cents(row['a'], up=True)
                bid = artifacts.price_cents(row['b'], up=False)
                depth = row['as'] // SIZE_UNIT
            else:
                ask = artifacts.price_cents(PRICE_UNIT - row['b'], up=True)
                bid = artifacts.price_cents(PRICE_UNIT - row['a'], up=False)
                depth = row['bs'] // SIZE_UNIT
            sides[side] = dict(q_low=artifacts.q_low(side, reference_i, strike_i, scales,
                                                     left_s, age_s),
                               ask=ask, bid=bid, depth=depth)
        side = max(sides, key=lambda key: sides[key]['q_low'])
        chosen = sides[side]
        if not (1 <= chosen['bid'] <= 99 and 1 <= chosen['ask'] <= 99):
            return 'quote_outside_cent_range', None
        blackout = artifacts.release_blackout(now_ms, close_ms)
        unstable = artifacts.unstable(now_ms, self.state['last_disruption_ms'],
                                      self.state['last_mismatch_ms'], market['cycles'],
                                      self.state['history'])
        fee = artifacts.entry_fee_cents(chosen['ask'])
        # Calibrate only quotes that could actually have traded, on a healthy feed. A settlement
        # mismatch stands trading down but must not starve calibration of clean markets.
        feed_unstable = artifacts.unstable(now_ms, self.state['last_disruption_ms'], None,
                                           market['cycles'], self.state['history'])
        untradeable = (not 0 <= chosen['ask'] - chosen['bid'] <= 2 or chosen['depth'] <= 0
                       or len(market['cycles']) < artifacts.CALIBRATION['probe_min_cycles'])
        self._probe(ticker, close_ms, left_s, side, chosen, fee, age_s,
                    blackout or feed_unstable or untradeable)
        calibration = self.state['calibration']
        tier = artifacts.ask_tier(chosen['ask'], chosen['q_low'])
        positions = self.state['positions'].values()
        realized = self.state['realized']
        snapshot = dict(
            inputs, setup='A', side=side, model_version=artifacts.MODEL_VERSION,
            rules_hash=artifacts.RULES_HASH, close_ms=close_ms, strike_i=strike_i,
            bid_cents=chosen['bid'], ask_cents=chosen['ask'], depth_contracts=chosen['depth'],
            q_low=chosen['q_low'], entry_fee_cents=fee,
            resolved_windows=calibration['resolved'], calibration_tier=tier,
            calibration_tier_n=calibration['tiers'].get(tier, {}).get('n', 0),
            calibration_lower_edge_cents=artifacts.calibration_edge_cents(
                calibration['tiers'].get(tier),
                chosen['ask'] + fee + artifacts.CALIBRATION['overhead_cents']),
            calibration_chain=calibration['chain'], release_blackout=blackout, unstable=unstable,
            # Losses beyond the basis must fail through the evaluator's gates, not its validator.
            allocation_balance_cents=max(
                0, artifacts.ACCOUNT['capital_basis_cents'] + realized['total_cents']),
            reserved_cents=(sum(p['cost_cents'] for p in positions)
                            + self.state['unresolved']['reserved_cents']),
            open_positions=sum(p['close_ms'] > now_ms for p in positions), pending_entries=0,
            entries_this_contract=self.state['entries'].get(ticker, 0),
            realized_today_cents=realized['days'].get(str(now_ms // 86_400_000), 0),
            settlement_mismatches_n=self.state['counters']['mismatched'])
        return None, snapshot

    def _probe(self, ticker, close_ms, left_s, side, chosen, fee, age_s, excluded):
        """Record calibration evidence in the tradeable regime only.

        A market counts as a window at its first usable quote in the entry window. Its
        probe is the first such quote that meets the bucket, the same moment an entry
        would fire, so calibration measures the model where it actually trades.
        """
        low, high = artifacts.CALIBRATION['probe_window_s']
        if ticker not in self.state['closes'] or excluded or age_s > 10 or not low <= left_s <= high:
            return
        self.state['windows'].setdefault(ticker, close_ms)
        probe = dict(close_ms=close_ms, side=side, q_low=chosen['q_low'],
                     ask_cents=chosen['ask'], fee_cents=fee)
        if ticker not in self.state['probes'] and artifacts.in_bucket(probe):
            self.state['probes'][ticker] = probe

    def _open(self, decision, market, now_ms):
        ticker, count, ask = decision['market_ticker'], decision['count'], decision['price_cents']
        self.state['positions'][decision['request_id']] = dict(
            ticker=ticker, side=decision['side'], count=count, price_cents=ask,
            cost_cents=artifacts.order_cost_cents(ask, count),
            close_ms=market['lifecycle']['close_time_ms'], opened_ms=now_ms)
        self.state['entries'][ticker] = self.state['entries'].get(ticker, 0) + 1

    def checkpoint(self):
        # Private state can exceed a public summary's byte bound.
        self.state_path.write_bytes(results.canonical(self.state))

    def views(self):
        # Reporting denominator from the frozen paper contract, not an observed
        # account balance and never an evaluate_snapshot risk input.
        summary = results.build_summary(self.journal_path, engine_id=KIND,
            capital_basis_cents=CONTRACT['capital_basis_cents'], source='kalshi_gold_paper',
            spec_sha256=self.generation)
        results.write_summary(self.out / 'paper-results', summary)
        # Older reports remain immutable in prior accepted S3 checkpoints.
        # Carry only the current report into the next private checkpoint.
        current_name = summary['summary_sha256'] + '.json'
        for path in (self.out / 'paper-results' / KIND).glob('*.json'):
            if path.name not in ('current.json', current_name):
                path.unlink()


def validate_result(result, frozen):
    """Validate canonical report bytes, reference, journal and frozen binding."""
    validate_generation(frozen)
    if result.get('kind') != KIND:
        raise ValueError('Gold result kind mismatch')
    files = result['files']
    base = 'paper-results/' + KIND + '/'
    reference = results.parse(files[base + 'current.json'].encode())
    if set(reference) != {'summary_sha256', 'report_hash'}:
        raise ValueError('invalid Gold current reference')
    digest = results.hash_value(reference['summary_sha256'])
    report = files[base + digest + '.json'].encode()
    if hashlib.sha256(report).hexdigest() != results.hash_value(reference['report_hash']):
        raise ValueError('Gold report hash mismatch')
    summary = results.validate_summary(results.parse(report))
    if (summary['engine_id'] != KIND or summary['source'] != 'kalshi_gold_paper'
            or summary['summary_sha256'] != digest
            or summary['spec_sha256'] != result['generation']
            or result.get('source_sha256') != frozen['source_sha256']):
        raise ValueError('Gold summary source mismatch')
    journal = files['decisions.jsonl'].encode()
    if hashlib.sha256(journal).hexdigest() != summary['source_sha256']:
        raise ValueError('Gold journal source mismatch')
    return summary, reference
