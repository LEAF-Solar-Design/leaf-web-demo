"""Read-only document projection; this module is not an execution authority."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime
from decimal import Decimal, InvalidOperation
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import time

from .attribution import account_digest
from .broker.account_risk import read_ledger


SCHEMA = "leaf.deployments.derived.v1"
MAX_INPUT_BYTES = 8 * 1024 * 1024
MAX_OUTPUT_BYTES = 2 * 1024 * 1024
MAX_ROWS = 1024
LEVERAGE_STEPS = (1, 5, 20, 50, 100, 250)
# deploy/runner/live-run.sh's owner whitelist, not the wider feed catalog.
OWNER_BOOKS = (
    "BTC-15M", "ETH-15M", "BTC-1H", "ETH-1H", "BNB-15M", "DOGE-15M",
    "HYPE-15M", "NEAR-15M", "SOL-15M", "XRP-15M", "ZEC-15M", "BNB-1H",
    "HYPE-1H", "XRP-1H",
)
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}\Z")
_ENTRY_STATES = {"canary", "probe", "probe_sized", "graduated"}


def _encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate key")
        result[key] = value
    return result


def _reject(value):
    raise ValueError("non-finite JSON number")


def _json(data):
    return json.loads(data, object_pairs_hook=_pairs, parse_constant=_reject)


def _read(path, limit=MAX_INPUT_BYTES):
    # Refuse devices/FIFOs and links before opening; never open sources for writing.
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError("not a regular file")
    with path.open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError("input exceeds byte limit")
    return data


def _number(value):
    if type(value) not in (str, int, float):
        raise ValueError("invalid number")
    try:
        result = Decimal(str(value))
    except InvalidOperation as exc:
        raise ValueError("invalid number") from exc
    if not result.is_finite() or result < 0 or result > Decimal("1e15"):
        raise ValueError("invalid number")
    return result


def _object(value):
    if type(value) is not dict:
        raise ValueError("expected object")
    return value


def _ids(value):
    if type(value) is not list or any(type(v) is not str or not _ID.fullmatch(v) for v in value):
        raise ValueError("invalid identifiers")
    if len(set(value)) != len(value):
        raise ValueError("duplicate identifiers")
    return value


def load_inputs(etc_dir, state_dir):
    """Capture bounded source bytes and their hashes; a missing lifecycle is optional."""
    etc, state = Path(etc_dir), Path(state_dir)
    inputs = {"documents": {}, "paths": {}, "evidence": {}, "source_errors": {}, "B_cents": None}

    def capture(key, path, *, optional=False, plain=False):
        inputs["paths"][key] = str(path)
        try:
            data = _read(path)
            inputs["evidence"][str(path)] = hashlib.sha256(data).hexdigest()
            value = data.decode("utf-8") if plain else _json(data)
            inputs["documents"][key] = value
            return value
        except FileNotFoundError:
            if optional:
                inputs["documents"][key] = None
            else:
                inputs["source_errors"][str(path)] = "missing"
        except (OSError, ValueError, RecursionError) as exc:
            inputs["source_errors"][str(path)] = type(exc).__name__
        return None

    for name in ("kalshi-engine-bindings.json", "probe-bindings.json", "kalshi-policy.json"):
        capture(name, etc / name)
    capture("kalshi-probe-hosts", etc / "kalshi-probe-hosts", plain=True)
    capture("kalshi-engine-account-overrides.json", etc / "kalshi-engine-account-overrides.json", optional=True)
    capture("engine-registry/projection.json", state / "engine-registry/projection.json")
    identity = capture("dashboard-account.json", state / "dashboard-account.json")
    ids = set()
    for name in ("kalshi-engine-bindings.json", "probe-bindings.json"):
        doc = inputs["documents"].get(name)
        if type(doc) is dict and type(doc.get("symbols")) is dict:
            for book in OWNER_BOOKS:
                value = doc["symbols"].get(book, doc.get("default") if name.startswith("kalshi-") else [])
                for eid in value if type(value) is list else [value]:
                    if type(eid) is str and _ID.fullmatch(eid):
                        ids.add(eid)
    if len(ids) > MAX_ROWS:
        raise ValueError("too many engines")
    for eid in sorted(ids):
        capture(f"engines/{eid}.json", etc / "engines" / f"{eid}.json")
        capture(f"engine-lifecycle/{eid}.json", state / "engine-lifecycle" / f"{eid}.json", optional=True)
    try:
        identity = _object(identity)
        aid = identity.get("account_id")
        if (type(aid) is not str or not aid or type(identity.get("subaccount_number")) is not int
                or identity["subaccount_number"] != 0):
            raise ValueError("invalid owner identity")
        principal = json.dumps(["kalshi", aid, 0], separators=(",", ":"))
        path = state / "account-risk" / (account_digest(principal) + ".sqlite3")
        inputs["ledger_path"] = str(path)
        # Hash the database and any WAL bytes around the read. A changing capture has no B.
        def ledger_bytes():
            captured = {str(path): hashlib.sha256(_read(path)).hexdigest()}
            wal = Path(str(path) + "-wal")
            try:
                captured[str(wal)] = hashlib.sha256(_read(wal)).hexdigest()
            except FileNotFoundError:
                pass
            return captured
        before = ledger_bytes()
        ledger = read_ledger(path, expected_account_id=principal, hot=True)
        after = ledger_bytes()
        inputs["evidence"].update(after)
        if before != after or not ledger["healthy"]:
            raise ValueError("ledger unavailable or changed during read")
        balance = ledger["state"].get("equity_cents")
        if type(balance) is not int or balance < 0:
            raise ValueError("invalid equity_cents")
        inputs["B_cents"] = balance
    except (OSError, ValueError, TypeError, KeyError, RecursionError) as exc:
        inputs["source_errors"][inputs.get("ledger_path", str(state / "dashboard-account.json"))] = str(exc)
    return inputs


def derive(inputs, *, now_ms):
    """Pure projection of a captured input set. No filesystem or clock access."""
    docs, paths = inputs["documents"], inputs["paths"]
    errors = dict(inputs.get("source_errors", {}))
    evidence = dict(inputs.get("evidence", {}))

    def source(key, validate, *, optional=False):
        path = paths.get(key, key)
        if path in errors:
            return None, False
        try:
            value = docs.get(key)
            if value is None and optional:
                return None, True
            return validate(value), True
        except (ValueError, TypeError, KeyError, InvalidOperation, OverflowError):
            errors[path] = "malformed"
            return None, False

    def identity(v):
        v = _object(v)
        if (type(v.get("account_id")) is not str or not v["account_id"]
                or type(v.get("subaccount_number")) is not int or v["subaccount_number"] != 0):
            raise ValueError("account missing")
        return v["account_id"]

    account, account_ok = source("dashboard-account.json", identity)
    def account_policy(v):
        v = _object(v)
        for key in ("stake_ceiling_usd", "size_fraction", "per_order_fraction", "daily_loss_fraction",
                    "cluster_fraction", "drawdown_brake_fraction", "drawdown_stop_fraction"):
            if key in v:
                _number(v[key])
        return v

    policy, policy_ok = source("kalshi-policy.json", account_policy)

    def bindings(v):
        v = _object(v)
        symbols = _object(v.get("symbols"))
        _ids(list(symbols))
        _ids(v.get("disabled", []))
        for eid in list(symbols.values()) + ([v["default"]] if "default" in v else []):
            if type(eid) is not str or not _ID.fullmatch(eid):
                raise ValueError("invalid engine")
        return v

    binding, binding_ok = source("kalshi-engine-bindings.json", bindings)

    def probes(v):
        symbols = _object(_object(v).get("symbols"))
        _ids(list(symbols))
        for value in symbols.values():
            _ids(value)
        return symbols

    probe, probe_ok = source("probe-bindings.json", probes)

    def hosts(v):
        if type(v) is not str:
            raise ValueError("hosts must be text")
        return set(_ids(["".join(line.split()) for line in v.splitlines() if line.strip()]))

    hosted, hosts_ok = source("kalshi-probe-hosts", hosts)

    def overrides(v):
        accounts = _object(_object(v).get("accounts"))
        entries = _object(_object(accounts.get(account, {"engines": {}})).get("engines"))
        for entry in entries.values():
            _object(entry)
            if entry.get("enabled") is not None and type(entry["enabled"]) is not bool:
                raise ValueError("invalid override enabled")
        return entries

    override, override_ok = source("kalshi-engine-account-overrides.json", overrides, optional=True)

    def registry(v):
        v = _object(v)
        for assignment in _object(v.get("assignments")).values():
            _ids(_object(assignment).get("symbols"))
        for entry in _object(v.get("accounts", {})).values():
            if type(_object(entry).get("exit_only")) is not bool:
                raise ValueError("invalid registry account")
        for roles in _object(v.get("roles_by_generation", {})).values():
            _object(roles)
        if "exit_only" in v and type(v["exit_only"]) is not bool:
            raise ValueError("invalid exit_only")
        return v

    registry_doc, registry_ok = source("engine-registry/projection.json", registry)
    candidates = []
    if account_ok and policy_ok:
        for book in OWNER_BOOKS:
            if binding_ok and override_ok:
                eid = binding["symbols"].get(book, binding.get("default"))
                if eid is not None:
                    candidates.append((eid, book, "incumbent"))
            if probe_ok and hosts_ok and registry_ok:
                candidates.extend((eid, book, "probe") for eid in probe.get(book, []))
    if len(candidates) > MAX_ROWS:
        raise ValueError("more than 1024 rows")
    rows = []
    balance = inputs.get("B_cents")
    for eid, book, role in candidates:
        engine_key, life_key = f"engines/{eid}.json", f"engine-lifecycle/{eid}.json"

        def engine(v):
            v = _object(v)
            if type(v.get("enabled")) is not bool:
                raise ValueError("enabled must be boolean")
            p = _object(v.get("policy"))
            for key in ("size_fraction", "size_scale", "per_order_fraction", "stake_ceiling_usd", "fixed_count"):
                if key in p:
                    _number(p[key])
            return v

        catalog, ok = source(engine_key, engine)

        def lifecycle(v):
            v = _object(v)
            if type(v.get("state")) is not str or type(v.get("entries_enabled")) is not bool:
                raise ValueError("invalid lifecycle")
            if v.get("entries_suspended_until") is not None:
                _number(v["entries_suspended_until"])
            if "policy" in v:
                _object(v["policy"])
            if v.get("expires_at") is not None:
                if type(v["expires_at"]) is not str:
                    raise ValueError("invalid expiry")
                stamp = datetime.fromisoformat(v["expires_at"].replace("Z", "+00:00"))
                if stamp.tzinfo is None:
                    raise ValueError("expiry requires timezone")
            return v

        life, life_ok = source(life_key, lifecycle, optional=True)
        if not ok or not life_ok:
            continue
        reasons = []
        # Probes refuse catalog-disabled engines at construction; this applies at their next construction.
        if not catalog["enabled"]:
            reasons.append("catalog_disabled")
        if life is not None:
            if life["state"] not in _ENTRY_STATES:
                reasons.append("lifecycle_state")
            if not life["entries_enabled"]:
                reasons.append("entries_disabled")
            if life.get("entries_suspended_until") is not None and _number(life["entries_suspended_until"]) * 1000 > now_ms:
                reasons.append("entries_suspended")
            if life.get("expires_at") is not None and datetime.fromisoformat(life["expires_at"].replace("Z", "+00:00")).timestamp() * 1000 <= now_ms:
                reasons.append("lifecycle_expired")
        elif role == "probe":
            reasons.append("lifecycle_missing")
        if role == "incumbent":
            if book in binding.get("disabled", []):
                reasons.append("book_disabled")
            item = (override or {}).get(eid)
            if item is not None:
                if type(item) is not dict or (item.get("enabled") is not None and type(item["enabled"]) is not bool):
                    errors[paths["kalshi-engine-account-overrides.json"]] = "malformed"
                    continue
                if item.get("enabled") is False:
                    reasons.append("override_disabled")
        else:
            if binding_ok and eid == binding["symbols"].get(book, binding.get("default")):
                reasons.append("probe_is_incumbent")
            if book not in hosted:
                reasons.append("not_hosted")
            assignment = registry_doc["assignments"].get(eid)
            if assignment is None or book not in assignment["symbols"] or assignment.get("domain") != "legacy-owner":
                reasons.append("registry_unassigned")
            else:
                owner = registry_doc.get("accounts", {}).get(assignment.get("account_id"), {})
                exit_only = registry_doc.get("exit_only", owner.get("exit_only"))
                roles = registry_doc.get("roles_by_generation", {})
                try:
                    points = [int(g) for g in roles if int(g) <= int(registry_doc["generation"])]
                    domain_role = roles[str(max(points))].get("legacy-owner") if points else None
                except (ValueError, KeyError, TypeError):
                    domain_role = None
                if exit_only is True or domain_role == "exit_only" or assignment.get("role") == "exit_only":
                    reasons.append("registry_exit_only")
                elif exit_only is not False and domain_role != "authority":
                    reasons.append("registry_unassigned")
        sizing = {}
        estimate = None
        try:
            p = catalog["policy"]
            if role == "probe":
                lp = (life or {}).get("policy", {})
                count = lp.get("fixed_count", (life or {}).get("contracts", p.get("fixed_count")))
                sizing = {"fixed_count": count, "contract_cost_cents": 100}
                estimate = _number(count) * 100
            else:
                sizing = {"size_fraction": p.get("size_fraction"), "size_scale": p.get("size_scale", 1),
                          "per_order_fraction": p.get("per_order_fraction"),
                          "stake_ceiling_usd": p.get("stake_ceiling_usd", policy.get("stake_ceiling_usd"))}
                if type(balance) is int and balance > 0:
                    estimate = min(Decimal(balance) * _number(sizing["size_fraction"]) * _number(sizing["size_scale"]),
                                   Decimal(balance) * _number(sizing["per_order_fraction"]),
                                   _number(sizing["stake_ceiling_usd"]) * 100)
        except (ValueError, TypeError, InvalidOperation):
            errors[paths.get(life_key if role == "probe" and life else engine_key, engine_key)] = "sizing_unavailable"
        leverage = None
        if estimate is not None and type(balance) is int and balance > 0:
            leverage = min(LEVERAGE_STEPS, key=lambda step: abs(Decimal(step) - 250 * estimate / balance))
        keys = ["dashboard-account.json", "kalshi-policy.json", engine_key, life_key]
        keys += (["kalshi-engine-bindings.json", "kalshi-engine-account-overrides.json"] if role == "incumbent"
                 else ["probe-bindings.json", "kalshi-probe-hosts", "engine-registry/projection.json"])
        row_evidence = {paths[k]: evidence[paths[k]] for k in keys if paths.get(k) in evidence}
        row_evidence.update({p: digest for p, digest in evidence.items() if p.startswith(inputs.get("ledger_path", "\0"))})
        rows.append({"engine": eid, "book": book, "role": role, "partition": None,
                     "on": not reasons, "off_reasons": sorted(reasons), "leverage": leverage,
                     "leverage_basis": {"A_est_cents": float(estimate) if estimate is not None else None,
                                        "B_cents": balance, "convention": "nearest-step-250A/B", "inputs": sizing},
                     "evidence": row_evidence})
    rows.sort(key=lambda row: (row["book"], row["engine"], row["role"]))
    return {"schema": SCHEMA, "account": account, "generated_at_ms": now_ms, "generation": 1,
            "source_digest": hashlib.sha256(_encode(sorted(evidence.items()))).hexdigest(),
            "B_cents": balance, "rows": rows,
            "counts": {"rows": len(rows), "on": sum(row["on"] for row in rows),
                       "off_by_reason": dict(sorted(Counter(r for row in rows for r in row["off_reasons"]).items()))},
            "source_errors": dict(sorted(errors.items())),
            "notes": ["Read-only derived view; not execution authority.",
                      "B is account-risk equity_cents, a sizing balance proxy.",
                      "A_est excludes conviction and favorite multipliers; ties choose the lower leverage step.",
                      "KILL markers and venue pause are runtime controls and are not represented.",
                      "Registry loss_breakers are thresholds, not evidence that a breaker has tripped."]}


def write_document(path, document, *, etc_dir=None):
    """Return written/unchanged; generation is assigned from the committed output."""
    path = Path(path).resolve()
    forbidden = [Path("/etc").resolve()]
    if etc_dir is not None:
        forbidden.append(Path(etc_dir).resolve())
    if any(path == root or root in path.parents for root in forbidden):
        raise ValueError("output must not be inside /etc or the input configuration directory")
    if len(document["rows"]) > MAX_ROWS:
        raise ValueError("more than 1024 rows")
    previous = None
    try:
        previous = _json(_read(path, MAX_OUTPUT_BYTES))
        if (type(previous) is not dict or previous.get("schema") != SCHEMA
                or type(previous.get("generation")) is not int or previous["generation"] < 1):
            raise ValueError("invalid previous generation")
    except FileNotFoundError:
        pass
    result = dict(document, generation=previous["generation"] + 1 if previous else 1)
    payload = _encode(result) + b"\n"
    if len(payload) > MAX_OUTPUT_BYTES:
        raise ValueError("output exceeds 2 MiB")
    if previous and all(previous.get(k) == result.get(k) for k in ("source_digest", "rows", "source_errors")):
        return "unchanged"
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".derived-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        if os.name != "nt":
            directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return "written"


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--etc", default="/etc/leafhft")
    parser.add_argument("--state", default="/var/lib/leafhft")
    parser.add_argument("--out", required=True)
    parser.add_argument("--print", action="store_true", dest="print_document")
    args = parser.parse_args(argv)
    try:
        document = derive(load_inputs(args.etc, args.state), now_ms=time.time_ns() // 1_000_000)
        status = write_document(args.out, document, etc_dir=args.etc)
        if args.print_document:
            print(_read(Path(args.out), MAX_OUTPUT_BYTES).decode(), end="")
        else:
            print(f"{status}: rows={document['counts']['rows']} on={document['counts']['on']} source_errors={len(document['source_errors'])}")
    except (OSError, ValueError) as exc:
        parser.exit(1, f"deployments derive refused: {exc}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
