"""Stage 2 paper fill calibration, grouped by placement distance, side and TIF.

Open orders remain in the fill-rate denominator and their rest times are censored.
Order outcomes are included so partial fills and censoring remain inspectable.
"""
from __future__ import annotations

import argparse
import json
import math
import sqlite3
import threading
import time
from pathlib import Path
from statistics import mean, median

from .ledger import Ledger, LedgerFailed
from .types import Side, TimeInForce

MAX_ROWS = 1_000_000
BUCKETS = ("0", "(0,0.5]", "(0.5,1]", "(1,2]", ">2", "unknown")


class _ReadOnlyLedger(Ledger):
    """Reuse Ledger.verify without the writable constructor or a flush on close."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.head_path = path.with_suffix(path.suffix + ".head")
        self._conn = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=2)
        self._lock = threading.Lock()
        self.failed = ""
        self._buf = []
        self._conn.execute("BEGIN")  # verification and aggregation share one snapshot

    def close(self) -> None:
        self._conn.close()


def wilson95(filled_n: int, n: int) -> list[float]:
    """Wilson score interval with z=1.96; no observations means [0, 1]."""
    if n < 0 or filled_n < 0 or filled_n > n:
        raise ValueError("expected 0 <= filled_n <= n")
    if n == 0:
        return [0.0, 1.0]
    p = filled_n / n
    z2 = 1.96**2
    denominator = 1 + z2 / n
    center = (p + z2 / (2 * n)) / denominator
    half = 1.96 * math.sqrt(p * (1 - p) / n + z2 / (4 * n * n)) / denominator
    return [0.0 if filled_n == 0 else max(0.0, center - half),
            1.0 if filled_n == n else min(1.0, center + half)]


def distance_bucket(side: str, price_i: int, mid_i: int | None) -> str:
    if not mid_i or mid_i < 0:
        return "unknown"
    # Crossing mid is the zero-distance cohort, on either side.
    distance = mid_i - price_i if side == "BUY" else price_i - mid_i
    if distance <= 0:
        return "0"
    # Integer comparisons preserve the exact fixed-point bucket boundaries.
    for numerator, label in ((1, "(0,0.5]"), (2, "(0.5,1]"), (4, "(1,2]")):
        if distance * 20_000 <= mid_i * numerator:
            return label
    return ">2"


def _enum_name(value: int | str, enum_type: type) -> str:
    return enum_type[value].name if isinstance(value, str) else enum_type(value).name


def _key(cohort: dict) -> tuple[str, str, str]:
    return cohort["side"], cohort["bucket"], cohort["tif"]


def _sort_key(key: tuple[str, str, str]) -> tuple:
    side, bucket, tif = key
    return bucket == "unknown", side, BUCKETS.index(bucket), tif


def compute(run_dir: Path, now_ns: int | None = None) -> dict:
    """Read all persisted rows, or return an error without partial statistics.

    Each order_outcomes entry contains state, filled_fraction, rest_ms and
    censored. A fill's filled_i, when supplied, is its executed size; otherwise
    size_i is used. Anonymous stale-cancel rows cannot close a specific order.
    computed_ts is the computation time in Unix nanoseconds.
    """
    run_dir = Path(run_dir)
    failure = {"run_id": run_dir.name, "ledger_ok": False, "error": "chain"}
    ledger = None
    try:
        ledger = _ReadOnlyLedger(run_dir / "ledger.sqlite")
        conn = ledger._conn
        count = conn.execute("SELECT COUNT(*) FROM (SELECT rowid FROM events LIMIT ?)", (MAX_ROWS + 1,)).fetchone()[0]
        if count > MAX_ROWS:
            return {**failure, "error": "row limit"}
        ok, count = ledger.verify()
        if not ok:
            return failure
        last = conn.execute("SELECT ts_ns, hash FROM events ORDER BY rowid DESC LIMIT 1").fetchone()
        ledger._count = count
        ledger._prev_hash = last[1] if last else "0" * 64
        ledger._check_head_sidecar()
        end_ns = now_ns if now_ns is not None else (last[0] if last else 0)
        orders: dict = {}
        fills: dict = {}
        cancels: dict = {}
        for ts, kind, raw in conn.execute("SELECT ts_ns, kind, body FROM events ORDER BY rowid"):
            if kind not in ("order", "fill", "cancel"):
                continue
            body = json.loads(raw)
            if kind == "order":
                oid = body["id"]
                if oid in orders or body["size_i"] <= 0:
                    raise ValueError("duplicate order or invalid size")
                orders[oid] = (ts, body)
            elif kind == "fill":
                size = body.get("filled_i", body.get("size_i", 0))
                if size < 0:
                    raise ValueError("negative fill size")
                if size:
                    entry = fills.setdefault(body["order_id"], [0, ts])
                    entry[0] += size
            else:
                cancels.setdefault(body["order_id"], ts)
        outcomes = []
        groups: dict = {}
        for oid, (ts, body) in orders.items():
            side = _enum_name(body["side"], Side)
            tif = _enum_name(body["tif"], TimeInForce)
            bucket = distance_bucket(side, body["price_i"], body.get("mid_i"))
            filled_size, fill_ts = fills.get(oid, (0, None))
            cancel_ts = cancels.get(oid)
            fraction = min(1.0, filled_size / body["size_i"])
            state = "filled" if fraction >= 0.999 else "partial" if fraction > 0 else "cancelled" if cancel_ts is not None else "open"
            event_times = [t for t in (fill_ts, cancel_ts) if t is not None]
            rest_ms = max(0, (min(event_times) if event_times else end_ns) - ts) / 1_000_000
            outcome = {"order_id": oid, "side": side, "bucket": bucket, "tif": tif,
                       "state": state, "filled_fraction": fraction, "rest_ms": rest_ms,
                       "censored": state == "open"}
            outcomes.append(outcome)
            group = groups.setdefault((side, bucket, tif), {"outcomes": [], "fill_ms": [], "cancel_ms": []})
            group["outcomes"].append(outcome)
            if state == "filled":
                group["fill_ms"].append(max(0, fill_ts - ts) / 1_000_000)
            if cancel_ts is not None:
                group["cancel_ms"].append(max(0, cancel_ts - ts) / 1_000_000)
        cohorts = []
        for key in sorted(groups, key=_sort_key):
            side, bucket, tif = key
            group = groups[key]
            items = group["outcomes"]
            n = len(items)
            counts = {state + "_n": sum(o["state"] == state for o in items)
                      for state in ("filled", "partial", "cancelled", "open")}
            cohorts.append({"side": side, "bucket": bucket, "tif": tif, "n": n, **counts,
                            "censored_n": counts["open_n"], "fill_rate": counts["filled_n"] / n,
                            "wilson95": wilson95(counts["filled_n"], n),
                            "median_rest_to_fill_ms": median(group["fill_ms"]) if group["fill_ms"] else None,
                            "median_rest_to_cancel_ms": median(group["cancel_ms"]) if group["cancel_ms"] else None,
                            "mean_filled_fraction": mean(o["filled_fraction"] for o in items)})
        return {"run_id": run_dir.name, "source": "paper", "orders": len(outcomes),
                "orders_without_mid": sum(o["bucket"] == "unknown" for o in outcomes),
                "cohorts": cohorts, "order_outcomes": outcomes, "computed_ts": time.time_ns(), "ledger_ok": True}
    except (sqlite3.Error, LedgerFailed, OSError):
        return failure
    except (ValueError, KeyError, TypeError, OverflowError):
        return {**failure, "error": "invalid ledger data"}
    finally:
        if ledger is not None:
            ledger.close()


def write(run_dir: Path) -> Path:
    run_dir = Path(run_dir)
    report = compute(run_dir)
    path = run_dir / "calibration.json"
    path.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    return path


def compare(paper: dict, live: dict) -> dict:
    """Compare shared cohorts; weight headline relative error by live orders."""
    if paper.get("ledger_ok") is False or live.get("ledger_ok") is False:
        return {"error": "unverified calibration report"}
    p = {_key(c): c for c in paper["cohorts"]}
    l = {_key(c): c for c in live["cohorts"]}
    cohorts = []
    for key in sorted(p.keys() & l.keys(), key=_sort_key):
        pc, lc = p[key], l[key]
        rate = lc["fill_rate"]
        cohorts.append({"side": key[0], "bucket": key[1], "tif": key[2],
                        "paper_rate": pc["fill_rate"], "live_rate": rate, "live_n": lc["n"],
                        "relative_error": abs(rate - pc["fill_rate"]) / max(pc["fill_rate"], 1e-9),
                        "inside_paper_interval": pc["wilson95"][0] <= rate <= pc["wilson95"][1]})
    uncompared = [{"side": k[0], "bucket": k[1], "tif": k[2], "missing": "live" if k in p else "paper"}
                  for k in sorted(p.keys() ^ l.keys(), key=_sort_key)]
    weight = sum(c["live_n"] for c in cohorts)
    return {"cohorts": cohorts, "uncompared": uncompared, "cohorts_compared": len(cohorts),
            "cohorts_inside": sum(c["inside_paper_interval"] for c in cohorts),
            "headline_relative_error": sum(c["relative_error"] * c["live_n"] for c in cohorts) / weight if weight else None}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--run-dir", type=Path)
    mode.add_argument("--compare", nargs=2, type=Path, metavar=("PAPER", "LIVE"))
    args = parser.parse_args(argv)
    if args.run_dir is not None:
        report = json.loads(write(args.run_dir).read_text(encoding="utf-8"))
    else:
        report = compare(*(json.loads(p.read_text(encoding="utf-8")) for p in args.compare))
    print(json.dumps(report, indent=2, allow_nan=False))
    return 2 if report.get("ledger_ok") is False or "error" in report else 0


if __name__ == "__main__":
    raise SystemExit(main())
