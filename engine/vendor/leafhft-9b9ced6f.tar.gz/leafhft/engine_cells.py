"""Live engine evidence for the owner's calibrated sizing view.

The I/O adapter supplies ``model_fee_cents`` from costs.order_fee_cents when
the venue did not report a fee. Keeping that dependency at the boundary makes
this module usable without importing a broker or a runner.
"""
from __future__ import annotations

from collections import Counter, deque
from copy import deepcopy
from decimal import Decimal, InvalidOperation, localcontext
import json
import math
import re

import leafhft.research.calibrated_sizing as calibrated_sizing


SCHEMA = "leafhft.engine-cells.v1"
MAX_BYTES = 65536
MAX_PAIRS = 2000


class CellRejected(ValueError):
    def __init__(self, reason):
        self.reason = reason
        super().__init__(reason)


def canonical(doc):
    return json.dumps(doc, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("ascii")


def exact(value, reason):
    """Only exact JSON numbers: integer cents or fixed-point strings."""
    if isinstance(value, bool) or not isinstance(value, (int, str, Decimal)):
        raise CellRejected(reason)
    if isinstance(value, str) and (len(value) > 100 or not re.fullmatch(r"-?\d+(?:\.\d+)?", value)):
        raise CellRejected(reason)
    try:
        number = Decimal(value)
    except (InvalidOperation, ValueError):
        raise CellRejected(reason) from None
    if (not number.is_finite() or len(number.as_tuple().digits) > 40
            or abs(number.as_tuple().exponent) > 40):
        raise CellRejected(reason)
    return number


def count_exact(value, reason):
    """A contract count: exact(), or the live broker's JSON-number fraction (hundredths).

    kalshi_live._count_number writes whole counts as ints and fractional counts as floats, so
    a float is accepted only when finite, non-integral and its repr is at most two decimals
    (5.98, 0.25); 0.125, 1e2 (100.0), NaN, inf and bools fail closed with reason."""
    if type(value) is float:
        if (not math.isfinite(value) or value == int(value)
                or not re.fullmatch(r"[0-9]+\.[0-9]{1,2}", repr(value))):
            raise CellRejected(reason)
        return Decimal(repr(value))
    return exact(value, reason)


def identifier(value):
    return (isinstance(value, str) and len(value) <= 128
            and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", value) is not None
            and value not in (".", ".."))


def window_ms(row):
    for key in ("window", "close_time_ms", "close_ms", "market_close_ms"):
        if row.get(key) is not None:
            value = exact(row[key], "invalid_window")
            break
    else:
        value = exact(row.get("settlement_minute"), "invalid_window") * 60000
    if value <= 0 or value != value.to_integral_value() or value > 10**15:
        raise CellRejected("invalid_window")
    return int(value)


def fill_fee(row):
    """Fee in cents and its provenance; zero is a reported fee too."""
    for key in ("venue_fee_cents", "reported_fee_cents", "fee_cents"):
        if row.get(key) is not None:
            # The incumbent persists a model fee on intent-basis rows.
            if key == "fee_cents" and row.get("price_basis") == "intent":
                continue
            fee = exact(row[key], "invalid_fee")
            basis = "reported"
            break
    else:
        if row.get("model_fee_cents") is None:
            raise CellRejected("missing_fee")
        fee = exact(row["model_fee_cents"], "invalid_fee")
        basis = "model_upper_bound"
    if fee < 0:
        raise CellRejected("invalid_fee")
    return fee, basis


def ticket_values(entry, outcome):
    """Exact normalized economics; pnl_cents on an outcome is already net."""
    if not isinstance(entry, dict) or not isinstance(outcome, dict):
        raise CellRejected("invalid_ticket")
    if entry.get("provenance", "live_fill") != "live_fill":
        raise CellRejected("invalid_provenance")
    symbol = entry.get("symbol")
    if not identifier(symbol):
        raise CellRejected("invalid_symbol")
    price = exact(entry.get("entry_price_cents", entry.get("price_cents")), "invalid_price")
    if not 0 < price < 100:
        raise CellRejected("invalid_price")
    count = exact(entry.get("count"), "invalid_count")
    if count <= 0 or count * 100 != (count * 100).to_integral_value():
        raise CellRejected("invalid_count")
    fee, basis = fill_fee(entry)
    window = window_ms(entry)
    if outcome.get("kind", "settle") not in ("settle", "exit", "void"):
        raise CellRejected("invalid_outcome")
    with localcontext() as ctx:
        ctx.prec = 120
        # The broker's whole-cent all-in cost when the ticket carries it; else the exact product.
        cost = (exact(entry["cost_cents"], "invalid_cost") if entry.get("cost_cents") is not None
                else price * count + fee)
        if cost < fee or cost <= 0:
            raise CellRejected("invalid_cost")
        exit_fee = exact(outcome.get("exit_fee_cents", 0), "invalid_fee")
        if exit_fee < 0:
            raise CellRejected("invalid_fee")
        if "pnl_cents" in outcome:
            pnl = exact(outcome["pnl_cents"], "invalid_pnl")
        elif outcome.get("kind") == "void":
            pnl = Decimal(0)
        elif "payout_cents" in outcome:
            pnl = exact(outcome["payout_cents"], "invalid_pnl") - cost - exit_fee
        elif type(outcome.get("won")) is bool:
            pnl = (100 * count if outcome["won"] else Decimal(0)) - cost - exit_fee
        else:
            raise CellRejected("missing_pnl")
        ratio = pnl / cost
    if not math.isfinite(float(ratio)):
        raise CellRejected("invalid_pnl")
    if outcome.get("fee_basis") == "model_upper_bound":
        basis = "model_upper_bound"
    return symbol, price, count, fee + exit_fee, basis, window, pnl, ratio


def ticket_cell(entry, outcome):
    symbol, price, _, _, _, window, _, ratio = ticket_values(entry, outcome)
    return symbol, calibrated_sizing.claimed_bucket(price / 100), ratio, window


class Cells:
    def __init__(self, model_fee=None):
        self.cells = {}
        self.fee_basis = Counter(reported=0, model_upper_bound=0)
        self.rejected = Counter()
        self.model_fee = model_fee

    def reject(self, reason):
        self.rejected[reason.reason if isinstance(reason, CellRejected) else str(reason)] += 1

    def add(self, entry, outcome):
        if self.model_fee is not None:
            try:
                fill_fee(entry)
            except CellRejected as exc:
                if exc.reason == "missing_fee":
                    entry = dict(entry, model_fee_cents=self.model_fee(
                        exact(entry.get("entry_price_cents", entry.get("price_cents")), "invalid_price"),
                        exact(entry.get("count"), "invalid_count")))
                else:
                    raise
        symbol, price, _, _, basis, window, _, ratio = ticket_values(entry, outcome)
        bucket = calibrated_sizing.claimed_bucket(price / 100)
        cell = self.cells.setdefault(symbol, {}).setdefault(bucket, {
            "n": 0, "wins": 0, "returns": deque(maxlen=MAX_PAIRS), "windows": deque(maxlen=MAX_PAIRS)})
        cell["n"] += 1
        cell["wins"] += int(ratio > 0)
        cell["returns"].append(float(ratio))
        cell["windows"].append(window)
        self.fee_basis[basis] += 1
        return symbol, bucket, ratio, window

    def to_document(self, engine_id):
        doc = {"schema": SCHEMA, "engine_id": engine_id, "provenance": "live_fill",
               "bucket_basis": "entry_price", "fee_basis": dict(self.fee_basis),
               "cells": {s: {b: {"n": c["n"], "wins": c["wins"],
                                   "returns": list(c["returns"]), "windows": list(c["windows"])}
                             for b, c in buckets.items()} for s, buckets in self.cells.items()},
               "rejected": dict(self.rejected)}
        cells = [c for buckets in doc["cells"].values() for c in buckets.values()]
        size = len(canonical(doc))
        while size > MAX_BYTES:
            pairs = sum(len(c["returns"]) for c in cells)
            if not pairs:
                raise ValueError("cell metadata exceeds byte limit")
            # Remove a proportional batch, oldest first in each cell. Re-encode
            # once per pass rather than once per pair on a large engine.
            remove = max(1, math.ceil(pairs * (1 - MAX_BYTES / size)))
            for c in sorted(cells, key=lambda c: len(c["returns"]), reverse=True):
                take = min(len(c["returns"]), max(1, math.ceil(remove * len(c["returns"]) / pairs)))
                del c["returns"][:take]
                del c["windows"][:take]
            size = len(canonical(doc))
        validate_document(doc)
        return doc

    @classmethod
    def from_document(cls, doc):
        validate_document(doc)
        result = cls()
        result.cells = deepcopy(doc["cells"])
        for buckets in result.cells.values():
            for cell in buckets.values():
                for key in ("returns", "windows"):
                    cell[key] = deque(cell[key], maxlen=MAX_PAIRS)
        result.fee_basis = Counter(doc["fee_basis"])
        result.rejected = Counter(doc["rejected"])
        return result


def validate_document(doc):
    def count(v):
        return type(v) is int and v >= 0

    if (not isinstance(doc, dict) or doc.get("schema") != SCHEMA
            or doc.get("provenance") != "live_fill" or doc.get("bucket_basis") != "entry_price"
            or not identifier(doc.get("engine_id"))):
        raise ValueError("invalid cell document identity")
    if set(doc) != {"schema", "engine_id", "provenance", "bucket_basis", "fee_basis", "cells", "rejected"}:
        raise ValueError("invalid cell document fields")
    fees, rejected, cells = doc["fee_basis"], doc["rejected"], doc["cells"]
    if (not isinstance(fees, dict) or set(fees) != {"reported", "model_upper_bound"}
            or not all(count(v) for v in fees.values()) or not isinstance(rejected, dict)
            or not all(isinstance(k, str) and k and count(v) for k, v in rejected.items())
            or not isinstance(cells, dict)):
        raise ValueError("invalid cell counters")
    buckets = {calibrated_sizing.claimed_bucket(p) for p in (0, .7, .8, .9, .95)}
    total = 0
    for symbol, groups in cells.items():
        if not identifier(symbol) or not isinstance(groups, dict):
            raise ValueError("invalid cell symbol")
        for bucket, cell in groups.items():
            if (bucket not in buckets or not isinstance(cell, dict)
                    or set(cell) != {"n", "wins", "returns", "windows"}
                    or not count(cell["n"]) or not count(cell["wins"])
                    or cell["wins"] > cell["n"]):
                raise ValueError("invalid cell totals")
            returns, windows = cell["returns"], cell["windows"]
            if (not isinstance(returns, list) or not isinstance(windows, list)
                    or len(returns) != len(windows) or len(returns) > min(MAX_PAIRS, cell["n"])
                    or not all(type(r) in (int, float) and math.isfinite(r) for r in returns)
                    or not all(type(w) is int and 0 < w <= 10**15 for w in windows)
                    or sum(r > 0 for r in returns) > cell["wins"]
                    or sum(r <= 0 for r in returns) > cell["n"] - cell["wins"]):
                raise ValueError("invalid cell pairs")
            total += cell["n"]
    if sum(fees.values()) != total:
        raise ValueError("fee counts do not match cells")
    if len(canonical(doc)) > MAX_BYTES:
        raise ValueError("cell document exceeds byte limit")
