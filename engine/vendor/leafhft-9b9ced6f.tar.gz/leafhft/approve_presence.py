"""Identity-grade Telegram presence for `engine_ops approve` (contract C6c, interim until RT5).

The runner sends the operator ONE card through a dedicated approvals bot and reads his reply
straight from the Bot API over TLS: never the desktop bridge, never a file a desktop process
wrote. Telegram's servers attest `from.id`, and a bot token cannot forge an inbound user message.
That attestation is the whole control, so an approval minted from it is IDENTITY grade, not
presence grade: its id carries the `tg1-` prefix and its sidecar a `grade` field that say so.
Root on the runner, or anyone driving the operator's Telegram client, can still forge one
(residuals R1 and R2 of the C6c contract). RT5's signed approvals replace this module.

This module holds the pinned trust roots, the Bot API client, the aws-cli secret fetcher, the
reply matcher, the card renderer, the root-only store check and the exclusive publish;
engine_ops composes them. It imports nothing from leafhft, so it can never form an import cycle
with the consumer.

One open card per store: the contract's single poller demultiplexing every issued record is
implemented as serialization. engine_ops holds the store's presence lock from before the card
until its record is terminal and polls for that one record only; a second approve while a card is
open is refused (presence_busy while the lock is held, presence_pending_other while an earlier
card's window is still open), so no poll can swallow another card's reply.

Hardening: every read and every response is bounded and strictly decoded, every network call has
a timeout, the bot token lives only in process memory and the request URL, the aws cli child sees
only an allowlisted environment (instance role only), every file opened in the store is fstat
checked (store_file_problem), and every error string passes `redact` before it leaves this module.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import socket
import stat
import subprocess
import tempfile
import time
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, Mapping
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

# Pinned trust roots: set in the reviewed PR, never from argv, a config file or the environment.
OPERATOR_TELEGRAM_USER_ID = 1987644052
APPROVALS_SECRET_ID = "leafhft/approvals-telegram"
GRADE = "identity-telegram-v1"
ID_PREFIX = "tg1-"

NOTIFY_SECRET_ID_PATH = Path("/etc/leafhft/notify-secret-id")
API_ROOT = "https://api.telegram.org"
AWS_REGION = "us-east-1"

MAX_SECRET_BYTES = 1024
MAX_NOTIFY_SECRET_BYTES = 4096
MAX_SECRET_ID_BYTES = 2048
MAX_RESPONSE_BYTES = 1024 * 1024
MAX_CARD_CHARS = 1500
MAX_WAVE_CARD_CHARS = 4096
MAX_REPLY_CHARS = 256
MAX_UPDATES = 100
MAX_STORE_COMPONENTS = 16
MAX_PROMPT_LOG_TAIL = 64 * 1024
SECRET_TIMEOUT_S = 30
SEND_TIMEOUT_S = 10
POLL_TIMEOUT_S = 25
POLL_HTTP_TIMEOUT_S = 35
REPLY_WINDOW_S = 600
WAIT_S = 630
RETRY_LIMIT = 5
RETRY_CAP_S = 5.0
# Raised from 3 and 6 on the operator's word, 2026-09-29: "why so slow? Lets do them all now".
CARDS_PER_HOUR = 12
CARDS_PER_DAY = 24
MISMATCH_LIMIT = 3
NONCE_LENGTH = 6
CROCKFORD = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
TITLE = "Kashbot probe approval (identity grade, tg1)"
WAVE_TITLE = "Kashbot wave approval (identity grade, tg1)"
FORWARD_KEYS = ("forward_origin", "forward_from", "forward_from_chat", "via_bot", "sender_chat")
# The only parent variables the aws cli child sees (SYSTEMROOT, TEMP and TMP matter on Windows only).
AWS_CHILD_ENV_KEYS = ("PATH", "LANG", "AWS_REGION", "AWS_DEFAULT_REGION", "SYSTEMROOT", "TEMP", "TMP")

_TOKEN = re.compile(r"(\d{1,20}):[A-Za-z0-9_-]{20,128}")
# runner_notify.py:39-40 shapes, plus a bare id:secret pair wherever it appears.
_TOKEN_SHAPES = re.compile(r"api\.telegram\.org/bot\S*|bot\d+:[A-Za-z0-9_-]{20,}|\b\d{5,20}:[A-Za-z0-9_-]{20,}")
_REPLY_SPLIT = re.compile(r"[\s,]+")
_CONFUSABLE = str.maketrans({"O": "0", "I": "1", "L": "1"})


class PresenceError(Exception):
    """A presence-channel failure. Its text is redacted before it is raised."""


class SecretUnavailable(PresenceError):
    """A secret is absent, unreadable or not the exact shape this module accepts."""


class TelegramError(PresenceError):
    """A Bot API call failed, timed out or answered something this module does not accept."""


class StoreInsecure(PresenceError):
    """A component of the approval store's path is not root-only."""


class PublishCollision(PresenceError):
    """A different document already holds the name being published."""


# ---------------------------------------------------------------- small pure helpers

def redact(text: Any, *values: str | None) -> str:
    """Scrub bot tokens (the runner_notify shapes plus each exact value and its secret half);
    at most 300 characters, so an error string can never carry a token to a log."""
    shown = str(text)
    for value in values:
        if value:
            shown = shown.replace(value, "[redacted]")
            half = value.partition(":")[2]
            if len(half) >= 8:
                shown = shown.replace(half, "[redacted]")
    return _TOKEN_SHAPES.sub("[redacted]", shown)[:300]


def _pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in items:
        if key in out:
            raise ValueError(f"duplicate key {key!r}")
        out[key] = value
    return out


def _no_constant(token: str) -> Any:
    raise ValueError(f"non-finite number {token}")


def strict_json(data: bytes) -> Any:
    """Duplicate keys, NaN and Infinity raise ValueError; never a half-understood value."""
    return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=_no_constant)


def text_sha256(text: str) -> str:
    return sha256(text.encode("utf-8")).hexdigest()


def is_root() -> bool:
    """True when the approve verb may run: euid 0 on POSIX (the store is root-only)."""
    return os.name != "posix" or os.geteuid() == 0


def host_name() -> str:
    try:
        return socket.gethostname()[:64] or "unknown"
    except OSError:
        return "unknown"


def backoff_sleep(seconds: float) -> None:
    time.sleep(seconds)


def parse_utc(value: Any) -> datetime | None:
    if type(value) is not str or not 0 < len(value) <= 64:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed.astimezone(timezone.utc) if parsed.tzinfo is not None else None


# ---------------------------------------------------------------- secrets

def bot_id(token: str) -> int:
    match = _TOKEN.fullmatch(token) if type(token) is str else None
    if match is None:
        raise SecretUnavailable("bot token is malformed")
    return int(match.group(1))


def approvals_token(text: Any) -> str:
    """The approvals secret: strict JSON holding exactly {telegram_bot_token}, at most 1 KiB."""
    data = text.encode("utf-8") if type(text) is str else b""
    if not data or len(data) > MAX_SECRET_BYTES:
        raise SecretUnavailable(f"approvals secret is empty or larger than {MAX_SECRET_BYTES} bytes")
    try:
        doc = strict_json(data)
    except (UnicodeError, ValueError, RecursionError):
        raise SecretUnavailable("approvals secret is not strict JSON") from None
    if not isinstance(doc, dict) or set(doc) != {"telegram_bot_token"}:
        raise SecretUnavailable("approvals secret must hold exactly telegram_bot_token")
    token = doc["telegram_bot_token"]
    bot_id(token)
    return token


def notify_bot_id(text: Any) -> int:
    """The notify bot's id from the notify secret ({telegram_bot_token, telegram_chat_id})."""
    data = text.encode("utf-8") if type(text) is str else b""
    if not data or len(data) > MAX_NOTIFY_SECRET_BYTES:
        raise SecretUnavailable("notify secret is empty or too large")
    try:
        doc = strict_json(data)
    except (UnicodeError, ValueError, RecursionError):
        raise SecretUnavailable("notify secret is not strict JSON") from None
    if not isinstance(doc, dict):
        raise SecretUnavailable("notify secret is not an object")
    return bot_id(doc.get("telegram_bot_token"))


def read_secret_id(path: Path) -> str:
    """One secret id from a root-owned pointer file (bounded, one token, no whitespace)."""
    try:
        with open(path, "rb") as stream:
            data = stream.read(MAX_SECRET_ID_BYTES + 1)
    except OSError as exc:
        raise SecretUnavailable(f"{path}: {type(exc).__name__}") from None
    try:
        secret_id = data.decode("utf-8").strip()
    except UnicodeError:
        raise SecretUnavailable(f"{path}: not UTF-8") from None
    if not secret_id or len(data) > MAX_SECRET_ID_BYTES or any(char.isspace() for char in secret_id):
        raise SecretUnavailable(f"{path}: not one secret id")
    return secret_id


def aws_child_env(parent: Mapping[str, str]) -> dict[str, str]:
    """The aws cli child's whole environment, built from an allowlist so only the instance role can
    answer: no profile, static key, session token, credentials or config file, container or web
    identity source, endpoint override or metadata switch crosses from the parent. Both files are
    pinned to os.devnull; AWS_EC2_METADATA_DISABLED is never passed."""
    env = {key: parent[key] for key in AWS_CHILD_ENV_KEYS if type(parent.get(key)) is str}
    env.update(AWS_CONFIG_FILE=os.devnull, AWS_SHARED_CREDENTIALS_FILE=os.devnull, AWS_PAGER="",
               AWS_CLI_AUTO_PROMPT="off")
    return env


def fetch_secret(secret_id: str) -> str:
    """SecretString through the aws cli on the instance role only (aws_child_env: an allowlisted
    environment, both credential files os.devnull); stdout is captured, returned and never logged."""
    if (type(secret_id) is not str or not 0 < len(secret_id) <= MAX_SECRET_ID_BYTES
            or any(char.isspace() for char in secret_id)):
        raise SecretUnavailable("secret id is malformed")
    try:
        result = subprocess.run(
            ["aws", "secretsmanager", "get-secret-value", "--region", AWS_REGION, "--secret-id", secret_id,
             "--query", "SecretString", "--output", "text"],
            capture_output=True, timeout=SECRET_TIMEOUT_S, env=aws_child_env(os.environ))
    except (OSError, subprocess.SubprocessError) as exc:
        raise SecretUnavailable(f"{secret_id}: aws cli {type(exc).__name__}") from None
    if result.returncode != 0:
        raise SecretUnavailable(f"{secret_id}: aws cli exit {result.returncode}")
    if len(result.stdout) > MAX_NOTIFY_SECRET_BYTES + 2:
        raise SecretUnavailable(f"{secret_id}: larger than {MAX_NOTIFY_SECRET_BYTES} bytes")
    try:
        return result.stdout.decode("utf-8").strip()
    except UnicodeError:
        raise SecretUnavailable(f"{secret_id}: not UTF-8") from None


# ---------------------------------------------------------------- the Bot API

class BotClient:
    """The approvals bot over TLS. The token lives in this object and the request URL only; every
    call has a timeout, every response is at most 1 MiB of strict JSON, and every failure raises a
    redacted TelegramError (an unreadable answer is never read as an empty one)."""

    def __init__(self, token: str) -> None:
        bot_id(token)
        self._token = token

    def _call(self, method: str, payload: Mapping[str, Any], timeout_s: float) -> Any:
        body = json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode("ascii")
        request = Request(f"{API_ROOT}/bot{self._token}/{method}", data=body, method="POST",
                          headers={"Content-Type": "application/json"})
        try:
            with urlopen(request, timeout=timeout_s) as response:
                data = response.read(MAX_RESPONSE_BYTES + 1)
        except HTTPError as exc:
            raise TelegramError(f"{method}: http {exc.code}") from None
        except (URLError, OSError, ValueError) as exc:
            raise TelegramError(redact(f"{method}: {type(exc).__name__}: {exc}", self._token)) from None
        if len(data) > MAX_RESPONSE_BYTES:
            raise TelegramError(f"{method}: response exceeds {MAX_RESPONSE_BYTES} bytes")
        try:
            doc = strict_json(data)
        except (UnicodeError, ValueError, RecursionError):
            raise TelegramError(f"{method}: response is not strict JSON") from None
        if not isinstance(doc, dict) or doc.get("ok") is not True or "result" not in doc:
            raise TelegramError(f"{method}: not ok")
        return doc["result"]

    def get_me(self) -> Any:
        return self._call("getMe", {}, SEND_TIMEOUT_S)

    def send(self, text: str, entities: list[dict[str, Any]]) -> dict[str, Any]:
        payload: dict[str, Any] = {"chat_id": OPERATOR_TELEGRAM_USER_ID, "text": text,
                                   "disable_web_page_preview": True}
        if entities:
            payload["entities"] = entities
        result = self._call("sendMessage", payload, SEND_TIMEOUT_S)
        if not isinstance(result, dict):
            raise TelegramError("sendMessage: result is not a message")
        return {"message_id": result.get("message_id"), "date": result.get("date"), "text": result.get("text")}

    def updates(self, offset: int, timeout_s: int) -> list[Any]:
        result = self._call("getUpdates", {"offset": offset, "timeout": timeout_s, "limit": MAX_UPDATES,
                                           "allowed_updates": ["message"]},
                            timeout_s + (POLL_HTTP_TIMEOUT_S - POLL_TIMEOUT_S))
        if not isinstance(result, list) or len(result) > MAX_UPDATES:
            raise TelegramError("getUpdates: result is not a bounded list")
        return result


# ---------------------------------------------------------------- nonces, card and reply matcher

def new_nonces(count: int) -> list[str]:
    """`count` distinct 6-character Crockford nonces (no I, L, O or U), from `secrets`."""
    found: list[str] = []
    while len(found) < count:
        nonce = "".join(secrets.choice(CROCKFORD) for _ in range(NONCE_LENGTH))
        if nonce not in found:
            found.append(nonce)
    return found


def normalize_nonce(token: str) -> str:
    return token.upper().replace("-", "").translate(_CONFUSABLE)


def parse_reply(text: Any, nonces: Iterable[str]) -> str | list[str] | None:
    """The string NO, the sorted nonces named, or None when any token is not a nonce of this card."""
    if type(text) is not str or not 0 < len(text) <= MAX_REPLY_CHARS:
        return None
    stripped = text.strip()
    if stripped == "NO":
        return "NO"
    wanted = set(nonces)
    tokens = [normalize_nonce(token) for token in _REPLY_SPLIT.split(stripped) if token]
    if not tokens or any(token not in wanted for token in tokens):
        return None
    return sorted(set(tokens))


def _is_id(value: Any, expected: Any) -> bool:
    return type(value) is int and value == expected


def classify_update(update: Any, *, card: Mapping[str, Any], bot: int,
                    nonces: Iterable[str]) -> tuple[str, Any]:
    """One Bot API update against the open card: ("accept", "NO" or [nonces]), ("mismatch", None),
    ("edited", None) or ("ignore", reason). Only the pinned operator, in his private chat, replying
    to THIS unedited card and dated inside the window by Telegram's clock, can accept; an update
    from anywhere else is ignored and never voids the card."""
    message = update.get("message") if isinstance(update, dict) else None
    if not isinstance(message, dict):
        return "ignore", "not_a_message"
    chat, sender = message.get("chat"), message.get("from")
    if (not isinstance(chat, dict) or chat.get("type") != "private"
            or not _is_id(chat.get("id"), OPERATOR_TELEGRAM_USER_ID)):
        return "ignore", "other_chat"
    if (not isinstance(sender, dict) or not _is_id(sender.get("id"), OPERATOR_TELEGRAM_USER_ID)
            or sender.get("is_bot") is not False):
        return "ignore", "other_sender"
    if any(key in message for key in FORWARD_KEYS):
        return "ignore", "forwarded"
    reply = message.get("reply_to_message")
    if not isinstance(reply, dict) or not _is_id(reply.get("message_id"), card["message_id"]):
        return "ignore", "not_a_reply_to_the_card"
    origin = reply.get("from")
    if not isinstance(origin, dict) or not _is_id(origin.get("id"), bot):
        return "ignore", "not_a_reply_to_the_card"
    date = message.get("date")
    if type(date) is not int or not card["date"] <= date <= card["date"] + REPLY_WINDOW_S:
        return "ignore", "outside_window"
    shown = reply.get("text")
    if "edit_date" in reply or type(shown) is not str or text_sha256(shown) != card["text_sha256"]:
        return "edited", None
    decision = parse_reply(message.get("text"), nonces)
    if decision is None:
        return "mismatch", None
    return "accept", decision


def _ascii(text: str) -> str:
    """Printable ASCII kept one for one (newlines too), everything else '?', so offsets hold."""
    return "".join(char if char == "\n" or " " <= char <= "~" else "?" for char in str(text))


def render_card(*, host: str, code_sha: str, account: str, items: list[Mapping[str, Any]],
                window_days: int, claim_by: datetime, expires: datetime,
                closes: datetime) -> tuple[str, list[dict[str, Any]]]:
    """The card text (ASCII, at most 1500 characters, no parse_mode) and one `code` entity per
    nonce. Raises ValueError when the card would be longer."""
    parts: list[str] = []
    entities: list[dict[str, Any]] = []

    def add(text: str) -> None:
        parts.append(_ascii(text))

    def add_code(text: str) -> None:
        entities.append({"type": "code", "offset": sum(len(part) for part in parts), "length": len(text)})
        parts.append(_ascii(text))

    add(TITLE + "\n")
    add(f"host {host}, runner checkout {code_sha[:12]} (not bound to the approval)\n")
    add(f"account {account}\n")
    for index, item in enumerate(items, 1):
        add(f"{index}. book {'+'.join(item['symbols'])}, engine {item['engine_id']} "
            f"(manifest {item['manifest_digest'][:6]}), 1 contract, displaces {item['displaces']}, "
            f"breakers engine {item['engine_pct']}% account {item['account_pct']}%, nonce ")
        add_code(item["nonce"])
        add(f", digest {item['digest'][:12]}\n")
    add(f"probe window {window_days} d, claim by {claim_by:%H:%M}Z, expires {expires:%Y-%m-%d %H:%M}Z\n")
    add(f"Reply to THIS message with the nonces you approve, or NO. Closes {closes:%H:%M}Z.")
    text = "".join(parts)
    if len(text) > MAX_CARD_CHARS:
        raise ValueError(f"card is {len(text)} characters; the limit is {MAX_CARD_CHARS}")
    return text, entities


def _breaker_pct(index: int, item: Mapping[str, Any], key: str) -> int:
    """A row's breaker percentage; missing, None or not an int fails closed (KeyError)."""
    value = item[key]
    if type(value) is not int:
        raise KeyError(f"wave item {index}: {key} is missing or not an integer percentage")
    return value


def _wave_breakers(items: list[Mapping[str, Any]]) -> dict[str, tuple[int, int]]:
    """Per account, in first-seen order: the (account %, engine %) the header states, each the most
    common value across that account's rows (a tie goes to the first seen; an engine tie prefers the
    account's own %, which is what an engine without its own breaker inherits). Reads every row's
    percentages before any text exists, so one missing percentage refuses the whole card. O(n)."""
    seen: dict[str, tuple[dict[int, int], dict[int, int]]] = {}
    for index, item in enumerate(items, 1):
        accounts, engines = seen.setdefault(item["account"], ({}, {}))
        account_pct = _breaker_pct(index, item, "account_pct")
        engine_pct = _breaker_pct(index, item, "engine_pct")
        accounts[account_pct] = accounts.get(account_pct, 0) + 1
        engines[engine_pct] = engines.get(engine_pct, 0) + 1
    header = {}
    for account, (accounts, engines) in seen.items():
        account_pct = max(accounts, key=accounts.__getitem__)
        engine_pct = max(engines, key=lambda pct: (engines[pct], pct == account_pct))
        header[account] = (account_pct, engine_pct)
    return header


def render_wave_card(*, host: str, code_sha: str, items: list[Mapping[str, Any]],
                     manifest_sha256: str, nonce: str, claim_by: datetime,
                     closes: datetime, window_days: int) -> tuple[str, list[dict[str, Any]]]:
    """One nonce covers every displayed item; refuse if even one complete row cannot fit. The header
    states each account's loss breakers once (account %, and the engine % its rows share unless a
    row says otherwise); a row appends `|E<n>%` only when its engine breaker differs, and an assign
    row, or a row whose account % differs from the header, always appends both `|E<n>% A<n>%`. A
    row without either percentage fails closed (KeyError) before any text exists, never a guess."""
    breakers = _wave_breakers(items)
    probes = sum(item["kind"] == "probe" for item in items)
    header = _ascii(
        f"{WAVE_TITLE}\n"
        f"host {host}, runner checkout {code_sha[:12]} (not bound to the approval)\n"
        f"{len(items)} items: {probes} probe, {len(items) - probes} assign\n"
        f"manifest sha256 {manifest_sha256[:12]}\n"
        + "".join(f"breakers: {account} account {account_pct}% (engine {engine_pct}% unless a row says "
                  f"otherwise)\n" for account, (account_pct, engine_pct) in breakers.items())
        + "item | kind | engine | account (label, domain) | books | contracts/role | "
          "breakers E/A if not as above\n")
    if probes < len(items):
        header += ("This assigns a real-money engine to that account and widens the identity-grade exception "
                   "beyond probes.\n")
    footer = _ascii(
        f"claim by {claim_by:%Y-%m-%d %H:%M}Z; probes expire after the {window_days}-day window plus claim time\n"
        f"Reply to THIS message with {nonce} to approve ALL items, or NO. Closes {closes:%H:%M}Z.")
    rows = []
    for index, item in enumerate(items, 1):
        account = item['account']
        account_pct, engine_pct = breakers[account]
        if item['kind'] == 'assign':
            account += f"({item['account_label']},{item['domain']})"
        if item['kind'] == 'assign' or item['account_pct'] != account_pct:
            shown = f"|E{item['engine_pct']}% A{item['account_pct']}%"
        elif item['engine_pct'] != engine_pct:
            shown = f"|E{item['engine_pct']}%"
        else:
            shown = ""
        row = _ascii(f"{index} |{item['kind']}|{item['engine_id']}|{account}|"
                     f"{'+'.join(item['symbols'])}|{item['sizing']}{shown}\n")
        if len(header) + sum(map(len, rows)) + len(row) + len(footer) > MAX_WAVE_CARD_CHARS:
            raise ValueError(f"wave_card_too_long: {len(rows)} of {len(items)} items fit within "
                             f"{MAX_WAVE_CARD_CHARS} characters; split the wave")
        rows.append(row)
    text = header + "".join(rows) + footer
    if len(text) > MAX_WAVE_CARD_CHARS:
        raise ValueError(f"wave_card_too_long: 0 of {len(items)} items fit within "
                         f"{MAX_WAVE_CARD_CHARS} characters; split the wave")
    offset = len(text) - len(footer) + footer.index(nonce)
    return text, [{"type": "code", "offset": offset, "length": len(nonce)}]


# ---------------------------------------------------------------- the root-only store

def check_store_chain(path: Path | str) -> None:
    """POSIX: lstat every component from the store up to / (at most 16). No component may be a
    symlink, whoever owns it, and the store's resolved path must equal its configured absolute
    path, so the chain validated here is the chain the kernel walks (a root-owned symlink can no
    longer point the store somewhere unvalidated). Every owner is 0 or euid; no component is group
    or other writable unless it is root-owned with the sticky bit. Absent components are skipped.
    Raises StoreInsecure naming the component. A no-op elsewhere (Windows has no POSIX ownership)."""
    if os.name != "posix":
        return
    euid = os.geteuid()
    absolute = Path(os.path.abspath(os.fspath(path)))
    chain = [absolute, *absolute.parents]
    if len(chain) > MAX_STORE_COMPONENTS:
        raise StoreInsecure(f"{absolute} is more than {MAX_STORE_COMPONENTS} components deep")
    for component in chain:
        try:
            status = os.lstat(component)
        except FileNotFoundError:
            continue
        except OSError as exc:
            raise StoreInsecure(f"{component}: {type(exc).__name__}") from None
        if stat.S_ISLNK(status.st_mode):
            raise StoreInsecure(f"{component} is a symlink (uid {status.st_uid}); the store's chain may "
                                "hold no symlink")
        if status.st_uid not in (0, euid):
            raise StoreInsecure(f"{component} is owned by uid {status.st_uid}")
        if status.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
            if not (status.st_uid == 0 and status.st_mode & stat.S_ISVTX):
                raise StoreInsecure(f"{component} is group or other writable")
    try:
        resolved = os.path.realpath(os.fspath(path))  # the configured text, so `link/..` resolves too
    except (OSError, ValueError) as exc:
        raise StoreInsecure(f"{absolute}: {type(exc).__name__}") from None
    if resolved != str(absolute):
        raise StoreInsecure(f"{os.fspath(path)} resolves to {resolved}, not {absolute}; the resolved "
                            "chain differs from the configured one")


def store_owner_uids() -> frozenset[int] | None:
    """The owners a file inside the approval store may have: root and this process's euid on
    POSIX. None elsewhere (Windows reports no POSIX owner, so the owner check is skipped there)."""
    if os.name != "posix":
        return None
    return frozenset({0, os.geteuid()})


def store_file_problem(opened: os.stat_result, linked: os.stat_result) -> str | None:
    """Judge one opened store file: `opened` is fstat of the open descriptor, `linked` is lstat of
    its path. None when it is the same regular file, not a symlink, owned by store_owner_uids()
    and (POSIX) neither group nor other writable nor setuid/setgid; else the reason. Pure."""
    if stat.S_ISLNK(linked.st_mode):
        return "is a symlink"
    if not stat.S_ISREG(opened.st_mode):
        return "is not a regular file"
    if os.name == "posix" and (opened.st_dev, opened.st_ino) != (linked.st_dev, linked.st_ino):
        return "was replaced between open and lstat"
    owners = store_owner_uids()
    if owners is not None and opened.st_uid not in owners:
        return f"is owned by uid {opened.st_uid}"
    if os.name == "posix" and opened.st_mode & (stat.S_IWGRP | stat.S_IWOTH | stat.S_ISUID | stat.S_ISGID):
        return f"has mode {stat.S_IMODE(opened.st_mode):04o} (group or other writable)"
    return None


def _fsync_dir(directory: Path) -> None:
    if os.name != "posix":
        return
    fd = os.open(directory, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def publish_exclusive(directory: Path, name: str, data: bytes, *, keep_existing: bool = False) -> bool:
    """Publish `data` as `directory/name` atomically and exclusively: a temp file in the store,
    0o444 on POSIX, fsync, hard link to the final name, unlink the temp, fsync the directory. No
    reader ever sees a truncated file. True when this call published; False when identical bytes
    (or, with keep_existing, any bytes) already stand; PublishCollision on different bytes."""
    final = Path(directory) / name
    fd, temporary = tempfile.mkstemp(prefix="." + name + ".", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if os.name == "posix":
            os.chmod(temporary, 0o444)
        try:
            os.link(temporary, final)
            published = True
        except FileExistsError:
            if not keep_existing:
                with open(final, "rb") as stream:
                    existing = stream.read(len(data) + 1)
                if existing != data:
                    raise PublishCollision(f"{name} already holds a different document") from None
            published = False
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
    _fsync_dir(Path(directory))
    return published


def recent_cards(path: Path, now: datetime) -> tuple[int, int]:
    """(cards in the last hour, cards this UTC day) from the prompt log's last 64 KiB. A row it
    cannot read is skipped; an unreadable log raises PresenceError (the caller fails closed)."""
    try:
        with open(path, "rb") as stream:
            size = stream.seek(0, os.SEEK_END)
            start = max(0, size - MAX_PROMPT_LOG_TAIL)
            stream.seek(start)
            data = stream.read(MAX_PROMPT_LOG_TAIL)
    except FileNotFoundError:
        return 0, 0
    except OSError as exc:
        raise PresenceError(f"{path}: {type(exc).__name__}") from None
    lines = data.split(b"\n")
    if start > 0:
        lines = lines[1:]
    hour = day = 0
    for line in lines:
        if not line.strip():
            continue
        try:
            row = strict_json(line)
        except (UnicodeError, ValueError, RecursionError):
            continue
        at = parse_utc(row.get("at")) if isinstance(row, dict) else None
        if at is None:
            continue
        if now - at < timedelta(hours=1):
            hour += 1
        if at.date() == now.astimezone(timezone.utc).date():
            day += 1
    return hour, day
