"""Root-only tester Kalshi account publisher; the dashboard pusher stays keyless.

Each lane's credential is read only in a child handed a binding on stdin, never argv or
environment. The imported deposits process runner kills at the hard wall, discards stderr
and bounds the result. Failures publish nothing and never stop the next lane. Root-owned,
lane-group 0440 documents are atomically replaced and read with inode and O_NOFOLLOW checks.
Only validated, bounded account data and static outcome codes leave the child.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import secrets
import stat
import sys
import time
from datetime import datetime
from pathlib import Path

from . import account_lane_agent as agent
from .account_lane_deposits import (
    DocumentRefused, PublishRefused, _bindings, _credential, _lane_directory, _lane_gid,
    _write_published, _run_child, _file_safe, _published_tree_safe, _refuse_constant,
    _int_within, _js_length, _json_bytes, MAX_LANES, LANE_BUDGET_S, LANE_WALL_S,
    KILL_GRACE_S, MAX_CHILD_REQUEST_BYTES, MAX_CHILD_RESULT_BYTES, CHILD_FLAG, CLOCK_SKEW_S,
)

SCHEMA = "leafhft.lane-kalshi-account.v1"
FILE_NAME = "kalshi-account.json"
OUTCOME_PATH = Path("/var/lib/leafhft-account-deposits/kalshi-account-outcomes.json")
UNIT_TIMEOUT_S = int(2 * MAX_LANES * (LANE_WALL_S + KILL_GRACE_S)) + 120
MAX_ACCOUNT_BYTES = 262_144
MAX_ROWS = 2000
MAX_INT = 100_000_000
MAX_SIGNED_CENTS = 1_000_000_000
MAX_FILE_BYTES = 3 * MAX_ACCOUNT_BYTES + 8192
LISTS = ("orders", "fills", "settlements")
# Receiver: ops-dashboard src/lib/services/leafhft-runs.ts, validateKalshiAccount*.
# Unlike the owner's normalizers, its row fields are required and most cents cap at 1e8.
_ISO = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}"
                  r"(?:\.[0-9]{1,6})?(?:Z|[+-][0-9]{2}:[0-9]{2})")
_REFUSAL_CODES = frozenset({"no_credential", "credential_invalid", "venue_error",
                            "balance_missing", "account_invalid", "child_failed", "timeout",
                            "projection_unsafe", "lane_user_unresolved"})
STRINGS = {
    "fills": ("fill_id", "order_id", "trade_id", "ticker", "market_ticker", "book_side"),
    "orders": ("order_id", "ticker", "status"),
    "settlements": ("ticker", "event_ticker", "market_result"),
}
COUNTS = {"fills": ("count",), "orders": ("initial_count", "fill_count", "remaining_count"),
          "settlements": ("yes_count", "no_count")}
CENTS = {
    "fills": ("yes_price_cents", "no_price_cents", "fee_cents", "exchange_index", "subaccount_number"),
    "orders": ("yes_price_cents", "no_price_cents", "taker_fees_cents", "taker_fill_cost_cents",
               "maker_fees_cents", "maker_fill_cost_cents", "exchange_index"),
    "settlements": ("yes_total_cost_cents", "no_total_cost_cents", "fee_cents", "exchange_index"),
}
DATES = {"fills": ("created_time",), "orders": ("created_time", "last_update_time"),
         "settlements": ("settled_time",)}
EXTRA = {"fills": ("side", "action", "is_taker", "is_ours", "ts"),
         "orders": ("side", "action", "is_ours", "client_order_id"),
         "settlements": ("revenue_cents", "value")}
FIELDS = {kind: (*STRINGS[kind], *COUNTS[kind], *CENTS[kind], *DATES[kind], *EXTRA[kind])
          for kind in LISTS}
DROP_REASONS = frozenset({"shape", "row_cap", "byte_cap", "unkeyed", "duplicate",
                          *(field for fields in FIELDS.values() for field in fields)})
DOC_KEYS = {"schema", "lane", "fetched_at", "account", "digest", "dropped"}


def _text(value, limit=64):
    length = _js_length(value) if type(value) is str else None
    return length is not None and 0 < length <= limit


def _timestamp(value):
    # A conservative ISO subset accepted by Date.parse, including the venue's UTC timestamps.
    if not _text(value, 40) or not _ISO.fullmatch(value):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed.timestamp() if parsed.tzinfo is not None else None
    except (ValueError, OverflowError, OSError):
        return None


def row_refusal(kind, row):
    """First receiver-bound failure, as a static field name; never include venue values."""
    if type(row) is not dict or set(row) != set(FIELDS[kind]):
        return "shape"
    for field in STRINGS[kind]:
        if not _text(row[field], 96 if "ticker" in field else 64):
            return field
    for field in COUNTS[kind]:
        value = row[field]
        if (type(value) not in (int, float) or not math.isfinite(value)
                or not 0 <= value <= MAX_INT or round(value * 100) / 100 != value):
            return field
    for field in CENTS[kind]:
        if not _int_within(row[field], 0, MAX_INT):
            return field
    for field in DATES[kind]:
        if _timestamp(row[field]) is None:
            return field
    if kind in ("fills", "orders"):
        for field, allowed in (("side", ("yes", "no")), ("action", ("buy", "sell"))):
            if row[field] not in allowed:
                return field
        if type(row["is_ours"]) is not bool:
            return "is_ours"
    if kind == "fills":
        if row["is_taker"] is not None and type(row["is_taker"]) is not bool:
            return "is_taker"
        if row["ts"] is not None and not _int_within(row["ts"], 0, 4_102_444_800):
            return "ts"
    elif kind == "orders":
        if row["client_order_id"] is not None and not _text(row["client_order_id"]):
            return "client_order_id"
    else:
        for field in ("revenue_cents", "value"):
            if not _int_within(row[field], -MAX_SIGNED_CENTS, MAX_SIGNED_CENTS):
                return field
    return None


def _metadata(raw):
    if type(raw) is not dict:
        raise PublishRefused("account_invalid")
    stats = raw.get("stats")
    if (type(stats) is not dict or set(stats) != {"pages", "bad_rows", "errors", "cursor_reset"}
            or any(not _int_within(v, 0, MAX_INT) for v in stats.values())):
        raise PublishRefused("account_invalid")
    if stats["errors"]:
        raise PublishRefused("venue_error")
    balances = raw.get("balances")
    if type(balances) is not dict or any(
            not _int_within(balances.get(key), 0, MAX_INT)
            for key in ("balance_cents", "portfolio_value_cents")):
        raise PublishRefused("balance_missing")
    if (_timestamp(balances.get("captured_at")) is None
            or (balances.get("margin_cents") is not None
                and not _int_within(balances["margin_cents"], 0, MAX_INT))):
        raise PublishRefused("account_invalid")
    # The receiver requires all four shards if shards is supplied. Do not invent zero balances
    # for absent exchanges: aggregate equity is authoritative and partial shards are omitted.
    shards = balances.get("shards")
    if not (type(shards) is dict and set(shards) == {"0", "1", "2", "3"}
            and all(_int_within(v, 0, MAX_INT) for v in shards.values())):
        shards = None
    return {"balance_cents": balances["balance_cents"],
            "portfolio_value_cents": balances["portfolio_value_cents"],
            "margin_cents": balances.get("margin_cents"), "shards": shards,
            "captured_at": balances["captured_at"]}, dict(stats)


def account_digest(block):
    return hashlib.sha256(agent.canonical(block)).hexdigest()


def select_account(raw):
    """Keep valid rows newest first, trimming oldest rows globally to the block byte cap."""
    balances, stats = _metadata(raw)
    block = {"venue": "kalshi", "deposits": [], "balances": balances, "stats": stats}
    dropped = {}
    if stats["bad_rows"]:
        dropped["unkeyed"] = stats["bad_rows"]
    def drop(reason, count=1):
        dropped[reason] = dropped.get(reason, 0) + count
    for kind in LISTS:
        rows = raw.get(kind)
        if type(rows) is not list:
            raise PublishRefused("account_invalid")
        kept, seen = [], set()
        for row in rows:
            reason = row_refusal(kind, row)
            if reason is None:
                key = (row["ticker"], row["settled_time"]) if kind == "settlements" else row[
                    "fill_id" if kind == "fills" else "order_id"]
                if key in seen:
                    reason = "duplicate"
                else:
                    seen.add(key)
                    kept.append(dict(row))
            if reason is not None:
                drop(reason)
        kept.sort(key=lambda row: _timestamp(row[DATES[kind][0]]), reverse=True)
        if len(kept) > MAX_ROWS:
            drop("row_cap", len(kept) - MAX_ROWS)
            kept = kept[:MAX_ROWS]
        block[kind] = kept
    total = _json_bytes(block)
    while total > MAX_ACCOUNT_BYTES:
        candidates = [kind for kind in LISTS if block[kind]]
        if not candidates:
            raise PublishRefused("account_invalid")
        kind = min(candidates, key=lambda k: _timestamp(block[k][-1][DATES[k][0]]))
        row = block[kind].pop()
        total -= _json_bytes(row) + (1 if block[kind] else 0)
        drop("byte_cap")
    return block, dropped


def document_bytes(lane_id, block, dropped, fetched_at):
    return agent.canonical({"schema": SCHEMA, "lane": agent.identifier(lane_id),
                            "fetched_at": fetched_at, "account": block,
                            "digest": account_digest(block), "dropped": dropped})


def parse_document(data, lane_id, *, now_s, max_age_s):
    if type(data) is not bytes or len(data) > MAX_FILE_BYTES:
        raise DocumentRefused("invalid")
    try:
        doc = json.loads(data, object_pairs_hook=agent._pairs, parse_constant=_refuse_constant)
        if (type(doc) is not dict or set(doc) != DOC_KEYS or doc["schema"] != SCHEMA
                or doc["lane"] != lane_id or type(doc["fetched_at"]) is not int
                or doc["fetched_at"] < 0 or doc["fetched_at"] > now_s + CLOCK_SKEW_S
                or type(doc["dropped"]) is not dict
                or any(k not in DROP_REASONS or not _int_within(v, 0, MAX_INT)
                       for k, v in doc["dropped"].items())):
            raise ValueError
        block = doc["account"]
        if type(block) is not dict or set(block) != {
                "venue", "fills", "settlements", "orders", "deposits", "balances", "stats"}:
            raise ValueError
        if block["venue"] != "kalshi" or block["deposits"] != []:
            raise ValueError
        selected, dropped = select_account(block)
        if selected != block or any(k != "unkeyed" for k in dropped):
            raise ValueError
        digest = account_digest(block)
        if doc["digest"] != digest or _json_bytes(block) > MAX_ACCOUNT_BYTES:
            raise ValueError
    except Exception:
        raise DocumentRefused("invalid") from None
    if now_s - doc["fetched_at"] > max_age_s:
        raise DocumentRefused("stale")
    return block, digest


def published_path(lane_id):
    return agent.safe_path(agent.PROJECTION_ROOT / agent.identifier(lane_id) / FILE_NAME)




def read_published(lane_id, *, now_s, max_age_s):
    """(block, digest) from PROJECTION_ROOT/<lane>/kalshi-account.json, else DocumentRefused with a
    static code. The file must be root-owned, own-group 0440 and single-link, in root-owned
    directories that are not group/other-writable with trusted ancestors; it is opened O_NOFOLLOW
    and read through the very inode that check saw, bounded."""
    try:
        # Nothing at the name at all (a host the root fetch never ran on) is `absent`, checked with
        # lstat before any path rule, so a link planted at the name is still `unsafe` below.
        os.lstat(agent.PROJECTION_ROOT / agent.identifier(lane_id) / FILE_NAME)
        path = published_path(lane_id)
        info = _published_tree_safe(path)
    except FileNotFoundError:
        raise DocumentRefused("absent") from None
    except agent.LaneRefused:
        raise DocumentRefused("unsafe") from None
    except OSError:
        raise DocumentRefused("unreadable") from None
    if info is None:
        raise DocumentRefused("unsafe")
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
                     | getattr(os, "O_BINARY", 0))
    except FileNotFoundError:
        raise DocumentRefused("absent") from None
    except OSError:
        raise DocumentRefused("unsafe") from None
    try:
        with os.fdopen(fd, "rb") as stream:
            opened = os.fstat(stream.fileno())
            if not _file_safe(opened) or (opened.st_dev, opened.st_ino) != (info.st_dev, info.st_ino):
                raise DocumentRefused("unsafe")
            data = stream.read(MAX_FILE_BYTES + 1)
    except DocumentRefused:
        raise
    except OSError:
        raise DocumentRefused("unreadable") from None
    return parse_document(data, lane_id, now_s=now_s, max_age_s=max_age_s)


def _fetch_account(key_id, pem, deadline):
    from . import kalshi_account
    fetch = kalshi_account._make_default_fetch(key_id, pem, kalshi_account.REST_URL, deadline=deadline)
    sync = kalshi_account.AccountSync(None, "", "", fetch=fetch, lists=LISTS, balances=True,
                                      max_pages=1, page_size=100, margin=False)
    result = sync.sync()
    _metadata(result)
    return result


def lane_fetch(binding):
    if type(binding) is not dict or set(binding) != set(agent.scope(
            binding.get("tenant_id"), binding.get("lane_id"))):
        raise PublishRefused("child_failed")
    agent.check_scope(binding, binding)
    key_id, pem = _credential(agent.LanePaths(binding["lane_id"]), binding)
    try:
        return _fetch_account(key_id, pem, time.monotonic() + LANE_BUDGET_S)
    finally:
        del key_id, pem


def child_main(stdin, stdout):
    try:
        request = stdin.read(MAX_CHILD_REQUEST_BYTES + 1)
        if len(request) > MAX_CHILD_REQUEST_BYTES:
            raise ValueError
        block, dropped = select_account(lane_fetch(agent.parse(request)))
        outcome = {"status": "ok", "account": block, "dropped": dropped}
    except PublishRefused as exc:
        code = str(exc) if str(exc) in _REFUSAL_CODES else "child_failed"
        outcome = {"status": "refused", "code": code}
    except Exception:
        outcome = {"status": "refused", "code": "child_failed"}
    stdout.write(agent.canonical(outcome) + b"\n")
    stdout.flush()
    return 0


def _child_command():
    return [sys.executable, "-m", "leafhft.account_lane_kalshi", CHILD_FLAG]


def decode_outcome(out):
    try:
        if type(out) is not bytes or len(out) > MAX_CHILD_RESULT_BYTES:
            raise ValueError
        outcome = json.loads(out, object_pairs_hook=agent._pairs, parse_constant=_refuse_constant)
        if type(outcome) is not dict:
            raise ValueError
        if (set(outcome) == {"status", "code"} and outcome["status"] == "refused"
                and type(outcome["code"]) is str and outcome["code"] in _REFUSAL_CODES):
            raise PublishRefused(outcome["code"])
        if set(outcome) != {"status", "account", "dropped"} or outcome["status"] != "ok":
            raise ValueError
        # Revalidate the child's output with the exact published-document reader.
        lane = "00000000-0000-4000-8000-000000000000"
        parse_document(document_bytes(lane, outcome["account"], outcome["dropped"], 0),
                       lane, now_s=0, max_age_s=0)
        return outcome["account"], outcome["dropped"]
    except PublishRefused:
        raise
    except Exception:
        raise PublishRefused("child_failed") from None


def fetch_isolated(binding):
    return decode_outcome(_run_child(_child_command(), agent.canonical(binding), LANE_WALL_S))


def publish_lane(binding, *, now_s=None):
    lane_id = agent.identifier(binding.get("lane_id") if type(binding) is dict else None)
    gid = _lane_gid(lane_id)
    directory = _lane_directory(lane_id)
    block, dropped = fetch_isolated(binding)
    fetched_at = int(time.time()) if now_s is None else now_s
    data = document_bytes(lane_id, block, dropped, fetched_at)
    parse_document(data, lane_id, now_s=fetched_at, max_age_s=0)
    try:
        _write_published(agent.safe_path(directory / FILE_NAME), data, gid=gid)
    except agent.LaneRefused:
        raise PublishRefused("projection_unsafe") from None
    return {"lane": lane_id, "rows": sum(len(block[k]) for k in LISTS), "dropped": dropped}


def publish_all(*, now_s=None):
    if not agent.safe_path(agent.CONFIG_ROOT / "ENABLED").exists():
        return {}
    report = {}
    for binding in _bindings():
        if not agent.safe_path(agent.CONFIG_ROOT / "ENABLED").exists():
            break
        lane_id = binding["lane_id"]
        try:
            publish_lane(binding, now_s=now_s)
            report[lane_id] = "published"
        except PublishRefused as exc:
            report[lane_id] = str(exc) if str(exc) in _REFUSAL_CODES else "error"
        except Exception:
            report[lane_id] = "error"
    return report


def run_once(*, now_s=None):
    if os.name != "posix" or os.geteuid() != 0:
        raise agent.LaneRefused("root agent required")
    return publish_all(now_s=now_s)


def write_outcomes(report, *, now_s=None):
    """Replace this run's bounded, secret-free status snapshot in the unit's private state dir."""
    at = int(time.time()) if now_s is None else now_s
    codes = _REFUSAL_CODES | {"published", "timeout", "child_failed", "projection_unsafe",
                              "lane_user_unresolved"}
    outcomes = {}
    for lane_id, status in list(report.items())[:MAX_LANES]:
        if status not in codes:
            status = "error"
        outcomes[agent.identifier(lane_id)] = {"status": status, "at": at}
    target = agent.safe_path(OUTCOME_PATH)
    if os.name != "posix":
        agent.write_private(target, outcomes)
        return
    with agent.private_parent(target) as parent:
        info = os.fstat(parent)
        if (info.st_uid != 0 or info.st_gid != 0 or stat.S_IMODE(info.st_mode) != 0o700):
            raise agent.LaneRefused("unsafe outcome directory")
        name = ".outcomes-" + secrets.token_hex(16)
        fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                os.fchown(stream.fileno(), 0, 0)
                os.fchmod(stream.fileno(), 0o600)
                stream.write(agent.canonical(outcomes))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(name, target.name, src_dir_fd=parent, dst_dir_fd=parent)
            os.fsync(parent)
        finally:
            try:
                os.unlink(name, dir_fd=parent)
            except FileNotFoundError:
                pass


def main(argv=None):
    if os.name != "posix" or os.geteuid() != 0:
        return 2
    if list(sys.argv[1:] if argv is None else argv) == [CHILD_FLAG]:
        return child_main(sys.stdin.buffer, sys.stdout.buffer)
    try:
        report = run_once()
    except Exception:
        report = {}
    try:
        write_outcomes(report)
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
