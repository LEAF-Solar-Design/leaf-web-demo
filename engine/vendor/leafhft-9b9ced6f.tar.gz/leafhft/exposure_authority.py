"""Exposure authority machinery around the C1 registry (contracts/X2X3.md v3 section 2.1, v3.1 A6/A7).

The registry document schema stays EXACTLY C1's, so every pre-X1 reader keeps decoding it. Everything
X1 adds lives beside it:

- `<registry dir>/exposure-state.json`, the sidecar: per member enforcement (operational|observe),
  the fine-grained transfer state, the attested-foreign set, and the projection's activation
  record (`projection`, null before first use). Root 0600, strict decoder, 64 KiB
  cap, never projected, never read by a book. An absent member means `operational` (fails closed).
- `<registry dir>/exposure-history.jsonl`, append-only and hash-chained (`previous_row_digest`):
  one `role` row per role change per domain, appended under the registry lock BEFORE the atomic
  replace, then one `commit` row AFTER it. Only a generation with a commit row is an authority
  interval (A7): an appended-but-unapplied tail is never one, and RegistryStore never reuses a
  tentative generation. Readers cap it at 4 MiB and refuse beyond that (`history_oversize`).
  Intervals come only from role rows grouped under their own commit row, in file order, whose
  role agrees with the committed registry's `roles_by_generation` (else `history_role_mismatch`),
  and only under a commit row for a generation the journal PROVES committed, above every earlier
  commit, with that generation's committed digest (else `history_generation_mismatch`, or
  `history_incomplete_evidence` below the floor of an incomplete journal walk). Only
  `committed_ancestry` proves commitment, so an answer without it is `unverified` and grants
  nothing; `read_authority` is the production path and always passes it.
- `/var/lib/leafhft-exposure/roles/<slug>.json`, one role file per domain plus the `_registry.json`
  marker. Lowerings are written BEFORE the registry replace and raises AFTER it, so a crash leaves
  a domain at most one projection tick too strict, never too permissive. A projection validates
  the sidecar against the registry FIRST; while it is unreadable or inconsistent no file is raised.
  Activation writes a random token into the role directory (`.projection-token`), then
  `<registry dir>/exposure-projection.json` (the witness: the resolved directory and the token's
  digest), then an identical 0444 mirror beside the role directory, then the sidecar's `projection`
  record (the witness digest too). Verified later projections repair a missing or differing mirror.
  From then on an
  authority-changing commit without a role directory refuses `roles_dir_required`, a missing
  witness `projection_witness_missing`, and any writer or projector naming another directory, or
  a directory without the recorded token (a fresh one at the same pathname), `roles_dir_mismatch`.
  Moving the role directory is a root operation: retire the registry witness and sidecar record,
  and delete the mirror at the OLD resolved role directory's parent so old readers stop trusting it.
- `DomainRole`, the hot-path reader: one os.stat per call, a re-parse only when (mtime, inode, size)
  changes, four states (absent, unregistered, unreadable, the record), plus `for_ledger_root`
  whose unmapped root under a present marker is `domain_ledger_mismatch` (A6, fails closed). The
  class constructors are registry-backed: once the registry's witness exists, a missing marker or
  role file, or a directory without the recorded token, is `unreadable`, never `absent`.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import stat as stat_module
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from . import engine_registry as er
from .engine_registry import DOMAIN_AUTHORITY, DOMAIN_EXIT_ONLY, LEGACY_OWNER_DOMAIN, RegistryError

STATE_SCHEMA = "leafhft.exposure_state.v1"
STATE_FILE = "exposure-state.json"
HISTORY_FILE = "exposure-history.jsonl"
MARKER_FILE = "_registry.json"
PROJECTION_FILE = "exposure-projection.json"
TOKEN_FILE = ".projection-token"
RECEIPT_SCHEMA = "leafhft.exposure_conformance.receipt.v1"

EXPOSURE_ROOT = Path("/var/lib/leafhft-exposure")
ROLES_DIR = EXPOSURE_ROOT / "roles"
REGISTRY_DIR = Path("/var/lib/leafhft/engine-registry")
OWNER_LEDGER_ROOT = "/var/lib/leafhft/account-risk"
_LANE_LEDGER_ROOT = re.compile(r"/var/lib/leafhft-accounts/([a-z0-9][a-z0-9-]{0,63})/account-risk")

MAX_STATE_BYTES = 64 * 1024
MAX_HISTORY_BYTES = 4 * 1024 * 1024
MAX_HISTORY_ROW_BYTES = 4096
MAX_ROLE_BYTES = 4096
MAX_RECEIPT_BYTES = 64 * 1024
MAX_ROLE_DIR_ENTRIES = 1024
MAX_FLAT_READS = 2
MAX_ORPHANS = 64
MAX_ATTESTED = 64
RECEIPT_MAX_AGE_S = 600
RECEIPT_FUTURE_SKEW_S = 30

OPERATIONAL = "operational"
OBSERVE = "observe"
ENFORCEMENTS = (OPERATIONAL, OBSERVE)
PHASES = ("prepared", "disabling", "acked", "begun", "reconciling", "flat_proven")
# The pre-BEGIN phases lower the draining domain's role file while the registry still names it.
LOWERING_PHASES = frozenset({"prepared", "disabling", "acked"})
# Sidecar phase -> the coarse C1 transfer step it corresponds to once BEGIN has committed.
PHASE_TO_STEP = {"begun": "draining", "reconciling": "reconciling", "flat_proven": "flat_proven"}
REASON_REGISTRY = "registry"
REASON_TRANSFER_PREPARED = "transfer_prepared"

ABSENT = "absent"
UNREGISTERED = "unregistered"
UNREADABLE = "unreadable"
RECORD = "record"
LEDGER_MISMATCH = "domain_ledger_mismatch"
PRINCIPAL_MISMATCH = "domain_principal_mismatch"
PRINCIPAL_SOURCES = ("adopted", "rebind")

# What the history proves (`committed_ancestry`, `authority_intervals`, `first_row_ns`).
VERIFIED = "verified"
INCOMPLETE_EVIDENCE = "incomplete_evidence"
UNVERIFIED = "unverified"

_STATE_KEYS = frozenset({"schema", "registry_generation", "registry_digest", "members", "projection"})
_PROJECTION_KEYS = frozenset({"roles_dir", "token_digest", "witness_digest"})
_WITNESS_KEYS = frozenset({"roles_dir", "token_digest"})
_STATE_MEMBER_KEYS = frozenset({"enforcement", "transfer", "attested_foreign"})
_STATE_TRANSFER_KEYS = frozenset({"request_id", "from", "to", "phase", "prepared_at", "deadline_at",
                                  "approval_id", "disabled_at", "ack_digest", "flat_reads",
                                  "orphans_resolved"})
_FLAT_READ_KEYS = frozenset({"at", "revision"})
_ATTESTED_KEYS = frozenset({"ticker", "side", "count", "approval_id"})
_ROLE_KEYS = frozenset({"schema", "domain", "member_key", "role", "enforcement", "reason", "generation",
                        "registry_digest"})
_ROLE_KEYS_V2 = _ROLE_KEYS | {"expected_principal_digest"}
_PRINCIPAL_KEYS = frozenset({"digest", "source", "at", "request_id"})
_MARKER_KEYS = frozenset({"generation", "digest"})
_HISTORY_KEYS = frozenset({"kind", "member_key", "domain", "role", "enforcement", "generation",
                           "registry_digest", "at_ns", "request_id", "outcome", "previous_row_digest",
                           "row_digest"})

_TICKER = re.compile(r"[A-Z0-9][A-Z0-9._-]{0,63}")
_COUNT = re.compile(r"(0|[1-9][0-9]{0,8})(\.[0-9]{1,2})?")
_REVISION = re.compile(r"0|[1-9][0-9]{0,17}")
_NS = re.compile(r"0|[1-9][0-9]{0,19}")


# ---------------------------------------------------------------- principal: the venue key a domain trades with

def principal_digest(key_id: str) -> str:
    """The Kalshi key id's identity, the only form that leaves a credential reader (never the key id).
    Byte-identical to the exposure audit's `key_digest`. Raises ValueError on anything but a key id
    of 8 to 256 characters."""
    if type(key_id) is not str or not 8 <= len(key_id) <= 256:
        raise ValueError("a principal key id is a str of 8 to 256 characters")
    return hashlib.sha256(b"leafhft-kalshi-key:" + key_id.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------- sidecar: exposure-state.json

def empty_state() -> dict[str, Any]:
    return {"schema": STATE_SCHEMA, "registry_generation": None, "registry_digest": None, "members": {},
            "projection": None}


def _unique_list(value: Any, where: str, limit: int) -> list[Any]:
    if type(value) is not list or len(value) > limit:
        raise RegistryError("invalid_value", f"{where}: a list of at most {limit}")
    return value


def _validate_transfer(transfer: Any, where: str) -> None:
    er._exact(transfer, _STATE_TRANSFER_KEYS, where)
    er._match(er._REF_ID, transfer["request_id"], f"{where}.request_id")
    source = er._match(er._DOMAIN, transfer["from"], f"{where}.from")
    target = er._match(er._DOMAIN, transfer["to"], f"{where}.to")
    if source == target:
        raise RegistryError("invalid_value", f"{where}: from and to are the same domain")
    if transfer["phase"] not in PHASES:
        raise RegistryError("invalid_value", f"{where}.phase: {transfer['phase']!r}")
    prepared = er._stamp(transfer["prepared_at"], f"{where}.prepared_at")
    deadline = er._stamp(transfer["deadline_at"], f"{where}.deadline_at")
    if deadline < prepared:  # fixed-width UTC stamps order lexically
        raise RegistryError("invalid_value", f"{where}: deadline_at precedes prepared_at")
    er._match(er._REF_ID, transfer["approval_id"], f"{where}.approval_id")
    if transfer["disabled_at"] is not None:
        er._stamp(transfer["disabled_at"], f"{where}.disabled_at")
    er._match(er._HEX64, transfer["ack_digest"], f"{where}.ack_digest", nullable=True)
    for index, read in enumerate(_unique_list(transfer["flat_reads"], f"{where}.flat_reads", MAX_FLAT_READS)):
        er._exact(read, _FLAT_READ_KEYS, f"{where}.flat_reads[{index}]")
        er._stamp(read["at"], f"{where}.flat_reads[{index}].at")
        er._match(_REVISION, read["revision"], f"{where}.flat_reads[{index}].revision")
    orphans = _unique_list(transfer["orphans_resolved"], f"{where}.orphans_resolved", MAX_ORPHANS)
    for index, client_id in enumerate(orphans):
        er._match(er._REF_ID, client_id, f"{where}.orphans_resolved[{index}]")
    if len(set(orphans)) != len(orphans):
        raise RegistryError("invalid_value", f"{where}.orphans_resolved: duplicate client ids")


def validate_state(state: Any) -> dict[str, Any]:
    """Structural validation of one sidecar document; raises on any defect (fails closed). The
    optional `principals` key (X1b) is never empty: without a principal the writer drops it, so the
    document is exactly the pre-X1b shape."""
    if type(state) is dict and "principals" in state:
        er._exact(state, _STATE_KEYS | {"principals"}, "exposure-state")
        _validate_principals(state["principals"])
    else:
        er._exact(state, _STATE_KEYS, "exposure-state")
    if state["schema"] != STATE_SCHEMA:
        raise RegistryError("unknown_schema", repr(state["schema"]))
    if state["registry_generation"] is None:
        if state["registry_digest"] is not None:
            raise RegistryError("invalid_value", "exposure-state: a digest without a generation")
    else:
        er._decimal(state["registry_generation"], "exposure-state.registry_generation", 1, er.MAX_GENERATION)
        er._match(er._HEX64, state["registry_digest"], "exposure-state.registry_digest")
    members = er._object(state["members"], "exposure-state.members")
    if len(members) > er.MAX_ACCOUNTS:
        raise RegistryError("too_many_accounts", f"exposure-state: at most {er.MAX_ACCOUNTS} members")
    for key, member in members.items():
        er._match(er._KEY_ID, key, "exposure-state.members key")
        where = f"exposure-state.members.{key}"
        er._exact(member, _STATE_MEMBER_KEYS, where)
        if member["enforcement"] not in ENFORCEMENTS:
            raise RegistryError("invalid_value", f"{where}.enforcement: {member['enforcement']!r}")
        if member["transfer"] is not None:
            _validate_transfer(member["transfer"], f"{where}.transfer")
        seen = set()
        for index, row in enumerate(_unique_list(member["attested_foreign"], f"{where}.attested_foreign",
                                                 MAX_ATTESTED)):
            at = f"{where}.attested_foreign[{index}]"
            er._exact(row, _ATTESTED_KEYS, at)
            er._match(_TICKER, row["ticker"], f"{at}.ticker")
            if row["side"] not in ("yes", "no"):
                raise RegistryError("invalid_value", f"{at}.side: {row['side']!r}")
            if type(row["count"]) is not str or _COUNT.fullmatch(row["count"]) is None or float(row["count"]) <= 0:
                raise RegistryError("non_decimal_string_number", f"{at}.count: {row['count']!r}")
            er._match(er._REF_ID, row["approval_id"], f"{at}.approval_id")
            if (row["ticker"], row["side"]) in seen:
                raise RegistryError("invalid_value", f"{at}: duplicate ticker and side")
            seen.add((row["ticker"], row["side"]))
    projection = state["projection"]
    if projection is not None:
        er._exact(projection, _PROJECTION_KEYS, "exposure-state.projection")
        _path_text(projection["roles_dir"], "exposure-state.projection.roles_dir")
        er._match(er._HEX64, projection["token_digest"], "exposure-state.projection.token_digest")
        er._match(er._HEX64, projection["witness_digest"], "exposure-state.projection.witness_digest")
    return state


def _validate_principals(principals: Any) -> None:
    where = "exposure-state.principals"
    er._object(principals, where)
    if not principals:
        raise RegistryError("invalid_value", f"{where}: an empty map (the key is removed instead)")
    if len(principals) > er.MAX_ACCOUNTS:
        raise RegistryError("too_many_accounts", f"{where}: at most {er.MAX_ACCOUNTS} domains")
    for domain, entry in principals.items():
        er._match(er._DOMAIN, domain, f"{where} key")
        at = f"{where}.{domain}"
        er._exact(entry, _PRINCIPAL_KEYS, at)
        er._match(er._HEX64, entry["digest"], f"{at}.digest")
        if entry["source"] not in PRINCIPAL_SOURCES:
            raise RegistryError("invalid_value", f"{at}.source: {entry['source']!r}")
        er._stamp(entry["at"], f"{at}.at")
        er._match(er._REF_ID, entry["request_id"], f"{at}.request_id")


def state_principal(state: Mapping[str, Any] | None, domain: str) -> str | None:
    """The principal digest the sidecar records for `domain`, or None (no sidecar, or unbound)."""
    if state is None:
        return None
    entry = state.get("principals", {}).get(domain)
    return None if entry is None else entry["digest"]


def record_principal(state: dict[str, Any], registry: er.Registry, domain: str, digest: str, *,
                     source: str, at: str, request_id: str) -> bool:
    """Bind `domain` to `digest` in `state` (in place, for a `mutate_exposure` state_change). Refuses
    `unknown_domain` for a domain no registry account has and `principal_shared` when another
    member's domain already records the digest (two domains of ONE member may share a key). False
    when the same digest is already recorded (idempotent)."""
    member_of = {account["domain"]: account["member_key"] for account in registry.accounts.values()}
    if domain not in member_of:
        raise RegistryError("unknown_domain", repr(domain))
    er._match(er._HEX64, digest, "principal digest")
    if source not in PRINCIPAL_SOURCES:
        raise RegistryError("invalid_value", f"principal source: {source!r}")
    principals = state.get("principals") or {}
    for other, entry in sorted(principals.items()):
        if other != domain and entry["digest"] == digest and member_of.get(other) != member_of[domain]:
            raise RegistryError("principal_shared",
                                f"{domain}: the key is already bound to {other} of another member")
    current = principals.get(domain)
    if current is not None and current["digest"] == digest:
        return False
    principals = dict(principals)
    principals[domain] = {"digest": digest, "source": source, "at": er._stamp(at, "principal at"),
                          "request_id": er._match(er._REF_ID, request_id, "principal request_id")}
    state["principals"] = principals
    return True


def clear_principal(state: dict[str, Any], domain: str | None) -> bool:
    """Remove one domain's principal (every one for None); the `principals` key goes with its last
    entry. Returns whether anything changed."""
    principals = state.get("principals")
    if not principals:
        state.pop("principals", None)
        return False
    if domain is None:
        del state["principals"]
        return True
    if domain not in principals:
        return False
    principals = {key: value for key, value in principals.items() if key != domain}
    if principals:
        state["principals"] = principals
    else:
        del state["principals"]
    return True


def _path_text(value: Any, where: str) -> str:
    if type(value) is not str or not 1 <= len(value) <= 1024:
        raise RegistryError("invalid_value", f"{where}: not a path")
    return value


def decode_state(data: bytes) -> dict[str, Any]:
    """Strict decode: bounded, no JSON numbers, no duplicate, unknown or missing keys."""
    return validate_state(er.strict_loads(data, MAX_STATE_BYTES))


def load_state(registry_dir: Path | str) -> dict[str, Any]:
    """The sidecar, or an empty one when it was never written (every member then `operational`)."""
    path = Path(registry_dir) / STATE_FILE
    try:
        data = er._read_bounded(path, MAX_STATE_BYTES)
    except FileNotFoundError:
        return empty_state()
    except OSError as exc:
        raise RegistryError("state_unreadable", f"{path}: {exc}") from exc
    return decode_state(data)


def write_state(registry_dir: Path | str, state: Mapping[str, Any]) -> dict[str, Any]:
    """Re-decode what is about to be written, then replace atomically at 0600."""
    data = er.canonical_bytes(state)
    decoded = decode_state(data)
    er._atomic_write(Path(registry_dir) / STATE_FILE, data, 0o600)
    return decoded


def member_enforcement(state: Mapping[str, Any] | None, member_key: str) -> str:
    """An absent member (or no readable sidecar) is `operational`: the strict reading."""
    member = None if state is None else state["members"].get(member_key)
    return OPERATIONAL if member is None else member["enforcement"]


def _state_or_strictest(registry_dir: Path) -> tuple[dict[str, Any] | None, str | None]:
    """(state, None), or (None, error) when the sidecar is unreadable; role files then take the
    strictest reading (every member operational) rather than refusing to lower."""
    try:
        return load_state(registry_dir), None
    except (RegistryError, OSError) as exc:
        return None, str(exc) or type(exc).__name__


# ---------------------------------------------------------------- conformance receipts (X5 writes them)

def check_conformance_receipt(path: Path | str, domain: str, *, now: datetime | None = None) -> str | None:
    """None when `path` is a fresh (<= 600 s) conformant X5 receipt for `domain`, checked as if the
    domain were exit_only, carrying its config and status digests; else the reason it is not."""
    now = datetime.now(timezone.utc) if now is None else now
    try:
        data = er._read_bounded(Path(path), MAX_RECEIPT_BYTES)
    except FileNotFoundError:
        return "receipt_missing"
    except (OSError, RegistryError) as exc:
        return f"receipt_unreadable ({exc})"
    try:
        raw = json.loads(data.decode("utf-8"), object_pairs_hook=er._pairs)
    except (RegistryError, UnicodeError, ValueError, RecursionError):
        return "receipt_invalid_json"
    if type(raw) is not dict:
        return "receipt_not_an_object"
    if raw.get("schema") != RECEIPT_SCHEMA:
        return "receipt_unknown_schema"
    if raw.get("domain") != domain:
        return "receipt_other_domain"
    if raw.get("as_if") != DOMAIN_EXIT_ONLY:
        return "receipt_not_as_if_exit_only"
    if raw.get("conformant") is not True:
        return "receipt_not_conformant"
    for key in ("config_digest", "status_digest"):
        value = raw.get(key)
        if type(value) is not str or er._HEX64.fullmatch(value) is None:
            return f"receipt_missing_{key}"
    stamp = raw.get("generated_at")
    try:
        generated = datetime.strptime(er._stamp(stamp, "generated_at"), "%Y-%m-%dT%H:%M:%SZ")
    except RegistryError:
        return "receipt_bad_generated_at"
    age = (now.astimezone(timezone.utc).replace(tzinfo=None) - generated).total_seconds()
    if age > RECEIPT_MAX_AGE_S:
        return f"receipt_stale ({int(age)} s > {RECEIPT_MAX_AGE_S} s)"
    if age < -RECEIPT_FUTURE_SKEW_S:
        return "receipt_from_the_future"
    return None


# ---------------------------------------------------------------- history: exposure-history.jsonl

def _row_digest(row: Mapping[str, Any]) -> str:
    return hashlib.sha256(er.canonical_bytes({k: v for k, v in row.items() if k != "row_digest"})).hexdigest()


def _validate_row(row: Any, where: str) -> dict[str, Any]:
    er._exact(row, _HISTORY_KEYS, where)
    if row["kind"] == "role":
        er._match(er._KEY_ID, row["member_key"], f"{where}.member_key")
        er._match(er._DOMAIN, row["domain"], f"{where}.domain")
        if row["role"] not in (DOMAIN_AUTHORITY, DOMAIN_EXIT_ONLY):
            raise RegistryError("invalid_value", f"{where}.role: {row['role']!r}")
        if row["enforcement"] not in ENFORCEMENTS:
            raise RegistryError("invalid_value", f"{where}.enforcement: {row['enforcement']!r}")
    elif row["kind"] == "commit":
        if any(row[key] is not None for key in ("member_key", "domain", "role", "enforcement")):
            raise RegistryError("invalid_value", f"{where}: a commit row names no domain")
    else:
        raise RegistryError("invalid_value", f"{where}.kind: {row['kind']!r}")
    er._decimal(row["generation"], f"{where}.generation", 1, er.MAX_GENERATION)
    er._match(er._HEX64, row["registry_digest"], f"{where}.registry_digest")
    er._match(_NS, row["at_ns"], f"{where}.at_ns")
    er._match(er._REF_ID, row["request_id"], f"{where}.request_id", nullable=True)
    er._match(er._ACTION, row["outcome"], f"{where}.outcome")
    er._match(er._HEX64, row["previous_row_digest"], f"{where}.previous_row_digest", nullable=True)
    er._match(er._HEX64, row["row_digest"], f"{where}.row_digest")
    return row


def _history_row(kind: str, registry: er.Registry, *, at_ns: int, request_id: str | None, outcome: str,
                 member_key: str | None = None, domain: str | None = None, role: str | None = None,
                 enforcement: str | None = None) -> dict[str, Any]:
    return {"kind": kind, "member_key": member_key, "domain": domain, "role": role,
            "enforcement": enforcement, "generation": str(registry.generation),
            "registry_digest": registry.digest, "at_ns": str(at_ns), "request_id": request_id,
            "outcome": outcome}


def read_history(registry_dir: Path | str, *, limit: int = MAX_HISTORY_BYTES) -> list[dict[str, Any]]:
    """Every row, chain verified; [] when never written. Beyond `limit` bytes it refuses with
    `history_oversize` (X4 alarms) instead of reading an unbounded file."""
    path = Path(registry_dir) / HISTORY_FILE
    try:
        size = os.stat(path).st_size
    except FileNotFoundError:
        return []
    if size > limit:
        raise RegistryError("history_oversize", f"{path}: {size} bytes exceeds {limit}")
    data = er._read_bounded(path, limit)
    rows: list[dict[str, Any]] = []
    previous = None
    lines = data.split(b"\n")
    if lines and lines[-1] == b"":
        lines.pop()
    for index, line in enumerate(lines):
        where = f"history row {index}"
        try:
            row = _validate_row(er.strict_loads(line, MAX_HISTORY_ROW_BYTES), where)
        except RegistryError as exc:
            raise RegistryError("history_corrupt", f"{where}: {exc}") from exc
        if row["previous_row_digest"] != previous or row["row_digest"] != _row_digest(row):
            raise RegistryError("history_chain_broken", where)
        previous = row["row_digest"]
        rows.append(row)
    return rows


def _history_tail(registry_dir: Path) -> dict[str, Any] | None:
    """The last row, digest verified, read from the file's tail only (bounded)."""
    rows = er._tail_rows(registry_dir / HISTORY_FILE, 1)
    if not rows:
        return None
    try:
        row = _validate_row(rows[-1], "history tail")
    except RegistryError as exc:
        raise RegistryError("history_corrupt", str(exc)) from exc
    if row["row_digest"] != _row_digest(row):
        raise RegistryError("history_chain_broken", "history tail")
    return row


def append_history(registry_dir: Path | str, rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Chain and append rows in one write + fsync. Caller holds the registry lock."""
    directory = Path(registry_dir)
    tail = _history_tail(directory)
    previous = None if tail is None else tail["row_digest"]
    sealed, payload = [], bytearray()
    for row in rows:
        row = dict(row, previous_row_digest=previous)
        row["row_digest"] = _row_digest(row)
        _validate_row(row, "new history row")
        line = er.canonical_bytes(row) + b"\n"
        if len(line) > MAX_HISTORY_ROW_BYTES:
            raise RegistryError("history_row_too_large", str(len(line)))
        payload += line
        sealed.append(row)
        previous = row["row_digest"]
    if not payload:
        return sealed
    flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_BINARY", 0)
    fd = os.open(directory / HISTORY_FILE, flags, 0o644)
    try:
        os.write(fd, bytes(payload))
        os.fsync(fd)
    finally:
        os.close(fd)
    return sealed


def _role_row_problem(row: Mapping[str, Any], registry: er.Registry) -> str | None:
    """None when the committed registry vouches for this role row: its generation has retained
    roles in `roles_by_generation`, its digest is the registry's own at the current generation,
    and its role is the domain's role at that generation."""
    generation = int(row["generation"])
    roles = registry.roles_at(generation)
    if roles is None:
        return f"generation {generation} has no retained roles in the committed registry"
    if generation == registry.generation and row["registry_digest"] != registry.digest:
        return f"generation {generation} digest is not the committed registry's"
    if roles.get(row["domain"]) != row["role"]:
        return (f"{row['domain']} is {roles.get(row['domain'], 'unregistered')} at generation {generation}, "
                f"the row says {row['role']}")
    return None


def _journal_generation(row: Mapping[str, Any]) -> int | None:
    generation = row.get("generation")
    if type(generation) is not str or er._DECIMAL.fullmatch(generation) is None:
        return None
    return int(generation)


@dataclass(frozen=True)
class Ancestry:
    """The journal's word on which generations committed (`committed_ancestry`). VERIFIED: the walk
    reached the init row, so a generation outside `committed` never committed. INCOMPLETE_EVIDENCE:
    the walk stopped at `floor` (a gap, a row without its digest, an ambiguous predecessor, rotation),
    so no generation below `floor` can be proven committed and none of them grants."""
    committed: Mapping[int, str]
    status: str
    floor: int


@dataclass(frozen=True)
class AuthorityIntervals:
    """`intervals` per domain. UNVERIFIED (no ancestry passed): empty, and every reader treats it as
    no grant. INCOMPLETE_EVIDENCE: only generations the journal proves committed contribute."""
    status: str
    intervals: Mapping[str, list[tuple[int, int | None, int]]]
    problems: tuple[str, ...] = ()


@dataclass(frozen=True)
class FirstRows:
    """`first` per member, under the same status rule as AuthorityIntervals: an UNVERIFIED answer is
    empty and exempts no SENT as pre_registry."""
    status: str
    first: Mapping[str, int]
    problems: tuple[str, ...] = ()


_NO_ANCESTRY = f"history_unverified: no committed ancestry was passed, so no commit row is proven ({UNVERIFIED})"


def committed_ancestry(registry_dir: Path | str, registry: er.Registry) -> Ancestry:
    """Every committed generation the journal still holds, walked back from `registry` through each
    row's `previous_digest` to its init. A tentative row chains TO a committed digest but nothing
    committed chains to it, so no tentative generation is ever reached. Rows naming the committed
    digest must agree with each other and with the committed document's generation and
    `previous_digest`, else `journal_ambiguous` before any walk. A walk that meets a gap, a
    predecessor without its digest, an ambiguous or non-descending predecessor, or the end of the
    journal's two bounded files stops there: INCOMPLETE_EVIDENCE with that floor. Invalid JSON is
    `journal_corrupt` (raised by the journal reader)."""
    by_digest: dict[str, list[Mapping[str, Any]]] = {}
    for row in er.RegistryStore(registry_dir)._journal_rows(er.MAX_JOURNAL_WALK):
        if type(row.get("digest")) is str:
            by_digest.setdefault(row["digest"], []).append(row)

    def shapes(digest: str) -> set[tuple[int | None, Any, Any]]:
        return {(_journal_generation(row), row.get("previous_digest"), row.get("action"))
                for row in by_digest.get(digest, ())}

    committed = {registry.generation: registry.digest}
    anchors = shapes(registry.digest)
    if len(anchors) > 1 or any(anchor[:2] != (registry.generation, registry.doc["previous_digest"])
                               for anchor in anchors):
        raise RegistryError("journal_ambiguous",
                            f"{len(by_digest[registry.digest])} journal rows name generation "
                            f"{registry.generation}'s digest and disagree with it or with each other")
    if not anchors:
        return Ancestry(committed, INCOMPLETE_EVIDENCE, registry.generation)
    ((generation, previous, action),) = anchors
    while action != "init":
        found = shapes(previous) if type(previous) is str else set()
        if len(found) != 1:
            break
        ((earlier, earlier_previous, earlier_action),) = found
        if earlier is None or earlier >= generation:
            break
        committed[earlier] = previous
        generation, previous, action = earlier, earlier_previous, earlier_action
    else:
        return Ancestry(committed, VERIFIED, min(committed))
    return Ancestry(committed, INCOMPLETE_EVIDENCE, min(committed))


def _commit_row_problem(row: Mapping[str, Any], registry: er.Registry, ancestry: Ancestry, last: int,
                        generation_of: Mapping[str, int]) -> tuple[str, str] | None:
    """None when this commit row may open a group: a generation `ancestry` proves committed, with
    that generation's committed digest, strictly above every commit accepted before it (a backward
    or duplicate commit is refused), its digest naming no other accepted generation, within the
    committed registry. Else (code, reason). O(1) per row."""
    generation, digest = int(row["generation"]), row["registry_digest"]
    mismatch = "history_generation_mismatch"
    proven = ancestry.committed.get(generation)
    if proven is None:
        if ancestry.status != VERIFIED and generation < ancestry.floor:
            return ("history_incomplete_evidence",
                    f"commits generation {generation}, below generation {ancestry.floor}, the oldest the "
                    f"journal still proves committed")
        return mismatch, f"commits generation {generation}, which never committed"
    if proven != digest:
        return mismatch, f"generation {generation} digest is not that generation's committed digest"
    if generation <= last:
        return mismatch, f"commits generation {generation} at or below the already committed generation {last}"
    if generation_of.get(digest, generation) != generation:
        return mismatch, f"names generation {generation_of[digest]}'s digest for generation {generation}"
    if generation > registry.generation:
        return mismatch, f"generation {generation} is beyond the committed registry's {registry.generation}"
    if generation == registry.generation and digest != registry.digest:
        return mismatch, f"generation {generation} digest is not the committed registry's"
    return None


def bind_history(rows: Iterable[Mapping[str, Any]], registry: er.Registry,
                 ancestry: Ancestry | None = None
                 ) -> tuple[list[tuple[Mapping[str, Any], list[Mapping[str, Any]]]], list[str]]:
    """([(commit row, the role rows it commits)], problems), in file order. Without an `Ancestry`
    (from `committed_ancestry`) no commit row is proven: ([], [history_unverified]). A role row
    belongs to the next commit row only when both name the same (generation, digest); anything else
    pending at a commit is a tentative tail (A7) and is dropped. A commit row the committed evidence
    does not vouch for (`_commit_row_problem`) is `history_generation_mismatch`, or
    `history_incomplete_evidence` below an incomplete walk's floor, and binds nothing. A row naming
    an already committed generation after its commit, one bound to a rejected commit, or one whose
    role the committed registry's `roles_by_generation` contradicts, is `history_role_mismatch`.
    All are reported, never an interval (X4 alarms)."""
    if not isinstance(ancestry, Ancestry):
        return [], [_NO_ANCESTRY]
    groups: list[tuple[Mapping[str, Any], list[Mapping[str, Any]]]] = []
    problems: list[str] = []
    committed: set[tuple[str, str]] = set()
    generation_of: dict[str, int] = {}
    last = 0
    pending: list[tuple[int, Mapping[str, Any]]] = []

    def stale(index: int, row: Mapping[str, Any]) -> None:
        if (row["generation"], row["registry_digest"]) in committed:
            problems.append(f"history_role_mismatch: row {index} follows generation {row['generation']}'s commit")

    for index, row in enumerate(rows):
        if row["kind"] == "role":
            pending.append((index, row))
            continue
        key = (row["generation"], row["registry_digest"])
        rejected = _commit_row_problem(row, registry, ancestry, last, generation_of)
        if rejected is not None:
            problems.append(f"{rejected[0]}: row {index} {rejected[1]}")
        bound = []
        for at, role_row in pending:
            if (role_row["generation"], role_row["registry_digest"]) != key:
                stale(at, role_row)
                continue
            problem = _role_row_problem(role_row, registry)
            if problem is None and rejected is not None:
                problem = f"belongs to the rejected commit row {index}"
            if problem is None:
                bound.append(role_row)
            else:
                problems.append(f"history_role_mismatch: row {at} {problem}")
        pending = []
        if rejected is None:
            committed.add(key)
            generation_of[row["registry_digest"]] = last = int(row["generation"])
            groups.append((row, bound))
    for at, role_row in pending:
        stale(at, role_row)
    return groups, problems


def authority_intervals(rows: Iterable[Mapping[str, Any]], registry: er.Registry,
                        ancestry: Ancestry | None = None) -> AuthorityIntervals:
    """Per domain, the (start_ns, end_ns or None, generation) intervals in which it held authority,
    with the ancestry's status; without `committed_ancestry` evidence the answer is UNVERIFIED and
    empty (a structural check cannot prove a generation committed).

    Only role rows `bind_history` binds to their own accepted commit count (A7: a tentative tail
    never does; a chained row the committed registry contradicts, or a commit for a generation the
    journal does not prove committed, never does). A raise starts at its commit row (the latest
    moment it could have taken effect); a lowering ends the interval at its role row, written
    before the replace (the earliest moment), so an interval never overstates authority."""
    if not isinstance(ancestry, Ancestry):
        return AuthorityIntervals(UNVERIFIED, {}, (_NO_ANCESTRY,))
    groups, problems = bind_history(rows, registry, ancestry)
    open_: dict[str, tuple[int, int]] = {}
    out: dict[str, list[tuple[int, int | None, int]]] = {}
    for commit, bound in groups:
        for row in bound:
            domain = row["domain"]
            if row["role"] == DOMAIN_AUTHORITY and domain not in open_:
                open_[domain] = (int(commit["at_ns"]), int(row["generation"]))
            elif row["role"] == DOMAIN_EXIT_ONLY and domain in open_:
                start, generation = open_.pop(domain)
                out.setdefault(domain, []).append((start, max(start, int(row["at_ns"])), generation))
    for domain, (start, generation) in open_.items():
        out.setdefault(domain, []).append((start, None, generation))
    return AuthorityIntervals(ancestry.status, out, tuple(problems))


def first_row_ns(rows: Iterable[Mapping[str, Any]], registry: er.Registry,
                 ancestry: Ancestry | None = None) -> FirstRows:
    """Per member, the at_ns of its first bound role row; E1 counts SENTs before it as pre_registry.
    Without `committed_ancestry` evidence the answer is UNVERIFIED and empty."""
    if not isinstance(ancestry, Ancestry):
        return FirstRows(UNVERIFIED, {}, (_NO_ANCESTRY,))
    groups, problems = bind_history(rows, registry, ancestry)
    first: dict[str, int] = {}
    for _, bound in groups:
        for row in bound:
            first.setdefault(row["member_key"], int(row["at_ns"]))
    return FirstRows(ancestry.status, first, tuple(problems))


def read_authority(registry_dir: Path | str) -> tuple[AuthorityIntervals, FirstRows]:
    """The production read (E1, X4): the committed registry, its history and the journal's
    committed ancestry, so every answer carries verified evidence. History and journal refusals
    (`history_*`, `journal_*`) propagate; no registry is an UNVERIFIED, empty answer."""
    registry = er.RegistryStore(registry_dir).load()
    if registry is None:
        return (AuthorityIntervals(UNVERIFIED, {}, ("registry_absent",)),
                FirstRows(UNVERIFIED, {}, ("registry_absent",)))
    rows = read_history(registry_dir)
    ancestry = committed_ancestry(registry_dir, registry)
    return authority_intervals(rows, registry, ancestry), first_row_ns(rows, registry, ancestry)


def _role_map(registry: er.Registry) -> dict[str, str]:
    """domain -> role of one registry generation."""
    return er.derive_roles(registry.accounts, registry.doc["exposure"]["members"])


def _roles(registry: er.Registry) -> dict[str, tuple[str, str]]:
    """domain -> (role, member_key) of one registry generation."""
    return {account["domain"]: (DOMAIN_EXIT_ONLY if account["exit_only"] else DOMAIN_AUTHORITY,
                                account["member_key"])
            for account in registry.accounts.values()}


def _repair_commit_row(registry_dir: Path, registry: er.Registry, now_ns: int) -> bool:
    """`registry` is committed (it was loaded from disk and chain-verified); if the history tail is
    its own role rows with no commit row (a crash between the replace and the commit row), add it."""
    tail = _history_tail(registry_dir)
    if (tail is None or tail["kind"] != "role"
            or (tail["generation"], tail["registry_digest"]) != (str(registry.generation), registry.digest)):
        return False
    append_history(registry_dir, [_history_row("commit", registry, at_ns=now_ns, request_id=None,
                                               outcome="repaired")])
    return True


def reconcile_history(registry_dir: Path | str, registry: er.Registry, *,
                      now_ns: int | None = None) -> int:
    """Make the committed history agree with the committed registry: add a missing commit row, or
    seed role rows for a registry the history never saw (a pre-X1 registry). Returns rows added."""
    directory = Path(registry_dir)
    now_ns = time.time_ns() if now_ns is None else now_ns
    rows = read_history(directory)
    committed = {(row["generation"], row["registry_digest"]) for row in rows if row["kind"] == "commit"}
    key = (str(registry.generation), registry.digest)
    if key not in committed and any(row["kind"] == "role" and (row["generation"], row["registry_digest"]) == key
                                    for row in rows):
        append_history(directory, [_history_row("commit", registry, at_ns=now_ns, request_id=None,
                                                outcome="repaired")])
        return 1
    known: dict[str, str] = {}
    for row in rows:
        if row["kind"] == "role" and (row["generation"], row["registry_digest"]) in committed:
            known[row["domain"]] = row["role"]
    state, _ = _state_or_strictest(directory)
    seed = [_history_row("role", registry, at_ns=now_ns, request_id=None, outcome="seeded",
                         member_key=member_key, domain=domain, role=role,
                         enforcement=member_enforcement(state, member_key))
            for domain, (role, member_key) in sorted(_roles(registry).items()) if known.get(domain) != role]
    if not seed:
        return 0
    append_history(directory, seed + [_history_row("commit", registry, at_ns=now_ns, request_id=None,
                                                   outcome="seeded")])
    return len(seed) + 1


# ---------------------------------------------------------------- role files

def slug(domain: str) -> str:
    """File stem of a domain's role file: `:` becomes `_` (lane ids never contain `_`)."""
    return er._match(er._DOMAIN, domain, "domain").replace(":", "_")


def role_path(roles_dir: Path | str, domain: str) -> Path:
    return Path(roles_dir) / f"{slug(domain)}.json"


def desired_roles(registry: er.Registry, state: Mapping[str, Any] | None) -> dict[str, dict[str, Any]]:
    """Each domain's role record: exit_only when the registry says so OR when its member's sidecar
    transfer drains FROM it in a pre-BEGIN phase (the transfer-prepared lowering). A domain whose
    sidecar records a principal gets schema 2 with `expected_principal_digest`; every other record
    is exactly schema 1."""
    out: dict[str, dict[str, Any]] = {}
    for domain, (role, member_key) in _roles(registry).items():
        member = None if state is None else state["members"].get(member_key)
        transfer = None if member is None else member["transfer"]
        reason = REASON_REGISTRY
        if (role == DOMAIN_AUTHORITY and transfer is not None and transfer["from"] == domain
                and transfer["phase"] in LOWERING_PHASES):
            role, reason = DOMAIN_EXIT_ONLY, REASON_TRANSFER_PREPARED
        out[domain] = {"schema": 1, "domain": domain, "member_key": member_key, "role": role,
                       "enforcement": member_enforcement(state, member_key), "reason": reason,
                       "generation": registry.generation, "registry_digest": registry.digest}
        principal = state_principal(state, domain)
        if principal is not None:
            out[domain]["schema"] = 2
            out[domain]["expected_principal_digest"] = principal
    return out


def _role_bytes(record: Mapping[str, Any]) -> bytes:
    return er.canonical_bytes(record)


def _check_roles_dir(roles_dir: Path, owner: int | None) -> None:
    """Fails closed: the projector writes only into root-owned 0755 directories (X4's tmpfiles). With
    `owner` None (tests, dev) or off POSIX the directory is created instead of checked. Checked on
    the RESOLVED directory, as the identity check (`_dir_identity`) compares it, so both agree on a
    symlink (X1a-fix4): the directory holding the link, the target and the target's parent must
    each be owned by `owner` with mode 0755; a link to a foreign or writable directory refuses."""
    if owner is None or os.name != "posix":
        roles_dir.mkdir(parents=True, exist_ok=True)
        return
    resolved = Path(os.path.realpath(os.fspath(roles_dir)))
    checked = []
    for directory in (Path(os.path.realpath(os.fspath(roles_dir.parent))), resolved.parent, resolved):
        if directory not in checked:
            checked.append(directory)
    for directory in checked:
        try:
            info = os.lstat(directory)
        except OSError as exc:
            raise RegistryError("roles_dir_unsafe", f"{directory}: {exc}") from exc
        if (not stat_module.S_ISDIR(info.st_mode) or info.st_uid != owner
                or stat_module.S_IMODE(info.st_mode) != 0o755):
            raise RegistryError("roles_dir_unsafe",
                                f"{directory}: must be a directory owned by uid {owner} with mode 0755")


def _existing_role_files(roles_dir: Path) -> dict[str, Path]:
    found: dict[str, Path] = {}
    with os.scandir(roles_dir) as entries:
        for index, entry in enumerate(entries):
            if index >= MAX_ROLE_DIR_ENTRIES:
                raise RegistryError("roles_dir_overfull", f"{roles_dir}: more than {MAX_ROLE_DIR_ENTRIES} entries")
            name = entry.name
            if name.startswith(".") or not name.endswith(".json") or name == MARKER_FILE:
                continue
            found[name[:-len(".json")]] = Path(entry.path)
    return found


def _read_small(path: Path) -> bytes | None:
    try:
        return er._read_bounded(path, MAX_ROLE_BYTES)
    except (OSError, RegistryError):
        return None


def _write_roles(roles_dir: Path, registry: er.Registry, state: Mapping[str, Any] | None, *,
                 owner: int | None, lowering_only: bool) -> dict[str, list[str]]:
    """Phase 1: every lowering (a domain whose desired role is exit_only and whose file differs) and
    every removal of a file naming no registered domain. Phase 2, unless `lowering_only`: the
    marker, then every other differing file (the raises). Idempotent: equal bytes are skipped."""
    _check_roles_dir(roles_dir, owner)
    desired = desired_roles(registry, state)
    wanted = {slug(domain): (domain, _role_bytes(record)) for domain, record in desired.items()}
    existing = _existing_role_files(roles_dir)
    report: dict[str, list[str]] = {"lowered": [], "raised": [], "removed": [], "unchanged": []}
    later = []
    for stem in sorted(wanted):
        domain, data = wanted[stem]
        path = roles_dir / f"{stem}.json"
        if _read_small(path) == data:
            report["unchanged"].append(domain)
        elif desired[domain]["role"] == DOMAIN_EXIT_ONLY:
            er._atomic_write(path, data, 0o444)
            report["lowered"].append(domain)
        else:
            later.append((domain, path, data))
    for stem in sorted(set(existing) - set(wanted)):
        existing[stem].unlink()
        report["removed"].append(stem)
    if lowering_only:
        return report
    marker = er.canonical_bytes({"generation": registry.generation, "digest": registry.digest})
    marker_path = roles_dir / MARKER_FILE
    report["marker"] = []
    if _read_small(marker_path) != marker:
        er._atomic_write(marker_path, marker, 0o444)
        report["marker"].append(str(registry.generation))
    for domain, path, data in later:
        er._atomic_write(path, data, 0o444)
        report["raised"].append(domain)
    return report


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _decode_witness(data: bytes, where: str) -> dict[str, Any]:
    witness = er._exact(er.strict_loads(data, MAX_ROLE_BYTES), _WITNESS_KEYS, where)
    _path_text(witness["roles_dir"], f"{where}.roles_dir")
    er._match(er._HEX64, witness["token_digest"], f"{where}.token_digest")
    return witness


def _read_witness(registry_dir: Path | str) -> tuple[bytes, dict[str, Any]] | None:
    """(bytes, decoded) of the projection witness, or None when absent. One that cannot be read or
    decoded refuses `roles_dir_mismatch` (fails closed)."""
    path = Path(registry_dir) / PROJECTION_FILE
    try:
        data = er._read_bounded(path, MAX_ROLE_BYTES)
    except FileNotFoundError:
        return None
    except (OSError, RegistryError) as exc:
        raise RegistryError("roles_dir_mismatch", f"{path}: unreadable ({exc})") from exc
    try:
        return data, _decode_witness(data, str(path))
    except RegistryError as exc:
        raise RegistryError("roles_dir_mismatch", f"{path}: {exc}") from exc


def _token_digest(roles_dir: Path | str) -> str | None:
    data = _read_small(Path(roles_dir) / TOKEN_FILE)
    return None if data is None else _sha256(data)


def projection_active(registry_dir: Path | str) -> bool:
    """True once a projection was activated: the sidecar's activation record or the witness says
    so (a readable sidecar with no record and no witness is first use)."""
    state, _ = _state_or_strictest(Path(registry_dir))
    return (state is not None and state["projection"] is not None) or os.path.exists(
        Path(registry_dir) / PROJECTION_FILE)


def _dir_identity(path: Path | str) -> str:
    """Resolved path identity: symlinks, `..` and (on Windows) case all compare equal."""
    return os.path.normcase(os.path.realpath(os.fspath(path)))


def recorded_roles_dir(registry_dir: Path | str) -> str | None:
    """The role directory the projection witness recorded, or None when there is no witness."""
    witness = _read_witness(registry_dir)
    return None if witness is None else witness[1]["roles_dir"]


def active_projection(registry_dir: Path | str, roles_dir: Path | str | None = None) -> dict[str, str] | None:
    """The verified activation evidence ({roles_dir, token_digest, witness_digest}), or None at first
    use: the registry's sidecar records no activation and no witness exists. Fails closed with
    `projection_witness_missing` when the sidecar records an activation and the witness is gone, and
    `roles_dir_mismatch` when the witness is unreadable or disagrees with the sidecar's record, names
    a directory other than `roles_dir`, or `roles_dir` lacks the token recorded at activation (a
    fresh directory at the same pathname). A witness with no record (a crash inside activation, or
    an unreadable sidecar) is verified on its own."""
    directory = Path(registry_dir)
    state, _ = _state_or_strictest(directory)
    record = None if state is None else state["projection"]
    witness = _read_witness(directory)
    if witness is None:
        if record is not None:
            raise RegistryError("projection_witness_missing",
                                f"the registry records a projection into {record['roles_dir']}, "
                                f"but {directory / PROJECTION_FILE} is gone")
        return None
    data, body = witness
    evidence = {"roles_dir": body["roles_dir"], "token_digest": body["token_digest"],
                "witness_digest": _sha256(data)}
    if record is not None and record != evidence:
        raise RegistryError("roles_dir_mismatch",
                            f"{directory / PROJECTION_FILE} is not the witness the registry recorded")
    if roles_dir is not None:
        if _dir_identity(body["roles_dir"]) != _dir_identity(roles_dir):
            raise RegistryError("roles_dir_mismatch",
                                f"the active projection writes {body['roles_dir']}, this writer {os.fspath(roles_dir)}")
        if _token_digest(roles_dir) != body["token_digest"]:
            raise RegistryError("roles_dir_mismatch",
                                f"{os.fspath(roles_dir)} lacks the projection's activation token: "
                                f"a replaced or fresh directory")
    return evidence


def _require_recorded_roles_dir(registry_dir: Path, roles_dir: Path) -> None:
    """A writer or projector whose role directory is not the one the active projection recorded
    (another path, or a fresh directory at that path) refuses `roles_dir_mismatch`, and one whose
    witness is gone `projection_witness_missing`, before any journal, sidecar, registry or role
    write: lowering B while every reader of the recorded A still answers authority is a bypass.
    Moving the role directory is a root operation: retire the witness and the sidecar's record,
    and delete the mirror at the OLD resolved role directory's parent."""
    active_projection(registry_dir, roles_dir)


def _mark_projection_active(registry_dir: Path, roles_dir: Path,
                            state: dict[str, Any] | None) -> dict[str, Any] | None:
    """Verify, or at first use perform, activation: a random token into `roles_dir`, then the
    registry witness, then the sidecar's record. Mirror sync follows the role writes so a
    mirror failure cannot prevent a lowering. A crash leaves a token or a witness without a
    record, which the next activation
    verifies and completes. Returns the sidecar as it now stands (None while unreadable, when the
    witness alone carries the activation)."""
    evidence = active_projection(registry_dir, roles_dir)
    if evidence is None:
        token = secrets.token_hex(32).encode("ascii")
        er._atomic_write(roles_dir / TOKEN_FILE, token, 0o444)
        data = er.canonical_bytes({"roles_dir": os.path.realpath(os.fspath(roles_dir)),
                                   "token_digest": _sha256(token)})
        er._atomic_write(registry_dir / PROJECTION_FILE, data, 0o644)
        evidence = {"roles_dir": os.path.realpath(os.fspath(roles_dir)), "token_digest": _sha256(token),
                    "witness_digest": _sha256(data)}
    else:
        witness = _read_witness(registry_dir)
        if witness is None or _sha256(witness[0]) != evidence["witness_digest"]:
            raise RegistryError("roles_dir_mismatch", "the verified projection witness changed")
    if state is not None and state["projection"] != evidence:
        state = write_state(registry_dir, dict(state, projection=evidence))
    return state


def _witness_mirror_path(registry_dir: Path | str, roles_dir: Path | str) -> Path | None:
    """A sibling of the resolved role directory, unless it is the registry witness itself."""
    mirror = Path(os.path.realpath(os.fspath(roles_dir))).parent / PROJECTION_FILE
    witness = Path(registry_dir) / PROJECTION_FILE
    return None if _dir_identity(mirror) == _dir_identity(witness) else mirror


def _verified_witness_bytes(registry_dir: Path, roles_dir: Path) -> bytes | None:
    evidence = active_projection(registry_dir, roles_dir)
    if evidence is None:
        return None
    witness = _read_witness(registry_dir)
    if witness is None or _sha256(witness[0]) != evidence["witness_digest"]:
        raise RegistryError("roles_dir_mismatch", "the verified projection witness changed")
    return witness[0]


def _sync_witness_mirror_locked(registry_dir: Path, roles_dir: Path) -> dict[str, Any]:
    try:
        data = _verified_witness_bytes(registry_dir, roles_dir)
        if data is None:
            return {"ok": True, "changed": False, "error": None}
        mirror = _witness_mirror_path(registry_dir, roles_dir)
        changed = mirror is not None and _read_small(mirror) != data
        if changed:
            er._atomic_write(mirror, data, 0o444)
        return {"ok": True, "changed": changed, "error": None}
    except (RegistryError, OSError) as exc:
        return {"ok": False, "changed": False, "error": str(exc) or type(exc).__name__}


def sync_witness_mirror(registry_dir: Path | str, roles_dir: Path | str) -> dict[str, Any]:
    """Verify the registry authority and idempotently sync its readable witness mirror.
    Failures are reportable evidence, never a reason to skip the step's other actions.
    Equal bytes need no lock. A write re-verifies under the registry lock; contention defers
    the copy until the next tick without waiting for another writer."""
    store = er.RegistryStore(registry_dir, lock_timeout_s=0)
    try:
        data = _verified_witness_bytes(store.directory, Path(roles_dir))
        if data is None:
            return {"ok": True, "changed": False, "error": None}
        mirror = _witness_mirror_path(store.directory, roles_dir)
        if mirror is None or _read_small(mirror) == data:
            return {"ok": True, "changed": False, "error": None}
        with store._lock():
            return _sync_witness_mirror_locked(store.directory, Path(roles_dir))
    except TimeoutError:
        return {"ok": False, "changed": False, "error": "busy"}
    except (RegistryError, OSError) as exc:
        return {"ok": False, "changed": False, "error": str(exc) or type(exc).__name__}


def _require_roles_dir(store: er.RegistryStore, old_roles: Mapping[str, str], new_roles: Mapping[str, str]) -> None:
    """An authority-changing commit (any domain's role changes, appears or goes) by a writer with
    no role directory refuses once projection is active (`roles_dir_required`, or
    `projection_witness_missing` when the registry records an activation whose witness is gone):
    its lowering would trail the replace. Any commit by a writer whose role directory is not the
    recorded one refuses `roles_dir_mismatch`."""
    if store.roles_dir is not None:
        _require_recorded_roles_dir(store.directory, store.roles_dir)
        return
    if dict(old_roles) != dict(new_roles) and active_projection(store.directory) is not None:
        raise RegistryError("roles_dir_required",
                            "an authority change needs the role directory once projection is active")


def _binding_ok(state: Mapping[str, Any], registry: er.Registry) -> bool:
    """The sidecar is bound to `registry`: never bound yet (a fresh or pre-X1 sidecar, so only the
    phases decide), bound to it, or bound to the generation it replaced (the crash window between
    a commit's replace and its rebind)."""
    generation, digest = state["registry_generation"], state["registry_digest"]
    if generation is None:
        return True
    if (generation, digest) == (str(registry.generation), registry.digest):
        return True
    return digest == registry.doc["previous_digest"] and int(generation) < registry.generation


def projection_problems(registry: er.Registry, state: Mapping[str, Any] | None,
                        state_error: str | None) -> list[str]:
    """Checked BEFORE any role file is written: an unreadable sidecar, a sidecar bound to another
    registry, or a transfer phase illegal for this registry. Any entry withholds every raise."""
    if state is None:
        return [f"state_unreadable: {state_error}"]
    problems = []
    if not _binding_ok(state, registry):
        problems.append(f"state_binding_mismatch: sidecar bound to generation {state['registry_generation']}, "
                        f"registry is generation {registry.generation}")
    problems.extend(state_consistency(registry, state))
    return problems


def _project_locked(store: er.RegistryStore, registry: er.Registry, roles_dir: Path, *,
                    owner: int | None, now_ns: int | None = None) -> dict[str, Any]:
    _require_recorded_roles_dir(store.directory, roles_dir)
    state, state_error = _state_or_strictest(store.directory)
    problems = projection_problems(registry, state, state_error)
    report: dict[str, Any] = {"generation": registry.generation, "digest": registry.digest,
                              "state_error": state_error, "history_error": None, "history_rows": 0,
                              "inconsistent": problems, "raises_withheld": bool(problems), "marker": []}
    _check_roles_dir(roles_dir, owner)
    state = _mark_projection_active(store.directory, roles_dir, state)
    # Inconsistent transfer state: lowerings and removals still apply, no file is raised (X4 alarms).
    report.update(_write_roles(roles_dir, registry, state, owner=owner, lowering_only=bool(problems)))
    report["witness_mirror"] = _sync_witness_mirror_locked(store.directory, roles_dir)
    if not problems and (state["registry_generation"], state["registry_digest"]) != (
            str(registry.generation), registry.digest):
        write_state(store.directory, dict(state, registry_generation=str(registry.generation),
                                          registry_digest=registry.digest))
    try:
        report["history_rows"] = reconcile_history(store.directory, registry, now_ns=now_ns)
    except (RegistryError, OSError) as exc:  # evidence, not enforcement: role files are already right
        report["history_error"] = str(exc) or type(exc).__name__
    return report


def project(registry_dir: Path | str, roles_dir: Path | str = ROLES_DIR, *, owner: int | None = 0,
            now_ns: int | None = None, lock_timeout_s: float = er.LOCK_TIMEOUT_S) -> dict[str, Any]:
    """`exposure project`: rewrite the role files and marker from the committed registry and the
    sidecar, lowerings first, idempotently; X4 `step` runs it every tick. Holds the registry lock for
    local file I/O only, so a concurrent commit can never have its lowering overwritten by a stale
    raise. Returns a report; `registry` None means no registry exists and nothing was written."""
    store = er.RegistryStore(registry_dir, lock_timeout_s=lock_timeout_s)
    with store._lock():
        registry = store.load()
        if registry is None:
            return {"generation": None, "digest": None, "registry": None}
        return _project_locked(store, registry, Path(roles_dir), owner=owner, now_ns=now_ns)


def state_consistency(registry: er.Registry, state: Mapping[str, Any]) -> list[str]:
    """Members whose sidecar transfer is illegal for this registry: a phase that disagrees with the
    C1 transfer triple, a transfer naming a domain outside its member, a pre-BEGIN phase whose
    `from` is not the registry's authority, a C1 drain from another domain, or a transfer for a
    member the registry does not know (reported, never repaired here: X4 owns the state machine)."""
    problems = []
    members = registry.doc["exposure"]["members"]
    domains: dict[str, set[str]] = {}
    for account in registry.accounts.values():
        domains.setdefault(account["member_key"], set()).add(account["domain"])
    for member_key, member in sorted(members.items()):
        side = state["members"].get(member_key)
        transfer = None if side is None else side["transfer"]
        c1 = member["transfer"]
        step = None if c1 is None else c1["step"]
        expected = None if transfer is None else PHASE_TO_STEP.get(transfer["phase"])
        if step != expected:
            problems.append(f"{member_key}: registry step {step!r}, sidecar phase "
                            f"{None if transfer is None else transfer['phase']!r}")
        elif transfer is not None:
            where = f"{member_key}: transfer {transfer['request_id']} ({transfer['phase']})"
            if not {transfer["from"], transfer["to"]} <= domains.get(member_key, set()):
                problems.append(f"{where} names a domain outside the member")
            elif c1 is None and member["authority_domain"] != transfer["from"]:
                problems.append(f"{where} drains {transfer['from']} but the registry's authority is "
                                f"{member['authority_domain']!r}")
            elif c1 is not None and c1["draining_from"] != transfer["from"]:
                problems.append(f"{where} drains {transfer['from']} but the registry drains {c1['draining_from']}")
    for member_key, side in sorted(state["members"].items()):
        if member_key not in members and side["transfer"] is not None:
            problems.append(f"{member_key}: a sidecar transfer for a member the registry does not know")
    registered = {account["domain"] for account in registry.accounts.values()}
    for domain in sorted(state.get("principals", {})):
        if domain not in registered:
            problems.append(f"principals: {domain} is recorded for a domain the registry does not know")
    return problems


# ---------------------------------------------------------------- the commit hook RegistryStore runs

class CommitPlan:
    """The exposure half of one RegistryStore._commit, under its lock: history role rows and role
    LOWERINGS before the atomic replace; the commit row, the marker and the raises after it."""

    def __init__(self, store: er.RegistryStore, current: er.Registry | None, registry: er.Registry, *,
                 action: str, request_id: str | None, now_ns: int | None = None) -> None:
        self.store = store
        self.current = current
        self.registry = registry
        self.action = action
        self.request_id = request_id
        self.now_ns = time.time_ns() if now_ns is None else now_ns
        self.changed = False
        # Runs before the journal append, so a refusal leaves no tentative generation behind.
        _require_roles_dir(store, {} if current is None else _role_map(current), _role_map(registry))
        self.state, self.state_error = _state_or_strictest(store.directory)

    def before_replace(self) -> None:
        directory = self.store.directory
        old = {} if self.current is None else _roles(self.current)
        rows = [_history_row("role", self.registry, at_ns=self.now_ns, request_id=self.request_id,
                             outcome=self.action, member_key=member_key, domain=domain, role=role,
                             enforcement=member_enforcement(self.state, member_key))
                for domain, (role, member_key) in sorted(_roles(self.registry).items())
                if old.get(domain, (None,))[0] != role]
        if rows:
            # A role change is refused on a broken history: its interval would be unprovable.
            if self.current is not None:
                _repair_commit_row(directory, self.current, self.now_ns)
            append_history(directory, rows)
        elif self.current is not None:
            try:  # no role change: history is evidence only, so a broken one never blocks the write
                _repair_commit_row(directory, self.current, self.now_ns)
            except (RegistryError, OSError):
                pass
        self.changed = bool(rows)
        if self.store.roles_dir is not None:
            _check_roles_dir(self.store.roles_dir, self.store.roles_owner)
            # The activation record lands in the sidecar; carry it into the state after_replace rebinds.
            self.state = _mark_projection_active(directory, self.store.roles_dir, self.state)
            _write_roles(self.store.roles_dir, self.registry, self.state, owner=self.store.roles_owner,
                         lowering_only=True)

    def after_replace(self) -> None:
        directory = self.store.directory
        if self.changed:
            append_history(directory, [_history_row(
                "commit", self.registry, at_ns=time.time_ns(), request_id=self.request_id,
                outcome="committed")])
        # Carry the sidecar's binding across the commit it saw; the phases are judged separately.
        state = self.state
        if (state is not None and (directory / STATE_FILE).exists()
                and (state["registry_generation"] is None if self.current is None
                     else _binding_ok(state, self.current))):
            write_state(directory, dict(state, registry_generation=str(self.registry.generation),
                                        registry_digest=self.registry.digest))
        if self.store.roles_dir is not None:
            _project_locked(self.store, self.registry, self.store.roles_dir, owner=self.store.roles_owner)


# ---------------------------------------------------------------- CAS writes for the verbs and the step

def mutate_exposure(registry_dir: Path | str, *, expect: tuple[int, str], action: str,
                    registry_change: Callable[[dict[str, Any]], bool] | None = None,
                    state_change: Callable[[dict[str, Any]], bool] | None = None,
                    roles_dir: Path | str | None = None, owner: int | None = 0,
                    request_id: str | None = None, actor: str | None = None,
                    now: datetime | None = None,
                    lock_timeout_s: float = er.LOCK_TIMEOUT_S) -> tuple[er.Registry, dict[str, Any]]:
    """One compare-and-swap on the (generation, digest) read before the decision; a mismatch
    refuses with `registry_changed` and writes nothing. The sidecar change (if any) lands first so
    the registry commit's lowering pass already sees it; with no registry change, the role files
    are re-projected so a sidecar lowering (transfer prepared) takes effect at once."""
    store = er.RegistryStore(registry_dir, lock_timeout_s=lock_timeout_s, roles_dir=roles_dir,
                             roles_owner=owner)
    with store._lock():
        current = store.load()
        if current is None:
            raise RegistryError("registry_absent", "run registry init first")
        if (current.generation, current.digest) != tuple(expect):
            raise RegistryError("registry_changed",
                                f"expected generation {expect[0]}, found {current.generation}")
        doc = None
        if registry_change is not None:
            doc = current.copy_document()
            if not registry_change(doc):
                doc = None
        if store.roles_dir is not None:
            # Refuse before the sidecar write, so a roles_dir_mismatch refusal writes nothing.
            _require_recorded_roles_dir(store.directory, store.roles_dir)
        elif doc is not None:
            # Refuse before the sidecar write, so a roles_dir_required refusal writes nothing.
            try:
                new_roles = er.derive_roles(doc["accounts"], doc["exposure"]["members"])
            except (KeyError, TypeError, AttributeError):
                new_roles = None  # a malformed document: _commit's strict decoder refuses it
            if new_roles is not None:
                _require_roles_dir(store, _role_map(current), new_roles)
        state = load_state(store.directory)
        if state_change is not None:
            candidate = json.loads(er.canonical_bytes(state))
            if state_change(candidate):
                state = write_state(store.directory, candidate)
        registry = current
        if doc is not None:
            registry = store._commit(current, doc, action, request_id=request_id, actor=actor, now=now)
        if registry is current and store.roles_dir is not None:
            _project_locked(store, current, store.roles_dir, owner=owner)
        return registry, state


def apply_register(doc: dict[str, Any], account_id: str, *, domain: str, kind: str, label: str,
                   lane_id: str | None = None, member_key: str | None = None,
                   new_member_key: str | None = None, attestation: str | None = None) -> bool:
    """Add one account (pure, doc in place). Under an existing member the domain starts exit_only;
    a new single-domain member holds its own authority only with a signed D7 attestation id
    (VII.4: membership fails closed)."""
    if (member_key is None) == (new_member_key is None):
        raise RegistryError("invalid_member", "exactly one of member_key or new_member_key")
    er._match(er._KEY_ID, account_id, "account_id")
    if account_id in doc["accounts"]:
        raise RegistryError("account_exists", account_id)
    if any(account["domain"] == domain for account in doc["accounts"].values()):
        raise RegistryError("domain_reused", domain)
    if len(doc["accounts"]) >= er.MAX_ACCOUNTS:
        raise RegistryError("too_many_accounts", str(er.MAX_ACCOUNTS))
    members = doc["exposure"]["members"]
    if new_member_key is not None:
        er._match(er._KEY_ID, new_member_key, "new_member_key")
        if new_member_key in members:
            raise RegistryError("member_exists", new_member_key)
        if attestation is None:
            raise RegistryError("attestation_required", f"new member {new_member_key} needs a D7 attestation")
        er._match(er._REF_ID, attestation, "attestation")
        members[new_member_key] = {"authority_domain": domain, "transfer": None}
        key = new_member_key
    else:
        if member_key not in members:
            raise RegistryError("unknown_member", repr(member_key))
        key = member_key
    record = er.AccountSource(account_id, kind, domain, key, Path("."), lane_id, label).record()
    record["exit_only"] = members[key]["authority_domain"] != domain
    doc["accounts"][account_id] = record
    return True


# ---------------------------------------------------------------- the reader books and root tools use

@dataclass(frozen=True)
class RoleView:
    state: str
    domain: str | None = None
    member_key: str | None = None
    role: str | None = None
    enforcement: str | None = None
    reason: str | None = None
    generation: int | None = None
    registry_digest: str | None = None
    expected_principal_digest: str | None = None

    @property
    def refuses_opening(self) -> bool:
        """exit_only under operational enforcement, or any state that cannot prove authority."""
        if self.state == RECORD:
            return self.role == DOMAIN_EXIT_ONLY and self.enforcement == OPERATIONAL
        return self.state != ABSENT


_ABSENT_VIEW = RoleView(ABSENT)
_UNREGISTERED_VIEW = RoleView(UNREGISTERED)
_UNREADABLE_VIEW = RoleView(UNREADABLE)
_MISMATCH_VIEW = RoleView(LEDGER_MISMATCH)
_PRINCIPAL_MISMATCH_VIEW = RoleView(PRINCIPAL_MISMATCH)


def _parse_role(data: bytes, domain: str | None) -> RoleView:
    """Schema exactly int 1 (no principal) or exactly int 2 (with `expected_principal_digest`);
    anything else is unreadable (fails closed)."""
    try:
        raw = json.loads(data.decode("utf-8"), object_pairs_hook=er._pairs)
        if type(raw) is not dict or type(raw.get("schema")) is not int or raw["schema"] not in (1, 2):
            return _UNREADABLE_VIEW
        er._exact(raw, _ROLE_KEYS_V2 if raw["schema"] == 2 else _ROLE_KEYS, "role file")
        er._match(er._DOMAIN, raw["domain"], "role file domain")
        er._match(er._KEY_ID, raw["member_key"], "role file member_key")
        er._match(er._HEX64, raw["registry_digest"], "role file registry_digest")
        principal = (er._match(er._HEX64, raw["expected_principal_digest"], "role file expected_principal_digest")
                     if raw["schema"] == 2 else None)
    except (RegistryError, UnicodeError, ValueError, RecursionError):
        return _UNREADABLE_VIEW
    generation = raw["generation"]
    if ((domain is not None and raw["domain"] != domain)
            or raw["role"] not in (DOMAIN_AUTHORITY, DOMAIN_EXIT_ONLY)
            or raw["enforcement"] not in ENFORCEMENTS
            or raw["reason"] not in (REASON_REGISTRY, REASON_TRANSFER_PREPARED)
            or type(generation) is not int or not 1 <= generation <= er.MAX_GENERATION):
        return _UNREADABLE_VIEW
    return RoleView(RECORD, raw["domain"], raw["member_key"], raw["role"], raw["enforcement"],
                    raw["reason"], generation, raw["registry_digest"], principal)


def _stat_key(path: str) -> tuple[int, int, int, int, int] | None:
    """Evidence identity and permission changes; only a missing file returns None."""
    try:
        info = os.stat(path)
    except FileNotFoundError:
        return None
    return (info.st_mtime_ns, info.st_ino, info.st_size, info.st_mode, info.st_ctime_ns)


_INACCESSIBLE_WITNESS = object()


def _witness_stat_key(path: str | None) -> Any:
    """Keep inaccessible evidence distinct from absence without rejecting a readable peer."""
    if path is None:
        return None
    try:
        key = _stat_key(path)
    except PermissionError:
        return _INACCESSIBLE_WITNESS
    # Windows may report opening a directory as PermissionError. It is still broken evidence.
    if key is not None and stat_module.S_ISDIR(key[3]):
        raise IsADirectoryError(path)
    return key


def domain_for_ledger_root(root: Path | str) -> str | None:
    """`/var/lib/leafhft/account-risk` -> legacy-owner; `/var/lib/leafhft-accounts/<uuid>/account-risk`
    -> account-lane:<uuid>; any other root -> None."""
    text = os.fspath(root).replace("\\", "/").rstrip("/")
    if text == OWNER_LEDGER_ROOT:
        return LEGACY_OWNER_DOMAIN
    match = _LANE_LEDGER_ROOT.fullmatch(text)
    return None if match is None else f"account-lane:{match.group(1)}"


class DomainRole:
    """One domain's exposure role. Hot path: one os.stat when the role file exists, a re-parse only
    when (mtime, inode, size) changes, no allocation on a cache hit. States: `absent` (no marker, and
    for a root reader passing `registry_path`, no registry either: byte-identical behaviour),
    `unregistered` (marker present, no file for this domain: fails closed), `unreadable` (parse
    failure, or for a root reader a registry present with the marker absent), or the record.
    A reader built for an unmapped ledger root reports `domain_ledger_mismatch` while a marker exists
    and, like a mapped root reader, `unreadable` when a registry exists with no marker.

    Witness-backed (`registry_dir` by default in both class constructors, plus its mirror): once a
    projection witness exists, every miss and every re-parse checks that the role directory still
    holds its marker and the activation token the witness recorded, so a missing projection, or a
    fresh directory at the same pathname, is `unreadable`, never `absent`. A cached answer is bound
    to that evidence too (X1a-fix4, astra pass 4): every read also stats both witnesses, the token and
    the marker, and any change (removed, replaced, a new directory) drops the cache and re-runs the
    projection check before an answer is returned, so a retained reader never answers authority
    from evidence that is gone. The mirror lives beside the role directory so tenant namespaces
    can read it when the registry witness is inaccessible. Every readable witness must be valid;
    two readable witnesses must have identical bytes. Cost: a cached hit is one os.stat of the
    role file, plus four evidence stats when registry-backed (five in all), and no parse.

    Principal-bound (X1b, `principal_digest`, the sha256 of the live client's key id through
    `principal_digest()`): a record whose `expected_principal_digest` differs from it reads
    `domain_principal_mismatch`, which refuses openings. A record with no expected digest (an
    unbound domain) is returned unchanged, and without `principal_digest` the reader behaves exactly
    as before."""

    __slots__ = ("path", "domain", "marker_path", "registry_path", "witness_path", "mirror_path", "token_path", "_key",
                 "_evidence", "_view", "parses", "principal")

    def __init__(self, path: Path | str | None, *, registry_path: Path | str | None = None,
                 domain: str | None = None, marker_path: Path | str | None = None,
                 registry_dir: Path | str | None = None, principal_digest: str | None = None) -> None:
        # Fails closed before any read: a malformed expected digest raises here.
        self.principal = er._match(er._HEX64, principal_digest, "principal_digest", nullable=True)
        self.path = None if path is None else os.fspath(path)
        self.domain = domain
        if marker_path is None:
            if path is None:
                raise ValueError("a reader without a role file needs its marker path")
            marker_path = Path(path).parent / MARKER_FILE
        self.marker_path = os.fspath(marker_path)
        self.registry_path = None if registry_path is None else os.fspath(registry_path)
        self.witness_path = None if registry_dir is None else os.fspath(Path(registry_dir) / PROJECTION_FILE)
        mirror = (None if registry_dir is None else
                  _witness_mirror_path(registry_dir, Path(self.marker_path).parent))
        self.mirror_path = None if mirror is None else os.fspath(mirror)
        self.token_path = os.fspath(Path(self.marker_path).parent / TOKEN_FILE)
        self._key: tuple[int, int, int] | None = None
        self._evidence: tuple[Any, Any, Any, Any] | None = None
        self._view: RoleView = _ABSENT_VIEW
        self.parses = 0

    @classmethod
    def for_domain(cls, domain: str, roles_dir: Path | str = ROLES_DIR, *,
                   registry_path: Path | str | None = None,
                   registry_dir: Path | str | None = REGISTRY_DIR,
                   principal_digest: str | None = None) -> "DomainRole":
        return cls(role_path(roles_dir, domain), registry_path=registry_path, domain=domain,
                   registry_dir=registry_dir, principal_digest=principal_digest)

    @classmethod
    def for_ledger_root(cls, root: Path | str, roles_dir: Path | str = ROLES_DIR, *,
                        registry_path: Path | str | None = None,
                        registry_dir: Path | str | None = REGISTRY_DIR,
                        principal_digest: str | None = None) -> "DomainRole":
        """The reader for the domain that owns this ledger root. An unmapped root under a present
        marker is `domain_ledger_mismatch` (A6): only a registered root-to-domain mapping admits."""
        domain = domain_for_ledger_root(root)
        if domain is None:
            return cls(None, registry_path=registry_path, marker_path=Path(roles_dir) / MARKER_FILE,
                       registry_dir=registry_dir, principal_digest=principal_digest)
        return cls.for_domain(domain, roles_dir, registry_path=registry_path, registry_dir=registry_dir,
                              principal_digest=principal_digest)

    def _projection_broken(self) -> bool:
        """Validate every readable witness, allowing an inaccessible peer only when one is readable.
        Runs on misses, re-parses, and changed evidence; two absent witnesses retain legacy behavior."""
        readable = None
        inaccessible = False
        token_digest = None
        for path in (self.witness_path, self.mirror_path):
            if path is None:
                continue
            try:
                _witness_stat_key(path)
                data = er._read_bounded(Path(path), MAX_ROLE_BYTES)
            except FileNotFoundError:
                continue
            except PermissionError:
                inaccessible = True
                continue
            except (OSError, RegistryError):
                return True
            try:
                witness = _decode_witness(data, path)
            except RegistryError:
                return True
            if readable is not None and readable != data:
                return True
            readable = data
            token_digest = witness["token_digest"]
        if readable is None:
            return inaccessible
        token = _read_small(Path(self.token_path))
        return (not os.path.exists(self.marker_path) or token is None
                or _sha256(token) != token_digest)

    def _evidence_key(self) -> tuple[Any, Any, Any, Any] | None:
        """Witness, mirror, token and marker stats, taken before the check they guard. Inaccessible
        witnesses have a stable sentinel; `_projection_broken` decides whether a peer suffices.
        Token and marker errors still propagate so the caller answers unreadable."""
        if self.witness_path is None:
            return None  # registry_dir=None preserves the legacy reader, including token access.
        # Deliberately re-stat permission-denied registry paths so restored access is revalidated.
        return (_witness_stat_key(self.witness_path), _witness_stat_key(self.mirror_path),
                _stat_key(self.token_path), _stat_key(self.marker_path))

    def read(self) -> RoleView:
        if self.path is None:
            if os.path.exists(self.marker_path):
                return _MISMATCH_VIEW
            # Same rule as a mapped root reader: a registry, or an active projection, with no marker
            # fails closed.
            if ((self.registry_path is not None and os.path.exists(self.registry_path))
                    or self._projection_broken()):
                return _UNREADABLE_VIEW
            return _ABSENT_VIEW
        try:
            info = os.stat(self.path)
        except FileNotFoundError:
            self._key = None
            marker = os.path.exists(self.marker_path)
            if self.registry_path is not None and not marker and os.path.exists(self.registry_path):
                return _UNREADABLE_VIEW
            if self._projection_broken():
                return _UNREADABLE_VIEW
            return _UNREGISTERED_VIEW if marker else _ABSENT_VIEW
        except OSError:
            self._key = None
            return _UNREADABLE_VIEW
        if (self.registry_path is not None and not os.path.exists(self.marker_path)
                and os.path.exists(self.registry_path)):
            return _UNREADABLE_VIEW
        key = (info.st_mtime_ns, info.st_ino, info.st_size)
        try:
            evidence = self._evidence_key()
        except OSError:
            self._key = None
            return _UNREADABLE_VIEW
        if key == self._key and evidence == self._evidence:
            return self._view
        if self._projection_broken():
            self._key = None
            return _UNREADABLE_VIEW
        self.parses += 1
        try:
            data = er._read_bounded(Path(self.path), MAX_ROLE_BYTES)
        except (OSError, RegistryError):
            self._key = None
            return _UNREADABLE_VIEW
        view = _parse_role(data, self.domain)
        # Bound once per re-parse and the bound view is what is cached: a cached hit costs exactly
        # what it cost before X1b (no extra stat, no compare, no allocation).
        if (self.principal is not None and view.state == RECORD and view.expected_principal_digest is not None
                and view.expected_principal_digest != self.principal):
            view = _PRINCIPAL_MISMATCH_VIEW
        self._view = view
        self._key = key
        self._evidence = evidence
        return self._view
