"""Co-hosting rules for lane `engines`: probe identity, incumbent-first ordering, the conflict rule.

Contract (Wave A, plan D0): every function here is pure and deterministic apart from the random
tail of `probe_client_id`; nothing does I/O, and nothing imports leafhft.cli, leafhft.broker or a
Wave A sibling, so the book host (C5b, C7b) and the probe runner (C7a) can import it on the hot
path. Inputs are validated and anything malformed fails closed.

Identity: incumbent client ids stay `lh-<hex>`; a probe's are `lp-<code>-<20 hex>` with
`code = sha256(engine_id)[:4]`. Probes never use retry ids, because `lb-r1-` would break the
partition.
"""
from __future__ import annotations

import hashlib
import os
import re
from collections import OrderedDict
from dataclasses import dataclass
from decimal import Decimal
from functools import lru_cache
from typing import Sequence

DEFAULT_PROBES_PER_BOOK = 4  # Twin in leafhft/probe_bindings.py; both must change together.
MAX_PROBES_PER_BOOK = 40  # Twin in leafhft/probe_bindings.py; both must change together.

ENGINE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")  # always fullmatch: "$" admits a trailing newline
PROBE_PREFIX = "lp-"
INCUMBENT_PREFIX = "lh-"
ENGINES_LANE = "engines"
INCUMBENT_PARTITION = "incumbent"
PROBE_PARTITION_PREFIX = "probe:"
CODE_LEN = 4
PROBE_TAIL_BYTES = 10  # 20 hex characters of os.urandom
INTENT_STATES = frozenset({"pending", "sent", "filled", "unknown"})

_HEX = frozenset("0123456789abcdef")
# Offset of the '-' that closes "lp-<code>" in a probe client id.
_CODE_END = len(PROBE_PREFIX) + CODE_LEN

REFUSAL_CODES = ("engine_disagreement", "engine_position_exists", "ticker_owned", "ticker_pending",
                 "ticker_unknown", "incumbent_undecided", "probe_code_collision", "lifecycle",
                 "breaker_engine", "breaker_account", "registry_gate", "exposure_authority", "cash",
                 "floor", "exposure_ledger_busy")


def _is_code(code: object) -> bool:
    return (type(code) is str and len(code) == CODE_LEN
            and all(ch in _HEX for ch in code))


@lru_cache(maxsize=1024)
def engine_code(engine_id: str) -> str:
    """Return the 4-hex partition code sha256(engine_id)[:4]; pure, cached, ValueError on an id outside ENGINE_ID_RE."""
    if type(engine_id) is not str or ENGINE_ID_RE.fullmatch(engine_id) is None:
        raise ValueError(f"engine id outside ENGINE_ID_RE: {engine_id!r}"[:120])
    return hashlib.sha256(engine_id.encode("ascii")).hexdigest()[:CODE_LEN]


def probe_client_id(engine_id: str) -> str:
    """Return a fresh probe client id "lp-<code>-<20 hex>" from os.urandom; ValueError on a bad engine id."""
    return f"{PROBE_PREFIX}{engine_code(engine_id)}-{os.urandom(PROBE_TAIL_BYTES).hex()}"


def owns(code: str, client_id: str) -> bool:
    """True when client_id carries the strict prefix "lp-<code>-"; pure, no allocation, False on any malformed input."""
    return (_is_code(code) and type(client_id) is str and len(client_id) > _CODE_END + 1
            and client_id.startswith(PROBE_PREFIX) and client_id[_CODE_END] == "-"
            and client_id.startswith(code, len(PROBE_PREFIX)))


def incumbent_owns(client_id: str) -> bool:
    """True when client_id is an incumbent id (starts with "lh-"); pure, no allocation."""
    return type(client_id) is str and client_id.startswith(INCUMBENT_PREFIX)


def _cohosted(client_id: str, co_hosted_codes: frozenset[str]) -> bool:
    """True for an incumbent id or a probe id whose code is hosted in this process."""
    if client_id.startswith(INCUMBENT_PREFIX):
        return True
    return (client_id.startswith(PROBE_PREFIX) and len(client_id) > _CODE_END + 1
            and client_id[_CODE_END] == "-" and client_id[len(PROBE_PREFIX):_CODE_END] in co_hosted_codes)


def _require_int(name: str, value: object) -> None:
    if type(value) is not int:
        raise TypeError(f"{name} must be int")


def _require_text(name: str, value: object) -> None:
    if type(value) is not str or not value:
        raise ValueError(f"{name} must be a non-empty str")


def _require_count(value: object) -> None:
    if not isinstance(value, Decimal) or not value.is_finite() or value < 0:
        raise ValueError("count must be a finite non-negative Decimal")


@dataclass(frozen=True)
class Intent:
    """An open authority intent on a ticker. Validated at construction; fails closed on bad fields.

    `lane` is an addition to the frozen contract (trailing, defaulted to `engines`) because the
    conflict rule's "owner in another lane" needs it and a client id cannot say it: `lh-` ids are
    shared by several lanes. `engine_id` may be empty for a foreign owner the snapshot cannot name.
    """
    client_id: str
    engine_id: str
    ticker: str
    side_yes: bool
    close: bool
    count: Decimal
    state: str  # pending|sent|filled|unknown
    lane: str = ENGINES_LANE

    def __post_init__(self) -> None:
        _require_text("client_id", self.client_id)
        if type(self.engine_id) is not str:
            raise TypeError("engine_id must be str")
        _require_text("ticker", self.ticker)
        if type(self.side_yes) is not bool or type(self.close) is not bool:
            raise TypeError("side_yes and close must be bool")
        _require_count(self.count)
        if self.state not in INTENT_STATES:
            raise ValueError(f"intent state must be one of {sorted(INTENT_STATES)}")
        _require_text("lane", self.lane)


@dataclass(frozen=True)
class Proposal:
    """One engine's proposed order on a ticker. Validated at construction; fails closed on bad fields."""
    engine_id: str
    ticker: str
    side_yes: bool
    close: bool
    count: Decimal
    price_cents: int
    edge_cents: int
    decision_id: str
    at_ns: int

    def __post_init__(self) -> None:
        if type(self.engine_id) is not str or ENGINE_ID_RE.fullmatch(self.engine_id) is None:
            raise ValueError("proposal engine_id outside ENGINE_ID_RE")
        _require_text("ticker", self.ticker)
        if type(self.side_yes) is not bool or type(self.close) is not bool:
            raise TypeError("side_yes and close must be bool")
        _require_count(self.count)
        _require_int("price_cents", self.price_cents)
        _require_int("edge_cents", self.edge_cents)
        if type(self.decision_id) is not str:
            raise TypeError("decision_id must be str")
        _require_int("at_ns", self.at_ns)


def _check_partition(partition: str | None) -> None:
    if partition is None or partition == INCUMBENT_PARTITION:
        return
    if (type(partition) is str and partition.startswith(PROBE_PARTITION_PREFIX)
            and _is_code(partition[len(PROBE_PARTITION_PREFIX):])):
        return
    raise ValueError(f"partition must be None, 'incumbent' or 'probe:<4 hex>': {partition!r}"[:120])


def engines_conflict(owner_intents: Sequence[Intent], proposal: Proposal, *, partition: str | None,
                     incumbent_decided: bool, co_hosted_codes: frozenset[str]) -> str | None:
    """Return the D0 conflict refusal code for proposal against the ticker's owner intents, or None; pure, one pass, no allocation beyond the returned code.

    Order (wave-A contract): no owner and decided -> None; owner in another lane -> ticker_owned;
    a foreign-process pending/unknown owner -> ticker_pending / ticker_unknown (unknown wins);
    different side or close -> engine_disagreement; same engine_id -> engine_position_exists;
    all owners co-hosted (lh- or a code in co_hosted_codes) -> None (same-side add, caps decide);
    undecided -> incumbent_undecided; else ticker_owned. partition=None is the legacy guard:
    ticker_owned for ANY owner, None otherwise. The incumbent partition's own proposals pass
    incumbent_decided=True: the gate orders probes behind the incumbent, never the reverse.
    """
    _check_partition(partition)
    if type(incumbent_decided) is not bool:
        raise TypeError("incumbent_decided must be bool")
    if partition is None:
        return "ticker_owned" if owner_intents else None
    if not owner_intents:
        return None if incumbent_decided else "incumbent_undecided"
    other_lane = foreign_unknown = foreign_pending = disagree = same_engine = False
    all_cohosted = True
    side_yes, close, engine_id = proposal.side_yes, proposal.close, proposal.engine_id
    for intent in owner_intents:
        if intent.lane != ENGINES_LANE:
            other_lane = True
            continue
        hosted = _cohosted(intent.client_id, co_hosted_codes)
        if not hosted:
            all_cohosted = False
            if intent.state == "unknown":
                foreign_unknown = True
            elif intent.state == "pending":
                foreign_pending = True
        if intent.side_yes is not side_yes or intent.close is not close:
            disagree = True
        if intent.engine_id == engine_id:
            same_engine = True
    if other_lane:
        return "ticker_owned"
    if foreign_unknown:
        return "ticker_unknown"
    if foreign_pending:
        return "ticker_pending"
    if disagree:
        return "engine_disagreement"
    if same_engine:
        return "engine_position_exists"
    if all_cohosted:
        return None
    if not incumbent_decided:
        return "incumbent_undecided"
    return "ticker_owned"


class IncumbentDecided:
    """Per-book entry decisions and leans, keyed by (ticker, window_id).

    An undecided window admits a side matching the incumbent's lean for 3 s after it was recorded.
    Final decisions and elapsed window ends always take precedence over a lean.
    In first-come mode every window is final for admission; existing ownership rules decide conflicts.

    Bounded: entries untouched for `retain_ns` (default 1 h) are evicted oldest first, and at most
    `max_keys` are held. Lookups are O(1) dict reads; eviction is amortized O(1). An evicted or
    never-seen window reads as NOT final unless first-come mode is enabled.
    """

    RETAIN_NS = 3_600 * 1_000_000_000
    MAX_KEYS = 65_536
    LEAN_FRESH_NS = 3_000_000_000

    def __init__(self, *, retain_ns: int = RETAIN_NS, max_keys: int = MAX_KEYS,
                 first_come: bool = False) -> None:
        """Build a record; first_come bypasses waiting. TypeError for non-bool, ValueError for bad bounds."""
        if type(retain_ns) is not int or retain_ns <= 0 or type(max_keys) is not int or max_keys <= 0:
            raise ValueError("retain_ns and max_keys must be positive ints")
        if type(first_come) is not bool:
            raise TypeError("first_come must be bool")
        self.retain_ns = retain_ns
        self.max_keys = max_keys
        self.first_come = first_come
        # key -> [final, end_ns or None, stamp_ns, lean_side, lean_ns]; oldest touch first.
        self._windows: OrderedDict[tuple[str, str], list] = OrderedDict()
        self._now_ns = 0

    def __len__(self) -> int:
        """Number of (ticker, window) entries currently held."""
        return len(self._windows)

    def _touch(self, key: tuple[str, str], stamp_ns: int) -> list:
        entry = self._windows.get(key)
        if entry is None:
            entry = [False, None, stamp_ns, None, 0]
            self._windows[key] = entry
        else:
            entry[2] = max(entry[2], stamp_ns)
            self._windows.move_to_end(key)
        return entry

    def _evict(self) -> None:
        horizon = self._now_ns - self.retain_ns
        windows = self._windows
        while windows:
            key, entry = next(iter(windows.items()))
            if len(windows) <= self.max_keys and entry[2] >= horizon:
                break
            del windows[key]

    def record(self, ticker: str, window_id: str, final: bool, now_ns: int) -> None:
        """Record the incumbent's decision for (ticker, window); final is sticky; amortized O(1)."""
        _require_text("ticker", ticker)
        if type(window_id) is not str:
            raise TypeError("window_id must be str")
        if type(final) is not bool:
            raise TypeError("final must be bool")
        _require_int("now_ns", now_ns)
        self._now_ns = max(self._now_ns, now_ns)
        entry = self._touch((ticker, window_id), now_ns)
        if final:
            entry[0] = True
        self._evict()

    def record_lean(self, ticker: str, window_id: str, side_yes: bool, now_ns: int) -> None:
        """Record a bool side lean, fresh for 3 s; preserve final/end state; amortized O(1)."""
        _require_text("ticker", ticker)
        if type(window_id) is not str:
            raise TypeError("window_id must be str")
        if type(side_yes) is not bool:
            raise TypeError("side_yes must be bool")
        _require_int("now_ns", now_ns)
        self._now_ns = max(self._now_ns, now_ns)
        entry = self._touch((ticker, window_id), now_ns)
        entry[3] = side_yes
        entry[4] = now_ns
        self._evict()

    def set_window_end(self, ticker: str, window_id: str, end_ns: int) -> None:
        """Record when the incumbent's entry window for (ticker, window) closes; amortized O(1)."""
        _require_text("ticker", ticker)
        if type(window_id) is not str:
            raise TypeError("window_id must be str")
        _require_int("end_ns", end_ns)
        entry = self._touch((ticker, window_id), end_ns)
        entry[1] = end_ns
        self._evict()

    def is_final(self, ticker: str, window_id: str, now_ns: int, side_yes: bool | None = None) -> bool:
        """True for a final decision, elapsed end, or matching bool lean at most 3 s old.

        With no side, ignore leans. First-come mode returns True for any integer now_ns.
        Pure O(1) read; unknown windows otherwise return False.
        """
        if type(now_ns) is not int:
            return False
        if self.first_come:
            return True
        entry = self._windows.get((ticker, window_id))
        if entry is None:
            return False
        if entry[0]:
            return True
        end_ns = entry[1]
        if end_ns is not None and now_ns >= end_ns:
            return True
        return (type(side_yes) is bool and entry[3] is side_yes
                and 0 <= now_ns - entry[4] <= self.LEAN_FRESH_NS)


@dataclass
class Disturbance:
    """Probe-caused disturbance counters for one book (D10 executor.disturbance); telemetry."""
    incumbent_refusals_by_probe: int = 0
    lane_refusals_by_probe: int = 0
    revision_retries: int = 0
    stale_snapshot_refusals: int = 0


class CoHostRefused(ValueError):
    """A probe registration refusal; `code` is probe_code_collision or max_per_book."""

    def __init__(self, code: str, detail: str) -> None:
        super().__init__(f"{code}: {detail}")
        self.code = code


class CoHost:
    """One book's incumbent, probe codes and disturbance counters; default four probes, maximum 40."""

    def __init__(self, incumbent_engine_id: str | None = None, *,
                 max_per_book: int = DEFAULT_PROBES_PER_BOOK) -> None:
        """Build an empty co-host; ValueError on a bad incumbent id or a cap outside integer 1..40."""
        if incumbent_engine_id is not None:
            engine_code(incumbent_engine_id)
        if type(max_per_book) is not int or not 1 <= max_per_book <= MAX_PROBES_PER_BOOK:
            raise ValueError(f"max_per_book must be an integer 1..{MAX_PROBES_PER_BOOK}")
        self.incumbent_engine_id = incumbent_engine_id
        self.max_per_book = max_per_book
        self.codes: set[str] = set()
        self.co_hosted_codes: frozenset[str] = frozenset()
        self.disturbance = Disturbance()
        self._engine_by_code: dict[str, str] = {}

    def register_probe(self, engine_id: str) -> str:
        """Register a probe and return its code; CoHostRefused on a code collision or past max_per_book, ValueError on a bad id."""
        code = engine_code(engine_id)
        holder = self._engine_by_code.get(code)
        if holder is not None:
            raise CoHostRefused("probe_code_collision", f"{engine_id} and {holder} share code {code}")
        if len(self.codes) >= self.max_per_book:
            raise CoHostRefused("max_per_book", f"{len(self.codes)} probes already hosted")
        self._engine_by_code[code] = engine_id
        self.codes.add(code)
        self.co_hosted_codes = frozenset(self.codes)
        return code

    def engine_for(self, code: str) -> str | None:
        """Return the hosted probe engine_id for a code, or None; pure O(1)."""
        return self._engine_by_code.get(code)

    def disturbed(self) -> str | None:
        """Return incumbent_disturbed or lane_disturbed once a probe caused either refusal (D0 stop condition), else None."""
        if self.disturbance.incumbent_refusals_by_probe:
            return "incumbent_disturbed"
        if self.disturbance.lane_refusals_by_probe:
            return "lane_disturbed"
        return None

    def status(self) -> dict:
        """Return the D10 executor.disturbance block: the four counters, ints, never null."""
        d = self.disturbance
        return {"incumbent_refusals_by_probe": d.incumbent_refusals_by_probe,
                "lane_refusals_by_probe": d.lane_refusals_by_probe,
                "revision_retries": d.revision_retries,
                "stale_snapshot_refusals": d.stale_snapshot_refusals}
