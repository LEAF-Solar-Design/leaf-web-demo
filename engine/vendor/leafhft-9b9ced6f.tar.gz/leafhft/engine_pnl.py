"""Per-engine P&L rollups and the D10 engine push blocks (runner -> dashboard wire v1).

Contract (plan D10, slice C9; the consumer is ops-dashboard kashbot-engine-runtime.ts, pinned to
the D1 migration 20260923120000_kashbot_engine_runtime.sql):
  * `realized_by_engine(ledger_rows, utc_day)` splits exactly the rows that
    `broker.kalshi_book.prior_realized_today_cents` counts (settle/void/exit, an int pnl_cents, an
    int settled_ns or, for an exit, ts_ns inside the UTC day), so the per-engine sums equal that
    function over the same ledger. The dedupe rules are the ledger's; nothing here re-derives one.
  * `push_blocks(payload, runs_dir)` runs only behind LEAFHFT_PUSH_ENGINE_ROLLUPS=1 (push.py owns
    the flag check) and never raises: each block is built, schema checked and size capped on its
    own, and a block that fails is dropped with `drop_and_record(block, reason)` while every other
    block still ships.
  * Bounded: at most MAX_RUN_DIRS ticket ledgers of MAX_LEDGER_BYTES each, summarized once per
    file version (a stat-keyed cache of at most MAX_CACHE entries, persisted across the oneshot
    pushes in ROLLUP_CACHE_NAME beside the runs dir, at most MAX_CACHE_FILE_BYTES); cache misses
    parse at most MAX_PARSE_BYTES_PER_PUSH per push and defer the rest as a counted drop; at most
    MAX_LIFECYCLE_RECORDS lifecycle records (the newest by mtime); every new block <= MAX_BLOCK_BYTES; execution_events <=
    MAX_EXECUTION_EVENTS.
  * An unknown value is None, never 0. Tickets retain null engine ids with reason markers;
    rollups omit invalid or unresolved identities and count them in truncated.
"""
from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from decimal import Context, Decimal, DecimalException, InvalidOperation, localcontext
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
from typing import Any, Iterable, Mapping

import orjson

from . import ENGINE_CATALOG_CAPACITY
from .attribution import attribution_or_unknown
from .broker.kalshi_book import MAX_TICKET_LEDGER_BYTES

ENGINE_ROLLUPS_ENV = "LEAFHFT_PUSH_ENGINE_ROLLUPS"
ENGINE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")
UNKNOWN_ENGINE = "unknown"  # attribution_or_unknown's own sentinel engine id
DOMAIN = "kalshi"
ROLLUP_SCHEMA = "1"  # str token, as required by the dashboard's SCHEMA_RE
MAX_BLOCK_BYTES = 64 * 1024
MAX_ENGINES_BYTES = 256 * 1024  # mirrors push.MAX_ENGINES_BYTES for the augmented engines[] rows
MAX_LIFECYCLE_BYTES = 8192  # mirrors push._kalshi_book's lifecycle bound
MAX_EXECUTION_EVENTS = 200
MAX_EVENTS_PER_BOOK = 1024
# Today's and yesterday's kalshi run dirs. Measured on the runner 2026-09-28: 28 to 74 new run dirs
# a day (09-20..09-28), 52 live-kalshi dirs by 12:55Z, and the old cap of 64 dropped "31 excess run
# dirs" on 312 pushes that day. 256 covers two measured peak days (2 x 74) with ~70% headroom.
MAX_RUN_DIRS = 256
MAX_LEDGER_BYTES = MAX_TICKET_LEDGER_BYTES  # the ledger's own read bound, as prior_realized reads it
# Cache misses parse at most this many ledger bytes per push; the rest defer to later pushes as a
# counted drop. Sized to the old 64-dir cap at the full ledger bound, so a push main could read in
# full is never deferred (the byte identity of FU-ROLLUP-RUN-DIRS item 4), about 64 MiB.
MAX_PARSE_BYTES_PER_PUSH = 64 * (MAX_LEDGER_BYTES + 1)
ROLLUP_CACHE_NAME = "engine-rollup-cache.json"  # beside the runs dir: <runs_dir>/../<name>
ROLLUP_CACHE_SCHEMA = "leafhft.engine-rollup-cache.v1"
# The persisted summaries hold only fill rows reduced to the fields the rollup reads (~70 bytes a
# row); a larger file is ignored and rebuilt, and a write evicts least recently used entries to fit.
MAX_CACHE_FILE_BYTES = 64 * 1024 * 1024
MAX_STATUS_BYTES = 1024 * 1024
MAX_STATUS_AGE_S = 15 * 60
MAX_CONFIG_BYTES = 65536
MAX_JSON_DEPTH = 64
MAX_CACHE = 2 * MAX_RUN_DIRS  # ledger summaries: every run dir in the window, twice, so a day rollover never thrashes
# Exposure ledgers read per push; their existing bound stays independent of lifecycle capacity.
MAX_RECORDS = 256
# Read every lifecycle the catalog can hold. Over the bound the newest files by mtime survive
# (_recent_paths); downstream row and byte bounds remain independent of this source read bound.
MAX_LIFECYCLE_RECORDS = ENGINE_CATALOG_CAPACITY
# Fallback engine rows kept in the pushed engines block: the consumer mirror's engines bound
# (tests/test_push_engine_rollup.py, array(payload engines, 64)); raise only after the live consumer
# bound is confirmed. Rows over it go least recently written first (_trim_engine_rows).
MAX_ENGINE_ROWS = 64
MAX_BREAKER_ENGINES = 64  # the consumer's per-account loss_breakers.engines bound (kashbot-engine-runtime)
MAX_ROLLUP_ROWS = 64
MAX_STOP_REASONS = 16
MAX_CENTS = 100_000_000_000
MAX_COUNT = 1_000_000_000
MAX_SAFE_INTEGER = (1 << 53) - 1
MAX_INPUTS = 16
MAX_MARKETS = 64
MAX_COUNTERPARTS = 8
HISTORY_LIMIT = 32
IDENTITY_TTL_S = 5.0
EXECUTION_KINDS = frozenset({"proposal", "sized", "refused", "conflict", "superseded"})
PROBE_STATES = frozenset({"probe", "probe_sized"})
PROBE_CID_PREFIX = "lp-"
_REALIZED_KINDS = ("settle", "void", "exit")
_INT_MIN, _INT_MAX = -(1 << 63), (1 << 64) - 1  # orjson's integer range: prior_realized parses with orjson
_TEXT_MAX = 200
_IDENTITY_ENV = "LEAFHFT_DASHBOARD_ACCOUNT_IDENTITY_PATH"
_DEFAULT_IDENTITY = "/var/lib/leafhft/dashboard-account.json"
_ENGINES_DIR_ENV = "LEAFHFT_ENGINES_DIR"
_DEFAULT_ENGINES_DIR = "/etc/leafhft/engines"
_REGISTRY_ENV = "LEAFHFT_ENGINE_REGISTRY"  # the status push's mirror of cfg.engine_registry
_LANE_ACCOUNTS_PATH = "/var/lib/leafhft-projections/dashboard-accounts.json"
_LANE_ACCOUNTS_SCHEMA = "leafhft.lane-dashboard-accounts.v1"
# engine_registry X1c: the registry keys the owner account "owner" (a tenant by its lane id), and
# engine_ops writes that key into every lifecycle record. This push (push_kalshi_status) is the
# owner's, so only this key resolves to its dashboard identity. A tenant's key is its lane id (the
# form _registry_block resolves through the public lane map) and names another account; any
# other string belongs to no account the registry knows and keeps the unresolvable drop.
REGISTRY_OWNER_KEY = "owner"
_REGISTRY_TENANT_KEY = re.compile(r"[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}")
_ACK_NOTE_ENGINE = re.compile(r"^engine: ([a-z0-9][a-z0-9-]{0,31})\b")

RECENT_DROPS: deque = deque(maxlen=64)

# Input: incumbent and probe run ledgers, including each line's attribution.
# Input: exposure files, with independent day and position entries.
# Input: lifecycle records, including history, observations and breaker decisions.
# Input: run configs and run status/executor events.
# Input: dashboard/lane identities and registry projection/publication files.
# Input: owner payload engine rows and bindings (control_acks retain their existing path).
# All JSON units pass the same byte/depth bound before canonical verification.
# Validate each entry before accumulation; count rejects and preserve healthy siblings.


def drop_and_record(block: str, reason: str, *, reason_limit: int = _TEXT_MAX) -> None:
    """Log one line and keep the reason in RECENT_DROPS (last 64). Never raises."""
    name, why = str(block)[:96], str(reason)[:reason_limit]
    RECENT_DROPS.append({"block": name, "reason": why, "at": time.time()})
    print(f"push engine rollups: dropped {name}: {why}", flush=True)
    return None


def _record_file_drops(block: str, path: Path, reasons: Counter) -> None:
    if reasons:
        counts = ", ".join(f"{reason}: {count}" for reason, count in reasons.most_common(8))
        drop_and_record(block, f"{path.name}: {counts}", reason_limit=1024)


# ------------------------------------------------------------------------------ rollups

@dataclass
class DayRollup:
    realized_cents: int = 0
    settled: int = 0  # settle + void rows, as ProbeExecutor counts them
    won: int = 0
    lost: int = 0
    voided: int = 0
    exits: int = 0
    entries: int = 0
    contracts: Decimal = field(default_factory=Decimal)

    def add(self, other: "DayRollup") -> None:
        for name in ("realized_cents", "settled", "won", "lost", "voided", "exits", "entries", "contracts"):
            setattr(self, name, getattr(self, name) + getattr(other, name))

    def to_dict(self) -> dict[str, Any]:
        contracts = self.contracts
        return {"realized_cents": self.realized_cents, "settled": self.settled, "won": self.won,
                "lost": self.lost, "voided": self.voided, "exits": self.exits, "entries": self.entries,
                "contracts": int(contracts) if contracts == contracts.to_integral_value() else float(contracts)}


def _ledger_int(value) -> bool:
    return type(value) is int and _INT_MIN <= value <= _INT_MAX


def _contracts(value) -> Decimal | None:
    if type(value) not in (int, float):
        return None
    try:
        count = Decimal(str(value))
    except InvalidOperation:
        return None
    return count if count.is_finite() and count >= 0 else None


def _day_bounds(utc_day) -> tuple[int, int, str]:
    """Same arithmetic as prior_realized_today_cents, so a boundary row lands on the same side."""
    if isinstance(utc_day, datetime):
        utc_day = utc_day.astimezone(timezone.utc).date()
    elif isinstance(utc_day, str):
        utc_day = date.fromisoformat(utc_day)
    if not isinstance(utc_day, date):
        raise ValueError("utc_day: expected a date, datetime or YYYY-MM-DD")
    day_start = datetime(utc_day.year, utc_day.month, utc_day.day, tzinfo=timezone.utc)
    start_ns = int(day_start.timestamp() * 1_000_000_000)
    return start_ns, start_ns + 86_400_000_000_000, utc_day.isoformat()


def _ident(row) -> tuple[str, str | None]:
    """(engine key, account digest). A row without an attribution dict skips the digest check:
    attribution_or_unknown would return the unknown sentinel for it anyway."""
    value = row.get("attribution")
    if not isinstance(value, dict):
        return UNKNOWN_ENGINE, None
    attribution = attribution_or_unknown(value)
    if attribution.get("status") != "known":
        return UNKNOWN_ENGINE, None
    return attribution["engine_id"], attribution["account_digest"]


def engine_key(row) -> str:
    """The engine a ledger row belongs to: the verified attribution's engine_id, else 'unknown'."""
    return _ident(row)[0] if isinstance(row, dict) else UNKNOWN_ENGINE


def _rollup(rows, idents, start_ns, end_ns) -> dict[str, DayRollup]:
    out: dict[str, DayRollup] = {}
    for row, ident in zip(rows, idents):
        if ident is None:
            continue
        kind = row.get("kind")
        if kind in _REALIZED_KINDS:
            at = row.get("ts_ns") if kind == "exit" else row.get("settled_ns")
            pnl = row.get("pnl_cents")
            if not _ledger_int(at) or not _ledger_int(pnl):
                continue
            if start_ns is not None and not start_ns <= at < end_ns:
                continue
            rollup = out.setdefault(ident[0], DayRollup())
            rollup.realized_cents += pnl
            if kind == "exit":
                rollup.exits += 1
            else:
                rollup.settled += 1
                if kind == "void":
                    rollup.voided += 1
                elif pnl > 0:
                    rollup.won += 1
                else:
                    rollup.lost += 1
        elif kind == "buy":
            at, count = row.get("ts_ns"), _contracts(row.get("count"))
            if not _ledger_int(at) or count is None:
                continue
            if start_ns is not None and not start_ns <= at < end_ns:
                continue
            rollup = out.setdefault(ident[0], DayRollup())
            rollup.entries += 1
            rollup.contracts += count
    return out


def realized_by_engine(ledger_rows: Iterable[Any], utc_day) -> Mapping[str, DayRollup]:
    """Per-engine UTC-day rollup of parsed ledger rows. For every engine, realized_cents equals
    prior_realized_today_cents over that engine's rows of the same ledger (property-tested);
    rows that are not dicts, or fail the ledger's own type checks, count nowhere."""
    start_ns, end_ns, _ = _day_bounds(utc_day)
    rows = [row for row in ledger_rows if isinstance(row, dict)]
    return _rollup(rows, [_ident(row) for row in rows], start_ns, end_ns)


@dataclass
class _LedgerSummary:
    symbol: str
    day: dict[str, DayRollup]
    lifetime: dict[str, DayRollup]
    digests: dict[str, str]
    opened: dict[str, tuple[str, int]]  # client_id -> (engine key, buy cost cents)
    closed: set[str]
    rows: list[dict] = field(default_factory=list)
    dropped: int = 0
    idents: list[tuple[str, str | None]] = field(default_factory=list)
    drop_reasons: Counter = field(default_factory=Counter)
    drops_logged: bool = False


_LEDGER_CACHE: dict[str, tuple[tuple, _LedgerSummary]] = {}


class _LedgerRows(list):
    def __init__(self):
        super().__init__()
        self.dropped = 0
        self.idents = []
        self.drop_reasons = Counter()


def _wire_count(value, *, strings=False) -> Decimal:
    if type(value) not in ((int, float, str) if strings else (int, float)):
        raise ValueError("invalid count type")
    with localcontext(Context(prec=28, Emin=-28, Emax=18)):
        count = Decimal(str(value))
        if (not count.is_finite() or not 0 <= count <= MAX_COUNT
                or count != count.quantize(Decimal("0.01"))):
            raise ValueError("count outside bounds or grid")
        return count


def _valid_totals(rollup):
    return (_integer(rollup.realized_cents, -MAX_CENTS, MAX_CENTS)
            and all(_integer(getattr(rollup, name), 0, MAX_COUNT)
                    for name in ("settled", "won", "lost", "voided", "exits", "entries"))
            and rollup.contracts.is_finite() and 0 <= rollup.contracts <= MAX_COUNT)


def _read_rows(path: Path) -> _LedgerRows:
    with path.open("rb") as stream:
        data = stream.read(MAX_LEDGER_BYTES + 1)
    if len(data) > MAX_LEDGER_BYTES:
        raise ValueError("ticket ledger exceeds bound")
    rows = _LedgerRows()
    for line in data.split(b"\n"):
        if not line.strip():
            continue
        reason = "invalid ticket entry"
        try:
            row = _json_value(line, MAX_LEDGER_BYTES, decoder=orjson.loads)
            kind = row.get("kind")
            if not isinstance(kind, str):
                raise ValueError("invalid ticket kind")
            reason = "invalid ticket attribution"
            engine, digest = _ident(row)
            reason = "invalid ticket entry"
            if kind in _REALIZED_KINDS or kind in ("buy", "adopt"):
                if engine == UNKNOWN_ENGINE or not _token(engine, ENGINE_ID_RE):
                    raise ValueError("unresolved ticket engine")
                if digest is not None and not _token(digest):
                    raise ValueError("invalid ticket account digest")
                at = row.get("settled_ns") if kind in ("settle", "void") else row.get("ts_ns")
                if not _ledger_int(at):
                    raise ValueError("invalid ticket time")
                if kind in _REALIZED_KINDS and not _integer(row.get("pnl_cents"), -MAX_CENTS, MAX_CENTS):
                    raise ValueError("invalid ticket pnl")
                if kind == "buy":
                    _wire_count(row.get("count"))
                if kind in ("buy", "adopt") and not _integer(row.get("cost_cents", 0), 0, MAX_CENTS):
                    raise ValueError("invalid ticket cost")
            rows.append(row)
            rows.idents.append((engine, digest))
        except Exception as exc:
            rows.dropped += 1
            if isinstance(exc, ValueError) and reason == "invalid ticket entry":
                reason = str(exc)
            rows.drop_reasons[reason] += 1
    return rows


def _ledger_summary(rows, idents, dropped, drop_reasons, symbol: str, utc_day: str) -> _LedgerSummary:
    start_ns, end_ns, _ = _day_bounds(utc_day)
    summary = _LedgerSummary(symbol, _rollup(rows, idents, start_ns, end_ns),
                             _rollup(rows, idents, None, None), {}, {}, set(), rows,
                             dropped, idents, drop_reasons)
    for row, (engine, digest) in zip(rows, idents):
        if digest is not None:
            summary.digests.setdefault(engine, digest)
        cid, kind = row.get("client_id"), row.get("kind")
        if not isinstance(cid, str):
            continue
        if kind in ("settle", "void"):
            summary.closed.add(cid)
        elif kind in ("buy", "adopt") and cid not in summary.opened:
            cost = row.get("cost_cents")
            summary.opened[cid] = (engine, cost if type(cost) is int and 0 <= cost <= _INT_MAX else 0)
    return summary


_DEFERRED = object()  # _summarize's answer for a cache miss past the push's parse budget: unread


def _summarize(path: Path, symbol: str, utc_day: str, cache: "_RollupCache | None" = None):
    """Parsed once per (size, mtime, day): attribution digests are the expensive part. With a
    cache, a summary an earlier push persisted is reused only on an exact file key match, and a
    miss past the push's parse budget returns _DEFERRED without reading the ledger."""
    try:
        info = path.stat()
    except OSError:
        return None
    key = (info.st_size, info.st_mtime_ns, utc_day, symbol)
    name = str(path)
    hit = _LEDGER_CACHE.get(name)
    if hit is not None and hit[0] == key:
        _LEDGER_CACHE[name] = _LEDGER_CACHE.pop(name)  # most recently used last
        if cache is not None:
            cache.remember(name, info, hit[1])
        return hit[1]
    summary = cache.summary(name, info, symbol, utc_day) if cache is not None else None
    if summary is None:
        if cache is not None and not cache.admit(info.st_size):
            return _DEFERRED
        try:
            rows = _read_rows(path)
        except OSError:
            return None
        summary = _ledger_summary(rows, rows.idents, rows.dropped, rows.drop_reasons, symbol, utc_day)
        if cache is not None:
            cache.remember(name, info, summary)
    _LEDGER_CACHE.pop(name, None)
    while _LEDGER_CACHE and len(_LEDGER_CACHE) >= MAX_CACHE:
        _LEDGER_CACHE.pop(next(iter(_LEDGER_CACHE)))  # least recently used first, never clear-all
    _LEDGER_CACHE[name] = (key, summary)
    return summary


def _pack_rows(summary: _LedgerSummary) -> dict[str, list]:
    """The fill rows reduced to exactly the fields the rollup reads, engines and digests interned.
    Every value was type checked by _read_rows, so it round-trips through orjson unchanged."""
    engines: dict[str, int] = {}
    digests: dict[str, int] = {}
    packed = []
    for row, (engine, digest) in zip(summary.rows, summary.idents):
        kind = row.get("kind")
        if kind not in _REALIZED_KINDS and kind not in ("buy", "adopt"):
            continue  # _engine_rollups never reads a non-fill row
        cid = row.get("client_id")
        item = [engines.setdefault(engine, len(engines)),
                -1 if digest is None else digests.setdefault(digest, len(digests)),
                kind, cid if isinstance(cid, str) else None]
        if kind == "exit":
            item += [row["ts_ns"], row["pnl_cents"]]
        elif kind in _REALIZED_KINDS:
            item += [row["settled_ns"], row["pnl_cents"]]
        elif kind == "buy":
            item += [row["ts_ns"], row["count"], row.get("cost_cents", 0)]
        else:
            item.append(row.get("cost_cents", 0))
        packed.append(item)
    return {"engines": list(engines), "digests": list(digests), "rows": packed}


def _unpack_rows(entry: dict) -> tuple[list[dict], list[tuple[str, str | None]]]:
    """Inverse of _pack_rows. Fails closed (ValueError) on any shape _read_rows would not emit."""
    engines, digests, packed = entry.get("engines"), entry.get("digests"), entry.get("rows")
    if not isinstance(engines, list) or not isinstance(digests, list) or not isinstance(packed, list):
        raise ValueError("invalid cache entry shape")
    if any(not _token(engine, ENGINE_ID_RE) or engine == UNKNOWN_ENGINE for engine in engines):
        raise ValueError("invalid cache engine")
    if any(not _token(digest) for digest in digests):
        raise ValueError("invalid cache digest")
    rows, idents = [], []
    for item in packed:
        if not isinstance(item, list) or len(item) < 5:
            raise ValueError("invalid cache row")
        engine, digest, kind, cid = item[:4]
        if (type(engine) is not int or not 0 <= engine < len(engines)
                or type(digest) is not int or not -1 <= digest < len(digests)
                or (cid is not None and not isinstance(cid, str))):
            raise ValueError("invalid cache row")
        row: dict[str, Any] = {"kind": kind}
        if cid is not None:
            row["client_id"] = cid
        if kind in _REALIZED_KINDS and len(item) == 6:
            if not _ledger_int(item[4]) or not _integer(item[5], -MAX_CENTS, MAX_CENTS):
                raise ValueError("invalid cache row")
            row["ts_ns" if kind == "exit" else "settled_ns"] = item[4]
            row["pnl_cents"] = item[5]
        elif kind == "buy" and len(item) == 7:
            if not _ledger_int(item[4]) or not _integer(item[6], 0, MAX_CENTS):
                raise ValueError("invalid cache row")
            _wire_count(item[5])
            row.update(ts_ns=item[4], count=item[5], cost_cents=item[6])
        elif kind == "adopt" and len(item) == 5:
            if not _integer(item[4], 0, MAX_CENTS):
                raise ValueError("invalid cache row")
            row["cost_cents"] = item[4]
        else:
            raise ValueError("invalid cache row")
        rows.append(row)
        idents.append((engines[engine], digests[digest] if digest >= 0 else None))
    return rows, idents


def _fsync_directory(directory: Path) -> None:
    if os.name != "posix":
        return
    try:
        fd = os.open(directory, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass  # durability of the rename is best effort; the cache is rebuildable


class _RollupCache:
    """Ledger summaries persisted across the oneshot pushes (leafhft-push.timer runs one a minute,
    so the in-process _LEDGER_CACHE is empty on every push). Never raises. A missing file is a
    cold start; an unreadable, corrupt, oversized or wrong-version file is ignored, counted once
    through drop_and_record and rebuilt. An entry is used only when (path, st_ino, st_size,
    st_mtime_ns) matches exactly. Writes are atomic (temp file, fsync, replace) and evict least
    recently used entries past MAX_CACHE or MAX_CACHE_FILE_BYTES, never clear-all."""

    def __init__(self, path: Path | None):
        self.path = path
        self.entries: dict[str, dict] = {}
        self.tick = 1  # this push's LRU stamp: one more than the file's
        self.dirty = False
        self.invalid = 0
        self.parsed = 0  # ledger bytes this push's misses were charged
        self.deferring = False

    @classmethod
    def load(cls, runs_dir) -> "_RollupCache":
        try:
            cache = cls(Path(runs_dir).parent / ROLLUP_CACHE_NAME)
        except Exception as exc:
            drop_and_record("engine_rollups.cache", f"cache path unavailable ({type(exc).__name__})")
            return cls(None)
        try:
            with open(cache.path, "rb") as stream:
                data = stream.read(MAX_CACHE_FILE_BYTES + 1)
        except FileNotFoundError:
            return cache
        except Exception as exc:
            cache._ignore(f"unreadable, {type(exc).__name__}")
            return cache
        try:
            if len(data) > MAX_CACHE_FILE_BYTES:
                raise ValueError("oversized")
            head, newline, body = data.partition(b"\n")
            if not newline:
                raise ValueError("truncated")
            header = orjson.loads(head)
            if not isinstance(header, dict):
                raise ValueError("invalid header")
            if header.get("schema") != ROLLUP_CACHE_SCHEMA:
                raise ValueError("wrong version")
            if header.get("sha256") != hashlib.sha256(body).hexdigest():
                raise ValueError("checksum mismatch")
            tick = header.get("tick")
            if not _integer(tick, 0, MAX_SAFE_INTEGER - 1):
                raise ValueError("invalid tick")
            entries = orjson.loads(body)
            if not isinstance(entries, list) or len(entries) > MAX_CACHE:
                raise ValueError("invalid entries")
            loaded: dict[str, dict] = {}
            for entry in entries:
                if (not isinstance(entry, dict) or not isinstance(entry.get("path"), str)
                        or entry["path"] in loaded
                        or not all(_ledger_int(entry.get(name)) for name in ("ino", "size", "mtime_ns"))
                        or not _integer(entry.get("used"), 0, tick)):
                    raise ValueError("invalid entry key")
                loaded[entry["path"]] = entry
        except orjson.JSONDecodeError:
            cache._ignore("corrupt")
            return cache
        except Exception as exc:
            cache._ignore(str(exc)[:64] if isinstance(exc, ValueError) else type(exc).__name__)
            return cache
        cache.entries, cache.tick = loaded, tick + 1
        return cache

    def _ignore(self, reason: str) -> None:
        drop_and_record("engine_rollups.cache", f"cache ignored ({reason}); rebuilding")
        self.entries = {}
        self.dirty = True

    @staticmethod
    def _matches(entry, info) -> bool:
        return (entry["ino"], entry["size"], entry["mtime_ns"]) == (info.st_ino, info.st_size, info.st_mtime_ns)

    def admit(self, size: int) -> bool:
        """Charge one miss to this push's parse budget. Once one miss defers, every later miss
        defers too, so the newest dirs are the ones read and the rest wait for later pushes."""
        cost = min(max(size, 0), MAX_LEDGER_BYTES + 1)  # _read_rows never reads past this
        if self.deferring or self.parsed + cost > MAX_PARSE_BYTES_PER_PUSH:
            self.deferring = True
            return False
        self.parsed += cost
        return True

    def summary(self, name: str, info, symbol: str, utc_day: str) -> _LedgerSummary | None:
        entry = self.entries.get(name)
        if entry is None or not self._matches(entry, info):
            return None
        try:
            rows, idents = _unpack_rows(entry)
            dropped, reasons = entry.get("dropped"), entry.get("reasons")
            if not _integer(dropped, 0, MAX_COUNT) or not isinstance(reasons, list):
                raise ValueError("invalid cache drop counts")
            drop_reasons = Counter()
            for item in reasons:
                if (not isinstance(item, list) or len(item) != 2 or not isinstance(item[0], str)
                        or not _integer(item[1], 1, MAX_COUNT) or item[0] in drop_reasons):
                    raise ValueError("invalid cache drop reason")
                drop_reasons[item[0]] = item[1]
            summary = _ledger_summary(rows, idents, dropped, drop_reasons, symbol, utc_day)
        except Exception:
            del self.entries[name]
            self.invalid += 1
            self.dirty = True
            return None
        entry["used"] = self.tick
        return summary

    def remember(self, name: str, info, summary: _LedgerSummary) -> None:
        entry = self.entries.get(name)
        if entry is not None and self._matches(entry, info):
            entry["used"] = self.tick
            return
        self.entries.pop(name, None)
        try:
            packed = _pack_rows(summary)
            reasons = [[reason, count] for reason, count in summary.drop_reasons.items()]
        except Exception:
            return  # an unpackable summary stays a miss on the next push
        self.entries[name] = {"path": name, "ino": info.st_ino, "size": info.st_size,
                              "mtime_ns": info.st_mtime_ns, "used": self.tick,
                              "dropped": summary.dropped, "reasons": reasons, **packed}
        self.dirty = True

    def save(self) -> None:
        if self.invalid:
            drop_and_record("engine_rollups.cache", f"{self.invalid} invalid cache entries ignored; rebuilding")
            self.invalid = 0
        if not self.dirty or self.path is None:
            return
        temp = None
        try:
            # Least recently used first; sorted() is stable, so equal stamps keep file order.
            ordered = sorted(self.entries.values(), key=lambda entry: entry["used"])
            ordered = ordered[max(0, len(ordered) - MAX_CACHE):]
            blobs = []
            for entry in ordered:
                try:
                    blobs.append(orjson.dumps(entry))
                except TypeError:
                    continue  # e.g. an st_ino past 64 bits: that ledger stays a miss
            limit = MAX_CACHE_FILE_BYTES - 256  # the header line is under 256 bytes
            total, start = 2 + sum(len(blob) + 1 for blob in blobs), 0
            while start < len(blobs) and total > limit:
                total -= len(blobs[start]) + 1
                start += 1
            body = b"[" + b",".join(blobs[start:]) + b"]"
            header = orjson.dumps({"schema": ROLLUP_CACHE_SCHEMA, "sha256": hashlib.sha256(body).hexdigest(),
                                   "tick": self.tick, "entries": len(blobs) - start})
            fd, temp = tempfile.mkstemp(prefix=".engine-rollup-cache.", suffix=".tmp", dir=self.path.parent)
            with os.fdopen(fd, "wb") as stream:
                stream.write(header + b"\n" + body)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, self.path)
            temp = None
            self.dirty = False
            _fsync_directory(self.path.parent)
        except Exception as exc:
            drop_and_record("engine_rollups.cache", f"cache write failed ({type(exc).__name__})")
        finally:
            if temp is not None:
                try:
                    os.unlink(temp)
                except OSError:
                    pass


class _JSONDepthError(ValueError):
    pass


def _check_json_depth(value) -> None:
    """Walk decoded containers without recursion; scalar children cannot add depth."""
    if not isinstance(value, (dict, list)):
        return
    stack = [(value, 1)]
    while stack:
        container, depth = stack.pop()
        if depth > MAX_JSON_DEPTH:
            raise _JSONDepthError("document exceeds nesting bound")
        children = container.values() if isinstance(container, dict) else container
        for child in children:
            if isinstance(child, (dict, list)):
                stack.append((child, depth + 1))


def _json_value(data, limit: int, *, expected=dict, decoder=json.loads):
    """Bound one JSON unit and guard decoding before attribution verification runs."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    if len(data) > limit:
        raise ValueError("document exceeds bound")
    opens = data.count(b"[") + data.count(b"{")
    try:
        value = decoder(data.decode("utf-8-sig"))
    except (RecursionError, ValueError) as exc:
        raise ValueError("invalid JSON document") from exc
    if opens > MAX_JSON_DEPTH:
        _check_json_depth(value)
    if not isinstance(value, expected):
        raise ValueError("invalid JSON top-level type")
    return value


def _bounded_json(path: Path, limit: int):
    with path.open("rb") as stream:
        data = stream.read(limit + 1)
    return _json_value(data, limit)


class _RunList(list):
    dropped = 0


def _kalshi_runs(runs_dir: Path, now: datetime) -> list[tuple[Path, str]]:
    """Today's and yesterday's kalshi run dirs, newest first, as prior_realized scans them."""
    today = now.strftime("%Y%m%d")
    yesterday = (now - timedelta(days=1)).strftime("%Y%m%d")
    try:
        entries = [entry for entry in os.scandir(runs_dir)
                   if entry.name.startswith((today, yesterday)) and entry.is_dir()]
    except OSError:
        return []
    entries.sort(key=lambda entry: entry.name, reverse=True)
    runs = _RunList()
    for index, entry in enumerate(entries):
        if len(runs) >= MAX_RUN_DIRS:
            runs.dropped += len(entries) - index
            drop_and_record("engine_rollups.runs", f"{len(entries) - index} excess run dirs")
            break
        try:
            config = _bounded_json(Path(entry.path) / "config.json", MAX_CONFIG_BYTES)
        except FileNotFoundError:
            continue
        except (OSError, ValueError) as exc:
            runs.dropped += 1
            drop_and_record("engine_rollups.runs",
                            f"unreadable run config ({type(exc).__name__}, {entry.name[:64]})")
            continue
        if not isinstance(config, dict):
            runs.dropped += 1
            drop_and_record("engine_rollups.runs", "run config is not an object")
        elif config.get("venue") == "kalshi":
            if _token(config.get("symbol"), r"[A-Za-z0-9._:-]{1,96}"):
                runs.append((Path(entry.path), config["symbol"]))
            else:
                runs.dropped += 1
                drop_and_record("engine_rollups.runs", "invalid run symbol")
    return runs


def _probe_rollups(exposure_dir: Path | None, utc_day: str, dropped=None) -> dict[str, dict[str, Any]]:
    """Probe engines from their ExposureLedger documents: realized from the ledger's own day
    totals, counts from its entries (a pruned entry is older than yesterday)."""
    from .canary import ExposureLedger, LEDGER_MAX_BYTES, LIVE_STATES, TERMINAL_STATES

    out: dict[str, dict[str, Any]] = {}
    if exposure_dir is None or not exposure_dir.is_dir():
        return out
    recent, excess = _recent_paths(exposure_dir, MAX_RECORDS)
    if dropped is not None:
        dropped[0] += excess
    for path in sorted(recent):
        engine = path.stem
        file_dropped = 0
        reasons = Counter()
        try:
            if not ENGINE_ID_RE.fullmatch(engine):
                raise ValueError("invalid engine id")
            doc = _bounded_json(path, LEDGER_MAX_BYTES)
            # Reuse the ledger's header and entry-count checks. Validate actual entries
            # independently below, so one bad state does not discard healthy siblings.
            header = dict(doc)
            if isinstance(doc.get("entries"), dict):
                header["entries"] = dict.fromkeys(doc["entries"], {"state": "reserved"})
            ExposureLedger(exposure_dir, engine)._valid(header)
            day, lifetime = DayRollup(), DayRollup()
            positions = cost = 0
            accepted = 0
            with localcontext(Context(prec=28, Emin=-28, Emax=18)):
                for date_key, value in doc["days"].items():
                    try:
                        if not isinstance(value, dict) or date.fromisoformat(date_key).isoformat() != date_key:
                            raise ValueError("invalid exposure day shape")
                        realized = value.get("realized_cents", 0)
                        if (not _integer(realized, -MAX_CENTS, MAX_CENTS)
                                or not -MAX_CENTS <= lifetime.realized_cents + realized <= MAX_CENTS):
                            raise ValueError("realized cents outside consumer bounds")
                        lifetime.realized_cents += realized
                        if date_key == utc_day:
                            day.realized_cents = realized
                        accepted += 1
                    except (ValueError, TypeError):
                        file_dropped += 1
                        reasons["invalid exposure day"] += 1
                for entry in doc["entries"].values():
                    try:
                        if not isinstance(entry, dict):
                            raise ValueError("invalid exposure entry shape")
                        state = entry.get("state")
                        if not isinstance(state, str) or state not in LIVE_STATES | TERMINAL_STATES:
                            raise ValueError("invalid exposure state")
                        if state not in ("open", "closed"):
                            accepted += 1
                            continue
                        # Stage the entire entry, including its settlement counters. Nothing
                        # from a rejected entry can leak into either set of totals.
                        next_day = DayRollup(**vars(day))
                        next_lifetime = DayRollup(**vars(lifetime))
                        with localcontext(Context(prec=28, Emin=-28, Emax=18)):
                            count = _wire_count(entry.get("count"), strings=True)
                            reserved_day = entry.get("reserved_day")
                            if not isinstance(reserved_day, str) or date.fromisoformat(reserved_day).isoformat() != reserved_day:
                                raise ValueError("invalid exposure reservation day")
                            for rollup, matches in ((next_day, entry.get("reserved_day") == utc_day),
                                                    (next_lifetime, True)):
                                if matches:
                                    rollup.contracts += count
                                    rollup.entries += 1
                                    if rollup.contracts > MAX_COUNT or rollup.entries > MAX_COUNT:
                                        raise ValueError("accumulated count outside consumer bounds")
                            entry_cost = entry.get("cost_cents")
                            if state == "open" and (not _integer(entry_cost, 0, MAX_CENTS)
                                    or cost + entry_cost > MAX_CENTS or positions >= MAX_COUNT):
                                raise ValueError("open exposure outside consumer bounds")
                            if state == "closed":
                                realized = entry.get("realized_cents")
                                closed_day = entry.get("closed_day")
                                if (not isinstance(closed_day, str) or date.fromisoformat(closed_day).isoformat() != closed_day
                                        or entry.get("kind") not in ("settled", "voided", "exit")):
                                    raise ValueError("invalid exposure settlement")
                                if not _integer(realized, -MAX_CENTS, MAX_CENTS):
                                    raise ValueError("settlement outside consumer bounds")
                                for rollup, matches in ((next_day, entry.get("closed_day") == utc_day),
                                                        (next_lifetime, True)):
                                    if not matches:
                                        continue
                                    if entry.get("kind") == "exit":
                                        rollup.exits += 1
                                    else:
                                        rollup.settled += 1
                                        if entry.get("kind") == "voided":
                                            rollup.voided += 1
                                        elif realized > 0:
                                            rollup.won += 1
                                        else:
                                            rollup.lost += 1
                                    if any(getattr(rollup, name) > MAX_COUNT for name in
                                           ("exits", "settled", "voided", "won", "lost")):
                                        raise ValueError("settlement count outside consumer bounds")
                        day, lifetime = next_day, next_lifetime
                        accepted += 1
                        if state == "open":
                            positions += 1
                            cost += entry_cost
                    except Exception:
                        file_dropped += 1
                        reasons["invalid exposure entry"] += 1
            if accepted or not file_dropped:
                out[engine] = {"day": day, "lifetime": lifetime, "open": {"positions": positions, "cost_cents": cost}}
        except Exception as exc:
            # The ledger's validator is not a validator for every shape consumed above.
            # Keep the file boundary around parsing, validation and accumulation alike.
            file_dropped += 1
            reasons[f"invalid exposure ledger: {type(exc).__name__}"] += 1
        _record_file_drops(f"engine_rollups.probe.{engine}", path, reasons)
        if dropped is not None:
            dropped[0] += file_dropped
    return out


# ------------------------------------------------------------------------------ identity

_IDENTITY = [0.0, None, None]  # checked_at (monotonic), path, account id


def encode_account_id(value) -> str | None:
    """Mirror of the dashboard's encodeLeafhftAccountId: the dashboard issues the canonical id
    (runner_account.account_id) and the runner stores it verbatim, so encoding is validation."""
    from .engines import account_id

    try:
        value = account_id(value)
        parts = _json_value(value, 160, expected=list)
    except ValueError:
        return None
    if (not isinstance(parts, list) or len(parts) != 3
            or not isinstance(parts[0], str) or not re.fullmatch(r"[A-Za-z0-9._:-]{1,64}", parts[0])
            or not isinstance(parts[1], str) or not re.fullmatch(r"[a-z_]{1,32}", parts[1])
            or type(parts[2]) is not int or not 0 <= parts[2] <= 1_000_000
            or json.dumps(parts, separators=(",", ":")) != value):
        return None
    return value


def _owned_account(value, host=None):
    account = encode_account_id(value)
    return account if account is not None and (host is None or _json_value(account, 160, expected=list)[0] == host) else None


def _lifecycle_account(value) -> str | None:
    """A lifecycle record's account as the dashboard canonical id. A canonical id passes unchanged;
    the owner registry key resolves to this push's identity_account_id (None when that is absent,
    which keeps the unresolvable drop). Raises ValueError for a tenant's registry key; any other
    value belongs to no account and returns None (the unresolvable drop)."""
    account = encode_account_id(value)
    if account is not None or not isinstance(value, str):
        return account
    from .engine_registry import KEY_ID_RE

    if not KEY_ID_RE.fullmatch(value):
        return None
    if value == REGISTRY_OWNER_KEY:
        return identity_account_id()
    if _REGISTRY_TENANT_KEY.fullmatch(value):
        raise ValueError("lifecycle account belongs to another account")
    return None


def _dashboard_identity(path):
    from .engines import DashboardAccountIdentity

    return DashboardAccountIdentity(**_bounded_json(Path(path), 1024))


def identity_account_id(path=None) -> str | None:
    """The host's dashboard account id, re-read at most every IDENTITY_TTL_S; None when absent."""

    path = str(path or os.environ.get(_IDENTITY_ENV, _DEFAULT_IDENTITY))
    now = time.monotonic()
    if _IDENTITY[1] == path and 0 <= now - _IDENTITY[0] < IDENTITY_TTL_S:
        return _IDENTITY[2]
    try:
        value = encode_account_id(_dashboard_identity(path).account_id)
    except (OSError, ValueError, TypeError):
        value = None
    if value is None and Path(path).exists():
        drop_and_record("identity", "invalid dashboard identity")
    _IDENTITY[:] = [now, path, value]
    return value


def narrow_engine_id(value) -> tuple[str | None, str | None]:
    """(engine_id, reason marker): a failing id becomes null with a reason, never a drop."""
    if value is None:
        return None, "attribution_unknown"
    if isinstance(value, str) and ENGINE_ID_RE.fullmatch(value):
        return value, None
    return None, "engine_id_invalid"


def _text(value, limit=_TEXT_MAX) -> str | None:
    return value[:limit] if isinstance(value, str) else None


def _consumer_text(value, limit=_TEXT_MAX) -> str | None:
    if not isinstance(value, str):
        return None
    # JavaScript string bounds count UTF-16 units, not Python code points.
    units = 0
    for index, char in enumerate(value):
        units += 2 if ord(char) > 0xFFFF else 1
        if units > limit:
            return value[:index]
    return value


def _token(value, pattern=r"[A-Za-z0-9._:-]{1,128}") -> bool:
    return isinstance(value, str) and re.fullmatch(pattern, value) is not None


def _integer(value, low, high) -> bool:
    return type(value) is int and low <= value <= high


def _number(value, low, high) -> bool:
    return type(value) in (int, float) and low <= value <= high


# canary._record_probe_count stores a fractional probe rung as exactly this string form ("0.25").
_FRACTIONAL_CONTRACTS = re.compile(r"(?:0\.[0-9]{2}|1\.00)")


def _lifecycle_contracts(value) -> Decimal | None:
    """A lifecycle record's contracts as a Decimal: an int or float in [0, MAX_COUNT], or exactly the
    canonical fractional rung string canary writes. None for anything else ("0.2", "1.50", bool)."""
    if type(value) is str:
        return Decimal(value) if _FRACTIONAL_CONTRACTS.fullmatch(value) else None
    return Decimal(str(value)) if _number(value, 0, MAX_COUNT) else None


def _wire_contracts(value):
    """The payload form of valid lifecycle contracts, or None. An int or float passes through
    unchanged; a fractional rung string becomes a JSON number exactly as DayRollup.to_dict emits
    one ("0.25" -> 0.25, "1.00" -> 1), so the wire never carries a string."""
    count = _lifecycle_contracts(value)
    if count is None or type(value) is not str:
        return None if count is None else value
    return int(count) if count == count.to_integral_value() else float(count)


def _recent_paths(directory: Path, limit: int) -> tuple[list[Path], int]:
    """(at most `limit` *.json paths newest first, excess count). Priority is file mtime, newest
    first, with the filename as the tie-break, never the alphabetically first. One stat per file;
    a file that vanishes or cannot be stated ranks last."""
    ranked = []
    for path in directory.glob("*.json"):
        try:
            mtime_ns = path.stat().st_mtime_ns
        except OSError:
            mtime_ns = -1
        ranked.append((-mtime_ns, path.name, path))
    ranked.sort()
    return [path for _, _, path in ranked[:limit]], max(0, len(ranked) - limit)


def _parsed_time(value) -> datetime | None:
    if not isinstance(value, str):
        return None
    # fromisoformat accepts minute-only times and arbitrary fractional precision,
    # but also silently carries overflowing offset minutes/seconds. Reject those.
    offset = re.search(r"[+-]([0-9]{2})(?::?([0-9]{2}))?(?::?([0-9]{2}))?(?:[.,][0-9]+)?$", value[10:])
    if offset and (int(offset[1]) > 23 or any(int(part or 0) > 59 for part in offset.groups()[1:])):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except (OverflowError, ValueError):
        return None


def _iso(value, *, generated=False) -> str | None:
    parsed = _parsed_time(value)
    if parsed is None:
        return None
    # Preserve producer-generated bytes (including the run-less push golden).
    # Copied record fields always use JavaScript's UTC millisecond form.
    if generated and value.endswith("Z"):
        return value
    precision = "auto" if generated else "milliseconds"
    return parsed.isoformat(timespec=precision).replace("+00:00", "Z")


def _timestamp_ns(value) -> int | None:
    """Exact UTC ordering key; never round a source clock through datetime or float.

    Naive clocks are UTC, as in _iso. Fractions finer than a nanosecond must be
    zero beyond the ninth digit, otherwise the clock has no exact integer key.
    """
    if not isinstance(value, str):
        return None
    match = re.fullmatch(
        r"([0-9]{4})-([0-9]{2})-([0-9]{2})(?:[Tt ]([0-9]{2})"
        r"(?::?([0-9]{2}))?(?::?([0-9]{2}))?(?:[.,]([0-9]+))?"
        r"(?:Z|([+-])([0-9]{2})(?::?([0-9]{2}))?(?::?([0-9]{2}))?"
        r"(?:[.,]([0-9]+))?)?)?", value)
    if match is None:
        return None
    year, month, day, hour, minute, second, fraction, sign, oh, om, os_, of = match.groups()
    try:
        days = date(int(year), int(month), int(day)).toordinal() - date(1970, 1, 1).toordinal()
        hour, minute, second, oh, om, os_ = (int(part or 0) for part in (hour, minute, second, oh, om, os_))
        if hour > 23 or oh > 23 or any(part > 59 for part in (minute, second, om, os_)):
            return None
        if any(any(digit != "0" for digit in part[9:]) for part in (fraction or "", of or "")):
            return None
        nanos = int(((fraction or "") + "000000000")[:9])
        offset_nanos = int(((of or "") + "000000000")[:9])
        offset = ((oh * 3600 + om * 60 + os_) * 1_000_000_000 + offset_nanos)
        return ((days * 86400 + hour * 3600 + minute * 60 + second) * 1_000_000_000
                + nanos - (offset if sign == "+" else -offset if sign == "-" else 0))
    except ValueError:
        return None


def _epoch_iso(value, divisor=1, *, generated=False):
    try:
        parsed = datetime.fromtimestamp(value / divisor, timezone.utc)
        if generated:
            return parsed.isoformat(timespec="milliseconds" if parsed.microsecond else "seconds").replace("+00:00", "Z")
        return _iso(parsed.isoformat())
    except (OverflowError, OSError, ValueError):
        return None


def _valid_lifecycle(block):
    if not isinstance(block, dict) or not _fits(block, MAX_LIFECYCLE_BYTES):
        return False
    if not _token(block.get("state"), r"[a-z][a-z0-9_]{0,31}"):
        return False
    for name in ("entries_suspended_until", "probe_started_at", "expires_at", "halted_at"):
        if block.get(name) is not None and not _iso(block[name]):
            return False
    for name, pattern in (("approval_id", r"[A-Za-z0-9._:-]{1,128}"),
                          ("snapshot_digest", r"[A-Za-z0-9._:-]{1,128}"),
                          ("halted_from", r"[a-z][a-z0-9_]{0,31}")):
        if block.get(name) is not None and not _token(block[name], pattern):
            return False
    if block.get("entries_enabled") is not None and type(block["entries_enabled"]) is not bool:
        return False
    if block.get("contracts") is not None and _lifecycle_contracts(block["contracts"]) is None:
        return False
    if block.get("observations") is not None and not _integer(block["observations"], 0, MAX_SAFE_INTEGER):
        return False
    eligibility = block.get("eligibility")
    if eligibility is not None and (not isinstance(eligibility, dict)
            or (eligibility.get("expires_at") is not None and not _iso(eligibility["expires_at"]))):
        return False
    reasons = block.get("stop_reasons") if block.get("stop_reasons") is not None else []
    history = block.get("history") if block.get("history") is not None else []
    if not isinstance(reasons, list) or len(reasons) > MAX_STOP_REASONS:
        return False
    for reason in reasons:
        code = reason.get("code") if isinstance(reason, dict) else reason
        if not _token(code, r"[A-Za-z0-9._:-]{1,64}"):
            return False
        if isinstance(reason, dict) and reason.get("text") is not None:
            if (not isinstance(reason["text"], str)
                    or len(reason["text"].encode("utf-16-le", errors="surrogatepass")) // 2 > 512):
                return False
    return (isinstance(history, list) and len(history) <= HISTORY_LIMIT
            and all(isinstance(h, dict) and _fits(h, 1024)
                    and _token(h.get("state"), r"[a-z][a-z0-9_]{0,31}")
                    and _iso(h.get("at") if h.get("at") is not None else h.get("ts")) for h in history))


def _conform_lifecycle(value):
    if not isinstance(value, dict):
        return None
    block = dict(value)
    if _wire_contracts(block.get("contracts")) is not None:
        block["contracts"] = _wire_contracts(block["contracts"])  # a fractional rung ships as a number
    for name in ("entries_suspended_until", "probe_started_at", "expires_at", "halted_at"):
        stamp = block.get(name)
        if stamp is not None:
            normalized = (_epoch_iso(stamp) if name == "entries_suspended_until"
                          and type(stamp) is int and stamp >= 0 else _iso(stamp))
            if normalized is None:
                block.pop(name)
                drop_and_record(f"lifecycle.{name}", "invalid timestamp")
            else:
                block[name] = normalized
    if isinstance(block.get("eligibility"), dict):
        eligibility = dict(block["eligibility"])
        if eligibility.get("expires_at") is not None:
            eligibility["expires_at"] = _iso(eligibility["expires_at"])
            if eligibility["expires_at"] is None:
                eligibility.pop("expires_at")
                drop_and_record("lifecycle.eligibility.expires_at", "invalid timestamp")
        block["eligibility"] = eligibility
    if isinstance(block.get("observations"), dict):
        observations = block["observations"]
        count = sum(_token(k, r"[A-Za-z0-9._:-]{1,96}") and _integer(v, -MAX_CENTS, MAX_CENTS)
                    for k, v in observations.items())
        if count != len(observations):
            drop_and_record("lifecycle.observations", f"{len(observations) - count} invalid entries")
        block["observations"] = count
    if isinstance(block.get("stop_reasons"), list):
        reasons = block["stop_reasons"]
        if len(reasons) > MAX_STOP_REASONS:
            drop_and_record("lifecycle.stop_reasons", f"{len(reasons) - MAX_STOP_REASONS} excess reason(s)")
        block["stop_reasons"] = []
        for reason in reasons[:MAX_STOP_REASONS]:
            code = reason.get("code") if isinstance(reason, dict) else reason
            if (not _token(code, r"[A-Za-z0-9._:-]{1,64}") or (isinstance(reason, dict)
                    and reason.get("text") is not None and not isinstance(reason["text"], str))):
                drop_and_record("lifecycle.stop_reasons", "invalid reason")
                continue
            block["stop_reasons"].append(
                {**reason, "text": _consumer_text(reason["text"], 512)}
                if isinstance(reason, dict) and isinstance(reason.get("text"), str) else reason)
    if isinstance(block.get("history"), list):
        history = []
        if len(block["history"]) > HISTORY_LIMIT:
            drop_and_record("lifecycle.history", f"{len(block['history']) - HISTORY_LIMIT} excess entries")
        for entry in block["history"][-HISTORY_LIMIT:]:
            if not isinstance(entry, dict) or not _token(entry.get("state"), r"[a-z][a-z0-9_]{0,31}"):
                drop_and_record("lifecycle.history", "invalid history entry")
                continue
            entry = dict(entry)
            if "contracts" in entry:
                contracts = _wire_contracts(entry["contracts"])
                if contracts is None:
                    entry.pop("contracts")
                    drop_and_record("lifecycle.history.contracts", "invalid contract count")
                else:
                    entry["contracts"] = contracts
            for name in ("at", "ts"):
                if entry.get(name) is not None:
                    entry[name] = _iso(entry[name])
                    if entry[name] is None:
                        entry.pop(name)
                        drop_and_record(f"lifecycle.history.{name}", "invalid timestamp")
            if entry.get("at") is None and entry.get("ts") is None:
                if not any(entry.get(name) is not None for name in ("at", "ts")):
                    drop_and_record("lifecycle.history", "history entry without a timestamp")
                continue  # TS :494 requires a timestamp on each history entry.
            if not _fits(entry, 1024):
                drop_and_record("lifecycle.history", "oversize history entry")
                continue
            history.append(entry)
        block["history"] = history
    return block if _valid_lifecycle(block) else None


def ticket_fields(row: Mapping, attribution: Mapping) -> dict[str, Any]:
    """The D10 kalshi_tickets additions for one ledger row (behind the flag, push.py)."""
    known = attribution.get("status") == "known"
    engine_id, reason = narrow_engine_id(attribution.get("engine_id") if known else None)
    cid = row.get("client_id")
    return {"engine_id": engine_id, "engine_id_reason": reason,
            "decision_id": _text(attribution.get("decision_id")) if known else None,
            "policy_digest": _text(attribution.get("policy_digest")) if known else None,
            "account_id": identity_account_id(),
            "book_role": "probe" if isinstance(cid, str) and cid.startswith(PROBE_CID_PREFIX) else "incumbent"}


# ------------------------------------------------------------------------------ lifecycle

class _LifecycleRecords(dict):
    """The reader's {engine_id: (record, reason)} plus `recency`: the read engine ids newest first
    by file mtime, the priority every later bound trims by (least recently written first)."""

    recency: tuple[str, ...] = ()


def _lifecycle_records(directory: Path) -> dict[str, tuple[dict | None, str | None]]:
    """{engine_id: (record, None) | (None, reason)}; one bad record never hides the others. Over
    MAX_LIFECYCLE_RECORDS files the newest by mtime are read (a live engine's record is rewritten as it
    observes), in filename order so everything downstream iterates as before."""
    from .canary import CanaryStore, MAX_BYTES

    records = _LifecycleRecords()
    if not directory.is_dir():
        return records
    store = CanaryStore(directory)
    recent, excess = _recent_paths(directory, MAX_LIFECYCLE_RECORDS)
    if excess:
        drop_and_record("lifecycle", f"{excess} excess records over the cap of {MAX_LIFECYCLE_RECORDS} "
                                     f"(the newest {MAX_LIFECYCLE_RECORDS} by mtime were read)")
    records.recency = tuple(path.stem for path in recent)
    for path in sorted(recent):
        try:
            if not ENGINE_ID_RE.fullmatch(path.stem):
                raise ValueError("invalid lifecycle engine")
            _bounded_json(path, MAX_BYTES)
            record = store.get(path.stem)  # Retain CanaryStore's checksum and sizing checks.
            if not isinstance(record, dict):
                raise ValueError("lifecycle is not an object")
            records[path.stem] = (record, None)
        except Exception as exc:
            records[path.stem] = (None, f"lifecycle_unreadable: {type(exc).__name__}")
            drop_and_record(f"lifecycle.{path.stem}", "invalid lifecycle record")
    return records


def lifecycle_block(record: Mapping) -> tuple[dict | None, str | None]:
    """The D10 full lifecycle from a CanaryStore record, or (None, reason) on a schema failure."""
    from .canary import STATES

    if not isinstance(record, Mapping):
        return None, "lifecycle_not_object"
    if record.get("state") not in STATES:
        return None, "lifecycle_state_invalid"
    if type(record.get("entries_enabled")) is not bool:
        return None, "lifecycle_entries_enabled_invalid"
    until = record.get("entries_suspended_until")
    contracts = record.get("contracts")
    if contracts is not None:
        contracts = _wire_contracts(contracts)  # int/float unchanged; "0.25" -> 0.25
        if contracts is None:
            drop_and_record("lifecycle.contracts", "invalid contract count")
    stop_reasons, history = record.get("stop_reasons", []), record.get("history", [])
    if not isinstance(stop_reasons, list) or not isinstance(history, list):
        return None, "lifecycle_lists_invalid"
    observations = record.get("observations") or {}
    if not isinstance(observations, dict):
        return None, "lifecycle_observations_invalid"
    valid_observations = {k: v for k, v in observations.items()
                          if _token(k, r"[A-Za-z0-9._:-]{1,96}") and _integer(v, -MAX_CENTS, MAX_CENTS)}
    if len(valid_observations) != len(observations):
        drop_and_record("lifecycle.observations", f"{len(observations) - len(valid_observations)} invalid entries")
    observations = valid_observations
    texts = ("probe_started_at", "expires_at", "approval_id", "halted_from", "halted_at", "snapshot_digest")
    if any(record.get(name) is not None and not isinstance(record.get(name), str)
           for name in ("approval_id", "halted_from", "snapshot_digest")):
        return None, "lifecycle_text_invalid"
    eligibility = record.get("eligibility")
    expires = eligibility.get("expires_at") if isinstance(eligibility, dict) else None
    block = {"state": record["state"], "entries_enabled": record["entries_enabled"],
             "entries_suspended_until": until, "stop_reasons": stop_reasons[:MAX_STOP_REASONS],
             "contracts": contracts, "observations": len(observations),  # observed symbols, not their P&L sum
             "eligibility": {"expires_at": expires},
              "history": history,
              **{name: record.get(name) for name in texts}}
    # CanaryStore accepts human approval references (canary.py:168-171, 964),
    # but parseLifecycle's approval_id is an optional token (receiver :567).
    # Keep valid source evidence; do not invent a different approval identity.
    if block["approval_id"] is not None and not _token(block["approval_id"]):
        block["approval_id"] = None
        drop_and_record("lifecycle.approval_id", "source reference is not a wire token")
    conformed = _conform_lifecycle(block)
    if conformed is None:
        if not _fits(block, MAX_LIFECYCLE_BYTES):
            return None, "lifecycle_oversize"
        return None, "lifecycle_consumer_invalid"
    block = conformed
    try:
        size = len(json.dumps(block, allow_nan=False).encode("utf-8"))
    except (TypeError, ValueError):
        return None, "lifecycle_not_json"
    if size > MAX_LIFECYCLE_BYTES:
        return None, "lifecycle_oversize"
    if not _valid_lifecycle(block):
        return None, "lifecycle_consumer_invalid"
    if len(stop_reasons) > MAX_STOP_REASONS:
        drop_and_record("lifecycle.stop_reasons", f"{len(stop_reasons) - MAX_STOP_REASONS} excess reason(s)")
    return block, None


class _ValidatedLifecycleRecords(dict):
    """One shared source pass, including cached display and breaker projections."""

    def __init__(self):
        super().__init__()
        self.lifecycles = {}
        self.breakers = {}
        self.recency = ()  # the reader's newest-first engine ids; empty for a plain mapping


def _validated_lifecycle_records(records):
    if isinstance(records, _ValidatedLifecycleRecords):
        return records
    from .canary import STATES

    validated = _ValidatedLifecycleRecords()
    validated.recency = tuple(getattr(records, "recency", ()))
    for engine, (record, problem) in records.items():
        if record is None:
            validated[engine] = (None, problem)  # Preserve the source reader's diagnostic.
            continue
        site = f"lifecycle.{engine}"
        try:
            if not _token(engine, ENGINE_ID_RE) or not isinstance(record, dict):
                raise ValueError("invalid lifecycle record")
            if (not isinstance(record.get("state"), str) or record["state"] not in STATES
                    or type(record.get("entries_enabled")) is not bool):
                raise ValueError("invalid lifecycle state")
            approval = record.get("approval_id")
            if approval is not None and (not isinstance(approval, str)
                    or not approval.strip() or len(approval) > 200):
                raise ValueError("invalid approval_id")
            for name, pattern in (("snapshot_digest", r"[A-Za-z0-9._:-]{1,128}"),
                                  ("halted_from", r"[a-z][a-z0-9_]{0,31}")):
                if record.get(name) is not None and not _token(record[name], pattern):
                    raise ValueError(f"invalid {name}")
            stamp = record.get("last_observed_at")
            stamp_ns = _timestamp_ns(stamp) if stamp is not None else None
            if stamp is not None and (stamp_ns is None or _iso(stamp) is None):
                raise ValueError("invalid last_observed_at")
            # Display conformation may trim fields on an existing payload row, but
            # malformed source evidence must never contribute to any aggregate.
            if record.get("contracts") is not None and _lifecycle_contracts(record["contracts"]) is None:
                raise ValueError("invalid contracts")
            observations = record.get("observations")
            if observations is not None and (not isinstance(observations, dict) or any(
                    not _token(key, r"[A-Za-z0-9._:-]{1,96}") or not _integer(value, -MAX_CENTS, MAX_CENTS)
                    for key, value in observations.items())):
                raise ValueError("invalid observations")
            for name in ("entries_suspended_until", "probe_started_at", "expires_at", "halted_at"):
                value = record.get(name)
                if value is not None and not (
                        _epoch_iso(value) if name == "entries_suspended_until" and type(value) is int
                        and value >= 0 else _iso(value)):
                    raise ValueError(f"invalid {name}")
            eligibility = record.get("eligibility")
            if eligibility is not None and (not isinstance(eligibility, dict) or (
                    eligibility.get("expires_at") is not None and not _iso(eligibility["expires_at"]))):
                raise ValueError("invalid eligibility")
            reasons, history = record.get("stop_reasons", []), record.get("history", [])
            if not isinstance(reasons, list) or any(
                    not _token(reason.get("code") if isinstance(reason, dict) else reason, r"[A-Za-z0-9._:-]{1,64}")
                    or (isinstance(reason, dict) and reason.get("text") is not None
                        and not isinstance(reason["text"], str)) for reason in reasons):
                raise ValueError("invalid stop_reasons")
            if not isinstance(history, list) or any(
                    not isinstance(entry, dict) or not _token(entry.get("state"), r"[a-z][a-z0-9_]{0,31}")
                    or not _iso(entry.get("at") if entry.get("at") is not None else entry.get("ts"))
                    or not _fits(entry, 1024) for entry in history):
                raise ValueError("invalid history")
            account = _lifecycle_account(record.get("account_id"))
            if account is not None and account != record.get("account_id"):
                record = {**record, "account_id": account}  # a copy: the source record is never mutated
            breaker = record.get("breaker")
            projection = None
            if breaker is not None:
                site = "loss_breakers"
                if not isinstance(breaker, dict) or account is None:
                    raise ValueError("invalid breaker entry")
                # Source field, nullable, validator, writer line in canary.py.
                # Missing legacy metadata stays optional; explicit null follows
                # the writer, including every unknown-day limit and remaining room.
                cents = lambda value: _integer(value, 0, MAX_CENTS)
                pct = lambda value: _number(value, 0, 100)
                boolean = lambda value: type(value) is bool
                fields = (
                    ("utc_day", False, lambda value: isinstance(value, str)
                     and date.fromisoformat(value).isoformat() == value, 1480),
                    ("reason", True, _token, 1480),
                    ("day_start_marked_cents", True, cents, 1481),
                    ("day_start_portfolio_cents", True, cents, 1482),
                    ("day_start_reason", True, _token, 1483),
                    ("account_loss_basis", False, _token, 1484),
                    ("probe_gate_account_loss_basis", False, _token, 1484),
                    ("engine_pct", False, pct, 1485),
                    ("inherited", False, boolean, 1485),
                    ("engine_limit_cents", True, cents, 1486),
                    ("engine_loss_cents", False, cents, 1486),
                    ("engine_remaining_cents", True, cents, 1487),
                    ("engine_suspended", False, boolean, 1488),
                    ("account_pct", False, pct, 1489),
                    ("account_limit_cents", True, cents, 1490),
                    ("account_loss_cents", False, cents, 1491),
                    ("account_remaining_cents", True, cents, 1492),
                    ("account_suspended", False, boolean, 1493),
                )
                required = {"utc_day", "engine_loss_cents", "engine_suspended",
                            "account_loss_cents", "account_suspended"}
                for name, nullable, valid, writer_line in fields:
                    if name not in breaker and name not in required:
                        continue
                    value = breaker.get(name)
                    if not (nullable if value is None else valid(value)):
                        raise ValueError(f"invalid {name} (canary.py:{writer_line})")
                day = breaker["utc_day"]
                states = {}
                for role in ("account", "engine"):
                    state = {name: breaker.get(f"{role}_{name}")
                             for name in ("pct", "loss_cents", "limit_cents", "suspended")}
                    states[role] = state
                inherited, marked = breaker.get("inherited"), breaker.get("day_start_marked_cents")
                states["engine"]["inherited"] = inherited
                projection = {"utc_day": day, "account_id": account, "stamp_ns": stamp_ns,
                              "observed_at": _iso(stamp) if stamp is not None else None,
                              "day_start_portfolio_cents": marked, **states}
            elif record.get("account_id") is not None and account is None:
                raise ValueError("invalid lifecycle account")
            site = f"lifecycle.{engine}"
            lifecycle, reason = lifecycle_block(record)
            if lifecycle is None:
                raise ValueError(reason)
            validated[engine] = (record, None)
            validated.lifecycles[engine] = lifecycle
            if projection is not None:
                validated.breakers[engine] = projection
        except (TypeError, ValueError, OverflowError) as exc:
            drop_and_record(site, str(exc))
    return validated


# ------------------------------------------------------------------------------ blocks

def _fits(value, limit=None) -> bool:
    limit = MAX_BLOCK_BYTES if limit is None else limit
    try:
        return len(json.dumps(value, allow_nan=False).encode("utf-8")) <= limit
    except (TypeError, ValueError):
        return False


def _markets(bindings) -> dict[str, list[str]]:
    from .feeds.kalshi import SYMBOL_MAP

    out: dict[str, list[str]] = {}
    if not isinstance(bindings, dict):
        return out
    symbols = bindings.get("symbols") if isinstance(bindings.get("symbols"), dict) else {}
    disabled = set(bindings.get("disabled") or ()) if isinstance(bindings.get("disabled"), list) else set()
    default = bindings.get("default")
    for symbol in sorted(SYMBOL_MAP):
        engine = symbols.get(symbol, default)
        if symbol not in disabled and isinstance(engine, str):
            out.setdefault(engine, []).append(symbol)
    return out


def _conform_engine_row(row, host):
    if not isinstance(row, dict) or not _token(row.get("engine_id"), ENGINE_ID_RE):
        drop_and_record("engines", "invalid engine row")
        return None
    new = dict(row)
    engine = new["engine_id"]
    if new.get("lifecycle") is not None:
        lifecycle = _conform_lifecycle(new["lifecycle"])
        if lifecycle is None:
            new.pop("lifecycle", None)
            drop_and_record(f"engines.{engine}.lifecycle", "invalid fallback lifecycle")
        else:
            new["lifecycle"] = lifecycle
    if new.get("account_id") is not None and _owned_account(new["account_id"], host) is None:
        new.pop("account_id")
        drop_and_record(f"engines.{engine}.account_id", "invalid account")
    claim = new.get("claim")
    if claim is not None and (not isinstance(claim, dict)
            or _owned_account(claim.get("account_id"), host) is None
            or (claim.get("domain") is not None and not _token(claim["domain"]))
            or (claim.get("role") is not None and not _token(claim["role"], r"[a-z][a-z0-9_]{0,31}"))):
        new.pop("claim")
        drop_and_record(f"engines.{engine}.claim", "invalid claim")
    inputs, markets = new.get("inputs"), new.get("markets")
    if isinstance(inputs, list):
        valid = []
        for item in inputs:
            if (len(valid) < MAX_INPUTS and isinstance(item, dict) and set(item) == {"kind", "id"}
                    and item["kind"] in ("kalshi_book", "index", "feed", "derived")
                    and _token(item["id"], r"[A-Za-z0-9._:/-]{1,96}")):
                valid.append(item)
            else:
                drop_and_record(f"engines.{engine}.inputs", "invalid or excess input")
        inputs = new["inputs"] = valid
    if isinstance(markets, list):
        valid = []
        for item in markets:
            if len(valid) < MAX_MARKETS and _token(item, r"[A-Za-z0-9._:-]{1,96}") and item not in valid:
                valid.append(item)
            else:
                drop_and_record(f"engines.{engine}.markets", "invalid, duplicate or excess market")
        markets = new["markets"] = valid
    valid_inputs = (isinstance(inputs, list) and len(inputs) <= MAX_INPUTS
                    and all(isinstance(item, dict) and set(item) == {"kind", "id"}
                            and item["kind"] in ("kalshi_book", "index", "feed", "derived")
                            and _token(item["id"], r"[A-Za-z0-9._:/-]{1,96}") for item in inputs))
    valid_markets = (isinstance(markets, list) and len(markets) <= MAX_MARKETS
                     and all(_token(item, r"[A-Za-z0-9._:-]{1,96}") for item in markets)
                     and len(set(markets)) == len(markets))
    for name, valid in (("inputs", valid_inputs), ("markets", valid_markets),
                        ("revision", _token(new.get("revision")))):
        if new.get(name) is not None and not valid:
            new.pop(name)
            drop_and_record(f"engines.{engine}.{name}", "invalid runtime field")
    return new


def _trim_engine_rows(rows: list[dict], recency) -> list[dict]:
    """Bound conformed fallback rows to MAX_ENGINE_ROWS rows and MAX_ENGINES_BYTES. Rows go least
    recently written lifecycle first (recency: engine ids newest first; an engine without a record
    ranks last; ties drop the later payload row, the old pop order); survivors keep payload order.
    Each row is serialized once, so trimming is linear in the block, never a re-dump per pop."""
    rank = {engine: index for index, engine in enumerate(recency)}
    sizes = []
    for row in rows:
        try:
            sizes.append(len(json.dumps(row, allow_nan=False).encode("utf-8")))
        except (TypeError, ValueError):
            sizes.append(None)  # never fits; omitted before any serializable row
    order = sorted(range(len(rows)), reverse=True,
                   key=lambda index: (sizes[index] is None, rank.get(rows[index].get("engine_id"), len(rank)), index))
    omitted = set(order[:max(0, len(rows) - MAX_ENGINE_ROWS)])
    if omitted:
        drop_and_record("engines", f"{len(omitted)} excess row(s)")
    kept = [index for index in range(len(rows)) if index not in omitted]
    count, total = len(kept), sum(sizes[index] or 0 for index in kept)
    unserializable = sum(sizes[index] is None for index in kept)
    for index in order:
        # json.dumps(list): "[" + rows joined by ", " + "]".
        if not unserializable and (count == 0 or 2 + total + 2 * (count - 1) <= MAX_ENGINES_BYTES):
            break
        if index in omitted:
            continue
        omitted.add(index)
        count, total = count - 1, total - (sizes[index] or 0)
        unserializable -= sizes[index] is None
        drop_and_record("engines", "oversize fallback row omitted")
    trimmed = [row for index, row in enumerate(rows) if index not in omitted]
    while trimmed and not _fits(trimmed, MAX_ENGINES_BYTES):  # the exact check the arithmetic models
        trimmed.pop()
        drop_and_record("engines", "oversize fallback row omitted")
    return trimmed


def augment_engine_row(row, records, identity, host, markets_by_engine) -> dict:
    """Return one augmented engine row without mutating or trimming the input catalog."""
    from .engine_feeds import KALSHI_BOOK_KIND, kalshi_book_feed_id

    engine = row.get("engine_id") if isinstance(row, dict) else None
    if not isinstance(engine, str):
        return row
    new = dict(row)
    markets = markets_by_engine.get(engine, [])[:MAX_MARKETS]
    new["inputs"] = [{"kind": KALSHI_BOOK_KIND, "id": kalshi_book_feed_id(s)} for s in markets][:MAX_INPUTS]
    new["markets"] = markets
    record, problem = records.get(engine, (None, None))
    if problem is not None:
        drop_and_record(f"engines.{engine}.lifecycle", problem)
    state = None
    if record is not None:
        lifecycle = records.lifecycles[engine]
        existing = row.get("lifecycle") if isinstance(row.get("lifecycle"), dict) else {}
        new["lifecycle"] = {**existing, **lifecycle}
        for name in ("entries_suspended_until", "probe_started_at", "expires_at", "halted_at"):
            if name in record and name not in lifecycle:
                new["lifecycle"].pop(name, None)
        state = lifecycle["state"]
    if new.get("lifecycle") is not None and not _valid_lifecycle(new["lifecycle"]):
        new.pop("lifecycle", None)
        drop_and_record(f"engines.{engine}.lifecycle", "invalid fallback lifecycle")
    account = (_owned_account(record.get("account_id"), host) if record is not None else None) \
        or _owned_account((row.get("account") or {}).get("account_id")
                          if isinstance(row.get("account"), dict) else None, host) \
        or _owned_account(identity, host)
    role = "probe" if state in PROBE_STATES else "incumbent" if markets else None
    new.pop("account_id", None)
    new.pop("claim", None)
    if account is not None:
        new["account_id"] = account
        new["claim"] = {"account_id": account, "domain": DOMAIN, "role": role}
    return _conform_engine_row(new, host)


def load_augment_context(engines_dir=None, lifecycle_dir=None) -> tuple[dict, str | None]:
    """Load validated lifecycle records and owner identity; report failures without raising."""
    try:
        lifecycle = _augment_lifecycle_directory(engines_dir, lifecycle_dir)
        records = _validated_lifecycle_records(_lifecycle_records(lifecycle))
        return records, identity_account_id()
    except Exception as exc:
        drop_and_record("lifecycle", f"{type(exc).__name__}: {str(exc)[:160]}")
        return {}, None


def _augment_lifecycle_directory(engines_dir=None, lifecycle_dir=None):
    from .canary import LIFECYCLE_DIR_ENV, lifecycle_directory
    from .engine_ops import DEFAULT_LIFECYCLE_DIR

    engines_dir = Path(engines_dir or os.environ.get(_ENGINES_DIR_ENV, _DEFAULT_ENGINES_DIR))
    return Path(lifecycle_directory(
        engines_dir, lifecycle_dir or os.environ.get(LIFECYCLE_DIR_ENV) or DEFAULT_LIFECYCLE_DIR))


def _augment_engines(payload, records, identity) -> None:
    records = _validated_lifecycle_records(records)
    rows = payload.get("engines")
    if not isinstance(rows, list):
        return
    # Establish a conforming fallback before any augmentation can fail or exceed its cap.
    rows = [_conform_engine_row(row, payload.get("host")) for row in rows]
    rows = [row for row in rows if row is not None]
    rows = _trim_engine_rows(rows, records.recency)
    payload["engines"] = rows
    markets_by_engine = _markets(payload.get("engine_bindings"))
    augmented = [augment_engine_row(row, records, identity, payload.get("host"), markets_by_engine)
                 for row in rows]
    if not _fits(augmented, MAX_ENGINES_BYTES):
        drop_and_record("engines.augmentation", "oversize; rows pushed without the D10 fields")
        return
    payload["engines"] = augmented


def _loss_breakers(records, utc_day, observed_at=None) -> list[dict[str, Any]]:
    """The D5a block per account, from canary's breaker decision on each record (runner side), plus the
    host account's computed ACCOUNT observation when no decision covers it today (account_breaker_block)."""
    records = _validated_lifecycle_records(records)
    observed_at = _iso(observed_at if observed_at is not None else datetime.now(timezone.utc).isoformat(),
                       generated=True)
    if observed_at is None:
        drop_and_record("loss_breakers", "invalid observed_at")
        return []
    accounts: dict[str, dict[str, Any]] = {}
    keys: dict[str, tuple] = {}
    for engine, breaker in sorted(records.breakers.items()):
        if breaker["utc_day"] != utc_day:
            continue
        account, stamp = breaker["account_id"], breaker["stamp_ns"]
        # Exact ties (including two absent clocks) go to the lexically later engine id.
        # A real observation always wins over an absent clock, even before the epoch.
        key = keys[engine] = (stamp is not None, stamp if stamp is not None else 0, engine)
        block = accounts.setdefault(account, {"_key": None, "utc_day": utc_day, "account_id": account,
                                              "day_start_portfolio_cents": None, "account": None, "engines": {}})
        if block["_key"] is None or key > block["_key"]:
            block["_key"] = key
            block["observed_at"] = breaker["observed_at"] or observed_at
            block["day_start_portfolio_cents"] = breaker["day_start_portfolio_cents"]
            block["account"] = breaker["account"]
        block["engines"][engine] = breaker["engine"]
    computed = account_breaker_block(utc_day, observed_at, skip=accounts,
                                     registry_path=os.environ.get(_REGISTRY_ENV))
    if computed is not None:
        accounts[computed["account_id"]] = {"_key": None, **computed}
    out = []
    for account in sorted(accounts):
        block = accounts[account]
        block.pop("_key")
        if len(out) >= 32:
            drop_and_record("loss_breakers", "consumer row bound exceeded")
            continue
        engines = block["engines"]
        if len(engines) > MAX_BREAKER_ENGINES:
            # MAX_LIFECYCLE_RECORDS exceeds the consumer's per-account bound: keep the most recently
            # observed engines (the account-level fields above already saw every engine).
            newest = set(sorted(engines, key=keys.__getitem__, reverse=True)[:MAX_BREAKER_ENGINES])
            drop_and_record("loss_breakers", f"{len(engines) - MAX_BREAKER_ENGINES} engine(s) over the consumer "
                                             f"bound of {MAX_BREAKER_ENGINES}; the most recently observed kept")
            block["engines"] = {engine: value for engine, value in engines.items() if engine in newest}
        out.append(block)
    return out


_ACCOUNT_RISK_ROOT_ENV = "LEAFHFT_ACCOUNT_RISK_ROOT"  # the live client's ledger root (broker/kalshi_live.py)
_DEFAULT_ACCOUNT_RISK_ROOT = "/var/lib/leafhft/account-risk"


def account_breaker_entry(account_id, utc_day, observed_at, day_open_cents, equity_cents,
                          pct) -> dict[str, Any] | None:
    """Pure: one computed D5a ACCOUNT observation by breaker.py's rule (limit = pct * day_start // 100,
    suspended once the loss reaches it); None on any input outside the dashboard bounds, never a guess."""
    if (not isinstance(account_id, str) or not _integer(day_open_cents, 0, MAX_CENTS)
            or type(equity_cents) is not int or equity_cents < 0
            or (pct is not None and not _integer(pct, 0, 100))):
        return None
    loss = max(0, day_open_cents - equity_cents)  # the gate's net account loss; a gain is 0
    limit = pct * day_open_cents // 100 if pct is not None else None
    return {"utc_day": utc_day, "account_id": account_id, "day_start_portfolio_cents": day_open_cents,
            "account": {"pct": pct, "loss_cents": loss, "limit_cents": limit,
                        "suspended": limit is not None and loss >= limit},
            "engines": {}, "observed_at": observed_at}


def _account_breaker_pct(account_ids, registry_path, *, domain="legacy-owner") -> int | None:
    """Reads only: the registry's ACCOUNT pct the live gate uses (kalshi_live_runtime._loss_breakers), from
    the tenant breakers view or the owner's whole registry; None when unconfigured, unreadable or unknown."""
    # Contract: use the owner's whole registry when no path is supplied; never invent a pct.
    try:
        path = registry_path or os.environ.get(_REGISTRY_ENV)
        if not path:
            if domain != "legacy-owner":
                return None
            from .engine_ops import DEFAULT_REGISTRY_DIR

            # live-run.sh supplies cfg.engine_registry via --engine-registry projection.json
            # in this directory. The push has no book cfg; assignments.json is the same whole
            # registry without the projection's publication marker dependency.
            path = Path(DEFAULT_REGISTRY_DIR) / "assignments.json"
        from .engine_registry import (BREAKERS_VIEW_FILE, MAX_REGISTRY_BYTES, PROJECTION_SCHEMA,
                                      PROJECTION_SCHEMA_V2, Registry, RegistryProjection, strict_loads,
                                      validate_breakers_view, validate_projection)

        # Mirror kalshi_live_runtime.py:4739-4771. Its instance method is coupled to the
        # CLI import and host cache; a fresh read-only gate supplies the same refresh/digest check.
        projection = RegistryProjection(path)
        projection.exit_only(next(iter(account_ids), None))
        if projection.digest is None:
            return None
        with open(path, "rb") as stream:
            data = stream.read(MAX_REGISTRY_BYTES + 1)
        if len(data) > MAX_REGISTRY_BYTES:
            return None
        doc = strict_loads(data, MAX_REGISTRY_BYTES)
        if type(doc) is dict and doc.get("schema") in (PROJECTION_SCHEMA, PROJECTION_SCHEMA_V2):
            view = validate_projection(doc)
            with open(Path(path).with_name(BREAKERS_VIEW_FILE), "rb") as stream:
                breakers = validate_breakers_view(strict_loads(
                    stream.read(MAX_REGISTRY_BYTES + 1), MAX_REGISTRY_BYTES))
            if (view["digest"] != projection.digest
                    or breakers["generation"] != view["generation"]
                    or breakers["domain"] != view["domain"] or breakers["domain"] != domain
                    or breakers["account_id"] != view["account_id"]
                    or breakers.get("book_account_id") != view.get("book_account_id")
                    or set(breakers["engines"]) != set(view["assignments"])
                    or not any(aid in (view["account_id"], view.get("book_account_id")) for aid in account_ids)):
                return None
            pct = int(breakers["account_pct"])
        else:
            registry = Registry.from_bytes(data)
            pct = None
            for aid in account_ids:
                try:
                    pct = registry.effective_pct(aid)[0]
                    break
                except Exception:
                    continue
    except Exception:
        return None
    return pct if _integer(pct, 0, 100) else None


def _account_breaker_inputs(utc_day, identity=None, skip=(), registry_path=None, domain="legacy-owner"):
    """Reads only: (account_id, day_open_cents, equity_cents, pct) for the host account from the shared
    AccountRiskLedger file the live gate reads (kalshi_live_runtime._account_net_loss) and the registry
    pct. None when `skip` holds the account, or any ledger input is missing, unreadable or not today's."""
    try:
        from .attribution import account_digest
        from .broker.account_risk import _read_body_ro

        if identity is None:
            from .engines import load_dashboard_account_identity

            identity = load_dashboard_account_identity(os.environ.get(_IDENTITY_ENV, _DEFAULT_IDENTITY))
        account = encode_account_id(identity.account_id)
        if account is None or account in skip or identity.subaccount_number != 0:
            return None
        # VerifiedAccountRiskLedger.principal: the ledger file every book on this account shares.
        principal = json.dumps(["kalshi", identity.account_id, identity.subaccount_number],
                               separators=(",", ":"))
        path = Path(os.environ.get(_ACCOUNT_RISK_ROOT_ENV) or _DEFAULT_ACCOUNT_RISK_ROOT) \
            / (account_digest(principal) + ".sqlite3")
        if not path.is_file():
            return None
        body = _read_body_ro(path)
        state = json.loads(body) if isinstance(body, str) else None
        if (not isinstance(state, dict) or state.get("version") != 1 or state.get("account_id") != principal
                or state.get("day") != utc_day):
            return None
        day_open, equity = state.get("day_open_cents"), state.get("equity_cents")
        if type(day_open) is not int or type(equity) is not int:
            return None
    except Exception:
        return None
    # Contract: the gate's verified book id selects pct; the dashboard canonical id stays on the wire.
    # _kalshi_probe_account_id uses this identity.account_id, not a salted attribution digest or
    # the registry's "owner" key; Registry.effective_pct resolves its book_account_id alias.
    return account, day_open, equity, _account_breaker_pct([identity.account_id], registry_path, domain=domain)


def account_breaker_block(utc_day, observed_at, *, skip=(), identity=None, registry_path=None,
                          domain="legacy-owner") -> dict[str, Any] | None:
    """The host account's computed D5a ACCOUNT observation for utc_day, or None (nothing new) when `skip`
    already carries that account or any ledger input is missing. Reads only; never raises."""
    inputs = _account_breaker_inputs(utc_day, identity, skip, registry_path, domain)
    if inputs is None:
        return None
    return account_breaker_entry(inputs[0], utc_day, observed_at, *inputs[1:])


def _engine_rollups(runs, exposure_dir, records, identity, now, host=None, *, cache=None) -> dict[str, Any]:
    records = _validated_lifecycle_records(records)
    utc_day = now.date().isoformat()
    start_ns, end_ns, _ = _day_bounds(utc_day)
    incumbents: dict[str, dict[str, Any]] = {}
    opened: dict[str, tuple[str, int]] = {}
    closed: set[str] = set()
    file_dropped = getattr(runs, "dropped", 0)
    deferred = 0
    for path, symbol in runs:
        summary = None
        reasons = Counter()
        try:
            with localcontext(Context(prec=28, Emin=-28, Emax=18)):
                summary = _summarize(path / "kalshi-tickets.jsonl", symbol, utc_day, cache)
                if summary is _DEFERRED:
                    summary = None
                    deferred += 1
                    continue
                if summary is None:
                    if (path / "kalshi-tickets.jsonl").exists():
                        raise ValueError("ticket ledger unreadable")
                    continue
                reasons.update(summary.drop_reasons)
                if (not isinstance(summary.day, dict) or not isinstance(summary.lifetime, dict)
                        or not isinstance(summary.digests, dict) or not isinstance(summary.opened, dict)
                        or not isinstance(summary.closed, set)):
                    raise ValueError("invalid ledger summary shape")
                file_dropped += summary.dropped
                pending = dict(incumbents)
                pending_opened = dict(opened)
                pending_closed = set(closed)
                pending_exposure = {}
                for cid, (engine, cost) in pending_opened.items():
                    if cid not in pending_closed:
                        positions, total_cost = pending_exposure.get(engine, (0, 0))
                        pending_exposure[engine] = (positions + 1, total_cost + cost)
                for source, (engine, digest) in zip(summary.rows, summary.idents):
                    try:
                        kind, cid = source.get("kind"), source.get("client_id")
                        if kind not in _REALIZED_KINDS and kind not in ("buy", "adopt"):
                            continue  # Non-fill ticket events carry no rollup contribution.
                        previous = pending.get(engine)
                        entry = {"day": DayRollup(**vars(previous["day"])) if previous else DayRollup(),
                                 "lifetime": DayRollup(**vars(previous["lifetime"])) if previous else DayRollup(),
                                 "symbols": set(previous["symbols"]) if previous else set(),
                                 "digest": previous["digest"] if previous else None}
                        ident = [(engine, digest)]
                        entry["day"].add(_rollup([source], ident, start_ns, end_ns).get(engine, DayRollup()))
                        entry["lifetime"].add(_rollup([source], ident, None, None).get(engine, DayRollup()))
                        if not _valid_totals(entry["day"]) or not _valid_totals(entry["lifetime"]):
                            raise ValueError("accumulated ticket totals outside consumer bounds")
                        next_exposure = None
                        if (isinstance(cid, str) and kind in ("buy", "adopt")
                                and cid not in pending_opened and cid not in pending_closed):
                            positions, total_cost = pending_exposure.get(engine, (0, 0))
                            next_exposure = (positions + 1, total_cost + source.get("cost_cents", 0))
                            if next_exposure[0] > MAX_COUNT or next_exposure[1] > MAX_CENTS:
                                raise ValueError("accumulated open exposure outside consumer bounds")
                        entry["symbols"].add(summary.symbol)
                        entry["digest"] = entry["digest"] or digest
                        pending[engine] = entry
                        if isinstance(cid, str):
                            if kind in ("settle", "void"):
                                if cid in pending_opened and cid not in pending_closed:
                                    owner, cost = pending_opened[cid]
                                    positions, total_cost = pending_exposure[owner]
                                    pending_exposure[owner] = (positions - 1, total_cost - cost)
                                pending_closed.add(cid)
                            elif kind in ("buy", "adopt"):
                                pending_opened.setdefault(cid, (engine, source.get("cost_cents", 0)))
                                if next_exposure is not None:
                                    pending_exposure[engine] = next_exposure
                    except (ValueError, DecimalException):
                        file_dropped += 1
                        reasons["invalid accumulated ticket entry"] += 1
            # Commit only after every operation on this file has succeeded.
            incumbents.update(pending)
            opened, closed = pending_opened, pending_closed
        except Exception as exc:
            file_dropped += 1
            reasons[f"invalid ticket ledger: {type(exc).__name__}"] += 1
        if reasons and (summary is None or not summary.drops_logged):
            _record_file_drops("engine_rollups.incumbent", path / "kalshi-tickets.jsonl", reasons)
            if summary is not None:
                summary.drops_logged = True
    if deferred:
        # Incomplete exactly as an excess-dir drop is: counted in truncated, read on a later push.
        file_dropped += deferred
        drop_and_record("engine_rollups.runs", f"{deferred} run dirs deferred (parse budget)")
    open_by_engine: dict[str, list[int]] = {}
    for cid, value in opened.items():
        try:
            engine, cost = value
            if cid not in closed:
                totals = open_by_engine.get(engine, [0, 0])
                next_totals = [totals[0] + 1, totals[1] + cost]
                if next_totals[0] > MAX_COUNT or next_totals[1] > MAX_CENTS:
                    raise ValueError("accumulated open exposure outside consumer bounds")
                incumbents.setdefault(engine, {"day": DayRollup(), "lifetime": DayRollup(),
                                               "symbols": set(), "digest": None})
                open_by_engine[engine] = next_totals
        except Exception:
            file_dropped += 1
            drop_and_record("engine_rollups.incumbent", "invalid open exposure entry")

    def row(engine, role, day, lifetime, open_block, symbols, digest):
        engine_id, reason = narrow_engine_id(None if engine == UNKNOWN_ENGINE else engine)
        record = records.get(engine, (None, None))[0] if engine_id else None
        lifecycle = ({"state": record.get("state"), "entries_enabled": record.get("entries_enabled")}
                     if isinstance(record, dict) else None)
        account = (_owned_account(record.get("account_id"), host) if isinstance(record, dict) else None) \
            or _owned_account(identity, host)
        if engine_id is None or account is None:
            return None
        return {"engine_id": engine_id, "engine_id_reason": reason, "account_digest": digest,
                "role": role, "symbols": sorted(symbols)[:MAX_MARKETS], "day": day.to_dict(),
                "open": open_block, "lifetime": lifetime.to_dict(), "lifecycle": lifecycle,
                "claim": {"account_id": account, "domain": DOMAIN, "role": role}}

    rows = []
    for engine in sorted(incumbents):
        try:
            with localcontext(Context(prec=28, Emin=-28, Emax=18)):
                entry = incumbents[engine]
                positions, cost = open_by_engine.get(engine, [0, 0])
                rows.append(row(engine, "incumbent", entry["day"], entry["lifetime"],
                                {"positions": positions, "cost_cents": cost}, entry["symbols"], entry["digest"]))
        except Exception:
            rows.append(None)
            drop_and_record("engine_rollups.incumbent", "invalid rollup entry")
    probe_dropped = [0]
    for engine, entry in sorted(_probe_rollups(exposure_dir, utc_day, probe_dropped).items()):
        try:
            with localcontext(Context(prec=28, Emin=-28, Emax=18)):
                rows.append(row(engine, "probe", entry["day"], entry["lifetime"], entry["open"], (), None))
        except Exception:
            rows.append(None)
            drop_and_record(f"engine_rollups.probe.{engine}", "invalid rollup entry")
    kept, seen = [], set()
    for entry in rows:
        try:
            if entry is None or entry["engine_id"] in seen:
                continue
            day, opened = entry["day"], entry["open"]
            if (not isinstance(day, dict) or not isinstance(opened, dict)
                    or not isinstance(entry["symbols"], list)
                    or not _integer(day["realized_cents"], -MAX_CENTS, MAX_CENTS)
                    or any(not _integer(day[name], 0, MAX_COUNT)
                           for name in ("settled", "won", "lost", "voided", "exits", "entries"))
                    or not _number(day["contracts"], 0, MAX_COUNT)
                    or not _integer(opened["positions"], 0, MAX_COUNT)
                    or not _integer(opened["cost_cents"], 0, MAX_CENTS)
                    or not all(_token(s, r"[A-Za-z0-9._:-]{1,96}") for s in entry["symbols"])
                    or (entry["account_digest"] is not None and not _token(entry["account_digest"]))
                    or (entry["lifecycle"] is not None and not _fits(entry["lifecycle"], 2048))
                    or not _fits(entry["lifetime"], 1024) or not _fits(entry, 4096)):
                continue
            # The consumer keys by engine_id alone. Keep the incumbent when both ledgers exist;
            # summing them would mix distinct book roles and could double-count mirrored fills.
            seen.add(entry["engine_id"])
            kept.append(entry)
        except Exception:
            drop_and_record("engine_rollups.row", "invalid rollup entry")
    block = {"schema": ROLLUP_SCHEMA, "as_of": _iso(now.isoformat(), generated=True), "utc_day": utc_day,
             "lifetime_basis": "ledgers_since_yesterday_utc", "rows": kept[:MAX_ROLLUP_ROWS],
             "truncated": file_dropped + probe_dropped[0] + len(rows) - min(len(kept), MAX_ROLLUP_ROWS)}
    while block["rows"] and not _fits(block):
        block["rows"].pop()
        block["truncated"] += 1
    return block


def _execution_event(item, symbol) -> dict[str, Any] | None:
    if (not isinstance(item, dict) or not isinstance(item.get("kind"), str)
            or item["kind"] not in EXECUTION_KINDS):
        return None
    engine = item.get("engine_id")
    at_ms = item.get("at_ms")
    counterparts = item.get("counterpart_engine_ids", [])
    if (not isinstance(engine, str) or not ENGINE_ID_RE.fullmatch(engine)
            or type(at_ms) is not int or not 0 <= at_ms <= (1 << 53) - 1
            or not isinstance(counterparts, list) or len(counterparts) > MAX_COUNTERPARTS
            or any(not isinstance(c, str) or not ENGINE_ID_RE.fullmatch(c) for c in counterparts)):
        return None
    at = _epoch_iso(at_ms, 1000, generated=True)
    if at is None:
        return None
    return {"kind": item["kind"], "engine_id": engine, "counterpart_engine_ids": list(counterparts),
            "at_ms": at_ms, "at": at, "symbol": symbol, "ticker": _consumer_text(item.get("ticker"), 128),
            "reason": _consumer_text(item.get("reason"), 128)}


def _execution_events(runs, now_s) -> tuple[list[dict[str, Any]], int, int]:
    """Newest first across every fresh book status executor block. Returns (events, truncated,
    malformed)."""
    events, malformed, excess = [], 0, 0
    for path, symbol in runs:
        status_path = path / "kalshi-edge-status.json"
        try:
            if now_s - status_path.stat().st_mtime > MAX_STATUS_AGE_S:
                continue
            status = _bounded_json(status_path, MAX_STATUS_BYTES)
        except FileNotFoundError:
            continue
        except _JSONDepthError:
            malformed += 1
            _record_file_drops("execution_events", status_path, Counter({"document exceeds nesting bound": 1}))
            continue
        except (OSError, ValueError):
            malformed += 1
            _record_file_drops("execution_events", status_path, Counter({"unreadable status": 1}))
            continue
        if not isinstance(status, dict):
            malformed += 1
            _record_file_drops("execution_events", status_path, Counter({"invalid status shape": 1}))
            continue
        executor = status.get("executor")
        if executor is None:
            continue
        if not isinstance(executor, dict):
            malformed += 1
            _record_file_drops("execution_events", status_path, Counter({"invalid executor shape": 1}))
            continue
        items = executor.get("events")
        if items is None:
            continue
        if not isinstance(items, list):
            malformed += 1
            _record_file_drops("execution_events", status_path, Counter({"invalid events shape": 1}))
            continue
        excess += max(0, len(items) - MAX_EVENTS_PER_BOOK)
        file_malformed = 0
        for item in items[:MAX_EVENTS_PER_BOOK]:
            event = _execution_event(item, symbol)
            if event is None:
                malformed += 1
                file_malformed += 1
            else:
                events.append(event)
        if file_malformed:
            _record_file_drops("execution_events", status_path, Counter({"invalid event": file_malformed}))
    events.sort(key=lambda event: event["at_ms"], reverse=True)
    kept = events[:MAX_EXECUTION_EVENTS]
    truncated = excess + len(events) - len(kept)
    while kept and not _fits(kept):
        kept.pop()
        truncated += 1
    return kept, truncated, malformed


def _registry_account_id(value) -> str | None:
    """The registry consumer's parseLeafhftAccountId, stricter than legacy account ids."""
    return encode_account_id(value)


def _registry_block(projection) -> dict[str, Any] | None:
    owner_regime = os.environ.get("LEAFHFT_RISK_REGIME") == "owner"
    if projection is None:
        path = os.environ.get(_REGISTRY_ENV)
        if not path and not owner_regime:
            return None  # no registry configured: the block is absent, not empty
        try:
            if not path:
                from .engine_ops import DEFAULT_REGISTRY_DIR

                path = Path(DEFAULT_REGISTRY_DIR) / "projection.json"
            from .engine_registry import RegistryProjection
            projection = (RegistryProjection.load(path) if hasattr(RegistryProjection, "load")
                          else RegistryProjection(path))
        except Exception as exc:
            return drop_and_record("engine_registry", f"registry unavailable: {type(exc).__name__}")
    try:
        # Canonical registry verification still owns checksums, publication and floors.
        # Bound its file inputs first, including the publication marker when present.
        path = getattr(projection, "path", None)
        if path is not None and owner_regime and not Path(path).exists():
            return drop_and_record("engine_registry", "registry projection unavailable")
        if path is not None and Path(path).exists():
            from .engine_registry import MAX_REGISTRY_BYTES

            _bounded_json(Path(path), MAX_REGISTRY_BYTES)
        marker = getattr(projection, "_marker", None)
        if marker is not None and Path(marker).exists():
            from .engine_registry import MAX_PUBLICATION_BYTES

            _bounded_json(Path(marker), MAX_PUBLICATION_BYTES)
        block = projection.push_block()
    except Exception as exc:
        return drop_and_record("engine_registry", f"registry unavailable: {type(exc).__name__}")
    if block is None:
        if (getattr(projection, "path", None) is not None
                and (owner_regime or Path(projection.path).exists())):
            drop_and_record("engine_registry", "registry projection unavailable")
        return None
    if not isinstance(block, dict):
        return drop_and_record("engine_registry", "push_block is not an object")
    if (not _integer(block.get("generation"), 0, MAX_SAFE_INTEGER) or not _token(block.get("digest"))
            or (block.get("schema") is not None and not _token(block["schema"], r"[A-Za-z0-9._:/-]{1,64}"))
            or any(block.get(name) is not None and not isinstance(block[name], (dict, list))
                   for name in ("accounts", "loss_breakers", "exposure", "audit"))):
        return drop_and_record("engine_registry", "invalid registry header")
    source = block.get("assignments")
    if source is None:
        source = []
    if not isinstance(source, list):
        return drop_and_record("engine_registry", "assignments is not an array")
    owner = identity_account_id()
    owner_id = _registry_account_id(owner)
    identities = {}
    lane_accounts = None
    lane_accounts_read = False
    assignments = []
    missing = 0
    seen = set()
    for index, assignment in enumerate(source):
        if index >= 512:
            drop_and_record("engine_registry.assignments", f"{len(source) - index} excess assignments")
            break
        if (not isinstance(assignment, dict) or not _token(assignment.get("engine_id"), ENGINE_ID_RE)
                or assignment["engine_id"] in seen
                or not isinstance(assignment.get("account_id"), str)
                or (assignment.get("book_account_id") is not None and not isinstance(assignment["book_account_id"], str))
                or (assignment.get("domain") is not None and not _token(assignment["domain"]))
                or (assignment.get("role") is not None and not _token(assignment["role"], r"[a-z][a-z0-9_]{0,31}"))):
            drop_and_record("engine_registry.assignments", "invalid assignment")
            continue
        key, book = assignment.get("account_id"), assignment.get("book_account_id")
        lookup = (key, book)
        if lookup not in identities:
            account = None
            if key == "owner" or (owner is not None and book == owner):
                account = owner_id
            elif isinstance(key, str) and _REGISTRY_TENANT_KEY.fullmatch(key):
                if not lane_accounts_read:
                    lane_accounts_read = True
                    try:
                        lane_map = _bounded_json(Path(_LANE_ACCOUNTS_PATH), 64 * 1024)
                        if (not isinstance(lane_map, dict)
                                or lane_map.get("schema") != _LANE_ACCOUNTS_SCHEMA
                                or not isinstance(lane_map.get("lanes"), dict)):
                            raise ValueError("invalid lane account map")
                        lane_accounts = lane_map["lanes"]
                    except Exception:
                        drop_and_record("engine_registry", "lane account map unavailable")
                value = lane_accounts.get(key) if lane_accounts is not None else None
                if isinstance(value, str):
                    candidate = _registry_account_id(value)
                    if candidate is not None and json.loads(candidate)[0] == "kashbot-" + key:
                        account = candidate
            identities[lookup] = account
        account = identities[lookup]
        if account is None:
            missing += 1
            continue
        # Only the verified canonical identity goes on the wire, never a registry key or book id.
        row = {name: assignment[name] for name in ("engine_id", "role", "domain") if name in assignment}
        row["account_id"] = account
        assignments.append(row)
        seen.add(assignment["engine_id"])
    block = {**block, "assignments": assignments}
    if block.get("updated_at") is not None:
        block["updated_at"] = _iso(block["updated_at"])
        if block["updated_at"] is None:
            block.pop("updated_at")
            drop_and_record("engine_registry.updated_at", "invalid timestamp")
    if missing:
        drop_and_record("engine_registry", f"{missing} assignment(s) without a dashboard account id")
    if not _fits(block):
        return drop_and_record("engine_registry", "oversize")
    return block


def _ack_results(payload, records) -> None:
    records = _validated_lifecycle_records(records)
    acks = payload.get("control_acks")
    if not isinstance(acks, list) or not acks:
        return
    out = []
    for ack in acks:
        engine = ack.get("engine_id") if isinstance(ack, dict) else None
        if not (isinstance(engine, str) and ENGINE_ID_RE.fullmatch(engine)) and isinstance(ack, dict):
            match = _ACK_NOTE_ENGINE.match(ack.get("note") or "") if isinstance(ack.get("note"), str) else None
            engine = match.group(1) if match else None
        if not isinstance(engine, str) or not ENGINE_ID_RE.fullmatch(engine):
            out.append(ack)
            continue
        record = records.get(engine, (None, None))[0]
        result = dict(ack.get("result")) if isinstance(ack.get("result"), dict) else {}
        result.update(lifecycle_state=_text(record.get("state")) if isinstance(record, dict) else None,
                      snapshot_digest=_text(record.get("snapshot_digest")) if isinstance(record, dict) else None)
        out.append({**ack, "result": result})  # a copy: the persisted ack queue is never mutated
    payload["control_acks"] = out


def push_blocks(payload: dict[str, Any], runs_dir, *, engines_dir=None, lifecycle_dir=None,
                projection=None, now: datetime | None = None) -> dict[str, Any]:
    """Add the D10 blocks to a run-less status payload in place. Never raises; each block fails
    alone through drop_and_record. Returns the payload for convenience."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    utc_day = now.date().isoformat()
    try:
        lifecycle = _augment_lifecycle_directory(engines_dir, lifecycle_dir)
        records = _validated_lifecycle_records(_lifecycle_records(lifecycle))
    except Exception as exc:
        drop_and_record("lifecycle", f"{type(exc).__name__}: {str(exc)[:160]}")
        lifecycle, records = None, {}
    identity = identity_account_id()
    runs: list[tuple[Path, str]] = []
    try:
        runs = _kalshi_runs(Path(runs_dir), now)
    except Exception as exc:
        drop_and_record("runs", f"{type(exc).__name__}: {str(exc)[:160]}")

    def engines():
        _augment_engines(payload, records, identity)

    def registry():
        block = _registry_block(projection)
        if block is not None:
            payload["engine_registry"] = block

    def breakers():
        block = _loss_breakers(records, utc_day, now.isoformat().replace("+00:00", "Z"))
        if _fits(block):
            payload["loss_breakers"] = block
        else:
            drop_and_record("loss_breakers", "oversize")

    def rollups():
        exposure = lifecycle / "exposure" if lifecycle is not None else None
        cache = _RollupCache.load(runs_dir)
        try:
            payload["engine_rollups"] = _engine_rollups(runs, exposure, records, identity, now,
                                                        payload.get("host"), cache=cache)
        finally:
            cache.save()

    def events():
        kept, truncated, malformed = _execution_events(runs, now.timestamp())
        payload["execution_events"] = kept
        if truncated:
            payload["execution_events_truncated"] = truncated

    def acks():
        _ack_results(payload, records)

    for name, step in (("engines", engines), ("engine_registry", registry), ("loss_breakers", breakers),
                       ("engine_rollups", rollups), ("execution_events", events), ("control_acks", acks)):
        try:
            step()
        except Exception as exc:  # one block never blocks another, nor the status push
            if name not in ("engines", "control_acks"):  # those two keep their pre-flag rows
                payload.pop(name, None)
                if name == "execution_events":
                    payload.pop("execution_events_truncated", None)
            drop_and_record(name, f"{type(exc).__name__}: {str(exc)[:160]}")
    return payload
