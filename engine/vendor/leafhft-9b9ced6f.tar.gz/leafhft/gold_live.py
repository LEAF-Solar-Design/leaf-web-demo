"""Gold live admission, operator arming, and source-bound calibration inputs.

This core supplies the live strategy and runtime; it never submits an order.
The code pin and a short-lived operator document are independent of config.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal
import hashlib
import json
import math
import os
import re
import stat
import time

from leafhft import gold_artifacts
from leafhft.research import calibrated_sizing


GOLD_LIVE_ADMISSION = {"GOLD-15M": ("KXGOLD15M", "Metal.Index.1OZGOLD/USD")}
GOLD_LIVE_ENTRY_PIN = "enabled"
if GOLD_LIVE_ENTRY_PIN not in ("disabled", "enabled"):
    raise ValueError("invalid GOLD_LIVE_ENTRY_PIN")

ARM_SCHEMA = "leafhft.gold-entry-arm.v1"
EVIDENCE_SCHEMA = "leafhft.gold-live-evidence.v1"
MAX_ARM_BYTES = 4096
MAX_EVIDENCE_BYTES = 1024 * 1024
_ARM_KEYS = {
    "schema", "series", "symbol", "build_sha", "risk_regime", "issued_at_ms",
    "expires_at_ms", "max_ticket_cents", "evidence_sha256", "approval_id",
}
# v2 binds the arm to one Kashbot account lane at a fixed contract count.
ARM_SCHEMA_V2 = "leafhft.gold-entry-arm.v2"
_ACCOUNT_ARM_KEYS = {
    "schema", "series", "symbol", "build_sha", "risk_regime", "lane_id", "issued_at_ms",
    "expires_at_ms", "fixed_count", "approval_id",
}
_FIXED_COUNT = re.compile(r"(?:0|[1-9][0-9]*)(?:\.[0-9]{1,2})?")
_LANE_ID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}")
_EVIDENCE_KEYS = {
    "schema", "generated_at_ms", "source_sha256", "artifacts_sha256", "rules_hash",
    "model_version", "calibration", "last_mismatch_ms", "cells", "provenance",
}


class EvidenceRefused(ValueError):
    """A bounded reason suitable for reporting without echoing file contents."""

    def __init__(self, reason):
        self.reason = reason
        super().__init__(reason)


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise EvidenceRefused("duplicate_keys")
        result[key] = value
    return result


def _constant(_):
    raise EvidenceRefused("nonfinite_json")


def _hex(value, length):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{%d}" % length, value) is not None


def _lane_id(value):
    return isinstance(value, str) and _LANE_ID.fullmatch(value) is not None


def _integer(value, minimum=0):
    return type(value) is int and value >= minimum


def _signature(info):
    return info.st_ino, info.st_size, info.st_mtime_ns


def _root_owned(info):
    return os.name == "posix" and info.st_uid == 0


def _readonly_opener(path, flags):
    # Refuse a symlink swapped in after lstat; a swapped FIFO cannot block us.
    return os.open(path, flags | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))


def _arm_metadata_reason(info, owner_ok):
    """Arm file rules shared by v1 and v2: a root-owned, unwritable, bounded regular file."""
    if stat.S_ISLNK(info.st_mode):
        return "file_symlink"
    if not stat.S_ISREG(info.st_mode):
        return "file_not_regular"
    if not owner_ok(info):
        return "file_owner"
    if info.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
        return "file_writable"
    if info.st_size > MAX_ARM_BYTES:
        return "file_too_large"
    return None


class GoldEntrySwitch:
    """Cache file I/O for five seconds, but recheck time and build on every call.

    build_dirty describes the running build, not a claim in the arm document.
    stat_owner_ok receives an os.stat_result and defaults to POSIX root ownership.
    """

    def __init__(self, arm_path="/etc/leafhft/gold-entry-arm.json", *,
                 clock_ms=None, monotonic_s=None, build_sha=None, build_dirty=None,
                 risk_regime=None, stat_owner_ok=None):
        self.arm_path = arm_path
        self.clock_ms = clock_ms if clock_ms is not None else lambda: int(time.time() * 1000)
        self.monotonic_s = monotonic_s if monotonic_s is not None else time.monotonic
        self.build_sha = os.environ.get("LEAFHFT_BUILD_SHA", "") if build_sha is None else build_sha
        self.build_dirty = os.environ.get("LEAFHFT_BUILD_DIRTY", "") if build_dirty is None else build_dirty
        self.risk_regime = os.environ.get("LEAFHFT_RISK_REGIME", "") if risk_regime is None else risk_regime
        self.stat_owner_ok = _root_owned if stat_owner_ok is None else stat_owner_ok
        self.stats = {"lstat": 0, "reads": 0}
        self._last_stat = None
        self._signature = None
        self._parsed = None
        self._document = None
        self._file_reason = "file_missing"
        self._read_reason = "file_missing"

    @property
    def document(self):
        """The last armed document, copied so a caller cannot change the cache."""
        return deepcopy(self._document)

    def _metadata_reason(self, info):
        return _arm_metadata_reason(info, self.stat_owner_ok)

    def _refresh(self):
        self.stats["lstat"] += 1
        try:
            info = os.lstat(self.arm_path)
        except FileNotFoundError:
            self._signature = None
            self._parsed = None
            self._file_reason = "file_missing"
            return
        reason = self._metadata_reason(info)
        if reason:
            self._file_reason = reason
            return
        signature = _signature(info)
        if signature == self._signature:
            self._file_reason = self._read_reason
            return
        self._signature = signature
        self._parsed = None
        self._read_reason = self._file_reason = "file_io"
        self.stats["reads"] += 1
        with open(self.arm_path, "rb", opener=_readonly_opener) as stream:
            opened = os.fstat(stream.fileno())
            reason = self._metadata_reason(opened)
            if reason:
                self._read_reason = self._file_reason = reason
                return
            if opened.st_dev != info.st_dev or _signature(opened) != signature:
                self._read_reason = self._file_reason = "file_changed"
                return
            data = stream.read(MAX_ARM_BYTES + 1)
            if _signature(os.fstat(stream.fileno())) != signature:
                self._read_reason = self._file_reason = "file_changed"
                return
        if len(data) > MAX_ARM_BYTES:
            self._read_reason = self._file_reason = "file_too_large"
            return
        try:
            text = data.decode("utf-8")
        except UnicodeError:
            self._read_reason = self._file_reason = "file_utf8"
            return
        try:
            self._parsed = json.loads(text, object_pairs_hook=_pairs, parse_constant=_constant)
        except EvidenceRefused as exc:
            self._read_reason = self._file_reason = exc.reason
            return
        except (ValueError, RecursionError):
            self._read_reason = self._file_reason = "file_json"
            return
        self._read_reason = self._file_reason = None

    def _document_reason(self, doc, now):
        if not isinstance(doc, dict):
            return "document_type"
        if _ARM_KEYS - doc.keys():
            return "missing_keys"
        if doc.keys() - _ARM_KEYS:
            return "unknown_keys"
        if doc["schema"] != ARM_SCHEMA:
            return "schema"
        if doc["series"] != "KXGOLD15M":
            return "series"
        if doc["symbol"] != "GOLD-15M":
            return "symbol"
        if not _hex(doc["build_sha"], 40):
            return "build_sha_format"
        if doc["build_sha"] != self.build_sha:
            return "build_sha_mismatch"
        if self.build_dirty != "0":
            return "build_dirty"
        if doc["risk_regime"] != "owner":
            return "risk_regime"
        if doc["risk_regime"] != self.risk_regime:
            return "risk_regime_mismatch"
        issued, expires = doc["issued_at_ms"], doc["expires_at_ms"]
        if not _integer(issued) or not _integer(expires):
            return "timestamp_type"
        if now >= expires:
            return "expired"
        if expires <= issued:
            return "invalid_lifetime"
        if expires - issued > 86_400_000:
            return "lifetime_too_long"
        if issued > now + 60_000:
            return "issued_in_future"
        if not _integer(doc["max_ticket_cents"], 1) or doc["max_ticket_cents"] > 500:
            return "max_ticket_cents"
        if not _hex(doc["evidence_sha256"], 64):
            return "evidence_sha256"
        if not isinstance(doc["approval_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", doc["approval_id"]):
            return "approval_id"
        return None

    def armed(self):
        self._document = None
        if GOLD_LIVE_ENTRY_PIN != "enabled":
            return False, "code_pin_disabled"
        try:
            tick = self.monotonic_s()
            if not math.isfinite(tick):
                return False, "clock_error"
            if self._last_stat is None or tick - self._last_stat >= 5.0:
                self._last_stat = tick
                self._file_reason = "file_io"
                self._refresh()
            if self._file_reason:
                return False, self._file_reason
            now = self.clock_ms()
            if not _integer(now):
                return False, "clock_error"
            reason = self._document_reason(self._parsed, now)
            if reason:
                return False, reason
            self._document = self._parsed
            return True, "armed"
        except Exception:
            # File races, permission errors, and injected clock/owner failures fail closed.
            return False, "switch_error"


class GoldArmRefused(ValueError):
    """A lane-bound arm refusal; reason is a short machine string, never file contents."""

    def __init__(self, reason):
        self.reason = reason
        super().__init__(reason)


@dataclass(frozen=True)
class GoldAccountArm:
    series: str
    symbol: str
    build_sha: str
    lane_id: str
    issued_at_ms: int
    expires_at_ms: int
    fixed_count: Decimal
    approval_id: str
    sha256: str


def _read_account_arm_bytes(path):
    """One bounded read under the v1 file rules, rechecked on the open descriptor."""
    try:
        info = os.lstat(path)
    except FileNotFoundError:
        raise GoldArmRefused("file_missing") from None
    reason = _arm_metadata_reason(info, _root_owned)
    if reason:
        raise GoldArmRefused(reason)
    signature = _signature(info)
    with open(path, "rb", opener=_readonly_opener) as stream:
        opened = os.fstat(stream.fileno())
        reason = _arm_metadata_reason(opened, _root_owned)
        if reason:
            raise GoldArmRefused(reason)
        if opened.st_dev != info.st_dev or _signature(opened) != signature:
            raise GoldArmRefused("file_changed")
        data = stream.read(MAX_ARM_BYTES + 1)
        if _signature(os.fstat(stream.fileno())) != signature:
            raise GoldArmRefused("file_changed")
    if len(data) > MAX_ARM_BYTES:
        raise GoldArmRefused("file_too_large")
    return data


def _account_arm_reason(doc, lane_id, now):
    if not isinstance(doc, dict):
        return "document_type"
    if _ACCOUNT_ARM_KEYS - doc.keys():
        return "missing_keys"
    if doc.keys() - _ACCOUNT_ARM_KEYS:
        return "unknown_keys"
    if doc["schema"] != ARM_SCHEMA_V2:
        return "schema"
    if doc["series"] != "KXGOLD15M":
        return "series"
    if doc["symbol"] != "GOLD-15M":
        return "symbol"
    if not _hex(doc["build_sha"], 40):
        return "build_sha_format"
    if doc["risk_regime"] != "account":
        return "risk_regime"
    if not _lane_id(doc["lane_id"]):
        return "lane_id_format"
    if doc["lane_id"] != lane_id:
        return "lane_mismatch"
    issued, expires = doc["issued_at_ms"], doc["expires_at_ms"]
    if not _integer(issued) or not _integer(expires):
        return "timestamp_type"
    if now >= expires:
        return "expired"
    if expires <= issued:
        return "invalid_lifetime"
    if expires - issued > 86_400_000:
        return "lifetime_too_long"
    if issued > now + 60_000:
        return "issued_in_future"
    count = doc["fixed_count"]
    if not isinstance(count, str):
        return "fixed_count_type"
    if not _FIXED_COUNT.fullmatch(count) or not Decimal("0.01") <= Decimal(count) <= Decimal("1.00"):
        return "fixed_count"
    if not isinstance(doc["approval_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", doc["approval_id"]):
        return "approval_id"
    return None


def load_account_arm(path, *, lane_id, now_ms):
    """Load a v2 arm bound to one account lane; every refusal raises GoldArmRefused.

    The file must be canonical JSON (sorted keys, compact separators, ASCII
    escapes, no trailing newline) and obey the v1 ownership and size rules.
    """
    try:
        if not _lane_id(lane_id):
            raise GoldArmRefused("lane_id_argument")
        if not _integer(now_ms):
            raise GoldArmRefused("clock_error")
        data = _read_account_arm_bytes(path)
        try:
            text = data.decode("utf-8")
        except UnicodeError:
            raise GoldArmRefused("file_utf8") from None
        try:
            doc = json.loads(text, object_pairs_hook=_pairs, parse_constant=_constant)
        except EvidenceRefused as exc:
            raise GoldArmRefused(exc.reason) from None
        except (ValueError, RecursionError):
            raise GoldArmRefused("file_json") from None
        canonical = json.dumps(doc, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        if canonical != data:
            raise GoldArmRefused("noncanonical")
        reason = _account_arm_reason(doc, lane_id, now_ms)
        if reason:
            raise GoldArmRefused(reason)
        return GoldAccountArm(
            series=doc["series"], symbol=doc["symbol"], build_sha=doc["build_sha"],
            lane_id=doc["lane_id"], issued_at_ms=doc["issued_at_ms"],
            expires_at_ms=doc["expires_at_ms"], fixed_count=Decimal(doc["fixed_count"]),
            approval_id=doc["approval_id"], sha256=hashlib.sha256(data).hexdigest())
    except GoldArmRefused:
        raise
    except OSError as exc:
        raise GoldArmRefused("file_io") from exc
    except Exception as exc:
        # Anything unexpected fails closed with a bounded reason.
        raise GoldArmRefused("invalid") from exc


def account_entry_open(arm, *, lane_id, build_sha, build_dirty, now_ms):
    """Per-call entry gate for an account lane; closed unless every binding holds."""
    try:
        if GOLD_LIVE_ENTRY_PIN != "enabled":
            return False, "code_pin_disabled"
        if (not isinstance(arm, GoldAccountArm)
                or arm.series != "KXGOLD15M" or arm.symbol != "GOLD-15M"
                or not isinstance(arm.fixed_count, Decimal)
                or not arm.fixed_count.is_finite()
                or not Decimal("0.01") <= arm.fixed_count <= Decimal("1.00")
                or arm.fixed_count != arm.fixed_count.quantize(Decimal("0.01"))):
            return False, "arm_fields"
        if os.environ.get("LEAFHFT_RISK_REGIME", "") != "account":
            return False, "risk_regime_mismatch"
        if not _lane_id(lane_id) or os.environ.get("LEAFHFT_ACCOUNT_LANE_ID", "") != lane_id:
            return False, "lane_env_mismatch"
        if arm.lane_id != lane_id:
            return False, "lane_mismatch"
        if not _hex(build_sha, 40):
            return False, "build_sha_format"
        if build_sha != arm.build_sha:
            return False, "build_sha_mismatch"
        if not isinstance(build_dirty, str) or build_dirty != "0":
            return False, "build_dirty"
        if not _integer(now_ms) or not _integer(arm.expires_at_ms):
            return False, "clock_error"
        if now_ms >= arm.expires_at_ms:
            return False, "expired"
        return True, "open"
    except Exception:
        return False, "switch_error"


@dataclass(frozen=True)
class GoldEvidence:
    schema: str
    generated_at_ms: int
    source_sha256: str
    artifacts_sha256: str
    rules_hash: str
    model_version: str
    calibration: dict
    last_mismatch_ms: int | None
    cells: dict
    provenance: dict
    sha256: str


def _keys(value, expected, reason):
    if not isinstance(value, dict) or set(value) != set(expected):
        raise EvidenceRefused(reason)


def _validate_evidence(doc, *, now_ms, max_age_ms, source_sha256, artifacts_sha256):
    _keys(doc, _EVIDENCE_KEYS, "keys")
    if doc["schema"] != EVIDENCE_SCHEMA:
        raise EvidenceRefused("schema")
    for key, expected in (("source_sha256", source_sha256),
                          ("artifacts_sha256", artifacts_sha256),
                          ("rules_hash", gold_artifacts.RULES_HASH),
                          ("model_version", gold_artifacts.MODEL_VERSION)):
        if doc[key] != expected or (key != "model_version" and not _hex(doc[key], 64)):
            raise EvidenceRefused(key)
    generated = doc["generated_at_ms"]
    if not _integer(generated) or not _integer(now_ms) or not _integer(max_age_ms):
        raise EvidenceRefused("timestamp_type")
    if generated > now_ms + 60_000:
        raise EvidenceRefused("generated_in_future")
    if now_ms - generated > max_age_ms:
        raise EvidenceRefused("stale")
    if doc["last_mismatch_ms"] is not None and not _integer(doc["last_mismatch_ms"]):
        raise EvidenceRefused("last_mismatch_ms")
    calibration = doc["calibration"]
    _keys(calibration, {"resolved", "chain", "tiers"}, "calibration_keys")
    if not _integer(calibration["resolved"]) or not _hex(calibration["chain"], 64):
        raise EvidenceRefused("calibration")
    if not isinstance(calibration["tiers"], dict):
        raise EvidenceRefused("tiers")
    for tier in calibration["tiers"].values():
        _keys(tier, {"n", "wins", "cost_cents", "days"}, "tier_keys")
        if not all(_integer(tier[key]) for key in ("n", "wins", "cost_cents")):
            raise EvidenceRefused("tier_counts")
        if tier["wins"] > tier["n"]:
            raise EvidenceRefused("wins_gt_n")
        days = tier["days"]
        if (not isinstance(days, list) or len(days) > 32
                or not all(_integer(day) for day in days) or days != sorted(set(days))):
            raise EvidenceRefused("days")
    cells = doc["cells"]
    if not isinstance(cells, dict):
        raise EvidenceRefused("cells")
    buckets = {calibrated_sizing.claimed_bucket(q) for q in (0.0, 0.70, 0.80, 0.90, 0.95, 1.0)}
    for bucket, cell in cells.items():
        if bucket not in buckets:
            raise EvidenceRefused("cell_bucket")
        _keys(cell, {"returns", "cluster_sizes"}, "cell_keys")
        returns, sizes = cell["returns"], cell["cluster_sizes"]
        if not isinstance(returns, list) or len(returns) > 10000:
            raise EvidenceRefused("returns_length")
        if not all(type(value) in (int, float) and math.isfinite(value) for value in returns):
            raise EvidenceRefused("returns_nonfinite")
        if (not isinstance(sizes, list) or not all(_integer(size, 1) for size in sizes)
                or sum(sizes) != len(returns)):
            raise EvidenceRefused("cluster_sizes")
    provenance = doc["provenance"]
    _keys(provenance, {"kind", "bundle_sha256", "first_cursor", "last_cursor", "envelopes_n", "gaps_n"}, "provenance_keys")
    if (provenance["kind"] != "replay" or not _hex(provenance["bundle_sha256"], 64)
            or not _integer(provenance["envelopes_n"]) or not _integer(provenance["gaps_n"])):
        raise EvidenceRefused("provenance")


def load_evidence(path, *, expected_sha256, now_ms, max_age_ms=86_400_000,
                  source_sha256, artifacts_sha256):
    """Read bounded canonical JSON and bind it to the caller's exact Gold build.

    Canonical encoding is sorted keys, compact separators, ASCII JSON escapes,
    UTF-8 bytes, and no trailing newline, matching the existing Gold artifacts.
    The caller supplies gold_source_sha256() and gold_paper_live.ARTIFACTS_SHA256.
    """
    try:
        with open(path, "rb") as stream:
            data = stream.read(MAX_EVIDENCE_BYTES + 1)
        if len(data) > MAX_EVIDENCE_BYTES:
            raise EvidenceRefused("too_large")
        digest = hashlib.sha256(data).hexdigest()
        if not _hex(expected_sha256, 64) or digest != expected_sha256:
            raise EvidenceRefused("sha256")
        try:
            doc = json.loads(data.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=_constant)
        except (UnicodeError, ValueError, RecursionError) as exc:
            if isinstance(exc, EvidenceRefused):
                raise
            raise EvidenceRefused("json") from exc
        canonical = json.dumps(doc, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        if canonical != data:
            raise EvidenceRefused("noncanonical")
        _validate_evidence(doc, now_ms=now_ms, max_age_ms=max_age_ms,
                           source_sha256=source_sha256, artifacts_sha256=artifacts_sha256)
        return GoldEvidence(**doc, sha256=digest)
    except EvidenceRefused:
        raise
    except OSError as exc:
        raise EvidenceRefused("io") from exc
    except (TypeError, ValueError, OverflowError, RecursionError) as exc:
        raise EvidenceRefused("invalid") from exc


def gold_entry_count(evidence, *, q_low, ask_cents, entry_fee_cents, evaluator_count,
                     basis_cents, free_cash_cents, max_ticket_cents):
    """Intersect calibrated sizing with the evaluator and operator ticket limits."""
    try:
        if evidence is None:
            return 0, "sizing:no_cell"
        bucket = calibrated_sizing.claimed_bucket(q_low)
        if bucket not in evidence.cells:
            return 0, "sizing:no_cell"
        data = evidence.cells[bucket]
        cell = calibrated_sizing.cell_fraction(data["returns"], data["cluster_sizes"])
        if cell.fraction <= 0:
            return 0, "sizing:" + cell.reason
        if (not _integer(evaluator_count) or not _integer(ask_cents, 1)
                or not _integer(entry_fee_cents) or not _integer(basis_cents, 1)
                or not _integer(free_cash_cents) or not _integer(max_ticket_cents)):
            return 0, "sizing:error"
        cost = ask_cents + entry_fee_cents + 2
        fraction = calibrated_sizing.ticket_fraction(
            cell, balance_usd=basis_cents / 100,
            incumbent_allowance_usd=max_ticket_cents / 100,
            cluster_remaining_usd=free_cash_cents / 100)
        count = max(0, min(evaluator_count, math.floor(fraction * basis_cents / cost),
                           max_ticket_cents // cost))
        return count, "sizing:ok" if count else "sizing:below_one_contract"
    except ValueError:
        return 0, "sizing:error"
