"""Bounded local publication for Kashbot's GAP-TRUTH-JOURNEY.

One trusted publisher code path serves this single-tenant host. Its concurrent
invocations serialize through an OS advisory lock on a persistent open file.
The kernel releases the lock when its holder exits, including on process death.
Other principals writing here, including symlink swaps between checks and use,
are outside this threat model. Store and destination symlinks are still
rejected when checked. Census allows 64 valid reports and 64 unrelated entries;
retention repairs any admitted backlog to the newest 14 valid report days.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import date
from decimal import Decimal, DecimalException
import errno
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import time


DEFAULT_PUBLISH_DIR = Path("/var/lib/leafhft/reports/economics")
MAX_REPORT_BYTES = 1024 * 1024
MAX_ENTRIES = 64
RETAIN_DAYS = 14
SCHEMA = "leafhft.economics.v1"
LOCK_NAME = ".publish.lock"
LOCK_WAIT_SECONDS = 5


class PublicationError(ValueError):
    """The report could not be committed."""


class RetentionError(PublicationError):
    """Publication committed, but retention did not complete."""


class InvalidDecimalError(PublicationError):
    """A JSON number cannot be represented by Decimal."""


def _canonical_day(day):
    if not isinstance(day, str) or re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", day) is None:
        raise PublicationError("report day must be a canonical YYYY-MM-DD UTC date")
    try:
        date.fromisoformat(day)
    except ValueError:
        raise PublicationError("report day must be a valid UTC date") from None
    return day


def _invalid_constant(value):
    raise ValueError("nonfinite JSON constant")


def _validate(data, day):
    _canonical_day(day)
    if len(data) > MAX_REPORT_BYTES:
        raise PublicationError("report exceeds 1 MiB")
    try:
        report = json.loads(data, parse_float=Decimal, parse_constant=_invalid_constant)
    except (DecimalException, OverflowError):
        raise InvalidDecimalError("report contains an invalid decimal") from None
    except (ValueError, UnicodeError, RecursionError):
        raise PublicationError("report is not valid JSON") from None
    if not isinstance(report, dict) or report.get("schema") != SCHEMA or report.get("day") != day:
        raise PublicationError("report schema or day does not match destination")


def _valid_report(path, day):
    """Read only regular nonsymlink files, with one byte to detect overflow."""
    try:
        before = path.lstat()
        if not stat.S_ISREG(before.st_mode):
            return False
        flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
        with os.fdopen(os.open(path, flags), "rb") as stream:
            opened = os.fstat(stream.fileno())
            if not stat.S_ISREG(opened.st_mode) or not os.path.samestat(before, opened):
                return False
            data = stream.read(MAX_REPORT_BYTES + 1)
        _validate(data, day)
        return True
    except InvalidDecimalError:
        raise
    except PublicationError:
        return False


def _check_store(store):
    if not stat.S_ISDIR(store.lstat().st_mode):
        raise PublicationError("store must be a nonsymlink directory")


def _check_destination(destination, day):
    try:
        destination.lstat()
    except FileNotFoundError:
        return
    except OSError as exc:
        raise PublicationError("publication not committed: candidate unreadable") from exc
    if not _precommit_candidate(destination, day):
        raise PublicationError("existing destination is not a valid nonsymlink economics report")


def _precommit_candidate(path, day):
    try:
        return _valid_report(path, day)
    except (OSError, InvalidDecimalError, DecimalException, OverflowError, RecursionError) as exc:
        raise PublicationError("publication not committed: candidate unreadable") from exc


def _report_days(store, entries):
    days = set()
    for name in entries:
        if re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}\.json", name) is None:
            continue
        day = name[:-5]
        if _valid_report(store / name, day):
            days.add(day)
    return days


def _candidates(store):
    # Classify before any report write. Each class permits one extra entry only
    # to detect overflow. The persistent lock is control metadata, not input.
    entries = []
    reports = 0
    unrelated = 0
    with os.scandir(store) as iterator:
        for entry in iterator:
            if entry.name == LOCK_NAME:
                continue
            name = entry.name
            if (re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}\.json", name)
                    and _precommit_candidate(store / name, name[:-5])):
                reports += 1
            else:
                unrelated += 1
            if unrelated > MAX_ENTRIES:
                raise PublicationError("store directory exceeds 64 entries unrelated to reports")
            if reports > MAX_ENTRIES:
                raise PublicationError("store directory exceeds 64 valid report days")
            entries.append(name)
    return entries


def _case_insensitive(path):
    """Probe an existing entry without creating files or following symlinks."""
    try:
        return os.path.samestat(path.lstat(), path.with_name(path.name.swapcase()).lstat())
    except FileNotFoundError:
        return False
    except OSError as exc:
        raise PublicationError("publication not committed: candidate unreadable") from exc


def _publication_candidates(store, day):
    _check_store(store)
    entries = _candidates(store)
    destination = store / (day + ".json")
    # Only aliases on this filesystem can overwrite a differently-cased entry.
    if any(name != destination.name and name.casefold() == destination.name.casefold()
           and _case_insensitive(store / name) for name in entries):
        raise PublicationError("publication not committed: noncanonical destination alias")
    _check_destination(destination, day)
    return entries


def _try_lock(fd):
    if os.name == "nt":
        import msvcrt

        os.lseek(fd, 0, os.SEEK_SET)
        # Windows permits locking beyond EOF, so the lock file needs no writes.
        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
    else:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)


def _unlock(fd):
    if os.name == "nt":
        import msvcrt

        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
    else:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_UN)


@contextmanager
def _publication_lock(store):
    path = store / LOCK_NAME
    try:
        info = path.lstat()
    except FileNotFoundError:
        pass
    else:
        if not stat.S_ISREG(info.st_mode):
            raise PublicationError("publication lock must be a nonsymlink regular file")
    fd = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
    acquired = False
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise PublicationError("publication lock must be a nonsymlink regular file")
        deadline = time.monotonic() + LOCK_WAIT_SECONDS
        while True:
            try:
                _try_lock(fd)
                acquired = True
                break
            except OSError as exc:
                if exc.errno not in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                    raise
                if time.monotonic() >= deadline:
                    raise PublicationError("publication lock wait timed out") from None
                time.sleep(min(0.05, max(0, deadline - time.monotonic())))
        yield
    finally:
        try:
            if acquired:
                _unlock(fd)
        finally:
            os.close(fd)


def publish_report(store, day, serialized):
    """Commit serialized producer JSON, then retain the newest 14 valid days.

    RetentionError means the atomic replacement already succeeded. No accounting
    fields are transformed here; INCOMPLETE reports and null values are valid.
    """
    _canonical_day(day)
    data = serialized.encode("utf-8") if isinstance(serialized, str) else serialized
    if not isinstance(data, bytes):
        raise PublicationError("serialized report must be text or bytes")
    _validate(data, day)
    store = Path(store)
    # lstat also rejects dangling symlinks, which exists() would miss.
    try:
        _check_store(store)
    except FileNotFoundError:
        store.mkdir(parents=True, exist_ok=True)
        _check_store(store)
    try:
        (store / LOCK_NAME).lstat()
    except FileNotFoundError:
        # A refused first publication must not leave control metadata behind.
        # Repeat under the lock: another publisher may change the store meanwhile.
        _publication_candidates(store, day)
    with _publication_lock(store):
        return _publish_locked(store, day, data)


def _publish_locked(store, day, data):
    entries = _publication_candidates(store, day)
    destination = store / (day + ".json")
    temporary = None
    try:
        fd, name = tempfile.mkstemp(prefix="." + day + ".", suffix=".tmp", dir=store)
        temporary = Path(name)
        with os.fdopen(fd, "wb") as stream:
            if stream.write(data) != len(data):
                raise OSError("short report write")
            stream.flush()
            os.fsync(stream.fileno())
        _check_store(store)
        _check_destination(destination, day)
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    try:
        _check_store(store)
        days = _report_days(store, entries)
        for old_day in sorted(days | {day}, reverse=True)[RETAIN_DAYS:]:
            path = store / (old_day + ".json")
            # A file changed since the census must qualify again before deletion.
            if _valid_report(path, old_day):
                path.unlink()
    except (OSError, ValueError, DecimalException, OverflowError, RecursionError) as exc:
        raise RetentionError("publication committed but retention failed") from exc
    return destination
