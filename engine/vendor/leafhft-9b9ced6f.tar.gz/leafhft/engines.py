"""Named policy documents for Kalshi engines; inert until a reader selects one."""
from __future__ import annotations

import errno
import hashlib
import json
import logging
import math
import os
import re
import stat
import tempfile
from collections import deque
from contextlib import contextmanager
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import ENGINE_CATALOG_CAPACITY, ENGINE_CATALOG_MAX_ENTRIES
from .broker.kalshi_pool import _FileLock
from .engine_layers import TRANSFORM
from .policy import (KalshiPolicy, OPTIONAL_POLICY_BOUNDS, POLICY_BOUNDS, PolicyError, policy_digest,
                     policy_document, policy_from_mapping, write_policy, validate_hard_maxima,
                     risk_envelope)


CONFIGURE_LOCK_TIMEOUT_S = 5.0
DEFAULT_CAPACITY = ENGINE_CATALOG_CAPACITY
SUPPORTED_CAPACITIES = frozenset({64, 256, 512, DEFAULT_CAPACITY})


def _bound(key):
    """(lo, hi, kind) for a required or optional policy key; None for an unknown key."""
    return POLICY_BOUNDS.get(key) or OPTIONAL_POLICY_BOUNDS.get(key)


# The words that clear an optional policy key when a value arrives as a string (compared after
# strip().lower()); the same set cli._parse_policy_value maps to None. A required key never clears.
_UNSET_WORDS = frozenset(("", "none", "unset"))


class EngineError(ValueError):
    """Invalid engine, binding, or document operation."""


def _override_provenance(provenance):
    if provenance is None:
        return {"source": "cli"}
    allowed = {"source", "control_request_id", "actor", "approval_id", "experiment_id", "note_ref"}
    if not isinstance(provenance, dict) or set(provenance) - allowed:
        raise EngineError("provenance: unknown key or non-object")
    result = {"source": "cli", **provenance}
    for key, value in result.items():
        if key == "control_request_id" and type(value) is int:
            continue
        if not isinstance(value, str):
            raise EngineError(f"provenance: invalid {key}")
        limit = {"control_request_id": 64, "actor": 120, "note_ref": 200}.get(key)
        if limit is not None and len(value) > limit:
            raise EngineError(f"provenance: invalid {key}")
        if key in {"approval_id", "experiment_id"} and not re.fullmatch(r"[A-Za-z0-9._:-]{1,96}", value):
            raise EngineError(f"provenance: invalid {key}")
    return result


class _ProvenanceSymlinkError(OSError):
    """A refused sidecar symlink, independent of platform errno aliases."""


def append_override_provenance(overrides_path, record):
    """Append under the caller's configure lock; rotate without changing overrides."""
    path = Path(overrides_path).with_suffix(".provenance.jsonl")
    if os.path.islink(path):
        raise _ProvenanceSymlinkError(errno.ELOOP, "provenance sidecar is a symlink")
    flags = os.O_RDWR | os.O_CREAT | os.O_APPEND | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags, 0o600)
    try:
        info = os.fstat(fd)
        linked = path.lstat()
        if (not stat.S_ISREG(info.st_mode) or not stat.S_ISREG(linked.st_mode)
                or (info.st_dev, info.st_ino) != (linked.st_dev, linked.st_ino)):
            raise OSError(errno.ELOOP, "provenance sidecar is not a regular file")
        if (info.st_uid != Path(overrides_path).stat().st_uid
                or (hasattr(os, "geteuid") and info.st_uid != os.geteuid())):
            raise OSError(errno.EPERM, "provenance owner differs from overrides")
        if hasattr(os, "fchmod"):
            os.fchmod(fd, 0o600)
        with os.fdopen(fd, "a+", encoding="utf-8", newline="\n") as stream:
            fd = None
            stream.write(json.dumps(record, sort_keys=True) + "\n")
            stream.flush()
            if os.fstat(stream.fileno()).st_size <= 1024 * 1024:
                return
            stream.seek(0)
            newest = deque(stream, maxlen=2000)
        temp_fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
        try:
            with os.fdopen(temp_fd, "w", encoding="utf-8", newline="\n") as stream:
                stream.writelines(newest)
            if os.path.islink(path):
                raise _ProvenanceSymlinkError(errno.ELOOP, "provenance sidecar is a symlink")
            os.replace(temp_name, path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)
    finally:
        if fd is not None:
            os.close(fd)


@contextmanager
def _configure_lock(registry, *, timeout_s=None):
    """Serialize global and account read-check-write transactions on one lock file."""
    lock = _FileLock(registry.dir_path / ".configure.lock",
                     timeout_s=CONFIGURE_LOCK_TIMEOUT_S if timeout_s is None else timeout_s)
    try:
        lock.__enter__()
    except TimeoutError as exc:
        raise EngineError("engine configuration is busy; retry") from exc
    try:
        yield
    finally:
        lock.__exit__(None, None, None)


def _id(value, field="engine_id"):
    if not isinstance(value, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,31}", value):
        raise EngineError(f"{field}: invalid id {value!r}")
    return value


def _timestamp(value, field):
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.utcoffset() != timedelta(0):
            raise ValueError("must be UTC")
        return dt
    except (AttributeError, TypeError, ValueError) as exc:
        raise EngineError(f"{field}: must be an ISO UTC timestamp") from exc


@dataclass(frozen=True)
class Engine:
    engine_id: str
    name: str
    description: str
    policy: KalshiPolicy
    version: int
    parent_engine_id: str | None
    created_at: str
    updated_at: str
    enabled: bool = True

    def __post_init__(self):
        _id(self.engine_id)
        if not isinstance(self.name, str) or not 1 <= len(self.name) <= 64 or not self.name.isprintable():
            raise EngineError("name: must be 1..64 printable characters")
        if not isinstance(self.description, str) or len(self.description) > 500:
            raise EngineError("description: must be 0..500 characters")
        if type(self.version) is not int or self.version < 1:
            raise EngineError("version: must be an integer >= 1")
        if self.parent_engine_id is not None:
            _id(self.parent_engine_id, "parent_engine_id")
        if not isinstance(self.policy, KalshiPolicy):
            raise EngineError("policy: must be a KalshiPolicy")
        if type(self.enabled) is not bool:
            raise EngineError("enabled: must be a bool")
        if _timestamp(self.updated_at, "updated_at") < _timestamp(self.created_at, "created_at"):
            raise EngineError("updated_at: precedes created_at")


def capabilities(policy) -> dict:
    def value(key):
        return getattr(policy, key, False) if key in POLICY_BOUNDS else False

    bands = sorted((key for key in POLICY_BOUNDS
                    if re.fullmatch(r"edge_min_\d+_\d+_cents", key)),
                   key=lambda key: int(key.split("_")[2]))
    favorite_key = "favorite_size_mult" if "favorite_size_mult" in POLICY_BOUNDS else "favorite_mult"
    return {
        "risk_envelope": risk_envelope(),
        "exit_rule": value("exit_margin_cents") > 0,
        "favorites": value(favorite_key) > 1,
        "bands_open": [key[len("edge_min_"):-len("_cents")] for key in bands
                       if hasattr(policy, key) and value(key) < 99],
        "big_edge_cap": ("big_edge_cents" in POLICY_BOUNDS and value("big_edge_cents") < 99)
                        or value("big_edge_min_prob") >= 1.0,
        "drawdown_law": {"brake": value("drawdown_brake_fraction"),
                         "stop": value("drawdown_stop_fraction")},
        "reversal": value("reversal_mult") > 0,
        # Present only when set, so an unset engine's capabilities keep their legacy bytes.
        **({"reversal_execution_mode": policy.reversal_execution_mode}
           if getattr(policy, "reversal_execution_mode", None) is not None else {}),
        **({"variance_estimator": policy.variance_estimator}
           if getattr(policy, "variance_estimator", None) is not None else {}),
        **({"exit_variance_estimator": policy.exit_variance_estimator}
           if getattr(policy, "exit_variance_estimator", None) is not None else {}),
    }


def _read(path, limit):
    # Standalone filesystem calls have no internal deadline; worst-case wall time is unbounded.
    try:
        with Path(path).open("rb") as stream:
            data = stream.read(limit + 1)
        if len(data) > limit:
            raise EngineError(f"{path}: exceeds {limit} bytes")
        raw = json.loads(data.decode("utf-8"))
        if not isinstance(raw, dict):
            raise EngineError(f"{path}: must contain a JSON object")
        return raw
    except (OSError, UnicodeError, ValueError, RecursionError) as exc:
        raise EngineError(f"{path}: {exc}") from exc


def _write(path, document, limit):
    # write_policy serializes dataclasses with policy_document; reuse its owner/mode and
    # state-directory fallback unchanged for these two document dataclasses.
    try:
        if len(json.dumps(policy_document(document), sort_keys=True, separators=(",", ":")).encode()) > limit:
            raise EngineError(f"{path}: exceeds {limit} bytes")
        path.parent.mkdir(parents=True, exist_ok=True)
        write_policy(path, document)
    except (OSError, PolicyError) as exc:
        raise EngineError(f"{path}: {exc}") from exc


class EngineRegistry:
    def __init__(self, dir_path, *, capacity=DEFAULT_CAPACITY):
        if type(capacity) is not int or capacity not in SUPPORTED_CAPACITIES:
            raise EngineError("capacity: must be 64, 256, 512 or 1024")
        self.capacity = capacity
        self.dir_path = Path(dir_path)
        self.problems: list[str] = []

    def path_for(self, engine_id):
        return self.dir_path / f"{_id(engine_id)}.json"

    def _paths(self, *, reserve_entry=False):
        # Assumes a stable directory; this is not a concurrent-writer transaction.
        try:
            if not self.dir_path.exists():
                return []
            paths = []
            count = 0
            with os.scandir(self.dir_path) as entries:
                for count, entry in enumerate(entries, 1):
                    if count > ENGINE_CATALOG_MAX_ENTRIES:
                        raise EngineError(f"registry: exceeds {ENGINE_CATALOG_MAX_ENTRIES} directory entries")
                    path = Path(entry.path)
                    if path.suffix == ".json":
                        paths.append(path)
                        if len(paths) > self.capacity:
                            raise EngineError(f"registry: exceeds {self.capacity} engine files")
            if reserve_entry and count == ENGINE_CATALOG_MAX_ENTRIES:
                raise EngineError(f"registry: no room within {ENGINE_CATALOG_MAX_ENTRIES} directory entries")
            return sorted(paths)
        except OSError as exc:
            raise EngineError(f"registry: {exc}") from exc

    def list(self):
        # At 1024 files: 8,388,608 bytes (8 MiB) of accepted JSON, plus at most
        # 1024 one-byte overflow probes per complete pass. This bounds raw input,
        # not peak Python RSS: decoded objects add overhead. It is not an I/O timeout.
        self.problems = []
        engines = []
        try:
            paths = self._paths()
        except EngineError as exc:
            self.problems.append(str(exc))
            return engines
        for path in paths:
            try:
                engines.append(self.get(path.stem))
            except EngineError as exc:
                self.problems.append(f"{path.name}: {exc}")
        return engines

    def get(self, engine_id):
        raw = _read(self.path_for(engine_id), 8192)
        try:
            raw["policy"] = policy_from_mapping(raw["policy"])
            engine = Engine(**raw)
        except (KeyError, TypeError, PolicyError) as exc:
            raise EngineError(f"{engine_id}: {exc}") from exc
        if engine.engine_id != engine_id:
            raise EngineError(f"{engine_id}: engine_id does not match filename")
        return engine

    def create(self, engine_id, name, description, policy, parent=None):
        path = self.path_for(engine_id)
        try:
            with _configure_lock(self):
                if path.exists():
                    raise EngineError(f"{engine_id}: already exists")
                if len(self._paths(reserve_entry=True)) >= self.capacity:
                    raise EngineError(f"registry: exceeds {self.capacity} engine files")
                if parent is not None:
                    self.get(parent)
                now = datetime.now(timezone.utc).isoformat()
                engine = Engine(engine_id, name, description, policy, 1, parent, now, now)
                _write(path, engine, 8192)
                return engine
        except OSError as exc:
            raise EngineError(f"{engine_id}: {exc}") from exc

    def set_values(self, engine_id, values, *, validator=None):
        """A string value parses to its key's kind; for an optional key an _UNSET_WORDS string
        parses to None, which clears the key (policy_document omits it). Fails closed on the rest."""
        with _configure_lock(self):
            current = self.get(engine_id)
            parsed = {}
            try:
                for key, value in values.items():
                    if _bound(key) is None:
                        raise EngineError(f"policy set: unknown key {key!r}")
                    kind = _bound(key)[2]
                    if isinstance(value, str):
                        if key in OPTIONAL_POLICY_BOUNDS and value.strip().lower() in _UNSET_WORDS:
                            value = None
                        else:
                            try:
                                value = kind(value)
                            except ValueError as exc:
                                raise EngineError(f"{key}: {value!r} is not a valid {kind.__name__}") from exc
                    parsed[key] = value
                validate_hard_maxima(parsed)
                policy = policy_from_mapping({**policy_document(current.policy), **parsed})
            except PolicyError as exc:
                raise EngineError(str(exc)) from exc
            now = max(datetime.now(timezone.utc),
                      _timestamp(current.updated_at, "updated_at") + timedelta(microseconds=1))
            engine = replace(current, policy=policy, version=current.version + 1, updated_at=now.isoformat())
            if validator is not None:
                validator(engine)
            _write(self.path_for(engine_id), engine, 8192)
            return engine

    def set_enabled(self, engine_id, enabled):
        if type(enabled) is not bool:
            raise EngineError("enabled: must be a bool")
        with _configure_lock(self):
            current = self.get(engine_id)
            now = max(datetime.now(timezone.utc),
                      _timestamp(current.updated_at, "updated_at") + timedelta(microseconds=1))
            engine = replace(current, enabled=enabled, version=current.version + 1,
                             updated_at=now.isoformat())
            _write(self.path_for(engine_id), engine, 8192)
            return engine

    def configure(self, engine_id, expected_revision, *, enabled=..., set_values=None,
                  validator=None):
        with _configure_lock(self):
            current = self.get(engine_id)
            revision = engine_revision(current)
            if expected_revision != revision:
                raise EngineError(f"revision conflict: expected {expected_revision}, current {revision}")
            if enabled is not ... and type(enabled) is not bool:
                raise EngineError("enabled: must be a bool")
            values = dict(set_values or {})
            try:
                validate_hard_maxima(values)
                policy = policy_from_mapping({**policy_document(current.policy), **values})
            except PolicyError as exc:
                raise EngineError(str(exc)) from exc
            now = max(datetime.now(timezone.utc),
                      _timestamp(current.updated_at, "updated_at") + timedelta(microseconds=1))
            engine = replace(current, policy=policy,
                             enabled=current.enabled if enabled is ... else enabled,
                             version=current.version + 1, updated_at=now.isoformat())
            if validator is not None:
                validator(engine)
            _write(self.path_for(engine_id), engine, 8192)
            return engine


def account_id(value):
    if (not isinstance(value, str) or not 1 <= len(value) <= 160
            or any(ord(char) < 0x20 or ord(char) == 0x7F for char in value)):
        raise EngineError("account_id: invalid id")
    return value


def _revision(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def engine_revision(engine):
    return _revision({"engine_id": engine.engine_id, "version": engine.version,
                      "enabled": engine.enabled, "policy_digest": policy_digest(engine.policy)})


def account_revision(aid, engine, override):
    return _revision({"account_id": account_id(aid), "global": engine_revision(engine),
                      "override": asdict(override) if override is not None else None})


DEFAULT_DARKHORSE_CONFIG = Path("/etc/leafhft/darkhorse.json")
DARKHORSE_KEYS = frozenset({"base_count", "max_mult", "score_threshold_120", "score_threshold_45"})


class AccountDarkHorse:
    """Account controls over host-owned artifacts, never an alternate model registry.

    The small controls document is authoritative. The runtime document is only a
    projection for the existing Dark Horse runner. Both must agree at order send.
    Host arming is deliberately not inherited by a newly enrolled account.
    """

    def __init__(self, state, aid, *, host_path=None):
        self.state = Path(state)
        self.aid = account_id(aid)
        self.host_path = Path(host_path) if host_path is not None else DEFAULT_DARKHORSE_CONFIG
        self.path = self.state / "darkhorse-controls.json"
        self.runtime_path = self.state / "darkhorse.json"
        self._cache_key = None
        self._cache = None
        self._cache_matches = False

    @staticmethod
    def validate_values(values, unset=()):
        if (not isinstance(values, dict) or not isinstance(unset, (list, tuple))
                or any(not isinstance(key, str) for key in unset)
                or set(values) - DARKHORSE_KEYS or set(unset) - DARKHORSE_KEYS
                or set(values) & set(unset)):
            raise EngineError("Darkhorse: unknown or conflicting control")
        for key, value in values.items():
            try:
                finite = isinstance(value, (int, float)) and math.isfinite(value)
            except OverflowError:
                finite = False
            if isinstance(value, bool) or not finite:
                raise EngineError(f"{key}: must be a finite number")
            lo, hi = (0.01, 0.50) if key == "base_count" else (1, 10) if key == "max_mult" else (0, 1)
            if not lo <= value <= hi:
                raise EngineError(f"{key}: value outside bounds")
            if key in {"base_count", "max_mult"}:
                from decimal import Decimal
                if Decimal(str(value)) != Decimal(str(value)).quantize(Decimal("0.01")):
                    raise EngineError(f"{key}: at most two decimal places")

    def _host(self):
        from .config import load_darkhorse_config, darkhorse_model_shas
        from .strategy.darkhorse import DarkHorseModel
        raw = load_darkhorse_config(self.host_path)
        shas = darkhorse_model_shas(self.host_path)
        models = tuple(DarkHorseModel.load(path) for path in raw["models"])
        if (len(shas) != 2 or {m.entry_offset_s for m in models} != {120, 45}
                or load_darkhorse_config(self.host_path) != raw
                or darkhorse_model_shas(self.host_path) != shas):
            raise EngineError("Darkhorse: invalid host models")
        return raw, models, shas

    def _document(self):
        from .account_lane_agent import parse, read_private
        import os
        if not self.path.exists():
            return {"account_id": self.aid, "enabled": False, "policy": {},
                    "revision": 0, "updated_at": None, "history": []}
        raw = parse(read_private(self.path, owner=os.geteuid() if hasattr(os, "geteuid") else 0))
        if (not isinstance(raw, dict) or set(raw) != {
                "account_id", "enabled", "policy", "revision", "updated_at", "history"}
                or raw["account_id"] != self.aid or type(raw["enabled"]) is not bool
                or type(raw["revision"]) is not int or raw["revision"] < 1
                or not isinstance(raw["history"], list) or len(raw["history"]) > 20):
            raise EngineError("Darkhorse: invalid account controls")
        _timestamp(raw["updated_at"], "updated_at")
        self.validate_values(raw["policy"])
        return raw

    def resolve(self):
        raw, models, shas = self._host()
        document = self._document()
        values = {"base_count": float(raw["base_count"]), "max_mult": float(raw["max_mult"]),
                  **{f"score_threshold_{int(m.entry_offset_s)}": m.score_threshold for m in models},
                  **document["policy"]}
        self.validate_values(values)
        for model in models:
            value = values[f"score_threshold_{int(model.entry_offset_s)}"]
            if not model.score_threshold <= value < model.score_p99:
                raise EngineError("Darkhorse: threshold must be at least trained threshold and below score_p99")
        runtime = {**raw, "armed": int(document["enabled"]),
                   "base_count": format(values["base_count"], ".2f"),
                   "max_mult": format(values["max_mult"], ".2f")}
        revision = _revision({"account_id": self.aid, "host": raw, "model_shas": shas,
                              "controls": document})
        return document, values, runtime, models, shas, revision

    def materialize(self):
        from .account_lane_agent import write_private
        resolved = self.resolve()
        write_private(self.runtime_path, resolved[2])
        return resolved

    def configure(self, expected_revision, *, enabled=..., set_values=None, unset=()):
        from .account_lane_agent import write_private
        self.validate_values({} if set_values is None else set_values, unset)
        if enabled is not ... and enabled is not None and type(enabled) is not bool:
            raise EngineError("Darkhorse: enabled must be bool or null")
        document, values, runtime, models, shas, revision = self.resolve()
        if expected_revision != revision:
            raise EngineError("Darkhorse: revision conflict")
        policy = dict(document["policy"])
        for key in unset:
            policy.pop(key, None)
        policy.update(set_values or {})
        # Resolve the candidate against the same host models before either write.
        host, host_models, host_shas = self._host()
        if host_models != models or host_shas != shas or self.resolve()[-1] != revision:
            raise EngineError("Darkhorse: host configuration changed")
        defaults = {"base_count": float(host["base_count"]), "max_mult": float(host["max_mult"])}
        defaults.update({f"score_threshold_{int(m.entry_offset_s)}": m.score_threshold for m in models})
        candidate = {**defaults, **policy}
        self.validate_values(candidate)
        for model in models:
            if not model.score_threshold <= candidate[f"score_threshold_{int(model.entry_offset_s)}"] < model.score_p99:
                raise EngineError("Darkhorse: threshold must be at least trained threshold and below score_p99")
        now = datetime.now(timezone.utc).isoformat()
        new_enabled = document["enabled"] if enabled is ... else bool(enabled)
        change = {"revision": document["revision"] + 1, "updated_at": now,
                  "enabled": new_enabled, "policy": policy}
        new = {"account_id": self.aid, **change, "history": (document["history"] + [change])[-20:]}
        # A partial write cannot enable orders: admission requires both documents.
        write_private(self.runtime_path, {**runtime, "armed": int(new_enabled),
                      "base_count": format(candidate["base_count"], ".2f"),
                      "max_mult": format(candidate["max_mult"], ".2f")})
        write_private(self.path, new)
        return self.resolve()

    def admitted(self):
        """Fresh send-boundary check, also used before producing model decisions."""
        from .config import load_darkhorse_config
        resolved = self.resolve()
        if not resolved[0]["enabled"] or load_darkhorse_config(self.runtime_path) != resolved[2]:
            raise EngineError("Darkhorse: account disabled or configuration pending")
        return resolved

    def decision_settings(self):
        # The timer runs every millisecond. Re-read only when a producer changes.
        from .config import load_darkhorse_config
        paths = [self.host_path, self.path, self.runtime_path]
        if self._cache is not None:
            paths += [Path(p) for p in self._cache[2]["models"]]
        def fingerprint(path):
            try:
                st = path.stat()
                return (str(path), st.st_mtime_ns, st.st_size, st.st_ino)
            except FileNotFoundError:
                return (str(path), None)
        key = tuple(fingerprint(path) for path in paths)
        if key != self._cache_key:
            self._cache = self.resolve()
            try:
                self._cache_matches = load_darkhorse_config(self.runtime_path) == self._cache[2]
            except (OSError, ValueError):
                self._cache_matches = False
            self._cache_key = tuple(fingerprint(path) for path in
                [self.host_path, self.path, self.runtime_path, *map(Path, self._cache[2]["models"])])
        if not self._cache_matches:
            raise EngineError("Darkhorse: configuration pending")
        return self._cache


@dataclass(frozen=True)
class AccountOverride:
    enabled: bool | None
    policy: dict[str, int | float]
    revision: int
    updated_at: str

    def __post_init__(self):
        if self.enabled is not None and type(self.enabled) is not bool:
            raise EngineError("enabled: must be a bool or null")
        if not isinstance(self.policy, dict):
            raise EngineError("policy: must be an object")
        if type(self.revision) is not int or self.revision < 1:
            raise EngineError("revision: must be an integer >= 1")
        _timestamp(self.updated_at, "updated_at")
        for key, value in self.policy.items():
            if _bound(key) is None:
                raise EngineError(f"policy: unknown key {key!r}")
            if value is None and key in OPTIONAL_POLICY_BOUNDS:
                continue  # explicit legacy for this account over a global mode
            lo, hi, kind = _bound(key)
            if isinstance(value, bool) or (kind is int and type(value) is not int) \
                    or (kind is float and not isinstance(value, (int, float))) \
                    or not math.isfinite(float(value)) or not lo <= value <= hi:
                raise EngineError(f"{key}: invalid value")


@dataclass(frozen=True)
class _AccountOverrideDocument:
    schema_version: int
    accounts: dict[str, dict[str, dict]]


@dataclass(frozen=True)
class DashboardAccountIdentity:
    schema_version: int
    account_id: str
    subaccount_number: int
    verified_at: str

    def __post_init__(self):
        if self.schema_version != 1:
            raise EngineError("identity: unsupported schema_version")
        account_id(self.account_id)
        if type(self.subaccount_number) is not int or not 0 <= self.subaccount_number <= 1_000_000:
            raise EngineError("identity: invalid subaccount_number")
        _timestamp(self.verified_at, "verified_at")


def load_dashboard_account_identity(path):
    raw = _read(Path(path), 1024)
    try:
        return DashboardAccountIdentity(**raw)
    except TypeError as exc:
        raise EngineError(f"identity: {exc}") from exc


def write_dashboard_account_identity(path, value, subaccount_number):
    identity = DashboardAccountIdentity(
        1, account_id(value), subaccount_number, datetime.now(timezone.utc).isoformat())
    _write(Path(path), identity, 1024)
    return identity


class AccountOverrides:
    """Sparse per-account engine values. Global engine documents remain the source of defaults."""

    def __init__(self, path, registry):
        self.path = Path(path)
        self.registry = registry
        self.stale_engine_ids: set[str] = set()
        self.provenance_warning: str | None = None

    def _load(self, *, include_stale=False, requested_engine_id=None):
        self.stale_engine_ids = set()
        if not self.path.exists():
            return _AccountOverrideDocument(1, {})
        raw = _read(self.path, 65536)
        if set(raw) != {"schema_version", "accounts"} or raw["schema_version"] != 1 \
                or not isinstance(raw["accounts"], dict) or len(raw["accounts"]) > 128:
            raise EngineError("account overrides: invalid document")
        accounts = {}
        for aid, body in raw["accounts"].items():
            account_id(aid)
            if not isinstance(body, dict) or set(body) != {"engines"} \
                    or not isinstance(body["engines"], dict) or len(body["engines"]) > 64:
                raise EngineError("account overrides: invalid account entry")
            engines = {}
            for eid, value in body["engines"].items():
                _id(eid)
                if not isinstance(value, dict) or set(value) != {"enabled", "policy", "revision", "updated_at"}:
                    raise EngineError("account overrides: invalid engine entry")
                try:
                    override = AccountOverride(**value)
                except (TypeError, OverflowError) as exc:
                    raise EngineError("account overrides: invalid engine entry") from exc
                try:
                    engine = self.registry.get(eid)
                except EngineError as exc:
                    # Only another engine's absence is inert. Never drop the
                    # requested engine's controls if its file disappears mid-read.
                    if eid == requested_engine_id or not isinstance(exc.__cause__, FileNotFoundError):
                        raise
                    self.stale_engine_ids.add(eid)
                    # Guard loads retain stale controls so admission checks cannot lose them.
                    if include_stale or requested_engine_id is None:
                        # Preserve the well-formed stored value without normalizing it.
                        engines[eid] = value
                    continue
                # Validate against the current global policy, including cross-field invariants.
                self._effective(engine, override)
                engines[eid] = asdict(override)
            accounts[aid] = {"engines": engines}
        return _AccountOverrideDocument(1, accounts)

    @staticmethod
    def _effective(engine, override):
        try:
            policy = policy_from_mapping({**policy_document(engine.policy), **override.policy})
        except PolicyError as exc:
            raise EngineError(str(exc)) from exc
        return (engine.enabled if override.enabled is None else override.enabled), policy

    def get(self, aid, engine_id):
        aid, engine_id = account_id(aid), _id(engine_id)
        raw = self._load(requested_engine_id=engine_id).accounts.get(aid, {}).get("engines", {}).get(engine_id)
        return AccountOverride(**raw) if raw is not None else None

    def resolve(self, aid, engine_id):
        engine = self.registry.get(engine_id)
        override = self.get(aid, engine_id)
        if override is None:
            return engine.enabled, engine.policy, None
        enabled, policy = self._effective(engine, override)
        return enabled, policy, override

    def validate_engine(self, engine):
        """Refuse a global change that would invalidate an inherited account policy."""
        document = self._load(include_stale=True, requested_engine_id=engine.engine_id)
        for body in document.accounts.values():
            raw = body["engines"].get(engine.engine_id)
            if raw is not None:
                self._effective(engine, AccountOverride(**raw))

    def configure(self, aid, engine_id, expected_revision, *, enabled=..., set_values=None, unset=(),
                  provenance: dict | None = None):
        self.provenance_warning = None
        metadata = _override_provenance(provenance)
        unset = tuple(unset)
        with _configure_lock(self.registry):
            aid, engine_id = account_id(aid), _id(engine_id)
            engine = self.registry.get(engine_id)
            document = self._load(include_stale=True, requested_engine_id=engine_id)
            accounts = json.loads(json.dumps(document.accounts))
            engines = accounts.setdefault(aid, {"engines": {}})["engines"]
            previous_raw = engines.get(engine_id)
            previous = AccountOverride(**previous_raw) if previous_raw is not None else None
            revision = account_revision(aid, engine, previous)
            if expected_revision != revision:
                raise EngineError(f"revision conflict: expected {expected_revision}, current {revision}")
            current_enabled = previous.enabled if previous is not None else None
            current_policy = dict(previous.policy) if previous is not None else {}
            if enabled is not ...:
                if enabled is not None and type(enabled) is not bool:
                    raise EngineError("enabled: must be a bool or null")
                current_enabled = enabled
            for key in unset:
                if _bound(key) is None:
                    raise EngineError(f"policy: unknown key {key!r}")
                current_policy.pop(key, None)
            for key, value in (set_values or {}).items():
                if _bound(key) is None:
                    raise EngineError(f"policy: unknown key {key!r}")
                if key in TRANSFORM:
                    raise EngineError(f"engine_layer_key: {key}")
                current_policy[key] = value
            now = datetime.now(timezone.utc).isoformat()
            override = AccountOverride(current_enabled, current_policy,
                                       (previous.revision + 1) if previous else 1, now)
            try:
                validate_hard_maxima(current_policy)
            except PolicyError as exc:
                raise EngineError(str(exc)) from exc
            self._effective(engine, override)
            if override.enabled is None and not override.policy:
                engines.pop(engine_id, None)
                if not engines:
                    accounts.pop(aid, None)
            else:
                engines[engine_id] = asdict(override)
            _write(self.path, _AccountOverrideDocument(1, accounts), 65536)
            record = {"schema": "leafhft.override-provenance.v1", "at": override.updated_at,
                      "account_id": aid, "engine_id": engine_id, "revision": override.revision,
                      "set_keys": sorted(set_values or {}), "unset_keys": sorted(unset), **metadata}
            if enabled is not ...:
                record["enabled_change"] = enabled
            try:
                append_override_provenance(self.path, record)
            except OSError as exc:
                reason = "symlink" if isinstance(exc, _ProvenanceSymlinkError) else errno.errorcode.get(exc.errno, 'UNKNOWN')
                self.provenance_warning = f"provenance: not written ({reason})"
                logging.getLogger(__name__).warning(self.provenance_warning)
            return self.resolve(aid, engine_id)


@dataclass(frozen=True)
class _BindingDocument:
    default: str | None
    symbols: dict[str, str]
    disabled: tuple[str, ...] = ()


class Bindings:
    def __init__(self, path, registry):
        self.path = Path(path)
        self.registry = registry

    @staticmethod
    def _symbol(symbol):
        from .feeds.kalshi import SYMBOL_MAP

        if not isinstance(symbol, str) or symbol not in SYMBOL_MAP:
            raise EngineError(f"symbol: unknown symbol {symbol!r}")

    def load(self):
        try:
            if not self.path.exists():
                return _BindingDocument(None, {}, ())
        except OSError as exc:
            raise EngineError(str(exc)) from exc
        raw = _read(self.path, 4096)
        if (set(raw) not in ({"default", "symbols"}, {"default", "symbols", "disabled"})
                or not isinstance(raw["symbols"], dict)):
            raise EngineError("bindings: expected default, symbols, and optional disabled list")
        disabled = raw.get("disabled", [])
        if (not isinstance(disabled, list) or len(disabled) > 64
                or any(not isinstance(symbol, str) for symbol in disabled)
                or len(set(disabled)) != len(disabled)):
            raise EngineError("bindings: disabled must be a unique symbol list")
        if raw["default"] is not None:
            self.registry.get(raw["default"])
        for symbol, engine_id in raw["symbols"].items():
            self._symbol(symbol)
            self.registry.get(engine_id)
        for symbol in disabled:
            self._symbol(symbol)
        return _BindingDocument(raw["default"], raw["symbols"], tuple(sorted(disabled)))

    def resolve(self, symbol):
        self._symbol(symbol)
        document = self.load()
        engine_id = document.symbols.get(symbol, document.default)
        if engine_id is None:
            raise EngineError(f"{symbol}: no default engine or symbol binding")
        return engine_id

    def is_enabled(self, symbol):
        self._symbol(symbol)
        return symbol not in self.load().disabled

    def set_enabled(self, symbol, enabled):
        self._symbol(symbol)
        if type(enabled) is not bool:
            raise EngineError("enabled: must be a bool")
        document = self.load()
        disabled = set(document.disabled)
        if enabled:
            disabled.discard(symbol)
        else:
            disabled.add(symbol)
        _write(self.path, _BindingDocument(document.default, document.symbols,
                                           tuple(sorted(disabled))), 4096)

    def bind(self, symbol, engine_id):
        self.registry.get(engine_id)
        if symbol != "all":
            self._symbol(symbol)
        document = self.load()
        if symbol == "all":
            document = _BindingDocument(engine_id, {}, document.disabled)
        else:
            document = _BindingDocument(document.default,
                                        {**document.symbols, symbol: engine_id},
                                        document.disabled)
        _write(self.path, document, 4096)

    def unbind(self, symbol):
        self._symbol(symbol)
        document = self.load()
        symbols = dict(document.symbols)
        symbols.pop(symbol, None)
        _write(self.path, _BindingDocument(document.default, symbols, document.disabled), 4096)
