"""Inert book, transform and account-execution documents (BE-D1).

The legacy catalog remains the authoring source. C3 identity is the canonical
transform alone; neither account ownership nor execution thresholds enter it.
No runtime selection, filesystem write or environment mutation happens here.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from types import MappingProxyType

from .books.manifest import BookManifest, decode_manifest, encode_manifest
from .policy import (DEFAULT_POLICY, OPTIONAL_POLICY_BOUNDS, POLICY_BOUNDS,
                     KalshiPolicy, PolicyError, _validate_field, policy_from_mapping)

BookSpec = BookManifest
decode_book_spec = decode_manifest
encode_book_spec = encode_manifest
MAX_DOCUMENT_BYTES = 64 * 1024
ENGINE_SCHEMA = "leafhft.engine-spec.v1"
EXECUTION_SCHEMA = "leafhft.execution-policy.v1"
BINDINGS_SCHEMA = "leafhft.bindings.v1"
REFUSAL_CODES = (
    "bad_type", "bad_string", "bad_value", "not_json", "oversize", "nonfinite",
    "unknown_key", "duplicate_key", "missing_key", "missing_digest", "digest_mismatch",
    "schema_unsupported", "sampling_invalid", "policy_invalid", "binding.duplicate",
    "binding.reference_mismatch", "binding.owner_mismatch", "binding.integration_mismatch",
    "binding.book_mismatch", "binding_not_runtime_bindable",
)
TRANSFORM = frozenset({
    "variance_estimator", "exit_variance_estimator",
    "mean_fast_index", "exit_variance_scale", "calibration_intercept",
    "calibration_model_coef", "calibration_market_coef", "calibration_k_coef",
})
KERNEL_PARAM_KEYS = frozenset({
    "settlement_method", "fee_multiplier", "latency_penalty_cents", "window_s",
    "min_step_variance", "max_quote_age_ms", "max_index_age_ms",
})
EXIT_VARIANCE_SCALE_JUSTIFICATION = (
    "KalshiEdge._maybe_exit scales variance before computing hold probability "
    "and fair value; exit_variance_scale changes the transform output, rather "
    "than an acceptance threshold, so it belongs to TRANSFORM."
)

# Explicit lists are intentional: a future policy key must receive a review.
EXECUTION_SECTIONS = MappingProxyType({
    "admission_thresholds": frozenset({
        "min_k", "favorite_edge_threshold_cents", "edge_threshold_cents",
        "big_edge_cents", "big_edge_min_prob", "min_win_cents",
        "edge_min_20_49_cents", "edge_min_50_69_cents", "edge_min_70_79_cents",
        "edge_min_80_89_cents", "edge_min_90_94_cents",
    }),
    "price_bounds": frozenset({
        "min_price_cents", "max_price_cents", "favorite_price_cents",
        "execution_price_buffer_cents", "execution_zero_fill_retries",
        "all_in_band_lo", "all_in_band_hi", "all_in_value_lo", "all_in_value_hi",
        "all_in_anchor_lo", "all_in_anchor_hi",
    }),
    "depth": frozenset({"min_depth", "exit_min_depth"}),
    "sizing": frozenset({
        "size_fraction", "favorite_mult", "conviction_min", "conviction_max",
        "target_win_cents", "kelly_fraction", "fixed_count", "risk_resize_live",
        "all_in_value_fraction", "all_in_max_legs",
    }),
    "stakes": frozenset({
        "per_order_fraction", "cluster_fraction", "stake_ceiling_usd",
        "reversal_max_extra_cents", "reversal_max_open_cents", "reversal_budget_cents",
    }),
    "drawdown_latches": frozenset({
        "daily_loss_fraction", "cash_floor_cents", "drawdown_brake_fraction",
        "drawdown_stop_fraction", "all_in_once_armed",
    }),
    "exits": frozenset({
        "exit_margin_cents", "exit_prob_ceiling", "exit_max_quote_age_ms",
        "exit_min_hold_s", "reentry_block_s", "exit_min_hold_fraction",
        "reversal_mult", "reversal_input_age_ms", "reversal_execution_mode",
    }),
})
POLICY_FIELD_SECTIONS = MappingProxyType({
    **{key: section for section, keys in EXECUTION_SECTIONS.items() for key in keys},
    **{key: "transform" for key in TRANSFORM},
})
POLICY_FIELD_LAYERS = MappingProxyType({
    key: "TRANSFORM" if key in TRANSFORM else "EXECUTION"
    for key in POLICY_FIELD_SECTIONS
})
# These legacy strategy params are not KalshiPolicy fields. They still govern
# acceptance/sizing and must not silently become transform or account params.
LEGACY_EXECUTION_PARAM_KEYS = frozenset({
    "max_order_cents", "refire_min_gap_ms", "favorite_size_mult",
})
PARAM_FIELD_LAYERS = MappingProxyType({
    **POLICY_FIELD_LAYERS,
    **{key: "KERNEL" for key in KERNEL_PARAM_KEYS},
    **{key: "EXECUTION" for key in LEGACY_EXECUTION_PARAM_KEYS},
})
KERNEL_DEFAULTS = MappingProxyType({
    "settlement_method": "mean", "fee_multiplier": 0.07,
    "latency_penalty_cents": 0.5, "window_s": 120.0,
    "min_step_variance": 0.0, "max_quote_age_ms": 60_000, "max_index_age_ms": 0,
})
_KERNEL_BOUNDS = {
    "fee_multiplier": (0.01, 0.5, float),
    "latency_penalty_cents": (0.0, 20.0, float),
    "window_s": (10.0, 600.0, float),
    "min_step_variance": (0.0, 1.0, float),
    "max_quote_age_ms": (1, 3_600_000, int),
    "max_index_age_ms": (0, 600_000, int),
}
_BOUNDS = {**POLICY_BOUNDS, **OPTIONAL_POLICY_BOUNDS}
_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,31}")
_BOOK_REF = re.compile(r"[a-z0-9][a-z0-9-]{0,31}:[A-Za-z0-9_./-]{1,64}")
_LEGACY_KEYS = frozenset({
    "engine_id", "name", "description", "policy", "version", "parent_engine_id",
    "created_at", "updated_at", "enabled",
})


class LayerInvalid(ValueError):
    """A stable, machine-readable refusal code with human-readable detail."""

    def __init__(self, code: str, detail: str):
        self.code, self.detail = code, detail
        super().__init__(f"{code}: {detail}")


def canonical_json(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("ascii")


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise LayerInvalid("duplicate_key", key)
        result[key] = value
    return result


def _nonfinite(text):
    raise LayerInvalid("nonfinite", text)


def _finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise LayerInvalid("nonfinite", "non-finite number")
    if isinstance(value, Mapping):
        for child in value.values():
            _finite(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            _finite(child)


def _load(raw):
    if isinstance(raw, str):
        try:
            raw = raw.encode("utf-8")
        except UnicodeError:
            raise LayerInvalid("not_json", "not UTF-8") from None
    if not isinstance(raw, (bytes, bytearray)):
        raise LayerInvalid("bad_type", "expected bytes or str")
    if len(raw) > MAX_DOCUMENT_BYTES:
        raise LayerInvalid("oversize", "document exceeds byte limit")
    try:
        doc = json.loads(bytes(raw).decode("utf-8"), object_pairs_hook=_pairs,
                         parse_constant=_nonfinite)
        _finite(doc)  # Includes overflowing JSON exponents such as 1e999.
        return doc
    except LayerInvalid:
        raise
    except (ValueError, UnicodeError, RecursionError):
        raise LayerInvalid("not_json", "invalid JSON") from None


def _keys(doc, allowed, required=()):
    if not isinstance(doc, Mapping):
        raise LayerInvalid("bad_type", "expected an object")
    if any(type(key) is not str for key in doc):
        raise LayerInvalid("bad_type", "object keys must be strings")
    unknown = set(doc) - set(allowed)
    if unknown:
        raise LayerInvalid("unknown_key", sorted(unknown)[0])
    missing = set(required) - set(doc)
    if missing:
        raise LayerInvalid("missing_key", sorted(missing)[0])
    _finite(doc)


def _text(value, where, *, pattern=None, limit=160):
    if type(value) is not str or not 1 <= len(value) <= limit or not value.isprintable():
        raise LayerInvalid("bad_string", where)
    if pattern is not None and not pattern.fullmatch(value):
        raise LayerInvalid("bad_string", where)
    return value


def _bool(value, where):
    if type(value) is not bool:
        raise LayerInvalid("bad_type", where + " must be bool")


def _number(key, value, bounds):
    _finite(value)
    try:
        _validate_field(key, value, *bounds)
    except (PolicyError, OverflowError) as exc:
        raise LayerInvalid("bad_value", str(exc)) from None
    return float(value) if bounds[2] is float else value


def _policy_values(values, allowed, *, normalize=False):
    _keys(values, allowed)
    result = {}
    for key, value in values.items():
        if value is None and key in OPTIONAL_POLICY_BOUNDS:
            result[key] = None
        else:
            numeric = _number(key, value, _BOUNDS[key])
            result[key] = numeric if normalize else value
    return result


def _build_policy(values) -> KalshiPolicy:
    try:
        return policy_from_mapping(values)
    except (PolicyError, TypeError, ValueError, OverflowError) as exc:
        raise LayerInvalid("policy_invalid", str(exc)) from None


@dataclass(frozen=True, slots=True)
class Sampling:
    window_s: float = 120.0
    sample_interval_ms: int | None = 200
    index_5hz: bool = False
    mean_fast_index: int = 0

    def __post_init__(self):
        object.__setattr__(self, "window_s", _number("window_s", self.window_s, _KERNEL_BOUNDS["window_s"]))
        _bool(self.index_5hz, "index_5hz")
        if self.index_5hz:
            if self.sample_interval_ms is not None:
                raise LayerInvalid("sampling_invalid", "choose index_5hz or sample_interval_ms")
        else:
            _number("sample_interval_ms", self.sample_interval_ms, (1, 600_000, int))
        _number("mean_fast_index", self.mean_fast_index, POLICY_BOUNDS["mean_fast_index"])

    def to_dict(self):
        return {"window_s": self.window_s, "sample_interval_ms": self.sample_interval_ms,
                "index_5hz": self.index_5hz, "mean_fast_index": self.mean_fast_index}


def _sampling(doc):
    if isinstance(doc, Sampling):
        return doc
    _keys(doc, {"window_s", "sample_interval_ms", "index_5hz", "mean_fast_index"},
          {"window_s", "mean_fast_index"})
    values = dict(doc)
    if values.get("index_5hz") is True and "sample_interval_ms" not in values:
        values["sample_interval_ms"] = None
    return Sampling(**values)


@dataclass(frozen=True, slots=True)
class EngineSpec:
    engine_id: str
    version: int
    owner: str = "house"
    owner_namespace: str = "house"
    kernel_id: str = "kalshi_edge"
    book_refs: tuple[str, ...] = ()
    sampling: Sampling = field(default_factory=Sampling)
    transform: Mapping = field(default_factory=dict)
    kernel_params: Mapping = field(default_factory=dict)

    def __post_init__(self):
        _text(self.engine_id, "engine_id", pattern=_ID)
        if type(self.version) is not int or self.version < 1:
            raise LayerInvalid("bad_value", "version must be an integer >= 1")
        if self.owner not in ("house", "account"):
            raise LayerInvalid("bad_value", "owner must be house or account")
        _text(self.owner_namespace, "owner_namespace")
        _text(self.kernel_id, "kernel_id", pattern=re.compile(r"[a-z][a-z0-9_-]{0,63}"))
        if not isinstance(self.book_refs, (list, tuple)) or len(self.book_refs) > 64:
            raise LayerInvalid("bad_type", "book_refs must be a bounded list")
        refs = tuple(_text(ref, "book_refs", pattern=_BOOK_REF) for ref in self.book_refs)
        if len(set(refs)) != len(refs):
            raise LayerInvalid("bad_value", "duplicate book_ref")
        object.__setattr__(self, "book_refs", refs)
        sampling = _sampling(self.sampling)
        values = _policy_values(self.transform, TRANSFORM)
        values = {**{key: getattr(DEFAULT_POLICY, key) for key in TRANSFORM if key in POLICY_BOUNDS},
                  **values}
        if values["mean_fast_index"] != sampling.mean_fast_index:
            raise LayerInvalid("sampling_invalid", "mean_fast_index disagrees with transform")
        _build_policy(values)
        _keys(self.kernel_params, KERNEL_PARAM_KEYS)
        params = {**KERNEL_DEFAULTS, "window_s": sampling.window_s, **self.kernel_params}
        if params["settlement_method"] not in ("mean", "trimmed_mean_20"):
            raise LayerInvalid("bad_value", "settlement_method")
        for key, bounds in _KERNEL_BOUNDS.items():
            params[key] = _number(key, params[key], bounds)
        if params["window_s"] != sampling.window_s:
            raise LayerInvalid("sampling_invalid", "window_s disagrees with kernel params")
        object.__setattr__(self, "sampling", sampling)
        object.__setattr__(self, "transform", MappingProxyType(values))
        object.__setattr__(self, "kernel_params", MappingProxyType(params))

    @property
    def spec_ref(self):
        return f"{self.owner}:{self.owner_namespace}/{self.engine_id}@{self.version}"

    def transform_document(self):
        values = _policy_values(self.transform, TRANSFORM, normalize=True)
        return {"kernel_id": self.kernel_id, "book_refs": list(self.book_refs),
                "sampling": self.sampling.to_dict(),
                "transform": {key: value for key, value in values.items() if value is not None},
                "kernel_params": dict(self.kernel_params)}

    @property
    def transform_digest(self):
        """Bare sha256 hex, over sorted compact ASCII JSON of transform inputs."""
        return hashlib.sha256(canonical_json(self.transform_document())).hexdigest()

    def to_dict(self):
        return {"schema": ENGINE_SCHEMA, "engine_id": self.engine_id, "version": self.version,
                "owner": self.owner, "owner_namespace": self.owner_namespace,
                **self.transform_document(), "transform": dict(self.transform),
                "transform_digest": self.transform_digest}


def engine_spec_from_dict(doc) -> EngineSpec:
    fields = {"schema", "engine_id", "version", "owner", "owner_namespace", "kernel_id",
              "book_refs", "sampling", "transform", "kernel_params", "transform_digest"}
    _keys(doc, fields)
    if "transform_digest" not in doc:
        raise LayerInvalid("missing_digest", "transform_digest")
    _keys(doc, fields, fields)
    if doc["schema"] != ENGINE_SCHEMA:
        raise LayerInvalid("schema_unsupported", "engine spec")
    engine = EngineSpec(**{key: value for key, value in doc.items()
                           if key not in ("schema", "transform_digest")})
    if doc["transform_digest"] != engine.transform_digest:
        raise LayerInvalid("digest_mismatch", "transform_digest")
    return engine


def decode_engine_spec(raw) -> EngineSpec:
    return engine_spec_from_dict(_load(raw))


def encode_engine_spec(engine: EngineSpec) -> bytes:
    return _encode(engine.to_dict(), engine_spec_from_dict)


@dataclass(frozen=True, slots=True)
class ExecutionPolicy:
    account_id: str
    values: Mapping = field(default_factory=dict)

    def __post_init__(self):
        _text(self.account_id, "account_id")
        values = _policy_values(self.values, set(POLICY_FIELD_LAYERS) - TRANSFORM)
        _build_policy(values)
        object.__setattr__(self, "values", MappingProxyType(values))

    @property
    def sections(self):
        return MappingProxyType({section: MappingProxyType({key: self.values[key]
                    for key in sorted(keys) if key in self.values})
                    for section, keys in EXECUTION_SECTIONS.items()})

    def kalshi_policy(self, engine: EngineSpec) -> KalshiPolicy:
        """Apply the current owner/account risk regime without changing stored values."""
        return _build_policy({**engine.transform, **self.values})

    def to_dict(self):
        return {"schema": EXECUTION_SCHEMA, "account_id": self.account_id,
                "sections": {key: dict(value) for key, value in self.sections.items()}}


def execution_policy_from_dict(doc) -> ExecutionPolicy:
    _keys(doc, {"schema", "account_id", "sections"}, {"schema", "account_id", "sections"})
    if doc["schema"] != EXECUTION_SCHEMA:
        raise LayerInvalid("schema_unsupported", "execution policy")
    _keys(doc["sections"], EXECUTION_SECTIONS, EXECUTION_SECTIONS)
    values = {}
    for section, allowed in EXECUTION_SECTIONS.items():
        _keys(doc["sections"][section], allowed)
        values.update(doc["sections"][section])
    return ExecutionPolicy(doc["account_id"], values)


def decode_execution_policy(raw) -> ExecutionPolicy:
    return execution_policy_from_dict(_load(raw))


def encode_execution_policy(execution: ExecutionPolicy) -> bytes:
    return _encode(execution.to_dict(), execution_policy_from_dict)


@dataclass(frozen=True, slots=True)
class Binding:
    account_id: str
    book_id: str
    engine_ref: str
    role: str = "incumbent"
    engine_enabled: bool = True
    account_enabled: bool | None = None
    book_enabled: bool = True

    def __post_init__(self):
        _text(self.account_id, "account_id")
        _text(self.book_id, "book_id", pattern=_BOOK_REF)
        _text(self.engine_ref, "engine_ref", limit=256)
        if self.role not in ("incumbent", "probe"):
            raise LayerInvalid("bad_value", "binding role")
        _bool(self.engine_enabled, "engine_enabled")
        if self.account_enabled is not None:
            _bool(self.account_enabled, "account_enabled")
        _bool(self.book_enabled, "book_enabled")

    def effective_enabled(self, inherited_account_enabled: bool):
        _bool(inherited_account_enabled, "inherited_account_enabled")
        account = inherited_account_enabled if self.account_enabled is None else self.account_enabled
        return self.engine_enabled and account and self.book_enabled

    def to_dict(self):
        return {"account_id": self.account_id, "book_id": self.book_id,
                "engine_ref": self.engine_ref, "role": self.role,
                "engine_enabled": self.engine_enabled, "account_enabled": self.account_enabled,
                "book_enabled": self.book_enabled}


def binding_from_dict(doc) -> Binding:
    fields = {"account_id", "book_id", "engine_ref", "role", "engine_enabled",
              "account_enabled", "book_enabled"}
    _keys(doc, fields, fields)
    return Binding(**doc)


def decode_binding(raw) -> Binding:
    return binding_from_dict(_load(raw))


def encode_binding(binding: Binding) -> bytes:
    return _encode(binding.to_dict(), binding_from_dict)


@dataclass(frozen=True, slots=True)
class BindingValidation:
    runtime_bindable: bool
    code: str | None = None


def validate_binding(binding: Binding, engine: EngineSpec, book: BookSpec, *, symbol_map=None):
    if binding.book_id != book.book_id or binding.engine_ref != engine.spec_ref:
        raise LayerInvalid("binding.reference_mismatch", "book or engine reference")
    if engine.owner == "account" and engine.owner_namespace != binding.account_id:
        raise LayerInvalid("binding.owner_mismatch", "account namespace")
    if engine.kernel_id == "kalshi_edge" and book.integration.id != "kalshi-v2":
        raise LayerInvalid("binding.integration_mismatch", book.integration.id)
    if book.book_id not in engine.book_refs:
        raise LayerInvalid("binding.book_mismatch", "engine does not read the bound book")
    if symbol_map is None:
        from .feeds.kalshi import SYMBOL_MAP
        symbol_map = SYMBOL_MAP
    if book.symbol not in symbol_map:
        return BindingValidation(False, "binding_not_runtime_bindable")
    return BindingValidation(True)


@dataclass(frozen=True, slots=True)
class BindingsEnvelope:
    bindings: tuple[Binding, ...]
    default: str | None = None
    disabled: tuple[str, ...] = ()

    def __post_init__(self):
        if not isinstance(self.disabled, (list, tuple)) or len(self.disabled) > 64:
            raise LayerInvalid("bad_type", "disabled must be a bounded book-id list")
        disabled = tuple(_text(book_id, "disabled", pattern=_BOOK_REF) for book_id in self.disabled)
        if len(set(disabled)) != len(disabled):
            raise LayerInvalid("binding.duplicate", "duplicate disabled book")
        object.__setattr__(self, "disabled", disabled)
        if self.default is not None:
            _text(self.default, "default", limit=256)
        if not isinstance(self.bindings, (list, tuple)) or len(self.bindings) > 1024:
            raise LayerInvalid("bad_type", "bindings must be a bounded list")
        rows = tuple(self.bindings)
        if any(not isinstance(row, Binding) for row in rows):
            raise LayerInvalid("bad_type", "bindings must contain Binding documents")
        identities = [(row.account_id, row.book_id, row.engine_ref, row.role) for row in rows]
        if len(set(identities)) != len(rows):
            raise LayerInvalid("binding.duplicate", "duplicate binding")
        object.__setattr__(self, "bindings", rows)

    def to_dict(self):
        return {"schema": BINDINGS_SCHEMA, "default": self.default, "disabled": list(self.disabled),
                "bindings": [row.to_dict() for row in self.bindings]}

    def effective_enabled(self, binding: Binding, inherited_account_enabled: bool):
        return (binding.book_id not in self.disabled
                and binding.effective_enabled(inherited_account_enabled))


def bindings_from_dict(doc):
    _keys(doc, {"schema", "default", "disabled", "bindings"},
          {"schema", "default", "disabled", "bindings"})
    if doc["schema"] != BINDINGS_SCHEMA:
        raise LayerInvalid("schema_unsupported", "bindings")
    if type(doc["bindings"]) is not list or len(doc["bindings"]) > 1024:
        raise LayerInvalid("bad_type", "bindings must be a bounded list")
    return BindingsEnvelope(tuple(binding_from_dict(row) for row in doc["bindings"]),
                            doc["default"], doc["disabled"])


def decode_bindings(raw):
    return bindings_from_dict(_load(raw))


def encode_bindings(envelope: BindingsEnvelope):
    return _encode(envelope.to_dict(), bindings_from_dict)


def _encode(doc, validator):
    validator(doc)
    raw = canonical_json(doc)
    if len(raw) > MAX_DOCUMENT_BYTES:
        raise LayerInvalid("oversize", "document exceeds byte limit")
    return raw


@dataclass(frozen=True, slots=True)
class LegacyEnvelope:
    name: str
    description: str
    created_at: str
    updated_at: str
    version: int
    parent_engine_id: str | None
    enabled: bool
    present_keys: frozenset[str]
    source_key_order: tuple[str, ...]
    policy_key_order: tuple[str, ...]
    canonical_form: str
    noncanonical_input: bool
    input_kind: str


def _legacy(doc):
    _keys(doc, _LEGACY_KEYS, _LEGACY_KEYS - {"enabled"})
    _text(doc["name"], "name", limit=64)
    if type(doc["description"]) is not str or len(doc["description"]) > 500:
        raise LayerInvalid("bad_string", "description")
    if doc["parent_engine_id"] is not None:
        _text(doc["parent_engine_id"], "parent_engine_id", pattern=_ID)
    _bool(doc.get("enabled", True), "enabled")
    try:
        times = [datetime.fromisoformat(doc[key].replace("Z", "+00:00"))
                 for key in ("created_at", "updated_at")]
        if any(dt.utcoffset() != timedelta(0) for dt in times) or times[1] < times[0]:
            raise ValueError()
    except (AttributeError, TypeError, ValueError):
        raise LayerInvalid("bad_value", "legacy timestamps must be ordered UTC") from None
    _policy_values(doc["policy"], _BOUNDS)
    _build_policy(doc["policy"])


def decompose(legacy, *, account_id="owner", owner="house", owner_namespace=None,
              kernel_id="kalshi_edge", book_refs=(), sampling=None, kernel_params=None):
    """Return typed layers and formatting metadata, never cached original bytes.

    Bytes and text compose back to that same type; mappings compose to mappings.
    The sorted compact form of policy.write_policy is byte-preserving, as is
    that form with the single LF used by checked-in catalog mirrors.
    Hand formatting is flagged and composes to semantically equal writer bytes.
    """
    input_kind = "mapping" if isinstance(legacy, Mapping) else "text" if isinstance(legacy, str) else "bytes"
    doc = dict(legacy) if input_kind == "mapping" else _load(legacy)
    _legacy(doc)
    values = doc["policy"]
    fast = values.get("mean_fast_index", DEFAULT_POLICY.mean_fast_index)
    params = dict(kernel_params or {})
    if sampling is None:
        sampling = Sampling(window_s=params.get("window_s", KERNEL_DEFAULTS["window_s"]),
                            mean_fast_index=fast)
    engine = EngineSpec(doc["engine_id"], doc["version"], owner,
                        owner_namespace or ("house" if owner == "house" else account_id),
                        kernel_id, book_refs, sampling,
                        {key: value for key, value in values.items() if key in TRANSFORM}, params)
    execution = ExecutionPolicy(account_id, {key: value for key, value in values.items()
                                             if key not in TRANSFORM})
    writer = canonical_json(doc)
    raw = legacy.encode("utf-8") if input_kind == "text" else bytes(legacy) if input_kind == "bytes" else writer
    form = "legacy-writer-lf" if raw == writer + b"\n" else "legacy-writer"
    envelope = LegacyEnvelope(
        doc["name"], doc["description"], doc["created_at"], doc["updated_at"],
        doc["version"], doc["parent_engine_id"], doc.get("enabled", True),
        frozenset(values), tuple(doc), tuple(values), form,
        raw not in (writer, writer + b"\n"), input_kind)
    return engine, execution, envelope


def compose(engine: EngineSpec, execution: ExecutionPolicy, envelope: LegacyEnvelope):
    """Validate an effective KalshiPolicy, but retain un-clamped stored values.

    Optional omissions and numeric spellings survive. Risk clamping belongs to
    ExecutionPolicy.kalshi_policy, not to this lossless derived-view adapter.
    """
    execution.kalshi_policy(engine)
    values = {**engine.transform, **execution.values}
    missing = envelope.present_keys - values.keys()
    if missing:
        raise LayerInvalid("missing_key", sorted(missing)[0])
    policy = {key: values[key] for key in envelope.policy_key_order}
    doc = {"engine_id": engine.engine_id, "name": envelope.name,
           "description": envelope.description, "policy": policy,
           "version": engine.version, "parent_engine_id": envelope.parent_engine_id,
           "created_at": envelope.created_at, "updated_at": envelope.updated_at,
           "enabled": envelope.enabled}
    doc = {key: doc[key] for key in envelope.source_key_order}
    _legacy(doc)
    if envelope.input_kind == "mapping":
        return doc
    raw = canonical_json(doc)
    if envelope.canonical_form == "legacy-writer-lf":
        raw += b"\n"
    return raw.decode("ascii") if envelope.input_kind == "text" else raw
