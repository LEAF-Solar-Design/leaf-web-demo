"""Pure, bounded probe-population coverage; all times are caller-supplied ns.

Consumes PD1 ReadResult (or its sessions) and journalctl -o json dictionaries.
Reads _PID, UNIT, __REALTIME_TIMESTAMP (microseconds), INVOCATION_ID,
MESSAGE, JOB_TYPE, JOB_RESULT and EXIT_STATUS. Only PID 1 records for the
requested unit are lifecycle evidence. Started messages or successful start
jobs open an invocation; every other record after Started is stop-side
evidence. Missing invocation identity fails closed.

A RootCheckpoint is trusted prior root evidence for [p_ns, c_ns], with the
same book, policy and code set. A live checkpoint carries its session identity;
the retained continuation must reach back to C. A down checkpoint proves the
interval until the next Started. engine_ids carries prior population bindings.
The caller owns journal/log acquisition and checkpoint provenance. No I/O,
clock, caller or qualification side effects are installed here.
"""
from __future__ import annotations

from dataclasses import dataclass

MAX_SESSIONS = 256
MAX_ROWS = 1_000_000
MAX_JOURNAL_RECORDS = 8192
MAX_BOOKS = 256
MAX_CODES = 256
STOP_TOLERANCE_NS = 120 * 1_000_000_000
FRESHNESS_NS = 15 * 60 * 1_000_000_000
POLICIES = frozenset({"necessary", "codes", "causal", "present"})


@dataclass(frozen=True)
class CoverageProblem:
    code: str
    detail: str


@dataclass(frozen=True)
class CoveredSession:
    symbol: str
    session_id: str
    invocation_id: str
    start_ns: int
    end_ns: int | None


@dataclass(frozen=True)
class CoverageDocument:
    p_ns: int
    q_ns: int
    policy: str
    counts: dict[str, int]
    sessions: tuple[CoveredSession, ...]


@dataclass(frozen=True)
class RootCheckpoint:
    symbol: str
    unit: str
    account_id: str
    p_ns: int
    c_ns: int
    policy: str
    counts: dict[str, int]
    down: bool = True
    sessions: tuple[CoveredSession, ...] = ()
    engine_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class BookEvidence:
    symbol: str
    unit: str
    account_id: str
    sessions: object
    journal: list[dict]
    checkpoint: RootCheckpoint | None = None
    pre_cohost_status2_invocations: tuple[str, ...] = ()


def _problem(code, detail):
    return CoverageProblem(code, detail)


def _sessions(value):
    return getattr(value, "sessions", value)


def _started(row):
    return (str(row.get("MESSAGE", "")).startswith("Started ")
            or (row.get("JOB_TYPE") == "start" and row.get("JOB_RESULT") == "done"))


def qualify_book(sessions, journal, *, p_ns, q_ns, symbol, unit, account_id,
                 codes, policy="codes", checkpoint=None,
                 pre_cohost_status2_invocations=()):
    """Return CoverageDocument or CoverageProblem, never both.

    PD1 parsed sessions must be chronological. All retained sessions through Q
    are checked, including the predecessor proving that P lies in downtime.
    Events at P and Q are included. Checkpoint counts include C, so tail counts
    are strictly after C. Status 2 is proof only for explicitly named historical
    pre-co-host invocations; status 4 is always a no-incumbent exit.
    """
    if (type(p_ns) is not int or type(q_ns) is not int or not 0 <= p_ns <= q_ns
            or not symbol or not unit or not account_id or policy not in POLICIES):
        return _problem("invalid-parameters", "interval, identity or policy invalid")
    if (not isinstance(codes, (list, tuple, set, frozenset)) or not codes
            or len(codes) > MAX_CODES
            or any(type(code) is not str or len(code) != 4
                   or any(c not in "0123456789abcdef" for c in code) for code in codes)):
        return _problem("invalid-codes", "bounded four-hex code set required")
    codes = tuple(sorted(set(codes)))
    counts = dict.fromkeys(codes, 0)
    boundary = p_ns
    used = ()
    checkpoint_live = None
    if checkpoint is not None:
        if (not isinstance(checkpoint, RootCheckpoint)
                or (checkpoint.symbol, checkpoint.unit, checkpoint.account_id)
                != (symbol, unit, account_id)
                or checkpoint.p_ns != p_ns or checkpoint.policy != policy
                or type(checkpoint.c_ns) is not int or not p_ns <= checkpoint.c_ns <= q_ns
                or set(checkpoint.counts) != set(codes)
                or any(type(n) is not int or n < 0 for n in checkpoint.counts.values())
                or len(checkpoint.sessions) > MAX_SESSIONS
                or len(checkpoint.engine_ids) > MAX_CODES):
            return _problem("invalid-checkpoint", "checkpoint identity, interval or policy differs")
        live = [s for s in checkpoint.sessions if s.end_ns is None]
        if (checkpoint.down and live) or (not checkpoint.down and len(live) != 1):
            return _problem("invalid-checkpoint", "checkpoint live/down state differs")
        if live:
            checkpoint_live = live[0]
            if (checkpoint_live.symbol != symbol or not checkpoint_live.invocation_id
                    or checkpoint_live.start_ns > checkpoint.c_ns):
                return _problem("invalid-checkpoint", "invalid live checkpoint identity")
        boundary = checkpoint.c_ns
        counts = dict(checkpoint.counts)
        used = checkpoint.sessions
    if getattr(sessions, "problem", None):
        return _problem("log-problem", str(sessions.problem))
    sessions = _sessions(sessions)
    if not isinstance(sessions, (list, tuple)) or not isinstance(journal, (list, tuple)):
        return _problem("invalid-input", "bounded session and journal lists required")
    if (len(sessions) > MAX_SESSIONS
            or len(sessions) + len(used) - (checkpoint_live is not None) > MAX_SESSIONS):
        return _problem("session-bound", "more than 256 sessions")
    if len(journal) > MAX_JOURNAL_RECORDS or sum(len(s.rows) for s in sessions) > MAX_ROWS:
        return _problem("input-bound", "row or journal bound exceeded")
    lifecycle = []
    try:
        for row in journal:
            if str(row.get("_PID")) != "1" or row.get("UNIT") != unit:
                continue
            at = int(row["__REALTIME_TIMESTAMP"]) * 1000
            if at < 0:
                raise ValueError("negative journal timestamp")
            if at <= q_ns:
                inv = row.get("INVOCATION_ID")
                if type(inv) is not str or not inv:
                    return _problem("invocation-mismatch", "PID 1 record lacks invocation id")
                lifecycle.append((at, inv, _started(row), row))
    except (KeyError, TypeError, ValueError) as exc:
        return _problem("journal-problem", str(exc))
    lifecycle.sort(key=lambda entry: entry[0])
    starts = {}
    if checkpoint_live is not None:
        starts[checkpoint_live.invocation_id] = checkpoint_live.start_ns
    for at, inv, start, row in lifecycle:
        if start:
            if inv in starts:
                if checkpoint_live is not None and inv == checkpoint_live.invocation_id and at == starts[inv]:
                    continue
                return _problem("invocation-mismatch", "duplicate Started invocation")
            starts[inv] = at
    retained = []
    previous_end = None
    seen = set()
    for session in sessions:
        if not session.rows:
            return _problem("log-problem", "empty session")
        first, last = session.rows[0], session.rows[-1]
        if first["at_ns"] > q_ns:
            return _problem("future-row", "session opens after Q")
        header = session.header
        if (header.get("symbol"), header.get("unit"), header.get("account_id")) != (symbol, unit, account_id):
            return _problem("identity-mismatch", "symbol, unit or account differs")
        inv = header.get("invocation_id")
        if not inv or inv in seen:
            return _problem("invocation-mismatch", "missing or reused session invocation")
        seen.add(inv)
        if inv not in starts:
            return _problem("missing-started", session.session_id)
        if starts[inv] > first["at_ns"]:
            return _problem("invocation-mismatch", "Started follows session opening")
        if previous_end is not None and starts[inv] < previous_end:
            return _problem("overlapping-session", session.session_id)
        if last["at_ns"] > q_ns:
            return _problem("future-row", "row after Q")
        if session.lossy or any(r.get("lossy") or r.get("dropped", 0) for r in session.rows):
            return _problem("lossy-session", session.session_id)
        stop = [at for at, rid, start, _ in lifecycle
                if rid == inv and not start and at >= starts[inv]]
        quiesce = session.quiesce
        if quiesce is not None:
            if not session.clean or session.rows[-1] is not quiesce:
                return _problem("unclean-session", session.session_id)
            if not stop:
                return _problem("missing-stop", session.session_id)
            if abs(quiesce["at_ns"] - stop[0]) > STOP_TOLERANCE_NS:
                return _problem("stop-distance", session.session_id)
            previous_end = max(quiesce["at_ns"], stop[-1])
        else:
            if session is not sessions[-1]:
                return _problem("unclean-session", session.session_id)
            if stop or any(at > starts[inv] and not start for at, _, start, _ in lifecycle):
                return _problem("live-stop", "non-start PID 1 record after live Started")
            if q_ns - last["at_ns"] > FRESHNESS_NS:
                return _problem("stale-session", session.session_id)
            previous_end = None
        retained.append(session)
        if checkpoint_live is not None and inv == checkpoint_live.invocation_id:
            if session.session_id != checkpoint_live.session_id:
                return _problem("invocation-mismatch", "checkpoint session identity differs")
            used = tuple(s for s in used if s.invocation_id != inv)
        used += (CoveredSession(symbol, session.session_id, inv, starts[inv],
                                quiesce["at_ns"] if quiesce else None),)
    empty_intervals = []
    for inv, at in starts.items():
        if inv in seen:
            continue
        proof = [time for time, rid, start, row in lifecycle
                 if rid == inv and not start and time >= at
                 and (str(row.get("EXIT_STATUS")) == "4"
                      or (str(row.get("EXIT_STATUS")) == "2"
                          and inv in pre_cohost_status2_invocations))]
        next_start = min((time for rid, time in starts.items() if time > at), default=q_ns + 1)
        if not proof or min(proof) >= next_start:
            return _problem("missing-session", inv)
        empty_intervals.append((at, next_start))
    # A stop for an unknown invocation cannot be assigned to any interval.
    if any(inv not in starts for _, inv, _, _ in lifecycle):
        return _problem("invocation-mismatch", "stop has no matching Started")
    if not retained:
        return _problem("missing-session", "no retained session at qualification")
    first = retained[0]
    if checkpoint is None:
        cursor = boundary
        for at, end in sorted(empty_intervals):
            if at <= cursor < end:
                cursor = end
        empty_prefix = cursor > boundary and cursor >= starts[first.header["invocation_id"]]
        if first.truncated or (first.rows[0]["at_ns"] > boundary and not empty_prefix):
            return _problem("retention-hole", "first retained opening does not cover P")
    if checkpoint is not None:
        if checkpoint_live is None:
            if first.truncated or first.rows[0]["at_ns"] < boundary:
                return _problem("retention-hole", "down checkpoint tail must open at/after C")
        elif (first.header.get("invocation_id") != checkpoint_live.invocation_id
              or first.rows[0]["at_ns"] > boundary):
            return _problem("retention-hole", "live checkpoint continuation does not reach C")
    if q_ns - retained[-1].rows[-1]["at_ns"] > FRESHNESS_NS:
        return _problem("stale-session", "last row older than 15 minutes")
    for session in retained:
        for row in session.events:
            at = row["at_ns"]
            if not (boundary <= at <= q_ns) or (checkpoint is not None and at == boundary):
                continue
            for code in codes:
                matches = (code in row["codes"] if policy in {"codes", "causal"}
                           else code in row["present"])
                if policy == "necessary":
                    matches = matches and row["probes_necessary"]
                if row["unattributed"] > 0 or matches:
                    counts[code] += 1
    return CoverageDocument(p_ns, q_ns, policy, counts, used)


def qualify_population(books, *, engine_id, p_ns, q_ns, codes, policy="codes"):
    """Sum every supplied book with an overlapping session binding engine_id.

    The caller must supply the complete book inventory; this pure rule cannot
    discover omitted books. Root checkpoints explicitly carry prior bindings.
    """
    if (type(p_ns) is not int or type(q_ns) is not int or not 0 <= p_ns <= q_ns
            or type(engine_id) is not str or not engine_id or policy not in POLICIES):
        return _problem("invalid-parameters", "interval, engine or policy invalid")
    if not isinstance(books, (list, tuple)) or len(books) > MAX_BOOKS:
        return _problem("book-bound", "bounded book list required")
    documents = []
    identities = set()
    total_sessions = 0
    total_rows = total_journal = 0
    for book in books:
        identity = (book.account_id, book.symbol)
        if identity in identities:
            return _problem("duplicate-book", book.symbol)
        identities.add(identity)
        if getattr(book.sessions, "problem", None):
            return _problem("log-problem", str(book.sessions.problem))
        sessions = _sessions(book.sessions)
        if not isinstance(sessions, (list, tuple)) or len(sessions) > MAX_SESSIONS:
            return _problem("session-bound", "bounded sessions required")
        total_sessions += len(sessions)
        if total_sessions > MAX_SESSIONS:
            return _problem("session-bound", "population exceeds 256 sessions")
        total_rows += sum(len(s.rows) for s in sessions)
        if total_rows > MAX_ROWS:
            return _problem("input-bound", "row bound exceeded")
        if not isinstance(book.journal, (list, tuple)) or len(book.journal) > MAX_JOURNAL_RECORDS:
            return _problem("input-bound", "journal bound exceeded")
        total_journal += len(book.journal)
        if total_journal > MAX_JOURNAL_RECORDS:
            return _problem("input-bound", "population journal bound exceeded")
        selected = any(s.rows and s.rows[0]["at_ns"] <= q_ns
                       and (s.quiesce is None or s.quiesce["at_ns"] >= p_ns)
                       and any(b["engine_id"] == engine_id and b["at_ns"] <= q_ns
                               for b in s.bindings) for s in sessions)
        if book.checkpoint is not None and engine_id in book.checkpoint.engine_ids:
            selected = True
        if not selected:
            continue
        result = qualify_book(book.sessions, book.journal, p_ns=p_ns, q_ns=q_ns,
                              symbol=book.symbol, unit=book.unit, account_id=book.account_id,
                              codes=codes, policy=policy, checkpoint=book.checkpoint,
                              pre_cohost_status2_invocations=book.pre_cohost_status2_invocations)
        if isinstance(result, CoverageProblem):
            return result
        documents.append(result)
    if not documents:
        return _problem("missing-binding", engine_id)
    counts = {code: sum(d.counts[code] for d in documents) for code in documents[0].counts}
    used = tuple(s for d in documents for s in d.sessions)
    if len(used) > MAX_SESSIONS:
        return _problem("session-bound", "population exceeds 256 sessions")
    return CoverageDocument(p_ns, q_ns, policy, counts, used)
