"""every field is quoted from a file the running process wrote; this module derives nothing and persists nothing.

Liveness, ages, counts and verdicts compare those records with local OS observations.
No checkout, policy source, network service or persistent cache is consulted.
"""
from __future__ import annotations

import heapq
import json
import os
import re
import subprocess
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

MAX_RUN_DIRS = 256
MAX_ERRORS = 20
MAX_ENTRIES = 65536
MAX_BYTES = 1024 * 1024
TIMEOUT_S = 3.0
VERDICTS = ("IN_SYNC", "DRIFTED", "DEGRADED", "UNREADABLE")


def _list_units() -> list[str]:
    result = subprocess.run(
        ["systemctl", "list-units", "leafhft-live@*", "--all", "--plain",
         "--no-legend", "--no-pager"],
        capture_output=True, text=True, timeout=TIMEOUT_S, check=True,
    )
    if result.returncode:
        raise OSError("systemctl list-units failed")
    return sorted({line.split()[0] for line in result.stdout.splitlines()
                   if line.split() and re.fullmatch(
                       r"leafhft-live@[A-Za-z0-9_-]+\.service", line.split()[0])})


def _unit_key(unit: str) -> tuple[str, str] | None:
    instance = unit.removeprefix("leafhft-live@").removesuffix(".service")
    # These two runner labels predate the venue-symbol naming convention.
    if instance == "binanceus-mm":
        return "binanceus", "btc-usd"
    if instance == "kalshi-perp-btc":
        return "kalshi-perp", "btc-perp"
    for prefix, venue in (("polymarket-us-", "polymarket_us"),
                          ("polymarket_us-", "polymarket_us"),
                          ("kalshi-perp-", "kalshi-perp"),
                          ("binanceus-", "binanceus"), ("coinbase-", "coinbase"),
                          ("kraken-", "kraken"), ("kalshi-", "kalshi")):
        if instance.startswith(prefix):
            return venue, instance[len(prefix):].lower()
    return None


def _scan_processes(proc_root: Path = Path("/proc")) -> Counter:
    counts = Counter()
    deadline = time.monotonic() + TIMEOUT_S
    with os.scandir(proc_root) as entries:
        for index, entry in enumerate(entries):
            if index >= MAX_ENTRIES or time.monotonic() >= deadline:
                raise OSError("process scan exceeded its bound")
            if not entry.name.isdigit():
                continue
            try:
                with open(Path(entry.path) / "cmdline", "rb") as stream:
                    data = stream.read(MAX_BYTES + 1)
            except (FileNotFoundError, ProcessLookupError):
                continue  # A process may exit between enumeration and read.
            if len(data) > MAX_BYTES:
                raise OSError("process command line exceeded its bound")
            args = data.decode("utf-8", errors="replace").rstrip("\0").split("\0")
            if (len(args) >= 8 and re.fullmatch(r"python(?:\d+(?:\.\d+)*)?", Path(args[0]).name)
                    and args[1:5] == ["-m", "leafhft", "live", "--venue"]
                    and args[6] == "--symbol"):
                counts[(args[5].lower(), args[7].lower())] += 1
    return counts


def _run_dirs(root: Path) -> list[Path]:
    def candidates():
        with os.scandir(root) as entries:
            for index, entry in enumerate(entries):
                if index >= MAX_ENTRIES:
                    raise OSError("runs root enumeration exceeded its bound")
                if "-live-" in entry.name and entry.is_dir(follow_symlinks=False):
                    yield Path(entry.path)
    # Retain only the newest 256 names; open no older run's files.
    return heapq.nlargest(MAX_RUN_DIRS, candidates(), key=lambda path: path.name)


def _read_json(path: Path) -> tuple[dict, str | None]:
    try:
        with path.open("rb") as stream:
            data = stream.read(MAX_BYTES + 1)
        if len(data) > MAX_BYTES:
            raise ValueError("file exceeds size bound")
        value = json.loads(data)
        if not isinstance(value, dict):
            raise ValueError("expected JSON object")
        return value, None
    except (OSError, ValueError, UnicodeError) as exc:
        return {}, f"{path.name}: {type(exc).__name__}"


def _block(value) -> dict:
    return value if isinstance(value, dict) else {}


def _sha(build: dict) -> str | None:
    value = build.get("git_sha")
    return value if isinstance(value, str) and value.strip() else None


def _age(status: dict, path: Path, now: float) -> float | None:
    try:
        stamp = datetime.fromisoformat(status["generated_at"].replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            return None
        age = now - stamp.timestamp()
        file_age = now - path.stat().st_mtime
        if age < 0 or file_age < -1:
            return None
        return max(age, file_age)
    except (KeyError, AttributeError, TypeError, ValueError, OSError, OverflowError):
        return None


def collect(runs_root: str | Path) -> dict:
    from .cli import KALSHI_STATUS_INTERVAL_S

    rows = []
    try:
        units = _list_units()
        paths = _run_dirs(Path(runs_root))
        processes = _scan_processes()
    except (OSError, subprocess.SubprocessError) as exc:
        return {"rows": rows, "verdict": "UNREADABLE", "exit_code": 3,
                "error": f"{type(exc).__name__}: {exc}"}
    selected = {}
    errors = []
    error_count = 0

    def record_error(message):
        nonlocal error_count
        error_count += 1
        if len(errors) < MAX_ERRORS:
            errors.append(message)

    keys = {_unit_key(unit) for unit in units}
    for path in paths:
        cfg, error = _read_json(path / "config.json")
        if error:
            record_error(f"{path.name}/{error}")
            continue
        key = (str(cfg.get("venue", "")).lower(), str(cfg.get("symbol", "")).lower())
        if key not in keys or key in selected or cfg.get("mode", "live") != "live":
            continue
        selected[key] = (path, cfg)
    now = time.time()
    drifted = False
    degraded = not units or bool(errors)
    live_shas = set()
    for unit in units:
        key = _unit_key(unit)
        path, cfg = selected.get(key, (None, {}))
        status, error = _read_json(path / "kalshi-edge-status.json") if path else ({}, "no matching run")
        if path and error:
            record_error(f"{path.name}/{error}")
        config_build, build = _block(cfg.get("build")), _block(status.get("build"))
        policy, engine = _block(status.get("policy")), _block(status.get("engine"))
        age = _age(status, path / "kalshi-edge-status.json", now) if path else None
        count = processes.get(key, 0)
        live = count >= 1 and age is not None and age < 2 * KALSHI_STATUS_INTERVAL_S
        config_sha, status_sha = _sha(config_build), _sha(build)
        if config_sha and status_sha and config_sha != status_sha:
            drifted = True
        if live and status_sha:
            live_shas.add(status_sha)
        degraded |= (not live or not config_sha or not status_sha or bool(error)
                     or bool(policy.get("error")) or bool(engine.get("error")))
        rows.append({
            "unit": unit, "run_dir": str(path) if path else None,
            "build": build, "config_build": config_build,
            "git_sha": status_sha, "dirty": build.get("dirty"),
            "processes": count, "status_age_s": age, "live": live,
            "config_digest": cfg.get("digest"), "policy_path": cfg.get("policy_path"),
            "engines_dir": cfg.get("engines_dir"), "engine_bindings": cfg.get("engine_bindings"),
            "policy_digest": policy.get("digest"), "policy_error": policy.get("error"),
            "engine_id": engine.get("engine_id"), "engine_error": engine.get("error"),
            "generated_at": status.get("generated_at"), "error": error,
        })
    code = 1 if drifted or len(live_shas) > 1 else 2 if degraded else 0
    if error_count > MAX_ERRORS:
        errors[-1] = f"... {error_count - MAX_ERRORS + 1} more errors ({error_count} total)"
    return {"rows": rows, "verdict": VERDICTS[code], "exit_code": code, "errors": errors}


def cmd_deployed(args) -> int:
    report = collect(args.runs_root)
    if args.live_units:
        if report["exit_code"] == 3:
            return 3
        for row in report["rows"]:
            if row["live"]:
                print(row["unit"])
        return 0
    if args.json:
        print(json.dumps(report, sort_keys=True))
    else:
        summary = f"{report['verdict']}: {len(report['rows'])} units"
        if report["verdict"] != "IN_SYNC":
            print(summary)
        print("unit sha12 dirty processes status_age_s config_digest12 policy_digest12 engine_id errors")
        for row in report["rows"]:
            age = row["status_age_s"]
            issues = [str(row[key]) for key in ("engine_error", "policy_error", "error") if row[key]]
            print(" ".join([
                row["unit"], str(row["git_sha"] or "-")[:12],
                str(row["dirty"]) if row["dirty"] is not None else "-",
                str(row["processes"]), f"{age:.1f}" if age is not None else "-",
                str(row["config_digest"] or "-")[:12], str(row["policy_digest"] or "-")[:12],
                str(row["engine_id"] or "-"), "; ".join(issues) or "-",
            ]))
        if report["verdict"] == "IN_SYNC":
            print(summary)
        if report.get("error"):
            print(report["error"])
        for error in report.get("errors", []):
            print(error)
    return report["exit_code"]
