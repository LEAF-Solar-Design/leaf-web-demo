"""Host-authenticated discovery and durable, lane-local runner registration.

The pending journal is committed before POST. Discovery excludes registered
lanes, so recovery always includes local journals, even when GET is empty.
Only public enrollment material and a token hash cross the network boundary.
"""
from __future__ import annotations

import base64
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import subprocess
import sys
import tempfile
import time
import urllib.request

from . import account_lane_agent as agent
from . import account_lane_sync as sync
from .private_dir import ensure_private_dir

DASHBOARD = "https://ops-dashboard-seven.vercel.app"
PROVISION_URL = DASHBOARD + "/api/kashbot/runner/provision"
WORK_URL = DASHBOARD + sync.WORK_PATH
TELEMETRY_URL = DASHBOARD + "/api/kashbot/runner/work"
LEGACY_WORK_URLS = frozenset({DASHBOARD, DASHBOARD + "/"})
LEGACY_TELEMETRY_URLS = frozenset({
    DASHBOARD + "/api/kashbot/runner/telemetry",
    DASHBOARD + "/api/kashbot/runner/work",
    DASHBOARD + "/api/kashbot/runner/work?__kashbot=telemetry",
})
ENGINE_SOURCE = Path("/etc/leafhft/engines")
# C14-A: the engine registry new lanes register in. Each lane receives a 0444 per-domain VIEW of it
# under agent.PROJECTION_ROOT, a root-owned tree outside every lane root (no lane owns an ancestor),
# plus its 0444 replay floor (<root>/<lane>/floor.json) that only this provisioner writes.
# Phase B item: the lane's engine-bindings.json stays lane-writable 0600 (push's in-process book
# lowering writes it as the lane user), and the owner's `leafhft engine set` path (cli.py ~8200)
# does not consult registry authority; both move with the phase B catalog filter.
REGISTRY_DIR = Path("/var/lib/leafhft/engine-registry")
ROOT_UID = 0
ROLES_OWNER = 0
# Outcomes that mean a lane's registry state could not be brought up to date this tick.
REGISTRY_REFUSALS = frozenset({"registry_unreadable", "register_refused", "projection_refused",
                               "projection_below_floor"})
# The operator's explicit report-only fallback: while this root-owned file exists, a lane with no
# published projection still gets its timers (phase A is report-only). Without it a lane's timers
# start only once its projection and floor are published.
REPORT_ONLY_FALLBACK = agent.CONFIG_ROOT / "REGISTRY_REPORT_ONLY"
# S7 A L3: the canonical lifecycle store (engine_ops.DEFAULT_LIFECYCLE_DIR, the owner books' store) holds
# every tenant probe record; a tenant book's outbox sits in its own lifecycle dir
# (account_lane_agent.probe_hosting_paths: STATE_ROOT/<lane>/engine-lifecycle/outbox/<engine>.json).
LIFECYCLE_DIR = Path("/var/lib/leafhft/engine-lifecycle")
LANE_LIFECYCLE_DIR = "engine-lifecycle"
# Written beside each lane's lease on every tick that published or confirmed a superseding lease
# (engine_ops registry audit reports lane_lease_stale only while it exists); never written on failure.
LEASE_PUBLISHER_HEARTBEAT = "lease-publisher.heartbeat"
# Lock contract: the publisher takes no engine_ops lock (engine-ops.lock, the registry lock). Leases are
# ordered by store_revision within a store_epoch (CanaryStore._lease_snapshot reads a consistent snapshot;
# publish_lane_lease refuses an older revision), so no owner verb, halt included, ever waits on it.
# Hot-path budget: one whole tick (harvest, one snapshot, every lane's publish and heartbeat) at 32 lanes x 30
# engines and 512 records with the real fsyncing publisher. Measured 2026-09-28 on Linux (WSL2 ext4, loaded
# host): p50 1.6-2.4 s, max 2.7-8.1 s under load, plus about 1.4 s of lazy imports in a fresh process.
# The 5 s budget includes first-call imports; loaded-host outliers can exceed it. With LEASE_S 120 s and
# a 30 s tick cadence, a slow tick costs freshness, never validity: the lease's expiry is not extended.
LEASE_TICK_BUDGET_MS = 5000
HARVEST_REFUSALS_SHOWN = 8


class ProvisionRefused(ValueError):
    """Only static errors leave this boundary."""


class CatalogLockDegraded(ProvisionRefused):
    """The catalog refreshed, but its configure lock could not be used."""

    def __init__(self, reason, refreshed):
        super().__init__(reason)
        self.refreshed = refreshed


class ProvisionClient:
    def __init__(self, *, opener=None):
        token = os.environ.get("LEAFHFT_DASHBOARD_TOKEN", "")
        if not isinstance(token, str) or not re.fullmatch(r"[A-Za-z0-9_\-\.~+/=]{16,4096}", token):
            raise ProvisionRefused("host credential refused")
        self._token = token
        self._opener = opener if opener is not None else urllib.request.build_opener(sync.NoRedirect())

    def _request(self, body=None):
        try:
            request = urllib.request.Request(PROVISION_URL,
                data=None if body is None else agent.canonical(body),
                method="GET" if body is None else "POST",
                headers={"Authorization": "Bearer " + self._token,
                         "Accept": "application/json", "Content-Type": "application/json",
                         "User-Agent": "KashbotRunner/1.0"})
            with self._opener.open(request, timeout=sync.TIMEOUT) as response:
                if (type(response.status) is not int or not 200 <= response.status < 300
                        or response.geturl() != PROVISION_URL
                        or response.headers.get_content_type() != "application/json"):
                    raise ValueError
                data = response.read(sync.MAX_BYTES + 1)
                if len(data) > sync.MAX_BYTES:
                    raise ValueError
                return agent.parse(data)
        except Exception:
            raise ProvisionRefused("provision request refused") from None

    def discover(self):
        return self._request()

    def register(self, body):
        if type(body) is not dict or set(body) != {
                "lane_id", "token_hash", "enrollment_key_id", "public_key_der"}:
            raise ProvisionRefused("registration fields refused")
        return self._request(body)


def _directory(path, *, private=True):
    path = agent.safe_path(path)
    if private:
        ensure_private_dir(path, owner=0, refusal=ProvisionRefused("unsafe provisioning directory"))
    else:
        path.mkdir(mode=0o711, exist_ok=True)
        info = path.stat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise ProvisionRefused("unsafe provisioning directory")
    # Persist the directory entry before placing durable identities inside it.
    with agent.private_parent(path) as parent:
        os.fsync(parent)
    return path


def _write(path, value):
    path = agent.safe_path(path)
    if path.exists():
        agent.read_private(path)
    agent.write_private(path, value)


def _optional(path):
    path = agent.safe_path(path)
    return agent.parse(agent.read_private(path)) if path.exists() else None


def _bindings(value):
    if type(value) is not list or len(value) > 256:
        raise ProvisionRefused("bindings refused")
    lanes, tenants = set(), set()
    for binding in value:
        if type(binding) is not dict:
            raise ProvisionRefused("binding refused")
        expected = agent.scope(binding.get("tenant_id"), binding.get("lane_id"))
        agent.check_scope(binding, expected)
        if set(binding) != set(expected) or binding["lane_id"] in lanes or binding["tenant_id"] in tenants:
            raise ProvisionRefused("duplicate account binding")
        lanes.add(binding["lane_id"])
        tenants.add(binding["tenant_id"])
    return value


def _assignments(doc):
    if (type(doc) is not dict or set(doc) != {"success", "lanes"}
            or doc["success"] is not True or type(doc["lanes"]) is not list
            or len(doc["lanes"]) > 100):
        raise ProvisionRefused("assignments refused")
    result = []
    for row in doc["lanes"]:
        if type(row) is not dict or set(row) != {"lane_id", "tenant_id"}:
            raise ProvisionRefused("assignment selectors refused")
        result.append(agent.scope(row["tenant_id"], row["lane_id"]))
    return _bindings(result)


def _request(binding):
    path = agent.LanePaths(binding["lane_id"]).config
    token = agent.read_private(path / "runner-token").decode("ascii")
    if not re.fullmatch(r"[A-Za-z0-9_-]{43,128}", token):
        raise ProvisionRefused("lane token refused")
    if token == os.environ.get("LEAFHFT_DASHBOARD_TOKEN"):
        raise ProvisionRefused("host token cannot identify a lane")
    dashboard_url = agent.read_private(path / "dashboard-url").decode("ascii")
    if dashboard_url != WORK_URL and dashboard_url not in LEGACY_WORK_URLS:
        raise ProvisionRefused("lane endpoint refused")
    return {"lane_id": binding["lane_id"], "token_hash": hashlib.sha256(token.encode()).hexdigest(),
            **agent.lane_enrollment_key(binding["lane_id"])}


def _journal_path(lane_id):
    return agent.CONFIG_ROOT / (agent.identifier(lane_id) + ".provision.json")


def _journal(path):
    doc = _optional(_journal_path(path.name))
    if doc is None:
        return None
    if (type(doc) is not dict or set(doc) != {"binding", "phase", "request"}
            or doc["phase"] not in ("preparing", "pending", "registered", "complete")):
        raise ProvisionRefused("provision journal refused")
    _bindings([doc["binding"]])
    if doc["binding"]["lane_id"] != path.name:
        raise ProvisionRefused("journal scope refused")
    if doc["phase"] == "preparing":
        if doc["request"] is not None:
            raise ProvisionRefused("journal phase refused")
    elif doc["request"] != _request(doc["binding"]):
        # Missing, changed or corrupt registered material must never be replaced.
        raise ProvisionRefused("registered material changed")
    return doc


def _inventory():
    journals, tokens, keys = {}, set(), set()
    directories = 0
    for path in sorted(agent.CONFIG_ROOT.iterdir()):
        if path.name.endswith(".provision.json"):
            lane_id = agent.identifier(path.name.removesuffix(".provision.json"))
            journals[lane_id] = _journal(agent.LanePaths(lane_id).config)
            if len(journals) > 256:
                raise ProvisionRefused("too many account lanes")
            continue
        if not agent.UUID.fullmatch(path.name):
            continue
        _directory(path)
        directories += 1
        if directories > 256:
            raise ProvisionRefused("too many account lanes")
        token_path = agent.safe_path(path / "runner-token")
        key_path = agent.safe_path(path / "enrollment-private.pem")
        if token_path.exists():
            token = agent.read_private(token_path)
            if token in tokens:
                raise ProvisionRefused("duplicate lane token")
            tokens.add(token)
        if key_path.exists():
            public = agent.lane_enrollment_key(path.name)["public_key_der"]
            if public in keys:
                raise ProvisionRefused("duplicate lane enrollment key")
            keys.add(public)
    return journals


def _prepare(binding):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    paths = agent.LanePaths(binding["lane_id"])
    _directory(paths.config)
    for name in ("runner-token", "enrollment-private.pem", "dashboard-url"):
        path = agent.safe_path(paths.config / name)
        if path.exists():
            agent.read_private(path)
            continue
        if name == "runner-token":
            data = secrets.token_urlsafe(32).encode("ascii")
        elif name == "enrollment-private.pem":
            key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
            data = key.private_bytes(serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
        else:
            data = WORK_URL.encode("ascii")
        _write(path, data)
    _directory(agent.STATE_ROOT, private=False)
    _directory(paths.state)
    _write(paths.state / "KILL", b"account not activated\n")
    # Enrollment creates config.json only after credential validation. A stub
    # would look like an existing account fingerprint to the control agent.
    _write(paths.config / "approval.json", {**binding, "approved": False})
    doc = {"binding": binding, "phase": "pending", "request": _request(binding)}
    _write(_journal_path(paths.lane_id), doc)
    return doc


def _ensure_push_config(binding):
    paths = agent.LanePaths(binding["lane_id"])
    target = agent.safe_path(paths.config / "push.json")
    dashboard_path = agent.safe_path(paths.config / "dashboard-url")
    dashboard_url = agent.read_private(dashboard_path).decode("ascii")
    if dashboard_url != WORK_URL and dashboard_url not in LEGACY_WORK_URLS:
        raise ProvisionRefused("lane endpoint refused")
    token = agent.read_private(paths.config / "runner-token").decode("ascii")
    expected = {**binding, "url": TELEMETRY_URL,
                "token": token}
    if target.exists():
        existing = agent.parse(agent.read_private(target))
        if existing == expected:
            if dashboard_url != WORK_URL:
                _write(dashboard_path, WORK_URL.encode("ascii"))
            return
        legacy = {**binding, "url": existing.get("url"), "token": token}
        if (existing != legacy or existing.get("url") not in LEGACY_TELEMETRY_URLS):
            raise ProvisionRefused("lane telemetry endpoint refused")
    # The provision lock serializes both replacements. If the host dies between
    # them, the only mixed state contains one exact old route and one exact new
    # route; the next pass converges it. No unknown value is ever overwritten.
    if dashboard_url != WORK_URL:
        _write(dashboard_path, WORK_URL.encode("ascii"))
    _write(target, expected)


def _write_public(target, data):
    """Atomic replace whose file is already 0444 when it becomes visible to lane readers."""
    with agent.private_parent(target) as parent:
        name = ".engine-" + secrets.token_hex(16)
        fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o444, dir_fd=parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                os.fchmod(stream.fileno(), 0o444)
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(name, target.name, src_dir_fd=parent, dst_dir_fd=parent)
            os.fsync(parent)
        finally:
            try:
                os.unlink(name, dir_fd=parent)
            except FileNotFoundError:
                pass


def _ensure_configure_lock(engine_dir, user):
    """Publish the lane-owned lock once; never replace an existing lock inode."""
    target = engine_dir / ".configure.lock"
    with agent.private_parent(target) as parent:
        try:
            fd = os.open(target.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o600, dir_fd=parent)
        except FileExistsError:
            info = os.stat(target.name, dir_fd=parent, follow_symlinks=False)
            if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                    or info.st_uid != user.pw_uid or stat.S_IMODE(info.st_mode) != 0o600
                    or info.st_size != 1):
                raise ProvisionRefused("engine configure lock refused")
        else:
            try:
                os.write(fd, b"\0")
                os.fchmod(fd, 0o600)
                os.fchown(fd, user.pw_uid, user.pw_gid)
                os.fsync(fd)
            finally:
                os.close(fd)
            os.fsync(parent)


def _sync_engine_catalog(binding):
    """Copy validated public engine policy into one lane, leaving its overrides private and mutable."""
    if os.name != "posix":
        return False
    import pwd
    from .engines import EngineError, EngineRegistry, _configure_lock

    paths = agent.LanePaths(binding["lane_id"])
    try:
        user = pwd.getpwnam(agent.account_user(paths.lane_id))
    except KeyError:
        return False
    registry = EngineRegistry(ENGINE_SOURCE)
    engines = registry.list()
    if not engines or registry.problems:
        raise ProvisionRefused("engine catalog refused")
    catalog = agent.safe_path(paths.state / "engine-catalog")
    engine_dir = agent.safe_path(catalog / "engines")
    # Live books traverse this catalog as the lane user on every lifecycle poll, and one
    # EACCES latches their entries off until restart. Never drop others' r-x while writing.
    writable_directories = []
    try:
        for directory in (catalog, engine_dir):
            directory.mkdir(mode=0o755, exist_ok=True)
            if directory.stat().st_uid != 0:
                raise ProvisionRefused("engine catalog ownership refused")
            os.chmod(directory, 0o755)
            writable_directories.append(directory)
        with ExitStack() as locks:
            lock_problem = None
            try:
                try:
                    _ensure_configure_lock(engine_dir, user)
                except (OSError, agent.LaneRefused) as exc:
                    raise ProvisionRefused("engine configure lock refused") from exc
                locks.enter_context(_configure_lock(EngineRegistry(engine_dir), timeout_s=1.0))
            except ProvisionRefused as exc:
                lock_problem = str(exc)
            except EngineError:
                lock_problem = "engine catalog lock busy"
            # A tenant-held or refused lock must never delay an owner's disable.
            # Refresh errors propagate independently of lock acquisition failures.
            refreshed = _refresh_engine_catalog(paths, engine_dir, engines, user)
            if lock_problem is not None:
                raise CatalogLockDegraded(lock_problem, refreshed)
            return refreshed
    finally:
        for directory in reversed(writable_directories):
            try:
                os.chmod(directory, 0o555)
            except OSError:
                pass


def _refresh_engine_catalog(paths, engine_dir, engines, user):
    """Refresh under the catalog lock when available, or unlocked to propagate policy."""
    wanted = set()
    for engine in engines:
        source = agent.safe_path(ENGINE_SOURCE / (engine.engine_id + ".json"))
        data = source.read_bytes()
        if len(data) > 65536:
            raise ProvisionRefused("engine catalog refused")
        target = agent.safe_path(engine_dir / source.name)
        wanted.add(source.name)
        # Unchanged engines are left alone: no rewrite churn, no 0600 window for readers.
        if (target.is_file() and not target.is_symlink()
                and stat.S_IMODE(target.stat().st_mode) == 0o444 and target.read_bytes() == data):
            continue
        _write_public(target, data)
    for target in engine_dir.glob("*.json"):
        if target.name not in wanted:
            target.unlink()

    mutable = {
        # No owner engine and every symbol off: entries wait for the registry to grant authority.
        paths.state / "engine-bindings.json": empty_bindings(),
        paths.state / "engine-account-overrides.json": {"schema_version": 1, "accounts": {}},
        paths.state / "dashboard-account-identity.json": {
            "schema_version": 1,
            "account_id": json.dumps(["kashbot-" + paths.lane_id, "kalshi", 0], separators=(",", ":")),
            "subaccount_number": 0,
            "verified_at": "1970-01-01T00:00:00+00:00",
        },
    }
    for target, initial in mutable.items():
        target = agent.safe_path(target)
        if not target.exists():
            agent.write_private(target, initial)
            os.chown(target, user.pw_uid, user.pw_gid)
            os.chmod(target, 0o600)
    return True


def empty_bindings():
    return {"default": None, "symbols": {}, "disabled": list(agent.canonical_symbols())}


def lane_domain(lane_id):
    return "account-lane:" + agent.identifier(lane_id)


def _load_registry():
    """The committed registry generation (chain-verified), or None when none was ever written."""
    from . import engine_registry
    return engine_registry.RegistryStore(REGISTRY_DIR).load()


def _member_key(lane_id):
    """The distinctness witness input provisioning holds: the lane's durable key, digested in-process
    and never printed. Without a D7 attestation the member holds no authority."""
    der = base64.b64decode(agent.lane_enrollment_key(lane_id)["public_key_der"], validate=True)
    return "lane-" + hashlib.sha256(b"leafhft-exposure-member:" + der).hexdigest()[:40]


def _register_exit_only(registry, lane_id):
    """Register a lane the registry does not know as an exit_only domain (X1 `exposure register`
    under one CAS). A domain the registry already holds is left exactly as it is."""
    from . import exposure_authority

    domain = lane_domain(lane_id)
    if any(account["domain"] == domain for account in registry.accounts.values()):
        return registry, False
    member = _member_key(lane_id)

    def change(doc):
        members = doc["exposure"]["members"]
        if member not in members:
            # A new member with no authority domain: register below can only add it exit_only.
            members[member] = {"authority_domain": None, "transfer": None}
        return exposure_authority.apply_register(
            doc, lane_id, domain=domain, kind="tenant", label="Kashbot lane " + lane_id[:8],
            lane_id=lane_id, member_key=member)

    registry, _ = exposure_authority.mutate_exposure(
        REGISTRY_DIR, expect=(registry.generation, registry.digest), action="exposure.register",
        registry_change=change, roles_dir=exposure_authority.recorded_roles_dir(REGISTRY_DIR),
        owner=ROLES_OWNER, request_id="lane-register-" + lane_id, actor="account-provision")
    if registry.exit_only(lane_id) is not True:
        raise ProvisionRefused("lane registration refused")
    return registry, True


def registry_projection_path(lane_id):
    return agent.registry_projection_path(agent.LanePaths(lane_id))


def _trusted_ancestors(path):
    """Refuse a projection tree any non-root user could rename: every ancestor above it is owned by
    root and is never group- or world-writable without the sticky bit."""
    if os.name != "posix":
        return
    for part in Path(path).parents:
        info = os.lstat(part)
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid not in (0, ROOT_UID)
                or (info.st_mode & 0o022 and not info.st_mode & stat.S_ISVTX)):
            raise ProvisionRefused("registry projection ancestor refused")


def _projection_current(target, data):
    """True when `target` is already the root-owned 0444 regular file holding exactly `data`."""
    try:
        info = os.lstat(target)
    except FileNotFoundError:
        return False
    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != ROOT_UID
            or info.st_size != len(data)
            or (os.name == "posix" and stat.S_IMODE(info.st_mode) != 0o444)):
        return False
    with open(target, "rb") as stream:
        return stream.read(len(data) + 1) == data


def _publish(target, data):
    """Atomically replace `target` (in an already-checked root-owned directory) with `data`, 0444 on
    POSIX. "unchanged" when the bytes are already there, so readers see no churn."""
    if _projection_current(target, data):
        return "unchanged"
    if os.name == "posix":
        _write_public(target, data)
    else:
        # No POSIX modes here: a read-only file would refuse the next os.replace.
        fd, name = tempfile.mkstemp(prefix=".engine-", dir=target.parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(name, target)
        finally:
            Path(name).unlink(missing_ok=True)
    return "written"


def _lane_directory_staging(info, lane_id):
    """Only root's staging directory or this lane's interrupted creation is repairable."""
    if info.st_uid != ROOT_UID or stat.S_IMODE(info.st_mode) != 0o700:
        return False
    if info.st_gid == 0:
        return True
    try:
        return info.st_gid == agent.lane_gid(lane_id)
    except agent.LaneRefused:
        return False


def _write_projection(lane_id, data):
    """Write the lane's view under PROJECTION_ROOT/<lane>/engine-registry/: root-owned 0444 in
    a trusted lane directory, never inside the lane root (the tenant owns
    that directory and could rename or replay anything in it). Rewritten only when the bytes differ,
    so a generation bump lands on the next tick."""
    paths = agent.LanePaths(lane_id)
    if not agent.safe_path(paths.state).is_dir():
        return "lane_root_absent"
    target = agent.safe_path(registry_projection_path(lane_id))
    directory = target.parent
    _trusted_ancestors(agent.PROJECTION_ROOT)
    for level in (agent.PROJECTION_ROOT, directory.parent, directory):
        lane_level = level == directory.parent
        created = False
        try:
            level.mkdir(mode=0o700 if lane_level else 0o755)
            created = True
        except FileExistsError:
            pass
        info = os.lstat(level)
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != ROOT_UID:
            raise ProvisionRefused("registry projection ownership refused")
        if os.name == "posix":
            fd = os.open(level, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                info = os.fstat(fd)
                if info.st_uid != ROOT_UID:
                    raise ProvisionRefused("registry projection ownership refused")
                if lane_level:
                    staging = _lane_directory_staging(info, lane_id)
                    if not (agent.lane_dir_mode_ok(info, lane_id)
                            or staging or created):
                        raise ProvisionRefused("registry projection lane mode refused")
                    # Bootstrap precedes useradd. Publish in the legacy mode even when
                    # the account is unresolved; the independent tick step converts it.
                    if created or staging:
                        os.fchmod(fd, 0o755)
                        if created and ROOT_UID == 0 and info.st_gid != 0:
                            os.fchown(fd, ROOT_UID, 0)
                else:
                    os.fchmod(fd, 0o755)
            finally:
                os.close(fd)
    return _publish(target, data)


def _reconcile_lane_directory(lane_id):
    """Best-effort migration on every tick, independent of registry publication."""
    if os.name != "posix":
        return "unsupported"
    try:
        directory = agent.safe_path(agent.PROJECTION_ROOT / agent.identifier(lane_id))
        _trusted_ancestors(directory)
        fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            info = os.fstat(fd)
            staging = _lane_directory_staging(info, lane_id)
            if info.st_uid != ROOT_UID or not (staging or agent.lane_dir_mode_ok(info, lane_id)):
                return "refused"
            try:
                gid = agent.lane_gid(lane_id)
            except agent.LaneRefused:
                if staging:
                    os.fchmod(fd, 0o755)
                return "lane_user_unresolved"
            if stat.S_IMODE(info.st_mode) == 0o750 and info.st_gid == gid:
                return "unchanged"
            # A crash between these calls leaves a valid 0755 root:lane-group directory.
            if staging:
                os.fchmod(fd, 0o755)
            os.fchown(fd, ROOT_UID, gid)
            os.fchmod(fd, 0o750)
            return "converted"
        finally:
            os.close(fd)
    except FileNotFoundError:
        return "absent"
    except Exception:
        return "refused"


def registry_projection_floor_path(lane_id):
    return agent.registry_projection_floor_path(agent.LanePaths(lane_id))


def _published_floor(lane_id):
    """The lane's root-owned replay floor, None when none was ever published. Raises on a floor that
    is not a single-link root-owned regular file or does not parse: never silently treated as zero."""
    target = agent.safe_path(registry_projection_floor_path(lane_id))
    try:
        info = os.lstat(target)
    except FileNotFoundError:
        return None
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != ROOT_UID:
        raise ProvisionRefused("registry projection floor refused")
    with open(target, "rb") as stream:
        return agent.parse_projection_floor(stream.read(agent.PROJECTION_FLOOR_MAX + 1), lane_id)


def _write_floor(lane_id, generation):
    """Publish the lane's replay floor beside its projection directory (PROJECTION_ROOT/<lane>/
    floor.json, 0444). Only the root provisioner writes it; the lane only reads it. Called after the
    projection is in place, so a reader never sees a floor above the projection it can read."""
    target = agent.safe_path(registry_projection_floor_path(lane_id))
    return _publish(target, agent.projection_floor_bytes(lane_id, generation))


def _publish_lane(registry, lane_id, data, *, report=None):
    """Projection and breakers then floor from one snapshot. A snapshot below the floor
    already published is `projection_below_floor` and writes nothing: the floor never goes down."""
    from . import engine_registry

    breakers = engine_registry.breakers_view_bytes(registry, lane_domain(lane_id))
    floor = _published_floor(lane_id)
    if floor is not None and floor > registry.generation:
        if report is not None:
            report["breakers"] = "projection_below_floor"
        return "projection_below_floor"
    outcome = _write_projection(lane_id, data)
    if outcome in ("written", "unchanged"):
        breaker_outcome = _publish(
            agent.safe_path(registry_projection_path(lane_id)).with_name(engine_registry.BREAKERS_VIEW_FILE),
            breakers)
        if report is not None:
            report["breakers"] = breaker_outcome
        _write_floor(lane_id, registry.generation)
    elif report is not None:
        report["breakers"] = outcome
    return outcome


def _register_reconciled(registry, lane_id):
    """(registry, outcome, fresh). A refused CAS means the snapshot in hand may be stale, so the
    committed registry is reloaded and registration retried once against it. `fresh` is False when
    that reload failed or the retry was refused too: the shared snapshot is then not known current,
    so the caller publishes nothing from it to ANY lane and the next tick reloads."""
    try:
        registry, registered = _register_exit_only(registry, lane_id)
        return registry, "registered" if registered else "known", True
    except Exception:
        pass
    try:
        reloaded = _load_registry()
        if reloaded is None:
            raise ProvisionRefused("registry vanished")
    except Exception:
        return registry, "register_refused", False
    try:
        reloaded, registered = _register_exit_only(reloaded, lane_id)
        return reloaded, "registered" if registered else "known", True
    except Exception:
        return reloaded, "register_refused", False


def sync_registry(bindings):
    """C14-A phase A, report-only. Register every bound lane the registry does not know as an
    exit_only domain, then write each lane its own per-domain view (`projection_for`: no member_key,
    no other lane's data) and its replay floor. Returns {lane_id: {"register": outcome, "projection":
    outcome}}; one lane's failure never stops provisioning, and a lane whose projection is missing
    fails closed at its readers. A refused CAS reloads before anything is published; a second
    refusal (or a failed reload) invalidates the shared snapshot for EVERY lane in this sync, so each
    keeps its previous projection (`unchanged`) and the next tick reloads."""
    from . import engine_registry

    lanes = [agent.identifier(binding["lane_id"]) for binding in bindings]
    try:
        registry = _load_registry()
    except Exception:
        return {lane_id: {"register": "registry_unreadable", "projection": "registry_unreadable"}
                for lane_id in lanes}
    if registry is None:
        return {lane_id: {"register": "registry_absent", "projection": "registry_absent"} for lane_id in lanes}
    report, fresh = {}, True
    for lane_id in lanes:
        registry, outcome, reloaded = _register_reconciled(registry, lane_id)
        fresh = fresh and reloaded
        report[lane_id] = {"register": outcome}
    for lane_id in lanes:
        if not fresh:
            # Never publish from a snapshot a refused CAS may have proved stale: every view stays.
            report[lane_id]["projection"] = "unchanged"
            continue
        try:
            data = engine_registry.projection_bytes(registry, lane_domain(lane_id))
        except engine_registry.RegistryError:
            report[lane_id]["projection"] = "domain_unregistered"
            continue
        try:
            report[lane_id]["breakers"] = "breakers_refused"
            report[lane_id]["projection"] = _publish_lane(registry, lane_id, data, report=report[lane_id])
        except Exception:
            report[lane_id]["projection"] = "projection_refused"
    return report


DASHBOARD_ACCOUNTS_FILE = "dashboard-accounts.json"
DASHBOARD_ACCOUNTS_SCHEMA = "leafhft.lane-dashboard-accounts.v1"


def publish_dashboard_accounts(bindings):
    """Publish public account ids from root identities; failures never interrupt the tick."""
    try:
        lanes = {}
        for binding in bindings:
            try:
                lane_id = agent.identifier(binding["lane_id"])
                path = agent.lane_identity_path(agent.LanePaths(lane_id))
                if os.name == "posix" and os.lstat(path).st_uid != ROOT_UID:
                    continue
                data = agent._read_root_public(path)
                if data is None or len(data) > agent.LANE_IDENTITY_MAX:
                    continue
                identity = agent.parse(data)
                if not isinstance(identity, dict) or not isinstance(identity.get("account_id"), str):
                    continue
                account_id = identity["account_id"]
                account = json.loads(account_id)
                if (not isinstance(account, list) or len(account) != 3
                        or account[0] != "kashbot-" + lane_id
                        or not isinstance(account[1], str) or not account[1]
                        or type(account[2]) is not int or account[2] < 0):
                    continue
                lanes[lane_id] = account_id
            except Exception:
                continue
        target = agent.safe_path(agent.PROJECTION_ROOT / DASHBOARD_ACCOUNTS_FILE)
        _trusted_ancestors(agent.PROJECTION_ROOT)
        agent.PROJECTION_ROOT.mkdir(mode=0o755, exist_ok=True)
        _trusted_ancestors(target)
        data = json.dumps({"schema": DASHBOARD_ACCOUNTS_SCHEMA, "lanes": lanes},
                          sort_keys=True, separators=(",", ":")).encode()
        return {"dashboard_accounts": _publish(target, data)}
    except Exception:
        return {"dashboard_accounts": "publish_refused"}


def _lane_account(registry, lane_id):
    """The one registry account key of the lane's domain; None when there is none or several (build_lease
    then refuses that lane's lease by name)."""
    domain = lane_domain(lane_id)
    keys = [key for key, account in registry.accounts.items()
            if account.get("lane_id") == lane_id and account.get("domain") == domain]
    return keys[0] if len(keys) == 1 else None


def _lane_uid(lane_id):
    """The uid read_outbox requires of the lane's outbox files: the owner of STATE_ROOT/<lane>, which must be
    a real directory (lstat, never a symlink) owned by a non-zero uid. None otherwise: nothing is harvested."""
    try:
        info = os.lstat(agent.STATE_ROOT / agent.identifier(lane_id))
    except Exception:
        return None
    if not stat.S_ISDIR(info.st_mode) or info.st_uid == 0:
        return None
    return info.st_uid


def _harvest_lane(lease, born_as, store, lane_id, key, engine_ids, now):
    """Fold the lane's book-exported restrictions into the canonical store: (outcome, applied, refusals).

    Reads exactly STATE_ROOT/<lane>/engine-lifecycle/outbox/<engine>.json for each engine the registry
    assigns to the lane's account, by read_outbox's dir_fd walk as root (never a listing), and applies it with
    CanaryStore.restrict under the store owner's uid. restrict can only halt, suspend or trip, and writes
    nothing on an authorization_ref mismatch (harvest_stale_ref). A record that is not the lane's
    (account_id other than the lane's registry key) is never touched. One engine's refusal never stops the
    next; outbox_absent is the ordinary case, not a refusal."""
    uid = _lane_uid(lane_id)
    if uid is None:
        return "lane_root_untrusted", 0, {}
    applied, refusals = 0, {}
    for engine_id in engine_ids:
        facts = lease.read_outbox(agent.STATE_ROOT, (lane_id, LANE_LIFECYCLE_DIR), engine_id, uid, now=now)
        if isinstance(facts, lease.OutboxRefusal):
            if facts.code != lease.OUTBOX_ABSENT:
                refusals[engine_id] = facts.code
            continue
        if not facts.halt_reasons and facts.suspend_until is None and not facts.trips:
            continue
        try:
            with born_as(LIFECYCLE_DIR):
                before = store.optional(engine_id)
                if before is None or before.get("account_id") != key:
                    refusals[engine_id] = "harvest_record_not_lane"
                    continue
                after = store.restrict(engine_id, authorization_ref=facts.authorization_ref,
                                       halt_reasons=facts.halt_reasons, suspend_until=facts.suspend_until,
                                       trips=facts.trips, now=now)
        except Exception:
            refusals[engine_id] = "harvest_restrict_failed"
            continue
        if after is None:
            refusals[engine_id] = "harvest_stale_ref"
        elif after.get("snapshot_digest") != before.get("snapshot_digest"):
            applied += 1
    return ("refused" if refusals else "ok"), applied, refusals


def _write_heartbeat(lease_module, lane_id, lease):
    """PROJECTION_ROOT/<lane>/LEASE_PUBLISHER_HEARTBEAT, root-owned 0444 by temp, fsync and replace in the
    lane directory publish_lane_lease just trusted (opened by dir_fd with O_NOFOLLOW, re-checked here)."""
    root = agent.PROJECTION_ROOT
    if not stat.S_ISDIR(os.lstat(root).st_mode):
        raise ProvisionRefused("projection root refused")
    root_fd = os.open(root, lease_module._DIR_FLAGS)
    try:
        lane_fd = os.open(lane_id, lease_module._DIR_FLAGS, dir_fd=root_fd)
        try:
            if not lease_module.lane_dir_trusted(os.fstat(lane_fd), ROOT_UID, lane=lane_id):
                raise ProvisionRefused("lease lane directory refused")
            lease_module._write_at(lane_fd, LEASE_PUBLISHER_HEARTBEAT,
                                   f"{lease.lease_seq} {lease.valid_until}\n".encode("ascii"))
        finally:
            os.close(lane_fd)
    finally:
        os.close(root_fd)


def publish_leases(bindings, *, now=None):
    """S7 A L3, every provision tick after sync_registry: harvest each lane's book restrictions into the
    canonical lifecycle store, then publish each lane its lifecycle lease and probe bindings.

    Takes no engine_ops lock (see LEASE_TICK_BUDGET_MS): store_revision orders leases within a store_epoch.
    1. harvest every lane (_harvest_lane; CanaryStore.restrict takes the store flock itself);
    2. ONE bounded CanaryStore._lease_snapshot: records, epoch and revision in one consistent read,
       taken after every harvest, so each harvested restriction goes out in this tick's lease;
    3. per lane, build_lease from that snapshot and publish_lane_lease (whose store_revision floor refuses
       an older snapshot within the epoch), then the heartbeat. Epoch resets are included in the lane report.
    An owner verb (a halt) that commits after step 2 advances the store revision: this tick's lease may
    predate it, the next tick's carries it, and this tick's older snapshot can never overwrite a lease a
    newer snapshot already published. A stale refusal counts as "superseded" only after reading a live
    lease in the same epoch at or above this snapshot's revision; that lease gets the heartbeat.
    Otherwise the refusal remains a lane failure. A busy snapshot skips publication until the next tick.
    A lane with no probes still gets a valid lease
    with engines {}. Each lane is isolated: a failure is lanes[lane]["harvest"] or ["lease"] = <code> and
    never stops another lane, the same lane's publish (a harvest refusal still publishes) or any owner verb.
    Every failure fails closed for tenant ENTRY: no lease is written and the last one ages out within
    LEASE_S. The owner books, the incumbent and owner records are never touched. Returns {"lanes": {lane:
    {...}}, "tick": outcome (including failing lane ids), "superseded": count, "tick_ms": the whole tick, "budget_ms":
    LEASE_TICK_BUDGET_MS}. Never raises."""
    result = {"lanes": {}, "tick": None, "superseded": 0, "tick_ms": None, "budget_ms": LEASE_TICK_BUDGET_MS}
    started = time.perf_counter()
    try:
        lanes = [agent.identifier(binding["lane_id"]) for binding in bindings]
        result["lanes"] = {lane_id: {} for lane_id in lanes}
        if not lanes:
            result["tick"] = "no_lanes"
            return result
        if not REGISTRY_DIR.is_dir():
            return _every(result, "lease", "registry_absent")
        from . import engine_ops
        _lease_tick(result, lanes, engine_ops._born_as, now)
    except Exception:
        result["tick"] = "lease_tick_failed"
    finally:
        result["tick_ms"] = round((time.perf_counter() - started) * 1000, 3)
    return result


def _every(result, field, code):
    for row in result["lanes"].values():
        row[field] = code
    result["tick"] = code
    return result


def _lease_tick(result, lanes, born_as, now):
    """publish_leases' body; holds no lock of its own."""
    from . import engine_registry
    from . import lifecycle_lease as lease
    from .canary import CanaryStore, LifecycleBusy

    now = datetime.now(timezone.utc) if now is None else now
    try:
        registry = engine_registry.RegistryStore(REGISTRY_DIR).load(complete_publication=False)
    except Exception:
        return _every(result, "lease", "registry_unreadable")
    if registry is None:
        return _every(result, "lease", "registry_absent")
    store = CanaryStore(LIFECYCLE_DIR) if LIFECYCLE_DIR.is_dir() else None
    by_account = {}
    for engine_id in sorted(registry.assignments):
        by_account.setdefault(registry.assignments[engine_id].get("account_id"), []).append(engine_id)
    for lane_id in lanes:
        row = result["lanes"][lane_id]
        key = _lane_account(registry, lane_id)
        if key is None:
            row["harvest"] = "lane_account_missing"
            continue
        if store is None:
            row["harvest"] = "lifecycle_store_absent"
            continue
        try:
            outcome, applied, refusals = _harvest_lane(lease, born_as, store, lane_id, key,
                                                       by_account.get(key, ()), now)
        except Exception:
            outcome, applied, refusals = "harvest_failed", 0, {}
        row["harvest"] = outcome
        if applied:
            row["harvest_applied"] = applied
        if refusals:
            row["harvest_refusals"] = dict(sorted(refusals.items())[:HARVEST_REFUSALS_SHOWN])
    try:
        if store is None:
            return _every(result, "lease", "lifecycle_store_absent")
        with born_as(LIFECYCLE_DIR):
            epoch, revision, records = store._lease_snapshot()
    except LifecycleBusy:
        return _every(result, "lease", "snapshot_busy")
    except Exception:
        return _every(result, "lease", "lease_snapshot_failed")
    if revision is None:
        return _every(result, "lease", lease.LEASE_REVISION_UNKNOWN)
    for lane_id in lanes:
        row = result["lanes"][lane_id]
        lease_doc = None
        try:
            lease_doc, bindings_doc = lease.build_lease(registry, records, lane_id, lane_domain(lane_id), now,
                                                        lease.LEASE_S, store_revision=revision, store_epoch=epoch)
            published_lease = lease.publish_lane_lease(agent.PROJECTION_ROOT, lane_id, lease_doc, bindings_doc,
                                                       owner_uid=ROOT_UID, report=row)
        except lease.LeaseError as exc:
            row["lease"] = exc.code
            if exc.code != lease.LEASE_STALE_SNAPSHOT or lease_doc is None:
                continue
            try:
                published_lease = lease.LeaseReader(
                    agent.PROJECTION_ROOT / lane_id / lease.LEASE_NAME, lane=lane_id,
                    domain=lane_domain(lane_id), book_account_id=lease_doc["book_account_id"],
                    owner_uid=ROOT_UID).current()
            except Exception:
                published_lease = None
            if (published_lease is None or published_lease.store_epoch != epoch
                    or published_lease.store_revision < revision):
                continue
            row["lease"] = "superseded"
            result["superseded"] += 1
        except Exception:
            row["lease"] = "lease_publish_failed"
            continue
        else:
            row["lease"] = "published"
        row.update(lease_seq=published_lease.lease_seq, engines=len(published_lease.grants),
                   store_epoch=published_lease.store_epoch, store_revision=published_lease.store_revision)
        try:
            _write_heartbeat(lease, lane_id, published_lease)
            row["heartbeat"] = "written"
        except Exception:
            row["heartbeat"] = "heartbeat_failed"
    failures = [lane_id for lane_id in lanes
                if result["lanes"][lane_id]["lease"] not in {"published", "superseded"}
                or result["lanes"][lane_id].get("heartbeat") == "heartbeat_failed"]
    result["tick"] = "failed:" + ",".join(failures) if failures else "published"
    return result


def entry_authority(lane_id, *, projection=None):
    """(True, None) only when the committed registry names the lane's domain as its member's
    authority; otherwise (False, static reason). Fails closed on every read problem. `projection`
    (the lane's monotonic RegistryProjection reader) answers for a caller that cannot read the
    registry itself, the lane user under leafhft-account-push@."""
    domain = lane_domain(lane_id)
    if projection is not None:
        exit_only = projection.exit_only(domain)
        if exit_only is None:
            return False, ("projection_replayed" if projection.error == "projection_replayed"
                           else "projection_unreadable")
        return (False, "domain_exit_only") if exit_only else (True, None)
    try:
        registry = _load_registry()
    except Exception:
        return False, "registry_unreadable"
    if registry is None:
        return False, "registry_absent"
    accounts = [account for account in registry.accounts.values() if account["domain"] == domain]
    if not accounts:
        return False, "domain_unregistered"
    if accounts[0]["exit_only"] is not False:
        return False, "domain_exit_only"
    return True, None


def _lane_owner(lane_id):
    """(uid, gid) of the lane's service account on POSIX, None elsewhere."""
    if os.name != "posix":
        return None
    import pwd
    try:
        user = pwd.getpwnam(agent.account_user(lane_id))
    except KeyError:
        raise ProvisionRefused("account user missing") from None
    return user.pw_uid, user.pw_gid


def require_entry_authority(lane_id, *, projection=None):
    """Raise ProvisionRefused("entries refused: <registry reason>") unless the lane's domain holds
    exposure authority. The first step of enable_entries, and the whole check for an enabling row
    that names no symbol (engine.configure enabled:true)."""
    allowed, reason = entry_authority(lane_id, projection=projection)
    if not allowed:
        raise ProvisionRefused("entries refused: " + reason)


_NO_OWNER = object()


def lane_bindings(lane_id, *, owner=_NO_OWNER):
    """The lane's validated engine-bindings.json document (read-only; `disabled` may be absent)."""
    owner = _lane_owner(lane_id) if owner is _NO_OWNER else owner
    path = agent.safe_path(agent.LanePaths(lane_id).state / "engine-bindings.json")
    doc = agent.parse(agent.read_private(path, owner=0 if owner is None else owner[0]))
    if (type(doc) is not dict or set(doc) not in ({"default", "symbols"}, {"default", "symbols", "disabled"})
            or type(doc.get("disabled", [])) is not list):
        raise ProvisionRefused("lane bindings refused")
    return doc


def enable_entries(lane_id, symbols, *, projection=None):
    """Turn entries back on for `symbols` in the lane's bindings. Refused with the reason until the
    registry grants the lane's domain exposure authority (a new lane is exit_only). The lane agent's
    control applier calls it for a book.configure enabled:true only after push's original applier
    passed every one of its checks (account_lane_agent.enable_book_in_lane)."""
    require_entry_authority(lane_id, projection=projection)
    known = agent.canonical_symbols()
    wanted = set(symbols)
    if not wanted or not wanted <= set(known):
        raise ProvisionRefused("entry symbols refused")
    owner = _lane_owner(lane_id)
    path = agent.safe_path(agent.LanePaths(lane_id).state / "engine-bindings.json")
    doc = lane_bindings(lane_id, owner=owner)
    doc = {**doc, "disabled": [symbol for symbol in known if symbol in doc.get("disabled", []) and symbol not in wanted]}
    agent.write_private(path, doc)
    if owner is not None:
        os.chown(path, *owner)
        os.chmod(path, 0o600)
    return doc


def _enable(lane_id):
    agent.identifier(lane_id)
    for unit in ("leafhft-account-agent.timer",
                 "leafhft-account-sync@" + lane_id + ".timer",
                 "leafhft-account-push@" + lane_id + ".timer"):
        subprocess.run(["/usr/bin/systemctl", "enable", "--now", unit], check=True,
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=90, env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin"})

    # An older host may not have the deposits unit yet. It must never block lane controls.
    try:
        subprocess.run(["/usr/bin/systemctl", "enable", "--now", "leafhft-account-deposits.timer"],
            check=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=90, env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin"})
    except Exception as exc:
        print(f"Account lane {lane_id} deposits timer enable failed: {type(exc).__name__}.",
              file=sys.stderr, flush=True)


def _reconcile_live_ledgers(bindings, journals):
    """Read-only export has no trading-readiness gate.

    A lane remains provisioned while its durable binding OR recovery journal
    exists. Empty discovery, paused books and missing registry projections are
    never retirement. Only removal of both durable records retires this timer.
    """
    active = {agent.identifier(binding["lane_id"]) for binding in bindings}
    retained = active | set(journals)
    deadline = time.monotonic() + 15

    def run(argv, **kwargs):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise subprocess.TimeoutExpired(argv, 15)
        return subprocess.run(argv, stdin=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                              timeout=min(15, remaining),
                              env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin"}, **kwargs)

    template = "leafhft-account-live-ledger@.timer"
    installed = run(
        ["/usr/bin/systemctl", "list-unit-files", "--no-legend", "--no-pager", template],
        stdout=subprocess.PIPE, text=True, check=False)
    if installed.returncode or not any(row.split()[:1] == [template] for row in installed.stdout.splitlines()):
        return  # The template may not be installed yet during deployment.
    # systemd lists only the template row in list-unit-files, never an enabled instance, so instances
    # come from list-units and their enablement from ONE batched is-enabled (one state per argument).
    listed = run(
        ["/usr/bin/systemctl", "list-units", "--all", "--plain", "--no-legend", "--no-pager",
         "leafhft-account-live-ledger@*.timer"],
        stdout=subprocess.PIPE, text=True, check=True)
    loads = {}
    for row in listed.stdout.splitlines():
        fields = row.split()
        match = re.fullmatch(r"leafhft-account-live-ledger@([0-9a-f-]+)\.timer", fields[0]) if fields else None
        if match and agent.UUID.fullmatch(match[1]):
            loads[match[1]] = fields[1] if len(fields) > 1 else ""
    lanes = sorted(active | set(loads))
    if not lanes:
        return
    units = ["leafhft-account-live-ledger@" + lane_id + ".timer" for lane_id in lanes]
    reply = run(["/usr/bin/systemctl", "is-enabled", *units], stdout=subprocess.PIPE, text=True, check=False)
    replies = reply.stdout.splitlines()
    if len(replies) != len(units):
        return  # Unreadable enablement: never enable or disable on a guess.
    states = {lane_id: state.strip() for lane_id, state in zip(lanes, replies)}
    for lane_id, unit in zip(lanes, units):
        if lane_id in active and states[lane_id] not in {"enabled", "enabled-runtime"}:
            run(["/usr/bin/systemctl", "enable", "--now", "--no-reload", unit],
                stdout=subprocess.DEVNULL, check=True)
    for lane_id, unit in zip(lanes, units):
        # A loaded timer for a retired lane is stopped even when its enablement reads otherwise.
        if lane_id in loads and lane_id not in retained and (
                states[lane_id] in {"enabled", "enabled-runtime", "linked", "linked-runtime"}
                or loads[lane_id] == "loaded"):
            run(["/usr/bin/systemctl", "disable", "--now", "--no-reload", unit],
                stdout=subprocess.DEVNULL, check=True)


def _provision_once(client):
    sync._require_root()
    _directory(agent.CONFIG_ROOT, private=False)
    with sync._lane_lock(agent.CONFIG_ROOT / "provision.lock"):
        bindings = _optional(agent.CONFIG_ROOT / "bindings.json")
        bindings = _bindings([] if bindings is None else bindings)
        journals = _inventory()
        assignments = _assignments(client.discover())
        merged = {b["lane_id"]: b for b in bindings}
        for binding in [j["binding"] for j in journals.values()] + assignments:
            if binding["lane_id"] in merged and merged[binding["lane_id"]] != binding:
                raise ProvisionRefused("account reassignment refused")
            merged[binding["lane_id"]] = binding
        _bindings(list(merged.values()))
        for binding in assignments:
            lane_id = binding["lane_id"]
            if lane_id in journals:
                continue
            path = agent.LanePaths(lane_id).config
            if path.exists() or any(b["lane_id"] == lane_id for b in bindings):
                raise ProvisionRefused("unmanaged lane refused")
            doc = {"binding": binding, "phase": "preparing", "request": None}
            # The intent precedes even mkdir, so a crash never strands an
            # unjournaled directory or permits replacement of registered keys.
            _write(_journal_path(lane_id), doc)
            journals[lane_id] = doc
        # Prepare the whole batch and check identities before sending any POST.
        for lane_id, doc in journals.items():
            if doc["phase"] == "preparing":
                journals[lane_id] = _prepare(doc["binding"])
        _inventory()
        completed = 0
        registered = {}
        for lane_id, doc in journals.items():
            path = _journal_path(lane_id)
            if doc["phase"] == "complete":
                if doc["binding"] not in bindings:
                    raise ProvisionRefused("durable binding missing")
                continue
            if doc["phase"] == "pending":
                reply = client.register(doc["request"])
                expected = {"success": True, "lane_id": lane_id,
                            "enrollment_key_id": doc["request"]["enrollment_key_id"], "provisioned": True}
                if (type(reply) is not dict or set(reply) != set(expected)
                        or any(type(reply[k]) is not type(v) or reply[k] != v for k, v in expected.items())):
                    raise ProvisionRefused("registration acknowledgement refused")
                doc = {**doc, "phase": "registered"}
                _write(path, doc)
            if doc["binding"] not in bindings:
                bindings = _bindings([*bindings, doc["binding"]])
                _write(agent.CONFIG_ROOT / "bindings.json", bindings)
            registered[lane_id] = doc
        # Every tick, and BEFORE any trading timer starts, so a lane never runs a tick without its projection
        # and a registry generation bump reaches every lane on the next pass.
        report = sync_registry(bindings)
        publish_dashboard_accounts(bindings)
        for lane_id, outcome in report.items():
            outcome["lane_directory"] = _reconcile_lane_directory(lane_id)
            if REGISTRY_REFUSALS & set(outcome.values()):
                print("Account lane " + lane_id + " registry sync refused.", file=sys.stderr)
        # S7 A L3: after the projection and breakers publish, harvest then lease, every tick. It never
        # raises; a lane it could not publish keeps no lease past LEASE_S, so its tenant probes stop entering.
        publish_leases(bindings)
        startable = _startable_lanes(report)
        for lane_id, doc in registered.items():
            if lane_id not in startable:
                continue  # stays `registered`: the next tick completes it once its projection lands
            _write(agent.CONFIG_ROOT / "ENABLED", b"account control enabled\n")
            _enable(lane_id)
            _write(_journal_path(lane_id), {**doc, "phase": "complete"})
            completed += 1
        degraded = []
        for binding in bindings:
            _ensure_push_config(binding)
            try:
                refreshed = _sync_engine_catalog(binding)
            except CatalogLockDegraded as exc:
                print("Account lane " + binding["lane_id"] + ": " + str(exc), file=sys.stderr)
                degraded.append(binding["lane_id"])
                refreshed = exc.refreshed
            except ProvisionRefused as exc:
                print("Account lane " + binding["lane_id"] + ": " + str(exc), file=sys.stderr)
                degraded.append(binding["lane_id"])
                continue
            if refreshed and binding["lane_id"] in startable:
                _enable(binding["lane_id"])
        # Reporting must never delay publication of registry revocations or lane configuration.
        try:
            _reconcile_live_ledgers(bindings, journals)
        except Exception:
            print("Account live ledger reconcile failed.", file=sys.stderr)
        if degraded:
            raise ProvisionRefused("account lanes degraded: " + ", ".join(degraded))
        return completed


def _projection_published(lane_id):
    """True when the lane's projection and its replay floor are both in the root-owned tree."""
    return (agent.safe_path(registry_projection_path(lane_id)).is_file()
            and agent.safe_path(registry_projection_floor_path(lane_id)).is_file())


def _startable_lanes(report):
    """The lanes whose timers may start this tick: those with a published projection and floor, or
    every lane while the operator's REPORT_ONLY_FALLBACK file exists. Each refusal is logged with the
    lane's sync outcome, so a failed first sync never starts a lane's books."""
    fallback = agent.safe_path(REPORT_ONLY_FALLBACK).exists()
    startable = set()
    for lane_id, outcome in report.items():
        if _projection_published(lane_id):
            startable.add(lane_id)
        elif fallback:
            startable.add(lane_id)
            print("Account lane " + lane_id + " starting without a registry projection: operator "
                  "report-only fallback (" + outcome["register"] + ", " + outcome["projection"] + ").",
                  file=sys.stderr)
        else:
            print("Account lane " + lane_id + " timers refused: no registry projection ("
                  + outcome["register"] + ", " + outcome["projection"] + ").", file=sys.stderr)
    return startable


def provision_once(client=None):
    try:
        return _provision_once(ProvisionClient() if client is None else client)
    except Exception as error:
        raise ProvisionRefused("account provisioning refused") from error


def main(argv=None):
    try:
        if (sys.argv[1:] if argv is None else argv):
            raise ProvisionRefused("provision selectors refused")
        provision_once()
        return 0
    except Exception:
        print("Account provisioning refused.", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
