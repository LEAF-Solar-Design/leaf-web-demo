"""Bounded checkpoint files shared by the Gold and portfolio paper runners."""
from __future__ import annotations

import base64
from pathlib import Path, PurePosixPath

MAX_CHECKPOINT_BYTES = 64 * 1024 * 1024


def safe_path(root, name):
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or any(p in ('.', '..') for p in path.parts) or '\\' in name or ':' in name:
        raise ValueError('invalid checkpoint path')
    target = Path(root).joinpath(*path.parts)
    if any(p.is_symlink() for p in (target, *target.parents)):
        raise ValueError('checkpoint links forbidden')
    return target


LEDGER_INDEX_SUFFIXES = ('.sqlite3', '.sqlite3-journal', '.sqlite3-wal', '.sqlite3-shm')


def _is_ledger_index(path):
    """A DurableLedger's <ledger>.jsonl.sqlite3 (and its sidecars) is rebuilt
    from the sibling JSONL on every open, so it is never checkpoint state."""
    for suffix in LEDGER_INDEX_SUFFIXES:
        if path.name.endswith('.jsonl' + suffix):
            return path.with_name(path.name[:-len(suffix)]).is_file()
    return False


def snapshot(directory, *, max_bytes=MAX_CHECKPOINT_BYTES):
    files = {}
    total = 0
    if any(p.is_symlink() for p in (Path(directory), *Path(directory).parents)):
        raise ValueError('checkpoint links forbidden')
    for path in sorted(Path(directory).rglob('*')):
        if path.is_symlink():
            raise ValueError('checkpoint links forbidden')
        if path.is_file() and not _is_ledger_index(path):
            remaining = max_bytes - total
            if path.stat().st_size > remaining:
                raise ValueError('checkpoint too large')
            with path.open('rb') as source:
                data = source.read(remaining + 1)
            total += len(data)
            if total > max_bytes:
                raise ValueError('checkpoint too large')
            try:
                content = data.decode('utf-8')
            except UnicodeDecodeError:
                content = {'encoding': 'base64', 'data': base64.b64encode(data).decode('ascii')}
            files[path.relative_to(directory).as_posix()] = content
    return files


def restore(directory, files, *, max_bytes=MAX_CHECKPOINT_BYTES):
    if type(files) is not dict:
        raise ValueError('invalid checkpoint files')
    prepared = []
    total = 0
    for name, content in files.items():
        if type(name) is not str:
            raise ValueError('invalid checkpoint path')
        path = safe_path(directory, name)
        remaining = max_bytes - total
        if type(content) is str:
            if len(content) > remaining:
                raise ValueError('checkpoint too large')
            data = content.encode('utf-8')
        elif (type(content) is dict and set(content) == {'encoding', 'data'}
              and content['encoding'] == 'base64' and type(content['data']) is str):
            encoded = content['data']
            if len(encoded) > 4 * ((remaining + 2) // 3):
                raise ValueError('checkpoint too large')
            try:
                data = base64.b64decode(encoded, validate=True)
            except ValueError as exc:
                raise ValueError('invalid checkpoint base64') from exc
            if base64.b64encode(data).decode('ascii') != encoded:
                raise ValueError('invalid checkpoint base64')
        else:
            raise ValueError('invalid checkpoint content')
        total += len(data)
        if total > max_bytes:
            raise ValueError('checkpoint too large')
        prepared.append((path, data))
    # Reject malformed or oversized checkpoints before writing economic state.
    for path, data in prepared:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
