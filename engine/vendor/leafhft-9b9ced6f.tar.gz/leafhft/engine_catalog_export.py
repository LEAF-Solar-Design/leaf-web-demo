"""Best-effort owner engine catalog telemetry, separate from the control-bearing status POST.

Never raises into the push tick; bounded in time, bytes and files, and resumes an
unfinished generation across ticks using the exact WIRE-v1 request bytes.
"""
from __future__ import annotations

import hashlib
from copy import deepcopy
from contextlib import redirect_stdout
import json
import math
import os
from pathlib import Path
import re
import socket
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

from . import engine_telemetry

ENDPOINT = "/api/leafhft/ingest"
REQUEST_TIMEOUT_S = 5.0
EXPORT_BUDGET_S = 20.0
TICK_WALL_S = 50.0
HEARTBEAT_S = 300
# An in-flight snapshot is abandoned only after this long. It must exceed one full send: each push tick
# sends for at most EXPORT_BUDGET_S, and 75 requests took about 12.5 min on 2026-10-02, so at 600 s every
# snapshot was abandoned unfinished and the dashboard never completed a generation (owner switches locked).
STALE_INFLIGHT_S = 2400
REFUSAL_BACKOFF_S = 1800
MAX_STATE_BYTES = 64 * 1024
STATE_DIRNAME = "engine-catalog-snapshot"
VENUE = "kalshi"
_MAX_INTEGER = 2**53 - 1


def _fresh_state():
    return {"version": 1, "producer_epoch": max(1, int(time.time() * 1000)),
            "sequence": 0, "published_key": None, "published_at": None,
            "refused_until": None, "refused_code": None, "inflight": None,
            "runtime_suppressed_until": None}


def _integer(value, low, high=_MAX_INTEGER):
    return type(value) is int and low <= value <= high


def _wall(value):
    return type(value) is float and math.isfinite(value) and value >= 0


def _valid_state(state):
    if type(state) is dict:
        state.setdefault("runtime_suppressed_until", None)
    if type(state) is not dict or set(state) != set(_fresh_state()):
        return False
    if (type(state["version"]) is not int or state["version"] != 1
            or not _integer(state["producer_epoch"], 1)
            or not _integer(state["sequence"], 0)):
        return False
    for key in ("published_key", "refused_code"):
        if state[key] is not None and type(state[key]) is not str:
            return False
    for key in ("published_at", "refused_until", "runtime_suppressed_until"):
        if state[key] is not None and not _wall(state[key]):
            return False
    if (state["published_key"] is None) != (state["published_at"] is None):
        return False
    if (state["refused_code"] is None) != (state["refused_until"] is None):
        return False
    flight = state["inflight"]
    return flight is None or (
        type(flight) is dict
        and set(flight) == {"sequence", "key", "next", "page_count", "created_at"}
        and _integer(flight["sequence"], 1)
        and flight["sequence"] == state["sequence"]
        and type(flight["key"]) is str
        and _integer(flight["page_count"], 1, engine_telemetry.MAX_PAGES)
        and _integer(flight["next"], 0, flight["page_count"] + 2)
        and _wall(flight["created_at"]))


def _read(path, limit):
    with path.open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError("oversize file")
    return data


def _atomic(path, data):
    # Fixed per-file temp names also bound leftovers after an interrupted tick.
    temporary = path.with_name("." + path.name + ".tmp")
    try:
        with temporary.open("wb") as stream:
            stream.write(data)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _save(directory, state):
    data = json.dumps(state, allow_nan=False, separators=(",", ":")).encode("utf-8")
    if len(data) > MAX_STATE_BYTES:
        raise ValueError("oversize state")
    _atomic(directory / "state.json", data)


def _names(count):
    return ["begin.json", *(f"page-{index:04d}.json" for index in range(count)), "complete.json"]


def _clear_spool(directory):
    # Fixed name set: even a corrupt state cannot cause an unbounded directory scan.
    for name in _names(engine_telemetry.MAX_PAGES):
        (directory / name).unlink(missing_ok=True)


def _drop(directory, state):
    state["inflight"] = None
    _save(directory, state)
    _clear_spool(directory)


def _error_reply(raw):
    try:
        reply = json.loads(raw)
        detail = reply.get("engine_snapshot", {}) if type(reply) is dict else {}
        if type(detail) is dict:
            code = detail.get("code")
            if type(code) is not str or re.fullmatch(r"[A-Z][A-Z0-9_]{0,63}", code) is None:
                code = None
            return code, detail.get("retryable") is True
    except (ValueError, TypeError, RecursionError):
        pass
    return None, False


class DeadlineExceeded(TimeoutError):
    pass


def _read_response(response, limit, request_deadline):
    # Defense in depth inside the worker; _exchange's join is what bounds the caller.
    chunks = []
    remaining = limit
    read = getattr(response, "read1", response.read)
    while remaining:
        if time.monotonic() >= request_deadline:
            response.close()
            raise DeadlineExceeded()
        chunk = read(min(64 * 1024, remaining))
        if time.monotonic() >= request_deadline:
            response.close()
            raise DeadlineExceeded()
        if not chunk:
            break
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def _exchange(request, request_deadline):
    """Returns control to the caller by request_deadline: urlopen's timeout is per socket
    operation, so a trickling server is abandoned to a daemon worker instead of waited on.

    Result: ("ok", status, raw), ("http", HTTPError, raw) or ("error", exception). The worker
    only performs I/O; every state decision stays with the caller."""
    outcome = []
    socket_timeout = max(0.1, request_deadline - time.monotonic())

    def run():
        try:
            try:
                with urllib.request.urlopen(request, timeout=socket_timeout) as response:
                    raw = _read_response(response, 1 << 20, request_deadline)
                    status = getattr(response, "status", 200)
                outcome.append(("ok", status, raw))
            except urllib.error.HTTPError as exc:
                try:
                    outcome.append(("http", exc, _read_response(exc, 64 * 1024, request_deadline)))
                finally:
                    exc.close()
        except Exception as exc:
            outcome.append(("error", exc))

    worker = threading.Thread(target=run, daemon=True, name="engine-catalog-post")
    wait = max(0.0, request_deadline - time.monotonic())
    worker.start()
    worker.join(wait)
    if worker.is_alive():
        return ("error", DeadlineExceeded())
    if not outcome:
        return ("error", RuntimeError())
    return outcome[0]


def _export(runs_dir, url, token_env, deadline, notes):
    from . import engine_pnl, push

    directory = Path(runs_dir).parent / STATE_DIRNAME
    directory.mkdir(mode=0o750, parents=True, exist_ok=True)
    try:
        state = json.loads(_read(directory / "state.json", MAX_STATE_BYTES))
        if not _valid_state(state):
            raise ValueError("invalid state")
    except FileNotFoundError:
        state = _fresh_state()
    except (ValueError, TypeError, RecursionError):
        notes.append("state reset")
        state = _fresh_state()
        _clear_spool(directory)
        _save(directory, state)
    now = time.time()
    if state["refused_until"] is not None and state["refused_until"] > now:
        return f"refused {state['refused_code']}, backing off"
    token = os.environ.get(token_env)
    if not token:
        return "no token"
    flight = state["inflight"]
    bodies = None
    if flight is not None:
        if now - flight["created_at"] < STALE_INFLIGHT_S:
            try:
                bodies = [_read(directory / name, engine_telemetry.MAX_REQUEST_BYTES)
                          for name in _names(flight["page_count"])]
                # Check framing without freezing or rebuilding an unfinished generation.
                for index, body in enumerate(bodies):
                    outer = json.loads(body)
                    if type(outer) is not dict or set(outer) != {"engine_snapshot"}:
                        raise ValueError("spool envelope")
                    frame = outer["engine_snapshot"]
                    op = "begin" if index == 0 else "complete" if index == len(bodies) - 1 else "page"
                    if (type(frame) is not dict or frame.get("op") != op
                            or frame.get("version") != 1
                            or frame.get("producer_epoch") != state["producer_epoch"]
                            or frame.get("sequence") != flight["sequence"]
                            or frame.get("host") != socket.gethostname()[:64]
                            or frame.get("venue") != VENUE
                            or (op == "page" and frame.get("page_index") != index - 1)):
                        raise ValueError("spool identity")
                begin = json.loads(bodies[0])["engine_snapshot"]
                if (begin.get("page_count") != flight["page_count"]
                        or not _integer(begin.get("engine_count"), 0, engine_telemetry.MAX_ENGINES)
                        or not _integer(begin.get("control_count"), 0, engine_telemetry.MAX_CONTROLS)):
                    raise ValueError("spool counts")
            except (OSError, ValueError, TypeError, KeyError, RecursionError):
                bodies = None
        if bodies is None:
            _drop(directory, state)
            flight = None
    if flight is None:
        # Preparation overruns the deadline by at most one bounded phase (catalog work is bounded by
        # ENGINE_CATALOG_CAPACITY): every phase boundary returns "deadline" before any spool write,
        # state change or sequence is consumed.
        if deadline - time.monotonic() < REQUEST_TIMEOUT_S:
            return "deadline"
        # The public entry emits exactly one summary, including collector refusals.
        with open(os.devnull, "w") as sink, redirect_stdout(sink):
            blocks = push._engine_status_blocks(whole_catalog=True)
        if deadline - time.monotonic() < REQUEST_TIMEOUT_S:
            return "deadline"
        controls = blocks.get("engine_controls")
        if ("engines" not in blocks or not isinstance(controls, dict)
                or not isinstance(controls.get("states"), list)):
            return "catalog unavailable, nothing published"
        logical = {"engines": blocks["engines"],
                   "controls": controls["states"]}
        if "engine_bindings" in blocks:
            logical["engine_bindings"] = blocks["engine_bindings"]
        sequence = state["sequence"] + 1
        host = socket.gethostname()[:64]
        snapshot_identity = dict(
            context=engine_telemetry.HostContext(host), venue=VENUE,
            observed_at=datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
            producer_epoch=state["producer_epoch"], sequence=sequence)
        suppressed_until = state["runtime_suppressed_until"]
        runtime_rows = None
        if (os.environ.get(engine_pnl.ENGINE_ROLLUPS_ENV) == "1"
                and (suppressed_until is None or suppressed_until <= now)):
            try:
                with open(os.devnull, "w") as sink, redirect_stdout(sink):
                    records, identity = engine_pnl.load_augment_context()
                    markets = engine_pnl._markets(blocks.get("engine_bindings"))
                    projection = []
                    for row in blocks["engines"]:
                        augmented = engine_pnl.augment_engine_row(row, records, identity, host, markets)
                        projection.append({key: augmented[key] for key in (
                            "engine_id", "inputs", "markets", "account_id", "claim", "lifecycle", "revision")
                            if augmented is not None and key in augmented})
                runtime_rows = projection
                logical["runtime"] = {"engines": runtime_rows}
            except Exception as exc:
                notes.append(f"runtime unavailable {type(exc).__name__}")
        if deadline - time.monotonic() < REQUEST_TIMEOUT_S:
            return "deadline"
        # The key covers the UNVALIDATED projection: an unchanged tick freezes nothing, and a
        # permanently invalid runtime row still compares equal instead of republishing every tick.
        key = hashlib.sha256(json.dumps(logical, sort_keys=True, separators=(",", ":"),
                                        default=str).encode("utf-8")).hexdigest()
        if (key == state["published_key"] and state["published_at"] is not None
                and now - state["published_at"] < HEARTBEAT_S):
            return "unchanged"
        if runtime_rows is not None:
            # Publishing only: the mirror may also rewrite catalog/control records, so
            # give it fresh scratch copies and take back only accepted runtime rows.
            try:
                from .engines import load_dashboard_account_identity

                identity_path = Path(os.environ.get(
                    push._CONTROL_ACCOUNT_IDENTITY_ENV, push._DEFAULT_CONTROL_ACCOUNT_IDENTITY))
                dashboard_identity = (load_dashboard_account_identity(identity_path)
                                      if identity_path.exists() else None)
                scope = {"host": host, "venue": VENUE,
                         "account": dashboard_identity.subaccount_number if dashboard_identity is not None else None,
                         "accounts_disabled": dashboard_identity is None}

                def filter_rows(rows):
                    scratch = {"engines": deepcopy(logical["engines"]),
                               "controls": deepcopy(logical["controls"]),
                               "runtime": {"engines": deepcopy(rows)}, "refusals": []}
                    engine_telemetry._filter_runtime_references(scratch, scope=scope)
                    return scratch["runtime"]["engines"]

                filtered = filter_rows(runtime_rows)
                retained = {row["engine_id"] for row in filtered}
                retries = [{key: value for key, value in projected.items() if key != "lifecycle"}
                           for projected in runtime_rows
                           if projected.get("engine_id") not in retained and "lifecycle" in projected]
                # Retry together to avoid copying the entire catalog once per rejected row.
                retried = filter_rows(retries) if retries else []
                stripped_ids = {row["engine_id"] for row in retried}
                filtered.extend(retried)
                valid = []
                for projected in filtered:
                    try:
                        engine_telemetry.freeze_engine_snapshot(
                            {"runtime": {"engines": [projected]}}, **snapshot_identity)
                    except engine_telemetry.SnapshotConstructionError:
                        continue
                    valid.append(projected)
                logical["runtime"] = {"engines": valid}
                stripped = sum(row["engine_id"] in stripped_ids for row in valid)
                if len(valid) != len(runtime_rows) or stripped:
                    notes.append(f"runtime dropped {len(runtime_rows) - len(valid)}, lifecycle stripped {stripped}")
            except Exception as exc:
                logical.pop("runtime", None)
                notes.append(f"runtime unavailable {getattr(exc, 'code', type(exc).__name__)}")
        try:
            snapshot = engine_telemetry.freeze_engine_snapshot(
                logical, **snapshot_identity)
            requests = engine_telemetry.build_snapshot_requests(snapshot)
        except engine_telemetry.SnapshotConstructionError as exc:
            return f"refused locally {exc.code}"
        if deadline - time.monotonic() < REQUEST_TIMEOUT_S:
            return "deadline"
        bodies = [requests.begin, *requests.pages, requests.complete]
        _clear_spool(directory)
        for name, body in zip(_names(len(requests.pages)), bodies):
            _atomic(directory / name, body)
        flight = {"sequence": sequence, "key": key, "next": 0,
                  "page_count": len(requests.pages), "created_at": now}
        state.update(sequence=sequence, inflight=flight)
        _save(directory, state)
    carries_runtime = any(
        json.loads(body)["engine_snapshot"].get("auxiliary", {}).get("runtime", {}).get("engines")
        for body in bodies[1:])
    for index in range(flight["next"], len(bodies)):
        if deadline - time.monotonic() < REQUEST_TIMEOUT_S:
            return f"in flight {flight['next']}/{len(bodies)} requests"
        request = urllib.request.Request(
            url.rstrip("/") + ENDPOINT, data=bodies[index], method="POST",
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + token,
                     "User-Agent": "leafhft-push/0.1"})
        request_deadline = min(deadline, time.monotonic() + REQUEST_TIMEOUT_S)
        result = _exchange(request, request_deadline)
        if result[0] == "error":
            # Network, timeout, abandoned exchange or any other fault: keep inflight, stop here.
            return f"retry {type(result[1]).__name__}"
        if result[0] == "ok":
            _, status, raw = result
            try:
                reply = json.loads(raw)
            except (ValueError, RecursionError):
                reply = None
            if not 200 <= status < 300 or type(reply) is not dict or reply.get("success") is not True:
                code, _ = _error_reply(raw)
                return f"retry {code or 'invalid response'}"
        else:
            _, exc, raw = result
            code, retryable = _error_reply(raw)
            label = code or str(exc.code)
            if exc.code in (400, 403, 413) and carries_runtime:
                state.update(runtime_suppressed_until=time.time() + REFUSAL_BACKOFF_S,
                             refused_until=None, refused_code=None)
                _drop(directory, state)
                return f"restart {label}, runtime suppressed"
            if exc.code == 503 or retryable:
                return f"retry {label}"
            if exc.code == 409 and code in {
                    "STALE_GENERATION", "GENERATION_CONFLICT", "UNKNOWN_GENERATION",
                    "PAGE_CONFLICT", "OBSERVATION_ROLLBACK", "AUXILIARY_REJECTED"}:
                if code in {"STALE_GENERATION", "GENERATION_CONFLICT"}:
                    state["producer_epoch"] = max(state["producer_epoch"] + 1, int(time.time() * 1000))
                    state["sequence"] = 0
                _drop(directory, state)
                return f"restart {code}"
            if 400 <= exc.code < 500:
                state.update(refused_until=time.time() + REFUSAL_BACKOFF_S, refused_code=label)
                _drop(directory, state)
                return f"refused {exc.code} {label}"
            return f"retry {label}"
        flight["next"] = index + 1
        _save(directory, state)
    begin = json.loads(bodies[0])["engine_snapshot"]
    state.update(published_key=flight["key"], published_at=time.time(), inflight=None,
                 refused_until=None, refused_code=None)
    _save(directory, state)
    _clear_spool(directory)
    return (f"published seq={flight['sequence']} pages={flight['page_count']} "
            f"engines={begin['engine_count']} controls={begin['control_count']} bytes={sum(map(len, bodies))}")


def export_engine_catalog(runs_dir, url, token_env="LEAFHFT_DASHBOARD_TOKEN", *, deadline) -> None:
    """Publish or resume a bounded generation; telemetry failures never escape."""
    notes = []
    try:
        summary = _export(runs_dir, url, token_env, deadline, notes)
    except Exception as exc:
        summary = type(exc).__name__
    summary = "; ".join([*notes, summary]).replace("\r", " ").replace("\n", " ")
    print("push engine catalog: " + summary, flush=True)
