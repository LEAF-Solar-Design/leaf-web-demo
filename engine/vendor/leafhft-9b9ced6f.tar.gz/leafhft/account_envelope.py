"""Dark, document-only capture of the owner's effective account envelope.

SOURCES (paths are injectable; line references describe the runtime contract):
field                         source / conversion
five *_fraction fields        effective policy, same-named keys (precedence below)
cash_floor_cents              effective policy, same-named integer cents
per_book_stake_cents          account policy's stake_ceiling_usd, formatted with
                             '%.2f' exactly as deploy/runner/live-run.sh:185-198;
                             dollars * 100, then integer cents (cli.py:2098-2099,
                             kalshi_live_runtime.py:8659). kalshi-stake is NOT an
                             additional source when the account policy exists.
reversal_max_open_cents       effective policy, same-named integer cents
reversal_budget_cents         effective policy, same-named integer cents;
                             kalshi_live_runtime.py:978-990 assigns both to the
                             shared reversal budget, including on policy reload.

Owner semantics: policy.py:53-60,76-83 applies no hard-maxima clamp. Bindings select
engine policies (kalshi_live_runtime.py:659-689); sparse owner overrides replace
their keys (engines.py:677-696, kalshi_live_runtime.py:684-714). For each book and
POLICY_FIELD, use its selected engine's owner override if present, else its engine
policy's explicit value, else /etc/leafhft/kalshi-policy.json's same-named value.
A book with no selected engine uses the account policy directly. Compare only
these effective values across books, citing each effective source; a disagreement
has no unique account value and refuses. Books selecting the same engine share
one effective policy and are resolved once. Engine stake ceilings are entry caps,
not starting book stake.
Missing explicit values refuse even where legacy readers would supply defaults.

No runtime imports this module. Resolution reads only the supplied files, never
process environment or a clock. captured_at_ms defaults to zero (unspecified) for
pure resolution; capture supplies its observation time separately.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import sys
import tempfile
import time
from dataclasses import dataclass, replace
from decimal import Decimal
from pathlib import Path

from .tuning_plan_v2 import BOOKS, canonical_bytes, envelope_digest


FRACTIONS = (
    "daily_loss_fraction", "per_order_fraction", "cluster_fraction",
    "drawdown_brake_fraction", "drawdown_stop_fraction",
)
POLICY_FIELDS = FRACTIONS + (
    "cash_floor_cents", "reversal_max_open_cents", "reversal_budget_cents",
)
FIELDS = FRACTIONS + (
    "cash_floor_cents", "per_book_stake_cents",
    "reversal_max_open_cents", "reversal_budget_cents",
)
DEFAULT_OUT = Path("/etc/leafhft-deployments")
DEFAULT_ENVELOPE = DEFAULT_OUT / "account-envelope.json"
MAX_SOURCE_BYTES = 65536


class EnvelopeError(ValueError):
    """Stable refusal code; source contents are never reflected in errors."""

    def __init__(self, code):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class EnvelopePaths:
    policy: Path = Path("/etc/leafhft/kalshi-policy.json")
    bindings: Path = Path("/etc/leafhft/kalshi-engine-bindings.json")
    engines_dir: Path = Path("/etc/leafhft/engines")
    account_overrides: Path = Path("/etc/leafhft/kalshi-engine-account-overrides.json")
    account_identity: Path = Path("/var/lib/leafhft/dashboard-account.json")
    captured_at_ms: int = 0


def _paths(paths):
    return EnvelopePaths(**paths) if isinstance(paths, dict) else paths


def _read_bytes(path, limit=MAX_SOURCE_BYTES):
    """Local bounded reader: safe_read.py is absent in this build.

    POSIX traversal pins every directory and rejects symlinks at every component;
    O_NONBLOCK prevents a FIFO from blocking before the regular-file check.
    """
    path = Path(path)
    flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_NOFOLLOW", 0)
    directory = None
    fd = None
    try:
        if os.name == "posix":
            absolute = path.absolute()
            directory = os.open(absolute.anchor, flags | os.O_DIRECTORY)
            for part in absolute.parts[1:-1]:
                child = os.open(part, flags | os.O_DIRECTORY, dir_fd=directory)
                os.close(directory)
                directory = child
            fd = os.open(absolute.name, flags, dir_fd=directory)
        else:
            # Windows has no O_NOFOLLOW. Refuse known links/reparse points too.
            for part in (path, *path.parents):
                info = part.lstat()
                if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                    raise EnvelopeError("envelope_source_unsafe")
            fd = os.open(path, flags | getattr(os, "O_BINARY", 0))
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise EnvelopeError("envelope_source_unsafe")
        if info.st_size > limit:
            raise EnvelopeError("envelope_source_too_large")
        chunks = []
        remaining = limit + 1
        while remaining:
            chunk = os.read(fd, remaining)
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        data = b"".join(chunks)
        if len(data) > limit:
            raise EnvelopeError("envelope_source_too_large")
        return data
    finally:
        if fd is not None:
            os.close(fd)
        if directory is not None:
            os.close(directory)


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            field = "per_book_stake_cents" if key == "stake_ceiling_usd" else key
            if field in FIELDS:
                raise EnvelopeError("envelope_source_conflict:" + field)
            raise EnvelopeError("envelope_source_invalid")
        result[key] = value
    return result


def _bad_number(_):
    raise EnvelopeError("envelope_source_invalid")


@dataclass(frozen=True)
class _Source:
    path: Path
    document: dict
    sha256: str

    def cite(self, field, key):
        return {"field": field, "path": str(self.path), "sha256": self.sha256, "key": key}


def _source(path, *, missing=None, optional=False, limit=MAX_SOURCE_BYTES):
    try:
        data = _read_bytes(path, limit)
    except FileNotFoundError:
        if optional:
            return None
        raise EnvelopeError("envelope_source_missing:" + (missing or "configuration")) from None
    except OSError:
        raise EnvelopeError("envelope_source_unsafe") from None
    try:
        document = json.loads(data, object_pairs_hook=_pairs, parse_constant=_bad_number)
    except (UnicodeError, ValueError, RecursionError) as exc:
        if isinstance(exc, EnvelopeError):
            raise
        raise EnvelopeError("envelope_source_invalid") from None
    if type(document) is not dict:
        raise EnvelopeError("envelope_source_invalid")
    return _Source(Path(path), document, hashlib.sha256(data).hexdigest())


def _value(field, mapping):
    if field not in mapping:
        raise EnvelopeError("envelope_source_missing:" + field)
    value = mapping[field]
    # Validate explicit values with the runtime's bounds, without its ambient
    # regime/default merge. Under owner, these bounds are the complete clamp law.
    from .policy import POLICY_BOUNDS, PolicyError, _validate_field

    try:
        _validate_field(field, value, *POLICY_BOUNDS[field])
    except (PolicyError, OverflowError):
        raise EnvelopeError("envelope_source_invalid:" + field) from None
    if field in FRACTIONS:
        return format(Decimal(str(value)), "f")
    return value


def _bound_engines(paths):
    bindings = _source(paths.bindings, optional=True, limit=4096)
    if bindings is None:
        return None, [None]
    raw = bindings.document
    if (set(raw) not in ({"default", "symbols"}, {"default", "symbols", "disabled"})
            or type(raw["symbols"]) is not dict or set(raw["symbols"]) - BOOKS
            or type(raw.get("disabled", [])) is not list
            or any(type(b) is not str or b not in BOOKS for b in raw.get("disabled", []))):
        raise EnvelopeError("envelope_source_invalid:bindings")
    ids = [raw["default"], *raw["symbols"].values()]
    if any(eid is not None and (type(eid) is not str or
            re.fullmatch(r"[a-z0-9][a-z0-9-]{0,31}", eid) is None) for eid in ids):
        raise EnvelopeError("envelope_source_invalid:bindings")
    selected = {raw["symbols"].get(book, raw["default"]) for book in BOOKS}
    return bindings, sorted(selected - {None}) + ([None] if None in selected else [])


def resolve_effective(paths):
    """Return the closed envelope and provenance; refuse missing/ambiguous values.

    paths is EnvelopePaths or its keyword mapping. Optional absent bindings mean
    the runner's policy-only mode; absent overrides mean inheritance, as in
    AccountOverrides._load. An explicitly selected engine may never disappear.
    """
    paths = _paths(paths)
    if type(paths.captured_at_ms) is not int or paths.captured_at_ms < 0:
        raise EnvelopeError("envelope_source_invalid:captured_at_ms")
    account = _source(paths.policy, missing=FRACTIONS[0], limit=8192)
    bindings, engine_ids = _bound_engines(paths)
    overrides = identity = None
    owner_engines = {}
    if any(eid is not None for eid in engine_ids):
        identity = _source(paths.account_identity, missing="account_identity", limit=1024)
        from .engines import DashboardAccountIdentity

        try:
            owner = DashboardAccountIdentity(**identity.document)
        except (TypeError, ValueError):
            raise EnvelopeError("envelope_source_invalid:account_identity") from None
        overrides = _source(paths.account_overrides, optional=True)
        if overrides is not None:
            raw = overrides.document
            if (set(raw) != {"schema_version", "accounts"} or raw["schema_version"] != 1
                    or type(raw["accounts"]) is not dict):
                raise EnvelopeError("envelope_source_invalid:account_overrides")
            body = raw["accounts"].get(owner.account_id, {"engines": {}})
            if type(body) is not dict or set(body) != {"engines"} or type(body["engines"]) is not dict:
                raise EnvelopeError("envelope_source_invalid:account_overrides")
            owner_engines = body["engines"]
    doc = {"schema": "leafhft.account-envelope.v1"}
    citations = []
    # This startup stake is deliberately read before engine/override merges.
    if "stake_ceiling_usd" not in account.document:
        raise EnvelopeError("envelope_source_missing:per_book_stake_cents")
    try:
        stake = _value("stake_ceiling_usd", account.document)
    except EnvelopeError:
        raise EnvelopeError("envelope_source_invalid:per_book_stake_cents") from None
    doc["per_book_stake_cents"] = int(Decimal("%.2f" % float(stake)) * 100)
    citations.append(account.cite("per_book_stake_cents", "stake_ceiling_usd"))
    for eid in engine_ids:
        engine = None
        override = {}
        prefix = ""
        if eid is not None:
            engine = _source(Path(paths.engines_dir) / (eid + ".json"), missing=FRACTIONS[0], limit=8192)
            if engine.document.get("engine_id") != eid or type(engine.document.get("policy")) is not dict:
                raise EnvelopeError("envelope_source_invalid:engine")
            if eid in owner_engines:
                from .engines import AccountOverride

                try:
                    override = AccountOverride(**owner_engines[eid]).policy
                except (TypeError, ValueError, OverflowError):
                    raise EnvelopeError("envelope_source_invalid:account_overrides") from None
                prefix = "accounts." + owner.account_id + ".engines." + eid + ".policy."
        for field in POLICY_FIELDS:
            # Select one effective source before comparing books. An account
            # value superseded by an engine or override is not a candidate.
            if field in override:
                value = _value(field, override)
                citation = overrides.cite(field, prefix + field)
            elif engine is not None and field in engine.document["policy"]:
                value = _value(field, engine.document["policy"])
                citation = engine.cite(field, "policy." + field)
            else:
                value = _value(field, account.document)
                citation = account.cite(field, field)
            if field in doc and Decimal(str(doc[field])) != Decimal(str(value)):
                raise EnvelopeError("envelope_source_conflict:" + field)
            doc[field] = value
            if citation not in citations:
                citations.append(citation)
            for selector, key in ((bindings, "symbols/default"), (identity, "account_id")):
                if selector is not None:
                    citation = selector.cite(field, key)
                    if citation not in citations:
                        citations.append(citation)
    envelope_digest(doc)  # The v2 schema owns all final validation and hashing.
    return doc, {"resolved_regime": "owner", "sources": citations,
                 "captured_at_ms": paths.captured_at_ms}


def _require_root():
    if hasattr(os, "geteuid") and os.geteuid() != 0:
        raise EnvelopeError("not_root")


def _fsync_directory(directory):
    if os.name == "posix":
        fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def capture(paths, out_dir):
    """Root-only atomic file replacements; the deployment writer provisions dirs.

    Each file is atomic, not the two-file pair. Stage and fsync both first, publish
    provenance first and the authoritative document last; no runtime reads either.
    """
    _require_root()
    out_dir = Path(out_dir)
    if not out_dir.is_dir():
        raise EnvelopeError("envelope_output_missing")
    if out_dir.is_symlink():
        raise EnvelopeError("envelope_output_unsafe")
    doc, provenance = resolve_effective(replace(_paths(paths), captured_at_ms=time.time_ns() // 1_000_000))
    staged = []
    try:
        for name, value in (("account-envelope.provenance.json", provenance),
                            ("account-envelope.json", doc)):
            fd, temp = tempfile.mkstemp(prefix="." + name + ".", dir=out_dir)
            staged.append((temp, out_dir / name))
            with os.fdopen(fd, "wb") as stream:
                stream.write(canonical_bytes(value))
                stream.flush()
                if hasattr(os, "fchmod"):
                    os.fchmod(stream.fileno(), 0o644)
                else:
                    os.chmod(temp, 0o644)
                os.fsync(stream.fileno())
        for temp, target in staged:
            os.replace(temp, target)
            _fsync_directory(out_dir)
    except OSError:
        raise EnvelopeError("envelope_write_failed") from None
    finally:
        for temp, _ in staged:
            try:
                os.unlink(temp)
            except FileNotFoundError:
                pass
    return doc, provenance


def show(envelope_path=DEFAULT_ENVELOPE):
    doc = _source(envelope_path, missing="envelope").document
    envelope_digest(doc)
    return doc


def check(paths, envelope_path):
    """One diff per differing field against freshly resolved owner values."""
    stored = show(envelope_path)
    effective, _ = resolve_effective(paths)
    return [{"field": field, "stored": stored[field], "effective": effective[field]}
            for field in FIELDS
            if Decimal(str(stored[field])) != Decimal(str(effective[field]))]


def register_cli(subparsers):
    parser = subparsers.add_parser("envelope", help="capture and check the owner account envelope (dark)")
    commands = parser.add_subparsers(dest="envelope_cmd", required=True)
    capture_parser = commands.add_parser("capture")
    capture_parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    check_parser = commands.add_parser("check")
    check_parser.add_argument("--envelope", type=Path, default=DEFAULT_ENVELOPE)
    check_parser.add_argument("--json", action="store_true")
    commands.add_parser("show")


def cmd_envelope(args):
    try:
        if args.envelope_cmd == "capture":
            doc, _ = capture(EnvelopePaths(), args.out)
            print(canonical_bytes(doc).decode("ascii"))
        elif args.envelope_cmd == "show":
            print(canonical_bytes(show()).decode("ascii"))
        else:
            diffs = check(EnvelopePaths(), args.envelope)
            if args.json:
                print(json.dumps(diffs, sort_keys=True, separators=(",", ":")))
            else:
                for diff in diffs:
                    print("{field}: {stored} -> {effective}".format(**diff))
                if not diffs:
                    print("Account envelope matches effective owner configuration.")
            return int(bool(diffs))
        return 0
    except (ValueError, OSError) as exc:
        code = getattr(exc, "code", "envelope_refused")
        if getattr(args, "json", False):
            print(json.dumps({"error": code}, sort_keys=True))
        else:
            print(code, file=sys.stderr)
        return 2
