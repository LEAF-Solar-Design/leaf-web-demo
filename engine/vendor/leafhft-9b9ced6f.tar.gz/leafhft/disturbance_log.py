"""Per-book append-only evidence: one write, no fsync, never raises on the order path.

Schema leafhft.disturbance_log.v1 has common schema/session_id/seq/at_ns/kind
fields. open and cont carry symbol, unit, pid, process_start_ns, boot_id,
invocation_id, build_sha, account_id and lane_id. cont also carries the
events/pending/dropped/lossy watermark. hb and quiesce carry that watermark.
d carries refusal_code, incumbent_client_id, ticker, codes, present,
unattributed and probes_necessary. bind carries engine_id and code (both join
and rollback are recorded by the host). Times come from the writer wall clock,
never from the proposal. Every encoded row, including its newline, is <=2048 B.

Default directory: /var/lib/leafhft/engine-evidence/_book; each symbol gets
disturbance.jsonl and disturbance.jsonl.1. The default off marker is _book/OFF.
Directory, marker, heartbeat interval and generation size are parameters.
The 64 MiB generation cap is modeled, not an unlimited retention promise:
at 288 heartbeats + 1000 disturbances + 100 bindings + 20 session rows/day,
21 * 1408 * 2048 = 60,555,264 B < 64 MiB. Two generations retain at least a
full generation at rotation, enough for 21 days at that stated row budget.
Unbounded refusal rates can shorten retention; the reader must check coverage.

record attempts exactly one os.write while active, even with a backlog (it
attempts the oldest row). It does no filesystem lock acquisition or fsync.
Worker tick retries FIFO rows, repairs short-write tails, rotates and fsyncs;
quiesce drains and latches. close releases resources WITHOUT claiming a clean
stop, which also models a process crash in tests. No caller is installed here.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path

PROBE_PREFIX = "lp-"
CODE_LEN = 4
SCHEMA = "leafhft.disturbance_log.v1"
DEFAULT_DIRECTORY = Path("/var/lib/leafhft/engine-evidence/_book")
DEFAULT_SIZE_CAP = 64 * 1024 * 1024
MAX_ROW_BYTES = 2048
MAX_PENDING = 64
DEFAULT_MAX_BYTES = 2 * DEFAULT_SIZE_CAP + 1024 * 1024
DEFAULT_MAX_ROWS = 1_000_000
HEARTBEAT_NS = 300 * 1_000_000_000
_CODE = re.compile(r"[0-9a-f]{4}")
_ENGINE = re.compile(r"[a-z0-9][a-z0-9-]{0,31}")
_COMMON = {"schema", "session_id", "seq", "at_ns", "kind"}
_HEADER = {"symbol", "unit", "pid", "process_start_ns", "boot_id",
           "invocation_id", "build_sha", "account_id", "lane_id"}
_COUNTS = {"events", "pending", "dropped", "lossy"}
_FIELDS = {
    "open": _HEADER,
    "cont": _HEADER | _COUNTS,
    "hb": _COUNTS,
    "quiesce": _COUNTS,
    "d": {"refusal_code", "incumbent_client_id", "ticker", "codes", "present",
          "unattributed", "probes_necessary"},
    "bind": {"engine_id", "code"},
}


def _value(obj, name, default=None):
    return obj.get(name, default) if isinstance(obj, dict) else getattr(obj, name, default)


def causal_codes(owners, proposal, refusal_code="engine_disagreement"):
    """Attribute Intent-like owners without importing executor.

    codes names opposite-side (or opposite-close) probe owners; present names
    every valid probe code. Invalid lp- prefixes count as unattributed. Necessary
    means removing ALL probes removes the given refusal, not removing one probe.
    ticker ownership/pending/unknown and disagreement follow executor priority.
    """
    codes, present = set(), set()
    unattributed = 0
    remaining = []
    for owner in owners:
        cid = _value(owner, "client_id", "")
        disagree = (_value(owner, "side_yes") != _value(proposal, "side_yes")
                    or _value(owner, "close", False) != _value(proposal, "close", False))
        if isinstance(cid, str) and cid.startswith(PROBE_PREFIX):
            code = cid[len(PROBE_PREFIX):len(PROBE_PREFIX) + CODE_LEN]
            suffix = cid[len(PROBE_PREFIX) + CODE_LEN:]
            if _CODE.fullmatch(code) and suffix.startswith("-") and len(suffix) > 1:
                present.add(code)
                if disagree:
                    codes.add(code)
            else:
                unattributed += 1
        else:
            remaining.append(owner)
    # A non-probe can still refuse after removal, even for a different reason.
    def blocks(owner):
        cid = _value(owner, "client_id", "")
        if _value(owner, "lane", "engines") != "engines":
            return True
        if not isinstance(cid, str) or not cid.startswith("lh-"):
            return True
        return (_value(owner, "side_yes") != _value(proposal, "side_yes")
                or _value(owner, "close", False) != _value(proposal, "close", False)
                or _value(owner, "engine_id", "") == _value(proposal, "engine_id", None)
                or refusal_code == "ticker_conflict")
    return {"codes": sorted(codes), "present": sorted(present),
            "unattributed": unattributed,
            "probes_necessary": bool(present or unattributed) and not any(map(blocks, remaining))}


def disturbance_row(refusal_code, incumbent_client_id, ticker, owners, proposal):
    """Build the d payload under the authority lock; record later outside it."""
    return {"refusal_code": refusal_code, "incumbent_client_id": incumbent_client_id,
            "ticker": ticker, **causal_codes(owners, proposal, refusal_code)}


def _encode(row):
    _validate(row)
    data = (json.dumps(row, separators=(",", ":"), ensure_ascii=True,
                       allow_nan=False) + "\n").encode("utf-8")
    if len(data) > MAX_ROW_BYTES:
        raise ValueError("row exceeds 2048 bytes")
    return data


def _validate(row):
    if type(row) is not dict or row.get("schema") != SCHEMA:
        raise ValueError("invalid schema")
    kind = row.get("kind")
    if type(kind) is not str or kind not in _FIELDS:
        raise ValueError("unknown kind")
    if set(row) != _COMMON | _FIELDS[kind]:
        raise ValueError("unexpected row keys")
    for key in ("seq", "at_ns"):
        if type(row[key]) is not int or row[key] < 0:
            raise ValueError("invalid " + key)
    if type(row["session_id"]) is not str or not row["session_id"]:
        raise ValueError("invalid session_id")
    if kind in {"open", "cont"}:
        for key in _HEADER - {"pid", "process_start_ns"}:
            if type(row[key]) is not str:
                raise ValueError("invalid header " + key)
        for key in ("pid", "process_start_ns"):
            if type(row[key]) is not int or row[key] < 0:
                raise ValueError("invalid header " + key)
        if not row["symbol"] or not row["account_id"] or not row["lane_id"]:
            raise ValueError("missing book identity")
        if kind == "open" and row["seq"] != 0:
            raise ValueError("open seq must be zero")
    if kind in {"cont", "hb", "quiesce"}:
        for key in _COUNTS - {"lossy"}:
            if type(row[key]) is not int or row[key] < 0:
                raise ValueError("invalid count " + key)
        if type(row["lossy"]) is not bool or row["pending"] > MAX_PENDING:
            raise ValueError("invalid watermark")
        if row["dropped"] and not row["lossy"]:
            raise ValueError("dropped rows without lossy")
    if kind == "d":
        for key in ("refusal_code", "incumbent_client_id", "ticker"):
            if type(row[key]) is not str or not row[key]:
                raise ValueError("invalid disturbance " + key)
        for key in ("codes", "present"):
            values = row[key]
            if (type(values) is not list or any(type(v) is not str or not _CODE.fullmatch(v) for v in values)
                    or values != sorted(set(values))):
                raise ValueError("invalid " + key)
        if not set(row["codes"]) <= set(row["present"]):
            raise ValueError("codes not present")
        if type(row["unattributed"]) is not int or row["unattributed"] < 0:
            raise ValueError("invalid unattributed")
        if type(row["probes_necessary"]) is not bool:
            raise ValueError("invalid probes_necessary")
    if kind == "bind":
        if (type(row["engine_id"]) is not str or not _ENGINE.fullmatch(row["engine_id"])
                or type(row["code"]) is not str or not _CODE.fullmatch(row["code"])):
            raise ValueError("invalid binding")


class DisturbanceLog:
    """Single writer. open returns False on lock contention or unavailable storage.

    Explicit path overrides directory/symbol path construction. off_marker defaults
    to directory/OFF. Call tick from the worker at least every 30 s; its first call
    emits hb and subsequent heartbeats occur every heartbeat_ns (default 300 s).
    record takes a disturbance_row payload or its keyword fields and returns a
    boolean indicating whether a row was admitted (not a durability guarantee).
    """

    def __init__(self, symbol, *, account_id, lane_id="engines", directory=DEFAULT_DIRECTORY,
                 path=None, off_marker=None, size_cap=DEFAULT_SIZE_CAP,
                 heartbeat_ns=HEARTBEAT_NS, unit=None, pid=None, process_start_ns=None,
                 boot_id=None, invocation_id=None, build_sha="", clock=time.time_ns):
        if size_cap <= 0 or heartbeat_ns <= 0:
            raise ValueError("size_cap and heartbeat_ns must be positive")
        if not symbol or symbol in {".", ".."} or "/" in symbol or "\\" in symbol:
            raise ValueError("symbol must be a path component")
        self.path = Path(path) if path is not None else Path(directory) / symbol / "disturbance.jsonl"
        self.off_marker = Path(off_marker) if off_marker is not None else Path(directory) / "OFF"
        self.size_cap, self.heartbeat_ns, self.clock = size_cap, heartbeat_ns, clock
        if boot_id is None:
            try:
                boot_id = Path("/proc/sys/kernel/random/boot_id").read_text(encoding="ascii").strip()
            except OSError:
                boot_id = ""
        self.header = dict(symbol=symbol, account_id=account_id, lane_id=lane_id,
                           unit=os.environ.get("LEAFHFT_UNIT", "") if unit is None else unit,
                           pid=os.getpid() if pid is None else pid,
                           process_start_ns=clock() if process_start_ns is None else process_start_ns,
                           boot_id=boot_id,
                           invocation_id=os.environ.get("INVOCATION_ID", "") if invocation_id is None else invocation_id,
                           build_sha=build_sha)
        self.session_id = uuid.uuid4().hex
        self.events = self.dropped = self._seq = 0
        self.lossy = False
        self._pending = deque()
        self._lock = threading.Lock()
        self._worker_lock = threading.Lock()
        self._fd = self._lock_fd = None
        self._size = 0
        self._short_at = None
        self._active = self._stopped = self._off = False
        self._rotating = False
        self._last_hb = None

    @property
    def pending(self):
        return len(self._pending)

    def _row(self, kind, payload):
        return dict(schema=SCHEMA, session_id=self.session_id, seq=self._seq,
                    at_ns=self.clock(), kind=kind, **payload)

    def _counts(self):
        # Pending d rows precede this watermark in FIFO order. If they eventually
        # reach disk, the watermark must include them as well.
        events = self.events + sum(kind == "d" for kind, _ in self._pending)
        return dict(events=events, pending=self.pending, dropped=self.dropped, lossy=self.lossy)

    def _queue(self, kind, payload):
        if self.pending >= MAX_PENDING:
            self.dropped += 1
            self.lossy = True
            return False
        data = _encode(self._row(kind, payload))
        self._pending.append((kind, data))
        self._seq += 1
        return True

    def _write_one(self):
        kind, data = self._pending[0]
        # With an incomplete tail, keep the one-write contract without extending
        # corrupt bytes. Only the worker may truncate and retry the full row.
        if self._short_at is not None or self._rotating:
            os.write(self._fd, b"")
            return False
        try:
            count = os.write(self._fd, data)
        except OSError:
            return False
        if count != len(data):
            if count > 0:
                self._short_at = self._size
                self._size += count
            return False
        self._size += count
        self._pending.popleft()
        if kind == "d":
            self.events += 1
        return True

    def _drain(self):
        if self._short_at is not None:
            os.ftruncate(self._fd, self._short_at)
            self._size = self._short_at
            self._short_at = None
        while self._pending:
            if not self._write_one():
                return False
        return True

    def open(self):
        if self._active or self._stopped:
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._lock_fd = os.open(str(self.path) + ".lock", os.O_RDWR | os.O_CREAT, 0o600)
            if os.name == "nt":
                import msvcrt
                os.lseek(self._lock_fd, 0, os.SEEK_SET)
                msvcrt.locking(self._lock_fd, msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self._fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND
                               | getattr(os, "O_BINARY", 0), 0o600)
            self._size = os.fstat(self._fd).st_size
            # An incomplete previous process tail must fail closed in the parser;
            # never silently truncate another session's evidence.
            self._queue("open", self.header)
            if not self._drain():
                raise OSError("open row unavailable")
            os.fsync(self._fd)
            self._active = True
            return True
        except Exception:
            self.close()
            return False

    def record(self, row=None, **fields):
        """Attempt one unsynced append, FIFO; swallow all order-path errors."""
        if not self._active or self._stopped or self._off:
            return False
        if not self._lock.acquire(blocking=False):
            self.lossy = True
            self.dropped += 1
            try:
                os.write(self._fd, b"")
            except Exception:
                pass
            return False
        attempted = False
        try:
            if not self._active or self._stopped or self._off:
                return False
            admitted = self._queue("d", dict(row) if row is not None else fields)
            attempted = True
            self._write_one()
            return admitted
        except Exception:
            self.lossy = True
            self.dropped += 1
            if not attempted:
                try:
                    os.write(self._fd, b"")
                except Exception:
                    pass
            return False
        finally:
            self._lock.release()

    def bind(self, engine_id, code):
        """Worker call at each join and rollback. Does not fsync on its own."""
        with self._lock:
            if not self._active or self._stopped or self._off:
                return False
            admitted = self._queue("bind", dict(engine_id=engine_id, code=code))
            if self._pending:
                self._write_one()
            return admitted

    def tick(self):
        """Retry, rotate and sync outside the order path. OFF is sticky this session."""
        if not self._active or self._stopped:
            return
        with self._worker_lock:
            self._tick()

    def _tick(self):
        if not self._active or self._stopped:
            return
        try:
            rotate = False
            with self._lock:
                if self._stopped:
                    return
                if self.off_marker.exists():
                    self._off = self.lossy = True
                drained = self._drain()
                if drained and self._size >= self.size_cap:
                    # Reserve cont BEFORE letting order-path rows queue behind
                    # it. During old-generation fsync, record makes its single
                    # empty write and queues; it cannot append cont to the old
                    # generation. No fsync ever holds the write lock.
                    self._queue("cont", {**self.header, **self._counts()})
                    self._rotating = rotate = True
            if rotate:
                os.fsync(self._fd)
                with self._lock:
                    os.close(self._fd)
                    self._fd = None
                    os.replace(self.path, Path(str(self.path) + ".1"))
                    self._fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND
                                       | getattr(os, "O_BINARY", 0), 0o600)
                    self._size = 0
                    self._rotating = False
                    self._drain()
            with self._lock:
                now = self.clock()
                if self._last_hb is None or now - self._last_hb >= self.heartbeat_ns:
                    self._queue("hb", self._counts())
                    self._drain()
                    self._last_hb = now
            os.fsync(self._fd)
        except Exception:
            self.lossy = True
            if self._rotating:
                self._off = True

    def quiesce(self):
        """Drain under the write lock, append final watermark, latch even on failure."""
        if not self._active or self._stopped:
            return False
        with self._worker_lock:
            return self._quiesce()

    def _quiesce(self):
        if not self._active or self._stopped:
            return False
        success = False
        try:
            with self._lock:
                self._stopped = True
                self._drain()
                self._queue("quiesce", self._counts())
                success = self._drain()
            os.fsync(self._fd)
        except Exception:
            self.lossy = True
            success = False
        finally:
            self.close()
        return success

    def close(self):
        """Release descriptors, with no quiesce marker or fsync (abandoned session)."""
        self._active = False
        self._stopped = True
        for name in ("_fd", "_lock_fd"):
            fd = getattr(self, name)
            setattr(self, name, None)
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:
                    pass


Writer = DisturbanceLog


@dataclass
class Session:
    session_id: str
    header: dict
    rows: list = field(default_factory=list)
    events: list = field(default_factory=list)
    bindings: list = field(default_factory=list)
    clean: bool = False
    lossy: bool = False
    truncated: bool = False
    quiesce: dict | None = None


@dataclass
class ReadResult:
    sessions: list = field(default_factory=list)
    problem: str | None = None


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate key")
        result[key] = value
    return result


def read_log(data, *generations, max_bytes=DEFAULT_MAX_BYTES, max_rows=DEFAULT_MAX_ROWS):
    """Pure strict parser of chronological generation bytes (oldest first).

    Also accepts a list/tuple of generation bytes. No path opening is performed:
    PD3's caller owns pinned-descriptor reads. Any parse problem discards ALL
    sessions. A retained initial cont is marked truncated; coverage must not
    infer events before it. Rows after quiesce are preserved but void clean.
    """
    try:
        chunks = (data, *generations) if generations else (list(data) if isinstance(data, (list, tuple)) else [data])
        if max_bytes < 0 or max_rows < 0:
            raise ValueError("invalid input bound")
        if any(type(chunk) is not bytes for chunk in chunks):
            raise ValueError("input must be bytes")
        if sum(map(len, chunks)) > max_bytes:
            raise ValueError("input exceeds byte bound")
        sessions, seen = [], set()
        current = None
        previous_seq = previous_at = None
        last_at = None
        event_count = dropped = 0
        row_count = 0
        for chunk in chunks:
            if chunk and not chunk.endswith(b"\n"):
                raise ValueError("unterminated row")
            # Do not split the entire input into a second unbounded row list.
            start = 0
            while start < len(chunk):
                end = chunk.find(b"\n", start) + 1
                raw = chunk[start:end]
                start = end
                row_count += 1
                if row_count > max_rows:
                    raise ValueError("input exceeds row bound")
                if len(raw) > MAX_ROW_BYTES:
                    raise ValueError("row exceeds 2048 bytes")
                row = json.loads(raw, object_pairs_hook=_unique,
                                 parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON")))
                _validate(row)
                if last_at is not None and row["at_ns"] < last_at:
                    raise ValueError("at_ns backwards")
                last_at = row["at_ns"]
                kind = row["kind"]
                sid = row["session_id"]
                if kind == "open" or (kind == "cont" and current is None):
                    if sid in seen:
                        raise ValueError("duplicate session")
                    seen.add(sid)
                    current = Session(sid, {k: row[k] for k in _HEADER}, truncated=kind == "cont")
                    sessions.append(current)
                    previous_seq = row["seq"] - 1
                    previous_at = row["at_ns"]
                    event_count = row.get("events", 0)
                    dropped = row.get("dropped", 0)
                if current is None or sid != current.session_id:
                    raise ValueError("row outside current session")
                if row["seq"] != previous_seq + 1:
                    raise ValueError("seq hole")
                if row["at_ns"] < previous_at:
                    raise ValueError("at_ns backwards")
                if kind == "cont" and {k: row[k] for k in _HEADER} != current.header:
                    raise ValueError("continuation identity mismatch")
                if current.quiesce is not None:
                    current.clean = False
                previous_seq, previous_at = row["seq"], row["at_ns"]
                current.rows.append(row)
                if kind == "d":
                    current.events.append(row)
                    event_count += 1
                elif kind == "bind":
                    current.bindings.append(row)
                elif kind in {"cont", "hb", "quiesce"}:
                    if row["events"] != event_count or row["dropped"] < dropped:
                        raise ValueError("watermark mismatch")
                    if current.lossy and not row["lossy"]:
                        raise ValueError("lossy not sticky")
                    dropped = row["dropped"]
                    current.lossy |= row["lossy"]
                    if kind == "quiesce":
                        if current.quiesce is None:
                            current.clean = not (current.lossy or row["pending"] or row["dropped"])
                        current.quiesce = row
        return ReadResult(sessions=sessions)
    except (ValueError, TypeError, UnicodeError, RecursionError) as exc:
        return ReadResult(problem=str(exc))
