"""Kashbot allocation-decision evidence, with no execution authority.

Use a dedicated, explicitly named database. Like experiments, this API inherits
Ledger's single-writer contract: callers must serialize writers and reads with
writes. Records are account allocation decisions, never sizing instructions,
assignment authority, trade reversals, or approval to activate an engine.

Receipts are event dictionaries with ledger row/hash metadata. History is in
append order. Engine version/revision are future economics join keys only.
A non-retrospective record is not experiment preregistration.
"""
from __future__ import annotations

import json
import re
import sqlite3
import threading
import time
from contextlib import closing
from dataclasses import asdict
from pathlib import Path

from .engines import Engine, engine_revision
from .experiments import _ReadLedger
from .ledger import Ledger, LedgerFailed

_MAX_EVENTS = 100_000
_MAX_BYTES = 32_768
_MAX_INT = 2**63 - 1
_COMMON = {
    "schema_version", "event_id", "account_id", "actor_ref", "engine_id",
    "engine_version", "engine_revision", "before_bps", "after_bps", "recorded_ns",
}
_CHANGE = _COMMON | {
    "experiment_id", "hypothesis", "evaluation_start_ns", "evaluation_end_ns",
    "reversal_condition", "retrospective",
}
_REVERSAL = _COMMON | {"change_event_id", "reason"}
_IDENTITY = ("account_id", "engine_id", "engine_version", "engine_revision")


class AllocationHistoryRefused(ValueError):
    """Invalid caller content or malformed allocation history."""


def _integer(value, name, minimum=0, maximum=_MAX_INT):
    if type(value) is not int or not minimum <= value <= maximum:
        raise AllocationHistoryRefused(f"{name}: integer out of range")


def _text(value, name, maximum=256):
    if type(value) is not str or not value.strip() or len(value) > maximum:
        raise AllocationHistoryRefused(f"{name}: expected bounded nonempty text")


def _encoded(event):
    try:
        raw = json.dumps(event, sort_keys=True, separators=(",", ":"),
                         allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, UnicodeError) as exc:
        raise AllocationHistoryRefused("invalid event JSON") from exc
    if len(raw) > _MAX_BYTES:
        raise AllocationHistoryRefused("event exceeds 32768 bytes")
    return raw


def _validate(kind, body):
    fields = _CHANGE if kind == "allocation_change" else _REVERSAL
    if kind not in ("allocation_change", "allocation_reversal"):
        raise AllocationHistoryRefused("unsupported event kind")
    if type(body) is not dict or set(body) != fields:
        raise AllocationHistoryRefused("unsupported or missing event fields")
    _integer(body["schema_version"], "schema_version", 1, 1)
    for name in ("event_id", "account_id", "actor_ref", "engine_id"):
        _text(body[name], name)
    _integer(body["engine_version"], "engine_version", 1)
    revision = body["engine_revision"]
    if type(revision) is not str or not re.fullmatch(r"[0-9a-f]{64}", revision):
        raise AllocationHistoryRefused("invalid engine_revision")
    _integer(body["recorded_ns"], "recorded_ns")
    for name in ("before_bps", "after_bps"):
        _integer(body[name], name, 0, 10_000)
    if body["before_bps"] == body["after_bps"]:
        raise AllocationHistoryRefused("allocation must change")
    if kind == "allocation_change":
        if body["experiment_id"] is not None:
            _text(body["experiment_id"], "experiment_id")
        for name in ("hypothesis", "reversal_condition"):
            _text(body[name], name, 8192)
        for name in ("evaluation_start_ns", "evaluation_end_ns"):
            _integer(body[name], name)
        if body["evaluation_start_ns"] >= body["evaluation_end_ns"]:
            raise AllocationHistoryRefused("evaluation start must precede end")
        retrospective = body["recorded_ns"] >= body["evaluation_start_ns"]
        if type(body["retrospective"]) is not bool or body["retrospective"] != retrospective:
            raise AllocationHistoryRefused("invalid retrospective label")
    else:
        _text(body["change_event_id"], "change_event_id")
        _text(body["reason"], "reason", 8192)
    _encoded({"kind": kind, **body})


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise AllocationHistoryRefused("duplicate JSON key")
        result[key] = value
    return result


def _checkpoint(ledger):
    """Do not inherit Ledger's tolerance for absent or lagging checkpoints."""
    if ledger.failed:
        raise LedgerFailed(ledger.failed)
    if not ledger.head_path.exists():
        if ledger._count:
            raise LedgerFailed("missing allocation checkpoint; explicit recovery required")
        return
    try:
        with ledger.head_path.open("rb") as source:
            raw = source.read(1025)
        if len(raw) > 1024:
            raise ValueError("oversized checkpoint")
        checkpoint = json.loads(raw, object_pairs_hook=_unique)
        if (type(checkpoint) is not dict or set(checkpoint) != {"count", "head"}
                or type(checkpoint["count"]) is not int
                or checkpoint["count"] != ledger._count
                or checkpoint["head"] != ledger._prev_hash):
            raise ValueError("checkpoint mismatch")
    except (OSError, ValueError, TypeError) as exc:
        raise LedgerFailed("allocation checkpoint mismatch; explicit recovery required") from exc


def _history(ledger):
    if ledger._count > _MAX_EVENTS:
        raise AllocationHistoryRefused("allocation event limit exceeded")
    _checkpoint(ledger)
    events, by_id, links = [], {}, {}
    cursor = ledger._conn.execute(
        "SELECT rowid, ts_ns, kind, body, hash FROM events ORDER BY rowid LIMIT ?",
        (_MAX_EVENTS + 1,),
    )
    for row, ts, kind, raw, digest in cursor:
        if len(events) >= _MAX_EVENTS:
            raise AllocationHistoryRefused("allocation event limit exceeded")
        if type(raw) is not str or len(raw.encode("utf-8")) > _MAX_BYTES:
            raise AllocationHistoryRefused("invalid stored event size")
        try:
            body = json.loads(raw, object_pairs_hook=_unique)
        except (ValueError, RecursionError) as exc:
            raise AllocationHistoryRefused("invalid stored event JSON") from exc
        _validate(kind, body)
        if type(ts) is not int or body["recorded_ns"] != ts:
            raise AllocationHistoryRefused("stored timestamp mismatch")
        eid = body["event_id"]
        if eid in by_id:
            raise AllocationHistoryRefused("duplicate event_id in storage")
        if kind == "allocation_reversal":
            target = by_id.get(body["change_event_id"])
            if target is None or target["kind"] != "allocation_change":
                raise AllocationHistoryRefused("reversal must reference an earlier change")
            if any(body[key] != target[key] for key in _IDENTITY):
                raise AllocationHistoryRefused("reversal identity mismatch")
            if (body["before_bps"] != target["after_bps"]
                    or body["after_bps"] != target["before_bps"]):
                raise AllocationHistoryRefused("reversal allocation mismatch")
            if body["change_event_id"] in links:
                raise AllocationHistoryRefused("change already reversed")
            links[body["change_event_id"]] = eid
        event = {"kind": kind, **body, "row": row, "hash": digest}
        events.append(event)
        by_id[eid] = event
    return events, by_id, links


def _snapshot(path):
    with closing(_AllocationReadLedger(path)) as ledger:
        events, by_id, links = _history(ledger)
        return events, by_id, links, ledger._count, ledger._prev_hash


class _AllocationReadLedger(_ReadLedger):
    def __init__(self, path):
        self.path = Path(path)
        self.head_path = self.path.with_suffix(self.path.suffix + ".head")
        if not self.path.is_file():
            raise AllocationHistoryRefused("allocation ledger file does not exist")
        # Escape URI delimiters in the path so mode=ro cannot become a fragment
        # or part of a filename. SQLite also refuses creation if the file vanishes.
        self._conn = sqlite3.connect(
            self.path.resolve().as_uri() + "?mode=ro", uri=True, timeout=2.0,
        )
        self._lock = threading.Lock()
        self._buf = []
        self.failed = ""
        try:
            self._conn.execute("BEGIN")
            ok, self._count, self._prev_hash = self._verify_locked()
            if not ok:
                raise LedgerFailed("chain broken")
            self._check_head_sidecar()
        except Exception:
            self._conn.close()
            raise

    def _verify_locked(self):
        # Bound work before the inherited chain verifier walks the snapshot.
        if self.count() > _MAX_EVENTS:
            raise AllocationHistoryRefused("allocation event limit exceeded")
        return super()._verify_locked()


def _caller_content(event):
    return {key: value for key, value in event.items()
            if key not in {"recorded_ns", "retrospective", "row", "hash"}}


class AllocationHistory:
    """A single writer for a dedicated evidence ledger; no default path.

    now_ns is an optional caller clock for deterministic recording. The event's
    original timestamp and retrospective label survive exact retries. A failure
    latches this instance; reopening cannot repair a missing/lagging checkpoint.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._closed = False
        self._failed = ""
        if self.path.exists():
            _snapshot(self.path)  # Refuse unhealthy storage before writable open.
        elif self.path.with_suffix(self.path.suffix + ".head").exists():
            raise LedgerFailed("allocation database missing but checkpoint exists")
        self._ledger = Ledger(self.path)

    def _state(self):
        if self._closed or self._failed or self._ledger.failed:
            raise LedgerFailed(self._failed or self._ledger.failed or "history closed")
        try:
            state = _snapshot(self.path)
            if state[3:] != (self._ledger._count, self._ledger._prev_hash):
                raise LedgerFailed("allocation history changed outside its single writer")
            return state[:3]
        except Exception:
            self._failed = "allocation storage validation failed"
            raise

    def _record(self, kind, body, state):
        events, by_id, links = state
        existing = by_id.get(body["event_id"])
        if existing is not None:
            # Validate retry content with the original generated fields. A clock
            # crossing the window or gaining a digit cannot invalidate a retry.
            body = {**body, "recorded_ns": existing["recorded_ns"]}
            if kind == "allocation_change" and "retrospective" in existing:
                body["retrospective"] = existing["retrospective"]
        _validate(kind, body)
        candidate = {"kind": kind, **body}
        if existing is not None:
            if _caller_content(existing) != _caller_content(candidate):
                raise AllocationHistoryRefused("event_id reused with different content")
            return dict(existing)
        if kind == "allocation_reversal" and body["change_event_id"] in links:
            raise AllocationHistoryRefused("change already reversed")
        if len(events) >= _MAX_EVENTS:
            raise AllocationHistoryRefused("allocation event limit exceeded")
        try:
            self._ledger.append(body["recorded_ns"], kind, body)
            self._ledger.flush()
            # Success requires a verified committed row AND its exact checkpoint.
            return dict(self._state()[1][body["event_id"]])
        except Exception:
            self._failed = "allocation append failed; explicit recovery required"
            self._ledger.failed = self._ledger.failed or self._failed
            raise

    def record_change(self, *, event_id, account_id, actor_ref, engine: Engine,
                      hypothesis, evaluation_start_ns, evaluation_end_ns,
                      reversal_condition, before_bps, after_bps,
                      experiment_id=None, schema_version=1, now_ns=None):
        if not isinstance(engine, Engine):
            raise AllocationHistoryRefused("engine must be an Engine")
        _text(event_id, "event_id")
        _integer(engine.version, "engine_version", 1)
        try:
            json.dumps(asdict(engine), allow_nan=False)
        except (ValueError, TypeError, UnicodeError) as exc:
            raise AllocationHistoryRefused("engine contains invalid JSON values") from exc
        ts = time.time_ns() if now_ns is None else now_ns
        _integer(ts, "recorded_ns")
        _integer(evaluation_start_ns, "evaluation_start_ns")
        body = {
            "schema_version": schema_version, "event_id": event_id,
            "account_id": account_id, "actor_ref": actor_ref,
            "engine_id": engine.engine_id, "engine_version": engine.version,
            "engine_revision": engine_revision(engine), "experiment_id": experiment_id,
            "hypothesis": hypothesis, "evaluation_start_ns": evaluation_start_ns,
            "evaluation_end_ns": evaluation_end_ns, "reversal_condition": reversal_condition,
            "before_bps": before_bps, "after_bps": after_bps, "recorded_ns": ts,
            "retrospective": ts >= evaluation_start_ns,
        }
        return self._record("allocation_change", body, self._state())

    def record_reversal(self, *, event_id, account_id, actor_ref, change_event_id,
                        reason, schema_version=1, now_ns=None):
        for name, value in (("event_id", event_id), ("account_id", account_id),
                            ("actor_ref", actor_ref), ("change_event_id", change_event_id)):
            _text(value, name)
        ts = time.time_ns() if now_ns is None else now_ns
        _integer(ts, "recorded_ns")
        state = self._state()
        target = state[1].get(change_event_id)
        if target is None or target["kind"] != "allocation_change":
            raise AllocationHistoryRefused("reversal must reference an earlier change")
        if target["account_id"] != account_id:
            raise AllocationHistoryRefused("cross-account reversal refused")
        body = {
            "schema_version": schema_version, "event_id": event_id,
            **{key: target[key] for key in _IDENTITY}, "actor_ref": actor_ref,
            "change_event_id": change_event_id, "reason": reason,
            "before_bps": target["after_bps"], "after_bps": target["before_bps"],
            "recorded_ns": ts,
        }
        return self._record("allocation_reversal", body, state)

    def close(self):
        if not self._closed:
            self._closed = True
            if self._failed:
                self._ledger.failed = self._ledger.failed or self._failed
            self._ledger.close()


def read_history(path, *, account_id, engine_id=None, limit=1000):
    """Read all validated evidence, then scope and take the first limit events.

    reversal_links includes links for all matching changes, even when a linked
    reversal is past the page limit. No current allocation or P&L is inferred.
    Missing storage returns empty without creating a database or checkpoint.
    """
    _text(account_id, "account_id")
    if engine_id is not None:
        _text(engine_id, "engine_id")
    _integer(limit, "limit", 1, _MAX_EVENTS)
    path = Path(path)
    result = {"schema_version": 1, "account_id": account_id, "engine_id": engine_id,
              "events": [], "truncated": False, "reversal_links": {}}
    if not path.exists():
        if path.with_suffix(path.suffix + ".head").exists():
            raise LedgerFailed("allocation database missing but checkpoint exists")
        return result
    events, _, links, _, _ = _snapshot(path)
    selected = [event for event in events if event["account_id"] == account_id
                and (engine_id is None or event["engine_id"] == engine_id)]
    result["events"] = selected[:limit]
    result["truncated"] = len(selected) > limit
    result["reversal_links"] = {event["event_id"]: links[event["event_id"]]
                                for event in selected if event["event_id"] in links}
    return result
