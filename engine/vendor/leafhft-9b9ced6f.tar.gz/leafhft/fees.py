"""Venue fee schedules in integer basis points at the base 30-day-volume tier.

Numbers are the ones a fresh $100 account actually pays, verified 2026-09-05 (see REPORT.md sources):
  coinbase   Advanced Trade Intro tier (< $1K 30d volume): 60 bps maker / 120 bps taker
  kraken     Pro tier 1 (< $2.5K 30d volume):            40 bps maker /  80 bps taker
  binanceus  every Advanced (spot) pair since 2026-04-22:  0 bps maker /   2 bps taker (default, conservative)
  binanceus_tier0  Tier 0 pairs (BTC/USD listed by secondary sources): 0 bps maker / 1 bps taker

Fees are charged on notional in quote units, rounded UP (the venue never rounds in your favor).
"""
from __future__ import annotations

from dataclasses import dataclass

from .types import Liquidity, notional_q

BPS_DEN = 10_000


@dataclass(frozen=True, slots=True)
class FeeSchedule:
    venue: str
    maker_bps: int
    taker_bps: int

    def __post_init__(self) -> None:
        if not (0 <= self.maker_bps <= 1000 and 0 <= self.taker_bps <= 1000):
            raise ValueError("fee bps out of range")

    def fee_q(self, price_i: int, size_i: int, liq: Liquidity) -> int:
        """Fee in quote units for a fill of size at price. Ceil division: never under-charges."""
        bps = self.maker_bps if liq is Liquidity.MAKER else self.taker_bps
        n = notional_q(price_i, size_i)
        return -(-n * bps // BPS_DEN)

    def round_trip_bps(self, liq_in: Liquidity, liq_out: Liquidity) -> int:
        a = self.maker_bps if liq_in is Liquidity.MAKER else self.taker_bps
        b = self.maker_bps if liq_out is Liquidity.MAKER else self.taker_bps
        return a + b

    def fee_death_round_trips(self, liq_in: Liquidity, liq_out: Liquidity) -> float:
        """Round trips until fees alone consume the whole stake with zero price movement.

        Each round trip multiplies equity by (1 - rt/10000); solve for equity -> 0 asymptotically,
        so report the count at which 99% is gone. Infinite when the round trip is free.
        """
        rt = self.round_trip_bps(liq_in, liq_out)
        if rt == 0:
            return float("inf")
        import math

        return math.log(0.01) / math.log(1.0 - rt / BPS_DEN)


SCHEDULES: dict[str, FeeSchedule] = {
    "coinbase": FeeSchedule("coinbase", 60, 120),
    "kraken": FeeSchedule("kraken", 40, 80),
    "binanceus": FeeSchedule("binanceus", 0, 2),
    "binanceus_tier0": FeeSchedule("binanceus_tier0", 0, 1),
}


def schedule_for(venue: str) -> FeeSchedule:
    try:
        return SCHEDULES[venue]
    except KeyError as e:
        raise ValueError(f"unknown venue fee schedule {venue!r}; refusing to guess") from e
