"""Engine conformance: one receipt that says a kernel is pinned, clean, deterministic, bounded and new (C11).

`conform(manifest_path, corpus, engines_dir=...)` is the logic behind
`engine_ops conform <id> --corpus <tape_or_dir>` (C11-opsconform, #560), which writes the receipt under the
evidence directory and the conform record the probe gate reads.
In order, each step failing closed with a ConformRefused code from REFUSAL_CODES:

1. validate the manifest (C4, engine_manifest.load_manifest);
2. resolve the kernel through C10's kernels.resolve_kernel for mode "offline" (pin checked,
   conforms() run) and, for a policy kernel, check the catalog policy digest the manifest pins;
3. the static guard over the pinned module bytes: no process, network, file or dynamic-import
   module, no live broker or account module, no live or credential token; a CANDIDATE kernel (any
   source that is not a KERNELS entry's exact pinned bytes) is also refused every reflection name
   (REFLECTION_NAMES), the introspection modules (CANDIDATE_DENIED_MODULES, direct or through
   __import__) and the guard's private names. This AST lint is the early, legible message;
4. deterministic replay of the corpus TWICE, each in its own subprocess with a different
   PYTHONHASHSEED, through the offline host below and under the CAPABILITY GUARD
   (install_capability_guard: refusing shims over os, the platform os module, os.path's file
   reads, os.environ, open/io.open, builtins.__import__, subprocess and sys's streams, plus an
   audit hook for file, process, network, thread and frame reaches, and gc, inspect and dis
   removed from sys.modules and refused to kernel code). Any reach attributed to
   kernel code raises `conform_capability` naming the call, even when the kernel catches it; the
   two outputs must be byte-equal after normalize_receipt, and every decision row carries every
   Proposal field that reaches execution (DECISION_FIELDS), so a seed-dependent expiry, id,
   reason or meta fails;
5. inside each replay, the checkpoint round trip (checkpoint mid-tape, restore into fresh kernels,
   identical tail over the full decision rows, byte-equal final checkpoint) and the bounds (zero
   exceptions, at most MAX_PROPOSALS per frame, evaluate p99 us recorded);
6. novelty: the declared parent and every engine assigned on shared symbols (the registry
   projection) are required inputs (`novelty_inputs_missing` otherwise, never `novel`); a thesis,
   at least one proposal, and a decision set that is neither the parent's nor any assigned
   engine's on shared symbols (`novelty_clone`); exact Jaccard or the price-tolerant overlap above
   0.9 is flagged near-clone, never refused.

The receipt binds {manifest_digest, code_sha, corpus_sha256, kernel_pin}. The replay is a pure
function of the manifest, the catalog policy, the code and the corpus: the only clock is the
tape's receive stamp (time.time and time.time_ns read it inside every kernel call), iteration is
in tape order only, and the evaluate latency samples (the one wall-clock reading) are dropped by
normalize_receipt.

What the guards prove, and where the security boundary is. CPython reflection is unbounded
(__globals__, __closure__, gc.get_referrers, object.__subclasses__, ctypes), so no in-process shim
can make an original unreachable to arbitrary kernel code. The capability guard is therefore a
DETERMINISM AND HYGIENE check: it fails a kernel that reaches for I/O by ordinary means, and it is
a first line of defense in depth. The receipt's `capability_guard` field means "armed (hygiene)".
The SECURITY boundary for kernel code is the operator's promotion PR (a KernelPin is added only by
a reviewed PR; adding `live` is a second reviewed PR, plan D3 and B7) plus the pinned-bytes loader
(kernels._PinnedLoader executes exactly the hashed bytes).
"""
from __future__ import annotations

import _io
import argparse
import ast
import builtins
import hashlib
import inspect
import io
import json
import math
import os
import random
import re
import subprocess
import sys
import sysconfig
import time
from collections import deque
from collections.abc import Mapping, MutableMapping, Sequence
from dataclasses import dataclass
from decimal import ROUND_CEILING, ROUND_FLOOR, Decimal
from pathlib import Path, PurePath
from threading import get_ident
from types import BuiltinFunctionType, FunctionType

from .books.manifest import StrictJsonError, canonical_json, strict_json_loads
from .books.tape import TapeError, iter_tape
from .engine_manifest import (KERNEL_ENTRIES, EngineManifest, ManifestInvalid, identity_digest,
                              load_manifest, manifest_digest)
from .engine_registry import MAX_REGISTRY_BYTES
from .engines import EngineRegistry
from .feeds.base import IndexTick, Lifecycle
from .feeds.kalshi import SYMBOL_MAP
from .lanes import kernels
from .lanes.base import MAX_CHECKPOINT_BYTES, MAX_PROPOSALS, DecisionFrame, bound_proposals
from .lanes.base import canonical_json as state_json
from .policy import policy_digest
from .strategy.kalshi_edge import CLOSED_STATUSES
from .strategy.settlement import SETTLEMENT_WINDOW_S
from .types import PRICE_UNIT, SIZE_UNIT, Quote

CONFORM_SCHEMA = "leafhft.conform.v1"
REPLAY_SCHEMA = "leafhft.conform.replay.v1"
MODE = "offline"
HASH_SEEDS = ("1", "2718")
DEFAULT_BALANCE_CENTS = 10_000  # the C2 fixture streams' balance
MAX_CORPUS_BYTES = 16 << 20
MAX_TAPES = 16
MAX_MARKETS = 4096  # tracked markets per tape
MAX_INDEX_OBS = 7200  # index observations kept per index id for outcomes (two hours at 1 Hz)
MAX_DECISIONS = 20_000
MAX_PEERS = 32
MAX_CODE_FILES = 4096
MAX_CODE_BYTES = 64 << 20
MAX_CHILD_OUTPUT = 8 << 20
CHILD_TIMEOUT_S = 600
EXIT_REFUSED = 3
NEAR_CLONE = (9, 10)  # a Jaccard strictly above 9/10 is flagged
PRICE_TICK_CENTS = Decimal("1")  # the tolerant overlap pairs prices within one venue tick
MAX_ASSIGNMENTS = 4096  # registry projection rows read for the required peers
MAX_REGISTRY_READ = MAX_REGISTRY_BYTES
VOLATILE_KEYS = frozenset({"evaluate_p99_us", "at"})
LABEL = "offline conformance, not a verdict"
# One decision row per proposal: every Proposal field that reaches execution, canonical. The
# expiry is an offset from the frame time; meta is its canonical JSON text.
DECISION_FIELDS = ("frame_id", "ticker", "side", "price_cents", "count", "expires_offset_ns",
                   "opportunity_id", "reason", "meta")
NOVELTY_FIELDS = 5  # novelty compares the decision itself: (frame_id, ticker, side, price, count)

REFUSAL_CODES = frozenset({
    "manifest_invalid", "kernel_unlisted", "kernel_pin_missing", "kernel_pin_mismatch",
    "kernel_stale_pin", "kernel_too_large", "kernel_mode_not_pinned", "kernel_nonconformant",
    "kernel_import_failed", "static_guard", "conform_capability", "corpus_empty", "corpus_unreadable",
    "corpus_too_large", "corpus_invalid", "corpus_changed", "code_unreadable", "replay_failed",
    "nondeterministic", "checkpoint_mismatch", "bounds_exception", "bounds_proposals",
    "bounds_invalid_proposal", "novelty_thesis", "novelty_no_proposals", "novelty_clone",
    "novelty_inputs_missing", "peer_invalid",
})

_PACKAGE_DIR = Path(__file__).resolve().parent
_PACKAGE_ROOT = _PACKAGE_DIR.parent
_TAPE_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,47}")
_SERIES_SYMBOL = {series: symbol for symbol, (series, _index) in SYMBOL_MAP.items()}
_STAMP_KEY = {"l": "local_ns", "i": "local_ns", "q": "tr"}
_CENT = Decimal("0.01")
_MAX_SIZE = Decimal("999999.99")


class ConformRefused(Exception):
    """Conformance refused; `code` is one of REFUSAL_CODES, `frame_id` names the frame when one did."""

    def __init__(self, code: str, detail: str = "", frame_id: str | None = None):
        if code not in REFUSAL_CODES:
            raise ValueError(f"unknown conform refusal code {code!r}")
        self.code = code
        self.detail = str(detail)[:1000]
        self.frame_id = frame_id
        where = f" at {frame_id}" if frame_id else ""
        super().__init__(f"{code}{where}: {self.detail}" if self.detail else f"{code}{where}")

    def to_dict(self) -> dict:
        return {"code": self.code, "detail": self.detail, "frame_id": self.frame_id}


def symbol_of(ticker: str) -> str | None:
    """The SYMBOL_MAP symbol whose series prefixes this Kalshi ticker, or None."""
    return _SERIES_SYMBOL.get(ticker.split("-", 1)[0]) if type(ticker) is str else None


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _strip(value):
    if isinstance(value, Mapping):
        return {key: _strip(item) for key, item in value.items() if key not in VOLATILE_KEYS}
    if isinstance(value, (list, tuple)):
        return [_strip(item) for item in value]
    return value


def normalize_receipt(receipt: Mapping) -> bytes:
    """Canonical bytes of a receipt or replay section without its wall-clock fields
    (VOLATILE_KEYS at any depth): equal for equal inputs in any process and hash seed."""
    return canonical_json(_strip(receipt))


# ---------------------------------------------------------------- the static guard

# Process, network, file-system, dynamic-code and interpreter-surgery modules. pathlib stays
# allowed for path arithmetic; the pinned kernels read declared models through host modules.
DENIED_MODULES = frozenset({
    "socket", "ssl", "select", "selectors", "asyncio", "subprocess", "multiprocessing", "threading",
    "_thread", "concurrent", "signal", "os", "posix", "nt", "pty", "sys", "io", "shutil", "tempfile",
    "glob", "fileinput", "mmap", "sqlite3", "dbm", "shelve", "pickle", "marshal", "ctypes", "cffi",
    "importlib", "builtins", "runpy", "code", "codeop", "http", "urllib", "urllib3", "requests",
    "httpx", "aiohttp", "websocket", "websockets", "ftplib", "smtplib", "poplib", "imaplib",
    "nntplib", "telnetlib", "xmlrpc", "socketserver", "webbrowser", "boto3", "botocore",
    "paramiko", "grpc", "psutil",
})
# The money process, venue clients and accounts. leafhft.feeds.base is plain event dataclasses.
DENIED_LEAFHFT = (
    "leafhft.broker", "leafhft.cli", "leafhft.kalshi_live_runtime", "leafhft.push", "leafhft.executor", "leafhft.kalshi_account",
    "leafhft.polymarket_us_account", "leafhft.account_lane_agent", "leafhft.account_lane_provision",
    "leafhft.account_lane_sync", "leafhft.account_shadow", "leafhft.account_signal_follower",
    "leafhft.exposure_authority", "leafhft.signal_authority", "leafhft.feeds", "leafhft.mcp",
    "leafhft.shadow_aws", "leafhft.engine_ops", "leafhft.engine_registry", "leafhft.deployed",
    "leafhft.approve_presence", "leafhft.lanes.live_runner", "leafhft.lanes.probe_runner",
)
ALLOWED_LEAFHFT = ("leafhft.feeds.base",)
DENIED_CALLS = frozenset({"open", "exec", "eval", "compile", "__import__", "breakpoint", "input"})
DENIED_NAMES = frozenset({"__builtins__", "__import__", "__loader__"})
DENIED_ATTRS = frozenset({"__subclasses__", "__builtins__", "__loader__"})
# CANDIDATE sources only (anything that is not a KERNELS entry's exact pinned bytes; a pinned kernel
# is reviewed code and its pin is the control, and the pinned darkhorse kernel rebinds a function
# through __globals__, __closure__ and types). Refused by name anywhere in the source: as an
# attribute, a bare name or a string constant (a subscript key, a getattr argument).
REFLECTION_NAMES = frozenset({
    "__globals__", "__closure__", "__wrapped__", "__self__", "__dict__", "__subclasses__", "__reduce__",
    "__reduce_ex__", "cell_contents", "f_globals", "f_back", "f_locals", "gi_frame", "cr_frame", "_getframe",
})
CANDIDATE_DENIED_MODULES = frozenset({"gc", "ctypes", "inspect", "dis", "types", "importlib", "builtins",
                                      "leafhft.engine_conform"})
# The capability guard's own internals: the private table of originals and every holder of it.
GUARD_PRIVATE_NAMES = frozenset({"_ORIGINALS", "_vault", "_Held", "_Gate", "_ImportGate", "_ClassOnly",
                                 "_GuardedEnviron", "_GuardedStream", "_SANDBOX", "_Sandbox"})
LIVE_TOKEN_PATTERNS = (
    ("live_client", re.compile(r"\bKalshiLive[A-Za-z]*\b|\bkalshi_live\b|\bLiveKalshi[A-Za-z]*\b")),
    ("venue_endpoint", re.compile(r"(?:trading-api|api\.elections|external-api|demo-api)\.kalshi\.com")),
    ("credential_env", re.compile(r"\bKALSHI_[A-Z0-9_]*(?:KEY|SECRET|TOKEN)[A-Z0-9_]*\b"
                                  r"|\bAWS_(?:SECRET_ACCESS_KEY|ACCESS_KEY_ID|SESSION_TOKEN)\b")),
    ("credential_name", re.compile(r"\b(?:api_key|api_secret|private_key|secret_key|access_token"
                                   r"|password|passphrase)\b", re.IGNORECASE)),
    ("key_material", re.compile(r"-{5}BEGIN [A-Z ]{0,32}PRIVATE KEY-{5}")),
    ("live_ack", re.compile(r"LIVE[-_]ACK")),
    ("secret_store", re.compile(r"\bsecrets?_store\b|/etc/leafhft/(?:keys|secrets|credentials)")),
)


def _denied_module(name: str) -> bool:
    if name.split(".", 1)[0] in DENIED_MODULES:
        return True
    if any(name == allowed or name.startswith(allowed + ".") for allowed in ALLOWED_LEAFHFT):
        return False
    return any(name == prefix or name.startswith(prefix + ".") for prefix in DENIED_LEAFHFT)


def _import_names(node, package: str) -> list[str]:
    if isinstance(node, ast.Import):
        return [alias.name for alias in node.names]
    if node.level:
        parts = package.split(".") if package else []
        if node.level - 1 > len(parts):
            return ["<relative import beyond the package>"]
        base = ".".join(parts[:len(parts) - (node.level - 1)] + ([node.module] if node.module else []))
    else:
        base = node.module or ""
    return [base] + [f"{base}.{alias.name}" for alias in node.names if alias.name != "*"]


def _candidate_denied_module(name: str) -> bool:
    return any(name == denied or name.startswith(denied + ".") for denied in CANDIDATE_DENIED_MODULES)


def is_pinned_source(source: bytes, module: str) -> bool:
    """True only for a KERNELS entry's module whose source digest IS its pin (reviewed code). An
    EXTRA_PINS row, a foundry lane or an edited file is a candidate. Pure; fails closed to False."""
    pin = next((pin for pin in kernels.KERNELS.values() if pin.module == module), None)
    try:
        return pin is not None and hashlib.sha256(bytes(source)).hexdigest() == pin.sha256
    except TypeError:
        return False


def _import_call_target(node) -> str | None:
    """The module named by `__import__("x")` (a bare or attribute call) with a string first argument."""
    func = node.func
    named = (isinstance(func, ast.Name) and func.id == "__import__") or (
        isinstance(func, ast.Attribute) and func.attr == "__import__")
    if named and node.args and isinstance(node.args[0], ast.Constant) and type(node.args[0].value) is str:
        return node.args[0].value
    return None


def static_guard(source: bytes, module: str = "leafhft.lanes.candidate", pinned: bool | None = None) -> list[str]:
    """Every static refusal for a kernel module's source, in source order; empty means clean.

    AST checks: imports of DENIED_MODULES / DENIED_LEAFHFT (relative imports resolved against the
    module's package), calls of DENIED_CALLS, DENIED_NAMES and DENIED_ATTRS. For a CANDIDATE
    (`pinned` False; None decides by is_pinned_source) also REFLECTION_NAMES
    (`reflect:<name>:<line>`), CANDIDATE_DENIED_MODULES imported directly or through
    `__import__("x")` (`import:<name>:<line>`) and GUARD_PRIVATE_NAMES (`private:<name>:<line>`),
    each as an attribute, a name or a string constant. Text checks: the LIVE_TOKEN_PATTERNS. Pure
    and bounded by the source, which the caller already bounded."""
    try:
        text = bytes(source).decode("utf-8")
    except (UnicodeDecodeError, TypeError):
        return ["source:not_utf8"]
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        return [f"source:syntax:{exc.lineno}"]
    candidate = not (is_pinned_source(source, module) if pinned is None else pinned)
    package = module.rpartition(".")[0]
    problems = []
    for node in ast.walk(tree):
        line = getattr(node, "lineno", 0)
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.ImportFrom) and node.module == "__future__":
                continue
            for name in _import_names(node, package):
                if name.startswith("<") or _denied_module(name) or (candidate and _candidate_denied_module(name)):
                    problems.append((line, f"import:{name}:{line}"))
                    break
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in DENIED_CALLS:
                problems.append((line, f"call:{node.func.id}:{line}"))
            target = _import_call_target(node) if candidate else None
            if target is not None and (_denied_module(target) or _candidate_denied_module(target)):
                problems.append((line, f"import:{target}:{line}"))
        elif isinstance(node, ast.Name) and node.id in DENIED_NAMES:
            problems.append((line, f"name:{node.id}:{line}"))
        elif isinstance(node, ast.Attribute) and node.attr in DENIED_ATTRS:
            problems.append((line, f"attr:{node.attr}:{line}"))
        if not candidate:
            continue
        word = (node.attr if isinstance(node, ast.Attribute) else node.id if isinstance(node, ast.Name)
                else node.value if isinstance(node, ast.Constant) and type(node.value) is str else None)
        if word in REFLECTION_NAMES and not (isinstance(node, ast.Attribute) and word in DENIED_ATTRS):
            problems.append((line, f"reflect:{word}:{line}"))
        elif word in GUARD_PRIVATE_NAMES:
            problems.append((line, f"private:{word}:{line}"))
    for code, pattern in LIVE_TOKEN_PATTERNS:
        for match in pattern.finditer(text):
            line = text.count("\n", 0, match.start()) + 1
            problems.append((line, f"token:{code}:{line}"))
    ordered, seen = [], set()
    for _line, problem in sorted(problems, key=lambda item: item[0]):
        if problem not in seen:
            seen.add(problem)
            ordered.append(problem)
    return ordered


def guard_source(source: bytes, module: str = "leafhft.lanes.candidate", pinned: bool | None = None) -> None:
    """Raise ConformRefused(static_guard) when static_guard finds anything."""
    problems = static_guard(source, module, pinned)
    if problems:
        raise ConformRefused("static_guard", f"{module}: " + "; ".join(problems[:20]))


# ---------------------------------------------------------------- the capability guard and the replay clock
#
# The AST lint above cannot see a capability reached through an allowed import
# (`from random import _os; _os.getcwd()`, `Path(...).read_bytes()`). The capability guard
# enforces on the replay itself, in the replay child only (install_capability_guard): every
# shim and the audit hook ATTRIBUTE the reach by walking the stack. Library frames (stdlib,
# site-packages, frozen) and other leafhft host frames are skipped; the first decisive frame
# wins. Kernel code (every pinned kernel module and the module defining the replayed entry
# class) is refused everything. A trusted host reader (the policy catalog, the Darkhorse
# config and model load, the pinned source loader), an import the guard admitted, or a
# host-only stack may read and load, never write, spawn, connect or start a thread. A refused
# reach is recorded before the exception reaches the kernel, so a kernel that catches it is
# still refused (conform_capability, frame named). Every shim is a bound method of a __slots__ gate
# whose function runs under an EMPTY globals namespace and holds only an integer key: no
# __wrapped__, __globals__ entry, closure cell, __dict__ entry or __self__ attribute of a shim is an
# original, and the one private table (_Held._vault, readable from the class only) leaves the
# module namespace once the child is armed (astra pass 3: `_os.getcwd.__globals__["_ORIGINALS"]`
# reached every original one lookup away). gc, inspect and dis leave sys.modules and a meta path
# finder refuses them to kernel code. This is HYGIENE, not a sandbox: CPython reflection is
# unbounded (gc, ctypes, object.__subclasses__ reach the table), so the security boundary is the
# reviewed promotion PR plus the pinned-bytes loader (module docstring). Residual, by design: a
# kernel may read through a trusted reader's own API.

STRICT, IMPORT = "strict", "import"
KERNEL, HOST, LIB, TRUSTED = "kernel", "host", "lib", "trusted"
MAX_VIOLATIONS = 16
MAX_CLASSIFIED_FILES = 4096
TRUSTED_READERS = ("engines.py", "policy.py", "config.py", "shadow_manifest.py", os.path.join("lanes", "kernels.py"))
TRUSTED_LOADERS = {os.path.join("lanes", "darkhorse.py"): frozenset({"load_models"})}
_SHIM_CODE_NAMES = frozenset({"_capability_shim", "_import_shim"})
# Introspection modules taken out of sys.modules in the replay child and refused to kernel code (a
# meta path finder and the import shim). ctypes stays: numpy, loaded before the guard arms, holds it.
REPLAY_REMOVED_MODULES = frozenset({"gc", "inspect", "dis"})
_CALLABLES = (FunctionType, BuiltinFunctionType)
# os callables that compute without touching the file system, the process or the environment.
PURE_OS = frozenset({"fspath", "fsencode", "fsdecode", "strerror", "_check_methods", "_get_exports_list",
                     "_exists"})
# os callables refused to EVERY caller in the replay child (writes, spawns, signals, identity and
# environment changes); kernel code is refused every os callable. Prefixes of the attribute name.
OS_HOST_DENIED = ("system", "popen", "spawn", "exec", "fork", "kill", "startfile", "posix_spawn", "remove",
                  "unlink", "rename", "replace", "rmdir", "mkdir", "makedirs", "chmod", "lchmod", "fchmod",
                  "chown", "lchown", "fchown", "link", "symlink", "truncate", "ftruncate", "utime", "putenv",
                  "unsetenv", "chdir", "fchdir", "write", "pwrite", "sendfile", "mkfifo", "mknod", "_exit",
                  "abort", "set", "umask", "pipe", "dup", "openpty", "login_tty", "register_at_fork", "nice",
                  "sched_set", "posix_fallocate", "copy_file_range", "splice", "memfd_create", "eventfd")
PATH_READS = ("exists", "lexists", "isfile", "isdir", "islink", "isjunction", "ismount", "isdevdrive",
              "getsize", "getmtime", "getatime", "getctime", "samefile", "sameopenfile", "realpath",
              "abspath", "expanduser", "expandvars")
# Audit events refused to kernel code: file, process, network, thread, frame and native reaches.
AUDIT_DENIED = frozenset({"open", "import", "sys._getframe", "sys._current_frames", "sys.addaudithook",
                          "_thread.start_new_thread", "gc.get_objects", "gc.get_referrers",
                          "gc.get_referents"})
AUDIT_DENIED_PREFIXES = ("os.", "subprocess.", "socket.", "shutil.", "_winapi.", "winreg.", "ctypes.",
                         "mmap.", "sqlite3.", "urllib.", "http.", "ftplib.", "smtplib.", "poplib.",
                         "imaplib.", "nntplib.", "telnetlib.", "webbrowser.", "tempfile.", "glob.", "pty.",
                         "fcntl.", "msvcrt.", "resource.", "signal.", "syslog.", "_posixsubprocess.",
                         "threading.", "sys.set", "sys.monitoring", "ssl.", "select.")
# Of those, the ones refused to every caller (plus "open" for writing): host code, the trusted
# readers and library imports may read and load, never write, spawn, connect or start a thread.
HOST_DENIED_EVENTS = frozenset({"_thread.start_new_thread", "sys.addaudithook"})
HOST_DENIED_PREFIXES = ("subprocess.", "socket.", "shutil.", "tempfile.", "threading.", "_posixsubprocess.",
                        "urllib.", "http.", "ftplib.", "smtplib.", "poplib.", "imaplib.", "nntplib.",
                        "telnetlib.", "webbrowser.", "ssl.", "sqlite3.", "mmap.", "os.system", "os.exec",
                        "os.spawn", "os.posix_spawn", "os.fork", "os.kill", "os.startfile", "os.remove",
                        "os.rename", "os.rmdir", "os.mkdir", "os.chmod", "os.chown", "os.chflags",
                        "os.lchflags", "os.lchmod", "os.lchown", "os.link", "os.symlink", "os.truncate",
                        "os.utime", "os.putenv", "os.unsetenv", "os.chdir", "os.mkfifo", "os.mknod",
                        "os.setxattr", "_winapi.CreateProcess", "_winapi.CreateFile",
                        "_winapi.CreateNamedPipe", "_winapi.CreateJunction", "_winapi.TerminateProcess",
                        "_winapi.OpenProcess")


def _write_flags() -> int:
    flags = 0
    for name in ("O_WRONLY", "O_RDWR", "O_APPEND", "O_CREAT", "O_TRUNC", "O_EXCL"):
        flags |= getattr(os, name, 0)
    return flags


_WRITE_FLAGS = _write_flags()


class _CapabilityRefused(BaseException):
    """Raised into kernel code at a refused reach. A BaseException so `except Exception` in a kernel
    does not swallow it; the reach is recorded first, so catching it changes nothing."""


def _open_is_read(mode, flags) -> bool:
    if type(mode) is str:
        return not any(char in mode for char in "wax+")
    return mode is None and type(flags) is int and not flags & _WRITE_FLAGS


def _io_open_is_read(args, kwargs) -> bool:
    return _open_is_read(args[1] if len(args) > 1 else kwargs.get("mode", "r"), 0)


def _os_open_is_read(args, kwargs) -> bool:
    return _open_is_read(None, args[1] if len(args) > 1 else kwargs.get("flags", -1))


def _audit_host_ok(event: str, args) -> bool:
    if event == "open":
        return len(args) >= 3 and _open_is_read(args[1], args[2])
    return event not in HOST_DENIED_EVENTS and not event.startswith(HOST_DENIED_PREFIXES)


def _arg_text(value) -> str:
    """A bounded, side-effect-free rendering of a refused call's first argument."""
    if type(value) in (str, bytes, int):
        return repr(value)[:120]
    if isinstance(value, PurePath) and type(value).__module__.startswith("pathlib"):
        return repr(str(value))[:120]
    return type(value).__name__


def _absolute_module(name, globals_, level):
    if not level:
        return name
    package = None
    if isinstance(globals_, dict):
        package = globals_.get("__package__")
        if not package:
            package = globals_.get("__name__") or ""
            if "__path__" not in globals_:
                package = package.rpartition(".")[0]
    parts = package.split(".") if type(package) is str and package else []
    if level - 1 > len(parts):
        return None
    base = ".".join(parts[:len(parts) - (level - 1)])
    return f"{base}.{name}" if name and base else (name or base or None)


class _ClassOnly:
    """A class attribute its instances cannot read: `holder._vault` on an instance is an
    AttributeError, so no __self__ attribute of a shim reaches the table; the guard's own methods
    read it through `self.__class__`."""

    __slots__ = ("_value",)

    def __init__(self, value):
        self._value = value

    def __get__(self, instance, owner=None):
        if instance is not None:
            raise AttributeError("_vault")
        return self._value


class _Held:
    """Base of every shim gate and proxy: a __slots__ object holding an integer key and a name,
    never its original. `_vault` maps the key to the unguarded original (astra pass 2:
    `_os.getcwd.__wrapped__()`; astra pass 3: `_os.getcwd.__globals__["_ORIGINALS"]`); only the
    guard's own methods index it, and install_guard drops every holder of it from the module
    namespace once the child is armed. Bounded by the shimmed surface (a few hundred entries, once)."""

    __slots__ = ("_key", "_name")
    _vault = _ClassOnly({})
    _sandbox = None  # the process-wide _Sandbox, set once below


def _hold(original) -> int:
    """Park `original` in the vault and return its key (install time only)."""
    vault = _Held._vault
    key = len(vault)
    vault[key] = original
    return key


class _Gate(_Held):
    """One capability shim: `_Gate(name, original, host_ok)._capability_shim` is the bound method
    installed in place of `original`; its code name is a trust anchor for its own callees."""

    __slots__ = ("_host_ok",)

    def __init__(self, name, original, host_ok):
        self._key, self._name, self._host_ok = _hold(original), name, host_ok

    def _capability_shim(self, *args, **kwargs):
        sandbox = self._sandbox
        if sandbox.guarded and not sandbox.busy:
            sandbox.gate(self._name, self._host_ok, args, kwargs)
        return self.__class__._vault[self._key](*args, **kwargs)


class _ImportGate(_Held):
    """builtins.__import__ in the replay child: `_ImportGate(original)._import_shim`."""

    __slots__ = ()

    def __init__(self, original):
        self._key, self._name = _hold(original), "__import__"

    def _import_shim(self, name, globals=None, locals=None, fromlist=(), level=0):
        sandbox = self._sandbox
        if sandbox.guarded and not sandbox.busy:
            sandbox.gate_import(name, globals, fromlist, level)
        return self.__class__._vault[self._key](name, globals, locals, fromlist, level)


def _isolated(fn):
    """fn's code under an EMPTY globals namespace (no builtins either): a shim's __globals__ leads
    nowhere. The shim bodies read only their own gate, so they need no global name."""
    return FunctionType(fn.__code__, {"__builtins__": {}}, fn.__name__, fn.__defaults__, fn.__closure__)


_Gate._capability_shim = _isolated(_Gate._capability_shim)
_ImportGate._import_shim = _isolated(_ImportGate._import_shim)


class _GuardedEnviron(_Held, MutableMapping):
    """os.environ in the replay child: kernel code may neither read nor write the environment."""

    __slots__ = ()

    def __init__(self, environ, name):
        self._key = _hold(environ)
        self._name = name

    def __getitem__(self, key):
        _SANDBOX.gate(self._name, True, (key,))
        return self.__class__._vault[self._key][key]

    def __setitem__(self, key, value):
        _SANDBOX.gate(self._name, False, (key,))
        self.__class__._vault[self._key][key] = value

    def __delitem__(self, key):
        _SANDBOX.gate(self._name, False, (key,))
        del self.__class__._vault[self._key][key]

    def __iter__(self):
        _SANDBOX.gate(self._name, True)
        return iter(list(self.__class__._vault[self._key]))

    def __len__(self):
        _SANDBOX.gate(self._name, True)
        return len(self.__class__._vault[self._key])

    def copy(self):
        _SANDBOX.gate(self._name, True)
        return dict(self.__class__._vault[self._key])


class _GuardedStream(_Held):
    """sys.stdout / sys.stderr in the replay child: kernel code may not touch the process streams
    (the child's verdict travels on stdout)."""

    __slots__ = ()

    def __init__(self, stream, name):
        object.__setattr__(self, "_key", _hold(stream))
        object.__setattr__(self, "_name", name)

    def __getattr__(self, attr):
        _SANDBOX.gate(f"{self._name}.{attr}", True)
        return getattr(self.__class__._vault[self._key], attr)

    def __setattr__(self, attr, value):
        _SANDBOX.gate(f"{self._name}.{attr}", True)
        setattr(self.__class__._vault[self._key], attr, value)


class _RemovedModuleFinder:
    """First on sys.meta_path in the replay child: a load of a REPLAY_REMOVED_MODULES module that
    kernel code reached (importlib.import_module included, which skips builtins.__import__) is
    conform_capability; every other load falls through to the normal finders."""

    __slots__ = ()

    def find_spec(self, fullname, path=None, target=None):
        if fullname in REPLAY_REMOVED_MODULES:
            _SANDBOX.gate("import", True, (fullname,))
        return None


# Every module-global name that leads to the vault; install_guard removes them once the child is armed.
_VAULT_HOLDERS = ("_hold", "_ClassOnly", "_Held", "_Gate", "_ImportGate", "_isolated", "_GuardedEnviron",
                  "_GuardedStream")


class _Sandbox:
    """The replay's process-wide seams. The replay clock is always installed and is inert unless a
    kernel call runs on the calling thread. The capability guard exists only in a process that
    called install_guard (the replay child); it cannot be uninstalled (an audit hook never can)."""

    def __init__(self):
        self.thread = None   # ident of the thread inside a kernel call
        self.now_ns = 0      # the replay clock inside that call
        self.mode = STRICT   # IMPORT while a kernel module is being loaded
        self.clock_installed = False
        self.guarded = False
        self.busy = False    # reentrancy: the guard's own frame walks and formatting
        self.violations: list = []
        self.kinds: dict = {}
        self.package_prefixes: tuple = ()
        self.lib_prefixes: tuple = ()
        self.trusted_files: frozenset = frozenset()
        self.kernel_files: set = set()
        self.anchors: dict = {}

    # the replay clock
    def install_clock(self) -> None:
        """time.time / time.time_ns read the tape's receive stamp inside a kernel call, the real clock
        everywhere else; a kernel's wall-clock reading is then a function of the corpus."""
        if self.clock_installed:
            return
        real_time, real_time_ns, sandbox = time.time, time.time_ns, self

        def time_on_the_tape():
            return sandbox.now_ns / 1e9 if sandbox.thread == get_ident() else real_time()

        def time_ns_on_the_tape():
            return sandbox.now_ns if sandbox.thread == get_ident() else real_time_ns()

        time.time, time.time_ns = time_on_the_tape, time_ns_on_the_tape
        self.clock_installed = True

    def call(self, mode, now_ns, frame_id, fn, *args):
        """fn(*args) as kernel code on the replay clock. In the guarded child any refused reach, even one
        the kernel caught, raises conform_capability with frame_id once fn returns or raises."""
        outer = (self.thread, self.mode, self.now_ns)
        self.thread, self.mode, self.now_ns = get_ident(), mode, now_ns
        try:
            return fn(*args)
        except _CapabilityRefused:
            return None  # recorded; the finally clause refuses
        finally:
            self.thread, self.mode, self.now_ns = outer
            self.raise_violations(frame_id)

    def raise_violations(self, frame_id=None) -> None:
        if self.violations:
            found, self.violations = self.violations, []
            raise ConformRefused("conform_capability", "; ".join(found), frame_id)

    # attribution
    def _classify(self, filename: str) -> tuple:
        if filename.startswith("<frozen "):
            entry = (LIB, None)
        elif not os.path.isabs(filename):
            entry = (HOST, None)  # "<string>" and the like belong to whoever called them
        else:
            norm = os.path.normcase(filename)
            if norm in self.trusted_files:
                kind = TRUSTED
            elif norm in self.kernel_files:
                kind = KERNEL
            elif norm.startswith(self.package_prefixes):
                kind = HOST
            elif norm.startswith(self.lib_prefixes):
                kind = LIB
            else:
                kind = HOST
            entry = (kind, self.anchors.get(norm))
        if len(self.kinds) < MAX_CLASSIFIED_FILES:
            self.kinds[filename] = entry
        return entry

    def attribute(self, frame) -> str:
        """KERNEL when the nearest decisive frame is kernel code; TRUSTED when it is a trusted reader
        or a shim that already decided, or when no frame decides (a host-only stack)."""
        while frame is not None:
            code = frame.f_code
            kind, anchors = self.kinds.get(code.co_filename) or self._classify(code.co_filename)
            if anchors is not None and code.co_name in anchors:
                return TRUSTED
            if kind is KERNEL or kind is TRUSTED:
                return kind
            frame = frame.f_back
        return TRUSTED

    def _caller(self, depth: int):
        try:
            return sys._getframe(depth + 1)
        except ValueError:
            return None

    def gate(self, name, host_ok, args=(), kwargs=None) -> None:
        """Called directly by a shim or proxy: refuse `name` when kernel code reached it, or when other
        code did and host_ok is neither True nor a predicate accepting (args, kwargs)."""
        if not self.guarded or self.busy:
            return
        self.busy = True
        try:
            verdict = self.attribute(self._caller(2))
        finally:
            self.busy = False
        if verdict is KERNEL or not (host_ok is True or (callable(host_ok) and host_ok(args, kwargs or {}))):
            self.refuse(name, args)

    def gate_import(self, name, globals_, fromlist, level) -> None:
        """Called directly by the import shim: refuse a kernel import import_problem names."""
        self.busy = True
        try:
            verdict = self.attribute(self._caller(2))
        finally:
            self.busy = False
        if verdict is KERNEL:
            problem = self.import_problem(name, globals_, fromlist, level)
            if problem is not None:
                self.refuse("__import__", (problem,))

    def refuse(self, name, args=()):
        self.busy = True
        try:
            text = f"{name}({_arg_text(args[0])})" if args else name
        finally:
            self.busy = False
        if len(self.violations) < MAX_VIOLATIONS:
            self.violations.append(text)
        raise _CapabilityRefused(text)

    def _audit(self, event, args) -> None:
        if not self.guarded or self.busy:
            return
        if event not in AUDIT_DENIED and not event.startswith(AUDIT_DENIED_PREFIXES):
            return
        self.busy = True
        try:
            frame = self._caller(1)
            if (event == "sys._getframe" and frame is not None
                    and (self.kinds.get(frame.f_code.co_filename) or self._classify(frame.f_code.co_filename))[0] is LIB):
                verdict = TRUSTED  # a library asked for a frame (inspect, logging), not kernel code
            else:
                verdict = self.attribute(frame)
        finally:
            self.busy = False
        if verdict is KERNEL or not _audit_host_ok(event, args):
            self.refuse(event, args)

    def import_problem(self, name, globals_, fromlist, level):
        """The module a kernel import would reach and must not: a denied or REPLAY_REMOVED_MODULES
        module or submodule, or in STRICT mode (after the kernel is loaded) any first load or a
        not-yet-loaded submodule."""
        target = _absolute_module(name, globals_, level)
        if target is None:
            return f"<relative import beyond the package>.{name}"
        if _denied_module(target) or target.split(".", 1)[0] in REPLAY_REMOVED_MODULES:
            return target
        items = [item for item in (fromlist or ()) if type(item) is str and item != "*"]
        for item in items:
            if _denied_module(f"{target}.{item}"):
                return f"{target}.{item}"
        if self.mode is IMPORT:
            return None
        module = sys.modules.get(target)
        if module is None:
            return target
        for item in items:
            if f"{target}.{item}" not in sys.modules and item not in getattr(module, "__dict__", {}):
                return f"{target}.{item}"
        return None

    def register_kernel(self, entry_cls) -> None:
        """Every file defining entry_cls or a base outside the leafhft package is kernel code (the
        pinned modules already are)."""
        if not self.guarded:
            return
        files = set()
        for klass in tuple(getattr(entry_cls, "__mro__", ()))[:64]:
            if klass is object:
                continue
            for value in tuple(vars(klass).values())[:4096]:
                if isinstance(value, (classmethod, staticmethod)):
                    value = value.__func__
                if isinstance(value, FunctionType):
                    files.add(value.__code__.co_filename)
            module = sys.modules.get(getattr(klass, "__module__", None))
            file = getattr(module, "__file__", None)
            if type(file) is str:
                files.add(file)
        for file in files:
            if type(file) is str and os.path.isabs(file):
                norm = os.path.normcase(file)
                if not norm.startswith(self.package_prefixes) and not norm.startswith(self.lib_prefixes):
                    self.kernel_files.add(norm)
        self.kinds = {}

    # installation
    def _tables(self) -> None:
        def norm(path):
            return os.path.normcase(os.path.abspath(os.fspath(path)))

        packages = {norm(_PACKAGE_DIR), norm(os.path.dirname(os.path.abspath(__file__)))}
        self.package_prefixes = tuple(sorted(path.rstrip("\\/") + os.sep for path in packages))
        paths = sysconfig.get_paths()
        self.lib_prefixes = tuple(sorted({norm(paths[key]).rstrip("\\/") + os.sep
                                          for key in ("stdlib", "platstdlib", "purelib", "platlib")
                                          if paths.get(key)}))
        self.trusted_files = frozenset(prefix + os.path.normcase(rel)
                                       for prefix in self.package_prefixes for rel in TRUSTED_READERS)
        try:
            modules = [pin.module for pin in kernels.pins().values()]
        except ValueError:
            modules = []
        for module in modules:
            self.kernel_files.add(norm(kernels.module_path(module)))
            rel = os.path.normcase(os.path.join(*module.split(".")[1:]) + ".py")
            self.kernel_files.update(prefix + rel for prefix in self.package_prefixes)
        anchors = {norm(__file__): _SHIM_CODE_NAMES}
        for prefix in self.package_prefixes:
            anchors[prefix + os.path.normcase("engine_conform.py")] = _SHIM_CODE_NAMES
            for rel, names in TRUSTED_LOADERS.items():
                anchors[prefix + os.path.normcase(rel)] = names
        self.anchors = anchors
        self.kinds = {}

    def _shim(self, name, original, host_ok):
        """`original` behind the gate: the bound method `_capability_shim` of a fresh _Gate. Its
        __self__ is a __slots__ gate holding a key, its __globals__ is empty, and it has no closure,
        __wrapped__, defaults or __dict__ entry: no reach path of the shim is a forbidden original."""
        return _Gate(name, original, host_ok)._capability_shim

    def install_guard(self) -> None:
        """Install every shim and the audit hook; idempotent. Shims are installed BEFORE any kernel
        module is imported, so a module-level alias (`g = _os.getcwd`) captures the shim."""
        if self.guarded:
            return
        self.install_clock()
        self._tables()
        sys.dont_write_bytecode = True  # an import must only read: no __pycache__ write in the child
        native = sys.modules.get(os.name)
        support = [table for table in (getattr(os, name, None) for name in (
            "supports_dir_fd", "supports_fd", "supports_effective_ids", "supports_follow_symlinks"))
            if isinstance(table, set)]
        for module, label in ((os, "os"), (native, os.name)):
            if module is None:
                continue
            for attr, value in list(vars(module).items()):
                if attr in PURE_OS or attr.startswith("__") or not isinstance(value, _CALLABLES):
                    continue
                if attr == "open":
                    host_ok = _os_open_is_read
                elif attr == "fdopen":
                    host_ok = _io_open_is_read
                else:
                    host_ok = None if attr.lstrip("_").startswith(OS_HOST_DENIED) or attr == "_exit" else True
                shim = self._shim(f"{label}.{attr}", value, host_ok)
                setattr(module, attr, shim)
                for table in support:
                    if value in table:  # the shim replaces the original: the table exposes no original
                        table.discard(value)
                        table.add(shim)
            for attr in ("environ", "environb"):
                value = getattr(module, attr, None)
                if isinstance(value, Mapping) and not isinstance(value, _GuardedEnviron):
                    setattr(module, attr, _GuardedEnviron(value, f"{label}.{attr}"))
        for attr in PATH_READS:
            value = getattr(os.path, attr, None)
            if isinstance(value, _CALLABLES):
                setattr(os.path, attr, self._shim(f"os.path.{attr}", value, True))
        for module, label in ((builtins, "open"), (io, "io.open"), (_io, "_io.open")):
            module.open = self._shim(label, module.open, _io_open_is_read)
        for attr in ("Popen", "run", "call", "check_call", "check_output", "getoutput", "getstatusoutput"):
            value = getattr(subprocess, attr, None)
            if value is not None:
                setattr(subprocess, attr, self._shim(f"subprocess.{attr}", value, None))
        socket_module = sys.modules.get("socket")
        if socket_module is not None:
            for attr in ("create_connection", "create_server", "getaddrinfo", "gethostbyname",
                         "gethostbyname_ex", "gethostbyaddr", "getfqdn", "socketpair", "fromfd"):
                value = getattr(socket_module, attr, None)
                if isinstance(value, _CALLABLES):
                    setattr(socket_module, attr, self._shim(f"socket.{attr}", value, None))
        for attr in ("stdout", "stderr", "__stdout__", "__stderr__"):
            stream = getattr(sys, attr, None)
            if stream is not None and not isinstance(stream, _GuardedStream):
                setattr(sys, attr, _GuardedStream(stream, f"sys.{attr}"))
        sys.exit = self._shim("sys.exit", sys.exit, True)
        builtins.__import__ = _ImportGate(builtins.__import__)._import_shim
        # gc, inspect and dis leave sys.modules (their importers keep their own references) and a
        # finder ahead of every other refuses a kernel's reload; the import shim refuses the rest.
        sys.meta_path.insert(0, _RemovedModuleFinder())
        for module_name in REPLAY_REMOVED_MODULES:
            sys.modules.pop(module_name, None)
        sys.addaudithook(self._audit)
        self.guarded = True
        namespace = globals()  # no module-global name leads to the vault once the child is armed
        for holder in _VAULT_HOLDERS:
            namespace.pop(holder, None)


_SANDBOX = _Sandbox()
_Held._sandbox = _SANDBOX


def install_capability_guard() -> None:
    """Arm this process as a replay child: the capability shims and the audit hook (idempotent,
    permanent). Call it before the kernel module is imported. numpy is loaded first (it imports
    ctypes and introspection modules the guard then removes), and its absence fails closed."""
    if "numpy" not in sys.modules:
        import numpy  # noqa: F401
    if "numpy" not in sys.modules:
        raise ConformRefused("replay_failed", "numpy was not loaded before the capability guard armed")
    _SANDBOX.install_guard()


def import_kernel(fn, *args):
    """fn(*args) with kernel module imports admitted: the replay child resolves the pinned module
    this way, so its module-level code already runs under the guard."""
    return _SANDBOX.call(IMPORT, 0, "kernel-import", fn, *args)


# ---------------------------------------------------------------- manifest and kernel resolution

@dataclass(frozen=True)
class ResolvedKernel:
    """A kernel C10 verified: the pinned module bytes, their digest and the conforming entry class."""

    pin_id: str
    module: str
    attr: str
    sha256: str
    entry_cls: type
    source: bytes


def validate_manifest(path) -> EngineManifest:
    """C4 validation of `<manifests_dir>/<engine_id>.json`; ManifestInvalid becomes manifest_invalid."""
    try:
        return load_manifest(path)
    except ManifestInvalid as exc:
        raise ConformRefused("manifest_invalid", f"{exc.code}: {exc.detail}".strip()) from None


def pin_id_for(kernel_id: str) -> str | None:
    """The KERNELS pin id whose module is the manifest kernel's entry module, or None."""
    entry = KERNEL_ENTRIES.get(kernel_id) if type(kernel_id) is str else None
    if entry is None:
        return None
    for pin_id, pin in kernels.pins().items():
        if pin.module == entry[0]:
            return pin_id
    return None


def resolve_pin(pin_id: str) -> ResolvedKernel:
    """resolve_kernel(pin_id, "offline") plus the exact pinned bytes the static guard reads."""
    try:
        pin = kernels.pins().get(pin_id) if type(pin_id) is str else None
        if pin is None:
            raise kernels.KernelError("unlisted", f"{pin_id!r} is not a pinned kernel")
        entry_cls = kernels.resolve_kernel(pin_id, MODE)
        source = kernels.read_pinned_source(kernels.module_path(pin.module), pin.sha256)
    except kernels.KernelError as exc:
        raise ConformRefused("kernel_" + exc.code, exc.detail) from None
    except OSError as exc:
        raise ConformRefused("kernel_import_failed", f"{pin_id}: {exc}") from None
    return ResolvedKernel(pin_id, pin.module, pin.attr, pin.sha256, entry_cls, source)


def resolve_manifest_kernel(manifest: EngineManifest) -> ResolvedKernel:
    """The manifest's kernel through the KERNELS table; a lane kernel's module_sha256 must be the pin."""
    kernel = manifest.kernel
    entry = KERNEL_ENTRIES.get(kernel["kernel_id"])
    pin_id = pin_id_for(kernel["kernel_id"])
    if entry is None or pin_id is None:
        raise ConformRefused("kernel_unlisted", f"{kernel['kernel_id']!r} has no KERNELS pin")
    pin = kernels.pins()[pin_id]
    if pin.attr != entry[1]:
        raise ConformRefused("kernel_pin_mismatch", f"{pin_id}: pinned attr {pin.attr}, manifest entry {entry[1]}")
    if kernel["kind"] == "lane" and kernel["module_sha256"] != pin.sha256:
        raise ConformRefused("kernel_pin_mismatch",
                             f"{pin_id}: manifest module_sha256 {kernel['module_sha256'][:12]}, pin {pin.sha256[:12]}")
    return resolve_pin(pin_id)


# ---------------------------------------------------------------- the corpus

@dataclass(frozen=True)
class Tape:
    """One decoded tape: `items` are the delivered rows as (line, kind, row, event, receive_ns)."""

    name: str
    sha256: str
    rows: int
    items: tuple


@dataclass(frozen=True)
class Corpus:
    sha256: str
    tapes: tuple


def _event(kind: str, row: Mapping):
    if kind == "l":
        return Lifecycle(row["ticker"], row["status"], row["close_time_ms"], row["expiration_time_ms"],
                         row["strike_i"], row.get("strike_type", ""), row.get("open_time_ms", 0))
    if kind == "i":
        return IndexTick(row["index_id"], row["value_i"], row["source_ts_ms"], row["received_at_ms"],
                         row["local_ns"], row.get("avg60_value_i"), row.get("avg60_window_size"),
                         row.get("avg60_window_start_ms"))
    return Quote(venue=row["v"], symbol=row["s"], bid_i=row["b"], bid_size_i=row["bs"], ask_i=row["a"],
                 ask_size_i=row["as"], ts_exch_ns=row["te"], ts_recv_ns=row["tr"], seq=row["n"],
                 ts_arrival_ns=row.get("ta"))


def _read_bounded(path: Path, limit: int) -> bytes:
    try:
        with open(path, "rb") as handle:
            data = handle.read(limit + 1)
    except OSError as exc:
        raise ConformRefused("corpus_unreadable", f"{path.name}: {exc}") from None
    if len(data) > limit:
        raise ConformRefused("corpus_too_large", f"corpus exceeds {MAX_CORPUS_BYTES} bytes")
    return data


def decode_tape(name: str, data: bytes) -> Tape:
    """Strict B2 decode; delivered rows (l, i, q) become feed events with nondecreasing receive stamps."""
    items, last, rows = [], 0, 0
    try:
        for line, row in enumerate(iter_tape(data), 1):
            rows = line
            kind = row["t"]
            if kind not in _STAMP_KEY:
                continue  # x, i5, f and r rows are not delivered by the conformance host
            stamp = row[_STAMP_KEY[kind]]
            if stamp < last:
                raise ConformRefused("corpus_invalid", f"{name}:{line}: receive stamp goes backwards")
            last = stamp
            try:
                event = _event(kind, row)
            except Exception as exc:  # the feed dataclasses raise their own MalformedInput
                raise ConformRefused("corpus_invalid", f"{name}:{line}: {type(exc).__name__}: {exc}") from None
            items.append((line, kind, row, event, stamp))
    except TapeError as exc:
        raise ConformRefused("corpus_invalid", f"{name}:{rows + 1}: {exc.code}: {exc.detail}") from None
    return Tape(name, _sha256(data), rows, tuple(items))


def load_corpus(path) -> Corpus:
    """A tape file, or a directory of `*.jsonl` tapes in name order; bounded and strictly decoded.
    corpus_sha256 = sha256 over `name \\0 sha256(bytes) \\n` per tape, so one byte anywhere moves it.
    Bytes are CRLF-normalized first (the committed git blob, as C10 pins), so an autocrlf checkout
    and the Linux runner bind the same digest."""
    path = Path(path)
    try:
        if path.is_dir():
            files = sorted((item for item in path.glob("*.jsonl") if item.is_file()), key=lambda p: p.name)
        elif path.is_file():
            files = [path]
        else:
            raise ConformRefused("corpus_unreadable", f"{path} is neither a tape nor a directory")
    except OSError as exc:
        raise ConformRefused("corpus_unreadable", str(exc)) from None
    if not files:
        raise ConformRefused("corpus_empty", f"{path} holds no .jsonl tapes")
    if len(files) > MAX_TAPES:
        raise ConformRefused("corpus_too_large", f"more than {MAX_TAPES} tapes")
    tapes, total, manifest = [], 0, []
    for file in files:
        name = file.stem
        if not _TAPE_NAME.fullmatch(name):
            raise ConformRefused("corpus_invalid", f"tape name {name[:64]!r} must match {_TAPE_NAME.pattern}")
        data = _read_bounded(file, MAX_CORPUS_BYTES - total)
        total += len(data)
        tape = decode_tape(name, data.replace(b"\r\n", b"\n"))
        tapes.append(tape)
        manifest.append(name.encode("ascii") + b"\0" + tape.sha256.encode("ascii") + b"\n")
    return Corpus(_sha256(b"".join(manifest)), tuple(tapes))


# ---------------------------------------------------------------- the offline host

@dataclass(frozen=True)
class KernelSpec:
    """What the host runs: an entry class, its params and the symbols the engine declares."""

    engine_id: str
    entry_cls: type
    params: Mapping
    symbols: tuple
    engines_dir: Path | None = None
    balance_cents: int = DEFAULT_BALANCE_CENTS

    def __post_init__(self):
        if type(self.engine_id) is not str or not self.engine_id:
            raise ValueError("engine_id must be a non-empty string")
        if (type(self.symbols) is not tuple or not self.symbols or len(set(self.symbols)) != len(self.symbols)
                or any(symbol not in SYMBOL_MAP for symbol in self.symbols)):
            raise ValueError("symbols must be a tuple of distinct SYMBOL_MAP symbols")
        if type(self.balance_cents) is not int or self.balance_cents <= 0:
            raise ValueError("balance_cents must be a positive int")

    def construct(self):
        kwargs = {}
        try:
            parameters = inspect.signature(self.entry_cls).parameters
        except (TypeError, ValueError):
            parameters = {}
        if "engine_registry" in parameters and self.engines_dir is not None:
            kwargs["engine_registry"] = EngineRegistry(self.engines_dir)
        return self.entry_cls(dict(self.params), **kwargs)


class OfflineContext:
    """LaneContext for one symbol's kernel: the replay clock, host-owned reads, no state directory."""

    mode = "shadow"
    live = False

    def __init__(self, host: OfflineHost, symbol: str):
        self._host = host
        self.symbol = symbol
        self.engines_dir = host.spec.engines_dir
        self.family = "15m" if symbol.endswith("-15M") else "1h"
        self.series = (SYMBOL_MAP[symbol][0],)
        self.balance_cents = host.spec.balance_cents
        self.capital_basis_cents = host.spec.balance_cents
        self.free_cash_cents = host.spec.balance_cents
        self.strategy_params = {}
        self._rng = random.Random(int(_sha256(f"{host.spec.engine_id}:{symbol}".encode())[:16], 16))

    def now_ns(self) -> int:
        return self._host.now_ns

    def wall_ms(self) -> int:
        return self._host.now_ns // 1_000_000

    def catalog(self, ticker):
        market = self._host.markets.get(self.symbol, {}).get(ticker)
        if market is None:
            return None
        return {"symbol": self.symbol, "index_id": SYMBOL_MAP[self.symbol][1], "close_ms": market["close_ms"],
                "strike_i": market["strike_i"], "strike_type": market["strike_type"], "status": market["status"]}

    def history(self, ticker, n):
        return ()

    def positions(self):
        return ()

    def reserved_cents(self):
        return 0

    def fee_per_contract(self, price_cents):
        from .strategy.settlement import fee_per_contract

        return Decimal(fee_per_contract(float(Decimal(price_cents))))

    def rng(self):
        return self._rng

    def state_dir(self):
        raise PermissionError("the offline conformance host has no state directory")


def _plain_decimal(value: Decimal) -> str:
    return format(value.normalize(), "f")


def _cents(price_i: int, rounding) -> Decimal:
    cents = (Decimal(price_i) * 100 / PRICE_UNIT).quantize(_CENT, rounding=rounding)
    return min(max(cents, Decimal(0)), Decimal(100))


def _quote(row: Mapping) -> dict:
    """The DecisionFrame quote: bid rounded down and ask up to whole hundredths, sizes floored."""
    bid, ask = _cents(row["b"], ROUND_FLOOR), _cents(row["a"], ROUND_CEILING)
    bid_size = min((Decimal(row["bs"]) / SIZE_UNIT).quantize(_CENT, rounding=ROUND_FLOOR), _MAX_SIZE)
    ask_size = min((Decimal(row["as"]) / SIZE_UNIT).quantize(_CENT, rounding=ROUND_FLOOR), _MAX_SIZE)
    return {"yes_bid": _plain_decimal(bid), "yes_ask": _plain_decimal(ask),
            "no_bid": _plain_decimal(100 - ask), "no_ask": _plain_decimal(100 - bid),
            "bid_size": _plain_decimal(bid_size), "ask_size": _plain_decimal(ask_size), "at_ns": row["tr"]}


class OfflineHost:
    """Replays one tape through one kernel per declared symbol, created at the symbol's first event.

    Per delivered row: the row updates host state (markets from `l`, quotes from `q`, index from
    `i`), the event goes to the symbol's kernel (`i` rows to every declared symbol on that index),
    then the kernel evaluates one DecisionFrame per open market of that symbol, in tape order.
    Frame ids are `<tape>#<line>:<ticker>` (`<tape>#<line>` for an event delivery).

    Restore contract (the checkpoint round trip): host state is feed-derived, so a restored host
    rebuilds it by re-reading the tape prefix. A kernel with a NON-EMPTY checkpoint resumes from it
    and sees none of the prefix again; a kernel whose checkpoint is EMPTY declares that its state
    is a function of the feed ("feed warm-up belongs to the host", kalshi_edge_entry.py), so the
    host re-delivers the prefix to it with every output discarded.
    """

    def __init__(self, spec: KernelSpec, tape_name: str, *, sample: bool = True):
        _SANDBOX.install_clock()
        _SANDBOX.register_kernel(spec.entry_cls)
        self.spec = spec
        self.tape = tape_name
        self.sample = sample
        self.now_ns = 0
        self.kernels: dict = {}
        self.warming: set = set()
        self.markets: dict = {symbol: {} for symbol in spec.symbols}
        self.market_count = 0
        self.quotes: dict = {}
        self.index: dict = {}
        self.index_obs: dict = {}
        self.index_symbols: dict = {}
        for symbol in spec.symbols:
            self.index_symbols.setdefault(SYMBOL_MAP[symbol][1], []).append(symbol)
        self.outcomes: dict = {}
        self.decisions: list = []
        self.samples: list = []
        self.frames = 0
        self.max_per_frame = 0
        self.sequence = 0

    # kernels
    def _call(self, frame_id: str, fn, *args):
        """One kernel call on the replay clock (and, in the replay child, under the capability guard)."""
        return _SANDBOX.call(STRICT, self.now_ns, frame_id, fn, *args)

    def create(self, symbol: str, restored_state):
        context = OfflineContext(self, symbol)
        try:
            entry = self._call(f"{self.tape}#init:{symbol}", _start_kernel, self.spec, context, restored_state)
        except ConformRefused:
            raise
        except Exception as exc:
            raise ConformRefused("bounds_exception", f"initialize raised {type(exc).__name__}: {exc}",
                                 f"{self.tape}#init:{symbol}") from None
        self.kernels[symbol] = entry
        return entry

    def checkpoint_state(self) -> bytes:
        """Canonical bytes of {symbol: kernel.checkpoint()}; bounded like one kernel per symbol."""
        states = {}
        for symbol, kernel in self.kernels.items():
            try:
                state = self._call(f"{self.tape}#checkpoint:{symbol}", kernel.checkpoint)
            except ConformRefused:
                raise
            except Exception as exc:
                raise ConformRefused("bounds_exception", f"checkpoint raised {type(exc).__name__}: {exc}",
                                     f"{self.tape}#checkpoint:{symbol}") from None
            if type(state) is not dict:
                raise ConformRefused("checkpoint_mismatch", f"{symbol}: checkpoint() must return a dict")
            states[symbol] = state
        try:
            return state_json(states, MAX_CHECKPOINT_BYTES * max(1, len(states)))
        except ValueError as exc:
            raise ConformRefused("checkpoint_mismatch", f"checkpoint is not bounded canonical JSON: {exc}") from None

    def restore(self, states: Mapping) -> None:
        """Fresh kernels from their checkpoints; each must checkpoint back to the same bytes."""
        for symbol, state in states.items():
            if symbol not in self.markets or type(state) is not dict:
                raise ConformRefused("checkpoint_mismatch", f"checkpoint names {symbol!r}, not a declared symbol")
            entry = self.create(symbol, state)
            try:
                after = self._call(f"{self.tape}#restore:{symbol}", entry.checkpoint)
                same = state_json(after, MAX_CHECKPOINT_BYTES) == state_json(state, MAX_CHECKPOINT_BYTES)
            except ConformRefused:
                raise
            except Exception as exc:
                raise ConformRefused("checkpoint_mismatch", f"{symbol}: checkpoint after restore failed: {exc}") from None
            if not same:
                raise ConformRefused("checkpoint_mismatch", f"{symbol}: restore then checkpoint is not byte-equal")
            if not state:
                self.warming.add(symbol)

    # feed state
    def _track(self, symbol: str, row: Mapping) -> dict:
        table = self.markets[symbol]
        market = table.get(row["ticker"])
        if market is None:
            if self.market_count >= MAX_MARKETS:
                raise ConformRefused("corpus_too_large", f"{self.tape}: more than {MAX_MARKETS} markets")
            self.market_count += 1
            market = table[row["ticker"]] = {"ticker": row["ticker"]}
        market.update(close_ms=row["close_time_ms"] or row["expiration_time_ms"], strike_i=row["strike_i"],
                      strike_type=row.get("strike_type", ""), status=row["status"])
        return market

    def _observe_index(self, row: Mapping) -> None:
        index_id = row["index_id"]
        if index_id not in self.index_symbols:
            return
        self.index[index_id] = {"value_i": row["value_i"], "at_ns": row["local_ns"],
                                "source_ts_ms": row["source_ts_ms"]}
        observations = self.index_obs.get(index_id)
        if observations is None:
            observations = self.index_obs[index_id] = deque(maxlen=MAX_INDEX_OBS)
        observations.append((row["source_ts_ms"], row["value_i"]))

    def _outcome(self, symbol: str, market: Mapping) -> str:
        """Kalshi's rule over the tape's own index: the mean of one observation per second in the
        60 s before close (a later tick in a second wins) against the strike; `greater` is strict."""
        close = market["close_ms"]
        buckets = {}
        for source_ms, value in self.index_obs.get(SYMBOL_MAP[symbol][1], ()):
            if close - SETTLEMENT_WINDOW_S * 1000 <= source_ms < close:
                buckets[source_ms // 1000] = value
        if not buckets or not market["strike_i"]:
            return "unknown"
        total, strike = sum(buckets.values()), market["strike_i"] * len(buckets)
        above = total > strike if market["strike_type"] == "greater" else total >= strike
        return "yes" if above else "no"

    def _open(self, symbol: str) -> list:
        return [market for market in self.markets[symbol].values()
                if market["status"] not in CLOSED_STATUSES and market["close_ms"] * 1_000_000 > self.now_ns]

    # one row
    def step(self, item, *, record: bool = True) -> None:
        line, kind, row, event, stamp = item
        self.now_ns = stamp
        closing = None
        if kind == "i":
            self._observe_index(row)
            targets = self.index_symbols.get(row["index_id"], ())
        else:
            ticker = row["ticker"] if kind == "l" else row["s"]
            symbol = symbol_of(ticker)
            if symbol not in self.markets:
                return
            targets = (symbol,)
            if kind == "l":
                market = self._track(symbol, row)
                if market["status"] in CLOSED_STATUSES:
                    closing = (symbol, market)
            elif ticker in self.quotes or len(self.quotes) < MAX_MARKETS:
                self.quotes[ticker] = _quote(row)
        for symbol in targets:
            kernel = self.kernels.get(symbol)
            if kernel is None:
                if not record:
                    continue  # warm-up never creates a kernel the checkpoint did not hold
                kernel = self.create(symbol, None)
            deliver = record or symbol in self.warming
            if deliver:
                try:
                    self._call(f"{self.tape}#{line}", kernel.on_event, event, self.now_ns)
                except ConformRefused:
                    raise
                except Exception as exc:
                    raise ConformRefused("bounds_exception", f"on_event raised {type(exc).__name__}: {exc}",
                                         f"{self.tape}#{line}") from None
            for market in self._open(symbol):
                self.sequence += 1
                if deliver:
                    self._evaluate(kernel, symbol, market, line, record)
        if closing is not None:
            symbol, market = closing
            self.markets[symbol].pop(market["ticker"], None)
            self.quotes.pop(market["ticker"], None)
            self.outcomes[market["ticker"]] = {"ticker": market["ticker"], "close_ms": market["close_ms"],
                                               "strike_i": market["strike_i"],
                                               "outcome": self._outcome(symbol, market)}

    def _evaluate(self, kernel, symbol: str, market: Mapping, line: int, record: bool) -> None:
        ticker = market["ticker"]
        frame_id = f"{self.tape}#{line}:{ticker}"
        try:
            frame = DecisionFrame(
                opportunity_id=frame_id[:96], now_ns=self.now_ns, cutoff_ns=self.now_ns,
                close_ms=market["close_ms"], ticker=ticker, symbol=symbol, strike_i=market["strike_i"],
                side_candidates=(True, False), quote=self.quotes.get(ticker),
                index=self.index.get(SYMBOL_MAP[symbol][1]), history=(), positions=(),
                reserved_cents=0, sequence=self.sequence, gap=False)
        except ValueError as exc:
            raise ConformRefused("corpus_invalid", f"no valid frame: {exc}", frame_id) from None
        started = time.perf_counter_ns()
        try:
            proposals = self._call(frame_id, kernel.evaluate, frame)
        except ConformRefused:
            raise
        except Exception as exc:
            raise ConformRefused("bounds_exception", f"evaluate raised {type(exc).__name__}: {exc}", frame_id) from None
        elapsed = time.perf_counter_ns() - started
        if not record:
            return
        if type(proposals) is not list:
            raise ConformRefused("bounds_invalid_proposal", "evaluate must return a list", frame_id)
        if len(proposals) > MAX_PROPOSALS:
            raise ConformRefused("bounds_proposals",
                                 f"{len(proposals)} proposals in one frame; at most {MAX_PROPOSALS}", frame_id)
        try:
            bound_proposals(proposals, frame)
        except ValueError as exc:
            raise ConformRefused("bounds_invalid_proposal", str(exc), frame_id) from None
        self.frames += 1
        if self.sample:
            self.samples.append(elapsed)
        self.max_per_frame = max(self.max_per_frame, len(proposals))
        if len(self.decisions) + len(proposals) > MAX_DECISIONS:
            raise ConformRefused("corpus_too_large", f"more than {MAX_DECISIONS} proposals", frame_id)
        try:
            rows = [decision_row(frame_id, frame.now_ns, proposal) for proposal in proposals]
        except ValueError as exc:
            raise ConformRefused("bounds_invalid_proposal", str(exc), frame_id) from None
        self.decisions.extend(rows)


def _start_kernel(spec: KernelSpec, context, restored_state):
    entry = spec.construct()
    entry.initialize(context, restored_state)
    return entry


def decision_row(frame_id: str, now_ns: int, proposal) -> list:
    """The DECISION_FIELDS row of one proposal: every field that reaches execution, canonical, so a
    seed- or restore-dependent expiry, opportunity id, reason or meta changes the row."""
    return [frame_id, proposal.ticker, "yes" if proposal.side_yes else "no",
            _plain_decimal(proposal.limit_price_cents), _plain_decimal(proposal.count),
            proposal.expires_ns - now_ns, proposal.opportunity_id, proposal.reason,
            state_json(proposal.meta, 4096).decode("utf-8")]


def _round_trip(spec: KernelSpec, tape: Tape, at: int, checkpoint: bytes, tail: list, final: bytes) -> dict:
    """Restore fresh kernels from the mid-tape checkpoint; the tail and the final checkpoint must be
    byte-equal to the uninterrupted run's."""
    host = OfflineHost(spec, tape.name, sample=False)
    try:
        host.restore(json.loads(checkpoint))
        for item in tape.items[:at]:
            host.step(item, record=False)
        for item in tape.items[at:]:
            host.step(item)
        restored_final = host.checkpoint_state()
    except ConformRefused as exc:
        if exc.code in ("checkpoint_mismatch", "conform_capability"):
            raise
        raise ConformRefused("checkpoint_mismatch", f"after restore at item {at}: {exc.code}: {exc.detail}",
                             exc.frame_id) from None
    if canonical_json(host.decisions) != canonical_json(tail):
        index = next((n for n, (a, b) in enumerate(zip(host.decisions, tail)) if a != b),
                     min(len(host.decisions), len(tail)))
        frame_id = tail[index][0] if index < len(tail) else None
        raise ConformRefused("checkpoint_mismatch", f"{tape.name}: restored tail differs at decision {index} "
                             f"({len(host.decisions)} against {len(tail)})", frame_id)
    if restored_final != final:
        raise ConformRefused("checkpoint_mismatch", f"{tape.name}: final checkpoint differs after restore")
    return {"tape": tape.name, "at_item": at, "checkpoint_sha256": _sha256(checkpoint),
            "final_sha256": _sha256(final), "tail_decisions": len(tail), "round_trip": "byte_equal"}


def _p99_us(samples: list) -> str | None:
    if not samples:
        return None
    ordered = sorted(samples)
    value = ordered[max(0, math.ceil(0.99 * len(ordered)) - 1)]
    return str((Decimal(value) / 1000).quantize(Decimal("0.1")))


def replay_corpus(spec: KernelSpec, corpus: Corpus) -> dict:
    """The replay section: every tape through fresh kernels, the checkpoint round trip and the bounds.
    Raises ConformRefused on the first exception, oversized frame or round-trip difference."""
    decisions, samples, markets, checkpoints = [], [], [], []
    frames = max_per_frame = 0
    pnl, settled = Decimal(0), 0
    for tape in corpus.tapes:
        host = OfflineHost(spec, tape.name)
        at = len(tape.items) // 2
        checkpoint, tail_start = None, 0
        for n, item in enumerate(tape.items):
            if n == at:
                checkpoint, tail_start = host.checkpoint_state(), len(host.decisions)
            host.step(item)
        final = host.checkpoint_state()
        if checkpoint is None:
            checkpoint, tail_start = final, len(host.decisions)
        checkpoints.append(_round_trip(spec, tape, at, checkpoint, host.decisions[tail_start:], final))
        for decision in host.decisions:
            outcome = host.outcomes.get(decision[1], {}).get("outcome")
            if outcome in ("yes", "no"):
                price, count = Decimal(decision[3]), Decimal(decision[4])
                pnl += ((100 - price) if (outcome == "yes") == (decision[2] == "yes") else -price) * count
                settled += 1
        decisions.extend(host.decisions)
        samples.extend(host.samples)
        markets.extend(dict(outcome, tape=tape.name) for outcome in host.outcomes.values())
        frames += host.frames
        max_per_frame = max(max_per_frame, host.max_per_frame)
        if len(decisions) > MAX_DECISIONS:
            raise ConformRefused("corpus_too_large", f"more than {MAX_DECISIONS} proposals")
    return {
        "schema": REPLAY_SCHEMA, "engine_id": spec.engine_id, "mode": MODE, "corpus_sha256": corpus.sha256,
        "symbols": list(spec.symbols), "balance_cents": spec.balance_cents,
        "tapes": [{"name": t.name, "sha256": t.sha256, "rows": t.rows, "events": len(t.items)} for t in corpus.tapes],
        "frames": frames, "proposals": len(decisions), "decisions_sha256": _sha256(canonical_json(decisions)),
        "decision_fields": list(DECISION_FIELDS), "decisions": decisions,
        "max_proposals_per_frame": max_per_frame, "proposal_limit": MAX_PROPOSALS,
        "exceptions": 0, "evaluate_p99_us": _p99_us(samples), "evaluate_samples": len(samples),
        "markets": markets, "replay_pnl_cents": _plain_decimal(pnl) if pnl else "0", "replay_settled": settled,
        "checkpoint": checkpoints,
    }


def spec_for(manifest: EngineManifest, resolved: ResolvedKernel, engines_dir) -> KernelSpec:
    """The host spec for a validated manifest; a policy kernel's catalog digest must be the pin."""
    kernel = manifest.kernel
    if kernel["kind"] == "policy":
        if engines_dir is None:
            raise ConformRefused("kernel_pin_missing", "a policy kernel needs the engines catalog")
        try:
            engine = EngineRegistry(engines_dir).get(kernel["policy_engine_id"])
        except Exception as exc:
            raise ConformRefused("kernel_pin_missing",
                                 f"catalog engine {kernel['policy_engine_id']}: {type(exc).__name__}") from None
        if policy_digest(engine.policy) != kernel["policy_digest"]:
            raise ConformRefused("kernel_pin_mismatch", "the catalog policy digest differs from the manifest pin")
        params = {"policy_engine_id": kernel["policy_engine_id"], "policy_digest": kernel["policy_digest"]}
    else:
        params = {key: value for key, value in kernel["params"].items()}
    return KernelSpec(manifest.engine_id, resolved.entry_cls, params, tuple(manifest.inputs["symbols"]),
                      None if engines_dir is None else Path(engines_dir))


# ---------------------------------------------------------------- two subprocesses, two hash seeds

def _child_command(manifest_path: Path, corpus_path: Path, engines_dir: Path) -> list[str]:
    return [sys.executable, "-m", "leafhft.engine_conform", "replay", "--manifest", str(manifest_path),
            "--corpus", str(corpus_path), "--engines-dir", str(engines_dir)]


def replay_in_subprocesses(manifest_path, corpus_path, engines_dir, hash_seeds=HASH_SEEDS) -> dict:
    """Run the replay once per hash seed, each in its own interpreter, concurrently; the outputs
    must be byte-equal after normalize_receipt. Returns the first child's section."""
    seeds = tuple(hash_seeds)
    if len(seeds) < 2 or len(set(seeds)) != len(seeds) or any(not re.fullmatch(r"[0-9]{1,10}", s) for s in seeds):
        raise ValueError("hash_seeds: at least two distinct decimal PYTHONHASHSEED values")
    command = _child_command(Path(manifest_path).resolve(), Path(corpus_path).resolve(), Path(engines_dir).resolve())
    procs, results = [], []
    try:
        for seed in seeds:
            env = dict(os.environ)
            env["PYTHONHASHSEED"] = seed
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONPATH"] = os.pathsep.join(filter(None, (str(_PACKAGE_ROOT), env.get("PYTHONPATH"))))
            procs.append(subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE, env=env, cwd=str(_PACKAGE_ROOT)))
        deadline = time.monotonic() + CHILD_TIMEOUT_S
        for proc in procs:
            out, err = proc.communicate(timeout=max(1.0, deadline - time.monotonic()))
            results.append((proc.returncode, out, err))
    except subprocess.TimeoutExpired:
        raise ConformRefused("replay_failed", f"a replay child exceeded {CHILD_TIMEOUT_S} s") from None
    except OSError as exc:
        raise ConformRefused("replay_failed", f"could not start a replay child: {exc}") from None
    finally:
        for proc in procs:
            if proc.poll() is None:
                proc.kill()
                proc.wait()
    return compare_replays(seeds, results)


def compare_replays(hash_seeds, results) -> dict:
    """The determinism verdict over one (returncode, stdout, stderr) per hash seed: every child must
    replay (or refuse identically) and the outputs must be byte-equal after normalize_receipt, over
    the full DECISION_FIELDS rows. Returns the first child's section."""
    seeds = tuple(hash_seeds)
    if len(seeds) < 2 or len(results) != len(seeds):
        raise ValueError("compare_replays: one result per hash seed, at least two")
    documents = []
    for seed, (code, out, err) in zip(seeds, results):
        if code not in (0, EXIT_REFUSED) or len(out) > MAX_CHILD_OUTPUT:
            tail = err.decode("utf-8", "replace")[-800:]
            raise ConformRefused("replay_failed", f"seed {seed}: exit {code}: {tail}")
        try:
            documents.append((code, strict_json_loads(out)))
        except StrictJsonError as exc:
            raise ConformRefused("replay_failed", f"seed {seed}: unreadable output: {exc}") from None
    refusals = [doc.get("refused") for code, doc in documents if code == EXIT_REFUSED]
    if refusals:
        if len(refusals) == len(documents) and all(item == refusals[0] for item in refusals):
            refused = refusals[0]
            code = refused.get("code") if isinstance(refused, dict) else None
            if code not in REFUSAL_CODES:
                raise ConformRefused("replay_failed", "a replay child refused with an unknown code")
            raise ConformRefused(code, refused.get("detail", ""), refused.get("frame_id"))
        raise ConformRefused("nondeterministic", f"hash seeds {list(seeds)}: the children disagree on refusal")
    normalized = [normalize_receipt(doc) for _code, doc in documents]
    for seed, body in zip(seeds[1:], normalized[1:]):
        if body != normalized[0]:
            offset = next((n for n, (a, b) in enumerate(zip(body, normalized[0])) if a != b),
                          min(len(body), len(normalized[0])))
            raise ConformRefused("nondeterministic",
                                 f"seed {seed} differs from seed {seeds[0]} at byte {offset} after normalize_receipt")
    return documents[0][1]


# ---------------------------------------------------------------- novelty

@dataclass(frozen=True)
class EngineDecisions:
    """One engine's decisions on the corpus: DECISION_FIELDS tuples; novelty reads the first
    NOVELTY_FIELDS (frame_id, ticker, side, price, count)."""

    engine_id: str
    relation: str
    identity: str
    symbols: frozenset
    decisions: tuple


def _jaccard_text(common: int, union: int) -> str | None:
    return None if union == 0 else str((Decimal(common) / Decimal(union)).quantize(Decimal("0.0001")))


def _near(common: int, union: int) -> bool:
    return union > 0 and common * NEAR_CLONE[1] > union * NEAR_CLONE[0]


def _tolerant_matches(mine, theirs) -> int:
    """One-to-one matches on (frame_id, ticker, side) whose prices differ by at most PRICE_TICK_CENTS
    (count ignored): per key both price lists are sorted and paired by a two-pointer sweep, a maximum
    matching for a fixed tolerance, so O(n log n) over the decisions."""
    groups: dict = {}
    for slot, rows in ((0, mine), (1, theirs)):
        for row in rows:
            groups.setdefault((row[0], row[1], row[2]), ([], []))[slot].append(Decimal(row[3]))
    matched = 0
    for left, right in groups.values():
        if not left or not right:
            continue
        left.sort()
        right.sort()
        i = j = 0
        while i < len(left) and j < len(right):
            if abs(left[i] - right[j]) <= PRICE_TICK_CENTS:
                matched, i, j = matched + 1, i + 1, j + 1
            elif left[i] < right[j]:
                i += 1
            else:
                j += 1
    return matched


def novelty(thesis, own: EngineDecisions, peers: Sequence[EngineDecisions], *, parent: str | None = None,
            required: Sequence[str] = ()) -> dict:
    """The novelty rule: a thesis, >= 1 proposal, every required input compared (the declared parent as
    relation "parent" and every id in `required`, else novelty_inputs_missing, never "novel"), and no
    peer with the same kernel identity or the same non-empty decision set on shared symbols
    (novelty_clone).

    Two overlap measures per peer over the decisions (frame_id, ticker, side, price, count) on shared
    symbols, either above 0.9 flagging near-clone (never refused). `jaccard` is exact-tuple Jaccard and
    is blind to a uniform perturbation: a clone with every price shifted by +0.01 shares no exact tuple
    and reads 0.0. `tolerant_jaccard` matches one to one on (frame_id, ticker, side) with prices within
    PRICE_TICK_CENTS, count ignored, so that clone reads 1.0 and is flagged."""
    text = thesis.get("novelty") if isinstance(thesis, Mapping) else None
    if type(text) is not str or not text.strip():
        raise ConformRefused("novelty_thesis", "the manifest thesis names no novelty")
    if not own.decisions:
        raise ConformRefused("novelty_no_proposals", "the engine made no proposal on the corpus")
    supplied = {peer.engine_id for peer in peers}
    parent_compared = parent is not None and any(p.relation == "parent" and p.engine_id == parent for p in peers)
    missing = ([f"parent {parent}"] if parent is not None and not parent_compared else [])
    missing += [f"assigned {engine_id}" for engine_id in sorted(set(required) - supplied)]
    if missing:
        raise ConformRefused("novelty_inputs_missing", "not compared: " + ", ".join(missing[:20]))
    compared, near = [], []
    own_rows = {tuple(d[:NOVELTY_FIELDS]) for d in own.decisions}
    for peer in peers:
        if peer.identity == own.identity:
            raise ConformRefused("novelty_clone", f"{peer.engine_id} ({peer.relation}): the same kernel and params")
        shared = own.symbols & peer.symbols
        mine = {d for d in own_rows if symbol_of(d[1]) in shared}
        theirs = {tuple(d[:NOVELTY_FIELDS]) for d in peer.decisions if symbol_of(d[1]) in shared}
        common, union = len(mine & theirs), len(mine | theirs)
        if mine and mine == theirs:
            raise ConformRefused("novelty_clone",
                                 f"{peer.engine_id} ({peer.relation}): the same {len(mine)} decisions on shared symbols")
        matched = _tolerant_matches(mine, theirs)
        tolerant_union = len(mine) + len(theirs) - matched
        flagged = _near(common, union) or _near(matched, tolerant_union)
        if flagged:
            near.append(peer.engine_id)
        compared.append({"engine_id": peer.engine_id, "relation": peer.relation, "shared_symbols": sorted(shared),
                         "shared_decisions": common, "union_decisions": union,
                         "jaccard": _jaccard_text(common, union), "tolerant_matches": matched,
                         "tolerant_jaccard": _jaccard_text(matched, tolerant_union), "near_clone": flagged})
    return {"thesis": True, "proposals": len(own.decisions), "parent": parent,
            "parent_compared": parent_compared, "required": sorted(set(required)), "compared": compared,
            "near_clone": near, "verdict": "near_clone" if near else "novel"}


def assignments_from_registry(path) -> dict:
    """{engine_id: symbols} from a registry document (the projection's source); any unreadable or
    invalid document is novelty_inputs_missing, never an empty projection."""
    try:
        with open(path, "rb") as handle:
            data = handle.read(MAX_REGISTRY_READ + 1)
        if len(data) > MAX_REGISTRY_READ:
            raise ValueError(f"exceeds {MAX_REGISTRY_READ} bytes")
        from .engine_registry import Registry

        registry = Registry.from_bytes(data)
        return {engine_id: tuple(row["symbols"]) for engine_id, row in registry.assignments.items()}
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise ConformRefused("novelty_inputs_missing",
                             f"registry projection {Path(path).name}: {type(exc).__name__}: {exc}") from None


def novelty_inputs(manifest: EngineManifest, assignments) -> tuple:
    """(parent, assigned engine ids on the manifest's symbols): the peers novelty MUST compare.
    `assignments` is the registry projection, {engine_id: symbols} or {engine_id: {"symbols": ...}},
    or a registry document path; None or anything unreadable is novelty_inputs_missing."""
    if assignments is None:
        raise ConformRefused("novelty_inputs_missing", "no registry projection: the assigned engines are unknown")
    if isinstance(assignments, (str, os.PathLike)):
        assignments = assignments_from_registry(assignments)
    if not isinstance(assignments, Mapping) or len(assignments) > MAX_ASSIGNMENTS:
        raise ConformRefused("novelty_inputs_missing", f"the registry projection is not a mapping of at most "
                             f"{MAX_ASSIGNMENTS} assignments")
    own = frozenset(manifest.inputs["symbols"])
    required = []
    for engine_id, row in assignments.items():
        symbols = row.get("symbols") if isinstance(row, Mapping) else row
        if (type(engine_id) is not str or not isinstance(symbols, (list, tuple, set, frozenset))
                or any(type(symbol) is not str for symbol in symbols)):
            raise ConformRefused("novelty_inputs_missing", f"unreadable assignment {str(engine_id)[:40]!r}")
        if engine_id != manifest.engine_id and own & frozenset(symbols):
            required.append(engine_id)
    return manifest.identity["parent"], tuple(sorted(required))


def _load_peers(manifest: EngineManifest, peers, parent=None, required=()) -> list:
    """The supplied peers, validated, covering the required inputs: the declared parent (relation
    "parent") and every required assigned engine; a missing one is novelty_inputs_missing."""
    loaded, seen = [], {manifest.engine_id}
    for item in peers:
        if not (isinstance(item, (tuple, list)) and len(item) == 2):
            raise ConformRefused("peer_invalid", "a peer is (relation, manifest_path)")
        relation, path = item
        if relation not in ("parent", "assigned"):
            raise ConformRefused("peer_invalid", f"relation {str(relation)[:32]!r} is not parent or assigned")
        if not isinstance(path, (str, os.PathLike)) or not Path(path).is_file():
            raise ConformRefused("novelty_inputs_missing", f"{relation} manifest {str(path)[-80:]!r} is missing")
        try:
            peer = load_manifest(path)
        except ManifestInvalid as exc:
            raise ConformRefused("peer_invalid", f"{Path(path).name}: {exc.code}") from None
        if relation == "parent" and peer.engine_id != manifest.identity["parent"]:
            raise ConformRefused("peer_invalid", f"{peer.engine_id} is not the manifest's parent")
        if peer.engine_id in seen:
            raise ConformRefused("peer_invalid", f"{peer.engine_id} is named twice or is the engine itself")
        seen.add(peer.engine_id)
        loaded.append((relation, peer))
        if len(loaded) > MAX_PEERS:
            raise ConformRefused("peer_invalid", f"more than {MAX_PEERS} peers")
    supplied = {peer.engine_id for _relation, peer in loaded}
    missing = ([f"parent {parent}"] if parent is not None
               and not any(r == "parent" and p.engine_id == parent for r, p in loaded) else [])
    missing += [f"assigned {engine_id}" for engine_id in required if engine_id not in supplied]
    if missing:
        raise ConformRefused("novelty_inputs_missing", "not supplied: " + ", ".join(missing[:20]))
    return loaded


def _peer_decisions(relation: str, peer: EngineManifest, corpus: Corpus, engines_dir) -> EngineDecisions:
    try:
        spec = spec_for(peer, resolve_manifest_kernel(peer), engines_dir)
        section = replay_corpus(spec, corpus)
    except ConformRefused as exc:
        raise ConformRefused("peer_invalid", f"{peer.engine_id}: {exc.code}: {exc.detail}") from None
    return EngineDecisions(peer.engine_id, relation, identity_digest(peer), frozenset(peer.inputs["symbols"]),
                           tuple(tuple(d) for d in section["decisions"]))


# ---------------------------------------------------------------- code identity and the receipt

def code_sha(root=None) -> str:
    """sha256 over the leafhft package source (`relpath \\0 sha256(LF-normalized bytes) \\n` in path
    order): the code that produced the receipt, without a git call. Bounded; fails closed."""
    root = _PACKAGE_DIR if root is None else Path(root)
    try:
        files = sorted((path for path in root.rglob("*.py") if "__pycache__" not in path.parts),
                       key=lambda path: path.relative_to(root).as_posix())
    except OSError as exc:
        raise ConformRefused("code_unreadable", str(exc)) from None
    if len(files) > MAX_CODE_FILES:
        raise ConformRefused("code_unreadable", f"more than {MAX_CODE_FILES} source files")
    digest, total = hashlib.sha256(), 0
    for path in files:
        try:
            with open(path, "rb") as handle:
                data = handle.read(MAX_CODE_BYTES - total + 1)
        except OSError as exc:
            raise ConformRefused("code_unreadable", f"{path.name}: {exc}") from None
        total += len(data)
        if total > MAX_CODE_BYTES:
            raise ConformRefused("code_unreadable", f"package source exceeds {MAX_CODE_BYTES} bytes")
        rel = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(rel + b"\0" + _sha256(data.replace(b"\r\n", b"\n")).encode("ascii") + b"\n")
    return digest.hexdigest()


def conform(manifest_path, corpus_path, *, engines_dir, assignments=None, peers=(),
            hash_seeds=HASH_SEEDS) -> dict:
    """The conform receipt for one engine, or ConformRefused. `assignments` is the registry
    projection (see novelty_inputs); `peers` are (relation, manifest_path) pairs and must include the
    declared parent ("parent") and every engine assigned on shared symbols ("assigned"). A missing
    one, or no readable projection, is novelty_inputs_missing before anything is replayed."""
    manifest_path = Path(manifest_path).resolve()
    corpus_path = Path(corpus_path).resolve()
    engines_dir = Path(engines_dir).resolve()
    manifest = validate_manifest(manifest_path)
    resolved = resolve_manifest_kernel(manifest)
    guard_source(resolved.source, resolved.module)
    spec = spec_for(manifest, resolved, engines_dir)
    parent, required = novelty_inputs(manifest, assignments)
    loaded = _load_peers(manifest, peers, parent, required)
    identity = identity_digest(manifest)
    for relation, peer in loaded:  # a clone is refused before anything is replayed
        if identity_digest(peer) == identity:
            raise ConformRefused("novelty_clone", f"{peer.engine_id} ({relation}): the same kernel and params")
    corpus = load_corpus(corpus_path)
    section = replay_in_subprocesses(manifest_path, corpus_path, engines_dir, hash_seeds)
    if section.pop("capability_guard", None) != "armed":
        raise ConformRefused("replay_failed", "a replay child ran without the capability guard")
    if section.get("corpus_sha256") != corpus.sha256 or section.get("engine_id") != spec.engine_id:
        raise ConformRefused("corpus_changed", "the replay read a different corpus or engine")
    own = EngineDecisions(manifest.engine_id, "self", identity, frozenset(spec.symbols),
                          tuple(tuple(d) for d in section["decisions"]))
    peer_decisions = [_peer_decisions(relation, peer, corpus, engines_dir) for relation, peer in loaded]
    verdict = novelty(manifest.thesis, own, peer_decisions, parent=parent, required=required)
    binds = {"manifest_digest": manifest_digest(manifest), "code_sha": code_sha(),
             "corpus_sha256": corpus.sha256, "kernel_pin": resolved.sha256}
    kernel = manifest.kernel
    replay = {key: value for key, value in section.items()
              if key not in ("checkpoint", "evaluate_p99_us", "evaluate_samples", "exceptions",
                             "max_proposals_per_frame", "proposal_limit")}
    return {
        "schema": CONFORM_SCHEMA, "engine_id": manifest.engine_id, "version": manifest.identity["version"],
        **binds, "binding_sha256": _sha256(canonical_json(binds)),
        "kernel": {"kernel_id": kernel["kernel_id"], "kind": kernel["kind"], "pin_id": resolved.pin_id,
                   "module": resolved.module, "attr": resolved.attr, "mode": MODE,
                   "policy_digest": kernel.get("policy_digest")},
        "provenance_code_sha": manifest.provenance["code_sha"],
        "static_guard": {"verdict": "passed", "module": resolved.module},
        "capability_guard": {"verdict": "passed", "armed_in": "every replay subprocess"},
        "determinism": {"hash_seeds": list(hash_seeds), "subprocesses": len(tuple(hash_seeds)), "byte_equal": True},
        "replay": replay,
        "checkpoint": section["checkpoint"],
        "bounds": {"exceptions": section["exceptions"], "max_proposals_per_frame": section["max_proposals_per_frame"],
                   "proposal_limit": section["proposal_limit"], "evaluate_p99_us": section["evaluate_p99_us"],
                   "evaluate_samples": section["evaluate_samples"]},
        "novelty": verdict,
        "label": LABEL,
    }


# ---------------------------------------------------------------- command line

def _write_atomic(path: Path, data: bytes) -> None:
    temp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    with open(temp, "wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp, path)


def _parse_peer(text: str):
    relation, sep, path = text.partition("=")
    if not sep:
        raise argparse.ArgumentTypeError("a peer is relation=manifest_path")
    return relation, path


def _emit(body: Mapping, code: int) -> int:
    sys.stdout.buffer.write(canonical_json(body) + b"\n")
    sys.stdout.flush()
    return code


def run_guarded_replay(spec: KernelSpec, corpus_path) -> int:
    """The replay child's body: the capability guard installed, the corpus replayed, one canonical JSON
    line on stdout (the section with "capability_guard": "armed", or {"refused": ...} and EXIT_REFUSED).
    A reach refused outside any kernel call (a finalizer, say) refuses the replay too."""
    install_capability_guard()
    try:
        body = replay_corpus(spec, load_corpus(corpus_path))
        _SANDBOX.raise_violations()
    except ConformRefused as exc:
        return _emit({"refused": exc.to_dict()}, EXIT_REFUSED)
    except _CapabilityRefused as exc:
        refused = ConformRefused("conform_capability", "; ".join(_SANDBOX.violations) or str(exc))
        _SANDBOX.violations = []
        return _emit({"refused": refused.to_dict()}, EXIT_REFUSED)
    body["capability_guard"] = "armed"
    return _emit(body, 0)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="python -m leafhft.engine_conform", description=__doc__.split("\n")[0])
    verbs = parser.add_subparsers(dest="verb", required=True)
    for name in ("replay", "conform"):
        verb = verbs.add_parser(name)
        verb.add_argument("--manifest", required=True)
        verb.add_argument("--corpus", required=True)
        verb.add_argument("--engines-dir", required=True)
        if name == "conform":
            verb.add_argument("--out", required=True)
            verb.add_argument("--registry", required=True,
                              help="the registry document whose assignments name the required peers")
            verb.add_argument("--peer", action="append", default=[], type=_parse_peer,
                              help="relation=manifest_path; relation is parent or assigned")
    args = parser.parse_args(argv)
    try:
        if args.verb == "replay":
            # The guard goes in before the kernel module is imported, so its module-level aliases
            # capture the shims; the import itself runs as kernel code.
            install_capability_guard()
            manifest = validate_manifest(args.manifest)
            spec = spec_for(manifest, import_kernel(resolve_manifest_kernel, manifest), args.engines_dir)
            return run_guarded_replay(spec, args.corpus)
        body = conform(args.manifest, args.corpus, engines_dir=args.engines_dir, assignments=args.registry,
                       peers=args.peer)
        _write_atomic(Path(args.out), canonical_json(body) + b"\n")
        body = {"engine_id": body["engine_id"], "binding_sha256": body["binding_sha256"],
                "novelty": body["novelty"]["verdict"], "out": str(args.out)}
    except ConformRefused as exc:
        return _emit({"refused": exc.to_dict()}, EXIT_REFUSED)
    return _emit(body, 0)


if __name__ == "__main__":
    sys.exit(main())
