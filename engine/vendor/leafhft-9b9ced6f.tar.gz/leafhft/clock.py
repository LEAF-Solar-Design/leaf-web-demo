"""Two clocks, never confused: wall time for ledgers and exchanges, monotonic for latency."""
from __future__ import annotations

import time
from datetime import datetime, timezone


def now_ns() -> int:
    """Wall clock, integer nanoseconds since epoch."""
    return time.time_ns()


def mono_ns() -> int:
    """Monotonic clock, integer nanoseconds; only differences are meaningful."""
    return time.perf_counter_ns()


def iso(ns: int) -> str:
    return datetime.fromtimestamp(ns / 1e9, tz=timezone.utc).isoformat(timespec="milliseconds")


def parse_rfc3339_ns(s: str) -> int:
    """Parse '2026-09-05T03:32:14.358292793Z' (up to 9 fractional digits) to epoch ns. Fails closed."""
    if not isinstance(s, str) or len(s) < 20 or len(s) > 40:
        raise ValueError(f"bad timestamp {s!r}")
    body = s[:-1] if s.endswith("Z") else s
    frac_ns = 0
    if "." in body:
        body, frac = body.split(".", 1)
        # strip a trailing offset if present
        for sep in ("+", "-"):
            if sep in frac:
                frac = frac.split(sep, 1)[0]
        if not frac.isdigit() or len(frac) > 9:
            raise ValueError(f"bad fraction in {s!r}")
        frac_ns = int(frac.ljust(9, "0"))
    dt = datetime.fromisoformat(body)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp()) * 1_000_000_000 + frac_ns
