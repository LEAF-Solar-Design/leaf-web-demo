"""Dedicated Gold live entry point using the shared live authorization gate.

main() is the owner entry and refuses any account lane. run_lane() is the account
lane seam: it runs one Gold book under the lane's own credential, arm and
AccountLiveBudget, and never reads the owner trees under /etc/leafhft or /run/leafhft.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from decimal import Decimal, InvalidOperation
import os
import sys
import time

from .config import PROBE_BINDINGS_ENV

OWNER_PATH_ROOTS = ("/etc/leafhft", "/run/leafhft")
LANE_KEY_ENV = ("LEAFHFT_KALSHI_KEY_ID", "LEAFHFT_KALSHI_PRIVATE_KEY_PEM")
# (lane_id, arm_path) while run_lane drives its one book; None for the owner.
_ACCOUNT_LANE = None


def _gold_live_fence(cfg):
    from .gold_live import GOLD_LIVE_ADMISSION

    if cfg.symbol not in GOLD_LIVE_ADMISSION:
        raise ValueError("gold fence: symbol")
    for field in (
        "policy_path", "engines_dir", "engine_bindings", "engine_account_overrides",
        "execution_experiment_path", "probe_bindings", "parity_mirror", "executor_mode",
        "shadow_policy_path", "lane_documents", "darkhorse_config_path",
        "alternate_strategy", "strategy_params",
    ):
        if getattr(cfg, field, None):
            raise ValueError("gold fence: " + field)
    if cfg.coordinated_mode != "off":
        raise ValueError("gold fence: coordinated_mode")


def _account_lane_open(lane_id, arm_path, now_ms=None):
    """The lane arm gate: fresh arm read, then gold_live.account_entry_open. Fails closed."""
    from . import gold_live

    now_ms = int(time.time() * 1000) if now_ms is None else now_ms
    try:
        arm = gold_live.load_account_arm(arm_path, lane_id=lane_id, now_ms=now_ms)
        opened, reason = gold_live.account_entry_open(
            arm, lane_id=lane_id, build_sha=os.environ.get("LEAFHFT_BUILD_SHA", ""),
            build_dirty=os.environ.get("LEAFHFT_BUILD_DIRTY", ""), now_ms=now_ms)
    except Exception as exc:
        return False, "arm:" + str(getattr(exc, "reason", "error"))[:64]
    return opened is True, str(reason)


def _gold_guard_buy(original, switch):
    from .broker.kalshi_book import KalshiBookError

    lane = _ACCOUNT_LANE  # bound at wrap time: a lane book never consults the owner switch

    async def guarded(ticker, *args, **kwargs):
        if not isinstance(ticker, str) or not ticker.startswith("KXGOLD15M-"):
            raise KalshiBookError("gold guard: ticker")
        armed, reason = _account_lane_open(*lane) if lane is not None else switch.armed()
        if not armed:
            raise KalshiBookError("gold guard: " + reason)
        return await original(ticker, *args, **kwargs)

    return guarded


class _GoldNoSideEngine:
    """Null lane for Gold, preserving the shared loop's reporting interface."""

    client = None

    def snapshot(self):
        return None

    def on_event(self, ev, now_ns):
        pass

    async def close(self):
        return {"clean": True, "unresolved": [], "unreconcilable": 0}


class _GoldLiveEvidence:
    """Bounded evidence reads, independent of the arm pin for disarmed diagnostics."""

    def __init__(self, clock_ms, path="/etc/leafhft/gold-live-evidence.json"):
        from .gold_runner import gold_source_sha256

        self.clock_ms = clock_ms
        self.path = path
        self.source_sha256 = gold_source_sha256()
        self.next_read_ms = 0
        self.evidence = None
        self.reason = "not_loaded"

    def __call__(self):
        import hashlib
        from . import gold_live
        from .gold_paper_live import ARTIFACTS_SHA256

        now_ms = self.clock_ms()
        if now_ms >= self.next_read_ms:
            self.next_read_ms = now_ms + 5000
            self.evidence = None
            try:
                with open(self.path, "rb") as stream:
                    data = stream.read(gold_live.MAX_EVIDENCE_BYTES + 1)
                if len(data) > gold_live.MAX_EVIDENCE_BYTES:
                    raise gold_live.EvidenceRefused("too_large")
                self.evidence = gold_live.load_evidence(
                    self.path, expected_sha256=hashlib.sha256(data).hexdigest(), now_ms=now_ms,
                    source_sha256=self.source_sha256, artifacts_sha256=ARTIFACTS_SHA256)
                self.reason = "ok"
            except gold_live.EvidenceRefused as exc:
                self.reason = exc.reason
            except OSError:
                self.reason = "io"
        if self.evidence is not None and not 0 <= now_ms - self.evidence.generated_at_ms <= 86_400_000:
            return None, "stale"
        return self.evidence, self.reason


def main(argv=None):
    parser = argparse.ArgumentParser(prog="python -m leafhft.gold_live_main")
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run")
    run.add_argument("--stake-usd", required=True)
    run.add_argument("--run-dir", required=True)
    run.add_argument("--ack-dir", required=True)
    run.add_argument("--seconds", type=int, required=True)
    args = parser.parse_args(argv)
    for name in ("LEAFHFT_ACCOUNT_LANE_ID", PROBE_BINDINGS_ENV):
        if name in os.environ:
            parser.error("Gold refuses environment variable " + name)
    try:
        stake = Decimal(args.stake_usd)
        valid = stake.is_finite() and Decimal("1.00") <= stake <= Decimal("50.00")
        valid = valid and stake == stake.quantize(Decimal("0.01"))
    except InvalidOperation:
        valid = False
    if not valid:
        parser.error("stake-usd must be 1.00 to 50.00 dollars in whole cents")
    if not 0 <= args.seconds <= 30 * 86_400:
        parser.error("seconds must be between 0 and 2592000")
    a = _gold_namespace(stake, args.run_dir, args.ack_dir, args.seconds,
                        "/var/lib/leafhft/kalshi-authority.json")
    from . import cli

    return cli.cmd_live(a)


def _gold_namespace(stake, run_dir, ack_dir, seconds, authority_path):
    """The one Gold selection: every optional fleet selector off, owner and lane alike."""
    return argparse.Namespace(
        venue="kalshi", symbol="GOLD-15M", strategy="kalshi_gold",
        stake_usd=format(stake, ".2f"), cash=format(stake, ".2f"), goal="1000",
        run_dir=run_dir, ack_dir=ack_dir, seconds=seconds,
        limits_profile="kalshi-experiment", darkhorse_config="", lane=(), params=None,
        policy="", engines_dir="", engine_bindings="", engine_account_overrides="",
        execution_experiment="", probe_bindings="", engine_registry="", lifecycle_dir="",
        parity_mirror=False, executor_mode=False, book_tap="", shadow_policy="",
        shadow_cash_usd=500, alternate="", block_minutes=0, reference_venue="",
        dashboard_account_identity="", coordinated_mode="off", classification_mode="", hot_observation_mode="off",
        authority_path=authority_path, demo=False,
        adopt_inventory=False, probe_order=False, transport="auto",
    )


def _owner_path(path) -> bool:
    text = str(path).replace("\\", "/")
    return any(text == root or text.startswith(root + "/") for root in OWNER_PATH_ROOTS)


def lane_budget(lane_id):
    """The kalshi_edge lane books' AccountLiveBudget, built from the same public helpers.

    Reads only the lane's systemd credential copies and its state directory. Returns
    (budget, per_book_allowance_cents, kalshi_authority_path). Raises on any refusal.
    """
    from . import account_lane_agent as agent
    from .broker.account_live_budget import AccountLiveBudget

    paths, config, read = agent.load_runtime(lane_id)
    credential = read("credential")
    if (os.environ.get("LEAFHFT_KALSHI_KEY_ID") != credential.get("key_id")
            or os.environ.get("LEAFHFT_KALSHI_PRIVATE_KEY_PEM") != credential.get("private_key_pem")
            or os.environ.get("LEAFHFT_LIVE") != "1"):
        raise agent.LaneRefused("account credential mismatch")
    authorization = read("approval")
    agent.require_live(config, credential, authorization, read("dry-run"), runtime_paths=paths)
    if os.environ.get("LEAFHFT_STATE_DIR") != str(paths.state):
        raise agent.LaneRefused("account state mismatch")
    if agent.safe_path(paths.state / "KILL").exists():
        raise agent.LaneRefused("account stopped")
    approved = agent.account_budget(paths, config)  # the approval binding check

    class ActivatedBudget(AccountLiveBudget):
        # Same activation fence as validate_live_arguments: stop or revoke ends every claim.
        def snapshot(self, **kwargs):
            agent.require_activation(paths, config, authorization)
            return super().snapshot(**kwargs)

        def claim(self, *args, **kwargs):
            agent.require_activation(paths, config, authorization)
            return super().claim(*args, **kwargs)

    budget = ActivatedBudget(approved.path, lane_id=approved.lane_id, generation=approved.generation,
                             digest=approved.digest, sizing=config.get("account_sizing"))
    budget.snapshot()
    stake = Decimal(agent.account_stake(config))
    return budget, int(stake * 100), str(paths.state / "kalshi-authority.json")


@contextmanager
def _account_lane_scope(lane_id, arm_path, max_count=None):
    """Bind the lane arm for this process's one Gold book.

    The shared driver builds KalshiGoldEdge and the buy guards by name at call time;
    inside this scope they come up in account mode and never consult the owner switch
    or evidence file. max_count caps the arm's fixed count. Restored on exit.
    """
    global _ACCOUNT_LANE
    from .strategy import kalshi_gold_edge

    original, previous = kalshi_gold_edge.KalshiGoldEdge, _ACCOUNT_LANE

    def account_book(params, *args, **kwargs):
        kwargs.update(account_lane_id=lane_id, account_arm_path=arm_path,
                      account_max_count=max_count)
        return original(params, *args, **kwargs)

    _ACCOUNT_LANE = (lane_id, arm_path)
    kalshi_gold_edge.KalshiGoldEdge = account_book
    try:
        yield
    finally:
        kalshi_gold_edge.KalshiGoldEdge = original
        _ACCOUNT_LANE = previous


def _run_lane_book(a, *, budget, lane_id, arm_path, fixed_count):
    """cmd_live's Kalshi branch for one Gold lane book, with the lane budget on the authorization.

    cmd_live itself is the kalshi_edge lane rail and refuses this selection by design.
    """
    import asyncio
    from dataclasses import replace

    from . import cli
    from .broker.live_gate import LiveGateClosed, readiness
    from .config import EngineConfig
    from .types import to_quote_q

    try:
        generation = cli._kalshi_authority_generation(a.authority_path)
    except ValueError as exc:
        print(f"LIVE GATE CLOSED: {exc}", file=sys.stderr)
        return 4
    cfg = EngineConfig(venue="kalshi", symbol=a.symbol, strategy=a.strategy, mode="live",
                       starting_cash_q=to_quote_q(a.stake_usd), goal_q=to_quote_q(a.goal),
                       run_seconds=a.seconds, limits_profile=a.limits_profile,
                       authority_path=a.authority_path, authority_generation=generation,
                       coordinated_mode="off",
                       # The default names the owner tree; Gold's fence refuses any value.
                       darkhorse_config_path=a.darkhorse_config)
    run_dir = cli._run_dir(a.run_dir, f"live-{a.venue}-{a.strategy}")
    source_ack = cli._copy_live_ack(cfg, a.ack_dir, run_dir)
    blockers = readiness(cfg, run_dir)
    if blockers:
        for blocker in blockers:
            print(f"LIVE GATE CLOSED: {blocker}", file=sys.stderr)
        cli._discard_refused_run_dir(cfg, run_dir)
        return 4
    try:
        auth = replace(cli._consume_shared_ack_and_arm(cfg, run_dir, source_ack),
                       account_budget=budget)
    except LiveGateClosed as exc:
        print(f"LIVE GATE CLOSED: {exc}\nconfig digest: {cfg.digest()}", file=sys.stderr)
        cli._discard_refused_run_dir(cfg, run_dir)
        return 4
    print(f"run_dir={run_dir}", flush=True)
    with _account_lane_scope(lane_id, arm_path, fixed_count):
        receipt = asyncio.run(cli._run_kalshi_live(a, cfg, auth, run_dir))
    cli._print_receipt(receipt)
    if not receipt["live"]["clean"]:
        print("LIVE NOT CLEAN: unresolved execution; inspect receipt.json", file=sys.stderr)
        return 5
    return receipt.get("exit_code", 5) if receipt.get("exception") else 0


def run_lane(*, lane_id, ack_dir, run_dir, authority_path, stake_usd, seconds,
             fixed_count=Decimal("0.25")) -> int:
    """Run Gold on one account lane. Refuses (exit 2, no venue call, no file read) unless the
    process is that lane's live account runtime; the lane budget failing to install is exit 4.

    authority_path is the lane's Gold arm. stake_usd is capped by the lane's per-book
    allowance and every non-reduce-only send claims against the same AccountLiveBudget.
    """
    def refuse(reason):
        print(f"GOLD LANE REFUSED: {reason}", file=sys.stderr)
        return 2

    if not isinstance(lane_id, str) or not lane_id or len(lane_id) > 64:
        return refuse("lane id")
    if os.environ.get("LEAFHFT_ACCOUNT_LANE_ID") != lane_id:
        return refuse("LEAFHFT_ACCOUNT_LANE_ID does not name this lane")
    if os.environ.get("LEAFHFT_RISK_REGIME") != "account":
        return refuse("LEAFHFT_RISK_REGIME is not account")
    if os.environ.get("LEAFHFT_LIVE") != "1":
        return refuse("LEAFHFT_LIVE is not 1")
    for name in LANE_KEY_ENV:
        if not os.environ.get(name):
            return refuse(name + " missing")
    if (not isinstance(fixed_count, Decimal) or not fixed_count.is_finite()
            or not Decimal("0.01") <= fixed_count <= Decimal("1.00")
            or fixed_count != fixed_count.quantize(Decimal("0.01"))):
        return refuse("fixed_count must be 0.01 to 1.00 in hundredths")
    try:
        stake = Decimal(str(stake_usd))
        valid = stake.is_finite() and stake > 0 and stake == stake.quantize(Decimal("0.01"))
    except InvalidOperation:
        valid = False
    if not valid:
        return refuse("stake-usd must be positive whole cents")
    if type(seconds) is not int or not 0 <= seconds <= 30 * 86_400:
        return refuse("seconds must be between 0 and 2592000")
    for label, path in (("ack dir", ack_dir), ("run dir", run_dir), ("arm path", authority_path)):
        if not path or _owner_path(path):
            return refuse(label + " is empty or an owner path")
    try:
        budget, allowance_cents, kalshi_authority = lane_budget(lane_id)
    except Exception as exc:
        print(f"LIVE GATE CLOSED: lane budget: {type(exc).__name__}: {str(exc)[:200]}",
              file=sys.stderr)
        return 4
    if _owner_path(kalshi_authority):
        return refuse("lane authority is an owner path")
    # One pool: the stake never exceeds the lane's per-book allowance.
    stake = min(stake, Decimal(allowance_cents) / 100)
    if stake <= 0:
        return refuse("lane allowance is zero")
    a = _gold_namespace(stake, run_dir, ack_dir, seconds, kalshi_authority)
    return _run_lane_book(a, budget=budget, lane_id=lane_id, arm_path=authority_path,
                          fixed_count=fixed_count)


if __name__ == "__main__":
    raise SystemExit(main())
