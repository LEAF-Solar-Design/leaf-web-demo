"""Tenant calibrated stake: each engine's cautious stake fraction from its own settled trades.

Tester card T2: stake follows an engine's real, cautious hit rate, and an engine stakes nothing
new until it has at least 20 independent settled trades. The owner already sizes that way in
owner_live_ledger; a tenant lane gets the same answer from its OWN ticket ledger, locally.

Parity contract: rows are paired with owner_live_ledger's own row readers (_engine, _entry,
_outcome, _episode) under the same dedup rules as its _consume and the same episode order as
its _export, then summed by engine_cells.Cells and sized by calibrated_sizing.cell_fraction with
its defaults. The same rows therefore give the tenant and the owner the same fraction.

Hardening contract: a pure function of the file bytes (no clock, no network, no broker import,
no writes). The read is bounded to the newest max_bytes and max_rows. Nothing a row contains
can raise out or grant stake: a bad row attributable to an engine zeroes only that engine with
reason "history_unreadable"; a line no engine can be read from, or an unreadable file, zeroes
every engine the same way. Dormant: no live path calls this module yet.
"""
from __future__ import annotations

from collections import Counter
from collections.abc import Mapping
from dataclasses import dataclass
from decimal import Decimal, localcontext
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import stat
import sys
import threading
from types import MappingProxyType

from leafhft.engine_cells import CellRejected, Cells, canonical, identifier
from leafhft.owner_live_ledger import _engine, _entry, _episode, _outcome
from leafhft.research import calibrated_sizing

MAX_ROWS = 20000
MAX_READ_BYTES = 32 * 1024 * 1024  # the tail window; the file is never read whole
BUCKETS = tuple(calibrated_sizing.claimed_bucket(p) for p in (0, .7, .8, .9, .95))
ALL_ENGINES = "*"  # not an identifier, so it never collides with a real engine id
REASONS = frozenset({"ok", "n_below_20", "n_eff_below_20", "history_unreadable", "no_history"})
# The owner's cell symbol comes from the run config; a tenant ledger is one book, so one
# fixed symbol keys its cells and the (engine, bucket) answer matches the owner's.
_SYMBOL = "tenant-book"
_ENTRY_KINDS = ("buy", "entry", "fill")
_OUTCOME_KINDS = ("settle", "exit", "void")


@dataclass(frozen=True)
class Decision:
    """One (engine, bucket) cell's stake fraction of the balance, 0.0 unless reason is "ok".

    reason "ok" means the cell passed the sample guards and fraction is cell_fraction's answer,
    which is itself 0.0 when the lower-bound edge is not positive; detail carries
    cell_fraction's own reason (or the rejection reason) for that case.
    """

    fraction: float
    n: int
    n_eff: float
    wins: int
    reason: str
    detail: str


def _zero(reason, detail, n=0, n_eff=0.0, wins=0):
    return Decision(0.0, n, n_eff, wins, reason, detail)


NO_HISTORY = _zero("no_history", "no_history")


def _sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()  # owner_live_ledger._hash


def _reason(sizing_reason):
    if sizing_reason.startswith("n<"):
        return "n_below_20"
    if sizing_reason.startswith("n_eff<"):
        return "n_eff_below_20"
    return "ok"


def _tail_lines(path, max_rows, max_bytes):
    """The newest complete lines, at most max_rows of them from at most max_bytes of the tail.

    Returns None for a missing file; raises OSError for an unreadable one. A partial first
    line (cut by the window) and an unterminated last line (a row still being written) are
    dropped, never parsed."""
    try:
        with Path(path).open("rb") as stream:
            size = stream.seek(0, 2)
            # One byte before the window: when it is a newline the first line is whole.
            start = max(0, size - max_bytes - 1)
            stream.seek(start)
            data = stream.read(max_bytes + 1)
    except FileNotFoundError:
        return None
    lines = data.split(b"\n")
    lines.pop()  # empty after a final newline, else an unfinished row
    if start > 0 and lines:
        lines.pop(0)  # the window cut this line (or it is the empty head before a newline)
    return lines[-max_rows:]


def _sealed(row):
    """False when the row carries an attribution that is not a sealed ("known") one, such as the
    attribution_or_unknown() sentinel an adopted ticket's rows get after a restart."""
    attribution = row.get("attribution")
    return not isinstance(attribution, dict) or attribution.get("status") == "known"


def _claimed_engine(row):
    """The engine a terminal row itself names with authority, else None (unknown)."""
    if not _sealed(row):
        return None
    attribution = row.get("attribution")
    engine = attribution.get("engine_id") if isinstance(attribution, dict) else row.get("engine_id")
    return engine if identifier(engine) else None


_REALIZING_KINDS = ("reversal", "close")  # KalshiBook H1c reversals, KalshiPerp closes
_REALIZING_FIELDS = ("pnl", "pnl_cents", "pnl_usd", "proceeds_cents", "realized_cents", "transaction")
# Kinds the brokers write that realize nothing, excluded by name before the field test: an
# "unsettled" report carries pnl_cents 0 and payout_cents 0 (kalshi_book.py
# SettlementPoller._maybe_report_unsettled, _ledger_row("unsettled", ...)), "adopt" re-opens
# a ticket after a restart (kalshi_book.py adopt_prior, kalshi_perp.py adopt, lanes/live_runner.py
# _adopt), "combined_zero" keeps a zero share of a combined fill (kalshi_book.py
# record_combined_zero), and "decision" logs an admission (kalshi_live_runtime.py, lanes/
# live_runner.py, strategy/kalshi_gold.py). Every other unknown kind with a P&L field refuses.
_NON_REALIZING_KINDS = frozenset({"unsettled", "adopt", "combined_zero", "decision"})


def _realizes(row):
    """True when a row outside buy/settle/exit/void realizes P&L (a reversal, a close, or any
    other kind not known to realize nothing that carries a P&L-shaped field), so the pairing
    cannot see that trade's result."""
    kind = row.get("kind")
    if kind in _REALIZING_KINDS:
        return True
    if kind in _NON_REALIZING_KINDS:
        return False
    return any(field in row for field in _REALIZING_FIELDS)


def _pair(lines, tainted):
    """owner_live_ledger._consume's pairing, in memory: first entry per (engine, client_id)
    wins, one terminal outcome per client_id, exits keyed by exit_client_id (else payload),
    and a contradicting replay kept as a conflict so _episode refuses it."""
    entries = {}
    outcomes = {}
    for line in lines:
        if not line.strip():
            continue
        engine = None
        try:
            row = json.loads(line)
            if not isinstance(row, dict):
                raise CellRejected("invalid_row")
            kind = row.get("kind")
            if kind not in _ENTRY_KINDS + _OUTCOME_KINDS:
                continue  # decisions, adopts and unknown kinds never size a cell
            engine = _engine(row, None)
            cid = row.get("client_id")
            if not isinstance(cid, str) or not cid or len(cid) > 512:
                raise CellRejected("invalid_client_id")
            key = (engine, _sha(cid))
            if kind in _ENTRY_KINDS:
                entry = _entry(row, _SYMBOL)
                entries.setdefault(key, entry)
                continue
            outcome = _outcome(row)
            payload = canonical(outcome).decode("ascii")
            event = ("terminal" if kind != "exit" else
                     _sha(str(row["exit_client_id"])) if row.get("exit_client_id") else _sha(payload))
            events = outcomes.setdefault(key, {})
            if event not in events:
                events[event] = outcome
                continue
            old, new = dict(events[event]), dict(outcome)
            old.pop("settled_at_ms", None)
            new.pop("settled_at_ms", None)
            if old != new:
                events.setdefault("conflict-" + _sha(payload), outcome)
        except Exception as exc:  # any bad row fails closed; nothing it holds may raise out
            reason = exc.reason if isinstance(exc, CellRejected) else "invalid_row"
            tainted[engine if identifier(engine) else ALL_ENGINES] = reason
    return entries, outcomes


def _pair_lane(lines, tainted, orphans, realized):
    """The lane-history pairing (lane_history_fractions only; calibrated_fractions keeps _pair,
    byte-identical to main): _pair's dedup and conflict rules, plus the refusals below.

    Every realizing row of another kind (_realizes: an H1c reversal closes a ticket with no
    settle or exit ever written for it) taints its engine, or every engine when its attribution
    is not sealed, with "realizing_row", and is counted in realized.

    Terminal rows pair by client_id, never by their own attribution alone: a settle, exit or void
    whose attribution is not sealed inherits the engine of the buy with the same client_id, so an
    adopted ticket's loss still lands on the engine that bought it. Fails closed for every engine
    (ALL_ENGINES) on an entry whose attribution is not sealed, on a terminal row whose sealed
    engine differs from its buy's ("engine_mismatch", as the owner reader refuses), and on a
    terminal row with an unknown engine and no buy anywhere in lines (an orphan whose loss cannot
    be attributed). An orphan with a sealed engine pairs with nothing and is counted in orphans."""
    entries = {}
    outcomes = {}
    buyers = {}  # hashed client_id -> the engines whose entries carry it
    terminals = []
    for line in lines:
        if not line.strip():
            continue
        engine = None
        try:
            row = json.loads(line)
            if not isinstance(row, dict):
                raise CellRejected("invalid_row")
            kind = row.get("kind")
            if kind not in _ENTRY_KINDS + _OUTCOME_KINDS:
                if _realizes(row):
                    engine = _claimed_engine(row)
                    key = engine if engine is not None else ALL_ENGINES
                    realized[key] = realized.get(key, 0) + 1
                    raise CellRejected("realizing_row")  # its loss would vanish from the pairing
                continue  # decisions, adopts and other non-realizing kinds never size a cell
            if kind in _OUTCOME_KINDS:
                engine = _claimed_engine(row)
            elif not _sealed(row):
                raise CellRejected("unattributed_entry")
            else:
                engine = _engine(row, None)
            cid = row.get("client_id")
            if not isinstance(cid, str) or not cid or len(cid) > 512:
                raise CellRejected("invalid_client_id")
            if kind in _OUTCOME_KINDS:
                terminals.append((row, kind, _sha(cid), engine))
                continue
            buyers.setdefault(_sha(cid), set()).add(engine)
            entries.setdefault((engine, _sha(cid)), _entry(row, _SYMBOL))
        except Exception as exc:  # any bad row fails closed; nothing it holds may raise out
            reason = exc.reason if isinstance(exc, CellRejected) else "invalid_row"
            tainted[engine if identifier(engine) else ALL_ENGINES] = reason
    for row, kind, cid, claimed in terminals:  # every entry is known now; terminals keep their order
        engine = None
        try:
            owners = buyers.get(cid)
            if not owners:
                if claimed is None:
                    raise CellRejected("orphan_unattributed_outcome")
                orphans[claimed] = orphans.get(claimed, 0) + 1
            elif claimed is None:
                if len(owners) != 1:
                    raise CellRejected("ambiguous_client_id")
                (claimed,) = owners
            elif claimed not in owners:
                raise CellRejected("engine_mismatch")
            engine = claimed
            key = (engine, cid)
            outcome = _outcome(row)
            payload = canonical(outcome).decode("ascii")
            event = ("terminal" if kind != "exit" else
                     _sha(str(row["exit_client_id"])) if row.get("exit_client_id") else _sha(payload))
            events = outcomes.setdefault(key, {})
            if event not in events:
                events[event] = outcome
                continue
            old, new = dict(events[event]), dict(outcome)
            old.pop("settled_at_ms", None)
            new.pop("settled_at_ms", None)
            if old != new:
                events.setdefault("conflict-" + _sha(payload), outcome)
        except Exception as exc:  # any bad row fails closed; nothing it holds may raise out
            reason = exc.reason if isinstance(exc, CellRejected) else "invalid_row"
            tainted[engine if identifier(engine) else ALL_ENGINES] = reason
    return entries, outcomes


def calibrated_fractions(ledger_path, *, max_rows=MAX_ROWS, now_ms=None, max_bytes=MAX_READ_BYTES):
    """{(engine_id, bucket): Decision} from one account's ticket ledger; never raises on file
    content. now_ms, when given, counts only trades filled and settled at or before it."""
    if type(max_rows) is not int or max_rows < 1 or type(max_bytes) is not int or max_bytes < 1:
        raise ValueError("max_rows and max_bytes must be positive integers")
    if now_ms is not None and (type(now_ms) is not int or now_ms < 0):
        raise ValueError("now_ms must be a non-negative integer")
    try:
        lines = _tail_lines(ledger_path, max_rows, max_bytes)
    except OSError:
        return {(ALL_ENGINES, b): _zero("history_unreadable", "unreadable_file") for b in BUCKETS}
    if lines is None:
        return {}
    return _fractions_from_lines(lines, now_ms)


def _fractions_from_lines(lines, now_ms=None, orphans=None, realized=None):
    """calibrated_fractions' pairing and sizing over lines already read (oldest first), in
    memory; the one core both the single-ledger and the cross-run readers share. Without orphans
    and realized (calibrated_fractions) rows pair exactly as on main (_pair); with them (the
    lane-history path) _pair_lane pairs by client_id, collects {engine: count} of sealed terminal
    rows that matched no buy in orphans, and refuses and collects realizing rows in realized."""
    tainted = {}
    with localcontext() as context:
        context.prec = 120  # owner_live_ledger.build_ledger's precision, for identical episodes
        if orphans is None and realized is None:
            entries, outcomes = _pair(lines, tainted)
        else:
            entries, outcomes = _pair_lane(lines, tainted, {} if orphans is None else orphans,
                                           {} if realized is None else realized)
        cells = {}
        # owner_live_ledger._export's order: entries by (fill time, hashed client id), outcomes by event.
        for (engine, cid), entry in sorted(entries.items(), key=lambda i: (i[1]["filled_at_ms"], i[0][1])):
            engine_cells = cells.setdefault(engine, Cells())
            if now_ms is not None and entry["filled_at_ms"] > now_ms:
                continue
            events = outcomes.get((engine, cid), {})
            try:
                outcome = _episode(entry, [events[e] for e in sorted(events)])
                if outcome is None or (now_ms is not None and outcome["settled_at_ms"] > now_ms):
                    continue  # still open
                engine_cells.add(entry, outcome)
            except Exception as exc:
                tainted[engine] = exc.reason if isinstance(exc, CellRejected) else "invalid_row"
    decisions = {}
    for engine in sorted(set(cells) | {e for e in tainted if e != ALL_ENGINES}):
        found = {}
        try:
            document = cells.get(engine, Cells()).to_document(engine)
            for bucket, cell in document["cells"].get(_SYMBOL, {}).items():
                sizing = calibrated_sizing.cell_fraction(cell["returns"], list(Counter(cell["windows"]).values()))
                found[bucket] = Decision(sizing.fraction, cell["n"], sizing.n_eff, cell["wins"],
                                         _reason(sizing.reason), sizing.reason)
        except Exception:
            tainted.setdefault(engine, "invalid_cells")
            found = {}
        why = tainted.get(engine, tainted.get(ALL_ENGINES))
        if why is None:
            decisions.update(((engine, bucket), value) for bucket, value in found.items())
            continue
        for bucket in BUCKETS:
            cell = found.get(bucket)
            decisions[(engine, bucket)] = (_zero("history_unreadable", why, cell.n, cell.n_eff, cell.wins)
                                           if cell else _zero("history_unreadable", why))
    if ALL_ENGINES in tainted:
        decisions.update(((ALL_ENGINES, b), _zero("history_unreadable", tainted[ALL_ENGINES]))
                         for b in BUCKETS)
    return decisions


def fraction_for(decisions, engine_id, claimed_prob):
    """The Decision for engine_id at claimed_prob's bucket; fraction 0 "no_history" for an
    unknown engine, bucket or probability, and "history_unreadable" when the whole ledger was."""
    bucket = calibrated_sizing.claimed_bucket(claimed_prob)
    if bucket is None:
        return NO_HISTORY
    found = decisions.get((engine_id, bucket))
    if found is None:
        found = decisions.get((ALL_ENGINES, bucket))
    return NO_HISTORY if found is None else found


# ---------------------------------------------------------------- T2-v4: the parent's cross-run history

HISTORY_MAX_BYTES = 4 * 1024 * 1024  # one ledger-byte budget shared by every run dir in a refresh
HISTORY_MAX_ROWS = 20000  # one row budget shared the same way; the newest rows are the ones kept
HISTORY_MAX_FILES = 64  # the newest run dirs read per refresh
HISTORY_MAX_PATHS = 4096  # a longer paths list is refused whole, so the selection itself is bounded
CONFIG_MAX_BYTES = 64 * 1024  # a run's config.json is read only when it is at most this size
PROBE_LEDGER_NAME = "kalshi-probe-tickets.jsonl"
PROBE_DIR_PREFIX = "probe-"


def _diagnose(path, why):
    """One stderr line per affected file per refresh; never a file write."""
    print(f"calibrated stake history: {path}: {why}"[:400], file=sys.stderr)


def _unreadable(why):
    """Every bucket history_unreadable for every engine: the whole history refuses."""
    return {(ALL_ENGINES, b): _zero("history_unreadable", why[:200]) for b in BUCKETS}


def _select(ledger_paths, max_files):
    """Any probe paths (to be refused), then the newest max_files distinct ledger paths, newest
    run dir first (a run dir's name starts with its UTC allocation stamp, cli.py _run_dir). A
    list over HISTORY_MAX_PATHS is refused whole."""
    if isinstance(ledger_paths, (str, bytes, os.PathLike)):
        raise TypeError("ledger_paths must be an iterable of paths, not one path")
    paths = list(itertools.islice(ledger_paths, HISTORY_MAX_PATHS + 1))
    if len(paths) > HISTORY_MAX_PATHS:
        raise ValueError(f"more than {HISTORY_MAX_PATHS} ledger paths")
    unique = {}
    for path in paths:
        path = Path(path)
        unique.setdefault(str(path), path)
    ordered = sorted(unique.values(), key=lambda p: (p.parent.name, p.name, str(p)), reverse=True)
    # Probe paths come first and never take a max_files slot: the reader refuses each of them.
    return [p for p in ordered if _is_probe(p)] + [p for p in ordered if not _is_probe(p)][:max_files]


def _is_probe(path):
    """The t2cal leg's own ledger, by name or by its probe-* run dir; it never feeds admission."""
    return path.name == PROBE_LEDGER_NAME or path.parent.name.startswith(PROBE_DIR_PREFIX)


def _run_identity_matches(directory, venue, symbol):
    """True when directory's config.json names this venue and symbol in live mode. Reads at most
    CONFIG_MAX_BYTES; raises on a missing, linked, oversized or malformed (or too deep) config."""
    config = directory / "config.json"
    info = os.lstat(config)
    if not stat.S_ISREG(info.st_mode):
        raise ValueError("run config is not a plain file")
    if info.st_size > CONFIG_MAX_BYTES:
        raise ValueError("run config over 64 KiB")
    with config.open("rb") as stream:
        raw = stream.read(CONFIG_MAX_BYTES)
    identity = json.loads(raw)  # a deeply nested config raises RecursionError, which refuses
    if not isinstance(identity, dict):
        raise ValueError("run config is not an object")
    return (identity.get("venue"), identity.get("symbol"), identity.get("mode")) == (venue, symbol, "live")


def _read_ledger_tail(path, info, max_bytes, max_rows, newest=True):
    """(lines, bytes read): the newest complete lines of the plain file path (lstat info), at
    most max_rows of them from at most max_bytes of its tail. A line the window cut is dropped,
    never parsed. An unterminated last line is skipped only in the newest ledger (newest=True),
    where it may be a row still being written; in a closed run it is a torn row and raises, so
    the whole history refuses rather than lose that row (a buy whose loss settles later)."""
    take = min(info.st_size, max_bytes)
    start = info.st_size - take
    with path.open("rb") as stream:
        stream.seek(start)
        data = stream.read(take)
    lines = data.split(b"\n")
    if lines[-1] and not newest:
        raise ValueError("torn final row in a closed run")
    lines.pop()  # empty after a final newline, else an unfinished row
    if start > 0 and lines:
        lines.pop(0)  # the window cut this line (dropped conservatively even when it is whole)
    return lines[-max_rows:], len(data)


def lane_history_fractions(ledger_paths, *, venue, symbol, max_bytes=HISTORY_MAX_BYTES,
                           max_rows=HISTORY_MAX_ROWS, max_files=HISTORY_MAX_FILES):
    """{(engine_id, bucket): Decision} from a PARENT's incumbent kalshi-tickets.jsonl files across
    its run dirs (a run dir resets every run, so one ledger alone forgets every earlier run).

    Bounds: the newest max_files paths, read newest first under ONE shared ledger budget of
    max_bytes and max_rows, so the newest history is what survives the cut; each run's
    config.json is read separately, at most CONFIG_MAX_BYTES of it, so total bytes read never
    exceed max_bytes + CONFIG_MAX_BYTES per file. Only runs whose config names this venue and
    symbol in live mode count. Rows are paired in memory, oldest run first, by the same core as
    calibrated_fractions (no temp file), so an entry in one run and its settlement in a later run
    make one episode, and a bad row zeroes its engine exactly as it does there.

    Skipped silently: a run excluded by identity (its config names another venue, symbol or a
    non-live mode) and a run with no ledger (a newly allocated or pruned run). Skipped with one
    diagnostic: a probe ledger (kalshi-probe-tickets.jsonl, or any file in a probe-* dir: the
    t2cal leg's own tickets must never feed its own admission).

    Fails closed: ANY other failure of an in-scope run (a symlinked or non-regular ledger or run
    dir, a missing, oversized, malformed or too deep config, PermissionError, a ledger read error,
    RecursionError, a torn unterminated last row in any ledger but the open one) makes the whole
    result history_unreadable for every engine and bucket, with one diagnostic. The open ledger is
    decided by position, never by a name stamp alone: it is the first ledger read AND the one with
    the strictly newest st_mtime_ns of every selected ledger. Dropping that run or row instead
    could drop its losses and turn a refusal into a positive fraction. Terminal rows pair by
    client_id (_pair): an unknown-attributed settlement counts for its buy's engine, and one that
    cannot be attributed refuses every engine. A row of any other kind that realizes P&L (an H1c
    reversal, which closes a ticket with no settle or exit ever written) makes its engine
    history_unreadable (every engine when unattributed), with one summary diagnostic: a parent
    that reversed inside the window was not holding to settlement. Sealed settlements whose buy
    is not in the read history get one summary diagnostic. No clock, no network, no writes."""
    return _lane_history(ledger_paths, venue, symbol, max_bytes, max_rows, max_files)[0]


def _lane_history(ledger_paths, venue, symbol, max_bytes=HISTORY_MAX_BYTES,
                  max_rows=HISTORY_MAX_ROWS, max_files=HISTORY_MAX_FILES):
    """(decisions, error): lane_history_fractions' answer and, when an in-scope run could not be
    read, the one-line reason (decisions are then history_unreadable everywhere), else None."""
    for name, value in (("max_bytes", max_bytes), ("max_rows", max_rows), ("max_files", max_files)):
        if type(value) is not int or value < 1:
            raise ValueError(f"{name} must be a positive integer")
    if type(venue) is not str or type(symbol) is not str:
        raise ValueError("venue and symbol must be strings")
    remaining_bytes, remaining_rows = max_bytes, max_rows
    blocks = []
    selected = _select(ledger_paths, max_files)
    latest = _last_written(selected)
    for path in selected:
        if remaining_bytes <= 0 or remaining_rows <= 0:
            break
        if _is_probe(path):
            _diagnose(path, "probe_ledger")
            continue
        try:
            try:
                info = os.lstat(path)
            except FileNotFoundError:
                continue  # a run with no tickets yet (or already pruned) holds no history
            if not stat.S_ISDIR(os.lstat(path.parent).st_mode):
                raise ValueError("run dir is not a plain directory")
            if not stat.S_ISREG(info.st_mode):
                raise ValueError("ledger is not a plain file")
            if not _run_identity_matches(path.parent, venue, symbol):
                continue  # another book's, or a paper run's, ledger never feeds this parent
            # Only the ledger that is newest by POSITION may end mid-write: the first one read (newest
            # run dir by name) AND the one written last (strictly newest mtime of every selected
            # ledger). A name alone is not enough: an unstamped dir sorts ahead of stamped ones.
            open_ledger = not blocks and latest is not None and str(path) == latest
            lines, used = _read_ledger_tail(path, info, remaining_bytes, remaining_rows, open_ledger)
        except Exception as exc:  # RecursionError included: one unreadable run refuses the whole history
            why = f"{type(exc).__name__}: {exc}"[:200]
            _diagnose(path, f"history_unreadable: {why}")
            return _unreadable(why), why
        remaining_bytes -= used
        remaining_rows -= len(lines)
        blocks.append(lines)
    lines = [line for block in reversed(blocks) for line in block]  # oldest run first
    if not lines:
        return {}, None
    orphans, realized = {}, {}
    decisions = _fractions_from_lines(lines, orphans=orphans, realized=realized)
    if orphans:  # a settlement whose buy is older than the window (or never logged) pairs with nothing
        _diagnose("history", "orphan_outcomes " + ",".join(f"{e}={n}" for e, n in sorted(orphans.items())))
    if realized:  # a reversal (or other realizing row) closed a ticket the pairing cannot see
        _diagnose("history", "history_unreadable realizing_rows "
                  + ",".join(f"{e}={n}" for e, n in sorted(realized.items())))
    return decisions, None


def _last_written(paths):
    """str(path) of the one non-probe ledger with the strictly greatest st_mtime_ns, else None
    (a tie, or any ledger whose lstat fails other than as missing: no ledger may then be open)."""
    best, best_ns, tied = None, None, False
    for path in paths:
        if _is_probe(path):
            continue
        try:
            mtime = os.lstat(path).st_mtime_ns
        except FileNotFoundError:
            continue
        except Exception:
            return None
        if best_ns is None or mtime > best_ns:
            best, best_ns, tied = str(path), mtime, False
        elif mtime == best_ns:
            tied = True
    return None if tied else best


# ---------------------------------------------------------------- T2-v4: the off-loop refresher

REFRESH_INTERVAL_NS = 60 * 1_000_000_000  # recompute at most this often
STALE_AFTER_NS = 180 * 1_000_000_000  # a snapshot older than this is not fresh
CLOCK_SKEW_NS = 1_000_000_000  # a caller's now may trail the publish by this much
REFRESH_POLL_S = 1.0
STOP_JOIN_S = 2.0


@dataclass(frozen=True)
class T2Snapshot:
    """One published history: decisions is a read-only mapping, computed_wall_ns the clock
    reading that confirmed it, error None unless the refresh failed (decisions then refuse every
    engine and bucket with history_unreadable, and source_digest is ""), source_digest the
    sha256 of the (path, st_size, st_mtime_ns) signature of every ledger and its run's config."""

    decisions: Mapping
    computed_wall_ns: int
    error: str | None
    source_digest: str


def _error_snapshot(now, why):
    why = why[:200]
    return T2Snapshot(MappingProxyType(_unreadable(why)), now if type(now) is int else 0, why, "")


_UNCOMPUTED = _error_snapshot(0, "not_computed")


def _signature(paths):
    """Covers each ledger AND its run's config.json, so a venue, symbol or mode flip re-parses."""
    rows = []
    for path in paths:
        for member in (path, path.parent / "config.json"):
            try:
                info = os.lstat(member)
                rows.append((str(member), info.st_size, info.st_mtime_ns))
            except FileNotFoundError:
                rows.append((str(member), -1, -1))
    return hashlib.sha256(repr(rows).encode("utf-8")).hexdigest()


class T2Refresher:
    """Keeps one book's parent history current off the event loop.

    Contract: one daemon thread per book (start/stop). refresh_once never raises: any failure,
    including one unreadable in-scope run, publishes an error snapshot, which is never fresh. It
    runs at most once per REFRESH_INTERVAL_NS of the injected clock (integer wall nanoseconds);
    it re-parses only when the ledger-and-config signature changed or the last snapshot carried
    an error (an error is never re-stamped), and otherwise re-stamps the same decisions. A
    snapshot is published by one reference assignment, so a reader on the book's loop takes
    self.snapshot and fresh(now_ns) and never parses a ledger itself. fresh(now_ns) is False for
    an error snapshot, one never computed, one older than STALE_AFTER_NS, or once stop() was
    called. stop() joins the thread within STOP_JOIN_S; a refresh still running after that
    (an orphaned thread) publishes nothing.

    Budget: one full refresh at the reader's bounds (4 MiB, 20000 rows) is modeled at 500 ms
    p95 on the refresher thread. Measured 2026-09-28 (dev host, 5 runs): KalshiBook-shaped rows,
    byte-bound, p50 285-400 ms p95 315-615 ms; minimal rows, row-bound (10000 trades), p50
    0.9-1.5 s p95 up to 2.2 s under host load, which is over the 500 ms model.
    tests/test_calibrated_stake_history.py test_lane_history_refresh_budget prints both and
    holds a 2.0 s CI ceiling."""

    def __init__(self, paths_fn, venue, symbol, clock):
        if not callable(paths_fn) or not callable(clock):
            raise TypeError("paths_fn and clock must be callable")
        if type(venue) is not str or type(symbol) is not str:
            raise ValueError("venue and symbol must be strings")
        self._paths_fn = paths_fn
        self._venue = venue
        self._symbol = symbol
        self._clock = clock
        self._snapshot = _UNCOMPUTED
        self._last_attempt_ns = None
        self._lock = threading.Lock()  # one refresh at a time; readers never take it
        self._publish_lock = threading.Lock()  # makes "not stopped, then publish" atomic with stop()
        self._stop = threading.Event()
        self._thread = None

    @property
    def snapshot(self):
        return self._snapshot

    def refresh_once(self):
        with self._lock:
            if self._stop.is_set():
                return self._snapshot  # a stopped refresher computes and publishes nothing
            now = 0
            try:
                now = self._clock()
                if type(now) is not int:
                    raise TypeError("clock must return integer nanoseconds")
                last = self._last_attempt_ns
                if last is not None and 0 <= now - last < REFRESH_INTERVAL_NS:
                    return self._snapshot
                self._last_attempt_ns = now
                paths = _select(self._paths_fn(), HISTORY_MAX_FILES)
                digest = _signature(paths)
                current = self._snapshot
                if current.error is None and current.source_digest == digest:
                    snapshot = T2Snapshot(current.decisions, now, None, digest)  # re-stamp, no re-parse
                else:
                    decisions, error = _lane_history(paths, self._venue, self._symbol)
                    snapshot = (_error_snapshot(now, error) if error is not None else
                                T2Snapshot(MappingProxyType(dict(decisions)), now, None, digest))
            except Exception as exc:  # RecursionError included
                snapshot = _error_snapshot(now, f"{type(exc).__name__}: {exc}")
            with self._publish_lock:
                if self._stop.is_set():
                    return self._snapshot  # stop() won: an orphaned refresh publishes nothing
                self._snapshot = snapshot
            return snapshot

    def fresh(self, now_ns):
        snapshot = self._snapshot
        if self._stop.is_set() or snapshot.error is not None or type(now_ns) is not int \
                or snapshot.computed_wall_ns <= 0:
            return False
        return -CLOCK_SKEW_NS <= now_ns - snapshot.computed_wall_ns <= STALE_AFTER_NS

    def start(self):
        if self._thread is not None:
            raise RuntimeError("T2Refresher already started")
        self._thread = threading.Thread(target=self._run, name=f"t2cal-refresh-{self._symbol}",
                                        daemon=True)
        self._thread.start()

    def _run(self):
        while not self._stop.is_set():
            self.refresh_once()
            self._stop.wait(REFRESH_POLL_S)

    def stop(self):
        """Signals the thread and joins it for at most STOP_JOIN_S; True when it has ended. From
        here on nothing is published and fresh() is False, even if the join timed out."""
        with self._publish_lock:
            self._stop.set()
        thread = self._thread
        if thread is not None:
            thread.join(STOP_JOIN_S)
        return thread is None or not thread.is_alive()


def admits(decisions, parent_id, price_cents, balance_cents, worst_debit_cents):
    """(True, "ok") only when parent_id's cell at the entry price's bucket reads "ok" with a
    positive fraction and floor(fraction * balance_cents) >= worst_debit_cents (the leg's whole
    worst-case debit fits inside the parent's calibrated stake). Otherwise (False, reason): the
    Decision's own reason, "stake_below_leg", or "invalid_input" for any non-int money input,
    a price outside 1..99, a non-positive balance or debit, or a malformed decisions/parent_id
    (including a mapping whose lookup raises or whose value is not a Decision). Never raises."""
    for value in (price_cents, balance_cents, worst_debit_cents):
        if type(value) is not int:
            return False, "invalid_input"
    if not 1 <= price_cents <= 99 or balance_cents <= 0 or worst_debit_cents <= 0:
        return False, "invalid_input"
    if type(parent_id) is not str or not parent_id or not isinstance(decisions, Mapping):
        return False, "invalid_input"
    try:  # a malformed mapping (a raising lookup, a non-Decision value) refuses, never raises
        decision = fraction_for(decisions, parent_id, price_cents / 100)
        if type(decision) is not Decision or type(decision.reason) is not str \
                or decision.reason not in REASONS:
            return False, "invalid_input"
    except Exception:
        return False, "invalid_input"
    if decision.reason != "ok":
        return False, decision.reason
    fraction = decision.fraction
    if isinstance(fraction, bool) or not isinstance(fraction, (int, float)) \
            or not math.isfinite(fraction) or fraction <= 0:
        return False, "stake_below_leg"
    if math.floor(Decimal(float(fraction)) * balance_cents) < worst_debit_cents:
        return False, "stake_below_leg"
    return True, "ok"
