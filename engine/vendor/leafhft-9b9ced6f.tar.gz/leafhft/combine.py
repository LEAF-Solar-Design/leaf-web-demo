"""COMBINE-S1: agreeing co-hosted probes become ONE combined, confidence-scaled venue order.

Pure: no I/O, no clock, no Decimal and no float on the plan and split path. Every count is an
integer number of 0.01-contract units (UNITS_PER_CONTRACT per contract) and every money figure is
integer cents, so plan plus split at 8 legs holds p99 <= 25 us (tests/test_combine.py measures it).

Legs are always passed in PRECEDENCE order (the lowest engine code, then client id); index 0 is the
anchor, whose client id is the wire client id. Every tie in every largest-remainder step goes to the
earlier leg, so the result is deterministic in the inputs alone.

  m(n) = min(1 + 0.5 (n - 1), M_MAX), M_MAX from config (default 2.0), hard-clamped to 3.0 here.
  t_i  = floor(b_i * m) on the plan grid (whole contracts for S1's whole-contract probes), clamped by
         the leg's own cap, never below its base b_i.
  C    = min(sum t_i, total cap, MAX_COMBINED_CONTRACTS); an excess is cut from the top-ups pro rata
         first, then from the bases pro rata, both by largest remainder.
Split of one venue fill: units level by level pro rata to target (never past a leg's target),
contract cost by the value each leg took, the venue fee by units, all by largest remainder; a cent
that would put a leg above its worst case moves to an earlier leg with room first.
"""
from __future__ import annotations

from decimal import Decimal

UNITS_PER_CONTRACT = 100
M_MAX_DEFAULT_X100 = 200  # M_MAX = 2.00, in hundredths
M_CEILING_X100 = 300  # the hard code ceiling on M_MAX, 3.00; no config can exceed it
MAX_COMBINED_CONTRACTS = 1000
MAX_COMBINED_UNITS = MAX_COMBINED_CONTRACTS * UNITS_PER_CONTRACT
MAX_LEGS = 64  # a group is at most the book's hosted probes; a larger one is refused whole
MAX_LEVELS = 256
RECEIPT_SCHEMA = "leafhft.combine.v1"


# ------------------------------------------------------------------------- units
def units_of(count) -> int:
    """A count (int, Decimal or decimal string) as 0.01-contract units; ValueError off the grid."""
    if type(count) is int:
        if count < 0:
            raise ValueError("count must be nonnegative")
        return count * UNITS_PER_CONTRACT
    if not isinstance(count, (Decimal, str)):
        raise ValueError("count must be int, Decimal or a decimal string")
    value = Decimal(count) * UNITS_PER_CONTRACT
    if not value.is_finite() or value < 0 or value != value.to_integral_value():
        raise ValueError("count must be nonnegative on the 0.01 grid")
    return int(value)


def count_text(units: int) -> str:
    """Units as the authority's canonical two-decimal count string ("1.50")."""
    if type(units) is not int or units < 0:
        raise ValueError("units must be a nonnegative int")
    return f"{units // UNITS_PER_CONTRACT}.{units % UNITS_PER_CONTRACT:02d}"


def count_value(units: int):
    """Units as a book count: an int for whole contracts (today's integer path), else a Decimal."""
    if units % UNITS_PER_CONTRACT == 0:
        return units // UNITS_PER_CONTRACT
    return Decimal(count_text(units))


def worst_cents(units: int, limit_cents: int, fee_cents: int) -> int:
    """The authority's worst-case debit of `units` at a limit and a per-contract fee: the ceiling
    of the contract cost plus the ceiling of the total fee (KalshiAuthority.claim's arithmetic)."""
    return (units * limit_cents + 99) // 100 + (units * fee_cents + 99) // 100


def units_for_room(room_cents: int, limit_cents: int, fee_cents: int) -> int:
    """The most units whose worst_cents fits in room_cents (0 for no room). O(1)."""
    per = limit_cents + fee_cents
    if type(room_cents) is not int or room_cents <= 0 or per <= 0:
        return 0
    units = min(room_cents * 100 // per, MAX_COMBINED_UNITS)
    while units and worst_cents(units, limit_cents, fee_cents) > room_cents:
        units -= 1
    return units


# -------------------------------------------------------------------- multiplier
def m_max_x100(value) -> int:
    """M_MAX from config text ("2.0", "2.5") in hundredths, clamped to 1.00..3.00; anything
    unreadable is the default 2.00. Never raises."""
    if value is None or value == "":
        return M_MAX_DEFAULT_X100
    try:
        number = Decimal(str(value)) * 100
    except (ArithmeticError, ValueError):
        return M_MAX_DEFAULT_X100
    if not number.is_finite():
        return M_MAX_DEFAULT_X100
    return max(100, min(M_CEILING_X100, int(number)))


def multiplier_x100(n: int, m_max: int = M_MAX_DEFAULT_X100) -> int:
    """m(n) = min(1 + 0.5 (n - 1), M_MAX) in hundredths; M_MAX is hard-clamped to 3.00 here."""
    if type(n) is not int or n < 1:
        raise ValueError("n must be a positive int")
    cap = m_max if type(m_max) is int and m_max >= 100 else M_MAX_DEFAULT_X100
    if cap > M_CEILING_X100:
        cap = M_CEILING_X100
    m = 100 + 50 * (n - 1)
    return m if m < cap else cap


# ------------------------------------------------------------------------ apportion
def _apportion(amount: int, weights, weight_sum: int) -> list:
    """`amount` split pro rata to `weights` by largest remainder, ties to the earlier index. The
    shares sum to amount, and when amount <= weight_sum no share exceeds its weight."""
    shares, rems = [], []
    for weight in weights:
        q, r = divmod(amount * weight, weight_sum)
        shares.append(q)
        rems.append(r)
    left = amount - sum(shares)
    if left:
        # reverse=True keeps equal remainders in index order (Python's sort is stable either way).
        for index in sorted(range(len(rems)), key=rems.__getitem__, reverse=True)[:left]:
            shares[index] += 1
    return shares


# --------------------------------------------------------------------------- plan
def plan_group(bases, caps, m_x100: int, total_cap_units: int, grid: int = 1) -> list:
    """Each leg's final target in units, in precedence order; the sum is C.

    bases[i] is the leg's own admitted count and caps[i] its own clamp (breaker rooms, its book's
    headroom, its raised exposure reservation); a leg whose clamp is below its base keeps its base.
    total_cap_units is the group clamp (the anchor book's room, the authority's total room, the
    account breaker); C never exceeds it or MAX_COMBINED_UNITS. grid: every target (so C) is a
    multiple of `grid` units; UNITS_PER_CONTRACT keeps whole-contract probes on whole-contract
    orders (every clamp is floored to the grid). Raises ValueError on bad input."""
    if grid != 1:
        if type(grid) is not int or grid < 1 or any(type(b) is not int or b <= 0 or b % grid for b in bases):
            raise ValueError("grid must be a positive int and every base a multiple of it")
        limit = total_cap_units if type(total_cap_units) is int else 0
        limit = max(0, min(limit, MAX_COMBINED_UNITS))
        scaled = plan_group([b // grid for b in bases], [c // grid if type(c) is int else c for c in caps],
                            m_x100, limit // grid)
        return [target * grid for target in scaled]
    count = len(bases)
    if not 1 <= count <= MAX_LEGS or len(caps) != count:
        raise ValueError("plan needs 1..MAX_LEGS legs with one cap each")
    if type(m_x100) is not int or not 100 <= m_x100 <= M_CEILING_X100:
        raise ValueError("multiplier out of range")
    targets = []
    base_sum = 0
    for index in range(count):
        base, cap = bases[index], caps[index]
        if type(base) is not int or base <= 0 or type(cap) is not int:
            raise ValueError("bases must be positive int units and caps int units")
        target = base * m_x100 // 100
        if target > cap:
            target = cap
        if target < base:
            target = base
        targets.append(target)
        base_sum += base
    total = sum(targets)
    limit = total_cap_units if type(total_cap_units) is int else 0
    if limit > MAX_COMBINED_UNITS:
        limit = MAX_COMBINED_UNITS
    if limit < 0:
        limit = 0
    if total <= limit:
        return targets
    excess = total - limit
    top_sum = total - base_sum
    if top_sum:
        cut = excess if excess < top_sum else top_sum
        tops = [targets[i] - bases[i] for i in range(count)]
        for index, share in enumerate(_apportion(cut, tops, top_sum)):
            targets[index] -= share
        excess -= cut
    if excess:  # every top-up is gone: the bases themselves are cut
        for index, share in enumerate(_apportion(excess, bases, base_sum)):
            targets[index] -= share
    return targets


# -------------------------------------------------------------------------- split
def _fill_level(amount: int, targets, room) -> list:
    """One level's units pro rata to target, never past a leg's remaining room; largest remainder."""
    count = len(targets)
    shares = [0] * count
    active = [i for i in range(count) if room[i] > 0]
    while amount and active:
        weights = [targets[i] for i in active]
        weight_sum = sum(weights)
        parts = _apportion(amount, weights, weight_sum) if weight_sum >= amount else None
        if parts is None:  # never on valid input (amount <= sum room <= sum targets)
            raise ValueError("fill exceeds the group's targets")
        amount = 0
        still = []
        for index, part in zip(active, parts):
            free = room[index] - shares[index]
            if part >= free:
                shares[index] += free
                amount += part - free
            else:
                shares[index] += part
                still.append(index)
        active = still
    if amount:
        raise ValueError("fill exceeds the group's targets")
    return shares


def split_fill(targets, levels, contract_cost_cents: int, fee_cents: int, worst, grid: int = 1) -> tuple:
    """(units, costs, fees) per leg of one venue fill, precedence order; each cost includes its fee.

    levels: [(units, price_cents)] in venue fill order; their units sum to the venue fill.
    contract_cost_cents and fee_cents are the venue's; each leg's cost includes its fee share.
    worst[i] is the leg's worst-case debit; a remainder cent that would breach it is relocated to
    the earliest leg that holds units and has room. grid: every leg's units are a multiple of
    `grid`; UNITS_PER_CONTRACT splits a whole-contract order's fill in whole contracts only (largest
    remainder, ties to the earlier leg), so a leg never holds a fractional share of it and a leg may
    hold zero. Raises ValueError on inconsistent input, on a fill or target off the grid (a fractional
    fill of a whole-contract order cannot be split without a fractional share: the caller fails
    closed), or when no leg has room for a cent (the caller latches: the invariants cannot hold)."""
    if grid != 1:
        # Costs go by value and fees by units, both proportional under the scaling, so the scaled
        # split's costs and fees are exactly the whole-grid split's.
        if (type(grid) is not int or grid < 1 or any(type(t) is not int or t % grid for t in targets)
                or any(type(level[0]) is not int or level[0] % grid for level in levels)):
            raise ValueError("grid must be a positive int and every target and level on it")
        units, costs, fees = split_fill([t // grid for t in targets], [(u // grid, p) for u, p in levels],
                                        contract_cost_cents, fee_cents, worst)
        return [share * grid for share in units], costs, fees
    count = len(targets)
    if not 1 <= count <= MAX_LEGS or len(worst) != count or len(levels) > MAX_LEVELS:
        raise ValueError("split needs 1..MAX_LEGS legs, one worst each, bounded levels")
    if type(contract_cost_cents) is not int or type(fee_cents) is not int or contract_cost_cents < 0 or fee_cents < 0:
        raise ValueError("venue cost and fee must be nonnegative int cents")
    units = value = None
    target_sum = sum(targets)
    for level_units, price in levels:
        if type(level_units) is not int or level_units < 0 or type(price) is not int or not 0 <= price <= 100:
            raise ValueError("level must be (units >= 0, price 0..100)")
        if not level_units:
            continue
        if units is None:  # the first level: every leg's room is its whole target, so nothing caps
            if level_units > target_sum:
                raise ValueError("fill exceeds the group's targets")
            units = _apportion(level_units, targets, target_sum)
            value = [share * price for share in units]
            continue
        shares = _fill_level(level_units, targets, [targets[i] - units[i] for i in range(count)])
        for index in range(count):
            share = shares[index]
            if share:
                units[index] += share
                value[index] += share * price
    if units is None:
        units, value = [0] * count, [0] * count
    filled = sum(units)
    if not filled:
        if contract_cost_cents or fee_cents:
            raise ValueError("a zero fill cannot carry cost")
        return units, [0] * count, [0] * count
    value_sum = sum(value)
    if value_sum:
        costs = _apportion(contract_cost_cents, value, value_sum)
    elif contract_cost_cents:
        costs = _apportion(contract_cost_cents, units, filled)  # every level at price 0: by units
    else:
        costs = [0] * count
    fees = _apportion(fee_cents, units, filled)
    for index in range(count):
        costs[index] += fees[index]
    if relocate(units, costs, worst):
        raise ValueError("no leg has room for the venue cost")
    for index in range(count):  # a relocated cent is contract cost: a leg's fee never exceeds its cost
        if fees[index] > costs[index]:
            fees[index] = costs[index]
    return units, costs, fees


def relocate(units, costs, worst) -> int:
    """In place: every cent above a leg's worst moves to the earliest leg holding units with room.
    Returns the cents that found no room (0 when every leg holds)."""
    excess = 0
    for index in range(len(costs)):
        over = costs[index] - worst[index]
        if over > 0:
            costs[index] -= over
            excess += over
    if not excess:
        return 0
    for index in range(len(costs)):
        if units[index]:
            room = worst[index] - costs[index]
            if room > 0:
                moved = room if room < excess else excess
                costs[index] += moved
                excess -= moved
                if not excess:
                    return 0
    return excess  # the costs now sum short of the venue cost; check_invariants names it cost_sum


def check_invariants(targets, units, costs, worst, venue_units: int, venue_cost_cents: int) -> list:
    """The breaches of one split, checked before any write; [] when it holds. Sums exact, every
    leg within its target and its worst case, and no leg carries cost without units."""
    breaches = []
    if sum(units) != venue_units:
        breaches.append("units_sum")
    if sum(costs) != venue_cost_cents:
        breaches.append("cost_sum")
    for index in range(len(targets)):
        if not 0 <= units[index] <= targets[index]:
            breaches.append(f"leg{index}_units")
        if not 0 <= costs[index] <= worst[index]:
            breaches.append(f"leg{index}_cost")
        if not units[index] and costs[index]:
            breaches.append(f"leg{index}_cost_without_fill")
    return breaches


# ------------------------------------------------------------------------ receipt
def receipt(*, wire_cid, ticker, side_yes, close_ms, limit_cents, n, m_x100, legs, targets, worst,
            units, costs, venue_units, venue_cost_cents, venue_fee_cents, outcome, at_ms) -> dict:
    """The leafhft.combine.v1 receipt of one group: legs, n, m, targets, venue numbers, sums."""
    return {
        "schema": RECEIPT_SCHEMA, "wire_client_id": wire_cid, "ticker": ticker, "side_yes": side_yes,
        "close_ms": close_ms, "limit_cents": limit_cents, "n": n, "m": count_text(m_x100),
        "outcome": outcome, "at_ms": at_ms,
        "legs": [{"client_id": leg[0], "engine_id": leg[1], "base": count_text(leg[2]),
                  "target": count_text(targets[i]), "worst_cents": worst[i],
                  "filled": None if units is None else count_text(units[i]),
                  "cost_cents": None if costs is None else costs[i], "combined": True}
                 for i, leg in enumerate(legs)],
        "count": count_text(sum(targets)),
        "venue": {"filled": None if venue_units is None else count_text(venue_units),
                  "cost_cents": venue_cost_cents, "fee_cents": venue_fee_cents},
        "sums": {"filled": None if units is None else count_text(sum(units)),
                 "cost_cents": None if costs is None else sum(costs)},
    }
