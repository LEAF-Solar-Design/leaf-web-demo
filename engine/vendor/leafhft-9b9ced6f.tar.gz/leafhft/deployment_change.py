"""Closed deployment requests and deterministic, document-only v2 derivation.

The request contains intent only. Catalog bytes, before-values and all derived
fields come from the caller's trusted inputs; this module grants no authority.
"""
from __future__ import annotations

import base64
import hashlib
import json
import re

from . import tuning_plan_v2 as v2


class ChangeRefused(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def _require(condition, code="change_grammar"):
    if not condition:
        raise ChangeRefused(code)


def _match(value, pattern):
    return type(value) is str and re.fullmatch(pattern, value) is not None


def _closed(value, fields):
    _require(type(value) is dict and set(value) == set(fields.split()))


def decode_change(raw: bytes) -> dict:
    """Parse exact submitted bytes with the server's JSON and ASCII rules."""
    _require(type(raw) is bytes, "invalid_json")
    _require(len(raw) <= v2.MAX_PLAN_BYTES, "plan_too_large")
    try:
        change = v2._json(raw)
    except v2.PlanV2Error:
        raise ChangeRefused("invalid_json") from None
    _require(type(change) is dict)
    _require("migration" not in change, "migration_deferred_p3")
    _require(change.get("origin") != "tuner", "tuner_deferred")
    _require(set(change) <= {"account", "origin", "items", "controls"})
    if "account" in change:
        _require(_match(change["account"], r"[0-9a-f]{8}"))
    if "origin" in change:
        _require(change["origin"] == "operator")
    items, controls = change.get("items", []), change.get("controls", [])
    _require(type(items) is list and len(items) <= 64)
    _require(type(controls) is list and len(controls) <= 15)
    deploys, creates, control_keys = set(), set(), set()
    for item in items:
        _require(type(item) is dict)
        if item.get("kind") == "create":
            _closed(item, "kind engine parent set summary")
            _require(_match(item["engine"], r"[A-Za-z0-9][A-Za-z0-9._:-]{0,31}"))
            _require(_match(item["parent"], v2._ID))
            _require(type(item["set"]) is dict)
            for key, value in item["set"].items():
                _require(_match(key, r"[A-Za-z_][A-Za-z0-9_]{0,127}") and
                         type(value) in (str, int, bool))
            _require(type(item["summary"]) is str and 1 <= len(item["summary"]) <= 300)
            _require(item["engine"] not in creates)
            creates.add(item["engine"])
        else:
            _closed(item, "kind book engine to")
            _require(item["kind"] == "deploy" and type(item["book"]) is str and
                     item["book"] in v2.BOOKS and _match(item["engine"], v2._ID))
            _closed(item["to"], "leverage on")
            _require(type(item["to"]["leverage"]) is int and
                     item["to"]["leverage"] in v2.LEVERAGES and type(item["to"]["on"]) is bool)
            key = item["book"], item["engine"]
            _require(key not in deploys)
            deploys.add(key)
    for control in controls:
        _require(type(control) is dict)
        if control.get("scope") == "account":
            _closed(control, "kind scope field to")
            _require(control["field"] == "paused")
        else:
            _closed(control, "kind scope book field to")
            _require(control["scope"] == "book" and control["field"] == "book_off" and
                     type(control["book"]) is str and control["book"] in v2.BOOKS)
        _require(control["kind"] == "control" and type(control["to"]) is bool)
        key = control["scope"], control.get("book", ""), control["field"]
        _require(key not in control_keys)
        control_keys.add(key)
    return change


def catalog_reader(catalog_dir, legacy_engines_dir):
    """Return exact policy bytes (or None), using the writer's safe-read paths."""
    from .deployments import _legacy_policy, _read

    def lookup(engine):
        _require(_match(engine, v2._ID))
        raw = _read(catalog_dir, engine + ".json", limit=v2.MAX_POLICY_BYTES, optional=True)
        if raw is None:
            raw = _read(legacy_engines_dir, engine + ".json", limit=v2.MAX_POLICY_BYTES,
                        optional=True, legacy=True)
            if raw is not None:
                raw = _legacy_policy(raw, engine)
        return raw

    return lookup


def derive(change, document, catalog_lookup, envelope_doc, sizing_basis, claim, freeze) -> dict:
    """Build a plan; lookup returns trusted policy bytes or None for absence.

    claim supplies proposal/account/sequence/cycle/change/origin. freeze supplies
    runner_host, code_sha, runner_nonce and frozen_at_ms. No clocks or random
    values are read here, so the writer can reproduce the signed transitions.
    """
    from .deployments import decode_document, project_baseline

    change = decode_change(v2.canonical_bytes(change))
    document = decode_document(v2.canonical_bytes(document))
    _require(claim["cycle_kind"] != "migration", "migration_deferred_p3")
    _require(claim["cycle_kind"] == "deployment_change")
    _require(claim["origin"] != "tuner", "tuner_deferred")
    _require(claim["origin"] == "operator")
    _require(claim["account"] == document["account"] == change.get("account", claim["account"]),
             "account_mismatch")
    _require(change.get("origin", claim["origin"]) == claim["origin"])
    requested_items, requested_controls = change.get("items", []), change.get("controls", [])
    books = {i["book"] for i in requested_items if i["kind"] == "deploy"}
    books.update(c["book"] for c in requested_controls if c["scope"] == "book")
    if any(c["scope"] == "account" for c in requested_controls):
        books = set(v2.BOOKS)
    baseline = project_baseline(document, books)
    rows = {(r["book"], r["engine"]): r for r in baseline["rows"]}
    desired_catalog = {e["engine_id"]: e["policy_sha256"] for e in document["catalog"]}
    policies, catalog, created = {}, {}, {}

    def existing(engine):
        if engine not in policies:
            raw = catalog_lookup(engine)
            _require(type(raw) is bytes, "dangling_reference")
            _require(len(raw) <= v2.MAX_POLICY_BYTES, "plan_too_large")
            digest = hashlib.sha256(raw).hexdigest()
            _require(desired_catalog.get(engine, digest) == digest, "immutable_engine")
            policies[engine], catalog[engine] = raw, digest
        return policies[engine], catalog[engine]

    for row in baseline["rows"]:
        existing(row["engine"])
    creates = [i for i in requested_items if i["kind"] == "create"]
    create_ids = {i["engine"] for i in creates}
    items = []
    for item in sorted(creates, key=lambda i: i["engine"]):
        engine = item["engine"]
        _require(engine not in desired_catalog and catalog_lookup(engine) is None and
                 item["parent"] not in create_ids, "immutable_engine")
        parent, parent_digest = existing(item["parent"])
        from .engine_ops import resolve_variant_policy
        try:
            raw = resolve_variant_policy(json.loads(parent), item["set"])
        except (ValueError, TypeError, KeyError, OverflowError, RecursionError):
            raise ChangeRefused("create_policy_mismatch") from None
        digest = hashlib.sha256(raw).hexdigest()
        created[engine] = digest
        items.append(dict(item, parent_policy_digest=parent_digest,
                          policy_bytes=base64.b64encode(raw).decode("ascii"), policy_digest=digest))
    deploys = [i for i in requested_items if i["kind"] == "deploy"]
    for item in sorted(deploys, key=lambda i: (i["book"], i["engine"])):
        engine = item["engine"]
        digest = created[engine] if engine in created else existing(engine)[1]
        old = rows.get((item["book"], engine))
        before = dict(leverage=old["leverage"], on=old["on"]) if old else None
        items.append(dict(item, engine_policy_digest=digest, **{"from": before}))
    controls = []
    for control in sorted(requested_controls,
                          key=lambda c: (c["scope"], c.get("book", ""), c["field"])):
        before = (document["paused"] if control["scope"] == "account" else
                  control["book"] in document["books_off"])
        controls.append(dict(control, book=control.get("book"), **{"from": before}))
    plan = {k: claim[k] for k in ("proposal_id", "account", "plan_seq", "cycle_kind",
                                  "cycle_id", "change_sha256", "origin")}
    plan.update({k: freeze[k] for k in ("runner_host", "code_sha", "runner_nonce", "frozen_at_ms")})
    plan.update(schema="leafhft.tuning-plan.v2", registry_account="owner", kind="change",
                expires_at_ms=freeze["frozen_at_ms"] + 86400000,
                expected_generation=document["generation"], resulting_generation=document["generation"] + 1,
                baseline=baseline, controls=controls, items=items,
                catalog=[dict(engine=e, engine_policy_digest=catalog[e]) for e in sorted(catalog)],
                envelope=dict(version=1, digest=v2.envelope_digest(envelope_doc), document=envelope_doc),
                sizing_basis=dict(sizing_basis), migration=None, effects=[], tuner_evidence=[])
    plan["effects"] = v2.compute_effects(plan)
    return v2.decode_plan_v2(v2.canonical_bytes(plan))
