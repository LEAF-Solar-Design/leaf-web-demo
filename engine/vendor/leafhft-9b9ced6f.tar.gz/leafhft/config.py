"""Engine configuration: frozen, range-checked, and the only place live mode can be named."""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from typing import Any
from pathlib import Path

from .types import QUOTE_UNIT, to_quote_q

VENUES = ("coinbase", "kraken", "binanceus", "kalshi", "kalshi-perp", "polymarket_us")
# leafhft/broker/kalshi_book.py:KALSHI_LIMITS_PROFILES must stay a subset of this tuple; enforced by tests/test_kalshi_live.py.
LIMITS_PROFILES = ("default", "conservative", "s2c", "aggressive", "kalshi-experiment", "kalshi-week2", "kalshi-sleeve", "kalshi-sleeve-fast", "kalshi-experiment-5x", "kalshi-house-money", "kalshi-favorites-5x")
MODES = ("paper", "replay", "live")


def paper_fuzz_config(options: dict[str, Any], *, mode: str):
    """Separate from live authorization and EngineConfig's legacy digest."""
    from .sim.fuzz import FuzzConfig, require_paper_environment

    require_paper_environment(mode)
    return FuzzConfig(**options)

# Order sizing, gates, routing and policy selection are the authorization surface.
_AUTHORIZED_FIELDS = (
    "venue", "symbol", "strategy", "mode", "starting_cash_q", "goal_q",
    "strategy_params", "risk", "residual_policy", "limits_profile",
    "reference_venue", "alternate_strategy", "block_minutes", "policy_path",
    "engines_dir", "engine_bindings", "engine_account_overrides", "dashboard_account_identity",
    "policy_bounds_digest", "execution_experiment_path",
    "authority_path", "authority_generation", "darkhorse_config_path", "darkhorse_model_shas",
    "lane_documents", "lane_digests", "coordinated_mode", "cohort_digest",
    "lifecycle_dir", "probe_bindings", "engine_registry", "execution_domain",
    "classification_mode",
    "hot_observation_mode",
    "parity_mirror",
    "executor_mode",
)
# Values EngineConfig.classification_mode accepts; "" is legacy and never enters the digest.
CLASSIFICATION_MODES = ("", "ticker")
# Environment fallbacks for the three co-hosting paths (C7b); `leafhft live` reads them only when
# the flag is absent, so a book whose argv and environment name none keeps its digest.
PROBE_BINDINGS_ENV = "LEAFHFT_PROBE_BINDINGS"
ENGINE_REGISTRY_ENV = "LEAFHFT_ENGINE_REGISTRY"
EXECUTION_DOMAIN_ENV = "LEAFHFT_EXECUTION_DOMAIN"
_EXECUTION_DOMAIN_RE = re.compile(r"legacy-owner|account-lane:[a-z0-9][a-z0-9-]{0,63}")
_EXCLUDED_FIELDS = (
    "paper", "ledger_path", "record_path", "replay_path", "run_seconds",
    "mark_interval_ms", "max_ticks",
    "shadow_policy_path", "shadow_cash_q",
    "lane_problems",
)


def _probe_hosting_inactive(path, symbol) -> bool:
    """True only when the bindings file loads CLEANLY and binds no probe engine to symbol (one
    bounded read, 64 KiB). A file that cannot be read or parsed keeps its fields, so a transient
    read failure never moves an already authorized probe host's digest; that host then hosts no
    probe and says why."""
    from .probe_bindings import load_probe_bindings

    bindings = load_probe_bindings(Path(path))
    return not bindings.errors and not bindings.engines_for(symbol)


def _darkhorse_read(path, limit=1024 * 1024):
    with Path(path).open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError("Dark Horse file exceeds size limit")
    return data


def load_darkhorse_config(path):
    """Strict, bounded config read. Only the three sizing/arming fields are hot."""
    from datetime import date
    from decimal import Decimal

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate Dark Horse config key")
            result[key] = value
        return result

    raw = json.loads(_darkhorse_read(path, 16384), object_pairs_hook=pairs)
    keys = {"armed", "base_count", "max_mult", "models", "max_filled_tickets", "pilot_start", "pilot_days"}
    if not isinstance(raw, dict) or set(raw) != keys:
        raise ValueError("invalid Dark Horse config keys")
    if type(raw["armed"]) is not int or raw["armed"] not in (0, 1):
        raise ValueError("Dark Horse armed must be 0 or 1")
    for key, ceiling in (("base_count", Decimal("0.50")), ("max_mult", Decimal("10"))):
        value = raw[key]
        if not isinstance(value, str) or not re.fullmatch(r"[0-9]{1,3}(?:\.[0-9]{1,2})?", value):
            raise ValueError("invalid Dark Horse " + key)
        if not 0 < Decimal(value) <= ceiling or (key == "max_mult" and Decimal(value) < 1):
            raise ValueError("Dark Horse sizing exceeds pilot bounds")
    for key, ceiling in (("max_filled_tickets", 500), ("pilot_days", 60)):
        if type(raw[key]) is not int or not 1 <= raw[key] <= ceiling:
            raise ValueError("invalid Dark Horse " + key)
    if not isinstance(raw["pilot_start"], str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw["pilot_start"]):
        raise ValueError("invalid Dark Horse pilot_start")
    date.fromisoformat(raw["pilot_start"])
    models = raw["models"]
    if (not isinstance(models, list) or len(models) != 2 or
            any(not isinstance(p, str) or not p or len(p) > 4096 or not Path(p).is_absolute() for p in models)
            or len(set(models)) != 2):
        raise ValueError("Dark Horse requires two distinct absolute model paths")
    return raw


def darkhorse_model_shas(path):
    """Invalid optional configuration must refuse its lane, never the engine config."""
    try:
        raw = load_darkhorse_config(path)
        return tuple(hashlib.sha256(_darkhorse_read(p)).hexdigest() for p in raw["models"])
    except (OSError, ValueError, TypeError):
        return ()


@dataclass(frozen=True, slots=True)
class RiskLimits:
    max_position_q: int = 100 * QUOTE_UNIT  # absolute notional cap, quote units
    max_order_q: int = 100 * QUOTE_UNIT  # per-order notional cap
    max_orders_per_min: int = 120
    max_open_orders: int = 4
    daily_loss_limit_q: int = 10 * QUOTE_UNIT  # stop for the day when realized+unrealized loss exceeds this
    drawdown_kill_bps: int = 1500  # kill switch when equity falls this far from its high-water mark
    price_band_bps: int = 200  # reject orders priced further than this from mid
    stale_feed_ms: int = 2000  # no orders when the quote is older than this (astra C8: 2 s initial policy)
    max_fills_per_min: int = 240

    @classmethod
    def conservative(cls) -> "RiskLimits":
        """Astra's round-1 live limits: $10 order, $25 inventory, halt at $2 daily loss / 5% drawdown."""
        return cls(
            max_position_q=25 * QUOTE_UNIT,
            max_order_q=10 * QUOTE_UNIT,
            max_orders_per_min=60,
            max_open_orders=2,
            daily_loss_limit_q=2 * QUOTE_UNIT,
            drawdown_kill_bps=500,
            price_band_bps=100,
            stale_feed_ms=2000,
            max_fills_per_min=120,
        )

    @classmethod
    def s2c(cls) -> "RiskLimits":
        """Conservative limits consumed by PLAN-STAGE2.md S2C."""
        return cls.conservative()

    @classmethod
    def aggressive(cls, stake_q: int) -> "RiskLimits":
        """Stake-scaled limits for the ramp: 10% order, 80% position, 5% daily loss, 1000 bps kill."""
        max_order_q = max(stake_q // 10, 2 * QUOTE_UNIT)
        max_position_q = max(stake_q * 80 // 100, max_order_q)
        daily_loss_limit_q = max(stake_q * 5 // 100, 1 * QUOTE_UNIT)
        return cls(
            max_position_q=max_position_q,
            max_order_q=max_order_q,
            max_orders_per_min=120,
            max_open_orders=2,
            daily_loss_limit_q=daily_loss_limit_q,
            drawdown_kill_bps=1000,
            price_band_bps=100,
            stale_feed_ms=2000,
            max_fills_per_min=120,
        )

    def __post_init__(self) -> None:
        if not (0 < self.max_position_q <= 10**6 * QUOTE_UNIT):
            raise ValueError("max_position_q out of range")
        if not (0 < self.max_order_q <= self.max_position_q):
            raise ValueError("max_order_q must be in (0, max_position_q]")
        if not (1 <= self.max_orders_per_min <= 6000):
            raise ValueError("max_orders_per_min out of range")
        if not (1 <= self.max_open_orders <= 64):
            raise ValueError("max_open_orders out of range")
        if not (0 < self.daily_loss_limit_q <= self.max_position_q):
            raise ValueError("daily_loss_limit_q out of range")
        if not (10 <= self.drawdown_kill_bps <= 10_000):
            raise ValueError("drawdown_kill_bps out of range")
        if not (1 <= self.price_band_bps <= 5000):
            raise ValueError("price_band_bps out of range")
        if not (100 <= self.stale_feed_ms <= 600_000):
            raise ValueError("stale_feed_ms out of range")
        if not (1 <= self.max_fills_per_min <= 10_000):
            raise ValueError("max_fills_per_min out of range")


@dataclass(frozen=True, slots=True)
class PaperModel:
    """How the paper broker fills. Conservative by construction."""

    latency_ms: int = 350  # order AND cancel arrival delay; measured REST round trip ~260 to 1100 ms
    taker_slippage_bps: int = 2  # market orders fill this much worse than the touch
    adverse_selection_bps: int = 1  # provisional maker haircut (astra C10); stress at 0/2/5, replace with measured markouts
    queue_model: str = "queue"  # "queue" (join behind resting size) or "touch" (optimistic)
    snapshot_fills: bool = False  # False: a crossed L1 snapshot is ambiguous, never a fill (astra r2 C3); True: fill capped by displayed size
    max_quote_age_ms: int = 2000  # taker orders arriving against a quote older than this are rejected, not filled

    def __post_init__(self) -> None:
        if not (0 <= self.latency_ms <= 10_000):
            raise ValueError("latency_ms out of range")
        if not (100 <= self.max_quote_age_ms <= 60_000):
            raise ValueError("max_quote_age_ms out of range")
        if not isinstance(self.snapshot_fills, bool):
            raise ValueError("snapshot_fills must be bool")
        if not (0 <= self.taker_slippage_bps <= 500):
            raise ValueError("taker_slippage_bps out of range")
        if not (0 <= self.adverse_selection_bps <= 500):
            raise ValueError("adverse_selection_bps out of range")
        if self.queue_model not in ("queue", "touch"):
            raise ValueError("queue_model must be 'queue' or 'touch'")


@dataclass(frozen=True, slots=True)
class EngineConfig:
    venue: str
    symbol: str
    strategy: str
    mode: str = "paper"
    starting_cash_q: int = 100 * QUOTE_UNIT
    goal_q: int = 1000 * QUOTE_UNIT
    strategy_params: dict[str, Any] = field(default_factory=dict)
    risk: RiskLimits = field(default_factory=RiskLimits)
    paper: PaperModel = field(default_factory=PaperModel)
    ledger_path: str = "runs/ledger.sqlite"
    record_path: str = ""  # JSONL tick capture; empty disables
    replay_path: str = ""  # JSONL ticks to replay in replay mode
    run_seconds: int = 0  # 0 = until interrupted
    mark_interval_ms: int = 1000
    max_ticks: int = 0  # 0 = unbounded (replay uses the file length)
    residual_policy: str = "hold"
    limits_profile: str = "default"
    reference_venue: str = ""
    alternate_strategy: str = ""
    block_minutes: int = 0
    policy_path: str = ""  # kalshi only: path to the hot-reloadable KalshiPolicy JSON file
    engines_dir: str = ""
    engine_bindings: str = ""
    engine_account_overrides: str = ""
    dashboard_account_identity: str = ""
    lifecycle_dir: str = ""  # probe lifecycle store; empty keeps <engines_dir>/lifecycle and the digest
    probe_bindings: str = ""  # probe engines per symbol (C7b); empty hosts no probe and keeps the digest
    engine_registry: str = ""  # registry projection the probes gate on; empty keeps the digest
    execution_domain: str = ""  # empty means legacy-owner at runtime, never stored and never digested
    # X3i: the KalshiLive exposure classification every book and probe client is built with. Empty
    # means "legacy": it is popped from the digest AND omitted from the written config.json
    # (cli._cfg_dict), so an unset book keeps its authorization and serializes exactly as before X3i;
    # "ticker" rotates the digest. Not hot. Set by argv only: `leafhft live --classification-mode
    # ticker` (default legacy). The two BTC books enable it through deploy/runner/live-run.sh (X5 and
    # later slices, Wave C); this field and the flag only make it possible. Rollback order: remove the
    # key (drop the flag; never blank it to "" in a stored config), take a fresh ack (acks are
    # one-shot), restart the book, and only then roll back the code, because older code builds
    # EngineConfig with cls(**d) and refuses the unknown key even when it is empty.
    classification_mode: str = ""
    # An on-mode config.json carries this key; pre-change code refuses unknown keys.
    # Rollback order: roll the feature back to off, take a fresh ack and restart books
    # before rolling back code, so the written config no longer carries the key.
    hot_observation_mode: str = "off"  # Off is omitted from the digest and written config.
    parity_mirror: bool = False  # C15: mirror the incumbent through KalshiEdgeEntry, no orders; off is popped from the digest
    executor_mode: bool = False  # C16c: probes share the incumbent's one KalshiLive client; off is popped from the digest
    execution_experiment_path: str = ""  # optional, reduction-only new-entry experiment
    authority_path: str = "/var/lib/leafhft/kalshi-authority.json"
    authority_generation: str = ""
    coordinated_mode: str = "off"
    cohort_digest: str = ""  # bound from the cohort freeze at construction, never supplied
    darkhorse_config_path: str = "/etc/leafhft/darkhorse.json"
    darkhorse_model_shas: tuple[str, ...] = ()
    lane_documents: tuple[str, ...] = ()
    lane_digests: tuple[str, ...] = ()
    lane_problems: tuple[tuple[str, str], ...] = ()
    policy_bounds_digest: str = ""  # digest of leafhft.policy.POLICY_BOUNDS at policy_path assignment time
    shadow_policy_path: str = ""  # kalshi only: path to a second, fenced paper-shadow KalshiPolicy JSON file
    shadow_cash_q: int = 0  # paper shadow's cash allocation, quote_q scaled; 0 when shadow_policy_path is empty

    def __post_init__(self) -> None:
        from .coordinated_cohort import FREEZE_PATH, OWNER_LANE, cached_freeze, owner_paths
        lane = Path(self.authority_path).parent.name
        if self.coordinated_mode not in ("off", "shadow", "live"):
            raise ValueError("invalid coordinated mode")
        if lane == OWNER_LANE and self.coordinated_mode != "off":
            raise ValueError("owner cannot receive coordinated intents")
        freeze = cached_freeze(FREEZE_PATH) if self.venue == "kalshi" else None
        if freeze is not None:
            if lane == OWNER_LANE or lane in freeze.testers:
                if self.cohort_digest and self.cohort_digest != freeze.digest:
                    raise ValueError("cohort freeze changed")
                object.__setattr__(self, "cohort_digest", freeze.digest)
                if lane == OWNER_LANE:
                    # A restarted owner runs only its exact materialized snapshot.
                    bindings, engines = owner_paths(freeze, FREEZE_PATH.parent)
                    object.__setattr__(self, "engine_bindings", bindings)
                    object.__setattr__(self, "engines_dir", engines)
            elif self.coordinated_mode != "off":
                raise ValueError("coordinated lane is outside the frozen cohort")
        elif self.cohort_digest:
            raise ValueError("cohort freeze unavailable")
        if self.coordinated_mode != "off":
            if (self.venue != "kalshi" or self.mode != "live" or self.strategy != "kalshi_edge"
                    or not self.dashboard_account_identity or not self.engine_account_overrides
                    or not self.cohort_digest):
                raise ValueError("coordinated entry requires a bound Kalshi account in the frozen cohort")
            from .feeds.kalshi import SYMBOL_MAP
            if self.symbol not in SYMBOL_MAP:
                raise ValueError("coordinated entry requires a canonical book")
        if self.venue not in VENUES:
            raise ValueError(f"venue must be one of {VENUES}")
        if not self.symbol or "/" in self.symbol or len(self.symbol) > 16:
            raise ValueError("symbol must look like BTC-USD")
        if self.mode not in MODES:
            raise ValueError(f"mode must be one of {MODES}")
        if self.alternate_strategy not in ("", "mm", "anchor_mm"):
            raise ValueError("alternate_strategy must be empty, 'mm' or 'anchor_mm'")
        if bool(self.alternate_strategy) != bool(self.block_minutes):
            raise ValueError("alternate_strategy and block_minutes must both be set or both empty")
        if self.block_minutes and not (5 <= self.block_minutes <= 1440):
            raise ValueError("block_minutes must be 0 or in [5, 1440]")
        if self.reference_venue not in ("", "coinbase"):
            raise ValueError("reference_venue must be empty or coinbase")
        if self.reference_venue:
            live_ok = self.mode == "live" and self.venue == "binanceus"
            paper_ok = self.mode == "paper" and self.strategy == "anchor_mm"
            if not (live_ok or paper_ok):
                raise ValueError("reference_venue requires paper anchor_mm or live binanceus")
        if self.strategy == "anchor_mm" and (
            self.mode != "paper" or self.venue != "binanceus" or self.symbol != "BTC-USD" or self.reference_venue != "coinbase"
        ):
            raise ValueError("anchor_mm requires paper binanceus with reference_venue coinbase")
        if self.residual_policy not in ("hold", "liquidate"):
            raise ValueError("residual_policy must be 'hold' or 'liquidate'")
        if self.mode == "live" and self.residual_policy == "liquidate":
            raise ValueError("live mode cannot liquidate residual positions")
        if self.limits_profile not in LIMITS_PROFILES:
            raise ValueError(f"limits_profile must be one of {LIMITS_PROFILES}")
        if self.limits_profile == "aggressive":
            object.__setattr__(self, "risk", RiskLimits.aggressive(self.starting_cash_q))
        elif self.limits_profile in ("conservative", "s2c"):
            object.__setattr__(self, "risk", getattr(RiskLimits, self.limits_profile)())
        if not (QUOTE_UNIT <= self.starting_cash_q <= 10**7 * QUOTE_UNIT):
            raise ValueError("starting_cash_q out of range")
        if self.goal_q <= self.starting_cash_q:
            raise ValueError("goal must exceed starting cash")
        if not (0 <= self.run_seconds <= 30 * 86_400):
            raise ValueError("run_seconds out of range")
        if not (100 <= self.mark_interval_ms <= 60_000):
            raise ValueError("mark_interval_ms out of range")
        if self.mode == "replay" and not self.replay_path:
            raise ValueError("replay mode needs replay_path")
        if not isinstance(self.strategy_params, dict) or len(self.strategy_params) > 64:
            raise ValueError("strategy_params must be a small dict")
        if not isinstance(self.policy_path, str) or len(self.policy_path) > 4096:
            raise ValueError("policy_path must be a string of at most 4096 chars")
        for key in ("engines_dir", "engine_bindings", "engine_account_overrides",
                    "dashboard_account_identity", "execution_experiment_path", "authority_path", "authority_generation", "darkhorse_config_path",
                    "lifecycle_dir", "probe_bindings", "engine_registry", "execution_domain"):
            if not isinstance(getattr(self, key), str) or len(getattr(self, key)) > 4096:
                raise ValueError(f"{key} must be a string of at most 4096 chars")
        if self.execution_domain and not _EXECUTION_DOMAIN_RE.fullmatch(self.execution_domain):
            raise ValueError("execution_domain must be legacy-owner or account-lane:<lane id>")
        if type(self.classification_mode) is not str or self.classification_mode not in CLASSIFICATION_MODES:
            raise ValueError("classification_mode must be empty (legacy) or 'ticker'")
        if type(self.hot_observation_mode) is not str or self.hot_observation_mode not in ("off", "shadow", "use"):
            raise ValueError("hot_observation_mode must be off, shadow or use")
        if (self.probe_bindings or self.engine_registry or self.execution_domain) and self.venue != "kalshi":
            raise ValueError("probe hosting requires venue kalshi")
        if type(self.parity_mirror) is not bool:
            raise ValueError("parity_mirror must be a bool")
        if self.parity_mirror and self.venue != "kalshi":
            raise ValueError("parity_mirror requires venue kalshi")
        if type(self.executor_mode) is not bool:
            raise ValueError("executor_mode must be a bool")
        if self.executor_mode and self.venue != "kalshi":
            raise ValueError("executor_mode requires venue kalshi")
        if self.executor_mode and not self.parity_mirror:
            raise ValueError("executor_mode requires parity_mirror")
        if self.probe_bindings and _probe_hosting_inactive(self.probe_bindings, self.symbol):
            # Resolved here, before any digest is authorized: a symbol the bindings bind no probe
            # to hosts nothing, so its probe configuration is inactive and never enters its digest.
            for name in ("probe_bindings", "engine_registry", "execution_domain"):
                object.__setattr__(self, name, "")
        if self.venue == "kalshi" and not self.darkhorse_model_shas:
            object.__setattr__(self, "darkhorse_model_shas", darkhorse_model_shas(self.darkhorse_config_path))
        if any(not isinstance(sha, str) or not re.fullmatch(r"[0-9a-f]{64}", sha) for sha in self.darkhorse_model_shas):
            raise ValueError("invalid Dark Horse model digest")
        from .lanes.document import LaneDocumentError, cold_digest, load_lane_document
        from .lanes.registry import MAX_LIVE

        if not isinstance(self.lane_documents, (tuple, list)) or len(self.lane_documents) > MAX_LIVE:
            raise ValueError(f"at most {MAX_LIVE} live lane documents")
        if any(type(path) is not str or not 1 <= len(path) <= 4096 for path in self.lane_documents):
            raise ValueError("lane_documents must contain document paths")
        object.__setattr__(self, "lane_documents", tuple(self.lane_documents))
        if self.lane_documents and self.venue != "kalshi":
            raise ValueError("live lane selection requires venue kalshi")
        documents, digests, problems = [], [], []
        for path in self.lane_documents:
            try:
                doc = load_lane_document(path)
            except (LaneDocumentError, OSError) as exc:
                digests.append("unreadable:" + hashlib.sha256(str(Path(path).absolute()).encode()).hexdigest())
                problems.append((path, str(exc)))
            else:
                documents.append(doc)
                digests.append(cold_digest(doc))
        object.__setattr__(self, "lane_problems", tuple(problems))
        if len({doc.id for doc in documents}) != len(documents):
            raise ValueError("duplicate lane ids")
        if not self.lane_digests:
            object.__setattr__(self, "lane_digests", tuple(digests))
        if (not isinstance(self.lane_digests, (tuple, list))
                or len(self.lane_digests) != len(self.lane_documents)
                or any(type(sha) is not str or not re.fullmatch(r"(?:unreadable:)?[0-9a-f]{64}", sha)
                       for sha in self.lane_digests)):
            raise ValueError("invalid lane document digest")
        object.__setattr__(self, "lane_digests", tuple(
            digest if digest.startswith("unreadable:") else authorized
            for digest, authorized in zip(digests, self.lane_digests)))
        if (self.engines_dir or self.engine_bindings or self.engine_account_overrides
                or self.dashboard_account_identity) and self.venue != "kalshi":
            raise ValueError("engine selection requires venue kalshi")
        if bool(self.engine_account_overrides) != bool(self.dashboard_account_identity):
            raise ValueError("engine_account_overrides and dashboard_account_identity must both be set or both empty")
        if self.execution_experiment_path and self.venue != "kalshi":
            raise ValueError("execution experiment requires venue kalshi")
        if self.engine_account_overrides and not (self.engines_dir and self.engine_bindings):
            raise ValueError("account engine overrides require engines_dir and engine_bindings")
        if self.policy_bounds_digest and not re.fullmatch(r"[0-9a-f]{64}", self.policy_bounds_digest):
            raise ValueError("policy_bounds_digest must be a sha256 hex digest")
        if bool(self.policy_path) != bool(self.policy_bounds_digest):
            raise ValueError("policy_path and policy_bounds_digest must both be set or both empty")
        if not isinstance(self.shadow_policy_path, str) or len(self.shadow_policy_path) > 4096:
            raise ValueError("shadow_policy_path must be a string of at most 4096 chars")
        if type(self.shadow_cash_q) is not int or self.shadow_cash_q < 0:
            raise ValueError("shadow_cash_q must be a nonnegative int")
        if bool(self.shadow_policy_path) != bool(self.shadow_cash_q):
            raise ValueError("shadow_policy_path and shadow_cash_q must both be set or both empty")
        if self.shadow_cash_q and not (QUOTE_UNIT <= self.shadow_cash_q <= 500 * QUOTE_UNIT):
            raise ValueError("shadow_cash_q out of range")

    def digest(self) -> str:
        """Hash the named economic authorization surface.

        Excluded: paper (latency, slippage, queue model, snapshot fills and quote
        age affect simulated fills only); shadow_policy_path and shadow_cash_q
        (fenced paper shadow only); ledger_path and record_path (observation);
        replay_path (paper input); run_seconds, mark_interval_ms and max_ticks
        (scheduling). Transport and record flags are CLI options, not config fields.
        New observational fields do not silently revoke an authorization.
        Narrowing this surface rotates legacy whole-config digests once.
        """
        values = {name: (asdict(self.risk) if name == "risk" else getattr(self, name))
                  for name in _AUTHORIZED_FIELDS}
        if not self.engines_dir and not self.engine_bindings:
            values.pop("engines_dir")
            values.pop("engine_bindings")
        if not self.engine_account_overrides and not self.dashboard_account_identity:
            values.pop("engine_account_overrides")
            values.pop("dashboard_account_identity")
        if not self.execution_experiment_path:
            values.pop("execution_experiment_path")
        if not self.lifecycle_dir:
            values.pop("lifecycle_dir")
        if not self.classification_mode:
            values.pop("classification_mode")
        if self.hot_observation_mode == "off":
            values.pop("hot_observation_mode")
        for name in ("probe_bindings", "engine_registry", "execution_domain"):
            if not getattr(self, name):
                values.pop(name)
        if not self.parity_mirror:
            values.pop("parity_mirror")
        if not self.executor_mode:
            values.pop("executor_mode", None)
        if self.coordinated_mode == "off":
            values.pop("coordinated_mode")
        if not self.cohort_digest:
            values.pop("cohort_digest")
        if self.venue != "kalshi":
            values.pop("darkhorse_config_path")
            values.pop("darkhorse_model_shas")
        if not self.lane_documents:
            values.pop("lane_documents")
            values.pop("lane_digests")
        return hashlib.sha256(json.dumps(values, sort_keys=True, default=str).encode()).hexdigest()

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "EngineConfig":
        d = dict(d)
        if "risk" in d and isinstance(d["risk"], dict):
            d["risk"] = RiskLimits(**d["risk"])
        if "paper" in d and isinstance(d["paper"], dict):
            d["paper"] = PaperModel(**d["paper"])
        for k in ("starting_cash_q", "goal_q"):
            if k in d and not isinstance(d[k], int):
                d[k] = to_quote_q(d[k])
        return cls(**d)
