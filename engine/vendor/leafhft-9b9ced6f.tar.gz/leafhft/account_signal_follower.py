"""Tester-side admission of shared coordinated entries, disabled by default.

One follower per tester book talks to the signal authority over its Unix
socket (peer-bound both ways). Tester local entries are always suppressed while
the cohort freeze exists; exits pass through untouched. A publication becomes an
order only after a strict binding check and a durable per-signal claim, and the
send boundary re-checks that claim and the 150ms signal deadline. This module
never owns credentials or submits orders; account-local limits only trim.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import sqlite3
import socket
import stat
import struct
import time

from .coordinated_signal import (
    AccountReadinessV1, ContractError, MAX_PAYLOAD_BYTES, SignalIntentV1, account_client_id,
)

AUTHORITY_SOCKET = Path("/run/leafhft-signal-authority/authority.sock")
MAX_BYTES = 262144
MAX_AGE_NS = 2_000_000_000
READINESS_INTERVAL_NS = 1_000_000_000
MAX_READINESS_MARKETS = 8
_DIGEST = re.compile(r"[0-9a-f]{64}\Z")
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}\Z")


def _integer(value, minimum=0):
    return type(value) is int and minimum <= value < 2**63


def _digest(value):
    return type(value) is str and _DIGEST.fullmatch(value) is not None


class CohortSignalFollower:
    """UID-authenticated shared authority; tester local entries are always suppressed."""

    def __init__(self, cfg, account_id):
        from .coordinated_cohort import OWNER_LANE, cached_freeze
        from .feeds.kalshi import SYMBOL_MAP
        self.lane_id = Path(cfg.authority_path).parent.name
        if account_id == OWNER_LANE or self.lane_id == OWNER_LANE:
            raise ContractError("owner cannot receive coordinated intents")
        freeze = cached_freeze()
        if (freeze is None or freeze.role(self.lane_id) != "tester"
                or freeze.digest != cfg.cohort_digest):
            raise ContractError("invalid cohort follower")
        if cfg.coordinated_mode not in ("shadow", "live") or cfg.symbol not in SYMBOL_MAP:
            raise ContractError("invalid follower binding")
        self.freeze = freeze
        self.cfg = cfg
        self.mode = cfg.coordinated_mode
        self.account_id = account_id
        self.symbol = cfg.symbol
        self.suppressed = True
        self.error = None
        self.response = None
        self.readiness_ns = None
        journal = Path(cfg.authority_path).parent / ("coordinated-" + self.symbol + ".sqlite")
        if journal.is_symlink():
            raise ContractError("symlink follower journal")
        initialized = journal.with_suffix(".initialized")
        if initialized.exists() and not journal.exists():
            raise ContractError("follower journal missing")
        self.db = sqlite3.connect(journal)
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS claims (signal_id TEXT PRIMARY KEY, epoch TEXT NOT NULL,
                sequence INTEGER NOT NULL, client_id TEXT NOT NULL, UNIQUE(epoch, sequence));
            CREATE TABLE IF NOT EXISTS audit (row TEXT NOT NULL);
        """)
        if not initialized.exists():
            with initialized.open("xb") as marker:
                marker.write(b"coordinated-follower-v2\n")
                marker.flush()
                os.fsync(marker.fileno())

    def record(self, kind, **fields):
        with self.db:
            self.db.execute("INSERT INTO audit VALUES (?)", (json.dumps(
                {"kind": kind, "symbol": self.symbol, "mode": self.mode, **fields},
                sort_keys=True, allow_nan=False),))

    def local_intents(self, intents, exit_type):
        """Exits pass through; every local entry is recorded and dropped."""
        result = []
        for intent in intents:
            if isinstance(intent, exit_type):
                result.append(intent)
                continue
            self.record("local_intent", ticker=intent.ticker, count=intent.count,
                        suppressed=True, decision=intent.decision)
        return result

    def request(self, request):
        """One bounded blocking round trip, 50ms timeout, peer UID pinned to the socket dir owner."""
        path = AUTHORITY_SOCKET
        parent = path.parent.lstat()
        if stat.S_ISLNK(parent.st_mode) or parent.st_mode & 0o022 or path.is_symlink():
            raise ContractError("invalid authority socket ownership")
        raw = json.dumps(request, separators=(",", ":"), allow_nan=False).encode() + b"\n"
        if len(raw) > MAX_PAYLOAD_BYTES:
            raise ContractError("authority request too large")
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as stream:
            stream.settimeout(0.05)
            stream.connect(str(path))
            _, uid, _ = struct.unpack("3i", stream.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
            if uid != parent.st_uid:
                raise ContractError("authority peer mismatch")
            stream.sendall(raw)
            with stream.makefile("rb") as reader:
                raw = reader.readline(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES or not raw.endswith(b"\n"):
            raise ContractError("invalid authority response")
        from .coordinated_cohort import decode
        return decode(raw)

    def _response(self, response):
        from .feeds.kalshi import SYMBOL_MAP
        keys = {"generation", "mode", "publication", "configuration_digest", "freeze_digest",
                "deployment_generation", "books"}
        if (type(response) is not dict or set(response) != keys
                or response["freeze_digest"] != self.freeze.digest
                or type(response["generation"]) is not str
                or _ID.fullmatch(response["generation"]) is None
                or not _digest(response["configuration_digest"])
                or not _integer(response["deployment_generation"], 1)
                or response["mode"] != self.mode or type(response["books"]) is not dict):
            raise ContractError("invalid authority binding")
        for symbol, book in response["books"].items():
            if (symbol not in SYMBOL_MAP or type(book) is not dict
                    or set(book) != {"engine_id", "engine_digest", "policy_digest"}
                    or type(book["engine_id"]) is not str or _ID.fullmatch(book["engine_id"]) is None
                    or not self.freeze.admits(book["engine_id"])
                    or not _digest(book["engine_digest"]) or not _digest(book["policy_digest"])):
                raise ContractError("invalid authority book")
        return response

    def _send_readiness(self, engine_id, strategy, book, now_ns):
        """At most once per second, only this book's open markets, one batched round trip."""
        if self.readiness_ns is not None and now_ns - self.readiness_ns < READINESS_INTERVAL_NS:
            return
        self.readiness_ns = now_ns
        if not strategy.entry_enabled:
            return
        from .broker.kalshi_book import expiry_cluster_id
        from .strategy.kalshi_edge import CLOSED_STATUSES
        from .types import QUOTE_UNIT
        now_ms = now_ns // 1_000_000
        markets = sorted((state.expiry_ms, market) for market, state in strategy._markets.items()
                         if state.expiry_ms and now_ms < state.expiry_ms
                         and state.status not in CLOSED_STATUSES)[:MAX_READINESS_MARKETS]
        if not markets:
            return
        stake = max(1, self.cfg.starting_cash_q * 100 // QUOTE_UNIT)
        maximum = max(0, strategy.max_order_cents // 100)
        response = self.response
        messages = [AccountReadinessV1(
            self.lane_id, market, local_room(book, 99, expiry_cluster_id(expiry_ms), maximum),
            True, now_ns, now_ns + MAX_AGE_NS, (engine_id,), stake, False,
            response["configuration_digest"], response["deployment_generation"]).to_dict()
            for expiry_ms, market in markets]
        self.request({"op": "readiness", "messages": messages})

    def poll(self, engine_id, now_ns, strategy, book):
        """One publication poll per evaluation cycle; returns a claimed item or None."""
        started = time.monotonic_ns()
        try:
            self.response = None
            response = self._response(self.request({"op": "poll", "symbol": self.symbol}))
            self.response = response
            binding = response["books"].get(self.symbol)
            if binding is None or binding["engine_id"] != engine_id:
                return None
            self._send_readiness(engine_id, strategy, book, now_ns)
            publication = response["publication"]
            if publication is None:
                return None
            if (type(publication) is not dict
                    or set(publication) != {"intent", "cluster_id", "submit"}
                    or publication["submit"] is not (self.mode == "live")
                    or not _integer(publication["cluster_id"])):
                raise ContractError("invalid authority publication")
            signal = SignalIntentV1.from_dict(publication["intent"])
            now = now_ns + time.monotonic_ns() - started
            if (signal.engine_id != engine_id or not self.freeze.admits(signal.engine_id)
                    or any(getattr(signal, key) != value for key, value in binding.items())
                    or signal.configuration_digest != response["configuration_digest"]
                    or signal.deployment_generation != response["deployment_generation"]
                    or signal.authority_epoch != response["generation"]
                    or set(dict(signal.allocation)) != set(self.freeze.testers)
                    or not signal.is_fresh(now)):
                raise ContractError("cohort signal binding mismatch")
            quantity = signal.for_account(self.lane_id).quantity
            cid = account_client_id(signal.signal_id, self.lane_id)
            with self.db:
                self.db.execute("BEGIN IMMEDIATE")
                if self.db.execute("SELECT 1 FROM claims WHERE signal_id=?",
                                   (signal.signal_id,)).fetchone():
                    return None  # already claimed on an earlier poll
                last = self.db.execute("SELECT MAX(sequence) FROM claims WHERE epoch=?",
                                       (signal.authority_epoch,)).fetchone()[0]
                if last is not None and signal.sequence <= last:
                    raise ContractError("replayed cohort signal")
                self.db.execute("INSERT INTO claims VALUES (?, ?, ?, ?)",
                                (signal.signal_id, signal.authority_epoch, signal.sequence, cid))
            envelope = {"signal": signal.to_dict(), "cluster_id": publication["cluster_id"],
                        "allocation": quantity}
            self.error = None
            return envelope, signal, cid
        except (OSError, ValueError, TypeError, KeyError, RecursionError, sqlite3.Error) as exc:
            self.error = str(exc)
            return None

    def send_check(self, envelope, client_id, now_ns):
        """Send boundary: live mode, same freeze, durable claim, inside the 150ms deadline."""
        from .coordinated_cohort import cached_freeze
        try:
            if self.mode != "live":
                return "coordinated_entry_unavailable"
            current = cached_freeze()
            if current is None or current.digest != self.freeze.digest:
                return "coordinated_cohort_changed"
            signal = SignalIntentV1.from_dict(envelope["signal"])
            if not signal.is_fresh(now_ns):
                return "coordinated_signal_expired"
            row = self.db.execute("SELECT client_id FROM claims WHERE signal_id=?",
                                  (signal.signal_id,)).fetchone()
            if (row is None or row[0] != client_id
                    or client_id != account_client_id(signal.signal_id, self.lane_id)):
                return "coordinated_signal_unclaimed"
            return None
        except (OSError, ValueError, TypeError, KeyError, RecursionError, sqlite3.Error):
            return "coordinated_signal_invalid"

    def close(self):
        self.db.close()


def local_room(book, price_cents, cluster_id, allocation):
    """Trim against the existing book predicate, including fees and cash floor."""
    from .strategy.kalshi_edge import kalshi_fee_cents
    unit = price_cents + kalshi_fee_cents(price_cents, 1)
    low, high = 0, allocation
    while low < high:
        middle = (low + high + 1) // 2
        if book.can_open(middle * unit, cluster_id) is None:
            low = middle
        else:
            high = middle - 1
    return low


def follower_intent(follower, item, strategy, book, now_ns):
    """Use local market metadata and local size law; authority only reduces size."""
    from .broker.kalshi_book import expiry_cluster_id
    from .policy import entry_size_cap, per_order_balance_cap_cents, hard_maxima, _fraction_cap_cents
    from .strategy.kalshi_edge import KalshiIntent, kalshi_fee_cents, CLOSED_STATUSES
    envelope, signal, cid = item
    state = strategy._markets.get(signal.market)
    if (state is None or state.status in CLOSED_STATUSES or not state.expiry_ms
            or now_ns // 1_000_000 >= state.expiry_ms
            or expiry_cluster_id(state.expiry_ms) != envelope["cluster_id"]
            or not strategy.entry_enabled):
        return None
    unit = signal.price_cents + kalshi_fee_cents(signal.price_cents, 1)
    cap = strategy.max_order_cents
    if strategy.balance_cents is not None:
        maxima = hard_maxima()
        capped = per_order_balance_cap_cents(strategy.balance_cents, _maxima=maxima)
        if capped is None:
            capped = strategy.balance_cents // 10
        elif capped == 1:
            # Preserve the follower's zero cap on sub-cent risk room.
            capped = _fraction_cap_cents(strategy.balance_cents, maxima["per_order_fraction"])
        cap = min(cap, capped)
        if strategy.policy_digest:
            cap = min(cap, entry_size_cap(
                strategy.balance_cents, size_fraction=strategy.size_fraction,
                size_scale=strategy.size_scale, conviction=1.0,
                conviction_max=strategy.conviction_max, favorite=False, favorite_mult=1,
                per_order_fraction=strategy.per_order_fraction,
                stake_ceiling_cents=strategy.stake_ceiling_cents,
                target_win_cents=strategy.target_win_cents, per_contract=unit))
    room = max(0, (cap - state.spent_cents) // unit)
    count = local_room(book, signal.price_cents, envelope["cluster_id"], min(envelope["allocation"], room))
    follower.record("would_submit" if follower.mode == "shadow" else "admitted",
                    signal_id=signal.signal_id, client_id=cid, count=count,
                    allocation=envelope["allocation"])
    if count < 1 or follower.mode == "shadow":
        return None
    state.spent_cents += count * unit
    state.last_intent_ms = now_ns // 1_000_000
    return KalshiIntent(signal.market, signal.side_yes, signal.price_cents, count,
                        envelope["cluster_id"], "coordinated_entry",
                        {"coordinated_signal": envelope, "coordinated_client_id": cid,
                         "close_time_ms": state.expiry_ms, "wall_time_ns": now_ns})
