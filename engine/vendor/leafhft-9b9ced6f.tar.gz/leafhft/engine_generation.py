"""Durable, disabled offline tuning (simulated) operations. No live engine registry is used.

SQLite serializes mutations and stores request replay receipts atomically with
the operation. Immutable files written before a commit are safe to reuse after
a crash. An external offline evaluator supplies the operation's paper journal.
A published paper report is offline tuning (simulated), never a verdict: the
Engine Lab promotes only from live_fill evidence (docs/ENGINES.md).
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import os
from pathlib import Path
import sqlite3

from . import paper_results as paper

STAGES = ("SPEC_FROZEN", "SCAFFOLDED", "PAPER_RUNNING", "REPORT_IMMUTABLE",
          "PUBLISHED", "VISIBLE", "FAILED")
MAX_OPERATIONS = 256
MAX_TRANSITIONS = 64


def validate_spec(spec):
    """A closed data schema, never code, imports, paths or execution settings."""
    required = {"engine_id", "mode", "enabled", "capital_basis_cents", "max_records"}
    optional = {"name", "hypothesis", "source", "series_ticker", "reference_ticker"}
    if (type(spec) is not dict or not required <= spec.keys()
            or not spec.keys() <= required | optional or spec.get("mode") != "paper"
            or spec.get("enabled") is not False):
        raise ValueError("spec must be a bounded disabled paper-only specification")
    paper.identifier(spec["engine_id"])
    paper.integer(spec["capital_basis_cents"], 1)
    paper.integer(spec["max_records"], 1, paper.MAX_RECORDS)
    for field in ("name", "hypothesis"):
        if field in spec and (type(spec[field]) is not str or not spec[field].strip()
                              or len(spec[field]) > 512):
            raise ValueError("invalid spec text")
    source = spec.get("source", "journal")
    if source not in ("journal", "kalshi_gold_paper"):
        raise ValueError("unknown paper source")
    if source == "kalshi_gold_paper":
        if (spec.get("series_ticker") != "KXGOLD15M"
                or spec.get("reference_ticker") != "Metal.Index.1OZGOLD/USD"):
            raise ValueError("Gold source must be exact")
    elif "series_ticker" in spec or "reference_ticker" in spec:
        raise ValueError("source fields require Gold adapter")
    data = paper.canonical(spec)
    if len(data) > 4096:
        raise ValueError("spec byte limit")
    return paper.parse(data)


def _request_id(value):
    if type(value) is not str or not 1 <= len(value) <= 128 or not value.strip():
        raise ValueError("client request ID required")
    return value


class OperationStore:
    def __init__(self, root=None, paper_results_root=None):
        self.root = paper.safe_path(root if root is not None else os.environ.get(
            "LEAFHFT_ENGINE_GENERATION_DIR", "/var/lib/leafhft/engine-generation"))
        self.paper_root = paper.safe_path(paper_results_root if paper_results_root is not None
            else os.environ.get("LEAFHFT_PAPER_RESULTS_DIR", "/var/lib/leafhft/paper-results"))
        self.root.mkdir(parents=True, exist_ok=True)
        self.database = paper.safe_path(self.root, "operations.sqlite3")
        with self._connection() as connection:
            connection.execute("CREATE TABLE IF NOT EXISTS operations "
                               "(id TEXT PRIMARY KEY, receipt BLOB NOT NULL)")
            connection.execute("CREATE TABLE IF NOT EXISTS requests "
                               "(id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, receipt BLOB NOT NULL)")

    @contextmanager
    def _connection(self):
        paper.safe_path(self.root, self.database.name)
        connection = sqlite3.connect(self.database, timeout=5)
        try:
            connection.execute("PRAGMA synchronous=FULL")
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    def journal_path(self, operation_id):
        return paper.safe_path(self.root, "operations", paper.identifier(operation_id), "journal.jsonl")

    def _get(self, connection, operation_id):
        paper.identifier(operation_id)
        row = connection.execute("SELECT receipt FROM operations WHERE id=?", (operation_id,)).fetchone()
        if row is None:
            raise ValueError("unknown generation")
        receipt = paper.parse(row[0])
        body = {key: value for key, value in receipt.items() if key != "receipt_sha256"}
        if receipt.get("receipt_sha256") != paper.sha256(body):
            raise ValueError("durable receipt hash mismatch")
        return receipt

    def _save(self, connection, receipt, stage, **updates):
        if stage not in STAGES:
            raise ValueError("invalid generation stage")
        previous = receipt.get("receipt_sha256")
        history = receipt.get("history", [])
        if len(history) >= MAX_TRANSITIONS:
            raise ValueError("generation transition limit")
        receipt = {**receipt, **updates, "stage": stage, "previous_receipt_sha256": previous,
                   "history": [*history, stage], "sequence": len(history) + 1}
        receipt.pop("receipt_sha256", None)
        receipt["receipt_sha256"] = paper.sha256(receipt)
        connection.execute("INSERT OR REPLACE INTO operations(id,receipt) VALUES (?,?)",
                           (receipt["operation_id"], paper.canonical(receipt)))
        return receipt

    def _mutation(self, name, client_request_id, arguments, action):
        request = _request_id(client_request_id)
        fingerprint = paper.sha256({"method": name, "arguments": arguments})
        with self._connection() as connection:
            old = connection.execute("SELECT fingerprint,receipt FROM requests WHERE id=?", (request,)).fetchone()
            if old is not None:
                if old[0] != fingerprint:
                    raise ValueError("conflicting client request ID reuse")
                return paper.parse(old[1])
            receipt = action(connection)
            connection.execute("INSERT INTO requests(id,fingerprint,receipt) VALUES (?,?,?)",
                               (request, fingerprint, paper.canonical(receipt)))
            return receipt

    def _expected(self, connection, operation_id, expected_spec_hash, expected_receipt_hash):
        receipt = self._get(connection, operation_id)
        if (paper.hash_value(expected_spec_hash) != receipt["spec_sha256"]
                or paper.hash_value(expected_receipt_hash) != receipt["receipt_sha256"]):
            raise ValueError("expected generation hash mismatch")
        self._spec(receipt)
        return receipt

    def _spec(self, receipt):
        data = paper.read_bytes(paper.safe_path(self.root, "specs", receipt["spec_sha256"] + ".json"))
        if hashlib.sha256(data).hexdigest() != receipt["spec_sha256"]:
            raise ValueError("frozen spec hash mismatch")
        return validate_spec(paper.parse(data))

    def _freeze(self, connection, spec, client_request_id, expected_spec_hash):
        spec = validate_spec(spec)
        if paper.sha256(spec) != paper.hash_value(expected_spec_hash):
            raise ValueError("expected spec hash mismatch")
        if connection.execute("SELECT COUNT(*) FROM operations").fetchone()[0] >= MAX_OPERATIONS:
            raise ValueError("generation store limit")
        operation_id = "gen-" + hashlib.sha256(client_request_id.encode()).hexdigest()[:48]
        paper.write_document(paper.safe_path(self.root, "specs", expected_spec_hash + ".json"), spec)
        return self._save(connection, {"operation_id": operation_id, "engine_id": spec["engine_id"],
            "spec_sha256": expected_spec_hash, "mode": "paper", "enabled": False,
            "failed_stage": None, "error": None, "report": None, "publication": None,
            "visibility": None, "resume": None}, "SPEC_FROZEN")

    def freeze_engine_spec(self, spec, client_request_id, expected_spec_hash):
        arguments = {"spec": spec, "expected_spec_hash": expected_spec_hash}
        return self._mutation("freeze", client_request_id, arguments,
            lambda connection: self._freeze(connection, spec, client_request_id, expected_spec_hash))

    def _failed(self, connection, receipt, stage, action, exc, **arguments):
        return self._save(connection, receipt, "FAILED", failed_stage=stage,
                          error=type(exc).__name__, resume={"action": action, **arguments})

    def _start(self, connection, receipt):
        if receipt["stage"] not in ("SPEC_FROZEN", "SCAFFOLDED"):
            raise ValueError("generation cannot start at this stage")
        try:
            descriptor = {"engine_id": receipt["engine_id"], "spec_sha256": receipt["spec_sha256"],
                          "mode": "paper", "enabled": False, "operation_id": receipt["operation_id"]}
            paper.write_document(paper.safe_path(self.root, "operations", receipt["operation_id"],
                                                "research.json"), descriptor)
            if receipt["stage"] == "SPEC_FROZEN":
                receipt = self._save(connection, receipt, "SCAFFOLDED")
            return self._save(connection, receipt, "PAPER_RUNNING", failed_stage=None, error=None,
                              resume=None)
        except (OSError, ValueError) as exc:
            return self._failed(connection, receipt, "SCAFFOLDED", "start", exc)

    def start_engine_generation(self, operation_id, client_request_id, expected_spec_hash,
                                expected_receipt_hash):
        arguments = dict(operation_id=operation_id, expected_spec_hash=expected_spec_hash,
                         expected_receipt_hash=expected_receipt_hash)
        return self._mutation("start", client_request_id, arguments, lambda connection:
            self._start(connection, self._expected(connection, **arguments)))

    def get_engine_generation(self, operation_id):
        with self._connection() as connection:
            return self._get(connection, operation_id)

    def list_engine_generations(self, limit=100):
        paper.integer(limit, 1, MAX_OPERATIONS)
        with self._connection() as connection:
            ids = connection.execute("SELECT id FROM operations ORDER BY id LIMIT ?", (limit,)).fetchall()
            return [self._get(connection, row[0]) for row in ids]

    def _publish(self, connection, receipt, summary_sha256, expected_report_hash):
        if receipt["stage"] not in ("PAPER_RUNNING", "REPORT_IMMUTABLE"):
            raise ValueError("generation cannot publish at this stage")
        # A retry rechecks immutable bytes but must retain the settled report
        # stage if that check or the publication write is temporarily unavailable.
        failed_stage = "PUBLISHED" if receipt["stage"] == "REPORT_IMMUTABLE" else "REPORT_IMMUTABLE"
        try:
            summary = paper.load_summary(self.paper_root, receipt["engine_id"],
                                         summary_sha256, expected_report_hash)
            spec = self._spec(receipt)
            if (summary["spec_sha256"] != receipt["spec_sha256"]
                    or summary["operation_id"] != receipt["operation_id"]
                    or summary["source"] != spec.get("source", "journal")
                    or summary["metrics"]["capital_basis_cents"] != spec["capital_basis_cents"]
                    or summary["source_records_n"] > spec["max_records"]):
                raise ValueError("report does not match frozen generation")
            reference = {"summary_sha256": summary_sha256, "report_hash": expected_report_hash}
            if receipt["stage"] == "REPORT_IMMUTABLE" and receipt["report"] != reference:
                raise ValueError("immutable report conflict")
            if receipt["stage"] == "PAPER_RUNNING":
                receipt = self._save(connection, receipt, "REPORT_IMMUTABLE", report=reference)
            failed_stage = "PUBLISHED"
            paper.write_summary(self.paper_root, summary, publish=True)
            return self._save(connection, receipt, "PUBLISHED", failed_stage=None, error=None,
                resume=None, publication={**reference, "consumer": "engine_lab_v3", "provenance": "paper"})
        except (OSError, ValueError) as exc:
            return self._failed(connection, receipt, failed_stage, "publish", exc,
                                summary_sha256=summary_sha256, expected_report_hash=expected_report_hash)

    def publish_engine_report(self, operation_id, client_request_id, expected_spec_hash,
                              expected_receipt_hash, summary_sha256, expected_report_hash):
        paper.hash_value(summary_sha256)
        paper.hash_value(expected_report_hash)
        arguments = dict(operation_id=operation_id, expected_spec_hash=expected_spec_hash,
                         expected_receipt_hash=expected_receipt_hash, summary_sha256=summary_sha256,
                         expected_report_hash=expected_report_hash)
        def publish(connection):
            receipt = self._expected(connection, operation_id, expected_spec_hash, expected_receipt_hash)
            return self._publish(connection, receipt, summary_sha256, expected_report_hash)
        return self._mutation("publish", client_request_id, arguments, publish)

    def _evaluate(self, connection, receipt):
        try:
            path = self.journal_path(receipt["operation_id"])
            if not path.exists():
                return receipt
            spec = self._spec(receipt)
            summary = paper.build_summary(path, engine_id=receipt["engine_id"],
                capital_basis_cents=spec["capital_basis_cents"], source=spec.get("source", "journal"),
                spec_sha256=receipt["spec_sha256"], operation_id=receipt["operation_id"],
                max_records=spec["max_records"])
            reference = paper.write_summary(self.paper_root, summary, publish=False)
            # An open or empty evaluation is resumable, with a real collecting report.
            if not summary["metrics"]["resolved_n"] or summary["metrics"]["open_n"]:
                if receipt.get("report") == reference:
                    return receipt
                return self._save(connection, receipt, "PAPER_RUNNING", report=reference)
            return self._publish(connection, receipt, reference["summary_sha256"], reference["report_hash"])
        except (OSError, ValueError) as exc:
            return self._failed(connection, receipt, "PAPER_RUNNING", "evaluate", exc)

    def retry_engine_generation_stage(self, operation_id, client_request_id, failed_stage,
                                      expected_spec_hash, expected_receipt_hash):
        arguments = dict(operation_id=operation_id, failed_stage=failed_stage,
                         expected_spec_hash=expected_spec_hash, expected_receipt_hash=expected_receipt_hash)
        def retry(connection):
            receipt = self._expected(connection, operation_id, expected_spec_hash, expected_receipt_hash)
            if receipt["stage"] != "FAILED" or receipt["failed_stage"] != failed_stage:
                raise ValueError("retry requires the exact failed stage")
            resume = receipt["resume"]
            # Resume only the stored action and hashes, never client replacement input.
            if resume["action"] == "start":
                receipt = self._save(connection, receipt, "SPEC_FROZEN", failed_stage=None, error=None)
                return self._start(connection, receipt)
            stage = "REPORT_IMMUTABLE" if failed_stage == "PUBLISHED" else "PAPER_RUNNING"
            receipt = self._save(connection, receipt, stage, failed_stage=None, error=None, resume=None)
            if resume["action"] == "publish":
                return self._publish(connection, receipt, resume["summary_sha256"], resume["expected_report_hash"])
            return self._evaluate(connection, receipt)
        return self._mutation("retry", client_request_id, arguments, retry)

    def generate_engine_end_to_end(self, spec, client_request_id, expected_spec_hash,
                                   operation_id=None, expected_receipt_hash=None):
        validate_spec(spec)
        if paper.sha256(spec) != paper.hash_value(expected_spec_hash):
            raise ValueError("expected spec hash mismatch")
        arguments = dict(spec=spec, expected_spec_hash=expected_spec_hash,
                         operation_id=operation_id, expected_receipt_hash=expected_receipt_hash)
        def generate(connection):
            if operation_id is None:
                if expected_receipt_hash is not None:
                    raise ValueError("unexpected prior receipt")
                receipt = self._freeze(connection, spec, client_request_id, expected_spec_hash)
            else:
                receipt = self._expected(connection, operation_id, expected_spec_hash, expected_receipt_hash)
            if receipt["stage"] in ("SPEC_FROZEN", "SCAFFOLDED"):
                receipt = self._start(connection, receipt)
            if receipt["stage"] == "PAPER_RUNNING":
                receipt = self._evaluate(connection, receipt)
            return receipt
        return self._mutation("end_to_end", client_request_id, arguments, generate)

    def record_visibility(self, operation_id, report_hash):
        """Internal push acknowledgement, deliberately absent from the MCP tools.

        Visible means shown as offline tuning (simulated), never promoted."""
        paper.hash_value(report_hash)
        with self._connection() as connection:
            receipt = self._get(connection, operation_id)
            if receipt["stage"] == "VISIBLE" and receipt["report"]["report_hash"] == report_hash:
                return receipt
            if receipt["stage"] != "PUBLISHED" or receipt["report"]["report_hash"] != report_hash:
                raise ValueError("visibility requires the exact published report")
            return self._save(connection, receipt, "VISIBLE", visibility={
                "report_hash": report_hash, "consumer": "engine_lab_v3", "basis": "ingest_accepted"})


EngineGenerationService = OperationStore
