"""Versioned decision identity. Historical identity is never inferred from prose."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import uuid


def account_digest(account: str | None = None) -> str:
    if not isinstance(account, str) or not account:
        return "unknown"
    return hashlib.sha256(("leafhft:account:v1:" + account).encode()).hexdigest()


def execution_account(client):
    """Only the verified execution principal can bind live decision identity."""
    getter = getattr(client, "attribution_account", None)
    return getter() if callable(getter) else None


def recovered_settlement_minute(row):
    minute = row.get("settlement_minute")
    if type(minute) is int and minute >= 0:
        return minute
    return attribution_or_unknown(row.get("attribution"))["cluster_minute"]


@dataclass(frozen=True)
class DecisionAttributionV1:
    decision_id: str
    account_digest: str
    engine_id: str
    policy_digest: str
    market_inputs: dict
    sizing_inputs: dict
    cluster_minute: int
    reason: str
    status: str = "known"
    schema_version: int = 1

    def __post_init__(self):
        if type(self.schema_version) is not int or self.schema_version != 1:
            raise ValueError("unsupported attribution schema")
        if self.status not in ("known", "unknown"):
            raise ValueError("invalid attribution status")
        if any(not isinstance(value, str) or not value for value in (
                self.decision_id, self.account_digest, self.engine_id, self.policy_digest)):
            raise ValueError("invalid attribution identity")
        if type(self.cluster_minute) is not int or self.cluster_minute < -1:
            raise ValueError("invalid settlement minute")
        if not isinstance(self.reason, str) or len(self.reason) > 400:
            raise ValueError("invalid attribution reason")
        if not isinstance(self.market_inputs, dict) or not isinstance(self.sizing_inputs, dict):
            raise ValueError("invalid attribution inputs")

    def to_dict(self) -> dict:
        row = deepcopy(self.__dict__)
        row["digest"] = hashlib.sha256(json.dumps(
            row, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
        return row


def valid_engine_revision(value) -> bool:
    """Revision metadata must fit the journal and contain no controls or surrogates."""
    return (isinstance(value, str) and 1 <= len(value) <= 128
            and all(ord(char) >= 0x20 and not 0x7F <= ord(char) <= 0x9F
                    and not 0xD800 <= ord(char) <= 0xDFFF for char in value))


def new_attribution(*, ticker, side_yes, price_cents, count, cluster_minute,
                    reason, engine_id, policy_digest, account=None, inputs=None, sizing=None,
                    deterministic_key=None, engine_revision=None) -> dict:
    """Live calls mint an ID; paper calls bind it to immutable opportunity/client keys."""
    # Omission preserves V1 bytes; an explicit revision overrides only the nested input.
    if engine_revision is not None and not valid_engine_revision(engine_revision):
        raise ValueError("invalid engine revision")
    decision_id = uuid.uuid4().hex if deterministic_key is None else hashlib.sha256(
        json.dumps(["leafhft:paper-decision:v1", deterministic_key, account_digest(account),
                    engine_id, policy_digest, ticker, side_yes, str(price_cents),
                    str(count), cluster_minute],
                   sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    return DecisionAttributionV1(
        decision_id, account_digest(account), engine_id or "unknown",
        policy_digest or "unknown",
        {"ticker": ticker, "side_yes": side_yes, "price_cents": str(price_cents),
         **(inputs or {}),
         **({"engine_revision": engine_revision} if engine_revision is not None else {})},
        {**(sizing or {}), "requested_count": str(count)},
        cluster_minute, reason[:400] if isinstance(reason, str) else "").to_dict()


def unknown_attribution() -> dict:
    return DecisionAttributionV1("unknown", "unknown", "unknown", "unknown",
                                 {}, {}, -1, "legacy attribution unavailable", "unknown").to_dict()


def attribution_or_unknown(value) -> dict:
    if not isinstance(value, dict) or value.get("schema_version") != 1:
        return unknown_attribution()
    row = deepcopy(value)
    digest = row.pop("digest", None)
    try:
        expected = hashlib.sha256(json.dumps(
            row, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
        required = DecisionAttributionV1(**row)
    except (TypeError, ValueError):
        return unknown_attribution()
    return required.to_dict() if digest == expected else unknown_attribution()


def scope_attribution(value, account=None) -> dict:
    """Bind a new proposal to its execution account before its first durable write."""
    row = attribution_or_unknown(value)
    if row["status"] == "known" and account is not None:
        row.pop("digest")
        row["account_digest"] = account_digest(account)
        return DecisionAttributionV1(**row).to_dict()
    return row
