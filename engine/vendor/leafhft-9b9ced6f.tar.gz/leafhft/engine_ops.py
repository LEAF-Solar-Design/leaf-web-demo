"""`python -m leafhft.engine_ops`: the one writer of engine assignment, probe and breaker state.

Plan D7 and D9, contract C6. This module never imports leafhft.cli; it composes engine_registry,
canary, breaker, probe_bar, engine_manifest, engine_feeds, engine_reasons, trials and the lanes
adapter through their public names only.

Exit codes are the machine contract: 0 ok, 2 refused (a named code on stderr, and on stdout with
--json), 3 internal error.

Every mutating verb (registry init --apply, assign, release, probe, probe-activate, probe-size,
graduate, retire, halt, breaker set, repair) runs under one engine_ops lock (`<registry-dir>/engine-ops.lock`) and then takes the registry
lock before the canary lock, always in that order and never nested the other way. Each carries a
`--request-id`: the request record under `<registry-dir>/requests/<id>/` makes a rerun of the same
id complete the earlier write (every step checks whether it already happened) and never duplicate
it; probe and release are the exception (NO_RESUME_VERBS, below). Each appends journal rows to `<registry-dir>/engine-ops-journal.jsonl`, writes one receipt
under `<evidence-dir>/<engine_id>/receipts/<utc>-<verb>.json`, and prints
`hot: engine <verb> applied; receipt <sha12>` for the control-ack note filter.

`probe` writes in order: registry assignment, CanaryStore.probe(), TrialStore.register(), the
enabled-only account override when one exists, the bindings, then consumes the approval. `--bind`
co-hosts the probe beside the incumbent through the probe bindings file (`--probe-bindings`, C7a
schema) and never touches the main bindings file; only `--displace`, backed by an approval card
that names the displaced engine, rewrites the main bindings file. Every bindings write keeps the
file's mode and owner (a new file: 0644, the directory's owner), because the books read it as
`leafhft` (incident 2026-09-24 05:24Z). A failure after any write rolls every earlier write back from the snapshots saved in the
request directory; a crash leaves the request `started`, which `registry audit` reports with the
`engine_ops repair` command that settles it.

Interrupted transactions (C6e): a probe or release is never auto-resumed. A rerun of a `started`
probe or release that already wrote a step (or has one in flight) refuses
`transaction_interrupted`, writes nothing, and names the completed steps, the in-flight step and
the repair commands. `engine_ops repair <request-id>` reports it read-only; `--finish` records a
probe that is already fully written (or finishes a release, which only lowers exposure), and
`--rollback` undoes a probe. Every rollback restores only the entries it wrote: a snapshot goes back
byte for byte only while the file is still exactly this request's own write, the main bindings file
otherwise gets back only the symbols still bound to this engine, the probe bindings file loses only
this request's own entries, and a lifecycle or overrides file someone changed since stands (listed
as left). A bindings write always starts from the file's current bytes, so a probe another request
bound meanwhile stays bound. A release acts only while the registry still holds the assignment
generation (request id and since stamp) it captured; one that meets another generation leaves it
and records release_superseded. A probe captures the assignment generation its registry step
wrote, and every later step, `repair` and every rollback goes on only while the registry still
holds it for the engine; otherwise the probe writes and undoes nothing more, ends `superseded`
(rollback_superseded; resume_superseded on records from before C6e), the audit names it and its id
is retired.

The books read two things engine_ops writes (C1c, first-probe gaps 2026-09-24): the registry
projection `<registry-dir>/projection.json`, which every registry commit rewrites (and `registry
project` rewrites for recovery), and the lifecycle dir, which defaults to the books' own
`/var/lib/leafhft/engine-lifecycle`. Every lifecycle write runs as the directory's owner with umask
0o022 (`_born_as`, C6d fix b), so a record is born the book's (user `leafhft`) and 0644; after a
mutating verb the hand-over walk still checks every entry and hands any root left behind to that
owner. Only `status` reads the pre-C0 `<engines-dir>/lifecycle`, and warns `lifecycle_dir_legacy`.

book_flat applies to displacement, not to co-hosting: a co-host never touches the incumbent, so
`probe --bind` and an `approve` item without `--displace` skip it; `--displace` requires it.

The ladder (plan D5, D7): `probe-size` moves a probe one rung (1 -> 2 -> 5 contracts) per approval,
only after operational qualification (the OQ record under `<oq-dir>/<engine_id>/oq.json`, which
`judge --write`, running as root, re-qualifies and persists on every read through
probe_bar.record_oq, beside the venue reconciliation venue.json, the fills oq-fills.json and its copy
venue-rows.json of the venue rows the root-run venue snapshot published under
`<venue-dir>/<engine_id>/venue.json` and the disturbance counters the probe executor on EVERY hosting
book (the probe bindings) stages under `<evidence-dir>/<engine_id>/staging/<symbol>/`; every file
root-owned 0444 in a root-owned 0755 directory; the judge refuses a snapshot that is stale
(oq_venue_stale, oq_balance_stale), out of the window (oq_time_out_of_window) or disagrees with the
attributed fills (oq_venue_mismatch), and a book's counters that are missing
(oq_counters_incomplete), whose window systemd's journal does not confirm
(oq_counters_window_unverified) or that the refusal journal contradicts (oq_counters_mismatch): the
counts are the book process's self-report, only their window is verified, and both independent
checks are required (C13 fix f: an unconfigured or unreadable refusal journal or book journal is
evidence_unavailable); the balance reconciles against the qualification's opening balance plus
every cash movement; the ladder acts only on that trusted set, the current probe's account and trial, a fresh
qualified_at, an evidence digest that recomputes and, per hosting book, counters one process
counted over the whole population window) and
never while the newest judge verdict holds or kills; `graduate` needs a fresh GRADUATE_ELIGIBLE
verdict from `judge` and a policy inside the HARD_MAXIMA constants; `retire` is terminal.
`probe-size` and `graduate` bind their approval to the request id at the transaction's FIRST write
(the consumption marker, before any lifecycle or registry write): a rerun of that id completes its
own transaction, and any other id presenting the approval is refused
approval_bound_to_other_request. `judge` (the daily timer) activates probe trials once the book
status shows the engine, runs the frozen scorer bounded, and writes
`<evidence-dir>/<engine_id>/verdicts/<utc>.json`; it holds no lock while a subprocess runs, so halt
always gets through, and INCONCLUSIVE never becomes KILL. An unactivated trial gets a PENDING file
but never a SCORED verdict. Activation takes the trial's opening balance from the root-run venue
read and persists it write-once in the lifecycle store (C13 fix g); qualification only reads it. A
read whose qualification fails in any way, raised or returned failed, HOLDs, persists
qualification_error (with the failing checks) and never falls back to an older OQ record (C13 fix f,
fix g), and `graduate` refuses such a verdict, one whose OQ record predates its own read
(verdict_stale_qualification), or one whose qualification the root-owned OQ record does not verify
(qualification_unverified): graduation re-derives qualification from that record, never from the
verdict's embedded fields.

X1c (found live 2026-09-24 07:24Z): the registry keys the owner account "owner" and a tenant by its
lane id, but a book passes the gate its dashboard identity file's account_id. engine_ops derives
each account's `book_account_id` offline from that same file (`--owner-identity` for the owner,
`<lane-identity-root>/<lane>/dashboard-account-identity.json` for a lane) at `registry init`, at `registry
project` and on every registry commit it makes; no credential is read. `registry project` stamps
the ids and publishes the projection and its marker in one generation, and recognises (and
replaces) the interim hand-patched projection that renamed the owner key to that id.

S7 A L2 (one store, leased down): a tenant lane's probe record lives in this same lifecycle store,
keyed by engine_id under the registry account key; engine_ops never opens, stats or lists anything
under `--lanes-root`. A lane probe writes neither owner bindings file (its bindings row is
`bindings:lane_published`) nor the lane's overrides (`override:lane_not_touched`); after every verb on
a lane-assigned engine, still under the ops lock, the lane's lease and probe bindings are rebuilt from
one registry snapshot and published root-owned under `--projection-root` (lifecycle_lease), and the
verb prints `lease: published|pending(<code>); tenant_effective_by=<iso>` without changing its exit
code. Tenant probes stay at the first rung (probe-size, graduate and --displace refuse
tenant_ladder_deferred) and the judge defers them (tenant_evidence_deferred).

Hardening: every file read is bounded, every JSON document is decoded strictly (duplicate keys and
non-finite numbers refused), every write is temp + fsync + atomic replace or exclusive create,
and every reader fails closed.
"""
from __future__ import annotations

import argparse
import errno
import hashlib
import importlib.util
import json
import math
import os
import posixpath
import re
import stat
import subprocess
import sys
import tempfile
import time
from collections import Counter
from contextlib import ExitStack, contextmanager
from datetime import datetime, timedelta, timezone
from decimal import ROUND_DOWN, Decimal, InvalidOperation
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Callable, Iterable, Mapping

from . import ENGINE_CATALOG_CAPACITY
from . import approve_presence, engine_feeds, engine_reasons, exposure_authority, probe_bar, scoring
from . import engine_registry as er
from . import lifecycle_lease
from . import probe_bindings as pb
from . import venue_snapshot
from .canary import (GRADUATE_FROM, LIFECYCLE_DIR_ENV, PROBE_SIZED_CONTRACTS, CanaryError, CanaryStore,
                     lifecycle_directory, maxima_breaches, opening_balance)
from .engine_manifest import (ENGINE_ID_RE, MANIFEST_SCHEMA, POLICY_KERNEL_ID, ManifestInvalid,
                              build_manifest, identity_digest, import_legacy, load_manifest,
                              manifest_bytes, manifest_digest)
from .engines import (AccountOverrides, EngineError, EngineRegistry, account_revision,
                      load_dashboard_account_identity)
from .policy import DEFAULT_POLICY, HARD_MAXIMA, policy_digest
from .probe_bindings import load_probe_bindings
from .trials import TRIALS_DIR, Activation, TrialError, TrialStore
from .books import replay_observer as replay_watch

EXIT_OK = 0
EXIT_REFUSED = 2
EXIT_INTERNAL = 3

REQUEST_SCHEMA = "leafhft.engine_ops.request.v1"
RECEIPT_SCHEMA = "leafhft.engine_ops.receipt.v1"
CONFORM_SCHEMA = "leafhft.engine_ops.conform.v1"
APPROVAL_KEYS = frozenset({"approval_id", "kind", "engine_id", "account", "symbols", "sizing",
                           "expires_at", "digest"})

DEFAULT_ENGINES_DIR = "/etc/leafhft/engines"
DEFAULT_BINDINGS = "/etc/leafhft/engine-registry-accounts.json"
DEFAULT_REGISTRY_DIR = "/var/lib/leafhft/engine-registry"
DEFAULT_APPROVALS_DIR = "/var/lib/leafhft-approvals"  # root-only (C6c); never under leafhft-owned /var/lib/leafhft
DEFAULT_MANIFESTS_DIR = "/etc/leafhft/engine-manifests"
DEFAULT_EVIDENCE_DIR = probe_bar.DEFAULT_EVIDENCE_ROOT  # /var/lib/leafhft/engine-evidence
# Must match User= in deploy/runner/units/leafhft-live@.service.
OWNER_BOOK_USER = "leafhft"
# The judge's OQ evidence set (C13 fix c): root-owned 0755 directories of root-owned 0444 files that
# the leafhft user can neither write nor rename (the /var/lib/leafhft-approvals pattern; the judge
# unit's StateDirectory creates it), never under leafhft-owned /var/lib/leafhft.
DEFAULT_OQ_DIR = "/var/lib/leafhft-oq"
# The root-run venue snapshot's evidence set (leafhft.venue_snapshot, <venue-dir>/<engine_id>/venue.json,
# root-owned); the judge requires it fresh and never reads the venue itself. The probe executor's
# leafhft-owned staging (its disturbance counters) is <evidence-dir>/<engine_id>/staging.
DEFAULT_VENUE_DIR = venue_snapshot.DEFAULT_EVIDENCE_DIR
VENUE_MAX_AGE = timedelta(minutes=15)  # the judge refuses an older venue read (oq_venue_stale) or balance (oq_balance_stale)
# The books that host a probe (C13 fix e): the probe bindings every book's host reads to build its
# ProbeExecutors (leafhft.probe_bindings; deploy/runner/live-run.sh passes $LEAFHFT_ETC/probe-bindings.json).
PROBE_BINDINGS_ENV = "LEAFHFT_PROBE_BINDINGS"
DEFAULT_PROBE_BINDINGS = "/etc/leafhft/probe-bindings.json"
# The account-risk ledger's refusal journal the judge cross-checks the self-reported counters against
# (JSON lines, probe_bar.ledger_refusal_count; its producer is leafhft.refusal_journal.RefusalJournal).
# REQUIRED (C13 fix f, fix g): unset, absent, last written before the coverage window opened, rotated
# past the window, unreadable or malformed, the qualification is evidence_unavailable and the verdict
# HOLDs; an absent journal is never read as zero refusals.
REFUSAL_JOURNAL_ENV = "LEAFHFT_REFUSAL_JOURNAL"
# systemd's journal verifies each book's counting window (C13 fix e): root-only, bounded. The unit
# name of a hosting book comes from this template, "{book}" standing for the lowercased symbol
# (deploy/runner/live-run.sh's leafhft-live@kalshi-<coin>-<period>.service). REQUIRED (C13 fix f):
# unset, or a journal that cannot be read, is evidence_unavailable, never a pass.
BOOK_UNIT_TEMPLATE_ENV = "LEAFHFT_BOOK_UNIT_TEMPLATE"
_BOOK_UNIT_TEMPLATE = re.compile(r"[A-Za-z0-9@._-]*\{book\}[A-Za-z0-9@._-]*\.service")
# The one reason a qualification whose independent evidence (the refusal journal, the journal
# window) is unconfigured or unreadable carries: the verdict HOLDs and the judge exits 2.
EVIDENCE_UNAVAILABLE = "evidence_unavailable"
QUALIFICATION_FAILED = "qualification_failed"  # any other exception inside the qualification
# C13 fix i: an activated trial whose opening balance is missing (a legacy activation written before
# the opening; engine_ops repairs it on its next --write call) is never judged: HOLD with this reason.
OPENING_BALANCE_MISSING = "opening_balance_missing"
JOURNALCTL = "journalctl"
JOURNAL_TIMEOUT_S = 20.0
UNIT_START_LOOKBACK = timedelta(minutes=15)  # a book's executor opens within this of its unit's start
OQ_WINDOW_SLACK = timedelta(seconds=60)  # every timestamp inside [population start, qualification] +- this
_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)
DEFAULT_LANES_ROOT = "/var/lib/leafhft-accounts"
# S7 A L2: engine_ops never opens, stats or lists anything under the lanes root (tenant-writable). A
# lane's identity comes from the root-owned config tree, and its lease and bindings are published
# under the root-owned projection root (account_lane_agent.CONFIG_ROOT and PROJECTION_ROOT).
DEFAULT_LANE_IDENTITY_ROOT = "/etc/leafhft-accounts"
DEFAULT_PROJECTION_ROOT = "/var/lib/leafhft-projections"
# Named tenant refusals and rows (S7 A L2).
TENANT_CAPACITY = "tenant_capacity"
LANE_BOOK_FULL = "lane_book_full"
TENANT_LADDER_DEFERRED = "tenant_ladder_deferred"
TENANT_EVIDENCE_DEFERRED = "tenant_evidence_deferred"
LANE_BINDINGS_ROW = "bindings:lane_published"
LANE_OVERRIDES_ROW = "override:lane_not_touched"
ROOTS_AMBIGUOUS = "roots_ambiguous"
LANE_BOOK_ACCOUNT_MISSING = "lane_book_account_missing"
LANE_PROBE_REQUIRES_BIND = "lane_probe_requires_bind"
REGISTRY_UNREADABLE = "registry_unreadable"
# The periodic S7 A L3 publisher's per-lane heartbeat under the projection root. registry audit reports
# lane_lease_stale only while it exists, so the audit never pages before a periodic publisher runs.
LEASE_PUBLISHER_HEARTBEAT = "lease-publisher.heartbeat"
# A lane-assigned engine still listed in the owner probe-bindings file (a legacy bind from before S7 A).
LANE_ENGINE_OWNER_BOUND = "lane_engine_owner_bound"
DEFAULT_OWNER_OVERRIDES = "/etc/leafhft/kalshi-engine-account-overrides.json"
DEFAULT_OWNER_RUNS = "/var/lib/leafhft/runs"
DEFAULT_CORPUS = Path(__file__).resolve().parent.parent / "tests" / "fixtures" / "kalshi_edge_entry"
LANE_OVERRIDES_NAME = "engine-account-overrides.json"
# X1c: the identity files the books read their account id from (live-run.sh --dashboard-account-
# identity for the owner; account_lane_agent's paths.state / this name for a lane).
DEFAULT_OWNER_IDENTITY = "/var/lib/leafhft/dashboard-account.json"
LANE_IDENTITY_NAME = "dashboard-account-identity.json"
PROBE_HOSTS_NAME = "kalshi-probe-hosts"  # beside the probe bindings file, as live-run.sh reads $etc
MAX_PROBE_HOSTS_BYTES = 65536
BINDINGS_NEW_MODE = 0o644  # the books run as leafhft and must read every bindings file
BINDINGS_SNAPSHOTS = frozenset({"bindings", "probe_bindings"})
# C0's cfg.lifecycle_dir, the dir the books read (live-run.sh --lifecycle-dir); the pre-C0 default
# <engines-dir>/lifecycle is read only by `status`, never written.
DEFAULT_LIFECYCLE_DIR = "/var/lib/leafhft/engine-lifecycle"
LEGACY_LIFECYCLE_NAME = "lifecycle"
LIFECYCLE_FILE_MODE = 0o644  # the books run as leafhft and read and update every lifecycle record
MAX_LIFECYCLE_ENTRIES = 4096  # the hand-over walk refuses beyond this rather than run unbounded
EXIT_CLIENT_PREFIX = "lx-"  # the books' exit order client ids (kalshi_book); never an open ticket

OPS_LOCK_FILE = "engine-ops.lock"
OPS_JOURNAL_FILE = "engine-ops-journal.jsonl"
OPS_LOCK_TIMEOUT_S = 10.0
OPS_LOCK_POLL_S = 0.05
# C13 fix j: the per-engine activation lock (<registry-dir>/activation-<engine>.lock, never the OPS
# lock, which cmd_probe_activate already holds and which is not reentrant): bounded wait, then
# Refused activation_busy.
ACTIVATION_LOCK_TIMEOUT_S = 10.0
# C13 fix j: the refusal journal's two generations are read as one inode-validated snapshot at most
# this many times; a rotation during every attempt is evidence_unavailable, never a count.
REFUSAL_SNAPSHOT_ATTEMPTS = 3
REGISTRY_SUBJECT = "_registry"

MAX_APPROVAL_BYTES = 4096
MAX_REQUEST_BYTES = 256 * 1024
MAX_JOURNAL_ROW_BYTES = 4096
MAX_REQUESTS_SCANNED = 4096
MAX_OVERRIDES_BYTES = 65536
MAX_LIFECYCLE_BYTES = 1024 * 1024
MAX_REPORT_BYTES = 1024 * 1024
MAX_ACTIVATION_BYTES = 1024 * 1024
MAX_CONFORM_BYTES = 4096
MAX_MANIFEST_FILES = 256
MAX_STATUS_ENGINES = ENGINE_CATALOG_CAPACITY  # status lists at most the catalog capacity (1024) engine ids
MAX_CORPUS_FILES = 16
MAX_CORPUS_BYTES = 4 * 1024 * 1024
MAX_CORPUS_ROWS = 100_000
MAX_EVALUATE_LOOPS = 128
MAX_RECEIPT_SUFFIX = 100

SUPERSEDED_CODES = ("resume_superseded", "rollback_superseded")
# C6e: a rerun of one of these verbs never continues a half-landed transaction; `repair` settles it.
NO_RESUME_VERBS = ("probe", "release")
REPAIR_TERMINAL = {"finish": ("completed",), "rollback": ("rolled_back", "superseded")}

# The ladder, graduation and the judge (C13).
VERDICT_SCHEMA = "leafhft.engine_ops.verdict.v1"
OQ_SCHEMA = probe_bar.OQ_SCHEMA
OQ_MIN_FILLS = 20  # probe_bar.OperationalQualification's default attributed-fill floor
VENUE_FILE = probe_bar.VENUE_FILE  # the judge's venue reconciliation (probe_bar.reconcile_venue), the OQ venue side
MAX_VENUE_BYTES = probe_bar.MAX_VENUE_BYTES
FILLS_FILE = probe_bar.FILLS_FILE  # the attributed fills the OQ read was computed from
MAX_FILLS_BYTES = probe_bar.MAX_FILLS_BYTES
OQ_MAX_AGE = timedelta(hours=48)  # the ladder acts only on a qualification the judge renewed recently
OQ_WRITER = "engine_ops judge"
_OQ_WRITER = re.compile(r"engine_ops judge (?:[0-9a-f]{12}|unknown)")
ROWS_FILE = probe_bar.ROWS_FILE  # the judge's copy of the executor's staged venue rows and counters
MAX_ROWS_BYTES = probe_bar.MAX_ROWS_BYTES
OQ_FILE_MODE = 0o444
OQ_DIR_MODE = 0o755
# The tuning planner runs as leafhft and reads every engine receipt.
RECEIPT_DIR_MODE = 0o755
RECEIPT_FILE_MODE = 0o644
MAX_OQ_CHAIN = 16  # path components checked above the OQ directory
# TEST-ONLY: the owner uid the OQ evidence set must carry in place of root, for a dev host where the
# judge cannot run as root. Production never sets it (a test pins the default and every assignment).
_OQ_TEST_OWNER_UID: int | None = None
DECISIONS = ("PENDING", "GRADUATE_ELIGIBLE", "RETUNE", "KILL", "HOLD")
LADDER_BLOCKING = frozenset({"HOLD", "KILL", "RETUNE"})
VERDICTS_DIR = "verdicts"
MAX_VERDICT_BYTES = 64 * 1024
MAX_VERDICT_SCAN = 65536  # directory entries read to find the newest verdict (one a day)
MAX_OQ_BYTES = probe_bar.MAX_OQ_BYTES
MAX_OQ_PNL_ROWS = probe_bar.MAX_PNL_ROWS
MAX_JUDGE_ENGINES = ENGINE_CATALOG_CAPACITY  # judge --all reads at most 1024 engines (the catalog capacity)
VERDICT_MAX_AGE = timedelta(hours=48)  # graduate acts only on a fresh read
JUDGE_SCORER_TIMEOUT_S = 600.0
MAX_SCRIPT_STDERR = 2048
DEFAULT_AUTHORITY = "/var/lib/leafhft/kalshi-authority.json"
SCRIPTS_DIR = Path(__file__).resolve().parent.parent / "scripts"
KALSHI_TRIAL_SCRIPT = SCRIPTS_DIR / "kalshi_trial.py"
# Bound on executor.engines entries read per book status, the catalog capacity (1024 entries inside a
# status file already capped at kalshi_trial.MAX_STATUS_BYTES); a probe past it fails closed.
HOSTED_STATUS_MAX_ENGINES = ENGINE_CATALOG_CAPACITY
_VERDICT_FILE = re.compile(r"(\d{8}T\d{6}Z)(?:-(\d{1,2}))?\.json")

PROBE_SIZING = str(probe_bar.LADDER[0])
PROBE_STEPS = ("registry", "lifecycle", "trial", "overrides", "probe_bindings", "bindings", "approval")
PROBE_PRECONDITIONS = ("not_assigned_elsewhere", "identity_unique", "concurrent_probes_below_max",
                       "no_owner_policy_override", "feeds_live_provisioned",
                       "manifest_conformed_or_waived", "lifecycle_state_allows",
                       "domain_is_exposure_authority", "approval_valid", "book_flat")
LIFECYCLE_ALLOWS_PROBE = frozenset({"absent", "shadow", "halted"})
ENTRY_STATES = frozenset({"canary", "probe", "probe_sized", "graduated"})
INTEGRITY_CODES = ("kill_criterion", "risk_invariant", "attribution_gap", "data_integrity_failure",
                   "policy_changed", "account_attribution_gap")
ASSIGN_ROLES = ("legacy",)

_FILE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
_REASON = re.compile(r"[a-z][a-z0-9_]{0,63}")
RETIRE_DEFAULT_REASON = "operator_retired"  # retire's reason when the caller names none (the C12 phone row)
_HEX40 = re.compile(r"[0-9a-f]{40}")
_LANE = re.compile(r"[a-z0-9][a-z0-9-]{0,63}")
_AUTHORITY = re.compile(r"([A-Za-z0-9][A-Za-z0-9._:-]{0,63})=(.+)")


class Refused(Exception):
    """A named refusal: exit 2, never a partial write left behind."""

    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail


class _TransactionSuperseded(Refused):
    """C6d fix d: the assignment generation a probe transaction captured is no longer the one the
    registry holds for its engine (a release, or a release and a reprobe, happened meanwhile). The
    request writes and undoes nothing more, ends `superseded` (its id retired) and the audit names it."""


# ---------------------------------------------------------------- bounded, strict file primitives

def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode("ascii")


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in items:
        if key in out:
            raise ValueError(f"duplicate key {key!r}")
        out[key] = value
    return out


def _no_constant(token: str) -> Any:
    raise ValueError(f"non-finite number {token}")


def _strict_loads(data: bytes, code: str) -> Any:
    """Duplicate keys, NaN and Infinity refuse with `code`; never returns a half-understood value."""
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=_no_constant)
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise Refused(code, str(exc)[:200]) from exc


MAX_GUARDED_DIRS = 64
_GUARDED_DIRS: set[str] = set()  # approval-store directories whose files _read_store_file opens


def _guard_dirs(*directories: Path) -> None:
    """Route every later _read_bounded of a file directly inside one of `directories` through
    _read_store_file. Bounded: past MAX_GUARDED_DIRS the set restarts with these directories (the
    store in use re-registers on every approvals_dir() call, just before its reads)."""
    keys = {os.path.normcase(os.path.abspath(directory)) for directory in directories}
    if len(_GUARDED_DIRS | keys) > MAX_GUARDED_DIRS:
        _GUARDED_DIRS.clear()
    _GUARDED_DIRS.update(keys)


def _read_store_file(path: Path, limit: int) -> bytes | None:
    """An approval-store read that fails closed: open without following a final symlink
    (O_NOFOLLOW, O_NONBLOCK so a FIFO cannot hang it), then fstat the descriptor and lstat the
    path and refuse store_corrupt unless approve_presence.store_file_problem passes (the same
    regular file, not a symlink, a trusted owner, not group or other writable). None when absent."""
    flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
             | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_NOCTTY", 0))
    try:
        fd = os.open(path, flags)
    except OSError as exc:
        try:
            linked = os.lstat(path)
        except OSError:
            linked = None
        if linked is not None and stat.S_ISLNK(linked.st_mode):
            raise Refused("store_corrupt", f"{path} is a symlink") from None
        if isinstance(exc, FileNotFoundError):
            return None
        raise Refused("file_unreadable", f"{path}: {exc}") from exc
    try:
        opened = os.fstat(fd)
        try:
            linked = os.lstat(path)
        except OSError as exc:
            raise Refused("store_corrupt", f"{path} vanished after it was opened: {type(exc).__name__}") from None
        problem = approve_presence.store_file_problem(opened, linked)
        if problem is not None:
            raise Refused("store_corrupt", f"{path} {problem}")
        stream = os.fdopen(fd, "rb")
    except BaseException:
        os.close(fd)
        raise
    with stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise Refused("file_too_large", f"{path} exceeds {limit} bytes")
    return data


def _read_bounded(path: Path, limit: int) -> bytes | None:
    """At most `limit` bytes; None when absent; anything larger or unreadable refuses. A file
    directly inside a guarded approval store is read through _read_store_file instead."""
    if _GUARDED_DIRS and os.path.normcase(os.path.abspath(os.path.dirname(path))) in _GUARDED_DIRS:
        return _read_store_file(path, limit)
    try:
        with open(path, "rb") as stream:
            data = stream.read(limit + 1)
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise Refused("file_unreadable", f"{path}: {exc}") from exc
    if len(data) > limit:
        raise Refused("file_too_large", f"{path} exceeds {limit} bytes")
    return data


def _atomic_write(path: Path, data: bytes) -> None:
    """Sibling temp, fsync, atomic replace: a reader sees the old bytes or the new ones."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def _file_owner(path: Path) -> tuple[int, int, int] | None:
    """(permission bits, uid, gid) of an existing file; None when absent."""
    try:
        info = os.stat(path)
    except FileNotFoundError:
        return None
    return stat.S_IMODE(info.st_mode), info.st_uid, info.st_gid


def _write_bindings_file(path: Path, data: bytes) -> None:
    """_atomic_write for a file the books read: the replacement carries the existing file's mode
    and owner (a new file gets 0644 and its directory's owner), set on the temp BEFORE the atomic
    replace so no reader ever sees a 0600 root file. Fails closed: when the owner cannot be kept
    the temp is removed and the old file stands (bindings_owner_unpreserved)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    kept = _file_owner(path)
    if kept is None:
        directory = os.stat(path.parent)
        kept = (BINDINGS_NEW_MODE, directory.st_uid, directory.st_gid)
    mode, uid, gid = kept
    fd, temporary = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
            fchown = getattr(os, "fchown", None)
            if fchown is not None:
                opened = os.fstat(stream.fileno())
                if (opened.st_uid, opened.st_gid) != (uid, gid):
                    try:
                        fchown(stream.fileno(), uid, gid)
                    except OSError as exc:
                        raise Refused("bindings_owner_unpreserved",
                                      f"{path}: cannot keep owner {uid}:{gid}: {exc}") from None
            fchmod = getattr(os, "fchmod", None)
            if fchmod is not None and os.name == "posix":
                fchmod(stream.fileno(), mode)  # after chown, which may clear setuid/setgid bits
            else:
                os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def _directory_owner(path: Path) -> tuple[int, int] | None:
    """(uid, gid) of an existing directory; None when absent."""
    try:
        info = os.stat(path)
    except FileNotFoundError:
        return None
    return info.st_uid, info.st_gid


def _lifecycle_entries(root: Path) -> Iterable[tuple[str, bool, Callable[[int], int]]]:
    """(relative path, is directory, opener taking the open flags) for every entry below `root`.
    POSIX walks by directory fd (os.fwalk, never following a symlink), so a path component swapped
    for a link between the listing and the open cannot redirect a root-owned change. Elsewhere only
    files are listed: directories there carry no POSIX owner."""
    fwalk = getattr(os, "fwalk", None)
    if fwalk is not None:
        for directory, dirnames, filenames, dir_fd in fwalk(root, follow_symlinks=False):
            relative = os.path.relpath(directory, root)
            for names, is_dir in ((dirnames, True), (filenames, False)):
                for name in names:
                    yield (os.path.normpath(os.path.join(relative, name)), is_dir,
                           lambda flags, name=name, dir_fd=dir_fd: os.open(name, flags, dir_fd=dir_fd))
        return
    for directory, _, filenames in os.walk(root):
        relative = os.path.relpath(directory, root)
        for name in filenames:
            path = os.path.join(directory, name)
            yield os.path.normpath(os.path.join(relative, name)), False, lambda flags, path=path: os.open(path, flags)


@contextmanager
def _born_as(directory: Path, osl: Any = os):
    """Every lifecycle write engine_ops makes runs inside this (C6d fix b, astra P2): on POSIX the
    effective gid then uid switch to the lifecycle directory's owner and the umask to 0o022 for the
    block, so a record is created by its final owner and no book (user leafhft) ever meets a root
    0600 record, even mid-verb or after a crash. The finally restores the uid, the gid, then the
    umask. A no-op off POSIX or when the directory does not exist yet; only the umask moves when the
    process already runs as the owner or is not root (only root can write as another user, and the
    hand-over walk still covers that case). `osl` is the os layer (a test seam). Refuses
    `lifecycle_owner_unpreserved` when the switch is not permitted."""
    names = ("stat", "geteuid", "getegid", "setegid", "seteuid", "umask")
    if getattr(osl, "name", None) != "posix" or not all(hasattr(osl, name) for name in names):
        yield
        return
    try:
        info = osl.stat(directory)
    except FileNotFoundError:
        info = None
    if info is None:
        yield
        return
    uid, gid = info.st_uid, info.st_gid
    euid, egid = osl.geteuid(), osl.getegid()
    switched: list[tuple[Callable[[int], None], int]] = []
    mask = osl.umask(0o022)
    try:
        try:
            if euid == 0 and egid != gid:  # the gid first: once the uid leaves root it cannot move
                osl.setegid(gid)
                switched.append((osl.setegid, egid))
            if euid == 0 and euid != uid:
                osl.seteuid(uid)
                switched.append((osl.seteuid, euid))
        except OSError as exc:
            raise Refused("lifecycle_owner_unpreserved",
                          f"{directory}: cannot write as {uid}:{gid}: {exc}") from None
        yield
    finally:
        for restore, value in reversed(switched):
            restore(value)
        osl.umask(mask)


def _lifecycle_readable(path: Path) -> None:
    """Inside _born_as, after a record write: the record is the owner's, so the owner sets 0644
    (CanaryStore's temp file is created 0600 whatever the umask). Bytes are never touched."""
    if os.name != "posix":
        return
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0))
    except FileNotFoundError:
        return
    try:
        if stat.S_ISREG(os.fstat(fd).st_mode):
            os.fchmod(fd, LIFECYCLE_FILE_MODE)
    finally:
        os.close(fd)


def _hand_lifecycle_to_owner(root: Path) -> list[str]:
    """Hand every entry below the lifecycle dir that another user owns (root, running engine_ops)
    to the directory's owner, files at 0644, so the book (user leafhft) can read and update what
    engine_ops wrote. Each entry is opened O_NOFOLLOW and changed through its fd; symlinks and
    special files are skipped. Bounded at MAX_LIFECYCLE_ENTRIES; refuses
    `lifecycle_owner_unpreserved` when an owner cannot be set. Returns the relative paths handed."""
    fchown = getattr(os, "fchown", None)
    owner = _directory_owner(root)
    if fchown is None or owner is None:
        return []  # no POSIX owners on this platform, or nothing written yet
    uid, gid = owner
    base = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    handed: list[str] = []
    for count, (relative, is_dir, opener) in enumerate(_lifecycle_entries(root), 1):
        if count > MAX_LIFECYCLE_ENTRIES:
            raise Refused("lifecycle_dir_too_large", f"{root} holds more than {MAX_LIFECYCLE_ENTRIES} entries")
        flags = base | (getattr(os, "O_DIRECTORY", 0) if is_dir else getattr(os, "O_NONBLOCK", 0))
        try:
            fd = opener(flags)
        except OSError as exc:
            if exc.errno in (errno.ELOOP, errno.ENOENT, errno.ENOTDIR, errno.ENXIO):
                continue  # a symlink, or gone since the listing
            raise Refused("lifecycle_owner_unpreserved", f"{root / relative}: {exc}") from None
        try:
            info = os.fstat(fd)
            wanted = stat.S_ISDIR(info.st_mode) if is_dir else stat.S_ISREG(info.st_mode)
            if not wanted or (info.st_uid, info.st_gid) == (uid, gid):
                continue
            try:
                fchown(fd, uid, gid)
                if not is_dir and os.name == "posix":
                    os.fchmod(fd, LIFECYCLE_FILE_MODE)  # after chown, which may clear mode bits
            except OSError as exc:
                raise Refused("lifecycle_owner_unpreserved",
                              f"{root / relative}: cannot hand to {uid}:{gid}: {exc}") from None
            handed.append(relative.replace(os.sep, "/"))
        finally:
            os.close(fd)
    return handed


def _write_all(fd: int, data: bytes) -> None:
    view = memoryview(data)
    while view:
        written = os.write(fd, view)
        view = view[written:]
    os.fsync(fd)


def _create_exclusive(path: Path, data: bytes) -> bool:
    """Create `path` with `data` only if it does not exist; False when it already does."""
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0)
    try:
        fd = os.open(path, flags, 0o644)
    except FileExistsError:
        return False
    try:
        _write_all(fd, data)
    finally:
        os.close(fd)
    return True


def _publish_receipt_modes(path: Path) -> None:
    """Widen only the receipt, its receipts directory and the engine directory. The evidence root
    is host provisioning (0755 root on the runner) and is never changed here; a root the planner
    cannot traverse makes it refuse the plan, which is the fail-closed outcome."""
    if os.name != "posix":
        return
    for target, mode in ((path, RECEIPT_FILE_MODE),
                         (path.parent, RECEIPT_DIR_MODE),
                         (path.parent.parent, RECEIPT_DIR_MODE)):
        try:
            os.chmod(target, mode)
        except OSError:
            # The recorded action has happened; the planner fails closed if unreadable.
            pass


def _append_line(path: Path, row: Mapping[str, Any]) -> None:
    line = _canonical(row) + b"\n"
    if len(line) > MAX_JOURNAL_ROW_BYTES:
        raise Refused("journal_row_too_large", str(len(line)))
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_BINARY", 0), 0o644)
    try:
        _write_all(fd, line)
    finally:
        os.close(fd)


def _lock_handle(handle) -> None:
    if os.name == "nt":
        import msvcrt
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)


def _unlock_handle(handle) -> None:
    if os.name == "nt":
        import msvcrt
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
    else:
        import fcntl
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


@contextmanager
def _exclusive_lock(path: Path, timeout_s: float):
    """OS lock on a dedicated file, bounded wait; the kernel drops a dead holder's lock."""
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = open(path, "a+b")
    try:
        if handle.seek(0, os.SEEK_END) == 0:
            handle.write(b"\0")
            handle.flush()
        deadline = time.monotonic() + timeout_s
        while True:
            try:
                _lock_handle(handle)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise Refused("ops_busy", "another engine_ops writer holds the lock") from None
                time.sleep(OPS_LOCK_POLL_S)
        try:
            yield
        finally:
            _unlock_handle(handle)
    finally:
        handle.close()


# ---------------------------------------------------------------- argument validators

def _engine_id(value: Any) -> str:
    if type(value) is not str or not ENGINE_ID_RE.fullmatch(value):
        raise Refused("invalid_engine_id", repr(value)[:64])
    return value


def _file_id(value: Any, name: str) -> str:
    if type(value) is not str or not _FILE_ID.fullmatch(value):
        raise Refused(f"invalid_{name}", f"{name} must match {_FILE_ID.pattern}")
    return value


def _symbols(value: Any) -> list[str]:
    if type(value) is not str:
        raise Refused("invalid_symbols", "a comma separated symbol list is required")
    return er.normalize_symbols([item.strip() for item in value.split(",") if item.strip()])


def _utc_time(value: Any) -> datetime | None:
    if type(value) is not str or not 0 < len(value) <= 64:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed.astimezone(timezone.utc) if parsed.tzinfo is not None else None


def _decimal_text(value: float, maximum: str) -> str:
    """Two-place decimal string, rounded down and clamped to 0..maximum (never a JSON float)."""
    try:
        number = Decimal(repr(float(value))).quantize(Decimal("0.01"), rounding=ROUND_DOWN)
    except (InvalidOperation, ValueError, OverflowError) as exc:
        raise Refused("invalid_value", repr(value)) from exc
    if not number.is_finite():
        raise Refused("invalid_value", repr(value))
    return str(max(Decimal(0), min(Decimal(maximum), number)))


def approval_digest(kind: str, engine_id: str | None, account: str, symbols: Iterable[str],
                    sizing: str, expires_at: str) -> str:
    """sha256 over canonical {kind, engine_id, account, symbols (sorted), sizing, expires_at}.

    The signer (the control applier or `engine_ops approve`) writes this digest into the approval;
    a verb recomputes it from its OWN arguments, so an approval authorizes exactly one action."""
    return _sha(_canonical({"kind": kind, "engine_id": engine_id, "account": account,
                            "symbols": sorted(symbols), "sizing": sizing, "expires_at": expires_at}))


# ---------------------------------------------------------------- the operations context

class _OpsCanaryStore(CanaryStore):
    """Keep provenance of this invocation's writes, captured under the store lock."""

    def __init__(self, directory: Path) -> None:
        super().__init__(directory)
        self.written_digests: dict[str, str] = {}

    def _write(self, record):
        super()._write(record)
        # CanaryStore writes these canonical bytes, including its new revision and digest.
        # Never reread the path here: a later writer's bytes are not ours to roll back.
        self.written_digests[record["engine_id"]] = _sha(_canonical(record))


def _wall_now() -> datetime:
    return datetime.now(timezone.utc)


class Ops:
    """Paths and stores for one invocation; a fixed run time and advancing judge clock.
    Constructing it performs no I/O."""

    def __init__(self, args: argparse.Namespace, now: datetime | None) -> None:
        self.engines_dir = Path(args.engines_dir)
        self.bindings = Path(args.bindings) if args.bindings else None
        self.probe_bindings = Path(getattr(args, "probe_bindings", None) or DEFAULT_PROBE_BINDINGS)
        self.registry_dir = Path(args.registry_dir)
        approvals = getattr(args, "approvals_dir", None)
        if approvals:
            self.approvals_path = Path(approvals)
        elif Path(args.registry_dir) == Path(DEFAULT_REGISTRY_DIR):
            self.approvals_path = Path(DEFAULT_APPROVALS_DIR)
        else:
            self.approvals_path = self.registry_dir / "approvals"
        self.manifests_dir = Path(args.manifests_dir)
        self.evidence_dir = Path(args.evidence_dir)
        default_evidence = self.evidence_dir == Path(DEFAULT_EVIDENCE_DIR)
        oq_dir, venue_dir = getattr(args, "oq_dir", None), getattr(args, "venue_dir", None)
        self.oq_dir = (Path(oq_dir) if oq_dir else Path(DEFAULT_OQ_DIR) if default_evidence
                       else self.evidence_dir.parent / "engine-oq")
        self.venue_dir = (Path(venue_dir) if venue_dir else Path(DEFAULT_VENUE_DIR) if default_evidence
                          else self.evidence_dir.parent / "engine-venue")
        self.trials_dir = Path(args.trials_dir)
        self.lanes_root = Path(args.lanes_root)
        # S7 A L2: the lane identity and projection roots NEVER derive from the lanes root. Defaults are
        # the root-owned trees, unconditionally; a non-default lanes root without both roots named, or a
        # root at or under the lanes root, is roots_ambiguous, raised at first use and before any read
        # (so owner verbs that touch no lane keep working on a scratch lanes root).
        identity_root = getattr(args, "lane_identity_root", None)
        projection_root = getattr(args, "projection_root", None)
        self._lane_identity_root = Path(identity_root or DEFAULT_LANE_IDENTITY_ROOT)
        self._projection_root = Path(projection_root or DEFAULT_PROJECTION_ROOT)
        self.roots_problem = _roots_problem(self.lanes_root, identity_root, projection_root)
        self.lease_notes: list[str] = []
        self.owner_overrides = Path(args.owner_overrides)
        self.owner_runs = Path(args.owner_runs)
        self.authority = Path(getattr(args, "authority_path", None) or DEFAULT_AUTHORITY)
        refusals = getattr(args, "refusal_journal", None)
        self.refusal_journal = Path(refusals) if refusals else None
        template = getattr(args, "book_unit_template", None)
        self.book_unit_template = template if type(template) is str and template else None
        self.owner_identity = Path(getattr(args, "owner_identity", None) or DEFAULT_OWNER_IDENTITY)
        self.book_id_problems: dict[str, str] = {}
        self.lifecycle_arg = args.lifecycle_dir
        self.json = bool(args.json)
        moment = _wall_now() if now is None else now
        if not isinstance(moment, datetime) or moment.tzinfo is None:
            raise Refused("invalid_time", "a timezone-aware clock is required")
        self.now = moment.astimezone(timezone.utc)
        self.run_now = self.now
        self._now_injected = now is not None
        self._canary: _OpsCanaryStore | None = None
        self._legacy_canary: CanaryStore | None = None
        self._requests: list[dict[str, Any]] | None = None
        self.warnings: list[str] = []

    def advance_clock(self) -> datetime:
        """Advance the judge's engine clock monotonically; injected clocks stay fixed.
        A naive or non-datetime wall read keeps the current clock (fails closed)."""
        if not self._now_injected:
            moment = _wall_now()
            if isinstance(moment, datetime) and moment.tzinfo is not None:
                moment = moment.astimezone(timezone.utc)
                if moment > self.now:
                    self.now = moment
        return self.now

    # stores ------------------------------------------------------------------------------------

    @property
    def lifecycle_dir(self) -> Path:
        """--lifecycle-dir, then $LEAFHFT_LIFECYCLE_DIR, then the books' DEFAULT_LIFECYCLE_DIR."""
        return lifecycle_directory(self.engines_dir, self.lifecycle_arg or os.environ.get(LIFECYCLE_DIR_ENV)
                                   or DEFAULT_LIFECYCLE_DIR)

    @property
    def legacy_lifecycle_dir(self) -> Path | None:
        """The pre-C0 default <engines-dir>/lifecycle, or None when it is the lifecycle dir itself."""
        legacy = self.engines_dir / LEGACY_LIFECYCLE_NAME
        same = os.path.normcase(os.path.abspath(legacy)) == os.path.normcase(os.path.abspath(self.lifecycle_dir))
        return None if same else legacy

    def staging_path(self, engine_id: str, symbol: str | None = None) -> Path:
        """<evidence-dir>/<engine_id>/staging/<symbol>: one hosting book's probe executor counters,
        where that book's host wires its ProbeExecutor (probe_bar.staging_directory over the same
        evidence root); without `symbol`, the engine's staging root."""
        return probe_bar.staging_directory(self.evidence_dir, engine_id, symbol)

    def canary(self) -> _OpsCanaryStore:
        if self._canary is None:
            self._canary = _OpsCanaryStore(self.lifecycle_dir)
        return self._canary

    def legacy_lifecycle(self, engine_id: str) -> dict[str, Any] | None:
        """Read-only (status): the engine's record in the legacy dir; None when absent or unreadable."""
        legacy = self.legacy_lifecycle_dir
        if legacy is None:
            return None
        if self._legacy_canary is None:
            self._legacy_canary = CanaryStore(legacy)
        try:
            return self._legacy_canary.optional(engine_id)
        except CanaryError:
            return None

    def hand_lifecycle(self, *, quiet: bool = False) -> None:
        """After a verb that opened the lifecycle store, every entry root wrote there goes to the
        directory's owner (0644 files), so the book can read and update it. `quiet` (a failed
        verb) swallows a hand-over failure so the verb's own error stands."""
        if self._canary is None:
            return
        try:
            _hand_lifecycle_to_owner(self.lifecycle_dir)
        except (Refused, OSError):
            if not quiet:
                raise

    def registry_store(self) -> er.RegistryStore:
        """Every commit through this store stamps the book ids derived at that moment (X1c)."""
        return er.RegistryStore(self.registry_dir, book_account_ids=self.book_account_ids)

    @property
    def lane_identity_root(self) -> Path:
        """Root-owned `<root>/<lane>/dashboard-account-identity.json`; Refused(roots_ambiguous)
        instead of any path when the roots are ambiguous (S7 A L2)."""
        if self.roots_problem is not None:
            raise Refused(ROOTS_AMBIGUOUS, self.roots_problem)
        return self._lane_identity_root

    @property
    def projection_root(self) -> Path:
        """Root-owned `<root>/<lane>/lifecycle-lease.json` and probe bindings; Refused(roots_ambiguous)
        when the roots are ambiguous (S7 A L2)."""
        if self.roots_problem is not None:
            raise Refused(ROOTS_AMBIGUOUS, self.roots_problem)
        return self._projection_root

    def identity_path(self, account: Mapping[str, Any]) -> Path | None:
        """The identity file the account's books read their account id from; None for a lane id
        that is not a lane id. A lane's is `<lane-identity-root>/<lane>/`, root-owned (S7 A L2);
        Refused(roots_ambiguous) when that root is ambiguous, never a lanes-root path."""
        lane = account.get("lane_id")
        if lane is None:
            return self.owner_identity
        if type(lane) is not str or not _LANE.fullmatch(lane):
            return None
        return self.lane_identity_root / lane / LANE_IDENTITY_NAME

    def book_account_ids(self, accounts: Mapping[str, Mapping[str, Any]]) -> dict[str, str | None]:
        """{account key: the id its books pass the gate, or None}; bounded (<= MAX_ACCOUNTS small
        reads), offline, never raises. Each None records its reason in `book_id_problems`."""
        ids: dict[str, str | None] = {}
        for aid, account in list(accounts.items())[:er.MAX_ACCOUNTS]:
            try:
                path = self.identity_path(account)
            except Refused as exc:  # roots_ambiguous: nothing is read
                ids[aid] = None
                self.book_id_problems[aid] = exc.code
                continue
            ids[aid], problem = (None, "lane_id_invalid") if path is None else book_account_id(path)
            if problem is None:
                self.book_id_problems.pop(aid, None)
            else:
                self.book_id_problems[aid] = problem
        return ids

    def registry_optional(self) -> er.Registry | None:
        return self.registry_store().load()

    def registry(self) -> er.Registry:
        registry = self.registry_optional()
        if registry is None:
            raise Refused("registry_absent", "run registry init --apply first")
        return registry

    def trials(self) -> TrialStore:
        return TrialStore(self.trials_dir)

    def catalog(self) -> EngineRegistry:
        return EngineRegistry(self.engines_dir)

    def catalog_engine(self, engine_id: str):
        try:
            return self.catalog().get(engine_id)
        except EngineError:
            return None

    def sources(self) -> list[er.AccountSource]:
        if self.bindings is None:
            return []
        if _read_bounded(self.bindings, er.MAX_SOURCES_BYTES) is None:
            raise Refused("bindings_absent", f"{self.bindings} does not exist")
        return er.load_sources(self.bindings)

    def source_for(self, account_id: str) -> er.AccountSource:
        for source in self.sources():
            if source.account_id == account_id:
                return source
        raise Refused("bindings_unknown", f"no bindings file is named for account {account_id!r}")

    def overrides_path(self, account: Mapping[str, Any]) -> Path | None:
        """The owner overrides file; None for a lane (S7 A L2: a lane's overrides file is
        tenant-writable and engine_ops never opens it)."""
        return self.owner_overrides if account.get("lane_id") is None else None

    def runs_root(self, account: Mapping[str, Any]) -> Path:
        """The owner books' runs root. A lane's runs are tenant-writable: refuses
        tenant_evidence_deferred rather than return a path under the lanes root (S7 A L2)."""
        if account.get("lane_id") is not None:
            raise Refused(TENANT_EVIDENCE_DEFERRED, "a lane's runs are tenant-writable; engine_ops never reads them")
        return self.owner_runs

    # manifests ---------------------------------------------------------------------------------

    def manifest_path(self, engine_id: str) -> Path:
        return self.manifests_dir / f"{_engine_id(engine_id)}.json"

    def manifest(self, engine_id: str):
        """(manifest, None) or (None, reason code); never raises for a bad file."""
        path = self.manifest_path(engine_id)
        if not path.exists():
            return None, "manifest_missing"
        try:
            return load_manifest(path), None
        except ManifestInvalid as exc:
            return None, exc.code

    def conform_record(self, engine_id: str) -> dict[str, Any] | None:
        data = _read_bounded(self.evidence_dir / engine_id / "conform.json", MAX_CONFORM_BYTES)
        if data is None:
            return None
        try:
            record = _strict_loads(data, "conform_invalid")
        except Refused:
            return None
        return record if isinstance(record, dict) and record.get("schema") == CONFORM_SCHEMA else None

    # requests, journal, receipts ------------------------------------------------------------------

    def request_dir(self, request_id: str) -> Path:
        return self.registry_dir / "requests" / _file_id(request_id, "request_id")

    def load_request(self, request_id: str) -> dict[str, Any] | None:
        data = _read_bounded(self.request_dir(request_id) / "request.json", MAX_REQUEST_BYTES)
        if data is None:
            return None
        record = _strict_loads(data, "request_invalid")
        if not isinstance(record, dict) or record.get("schema") != REQUEST_SCHEMA:
            raise Refused("request_invalid", request_id)
        return record

    def save_request(self, record: Mapping[str, Any]) -> None:
        data = _canonical(record)
        if len(data) > MAX_REQUEST_BYTES:
            raise Refused("request_too_large", record["request_id"])
        _atomic_write(self.request_dir(record["request_id"]) / "request.json", data)
        self._requests = None

    def requests(self) -> list[dict[str, Any]]:
        """Every readable request record, bounded; unreadable ones are skipped (audit names them)."""
        if self._requests is not None:
            return self._requests
        root = self.registry_dir / "requests"
        records: list[dict[str, Any]] = []
        try:
            with os.scandir(root) as iterator:
                entries = sorted((entry.name for entry in iterator if entry.is_dir()))
        except OSError:
            entries = []
        for name in entries[:MAX_REQUESTS_SCANNED]:
            if not _FILE_ID.fullmatch(name):
                continue
            try:
                record = self.load_request(name)
            except Refused:
                record = {"schema": REQUEST_SCHEMA, "request_id": name, "state": "unreadable",
                          "verb": None, "subject": None, "steps": [], "context": {},
                          "requested_at": None}
            if record is not None:
                records.append(record)
        self._requests = records
        return records

    def journal(self, verb: str, subject: str, request_id: str, event: str, **extra: Any) -> None:
        _append_line(self.registry_dir / OPS_JOURNAL_FILE,
                     {"at": self.now.isoformat(), "verb": verb, "subject": subject,
                      "request_id": request_id, "event": event, **extra})

    def write_receipt(self, subject: str, verb: str, body: Mapping[str, Any]) -> dict[str, str]:
        data = _canonical(body)
        directory = self.evidence_dir / subject / "receipts"
        base = f"{self.now:%Y%m%dT%H%M%SZ}-{verb}"
        for index in range(MAX_RECEIPT_SUFFIX):
            path = directory / (base + ("" if index == 0 else f"-{index}") + ".json")
            if _create_exclusive(path, data):
                _publish_receipt_modes(path)
                digest = _sha(data)
                return {"sha12": digest[:12], "sha256": digest, "path": str(path)}
        raise Refused("receipt_slots_exhausted", str(directory))

    def mutate(self, verb: str, subject: str, request_id: Any, args: Mapping[str, Any],
               perform: Callable[[dict[str, Any]], dict[str, Any]]) -> tuple[dict[str, str], dict, bool]:
        """Run one idempotent mutating verb. Returns (receipt, result, replayed)."""
        rid = _file_id(request_id, "request_id")
        digest = _sha(_canonical({"verb": verb, "subject": subject, "args": args}))
        with _exclusive_lock(self.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
            lanes = self.subject_lanes(subject)
            record = self.load_request(rid)
            if record is not None:
                if record.get("args_digest") != digest:
                    raise Refused("request_id_reused", f"{rid} was used for a different {record.get('verb')}")
                if record.get("state") == "completed":
                    self.publish_leases(lanes | _context_lane(record))
                    return record["receipt"], record["result"], True
                if record.get("state") == "superseded":  # C6d fix d: a superseded id is retired
                    superseded = (record.get("context") or {}).get("superseded") or {}
                    code = superseded.get("code")
                    raise Refused(code if code in SUPERSEDED_CODES else "resume_superseded",
                                  f"request {rid} was superseded by {superseded.get('by')!r} at "
                                  f"{superseded.get('step')!r}; its id is retired, use a new --request-id")
                if verb in NO_RESUME_VERBS and _interrupted(record):
                    # C6e: never continue a half-landed probe or release; nothing is written here.
                    raise Refused("transaction_interrupted", _interrupted_detail(record))
                if record.get("state") in ("refused", "rolled_back") or (
                        verb in NO_RESUME_VERBS and record.get("state") == "started"):
                    # Nothing of the earlier attempt stands (a started probe or release here wrote
                    # nothing outside the request dir): evaluate it afresh under the same id.
                    record.update(steps=[], context={}, result=None, receipt=None)
            else:
                record = {"schema": REQUEST_SCHEMA, "request_id": rid, "verb": verb, "subject": subject,
                          "args": dict(args), "args_digest": digest, "state": "started",
                          "requested_at": self.now.isoformat(), "steps": [], "context": {},
                          "result": None, "receipt": None}
            record["state"] = "started"
            self.save_request(record)
            self.journal(verb, subject, rid, "started")
            perform_failed = True
            try:
                try:
                    result = perform(record)
                    perform_failed = False
                finally:
                    if perform_failed and (record["steps"] or record["context"].get("current_step")
                                           or record["context"].get("rollback")):
                        # Publish before failure bookkeeping: even hand-over, request or journal
                        # errors must not leave a landed halt granting until the lease expires.
                        self.publish_leases(lanes | _context_lane(record))  # never raises
            except BaseException as exc:
                bookkeeping_errors = list(record["context"].get("bookkeeping_errors") or [])
                try:
                    self.hand_lifecycle()  # a rollback rewrites lifecycle records too
                except Exception as error:
                    bookkeeping_errors.append(f"hand_lifecycle: {type(error).__name__}: {error}"[:300])
                # Each step is one atomic write, so a failure with no completed step wrote nothing;
                # a probe that did write has already rolled back and says so in its state.
                if (record["state"] == "started" and not record["steps"]
                        and not record["context"].get("rollback_errors")):
                    record["state"] = "refused"
                    record["context"].pop("current_step", None)
                try:
                    self.save_request(record)
                except Exception as error:
                    bookkeeping_errors.append(f"save_request: {type(error).__name__}: {error}"[:300])
                code = getattr(exc, "code", type(exc).__name__)
                try:
                    self.journal(verb, subject, rid, record["state"], code=code,
                                 **({"bookkeeping_errors": bookkeeping_errors} if bookkeeping_errors else {}))
                except Exception as error:
                    bookkeeping_errors.append(f"journal: {type(error).__name__}: {error}"[:300])
                    try:  # a transient journal failure may still be reportable
                        self.journal(verb, subject, rid, "bookkeeping_failed", code=code,
                                     bookkeeping_errors=bookkeeping_errors)
                    except Exception:
                        pass
                for error in bookkeeping_errors:
                    print(f"warning: failure bookkeeping: {error}", file=sys.stderr)
                raise
            # A hand-over failure leaves the request started with its steps done; a rerun of the
            # same id skips every step and hands over again, except for probe and release, where
            # `engine_ops repair <rid> --finish` completes it (C6e).
            try:
                receipt = self.complete(record, result)
            finally:  # a failed hand-over still leaves the verb's writes standing: publish either way
                self.publish_leases(lanes | _context_lane(record))  # still under the ops lock
            return receipt, result, False

    # S7 A L2: the lane lease tail ------------------------------------------------------------------

    def subject_lanes(self, subject: str) -> set[str]:
        """The lane account keys a verb on `subject` concerns: the lane account its registry
        assignment names, read ONCE per verb before it acts (a probe adds its lane through its
        request context, a release or retire keeps the assignment it removes). Kill-switch latency
        contract: one lock-free, read-only registry snapshot (load without publication repair), so a
        halt, retire or release never waits on the registry lock and never writes a registry file;
        only a lane-assigned subject then takes the lock, for its lease publish. Registry only
        (root-owned); never raises, an unreadable registry concerns no lane."""
        if type(subject) is not str or not ENGINE_ID_RE.fullmatch(subject):
            return set()
        try:
            registry = self.registry_store().load(complete_publication=False)
        except Exception:
            return self._leased_lane_of_record(subject)
        if registry is None:
            return set()
        lane = _engine_lane(registry, subject)
        return set() if lane is None else {lane}

    def _leased_lane_of_record(self, subject: str) -> set[str]:
        """With the registry unreadable: the canonical record's account key when a lease is published
        for it (so the verb still prints pending(registry_unreadable)); owner store and projection root
        only. Never raises."""
        try:
            record = self.canary().optional(subject)
        except Exception:
            return set()
        key = None if record is None else record.get("account_id")
        if type(key) is not str or not _LANE.fullmatch(key) or _published_lease(self, key) is None:
            return set()
        return {key}

    def publish_leases(self, keys: Iterable[str]) -> None:
        """The lease tail, on every exit path of a verb that may have changed a lane-assigned record:
        rebuild and publish each lane's lease from one registry snapshot and the canonical records.
        Never raises and never changes the verb's exit code; each lane adds one
        `lease: published|pending(<code>); tenant_effective_by=<iso>` note (printed by `main`)."""
        for key in sorted(keys):
            try:
                note = _publish_lane(self, key)
            except Exception as exc:  # defense in depth: _publish_lane already never raises
                try:
                    previous = _published_lease(self, key) if type(key) is str else None
                except Exception:
                    previous = None
                code = getattr(exc, "code", None)
                note = _pending_note(code if type(code) is str else type(exc).__name__, previous)
            self.lease_notes.append(note)

    def flush_lease_notes(self) -> None:
        """Print the lease notes not yet printed (stdout, after the verb's own lines)."""
        notes, self.lease_notes = self.lease_notes, []
        for note in notes:
            print(note)

    def complete(self, record: dict[str, Any], result: Mapping[str, Any]) -> dict[str, str]:
        """The completion tail `mutate` and `repair --finish` share: hand the lifecycle over, write
        the verb's receipt, end the request `completed` and journal it. Returns the receipt."""
        verb, subject, rid = record["verb"], record["subject"], record["request_id"]
        self.hand_lifecycle()
        if verb == "probe" and _context_lane(record):
            # Completing the request newly permits a tenant grant. Persist the current
            # record unchanged so that grant has a newer store revision, even after an
            # interrupted probe already published a restrictive lease of all its writes.
            canary = self.canary()
            data = _read_bounded(canary.path_for(subject), MAX_LIFECYCLE_BYTES)
            if data is None:
                raise Refused("restore_conflict", "tenant probe lifecycle record is absent")
            with _born_as(self.lifecycle_dir):
                canary.restore_record(subject, data, expected_digest=_sha(data))
                _lifecycle_readable(canary.path_for(subject))
            _record_written(self, record, "lifecycle", canary.path_for(subject))
        receipt = self.write_receipt(subject, verb, {
            "schema": RECEIPT_SCHEMA, "verb": verb, "subject": subject, "request_id": rid,
            "at": self.now.isoformat(), "args": dict(record["args"]), "steps": list(record["steps"]),
            "result": result})
        record.update(state="completed", result=result, receipt=receipt)
        record["context"].pop("current_step", None)
        self.save_request(record)
        self.journal(verb, subject, rid, "completed", receipt=receipt["sha12"])
        return receipt

    def begin(self, record: dict[str, Any], step: str) -> bool:
        """True when `step` must still run; marks it in flight so a rollback includes it."""
        if step in record["steps"]:
            return False
        record["context"]["current_step"] = step
        self.save_request(record)
        return True

    def done(self, record: dict[str, Any], step: str) -> None:
        record["steps"].append(step)
        record["context"].pop("current_step", None)
        self.save_request(record)

    def snapshot(self, record: dict[str, Any], name: str, path: Path, limit: int) -> dict[str, Any]:
        """Save the bytes of `path` (or its absence) once per request, before the first write."""
        snapshots = record["context"].setdefault("snapshots", {})
        if name in snapshots:
            return snapshots[name]
        data = _read_bounded(path, limit)
        if data is not None:
            _atomic_write(self.request_dir(record["request_id"]) / f"{name}.bin", data)
        snapshots[name] = {"path": str(path), "existed": data is not None,
                           "sha256": None if data is None else _sha(data)}
        self.save_request(record)
        return snapshots[name]

    def restore(self, record: Mapping[str, Any], name: str) -> None:
        """Restore a snapshot (or its absence); lifecycle restores advance the store revision.
        The store checks this request's exact write under its lock before restoring."""
        meta = record["context"]["snapshots"][name]
        path = Path(meta["path"])
        data = None
        if meta["existed"]:
            data = _read_bounded(self.request_dir(record["request_id"]) / f"{name}.bin", MAX_LIFECYCLE_BYTES)
            if data is None or _sha(data) != meta["sha256"]:
                raise Refused("snapshot_damaged", f"{record['request_id']}/{name}")
        if name == "lifecycle":
            context = record["context"]
            if "lifecycle_after_sha256" not in context:
                raise Refused("restore_conflict", "this request's lifecycle write was not captured")
            canary = self.canary()
            with _born_as(self.lifecycle_dir):
                canary.restore_record(record["subject"], data,
                                      expected_digest=context["lifecycle_after_sha256"])
                if data is not None:
                    _lifecycle_readable(canary.path_for(record["subject"]))
            return
        if data is None:
            path.unlink(missing_ok=True)
            return
        (_write_bindings_file if name in BINDINGS_SNAPSHOTS else _atomic_write)(path, data)

    # approvals ---------------------------------------------------------------------------------

    def approvals_dir(self) -> Path:
        """The approval store, checked on every call: on POSIX each path component up to / must be
        root- or euid-owned, not a symlink and not group or other writable (root sticky dirs
        excepted), and the resolved path must be the configured one, else approval_store_insecure.
        It then guards the store and its approve-requests directory, so every file read there is
        opened without following a symlink and fstat checked (_read_store_file, store_corrupt). The
        consumer reaches the store only through here, so both checks cover minting and consuming."""
        try:
            approve_presence.check_store_chain(self.approvals_path)
        except approve_presence.StoreInsecure as exc:
            raise Refused("approval_store_insecure", str(exc)) from None
        _guard_dirs(self.approvals_path, self.approvals_path / APPROVE_REQUESTS_DIR)
        return self.approvals_path

    def load_approval(self, approval_id: str) -> dict[str, Any]:
        path = self.approvals_dir() / f"{_file_id(approval_id, 'approval')}.json"
        try:
            data = _read_bounded(path, MAX_APPROVAL_BYTES)
        except Refused as exc:
            raise Refused("approval_valid", exc.detail) from exc
        if data is None:
            raise Refused("approval_valid", f"approval {approval_id} does not resolve")
        try:
            doc = _strict_loads(data, "approval_valid")
        except Refused as exc:
            raise Refused("approval_valid", f"approval {approval_id} is malformed: {exc.detail}") from exc
        if (not isinstance(doc, dict) or set(doc) != APPROVAL_KEYS or doc["approval_id"] != approval_id
                or type(doc["kind"]) is not str or type(doc["account"]) is not str
                or type(doc["sizing"]) is not str or type(doc["expires_at"]) is not str
                or type(doc["digest"]) is not str
                or (doc["engine_id"] is not None and type(doc["engine_id"]) is not str)
                or type(doc["symbols"]) is not list
                or any(type(symbol) is not str for symbol in doc["symbols"])):
            raise Refused("approval_valid", f"approval {approval_id} is malformed")
        return doc

    def approval_problem(self, doc: Mapping[str, Any], *, kind: str, engine_id: str | None,
                         account: str, symbols: Iterable[str], sizing: str, request_id: str,
                         min_expiry: datetime | None = None) -> str | None:
        """None when `doc` authorizes exactly this action for this request, else the reason."""
        if doc["kind"] != kind:
            return f"approval kind {doc['kind']!r} is not {kind!r}"
        if doc["digest"] != approval_digest(kind, engine_id, account, symbols, sizing, doc["expires_at"]):
            return "approval digest does not match this verb's arguments"
        expires = _utc_time(doc["expires_at"])
        if expires is None or self.now >= expires:
            return "approval expired"
        if min_expiry is not None and expires < min_expiry:
            return "approval expires before the probe window ends (use --oq-only for a shorter sample)"
        consumer = self.approval_consumer(doc["approval_id"])
        if consumer is not None and consumer != request_id:
            return f"approval already consumed by request {consumer}"
        return None

    def approval_consumer(self, approval_id: str) -> str | None:
        data = _read_bounded(self.approvals_dir() / f"{approval_id}.consumed", MAX_APPROVAL_BYTES)
        if data is None:
            return None
        try:
            marker = _strict_loads(data, "approval_valid")
        except Refused:
            return "<unreadable>"
        request_id = marker.get("request_id") if isinstance(marker, dict) else None
        return request_id if type(request_id) is str else "<unreadable>"

    def consume_approval(self, approval_id: str, request_id: str) -> None:
        """Exactly once: exclusive create; a rerun of the consuming request is a no-op."""
        marker = _canonical({"approval_id": approval_id, "request_id": request_id,
                             "consumed_at": self.now.isoformat()})
        if _create_exclusive(self.approvals_dir() / f"{approval_id}.consumed", marker):
            return
        consumer = self.approval_consumer(approval_id)
        if consumer != request_id:
            raise Refused("approval_valid", f"approval already consumed by request {consumer}")

    # output ------------------------------------------------------------------------------------

    def emit(self, value: Any, text: str | None = None) -> None:
        if self.json:
            print(json.dumps(value, sort_keys=True, ensure_ascii=False))
        elif text is not None:
            print(text)
        else:
            print(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False))

    def applied(self, verb: str, receipt: Mapping[str, str], result: Mapping[str, Any],
                replayed: bool) -> int:
        if self.json:
            print(json.dumps({"ok": True, "verb": verb, "replayed": replayed, "receipt": receipt["sha12"],
                              "result": result}, sort_keys=True, ensure_ascii=False))
        print(f"hot: engine {verb} applied; receipt {receipt['sha12']}")
        self.flush_lease_notes()  # S7 A L2: after the hot line, so line one keeps its shape
        return EXIT_OK

    def refuse(self, code: str, detail: str = "") -> int:
        if self.json:
            print(json.dumps({"ok": False, "code": code, "detail": detail}, sort_keys=True))
        print(f"refused: {code}" + (f": {detail}" if detail else ""), file=sys.stderr)
        return EXIT_REFUSED


# ---------------------------------------------------------------- shared readers

def book_account_id(path: Path) -> tuple[str | None, str | None]:
    """(the id a book on this identity file passes the registry gate, None) or (None, problem).

    It is the file's account_id verbatim: cli._kalshi_probe_account_id hands the gate the engine
    watcher's account (load_dashboard_account_identity(cfg.dashboard_account_identity).account_id),
    else the same file through the client's account-risk identity_path, unchanged. The execution
    principal (attribution.execution_account, KalshiLive.attribution_account) is built from that
    same account_id, so this file is the one source; no credential and no venue call are needed.
    One bounded read (engines caps it at 1 KiB); never raises."""
    try:
        identity = load_dashboard_account_identity(path)
    except EngineError as exc:
        absent = isinstance(exc.__cause__, FileNotFoundError)
        return None, "identity_absent" if absent else "identity_invalid"
    except (OSError, TypeError, ValueError):
        return None, "identity_invalid"
    if not er.valid_book_account_id(identity.account_id):
        return None, "identity_unusable"
    return identity.account_id, None


# ---------------------------------------------------------------- S7 A L2: one store, leased down

def _roots_problem(lanes_root: Path, identity_root: str | None, projection_root: str | None) -> str | None:
    """None when the lane identity and projection roots are unambiguous, else why (lexical only, no
    I/O). A non-default lanes root needs both roots named explicitly, and neither may be the lanes
    root or sit under it: the lanes root is tenant-writable, so a root derived from or inside it would
    hand a tenant the book ids root stamps into the registry and the lease files root publishes."""
    if lanes_root != Path(DEFAULT_LANES_ROOT) and not (identity_root and projection_root):
        return ("a non-default --lanes-root needs explicit --lane-identity-root and --projection-root; "
                "neither ever derives from the lanes root")
    lanes = os.path.normcase(os.path.abspath(lanes_root))
    for flag, value in (("--lane-identity-root", identity_root or DEFAULT_LANE_IDENTITY_ROOT),
                        ("--projection-root", projection_root or DEFAULT_PROJECTION_ROOT)):
        path = os.path.normcase(os.path.abspath(value))
        if path == lanes or path.startswith(lanes.rstrip(os.sep) + os.sep):
            return f"{flag} is at or under the tenant-writable lanes root"
    return None


def _lane_accounts(registry: er.Registry | None) -> dict[str, str]:
    """{account key: lane id} of every registry account that carries a lane_id, at most
    er.MAX_ACCOUNTS; {} with no registry. The only lane enumeration engine_ops makes: the registry
    (root-owned), never a listing of the lanes root, so a tenant cannot add, hide or starve a lane."""
    lanes: dict[str, str] = {}
    if registry is None:
        return lanes
    for key, account in list(registry.accounts.items())[:er.MAX_ACCOUNTS]:
        lane = account.get("lane_id")
        if lane is not None:
            lanes[key] = str(lane)
    return lanes


def _context_lane(record: Mapping[str, Any]) -> set[str]:
    """The lane account key a request recorded in its context (a tenant probe, a lane release or
    retire), as a set; empty for an owner request. No read."""
    context = record.get("context")
    lane = context.get("lane") if isinstance(context, dict) else None
    return {lane} if type(lane) is str else set()


def _engine_lane(registry: er.Registry | None, engine_id: str) -> str | None:
    """The lane account key the engine's registry assignment names, else None (an owner engine or
    an unassigned one, or no registry). Two dict gets."""
    if registry is None:
        return None
    assignment = registry.assignments.get(engine_id)
    if assignment is None:
        return None
    account = registry.accounts.get(assignment["account_id"])
    return assignment["account_id"] if account is not None and account.get("lane_id") is not None else None


def _is_tenant_probe(registry: er.Registry | None, lanes: Mapping[str, str], engine_id: str,
                     record: Mapping[str, Any] | None) -> bool:
    """The judge's one tenant classifier (judge <id> and judge --all alike): the canonical record's
    account_id is a lane account key, or the registry assignment names a lane account."""
    return ((record is not None and record.get("account_id") in lanes)
            or _engine_lane(registry, engine_id) is not None)


def _account_lane(account: Mapping[str, Any] | None) -> str | None:
    """The lane id of one registry account record; None for the owner (or no account)."""
    lane = None if account is None else account.get("lane_id")
    return None if lane is None else str(lane)


def _lease_path(ops: Ops, lane: str) -> Path:
    return ops.projection_root / lane / lifecycle_lease.LEASE_NAME


def _lease_publisher_present(ops: Ops, lane: str) -> bool:
    """True when the periodic S7 A L3 lease publisher runs for `lane`: its root-owned heartbeat
    `<projection root>/<lane>/LEASE_PUBLISHER_HEARTBEAT` exists (L3 writes exactly that name). One
    stat under the root-owned projection root, never the lanes root; never raises."""
    if not _LANE.fullmatch(lane):
        return False
    try:
        return (ops.projection_root / lane / LEASE_PUBLISHER_HEARTBEAT).exists()
    except (OSError, Refused):
        return False


def _published_lease(ops: Ops, lane: str) -> Any:
    """The lane's currently published lease (root-owned projection root), or None when absent or
    unreadable. Never raises; never touches the lanes root."""
    if not _LANE.fullmatch(lane):
        return None
    try:
        data = _read_bounded(_lease_path(ops, lane), lifecycle_lease.LEASE_MAX_BYTES)
        return None if data is None else lifecycle_lease.parse_lease(data)
    except (Refused, CanaryError, OSError, ValueError):
        return None


def _ns_time(value: int) -> datetime:
    """Epoch nanoseconds as an aware UTC datetime (microsecond resolution, floor)."""
    return _EPOCH + timedelta(microseconds=value // 1000)


def _pending_note(code: Any, previous: Any) -> str:
    """The note of a lease that was NOT published: the book keeps obeying the previous lease until
    its valid_until (never the verb's clock); `none` when no lease was ever published (the book then
    enters nothing, so nothing is pending on its side)."""
    code = code if type(code) is str and code else "lease_publish_failed"
    until = "none" if previous is None else _ns_time(previous.valid_until).isoformat()
    return f"lease: pending({code[:64]}); tenant_effective_by={until}"


def _probe_request_completed(ops: Ops, engine_id: str, assignment: Mapping[str, Any]) -> bool:
    """True only when the assignment was written by a probe request of this engine that COMPLETED
    (S7 A L2): a started, interrupted, refused or rolled-back probe, or any non-probe assignment, is
    never leased, so a half-landed probe is never hosted. One bounded read of a root-owned request."""
    rid = assignment.get("request_id")
    if type(rid) is not str:
        return False
    try:
        record = ops.load_request(rid)
    except Exception:
        return False
    return (record is not None and record.get("state") == "completed" and record.get("verb") == "probe"
            and record.get("subject") == engine_id)


class _CompletedProbeStore:
    """The store build_lease reads for one lane: CanaryStore._lease_snapshot (the records, epoch and
    revision in ONE read under the store flock, taken inside build_lease at publish time, never
    records read earlier), narrowed to the engines whose tenant probe request completed. The
    epoch and revision are the whole store's, preserving publish ordering (lease_stale_snapshot)."""

    def __init__(self, store: Any, leasable: frozenset[str]):
        self._store = store
        self._leasable = leasable

    def _lease_snapshot(self) -> tuple[str, int | None, dict[str, Any]]:
        epoch, revision, records = self._store._lease_snapshot()
        return epoch, revision, {engine_id: record for engine_id, record in records.items()
                                 if engine_id in self._leasable}


def _publish_lane(ops: Ops, key: str) -> str:
    """Build and publish one lane's lease and probe bindings from ONE registry snapshot and ONE
    canonical store snapshot (lifecycle_lease.build_lease over CanaryStore._lease_snapshot), leasing only
    the engines assigned to that lane whose probe request completed (one registry assignment scan,
    at most LEASE_MAX_ENGINES request reads, one store snapshot). Returns the operator note and never
    raises; anything not published is `pending(<code>)` (_pending_note)."""
    hint = key if type(key) is str and _LANE.fullmatch(key) else None
    try:
        registry = ops.registry()
    except Exception:
        return _pending_note(REGISTRY_UNREADABLE, None if hint is None else _published_lease(ops, hint))
    account = registry.accounts.get(key)
    lane = _account_lane(account)
    if lane is None or not _LANE.fullmatch(lane):
        return _pending_note("lane_id_invalid", None if hint is None else _published_lease(ops, hint))
    previous = _published_lease(ops, lane)
    # No clock orders a publish: publish_lane_lease assigns lease_seq (a counter) under the lane flock
    # and refuses a snapshot older than the lane's store_revision (lease_stale_snapshot).
    now = ops.now
    try:
        leasable = frozenset(
            engine_id for engine_id, assignment in registry.assignments.items()
            if assignment.get("account_id") == key and _probe_request_completed(ops, engine_id, assignment))
        lease_doc, bindings_doc = lifecycle_lease.build_lease(
            registry, _CompletedProbeStore(ops.canary(), leasable), lane, account["domain"], now)
        lifecycle_lease.publish_lane_lease(ops.projection_root, lane, lease_doc, bindings_doc)
    except Exception as exc:  # LeaseError, Refused(roots_ambiguous), OSError, anything: never the verb's
        code = getattr(exc, "code", None)
        return _pending_note(code if type(code) is str else type(exc).__name__, previous)
    effective = now + timedelta(microseconds=lifecycle_lease.PROBE_REFRESH_NS // 1000)
    return f"lease: published; tenant_effective_by={effective.isoformat()}"


def _tenant_records(ops: Ops, registry: er.Registry, lanes: Mapping[str, str],
                    exclude: str | None = None) -> dict[str, int]:
    """{lane account key: canonical records it holds}, `exclude` left out: a record counts for the
    lane whose key its account_id is, or whose registry assignment names it. One bounded pass over the
    one store (at most its capacity); the count includes halted and retired records, which keep a slot."""
    counts = dict.fromkeys(lanes, 0)
    for record in ops.canary().list():
        if record["engine_id"] == exclude:
            continue
        key = record.get("account_id")
        if key not in lanes:
            key = _engine_lane(registry, record["engine_id"])
        if key in counts:
            counts[key] += 1
    return counts


def _tenant_capacity_problem(ops: Ops, registry: er.Registry, key: str, engine_id: str,
                             symbols: Iterable[str]) -> tuple[str, str] | None:
    """Before a tenant probe's first write: (code, detail) when it would exceed a tenant bound, so a
    tenant can never make an owner probe refuse `too many lifecycle candidates`. The engine always
    counts as one slot of THIS lane after the probe (every other record is counted where it stands),
    so an existing record from the owner or another lane can never slip past a full cap. Bounds
    (lifecycle_lease): LEASE_MAX_ENGINES per lane, TENANT_RECORD_CAP over every lane,
    MAX_PROBES_PER_BOOK engines per lane book (symbol)."""
    per_book: dict[str, int] = {}
    for other_id, assignment in registry.assignments.items():
        if other_id != engine_id and assignment.get("account_id") == key:
            for symbol in assignment.get("symbols") or ():
                per_book[symbol] = per_book.get(symbol, 0) + 1
    for symbol in symbols:
        if per_book.get(symbol, 0) >= pb.MAX_PROBES_PER_BOOK:
            return LANE_BOOK_FULL, (f"{key} book {symbol} already carries {pb.MAX_PROBES_PER_BOOK} engines "
                                    "(probe_bindings max_per_book)")
    counts = _tenant_records(ops, registry, _lane_accounts(registry), exclude=engine_id)
    if counts.get(key, 0) >= lifecycle_lease.LEASE_MAX_ENGINES:
        return TENANT_CAPACITY, f"{key} already holds {lifecycle_lease.LEASE_MAX_ENGINES} lifecycle records"
    if sum(counts.values()) >= lifecycle_lease.TENANT_RECORD_CAP:
        return TENANT_CAPACITY, (f"tenants already hold {lifecycle_lease.TENANT_RECORD_CAP} lifecycle records; "
                                 f"the owner keeps {lifecycle_lease.OWNER_RECORD_HEADROOM}")
    return None


def _refuse_tenant_ladder(ops: Ops, engine_id: str, verb: str) -> None:
    """probe-size, graduate and --displace on a lane-assigned engine refuse tenant_ladder_deferred
    before any lifecycle or registry write (tenant probes stay at the first rung until S7 D evidence).
    Called first inside the verb's request, under the ops lock, so a refusal (or an unreadable
    registry) leaves the same refused request record and journal rows HEAD's refusals leave."""
    registry = ops.registry_optional()
    if registry is not None and _engine_lane(registry, engine_id) is not None:
        raise Refused(TENANT_LADDER_DEFERRED, f"{verb} of lane-assigned {engine_id} waits for tenant evidence (S7 D)")


def _stop_codes(record: Mapping[str, Any] | None) -> list[str]:
    codes: list[str] = []
    for item in (record or {}).get("stop_reasons") or ():
        code = item if isinstance(item, str) else item.get("code") if isinstance(item, dict) else None
        if isinstance(code, str) and code and code not in codes:
            codes.append(code)
    return codes


def _override_entries(path: Path | None, engine_id: str) -> list[tuple[str, dict[str, Any]]]:
    """(account key, entry) for every override of `engine_id` in one overrides file; an absent
    file has none; an unreadable or malformed one refuses (fails closed). None (a lane, S7 A L2)
    opens nothing and has none."""
    if path is None:
        return []
    data = _read_bounded(path, MAX_OVERRIDES_BYTES)
    if data is None:
        return []
    doc = _strict_loads(data, "no_owner_policy_override")
    accounts = doc.get("accounts") if isinstance(doc, dict) else None
    if not isinstance(accounts, dict):
        raise Refused("no_owner_policy_override", f"{path}: malformed overrides document")
    entries = []
    for key, body in accounts.items():
        engines = body.get("engines") if isinstance(body, dict) else None
        if not isinstance(engines, dict):
            raise Refused("no_owner_policy_override", f"{path}: malformed account {key!r}")
        entry = engines.get(engine_id)
        if entry is not None:
            if not isinstance(entry, dict):
                raise Refused("no_owner_policy_override", f"{path}: malformed override {key!r}")
            entries.append((key, entry))
    return entries


def _other_account_engines(ops: Ops, account_id: str, registry: er.Registry) -> set[str]:
    """Engines active in another account's bindings or assigned to another account."""
    engines = {eid for eid, assignment in registry.assignments.items()
               if assignment["account_id"] != account_id}
    for source in ops.sources():
        if source.account_id != account_id:
            active, _ = er.expand_bindings(er.read_bindings(source.bindings_path))
            engines.update(active.values())
    return engines


def _is_exit_row(row: Mapping[str, Any]) -> bool:
    """An exit order (kind exit, or an `lx-` client id) closes a ticket; it is never an open one."""
    client_id = row.get("client_id")
    return row.get("kind") == "exit" or (type(client_id) is str and client_id.startswith(EXIT_CLIENT_PREFIX))


def _unsettled_tickets(runs_root: Path, symbol: str, now: datetime) -> tuple[list, int]:
    """The book ledger's filled tickets not yet settled, adopted or voided (plan D7 book_flat).
    Exit rows are dropped before counting (C6d fix b: the journal's filled `lx-` exit order of a
    fully exited ticket read as one unsettled ticket, so a flat BTC-1H book refused book_flat)."""
    from .broker.kalshi_book import unsettled_prior_tickets

    rows, bad = unsettled_prior_tickets(Path(runs_root), "kalshi", symbol, now)
    return [row for row in rows if not _is_exit_row(row)], bad


def _probe_policy(ops: Ops, engine_id: str, manifest) -> Any:
    """The policy the lifecycle binds: the catalog policy the manifest pins (policy kernel), the
    catalog engine of the same id (lane kernel), else the default policy for a code lane."""
    kernel = manifest.kernel if manifest is not None else None
    if kernel is not None and kernel["kind"] == "policy":
        engine = ops.catalog_engine(kernel["policy_engine_id"])
        return None if engine is None else engine.policy
    engine = ops.catalog_engine(engine_id)
    return DEFAULT_POLICY if engine is None else engine.policy


def _manifest_problem(ops: Ops, engine_id: str, manifest, manifest_error: str | None,
                      symbols: Iterable[str]) -> str | None:
    """manifest_conformed_or_waived: valid, covers the symbols, kernel pin holds, and either a
    conform receipt for this exact manifest digest or a waiver in its evidence."""
    if manifest is None:
        return f"manifest {manifest_error}"
    declared = set(manifest.inputs["symbols"])
    missing = sorted(set(symbols) - declared)
    if missing:
        return f"manifest does not declare {missing}"
    kernel = manifest.kernel
    if kernel["kind"] == "policy":
        engine = ops.catalog_engine(kernel["policy_engine_id"])
        if engine is None:
            return f"kernel pin: catalog engine {kernel['policy_engine_id']} is missing"
        if policy_digest(engine.policy) != kernel["policy_digest"]:
            return "kernel pin: the catalog policy digest differs from the manifest"
    conform = ops.conform_record(engine_id)
    conformed = conform is not None and conform.get("manifest_digest") == manifest_digest(manifest)
    waived = any(item["kind"] == "waiver" and str(item["detail"]).strip() for item in manifest.evidence)
    if not (conformed or waived):
        return "no conform receipt for this manifest digest and no waiver"
    return None


def _probe_approval_sizing(ops: Ops, doc: Mapping[str, Any]) -> str:
    """Keep legacy whole-count digest checks; opt in fractional and wave counts only."""
    sizing = doc["sizing"]
    try:
        count = Decimal(sizing)
        if count.is_finite() and count != count.to_integral_value():
            return sizing  # range/grid validation follows the existing preconditions
    except InvalidOperation:
        pass
    if sizing == "1.00":  # the wave publisher's canonical whole-count spelling
        try:
            data = _read_bounded(ops.approvals_dir() / f"{doc['approval_id']}.presence.json",
                                 MAX_APPROVE_RECORD_BYTES)
            sidecar = None if data is None else _strict_loads(data, "approval_valid")
            if (isinstance(sidecar, dict) and sidecar.get("schema") == PRESENCE_SCHEMA
                    and sidecar.get("approval_id") == doc["approval_id"]
                    and sidecar.get("digest") == doc["digest"]
                    and re.fullmatch(r"[0-9a-f]{64}", str(sidecar.get("manifest_sha256", "")))):
                return sizing
        except Refused:
            pass  # a legacy approval never needed a presence sidecar
    return PROBE_SIZING


def probe_failures(ops: Ops, engine_id: str, account_id: str | None, symbols: list[str], *,
                   registry: er.Registry, manifest, manifest_error: str | None, bind: bool = False,
                   approval: tuple[Mapping[str, Any], str, datetime | None] | None = None,
                   first_only: bool = False) -> list[tuple[str, str]]:
    """Every failing probe precondition as (code, detail), in the contract order. Checks that need
    an account are skipped when `account_id` is None (status --candidates without --account);
    approval_valid is skipped when `approval` is None; book_flat runs only with `bind`, which means
    DISPLACEMENT (C6d fix b): a co-host never touches the incumbent, so a book with open tickets
    may host a probe beside it, and only replacing the incumbent needs the book flat."""
    failures: list[tuple[str, str]] = []

    def fail(code: str, detail: str) -> bool:
        failures.append((code, detail))
        return first_only

    assignments = registry.assignments
    current = assignments.get(engine_id)
    account = registry.accounts.get(account_id) if account_id is not None else None

    if account_id is not None:
        others = _other_account_engines(ops, account_id, registry)
        if engine_id in others:
            holder = current["account_id"] if current is not None and current["account_id"] != account_id \
                else "another account's bindings"
            if fail("not_assigned_elsewhere", f"{engine_id} is held by {holder}"):
                return failures

    if manifest is not None:
        identity = identity_digest(manifest)
        wanted = set(symbols)
        for other_id, other in assignments.items():
            if (other_id != engine_id and other["identity_digest"] == identity
                    and wanted & set(other["symbols"])):
                if fail("identity_unique", f"{engine_id} has the identity of {other_id} on a shared symbol"):
                    return failures
                break

    probes = sum(1 for other_id, other in assignments.items()
                 if other["role"] == "probe" and other_id != engine_id)
    already_probe = current is not None and current["role"] == "probe"
    if not already_probe and probes >= int(registry.doc["max_concurrent_probes"]):
        if fail("concurrent_probes_below_max",
                f"{probes} probes already run; the registry allows {registry.doc['max_concurrent_probes']}"):
            return failures

    if account is not None:
        try:
            entries = _override_entries(ops.overrides_path(account), engine_id)
            policy_overrides = [key for key, entry in entries if entry.get("policy")]
            problem = f"a policy override exists for {policy_overrides}" if policy_overrides else None
        except Refused as exc:
            problem = exc.detail
        if problem is not None and fail("no_owner_policy_override", problem):
            return failures

    if manifest is not None:
        not_live = engine_feeds.feeds_live_provisioned(manifest)
        if not_live and fail("feeds_live_provisioned", ", ".join(not_live)):
            return failures

    problem = _manifest_problem(ops, engine_id, manifest, manifest_error, symbols)
    if problem is not None and fail("manifest_conformed_or_waived", problem):
        return failures

    try:
        record = ops.canary().optional(engine_id)
        state = "absent" if record is None else record["state"]
    except CanaryError as exc:
        state = f"unreadable ({exc})"
    if state not in LIFECYCLE_ALLOWS_PROBE:
        if fail("lifecycle_state_allows", f"lifecycle state {state}"):
            return failures

    if account_id is not None and registry.exit_only(account_id) is not False:
        detail = "unknown account" if account is None else f"{account['domain']} is exit-only"
        if fail("domain_is_exposure_authority", detail):
            return failures

    if approval is not None and account_id is not None:
        doc, request_id, min_expiry = approval
        sizing = _probe_approval_sizing(ops, doc)
        problem = ops.approval_problem(doc, kind="probe", engine_id=engine_id, account=account_id,
                                       symbols=symbols, sizing=sizing, request_id=request_id,
                                       min_expiry=min_expiry)
        if problem is not None and fail("approval_valid", problem):
            return failures

    if bind and account is not None:
        problem = _book_flat_problem(ops, account, symbols)
        if problem is not None and fail("book_flat", problem):
            return failures
    return failures


def _book_flat_problem(ops: Ops, account: Mapping[str, Any], symbols: Iterable[str]) -> str | None:
    """The first symbol whose book is not flat, as the book_flat detail; None when every one is."""
    for symbol in symbols:
        try:
            tickets, bad = _unsettled_tickets(ops.runs_root(account), symbol, ops.now)
        except Exception as exc:  # the flat proof failed to read: never flat (fail closed)
            tickets, bad = [], f"unreadable ({type(exc).__name__})"
        if tickets or bad:
            return f"{symbol}: {len(tickets)} unsettled tickets, bad lines {bad}"
    return None


# ---------------------------------------------------------------- registry verbs

def _authorities(values: Iterable[str] | None) -> dict[str, str]:
    authorities: dict[str, str] = {}
    for value in values or ():
        match = _AUTHORITY.fullmatch(value)
        if match is None:
            raise Refused("invalid_authority", f"{value!r}: expected member=domain")
        authorities[match.group(1)] = match.group(2)
    return authorities


def _enforcement(values: Iterable[str] | None) -> dict[str, str]:
    """member=mode pairs; a mode outside exposure_authority.ENFORCEMENTS refuses (fails closed)."""
    modes: dict[str, str] = {}
    for value in values or ():
        match = _AUTHORITY.fullmatch(value)
        if match is None or match.group(2) not in exposure_authority.ENFORCEMENTS:
            raise Refused("invalid_enforcement", repr(value)[:128])
        modes[match.group(1)] = match.group(2)
    return modes


def _identities(ops: Ops) -> dict[str, str]:
    found: dict[str, str] = {}
    for path in sorted(ops.manifests_dir.glob("*.json"))[:MAX_MANIFEST_FILES]:
        manifest, _ = ops.manifest(path.stem) if ENGINE_ID_RE.fullmatch(path.stem) else (None, None)
        if manifest is not None:
            found[manifest.engine_id] = identity_digest(manifest)
    return found


ROOT_STATE_ROOT = "/var/lib"  # root-owned state root: an unchecked roles directory never lands under it


def _posix_absolute(text: str) -> str:
    """The lexically normalized POSIX spelling of an absolute path, leading `//` collapsed."""
    return "/" + posixpath.normpath(text).lstrip("/")


def _under_root_state(path: Path) -> bool:
    """True when `path` sits at or under ROOT_STATE_ROOT by its normalized POSIX absolute path OR,
    on POSIX, its resolved (symlink-followed) path. Decides on normalized POSIX strings, never the
    spelling given, so `/var/lib/x/../x`, `/var/../var/lib/x`, a relative spelling and a symlink
    into or out of /var/lib all count, and the answer is the same on every platform (a Windows dev
    host never maps the POSIX spelling onto a drive letter)."""
    text = os.fspath(path)
    roots = {ROOT_STATE_ROOT}
    candidates: list[str] = []
    if os.name == "posix":
        roots.add(_posix_absolute(os.path.realpath(ROOT_STATE_ROOT)))
        candidates += [_posix_absolute(posixpath.abspath(text)), _posix_absolute(os.path.realpath(text))]
    else:
        spelled = text.replace("\\", "/")
        if spelled.startswith("/"):
            candidates.append(_posix_absolute(spelled))
    return any(c == r or c.startswith(r.rstrip("/") + "/") for c in candidates for r in roots)


def _roles_target(value: str, unchecked: bool) -> tuple[Path, int | None]:
    """Where registry init lowers the role files (--roles-dir, default exposure_authority.ROLES_DIR)
    and the owner it checks. Fails closed: every roles directory is checked root-owned 0755 (owner 0)
    whatever its spelling; only --roles-owner-unchecked skips the check (owner None, a test or dev
    target), and that flag is refused `roles_owner_unchecked_refused` for any directory under
    ROOT_STATE_ROOT."""
    roles_dir = Path(value)
    if not unchecked:
        return roles_dir, 0
    if _under_root_state(roles_dir):
        raise Refused("roles_owner_unchecked_refused",
                      f"{roles_dir} resolves under {ROOT_STATE_ROOT}; the owner check cannot be skipped there")
    return roles_dir, None


def _roles_configured(roles_dir: Path, owner: int | None) -> Path | None:
    """The roles directory registry init hands the library, or None when an owner-checked directory
    does not exist (ENOENT on lstat): no roles configured, so init proceeds without lowering role
    files, as it did before the owner check. An EXISTING directory is returned and the library's
    owner check (_check_roles_dir) still refuses it when unsafe; any other lstat error (EACCES,
    ELOOP, ENOTDIR) refuses `roles_dir_unsafe` (fails closed). Unchecked (owner None) directories
    are returned as given, where the library creates them."""
    if owner is None:
        return roles_dir
    try:
        os.lstat(os.fspath(roles_dir))
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise Refused("roles_dir_unsafe", f"{roles_dir}: {exc}") from exc
    return roles_dir


def _provisioned_lanes(sources: list[er.AccountSource], named: Iterable[str] | None) -> list[str]:
    """The verified provisioned lanes registry init must enumerate: every --provisioned-lane, each
    named by an account in the accounts file (else `unknown_lane`, fails closed), or, with none
    named, the lane of every account-lane domain in the accounts file."""
    known = {source.lane_id for source in sources if source.lane_id is not None}
    if named:
        lanes = sorted(set(named))
        unknown = [lane for lane in lanes if lane not in known]
        if unknown:
            raise Refused("unknown_lane", ", ".join(repr(lane)[:80] for lane in unknown[:8]))
        return lanes
    return sorted({source.lane_id for source in sources
                   if source.lane_id is not None and source.domain.startswith("account-lane:")})


def cmd_registry_init(ops: Ops, a: argparse.Namespace) -> int:
    if a.apply == a.dry_run:
        raise Refused("usage", "pass exactly one of --dry-run or --apply")
    sources = ops.sources()
    if not sources:
        raise Refused("bindings_absent", "--bindings must name the accounts file")
    authorities = _authorities(a.authority)
    enforcement = _enforcement(a.enforcement)
    receipts = sorted(str(path) for path in a.conformance_receipt or ())
    identities = _identities(ops) if a.identities else {}
    roles_dir, roles_owner = _roles_target(a.roles_dir, a.roles_owner_unchecked)
    roles_target = _roles_configured(roles_dir, roles_owner)
    provisioned = _provisioned_lanes(sources, a.provisioned_lane)
    book_ids = ops.book_account_ids({source.account_id: {"lane_id": source.lane_id} for source in sources})
    report = er.init_from_bindings(ops.registry_dir, sources, authorities=authorities,
                                   identity_digests=identities, dry_run=True, now=ops.now,
                                   enforcement=enforcement, conformance_receipts=receipts,
                                   provisioned_lanes=provisioned, roles_dir=roles_target,
                                   roles_owner=roles_owner, book_account_ids=book_ids)
    report = dict(report, provisioned_lanes=provisioned, roles_dir=os.fspath(roles_dir),
                  roles_owner_unchecked=roles_owner is None, roles_dir_present=roles_target is not None,
                  book_account_problems={**ops.book_id_problems, **report["book_account_problems"]})
    if a.dry_run:
        # The library dry-run stops before receipt validation; check the supplied receipts here so a
        # clean dry-run predicts a clean apply (same per-domain shape the apply refusal carries).
        receipt_problems: dict[str, list[str]] = {}
        for domain in report["receipts_required"]:
            problems = [exposure_authority.check_conformance_receipt(path, domain, now=ops.now)
                        for path in receipts]
            if None not in problems:
                receipt_problems[domain] = [problem for problem in problems if problem] or ["receipt_missing"]
        if report["receipts_required"]:
            report = dict(report, receipt_problems=receipt_problems)
        ops.emit(report)
        return EXIT_REFUSED if report["refusals"] or receipt_problems else EXIT_OK
    args = {"snapshot_digest": report["snapshot_digest"], "authorities": authorities,
            "identities": bool(a.identities), "enforcement": dict(sorted(enforcement.items())),
            "conformance_receipts": receipts, "roles_dir": os.fspath(roles_dir),
            "roles_owner_unchecked": roles_owner is None, "roles_dir_present": roles_target is not None,
            "provisioned_lanes": provisioned}
    if any(value is not None for value in book_ids.values()):  # absent ids keep the pre-X1c args
        args["book_account_ids"] = book_ids
    # The automatic id covers every effective argument, so a refused apply rerun with a corrected
    # argument (the missing receipt, a different mode) gets a fresh id instead of request_id_reused.
    request_id = a.request_id or f"registry-init-{_sha(_canonical(args))[:12]}"

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        store = ops.registry_store()
        if ops.begin(record, "registry"):
            existing = store.load()
            if existing is None:
                er.init_from_bindings(ops.registry_dir, sources, authorities=authorities,
                                      identity_digests=identities, dry_run=False, now=ops.now,
                                      request_id=record["request_id"], enforcement=enforcement,
                                      conformance_receipts=receipts, provisioned_lanes=provisioned,
                                      roles_dir=roles_target, roles_owner=roles_owner,
                                      book_account_ids=book_ids)
            elif not any(row.get("action") == "init" and row.get("request_id") == record["request_id"]
                         for row in store.journal_tail()):
                raise er.RegistryError("registry_exists", str(store.path))
            ops.done(record, "registry")
        registry = ops.registry()
        return {"generation": registry.generation, "digest": registry.digest,
                "snapshot_digest": report["snapshot_digest"],
                "assignments": len(registry.assignments),
                "book_account_ids": _book_ids_of(registry)}

    receipt, result, replayed = ops.mutate("registry-init", REGISTRY_SUBJECT, request_id, args, perform)
    return ops.applied("registry-init", receipt, result, replayed)


def cmd_registry_show(ops: Ops, a: argparse.Namespace) -> int:
    registry = ops.registry()
    value = {"generation": registry.generation, "digest": registry.digest, "document": registry.doc,
             "journal": ops.registry_store().journal_tail()}
    lines = [f"generation {registry.generation} digest {registry.digest[:12]}"]
    for engine_id, assignment in sorted(registry.assignments.items()):
        lines.append(f"{engine_id}: {assignment['role']} on {assignment['account_id']} "
                     f"{','.join(assignment['symbols'])}")
    ops.emit(value, "\n".join(lines))
    return EXIT_OK


def _book_ids_of(registry: er.Registry) -> dict[str, str | None]:
    return {aid: account.get(er.BOOK_ACCOUNT_ID) for aid, account in registry.accounts.items()}


def cmd_registry_project(ops: Ops, a: argparse.Namespace) -> int:
    """Recovery: rewrite projection.json (what the books read) from the committed registry.
    Every commit already writes it; this refuses, and leaves the old projection, when the registry
    file is absent, invalid or off its journal chain. X1c: when the derived book ids (or the ids an
    interim hand-patched projection names) are not yet in the registry, it commits them as one
    generation whose publication writes the projection and its published marker together; run it
    once as root after a deploy that carries X1c."""
    store = ops.registry_store()
    registry = store.project(now=ops.now)
    value = {"generation": registry.generation, "digest": registry.digest, "schema": registry.doc["schema"],
             "projection": os.fspath(store.projection_path), "book_account_ids": _book_ids_of(registry),
             "book_account_problems": {**ops.book_id_problems, **store.book_problems},
             "interim_rewritten": dict(store.interim)}
    text = (f"projection {store.projection_path} generation {registry.generation} "
            f"digest {registry.digest[:12]}")
    if store.interim:
        text += "; interim renamed key(s) rewritten canonically: " + ", ".join(sorted(store.interim))
    ops.emit(value, text)
    return EXIT_OK


def _lane_lease_findings(ops: Ops, registry: er.Registry) -> list[dict[str, Any]]:
    """S7 A L2, per lane with a leasable engine (lane-assigned with a canonical record): its lease is
    missing or unreadable (lane_lease_missing), older than 2 x LEASE_S (lane_lease_stale), an engine
    is absent from it (lane_engine_unleased), and a canonical tenant record carries a harvested halt
    or kill_criterion (lane_engine_restricted, shown as reported). Reads the registry, the one store
    and the root-owned projection root only; bounded by the registry's assignments."""
    lanes = _lane_accounts(registry)
    assigned: dict[str, list[str]] = {}
    for engine_id in sorted(registry.assignments):
        key = registry.assignments[engine_id]["account_id"]
        if key in lanes:
            assigned.setdefault(key, []).append(engine_id)
    canary = ops.canary()
    now_ns = lifecycle_lease.epoch_ns(ops.now)
    findings: list[dict[str, Any]] = []

    def finding(cls: str, key: str, engine_id: str | None, detail: str) -> None:
        findings.append({"class": cls, "account_id": key, "engine_id": engine_id, "symbols": [],
                         "detail": detail[:200]})

    if assigned:  # a legacy bind of a lane engine into the owner file holds an owner book slot
        try:
            owner_view = pb.strict_view(_read_bounded(ops.probe_bindings, pb.MAX_FILE_BYTES))
        except (pb.ProbeBindingsRefused, Refused, OSError, ValueError):
            owner_view = None  # a malformed owner file is its own audit's finding, not a lane's
        for key in sorted(assigned) if owner_view is not None else ():
            for engine_id in assigned[key]:
                listed = sorted(symbol for symbol, engines in owner_view.symbols.items() if engine_id in engines)
                if listed:
                    finding(LANE_ENGINE_OWNER_BOUND, key, engine_id,
                            f"lane-assigned {engine_id} is still bound in {ops.probe_bindings} on {listed}; "
                            f"engine_ops release or retire removes it")

    for key in sorted(assigned):
        records = {}
        for engine_id in assigned[key]:
            try:
                record = canary.optional(engine_id)
            except CanaryError:
                record = None
            if record is not None:
                records[engine_id] = record
        if not records:
            continue
        lane = lanes[key]
        lease = _published_lease(ops, lane)
        if lease is None:
            finding("lane_lease_missing", key, None, f"lane {lane}: no valid {lifecycle_lease.LEASE_NAME} "
                                                     f"under {ops.projection_root}")
        elif (now_ns - lease.issued_at > 2 * lifecycle_lease.LEASE_S * 10 ** 9
              and _lease_publisher_present(ops, lane)):
            # Only with the periodic L3 publisher running: before it exists a lease is published
            # by verbs alone and is expected to age, so a stale page would fire on every audit.
            finding("lane_lease_stale", key, None,
                    f"lane {lane}: lease issued {_ns_time(lease.issued_at).isoformat()}, older than "
                    f"{2 * lifecycle_lease.LEASE_S} s")
        for engine_id, record in records.items():
            if lease is not None and engine_id not in lease.grants:
                finding("lane_engine_unleased", key, engine_id, f"lane {lane}: {engine_id} is missing from its lease")
            harvested = record.get("harvested_halts")  # CanaryStore.restrict: {code: highest halt_seq}
            reported = sorted({code for code in _stop_codes(record) if code in lifecycle_lease.OUTBOX_HALT_CODES}
                              | (set(harvested) if isinstance(harvested, dict) else set()))
            if record.get("state") in ("halted", "retired") and reported:
                finding("lane_engine_restricted", key, engine_id,
                        f"lane {lane}: {engine_id} {record['state']} as reported {reported}")
    return findings


def cmd_registry_audit(ops: Ops, a: argparse.Namespace) -> int:
    registry = ops.registry()
    states: dict[str, str] = {}
    for record in ops.canary().list():
        states[record["engine_id"]] = record["state"]
    findings = er.audit_sources(registry, ops.sources(), lifecycle_states=states)
    for record in ops.requests():
        if record.get("state") in ("started", "unreadable", "superseded"):
            subject = record.get("subject")
            context = record.get("context")
            refused = context.get("resume_refused") if isinstance(context, dict) else None
            partial = f" resume refused {refused}" if type(refused) is str else ""
            superseded = context.get("superseded") if isinstance(context, dict) else None
            if isinstance(superseded, dict):  # C6d fix d: the partial transaction a newer one overtook
                partial += (f" {superseded.get('code')} at {superseded.get('step')}"
                            f" by {superseded.get('by')}")
            head = f"{record.get('verb')} {record['request_id']} {record.get('state')}"
            if record.get("state") == "started" and record.get("verb") in NO_RESUME_VERBS:
                head += f"; engine_ops repair {record['request_id']};"  # C6e: the command that settles it
            findings.append({"class": "request_incomplete", "account_id": None,
                             "engine_id": subject if isinstance(subject, str)
                             and ENGINE_ID_RE.fullmatch(subject) else None,
                             "symbols": [],
                             "detail": f"{head} after {record.get('steps')}{partial}"[:200]})
    findings.extend(_lane_lease_findings(ops, registry))
    report = ops.registry_store().write_audit(registry, findings, now=ops.now)
    lines = [f"{f['class']}: {f['engine_id'] or '-'} on {f['account_id'] or '-'} {f['detail']}"
             for f in findings] or ["registry audit clean"]
    ops.emit(report, "\n".join(lines))
    return EXIT_REFUSED if findings else EXIT_OK


# ---------------------------------------------------------------- exposure verbs (X1b, X2X3 v3 2.1 item 8)
# Budget, per verb: one registry load, one sidecar load and at most two CAS commits through
# exposure_authority.mutate_exposure; no loop over ledgers and no venue I/O. Every argument is
# regex- or length-bounded before the first read, and every write runs under ops.mutate (idempotent
# replay, request_id_reused, one receipt). A CAS loss refuses registry_changed and writes nothing.

EXPOSURE_SUBJECT = "_exposure"  # receipts under <evidence-dir>/_exposure/ (a member key may hold ':')
EXPOSURE_ACTOR = "engine_ops"
TRANSFER_DEADLINE_H = (1, 24)
TRANSFER_DEFAULT_DEADLINE_H = 3
_DEADLINE_H = re.compile(r"[1-9][0-9]?")
MAX_QUARANTINE_REASON = 200
MAX_ROLES_DIR_TEXT = 1024
TRANSFER_NEXT = "the 60 s exposure step advances it; watch scripts/leafhft_exposure_audit.py step"
X4_QUARANTINE = "python scripts/leafhft_exposure_audit.py quarantine --member {member}"


def _exposure_key(value: Any, name: str) -> str:
    """A member or account key; fails closed before any read."""
    if type(value) is not str or er.KEY_ID_RE.fullmatch(value) is None:
        raise Refused("invalid_value", f"{name} must match {er.KEY_ID_RE.pattern}")
    return value


def _exposure_domain(value: Any) -> str:
    if type(value) is not str or er.DOMAIN_RE.fullmatch(value) is None:
        raise Refused("invalid_value", f"domain must match {er.DOMAIN_RE.pattern}")
    return value


def cmd_domain(ops: Ops, a: argparse.Namespace) -> int:
    """owner-domain-control v1: the ops lock covers read, presence claim and atomic publication."""
    from . import owner_domain_control as dc, tuning_presence as tp

    try:
        dc.record_path(a.domain, ops.registry_dir)
        if a.domain_verb != "show":
            if not approve_presence.is_root():
                raise Refused("not_root", "domain control runs as root")
            dc.validate_request(a.domain, a.member_key, a.request_id, a.requested_by)
        with _exclusive_lock(ops.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
            current = dc.read_record(a.domain, ops.registry_dir)
            if a.domain_verb == "show":
                ops.emit(current if current is not None else {"state": "absent"})
                return EXIT_OK
            if a.domain_verb == "pause" and not tp._match(dc.REASON_RE, a.reason):
                raise Refused("invalid_reason", "reason must be a reason code")
            # Completed request replay never writes or consumes another presence decision.
            desired = "paused" if a.domain_verb == "pause" else "resumed"
            if current is not None and current["state"] == desired and current["request_id"] == a.request_id:
                ops.emit(current)
                return EXIT_OK
            if a.domain_verb == "resume":
                if not tp._safe_nonneg(a.expect_generation):
                    raise Refused("generation_stale", "expect_generation must be a non-negative integer")
                if current is None:
                    raise Refused("not_paused", "domain has no pause record")
                if current["generation"] != a.expect_generation:
                    raise Refused("generation_stale", "pause generation changed")
                if current["state"] != "paused":
                    raise Refused("not_paused", "domain is already resumed")
            registry = ops.registry()
            matches = [(key, row) for key, row in registry.accounts.items()
                       if row["domain"] == a.domain and row["member_key"] == a.member_key]
            if len(matches) != 1:
                raise Refused("domain_mismatch", "domain is not registered to this member")
            account_key, account_row = matches[0]
            if a.domain_verb == "pause":
                record = dc.paused_record(current, domain=a.domain, member_key=a.member_key,
                                          reason=a.reason, request_id=a.request_id,
                                          requested_by=a.requested_by, now=ops.now)
            else:
                if registry.exit_only(account_key) is not False:
                    raise Refused("domain_not_authority", "domain cannot resume while exit-only")
                try:
                    assertion = _device_input(a.presence_assertion_file, tp.MAX_ASSERTION_BYTES)
                    plan = _device_input(a.presence_plan_file, dc.MAX_PLAN_BYTES)
                    identity = ops.identity_path(account_row)
                    if identity is None or _read_store_file(identity, 1024) is None:
                        raise tp.PresenceRefused("evidence_scope", "owner_identity_absent")
                    approve_presence.check_store_chain(identity.parent)
                    account = ops.book_account_ids({account_key: account_row})[account_key]
                    clock = _approve_seams(ops, a).clock
                    now = clock()  # Presence expiry uses the runner clock after the lock wait and reads.
                    verified = dc.verify_resume(
                        assertion, plan, current=current, request_id=a.request_id, account=account,
                        host=approve_presence.host_name(), now=now)
                    record = {**current, "generation": current["generation"] + 1, "state": "resumed",
                              "request_id": a.request_id, "requested_by": a.requested_by,
                              "resumed_at": dc._iso(now), "resume_nonce": None,
                              "evidence_sha256": verified.evidence_sha256, "previous_digest": current["digest"]}
                    dc.encode_record(record)  # Validate before consuming evidence, including generation bounds.
                    ledger = _device_directory(_approve_store(ops), DEVICE_LEDGER_DIR)
                    dc.claim_resume(ledger, verified, now=clock(), require_root=os.name == "posix")
                except tp.PresenceRefused as exc:
                    raise Refused("presence_invalid", str(exc)) from None
                except Refused as exc:
                    raise Refused("presence_invalid", f"{exc.code}: {exc.detail}") from None
                except approve_presence.StoreInsecure:
                    raise Refused("presence_invalid", "evidence_scope: owner_identity_insecure") from None
            record = dc.write_record(record, ops.registry_dir)
            ops.emit(record)
            return EXIT_OK
    except dc.DomainRefused as exc:
        raise Refused(exc.code, exc.detail) from None


def _deadline_hours(value: Any) -> int:
    """--deadline-h: an integer 1..24 (default 3); anything else refuses invalid_value."""
    if value is None:
        return TRANSFER_DEFAULT_DEADLINE_H
    low, high = TRANSFER_DEADLINE_H
    if type(value) is not str or _DEADLINE_H.fullmatch(value) is None or not low <= int(value) <= high:
        raise Refused("invalid_value", f"--deadline-h must be an integer {low}..{high}, got {str(value)[:16]!r}")
    return int(value)


def _bounded_text(value: Any, name: str, limit: int) -> str:
    if type(value) is not str or not 1 <= len(value) <= limit or not value.isprintable():
        raise Refused("invalid_value", f"{name}: 1..{limit} printable characters")
    return value


def _exposure_roles(ops: Ops, a: argparse.Namespace) -> tuple[Path | None, int | None]:
    """(role directory, owner) the verb's CAS projects into: --roles-dir, else the directory the
    active projection's witness recorded; (None, 0) before any projection, so today's no-role-file
    behaviour stands. --roles-owner-unchecked goes through _roles_target and its /var/lib refusal."""
    value = a.roles_dir
    if value is not None and (type(value) is not str or not 1 <= len(value) <= MAX_ROLES_DIR_TEXT):
        raise Refused("invalid_value", f"--roles-dir: 1..{MAX_ROLES_DIR_TEXT} characters")
    if value is None:
        value = exposure_authority.recorded_roles_dir(ops.registry_dir)
    if value is None:
        return None, 0
    return _roles_target(value, a.roles_owner_unchecked)


def _roles_args(roles: tuple[Path | None, int | None]) -> dict[str, Any]:
    roles_dir, owner = roles
    return {"roles_dir": None if roles_dir is None else os.fspath(roles_dir),
            "roles_owner_unchecked": roles_dir is not None and owner is None}


def _exposure_cas(ops: Ops, registry: er.Registry, action: str, request_id: str,
                  roles: tuple[Path | None, int | None], *,
                  registry_change: Callable[[dict[str, Any]], bool] | None = None,
                  state_change: Callable[[dict[str, Any]], bool] | None = None
                  ) -> tuple[er.Registry, dict[str, Any]]:
    """One compare-and-swap on the (generation, digest) of `registry`, the read the caller decided on."""
    roles_dir, owner = roles
    return exposure_authority.mutate_exposure(
        ops.registry_dir, expect=(registry.generation, registry.digest), action=action,
        registry_change=registry_change, state_change=state_change, roles_dir=roles_dir, owner=owner,
        request_id=request_id, actor=EXPOSURE_ACTOR, now=ops.now)


def _member_domains(registry: er.Registry, member: str) -> list[str]:
    return sorted(account["domain"] for account in registry.accounts.values() if account["member_key"] == member)


def _exposure_applied(ops: Ops, verb: str, receipt: Mapping[str, str], result: Mapping[str, Any],
                      replayed: bool, text: str) -> int:
    if not ops.json:
        print(text)
    return ops.applied(verb, receipt, result, replayed)


def cmd_exposure_transfer(ops: Ops, a: argparse.Namespace) -> int:
    """PREPARE (X2X3 v3 section 5 step 1): one sidecar CAS writes the member's transfer at phase
    `prepared`, which lowers the source domain's role file (transfer_prepared) at once. The registry
    authority is unchanged; X4's step owns every later phase. The exposure_transfer approval binds
    the member (account) and the target domain (sizing) and is consumed once, after the write."""
    _file_id(a.request_id, "request_id")
    member = _exposure_key(a.member, "member")
    target = _exposure_domain(a.to)
    hours = _deadline_hours(a.deadline_h)
    approval_id = _file_id(a.approval, "approval")
    roles = _exposure_roles(ops, a)
    args = {"member": member, "to": target, "approval": approval_id, "deadline_h": hours, **_roles_args(roles)}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        rid = record["request_id"]
        registry = ops.registry()
        if ops.begin(record, "sidecar"):
            members = registry.doc["exposure"]["members"]
            if member not in members:
                raise Refused("unknown_member", member)
            side = exposure_authority.load_state(ops.registry_dir)["members"].get(member)
            pending = None if side is None else side["transfer"]
            if pending is not None and pending["request_id"] == rid:
                transfer = pending  # this request's own write already landed: the record stands
            else:
                source = members[member]["authority_domain"]
                if source is None:
                    raise Refused("authority_not_held", f"{member} holds no authority to transfer")
                if members[member]["transfer"] is not None or pending is not None:
                    raise Refused("transfer_pending", f"{member} already has a transfer in flight")
                if target not in _member_domains(registry, member):
                    raise Refused("authority_domain_unknown", f"{target} is not a domain of member {member}")
                if target == source:
                    raise Refused("same_domain", f"{member} already holds authority on {target}")
                doc = ops.load_approval(approval_id)
                problem = ops.approval_problem(doc, kind="exposure_transfer", engine_id=None, account=member,
                                               symbols=[], sizing=target, request_id=rid)
                if problem is not None:
                    raise Refused("approval_valid", problem)
                transfer = {"request_id": rid, "from": source, "to": target, "phase": "prepared",
                            "prepared_at": er.utc_stamp(ops.now),
                            "deadline_at": er.utc_stamp(ops.now + timedelta(hours=hours)),
                            "approval_id": approval_id, "disabled_at": None, "ack_digest": None,
                            "flat_reads": [], "orphans_resolved": []}

                def change(state: dict[str, Any]) -> bool:
                    entry = state["members"].get(member)
                    if entry is None:
                        entry = {"enforcement": exposure_authority.member_enforcement(state, member),
                                 "transfer": None, "attested_foreign": []}
                        state["members"][member] = entry
                    if entry["transfer"] is not None:  # re-checked under the registry lock
                        if entry["transfer"]["request_id"] == rid:
                            return False
                        raise er.RegistryError("transfer_pending", f"{member}: another transfer is pending")
                    entry["transfer"] = dict(transfer)
                    return True

                _exposure_cas(ops, registry, "exposure.transfer", rid, roles, state_change=change)
            record["context"]["transfer"] = dict(transfer)
            ops.done(record, "sidecar")
        transfer = record["context"]["transfer"]
        if ops.begin(record, "approval"):
            ops.consume_approval(approval_id, rid)
            ops.done(record, "approval")
        return {"member": member, "from": transfer["from"], "to": transfer["to"], "request_id": rid,
                "phase": "prepared", "prepared_at": transfer["prepared_at"],
                "deadline_at": transfer["deadline_at"], "approval_id": approval_id,
                "registry_generation": registry.generation, "next": TRANSFER_NEXT}

    receipt, result, replayed = ops.mutate("exposure-transfer", EXPOSURE_SUBJECT, a.request_id, args, perform)
    text = (f"{result['member']}: transfer {result['from']} -> {result['to']} prepared, request "
            f"{result['request_id']}, deadline {result['deadline_at']}; next: {result['next']}")
    return _exposure_applied(ops, "exposure-transfer", receipt, result, replayed, text)


def cmd_exposure_quarantine(ops: Ops, a: argparse.Namespace) -> int:
    """QUARANTINE, lowering only, so no approval (X2X3 item 8): two CAS writes in X4's order, the
    registry half (authority and C1 transfer null) first, then the sidecar transfer cleared; each is
    its own step, so a crash between them resumes the second under the same request id. Every
    domain of the member then projects exit_only. Producers' off-lists need root host effects (X4
    Effects) and are NOT applied here: the result names the X4 command that applies them."""
    _file_id(a.request_id, "request_id")
    member = _exposure_key(a.member, "member")
    reason = "operator" if a.reason is None else _bounded_text(a.reason, "--reason", MAX_QUARANTINE_REASON)
    roles = _exposure_roles(ops, a)
    args = {"member": member, "reason": reason, **_roles_args(roles)}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        rid = record["request_id"]
        registry = ops.registry()
        if member not in registry.doc["exposure"]["members"]:
            raise Refused("unknown_member", member)
        context = record["context"]
        if ops.begin(record, "registry"):
            view = registry.doc["exposure"]["members"][member]
            committed = False
            if view["authority_domain"] is not None or view["transfer"] is not None:

                def null_authority(doc: dict[str, Any]) -> bool:
                    current = doc["exposure"]["members"][member]
                    if current["authority_domain"] is None and current["transfer"] is None:
                        return False
                    doc["exposure"]["members"][member] = {"authority_domain": None, "transfer": None}
                    return True

                after, _ = _exposure_cas(ops, registry, "exposure.quarantine", rid, roles,
                                         registry_change=null_authority)
                committed, registry = after.generation != registry.generation, after
            context["registry_committed"] = committed
            ops.done(record, "registry")
        if ops.begin(record, "sidecar"):
            cleared = []

            def clear_transfer(state: dict[str, Any]) -> bool:
                entry = state["members"].get(member)
                if entry is None or entry["transfer"] is None:
                    return False
                cleared.append(entry["transfer"]["request_id"])
                entry["transfer"] = None
                return True

            registry, _ = _exposure_cas(ops, registry, "exposure.quarantine", rid, roles,
                                        state_change=clear_transfer)
            context["transfer_cleared"] = cleared[0] if cleared else None
            ops.done(record, "sidecar")
        follow_up = X4_QUARANTINE.format(member=member)
        return {"member": member, "request_id": rid, "reason": reason, "authority_domain": None,
                "registry_generation": registry.generation,
                "registry_committed": bool(context.get("registry_committed")),
                "transfer_cleared": context.get("transfer_cleared"),
                "exit_only": _member_domains(registry, member), "off_lists_applied": False,
                "follow_up": follow_up}

    receipt, result, replayed = ops.mutate("exposure-quarantine", EXPOSURE_SUBJECT, a.request_id, args, perform)
    text = (f"{member}: quarantined, authority null, exit_only on {', '.join(result['exit_only'])} "
            f"(generation {result['registry_generation']}); producers' off-lists are NOT applied here, "
            f"run as root: {result['follow_up']}")
    return _exposure_applied(ops, "exposure-quarantine", receipt, result, replayed, text)


def _register_lane(domain: str, lane_id: Any) -> str | None:
    """The account's lane id: account-lane:<x> takes <x> (a different --lane-id refuses), and
    legacy-owner takes none (any --lane-id refuses); domain_lane_mismatch either way."""
    if domain == er.LEGACY_OWNER_DOMAIN:
        if lane_id is not None:
            raise Refused("domain_lane_mismatch", f"{domain} carries no lane id")
        return None
    lane = domain.split(":", 1)[1]
    if lane_id is not None and lane_id != lane:
        raise Refused("domain_lane_mismatch", f"{domain} is lane {lane}, not {str(lane_id)[:64]!r}")
    return lane


def cmd_exposure_register(ops: Ops, a: argparse.Namespace) -> int:
    """The attested register: one registry CAS adds one account. Under an existing member (--member)
    the new domain starts exit_only (fails closed, VII.4); a new single-domain member (--new-member)
    holds its own authority only with --attest, an exposure_register approval that must resolve in
    the approval store (the library checks only its shape), bound to the domain (account) and the
    new member (sizing), and consumed once after the commit."""
    if (a.member is None) == (a.new_member is None):
        raise Refused("usage", "pass exactly one of --member or --new-member")
    if a.new_member is not None and a.attest is None:
        raise Refused("usage", "--new-member needs --attest <approval id>")
    if a.member is not None and a.attest is not None:
        raise Refused("usage", "--attest goes with --new-member only")
    _file_id(a.request_id, "request_id")
    domain = _exposure_domain(a.domain)
    account_id = _exposure_key(a.account, "account")
    label = _bounded_text(a.label, "--label", er.MAX_LABEL)
    member = None if a.member is None else _exposure_key(a.member, "member")
    new_member = None if a.new_member is None else _exposure_key(a.new_member, "new_member")
    attest = None if a.attest is None else _file_id(a.attest, "attest")
    lane_id = _register_lane(domain, a.lane_id)
    roles = _exposure_roles(ops, a)
    args = {"domain": domain, "account": account_id, "kind": a.kind, "label": label, "lane_id": lane_id,
            "member": member, "new_member": new_member, "attest": attest, **_roles_args(roles)}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        rid = record["request_id"]
        if attest is not None:
            doc = ops.load_approval(attest)
            problem = ops.approval_problem(doc, kind="exposure_register", engine_id=None, account=domain,
                                           symbols=[], sizing=new_member, request_id=rid)
            if problem is not None:
                raise Refused("approval_valid", problem)
        resumed = record["context"].get("current_step") == "registry"
        registry = ops.registry()
        if ops.begin(record, "registry"):
            # A crash after the commit but before the step was recorded: the journal names this id.
            if not (resumed and any(row.get("action") == "exposure.register" and row.get("request_id") == rid
                                    for row in ops.registry_store().journal_tail())):

                def add_account(doc: dict[str, Any]) -> bool:
                    exposure_authority.apply_register(doc, account_id, domain=domain, kind=a.kind, label=label,
                                                      lane_id=lane_id, member_key=member,
                                                      new_member_key=new_member, attestation=attest)
                    er.apply_book_account_ids(doc, ops.book_account_ids(doc["accounts"]))  # X1c stamp
                    return True

                registry, _ = _exposure_cas(ops, registry, "exposure.register", rid, roles,
                                            registry_change=add_account)
            else:
                registry = ops.registry()
            ops.done(record, "registry")
        if attest is not None and ops.begin(record, "approval"):
            ops.consume_approval(attest, rid)
            ops.done(record, "approval")
        account = registry.accounts[account_id]
        return {"account_id": account_id, "domain": domain, "kind": account["kind"],
                "lane_id": account["lane_id"], "member": account["member_key"], "new_member": new_member is not None,
                "exit_only": account["exit_only"], "attestation": attest,
                "registry_generation": registry.generation}

    receipt, result, replayed = ops.mutate("exposure-register", EXPOSURE_SUBJECT, a.request_id, args, perform)
    text = (f"{account_id}: registered {domain} under member {result['member']} "
            f"({'exit_only' if result['exit_only'] else 'authority'}), generation {result['registry_generation']}")
    return _exposure_applied(ops, "exposure-register", receipt, result, replayed, text)


# ---------------------------------------------------------------- manifest verbs

def _write_manifest(ops: Ops, manifest) -> bool:
    """Write the canonical bytes; False when the identical manifest is already there. A different
    manifest already on disk is refused, never overwritten (freeze is the only rewrite)."""
    path = ops.manifest_path(manifest.engine_id)
    data = manifest_bytes(manifest)
    existing = _read_bounded(path, len(data) + 16384)
    if existing is not None:
        if existing == data:
            return False
        raise Refused("manifest_exists", f"{path} holds a different manifest; use manifest freeze")
    _atomic_write(path, data)
    return True


def cmd_manifest_import_legacy(ops: Ops, a: argparse.Namespace) -> int:
    if bool(a.all) == bool(a.engine_id):
        raise Refused("usage", "name one engine or pass --all")
    if not a.waiver or not a.waiver.strip():
        raise Refused("waiver_missing", "--waiver gives the reason the legacy engine has no evidence")
    engine_ids = [engine.engine_id for engine in ops.catalog().list()] if a.all else [_engine_id(a.engine_id)]
    symbols = _symbols(a.symbols) if a.symbols else None
    rows = []
    for engine_id in engine_ids:
        manifest = import_legacy(ops.engines_dir / f"{engine_id}.json", waiver_reason=a.waiver,
                                 symbols=symbols)
        written = _write_manifest(ops, manifest)
        rows.append({"engine_id": engine_id, "digest": manifest_digest(manifest), "written": written})
    ops.emit({"imported": rows}, "\n".join(
        f"{row['engine_id']}: {'written' if row['written'] else 'unchanged'} {row['digest'][:12]}"
        for row in rows) or "no engines")
    return EXIT_OK


def _set_values(pairs: Iterable[str] | None) -> dict[str, str]:
    values: dict[str, str] = {}
    for pair in pairs or ():
        key, sep, value = pair.partition("=")
        if not sep or not key or not value:
            raise Refused("invalid_set", f"{pair!r}: expected key=value")
        values[key.strip()] = value.strip()
    return values


def resolve_variant_policy(parent_policy, values):
    """Pure policy resolution with manifest-init/EngineRegistry.set_values semantics.

    Keep the legacy handler's filesystem transaction unchanged. This is its
    policy-only algorithm: normalize the parent as catalog.get does, parse
    string settings by their declared kind, validate, merge, then serialize
    with the policy serializer (including optional-key omission).
    """
    from .engines import EngineError, _bound, _UNSET_WORDS
    from .policy import (OPTIONAL_POLICY_BOUNDS, PolicyError, policy_document,
                         policy_from_mapping, validate_hard_maxima)

    try:
        parent = policy_from_mapping(parent_policy)
        parsed = {}
        for key, value in values.items():
            if _bound(key) is None:
                raise EngineError(f"policy set: unknown key {key!r}")
            kind = _bound(key)[2]
            if isinstance(value, str):
                if key in OPTIONAL_POLICY_BOUNDS and value.strip().lower() in _UNSET_WORDS:
                    value = None
                else:
                    try:
                        value = kind(value)
                    except ValueError as exc:
                        raise EngineError(f"{key}: {value!r} is not a valid {kind.__name__}") from exc
            parsed[key] = value
        if values:
            validate_hard_maxima(parsed)
            parent = policy_from_mapping({**policy_document(parent), **parsed})
        return json.dumps(policy_document(parent), sort_keys=True, separators=(",", ":"),
                          ensure_ascii=True, allow_nan=False).encode("ascii")
    except PolicyError as exc:
        raise EngineError(str(exc)) from exc


def cmd_manifest_init(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    parent_id = _engine_id(a.parent)
    if ops.manifest_path(engine_id).exists():
        raise Refused("manifest_exists", str(ops.manifest_path(engine_id)))
    catalog = ops.catalog()
    parent = catalog.get(parent_id)
    engine = ops.catalog_engine(engine_id)
    if engine is None:
        engine = catalog.create(engine_id, engine_id, a.summary[:500], parent.policy, parent=parent_id)
    values = _set_values(a.set)
    if values:
        engine = catalog.set_values(engine_id, values)
    symbols = _symbols(a.symbols) if a.symbols else sorted(er.symbols())
    policy = engine.policy
    body = {
        "schema": MANIFEST_SCHEMA,
        "identity": {"engine_id": engine_id, "version": engine.version, "parent": parent_id},
        "provenance": {"origin": "operator", "source_ref": f"engine_ops manifest init variant of {parent_id}",
                       "code_sha": None},
        "thesis": {"summary": a.summary, "novelty": a.novelty,
                   "kill_criterion": a.kill or "Three daily loss breaker trips in seven UTC days halt the engine for review.",
                   "expected_edge_cents": _decimal_text(policy.edge_threshold_cents, "99.99")},
        "kernel": {"kind": "policy", "kernel_id": POLICY_KERNEL_ID, "policy_engine_id": engine_id,
                   "policy_digest": policy_digest(policy)},
        "inputs": {"symbols": symbols, "feeds": engine_feeds.book_feeds(symbols), "history_rows": 0,
                   "models": []},
        "hot_keys": [],
        "risk_request": {"fractions": {key: _decimal_text(min(getattr(policy, key), maximum), "1")
                                       for key, maximum in HARD_MAXIMA.items()},
                         "caps": {}, "limits": {}},
        "evidence": [{"kind": "waiver", "ref": "manifest-init",
                      "detail": "New variant; its evidence arrives with try and the probe."}],
    }
    manifest = build_manifest(body)
    _write_manifest(ops, manifest)
    ops.emit({"engine_id": engine_id, "digest": manifest_digest(manifest)},
             f"{engine_id}: manifest {manifest_digest(manifest)[:12]}; next: engine_ops try {engine_id}")
    return EXIT_OK


def cmd_manifest_freeze(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    path = ops.manifest_path(engine_id)
    data = _read_bounded(path, 16384)
    if data is None:
        raise Refused("manifest_invalid", f"{path} does not exist")
    manifest = build_manifest(_strict_loads(data, "manifest_invalid"))
    if manifest.engine_id != engine_id:
        raise Refused("manifest_invalid", "identity.engine_id does not match the file name")
    _atomic_write(path, manifest_bytes(manifest))
    ops.emit({"engine_id": engine_id, "digest": manifest_digest(manifest)},
             f"{engine_id}: frozen {manifest_digest(manifest)[:12]}")
    return EXIT_OK


def cmd_manifest_show(ops: Ops, a: argparse.Namespace) -> int:
    manifest = load_manifest(ops.manifest_path(_engine_id(a.engine_id)))
    ops.emit(manifest.to_mapping())
    return EXIT_OK


def cmd_manifest_validate(ops: Ops, a: argparse.Namespace) -> int:
    manifest = load_manifest(ops.manifest_path(_engine_id(a.engine_id)))
    ops.emit({"engine_id": manifest.engine_id, "valid": True, "digest": manifest_digest(manifest)},
             f"{manifest.engine_id}: valid {manifest_digest(manifest)[:12]}")
    return EXIT_OK


# ---------------------------------------------------------------- assign and release

def cmd_assign(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    symbols = _symbols(a.symbols)
    if a.role not in ASSIGN_ROLES:
        raise Refused("invalid_role", f"assign sets {ASSIGN_ROLES}; probe and graduate have their own verbs")
    approval_id = _file_id(a.approval, "approval")
    args = {"account": a.account, "symbols": symbols, "role": a.role, "approval": approval_id}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        doc = ops.load_approval(approval_id)
        problem = ops.approval_problem(doc, kind="assign", engine_id=engine_id, account=a.account,
                                       symbols=symbols, sizing=a.role, request_id=record["request_id"])
        if problem is not None:
            raise Refused("approval_valid", problem)
        manifest, _ = ops.manifest(engine_id)
        if ops.begin(record, "registry"):
            ops.registry_store().assign(
                engine_id, a.account, a.role, symbols,
                identity_digest=None if manifest is None else identity_digest(manifest),
                manifest_digest=None if manifest is None else manifest_digest(manifest),
                request_id=record["request_id"], approval_id=approval_id, now=ops.now)
            ops.done(record, "registry")
        if ops.begin(record, "approval"):
            ops.consume_approval(approval_id, record["request_id"])
            ops.done(record, "approval")
        registry = ops.registry()
        return {"engine_id": engine_id, "account_id": a.account, "role": a.role, "symbols": symbols,
                "registry_generation": registry.generation}

    receipt, result, replayed = ops.mutate("assign", engine_id, a.request_id, args, perform)
    return ops.applied("assign", receipt, result, replayed)


def _same_generation(current: Mapping[str, Any] | None, captured: Mapping[str, Any]) -> bool:
    """One assignment generation is named by the request that wrote it and its since stamp."""
    return (current is not None and current.get("request_id") == captured.get("request_id")
            and current.get("since") == captured.get("since"))


def _probe_request_for(ops: Ops, assignment: Mapping[str, Any] | None, engine_id: str) -> dict[str, Any] | None:
    """The completed probe request that wrote the current assignment, when there is one."""
    request_id = None if assignment is None else assignment.get("request_id")
    if type(request_id) is not str or not _FILE_ID.fullmatch(request_id):
        return None
    record = ops.load_request(request_id)
    if record is None or record.get("verb") != "probe" or record.get("subject") != engine_id:
        return None
    return record


def _restore_probe_bindings(ops: Ops, assignment: Mapping[str, Any] | None, engine_id: str) -> bool:
    """Put the main bindings file back byte for byte from the probe request that displaced into it;
    True when restored. A co-hosted probe (C6d: probe_bindings only) never wrote the main file, so
    there is nothing to restore (False). Refuses when no probe request bound the engine or the file
    changed after the probe wrote it."""
    probe = _probe_request_for(ops, assignment, engine_id)
    snapshots = (probe or {}).get("context", {}).get("snapshots", {})
    if probe is None or "bindings" not in snapshots:
        if probe is None or "probe_bindings" not in (probe.get("steps") or ()):
            raise Refused("no_bindings_snapshot", f"{engine_id} was not bound by a probe request")
        return False  # co-hosted: the main file was never written
    path = Path(snapshots["bindings"]["path"])
    current = _read_bounded(path, er.MAX_BINDINGS_BYTES)
    wrote = probe["context"].get("bindings_after_sha256")
    if current is not None and _sha(current) != wrote and _sha(current) != snapshots["bindings"]["sha256"]:
        raise Refused("bindings_changed_since_probe", f"{path} changed after the probe bound it")
    ops.restore(probe, "bindings")
    return True


def _drop_legacy_owner_binding(ops: Ops, engine_id: str) -> bool:
    """Release and retire of a lane-assigned engine: remove a legacy entry for it from the owner
    probe-bindings file (a tenant probe bound on main before S7 A wrote there and would hold an owner
    max_per_book slot for good). True when an entry was removed. The file is root-owned; one bounded
    read, and a write only when it names the engine, so an ordinary lane release leaves it byte for
    byte. A malformed file is left alone (a risk-reducing verb never refuses on it; the book refuses
    that file anyway)."""
    try:
        data = pb.release_engine(_read_bounded(ops.probe_bindings, pb.MAX_FILE_BYTES), engine_id)
    except (pb.ProbeBindingsRefused, Refused):
        return False
    if data is None:
        return False
    _write_bindings_file(ops.probe_bindings, data)
    return True


def _interrupted(record: Mapping[str, Any]) -> bool:
    """C6e: a `started` request that wrote a step, or has one in flight, is interrupted."""
    context = record.get("context")
    return record.get("state") == "started" and bool(
        record.get("steps") or (isinstance(context, dict) and context.get("current_step")))


def _interrupted_detail(record: Mapping[str, Any]) -> str:
    """The refusal detail for a rerun of an interrupted probe or release: what it completed, what
    was in flight, and the exact commands that settle it."""
    rid = record.get("request_id")
    context = record.get("context") if isinstance(record.get("context"), dict) else {}
    return (f"{record.get('verb')} {rid} was interrupted after steps {list(record.get('steps') or [])} "
            f"with {context.get('current_step')!r} in flight; it is never resumed. Report it with "
            f"`engine_ops repair {rid}`, then settle it with `engine_ops repair {rid} --finish` or "
            f"`engine_ops repair {rid} --rollback`")


def _release_perform(ops: Ops, record: dict[str, Any], engine_id: str,
                     restore_bindings: bool) -> dict[str, Any]:
    """The release steps, shared by `release` and `repair --finish` (C6e): each step it has not
    done yet runs once, and acts only while the registry holds the captured generation."""
    context = record["context"]
    if "assignment" not in context:
        current = ops.registry().assignments.get(engine_id)
        if current is None:
            raise Refused("not_assigned", f"{engine_id} has no assignment")
        context["assignment"] = json.loads(json.dumps(current))
        ops.save_request(record)
    captured = context["assignment"]

    def owned(step: str) -> bool:
        """C6d fix c: a step acts only while the registry still holds the generation this
        request captured (its request id and since stamp), read under the ops lock. A finished
        release that finds another generation (a reprobe) or none (another release finished
        first) leaves every entry as it is and records release_superseded. At the registry
        step an absent assignment is only "already released", possibly by this request."""
        current = ops.registry().assignments.get(engine_id)
        if _same_generation(current, captured):
            return True
        if current is None and step == "registry":
            return False
        if not context.get("release_superseded"):
            by = None if current is None else current.get("request_id")
            context["release_superseded"] = {"step": step, "by": by}
            ops.save_request(record)
            ops.journal("release", engine_id, record["request_id"], "release_superseded",
                        step=step, by=by)
        return False

    # S7 A L2: a lane's engine was never in the owner bindings files; the lease republished after
    # this verb drops it from the lane's bindings, so neither owner file is read or written here.
    # The lane account KEY (as a probe records it), saved once before the first step so a rerun keeps
    # it after the assignment is gone; an owner release records nothing (its request.json is HEAD's).
    lane = context.get("lane")
    if lane is None:
        key = captured.get("account_id")
        if _account_lane(ops.registry().accounts.get(key)) is not None:
            lane = context["lane"] = key
            ops.save_request(record)
    if restore_bindings and ops.begin(record, "bindings"):
        if lane is not None or not owned("bindings"):
            context["bindings_restored"] = False
        else:
            context["bindings_restored"] = _restore_probe_bindings(ops, captured, engine_id)
        ops.done(record, "bindings")
    if ops.begin(record, "probe_bindings"):
        # Every release takes the engine off every book it co-hosts on; others stay bound.
        data = None
        if lane is None and owned("probe_bindings"):
            before = _read_bounded(ops.probe_bindings, pb.MAX_FILE_BYTES)
            data = _probe_bindings_change(pb.release_engine, before, engine_id)
            if data is not None:
                _write_bindings_file(ops.probe_bindings, data)
        elif lane is not None and owned("probe_bindings"):  # remove only this generation's legacy bind
            data = b"" if _drop_legacy_owner_binding(ops, engine_id) else None
        context["probe_bindings_removed"] = data is not None
        ops.done(record, "probe_bindings")
    if ops.begin(record, "registry"):
        if owned("registry"):
            def change(doc: dict[str, Any]) -> bool:  # the same check, under the registry lock
                if not _same_generation(doc["assignments"].get(engine_id), captured):
                    return False
                return er.apply_release(doc, engine_id)

            ops.registry_store().mutate("release", change, request_id=record["request_id"], now=ops.now)
        ops.done(record, "registry")
    result = {"engine_id": engine_id, "released_from": context["assignment"]["account_id"],
              "bindings_restored": bool(context.get("bindings_restored")),
              "probe_bindings_removed": bool(context.get("probe_bindings_removed")),
              "registry_generation": ops.registry().generation}
    if context.get("release_superseded"):
        result["release_superseded"] = context["release_superseded"]
    return result


def cmd_release(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    args = {"restore_bindings": bool(a.restore_bindings)}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        return _release_perform(ops, record, engine_id, bool(a.restore_bindings))

    receipt, result, replayed = ops.mutate("release", engine_id, a.request_id, args, perform)
    return ops.applied("release", receipt, result, replayed)


# ---------------------------------------------------------------- probe

def _bound_bytes(before: bytes | None, symbols: Iterable[str], engine_id: str) -> bytes:
    raw = {"default": None, "symbols": {}} if before is None else _strict_loads(before, "bindings_invalid")
    if not isinstance(raw, dict) or not isinstance(raw.get("symbols"), dict):
        raise Refused("bindings_invalid", "expected default, symbols and optional disabled")
    raw["symbols"] = {**raw["symbols"], **{symbol: engine_id for symbol in symbols}}
    data = json.dumps(raw, sort_keys=True, separators=(",", ":")).encode("utf-8")
    if len(data) > er.MAX_BINDINGS_BYTES:
        raise Refused("bindings_too_large", str(len(data)))
    return data


def _probe_bindings_change(change: Callable[..., bytes | None], *args: Any) -> bytes | None:
    """Run a probe_bindings writer; its named refusal becomes an engine_ops refusal."""
    try:
        return change(*args)
    except pb.ProbeBindingsRefused as exc:
        raise Refused(exc.code, exc.detail) from None


def _probe_hosts_missing(ops: Ops, symbols: Iterable[str]) -> list[str]:
    """The symbols `$etc/kalshi-probe-hosts` does not list, read the way live-run.sh reads it (one
    symbol per line, every whitespace character dropped). An absent file lists nothing."""
    path = ops.probe_bindings.parent / PROBE_HOSTS_NAME
    data = _read_bounded(path, MAX_PROBE_HOSTS_BYTES)
    listed = set()
    for line in (data or b"").decode("utf-8", "replace").splitlines():
        token = "".join(line.split())
        if token:
            listed.add(token)
    return [symbol for symbol in symbols if symbol not in listed]


def _card_displaces(ops: Ops, approval_id: str) -> str | None:
    """The `displaces` field the approval card showed for this approval (the frozen approve
    record the presence sidecar names), or None when there is no such card or its item was
    minted without `approve --displace` (an item from before that flag carries no `displace`)."""
    store = ops.approvals_dir()
    data = _read_bounded(store / f"{approval_id}.presence.json", MAX_APPROVAL_BYTES)
    if data is None:
        return None
    sidecar = _strict_loads(data, "displace_not_on_card")
    request_id = sidecar.get("request_id") if isinstance(sidecar, dict) else None
    if (not isinstance(sidecar, dict) or sidecar.get("approval_id") != approval_id
            or type(request_id) is not str or not _FILE_ID.fullmatch(request_id)):
        return None
    try:
        record = _load_approve_record(store, request_id)
    except Refused:
        return None
    for item in (record or {}).get("items") or ():
        if isinstance(item, dict) and item.get("approval_id") == approval_id:
            if item.get("displace") is False:  # minted to co-host (C6d fix b): it never displaces
                return None
            shown = item.get("displaces")
            return shown if type(shown) is str else None
    return None


def _assignment_identity(engine_id: str, assignment: Mapping[str, Any], generation: int) -> dict[str, Any]:
    """What a probe transaction captures once its registry step lands (C6d fix d): the engine, the
    account, the request that wrote the assignment and its since stamp (the assignment generation
    `_same_generation` compares), and the registry generation it was committed in (for the audit)."""
    return {"engine_id": engine_id, "account_id": assignment.get("account_id"),
            "request_id": assignment.get("request_id"), "since": assignment.get("since"),
            "generation": generation}


def _supersede(ops: Ops, record: dict[str, Any], engine_id: str, code: str, step: str,
               holder: Mapping[str, Any] | None) -> _TransactionSuperseded:
    """End the request `superseded` (C6d fix d): the steps it completed stay listed for the audit,
    the newer state stays untouched, the journal names the event, and a rerun of the id refuses."""
    context = record["context"]
    by = None if holder is None else holder.get("request_id")
    context["superseded"] = {"code": code, "step": step, "by": by,
                             "in_flight": context.pop("current_step", None)}
    record["state"] = "superseded"
    ops.save_request(record)
    ops.journal(record.get("verb") or "probe", engine_id, record["request_id"], code, step=step, by=by)
    return _TransactionSuperseded(code, f"{engine_id}: request {record['request_id']} no longer holds the "
                                        f"assignment generation it captured (now held by {by or 'no request'}); "
                                        "it writes nothing more and its id is retired")


def _probe_holds(ops: Ops, record: dict[str, Any], engine_id: str, step: str) -> None:
    """C6d fix d: before every probe step after the registry step, re-read the registry under the
    ops lock and go on only while it holds, for this engine, the assignment generation this request
    captured; otherwise raise resume_superseded, writing nothing.
    A record from before fix d captured nothing, so its own request id is the identity there."""
    context = record["context"]
    registry = ops.registry()
    holder = registry.assignments.get(engine_id)
    captured = context.get("assignment")
    if captured is None:
        if holder is not None and holder.get("request_id") == record["request_id"]:
            context["assignment"] = _assignment_identity(engine_id, holder, registry.generation)
            ops.save_request(record)
            return
    elif _same_generation(holder, captured):
        return
    raise _supersede(ops, record, engine_id, "resume_superseded", step, holder)


def _snapshot_limit(name: str) -> int:
    return {"bindings": er.MAX_BINDINGS_BYTES, "probe_bindings": pb.MAX_FILE_BYTES,
            "overrides": MAX_OVERRIDES_BYTES}.get(name, MAX_LIFECYCLE_BYTES)


def _record_written(ops: Ops, record: dict[str, Any], name: str, path: Path) -> None:
    """C6e: right after this request's own write to `path`, remember its sha256 as
    `<name>_after_sha256`, so a rollback restores the snapshot only while the file is still exactly
    that write. Never raises: an unrecorded write is one a rollback leaves standing."""
    try:
        if name == "lifecycle":
            # Captured by the verb's store instance at _write, never from a racing path read.
            digest = ops.canary().written_digests.get(record["subject"])
            if digest is None:  # a no-op or failed write grants no rollback ownership
                return
        else:
            data = _read_bounded(path, _snapshot_limit(name))
            digest = None if data is None else _sha(data)
        record["context"][f"{name}_after_sha256"] = digest
        ops.save_request(record)
    except (Refused, OSError):
        pass


def _snapshot_state(record: Mapping[str, Any], name: str) -> str:
    """'unchanged' (this request's write never landed), 'ours' (the file is still exactly this
    request's own write) or 'changed' (someone wrote it since, or a pre-C6e record never recorded
    its write)."""
    context = record["context"]
    meta = context["snapshots"][name]
    current = _read_bounded(Path(meta["path"]), _snapshot_limit(name))
    digest = None if current is None else _sha(current)
    if digest == meta["sha256"]:
        return "unchanged"
    after = context.get(f"{name}_after_sha256")
    return "ours" if after is not None and digest == after else "changed"


def _main_bindings_undo(record: Mapping[str, Any], engine_id: str,
                        path: Path) -> tuple[bytes | None, list[str], list[str]]:
    """C6e, the main bindings file entry by entry: (the bytes to write or None, the symbols given
    back, the symbols left). Only a symbol this request displaced and still bound to this engine
    goes back to its previous engine (the key is deleted when there was none); a symbol now bound to
    another engine, and every symbol this request never touched, stay. An unparseable file refuses
    (the caller leaves it untouched and records the error). Read only."""
    previous = record["context"].get("previous_bindings") or {}
    current = _read_bounded(path, er.MAX_BINDINGS_BYTES)
    if current is None:
        return None, [], sorted(previous)
    er.read_bindings(path)  # the strict reader must accept the file before any entry is changed
    raw = _strict_loads(current, "bindings_invalid")
    if not isinstance(raw, dict) or not isinstance(raw.get("symbols"), dict):
        raise Refused("bindings_invalid", f"{path}: expected default, symbols and optional disabled")
    symbols = dict(raw["symbols"])
    undone, left = [], []
    for symbol in sorted(previous):
        if symbols.get(symbol) == engine_id:
            if previous[symbol] is None:
                symbols.pop(symbol, None)
            else:
                symbols[symbol] = previous[symbol]
            undone.append(symbol)
        else:
            left.append(symbol)
    left.extend(sorted(symbol for symbol in symbols if symbol not in previous))
    if not undone:
        return None, undone, left
    raw["symbols"] = symbols
    data = json.dumps(raw, sort_keys=True, separators=(",", ":")).encode("utf-8")
    if len(data) > er.MAX_BINDINGS_BYTES:
        raise Refused("bindings_too_large", str(len(data)))
    return data, undone, left


def _rollback_main_bindings(ops: Ops, record: dict[str, Any], engine_id: str) -> tuple[list[str], list[str]]:
    """C6e (residual 2 of #487): take back only the main bindings entries this request wrote. The
    snapshot goes back byte for byte only while the file is still exactly this request's write;
    otherwise each displaced symbol still bound to this engine gets its previous engine back and
    every other entry stands. The write keeps mode and owner and must pass the strict reader.
    Returns (undone, left)."""
    state = _snapshot_state(record, "bindings")
    if state == "unchanged":
        return [], []
    if state == "ours":
        ops.restore(record, "bindings")
        return ["bindings"], []
    path = Path(record["context"]["snapshots"]["bindings"]["path"])
    data, undone, left = _main_bindings_undo(record, engine_id, path)
    if data is not None:
        _write_bindings_file(path, data)
        er.read_bindings(path)  # the reader must accept what was written
    return [f"bindings:{symbol}" for symbol in undone], [f"bindings:{symbol}" for symbol in left]


def _probe_bindings_undo(record: Mapping[str, Any], engine_id: str, current: bytes | None) -> str | list[str]:
    """What a rollback takes back from the probe bindings file: "unchanged", "restore" (the file is
    still exactly this request's write over its snapshot) or the symbols of this request's own
    entries still there. Read only."""
    context = record["context"]
    meta = context["snapshots"]["probe_bindings"]
    digest = None if current is None else _sha(current)
    if digest == meta["sha256"]:
        return "unchanged"  # this request's write never landed
    if (context.get("probe_bindings_base_sha256") == meta["sha256"]
            and digest == context.get("probe_bindings_after_sha256")):
        return "restore"
    added = context.get("probe_bindings_added")
    if not added:
        return []  # this request added nothing, so nothing here is its own
    view = _probe_bindings_change(pb.strict_view, current)
    return [symbol for symbol in added if engine_id in view.engines_for(symbol)]


def _rollback_probe_bindings(ops: Ops, record: dict[str, Any], engine_id: str) -> list[str]:
    """Take back only this request's own probe entry (C6d fix c). When the file is still exactly
    what this request wrote over its snapshot, put the snapshot back byte for byte (fix b);
    otherwise remove the engine from the symbols this request added and keep every other entry.
    Returns what was undone."""
    context = record["context"]
    current = _read_bounded(ops.probe_bindings, pb.MAX_FILE_BYTES)
    plan = _probe_bindings_undo(record, engine_id, current)
    if plan == "unchanged":
        return []
    if plan == "restore":
        ops.restore(record, "probe_bindings")
        return ["probe_bindings"]
    added = context.get("probe_bindings_added")
    if not added:
        return []  # this request added nothing, so nothing here is its own
    data = _probe_bindings_change(pb.release_engine, current, engine_id, added)
    if data is not None:
        _write_bindings_file(ops.probe_bindings, data)
    return [f"probe_bindings:{symbol}" for symbol in plan]


def _touched(record: Mapping[str, Any]) -> list[str]:
    """The steps a rollback considers: every completed step and the one in flight."""
    touched = list(record["steps"])
    current = record["context"].get("current_step")
    if current and current not in touched:
        touched.append(current)
    return touched


def _rollback_overtaken(registry: er.Registry, record: Mapping[str, Any], engine_id: str) -> bool:
    """True when the registry no longer holds the assignment generation this request wrote, so a
    rollback undoes nothing (C6d fix d). A registry step still in flight that never captured its
    generation counts as overtaken once the registry moved past the generation it started from
    while holding no assignment of this request (a release came after it)."""
    context = record["context"]
    holder = registry.assignments.get(engine_id)
    captured = context.get("assignment")
    if captured is not None:
        return not _same_generation(holder, captured)
    if holder is not None and holder.get("request_id") == record["request_id"]:
        return False
    if "registry" in record["steps"]:
        return True
    return (context.get("current_step") == "registry"
            and registry.generation != (context.get("registry_before") or {}).get("generation"))


def _rollback_plan(ops: Ops, record: Mapping[str, Any], engine_id: str, registry: er.Registry) -> dict[str, Any]:
    """Read only (`repair` report): what `repair --rollback` would take back and leave."""
    context = record["context"]
    touched = _touched(record)
    if _rollback_overtaken(registry, record, engine_id):
        return {"superseded": True, "undo": [], "leave": touched}
    snapshots = context.get("snapshots", {})
    undo: list[str] = []
    leave: list[str] = []
    for step in reversed(touched):
        try:
            if step in ("lifecycle", "overrides") and step in snapshots:
                state = _snapshot_state(record, step)
                (undo if state == "ours" else leave if state == "changed" else []).append(step)
            elif step == "bindings" and step in snapshots:
                state = _snapshot_state(record, step)
                if state == "ours":
                    undo.append(step)
                elif state == "changed":
                    _, given, kept = _main_bindings_undo(record, engine_id, Path(snapshots[step]["path"]))
                    undo.extend(f"bindings:{symbol}" for symbol in given)
                    leave.extend(f"bindings:{symbol}" for symbol in kept)
            elif step == "probe_bindings" and step in snapshots:
                plan = _probe_bindings_undo(record, engine_id, _read_bounded(ops.probe_bindings, pb.MAX_FILE_BYTES))
                if plan == "restore":
                    undo.append(step)
                elif isinstance(plan, list):
                    undo.extend(f"probe_bindings:{symbol}" for symbol in plan)
            elif step == "trial" and context.get("trial_id"):
                store = ops.trials()
                if context["trial_id"] in store.list() and store.get(context["trial_id"]).closed is None:
                    undo.append(step)
            elif step == "registry" and "registry_before" in context:
                holder = registry.assignments.get(engine_id)
                if holder is not None and holder.get("request_id") == record["request_id"]:
                    undo.append(step)
        except Exception as exc:  # an undo that would fail: named, never raised from a report
            leave.append(f"{step}: {getattr(exc, 'code', type(exc).__name__)}")
    return {"superseded": False, "undo": undo, "leave": leave}


def _rollback_probe(ops: Ops, record: dict[str, Any], engine_id: str) -> None:
    """Undo every write this request made, newest first; the request ends rolled_back, or stays
    started (for the audit) when an undo itself fails. C6d fix d: only while the registry still
    holds the assignment generation this request wrote. When a release (and perhaps a reprobe)
    overtook it, every entry there now is someone else's: nothing is undone, the request ends
    superseded and rollback_superseded is journaled. C6e: each undo restores only the entries this
    request wrote; what it leaves standing and what it took back land in context.rollback."""
    context = record["context"]
    touched = _touched(record)
    context.pop("rollback_errors", None)
    try:
        registry = ops.registry()
    except Exception as exc:  # ownership cannot be proven, so nothing is undone; the audit names it
        context["rollback_errors"] = [f"registry: {type(exc).__name__}: {exc}"[:200]]
        if "lifecycle_after_sha256" in context:
            context["rollback_errors"].append("lifecycle: restore_conflict: registry ownership unavailable")
        context["rollback"] = {"undone": [], "left": touched}
        ops.save_request(record)
        return
    holder = registry.assignments.get(engine_id)
    captured = context.get("assignment")
    if _rollback_overtaken(registry, record, engine_id):
        context["rollback"] = {"undone": [], "left": touched}
        if "lifecycle_after_sha256" in context:
            context["rollback_errors"] = ["lifecycle: restore_conflict: assignment generation superseded"]
        _supersede(ops, record, engine_id, "rollback_superseded", "rollback", holder)
        return
    overtaken: list[Any] = []
    errors = []
    undone: list[str] = []
    left: list[str] = []
    for step in reversed(touched):
        try:
            if step == "probe_bindings" and step in context.get("snapshots", {}):
                undone.extend(_rollback_probe_bindings(ops, record, engine_id))
            elif step == "bindings" and step in context.get("snapshots", {}):
                given, kept = _rollback_main_bindings(ops, record, engine_id)
                undone.extend(given)
                left.extend(kept)
            elif step in ("overrides", "lifecycle") and step in context.get("snapshots", {}):
                state = _snapshot_state(record, step)
                if state == "ours" or (step == "lifecycle" and "lifecycle_after_sha256" in context):
                    # Even a change seen before this read must go through the store's CAS.
                    ops.restore(record, step)
                    undone.append(step)
                elif state == "changed":  # a newer write (a halt after the crash) stands
                    left.append(step)
                    if step == "lifecycle":
                        errors.append("lifecycle: restore_conflict: lifecycle write ownership unavailable")
            elif step == "trial" and context.get("trial_id"):
                store = ops.trials()
                if context["trial_id"] in store.list() and store.get(context["trial_id"]).closed is None:
                    store.close(context["trial_id"], "ABANDONED", _sha(_canonical(record)),
                                f"engine_ops probe {record['request_id']} rolled back")
                    undone.append(step)
            elif step == "registry" and "registry_before" in context:
                before = context["registry_before"]
                taken: list[bool] = []

                def change(doc: dict[str, Any]) -> bool:
                    assignments, engines = doc["assignments"], doc["loss_breakers"]["engines"]
                    held = assignments.get(engine_id)
                    if held == before["assignment"] and engines.get(engine_id) == before["engine_pct"]:
                        return False
                    # The same ownership check, under the registry lock: only this request's own
                    # generation is taken back; a newer one stands.
                    if (held is None or held.get("request_id") != record["request_id"]
                            or (captured is not None and held.get("since") != captured.get("since"))):
                        overtaken.append(held)
                        return False
                    if before["assignment"] is None:
                        assignments.pop(engine_id, None)
                    else:
                        assignments[engine_id] = before["assignment"]
                    if before["engine_pct"] is None or before["assignment"] is None:
                        engines.pop(engine_id, None)
                    else:
                        engines[engine_id] = before["engine_pct"]
                    taken.append(True)
                    return True

                ops.registry_store().mutate("probe.rollback", change, request_id=record["request_id"],
                                            now=ops.now)
                if taken:
                    undone.append(step)
        except Exception as exc:  # keep undoing the rest; the audit names what is left
            errors.append(f"{step}: {type(exc).__name__}: {exc}"[:200])
            if step == "lifecycle" and step not in left:
                left.append(step)
    context["rollback"] = {"undone": undone, "left": left}
    if errors:
        context["rollback_errors"] = errors
    if overtaken:  # a newer generation reached the registry meanwhile; it stands
        _supersede(ops, record, engine_id, "rollback_superseded", "registry", overtaken[0])
        return
    if not errors:
        record["state"] = "rolled_back"
        record["steps"] = []
        context.pop("current_step", None)
    ops.save_request(record)


def _trusted_staging_parent(info: os.stat_result) -> bool:
    """Only root may be able to write a parent; anyone else could swap a child directory in."""
    return stat.S_ISDIR(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022


def _staging_root(ops: Ops, engine_id: str, *, apply: bool) -> str:
    """Inspect or provision staging; directory descriptors prevent symlink traversal. Only
    a parent the walk creates inside must be root-owned and not group or other writable
    (checked on the descriptor mkdir uses), so no other user can replace a component the
    walk just created. Traversing an existing component needs no trust: on the runner
    /var/lib/leafhft is leafhft-owned 0750 by design, above root-owned engine-evidence."""
    try:
        if os.name == "nt" or getattr(os, "geteuid", lambda: -1)() != 0:
            return "skipped_not_root"
        engine_id = _engine_id(engine_id)
        target = Path(os.path.abspath(ops.evidence_dir)) / engine_id / "staging"
        # Inspect every component, including the configured evidence root. Dry runs
        # never mkdir, open a lock, or write a receipt.
        existing = parent = None
        for path in (*reversed(target.parents), target):
            try:
                info = path.lstat()
            except FileNotFoundError:
                # The first missing component would be created: its parent must be trusted.
                # Everything below it would be created by root inside root's own directory.
                if parent is None or not _trusted_staging_parent(parent):
                    return "staging_path_unsafe"
                break
            if not stat.S_ISDIR(info.st_mode):
                return "staging_path_unsafe"
            if path == target:
                existing = info
            parent = info
        import pwd
        import grp
        try:
            user = pwd.getpwnam(OWNER_BOOK_USER)
            uid, gid = user.pw_uid, grp.getgrgid(user.pw_gid).gr_gid
        except KeyError:
            return "user_missing"
        if existing is not None:
            return "present" if (existing.st_uid, existing.st_gid) == (uid, gid) else "wrong_owner"
        if not apply:
            return "would_create"
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
        with ExitStack() as stack:
            fd = os.open(target.anchor, flags)
            stack.callback(os.close, fd)
            for index, part in enumerate(target.parts[1:], 1):
                created = False
                try:
                    child = os.open(part, flags, dir_fd=fd)
                except FileNotFoundError:
                    # Trust only the parent the walk creates inside, re-checked on the very
                    # descriptor mkdir uses: the path inspection above can be stale, and a
                    # directory planted higher up resolves here to its planter's owner.
                    if not _trusted_staging_parent(os.fstat(fd)):
                        return "staging_path_unsafe"
                    try:
                        os.mkdir(part, 0o755, dir_fd=fd)
                        created = True
                    except FileExistsError:
                        pass
                    child = os.open(part, flags, dir_fd=fd)
                stack.callback(os.close, child)
                last = index == len(target.parts) - 1
                if created:
                    # Defence in depth: chown only the empty directory root just made,
                    # never a directory swapped in between mkdir and open.
                    info = os.fstat(child)
                    if info.st_uid != 0 or info.st_nlink != 2:
                        return "staging_path_unsafe"
                    os.fchown(child, uid if last else 0, gid if last else 0)
                    os.fchmod(child, 0o755)
                elif last:
                    info = os.fstat(child)
                    return "present" if (info.st_uid, info.st_gid) == (uid, gid) else "wrong_owner"
                fd = child
        return "created"
    except Exception:
        # Permission errors and races are unsafe too; provisioning must never
        # undo a successful probe or weaken the judge's evidence requirements.
        return "staging_path_unsafe"


def ensure_staging_root(ops: Ops, engine_id: str) -> str:
    return _staging_root(ops, engine_id, apply=True)


def cmd_repair_staging(ops: Ops, a: argparse.Namespace) -> int:
    rid = _file_id(a.request_id, "request_id") if a.apply or a.request_id else None
    registry = ops.registry()
    counts: Counter[str] = Counter()
    for engine_id, assignment in sorted(registry.assignments.items()):
        account = registry.accounts.get(assignment["account_id"], {})
        if assignment["role"] != "probe" or account.get("kind") != "owner":
            continue
        outcome = (ensure_staging_root(ops, engine_id) if a.apply
                   else _staging_root(ops, engine_id, apply=False))
        counts[outcome] += 1
        result = {"engine_id": engine_id, "staging": outcome, "applied": a.apply}
        # A bad staging path can still have a safe receipts sibling. Never write
        # through an unsafe engine/evidence/receipts directory, or as a non-root caller.
        if a.apply and outcome != "skipped_not_root":
            directory = Path(os.path.abspath(ops.evidence_dir)) / engine_id / "receipts"
            safe = True
            for path in (*reversed(directory.parents), directory):
                try:
                    if not stat.S_ISDIR(path.lstat().st_mode):
                        safe = False
                        break
                except FileNotFoundError:
                    continue
                except OSError:
                    safe = False
                    break
            if safe:
                ops.write_receipt(engine_id, "repair-staging", {
                    "schema": RECEIPT_SCHEMA, "verb": "repair-staging", "subject": engine_id,
                    "request_id": rid, "at": ops.now.isoformat(), "result": result})
        ops.emit(result, f"{engine_id}: {outcome}")
    ops.emit({"outcomes": dict(counts)}, "outcomes: " + ", ".join(
        f"{outcome}={count}" for outcome, count in sorted(counts.items())))
    return 1 if any(counts[code] for code in (
        "wrong_owner", "staging_path_unsafe", "user_missing", "skipped_not_root")) else EXIT_OK


def cmd_probe(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    symbols = _symbols(a.symbols)
    approval_id = _file_id(a.approval, "approval")
    if type(a.window_days) is not int or not 1 <= a.window_days <= 90:
        raise Refused("invalid_window", "--window-days is 1..90")
    if a.window_days < probe_bar.WINDOW_DAYS and not a.oq_only:
        raise Refused("window_shorter_than_bar",
                      f"the probe bar window is {probe_bar.WINDOW_DAYS} d; a shorter sample needs --oq-only")
    code_sha = a.code_sha
    if code_sha is None:
        from .build import build_identity
        code_sha = str(build_identity().get("git_sha") or "")
    if not _HEX40.fullmatch(code_sha):
        raise Refused("code_sha_unknown", "pass --code-sha with the 40 hex deployed commit")
    displace = bool(getattr(a, "displace", False))
    args = {"symbols": symbols, "approval": approval_id, "bind": bool(a.bind),
            "window_days": a.window_days, "oq_only": bool(a.oq_only), "code_sha": code_sha}
    if displace:  # only when set, so a co-host request keeps the args digest it always had
        args["displace"] = True
    bind = "displace" if displace else "cohost" if a.bind else None

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        return _probe_perform(ops, record, engine_id, symbols, approval_id, bind,
                              a.window_days, bool(a.oq_only), code_sha)

    receipt, result, replayed = ops.mutate("probe", engine_id, a.request_id, args, perform)
    code = ops.applied("probe", receipt, result, replayed)
    if "staging" in result:
        prefix = "staging" if result["staging"] in ("created", "present") else "warning: staging"
        print(f"{prefix}: {result['staging']}")
    return code


def _probe_perform(ops: Ops, record: dict[str, Any], engine_id: str, symbols: list[str],
                   approval_id: str, bind: str | None, window_days: int, oq_only: bool,
                   code_sha: str) -> dict[str, Any]:
    """`bind` is None (no binding), "cohost" (the probe bindings file only) or "displace" (the
    main bindings file, only when the approval card named the displaced engine)."""
    request_id = record["request_id"]
    context = record["context"]
    if record["steps"] or context.get("current_step"):
        # C6e, defense in depth: a probe is never resumed, even by a caller that bypasses mutate.
        raise Refused("transaction_interrupted", _interrupted_detail(record))
    registry = ops.registry()
    approval = ops.load_approval(approval_id)
    account_id = approval["account"]
    # S7 A L2: a lane account's probe lives in this one store under the registry account key; its
    # bindings reach the lane only through the published lease, so the owner probe bindings file and
    # hosts file are never read or written for it.
    lane_key = account_id if _account_lane(registry.accounts.get(account_id)) is not None else None
    if lane_key is not None and bind == "displace":
        raise Refused(TENANT_LADDER_DEFERRED, f"--displace on lane {lane_key} waits for tenant evidence (S7 D)")
    if lane_key is not None and bind != "cohost":
        # A lane book hosts exactly what its lease grants, so an unbound tenant probe would still be
        # hosted and trade while its receipt said bound: false. Tenant probes are always bound.
        raise Refused(LANE_PROBE_REQUIRES_BIND, f"a probe on lane {lane_key} is hosted through its lease; pass --bind")
    manifest, manifest_error = ops.manifest(engine_id)
    min_expiry = None if oq_only else ops.now + timedelta(days=window_days)
    failures = probe_failures(ops, engine_id, account_id, symbols, registry=registry,
                              manifest=manifest, manifest_error=manifest_error, bind=bind == "displace",
                              approval=(approval, request_id, min_expiry), first_only=True)
    if failures:
        raise Refused(*failures[0])
    if lane_key is not None:
        if ops.roots_problem is not None:  # before any write
            raise Refused(ROOTS_AMBIGUOUS, ops.roots_problem)
        # The lane's books must be able to name themselves (the id the lease carries); without it
        # nothing could ever be leased, and a later identity would turn this probe live unseen.
        book_ids = ops.book_account_ids({lane_key: registry.accounts[lane_key]})
        if book_ids.get(lane_key) is None:
            raise Refused(LANE_BOOK_ACCOUNT_MISSING,
                          f"lane {lane_key} has no usable {LANE_IDENTITY_NAME} under the lane identity root "
                          f"({ops.book_id_problems.get(lane_key, 'identity_absent')})")
        try:
            problem = _tenant_capacity_problem(ops, registry, lane_key, engine_id, symbols)
        except CanaryError as exc:  # the store cannot be counted: never a tenant write past the cap
            raise Refused(TENANT_CAPACITY, f"the lifecycle store cannot be counted: {exc}"[:200]) from None
        if problem is not None:
            raise Refused(*problem)
        context["lane"] = lane_key
    elif bind == "cohost":
        missing = _probe_hosts_missing(ops, symbols)
        if missing:
            raise Refused("probe_hosts_missing",
                          f"{ops.probe_bindings.parent / PROBE_HOSTS_NAME} does not list {missing}, so no "
                          "book would host the probe; C8 order: add the symbol to the hosts file, then "
                          "bind, then the same-digest restart of that book")
        # max_per_book and a malformed probe file refuse here, before the first write.
        _probe_bindings_change(pb.bind_engine, _read_bounded(ops.probe_bindings, pb.MAX_FILE_BYTES),
                               symbols, engine_id)
    elif bind == "displace":
        view = er.read_bindings(ops.source_for(account_id).bindings_path)
        displaced = ",".join(sorted({view.symbols[symbol] for symbol in symbols
                                     if view.symbols.get(symbol) not in (None, engine_id)}))
        shown = _card_displaces(ops, approval_id)
        if not displaced or shown != displaced:
            raise Refused("displace_not_on_card",
                          f"--displace needs an approval card that showed displaces: {displaced or '<engine>'}; "
                          f"approval {approval_id} card shows {shown!r}")
    policy = _probe_policy(ops, engine_id, manifest)
    if manifest is None or policy is None:
        raise Refused("manifest_conformed_or_waived", "the probe needs a manifest and its pinned policy")
    # Preserve the existing refusal order through approval, bindings and pinned policy.
    # Only an authenticated probe approval reaches the new sizing checks, before any write.
    sizing = _probe_approval_sizing(ops, approval)
    # Old one-contract approvals retain their semantics. A fractional approval
    # must agree with the pinned policy the lifecycle actually trades.
    if sizing != PROBE_SIZING:
        try:
            count = _probe_sizing(sizing)
        except Refused as exc:
            raise Refused("approval_valid", exc.detail) from exc
        actual = getattr(policy, "fixed_count", None) or PROBE_SIZING
        if Decimal(str(actual)) != Decimal(count):
            raise Refused("approval_valid", "probe sizing does not match the pinned policy fixed_count")
    account = registry.accounts[account_id]
    expires_at = _utc_time(approval["expires_at"]).isoformat()
    source = ops.source_for(account_id) if bind == "displace" else None
    try:
        if "registry_before" not in context:
            current = registry.assignments.get(engine_id)
            context["registry_before"] = {
                "assignment": None if current is None else json.loads(json.dumps(current)),
                "engine_pct": registry.doc["loss_breakers"]["engines"].get(engine_id),
                "generation": registry.generation}
            if bind == "displace":
                view = er.read_bindings(source.bindings_path)
                context["previous_bindings"] = {symbol: view.symbols.get(symbol) for symbol in symbols}
            ops.save_request(record)

        if "registry" not in record["steps"]:
            ops.begin(record, "registry")
            after = ops.registry_store().assign(
                engine_id, account_id, "probe", symbols, identity_digest=identity_digest(manifest),
                manifest_digest=manifest_digest(manifest), request_id=request_id,
                approval_id=approval_id, previous_bindings=context.get("previous_bindings"), now=ops.now)
            context["assignment"] = _assignment_identity(engine_id, after.assignments[engine_id],
                                                         after.generation)
            ops.done(record, "registry")

        if ops.begin(record, "lifecycle"):
            _probe_holds(ops, record, engine_id, "lifecycle")
            canary = ops.canary()
            ops.snapshot(record, "lifecycle", canary.path_for(engine_id), MAX_LIFECYCLE_BYTES)
            current = canary.optional(engine_id)
            if not (current is not None and current["state"] == "probe"
                    and current.get("approval_id") == approval_id):
                others = _other_account_engines(ops, account_id, ops.registry())
                try:
                    with _born_as(ops.lifecycle_dir):  # the record is born the book's, never root 0600
                        canary.probe(SimpleNamespace(engine_id=engine_id, policy=policy), account=account_id,
                                     authorization_ref=approval_id, expires_at=expires_at,
                                     other_account_engine_ids=others, now=ops.now, approval_id=approval_id)
                        _lifecycle_readable(canary.path_for(engine_id))
                finally:  # C6e: a rollback restores the snapshot only over this exact write
                    _record_written(ops, record, "lifecycle", canary.path_for(engine_id))
            ops.done(record, "lifecycle")

        if ops.begin(record, "trial"):
            _probe_holds(ops, record, engine_id, "trial")
            activation_at = context.setdefault("activation_at", ops.now.isoformat())
            family = max(1, int(ops.registry().doc["max_concurrent_probes"]))
            registration = probe_bar.probe_registration(
                engine_id, account_id, symbols, family, activation_at, code_sha=code_sha,
                policy_digest=policy_digest(policy))
            context["trial_id"] = registration.trial_id
            ops.save_request(record)
            store = ops.trials()
            if registration.trial_id not in store.list():
                store.register(registration)
            ops.done(record, "trial")

        if lane_key is not None:
            # A lane's overrides file is tenant-writable: opened never, recorded as a no-op row.
            for row in (LANE_OVERRIDES_ROW, LANE_BINDINGS_ROW):
                if ops.begin(record, row):
                    ops.done(record, row)
        entries = _override_entries(ops.overrides_path(account), engine_id)
        disabled = [key for key, entry in entries if entry.get("enabled") is False and not entry.get("policy")]
        if disabled and ops.begin(record, "overrides"):
            _probe_holds(ops, record, engine_id, "overrides")
            path = ops.overrides_path(account)
            ops.snapshot(record, "overrides", path, MAX_OVERRIDES_BYTES)
            catalog = ops.catalog()
            engine = catalog.get(engine_id)
            overrides = AccountOverrides(path, catalog)
            try:
                for key in disabled:
                    previous = overrides.get(key, engine_id)
                    overrides.configure(key, engine_id, account_revision(key, engine, previous), enabled=True)
            finally:  # C6e: a rollback restores the snapshot only over this exact write
                _record_written(ops, record, "overrides", path)
            ops.done(record, "overrides")

        if bind == "cohost" and lane_key is None and "probe_bindings" not in record["steps"]:
            _probe_holds(ops, record, engine_id, "probe_bindings")
            path = ops.probe_bindings
            # The CURRENT bytes, read under the ops lock (C6d fix c): a probe another request bound
            # meanwhile stays bound; the snapshot only rolls back this entry.
            before = _read_bounded(path, pb.MAX_FILE_BYTES)
            ops.begin(record, "probe_bindings")
            ops.snapshot(record, "probe_bindings", path, pb.MAX_FILE_BYTES)
            data = _probe_bindings_change(pb.bind_engine, before, symbols, engine_id)
            if data is not None:
                view = pb.strict_view(before)
                context["probe_bindings_after_sha256"] = _sha(data)
                context["probe_bindings_base_sha256"] = None if before is None else _sha(before)
                context["probe_bindings_added"] = [symbol for symbol in symbols
                                                   if engine_id not in view.engines_for(symbol)]
                ops.save_request(record)
                _write_bindings_file(path, data)
                loaded = pb.load_probe_bindings(path)  # the book's reader must accept what was written
                if loaded.errors:
                    raise Refused("probe_bindings_invalid", loaded.errors[0])
            ops.done(record, "probe_bindings")

        if bind == "displace" and "bindings" not in record["steps"]:
            _probe_holds(ops, record, engine_id, "bindings")
            ops.begin(record, "bindings")
            ops.snapshot(record, "bindings", source.bindings_path, er.MAX_BINDINGS_BYTES)
            # The current bytes under the ops lock, which the snapshot just saved, so release can
            # still restore the snapshot.
            before = _read_bounded(source.bindings_path, er.MAX_BINDINGS_BYTES)
            data = _bound_bytes(before, symbols, engine_id)
            context["bindings_after_sha256"] = _sha(data)
            ops.save_request(record)
            _write_bindings_file(source.bindings_path, data)
            er.read_bindings(source.bindings_path)  # the reader must accept what was written
            ops.done(record, "bindings")

        if ops.begin(record, "approval"):
            _probe_holds(ops, record, engine_id, "approval")
            ops.consume_approval(approval_id, request_id)
            ops.done(record, "approval")
    except _TransactionSuperseded:  # the newer state stands: no rollback, the request is retired
        raise
    except BaseException:
        try:
            _rollback_probe(ops, record, engine_id)
        except Exception as error:
            # Rollback persistence/journaling must never replace the triggering refusal.
            record["context"].setdefault("bookkeeping_errors", []).append(
                f"rollback: {type(error).__name__}: {error}"[:300])
        raise
    result = _probe_result(ops, record, engine_id, account_id, symbols, bind, expires_at)
    if bind is not None and account.get("kind") == "owner":
        result["staging"] = ensure_staging_root(ops, engine_id)
    return result


def _probe_result(ops: Ops, record: Mapping[str, Any], engine_id: str, account_id: str, symbols: list[str],
                  bind: str | None, expires_at: str) -> dict[str, Any]:
    """The probe receipt's result, from a fully written transaction (probe and `repair --finish`)."""
    context = record["context"]
    lifecycle = ops.canary().get(engine_id)
    return {"engine_id": engine_id, "account_id": account_id, "symbols": symbols, "role": "probe",
            "registry_generation": ops.registry().generation, "lifecycle_state": lifecycle["state"],
            "expires_at": expires_at, "trial_id": context["trial_id"], "bound": bind is not None,
            "binding": bind, "previous_bindings": context.get("previous_bindings")}


# ---------------------------------------------------------------- repair (C6e)

def _probe_binding(args: Mapping[str, Any]) -> str | None:
    return "displace" if args.get("displace") else "cohost" if args.get("bind") else None


def _generation_holds(registry: er.Registry, record: Mapping[str, Any], engine_id: str) -> bool:
    """The registry still holds, for this engine, the generation the request captured (a pre-fix-d
    record captured nothing: the holder's request id is this one)."""
    holder = registry.assignments.get(engine_id)
    captured = record["context"].get("assignment")
    if captured is not None:
        return _same_generation(holder, captured)
    return holder is not None and holder.get("request_id") == record["request_id"]


def _approval_consumed(ops: Ops, record: Mapping[str, Any]) -> bool:
    """The probe's approval consumption marker names this request."""
    approval_id = (record.get("args") or {}).get("approval")
    return type(approval_id) is str and ops.approval_consumer(_file_id(approval_id, "approval")) == record["request_id"]


def _probe_finish_problem(ops: Ops, record: Mapping[str, Any], engine_id: str,
                          registry: er.Registry) -> tuple[str, str] | None:
    """None when `repair --finish` may record this probe: every step through `approval` is done
    with nothing in flight, or every step before it is done, `approval` is in flight and the
    consumption marker already names this request (the process died between the marker and its
    step record); and the captured generation still holds. Otherwise the named refusal."""
    steps, in_flight = record["steps"], record["context"].get("current_step")
    if record["context"].get("lane") is not None:  # S7 A L2: a lane probe writes no bindings file
        needed = ["registry", "lifecycle", "trial", LANE_BINDINGS_ROW]
    else:
        needed = ["registry", "lifecycle", "trial"] + {"cohost": ["probe_bindings"], "displace": ["bindings"]}.get(
            _probe_binding(record["args"]), [])
    written = "approval" in steps and not in_flight
    window = (in_flight == "approval" and all(step in steps for step in needed)
              and _approval_consumed(ops, record))
    if not (written or window):
        missing = [step for step in [*needed, "approval"] if step not in steps]
        return ("repair_finish_incomplete",
                f"request {record['request_id']} is missing {missing} (in flight {in_flight!r}); "
                f"only a fully written probe finishes: use engine_ops repair {record['request_id']} --rollback")
    if not _generation_holds(registry, record, engine_id):
        return ("repair_superseded",
                f"the registry no longer holds the assignment generation request {record['request_id']} "
                f"wrote for {engine_id}; nothing is recorded")
    return None


def _repair_report(ops: Ops, record: Mapping[str, Any], engine_id: str) -> dict[str, Any]:
    """Read only: the interrupted transaction, the world it would act on, and what each action does."""
    registry = ops.registry()
    context = record["context"]
    holder = registry.assignments.get(engine_id)
    report = {"request_id": record["request_id"], "verb": record["verb"], "subject": engine_id,
              "state": record["state"], "steps": list(record["steps"]),
              "in_flight": context.get("current_step"), "assignment": context.get("assignment"),
              "holder": None if holder is None else {key: holder.get(key) for key in
                                                     ("account_id", "role", "request_id", "since")},
              "generation_holds": _generation_holds(registry, record, engine_id)}
    if record["verb"] == "release":
        report.update(approval_consumed=None, finishable=True, rollback_plan=None)
    else:
        report.update(approval_consumed=_approval_consumed(ops, record),
                      finishable=_probe_finish_problem(ops, record, engine_id, registry) is None,
                      rollback_plan=_rollback_plan(ops, record, engine_id, registry))
    return report


def _repair_record(ops: Ops, record: dict[str, Any], action: str, undone: list[str], left: list[str],
                   errors: list[str]) -> dict[str, str]:
    """Every finish or rollback that acts: a `repair` receipt, context.repair and a `repaired` row."""
    at = ops.now.isoformat()
    receipt = ops.write_receipt(record["subject"], "repair", {
        "schema": RECEIPT_SCHEMA, "verb": "repair", "subject": record["subject"],
        "request_id": record["request_id"], "at": at, "action": action, "undone": list(undone),
        "left": list(left), "errors": list(errors)})
    record["context"]["repair"] = {"action": action, "at": at, "receipt": receipt}
    ops.save_request(record)
    ops.journal(record["verb"], record["subject"], record["request_id"], "repaired", action=action,
                receipt=receipt["sha12"])
    return receipt


def _repair_finish(ops: Ops, record: dict[str, Any], engine_id: str) -> dict[str, Any]:
    """Finish an interrupted transaction and complete it the way mutate does. A probe is only
    recorded (completion advances the tenant lifecycle revision without changing its state); a
    release runs its remaining steps, each still gated on the captured generation."""
    args = record["args"]
    if record["verb"] == "release":
        result = _release_perform(ops, record, engine_id, bool(args.get("restore_bindings")))
    else:
        registry = ops.registry()
        problem = _probe_finish_problem(ops, record, engine_id, registry)
        if problem is not None:
            raise Refused(*problem)
        if record["context"].get("current_step") == "approval":
            ops.done(record, "approval")  # the marker already names this request
        approval = ops.load_approval(_file_id(args["approval"], "approval"))
        expires_at = _utc_time(approval["expires_at"]).isoformat()
        result = _probe_result(ops, record, engine_id, approval["account"], list(args["symbols"]),
                               _probe_binding(args), expires_at)
    result["repaired"] = {"action": "finish", "at": ops.now.isoformat()}
    ops.complete(record, result)
    return result


def cmd_repair(ops: Ops, a: argparse.Namespace) -> int:
    """`engine_ops repair <request-id> [--finish | --rollback]` (C6e): report an interrupted probe or
    release read-only, finish it, or roll a probe back restoring only the entries it wrote."""
    rid = _file_id(a.request_id, "request_id")
    action = "finish" if a.finish else "rollback" if a.rollback else None
    with _exclusive_lock(ops.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
        record = ops.load_request(rid)
        if record is None:
            raise Refused("request_not_found", f"no request {rid}")
        verb = record.get("verb")
        if verb not in NO_RESUME_VERBS:
            raise Refused("repair_not_supported",
                          f"{verb} {rid}: repair settles only {'/'.join(NO_RESUME_VERBS)}; rerun the same "
                          "--request-id to complete it")
        engine_id = _engine_id(record.get("subject"))
        stored = record["context"].get("repair") if isinstance(record.get("context"), dict) else None
        if (action is not None and isinstance(stored, dict) and stored.get("action") == action
                and record.get("state") in REPAIR_TERMINAL[action]):
            receipt = stored["receipt"]
            if record["state"] == "superseded":
                return ops.refuse("rollback_superseded", f"{rid} was already rolled back as superseded; "
                                                         f"repair receipt {receipt['sha12']}")
            return ops.applied("repair", receipt, {"request_id": rid, "action": action,
                                                   "state": record["state"]}, True)
        if not _interrupted(record):
            raise Refused("request_not_interrupted", f"{verb} {rid} is {record.get('state')}; nothing to repair")
        if action is None:
            report = _repair_report(ops, record, engine_id)
            ops.emit(report)
            return EXIT_OK
        if verb == "release" and action == "rollback":
            raise Refused("repair_rollback_not_allowed",
                          f"undoing a release would re-authorize {engine_id} without an approval; "
                          f"use engine_ops repair {rid} --finish")
        lanes = ops.subject_lanes(engine_id) | _context_lane(record)
        if action == "finish":
            try:
                result = _repair_finish(ops, record, engine_id)
                receipt = _repair_record(ops, record, "finish", [], [], [])
            finally:  # S7 A L2, still under the ops lock, on every exit path
                ops.publish_leases(lanes | _context_lane(record))
            return ops.applied("repair", receipt, {"request_id": rid, "action": "finish",
                                                   "state": record["state"], "result": result}, False)
        try:
            _rollback_probe(ops, record, engine_id)
            ops.hand_lifecycle(quiet=True)  # a rollback rewrites lifecycle records too
        except Exception as error:
            if not record["context"].get("rollback_errors") and record["state"] != "superseded":
                raise
            # A failed save/hand-over cannot turn an already refused rollback into exit 3.
            print(f"warning: failure bookkeeping: rollback: {type(error).__name__}: {error}"[:400],
                  file=sys.stderr)
        finally:  # S7 A L2: the rolled-back engine leaves its lane's lease, whatever the rollback did
            ops.publish_leases(lanes)
        outcome = record["context"].get("rollback") or {}
        undone, left = list(outcome.get("undone") or []), list(outcome.get("left") or [])
        errors = list(record["context"].get("rollback_errors") or []) if record["state"] == "started" else []
        try:
            consumed = _approval_consumed(ops, record)
            if consumed:
                left.append("approval")
            receipt = _repair_record(ops, record, "rollback", undone, left, errors)
        except Exception as error:
            if record["state"] == "rolled_back":
                raise
            print(f"warning: failure bookkeeping: repair: {type(error).__name__}: {error}"[:400],
                  file=sys.stderr)
            code = "rollback_superseded" if record["state"] == "superseded" else "repair_incomplete"
            return ops.refuse(code, f"{rid}: {'; '.join(errors or record['context'].get('rollback_errors') or [])}")
        body = {"request_id": rid, "action": "rollback", "state": record["state"], "undone": undone,
                "left": left, "errors": errors}
        if consumed:
            body["approval"] = "consumed; it stays consumed, so a new probe needs a new approval"
        if record["state"] == "superseded":
            return ops.refuse("rollback_superseded",
                              f"{rid}: the registry no longer holds the generation it wrote, so nothing was "
                              f"undone; repair receipt {receipt['sha12']}")
        if record["state"] != "rolled_back":
            return ops.refuse("repair_incomplete", f"{rid}: {'; '.join(errors)}; rerun "
                                                   f"engine_ops repair {rid} --rollback")
        return ops.applied("repair", receipt, body, False)


def cmd_probe_activate(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    data = _read_bounded(Path(a.activation), MAX_ACTIVATION_BYTES)
    if data is None:
        raise Refused("activation_missing", a.activation)
    raw = _strict_loads(data, "activation_invalid")
    fields = {"activated_at", "population_start_ns", "flat", "books", "snapshot"}
    if not isinstance(raw, dict) or set(raw) != fields:
        raise Refused("activation_invalid", f"expected exactly {sorted(fields)}")
    args = {"activation_sha256": _sha(data)}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        probe = _probe_request_for(ops, ops.registry().assignments.get(engine_id), engine_id)
        trial_id = None if probe is None else probe["context"].get("trial_id")
        if trial_id is None:
            raise Refused("no_probe_trial", f"{engine_id} has no probe trial")
        store = ops.trials()
        if ops.begin(record, "trial"):
            trial = store.get(trial_id)
            if trial.activation is None:
                # C13 fix g: every activation takes the trial's opening balance, read before it; without
                # a trusted read nothing activates. C13 fix i: the opening is written BEFORE the
                # activation (_capture_opening_then_activate), so no activation exists without it.
                opening, unavailable = _venue_snapshot(ops, engine_id, _current_account(ops, engine_id))
                if unavailable is not None:
                    raise Refused("opening_balance_unavailable", f"{unavailable[0]}: {unavailable[1]}"[:300])
                _capture_opening_then_activate(ops, engine_id, trial_id, opening, lambda: store.activate(
                    trial_id, Activation(trial_id=trial_id, registration_hash=trial.registration_hash, **raw)))
            else:
                # C13 fix i: a legacy activation without its opening is repaired before anything else;
                # one that cannot be repaired yet stays unjudged (the judge HOLDs opening_balance_missing).
                _repair_opening_balance(ops, engine_id, trial_id, _current_account(ops, engine_id))
            ops.done(record, "trial")
        return {"engine_id": engine_id, "trial_id": trial_id,
                "activated_at": store.get(trial_id).activation.activated_at}

    receipt, result, replayed = ops.mutate("probe-activate", engine_id, a.request_id, args, perform)
    return ops.applied("probe-activate", receipt, result, replayed)


def cmd_halt(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    if type(a.reason) is not str or not _REASON.fullmatch(a.reason):
        raise Refused("invalid_reason", f"--reason must match {_REASON.pattern}")
    args = {"reason": a.reason}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        canary = ops.canary()
        if ops.begin(record, "lifecycle"):
            current = canary.optional(engine_id)
            if current is None:
                raise Refused("lifecycle_absent", f"{engine_id} has no lifecycle record")
            if not (current["state"] == "halted" and a.reason in _stop_codes(current)):
                with _born_as(ops.lifecycle_dir):
                    canary.halt(engine_id, a.reason, now=ops.now)
                    _lifecycle_readable(canary.path_for(engine_id))
            ops.done(record, "lifecycle")
        state = canary.get(engine_id)
        return {"engine_id": engine_id, "lifecycle_state": state["state"],
                "stop_reasons": _stop_codes(state)}

    receipt, result, replayed = ops.mutate("halt", engine_id, a.request_id, args, perform)
    return ops.applied("halt", receipt, result, replayed)


# ---------------------------------------------------------------- the ladder, graduation, retirement (C13)

def oq_trust_problem(status: os.stat_result, *, directory: bool, owner_uid: int, modes: bool) -> str | None:
    """Pure: why one path of the OQ evidence set is not the judge's own (C13 fix c), or None. It must
    not be a symlink, must be a directory (or a regular file), owned by `owner_uid` (root in
    production) and, where the host has POSIX modes, exactly 0755 (a directory) or 0444 (a file):
    a file the leafhft user wrote, or could still write or rename, never qualifies a probe."""
    mode = status.st_mode
    if stat.S_ISLNK(mode):
        return "is a symlink"
    if directory and not stat.S_ISDIR(mode):
        return "is not a directory"
    if not directory and not stat.S_ISREG(mode):
        return "is not a regular file"
    if status.st_uid != owner_uid:
        return f"is owned by uid {status.st_uid}, not {owner_uid}"
    want = OQ_DIR_MODE if directory else OQ_FILE_MODE
    if modes and stat.S_IMODE(mode) != want:
        return f"has mode {stat.S_IMODE(mode):04o}, not {want:04o}"
    return None


def _oq_trust() -> tuple[int, bool] | None:
    """(owner uid, POSIX modes checked) the OQ evidence set must carry: root and the exact modes on a
    POSIX host; the test-only owner in _OQ_TEST_OWNER_UID when a test sets it. None where nothing can
    be proven (a non-POSIX host without the test override): the set is then never trusted."""
    if _OQ_TEST_OWNER_UID is not None:
        return _OQ_TEST_OWNER_UID, os.name == "posix"
    if os.name != "posix":
        return None
    return 0, True


def _oq_set_problem(ops: Ops, engine_id: str) -> str | None:
    """Why <oq-dir> and <oq-dir>/<engine_id> are not a trusted evidence directory, or None
    (_trusted_set_problem)."""
    return _trusted_set_problem(ops.oq_dir, engine_id)


def _trusted_set_problem(base: Path, engine_id: str) -> str | None:
    """Why <base> and <base>/<engine_id> are not a trusted root-owned evidence directory, or None:
    each is oq_trust_problem-clean, and (POSIX) every component above them up to / (at most
    MAX_OQ_CHAIN) is no symlink, owned by root or the trusted owner, and group or other writable only
    when root-owned and sticky, so the leafhft user can neither write into the set nor rename it
    away. The judge's OQ set and the venue snapshot's set are both judged by it."""
    trust = _oq_trust()
    if trust is None:
        return "this host cannot prove file ownership (no POSIX owner), so no OQ evidence is trusted"
    owner, modes = trust
    for directory in (base, base / engine_id):
        try:
            status = os.lstat(directory)
        except OSError as exc:
            return f"{directory}: {type(exc).__name__}"
        problem = oq_trust_problem(status, directory=True, owner_uid=owner, modes=modes)
        if problem is not None:
            return f"{directory} {problem}"
    if not modes:
        return None
    absolute = Path(os.path.abspath(base))
    chain = list(absolute.parents)
    if len(chain) > MAX_OQ_CHAIN:
        return f"{absolute} is more than {MAX_OQ_CHAIN} components deep"
    for component in chain:
        try:
            status = os.lstat(component)
        except OSError as exc:
            return f"{component}: {type(exc).__name__}"
        if stat.S_ISLNK(status.st_mode):
            return f"{component} is a symlink"
        if status.st_uid not in (0, owner):
            return f"{component} is owned by uid {status.st_uid}"
        if status.st_mode & (stat.S_IWGRP | stat.S_IWOTH) and not (status.st_uid == 0
                                                                   and status.st_mode & stat.S_ISVTX):
            return f"{component} is group or other writable"
    return None


def _read_oq_file(path: Path, limit: int) -> bytes | None:
    """One file of the OQ evidence set, read only when the judge's own: opened without following a
    final symlink (O_NOFOLLOW, O_NONBLOCK), then the descriptor judged by oq_trust_problem and the
    path proven the same file. None when absent; Refused oq_untrusted_owner when not trusted,
    file_unreadable or file_too_large otherwise. The caller checks the directories first."""
    trust = _oq_trust()
    if trust is None:
        raise Refused("oq_untrusted_owner", "this host cannot prove file ownership (no POSIX owner)")
    owner, modes = trust
    flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
             | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_NOCTTY", 0))
    try:
        fd = os.open(path, flags)
    except OSError as exc:
        try:
            linked = os.lstat(path)
        except OSError:
            linked = None
        if linked is not None and stat.S_ISLNK(linked.st_mode):
            raise Refused("oq_untrusted_owner", f"{path} is a symlink") from None
        if isinstance(exc, FileNotFoundError):
            return None
        raise Refused("file_unreadable", f"{path}: {exc}") from exc
    try:
        opened = os.fstat(fd)
        problem = oq_trust_problem(opened, directory=False, owner_uid=owner, modes=modes)
        if problem is None and os.name == "posix":
            linked = os.lstat(path)
            if (opened.st_dev, opened.st_ino) != (linked.st_dev, linked.st_ino):
                problem = "was replaced between open and lstat"
        if problem is not None:
            raise Refused("oq_untrusted_owner", f"{path} {problem}")
        stream = os.fdopen(fd, "rb")
    except BaseException:
        os.close(fd)
        raise
    with stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise Refused("file_too_large", f"{path} exceeds {limit} bytes")
    return data


def _oq_load(ops: Ops, engine_id: str) -> tuple[dict[str, Any] | None, tuple[str, str] | None]:
    """(the OQ document at <oq-dir>/<engine_id>/oq.json, None) when it is the judge's own file and
    exactly a probe_bar.read_oq document for the engine it names (any engine); (None, None) when
    absent or malformed; (None, (oq_untrusted_owner, why)) when it or its directories are not the
    judge's root-owned set. Never raises for bad data."""
    path = ops.oq_dir / engine_id / probe_bar.OQ_FILE
    if not os.path.lexists(path):
        return None, None
    problem = _oq_set_problem(ops, engine_id)
    if problem is not None:
        return None, ("oq_untrusted_owner", problem[:300])
    try:
        data = _read_oq_file(path, MAX_OQ_BYTES)
        doc = None if data is None else _strict_loads(data, "oq_invalid")
    except Refused as exc:
        if exc.code == "oq_untrusted_owner":
            return None, (exc.code, exc.detail[:300])
        return None, None
    named = doc.get("engine_id") if isinstance(doc, dict) else None
    return (probe_bar.read_oq(data, named) if type(named) is str else None), None


def _oq_document(ops: Ops, engine_id: str) -> dict[str, Any] | None:
    """The trusted OQ document (_oq_load) for the engine it names, else None."""
    return _oq_load(ops, engine_id)[0]


def _oq_record(ops: Ops, engine_id: str) -> dict[str, Any] | None:
    """The engine's operational qualification record (probe_bar.OperationalQualification's result,
    recorded as <oq-dir>/<engine_id>/oq.json by the judge through probe_bar.record_oq), or None
    when absent, untrusted or not exactly that document for this engine (probe_bar.read_oq): a
    record that cannot be read never qualifies. Structure only: _oq_current is what the ladder acts on."""
    doc = _oq_document(ops, engine_id)
    return doc if doc is not None and doc["engine_id"] == engine_id else None


def _current_account(ops: Ops, engine_id: str) -> str | None:
    """The account the engine's current assignment (else its lifecycle record) runs on."""
    try:
        registry = ops.registry_optional()
        assignment = None if registry is None else registry.assignments.get(engine_id)
        if assignment is not None:
            return assignment["account_id"]
        account_id = (ops.canary().optional(engine_id) or {}).get("account_id")
    except (Refused, TrialError, er.RegistryError, OSError):  # CanaryError is a TrialError
        return None
    return account_id if type(account_id) is str else None


def _oq_current(ops: Ops, engine_id: str) -> tuple[dict[str, Any] | None, tuple[str, str] | None]:
    """The OQ record the ladder and the graduation gate act on (C13 fix b, fix c): (record, None)
    only when it is the judge's own qualification of this engine's CURRENT probe; (None, None) when
    there is no OQ document; else (None, (code, detail)) naming the first binding that fails:
    - oq_untrusted_owner: oq.json, oq-fills.json, venue.json or venue-rows.json, or their
      directories, are not root-owned with modes 0444 / 0755 (the leafhft user could have written
      or renamed them), _oq_set_problem and _read_oq_file;
    - oq_wrong_trial: it qualifies another engine, or not the current probe's account and trial;
    - oq_stale: qualified_at is outside the trial's window (before its activation, after it closed,
      in the future) or older than OQ_MAX_AGE;
    - oq_evidence_mismatch: not the judge's writer, or its evidence_digest does not recompute from
      oq-fills.json and venue.json on disk, or oq-fills.json does not re-parse as exactly the fills
      document for this engine, trial and population start, or venue.json was not computed from
      those fills and the venue-rows.json copy on disk for this account and trial;
    - oq_counters_incomplete: the probe bindings cannot be read or name no hosting book, or the
      venue-rows.json copy holds no accepted counters for one of the books they name (C13 fix e: every
      hosting book, never the last one written; a book whose window the judge could not verify
      against systemd, or whose counts the refusal journal contradicted, was copied as None);
    - oq_counters_gap: a book's single-process window opens after the population start while an
      earlier process counted (probe_bar.counters_gap): the window spans a restart, so the sample is
      re-earned, never covered by adding saved counts;
    - oq_counters_stale: a book's disturbance counters do not cover the population window
      (probe_bar.counters_problem: observed_at inside [population start, qualified_at], covers_from
      at or before the start, covers_to within COUNTERS_MAX_LAG of qualified_at).
    Never raises for bad data."""
    oq, problem = _oq_load(ops, engine_id)
    if problem is not None:
        return None, problem
    if oq is None:
        return None, None
    if oq["engine_id"] != engine_id:
        return None, ("oq_wrong_trial", f"oq.json qualifies engine {oq['engine_id']!r}, not {engine_id}")
    account_id = _current_account(ops, engine_id)
    try:
        trial_id = _probe_trial_id(ops, engine_id)
    except Refused as exc:
        return None, ("oq_wrong_trial", f"the current probe trial is unreadable: {exc.code}")
    if account_id is None or trial_id is None or oq["account_id"] != account_id or oq["trial_id"] != trial_id:
        return None, ("oq_wrong_trial", f"oq.json qualifies account {oq['account_id']!r} trial {oq['trial_id']!r}; "
                                        f"the current probe is account {account_id!r} trial {trial_id!r}")
    try:
        trial = ops.trials().get(trial_id)
    except (TrialError, OSError, ValueError) as exc:
        return None, ("oq_stale", f"trial {trial_id} is unreadable: {type(exc).__name__}")
    qualified = _utc_time(oq["qualified_at"])
    activated = None if trial.activation is None else _utc_time(trial.activation.activated_at)
    closed = None if not isinstance(trial.closed, dict) else _utc_time(trial.closed.get("closed_at"))
    if (qualified is None or activated is None or qualified < activated or qualified > ops.now
            or (closed is not None and qualified > closed) or ops.now - qualified > OQ_MAX_AGE):
        return None, ("oq_stale", f"qualified_at {oq['qualified_at']} is outside trial {trial_id}'s window "
                                  f"(activated {activated}, closed {closed}) or older than {OQ_MAX_AGE}")
    writer = oq["writer"]
    if type(writer) is not str or not _OQ_WRITER.fullmatch(writer) or oq["evidence_digest"] is None:
        return None, ("oq_evidence_mismatch", f"oq.json carries no {OQ_WRITER} writer and evidence digest")
    directory = ops.oq_dir / engine_id
    try:
        fills = _read_oq_file(directory / FILLS_FILE, MAX_FILLS_BYTES)
        venue = _read_oq_file(directory / VENUE_FILE, MAX_VENUE_BYTES)
        rows = _read_oq_file(directory / ROWS_FILE, MAX_ROWS_BYTES)
    except Refused as exc:
        code = "oq_untrusted_owner" if exc.code == "oq_untrusted_owner" else "oq_evidence_mismatch"
        return None, (code, f"{exc.code}: {exc.detail}"[:300])
    if fills is None or venue is None or rows is None:
        return None, ("oq_evidence_mismatch", f"{FILLS_FILE}, {VENUE_FILE} or {ROWS_FILE} is missing")
    start_ns = trial.activation.population_start_ns
    reconciliation = probe_bar.read_venue(venue, engine_id)
    document = probe_bar.read_fills_document(fills)  # the bytes hashed below must also BE the fills
    listed = None if document is None or document["fills"] is None else len(document["fills"])
    if (reconciliation is None or document is None or reconciliation["fills_sha256"] != _sha(fills)
            or reconciliation["rows_sha256"] != _sha(rows) or probe_bar.read_rows(rows, engine_id) is None
            or document["engine_id"] != engine_id or document["trial_id"] != trial_id
            or document["population_start_ns"] != start_ns or reconciliation["population_start_ns"] != start_ns
            or reconciliation["attributed_fills"] != listed
            or reconciliation["account_id"] != account_id or reconciliation["trial_id"] != trial_id
            or probe_bar.evidence_digest(fills, venue) != oq["evidence_digest"]):
        return None, ("oq_evidence_mismatch",
                      f"the evidence does not recompute from {FILLS_FILE}, {VENUE_FILE} and {ROWS_FILE} on disk")
    books, problem = _hosting_books(ops, engine_id)
    if problem is not None:
        return None, problem
    counters = probe_bar.read_rows(rows, engine_id)["counters"] or {}
    missing = [book for book in books if counters.get(book) is None]
    if missing or reconciliation["books_hosting"] != len(books):
        return None, ("oq_counters_incomplete",
                      f"no accepted counters from hosting book(s) {', '.join(missing) or '(none missing)'}; "
                      f"venue.json read {reconciliation['books_read']} of {reconciliation['books_hosting']} "
                      f"books, the probe bindings name {len(books)}"[:300])
    for book in books:
        gap = probe_bar.counters_gap(counters[book], population_start_ns=start_ns)
        if gap is not None:
            return None, ("oq_counters_gap", f"{book}: {gap}"[:300])
    for book in books:
        doc = counters[book]
        stale = probe_bar.counters_problem(doc["observed_at"], doc["covers_from"], doc["covers_to"],
                                           population_start_ns=start_ns, at=qualified)
        if stale is not None:
            return None, ("oq_counters_stale", f"{book}: {stale}"[:300])
    return oq, None


def _oq_inputs(ops: Ops, engine_id: str, trial, account_id: str | None,
               account: Mapping[str, Any] | None) -> tuple[Any, dict, Any, Any]:
    """(fills, ledger snapshot, settlements, one-lot P&L) for the probe's OQ: the trial's registered
    root ledgers plus this engine's own probe-<engine_id>/ ledgers under the account's runs root,
    read by scoring's bounded walker and episode builder. Probe-directory rows are attributed by
    cell > eng= > probe reason / attribution.engine_id / directory; a conflict is unattributed
    and so not selected. The snapshot's venue side stays None here; _record_qualification fills it
    from the venue reconciliation it produces. An unactivated trial or an unreadable or truncated
    walk yields inputs that fail OQ closed; never raises for bad data."""
    activation = trial.activation
    if activation is None or account is None:
        return None, {}, None, None
    start_ns = activation.population_start_ns
    now_ns = int(ops.now.timestamp() * 1_000_000) * 1000
    try:
        canary_record = ops.canary().optional(engine_id)
    except (CanaryError, OSError, ValueError):
        return None, {}, None, None
    try:
        rows, walked = scoring.walk_ledgers(ops.runs_root(account), list(trial.registration.execution["ledger_names"]),
                                            since_ns=start_ns, until_ns=max(start_ns, now_ns + 1),
                                            probe_engines=(engine_id,))
        episodes, built = scoring.build_episodes(rows)
    except (OSError, ValueError, TypeError, KeyError):
        return None, {}, None, None
    if walked.truncated or built.truncated:
        return None, {}, None, None
    return probe_bar.oq_inputs(episodes, None, engine_id=engine_id, account_id=account_id,
                               symbols=list(trial.registration.population.get("symbols") or ()),
                               population_start_ns=start_ns, now_ns=now_ns, canary_record=canary_record)


def _oq_set_dir(ops: Ops, engine_id: str) -> Path:
    """The judge's evidence directory <oq-dir>/<engine_id>, created 0755 when absent. ValueError
    (the judge's oq_write_failed) unless it then proves trusted exactly as the ladder will read it
    (_oq_set_problem), so root never publishes into a directory the leafhft user could swap."""
    for directory in (ops.oq_dir, ops.oq_dir / engine_id):
        try:
            os.mkdir(directory, OQ_DIR_MODE)
        except FileExistsError:
            continue
        if os.name == "posix":
            os.chmod(directory, OQ_DIR_MODE)  # the umask never narrows it
    problem = _oq_set_problem(ops, engine_id)
    if problem is not None:
        raise ValueError(f"oq_untrusted_owner: {problem}")
    return ops.oq_dir / engine_id


def _publish_oq_file(path: Path, data: bytes) -> None:
    """Sibling temp, fsync, mode 0444 (POSIX), atomic replace: a reader sees the old root-owned file
    or the new one, never a writable one."""
    fd, temporary = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            if os.name == "posix":
                os.fchmod(stream.fileno(), OQ_FILE_MODE)
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


_READ = object()  # _copy_staging reads the staged counters itself


def _hosting_books(ops: Ops, engine_id: str) -> tuple[list[str] | None, tuple[str, str] | None]:
    """The books that host the probe (C13 fix e): every symbol the probe bindings (<probe-bindings>,
    the file each book's host reads to build its ProbeExecutors and wire their per-book staging)
    bind this engine to, sorted; (None, ("oq_counters_incomplete", why)) when the bindings cannot be
    read or bind it to no book, so no qualification passes on a book set nobody can name."""
    bindings = load_probe_bindings(ops.probe_bindings)
    if bindings.errors:
        return None, ("oq_counters_incomplete",
                      f"the probe bindings {ops.probe_bindings} are unreadable: {bindings.errors[0]}"[:300])
    books = sorted(symbol for symbol, engines in bindings.symbols.items() if engine_id in engines)
    if not books:
        return None, ("oq_counters_incomplete", f"the probe bindings {ops.probe_bindings} bind {engine_id} "
                                                f"to no book"[:300])
    return books[:probe_bar.MAX_HOSTING_BOOKS], None


def _staged_counters(ops: Ops, engine_id: str, account_id: str | None, symbol: str,
                     *, book_account_id: str | None = None) -> dict[str, Any] | None:
    """One hosting book's staged disturbance counters (leafhft-owned
    <evidence-dir>/<engine_id>/staging/<symbol>/counters.json, written on that book's executor's
    reconciliation tick), validated by probe_bar.read_counters_staging for that book; None when
    absent or invalid (fails OQ closed). An explicitly supplied, registry-validated owner alias
    may validate the same bytes; only the judge's fresh copy is normalized to the registry key.
    Directory descriptors pin the producer directory on POSIX; no staging symlink is followed."""
    if type(account_id) is not str:
        return None
    try:
        directory = ops.staging_path(engine_id, symbol)
        path = directory / probe_bar.COUNTERS_STAGING_FILE
        directories = (directory.parent.parent.parent, directory.parent.parent, directory.parent, directory)
        flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
                 | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_NOCTTY", 0))
        with ExitStack() as stack:
            if os.name == "posix":
                parent_fd = None
                for component in directories:
                    fd = os.open(component if parent_fd is None else component.name,
                                 flags | os.O_DIRECTORY, dir_fd=parent_fd)
                    stack.callback(os.close, fd)
                    info = os.fstat(fd)
                    if not stat.S_ISDIR(info.st_mode):
                        return None
                    if component == directory.parent:
                        producer_uid = info.st_uid
                    parent_fd = fd
                fd = os.open(path.name, flags, dir_fd=parent_fd)
                stack.callback(os.close, fd)
                linked = os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False)
            else:
                # Hosts without directory descriptors still reject static symlinks and
                # recheck directory identities after opening the file.
                before = [component.lstat() for component in directories]
                if any(not stat.S_ISDIR(info.st_mode) for info in before):
                    return None
                producer_uid = before[-2].st_uid
                if not stat.S_ISREG(path.lstat().st_mode):
                    return None
                fd = os.open(path, flags)
                stack.callback(os.close, fd)
                linked = path.lstat()
                for component, original in zip(directories, before):
                    current = component.lstat()
                    if (not stat.S_ISDIR(current.st_mode)
                            or (current.st_dev, current.st_ino) != (original.st_dev, original.st_ino)):
                        return None
            opened = os.fstat(fd)
            if (not stat.S_ISREG(opened.st_mode) or not stat.S_ISREG(linked.st_mode)
                    or opened.st_uid != producer_uid
                    or (os.name == "posix" and (opened.st_dev, opened.st_ino) != (linked.st_dev, linked.st_ino))
                    or opened.st_size > probe_bar.MAX_COUNTERS_BYTES):
                return None
            with os.fdopen(fd, "rb", closefd=False) as stream:
                data = stream.read(probe_bar.MAX_COUNTERS_BYTES + 1)
        if len(data) > probe_bar.MAX_COUNTERS_BYTES:
            return None
    except (OSError, Refused, ValueError):
        return None
    identities = [account_id]
    if er.valid_book_account_id(book_account_id) and book_account_id != account_id:
        identities.append(book_account_id)
    for identity in identities:
        checked = probe_bar.read_counters_staging(data, engine_id, identity, symbol)
        if checked is not None:
            return {**checked, "account_id": account_id}
    return None


def _staged_counters_by_book(ops: Ops, engine_id: str, account_id: str | None,
                             books: list[str] | None, *, book_account_id: str | None = None) -> dict[str, Any] | None:
    """{symbol: _staged_counters or None} for every hosting book; None when the books are unknown."""
    if books is None:
        return None
    return {book: _staged_counters(ops, engine_id, account_id, book, book_account_id=book_account_id)
            for book in books}


def book_unit(symbol: str, template: str | None) -> str | None:
    """The systemd unit of the book that trades `symbol` from the configured template ("{book}" is
    the lowercased symbol; deploy/runner/live-run.sh's leafhft-live@kalshi-<coin>-<period>.service);
    None when no template, or one that is not exactly one bounded unit name, is configured."""
    if type(template) is not str or len(template) > 200 or not _BOOK_UNIT_TEMPLATE.fullmatch(template):
        return None
    return template.replace("{book}", symbol.lower())


def _journal_events(unit: str, since: datetime, until: datetime) -> list[tuple[datetime, str]] | None:
    """systemd's own (PID 1) records about `unit` inside [since, until]: `journalctl -u <unit> _PID=1
    -o json`, root-only, run bounded (JOURNAL_TIMEOUT_S, probe_bar.MAX_JOURNAL_BYTES read), parsed by
    probe_bar.journal_lifecycle. None when journalctl cannot run, fails or overflows the bound: an
    unreadable journal is oq_journal_unavailable, never a pass."""
    argv = [JOURNALCTL, "-u", unit, "_PID=1", "-o", "json", "--no-pager",
            "--since", f"@{max(0, int(since.timestamp()))}", "--until", f"@{max(0, math.ceil(until.timestamp()))}"]
    try:
        with tempfile.TemporaryFile() as out:
            result = subprocess.run(argv, stdout=out, stderr=subprocess.DEVNULL, timeout=JOURNAL_TIMEOUT_S,
                                    check=False)
            if result.returncode != 0:
                return None
            out.seek(0)
            data = out.read(probe_bar.MAX_JOURNAL_BYTES + 1)
    except (OSError, subprocess.SubprocessError):
        return None
    return probe_bar.journal_lifecycle(data)


def _counters_window_problem(book: str, counters: Mapping[str, Any],
                             template: str | None) -> tuple[str, str] | None:
    """Why systemd's journal does not confirm one book's counting window (C13 fix e), or None:
    evidence_unavailable (C13 fix f) when no book unit template is configured or the journal cannot
    be read (oq_journal_unavailable in the detail), oq_counters_window_unverified when the unit's
    recorded start, a start or stop inside [covers_from, covers_to], or the executor's own
    process_start_ns contradicts the staged window (probe_bar.counters_window_problem)."""
    unit = book_unit(book, template)
    if unit is None:
        return EVIDENCE_UNAVAILABLE, (f"{book}: no valid book unit template is configured (--book-unit-template, "
                                      f"${BOOK_UNIT_TEMPLATE_ENV}), so systemd's journal cannot verify the "
                                      f"counting window")[:300]
    first, last = _utc_time(counters["covers_from"]), _utc_time(counters["covers_to"])
    if first is None or last is None:
        return "oq_counters_window_unverified", f"{book}: the counters carry no readable window"
    events = _journal_events(unit, max(_EPOCH, first - UNIT_START_LOOKBACK), last)
    if events is None:
        return EVIDENCE_UNAVAILABLE, f"oq_journal_unavailable: {book}: systemd's journal for {unit} could not be read"[:300]
    why = probe_bar.counters_window_problem(events, counters)
    return None if why is None else ("oq_counters_window_unverified", f"{book} ({unit}): {why}"[:300])


def _file_identity(path: Path) -> tuple[int, int] | None:
    """(st_dev, st_ino) of `path`, None when absent; any other OSError propagates."""
    try:
        info = os.stat(path)
    except FileNotFoundError:
        return None
    return info.st_dev, info.st_ino


def _refusal_snapshot(rotated: Path, path: Path, since: datetime
                      ) -> tuple[list[bytes], datetime | None, tuple[str, str] | None] | None:
    """C13 fix j: one read attempt of the refusal journal's two generations (<journal>.1, then
    <journal>), bounded, read-only (no lock, no sleep). None when either file's (st_dev, st_ino)
    differs between the stats taken before and after the reads (a rotation happened during the
    read: the attempt, its bytes and any problem it met are thrown away). Else (parts, newest
    mtime, None), or ([], None, problem) for the first problem the coherent attempt met."""
    def unreadable(part: Path, exc: BaseException) -> tuple[str, str]:
        if isinstance(exc, Refused):
            return EVIDENCE_UNAVAILABLE, f"the refusal journal is unreadable: {exc.code}: {exc.detail}"[:300]
        return EVIDENCE_UNAVAILABLE, f"the refusal journal {part} is unreadable: {type(exc).__name__}"[:300]

    try:
        before = (_file_identity(rotated), _file_identity(path))
    except OSError as exc:
        return [], None, unreadable(path, exc)
    parts: list[bytes] = []
    written: datetime | None = None
    problem: tuple[str, str] | None = None
    for part in (rotated, path):
        try:
            data = _read_bounded(part, probe_bar.MAX_REFUSAL_BYTES)
            mtime = None if data is None else datetime.fromtimestamp(os.stat(part).st_mtime, timezone.utc)
        except (Refused, OSError, ValueError, OverflowError) as exc:
            problem = unreadable(part, exc)
            break
        if data is None:
            continue
        if part == rotated:
            first = probe_bar.refusal_journal_first_at(data)
            if first is None or first > since:
                problem = (EVIDENCE_UNAVAILABLE, f"the rotated refusal journal {rotated} starts at {first}, after "
                                                 f"the coverage window opened at {since.isoformat()}: rows "
                                                 f"inside the window may have rotated away"[:300])
                break
        parts.append(bytes(data) if data.endswith(b"\n") or not data else bytes(data) + b"\n")
        written = mtime if written is None else max(written, mtime)
    try:
        after = (_file_identity(rotated), _file_identity(path))
    except OSError as exc:
        return [], None, unreadable(path, exc)
    if after != before:
        return None
    return ([], None, problem) if problem is not None else (parts, written, None)


def _ledger_refusals(ops: Ops, engine_id: str, since: datetime) -> tuple[int | None, tuple[str, str] | None]:
    """(count, None): the refusals the account-risk ledger's refusal journal (<refusal-journal> and
    its one rotated generation <refusal-journal>.1, root-readable, written by the ledger's
    RefusalJournal) attributes to the probe's client ids since `since` up to now; else
    (None, ("evidence_unavailable", why)) (C13 fix f, fix g): no journal configured; neither file
    present (the producer never wrote one, so zero is never assumed); the newest file last written
    before `since` (the producer wrote nothing inside the coverage window); a rotated generation whose
    first row is after `since` (a second rotation dropped rows inside the window); unreadable,
    malformed or over the bound; C13 fix i: no producer heartbeat row inside [since, now] (an empty
    journal, or one whose modification time is fresh but carries no heartbeat, proves nothing:
    probe_bar.refusal_journal_evidence). The counts are never left uncross-checked and never read as
    zero without that positive record once the population starts. Before the start (since > now),
    the empty window counts zero after the existence, readability, rotation, snapshot and format
    checks; only the last-write and in-window heartbeat requirements are skipped (JUDGE v3).
    C13 fix j: the two generations are read as one inode-validated snapshot (_refusal_snapshot),
    so a rotation during the read is retried, never counted."""
    path = ops.refusal_journal
    if path is None:
        return None, (EVIDENCE_UNAVAILABLE, f"no refusal journal is configured (--refusal-journal, "
                                            f"${REFUSAL_JOURNAL_ENV}), so the self-reported counters cannot be "
                                            f"cross-checked")
    rotated = path.with_name(path.name + probe_bar.REFUSAL_ROTATED_SUFFIX)
    for _attempt in range(REFUSAL_SNAPSHOT_ATTEMPTS):
        snapshot = _refusal_snapshot(rotated, path, since)
        if snapshot is not None:
            break
    else:
        return None, (EVIDENCE_UNAVAILABLE, f"the refusal journal {path} rotated during every read attempt "
                                            f"({REFUSAL_SNAPSHOT_ATTEMPTS}): no coherent snapshot of its two "
                                            f"generations, which is never read as a count"[:300])
    parts, written, problem = snapshot
    if problem is not None:
        return None, problem
    if not parts:
        return None, (EVIDENCE_UNAVAILABLE, f"the refusal journal {path} does not exist: the account-risk ledger "
                                            f"published no refusal evidence, which is never read as zero"[:300])
    before_start = since > ops.now
    if not before_start and written < since:
        return None, (EVIDENCE_UNAVAILABLE, f"the refusal journal {path} was last written at {written.isoformat()}, "
                                            f"before the coverage window opened at {since.isoformat()}"[:300])
    count, why = probe_bar.refusal_journal_evidence(b"".join(parts), venue_snapshot.probe_prefix(engine_id),
                                                    since, ops.now)
    if before_start and why in (None, probe_bar.REFUSAL_JOURNAL_NO_HEARTBEAT):
        return 0, None
    if why == probe_bar.REFUSAL_JOURNAL_NO_HEARTBEAT:
        return None, (EVIDENCE_UNAVAILABLE, f"the refusal journal {path} carries no producer heartbeat between "
                                            f"{since.isoformat()} and {ops.now.isoformat()}: no positive record "
                                            f"that the ledger was journaling, which is never read as zero"[:300])
    if count is None:
        return None, (EVIDENCE_UNAVAILABLE, f"the refusal journal {path} is malformed or over its bound"[:300])
    return count, None


def _verified_counters(ops: Ops, engine_id: str, counters: Mapping[str, Any] | None,
                       population_start_ns: int) -> tuple[dict[str, Any] | None, int | None, tuple[str, str] | None]:
    """(counters to copy, ledger refusal count, first problem) (C13 fix e). Every hosting book must
    have staged counters (oq_counters_incomplete names the missing book) whose window systemd's
    journal confirms (_counters_window_problem); a book that fails is copied as None, so the OQ
    fails closed. The counts themselves stay the book processes' self-report, cross-checked against
    the refusal journal (_ledger_refusals): more refusals attributed to the probe than the books
    reported is oq_counters_mismatch and none of the counts is copied. Both independent checks are
    required (C13 fix f): an unconfigured or unreadable journal window or refusal journal is
    evidence_unavailable, never a pass."""
    if counters is None:
        return None, None, None
    verified: dict[str, Any] = {}
    problem = None
    for book in sorted(counters):
        doc = counters[book]
        cause = ""
        if doc is None:
            staging = ops.staging_path(engine_id)
            try:
                staging.stat()
            except FileNotFoundError:
                cause = "; staging dir absent"
            except OSError:
                pass
            else:
                try:
                    (ops.staging_path(engine_id, book) / probe_bar.COUNTERS_STAGING_FILE).stat()
                except FileNotFoundError:
                    cause = "; counters file absent"
                except OSError:
                    pass
        found = (("oq_counters_incomplete", f"hosting book {book} staged no counters the judge accepts{cause}")
                 if doc is None else _counters_window_problem(book, doc, ops.book_unit_template))
        verified[book] = None if found is not None else doc
        problem = problem or found
    if problem is not None:
        return verified, None, problem
    since = _EPOCH + timedelta(microseconds=population_start_ns // 1000)
    ledger, problem = _ledger_refusals(ops, engine_id, since)
    if problem is None and ledger is not None:
        reported = sum(doc["incumbent_refusals_by_probe"] + doc["lane_refusals_by_probe"]
                       for doc in verified.values())
        if ledger > reported:
            problem = ("oq_counters_mismatch", f"the account-risk ledger's refusal journal attributes {ledger} "
                                               f"refusal(s) to {engine_id}'s client ids since the population "
                                               f"start; its books self-reported {reported}")
    if problem is not None:
        return {book: None for book in verified}, ledger, problem
    return verified, ledger, None


def _venue_snapshot(ops: Ops, engine_id: str,
                    account_id: str | None) -> tuple[dict[str, Any] | None, tuple[str, str] | None]:
    """The root-run venue read the judge requires (C13 fix d): (document, None) only when
    <venue-dir>/<engine_id>/venue.json is root-owned 0444 in root-owned 0755 directories
    (_trusted_set_problem, _read_oq_file), exactly venue_snapshot.read_snapshot's document for this
    engine and account, not truncated, and observed within VENUE_MAX_AGE of now, else
    (None, ("oq_venue_stale", why)); and its balance's own updated_ts within the same VENUE_MAX_AGE,
    else (None, ("oq_balance_stale", why)) (C13 fix e). The judge never takes venue rows from the
    executor's staging."""
    path = venue_snapshot.snapshot_path(ops.venue_dir, engine_id)
    if not os.path.lexists(path):
        return None, ("oq_venue_stale", f"{path} is absent: no venue snapshot has read this probe")
    problem = _trusted_set_problem(ops.venue_dir, engine_id)
    if problem is not None:
        return None, ("oq_venue_stale", f"the venue snapshot is not root-owned: {problem}"[:300])
    try:
        data = _read_oq_file(path, venue_snapshot.MAX_SNAPSHOT_BYTES)
    except Refused as exc:
        return None, ("oq_venue_stale", f"{exc.code}: {exc.detail}"[:300])
    doc = None if data is None else venue_snapshot.read_snapshot(data, engine_id)
    if doc is None:
        return None, ("oq_venue_stale", f"{path} is not a venue snapshot of {engine_id}")
    if doc["account_id"] != account_id or doc["truncated"]:
        return None, ("oq_venue_stale", f"the venue snapshot reads account {doc['account_id']!r} "
                                        f"(truncated {doc['truncated']}), not the probe account {account_id!r}")
    observed = _utc_time(doc["observed_at"])
    if observed is None or ops.now - observed > VENUE_MAX_AGE:
        return None, ("oq_venue_stale", f"the venue snapshot was observed at {doc['observed_at']}, more than "
                                        f"{VENUE_MAX_AGE} before {ops.now.isoformat()}")
    # C13 fix e: a fresh read can carry an old balance; the venue's own updated_ts must be as fresh.
    updated = doc["balance_updated_ts"]
    moment = None if type(updated) is not int else _EPOCH + timedelta(seconds=updated)
    if moment is None or ops.now - moment > VENUE_MAX_AGE:
        return None, ("oq_balance_stale", f"the venue's balance was last updated at "
                                          f"{None if moment is None else moment.isoformat()}, more than "
                                          f"{VENUE_MAX_AGE} before {ops.now.isoformat()}")
    return doc, None


def _venue_problem(ops: Ops, snapshot: Mapping[str, Any], fills: Any, counters: Mapping[str, Any] | None,
                   population_start_ns: int) -> tuple[str, str] | None:
    """Why the judge refuses a fresh venue snapshot for this read, or None (C13 fix d). Pure over its
    inputs and the engine clock (ops.now):
    - oq_time_out_of_window: a timestamp in venue.json (venue_snapshot.timestamps) or in any hosting
      book's staged counters (observed_at, covers_to, and covers_to of every closed segment that ends
      inside the window) is unreadable or outside [population start - OQ_WINDOW_SLACK,
      qualification time + OQ_WINDOW_SLACK]; covers_from, where counting began, may precede the window but never
      follow it;
    - oq_venue_mismatch: an attributed fill (the ledger's, _oq_inputs) whose client id no venue fill
      carries, or a venue fill under the engine's prefix that no attributed fill names.
    `counters` maps each hosting book to its staged counters (None entries are absent books)."""
    low = _EPOCH + timedelta(microseconds=population_start_ns // 1000) - OQ_WINDOW_SLACK
    high = ops.now + OQ_WINDOW_SLACK
    stamps = list(venue_snapshot.timestamps(snapshot))
    for book, doc in sorted((counters or {}).items()):
        if doc is None:
            continue
        stamps += [(f"{book} counters observed_at", doc["observed_at"]), (f"{book} counters covers_to", doc["covers_to"])]
        for segment in doc["segments"]:
            closed = _utc_time(segment["covers_to"])
            if closed is None or closed >= low:
                stamps.append((f"{book} counters segment covers_to", segment["covers_to"]))
        first = _utc_time(doc["covers_from"])
        if first is None or first > high:
            return ("oq_time_out_of_window",
                    f"{book} counters covers_from {doc['covers_from']!r} is after {high.isoformat()}"[:300])
    for label, text in stamps:
        moment = _utc_time(text)
        if moment is None or not low <= moment <= high:
            return ("oq_time_out_of_window",
                    f"{label} {text!r} lies outside [{low.isoformat()}, {high.isoformat()}]"[:300])
    if isinstance(fills, (list, tuple)):
        attributed = {fill.get("client_id") if type(fill.get("client_id")) is str else None
                      for fill in fills if isinstance(fill, Mapping)}
        venue = venue_snapshot.fill_client_ids(snapshot)
        missing = sorted(str(cid) for cid in attributed if type(cid) is not str or cid not in venue)
        foreign = sorted(cid for cid in venue if cid.startswith(snapshot["prefix"]) and cid not in attributed)
        if missing or foreign:
            return ("oq_venue_mismatch",
                    f"{len(missing)} attributed fill(s) absent from the venue fills {missing[:3]}, "
                    f"{len(foreign)} venue fill(s) under {snapshot['prefix']} absent from attribution {foreign[:3]}"[:300])
    return None


def _copy_staging(ops: Ops, engine_id: str, account_id: str | None, trial_id: str,
                  venue: Mapping[str, Any] | None = None, counters: Any = _READ) -> tuple[dict[str, Any], bytes]:
    """The judge's copy of its OQ inputs: `venue`, the STAGING_SCHEMA venue rows converted from the
    root-run venue snapshot (venue_snapshot.staging_rows; None without a usable snapshot) and
    validated by probe_bar.venue_staging_doc, and every hosting book's staged counters
    ({symbol: counters or None}: _staged_counters_by_book over _hosting_books, or `counters` the
    caller already read and verified; None when the hosting books are unknown); an absent or
    invalid part is None, which fails OQ closed. Published root-owned as venue-rows.json and read
    BACK from that copy, which is what the judge qualifies from. No network, no credentials.
    ValueError when the copy cannot be written or does not read back."""
    account = account_id if type(account_id) is str else None
    checked = None if venue is None or account is None else probe_bar.venue_staging_doc(venue, engine_id, account)
    staged = (_staged_counters_by_book(ops, engine_id, account, _hosting_books(ops, engine_id)[0])
              if counters is _READ else counters)
    data = probe_bar.rows_bytes(checked, staged, engine_id=engine_id, account_id=account,
                                trial_id=trial_id, at=ops.now)
    path = _oq_set_dir(ops, engine_id) / ROWS_FILE
    _publish_oq_file(path, data)
    try:
        back = _read_oq_file(path, MAX_ROWS_BYTES)
    except Refused as exc:
        raise ValueError(f"{exc.code}: {exc.detail}") from None
    copy = probe_bar.read_rows(back, engine_id)
    if copy is None:
        raise ValueError(f"{ROWS_FILE} does not read back as the copy just written")
    return copy, back


def _oq_writer() -> str:
    return f"{OQ_WRITER} {_runner_code_sha()[:12]}"


def _opening_balance(ops: Ops, engine_id: str, trial_id: str) -> dict[str, Any] | None:
    """The trial's opening balance the lifecycle store persists (C13 fix f, fix g, canary.opening_balance:
    the balance read at activation and the transfers since), or None when absent or unreadable, which
    leaves the balance reconciliation inconclusive (opening_balance_missing), never a pass."""
    try:
        record = ops.canary().optional(engine_id)
    except (CanaryError, OSError, ValueError):
        return None
    return None if record is None else opening_balance(record, trial_id)


def _record_opening_balance(ops: Ops, engine_id: str, trial_id: str, venue: Mapping[str, Any]) -> None:
    """Persist the balance read taken at ACTIVATION as the trial's opening balance (C13 fix g; since
    C13 fix i only the legacy repair calls it, _repair_opening_balance, and a new activation captures
    through _capture_opening_then_activate; qualification never captures), write-once in the lifecycle
    store with the venue's capture time and updated_ts; a record that already carries this trial's
    opening is never recomputed. The reconciliation decides whether it is usable
    (probe_bar.balance_basis: read at or before the population start). C13 fix k: the write runs inside
    _born_as and ends 0644 owned by the lifecycle dir's owner, so the book (user leafhft) can read it
    whether or not the activation that follows succeeds."""
    if _opening_balance(ops, engine_id, trial_id) is not None or ops.canary().optional(engine_id) is None:
        return
    with _born_as(ops.lifecycle_dir):
        ops.canary().record_opening_balance(engine_id, trial_id=trial_id, balance_cents=venue["balance_cents"],
                                            observed_at=venue["balance_observed_at"],
                                            updated_ts=venue["balance_updated_ts"], now=ops.now)
        _lifecycle_readable(ops.canary().path_for(engine_id))


def _capture_opening_then_activate(ops: Ops, engine_id: str, trial_id: str, venue: Mapping[str, Any],
                                   activate: Callable[[], Any]) -> Any:
    """C13 fix i: the opening balance and the activation in the one order that never leaves an
    activation without its opening. The balance read `venue` (taken before activation) is written
    FIRST, atomically (the lifecycle store's temp plus replace), with replace=True so a retry after a
    crash between the two steps records its own fresh read over the earlier attempt's, and is read
    back; only then does `activate()` write the activation, and its result is returned. A crash or a
    failed opening write before activate() leaves no activation (Refused opening_balance_unrecorded);
    a crash after it leaves an activation whose opening is already durable.

    C13 fix j: the check, the opening and the activation happen under one per-engine activation lock
    (<registry-dir>/activation-<engine>.lock, taken inside the OPS lock when the caller holds it), so a
    losing activator never writes: one that finds the trial already activated returns None and leaves
    the committed opening and its transfers untouched. A wait past ACTIVATION_LOCK_TIMEOUT_S is
    Refused activation_busy, with nothing written.

    C13 fix k: the opening write runs inside _born_as and ends 0644 owned by the lifecycle dir's
    owner, so the book (user leafhft) can read it whether or not the activation that follows
    succeeds; the lock, the checks, the read-back and activate() (the root-owned trial store) stay
    outside it."""
    with ExitStack() as held:
        try:
            held.enter_context(_exclusive_lock(ops.registry_dir / f"activation-{engine_id}.lock",
                                               ACTIVATION_LOCK_TIMEOUT_S))
        except Refused as exc:
            if exc.code != "ops_busy":
                raise
            raise Refused("activation_busy", f"{engine_id}: another activator holds the activation lock past "
                                             f"{ACTIVATION_LOCK_TIMEOUT_S:g} s, so nothing was written") from None
        if ops.trials().get(trial_id).activation is not None:
            return None  # a concurrent activator won; its opening and transfers stand byte for byte
        canary = ops.canary()
        try:
            if canary.optional(engine_id) is None:
                raise CanaryError(f"{engine_id} has no lifecycle record to hold the opening balance")
            with _born_as(ops.lifecycle_dir):
                canary.record_opening_balance(engine_id, trial_id=trial_id, balance_cents=venue["balance_cents"],
                                              observed_at=venue["balance_observed_at"],
                                              updated_ts=venue["balance_updated_ts"], now=ops.now, replace=True)
                _lifecycle_readable(canary.path_for(engine_id))
        except (CanaryError, OSError, ValueError, TypeError, KeyError) as exc:
            raise Refused("opening_balance_unrecorded",
                          f"{engine_id}: the opening balance could not be recorded, so the trial is not "
                          f"activated: {type(exc).__name__}: {exc}"[:300]) from exc
        if _opening_balance(ops, engine_id, trial_id) is None:
            raise Refused("opening_balance_unrecorded",
                          f"{engine_id}: the opening balance does not read back, so the trial is not activated")
        return activate()


def _repair_opening_balance(ops: Ops, engine_id: str, trial_id: str, account_id: str | None) -> str | None:
    """C13 fix i: None when the activated trial carries its opening balance; a legacy activation
    written before the opening (older code) is repaired here, before any judgement, by capturing the
    root-run balance read now (write-once, _record_opening_balance). Else the reason text, starting
    opening_balance_missing, and the judge refuses to read the trial until a later call repairs it.
    A repaired opening read after the population start stays inconclusive in the reconciliation
    (probe_bar.balance_basis), never a pass."""
    if _opening_balance(ops, engine_id, trial_id) is not None:
        return None
    venue, unavailable = _venue_snapshot(ops, engine_id, account_id)
    if unavailable is not None:
        return (f"{OPENING_BALANCE_MISSING}: the activation carries no opening balance and the repair read "
                f"is unavailable: {unavailable[0]}: {unavailable[1]}")[:300]
    try:
        _record_opening_balance(ops, engine_id, trial_id, venue)
    except (CanaryError, OSError, ValueError, TypeError, KeyError) as exc:
        return (f"{OPENING_BALANCE_MISSING}: the activation carries no opening balance and the repair write "
                f"failed: {type(exc).__name__}: {exc}")[:300]
    if _opening_balance(ops, engine_id, trial_id) is None:
        return f"{OPENING_BALANCE_MISSING}: the repaired opening balance does not read back"
    return None


def _record_qualification(ops: Ops, engine_id: str, trial_id: str, account_id: str | None,
                          population_start_ns: int | None, fills: Any, snapshot: Any, settlements: Any,
                          pnl: Any, staged: tuple[Mapping[str, Any], bytes] | None,
                          ledger_refusals: int | None = None, opening: Any = _READ) -> dict[str, Any]:
    """The OQ chain's one writer (root). From the ledger side (_oq_inputs) and the judge's copy of the
    venue snapshot's rows and the executor's staged counters (_copy_staging: its parsed document and
    the exact bytes of venue-rows.json) it publishes, each root-owned 0444 and atomically, in this order
    beside that copy: oq-fills.json (the attributed fills), venue.json (probe_bar.reconcile_venue
    over those fills and the ledger's settlements and the qualification's opening balance and
    transfers, _opening_balance unless `opening` is given, bound to both files' sha256), then oq.json
    through probe_bar.record_oq with the snapshot's venue side taken from that reconciliation and an
    evidence_digest over fills and venue. A crash between writes leaves an oq.json whose digest no
    longer recomputes, which the ladder refuses."""
    directory = _oq_set_dir(ops, engine_id)
    account = account_id if type(account_id) is str else None
    if opening is _READ:
        opening = _opening_balance(ops, engine_id, trial_id)
    copy, rows = staged if staged is not None else (None, None)
    venue = disturbance = None
    if copy is not None:
        staging = copy["venue"]
        if staging is not None:
            venue = probe_bar.venue_rows(staging["orders"], staging["fills"], staging["settlements"],
                                         staging["balance"])
        disturbance = copy["counters"]
    fills_bytes = probe_bar.fills_document(fills, engine_id=engine_id, trial_id=trial_id,
                                           population_start_ns=population_start_ns)
    fills_doc = probe_bar.read_fills_document(fills_bytes)
    if fills_doc is not None and fills_doc.get("amount_refusals"):
        snapshot = dict(snapshot) if isinstance(snapshot, Mapping) else {}
        snapshot["amount_refusals"] = fills_doc["amount_refusals"]
    ledger_cash = snapshot.get("ledger_cash_delta_cents") if isinstance(snapshot, Mapping) else None
    reconciliation = probe_bar.reconcile_venue(
        fills, ledger_cash, venue, disturbance, engine_id=engine_id, account_id=account, trial_id=trial_id,
        population_start_ns=population_start_ns, at=ops.now, fills_sha256=_sha(fills_bytes),
        settlements=settlements, rows_sha256=None if rows is None else _sha(rows), ledger_refusals=ledger_refusals,
        opening_balance=opening, transfers=None if not isinstance(opening, Mapping) else opening.get("transfers"))
    venue_bytes = probe_bar.venue_bytes(reconciliation)
    # The serializer can fail an aggregate closed; qualify against the evidence actually written.
    reconciliation = probe_bar.read_venue(venue_bytes, engine_id)
    _publish_oq_file(directory / FILLS_FILE, fills_bytes)
    _publish_oq_file(directory / VENUE_FILE, venue_bytes)
    merged = probe_bar.with_venue(snapshot, reconciliation, engine_id=engine_id,
                                  population_start_ns=population_start_ns)
    return probe_bar.record_oq(directory / probe_bar.OQ_FILE, fills, merged, settlements, engine_id=engine_id,
                               account_id=account, trial_id=trial_id, at=ops.now, min_fills=OQ_MIN_FILLS,
                               one_lot_pnl_cents=pnl, evidence_digest=probe_bar.evidence_digest(fills_bytes, venue_bytes),
                               writer=_oq_writer(), mode=OQ_FILE_MODE)


def _qualify(ops: Ops, engine_id: str, trial, trial_id: str, account_id: str | None,
             account: Mapping[str, Any] | None) -> dict[str, Any]:
    """The judge's OQ read, persisted on every --write read (C13): the ledger side (_oq_inputs), the
    root-run venue snapshot (_venue_snapshot: the probe's fills for its client-id prefix, the
    settlements of their tickers, the balance) and every hosting book's staged disturbance counters
    (_hosting_books, _staged_counters_by_book), copied root-owned by _copy_staging and written by
    _record_qualification. The judge never touches the network: the unit keeps PrivateNetwork=true
    and holds no venue credentials. A snapshot the judge refuses (oq_venue_stale, oq_balance_stale,
    oq_time_out_of_window, oq_venue_mismatch; _venue_problem) is not copied, and a book whose
    counters it cannot accept (oq_counters_incomplete, oq_counters_window_unverified,
    evidence_unavailable, oq_counters_mismatch; _verified_counters) is copied as None, so the
    persisted OQ fails closed, and the refusal is then raised. A counters refusal outranks a venue
    refusal whose code the judge may hold (JUDGE_HOLD_CODES, JUDGE v3), so a holdable venue code never
    masks a counters failure found in the same read; otherwise the venue refusal is raised first. The
    persisted OQ is the same either way. The opening balance is only READ here
    (_opening_balance, captured at activation, C13 fix g); a trial without one reconciles
    inconclusive (opening_balance_missing). The ladder and the graduation gate read only its output,
    through _oq_current. The engine clock is shared by validation and persistence."""
    fills, snapshot, settlements, pnl = _oq_inputs(ops, engine_id, trial, account_id, account)
    start_ns = None if trial.activation is None else trial.activation.population_start_ns
    if start_ns is None:
        return _record_qualification(ops, engine_id, trial_id, account_id, None, fills, snapshot, settlements,
                                     pnl, None)
    venue, problem = _venue_snapshot(ops, engine_id, account_id)
    books, counters_problem = _hosting_books(ops, engine_id)
    book_account_id = None
    if account is not None and account.get("kind") == "owner" and account.get("lane_id") is None:
        candidate = account.get("book_account_id")
        if er.valid_book_account_id(candidate):
            book_account_id = candidate
    counters = _staged_counters_by_book(ops, engine_id, account_id, books, book_account_id=book_account_id)
    if problem is None:
        problem = _venue_problem(ops, venue, fills, counters, start_ns)
    rows = None if problem is not None else venue_snapshot.staging_rows(venue)
    verified, ledger, found = _verified_counters(ops, engine_id, counters, start_ns)
    counters_problem = counters_problem or found
    staged = _copy_staging(ops, engine_id, account_id, trial_id, rows, verified)
    record = _record_qualification(ops, engine_id, trial_id, account_id, start_ns, fills, snapshot, settlements,
                                   pnl, staged, ledger_refusals=ledger)
    if counters_problem is not None and (problem is None or problem[0] in JUDGE_HOLD_CODES):
        problem = counters_problem
    if problem is not None:
        raise Refused(*problem)
    return record


def _oq_passed(oq: Mapping[str, Any] | None) -> bool:
    return oq is not None and oq["passed"] is True and oq["attributed_fills"] >= OQ_MIN_FILLS


def _failed_checks(oq: Any) -> list[str]:
    """The names of an OQ record's failing checks in OQ_CHECKS order (C13 fix g); every check when the
    record is not a readable mapping, so a failure is never reported as naming nothing."""
    checks = oq.get("checks") if isinstance(oq, Mapping) else None
    if not isinstance(checks, Mapping):
        return list(probe_bar.OQ_CHECKS)
    return [name for name in probe_bar.OQ_CHECKS
            if not (isinstance(checks.get(name), Mapping) and checks[name].get("passed") is True)]


def _probe_trial_id(ops: Ops, engine_id: str) -> str | None:
    """The trial of the newest completed probe request for this engine."""
    trial_id, newest = None, None
    for row in ops.requests():
        if row.get("verb") != "probe" or row.get("subject") != engine_id or row.get("state") != "completed":
            continue
        candidate = (row.get("context") or {}).get("trial_id")
        stamp = str(row.get("requested_at"))
        if type(candidate) is str and (newest is None or stamp >= newest):
            trial_id, newest = candidate, stamp
    return trial_id


def _latest_verdict(ops: Ops, engine_id: str) -> dict[str, Any] | None:
    """The newest judge verdict for one engine; None when the judge never wrote one. Bounded scan.
    An unreadable or malformed newest file refuses verdict_unreadable: an older file never stands
    in for it."""
    directory = ops.evidence_dir / engine_id / VERDICTS_DIR
    best: tuple[tuple[str, int], str] | None = None
    try:
        with os.scandir(directory) as iterator:
            for count, entry in enumerate(iterator):
                if count >= MAX_VERDICT_SCAN:
                    raise Refused("verdict_unreadable", f"{directory} holds over {MAX_VERDICT_SCAN} entries")
                match = _VERDICT_FILE.fullmatch(entry.name)
                if match is not None:
                    key = (match.group(1), int(match.group(2) or 0))
                    if best is None or key > best[0]:
                        best = (key, entry.name)
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise Refused("verdict_unreadable", f"{directory}: {type(exc).__name__}") from exc
    if best is None:
        return None
    try:
        data = _read_bounded(directory / best[1], MAX_VERDICT_BYTES)
    except Refused as exc:
        raise Refused("verdict_unreadable", exc.detail) from exc
    doc = None if data is None else _strict_loads(data, "verdict_unreadable")
    if (not isinstance(doc, dict) or doc.get("schema") != VERDICT_SCHEMA or doc.get("engine_id") != engine_id
            or doc.get("decision") not in DECISIONS):
        raise Refused("verdict_unreadable", f"{best[1]} is malformed")
    return doc


def _current_verdict(ops: Ops, engine_id: str) -> dict[str, Any] | None:
    """The newest verdict when it reads the engine's current probe trial, else None."""
    verdict = _latest_verdict(ops, engine_id)
    if verdict is None or verdict.get("trial_id") != _probe_trial_id(ops, engine_id):
        return None
    return verdict


def _ladder_problem(ops: Ops, engine_id: str, rung: Any, contracts: int) -> tuple[str, str] | None:
    """Why `contracts` is not the next rung for this probe, or None. OQ first (the judge's own
    qualification of the current probe, _oq_current, then a pass), then the newest verdict of the
    current trial (a HOLD, RETUNE or KILL blocks), then probe_bar.ladder_step."""
    oq, problem = _oq_current(ops, engine_id)
    if problem is not None:
        return problem
    if not _oq_passed(oq):
        seen = "no OQ record" if oq is None else f"{oq['attributed_fills']} attributed fills, passed {oq['passed']}"
        return "oq_not_passed", f"the ladder needs operational qualification ({OQ_MIN_FILLS} attributed fills): {seen}"
    verdict = _current_verdict(ops, engine_id)
    if verdict is not None and verdict["decision"] in LADDER_BLOCKING:
        return "ladder_blocked", f"the newest judge verdict decides {verdict['decision']}"
    state = "PENDING" if verdict is None else verdict.get("verdict")
    step = probe_bar.ladder_step(state if type(state) is str else None, True, rung)
    if step != contracts:
        return "ladder_rung", (f"from {rung} contract(s) the next rung is {step}" if step is not None
                               else f"no rung follows {rung} contract(s) on a {state} read")
    return None


def _probe_assignment(registry: er.Registry, engine_id: str) -> Mapping[str, Any]:
    assignment = registry.assignments.get(engine_id)
    if assignment is None or assignment["role"] != "probe":
        raise Refused("not_probing", f"{engine_id} holds no probe assignment")
    return assignment


def _lifecycle_state(record: Mapping[str, Any] | None) -> str:
    return "absent" if record is None else record["state"]


def _refuse_bound_elsewhere(ops: Ops, approval_id: str, request_id: str) -> None:
    """An approval is bound to ONE request id by the transaction's first write (its consumption
    marker, written before any lifecycle or registry write), so another id presenting it is refused
    even while the binding request is still incomplete, and that request's rerun completes it."""
    consumer = ops.approval_consumer(approval_id)
    if consumer is not None and consumer != request_id:
        raise Refused("approval_bound_to_other_request", f"approval {approval_id} is bound to request {consumer}")


def cmd_probe_size(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    if type(a.contracts) is not int or a.contracts not in PROBE_SIZED_CONTRACTS:
        raise Refused("invalid_contracts", f"--contracts is one of {PROBE_SIZED_CONTRACTS}")
    approval_id = _file_id(a.approval, "approval")
    args = {"contracts": a.contracts, "approval": approval_id}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        _refuse_tenant_ladder(ops, engine_id, "probe-size")  # inside the request: HEAD's records and rows
        rid = record["request_id"]
        _refuse_bound_elsewhere(ops, approval_id, rid)
        assignment = _probe_assignment(ops.registry(), engine_id)
        account_id = assignment["account_id"]
        canary = ops.canary()
        checked = False

        def check() -> None:
            current = canary.optional(engine_id)
            state = _lifecycle_state(current)
            if state not in GRADUATE_FROM:
                raise Refused("lifecycle_state_allows", f"lifecycle state {state}")
            problem = _ladder_problem(ops, engine_id, current.get("contracts"), a.contracts)
            if problem is not None:
                raise Refused(*problem)
            doc = ops.load_approval(approval_id)
            reason = ops.approval_problem(doc, kind="probe_size", engine_id=engine_id, account=account_id,
                                          symbols=assignment["symbols"], sizing=str(a.contracts), request_id=rid)
            if reason is not None:
                raise Refused("approval_valid", reason)

        if ops.begin(record, "approval"):  # the first write binds the approval to this request id
            check()
            checked = True
            ops.consume_approval(approval_id, rid)
            ops.done(record, "approval")
        if ops.begin(record, "lifecycle"):
            def change(doc: dict[str, Any]) -> bool:
                entry = doc["assignments"].get(engine_id)
                if entry is None or entry["role"] != "probe" or entry["account_id"] != account_id:
                    raise Refused("not_probing", f"{engine_id} lost its probe assignment")
                current = canary.optional(engine_id)
                # A crash between the lifecycle write and done() resumes here: the approval is bound
                # to this request, so a lifecycle naming it is this request's own write.
                if not (_lifecycle_state(current) == "probe_sized" and current.get("contracts") == a.contracts
                        and current.get("approval_id") == approval_id):
                    if not checked:
                        check()
                    canary.probe_size(engine_id, contracts=a.contracts, approval_id=approval_id, now=ops.now)
                return False  # the rung is lifecycle state; the registry section only orders the locks

            # Registry lock first, the canary transition inside it (the module's lock order).
            ops.registry_store().mutate("probe-size", change, request_id=rid, now=ops.now)
            ops.done(record, "lifecycle")
        lifecycle = canary.get(engine_id)
        return {"engine_id": engine_id, "account_id": account_id, "lifecycle_state": lifecycle["state"],
                "contracts": lifecycle.get("contracts"), "registry_generation": ops.registry().generation}

    receipt, result, replayed = ops.mutate("probe-size", engine_id, a.request_id, args, perform)
    return ops.applied("probe-size", receipt, result, replayed)


def _graduation_problem(ops: Ops, engine_id: str) -> str | None:
    """None only for a fresh GRADUATE_ELIGIBLE verdict of the current trial whose gate passed, whose
    own read's qualification did not fail (qualification_error unset) and whose qualification is
    RE-DERIVED from the judge's root-owned OQ record (C13 fix g; the verdict's embedded qualification
    is display only, since the verdict directory is not root-owned): _oq_current must return the
    record (root-owned set, the current probe's engine, account and trial, fresh, its evidence digest
    recomputing from the files on disk) and it must pass; else qualification_unverified. That record
    must have been qualified inside the verdict's own read (verdict_stale_qualification otherwise, so
    a verdict scored against an older OQ record never graduates), and the verdict must name exactly
    that record, its qualified_at, evidence digest and pass flag (qualification_unverified)."""
    verdict = _latest_verdict(ops, engine_id)
    if verdict is None:
        return "no judge verdict; run engine_ops judge"
    if verdict.get("trial_id") != _probe_trial_id(ops, engine_id):
        return "the newest judge verdict reads another trial"
    if verdict["decision"] != "GRADUATE_ELIGIBLE":
        return f"the newest judge verdict decides {verdict['decision']}"
    gate = verdict.get("gate")
    if not isinstance(gate, dict) or gate.get("passed") is not True:
        return "the graduation gate did not pass"
    at = _utc_time(verdict.get("at"))
    if at is None or at > ops.now + timedelta(minutes=5) or ops.now - at > VERDICT_MAX_AGE:
        return f"the newest judge verdict is not fresh (older than {VERDICT_MAX_AGE})"
    if verdict.get("qualification_error") is not None:
        return f"verdict_qualification_error: the verdict's qualification failed: {verdict['qualification_error']}"[:300]
    oq, problem = _oq_current(ops, engine_id)
    if problem is not None:
        return f"qualification_unverified: the OQ record is not trusted: {problem[0]}: {problem[1]}"[:300]
    if oq is None:
        return "qualification_unverified: no OQ record qualifies the current probe"
    qualified = _utc_time(oq["qualified_at"])
    if qualified is None or not at - OQ_WINDOW_SLACK <= qualified <= at:
        return (f"verdict_stale_qualification: the verdict at {verdict.get('at')} was decided on no OQ record "
                f"qualified inside its own read (the OQ record's qualified_at "
                f"{None if qualified is None else qualified.isoformat()})")
    if not _oq_passed(oq):
        return (f"qualification_unverified: the OQ record did not pass ({oq['attributed_fills']} attributed "
                f"fills, failed {', '.join(_failed_checks(oq)) or 'none'})")[:300]
    claimed = verdict.get("qualification")
    if (not isinstance(claimed, dict) or claimed.get("passed") is not True
            or claimed.get("evidence_digest") != oq["evidence_digest"]
            or claimed.get("qualified_at") != oq["qualified_at"]):
        return ("qualification_unverified: the verdict's qualification does not name the OQ record "
                f"(qualified_at {oq['qualified_at']}, evidence digest {str(oq['evidence_digest'])[:12]})")
    return None


def _locked_transition(ops: Ops, record: dict[str, Any], action: str,
                       change: Callable[[dict[str, Any]], bool], wrote: list[bool]) -> None:
    """One registry critical section whose `change` performs the canary transition under the
    registry lock (registry lock, then canary lock: the module's order) and then edits the registry
    document. When the registry write refuses after the transition (`wrote` non-empty), the lifecycle
    record is restored through the store from the request's snapshot; an undo that itself fails is named
    in the request's rollback_errors for the audit. Re-raises the refusal."""
    try:
        ops.registry_store().mutate(action, change, request_id=record["request_id"], now=ops.now)
    except BaseException:
        if wrote:
            try:
                ops.restore(record, "lifecycle")
            except Exception as exc:  # the audit names what is left
                record["context"]["rollback_errors"] = [f"lifecycle: {type(exc).__name__}: {exc}"[:200]]
                # Ops.mutate persists this with guarded failure bookkeeping, preserving the
                # registry exception even if saving the rollback diagnostic also fails.
        raise


def cmd_graduate(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    approval_id = _file_id(a.approval, "approval")
    args = {"approval": approval_id}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        _refuse_tenant_ladder(ops, engine_id, "graduate")  # inside the request: HEAD's records and rows
        rid = record["request_id"]
        _refuse_bound_elsewhere(ops, approval_id, rid)
        assignment = ops.registry().assignments.get(engine_id)
        if assignment is None or assignment["role"] not in ("probe", "graduated"):
            raise Refused("not_probing", f"{engine_id} holds no probe assignment")
        account_id = assignment["account_id"]
        canary = ops.canary()
        checked = False

        def check() -> None:
            current = canary.optional(engine_id)
            state = _lifecycle_state(current)
            if state not in GRADUATE_FROM or assignment["role"] != "probe":
                raise Refused("lifecycle_state_allows", f"lifecycle state {state}, role {assignment['role']}")
            problem = _graduation_problem(ops, engine_id)
            if problem is not None:
                raise Refused("not_graduate_eligible", problem)
            breaches = maxima_breaches(current.get("policy"))
            if breaches:
                raise Refused("hard_maxima", f"the policy exceeds HARD_MAXIMA on {breaches}")
            doc = ops.load_approval(approval_id)
            reason = ops.approval_problem(doc, kind="graduate", engine_id=engine_id, account=account_id,
                                          symbols=assignment["symbols"], sizing="nominal", request_id=rid)
            if reason is not None:
                raise Refused("approval_valid", reason)

        if ops.begin(record, "approval"):  # the first write binds the approval to this request id
            check()
            checked = True
            ops.consume_approval(approval_id, rid)
            ops.done(record, "approval")
        if ops.begin(record, "registry"):
            ops.snapshot(record, "lifecycle", canary.path_for(engine_id), MAX_LIFECYCLE_BYTES)
            wrote: list[bool] = []

            def change(doc: dict[str, Any]) -> bool:
                entry = doc["assignments"].get(engine_id)
                if entry is None:
                    raise Refused("not_probing", f"{engine_id} lost its assignment")
                current = canary.optional(engine_id)
                # A rerun after a crash between the lifecycle write and the registry commit finds its
                # own graduated lifecycle (the approval is bound to this request) and goes on.
                if not (_lifecycle_state(current) == "graduated" and current.get("approval_id") == approval_id):
                    if not checked:
                        check()
                    canary.graduate(engine_id, approval_id=approval_id, now=ops.now)
                    _record_written(ops, record, "lifecycle", canary.path_for(engine_id))
                wrote.append(True)
                if entry["role"] == "graduated":
                    return False
                doc["assignments"][engine_id] = {**entry, "role": "graduated",
                                                 "request_id": record["request_id"], "approval_id": approval_id}
                return True

            # Registry lock first, the canary transition inside the same critical section (the
            # module's lock order); a registry write that refuses rolls the transition back.
            _locked_transition(ops, record, "graduate", change, wrote)
            ops.done(record, "lifecycle")
            ops.done(record, "registry")
        registry = ops.registry()
        return {"engine_id": engine_id, "account_id": account_id,
                "lifecycle_state": canary.get(engine_id)["state"],
                "role": registry.assignments[engine_id]["role"], "registry_generation": registry.generation}

    receipt, result, replayed = ops.mutate("graduate", engine_id, a.request_id, args, perform)
    return ops.applied("graduate", receipt, result, replayed)


def cmd_retire(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    if type(a.reason) is not str or not _REASON.fullmatch(a.reason):
        raise Refused("invalid_reason", f"--reason must match {_REASON.pattern}")
    args = {"reason": a.reason, "restore_bindings": bool(a.restore_bindings)}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        context = record["context"]
        if "assignment" not in context:
            current = ops.registry().assignments.get(engine_id)
            context["assignment"] = None if current is None else json.loads(json.dumps(current))
            ops.save_request(record)
        canary = ops.canary()
        if "registry" not in record["steps"] and canary.optional(engine_id) is None:
            raise Refused("lifecycle_absent", f"{engine_id} has no lifecycle record")
        if a.restore_bindings and ops.begin(record, "bindings"):
            captured = context["assignment"]
            lane = None if captured is None else _account_lane(ops.registry().accounts.get(captured["account_id"]))
            if lane is None:
                _restore_probe_bindings(ops, captured, engine_id)
            else:  # S7 A L2: a lane engine was never in an owner bindings file; nothing is restored
                context["lane"] = captured["account_id"]
            ops.done(record, "bindings")
        captured = context["assignment"]
        if (captured is not None and "registry" not in record["steps"]
                and _account_lane(ops.registry().accounts.get(captured["account_id"])) is not None
                and ops.begin(record, "legacy_bindings")):
            # S7 A L2: a legacy owner-file bind of this lane engine loses its owner slot as well. Lane
            # engines only, so an owner retire's steps and request bytes are HEAD's.
            context["lane"] = captured["account_id"]
            current = ops.registry().assignments.get(engine_id)
            if _same_generation(current, captured):
                context["legacy_binding_removed"] = _drop_legacy_owner_binding(ops, engine_id)
            else:
                context["legacy_binding_removed"] = False
                if not context.get("legacy_binding_superseded"):
                    by = None if current is None else current.get("request_id")
                    context["legacy_binding_superseded"] = {"by": by}
                    ops.save_request(record)
                    ops.journal("retire", engine_id, record["request_id"], "legacy_binding_superseded",
                                by=by)
            ops.done(record, "legacy_bindings")
        if ops.begin(record, "registry"):
            ops.snapshot(record, "lifecycle", canary.path_for(engine_id), MAX_LIFECYCLE_BYTES)
            wrote: list[bool] = []

            def change(doc: dict[str, Any]) -> bool:
                canary.retire(engine_id, a.reason, now=ops.now)  # a rerun writes nothing new
                _record_written(ops, record, "lifecycle", canary.path_for(engine_id))
                wrote.append(True)
                return engine_id in doc["assignments"] and er.apply_release(doc, engine_id)

            # Registry lock first, the canary transition inside the same critical section (the
            # module's lock order); a registry write that refuses rolls the transition back.
            _locked_transition(ops, record, "release", change, wrote)
            ops.done(record, "lifecycle")
            ops.done(record, "registry")
        state = canary.get(engine_id)
        result = {"engine_id": engine_id, "lifecycle_state": state["state"], "stop_reasons": _stop_codes(state),
                  "released_from": None if context["assignment"] is None else context["assignment"]["account_id"],
                  "bindings_restored": "bindings" in record["steps"] and context.get("lane") is None,
                  "registry_generation": ops.registry().generation}
        if context.get("legacy_binding_superseded"):
            result["legacy_binding_superseded"] = context["legacy_binding_superseded"]
        return result

    receipt, result, replayed = ops.mutate("retire", engine_id, a.request_id, args, perform)
    return ops.applied("retire", receipt, result, replayed)


# ---------------------------------------------------------------- judge (the daily timer)

def judge_decision(verdict: probe_bar.ProbeVerdict, gate: probe_bar.GateResult | None) -> str:
    """One decision per read. Pure. INCONCLUSIVE never becomes KILL; GRADUATE_ELIGIBLE needs the
    scorer's SUCCESS and every graduation_gate rule; an open window with no hold is PENDING."""
    if verdict.state == "INCONCLUSIVE":
        return "RETUNE"
    if verdict.decision == "KILL":
        return "KILL" if verdict.state == "FAILURE" else "HOLD"
    if verdict.decision == "GRADUATE_ELIGIBLE":
        return "GRADUATE_ELIGIBLE" if gate is not None and gate.passed else "HOLD"
    if verdict.decision == "RETUNE":
        return "RETUNE"
    if verdict.state == "PENDING" and not verdict.reasons:
        return "PENDING"
    return "HOLD"


def _run_script(argv: list[str], timeout_s: float) -> tuple[int, str]:
    """One bounded child process: (exit code, stderr tail). A timeout kills it and is 124; a
    launch failure is 127. The judge holds no engine_ops lock while this runs."""
    try:
        result = subprocess.run(argv, cwd=SCRIPTS_DIR.parent, capture_output=True, timeout=timeout_s,
                                check=False)
    except subprocess.TimeoutExpired:
        return 124, f"timed out after {timeout_s:g} s"
    except OSError as exc:
        return 127, f"{type(exc).__name__}: {exc}"
    return result.returncode, result.stderr.decode("utf-8", "replace")[-MAX_SCRIPT_STDERR:]


def _load_kalshi_trial() -> Any:
    """A fresh private module instance of scripts/kalshi_trial.py per call, never inserted into
    sys.modules, so a selector bound on the instance (_hosted_status) is seen by that one activation
    only; the script itself is never edited."""
    spec = importlib.util.spec_from_file_location("leafhft_engine_ops_kalshi_trial", KALSHI_TRIAL_SCRIPT)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load {KALSHI_TRIAL_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _hosted_status(kt: Any, engine_id: str, pinned_digest: str | None) -> Callable[..., dict[str, Any]]:
    """C13 fix k: kalshi_trial's `_status` for one probe. Every check of the original runs unchanged
    first; the book is returned as is when a lane is asked for or its top-level engine is the probe
    (a displaced probe). Otherwise the same status file, re-selected by kalshi_trial's own rule and
    refused if it changed during the read, must host exactly one `engine_id` entry with role probe in
    its executor.engines (first HOSTED_STATUS_MAX_ENGINES entries only); the view then names the probe
    and the registration's pinned policy digest (the hosted entry carries none) and keeps the book's
    own account-level reserved_cents and unreconciled, so the recorded `flat` stays conservative."""
    original = kt._status

    def select(directories, symbol, now_ns, lane=None):
        book = original(directories, symbol, now_ns, lane)
        if lane is not None or book["engine_id"] == engine_id:
            return book
        paths = [d / "kalshi-edge-status.json" for d in directories
                 if kt._matches(d, symbol) and (d / "kalshi-edge-status.json").is_file()]
        if not paths:
            raise kt.TrialError(f"{symbol}: status file changed during the read")
        path = max(paths, key=lambda p: (p.stat().st_mtime_ns, str(p)))
        raw, _ = kt._read(path, kt.MAX_STATUS_BYTES)
        watermark = kt._timestamp_ns(raw["generated_at"]) if "generated_at" in raw else path.stat().st_mtime_ns
        if watermark != book["status_watermark_ns"]:
            raise kt.TrialError(f"{symbol}: status file changed during the read")
        executor = raw.get("executor")
        if (not isinstance(executor, dict) or executor.get("error") is not None
                or not isinstance(executor.get("engines"), list)):
            raise kt.TrialError(f"{symbol}: engine mismatch in status (no hosted executor block)")
        hits = [e for e in executor["engines"][:HOSTED_STATUS_MAX_ENGINES]
                if isinstance(e, dict) and e.get("engine_id") == engine_id]
        if len(hits) != 1 or hits[0].get("role") != "probe":
            raise kt.TrialError(f"{symbol}: engine mismatch in status (the book hosts no {engine_id} probe)")
        if pinned_digest is None:
            raise kt.TrialError(f"{symbol}: the hosted probe's registration pins no policy digest")
        return {**book, "engine_id": engine_id, "policy_digest": pinned_digest}

    return select


def _book_activate(ops: Ops, engine_id: str, trial_id: str, account_id: str,
                   account: Mapping[str, Any]) -> str | None:
    """Activate the probe trial through scripts/kalshi_trial.py's own activate(), which refuses unless
    every probe book's fresh status file shows this engine. C13 fix k: the activation reads the probe's
    own entry, the top-level engine for a displaced probe or its executor.engines entry for a co-hosted
    one, never the incumbent's (_hosted_status on a private instance, _load_kalshi_trial). It runs in
    process, so the judge's single activation lock covers it, bounded by kalshi_trial's own read limits
    (MAX_DIRS, MAX_STATUS_BYTES, MAX_FILE_BYTES, MAX_TOTAL_ROWS) and the authority's 2 s read-lock
    timeout. None once activated, else why it stays pending."""
    if account.get("lane_id") is not None:
        return "activation_lane_unsupported"
    try:
        bindings = ops.source_for(account_id).bindings_path
    except Refused as exc:
        return exc.code
    argv = ["activate", trial_id,
            "--trials-dir", str(ops.trials_dir), "--runs-root", str(ops.runs_root(account)),
            "--authority", str(ops.authority), "--engines-dir", str(ops.engines_dir),
            "--bindings", str(bindings)]
    try:
        kt = _load_kalshi_trial()
        args = kt.parser().parse_args(argv)
        digest = ops.trials().get(trial_id).registration.candidate.get("policy_digest")
        kt._status = _hosted_status(kt, engine_id, digest)
        kt.activate(ops.trials(), args)
    except Exception as exc:  # the breadth the subprocess boundary had; never BaseException
        return f"book_status_pending: {type(exc).__name__}: {exc}"[:300]
    return None


def _score(ops: Ops, trial_id: str, runs_root: Path, write: bool) -> tuple[dict | None, bytes | None, str | None]:
    """(report, report bytes, None) from scripts/kalshi_engine_verdict.py run bounded, or
    (None, None, why). Without --write the scorer records no trial event."""
    with tempfile.TemporaryDirectory(prefix="leafhft-judge-") as scratch:
        out, md = Path(scratch) / "report.json", Path(scratch) / "report.md"
        argv = [sys.executable, str(SCRIPTS_DIR / "kalshi_engine_verdict.py"),
                "--trial", str(ops.trials_dir / trial_id), "--runs-root", str(runs_root),
                "--out", str(out), "--md", str(md), "--now", ops.now.isoformat()]
        if not write:
            argv.append("--no-event")
        code, err = _run_script(argv, JUDGE_SCORER_TIMEOUT_S)
        if code != 0:
            return None, None, f"scorer_failed: exit {code}: {err.strip()[-200:]}"
        try:
            data = _read_bounded(out, MAX_REPORT_BYTES)
            if data is None:
                return None, None, "scorer_failed: no report written"
            return _strict_loads(data, "scorer_report_invalid"), data, None
        except Refused as exc:
            return None, None, f"{exc.code}: {exc.detail}"[:300]


def _gate_lifecycle(ops: Ops, record: Mapping[str, Any] | None, oq: Mapping[str, Any] | None) -> dict[str, Any]:
    """probe_bar.graduation_gate's lifecycle input from the lifecycle record and the OQ record.
    Missing evidence stays None, which fails its rule (never a pass by default)."""
    record = record or {}
    started = _utc_time(record.get("probe_started_at"))
    days = None if started is None else max(0, (ops.now.date() - started.date()).days - 1)
    trips = [f"{day}T00:00:00+00:00" for day in record.get("breaker_trips") or ()
             if type(day) is str and len(day) == 10]
    stops = [row.get("at") for row in record.get("history") or ()
             if isinstance(row, dict) and row.get("state") == "halted"]
    pnl = None if oq is None else oq.get("one_lot_pnl_cents")
    return {"as_of": ops.now.isoformat(),
            "one_lot_pnl_cents": pnl if isinstance(pnl, list) and len(pnl) <= MAX_OQ_PNL_ROWS else None,
            "breaker_suspensions": trips, "integrity_stops": stops, "complete_utc_days": days,
            "oq_passed": _oq_passed(oq)}


def _plain(value: Any) -> Any:
    """Decimals as text so a verdict file never carries a float."""
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, dict):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    return value


def _write_verdict(ops: Ops, engine_id: str, body: Mapping[str, Any]) -> str:
    """Name by invocation time; the body carries the engine's judgement time."""
    data = _canonical(body)
    if len(data) > MAX_VERDICT_BYTES:
        raise Refused("verdict_too_large", f"{engine_id}: {len(data)} bytes")
    directory = ops.evidence_dir / engine_id / VERDICTS_DIR
    base = f"{ops.run_now:%Y%m%dT%H%M%SZ}"
    for index in range(MAX_RECEIPT_SUFFIX):
        path = directory / (base + ("" if index == 0 else f"-{index}") + ".json")
        if _create_exclusive(path, data):
            return str(path)
    raise Refused("verdict_slots_exhausted", str(directory))


# The judge's not-ready allowlist (D2, JUDGE v2): the ONLY error codes a judge row may classify as a
# "hold" (HOLD verdict, no page), each under its own condition in _judge_hold. Every other code,
# including every OQ integrity refusal and any code added later, is a failure and pages.
JUDGE_HOLD_CODES = frozenset({"oq_time_out_of_window", "oq_venue_stale", OPENING_BALANCE_MISSING})
JUDGE_VENUE_GRACE_S = 3600  # the snapshot timer runs every 5 min: a snapshot older than this pages
JUDGE_PRESTART_MAX_S = 3600  # kalshi_trial rounds the start up to the next 15 min or 1 h mark: further ahead pages


def _judge_venue_age_s(ops: Ops, engine_id: str, account_id: str | None) -> float | None:
    """Seconds since the probe's own venue snapshot was observed, read through the same trusted path
    as _venue_snapshot (root-owned, this engine and account, not truncated); None when the age
    cannot be established (absent, untrusted, unreadable, another account, unparseable). No network."""
    try:
        path = venue_snapshot.snapshot_path(ops.venue_dir, engine_id)
        if not os.path.lexists(path) or _trusted_set_problem(ops.venue_dir, engine_id) is not None:
            return None
        data = _read_oq_file(path, venue_snapshot.MAX_SNAPSHOT_BYTES)
        doc = None if data is None else venue_snapshot.read_snapshot(data, engine_id)
        if doc is None or doc["account_id"] != account_id or doc["truncated"]:
            return None
        observed = _utc_time(doc["observed_at"])
        return None if observed is None else (ops.now - observed).total_seconds()
    except Exception:  # fails closed: an age that cannot be read is no hold
        return None


def _judge_hold(ops: Ops, code: str, engine_id: str, trial, account_id: str | None, write: bool) -> bool:
    """True only for an allowlisted not-ready code under its condition (fails closed, never raises):
    - oq_time_out_of_window while the activated trial's whole check window is still in the future
      (start - OQ_WINDOW_SLACK > now + OQ_WINDOW_SLACK, so the last 2 x slack before the start pages)
      and the start is at most JUDGE_PRESTART_MAX_S + OQ_WINDOW_SLACK ahead (further is skew and
      pages); a start in the past, or one that cannot be converted to a time (overflow), is a failure;
    - oq_venue_stale while the snapshot's established age is within [0, JUDGE_VENUE_GRACE_S];
    - opening_balance_missing on a read-only call (write False)."""
    if code not in JUDGE_HOLD_CODES:
        return False
    if code == "oq_time_out_of_window":
        try:
            start_ns = None if trial.activation is None else trial.activation.population_start_ns
            if type(start_ns) is not int:
                return False
            start = _EPOCH + timedelta(microseconds=start_ns // 1000)
            return (start - OQ_WINDOW_SLACK > ops.now + OQ_WINDOW_SLACK
                    and start - ops.now <= timedelta(seconds=JUDGE_PRESTART_MAX_S) + OQ_WINDOW_SLACK)
        except (OverflowError, ValueError, OSError, TypeError):  # an unconvertible start is no hold
            return False
    if code == "oq_venue_stale":
        age = _judge_venue_age_s(ops, engine_id, account_id)
        return age is not None and 0 <= age <= JUDGE_VENUE_GRACE_S
    return code == OPENING_BALANCE_MISSING and not write


def _judge_one(ops: Ops, engine_id: str, registry: er.Registry, write: bool) -> dict[str, Any]:
    """Judge one probe. A per-engine problem lands in the row's `error` and the verdict file
    records a HOLD; only a missing trial or an unreadable store raises. The row's `error_kind`
    classifies the error (D2, JUDGE v2): "hold" ONLY for the not-ready allowlist JUDGE_HOLD_CODES
    under its conditions (_judge_hold): oq_time_out_of_window raised by _qualify while the trial's
    population start is after now, oq_venue_stale raised by _qualify while the snapshot is at most
    JUDGE_VENUE_GRACE_S old, and opening_balance_missing on a read-only call. Everything else is
    "failure": every other Refused from _qualify (oq_venue_mismatch, oq_counters_mismatch,
    oq_counters_window_unverified, evidence_unavailable, oq_untrusted_owner, any later code), a
    non-Refused qualification exception, a scorer error, an activated trial with no account. None
    without an error. Classification fails closed. `scorer_decision` is the decision before a failed
    qualification forces the published decision to HOLD, so cmd_judge still pages a masked KILL."""
    trial_id = _probe_trial_id(ops, engine_id)
    if trial_id is None:
        raise Refused("no_probe_trial", f"{engine_id} has no completed probe request")
    record = ops.canary().optional(engine_id)
    store = ops.trials()
    trial = store.get(trial_id)
    assignment = registry.assignments.get(engine_id)
    account_id = assignment["account_id"] if assignment is not None else (record or {}).get("account_id")
    account = registry.accounts.get(account_id) if type(account_id) is str else None
    pending = error = None
    if trial.activation is None:
        if _lifecycle_state(record) not in GRADUATE_FROM:
            pending = f"probe not running (lifecycle {_lifecycle_state(record)})"
        elif account is None:
            pending = "account_unknown"
        elif not write:
            pending = "not activated; judge --write activates once the book status shows the engine"
        else:
            # C13 fix g: activation takes the trial's opening balance. The root-run venue read is taken
            # BEFORE the population starts (activation sets the start at or after this moment); without
            # a trusted, fresh balance read the trial is not activated at all, so no new trial runs
            # without an opening. C13 fix i: the opening is persisted BEFORE the activation is
            # written (_capture_opening_then_activate), so a crash between them leaves no activation.
            opening, unavailable = _venue_snapshot(ops, engine_id, account_id)
            if unavailable is not None:
                pending = f"opening_balance_unavailable: {unavailable[0]}: {unavailable[1]}"[:300]
            else:
                try:
                    pending = _capture_opening_then_activate(
                        ops, engine_id, trial_id, opening,
                        lambda: _book_activate(ops, engine_id, trial_id, account_id, account))
                except Refused as exc:
                    pending = f"{exc.code}: {exc.detail}"[:300]
                trial = store.get(trial_id)
                if trial.activation is None and pending is None:
                    pending = "activation_not_recorded"
    # C13 fix i: an activation without its opening (legacy, written before the opening) is repaired
    # before any judgement on a --write call; until it is, the judge refuses to read the trial.
    opening_missing = None
    if trial.activation is not None and _opening_balance(ops, engine_id, trial_id) is None:
        opening_missing = (_repair_opening_balance(ops, engine_id, trial_id, account_id)
                           if write and type(account_id) is str else
                           f"{OPENING_BALANCE_MISSING}: the activation carries no opening balance; judge "
                           f"--write repairs it from a fresh venue read")
    report = data = None
    error_kind = None
    if trial.activation is not None:
        if account is None:
            error = "account_unknown"
        elif opening_missing is not None:
            error = opening_missing
            if _judge_hold(ops, OPENING_BALANCE_MISSING, engine_id, trial, None, write):
                error_kind = "hold"  # a read-only call never repairs: the opening is not ready, not failed
        else:
            report, data, error = _score(ops, trial_id, ops.runs_root(account), write)
    failure = None  # C13 fix f: (reason code, {type, message}) of a qualification that failed
    if write:  # every written read re-qualifies the probe and persists oq.json (C13)
        try:
            advance = getattr(ops, "advance_clock", None)
            if callable(advance):
                advance()
            result = _qualify(ops, engine_id, trial, trial_id, account_id if type(account_id) is str else None,
                              account)
            if trial.activation is not None and not _oq_passed(result):
                # C13 fix g: a qualification that RETURNED failed is a failed qualification too, exactly
                # as the exception path: HOLD, qualification_failed, the failing checks persisted.
                failed = _failed_checks(result)
                failure = (QUALIFICATION_FAILED, {
                    "type": "QualificationFailed",
                    "message": (f"operational qualification failed: {', '.join(failed) or 'no check named'}; "
                                f"{result.get('attributed_fills') if isinstance(result, Mapping) else None} "
                                f"attributed fills (at least {OQ_MIN_FILLS})")[:300],
                    "failed_checks": failed})
        except Refused as exc:  # refused evidence; the OQ it persisted fails closed
            held = _judge_hold(ops, exc.code, engine_id, trial,
                               account_id if type(account_id) is str else None, write)
            if error is None:  # only an allowlisted not-ready code holds without a page (JUDGE v2)
                error, error_kind = f"{exc.code}: {exc.detail}"[:300], ("hold" if held else "failure")
            elif not held:
                error_kind = "failure"
            failure = (exc.code, {"type": "Refused", "message": f"{exc.code}: {exc.detail}"[:300]})
        except Exception as exc:  # any other failure: never a verdict published on an older OQ record
            text = "oq_write_failed" if isinstance(exc, (OSError, ValueError)) else QUALIFICATION_FAILED
            error = error or f"{text}: {type(exc).__name__}: {exc}"[:300]
            error_kind = "failure"  # a real failure pages even behind an earlier hold
            failure = (QUALIFICATION_FAILED, {"type": type(exc).__name__[:64], "message": str(exc)[:300]})
    if error is None:
        error_kind = None
    elif error_kind != "hold":  # fail closed: anything not placed in the hold list pages
        error_kind = "failure"
    # Only the current probe's own qualification counts, and after a failed one none does (C13 fix f):
    # an older OQ record never stands in for the qualification this read could not complete.
    oq = None if failure is not None else _oq_current(ops, engine_id)[0]
    life = _gate_lifecycle(ops, record, oq)
    body: dict[str, Any] = {
        "schema": VERDICT_SCHEMA, "engine_id": engine_id, "trial_id": trial_id, "at": ops.now.isoformat(),
        "activated": trial.activation is not None, "verdict": "PENDING", "read_kind": None,
        "decision": "PENDING", "gate": None, "population": None, "next_read_at": None,
        "reasons": [], "text": "", "report_sha256": None if data is None else _sha(data),
        "lifecycle": {"state": _lifecycle_state(record), "contracts": (record or {}).get("contracts"),
                      "as_of": life["as_of"], "complete_utc_days": life["complete_utc_days"],
                      "breaker_suspensions": life["breaker_suspensions"],
                      "integrity_stops": life["integrity_stops"], "oq_passed": life["oq_passed"],
                      "one_lot_pnl_rows": None if life["one_lot_pnl_cents"] is None
                      else len(life["one_lot_pnl_cents"])},
        # C13 fix f: the OQ record this verdict was decided on (graduate refuses one older than the
        # verdict's own read) and the failure of this read's qualification, which forces HOLD.
        "qualification": None if oq is None else {"qualified_at": oq["qualified_at"],
                                                  "evidence_digest": oq["evidence_digest"],
                                                  "passed": _oq_passed(oq)},
        "qualification_error": None if failure is None else failure[1]}
    if trial.activation is None:
        body.update(reasons=["not_activated"], text=f"trial not activated: {pending}"[:1000])
    elif opening_missing is not None and account is not None:  # C13 fix i: never judged without its opening
        body.update(decision="HOLD", reasons=[OPENING_BALANCE_MISSING], text=opening_missing[:1000])
    elif report is None:
        body.update(decision="HOLD", reasons=["scorer_unavailable"], text=str(error)[:1000])
    else:
        verdict = probe_bar.read_verdict(report)
        gate = probe_bar.graduation_gate(report, life)
        read_kind = report.get("read_kind") if isinstance(report, dict) else None
        body.update(verdict=verdict.state, decision=judge_decision(verdict, gate),
                    read_kind=read_kind if type(read_kind) is str and len(read_kind) <= 32 else None,
                    gate={"passed": gate.passed, "failed_checks": list(gate.failed_checks),
                          "evidence": _plain(gate.evidence)},
                    population=dict(verdict.population), next_read_at=verdict.next_read_at,
                    reasons=list(verdict.reasons), text=verdict.text[:1000])
    scorer_decision = body["decision"]  # before any forced HOLD: a masked KILL still pages (JUDGE v2)
    if failure is not None:  # a failed qualification never publishes anything but HOLD
        body.update(decision="HOLD", reasons=[failure[0], *[r for r in body["reasons"] if r != failure[0]]])
    path = None
    if write:
        if data is not None:
            _atomic_write(ops.evidence_dir / engine_id / "verdict.json", data)
        path = _write_verdict(ops, engine_id, body)
    return {"engine_id": engine_id, "trial_id": trial_id, "activated": body["activated"],
            "verdict": body["verdict"], "read_kind": body["read_kind"], "decision": body["decision"],
            "path": path, "error": error, "error_kind": error_kind, "scorer_decision": scorer_decision}


def cmd_judge(ops: Ops, a: argparse.Namespace) -> int:
    """Exit 2 iff any row failed, which the timer unit turns into a unit failure that
    leafhft_alert's unit_failures rule pages (the ONLY pager); else exit 0. A row fails when its
    error_kind is "failure", its published decision is KILL, or its scorer_decision is KILL (a scorer
    KILL a failed qualification forced to HOLD still pages; the published HOLD still blocks the
    ladder). A row is a "hold" ONLY when _judge_one marked it so AND its error code is in
    JUDGE_HOLD_CODES: oq_time_out_of_window with the population start after now, oq_venue_stale with
    the snapshot at most JUDGE_VENUE_GRACE_S old, opening_balance_missing on a read-only call. A
    hold records its HOLD verdict, blocks the ladder and is counted in `held`, but never pages by
    itself. Any other error is a failure (fail closed), and an exception _judge_one raises under
    --all is a failure row."""
    if bool(a.engine_id) == bool(a.all):
        raise Refused("invalid_target", "judge takes one engine id or --all")
    registry = ops.registry()
    lanes = _lane_accounts(registry)
    tenant: list[str] = []  # S7 A L2: tenant probes wait for S7 D evidence, never a verdict here
    if a.engine_id:
        engine_ids = [_engine_id(a.engine_id)]
        try:
            record = ops.canary().optional(engine_ids[0])
        except Exception:
            record = None  # the owner path reads it again and names the problem
        if _is_tenant_probe(registry, lanes, engine_ids[0], record):
            tenant, engine_ids = engine_ids, []
    else:
        owner = []
        for record in ops.canary().list():
            if record["state"] not in GRADUATE_FROM:
                continue
            is_tenant = _is_tenant_probe(registry, lanes, record["engine_id"], record)
            (tenant if is_tenant else owner).append(record["engine_id"])
        # The cap counts owner probes only, so tenant records can never starve the owner sweep.
        engine_ids = sorted(owner)[:MAX_JUDGE_ENGINES]
        tenant = sorted(tenant)[:MAX_JUDGE_ENGINES]
    rows = [{"engine_id": engine_id, "trial_id": None, "activated": False, "verdict": None, "read_kind": None,
             "decision": "HOLD", "path": None, "error": None, "reasons": [EVIDENCE_UNAVAILABLE],
             "deferred": TENANT_EVIDENCE_DEFERRED} for engine_id in tenant]
    for engine_id in engine_ids:
        try:
            advance = getattr(ops, "advance_clock", None)
            if callable(advance):
                advance()
            rows.append(_judge_one(ops, engine_id, registry, bool(a.write)))
        except Exception as exc:
            if a.engine_id:
                raise
            rows.append({"engine_id": engine_id, "trial_id": None, "activated": False, "verdict": None,
                         "read_kind": None, "decision": None, "path": None,
                         "error": getattr(exc, "code", type(exc).__name__), "error_kind": "failure",
                         "scorer_decision": None})
    for row in rows:  # fail closed: only a marked hold whose code is allowlisted stays a hold
        error = row["error"]
        row["error_kind"] = (None if error is None
                             else "hold" if row.get("error_kind") == "hold" and type(error) is str
                             and error.split(":", 1)[0] in JUDGE_HOLD_CODES else "failure")
    failed = sum(1 for row in rows if row["error_kind"] == "failure" or row["decision"] == "KILL"
                 or row.get("scorer_decision") == "KILL")
    held = sum(1 for row in rows if row["error_kind"] == "hold")
    lines = [f"{row['engine_id']}: {row['decision'] or 'not judged'} ({row['verdict'] or '-'}"
             f"{', ' + row['read_kind'] if row['read_kind'] else ''})"
             f"{'; scorer KILL' if row.get('scorer_decision') == 'KILL' and row['decision'] != 'KILL' else ''}"
             f"{'; ' + row['error_kind'] + ': ' + row['error'] if row['error'] else ''}"
             f"{'; wrote ' + row['path'] if row['path'] else ''}"
             f"{'; ' + row['deferred'] + ' ' + EVIDENCE_UNAVAILABLE if row.get('deferred') else ''}"
             for row in rows]
    ops.emit({"judged": rows, "failed": failed, "held": held, "write": bool(a.write)},
             "\n".join(lines) or "no probes to judge")
    return EXIT_REFUSED if failed else EXIT_OK


# ---------------------------------------------------------------- breaker

def _breaker_view(registry: er.Registry) -> dict[str, Any]:
    breakers = registry.doc["loss_breakers"]
    accounts = {}
    for account_id in registry.accounts:
        pct, _ = registry.effective_pct(account_id)
        accounts[account_id] = {"pct": pct, "explicit": account_id in breakers["accounts"]}
    engines = {}
    for engine_id, assignment in registry.assignments.items():
        pct, inherited = registry.effective_pct(assignment["account_id"], engine_id)
        engines[engine_id] = {"account_id": assignment["account_id"], "pct": pct, "inherited": inherited}
    return {"default_pct": int(breakers["default_pct"]), "accounts": accounts, "engines": engines}


def cmd_breaker_show(ops: Ops, a: argparse.Namespace) -> int:
    view = _breaker_view(ops.registry())
    lines = [f"default {view['default_pct']}%"]
    lines += [f"account {aid}: {row['pct']}%" for aid, row in sorted(view["accounts"].items())]
    lines += [f"engine {eid}: {row['pct']}%{' (inherited)' if row['inherited'] else ''}"
              for eid, row in sorted(view["engines"].items())]
    ops.emit(view, "\n".join(lines))
    return EXIT_OK


def cmd_breaker_set(ops: Ops, a: argparse.Namespace) -> int:
    if type(a.pct) is not int or not er.MIN_BREAKER_PCT <= a.pct <= er.MAX_BREAKER_PCT:
        raise Refused("invalid_pct", f"--pct is {er.MIN_BREAKER_PCT}..{er.MAX_BREAKER_PCT}")
    approval_id = None if a.approval is None else _file_id(a.approval, "approval")
    subject = a.id if a.scope == "engine" else REGISTRY_SUBJECT
    if a.scope == "engine":
        _engine_id(a.id)
    args = {"scope": a.scope, "id": a.id, "pct": a.pct, "approval": approval_id}

    def perform(record: dict[str, Any]) -> dict[str, Any]:
        registry = ops.registry()
        if a.scope == "account":
            if a.id not in registry.accounts:
                raise Refused("unknown_account", a.id)
            account_id, engine_id = a.id, None
        else:
            assignment = registry.assignments.get(a.id)
            if assignment is None:
                raise Refused("unknown_engine", f"{a.id} has no assignment")
            account_id, engine_id = assignment["account_id"], a.id
        context = record["context"]
        current = registry.effective_pct(account_id, engine_id)[0]
        # Until this request's own write has landed, a raise is decided against the CURRENT
        # persisted pct, never a baseline an earlier attempt captured: another request may have
        # lowered it since, and then this target is a raise that needs the approval. Once the write
        # may have landed (done, or in flight with the target already stored) the decision stands.
        written = "registry" in record["steps"] or (context.get("current_step") == "registry"
                                                    and current == a.pct and "raising" in context)
        if not written:
            if context.get("before_pct") != current or context.get("raising") != (a.pct > current):
                context["before_pct"] = current
                context["raising"] = a.pct > current
                ops.save_request(record)
        raising = context.get("raising", a.pct > context["before_pct"])
        if raising:
            if approval_id is None:
                raise Refused("approval_valid", f"raising {a.scope} {a.id} from {context['before_pct']}% "
                                                f"to {a.pct}% needs --approval")
            doc = ops.load_approval(approval_id)
            problem = ops.approval_problem(doc, kind="breaker", engine_id=engine_id, account=account_id,
                                           symbols=(), sizing=str(a.pct), request_id=record["request_id"])
            if problem is not None:
                raise Refused("approval_valid", problem)
        if ops.begin(record, "registry"):
            ops.registry_store().set_breaker(a.scope, a.id, a.pct, request_id=record["request_id"],
                                             now=ops.now)
            ops.done(record, "registry")
        if raising and ops.begin(record, "approval"):
            ops.consume_approval(approval_id, record["request_id"])
            ops.done(record, "approval")
        registry = ops.registry()
        return {"scope": a.scope, "id": a.id, "before_pct": context["before_pct"],
                "pct": registry.effective_pct(account_id, engine_id)[0],
                "registry_generation": registry.generation}

    receipt, result, replayed = ops.mutate("breaker-set", subject, a.request_id, args, perform)
    return ops.applied("breaker-set", receipt, result, replayed)


# ---------------------------------------------------------------- approve (contract C6c, interim until RT5)
#
# Identity-grade `tg1-` probe approvals: the runner sends the operator ONE card through the
# dedicated approvals bot and mints only from his reply, read straight from the Bot API
# (approve_presence). The wait holds the presence lock only, never the ops lock, so halt always
# gets through. Everything a card shows is frozen in the root-only record before it is sent.
#
# One open card per store: the contract's one poller demultiplexing every issued record is
# implemented as serialization. The presence lock is held from before the card until its record
# is terminal and the poll waits on that one record, so no poll can swallow another card's reply;
# a second approve while a card is open is refused (presence_busy while the lock is held,
# presence_pending_other while an earlier card's window is still open).
#
# Every record transition is a compare-and-swap under the ops lock (_approve_cas): the stored
# record is re-read inside the lock and the transition refuses when its state is no longer the
# one it expects, so a cancel's voided always beats a late reply, a sent card or a publication.
# _approve_finish re-reads under the same lock before it publishes and never publishes after a void.
#
# C6f widens the exception by one kind: `--kind assign` mints ONE identity-grade assign approval
# per card (one engine, one account, its symbols, a role) under the same presence lock, the same
# shared prompt-log rate limits, the same 600 s window and reply rules. Its record and receipt carry
# `kind` and `role`; a probe record, card, args digest and receipt keep the exact shape they had.

APPROVE_SCHEMA = "leafhft.engine_ops.approve.v1"
PRESENCE_SCHEMA = "leafhft.engine_ops.presence.v1"
APPROVE_KINDS = ("probe", "assign", "wave")
ASSIGN_TITLE = "Kashbot assign approval (identity grade, tg1)"
MAX_APPROVE_ITEMS = 3
MAX_WAVE_ITEMS = 64
MAX_WAVE_MANIFEST_BYTES = 64 * 1024
MAX_WAVE_RECORD_BYTES = 256 * 1024
MAX_APPROVE_RECORD_BYTES = 64 * 1024
MAX_APPROVE_RECORDS = 512
MAX_LIST_ENTRIES = 512
MAX_OFFSET_BYTES = 256
APPROVE_TERMINAL = frozenset({"minted", "declined", "expired", "voided"})
APPROVE_REQUESTS_DIR = "approve-requests"
PRESENCE_LOCK_FILE = "presence.lock"
TELEGRAM_OFFSET_FILE = "telegram-offset.json"
POLLER_DIR_SUFFIX = "-poller"
PROMPT_LOG_FILE = "prompt-log.jsonl"
DEVICE_ID_PREFIX = "dv1-"
DEVICE_GRADE = "presence-device-v1"
DEVICE_LEDGER_DIR = "device-evidence"
DEVICE_OUTBOX_DIR = "device-notices"
DEVICE_EVIDENCE_KEYS = ("credential_id", "plan_sha256", "proposal_id", "evidence_sha256")
STORE_STATE_NAMES = frozenset({APPROVE_REQUESTS_DIR, PRESENCE_LOCK_FILE, PROMPT_LOG_FILE,
                               DEVICE_LEDGER_DIR, DEVICE_OUTBOX_DIR})
RUNNER_CHECKOUT = "/opt/leafhft"
RUNNER_PYTHON = "/opt/leafhft/.venv/bin/python"

_APPROVAL_FILE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]*\.json")
_REVOKE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}")
_PASS_THROUGH = (Refused, er.RegistryError, ManifestInvalid, CanaryError, TrialError, EngineError)


@contextmanager
def _presence_lock(path: Path):
    """Non-blocking: held from before the card until its record is terminal, so at most one card
    ever awaits a reply; a second approve refuses presence_busy instead of waiting."""
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = open(path, "a+b")
    try:
        if handle.seek(0, os.SEEK_END) == 0:
            handle.write(b"\0")
            handle.flush()
        try:
            _lock_handle(handle)
        except OSError:
            raise Refused("presence_busy", "another approve holds the presence lock") from None
        try:
            yield
        finally:
            _unlock_handle(handle)
    finally:
        handle.close()


def _approve_seams(ops: Ops, a: argparse.Namespace) -> SimpleNamespace:
    """The main() test seams, else the real Bot API, the aws-cli fetcher and the system clocks."""
    seams = getattr(a, "presence_seams", None)
    clock = getattr(seams, "clock", None)
    if clock is None:
        fixed = ops.now if getattr(seams, "now", None) is not None else None
        clock = (lambda: fixed) if fixed is not None else (lambda: datetime.now(timezone.utc))
    return SimpleNamespace(telegram=getattr(seams, "telegram", None),
                           secrets=getattr(seams, "secrets", None) or approve_presence.fetch_secret,
                           clock=clock, monotonic=getattr(seams, "monotonic", None) or time.monotonic,
                           ops_lock=ops.registry_dir / OPS_LOCK_FILE)


def _approve_store(ops: Ops) -> Path:
    """Create the store 0700 when absent, then the root-chain check (approvals_dir)."""
    ops.approvals_path.mkdir(mode=0o700, parents=True, exist_ok=True)
    return ops.approvals_dir()


def _approve_record_path(store: Path, request_id: str) -> Path:
    return store / APPROVE_REQUESTS_DIR / f"{request_id}.json"


def _load_approve_record(store: Path, request_id: str) -> dict[str, Any] | None:
    data = _read_bounded(_approve_record_path(store, request_id), MAX_WAVE_RECORD_BYTES)
    if data is None:
        return None
    record = _strict_loads(data, "approve_record_invalid")
    if (not isinstance(record, dict) or record.get("schema") != APPROVE_SCHEMA
            or record.get("request_id") != request_id):
        raise Refused("approve_record_invalid", request_id)
    if record.get("kind") != "wave" and len(data) > MAX_APPROVE_RECORD_BYTES:
        raise Refused("approve_record_too_large", request_id)
    return record


def _save_approve_record(store: Path, record: Mapping[str, Any]) -> None:
    data = _canonical(record)
    limit = MAX_WAVE_RECORD_BYTES if record.get("kind") == "wave" else MAX_APPROVE_RECORD_BYTES
    if len(data) > limit:
        raise Refused("approve_record_too_large", record["request_id"])
    _atomic_write(_approve_record_path(store, record["request_id"]), data)
    if record.get("grade") == DEVICE_GRADE:
        # Persist the rename before claiming evidence or publishing approvals. The
        # store sync also persists approve-requests when this is its first record.
        approve_presence._fsync_dir(store / APPROVE_REQUESTS_DIR)
        approve_presence._fsync_dir(store)


class _Superseded(Refused):
    """A compare-and-swap found the stored record in another state; the stored record stands."""


def _approve_cas(seams: SimpleNamespace, store: Path, record: Mapping[str, Any], expect: str) -> None:
    """Compare-and-swap one record transition under the ops lock (one bounded read and one
    atomic write, never network I/O): re-read the stored record and save `record` only while its
    stored state is still `expect` ("absent" for a record that must not exist yet). Otherwise the
    stored record wins (a cancel's voided beats a late reply or a sent card) and this refuses with
    its stop code, writing nothing."""
    with _exclusive_lock(seams.ops_lock, OPS_LOCK_TIMEOUT_S):
        current = _load_approve_record(store, record["request_id"])
        state = "absent" if current is None else current.get("state")
        if state != expect:
            if current is None:
                raise _Superseded("request_unknown", f"approve {record['request_id']} has no record")
            stopped = _approve_stopped(current)
            raise _Superseded(stopped.code, stopped.detail)
        _save_approve_record(store, record)


def _approve_close(store: Path, record: dict[str, Any], state: str, reason: str, detail: str,
                   seams: SimpleNamespace, *, expect: str | None) -> None:
    """Close `record`. With `expect` the close is a compare-and-swap from that state; None only
    for a caller that already holds the ops lock and re-read the record under it."""
    record.update(state=state, reason=reason, detail=str(detail)[:300], closed_at=seams.clock().isoformat())
    if expect is None:
        _save_approve_record(store, record)
    else:
        _approve_cas(seams, store, record, expect)


def _approve_stopped(record: Mapping[str, Any]) -> Refused:
    reason = record.get("reason")
    code = reason if type(reason) is str and _REASON.fullmatch(reason) else "approve_not_open"
    return Refused(code, f"approve {record.get('request_id')} is {record.get('state')}")


def _card_open(record: Mapping[str, Any], now_epoch: float) -> bool:
    card = record.get("card")
    return (isinstance(card, dict) and type(card.get("date")) is int
            and now_epoch < card["date"] + approve_presence.WAIT_S)


def _store_names(directory: Path, limit: int) -> list[str]:
    """At most `limit` entry names, sorted; an absent directory has none."""
    names: list[str] = []
    try:
        with os.scandir(directory) as iterator:
            for entry in iterator:
                names.append(entry.name)
                if len(names) >= limit:
                    break
    except FileNotFoundError:
        return []
    return sorted(names)


def _poller_offset_path(store: Path) -> Path:
    """The getUpdates cursor lives in a root-only sibling of the store (`<store>-poller`, 0700,
    the same chain check), never inside it: the approval store holds approval records only."""
    poller = store.parent / f"{store.name}{POLLER_DIR_SUFFIX}"
    poller.mkdir(mode=0o700, exist_ok=True)
    try:
        approve_presence.check_store_chain(poller)
    except approve_presence.StoreInsecure as exc:
        raise Refused("approval_store_insecure", str(exc)) from None
    return poller / TELEGRAM_OFFSET_FILE


def _telegram_offset(store: Path) -> int:
    path = _poller_offset_path(store)
    try:
        data = _read_bounded(path, MAX_OFFSET_BYTES)
        doc = None if data is None else _strict_loads(data, "offset_invalid")
    except Refused:
        return 0  # a cursor only: an old update re-read can never match the open card
    offset = doc.get("offset") if isinstance(doc, dict) else None
    return offset if type(offset) is int and offset >= 0 else 0


def _advance_offset(store: Path, offset: int) -> None:
    if offset > _telegram_offset(store):
        _atomic_write(_poller_offset_path(store), _canonical({"offset": offset}))


def _approve_items(values: list[str] | None) -> list[tuple[str, list[str]]]:
    """1..3 `engine_id=SYM[,SYM]` items, each engine once, symbol sets disjoint (a second --bind
    on one symbol would displace the first, so overlapping probes go on separate cards)."""
    if not values or len(values) > MAX_APPROVE_ITEMS:
        raise Refused("invalid_items", f"pass 1..{MAX_APPROVE_ITEMS} --item engine_id=SYM[,SYM]")
    items: list[tuple[str, list[str]]] = []
    engines: set[str] = set()
    covered: set[str] = set()
    for value in values:
        engine, sep, symbols_text = str(value).partition("=")
        if not sep:
            raise Refused("invalid_item", f"{str(value)[:80]!r}: expected engine_id=SYM[,SYM]")
        engine_id = _engine_id(engine)
        if engine_id in engines:
            raise Refused("duplicate_item", f"{engine_id} is named twice")
        symbols = _symbols(symbols_text)
        shared = covered & set(symbols)
        if shared:
            raise Refused("items_share_symbol",
                          f"{sorted(shared)} appear on two items; put overlapping probes on separate cards")
        engines.add(engine_id)
        covered.update(symbols)
        items.append((engine_id, symbols))
    return items


def _probe_sizing(value: Any) -> str:
    """A decimal contract count on the 0.01 grid, without rounding or coercing booleans."""
    if type(value) not in (str, int, Decimal) or len(str(value)) > 32:
        raise Refused("invalid_sizing", "probe sizing must be 0.01..1.00 on the 0.01 grid")
    try:
        count = Decimal(str(value))
        valid = count.is_finite() and Decimal("0.01") <= count <= 1 and count % Decimal("0.01") == 0
    except InvalidOperation:
        valid = False
    if not valid:
        raise Refused("invalid_sizing", "probe sizing must be 0.01..1.00 on the 0.01 grid")
    return format(count, ".2f")


def _wave_manifest(path: Path, *, data: bytes | None = None) -> tuple[list[dict[str, Any]], str]:
    """Strict JSON array (or {items: array}); the card binds the exact file bytes."""
    data = _read_bounded(path, MAX_WAVE_MANIFEST_BYTES) if data is None else data
    if data is None:
        raise Refused("manifest_missing", str(path))
    if len(data) > MAX_WAVE_MANIFEST_BYTES:
        raise Refused("file_too_large", f"{path} exceeds {MAX_WAVE_MANIFEST_BYTES} bytes")

    def decimal_number(token: str) -> Decimal:
        if "e" in token.lower():
            raise ValueError("wave numbers must use decimal notation, not an exponent")
        return Decimal(token)

    try:
        doc = json.loads(data.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=_no_constant,
                         parse_float=decimal_number, parse_int=Decimal)
    except (UnicodeError, ValueError, RecursionError, InvalidOperation) as exc:
        raise Refused("invalid_wave_manifest", str(exc)[:200]) from exc
    items = doc.get("items") if isinstance(doc, dict) and set(doc) == {"items"} else doc
    if not isinstance(items, list) or not 1 <= len(items) <= MAX_WAVE_ITEMS:
        raise Refused("invalid_items", f"a wave requires 1..{MAX_WAVE_ITEMS} items")
    rows = []
    engines: set[str] = set()
    for index, item in enumerate(items, 1):
        engine = item.get("engine", item.get("engine_id")) if isinstance(item, dict) else None
        try:
            if not isinstance(item, dict) or item.get("kind") not in ("probe", "assign"):
                raise Refused("invalid_item", "each wave item needs kind probe or assign")
            kind = item["kind"]
            allowed = {"kind", "engine", "engine_id", "account", "symbols"}
            allowed |= {"sizing"} if kind == "probe" else {"role"}
            if set(item) - allowed or ("engine" in item and "engine_id" in item):
                raise Refused("invalid_item", "unknown or ambiguous wave item fields")
            engine = _engine_id(engine)
            if engine in engines:
                raise Refused("duplicate_item", f"{engine} is named twice")
            account = _file_id(item.get("account", "owner" if kind == "probe" else None), "account")
            symbols = item.get("symbols")
            if symbols is not None:
                symbols = er.normalize_symbols(symbols) if isinstance(symbols, list) else _symbols(symbols)
            elif kind == "probe":
                raise Refused("invalid_symbols", "probe items require symbols")
            role = item.get("role", "legacy") if kind == "assign" else "probe"
            if kind == "assign" and role not in ASSIGN_ROLES:
                raise Refused("invalid_role", f"assign sets {ASSIGN_ROLES}")
            sizing = _probe_sizing(item.get("sizing", "0.25")) if kind == "probe" else role
            rows.append({"kind": kind, "engine_id": engine, "account": account,
                         "symbols": symbols, "role": role, "sizing": sizing})
            engines.add(engine)
        except (Refused, er.RegistryError) as exc:
            raise Refused(exc.code, f"wave item {index} ({engine}): {exc}") from None
    return rows, _sha(data)


def _wave_check(ops: Ops, rows: list[Mapping[str, Any]], registry: er.Registry) -> list[dict[str, Any]]:
    """Validate ALL items against a projected registry, without changing live state.

    The caller holds the ops lock. Projecting each assignment catches total headroom and
    identity collisions between items as well as collisions with existing assignments.
    """
    projected = er.Registry(json.loads(json.dumps(registry.doc)))
    checked = []
    for index, item in enumerate(rows, 1):
        engine_id = item["engine_id"]
        try:
            account = _assign_account(projected, item["account"])
            manifest, manifest_error = ops.manifest(engine_id)
            symbols = item["symbols"]
            if symbols is None:
                if manifest is None:
                    raise Refused("invalid_symbols", "assign needs symbols or a valid engine manifest")
                symbols = er.normalize_symbols(manifest.inputs["symbols"])
            if manifest is None and ops.catalog_engine(engine_id) is None:
                raise Refused("unknown_engine", engine_id)
            if item["kind"] == "probe":
                requested = _probe_sizing(item["sizing"])
                failures = probe_failures(ops, engine_id, account, symbols, registry=projected,
                                          manifest=manifest, manifest_error=manifest_error,
                                          approval=None, first_only=True)
                if failures:
                    raise Refused(*failures[0])
                # The probe-time rule, checked before a card slot is spent: the approved count must
                # equal the pinned policy fixed_count (unpinned trades PROBE_SIZING). Fails closed.
                pinned = getattr(_probe_policy(ops, engine_id, manifest), "fixed_count", None) or PROBE_SIZING
                try:
                    matches = Decimal(str(pinned)) == Decimal(requested)
                except InvalidOperation:
                    matches = False
                if not matches:
                    raise Refused("sizing_mismatch", f"item {index} engine {engine_id} requests sizing "
                                                     f"{requested}; the pinned policy fixed_count is {pinned}")
                # Reading the bindings is part of the existing probe-card preflight.
                view = er.read_bindings(ops.source_for(account).bindings_path)
                displaced = sorted({view.symbols[symbol] for symbol in symbols
                                    if view.symbols.get(symbol) not in (None, engine_id)})
                row = {"engine_id": engine_id, "symbols": symbols,
                       "manifest_digest": manifest_digest(manifest),
                       "displaces": ",".join(displaced) or "none", "displace": False,
                       "engine_pct": projected.effective_pct(account, engine_id)[0],
                       "account_pct": projected.effective_pct(account)[0]}
            else:
                row = _assign_check(ops, projected, account, engine_id, symbols, item["role"])
            if "manifest_digest" in item and item["manifest_digest"] != row["manifest_digest"]:
                raise Refused("manifest_changed", "engine manifest changed after the card was sent")
            er.apply_assign(projected.doc, engine_id, account, item["role"], symbols,
                            since=ops.now.isoformat(),
                            identity_digest=None if manifest is None else identity_digest(manifest),
                            manifest_digest=row["manifest_digest"])
            row.update(kind=item["kind"], account=account, role=item["role"], sizing=item["sizing"])
            checked.append(row)
        except (Refused, er.RegistryError) as exc:
            raise Refused(exc.code, f"wave item {index} ({engine_id}): {exc}") from None
    return checked


def _runner_code_sha() -> str:
    from .build import build_identity

    sha = str(build_identity().get("git_sha") or "")
    return sha if _HEX40.fullmatch(sha) else "unknown"


def _approve_displace(values: list[str] | None, items: list[tuple[str, list[str]]]) -> frozenset[str]:
    """The items `--displace ENGINE_ID` names (default none): each must be an item's engine."""
    engines = {engine_id for engine_id, _ in items}
    chosen = set()
    for value in values or ():
        engine_id = _engine_id(value)
        if engine_id not in engines:
            raise Refused("invalid_displace", f"--displace {engine_id} names no --item")
        chosen.add(engine_id)
    return frozenset(chosen)


def _approve_preflight(a: argparse.Namespace, seams: SimpleNamespace, account: str,
                       items: list[tuple[str, list[str]]],
                       displace: frozenset[str] = frozenset()) -> list[dict[str, Any]]:
    """The probe contract minus approval_valid for every item plus the cross-item probe count,
    under the ops lock for well under a second. book_flat runs only for an item in `displace`
    (C6d fix b: the printed probe command co-hosts unless the item displaces the incumbent).
    Returns what the card shows per item, `displace` included; any failure refuses before a card
    exists."""
    check = Ops(a, seams.clock())
    with _exclusive_lock(check.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
        registry = check.registry()
        engines = {engine_id for engine_id, _ in items}
        manifests = {}
        for engine_id, symbols in items:
            manifest, manifest_error = check.manifest(engine_id)
            failures = probe_failures(check, engine_id, account, symbols, registry=registry,
                                      manifest=manifest, manifest_error=manifest_error,
                                      bind=engine_id in displace, approval=None, first_only=True)
            if failures:
                code, detail = failures[0]
                raise Refused(code, f"{engine_id}: {detail}")
            manifests[engine_id] = manifest
        running = sum(1 for engine_id, row in registry.assignments.items()
                      if row["role"] == "probe" and engine_id not in engines)
        allowed = int(registry.doc["max_concurrent_probes"])
        if running + len(items) > allowed:
            raise Refused("concurrent_probes_below_max",
                          f"{running} probes run and this card adds {len(items)}; the registry allows {allowed}")
        view = er.read_bindings(check.source_for(account).bindings_path)
        rows = []
        for engine_id, symbols in items:
            displaced = sorted({view.symbols[symbol] for symbol in symbols
                                if view.symbols.get(symbol) not in (None, engine_id)})
            if engine_id in displace and not displaced:
                raise Refused("displace_nothing", f"{engine_id}: no incumbent on {symbols} to displace")
            rows.append({"engine_id": engine_id, "symbols": symbols,
                         "manifest_digest": manifest_digest(manifests[engine_id]),
                         "displaces": ",".join(displaced) or "none",
                         "engine_pct": registry.effective_pct(account, engine_id)[0],
                         "account_pct": registry.effective_pct(account)[0],
                         "displace": engine_id in displace})
    return rows


def _assign_account(registry: er.Registry, account: str) -> str:
    """The registry account key for `--account`: an account key (owner) or the lane id of exactly
    one registered account; anything else refuses unknown_account before a card exists."""
    if account in registry.accounts:
        return account
    matches = [aid for aid, record in registry.accounts.items() if record.get("lane_id") == account]
    if len(matches) != 1:
        raise Refused("unknown_account", f"{account} is neither a registered account nor one lane id")
    return matches[0]


def _assign_check(ops: Ops, registry: er.Registry, account: str, engine_id: str, symbols: list[str],
                  role: str) -> dict[str, Any]:
    """C6f: everything `assign` would refuse, checked before a card is sent and again at mint, in
    order: unknown_account, not_assigned_elsewhere, bound_elsewhere (the registry audit's
    expand_bindings over every other account's books), account_exit_only, then the registry's own
    check_assign. Returns what the card shows; the caller holds the ops lock."""
    key = _assign_account(registry, account)
    current = registry.assignments.get(engine_id)
    if current is not None and current["account_id"] != key:
        raise Refused("not_assigned_elsewhere", f"{engine_id} is assigned to {current['account_id']}; "
                                                "release it there first")
    for source in ops.sources():
        if source.account_id == key:
            continue
        active, _ = er.expand_bindings(er.read_bindings(source.bindings_path))
        bound = sorted(symbol for symbol, bound_id in active.items() if bound_id == engine_id)
        if bound:
            raise Refused("bound_elsewhere", f"{engine_id} is bound on {source.account_id} {bound}; "
                                             "unbind it there first")
    if registry.exit_only(key) is not False:
        raise Refused("account_exit_only", f"{registry.accounts[key]['domain']} is exit-only")
    manifest, _ = ops.manifest(engine_id)
    try:
        er.check_assign(registry.doc, engine_id, key, role, symbols,
                        None if manifest is None else identity_digest(manifest))
    except er.RegistryError as exc:
        raise Refused(exc.code, str(exc)) from None
    record = registry.accounts[key]
    return {"engine_id": engine_id, "symbols": symbols, "account": key, "account_label": record["label"],
            "domain": record["domain"], "role": role,
            "manifest_digest": None if manifest is None else manifest_digest(manifest),
            "engine_pct": registry.effective_pct(key, engine_id)[0], "account_pct": registry.effective_pct(key)[0]}


def _approve_assign_preflight(a: argparse.Namespace, seams: SimpleNamespace, account: str,
                              item: tuple[str, list[str]], role: str) -> dict[str, Any]:
    """_assign_check under the ops lock for well under a second; any failure refuses before a card."""
    check = Ops(a, seams.clock())
    with _exclusive_lock(check.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
        return _assign_check(check, check.registry(), account, item[0], item[1], role)


def _card_ascii(text: str) -> str:
    """Printable ASCII kept one for one (newlines too), everything else '?', so offsets hold."""
    return "".join(char if char == "\n" or " " <= char <= "~" else "?" for char in str(text))


def _render_assign_card(*, host: str, code_sha: str, account: str, row: Mapping[str, Any],
                        claim_by: datetime, closes: datetime) -> tuple[str, list[dict[str, Any]]]:
    """The assign card (ASCII, at most approve_presence.MAX_CARD_CHARS, no parse_mode) and one `code`
    entity for its nonce. Raises ValueError when the card would be longer."""
    parts: list[str] = []
    entities: list[dict[str, Any]] = []

    def add(text: str) -> None:
        parts.append(_card_ascii(text))

    add(ASSIGN_TITLE + "\n")
    add(f"host {host}, runner checkout {code_sha[:12]} (not bound to the approval)\n")
    add(f"ASSIGN engine {row['engine_id']} to account {account} ({row['account_label']}, "
        f"domain {row['domain']}), role {row['role']}\n")
    add(f"books {', '.join(row['symbols'])} ({len(row['symbols'])})\n")
    add("This assigns a real-money engine to that account and widens the identity-grade exception "
        "beyond probes.\n")
    manifest = row["manifest_digest"][:6] if row["manifest_digest"] else "none"
    add(f"manifest {manifest}, breakers engine {row['engine_pct']}% account {row['account_pct']}%, nonce ")
    entities.append({"type": "code", "offset": sum(len(part) for part in parts), "length": len(row["nonce"])})
    add(row["nonce"])
    add(f", digest {row['digest'][:12]}\n")
    add(f"claim by {claim_by:%Y-%m-%d %H:%M}Z (the approval expires then)\n")
    add(f"Reply to THIS message with the nonce to approve, or NO. Closes {closes:%H:%M}Z.")
    text = "".join(parts)
    if len(text) > approve_presence.MAX_CARD_CHARS:
        raise ValueError(f"card is {len(text)} characters; the limit is {approve_presence.MAX_CARD_CHARS}")
    return text, entities


def _approve_channel(seams: SimpleNamespace) -> tuple[Any, int]:
    """The approvals token in memory only; getMe must name that bot, and that bot must not be the
    notify bot (read from the notify secret; unreadable fails closed). Sends nothing."""
    secret_id = approve_presence.APPROVALS_SECRET_ID
    try:
        token = approve_presence.approvals_token(seams.secrets(secret_id))
    except Exception as exc:
        raise Refused("presence_channel_absent",
                      approve_presence.redact(f"{secret_id}: {type(exc).__name__}: {exc}")) from None
    bot = approve_presence.bot_id(token)
    telegram = seams.telegram if seams.telegram is not None else approve_presence.BotClient(token)
    try:
        me = telegram.get_me()
    except Exception as exc:
        raise Refused("presence_channel_absent",
                      approve_presence.redact(f"getMe: {type(exc).__name__}: {exc}", token)) from None
    if (not isinstance(me, dict) or me.get("is_bot") is not True or type(me.get("id")) is not int
            or me["id"] != bot):
        raise Refused("presence_channel_invalid", "getMe does not name the bot the approvals token belongs to")
    try:
        notify_id = approve_presence.read_secret_id(approve_presence.NOTIFY_SECRET_ID_PATH)
        notify_bot = approve_presence.notify_bot_id(seams.secrets(notify_id))
    except Exception as exc:
        raise Refused("notify_identity_unreadable",
                      approve_presence.redact(f"{type(exc).__name__}: {exc}", token)) from None
    if notify_bot == bot:
        raise Refused("approvals_channel_reuses_notify_bot",
                      "the approvals secret names the notify bot; create a dedicated approvals bot")
    return telegram, bot


def _approve_settle_others(seams: SimpleNamespace, store: Path) -> list[dict[str, Any]]:
    """Under the presence lock: a record left prompting by a crash is voided, an awaiting record
    whose window passed is expired, and one still open refuses presence_pending_other. Returns the
    records this call closed expired, so the caller can send each its CLOSED line once it holds the channel."""
    now_epoch = seams.clock().timestamp()
    expired: list[dict[str, Any]] = []
    for name in _store_names(store / APPROVE_REQUESTS_DIR, MAX_APPROVE_RECORDS):
        other = name[:-len(".json")] if name.endswith(".json") else ""
        if not _FILE_ID.fullmatch(other):
            continue
        try:
            record = _load_approve_record(store, other)
        except Refused:
            continue  # approve --list names it
        if record is None:
            continue
        try:
            if record.get("state") == "prompting":
                _approve_close(store, record, "voided", "card_outcome_unknown",
                               "found prompting with no send outcome", seams, expect="prompting")
            elif record.get("state") == "awaiting_reply":
                if _card_open(record, now_epoch):
                    raise Refused("presence_pending_other", other)
                _approve_close(store, record, "expired", "presence_window_expired",
                               "the window passed with no reply", seams, expect="awaiting_reply")
                expired.append(record)
        except _Superseded:
            continue  # a cancel closed it first; its terminal state stands
    return expired


def _approve_expiry_notice(telegram: Any, record: Mapping[str, Any]) -> None:
    """Best effort, called only by the process whose compare-and-swap closed `record` expired: ONE
    plain-text CLOSED line to the approvals chat naming the request id, the void card, its items and
    how to re-mint. It carries no nonce, digest or token, and no entities. A send failure is swallowed:
    the expired record already refuses every reply. At most one bounded sendMessage (the client's
    own timeout), never retried, no file written."""
    card = record.get("card") if isinstance(record.get("card"), dict) else {}
    items = "; ".join(f"{item.get('engine_id')}={','.join(item.get('symbols') or [])}"
                      for item in (record.get("items") or [])[:MAX_APPROVE_ITEMS] if isinstance(item, dict))
    if record.get("kind") == "wave":
        items = f"{len(record['items'])} wave items (manifest {record['manifest_sha256'][:12]})"
    text = _card_ascii(
        f"CLOSED: approve {record.get('request_id')} ({record.get('kind') or 'probe'}) expired with no reply "
        f"inside {approve_presence.REPLY_WINDOW_S} s; card {card.get('message_id')} is void, replying to it "
        f"mints nothing. Items: {items}. Nothing minted. To re-mint, rerun the same approve with a new "
        "--request-id.")[:approve_presence.MAX_CARD_CHARS]
    try:
        telegram.send(text, [])
    except Exception:
        pass  # best effort; the expired record already refuses every reply


def _approve_prompt(a: argparse.Namespace, seams: SimpleNamespace, store: Path, rid: str, account: str,
                    items: list[tuple[str, list[str]]], args_digest: str,
                    displace: frozenset[str] = frozenset(), kind: str = "probe",
                    role: str | None = None, from_request: Mapping[str, Any] | None = None,
                    wave: tuple[list[dict[str, Any]], str] | None = None) -> tuple[Any, int]:
    """Pre-flight, channel, rate limit, then the frozen record and ONE card. Returns the client and
    bot id with the record awaiting_reply; a failed or unknown send voids the record for good."""
    expired_others = _approve_settle_others(seams, store)
    if kind == "wave":
        check = Ops(a, seams.clock())
        with _exclusive_lock(check.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
            rows = _wave_check(check, wave[0], check.registry())
    elif kind == "assign":
        rows = [_approve_assign_preflight(a, seams, account, items[0], role)]
        account = rows[0].pop("account")  # the registry key a lane id resolved to
    else:
        rows = _approve_preflight(a, seams, account, items, displace)
    telegram, bot = _approve_channel(seams)
    for other in expired_others:  # the CLOSED line for each card this call expired, through its own bot
        if other.get("bot_id") == bot:
            _approve_expiry_notice(telegram, other)
    now = seams.clock().astimezone(timezone.utc)
    try:
        hour, day = approve_presence.recent_cards(store / PROMPT_LOG_FILE, now)
    except approve_presence.PresenceError as exc:
        raise Refused("presence_rate_limited", f"the prompt log is unreadable: {exc}") from None
    if hour >= approve_presence.CARDS_PER_HOUR or day >= approve_presence.CARDS_PER_DAY:
        raise Refused("presence_rate_limited",
                      f"{hour} cards in the last hour and {day} today; the limits are "
                      f"{approve_presence.CARDS_PER_HOUR} and {approve_presence.CARDS_PER_DAY}")
    moment = now.replace(microsecond=0)
    if kind == "assign":  # an assign approval is claimable for --claim-hours, then it expires
        expires, sizing = moment + timedelta(hours=a.claim_hours), role
    else:
        expires, sizing = moment + timedelta(days=probe_bar.WINDOW_DAYS, hours=a.claim_hours), PROBE_SIZING
    expires_at = expires.isoformat()
    nonces = approve_presence.new_nonces(1 if kind == "wave" else len(rows))
    for index, row in enumerate(rows):
        nonce = nonces[0] if kind == "wave" else nonces[index]
        row_kind, row_account, row_sizing = kind, account, sizing
        row_expiry = expires_at
        if kind == "wave":
            row_kind, row_account, row_sizing = row["kind"], row["account"], row["sizing"]
            if row_kind == "assign":
                row_expiry = (moment + timedelta(hours=a.claim_hours)).isoformat()
        row.update(nonce=nonce, expires_at=row_expiry, sizing=row_sizing,
                   digest=approval_digest(row_kind, row["engine_id"], row_account, row["symbols"], row_sizing, row_expiry),
                   approval_id=f"{approve_presence.ID_PREFIX}{moment:%Y%m%dT%H%M%SZ}-{row['engine_id']}-"
                               f"{nonce.lower()}",
                   outcome=None, declined_code=None, receipt=None)
    code_sha = _runner_code_sha()
    host = approve_presence.host_name()
    closes = moment + timedelta(seconds=approve_presence.REPLY_WINDOW_S)
    try:
        if kind == "wave":
            text, entities = approve_presence.render_wave_card(
                host=host, code_sha=code_sha, items=rows, manifest_sha256=wave[1], nonce=nonces[0],
                claim_by=moment + timedelta(hours=a.claim_hours), closes=closes,
                window_days=probe_bar.WINDOW_DAYS)
        elif kind == "assign":
            text, entities = _render_assign_card(host=host, code_sha=code_sha, account=account, row=rows[0],
                                                 claim_by=expires, closes=closes)
        else:
            text, entities = approve_presence.render_card(
                host=host, code_sha=code_sha, account=account, items=rows, window_days=probe_bar.WINDOW_DAYS,
                claim_by=moment + timedelta(hours=a.claim_hours), expires=expires, closes=closes)
    except ValueError as exc:
        raise Refused("wave_card_too_long" if kind == "wave" else "card_too_long", str(exc)) from None
    if from_request is not None:  # appended after the renderer returns, so the nonce offsets hold
        text += "\n" + _card_line(f"dashboard request {from_request['id'][:8]} by {from_request['requester']}: "
                                  f"{from_request['reason']}")
        if len(text) > approve_presence.MAX_CARD_CHARS:
            raise Refused("card_too_long",
                          f"card is {len(text)} characters; the limit is {approve_presence.MAX_CARD_CHARS}")
    record: dict[str, Any] = {
        "schema": APPROVE_SCHEMA, "request_id": rid, "args_digest": args_digest, "account": account,
        "claim_hours": a.claim_hours, "grade": approve_presence.GRADE, "state": "prompting",
        "reason": None, "detail": None, "created_at": moment.isoformat(), "closed_at": None,
        "host": host, "code_sha": code_sha, "bot_id": bot, "items": rows, "card": None,
        "mismatches": 0, "ignored": 0, "reply": None, "minted_ids": [], "stdout": [],
        "timing": {"card_send_ms": None, "reply_after_s": None, "mint_ms": None}}
    if kind == "assign":  # only here, so a probe record keeps the exact keys it always had
        record.update(kind="assign", role=role)
    if kind == "wave":
        record.update(kind="wave", manifest_sha256=wave[1])
    if from_request is not None:  # likewise: only a from-request record names its dashboard request
        record["from_request"] = {key: from_request[key] for key in FROM_REQUEST_RECORD_KEYS}
    _approve_cas(seams, store, record, "absent")
    _append_line(store / PROMPT_LOG_FILE, {"at": moment.isoformat(), "request_id": rid})
    _approve_cas(seams, store, record, "prompting")  # a cancel before the send: no card goes out
    started = seams.monotonic()
    try:
        sent = telegram.send(text, entities)
        message_id, date, shown = sent["message_id"], sent["date"], sent["text"]
        if type(message_id) is not int or type(date) is not int or type(shown) is not str:
            raise ValueError("sendMessage answered without message_id, date and text")
    except Exception as exc:
        detail = approve_presence.redact(f"{type(exc).__name__}: {exc}")
        _approve_close(store, record, "voided", "card_outcome_unknown", detail, seams, expect="prompting")
        raise Refused("card_outcome_unknown", f"{detail}; nothing minted, use a new --request-id") from None
    record.update(state="awaiting_reply", card={"message_id": message_id, "date": date,
                                                "text_sha256": approve_presence.text_sha256(shown)})
    record["timing"]["card_send_ms"] = int(round((seams.monotonic() - started) * 1000))
    try:
        _approve_cas(seams, store, record, "prompting")
    except _Superseded as exc:  # cancelled while the card was in flight: the card is void
        try:
            telegram.send(f"VOID: approve {rid} was cancelled; card {message_id} is void, replying to it "
                          "mints nothing", [])
        except Exception:
            pass  # best effort; the voided record already refuses every reply
        raise Refused(exc.code, f"{exc.detail}; card {message_id} was sent and is void, nothing minted") from None
    return telegram, bot


def _approve_batch(seams: SimpleNamespace, store: Path, record: dict[str, Any], batch: list[Any], bot: int,
                   nonces: list[str], telegram: Any, offset: int) -> bool:
    """Apply one getUpdates batch to the open record. Accepted evidence is saved BEFORE the offset
    moves past it; a batch with no accept moves the offset only after its counters are saved.
    True when a reply was accepted (the record is then reply_accepted)."""
    updates = sorted((update for update in batch
                      if isinstance(update, dict) and type(update.get("update_id")) is int),
                     key=lambda update: update["update_id"])
    record["ignored"] += len(batch) - len(updates)
    next_offset = offset
    mismatched = False
    for update in updates:
        update_id = update["update_id"]
        next_offset = max(next_offset, update_id + 1)
        verdict, value = approve_presence.classify_update(update, card=record["card"], bot=bot, nonces=nonces)
        if verdict == "ignore":
            record["ignored"] += 1
            continue
        if verdict == "edited":
            _approve_close(store, record, "voided", "card_edited", "the operator replied to an edited card", seams,
                           expect="awaiting_reply")
            _advance_offset(store, next_offset)
            raise Refused("card_edited", "the card was edited after it was sent; nothing minted")
        if verdict == "mismatch":
            record["mismatches"] += 1
            mismatched = True
            if record["mismatches"] >= approve_presence.MISMATCH_LIMIT:
                _approve_close(store, record, "voided", "mismatch_limit",
                               f"{record['mismatches']} replies named a token that is not a nonce", seams,
                               expect="awaiting_reply")
                _advance_offset(store, next_offset)
                raise Refused("mismatch_limit", "three replies named a token that is not a nonce of this card; "
                                                "nothing minted")
            continue
        message = update["message"]
        record["reply"] = {"update_id": update_id,
                           "message_id": message.get("message_id") if type(message.get("message_id")) is int
                           else None,
                           "from_id": message["from"]["id"], "chat_id": message["chat"]["id"],
                           "date": message["date"], "tokens": value}
        record["timing"]["reply_after_s"] = message["date"] - record["card"]["date"]
        if value == "NO":
            for item in record["items"]:
                item["outcome"] = "declined"
            _approve_close(store, record, "declined", "presence_declined", "the operator answered NO", seams,
                           expect="awaiting_reply")
            _advance_offset(store, update_id + 1)
            raise Refused("presence_declined", "the operator answered NO; nothing minted")
        for item in record["items"]:
            item["outcome"] = "approved" if item["nonce"] in value else "declined"
        record["state"] = "reply_accepted"
        _approve_cas(seams, store, record, "awaiting_reply")  # a cancel that landed first wins
        _advance_offset(store, update_id + 1)
        return True
    _approve_cas(seams, store, record, "awaiting_reply")
    _advance_offset(store, next_offset)
    if mismatched:
        try:
            telegram.send("nonce mismatch, nothing minted, reply again", [])
        except Exception:
            pass  # best effort; the record already counts the mismatch
    return False


def _approve_wait(seams: SimpleNamespace, store: Path, rid: str, telegram: Any, bot: int) -> None:
    """Poll the approvals bot until the record is reply_accepted (returns) or closed (raises).
    Holds the presence lock; the ops lock only inside each record compare-and-swap, never across a
    poll. An unreadable poll is retried, never read as
    silence; the fifth leaves the record awaiting_reply so a rerun inside the window resumes it."""
    record = _load_approve_record(store, rid)
    remaining = approve_presence.WAIT_S - (seams.clock().timestamp() - record["card"]["date"])
    deadline = seams.monotonic() + max(0.0, remaining)
    nonces = [item["nonce"] for item in record["items"]]
    failures = 0
    while True:
        if seams.monotonic() >= deadline:
            record = _load_approve_record(store, rid)
            if record.get("state") != "awaiting_reply":
                raise _approve_stopped(record)
            _approve_close(store, record, "expired", "presence_window_expired",
                           "no operator reply inside the window", seams, expect="awaiting_reply")
            _approve_expiry_notice(telegram, record)
            raise Refused("presence_window_expired",
                          f"no reply to approve {rid} inside {approve_presence.REPLY_WINDOW_S} s; nothing minted")
        offset = _telegram_offset(store)
        try:
            batch = telegram.updates(offset, approve_presence.POLL_TIMEOUT_S)
            if not isinstance(batch, list) or len(batch) > approve_presence.MAX_UPDATES:
                raise ValueError("getUpdates answered something other than a bounded list")
        except Exception as exc:
            failures += 1
            if failures >= approve_presence.RETRY_LIMIT:
                raise Refused("telegram_unreadable",
                              approve_presence.redact(f"{type(exc).__name__}: {exc}")
                              + "; rerun this --request-id inside the window to resume") from None
            approve_presence.backoff_sleep(min(approve_presence.RETRY_CAP_S, 0.5 * 2 ** failures))
            continue
        record = _load_approve_record(store, rid)
        if record.get("state") != "awaiting_reply":
            raise _approve_stopped(record)
        if _approve_batch(seams, store, record, batch, bot, nonces, telegram, offset):
            return


def _approve_publish(store: Path, record: Mapping[str, Any], item: Mapping[str, Any],
                     seams: SimpleNamespace, started: float) -> None:
    """The approval (exactly APPROVAL_KEYS, the values frozen at prompting) and its presence
    sidecar, each published exclusively; identical bytes already there count as published."""
    approval_id = item["approval_id"]
    doc = {"approval_id": approval_id, "kind": _approve_kind(record), "engine_id": item["engine_id"],
           "account": record["account"], "symbols": item["symbols"], "sizing": item["sizing"],
           "expires_at": item["expires_at"], "digest": item["digest"]}
    try:
        approve_presence.publish_exclusive(store, f"{approval_id}.json", _canonical(doc))
    except approve_presence.PublishCollision as exc:
        raise Refused("approval_id_collision", str(exc)) from None
    sidecar = {"schema": PRESENCE_SCHEMA, "approval_id": approval_id, "grade": record["grade"],
               "request_id": record["request_id"], "card": record.get("card"), "reply": record.get("reply"),
               "bot_id": record.get("bot_id"),
               "operator_user_id": (None if record["grade"] == DEVICE_GRADE
                                    else approve_presence.OPERATOR_TELEGRAM_USER_ID),
               "nonce": item["nonce"], "digest": item["digest"], "host": record["host"],
               "code_sha": record["code_sha"], "card_send_ms": record["timing"]["card_send_ms"],
               "reply_after_s": record["timing"]["reply_after_s"],
               "mint_ms": int(round((seams.monotonic() - started) * 1000))}
    if record.get("manifest_sha256") is not None:
        sidecar["manifest_sha256"] = record["manifest_sha256"]
    if record["grade"] == DEVICE_GRADE:
        sidecar.update({key: record[key] for key in DEVICE_EVIDENCE_KEYS})
    approve_presence.publish_exclusive(store, f"{approval_id}.presence.json", _canonical(sidecar),
                                       keep_existing=True)


def _approve_kind(record: Mapping[str, Any]) -> str:
    """The record's approval kind; a record written before C6f carries none and is a probe record."""
    return "assign" if record.get("kind") == "assign" else "probe"


def _approve_receipt(mint: Ops, record: Mapping[str, Any], item: Mapping[str, Any]) -> dict[str, str]:
    engine_id = item["engine_id"]
    body = {
        "schema": RECEIPT_SCHEMA, "verb": "approve", "subject": engine_id, "request_id": record["request_id"],
        "at": mint.now.isoformat(), "approval_id": item["approval_id"], "grade": record["grade"],
        "account": record["account"], "symbols": item["symbols"], "expires_at": item["expires_at"],
        "digest": item["digest"], "card_message_id": (record.get("card") or {}).get("message_id"),
        "reply_update_id": (record.get("reply") or {}).get("update_id"), "timing": dict(record["timing"])}
    if _approve_kind(record) == "assign":  # a probe receipt keeps its exact shape
        body.update(kind="assign", role=record["role"])
    if isinstance(record.get("from_request"), dict):  # likewise, only for a from-request mint
        body["from_request"] = record["from_request"]["id"]
    if record.get("manifest_sha256") is not None:
        body.update(manifest_sha256=record["manifest_sha256"], sizing=item["sizing"])
    if record["grade"] == DEVICE_GRADE:
        body.update({key: record[key] for key in DEVICE_EVIDENCE_KEYS})
    receipt = mint.write_receipt(engine_id, "approve", body)
    mint.journal("approve", engine_id, record["request_id"], "approve.minted",
                 approval=item["approval_id"], receipt=receipt["sha12"])
    return receipt


def _approve_replay(record: Mapping[str, Any]) -> int:
    for line in record.get("stdout") or ():
        print(line)
    return EXIT_OK


def _assign_request_id(engine_id: str, approval_id: str) -> str:
    """`assign-<engine>-<full approval id>`: no hash and no truncation, so it is unique exactly when the
    approval id is (timestamp, engine, nonce); derived at print time, never signed. At most 100 chars
    (7 + 32 engine + 1 + 60 approval id), all in [a-z0-9TZ-], so it passes _FILE_ID unchanged."""
    return f"assign-{engine_id}-{approval_id}"


def _wave_item_record(record: Mapping[str, Any], item: Mapping[str, Any]) -> dict[str, Any]:
    """Present each wave item to the unchanged single-item publisher and receipt writer."""
    return {**record, "kind": item["kind"], "account": item["account"], "role": item["role"]}


def _approve_wave_decline(mint: Ops, seams: SimpleNamespace, store: Path,
                          record: dict[str, Any], exc: Refused | er.RegistryError) -> None:
    """Revoke this wave's published approvals before closing it, including unsaved publishes."""
    record.update(reason=exc.code, detail=str(exc)[:300])
    # If revocation itself is interrupted, the next resume must finish it, never mint again.
    _save_approve_record(store, record)
    for item in record["items"]:
        approval_id = item["approval_id"]
        data = _read_bounded(store / f"{approval_id}.json", MAX_APPROVAL_BYTES)
        expected = _canonical({key: item[key] for key in APPROVAL_KEYS})
        if data is not None and (approval_id in record["minted_ids"] or data == expected):
            # A conflicting document at an unminted id belongs to someone else.
            _create_exclusive(store / f"{approval_id}.consumed", _canonical({
                "approval_id": approval_id, "request_id": f"revoked:{record['request_id']}",
                "consumed_at": mint.now.isoformat(), "revoked": True, "reason": exc.code}))
    _approve_close(store, record, "declined", exc.code, str(exc), seams, expect=None)


def _approve_wave_finish_locked(mint: Ops, seams: SimpleNamespace, store: Path,
                                record: dict[str, Any], started: float) -> int:
    """All validation precedes every publication while holding the same ops lock."""
    try:
        if record.get("reason") is not None:
            raise Refused(record["reason"], record["detail"])
        if any(item["outcome"] not in ("approved", "minted") for item in record["items"]):
            raise Refused("presence_declined", "the entire wave must be approved")
        _wave_check(mint, record["items"], mint.registry())
        for index, item in enumerate(record["items"], 1):
            approval = {"approval_id": item["approval_id"], "kind": item["kind"],
                        "engine_id": item["engine_id"], "account": item["account"],
                        "symbols": item["symbols"], "sizing": item["sizing"],
                        "expires_at": item["expires_at"], "digest": item["digest"]}
            expires = _utc_time(item["expires_at"])
            if expires is None or mint.now >= expires:
                raise Refused("approval_valid", f"wave item {index} ({item['engine_id']}): approval expired")
            existing = _read_bounded(store / f"{item['approval_id']}.json", MAX_APPROVAL_BYTES)
            if existing is not None and existing != _canonical(approval):
                raise Refused("approval_id_collision", f"wave item {index} ({item['engine_id']})")
    except (Refused, er.RegistryError) as exc:
        _approve_wave_decline(mint, seams, store, record, exc)
        raise Refused(exc.code, str(exc)) from None
    lines = []
    code_sha = record["code_sha"] if _HEX40.fullmatch(str(record.get("code_sha"))) else "<sha40>"
    for item in record["items"]:
        single = _wave_item_record(record, item)
        try:
            if item["approval_id"] not in record["minted_ids"]:
                _approve_publish(store, single, item, seams, started)
                record["minted_ids"].append(item["approval_id"])
                _save_approve_record(store, record)
            if item["receipt"] is None:
                item["receipt"] = _approve_receipt(mint, single, item)
            item["outcome"] = "minted"
            _save_approve_record(store, record)
        except (Refused, er.RegistryError) as exc:
            _approve_wave_decline(mint, seams, store, record, exc)
            raise Refused(exc.code, str(exc)) from None
        prefix = (f"approval {item['approval_id']} minted; next: cd {RUNNER_CHECKOUT} && {RUNNER_PYTHON} "
                  f"-m leafhft.engine_ops {item['kind']} {item['engine_id']}")
        if item["kind"] == "assign":
            lines.append(prefix + f" --account {item['account']} --symbols {','.join(item['symbols'])} "
                         f"--role {item['role']} --approval {item['approval_id']} --request-id "
                         f"{_assign_request_id(item['engine_id'], item['approval_id'])}")
        else:
            lines.append(prefix + f" --symbols {','.join(item['symbols'])} --approval {item['approval_id']} "
                         f"--bind --code-sha {code_sha} --request-id probe-{item['engine_id']}-{mint.now:%Y%m%d}")
    lines += [f"hot: engine approve applied; receipt {item['receipt']['sha12']}" for item in record["items"]]
    record["timing"]["mint_ms"] = int(round((seams.monotonic() - started) * 1000))
    record.update(state="minted", reason=None, closed_at=mint.now.isoformat(), stdout=lines)
    _save_approve_record(store, record)
    return _approve_replay(record)


MAX_WAVE_NOTICE_CHARS = 4000  # each minted-notice message stays under this; Telegram's cap is 4096


def _approve_wave_notice(telegram: Any, store: Path, rid: str) -> None:
    """Every minted wave id with its revoke command, packed into as few messages as fit under
    MAX_WAVE_NOTICE_CHARS each; no id is dropped. Called after the ops lock is released. Best
    effort: a failed read or send never changes the mint, and later chunks are still tried."""
    try:
        record = _load_approve_record(store, rid)
        items = record["items"] if isinstance(record, dict) and record.get("state") == "minted" else []
        lines = [f"minted {item['approval_id']}; revoke: approve --revoke {item['approval_id']}"
                 for item in items if item.get("outcome") == "minted"]
    except Exception:
        return  # best effort; the approvals stand and stdout carries every id
    chunks: list[list[str]] = []
    size = 0
    for line in lines:  # a line is at most 154 characters (two 60-character ids), far under the cap
        if chunks and size + 1 + len(line) < MAX_WAVE_NOTICE_CHARS:
            chunks[-1].append(line)
            size += 1 + len(line)
        else:
            chunks.append([line])
            size = len(line)
    for chunk in chunks:
        try:
            telegram.send("\n".join(chunk), [])
        except Exception:
            pass  # best effort; the approval stands either way


@contextmanager
def _approve_lease_tail(ops: Ops, subjects: Iterable[str], accounts: Iterable[str] = (),
                        *, notes: list[str] | None = None):
    """Approval paths bypass mutate; publish under their ops lock even on a partial mint."""
    subjects = tuple(subjects)
    lanes = set().union(*(ops.subject_lanes(subject) for subject in subjects))
    try:
        registry = ops.registry_store().load(complete_publication=False)
    except Exception:
        registry = None
    lane_accounts = _lane_accounts(registry)
    lanes.update(key for key in accounts if key in lane_accounts)
    try:
        yield
    finally:
        for subject in subjects:
            lanes.update(ops.subject_lanes(subject))
        ops.publish_leases(lanes)
        if notes is None:
            ops.flush_lease_notes()
        else:  # main prints these after the verb's output, also on exceptional exits
            notes.extend(ops.lease_notes)
            ops.lease_notes.clear()


def _approve_finish(a: argparse.Namespace, seams: SimpleNamespace, store: Path, rid: str,
                    telegram: Any) -> int:
    """Mint every approved item of a reply_accepted record under a FRESH clock and the ops lock
    (well under a second): each item's pre-flight re-runs, each publish is exclusive and
    idempotent per stored id, so a rerun after a crash finishes here without calling Telegram."""
    if telegram is not None:
        try:
            peek = _load_approve_record(store, rid)
        except (Refused, OSError):
            peek = None  # the locked path below reads it again and refuses exactly as before
        if isinstance(peek, dict) and peek.get("kind") == "wave" and peek.get("state") == "reply_accepted":
            # A wave mints under the ops lock with no Telegram call, then its minted notice goes out
            # after the lock is released. A minted wave never reaches here, so a replay never resends.
            code = _approve_finish(a, seams, store, rid, None)
            _approve_wave_notice(telegram, store, rid)
            return code
    started = seams.monotonic()
    mint = Ops(a, seams.clock())
    with _exclusive_lock(mint.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S), ExitStack() as tails:
        record = _load_approve_record(store, rid)
        if record is None:
            raise Refused("request_unknown", rid)
        tails.enter_context(_approve_lease_tail(
            mint, (item["engine_id"] for item in record["items"]),
            (item.get("account", record["account"]) for item in record["items"]),
            notes=getattr(seams, "lease_notes", None)))
        if record.get("state") == "minted":
            return _approve_replay(record)
        if record.get("state") != "reply_accepted":
            raise _approve_stopped(record)
        if record.get("kind") == "wave":
            return _approve_wave_finish_locked(mint, seams, store, record, started)
        registry = mint.registry()
        account = record["account"]
        kind = _approve_kind(record)
        for item in record["items"]:
            if item["outcome"] != "approved":
                continue
            if item["approval_id"] not in record["minted_ids"]:
                if kind == "assign":
                    try:
                        _assign_check(mint, registry, account, item["engine_id"], item["symbols"], record["role"])
                        failures = []
                    except Refused as exc:
                        failures = [(exc.code, exc.detail)]
                else:
                    manifest, manifest_error = mint.manifest(item["engine_id"])
                    failures = probe_failures(mint, item["engine_id"], account, item["symbols"],
                                              registry=registry, manifest=manifest,
                                              manifest_error=manifest_error, bind=item.get("displace") is True,
                                              approval=None, first_only=True)
                if failures:
                    item.update(outcome="declined", declined_code=failures[0][0])
                    _save_approve_record(store, record)
                    continue
                _approve_publish(store, record, item, seams, started)
                record["minted_ids"].append(item["approval_id"])
                _save_approve_record(store, record)
            if item["receipt"] is None:
                item["receipt"] = _approve_receipt(mint, record, item)
            item["outcome"] = "minted"
            _save_approve_record(store, record)
        minted = [item for item in record["items"] if item["outcome"] == "minted"]
        code_sha = record["code_sha"] if _HEX40.fullmatch(str(record.get("code_sha"))) else "<sha40>"
        day = f"{mint.now:%Y%m%d}"
        if kind == "assign":
            # The request id carries the full approval id, so two same-day assign approvals for one
            # engine print two ids and the second command is not refused as request_id_reused.
            lines = [f"approval {item['approval_id']} minted; next: cd {RUNNER_CHECKOUT} && {RUNNER_PYTHON} "
                     f"-m leafhft.engine_ops assign {item['engine_id']} --account {account} "
                     f"--symbols {','.join(item['symbols'])} --role {record['role']} "
                     f"--approval {item['approval_id']} --request-id "
                     f"{_assign_request_id(item['engine_id'], item['approval_id'])}"
                     for item in minted]
        else:
            lines = [f"approval {item['approval_id']} minted; next: cd {RUNNER_CHECKOUT} && {RUNNER_PYTHON} "
                     f"-m leafhft.engine_ops probe {item['engine_id']} --symbols {','.join(item['symbols'])} "
                     f"--approval {item['approval_id']} --bind{' --displace' if item.get('displace') is True else ''} "
                     f"--code-sha {code_sha} "
                     f"--request-id probe-{item['engine_id']}-{day}" for item in minted]
        lines += [f"hot: engine approve applied; receipt {item['receipt']['sha12']}" for item in minted]
        if isinstance(record.get("from_request"), dict):  # only then, so a hand approve prints what it did
            lines += [f"dashboard request {record['from_request']['id']} minted approval {item['approval_id']}"
                      for item in minted]
        record["timing"]["mint_ms"] = int(round((seams.monotonic() - started) * 1000))
        record["stdout"] = lines
        if not minted:
            code = next((item["declined_code"] for item in record["items"] if item.get("declined_code")),
                        "presence_declined")
            _approve_close(store, record, "declined", code, "no approved item passed its pre-flight at mint", seams,
                           expect=None)
            raise Refused(code, f"approve {rid}: nothing minted")
        record.update(state="minted", reason=None, closed_at=mint.now.isoformat())
        _save_approve_record(store, record)
    if telegram is not None:
        for item in minted:
            try:
                telegram.send(f"minted {item['approval_id']}; revoke: approve --revoke {item['approval_id']}", [])
            except Exception:
                pass  # best effort; the approval stands either way
    return _approve_replay(record)


def _approve_rerun(a: argparse.Namespace, seams: SimpleNamespace, store: Path, record: dict[str, Any]) -> int:
    state = record.get("state")
    if state in ("minted", "reply_accepted"):
        return _approve_finish(a, seams, store, record["request_id"], None)
    if state == "prompting":
        _approve_close(store, record, "voided", "card_outcome_unknown",
                       "a crash left the send outcome unknown; use a new --request-id", seams, expect="prompting")
    raise _approve_stopped(record)


# W2-F2: `approve --from-request FILE` mints from one EngineApprovalRequest object an admin recorded on
# the dashboard and the operator saved from the admin GET. The file only prefills arguments the operator
# could type as root: it is validated exactly as hand-typed card inputs are, then the unchanged C6c/C6f
# card, reply and mint path runs. The web gains no authority; the minted id is reported against the request.
FROM_REQUEST_KEYS = frozenset({"id", "client_request_id", "engine_id", "action", "account_id", "symbols", "role",
                               "reason", "request_expires_at", "requester", "created_at", "state", "revoked_by",
                               "revoked_at", "revocation_reason"})
FROM_REQUEST_STRINGS = ("id", "client_request_id", "engine_id", "action", "account_id", "reason",
                        "request_expires_at", "requester", "created_at", "state")
FROM_REQUEST_NULLABLE = ("role", "revoked_by", "revoked_at", "revocation_reason")
FROM_REQUEST_RECORD_KEYS = ("id", "requester", "reason", "request_expires_at", "account_id")
MAX_FROM_REQUEST_BYTES = 16 * 1024
MAX_FROM_REQUEST_ACCOUNT_CHARS = 160
MAX_FROM_REQUEST_REASON_CHARS = 200
MAX_FROM_REQUEST_REQUESTER_CHARS = 320
FROM_REQUEST_RID_PREFIX = "dash-"

_UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
_REQUEST_SYMBOL = re.compile(r"[A-Z0-9-]{1,16}")
_CARD_PRINTABLE = re.compile(r"[ -~]*")


def _card_line(text: str) -> str:
    """Every character outside 0x20..0x7E becomes '?', newlines included: one card line, never two."""
    return "".join(char if " " <= char <= "~" else "?" for char in text)


def _request_text(doc: Mapping[str, Any], key: str, minimum: int, maximum: int) -> str | None:
    """A request text that can reach the card or the record: null (nullable keys only, checked by the
    caller) or minimum..maximum characters of 0x20..0x7E with no leading or trailing space, so it can
    never carry a newline or a fake card line. Anything else refuses from_request_invalid."""
    value = doc[key]
    if value is None:
        return None
    if (not minimum <= len(value) <= maximum or not _CARD_PRINTABLE.fullmatch(value)
            or value != value.strip(" ")):
        raise Refused("from_request_invalid",
                      f"{key}: {minimum}..{maximum} characters of 0x20..0x7E, no leading or trailing space")
    return value


def _from_request_load(path: Path) -> dict[str, Any]:
    """The saved dashboard request, validated before any store, lock or card: at most 16 KiB
    (file_too_large, file_unreadable as _read_bounded says), one strict JSON object with exactly
    FROM_REQUEST_KEYS and their types (from_request_invalid), then the hand-input rules unchanged
    (invalid_role, invalid_engine_id, invalid_symbols, invalid_items). The state and the inbox expiry
    are judged only before a NEW card (_from_request_open), so a rerun of a minted id still replays."""
    data = _read_bounded(path, MAX_FROM_REQUEST_BYTES)
    if data is None:
        raise Refused("from_request_invalid", f"{path} does not exist")
    doc = _strict_loads(data, "from_request_invalid")
    if not isinstance(doc, dict) or set(doc) != FROM_REQUEST_KEYS:
        raise Refused("from_request_invalid", "one EngineApprovalRequest object with exactly its keys")
    wrong = [key for key in FROM_REQUEST_STRINGS if type(doc[key]) is not str]
    wrong += [key for key in FROM_REQUEST_NULLABLE if doc[key] is not None and type(doc[key]) is not str]
    if type(doc["symbols"]) is not list or any(type(symbol) is not str for symbol in doc["symbols"]):
        wrong.append("symbols")
    if wrong:
        raise Refused("from_request_invalid", f"wrong type: {', '.join(sorted(wrong))}")
    for key in ("id", "client_request_id"):
        if not _UUID.fullmatch(doc[key]):
            raise Refused("from_request_invalid", f"{key}: a lowercase UUID")
    engine_id = _engine_id(doc["engine_id"])
    request_kinds = ("probe", "assign")  # dashboard requests carry one item, never a wave manifest
    if doc["action"] not in request_kinds:
        raise Refused("from_request_invalid", f"action {ascii(doc['action'][:32])}: approve mints {request_kinds}")
    if not 1 <= len(doc["account_id"]) <= MAX_FROM_REQUEST_ACCOUNT_CHARS:
        raise Refused("from_request_invalid", f"account_id: 1..{MAX_FROM_REQUEST_ACCOUNT_CHARS} characters")
    reason = _request_text(doc, "reason", 1, MAX_FROM_REQUEST_REASON_CHARS)
    requester = _request_text(doc, "requester", 1, MAX_FROM_REQUEST_REQUESTER_CHARS)
    for key in ("revoked_by", "revocation_reason"):
        _request_text(doc, key, 0, MAX_FROM_REQUEST_BYTES)
    if any(not _REQUEST_SYMBOL.fullmatch(symbol) for symbol in doc["symbols"]):
        raise Refused("from_request_invalid", "symbols: each matches [A-Z0-9-]{1,16}")
    kind, role = doc["action"], doc["role"]
    if kind == "assign" and role not in ASSIGN_ROLES:
        raise Refused("invalid_role", f"an assign request sets {ASSIGN_ROLES}")
    if kind == "probe" and role is not None:
        raise Refused("invalid_role", "a probe request carries no role")
    items = _approve_items([f"{engine_id}={','.join(doc['symbols'])}"])
    return {"id": doc["id"], "kind": kind, "role": role, "items": items, "account_id": doc["account_id"],
            "requester": requester, "reason": reason, "request_expires_at": doc["request_expires_at"],
            "state": doc["state"]}


def _from_request_account(ops: Ops, book_id: str) -> str:
    """The one registry key whose book id (X1c: its identity file's account_id) equals the request's
    account_id verbatim. The ops lock is taken and released here, before the args digest, so it is
    never held while the presence lock is taken or across the reply wait. The request's string never
    becomes --account, a card line or a path; zero or several matches refuse unknown_account."""
    with _exclusive_lock(ops.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
        registry = ops.registry()
        book_ids = ops.book_account_ids(registry.accounts)
    matches = sorted(aid for aid, value in book_ids.items() if value is not None and value == book_id)
    if len(matches) != 1:
        raise Refused("unknown_account", f"{len(matches)} registered accounts carry the request's account id; "
                                         "exactly one must")
    return _file_id(matches[0], "account")


def _from_request_open(source: Mapping[str, Any], seams: SimpleNamespace) -> None:
    """Before a NEW card only: the dashboard request is still pending and its inbox expiry is after
    the fixed clock. The expiry never becomes the claim or probe window."""
    if source["state"] != "pending":
        raise Refused("request_not_pending", f"dashboard request {source['id']} is {ascii(source['state'][:32])}")
    expires = _utc_time(source["request_expires_at"])
    if expires is None or expires <= seams.clock().astimezone(timezone.utc):
        raise Refused("request_expired", f"dashboard request {source['id']} expired at "
                                         f"{ascii(source['request_expires_at'][:64])}")


def _device_directory(store: Path, name: str) -> Path:
    """Private device state under the checked approval store, never a caller-supplied ledger."""
    directory = store / name
    directory.mkdir(mode=0o700, exist_ok=True)
    try:
        approve_presence.check_store_chain(directory)
    except approve_presence.StoreInsecure as exc:
        raise Refused("approval_store_insecure", str(exc)) from None
    _guard_dirs(directory)
    return directory


def _device_input(path: str, limit: int) -> bytes:
    # O_NOFOLLOW/O_NONBLOCK plus fstat: a FIFO, symlink or mutable foreign file cannot
    # hang the root verb or change the bytes between hashing and parsing.
    data = _read_store_file(Path(path), limit)
    if data is None:
        raise Refused("file_unreadable", f"{path} does not exist")
    return data


def _device_manifest(ops: Ops, registry: er.Registry, plan: bytes, manifest: bytes,
                     rid: str) -> tuple[list[dict[str, Any]], str]:
    """Check the signed card scope against the root account mapping and exact file bytes.

    H1 checks plan identity and signatures; H4 owns the execution step grammar. Here only
    the closed placement manifests can become approvals (contract tuning-inbox-v1.md:277).
    """
    from . import tuning_presence as tp

    document = tp._parse_plan(plan).document
    # The mapping has authority only when its identity files and their parents are
    # protected. Check before the existing identity reader can open a FIFO or follow a
    # symlink. Missing identities do not participate; ambiguous matches still refuse.
    mapped_accounts = {}
    for key, account in list(registry.accounts.items())[:er.MAX_ACCOUNTS]:
        path = ops.identity_path(account)
        if path is None or _read_store_file(path, 1024) is None:
            continue
        try:
            approve_presence.check_store_chain(path.parent)
        except approve_presence.StoreInsecure as exc:
            raise Refused("approval_store_insecure", str(exc)) from None
        mapped_accounts[key] = account
    book_ids = ops.book_account_ids(mapped_accounts)
    matches = [key for key, value in book_ids.items() if value == document["account"]]
    if matches != [document["registry_account"]]:
        raise Refused("evidence_scope", "registry_account does not match the root account mapping")
    if rid not in [entry["request_id"] for entry in document["manifests"]]:
        raise Refused("evidence_scope", "card_request_id_unlisted")
    engines = document["engines"]
    if type(engines) is not list or not 1 <= len(engines) <= tp.MAX_CARDS:
        raise Refused("invalid_plan", "engines bound")
    scopes = {}
    for engine in engines:
        if (type(engine) is not dict or type(engine.get("id")) is not str
                or engine["id"] in scopes or type(engine.get("symbols")) is not list
                or type(engine.get("sizing")) is not str):
            raise Refused("invalid_plan", "engine scope")
        _engine_id(engine["id"])
        if (engine["symbols"] != er.normalize_symbols(engine["symbols"])
                or engine["sizing"] != _probe_sizing(engine["sizing"])):
            raise Refused("invalid_plan", "noncanonical engine scope")
        scopes[engine["id"]] = (engine["symbols"], engine["sizing"])
    seen: set[str] = set()
    selected = None
    for entry in document["manifests"]:
        if set(entry) != {"request_id", "bytes", "sha256"}:
            raise Refused("invalid_plan", "manifest fields")
        try:
            raw = tp.strict_b64(entry["bytes"], MAX_WAVE_MANIFEST_BYTES)
            card = tp.strict_json(raw, MAX_WAVE_MANIFEST_BYTES)
        except (ValueError, RecursionError) as exc:
            raise Refused("invalid_plan", "manifest encoding") from exc
        if _sha(raw) != entry["sha256"]:
            raise Refused("invalid_plan", "manifest digest")
        if (type(card) is not dict or set(card) != {"items"} or type(card["items"]) is not list
                or not 1 <= len(card["items"]) <= tp.MAX_CARDS):
            raise Refused("invalid_plan", "manifest items")
        for item in card["items"]:
            if (type(item) is not dict or set(item) != {"kind", "engine", "account", "symbols", "sizing"}
                    or item["kind"] != "probe" or item["account"] != document["registry_account"]
                    or type(item["engine"]) is not str or item["engine"] in seen
                    or item["engine"] not in scopes
                    or (item["symbols"], item["sizing"]) != scopes[item["engine"]]):
                raise Refused("evidence_scope", "manifest engine scope")
            seen.add(item["engine"])
        if entry["request_id"] == rid:
            if manifest != raw:
                raise Refused("evidence_scope", "manifest bytes differ from the signed card")
            selected = raw
    if seen != set(scopes) or selected is None:
        raise Refused("evidence_scope", "manifest coverage")
    return _wave_manifest(Path("signed-device-manifest"), data=selected)


def _approve_device_record(a: argparse.Namespace, rid: str, args_digest: str,
                           rows: list[dict[str, Any]], manifest_sha256: str,
                           verified: Any, now: datetime) -> dict[str, Any]:
    """Freeze the checked rows once; resumes reuse these ids, digests and expiries."""
    moment = now.astimezone(timezone.utc).replace(microsecond=0)
    nonce = approve_presence.new_nonces(1)[0]
    for row in rows:
        expires = moment + timedelta(hours=a.claim_hours)
        if row["kind"] == "probe":
            expires += timedelta(days=probe_bar.WINDOW_DAYS)
        expiry = expires.isoformat()
        row.update(nonce=nonce, expires_at=expiry,
                   digest=approval_digest(row["kind"], row["engine_id"], row["account"],
                                          row["symbols"], row["sizing"], expiry),
                   approval_id=f"{DEVICE_ID_PREFIX}{moment:%Y%m%dT%H%M%SZ}-{row['engine_id']}-{nonce.lower()}",
                   outcome="approved", declined_code=None, receipt=None)
    return {
        "schema": APPROVE_SCHEMA, "request_id": rid, "args_digest": args_digest,
        "kind": "wave", "account": "wave", "claim_hours": a.claim_hours,
        "grade": verified.grade, "state": "claiming", "reason": None, "detail": None,
        "created_at": moment.isoformat(), "closed_at": None, "host": verified.runner_host,
        "code_sha": verified.code_sha, "items": rows, "minted_ids": [], "stdout": [],
        "manifest_sha256": manifest_sha256,
        **{key: getattr(verified, key) for key in DEVICE_EVIDENCE_KEYS},
        "timing": {"card_send_ms": None, "reply_after_s": None, "mint_ms": None},
    }


def _approve_device_notice(store: Path, record: Mapping[str, Any]) -> None:
    """Durable, idempotent FYI for the executor's outbox drain; never network I/O in approve.

    A crash after the terminal mint save is repaired by the next authenticated rerun. An
    existing entry (including its delivery/backoff state) is never replaced on replay.
    """
    directory = _device_directory(store, DEVICE_OUTBOX_DIR)
    messages: list[str] = []
    for aid in record["minted_ids"]:
        line = f"minted {aid}; revoke: approve --revoke {aid}"
        if messages and len(messages[-1]) + 1 + len(line) <= MAX_WAVE_NOTICE_CHARS:
            messages[-1] += "\n" + line
        else:
            messages.append(line)
    notice = {
        "schema": "leafhft.tuning-fyi.v1", "request_id": record["request_id"],
        "proposal_id": record["proposal_id"], "plan_sha256": record["plan_sha256"],
        "grade": record["grade"], "minted_ids": record["minted_ids"],
        "created_at": record["closed_at"], "attempts": 0, "next_attempt_at_ms": 0,
        "messages": messages,
    }
    approve_presence.publish_exclusive(directory, f"{record['request_id']}.json", _canonical(notice),
                                       keep_existing=True)


def _approve_device(ops: Ops, a: argparse.Namespace, seams: SimpleNamespace) -> int:
    """Root-only device channel: verify inside the verb on EVERY attempt, even replay.

    The ops lock spans claim, journal and publication. No presence lock, card budget, Bot
    API or caller-supplied verification flag participates in this channel.
    """
    from . import tuning_presence as tp

    rid = _file_id(a.request_id, "request_id")
    if type(a.claim_hours) is not int or not 1 <= a.claim_hours <= 24:
        raise Refused("invalid_claim_hours", "--claim-hours is 1..24")
    assertion = _device_input(a.presence_decision, tp.MAX_ASSERTION_BYTES)
    plan = _device_input(a.presence_plan, tp.MAX_PLAN_BYTES)
    manifest = _device_input(a.manifest, MAX_WAVE_MANIFEST_BYTES)
    store = _approve_store(ops)
    started = seams.monotonic()
    with _exclusive_lock(seams.ops_lock, OPS_LOCK_TIMEOUT_S), ExitStack() as tails:
        mint = Ops(a, seams.clock())
        try:
            wave = _device_manifest(mint, mint.registry(), plan, manifest, rid)
            args_digest = _sha(_canonical({
                "kind": "wave", "grade": DEVICE_GRADE, "claim_hours": a.claim_hours,
                "manifest_sha256": wave[1], "plan_sha256": _sha(plan),
                "evidence_sha256": tp.parse_assertion(assertion).evidence_sha256,
            }))
            record = _load_approve_record(store, rid)
            if record is not None and (record.get("grade") != DEVICE_GRADE
                                       or record.get("args_digest") != args_digest):
                raise Refused("request_id_reused", f"{rid} was used for a different approve")
            ledger = _device_directory(store, DEVICE_LEDGER_DIR)
            if record is None:
                # Leave a slot for the serialized Telegram channel. Count every
                # entry, as the bounded settlement scan does (including temp files).
                if len(_store_names(store / APPROVE_REQUESTS_DIR, MAX_APPROVE_RECORDS)) >= MAX_APPROVE_RECORDS - 1:
                    raise Refused("approve_records_full", "device journal would exhaust the Telegram settlement scan")
                # Verify identity/signature for the frozen journal only. authorize_card
                # below remains authoritative for first-bind freshness and resume.
                verified = tp.verify_decision(
                    assertion, plan, now_ms=int(mint.now.timestamp() * 1000),
                    runner_host=approve_presence.host_name(), code_sha=_runner_code_sha(), first_bind=False)
                binding_key = tp._binding_key(verified.proposal_id, verified.plan_sha256)
                claim_name = f"claim-{tp._claim_key(binding_key, rid)}.json"
                if tp._read_record(ledger / claim_name) is not None:
                    raise Refused("evidence_scope", "card already claimed without a mint journal; refusing remint")
                rows = _wave_check(mint, wave[0], mint.registry())
                record = _approve_device_record(a, rid, args_digest, rows, wave[1], verified, mint.now)
                _save_approve_record(store, record)
            elif record.get("state") == "claiming":
                # A prior save may have stopped after rename but before directory
                # fsync. Make the same frozen journal durable before claiming again.
                _save_approve_record(store, record)
            card_auth = tp.authorize_card(
                ledger, assertion, plan, rid,
                now_ms=int(mint.now.timestamp() * 1000), runner_host=approve_presence.host_name(),
                code_sha=_runner_code_sha(), require_root=os.name == "posix")
            verified = card_auth.verified
            if any(record.get(key) != getattr(verified, key) for key in DEVICE_EVIDENCE_KEYS):
                raise Refused("evidence_scope", "mint journal and evidence claim disagree")
            if record["state"] == "claiming":
                # Either claim result is recoverable only with this durable journal.
                record["state"] = "reply_accepted"
                _save_approve_record(store, record)
            elif card_auth.first_claim:
                raise Refused("evidence_scope", "mint journal and evidence claim disagree")
        except tp.PresenceRefused as exc:
            raise Refused(exc.reason, exc.detail) from None
        if record["state"] not in ("reply_accepted", "minted"):
            raise _approve_stopped(record)
        if record["state"] == "minted":
            _approve_device_notice(store, record)
            return _approve_replay(record)
        tails.enter_context(_approve_lease_tail(
            mint, (item["engine_id"] for item in record["items"]),
            (item["account"] for item in record["items"]), notes=getattr(seams, "lease_notes", None)))
        result = _approve_wave_finish_locked(mint, seams, store, record, started)
        _approve_device_notice(store, record)
        return result


def _approve_mint(ops: Ops, a: argparse.Namespace, seams: SimpleNamespace) -> int:
    source = None
    wave = None
    if getattr(a, "from_request", None) is not None:
        source = _from_request_load(Path(a.from_request))
        kind, role, items = source["kind"], source["role"], source["items"]
    else:
        kind = getattr(a, "kind", None) or "probe"
        if kind not in APPROVE_KINDS:
            raise Refused("invalid_kind", f"--kind is one of {APPROVE_KINDS}")
        role = getattr(a, "role", None)
        if kind == "wave":
            if not getattr(a, "manifest", None):
                raise Refused("usage", "--kind wave requires --manifest FILE")
            if any(getattr(a, flag, None) is not None for flag in ("item", "account", "role", "displace")):
                raise Refused("usage", "the wave manifest carries all items, accounts, roles and sizing")
            wave = _wave_manifest(Path(a.manifest))
            items = [(row["engine_id"], row["symbols"]) for row in wave[0]]
        else:
            if getattr(a, "manifest", None) is not None:
                raise Refused("usage", "--manifest requires --kind wave")
            items = _approve_items(a.item)
    if kind == "assign":
        if len(items) != 1:
            raise Refused("invalid_items", "--kind assign takes exactly one --item ENGINE=SYM[,SYM...]")
        if getattr(a, "displace", None):
            raise Refused("usage", "--displace is a probe flag; an assign card binds nothing")
        if source is None and a.account is None:
            raise Refused("usage", "--kind assign needs --account (a registered lane id or owner)")
        role = "legacy" if role is None else role
        if role not in ASSIGN_ROLES:
            raise Refused("invalid_role", f"assign sets {ASSIGN_ROLES}")
    elif role is not None:
        raise Refused("usage", "--role is an assign flag")
    if kind == "wave":
        account = "wave"
    elif source is None:
        account = _file_id(a.account, "account")
    else:
        account = _from_request_account(ops, source["account_id"])
    if type(a.claim_hours) is not int or not 1 <= a.claim_hours <= 24:
        raise Refused("invalid_claim_hours", "--claim-hours is 1..24")
    if source is not None and a.request_id is None:
        rid = _file_id(f"{FROM_REQUEST_RID_PREFIX}{source['id']}", "request_id")
    else:
        rid = _file_id(a.request_id, "request_id")
    displace = _approve_displace(getattr(a, "displace", None), items)
    store = _approve_store(ops)
    request = {"account": account, "claim_hours": a.claim_hours,
               "items": [[engine_id, symbols] for engine_id, symbols in items]}
    if wave is not None:
        request.update(kind="wave", manifest_sha256=wave[1], items=wave[0])
    if displace:  # only when set, so a co-host approve keeps the args digest it always had
        request["displace"] = sorted(displace)
    if kind == "assign":  # likewise: a probe approve keeps its args digest byte for byte
        request.update(kind="assign", role=role)
    if source is not None:  # likewise: only a from-request approve names its dashboard request
        request["from_request"] = source["id"]
    args_digest = _sha(_canonical(request))

    def same(record: dict[str, Any]) -> dict[str, Any]:
        if record.get("args_digest") != args_digest:
            raise Refused("request_id_reused", f"{rid} was used for a different approve")
        return record

    record = _load_approve_record(store, rid)
    if record is not None and same(record).get("state") not in ("prompting", "awaiting_reply"):
        return _approve_rerun(a, seams, store, record)
    with _presence_lock(store / PRESENCE_LOCK_FILE):
        record = _load_approve_record(store, rid)
        if record is None:
            if source is not None:
                _from_request_open(source, seams)
            telegram, bot = _approve_prompt(a, seams, store, rid, account, items, args_digest, displace,
                                            kind, role, source, wave)
        else:
            same(record)
            if record.get("state") != "awaiting_reply":
                return _approve_rerun(a, seams, store, record)
            if not _card_open(record, seams.clock().timestamp()):
                _approve_close(store, record, "expired", "presence_window_expired",
                               "the window passed with no reply", seams, expect="awaiting_reply")
                try:  # best effort: the refusal below stands whatever the channel does
                    notice_client, notice_bot = _approve_channel(seams)
                except Exception:
                    notice_client, notice_bot = None, None
                if notice_client is not None and notice_bot == record.get("bot_id"):
                    _approve_expiry_notice(notice_client, record)
                raise Refused("presence_window_expired", f"approve {rid} closed with no reply; nothing minted")
            telegram, bot = _approve_channel(seams)
            if bot != record.get("bot_id"):
                raise Refused("presence_channel_invalid", "the approvals bot changed since this card was sent")
        _approve_wait(seams, store, rid, telegram, bot)
        return _approve_finish(a, seams, store, rid, telegram)


def _approve_revoke(a: argparse.Namespace, seams: SimpleNamespace) -> int:
    """Lowering needs no approval: an exclusive `<id>.consumed` marker whose request id
    `revoked:<rid>` no probe request can ever carry, so approval_problem refuses every later use."""
    approval_id = a.revoke
    if type(approval_id) is not str or not _REVOKE_ID.fullmatch(approval_id):
        raise Refused("invalid_approval", f"--revoke must match {_REVOKE_ID.pattern}")
    rid = _file_id(a.request_id, "request_id")
    reason = a.reason or "operator_revoked"
    if type(reason) is not str or not _REASON.fullmatch(reason):
        raise Refused("invalid_reason", f"--reason must match {_REASON.pattern}")
    act = Ops(a, seams.clock())
    marker_id = f"revoked:{rid}"
    with _exclusive_lock(act.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S), ExitStack() as tails:
        store = act.approvals_dir()
        if _read_bounded(store / f"{approval_id}.json", MAX_APPROVAL_BYTES) is None:
            raise Refused("approval_unknown", f"approval {approval_id} does not exist")
        try:
            approval = act.load_approval(approval_id)
            engine_id = approval["engine_id"]
            accounts = (approval["account"],)
        except Refused:
            engine_id = None
            accounts = ()
        subject = engine_id if type(engine_id) is str and ENGINE_ID_RE.fullmatch(engine_id) else REGISTRY_SUBJECT
        tails.enter_context(_approve_lease_tail(act, (subject,), accounts,
                                               notes=getattr(seams, "lease_notes", None)))
        created = False
        consumer = act.approval_consumer(approval_id)
        if consumer is None:
            created = _create_exclusive(store / f"{approval_id}.consumed", _canonical({
                "approval_id": approval_id, "request_id": marker_id, "consumed_at": act.now.isoformat(),
                "revoked": True, "reason": reason}))
            consumer = marker_id if created else act.approval_consumer(approval_id)
        if created:
            result = {"approval_id": approval_id, "revoked": True, "reason": reason}
            receipt = act.write_receipt(subject, "approve-revoke", {
                "schema": RECEIPT_SCHEMA, "verb": "approve-revoke", "subject": subject, "request_id": rid,
                "at": act.now.isoformat(), "result": result})
            act.journal("approve-revoke", subject, rid, "approve.revoked", approval=approval_id,
                        receipt=receipt["sha12"])
            return act.applied("approve-revoke", receipt, result, False)
        if consumer is not None and consumer.startswith("revoked:"):
            print(f"approval {approval_id} is already revoked ({consumer}); nothing to do")
            return EXIT_OK
    print(f"approval {approval_id} was consumed by request {consumer}; stop the probe with: "
          f"cd {RUNNER_CHECKOUT} && {RUNNER_PYTHON} -m leafhft.engine_ops halt {subject} "
          f"--reason operator_revoked --request-id halt-{subject}-{act.now:%Y%m%dT%H%M}")
    raise Refused("approval_consumed", f"approval {approval_id} was consumed by request {consumer}")


def _approve_cancel(a: argparse.Namespace, seams: SimpleNamespace) -> int:
    rid = _file_id(a.cancel, "request_id")
    act = Ops(a, seams.clock())
    with _exclusive_lock(act.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
        store = act.approvals_dir()
        record = _load_approve_record(store, rid)
        if record is None:
            raise Refused("request_unknown", f"no approve record {rid}")
        if record.get("state") in APPROVE_TERMINAL:
            if record.get("state") == "voided" and record.get("reason") == "cancelled":
                print(f"approve {rid} is already cancelled")
                return EXIT_OK
            raise Refused("request_terminal", f"approve {rid} is already {record.get('state')}")
        _approve_close(store, record, "voided", "cancelled", "cancelled by approve --cancel", seams, expect=None)
    minted = record.get("minted_ids") or []
    print(f"approve {rid} cancelled; " + (f"already minted {minted} stay until revoked" if minted
                                          else "nothing minted"))
    return EXIT_OK


def _approve_list(a: argparse.Namespace, seams: SimpleNamespace) -> int:
    """Read-only, at most 512 entries: every approval with its grade and state (flagging one with
    no presence sidecar), and every mint record that is not terminal (stuck-rid recovery)."""
    act = Ops(a, seams.clock())
    store = act.approvals_dir()
    approvals, other = [], []
    for name in _store_names(store, MAX_LIST_ENTRIES):
        if not _APPROVAL_FILE.fullmatch(name):
            if name in STORE_STATE_NAMES or (name.startswith(".") and name.endswith(".tmp")):
                other.append(name)  # mint state, or a publish temp a crash left behind
            elif not (_FILE_ID.fullmatch(name[:-len(".presence.json")]) and name.endswith(".presence.json")
                      or _FILE_ID.fullmatch(name[:-len(".consumed")]) and name.endswith(".consumed")):
                raise Refused("store_corrupt", f"{store / name} is not an approval, sidecar, marker or "
                                               "store state file")
            continue
        approval_id = name[:-len(".json")]
        row: dict[str, Any] = {
            "approval_id": approval_id,
            "grade": (DEVICE_GRADE if approval_id.startswith(DEVICE_ID_PREFIX) else
                      approve_presence.GRADE if approval_id.startswith(approve_presence.ID_PREFIX) else "unsigned"),
            "presence": (store / f"{approval_id}.presence.json").exists(), "engine_id": None, "account": None,
            "symbols": [], "expires_at": None}
        try:
            doc = act.load_approval(approval_id)
            row.update(engine_id=doc["engine_id"], account=doc["account"], symbols=doc["symbols"],
                       expires_at=doc["expires_at"])
            consumer = act.approval_consumer(approval_id)
            expires = _utc_time(doc["expires_at"])
            if consumer is not None and consumer.startswith("revoked:"):
                state = "revoked"
            elif consumer is not None:
                state = f"consumed by {consumer}"
            elif expires is None or act.now >= expires:
                state = "expired"
            else:
                state = "unclaimed"
        except Refused:
            state = "unreadable"
        row["state"] = state
        approvals.append(row)
    requests = []
    for name in _store_names(store / APPROVE_REQUESTS_DIR, MAX_APPROVE_RECORDS):
        rid = name[:-len(".json")] if name.endswith(".json") else ""
        if not _FILE_ID.fullmatch(rid):
            continue
        try:
            record = _load_approve_record(store, rid)
        except Refused:
            requests.append({"request_id": rid, "state": "unreadable", "age_s": None})
            continue
        if record is None or record.get("state") in APPROVE_TERMINAL:
            continue
        created = _utc_time(record.get("created_at"))
        requests.append({"request_id": rid, "state": record.get("state"),
                         "age_s": None if created is None else int((act.now - created).total_seconds())})
    lines = [f"approval {row['approval_id']} grade {row['grade']} engine {row['engine_id']} account {row['account']} "
             f"symbols {','.join(row['symbols'])} expires {row['expires_at']} state {row['state']}"
             + ("" if row["presence"] else " NO_PRESENCE_EVIDENCE") for row in approvals]
    lines += [f"request {row['request_id']} {row['state']} age {row['age_s']}s" for row in requests]
    act.emit({"approvals": approvals, "pending_requests": requests, "store_state": other},
             "\n".join(lines) or "no approvals")
    return EXIT_OK


def cmd_approve(ops: Ops, a: argparse.Namespace) -> int:
    """Mint identity-grade `tg1-` probe approvals (or, with --kind assign, one assign approval) from
    one operator Telegram reply, or revoke, cancel or list them. Refuses not_root on POSIX; the
    reply wait never holds the ops lock."""
    from_request = getattr(a, "from_request", None)
    device = (getattr(a, "presence_decision", None) is not None
              or getattr(a, "presence_plan", None) is not None)
    modes = [name for name, chosen in (("list", a.list), ("revoke", a.revoke is not None),
                                       ("cancel", a.cancel is not None),
                                       ("mint", bool(a.item) or from_request is not None
                                        or getattr(a, "manifest", None) is not None)) if chosen]
    if len(modes) != 1:
        raise Refused("usage", "pass exactly one of --item or --from-request (mint), --revoke, --cancel or --list")
    if device and (modes[0] != "mint" or from_request is not None or getattr(a, "kind", None) != "wave"
                   or not getattr(a, "manifest", None) or not getattr(a, "presence_decision", None)
                   or not getattr(a, "presence_plan", None)
                   or any(getattr(a, flag, None) is not None for flag in ("item", "account", "role", "displace"))):
        raise Refused("usage", "device approval requires --kind wave, --manifest, --request-id, "
                              "--presence-decision and --presence-plan, without item overrides")
    if from_request is not None:  # the document is the whole intent: no argument may override it
        given = [flag for flag, value in (("--item", a.item), ("--account", a.account),
                                          ("--kind", getattr(a, "kind", None)), ("--role", getattr(a, "role", None)),
                                          ("--displace", getattr(a, "displace", None)),
                                          ("--manifest", getattr(a, "manifest", None))) if value is not None]
        if given:
            raise Refused("usage", f"--from-request carries the whole request; drop {', '.join(given)}")
    if not approve_presence.is_root():
        raise Refused("not_root", "approve runs as root: the approval store is root-only")
    seams = _approve_seams(ops, a)
    seams.lease_notes = ops.lease_notes
    try:
        if modes[0] == "list":
            return _approve_list(a, seams)
        if modes[0] == "revoke":
            return _approve_revoke(a, seams)
        if modes[0] == "cancel":
            return _approve_cancel(a, seams)
        if device:
            return _approve_device(ops, a, seams)
        return _approve_mint(ops, a, seams)
    except _PASS_THROUGH:
        raise
    except Exception as exc:  # internal, and redacted: a Bot API error can carry the token
        print(f"internal: {type(exc).__name__}: {approve_presence.redact(exc)}", file=sys.stderr)
        return EXIT_INTERNAL


# ---------------------------------------------------------------- status (plan D9)

def next_step(status: Mapping[str, Any]) -> tuple[str | None, str | None]:
    """The one next-step function (plan D9). Pure; every sentence is engine_reasons' own text.

    A healthy entry state (entries open, nothing stopping them) returns (None, None): the reason
    table carries no sentence for "running", and this function never invents one."""
    lifecycle = status.get("lifecycle") or {}
    state = lifecycle.get("state")
    codes = [reason.get("code") for reason in lifecycle.get("stop_reasons") or ()
             if isinstance(reason, dict)]

    def say(code: str) -> tuple[str, str]:
        return code, engine_reasons.text(code)

    if state == "unreadable":
        return say("data_integrity_failure")
    if state == "retired":
        return say("lifecycle_retired")
    integrity = next((code for code in INTEGRITY_CODES if code in codes), None)
    if state == "halted":
        return say(integrity or "lifecycle_halted")
    if state in ENTRY_STATES:
        if integrity is not None:
            return say(integrity)
        if status.get("assignment") is None:
            return say("registry_gate")
        if "day_start_unknown" in codes:
            return say("day_start_unknown")
        if lifecycle.get("entries_suspended_until") is not None:
            for code in ("breaker_engine", "breaker_account"):
                if code in codes:
                    return say(code)
            return say("lifecycle_suspended")
        if not lifecycle.get("entries_enabled"):
            return say("lifecycle")
        return None, None
    if status.get("manifest_digest") is None:
        return say("manifest_invalid")
    inputs = status.get("inputs")
    if isinstance(inputs, list) and engine_feeds.feeds_live_provisioned({"inputs": {"feeds": inputs}}):
        return say("feeds_not_live")
    return say("lifecycle_not_entry_state")


def _verdict(ops: Ops, engine_id: str) -> dict[str, Any]:
    """Fails closed on a corrupt or oversized verdict.json: every field null, unreadable true, never raises."""
    empty = {"state": None, "read_kind": None, "next_read_at": None, "population": None, "unreadable": False}
    try:
        data = _read_bounded(ops.evidence_dir / engine_id / "verdict.json", MAX_REPORT_BYTES)
        report = None if data is None else _strict_loads(data, "verdict_invalid")
    except Refused:
        return {**empty, "unreadable": True}
    if report is None:
        return empty
    verdict = probe_bar.read_verdict(report)
    read_kind = report.get("read_kind") if isinstance(report, dict) else None
    return {"state": verdict.state,
            "read_kind": read_kind if type(read_kind) is str and len(read_kind) <= 32 else None,
            "next_read_at": verdict.next_read_at, "population": dict(verdict.population),
            "unreadable": False}


def _int_or_none(value: Any) -> int | None:
    return value if type(value) is int else None


def engine_status(ops: Ops, engine_id: str, registry: er.Registry | None = None,
                  economics_report=None) -> dict[str, Any]:
    """The D9 status object for one engine: every key present, null (never zero) for unknown."""
    from .engine_economics import engine_snapshot

    engine_id = _engine_id(engine_id)
    manifest, _ = ops.manifest(engine_id)
    kernel = None if manifest is None else manifest.kernel
    catalog_engine = ops.catalog_engine(kernel["policy_engine_id"] if kernel is not None
                                        and kernel["kind"] == "policy" else engine_id)
    assignment = None if registry is None else registry.assignments.get(engine_id)
    account = None if assignment is None else registry.accounts.get(assignment["account_id"])
    try:
        record = ops.canary().optional(engine_id)
        state = "absent" if record is None else record["state"]
        entries_enabled = record is not None and ops.canary().entries_enabled(engine_id, ops.now)
    except CanaryError:
        record, state, entries_enabled = None, "unreadable", False
    if record is None and state == "absent":
        legacy = ops.legacy_lifecycle(engine_id)
        if legacy is not None:
            # Reported, never written: the book reads only the lifecycle dir, so entries stay closed.
            record, state = legacy, legacy["state"]
            ops.warnings.append(f"lifecycle_dir_legacy: {engine_id} has a record in {ops.legacy_lifecycle_dir} "
                                f"and none in {ops.lifecycle_dir}; the book cannot see it")

    per_account: dict[str, bool] = {}
    if account is not None:
        try:
            for key, entry in _override_entries(ops.overrides_path(account), engine_id):
                if type(entry.get("enabled")) is bool:
                    per_account[key] = entry["enabled"]
        except Refused:
            per_account = {}

    recorded = (record or {}).get("breaker") or {}
    engine_pct = inherited = account_pct = None
    if assignment is not None:
        engine_pct, inherited = registry.effective_pct(assignment["account_id"], engine_id)
        account_pct = registry.effective_pct(assignment["account_id"])[0]

    conform = ops.conform_record(engine_id)
    conform_receipt = None
    if conform is not None and manifest is not None and conform.get("manifest_digest") == manifest_digest(manifest):
        conform_receipt = conform.get("receipt_sha12") if type(conform.get("receipt_sha12")) is str else None

    requests = [row for row in ops.requests() if row.get("subject") == engine_id]
    trial_id = None
    for row in sorted(requests, key=lambda row: str(row.get("requested_at"))):
        if row.get("verb") == "probe" and type(row.get("context", {}).get("trial_id")) is str \
                and row.get("state") in ("completed", "started"):
            trial_id = row["context"]["trial_id"]

    name = engine_id
    if catalog_engine is not None:
        name = catalog_engine.name
    elif manifest is not None:
        name = str(manifest.thesis["summary"])[:64]
    version = manifest.identity["version"] if manifest is not None else (
        catalog_engine.version if catalog_engine is not None else None)

    status: dict[str, Any] = {
        "engine_id": engine_id,
        "name": name,
        "version": version,
        "manifest_digest": None if manifest is None else manifest_digest(manifest),
        "kernel": {"kind": None if kernel is None else kernel["kind"],
                   "kernel_id": None if kernel is None else kernel["kernel_id"]},
        "inputs": [] if manifest is None else list(manifest.inputs["feeds"]),
        "markets": list(assignment["symbols"]) if assignment is not None else (
            [] if manifest is None else sorted(manifest.inputs["symbols"])),
        "owner": {"kind": "tenant" if account is not None and account["kind"] == "tenant" else "operator",
                  "lane_id": None if account is None else account["lane_id"]},
        "assignment": None if assignment is None else {
            "account_id": assignment["account_id"], "domain": assignment["domain"],
            "role": assignment["role"], "since": assignment["since"]},
        "enabled": {"global": None if catalog_engine is None else catalog_engine.enabled,
                    "per_account": per_account},
        "lifecycle": {
            "state": state,
            "entries_enabled": bool(entries_enabled),
            "entries_suspended_until": _int_or_none((record or {}).get("entries_suspended_until")),
            "stop_reasons": [{"code": code, "text": engine_reasons.text(code)} for code in _stop_codes(record)],
            "probe_started_at": (record or {}).get("probe_started_at"),
            "expires_at": (record or {}).get("expires_at"),
            "breaker": {
                "engine_pct": engine_pct, "inherited": inherited, "account_pct": account_pct,
                "engine_loss_cents": _int_or_none(recorded.get("engine_loss_cents")),
                "engine_limit_cents": _int_or_none(recorded.get("engine_limit_cents")),
                "account_loss_cents": _int_or_none(recorded.get("account_loss_cents")),
                "account_limit_cents": _int_or_none(recorded.get("account_limit_cents")),
                "day_start_marked_cents": _int_or_none(recorded.get("day_start_marked_cents"))}},
        "evidence": {"conform_receipt": conform_receipt, "trial_id": trial_id,
                     "verdict": _verdict(ops, engine_id)},
        "economics": engine_snapshot(economics_report,
                                     None if assignment is None else assignment["account_id"], engine_id),
        "pending_requests": [{"kind": row.get("verb"), "state": row.get("state"),
                              "requested_at": row.get("requested_at")}
                             for row in requests if row.get("state") in ("started", "unreadable")],
    }
    code, text = next_step(status)
    status["next_step"] = {"code": code, "text": text}
    return status


def _status_engine_ids(ops: Ops, registry: er.Registry | None) -> list[str]:
    ids: set[str] = set()
    try:
        paths = sorted(ops.manifests_dir.glob("*.json"))[:MAX_MANIFEST_FILES]
    except OSError:
        paths = []
    ids.update(path.stem for path in paths if ENGINE_ID_RE.fullmatch(path.stem))
    ids.update(engine.engine_id for engine in ops.catalog().list())
    if registry is not None:
        ids.update(registry.assignments)
    try:
        ids.update(record["engine_id"] for record in ops.canary().list())
    except CanaryError:
        pass
    legacy = ops.legacy_lifecycle_dir
    if legacy is not None:
        try:
            names = sorted(legacy.glob("*.json"))[:MAX_STATUS_ENGINES]
        except OSError:
            names = []
        ids.update(path.stem for path in names if ENGINE_ID_RE.fullmatch(path.stem))
    return sorted(ids)[:MAX_STATUS_ENGINES]


def cmd_status(ops: Ops, a: argparse.Namespace) -> int:
    registry = ops.registry_optional()
    if a.candidates:
        if registry is None:
            raise Refused("registry_absent", "run registry init --apply first")
        rows = []
        for engine_id in ([_engine_id(a.engine_id)] if a.engine_id else _status_engine_ids(ops, registry)):
            manifest, manifest_error = ops.manifest(engine_id)
            symbols = sorted(manifest.inputs["symbols"]) if manifest is not None else []
            failures = probe_failures(ops, engine_id, a.account, symbols, registry=registry,
                                      manifest=manifest, manifest_error=manifest_error)
            rows.append({"engine_id": engine_id, "eligible": not failures,
                         "refusals": [code for code, _ in failures]})
        ops.emit({"candidates": rows}, "\n".join(
            f"{row['engine_id']}: {'eligible' if row['eligible'] else ', '.join(row['refusals'])}"
            for row in rows) or "no engines")
        return EXIT_OK
    from .engine_economics import dumps_status, read_report

    economics_report = read_report(getattr(a, "economics_report", None))
    if a.engine_id:
        status = engine_status(ops, a.engine_id, registry, economics_report)
        if ops.json:
            print(dumps_status(status))
        else:
            ops.emit(status, _status_line(status))
    else:
        statuses = [engine_status(ops, engine_id, registry, economics_report)
                    for engine_id in _status_engine_ids(ops, registry)]
        if ops.json:
            print(dumps_status(statuses))
        else:
            ops.emit(statuses, "\n".join(_status_line(status) for status in statuses) or "no engines")
    for warning in ops.warnings:  # stderr, so the D9 status object keeps its shape
        print(f"warning: {warning}", file=sys.stderr)
    return EXIT_OK


def _status_line(status: Mapping[str, Any]) -> str:
    assignment = status["assignment"]
    where = "unassigned" if assignment is None else f"{assignment['role']} on {assignment['account_id']}"
    step = status["next_step"]["text"] or "entries open"
    return f"{status['engine_id']}: {status['lifecycle']['state']}, {where}; {step}"


# ---------------------------------------------------------------- try (plan D9 step 3)

def _replay_modules() -> SimpleNamespace:
    """The replay's dependencies, imported only when `try` runs."""
    from .feeds.base import IndexTick, Lifecycle
    from .lanes.base import DecisionFrame
    from .lanes.kalshi_edge_entry import KalshiEdgeEntry, LaneRefused
    from .strategy.kalshi_edge import KalshiEdge, KalshiIntent
    from .types import PRICE_UNIT, SIZE_UNIT, Quote

    return SimpleNamespace(IndexTick=IndexTick, Lifecycle=Lifecycle, DecisionFrame=DecisionFrame,
                           KalshiEdgeEntry=KalshiEdgeEntry, LaneRefused=LaneRefused,
                           KalshiEdge=KalshiEdge, KalshiIntent=KalshiIntent, PRICE_UNIT=PRICE_UNIT,
                           SIZE_UNIT=SIZE_UNIT, Quote=Quote)


def _corpus_int(row: Mapping[str, Any], key: str) -> int:
    value = row.get(key)
    if type(value) is not int:
        raise Refused("corpus_invalid", f"{row.get('kind')} row needs an integer {key}")
    return value


def _load_corpus(directory: Path) -> list[tuple[str, bytes, list[dict[str, Any]]]]:
    """Sorted *.jsonl streams, each a header row then lifecycle, index and quote rows; bounded."""
    try:
        files = sorted(path for path in directory.glob("*.jsonl") if path.is_file())
    except OSError as exc:
        raise Refused("corpus_unreadable", str(exc)) from exc
    if not files:
        raise Refused("corpus_empty", f"{directory} holds no .jsonl streams")
    if len(files) > MAX_CORPUS_FILES:
        raise Refused("corpus_too_large", f"more than {MAX_CORPUS_FILES} streams")
    streams, total = [], 0
    for path in files:
        data = _read_bounded(path, MAX_CORPUS_BYTES)
        if data is None:
            raise Refused("corpus_unreadable", f"{path.name} vanished while reading")
        total += len(data)
        if total > MAX_CORPUS_BYTES:
            raise Refused("corpus_too_large", f"more than {MAX_CORPUS_BYTES} bytes")
        rows = [_strict_loads(line, "corpus_invalid") for line in data.splitlines() if line.strip()]
        if not rows or len(rows) > MAX_CORPUS_ROWS:
            raise Refused("corpus_invalid", f"{path.name}: 1..{MAX_CORPUS_ROWS} rows")
        header = rows[0]
        if (not isinstance(header, dict) or header.get("kind") != "header"
                or header.get("family") not in ("15m", "1h") or type(header.get("balance_cents")) is not int):
            raise Refused("corpus_invalid", f"{path.name}: the first row is the header")
        for row in rows[1:]:
            if not isinstance(row, dict) or row.get("kind") not in ("lifecycle", "index", "quote"):
                raise Refused("corpus_invalid", f"{path.name}: unknown row kind")
            _corpus_int(row, "at_ms")
            if row["kind"] == "lifecycle":
                _corpus_int(row, "close_ms")
                _corpus_int(row, "strike_i")
            elif row["kind"] == "index":
                _corpus_int(row, "value_i")
            else:
                for key in ("bid_cents", "ask_cents", "depth"):
                    _corpus_int(row, key)
            if row["kind"] != "index" and type(row.get("ticker")) is not str:
                raise Refused("corpus_invalid", f"{path.name}: {row['kind']} row needs a ticker")
        streams.append((path.name, data, rows))
    return streams


def _decode(m: SimpleNamespace, row: Mapping[str, Any]):
    now_ms = row["at_ms"]
    if row["kind"] == "lifecycle":
        return m.Lifecycle(row["ticker"], "active", row["close_ms"], row["close_ms"], row["strike_i"])
    if row["kind"] == "index":
        return m.IndexTick("BRTI", row["value_i"], now_ms, now_ms, now_ms * 1_000_000)
    return m.Quote(venue="kalshi", symbol=row["ticker"],
                   bid_i=row["bid_cents"] * m.PRICE_UNIT // 100, ask_i=row["ask_cents"] * m.PRICE_UNIT // 100,
                   bid_size_i=row["depth"] * m.SIZE_UNIT, ask_size_i=row["depth"] * m.SIZE_UNIT,
                   ts_exch_ns=now_ms * 1_000_000, ts_recv_ns=now_ms * 1_000_000, seq=1)


def _replay(m: SimpleNamespace, engines_dir: Path, policy_engine_id: str, policy,
            rows: list[dict[str, Any]]) -> dict[str, Any]:
    """KalshiEdgeEntry beside the incumbent KalshiEdge on one stream: every proposal must equal
    the incumbent's intent one for one (the C2 parity rule). Records evaluate() latency."""
    header, events = rows[0], rows[1:]
    context = SimpleNamespace(engines_dir=engines_dir, family=header["family"],
                              balance_cents=header["balance_cents"])
    adapter = m.KalshiEdgeEntry({"policy_engine_id": policy_engine_id,
                                 "policy_digest": policy_digest(policy)})
    try:
        adapter.initialize(context)
    except m.LaneRefused as exc:
        code = str(exc).split(":", 1)[0].strip() or "lane_refused"
        raise Refused(code, str(exc)) from exc
    legacy = m.KalshiEdge({}, family=header["family"])
    legacy.engine_id = policy_engine_id
    legacy.apply_policy(policy)
    legacy.set_balance(header["balance_cents"])
    proposals, samples, mismatch = [], [], None
    for index, row in enumerate(events):
        now_ns = row["at_ms"] * 1_000_000
        event = _decode(m, row)
        intents = [intent for intent in legacy.on_event(event, row["at_ms"]) if isinstance(intent, m.KalshiIntent)]
        adapter.on_event(event, now_ns)
        batch_all = []
        for _ in range(MAX_EVALUATE_LOOPS):
            if not adapter.pending:
                break
            frame = m.DecisionFrame(
                opportunity_id="engine-ops-try", now_ns=now_ns, cutoff_ns=now_ns,
                close_ms=row["at_ms"] + 60000, ticker=adapter.pending[0][1].ticker, symbol="BTC",
                strike_i=100 * m.PRICE_UNIT, side_candidates=(True, False), quote=None, index=None,
                history=(), positions=(), reserved_cents=0, sequence=0, gap=False)
            started = time.perf_counter_ns()
            batch = adapter.evaluate(frame)
            samples.append(time.perf_counter_ns() - started)
            batch_all.extend(batch)
        got = [(p.ticker, p.side_yes, int(p.limit_price_cents), str(p.count), p.meta["cluster"])
               for p in batch_all]
        want = [(i.ticker, i.side_yes, int(i.price_cents), str(Decimal(i.count)), i.cluster_id)
                for i in intents]
        if got != want and mismatch is None:
            mismatch = f"row {index + 1}: {len(got)} proposals against {len(want)} incumbent intents"
        proposals.extend(got)
    return {"proposals": proposals, "samples_ns": samples, "mismatch": mismatch}


def _settle(rows: list[dict[str, Any]], proposals: list[tuple]) -> tuple[Decimal, int]:
    """Descriptive replay P&L before fees: YES pays 100 when the last index at or before close is
    above the strike. Offline description only, never a verdict."""
    markets = {row["ticker"]: (row["strike_i"], row["close_ms"]) for row in rows[1:]
               if row["kind"] == "lifecycle"}
    index = sorted((row["at_ms"], row["value_i"]) for row in rows[1:] if row["kind"] == "index")
    total, settled = Decimal(0), 0
    for ticker, side_yes, price, count, _cluster in proposals:
        market = markets.get(ticker)
        if market is None:
            continue
        strike, close_ms = market
        last = None
        for at_ms, value in index:
            if at_ms > close_ms:
                break
            last = value
        if last is None:
            continue
        won = (last > strike) == side_yes
        total += Decimal((100 - price) if won else -price) * Decimal(count)
        settled += 1
    return total, settled


def _p99_us(samples: list[int]) -> float | None:
    if not samples:
        return None
    ordered = sorted(samples)
    return round(ordered[max(0, math.ceil(0.99 * len(ordered)) - 1)] / 1000, 1)


def cmd_try(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = _engine_id(a.engine_id)
    path = ops.manifest_path(engine_id)
    if not path.exists():
        raise Refused("manifest_invalid", f"{path} does not exist; run manifest import-legacy or init")
    try:
        manifest = load_manifest(path)
    except ManifestInvalid as exc:
        raise Refused("manifest_invalid", f"{exc.code}: {engine_reasons.text(exc.reason)} {exc.detail}".strip()) from exc
    kernel = manifest.kernel
    if kernel["kind"] != "policy":
        raise Refused("try_kernel_unsupported", "try v1 replays the policy kernel; lane kernels conform elsewhere")
    engine = ops.catalog_engine(kernel["policy_engine_id"])
    if engine is None:
        raise Refused("kernel_pin_missing", f"catalog engine {kernel['policy_engine_id']} is missing")
    if policy_digest(engine.policy) != kernel["policy_digest"]:
        raise Refused("kernel_pin_mismatch", "the catalog policy digest differs from the manifest pin")
    corpus = Path(a.corpus) if a.corpus else DEFAULT_CORPUS
    streams = _load_corpus(corpus)
    corpus_sha = _sha(b"".join(name.encode() + b"\0" + _sha(data).encode() + b"\n" for name, data, _ in streams))
    m = _replay_modules()
    proposals, samples, pnl, settled = [], [], Decimal(0), 0
    for name, _data, rows in streams:
        replay = _replay(m, ops.engines_dir, kernel["policy_engine_id"], engine.policy, rows)
        if replay["mismatch"] is not None:
            raise Refused("parity_mismatch", f"{name} {replay['mismatch']}")
        proposals.extend(replay["proposals"])
        samples.extend(replay["samples_ns"])
        stream_pnl, stream_settled = _settle(rows, replay["proposals"])
        pnl += stream_pnl
        settled += stream_settled

    parent_id = manifest.identity["parent"]
    overlap = None
    if parent_id is not None:
        parent = ops.catalog_engine(parent_id)
        if parent is not None:
            theirs = []
            for _name, _data, rows in streams:
                theirs.extend(_replay(m, ops.engines_dir, parent_id, parent.policy, rows)["proposals"])
            shared = sum((Counter(proposals) & Counter(theirs)).values())
            union = len(proposals) + len(theirs) - shared
            overlap = {"parent": parent_id, "shared": shared, "parent_proposals": len(theirs),
                       "jaccard": None if union == 0 else round(shared / union, 4)}
        else:
            overlap = {"parent": parent_id, "shared": None, "parent_proposals": None, "jaccard": None}

    p99 = _p99_us(samples)
    card = {"engine_id": engine_id, "version": manifest.identity["version"],
            "manifest_digest": manifest_digest(manifest), "kernel_pin": kernel["policy_digest"],
            "corpus": str(corpus), "corpus_sha256": corpus_sha, "streams": len(streams),
            "proposals": len(proposals), "parity": "one for one with the incumbent",
            "overlap": overlap, "replay_pnl_cents": str(pnl), "replay_settled": settled,
            "replay_pnl_label": "offline, not a verdict", "evaluate_p99_us": p99,
            "novelty": "not checked", "probe_ready": True}
    with _exclusive_lock(ops.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
        receipt = ops.write_receipt(engine_id, "try", {"schema": RECEIPT_SCHEMA, "verb": "try",
                                                       "subject": engine_id, "at": ops.now.isoformat(),
                                                       "result": card})
        _atomic_write(ops.evidence_dir / engine_id / "conform.json", _canonical({
            "schema": CONFORM_SCHEMA, "engine_id": engine_id, "manifest_digest": card["manifest_digest"],
            "kernel_pin": card["kernel_pin"], "corpus_sha256": corpus_sha, "at": ops.now.isoformat(),
            "receipt_sha12": receipt["sha12"], "receipt_sha256": receipt["sha256"],
            "receipt_path": receipt["path"]}))
    card["receipt"] = receipt["sha12"]
    if overlap is None:
        overlap_line = "Overlap with the parent: no parent"
    elif overlap["shared"] is None:
        overlap_line = f"Overlap with the parent {parent_id}: parent not in the catalog"
    else:
        overlap_line = (f"Overlap with the parent {parent_id}: {overlap['shared']} of {len(proposals)} proposals "
                        f"shared (parent made {overlap['parent_proposals']})")
    lines = [
        f"Engine {engine_id} v{manifest.identity['version']} ({kernel['kernel_id']}), manifest {card['manifest_digest'][:12]}",
        f"Kernel pin: policy {kernel['policy_digest'][:12]} matches the catalog engine",
        f"Parity: {len(proposals)} proposals on {len(streams)} corpus streams match the incumbent one for one",
        f"Proposals on the corpus: {len(proposals)}",
        overlap_line,
        f"Replay P&L (offline, not a verdict): {pnl}c before fees over {settled} settled proposals",
        f"Evaluate p99: {'not measured' if p99 is None else f'{p99} us'}",
        "Novelty: not checked",
        f"Receipt: {receipt['sha12']}",
        "Probe-ready: yes",
    ]
    ops.emit(card, "\n".join(lines))
    return EXIT_OK


def cmd_conform(ops: Ops, a: argparse.Namespace) -> int:
    """C11-opsconform: engine_conform.conform over --corpus for any kernel kind (policy or lane), the
    novelty peers resolved from the registry and the manifests dir, the full receipt written under
    <evidence-dir>/<engine_id>/receipts and the conform record the probe gate reads
    (manifest_conformed_or_waived) written only after the manifest is re-read unchanged under the
    engine_ops lock. The replay (two subprocesses, each bounded by engine_conform.CHILD_TIMEOUT_S)
    runs outside the lock. Any ConformRefused is a named refusal (exit 2) and writes nothing."""
    from . import engine_conform  # lazy: only this verb pays the conformance import

    engine_id = _engine_id(a.engine_id)
    path = ops.manifest_path(engine_id)
    if not path.exists():
        raise Refused("manifest_invalid", f"{path} does not exist; run manifest import-legacy or init")
    try:
        manifest = load_manifest(path)
    except ManifestInvalid as exc:
        raise Refused("manifest_invalid", f"{exc.code}: {engine_reasons.text(exc.reason)} {exc.detail}".strip()) from exc
    registry = ops.registry()
    assignments = {eid: tuple(row["symbols"]) for eid, row in registry.assignments.items()}
    corpus = Path(a.corpus)
    try:
        parent, required = engine_conform.novelty_inputs(manifest, assignments)
        peers = [] if parent is None else [("parent", str(ops.manifest_path(parent)))]
        peers += [("assigned", str(ops.manifest_path(eid))) for eid in required if eid != parent]
        receipt_body = engine_conform.conform(path, corpus, engines_dir=ops.engines_dir,
                                              assignments=assignments, peers=peers)
    except engine_conform.ConformRefused as exc:
        where = f" at {exc.frame_id}" if exc.frame_id else ""
        raise Refused(exc.code, f"{exc.detail}{where}") from exc
    with _exclusive_lock(ops.registry_dir / OPS_LOCK_FILE, OPS_LOCK_TIMEOUT_S):
        try:
            current = manifest_digest(load_manifest(path))
        except (ManifestInvalid, OSError) as exc:
            raise Refused("conform_stale", f"the manifest became unreadable during conformance: {exc}") from exc
        if current != receipt_body["manifest_digest"]:
            raise Refused("conform_stale", "the manifest changed during conformance; rerun conform")
        receipt = ops.write_receipt(engine_id, "conform", {"schema": RECEIPT_SCHEMA, "verb": "conform",
                                                           "subject": engine_id, "at": ops.now.isoformat(),
                                                           "result": receipt_body})
        novelty = receipt_body["novelty"]
        record = {"schema": CONFORM_SCHEMA, "source": "conform", "engine_id": engine_id,
                  "manifest_digest": receipt_body["manifest_digest"], "kernel_pin": receipt_body["kernel_pin"],
                  "code_sha": receipt_body["code_sha"], "corpus_sha256": receipt_body["corpus_sha256"],
                  "binding_sha256": receipt_body["binding_sha256"], "novelty": novelty["verdict"],
                  "at": ops.now.isoformat(), "receipt_sha12": receipt["sha12"],
                  "receipt_sha256": receipt["sha256"], "receipt_path": receipt["path"]}
        _atomic_write(ops.evidence_dir / engine_id / "conform.json", _canonical(record))
    kernel = receipt_body["kernel"]
    card = {"engine_id": engine_id, "version": receipt_body["version"], "kernel_kind": kernel["kind"],
            "kernel_id": kernel["kernel_id"], "manifest_digest": receipt_body["manifest_digest"],
            "kernel_pin": receipt_body["kernel_pin"], "code_sha": receipt_body["code_sha"],
            "corpus": str(corpus), "corpus_sha256": receipt_body["corpus_sha256"],
            "binding_sha256": receipt_body["binding_sha256"], "proposals": novelty["proposals"],
            "novelty": novelty["verdict"], "near_clone": list(novelty["near_clone"]),
            "compared": [row["engine_id"] for row in novelty["compared"]],
            "evaluate_p99_us": receipt_body["bounds"]["evaluate_p99_us"], "label": receipt_body["label"],
            "receipt": receipt["sha12"], "probe_ready": True}
    near = f" (near clone of {', '.join(card['near_clone'])})" if card["near_clone"] else ""
    p99 = card["evaluate_p99_us"]
    lines = [
        f"Engine {engine_id} v{card['version']} ({kernel['kind']} kernel {kernel['kernel_id']}), "
        f"manifest {card['manifest_digest'][:12]}",
        f"Kernel pin {card['kernel_pin'][:12]}, code {card['code_sha'][:12]}, corpus {card['corpus_sha256'][:12]}",
        "Determinism: byte-equal across two hash seeds",
        f"Proposals on the corpus: {card['proposals']}",
        f"Novelty: {card['novelty']}{near}",
        f"Evaluate p99: {'not measured' if p99 is None else f'{p99} us'}",
        f"Receipt: {receipt['sha12']}",
        "Probe-ready: yes",
    ]
    ops.emit(card, "\n".join(lines))
    return EXIT_OK


# ---------------------------------------------------------------- the command line

def _global_flags(parser: argparse.ArgumentParser, *, suppress: bool) -> None:
    def default(value: Any) -> Any:
        return argparse.SUPPRESS if suppress else value

    parser.add_argument("--engines-dir", default=default(DEFAULT_ENGINES_DIR))
    parser.add_argument("--bindings", default=default(DEFAULT_BINDINGS),
                        help="the accounts file: each account's domain, member and bindings file")
    parser.add_argument("--probe-bindings", default=default(os.environ.get(PROBE_BINDINGS_ENV)
                                                            or DEFAULT_PROBE_BINDINGS),
                        help="the probe bindings file: probe --bind co-hosts through it (C7a schema, the hosts "
                             f"list {PROBE_HOSTS_NAME} beside it) and the judge reads every hosting book from it "
                             f"(default ${PROBE_BINDINGS_ENV}, else {DEFAULT_PROBE_BINDINGS})")
    parser.add_argument("--registry-dir", default=default(DEFAULT_REGISTRY_DIR))
    parser.add_argument("--approvals-dir", default=default(None),
                        help=f"the root-only approval store (default {DEFAULT_APPROVALS_DIR} with the default "
                             "--registry-dir, else <registry-dir>/approvals)")
    parser.add_argument("--manifests-dir", default=default(DEFAULT_MANIFESTS_DIR))
    parser.add_argument("--evidence-dir", default=default(os.environ.get(probe_bar.EVIDENCE_ROOT_ENV)
                                                          or DEFAULT_EVIDENCE_DIR),
                        help=f"receipts, verdicts and the probe executors' <engine_id>/staging (default "
                             f"${probe_bar.EVIDENCE_ROOT_ENV}, else {DEFAULT_EVIDENCE_DIR})")
    parser.add_argument("--oq-dir", default=default(None),
                        help=f"the judge's root-owned OQ evidence set (default {DEFAULT_OQ_DIR} with the default "
                             "--evidence-dir, else engine-oq beside it)")
    parser.add_argument("--venue-dir", default=default(None),
                        help=f"the root-run venue snapshot's evidence set (default {DEFAULT_VENUE_DIR} with the "
                             "default --evidence-dir, else engine-venue beside it)")
    parser.add_argument("--refusal-journal", default=default(os.environ.get(REFUSAL_JOURNAL_ENV) or None),
                        help=f"the account-risk ledger's refusal journal the judge cross-checks the probe "
                             f"counters against (default ${REFUSAL_JOURNAL_ENV}; the judge requires it: "
                             f"unset is {EVIDENCE_UNAVAILABLE})")
    parser.add_argument("--book-unit-template", default=default(os.environ.get(BOOK_UNIT_TEMPLATE_ENV) or None),
                        help=f"the systemd unit of a hosting book, {{book}} standing for its lowercased symbol, "
                             f"whose journal verifies the counting window (default ${BOOK_UNIT_TEMPLATE_ENV}; "
                             f"the judge requires it: unset is {EVIDENCE_UNAVAILABLE})")
    parser.add_argument("--trials-dir", default=default(TRIALS_DIR))
    parser.add_argument("--lanes-root", default=default(DEFAULT_LANES_ROOT),
                        help="the tenant lanes' writable state; engine_ops never opens, stats or lists it")
    parser.add_argument("--lane-identity-root", default=default(None),
                        help=f"root-owned <root>/<lane>/{LANE_IDENTITY_NAME} (default {DEFAULT_LANE_IDENTITY_ROOT}; "
                             "never derived from --lanes-root: a non-default --lanes-root needs this and "
                             "--projection-root named, else roots_ambiguous)")
    parser.add_argument("--projection-root", default=default(None),
                        help=f"root-owned <root>/<lane>/{lifecycle_lease.LEASE_NAME} and probe bindings the "
                             f"lease tail publishes (default {DEFAULT_PROJECTION_ROOT}; never derived from "
                             "--lanes-root)")
    parser.add_argument("--lifecycle-dir", default=default(None),
                        help=f"the lifecycle store the books read (default ${LIFECYCLE_DIR_ENV}, else "
                             f"{DEFAULT_LIFECYCLE_DIR}); status alone also reads <engines-dir>/"
                             f"{LEGACY_LIFECYCLE_NAME}")
    parser.add_argument("--owner-overrides", default=default(DEFAULT_OWNER_OVERRIDES),
                        help="the owner account's engine overrides file")
    parser.add_argument("--owner-runs", default=default(DEFAULT_OWNER_RUNS),
                        help="the owner account's book runs root (book_flat)")
    parser.add_argument("--owner-identity", default=default(DEFAULT_OWNER_IDENTITY),
                        help="the owner books' dashboard identity file (their book_account_id); a lane's is "
                             f"<lane-identity-root>/<lane>/{LANE_IDENTITY_NAME}")
    parser.add_argument("--json", action="store_true", default=default(False))


def cmd_watch(ops: Ops, a: argparse.Namespace) -> int:
    """B10: request local replay observation under the existing Ops transaction."""
    engine_id = _engine_id(a.engine_id)
    baseline_dir = str(Path(a.baseline_dir).resolve())
    normalized = {"book_id": a.book, "enabled": a.on, "account": a.account,
                  "baseline_dir": baseline_dir}

    def perform(record):
        book = replay_watch.books().get(a.book)
        if book is None:
            raise Refused("book_unknown")
        manifest, problem = ops.manifest(engine_id)
        if problem:
            raise Refused(problem)
        if manifest.kernel["kernel_id"] not in replay_watch.SIGNAL_KERNELS:
            raise Refused("kernel_not_signal")
        account_key = None
        if a.account is not None:
            registry = ops.registry()
            account_key = _assign_account(registry, a.account)
            account = registry.accounts[account_key]
            if (account["kind"] != "owner"
                    and engine_id not in er.projection_for(registry, account["domain"])["assignments"]):
                raise Refused("watch_not_owned")
        context = record["context"].get("b10_watch")
        watches = None
        already_applied = False
        if context is not None:
            try:
                watches, _ = replay_watch.read_watches(ops.registry_dir)
            except replay_watch.ReplayRefused as exc:
                raise Refused(exc.code) from None
            already_applied = context["intended"] in watches["rows"]
        if a.on and not already_applied:
            problem = replay_watch.baseline_problem(baseline_dir, a.book)
            if problem:
                raise Refused(problem)
        if book.symbol not in manifest.inputs["symbols"]:
            raise Refused("watch_symbol_mismatch")
        try:
            if watches is None:
                watches, _ = replay_watch.read_watches(ops.registry_dir)
            current = next((row for row in watches["rows"]
                            if (row["engine_id"], row["book_id"]) == (engine_id, a.book)), None)
            if context is None:
                intended = {"request_id": record["request_id"], "engine_id": engine_id,
                            "book_id": a.book, "enabled": a.on, "account_id": account_key,
                            "requested_at": ops.now.isoformat()}
                context = {"predecessor": current, "intended": intended}
                record["context"]["b10_watch"] = context
                # This durable preparation also keeps mutate from resetting the context
                # if a process fails after replacement but before the next request write.
                ops.done(record, "watch_prepared")
            intended = context["intended"]
            if current != intended:
                if current != context["predecessor"]:
                    raise _supersede(ops, record, engine_id, "resume_superseded", "watch", current)
                rows = [row for row in watches["rows"]
                        if (row["engine_id"], row["book_id"]) != (engine_id, a.book)]
                rows.append(intended)
                rows.sort(key=lambda row: (row["engine_id"], row["book_id"]))
                replay_watch.write_watches(ops.registry_dir, {"schema": replay_watch.WATCH_SCHEMA,
                                                            "rows": rows})
            if "watch" not in record["steps"]:
                ops.done(record, "watch")
        except replay_watch.ReplayRefused as exc:
            raise Refused(exc.code) from None
        return {"engine_id": engine_id, "book_id": a.book, "enabled": a.on,
                "request_id": record["request_id"], "state": "requested", "source": "replay"}

    receipt, result, replayed = ops.mutate("watch", engine_id, a.request_id, normalized, perform)
    return ops.applied("watch", receipt, result, replayed)


def cmd_watch_status(ops: Ops, a: argparse.Namespace) -> int:
    engine_id = None if a.engine_id is None else _engine_id(a.engine_id)
    if a.book is not None and a.book not in replay_watch.books():
        raise Refused("book_unknown")
    try:
        result = replay_watch.watch_status(ops.registry_dir, a.state_dir, engine_id, a.book)
    except replay_watch.ReplayRefused as exc:
        raise Refused(exc.code) from None
    ops.emit(result)
    return EXIT_OK


def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    _global_flags(common, suppress=True)
    parser = argparse.ArgumentParser(prog="python -m leafhft.engine_ops",
                                     description="Engine registry, probe, breaker and status (plan D7, D9).")
    _global_flags(parser, suppress=False)
    verbs = parser.add_subparsers(dest="verb")

    deploy = verbs.add_parser("deploy", help="root-only document deployments")
    deployment_verbs = deploy.add_subparsers(dest="deploy_verb", required=True)
    deployment_init = deployment_verbs.add_parser("init")
    deployment_init.add_argument("--account", required=True)
    deployment_apply = deployment_verbs.add_parser("apply", help="root-private signed input; trusted runner identity")
    deployment_apply.add_argument("input_directory")
    deployment_verbs.add_parser("recover")
    deployment_inspect = deployment_verbs.add_parser("inspect")
    deployment_inspect.add_argument("--json", action="store_true")
    deployment_settle = deployment_verbs.add_parser("settle")
    deployment_settle.add_argument("tx_id")
    settlement = deployment_settle.add_mutually_exclusive_group(required=True)
    settlement.add_argument("--finalize", action="store_true")
    settlement.add_argument("--abandon", action="store_true")
    deployment_settle.add_argument("--reason", required=True)
    deployment_settle.add_argument("--confirmed-ancestor", action="store_true")

    def verb(parent, name: str, handler, help_text: str):
        sub = parent.add_parser(name, parents=[common], help=help_text)
        sub.set_defaults(handler=handler)
        return sub

    registry = verbs.add_parser("registry", help="registry init, show, audit, project") \
        .add_subparsers(dest="registry_verb")
    init = verb(registry, "init", cmd_registry_init, "build generation 1 from every account's bindings")
    init.add_argument("--dry-run", action="store_true")
    init.add_argument("--apply", action="store_true")
    init.add_argument("--authority", action="append", help="member=domain, repeatable")
    init.add_argument("--enforcement", action="append",
                      help=f"member=mode, mode one of {'|'.join(exposure_authority.ENFORCEMENTS)}; repeatable")
    init.add_argument("--conformance-receipt", action="append", default=[],
                      help="a fresh X5 conformance receipt for an exit-only domain, repeatable")
    init.add_argument("--roles-dir", default=os.fspath(exposure_authority.ROLES_DIR),
                      help=f"where the role files land before the registry replace (default "
                           f"{exposure_authority.ROLES_DIR}); always checked root-owned 0755")
    init.add_argument("--roles-owner-unchecked", action="store_true",
                      help=f"skip the roles directory owner check (tests, dev); refused for any directory "
                           f"resolving under {ROOT_STATE_ROOT}, recorded in the receipt args")
    init.add_argument("--provisioned-lane", action="append", default=[],
                      help="a verified provisioned lane id, repeatable (default: every account-lane domain's lane "
                           "in the accounts file); a lane the accounts file does not name refuses unknown_lane")
    init.add_argument("--identities", action="store_true", help="stamp identity digests from manifests")
    init.add_argument("--request-id")
    verb(registry, "show", cmd_registry_show, "print the current generation")
    verb(registry, "audit", cmd_registry_audit, "every violation class; exit 2 when any is found")
    verb(registry, "project", cmd_registry_project,
         f"rewrite {er.PROJECTION_FILE} (what the books read) from the current registry; recovery only")

    domain = verbs.add_parser("domain", help="pause, resume or show an execution domain") \
        .add_subparsers(dest="domain_verb")
    domain_pause = verb(domain, "pause", cmd_domain, "stop domain entries; exits continue (no approval)")
    domain_resume = verb(domain, "resume", cmd_domain, "clear only the domain pause (device presence)")
    domain_show = verb(domain, "show", cmd_domain, "print the pause record or absent as JSON")
    for sub in (domain_pause, domain_resume, domain_show):
        sub.add_argument("--domain", required=True)
    for sub in (domain_pause, domain_resume):
        sub.add_argument("--member-key", required=True)
        sub.add_argument("--request-id", required=True)
        sub.add_argument("--requested-by", required=True)
    domain_pause.add_argument("--reason", required=True)
    domain_resume.add_argument("--expect-generation", type=int, required=True)
    domain_resume.add_argument("--presence-assertion-file", required=True)
    domain_resume.add_argument("--presence-plan-file", required=True)

    exposure = verbs.add_parser("exposure", help="exposure transfer, quarantine, register (X1b)") \
        .add_subparsers(dest="exposure_verb")
    transfer = verb(exposure, "transfer", cmd_exposure_transfer,
                    "prepare an authority transfer; X4's step advances it (approval)")
    transfer.add_argument("--member", required=True)
    transfer.add_argument("--to", required=True, help="the target domain, one of the member's")
    transfer.add_argument("--approval", required=True, help="an exposure_transfer approval id")
    transfer.add_argument("--deadline-h", help=f"hours until the step times the transfer out, "
                                               f"{TRANSFER_DEADLINE_H[0]}..{TRANSFER_DEADLINE_H[1]} "
                                               f"(default {TRANSFER_DEFAULT_DEADLINE_H})")
    quarantine = verb(exposure, "quarantine", cmd_exposure_quarantine,
                      "authority null, every domain of the member exit_only (no approval)")
    quarantine.add_argument("--member", required=True)
    quarantine.add_argument("--reason", help=f"at most {MAX_QUARANTINE_REASON} printable characters")
    register = verb(exposure, "register", cmd_exposure_register,
                    "add one account: exit_only under --member, or a new member with --attest")
    register.add_argument("--domain", required=True)
    register.add_argument("--account", required=True)
    register.add_argument("--kind", choices=er.ACCOUNT_KINDS, required=True)
    register.add_argument("--label", required=True)
    register.add_argument("--lane-id", help="defaults to the account-lane domain's lane; none for legacy-owner")
    register.add_argument("--member")
    register.add_argument("--new-member")
    register.add_argument("--attest", help="the exposure_register approval id a new member needs")
    for sub in (transfer, quarantine, register):
        sub.add_argument("--request-id", required=True)
        sub.add_argument("--roles-dir", help="the role directory (default: the one the active projection "
                                             "recorded; none before any projection)")
        sub.add_argument("--roles-owner-unchecked", action="store_true",
                         help=f"skip the roles directory owner check (tests, dev); refused for any "
                              f"directory resolving under {ROOT_STATE_ROOT}")

    manifest = verbs.add_parser("manifest", help="manifest import-legacy, init, freeze, show, validate") \
        .add_subparsers(dest="manifest_verb")
    legacy = verb(manifest, "import-legacy", cmd_manifest_import_legacy, "wrap catalog engines with a waiver")
    legacy.add_argument("engine_id", nargs="?")
    legacy.add_argument("--all", action="store_true")
    legacy.add_argument("--waiver", required=True)
    legacy.add_argument("--symbols")
    minit = verb(manifest, "init", cmd_manifest_init, "a testable variant in one command")
    minit.add_argument("engine_id")
    minit.add_argument("--template", choices=("variant",), default="variant")
    minit.add_argument("--parent", required=True)
    minit.add_argument("--set", action="append")
    minit.add_argument("--summary", required=True)
    minit.add_argument("--novelty", required=True)
    minit.add_argument("--kill")
    minit.add_argument("--symbols")
    for name, handler in (("freeze", cmd_manifest_freeze), ("show", cmd_manifest_show),
                          ("validate", cmd_manifest_validate)):
        verb(manifest, name, handler, f"manifest {name}").add_argument("engine_id")

    assign = verb(verbs, "assign", cmd_assign, "assign an engine to one account (approval)")
    assign.add_argument("engine_id")
    assign.add_argument("--account", required=True)
    assign.add_argument("--symbols", required=True)
    assign.add_argument("--role", default="legacy")
    assign.add_argument("--approval", required=True)
    assign.add_argument("--request-id", required=True)

    release = verb(verbs, "release", cmd_release, "release an assignment (no approval)")
    release.add_argument("engine_id")
    release.add_argument("--restore-bindings", action="store_true")
    release.add_argument("--request-id", required=True)

    probe = verb(verbs, "probe", cmd_probe, "start a one-contract live probe (approval)")
    probe.add_argument("engine_id")
    probe.add_argument("--symbols", required=True)
    probe.add_argument("--approval", required=True)
    probe.add_argument("--request-id", required=True)
    probe.add_argument("--bind", action="store_true",
                       help="co-host beside the incumbent through --probe-bindings; the main bindings "
                            "file is never written")
    probe.add_argument("--displace", action="store_true",
                       help="rewrite the main bindings file to displace the incumbent; the approval card "
                            "must have shown displaces: <engine>; book_flat applies only here")
    probe.add_argument("--window-days", type=int, default=probe_bar.WINDOW_DAYS)
    probe.add_argument("--oq-only", action="store_true")
    probe.add_argument("--code-sha")

    repair = verb(verbs, "repair", cmd_repair,
                  "report an interrupted probe or release; --finish or --rollback settles it (C6e)")
    repair.add_argument("request_id")
    settle = repair.add_mutually_exclusive_group()
    settle.add_argument("--finish", action="store_true",
                        help="record a fully written probe, or run a release's remaining steps")
    settle.add_argument("--rollback", action="store_true",
                        help="undo a probe, restoring only the entries it wrote (never a release)")

    staging = verb(verbs, "repair-staging", cmd_repair_staging, "provision owner probe staging directories")
    staging_mode = staging.add_mutually_exclusive_group()
    staging_mode.add_argument("--apply", action="store_true")
    staging_mode.add_argument("--dry-run", action="store_true")
    staging.add_argument("--request-id")

    activate = verb(verbs, "probe-activate", cmd_probe_activate, "activate the probe's trial")
    activate.add_argument("engine_id")
    activate.add_argument("--activation", required=True)
    activate.add_argument("--request-id", required=True)

    halt = verb(verbs, "halt", cmd_halt, "halt new entries (no approval)")
    halt.add_argument("engine_id")
    halt.add_argument("--reason", required=True)
    halt.add_argument("--request-id", required=True)

    size = verb(verbs, "probe-size", cmd_probe_size, "move a probe one rung up the 1-2-5 ladder (approval)")
    size.add_argument("engine_id")
    size.add_argument("--contracts", type=int, required=True, help="the next rung: 2, then 5")
    size.add_argument("--approval", required=True)
    size.add_argument("--request-id", required=True)

    graduate = verb(verbs, "graduate", cmd_graduate, "graduate a GRADUATE_ELIGIBLE probe (approval)")
    graduate.add_argument("engine_id")
    graduate.add_argument("--approval", required=True)
    graduate.add_argument("--request-id", required=True)

    retire = verb(verbs, "retire", cmd_retire, "retire an engine for good (terminal, no approval)")
    retire.add_argument("engine_id")
    # The C12 phone control never forwards a reason (engine_controls accepts and drops one), so its argv parses with
    # the operator default; an explicit --reason must still match _REASON.
    retire.add_argument("--reason", default=RETIRE_DEFAULT_REASON)
    retire.add_argument("--restore-bindings", action="store_true")
    retire.add_argument("--request-id", required=True)

    judge = verb(verbs, "judge", cmd_judge, "read every probe's verdict; exit 2 on a failed read or a KILL")
    judge.add_argument("engine_id", nargs="?")
    judge.add_argument("--all", action="store_true")
    judge.add_argument("--write", action="store_true",
                       help="activate trials, write verdicts/<utc>.json and verdict.json")
    judge.add_argument("--authority", dest="authority_path", help=f"the owner book's authority state (default {DEFAULT_AUTHORITY})")

    breaker = verbs.add_parser("breaker", help="breaker show, set").add_subparsers(dest="breaker_verb")
    verb(breaker, "show", cmd_breaker_show, "the D5a loss breakers")
    bset = verb(breaker, "set", cmd_breaker_set, "set an account or engine breaker percentage")
    bset.add_argument("--scope", choices=er.BREAKER_SCOPES, required=True)
    bset.add_argument("--id", required=True)
    bset.add_argument("--pct", type=int, required=True)
    bset.add_argument("--approval")
    bset.add_argument("--request-id", required=True)

    approve = verb(verbs, "approve", cmd_approve,
                   "identity-grade tg1- probe approvals from one Telegram reply (interim until RT5)")
    approve.add_argument("--account")
    approve.add_argument("--item", action="append", help="engine_id=SYM[,SYM]; 1..3 per card")
    approve.add_argument("--manifest", metavar="FILE", help="--kind wave: JSON manifest of 1..64 probe/assign items")
    approve.add_argument("--presence-decision", metavar="FILE", help="signed se-p256 tuning decision")
    approve.add_argument("--presence-plan", metavar="FILE", help="exact frozen tuning plan bytes")
    approve.add_argument("--displace", action="append", metavar="ENGINE_ID",
                         help="this item displaces the incumbent (book_flat applies); default: co-host")
    approve.add_argument("--request-id")
    approve.add_argument("--claim-hours", type=int, default=2)
    approve.add_argument("--revoke", metavar="APPROVAL_ID", help="revoke an unused approval (no approval)")
    approve.add_argument("--cancel", metavar="REQUEST_ID", help="void a mint record that is not terminal")
    approve.add_argument("--reason", help="the revoke reason (default operator_revoked)")
    approve.add_argument("--list", action="store_true", help="every approval and every open mint record")
    approve.add_argument("--kind", choices=APPROVE_KINDS, default=None,
                         help="assign: one --item, --account and --role; one assign approval per card "
                              "(default probe)")
    approve.add_argument("--role", help=f"the assign role (default legacy; {ASSIGN_ROLES})")
    approve.add_argument("--from-request", metavar="FILE",
                         help="mint from one saved dashboard approval request (no --item, --account, --kind, "
                              "--role or --displace; --request-id defaults to dash-<id>)")

    status = verb(verbs, "status", cmd_status, "the D9 status object")
    status.add_argument("engine_id", nargs="?")
    status.add_argument("--candidates", action="store_true")
    status.add_argument("--account")
    status.add_argument("--economics-report", default=None,
                        help="dated leafhft.economics.v1 JSON report (read-only; no freshness guarantee)")

    trial = verb(verbs, "try", cmd_try, "validate, pin, replay; exit 0 = probe-ready")
    trial.add_argument("engine_id")
    trial.add_argument("--corpus")

    conform = verb(verbs, "conform", cmd_conform,
                   "engine_conform over a corpus for any kernel; writes the conform record probe checks")
    conform.add_argument("engine_id")
    conform.add_argument("--corpus", required=True, help="a tape file or a directory of *.jsonl tapes")

    watch = verb(verbs, "watch", cmd_watch, "request replay-only book observation")
    watch.add_argument("engine_id")
    watch.add_argument("--book", required=True)
    toggle = watch.add_mutually_exclusive_group(required=True)
    toggle.add_argument("--on", action="store_true")
    toggle.add_argument("--off", action="store_true")
    watch.add_argument("--request-id", required=True)
    watch.add_argument("--account")
    watch.add_argument("--baseline-dir", default=replay_watch.DEFAULT_BASELINE)

    watch_status = verb(verbs, "watch-status", cmd_watch_status, "read local replay Watch acknowledgements")
    watch_status.add_argument("engine_id", nargs="?")
    watch_status.add_argument("--book")
    watch_status.add_argument("--state-dir", default=replay_watch.DEFAULT_STATE)
    return parser


def main(argv: list[str] | None = None, *, now: datetime | None = None, telegram: Any = None,
         secrets: Callable[[str], str] | None = None, clock: Callable[[], datetime] | None = None,
         monotonic: Callable[[], float] | None = None) -> int:
    """`telegram`, `secrets`, `clock` and `monotonic` are the approve verb's test seams; absent,
    it uses approve_presence.BotClient, the aws-cli fetcher and the system clocks."""
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return EXIT_OK if exc.code in (0, None) else EXIT_REFUSED
    if args.verb == "deploy":
        from .deployments import run_command
        return run_command(args)
    args.presence_seams = SimpleNamespace(telegram=telegram, secrets=secrets, clock=clock,
                                          monotonic=monotonic, now=now)
    handler = getattr(args, "handler", None)
    if handler is None:
        parser.print_usage(sys.stderr)
        return EXIT_REFUSED
    try:
        ops = Ops(args, now)
    except Refused as exc:
        print(f"refused: {exc.code}: {exc.detail}", file=sys.stderr)
        return EXIT_REFUSED
    try:
        return handler(ops, args)
    except Refused as exc:
        return ops.refuse(exc.code, exc.detail)
    except er.RegistryError as exc:
        return ops.refuse(exc.code, str(exc))
    except ManifestInvalid as exc:
        return ops.refuse("manifest_invalid", str(exc))
    except CanaryError as exc:
        return ops.refuse(getattr(exc, "code", "lifecycle_refused"), str(exc))
    except TrialError as exc:
        return ops.refuse("trial_refused", str(exc))
    except EngineError as exc:
        return ops.refuse("engine_invalid", str(exc))
    except Exception as exc:  # anything unexpected is internal, never a refusal
        print(f"internal: {type(exc).__name__}: {exc}", file=sys.stderr)
        return EXIT_INTERNAL
    finally:
        ops.flush_lease_notes()  # S7 A L2: a refused or failed verb still says what the lane obeys


if __name__ == "__main__":
    sys.exit(main())
