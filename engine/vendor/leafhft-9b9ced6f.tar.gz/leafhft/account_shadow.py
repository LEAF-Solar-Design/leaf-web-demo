"""Phase 1 account paper requests and telemetry, separate from live controls.

Account IDs stay opaque in documents. Path components are percent-encoded so an
account ID cannot select a different directory. Long components use a hash.
"""
from __future__ import annotations

import hashlib
import heapq
import json
import math
import os
import re
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote

from .engines import account_id
from .policy import (DEFAULT_POLICY, OPTIONAL_POLICY_BOUNDS, POLICY_BOUNDS, policy_digest,
                     policy_document, policy_from_mapping, validate_hard_maxima)


GATED_ENGINE_PREFIXES = ("risky-batman-",)
MIRROR_ENGINE_IDS = ("kalshi-gold-paper",)
GATE_MINUTES = 60
LIVE_UNAVAILABLE = "live deploy unavailable for Risky Batman in this release"
REQUEST_SCHEMA = "leafhft.account-shadow-request.v1"
SUMMARY_SCHEMA = "leafhft.account-shadow-summary.v1"
MAX_REQUEST_BYTES = 8192
MAX_SUMMARY_BYTES = 2048
MAX_SUMMARIES = 64
MAX_INTEGER = 2**53 - 1
_REQUEST_KEYS = frozenset({
    "schema", "account_id", "engine_id", "enabled", "overrides", "effective_policy",
    "effective_policy_digest", "generation", "requested_at",
})
_SUMMARY_KEYS = frozenset({
    "schema", "account_id", "engine_id", "generation", "effective_policy_digest",
    "state", "started_at", "updated_at", "live_tail_seconds", "decisions", "entries",
    "wins", "losses", "paper_pnl_cents", "max_drawdown_cents", "worst_trade_cents",
    "capital_basis_cents", "reasons",
})


class ShadowError(ValueError):
    """A shadow document or control was refused."""


def is_gated(engine_id):
    return isinstance(engine_id, str) and engine_id.startswith(GATED_ENGINE_PREFIXES)


def is_mirror_engine(engine_id):
    return isinstance(engine_id, str) and engine_id in MIRROR_ENGINE_IDS


def is_shadow_engine(engine_id):
    return is_gated(engine_id) or is_mirror_engine(engine_id)


def _engine_id(value):
    if (not isinstance(value, str)
            or not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,31}", value)
            or not is_shadow_engine(value)):
        raise ShadowError("engine_id: expected a shadow engine id")
    return value


def _encoded(document, limit):
    try:
        data = json.dumps(document, sort_keys=True, separators=(",", ":"),
                          allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, OverflowError, RecursionError) as exc:
        raise ShadowError("document: invalid JSON values") from exc
    if len(data) > limit:
        raise ShadowError(f"document: exceeds {limit} bytes")
    return data


def _timestamp(value, field):
    if not isinstance(value, str) or not 1 <= len(value) <= 64:
        raise ShadowError(f"{field}: expected ISO UTC timestamp")
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if stamp.utcoffset() != timedelta(0):
            raise ValueError
        return stamp
    except ValueError as exc:
        raise ShadowError(f"{field}: expected ISO UTC timestamp") from exc


def _number(value, field, minimum=-MAX_INTEGER, *, integer=False):
    if type(value) not in ((int,) if integer else (int, float)):
        raise ShadowError(f"{field}: invalid number")
    try:
        valid = math.isfinite(value) and minimum <= value <= MAX_INTEGER
    except OverflowError:
        valid = False
    if not valid:
        raise ShadowError(f"{field}: number outside bounds")


def validate_overrides(values, unset=()):
    if (not isinstance(values, dict) or len(values) > len(POLICY_BOUNDS)
            or not isinstance(unset, (list, tuple)) or len(unset) > len(POLICY_BOUNDS)
            or any(not isinstance(key, str) or key not in POLICY_BOUNDS for key in unset)
            or any(key not in POLICY_BOUNDS for key in values)):
        raise ShadowError("policy: unknown key or invalid set/unset")
    if len(set(unset)) != len(unset) or set(values) & set(unset):
        raise ShadowError("policy: duplicate or conflicting unset")
    for key, value in values.items():
        low, high, kind = POLICY_BOUNDS[key]
        _number(value, key, low, integer=kind is int)
        if value > high:
            raise ShadowError(f"{key}: value outside bounds")
        validate_hard_maxima({key: value})
    return values


def effective_policy(engine, overrides):
    validate_overrides(overrides)
    return policy_from_mapping({**policy_document(engine.policy), **overrides})


def effective_policy_digest(engine, overrides):
    return policy_digest(effective_policy(engine, overrides))


def _common(document, keys, schema, limit):
    if not isinstance(document, dict) or set(document) != keys:
        raise ShadowError("document: unexpected or missing keys")
    _encoded(document, limit)
    if document["schema"] != schema:
        raise ShadowError("schema: unsupported")
    account_id(document["account_id"])
    _engine_id(document["engine_id"])
    _number(document["generation"], "generation", 1, integer=True)
    digest = document["effective_policy_digest"]
    if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ShadowError("effective_policy_digest: invalid digest")


def validate_request(document):
    _common(document, _REQUEST_KEYS, REQUEST_SCHEMA, MAX_REQUEST_BYTES)
    if type(document["enabled"]) is not bool:
        raise ShadowError("enabled: expected bool")
    validate_overrides(document["overrides"])
    values = document["effective_policy"]
    # Every required key, plus an optional key only when it is set (absent-or-valid, never null).
    if (not isinstance(values, dict) or not set(POLICY_BOUNDS) <= set(values)
            or not set(values) <= set(POLICY_BOUNDS) | set(OPTIONAL_POLICY_BOUNDS)):
        raise ShadowError("effective_policy: expected complete policy")
    for key, (low, _, kind) in POLICY_BOUNDS.items():
        _number(values[key], key, low, integer=kind is int)
    for key, (low, high, kind) in OPTIONAL_POLICY_BOUNDS.items():
        if key in values:
            _number(values[key], key, low, integer=kind is int)
            if values[key] > high:
                raise ShadowError(f"{key}: value outside bounds")
    policy = policy_from_mapping(values)
    if (policy_document(policy) != values
            or policy_digest(policy) != document["effective_policy_digest"]):
        raise ShadowError("effective_policy_digest: policy mismatch")
    if any(values[key] != value for key, value in document["overrides"].items()):
        raise ShadowError("overrides: effective policy mismatch")
    _timestamp(document["requested_at"], "requested_at")
    return document


def validate_summary(document):
    _common(document, _SUMMARY_KEYS, SUMMARY_SCHEMA, MAX_SUMMARY_BYTES)
    # push._post uses JSON's default separators, including spaces. Bound that
    # representation as well as the compact file so C-E stays within 2 KiB.
    if len(json.dumps(document, allow_nan=False).encode("utf-8")) > MAX_SUMMARY_BYTES:
        raise ShadowError(f"summary: exceeds {MAX_SUMMARY_BYTES} wire bytes")
    if document["state"] not in ("running", "stopped", "delayed", "refused"):
        raise ShadowError("state: unsupported")
    updated = _timestamp(document["updated_at"], "updated_at")
    if document["started_at"] is not None:
        if _timestamp(document["started_at"], "started_at") > updated:
            raise ShadowError("updated_at: precedes started_at")
    elif document["state"] == "running":
        raise ShadowError("started_at: required while running")
    _number(document["live_tail_seconds"], "live_tail_seconds", 0)
    for key in ("decisions", "entries", "wins", "losses"):
        _number(document[key], key, 0, integer=True)
    for key in ("paper_pnl_cents", "worst_trade_cents"):
        _number(document[key], key)
    _number(document["max_drawdown_cents"], "max_drawdown_cents", 0)
    minimum_capital = 0 if (is_mirror_engine(document["engine_id"])
                            and document["state"] == "delayed") else 1
    _number(document["capital_basis_cents"], "capital_basis_cents", minimum_capital, integer=True)
    reasons = document["reasons"]
    if (not isinstance(reasons, list) or len(reasons) > 16
            or any(not isinstance(reason, str) or len(reason) > 160
                   or not reason.isprintable() for reason in reasons)):
        raise ShadowError("reasons: expected bounded printable strings")
    return document


def shadow_root(root=None):
    return Path(root if root is not None else os.environ.get(
        "LEAFHFT_ACCOUNT_SHADOW_DIR", "/var/lib/leafhft/account-shadow"))


def _account_component(aid):
    encoded = quote(account_id(aid), safe="").replace(".", "%2E")
    if len(encoded) > 240:
        return "%sha256-" + hashlib.sha256(aid.encode("utf-8")).hexdigest()
    # Windows device names are reserved even when they name a directory.
    if re.fullmatch(r"(?i:con|prn|aux|nul|com[1-9]|lpt[1-9])", encoded):
        encoded = f"%{ord(encoded[0]):02X}" + encoded[1:]
    return encoded


def request_path(aid, engine_id, root=None):
    return shadow_root(root) / "requests" / _account_component(aid) / f"{_engine_id(engine_id)}.json"


def summary_path(aid, engine_id, root=None):
    return shadow_root(root) / "summaries" / _account_component(aid) / f"{_engine_id(engine_id)}.json"


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ShadowError("document: duplicate key")
        result[key] = value
    return result


def _read(path, validator, limit):
    with path.open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ShadowError(f"document: exceeds {limit} bytes")
    try:
        document = json.loads(data, object_pairs_hook=_unique_object)
        return validator(document)
    except (UnicodeError, ValueError, TypeError, OverflowError, RecursionError) as exc:
        raise ShadowError(f"document: {exc}") from exc


def read_request(aid, engine_id, root=None):
    path = request_path(aid, engine_id, root)
    try:
        document = _read(path, validate_request, MAX_REQUEST_BYTES)
    except FileNotFoundError:
        return None
    if document["account_id"] != aid or document["engine_id"] != engine_id:
        raise ShadowError("request: identity does not match path")
    return document


def _atomic_write(path, document, validator, limit):
    validator(document)
    data = _encoded(document, limit)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            os.chmod(temporary, 0o640)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def write_request(aid, engine, enabled, *, set_values=None, unset=(), root=None):
    """Apply sparse paper edits; every enabled/digest transition starts a generation."""
    if type(enabled) is not bool:
        raise ShadowError("enabled: expected bool")
    values = {} if set_values is None else set_values
    validate_overrides(values, unset)
    if not enabled and (values or unset):
        raise ShadowError("set/unset require enabled true")
    path = request_path(aid, engine.engine_id, root)
    previous = read_request(aid, engine.engine_id, root)
    overrides = dict(previous["overrides"]) if previous else {}
    for key in unset:
        overrides.pop(key, None)
    overrides.update(values)
    policy = effective_policy(engine, overrides)
    digest = policy_digest(policy)
    changed = previous is None or (previous["enabled"], previous["effective_policy_digest"]) != (enabled, digest)
    document = {
        "schema": REQUEST_SCHEMA, "account_id": aid, "engine_id": engine.engine_id,
        "enabled": enabled, "overrides": overrides, "effective_policy": policy_document(policy),
        "effective_policy_digest": digest,
        "generation": (previous["generation"] if previous else 0) + int(changed),
        "requested_at": datetime.now(timezone.utc).isoformat(),
    }
    _atomic_write(path, document, validate_request, MAX_REQUEST_BYTES)
    return document


def write_mirror_request(aid, engine_id, enabled, *, root=None):
    """Enable or stop a frozen paper mirror without resolving an engine policy."""
    if not is_mirror_engine(engine_id):
        raise ShadowError("engine_id: expected a mirror engine id")
    if type(enabled) is not bool:
        raise ShadowError("enabled: expected bool")
    path = request_path(aid, engine_id, root)
    previous = read_request(aid, engine_id, root)
    changed = previous is None or previous["enabled"] != enabled
    document = {
        "schema": REQUEST_SCHEMA, "account_id": aid, "engine_id": engine_id,
        "enabled": enabled, "overrides": {}, "effective_policy": policy_document(DEFAULT_POLICY),
        "effective_policy_digest": policy_digest(DEFAULT_POLICY),
        "generation": (previous["generation"] if previous else 0) + int(changed),
        "requested_at": datetime.now(timezone.utc).isoformat(),
    }
    _atomic_write(path, document, validate_request, MAX_REQUEST_BYTES)
    return document


def write_summary(document, root=None):
    validate_summary(document)
    path = summary_path(document["account_id"], document["engine_id"], root)
    _atomic_write(path, document, validate_summary, MAX_SUMMARY_BYTES)
    return document


def read_summaries(root=None):
    """Read at most 64 files (2 KiB each), newest file modification first."""
    directory = shadow_root(root) / "summaries"

    def candidates():
        if not directory.is_dir():
            return
        for account in directory.iterdir():
            if account.is_symlink() or not account.is_dir():
                continue
            for path in account.glob("*.json"):
                try:
                    if not path.is_symlink() and path.is_file():
                        yield path.stat().st_mtime_ns, str(path), path
                except OSError:
                    continue

    try:
        paths = heapq.nlargest(MAX_SUMMARIES, candidates())
    except OSError:
        return []
    summaries = []
    for _, _, path in paths:
        try:
            document = _read(path, validate_summary, MAX_SUMMARY_BYTES)
            if path != summary_path(document["account_id"], document["engine_id"], root):
                continue
            summaries.append(document)
        except (OSError, ValueError):
            continue
    return summaries


def apply_shadow_control(value, verified_account_id, registry, *, runner_host: bool = False):
    if (not isinstance(value, dict) or set(value) - {"scope", "engine_id", "enabled", "set", "unset"}
            or not {"scope", "engine_id", "enabled"} <= set(value)):
        raise ShadowError("value: expected account scope, engine_id and enabled")
    _encoded(value, 4096)
    scope = value["scope"]
    if (not isinstance(scope, dict) or set(scope) != {"kind", "account_id"}
            or scope["kind"] != "account"):
        raise ShadowError("shadow controls require account scope")
    aid = account_id(scope["account_id"])
    if not runner_host and aid != verified_account_id:
        raise ShadowError("account scope does not match this verified runner account")
    eid = _engine_id(value["engine_id"])
    if type(value["enabled"]) is not bool:
        raise ShadowError("enabled: expected bool")
    if is_mirror_engine(eid):
        if "set" in value or "unset" in value:
            raise ShadowError("mirror engines are frozen")
        return write_mirror_request(aid, eid, value["enabled"])
    if not value["enabled"] and ("set" in value or "unset" in value):
        raise ShadowError("set/unset require enabled true")
    if "unset" in value and not isinstance(value["unset"], list):
        raise ShadowError("unset: expected list")
    values = value.get("set", {})
    unset = value.get("unset", [])
    validate_overrides(values, unset)
    return write_request(aid, registry.get(eid), value["enabled"], set_values=values, unset=unset)
