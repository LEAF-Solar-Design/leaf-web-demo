"""X5: pre-start exposure conformance in every launch path (contracts/X2X3.md v3 section 6, v3.1 A8).

`producers(domain, files, statuses)` is the section 1 opening-producer table as a pure function (it
reads, never writes): bounded, strict reads of the domain's own configuration (engine bindings,
engine documents, account overrides, Darkhorse controls, lane documents, the perp unit's wants
link) and, when given, its book statuses. Every row is {"producer", "symbol", "source", "on"}; `on`
is True, False or None, and None (unreadable) counts as ON everywhere: fails closed.

`prestart` runs before every fresh start of an opening producer: live-run.sh for the leafhft-live@
symbol books and kalshi-perp-btc (as leafhft), and leafhft-account@ lanes (ExecStartPre=+, as root).
A role that is absent, observe or authority exits 0 after the role-file stat, byte-identical to
today, without reading any JSON (so a bad file never stops an incumbent whose domain is authority).
exit_only, unregistered or unreadable evaluates the configured producers and exits 4 (the live
unit's RestartPreventExitStatus) when any is ON, logging one line per producer and writing a refusal
receipt: the book spool /var/lib/leafhft/exposure-refusals (A8: a book cannot write the root
directory) or, for the root lane prestart, /var/lib/leafhft-exposure/refusals. A receipt that cannot
be written never turns a refusal into a start. A lane whose config mode is not `live` exits 0: the
dry run starts the same unit and can open no exposure.

The prestart reads ONE role snapshot and does not synchronize it with the process launch that
follows: a launch is not a race-free transaction. A role that moves after the snapshot (a lowering
committed between the prestart and the first order) is caught by the X4 audit and the 60 s transfer
step, not by the prestart. `deploy_check.py --exposure` judges role files with this module's
`read_role`, the same call, so the report can never pass a projection the prestart refuses.

`check` adds the runtime producers from each book's selected status and writes the conformance
receipt X1 init and the X4 step read (exit 0 conformant, 4 not conformant, 3 unreadable).

Budgets: absent/authority path p99 <= 1 ms in-function (stdlib only at import, one role-file stat
plus the marker probe); exit_only evaluation p99 <= 25 ms at 1024 catalog entries. The benchmark
enumerates the catalog and reads engines referenced by symbol bindings, not all 1024 documents
(each input read once per evaluation). The whole command target is p99 <= 1.5 s on the host.
Guarded owner prestart retains live-run.sh's external 10-second command timeout (`timeout 10`).
Standalone filesystem operations have no internal deadline, so worst-case wall time is unbounded.
Neither benchmark targets nor byte caps establish a hard I/O timeout.
"""
from __future__ import annotations

import argparse
import hashlib
import heapq
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, TextIO

from . import ENGINE_CATALOG_CAPACITY, ENGINE_CATALOG_MAX_ENTRIES

# Only stdlib and package constants at import: the absent-role fast path never loads the registry code.

REFUSAL_SCHEMA = "leafhft.exposure_conformance.refusal.v1"
RECEIPT_SCHEMA = "leafhft.exposure_conformance.receipt.v1"  # exposure_authority.RECEIPT_SCHEMA

EXIT_CONFORMANT = 0
EXIT_USAGE = 2
EXIT_UNREADABLE = 3
EXIT_REFUSED = 4

LEGACY_OWNER = "legacy-owner"
EXIT_ONLY = "exit_only"
DEFAULT_ROLES_DIR = Path("/var/lib/leafhft-exposure/roles")      # exposure_authority.ROLES_DIR
LANE_REFUSALS_DIR = Path("/var/lib/leafhft-exposure/refusals")   # root 0755, the X4 collector's target
BOOK_REFUSAL_SPOOL = Path("/var/lib/leafhft/exposure-refusals")  # A8: leafhft 0750, X4 copies it out
MARKER_FILE = "_registry.json"                                   # exposure_authority.MARKER_FILE
STATUS_NAME = "kalshi-edge-status.json"
PERP_SYMBOL = "BTC-PERP"
PERP_UNIT = "leafhft-live@kalshi-perp-btc.service"
ANY = "*"

MAX_BINDINGS_BYTES = 4096            # engine_registry.MAX_BINDINGS_BYTES (engine_registry.py:47)
MAX_ENGINE_FILES = ENGINE_CATALOG_CAPACITY
MAX_ENGINE_BYTES = 16 * 1024
# At 1024 files: 16,777,216 bytes (16 MiB) of accepted engine JSON, plus at most
# 1024 one-byte overflow probes per complete pass. These are raw-input bounds,
# not peak Python RSS: decoded objects and read-once caches add overhead.
MAX_OVERRIDES_BYTES = 64 * 1024
MAX_LANE_BINDINGS_BYTES = 64 * 1024
MAX_LANE_DOCUMENT_BYTES = 64 * 1024
MAX_DARKHORSE_BYTES = 8 * 1024
MAX_IDENTITY_BYTES = 1024
MAX_LANE_CONFIG_BYTES = 64 * 1024
MAX_RUN_CONFIG_BYTES = 64 * 1024
MAX_STATUS_BYTES = 256 * 1024
MAX_RUN_DIRS = 64                    # newest by NAME (run directories are timestamped, cli.py:300-310)
MAX_RUN_SCAN = 100_000
MAX_LANES_PER_STATUS = 16
MAX_RECEIPT_BYTES = 64 * 1024        # exposure_authority.MAX_RECEIPT_BYTES
MAX_RECEIPT_ROWS = 128
MAX_REFUSAL_ROWS = 64
MAX_SOURCE = 160
STATUS_MAX_AGE_S = 90.0
STATUS_FUTURE_SKEW_S = 5.0
MTIME_SLACK_S = 5.0

PRODUCER_KINDS = frozenset({"engine_binding", "book_without_bindings", "darkhorse_host", "darkhorse_account",
                            "lane", "perp", "evaluation"})

_DOMAIN = re.compile(r"legacy-owner|account-lane:[a-z0-9][a-z0-9-]{0,63}")  # engine_registry._DOMAIN
_SYMBOL_LABEL = re.compile(r"[A-Z0-9]{1,8}-(?:15M|1H)")
_ENGINE_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,31}")
_HEX64 = re.compile(r"[0-9a-f]{64}")
_STAMP_FORMAT = "%Y-%m-%dT%H:%M:%SZ"

Producer = dict  # {"producer": str, "symbol": str, "source": str, "on": bool | None}
UnitActive = Callable[[str], "bool | None"]


# ---------------------------------------------------------------- where each domain's inputs live

@dataclass(frozen=True)
class DomainFiles:
    """Every configured input of one domain, at the paths its launcher passes (live-run.sh for
    legacy-owner, account_lane_agent.py:368-374 for a lane)."""
    domain: str
    lane_id: str | None
    engines_dir: Path
    bindings: Path
    overrides: Path
    identity: Path
    darkhorse: Path                  # host darkhorse.json (legacy) or darkhorse-controls.json (lane)
    lane_bindings: Path | None       # legacy only
    perp_wants: Path | None          # legacy only: the perp unit's enablement link
    runs: Path
    lane_config: Path | None         # lane only

    @property
    def legacy(self) -> bool:
        return self.lane_id is None


def domain_files(domain: str, *, etc: Path | str | None = None, owner_state: Path | str | None = None,
                 lanes_state: Path | str | None = None, lanes_config: Path | str | None = None,
                 systemd_dir: Path | str | None = None) -> DomainFiles:
    if _DOMAIN.fullmatch(domain) is None:
        raise ValueError(f"invalid domain {domain!r}")
    if domain == LEGACY_OWNER:
        etc = Path(etc if etc is not None else (os.environ.get("LEAFHFT_ETC") or "/etc/leafhft"))
        state = Path(owner_state if owner_state is not None else "/var/lib/leafhft")
        wants = Path(systemd_dir if systemd_dir is not None else "/etc/systemd/system") / "multi-user.target.wants"
        return DomainFiles(domain, None, etc / "engines", etc / "kalshi-engine-bindings.json",
                           etc / "kalshi-engine-account-overrides.json", state / "dashboard-account.json",
                           etc / "darkhorse.json", etc / "lane-bindings.json", wants / PERP_UNIT,
                           state / "runs", None)
    lane_id = domain.split(":", 1)[1]
    state = Path(lanes_state if lanes_state is not None else "/var/lib/leafhft-accounts") / lane_id
    config = Path(lanes_config if lanes_config is not None else "/etc/leafhft-accounts") / lane_id / "config.json"
    return DomainFiles(domain, lane_id, state / "engine-catalog" / "engines", state / "engine-bindings.json",
                       state / "engine-account-overrides.json", state / "dashboard-account-identity.json",
                       state / "darkhorse-controls.json", None, None, state / "runs", config)


def book_unit(files: DomainFiles, symbol: str) -> str:
    if files.legacy:
        return f"leafhft-live@kalshi-{symbol.lower()}.service"
    return f"leafhft-account@{files.lane_id}.service"


def refusal_slug(domain: str, *, symbol: str | None = None, producer: str | None = None) -> str:
    """The refusal receipt's file stem, named after the unit it refused (X4 `_REFUSAL_NAME`)."""
    if domain != LEGACY_OWNER:
        return "leafhft-account_" + domain.split(":", 1)[1]
    if producer == "perp":
        return "leafhft-live_kalshi-perp-btc"
    return f"leafhft-live_kalshi-{(symbol or 'unknown').lower()}"


def _symbols() -> tuple[str, ...]:
    from .engine_registry import symbols

    return symbols()


# ---------------------------------------------------------------- bounded, strict reads

class _Unreadable(Exception):
    """An input that exists but cannot be read or decoded: it counts as ON."""


def _pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"duplicate key {key!r}")
        out[key] = value
    return out


def _constant(text: str) -> Any:
    raise ValueError(f"non-finite number {text}")


def _decode(data: bytes) -> Any:
    """Strict JSON: UTF-8, no duplicate keys, no NaN or Infinity."""
    return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=_constant)


def _read_capped(path: Path | str, limit: int) -> bytes:
    """At most `limit` bytes or ValueError; FileNotFoundError propagates so callers can mean absent."""
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_BINARY", 0))
    with os.fdopen(fd, "rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"{Path(path).name} exceeds {limit} bytes")
    return data


def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode("ascii")


def _row(producer: str, symbol: str, source: str, on: bool | None) -> Producer:
    return {"producer": producer, "symbol": symbol, "source": str(source)[:MAX_SOURCE], "on": on}


class _Inputs:
    """Every configured input of one domain, read at most once per evaluation (bounded, strict),
    with its sha256 recorded for the receipt's config_digest."""

    def __init__(self, files: DomainFiles) -> None:
        self.files = files
        self.digests: dict[str, str] = {}
        self._json: dict[str, Any] = {}
        self._engines: dict[str, bool | None] = {}
        self._engine_files: int | None = None
        self._overrides: Any = None
        self._overrides_read = False

    def json(self, path: Path, limit: int) -> Any:
        """The decoded document, None when absent; raises _Unreadable."""
        key = os.fspath(path)
        if key in self._json:
            value = self._json[key]
            if value is _Unreadable:
                raise _Unreadable(key)
            return value
        try:
            data = _read_capped(path, limit)
        except FileNotFoundError:
            self.digests[key] = "absent"
            self._json[key] = None
            return None
        except (OSError, ValueError) as exc:
            self.digests[key] = "unreadable"
            self._json[key] = _Unreadable
            raise _Unreadable(key) from exc
        self.digests[key] = _digest(data)
        try:
            value = _decode(data)
        except (ValueError, UnicodeError, RecursionError) as exc:
            self._json[key] = _Unreadable
            raise _Unreadable(key) from exc
        self._json[key] = value
        return value

    def lane_mode(self) -> str | None:
        """The lane's config mode; None when unreadable (the lane then counts as live)."""
        if self.files.lane_config is None:
            return None
        try:
            raw = self.json(self.files.lane_config, MAX_LANE_CONFIG_BYTES)
        except _Unreadable:
            return None
        mode = raw.get("mode") if type(raw) is dict else None
        return mode if type(mode) is str else None

    def bindings(self) -> tuple[str | None, dict[str, str], frozenset[str]] | None:
        """(default, symbols, disabled), None when absent. The shape of engine_registry.read_bindings
        and engines.Bindings.load: 4 KiB, unknown symbols or engine ids refused."""
        raw = self.json(self.files.bindings, MAX_BINDINGS_BYTES)
        if raw is None:
            return None
        known = frozenset(_symbols())
        if (type(raw) is not dict or set(raw) not in ({"default", "symbols"}, {"default", "symbols", "disabled"})
                or type(raw["symbols"]) is not dict):
            raise _Unreadable("bindings: expected default, symbols, optional disabled")
        default = raw["default"]
        if default is not None and (type(default) is not str or _ENGINE_ID.fullmatch(default) is None):
            raise _Unreadable("bindings: default")
        for symbol, engine_id in raw["symbols"].items():
            if symbol not in known or type(engine_id) is not str or _ENGINE_ID.fullmatch(engine_id) is None:
                raise _Unreadable("bindings: symbols")
        disabled = raw.get("disabled", [])
        if (type(disabled) is not list or len(disabled) > 64
                or any(type(symbol) is not str or symbol not in known for symbol in disabled)
                or len(set(disabled)) != len(disabled)):
            raise _Unreadable("bindings: disabled")
        return default, dict(raw["symbols"]), frozenset(disabled)

    def _engine_count(self) -> int:
        if self._engine_files is None:
            count = 0
            try:
                with os.scandir(self.files.engines_dir) as entries:
                    # Assumes a stable directory during this read-once scan.
                    for scanned, entry in enumerate(entries, 1):
                        if scanned > ENGINE_CATALOG_MAX_ENTRIES:
                            count = MAX_ENGINE_FILES + 1
                            break
                        if entry.name.endswith(".json"):
                            count += 1
                            if count > MAX_ENGINE_FILES:
                                break
            except FileNotFoundError:
                count = 0
            except OSError:
                count = MAX_ENGINE_FILES + 1
            self._engine_files = count
        return self._engine_files

    def engine_enabled(self, engine_id: str) -> bool | None:
        """The engine document's own `enabled` (default True, engines.py:46); None when the
        catalog is over its cap, the document is missing (a global DELETE leaves the binding
        unloadable) or it cannot be decoded."""
        if engine_id in self._engines:
            return self._engines[engine_id]
        value = None
        try:
            if self._engine_count() <= MAX_ENGINE_FILES:
                raw = self.json(self.files.engines_dir / f"{engine_id}.json", MAX_ENGINE_BYTES)
                if type(raw) is dict and raw.get("engine_id") == engine_id:
                    flag = raw.get("enabled", True)
                    value = flag if type(flag) is bool else None
        except _Unreadable:
            value = None
        self._engines[engine_id] = value
        return value

    def _override_accounts(self) -> dict[str, dict[str, Any]] | None:
        """{account_id: {engine_id: entry}}, {} when absent; raises _Unreadable."""
        if self._overrides_read:
            if self._overrides is _Unreadable:
                raise _Unreadable("overrides")
            return self._overrides
        self._overrides_read = True
        self._overrides = _Unreadable
        raw = self.json(self.files.overrides, MAX_OVERRIDES_BYTES)
        accounts: dict[str, dict[str, Any]] = {}
        if raw is not None:
            if (type(raw) is not dict or set(raw) != {"schema_version", "accounts"}
                    or type(raw["schema_version"]) is not int or raw["schema_version"] != 1
                    or type(raw["accounts"]) is not dict or len(raw["accounts"]) > 128):
                raise _Unreadable("overrides: document")
            for account, body in raw["accounts"].items():
                if (type(body) is not dict or set(body) != {"engines"} or type(body["engines"]) is not dict
                        or len(body["engines"]) > 64
                        or any(type(entry) is not dict or "enabled" not in entry for entry in body["engines"].values())):
                    raise _Unreadable("overrides: account entry")
                accounts[account] = body["engines"]
        self._overrides = accounts
        return accounts

    def effective_enabled(self, engine_id: str) -> bool | None:
        """Engine AND account override, where `inherit` (null) drops to the global flag
        (engines.py:527, :534-538, :583-585)."""
        engine = self.engine_enabled(engine_id)
        if engine is None:
            return None
        try:
            accounts = self._override_accounts()
            if not accounts:
                return engine
            identity = self.json(self.files.identity, MAX_IDENTITY_BYTES)
        except _Unreadable:
            return None
        account = identity.get("account_id") if type(identity) is dict else None
        if type(account) is not str or not account:
            return None
        entry = accounts.get(account, {}).get(engine_id)
        if entry is None:
            return engine
        enabled = entry["enabled"]
        if enabled is None:
            return engine
        return enabled if type(enabled) is bool else None

    def darkhorse_armed(self) -> bool | None:
        """Host `armed` 0/1 (cli.py:2703-2713) or the lane's controls `enabled`; absent is off
        (engines.py:317-320)."""
        try:
            raw = self.json(self.files.darkhorse, MAX_DARKHORSE_BYTES)
        except _Unreadable:
            return None
        if raw is None:
            return False
        if type(raw) is not dict:
            return None
        if self.files.legacy:
            armed = raw.get("armed")
            return armed == 1 if type(armed) is int and armed in (0, 1) else None
        enabled = raw.get("enabled")
        return enabled if type(enabled) is bool else None

    def lane_documents(self) -> dict[str, list[str]] | None:
        """{symbol: [lane document path]} under live-run.sh's own rules (live-run.sh:213-241); {}
        when absent or not a legacy domain; None when unreadable."""
        if self.files.lane_bindings is None:
            return {}
        try:
            raw = self.json(self.files.lane_bindings, MAX_LANE_BINDINGS_BYTES)
        except _Unreadable:
            return None
        if raw is None:
            return {}
        if type(raw) is not dict or len(raw) > 64:
            return None
        for symbol, paths in raw.items():
            if not symbol or len(symbol) > 16 or type(paths) is not list or len(paths) > 4:
                return None
            if any(type(path) is not str or not os.path.isabs(path) or len(path) > 4096 or not path.isprintable()
                   for path in paths):
                return None
            if len(set(paths)) != len(paths):
                return None
        return raw

    def lane_armed(self, path: str) -> bool | None:
        """The document's `hot.armed`, hot-reloaded with no restart (lanes/live_runner.py:533-537)."""
        try:
            raw = self.json(Path(path), MAX_LANE_DOCUMENT_BYTES)
        except _Unreadable:
            return None
        if raw is None:
            return False
        hot = raw.get("hot") if type(raw) is dict else None
        armed = hot.get("armed") if type(hot) is dict else None
        return armed if type(armed) is bool else None

    def perp_enabled(self) -> bool | None:
        path = self.files.perp_wants
        if path is None:
            return False
        try:
            present = os.path.lexists(path)
        except OSError:
            self.digests[os.fspath(path)] = "unreadable"
            return None
        self.digests[os.fspath(path)] = "present" if present else "absent"
        return present


# ---------------------------------------------------------------- the section 1 table

def _configured(inputs: _Inputs, only: str | None) -> list[Producer]:
    """Configured producers: every symbol (or only `only`) plus the domain-level ones. The perp
    unit is a domain producer of its own: a symbol book's scope never includes it."""
    files = inputs.files
    symbols = (only,) if only is not None else _symbols()
    rows: list[Producer] = []
    if files.legacy:
        try:
            bound = files.bindings.is_file() and files.engines_dir.is_dir()
        except OSError:
            bound = None
    else:
        bound = True
    if bound is None:
        rows.extend(_row("book_without_bindings", symbol, "bindings_unreadable", None) for symbol in symbols)
    elif not bound:
        # _kalshi_policy_source returns a plain watcher and entry_enabled is True (cli.py:1500-1505, :3420).
        rows.extend(_row("book_without_bindings", symbol, "configured", True) for symbol in symbols)
    else:
        try:
            view = inputs.bindings()
        except _Unreadable:
            rows.extend(_row("engine_binding", symbol, "bindings_unreadable", None) for symbol in symbols)
        else:
            default, mapping, disabled = view if view is not None else (None, {}, frozenset())
            for symbol in symbols:
                if symbol in disabled:  # the robust switch: survives configure and bind (engines.py:648-671)
                    rows.append(_row("engine_binding", symbol, "disabled", False))
                    continue
                engine_id = mapping.get(symbol, default)
                if engine_id is None:
                    rows.append(_row("engine_binding", symbol, "unbound", False))
                    continue
                rows.append(_row("engine_binding", symbol, f"configured:{engine_id}",
                                 inputs.effective_enabled(engine_id)))
    if files.legacy:
        lanes = inputs.lane_documents()
        if lanes is None:
            rows.append(_row("lane", only or ANY, "lane_bindings_unreadable", None))
        else:
            for symbol in symbols:
                for path in lanes.get(symbol, ()):
                    rows.append(_row("lane", symbol, f"configured:{path}", inputs.lane_armed(path)))
        rows.append(_row("darkhorse_host", ANY, "configured", inputs.darkhorse_armed()))
        if only is None:
            rows.append(_row("perp", PERP_SYMBOL, "unit_enabled", inputs.perp_enabled()))
    else:
        rows.append(_row("darkhorse_account", ANY, "configured", inputs.darkhorse_armed()))
    return rows


def _flag(value: Any) -> bool | None:
    if type(value) is bool:
        return value
    if type(value) is int and value in (0, 1):
        return value == 1
    return None


def _runtime(files: DomainFiles, statuses: Mapping[str, Any]) -> list[Producer]:
    """Runtime producers from each book's selected status: effective enable is engine AND book
    (cli.py:1391); None (unreadable) for a status that could not be selected."""
    rows: list[Producer] = []
    darkhorse_kind = "darkhorse_host" if files.legacy else "darkhorse_account"
    for symbol, status in sorted(statuses.items()):
        if symbol == PERP_SYMBOL:
            active = status.get("active") if isinstance(status, Mapping) else None
            rows.append(_row("perp", PERP_SYMBOL, "unit_active", active if type(active) is bool else None))
            continue
        if not isinstance(status, Mapping):
            rows.append(_row("engine_binding", symbol, "status_unreadable", None))
            continue
        engine = status.get("engine")
        if engine is None:
            rows.append(_row("book_without_bindings", symbol, "runtime", True) if files.legacy
                        else _row("engine_binding", symbol, "runtime", None))
        elif not isinstance(engine, Mapping):
            rows.append(_row("engine_binding", symbol, "runtime", None))
        else:
            enabled, book = engine.get("enabled"), engine.get("book_enabled")
            on = False if (book is False or enabled is False) else True if enabled is True else None
            rows.append(_row("engine_binding", symbol, "runtime", on))
        darkhorse = status.get("darkhorse")
        if darkhorse is not None:
            armed = darkhorse.get("armed") if isinstance(darkhorse, Mapping) else None
            rows.append(_row(darkhorse_kind, symbol, "runtime", _flag(armed)))
        lanes = status.get("lanes")
        if lanes is not None:
            if not isinstance(lanes, Mapping):
                rows.append(_row("lane", symbol, "runtime", None))
                continue
            for lane_id, snapshot in sorted(lanes.items(), key=lambda item: str(item[0]))[:MAX_LANES_PER_STATUS]:
                armed = snapshot.get("armed") if isinstance(snapshot, Mapping) else None
                rows.append(_row("lane", symbol, f"runtime:{str(lane_id)[:64]}", armed if type(armed) is bool else None))
    return rows


def producers(domain: str, files: DomainFiles | None = None,
              statuses: Mapping[str, Any] | None = None) -> list[Producer]:
    """The section 1 opening-producer table for `domain`: configured rows for all 14 symbols plus
    the domain-level producers, and runtime rows when `statuses` ({symbol: status document or None
    when unreadable; PERP_SYMBOL: {"active": bool | None}}) is given. Reads only; never writes."""
    files = domain_files(domain) if files is None else files
    if files.domain != domain:
        raise ValueError(f"files belong to {files.domain}, not {domain}")
    rows = _configured(_Inputs(files), None)
    if statuses is not None:
        rows.extend(_runtime(files, statuses))
    return rows


def verdict(rows: list[Producer]) -> int:
    """0 every producer off, 4 any ON, 3 none ON but some unreadable."""
    if any(row["on"] is True for row in rows):
        return EXIT_REFUSED
    if any(row["on"] is None for row in rows):
        return EXIT_UNREADABLE
    return EXIT_CONFORMANT


# ---------------------------------------------------------------- the role

def read_role(domain: str, roles_dir: Path | str | None = None) -> Any:
    """None when the role is absent (no role file and no marker: two stats, no JSON, no registry
    import), else exposure_authority.RoleView (absent, unregistered, unreadable or the record)."""
    roles_dir = DEFAULT_ROLES_DIR if roles_dir is None else Path(roles_dir)
    path = roles_dir / f"{domain.replace(':', '_')}.json"
    try:
        os.stat(path)
    except FileNotFoundError:
        if not os.path.exists(roles_dir / MARKER_FILE):
            return None
    except OSError:
        pass  # the reader reports it unreadable
    from .exposure_authority import DomainRole

    return DomainRole(path, domain=domain, marker_path=roles_dir / MARKER_FILE).read()


def _role_summary(view: Any) -> dict[str, Any]:
    if view is None:
        return {"state": "absent", "role": None, "enforcement": None, "generation": None}
    return {"state": view.state, "role": view.role, "enforcement": view.enforcement,
            "generation": view.generation}


def _refuses(view: Any) -> bool:
    return view is not None and view.refuses_opening


# ---------------------------------------------------------------- receipts

def _stamp(epoch_s: float) -> str:
    return datetime.fromtimestamp(int(epoch_s), timezone.utc).strftime(_STAMP_FORMAT)


def _write_atomic(path: Path, data: bytes, mode: int = 0o644) -> None:
    """Temp file beside it (a dot name, which the X4 collector skips), fsync, rename."""
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)
    fd = os.open(tmp, flags, mode)
    try:
        view = memoryview(data)
        while view:
            view = view[os.write(fd, view):]
        os.fsync(fd)
    finally:
        os.close(fd)
    try:
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _validate_rows(rows: Any, where: str, limit: int) -> None:
    if type(rows) is not list or len(rows) > limit:
        raise ValueError(f"{where}: a list of at most {limit} rows")
    for row in rows:
        if (type(row) is not dict or set(row) != {"producer", "symbol", "source", "on"}
                or row["producer"] not in PRODUCER_KINDS or type(row["symbol"]) is not str
                or type(row["source"]) is not str or len(row["source"]) > MAX_SOURCE
                or row["on"] not in (True, False, None) or type(row["on"]) not in (bool, type(None))):
            raise ValueError(f"{where}: malformed row {row!r}")


def _validate_role(role: Any, where: str) -> None:
    if (type(role) is not dict or set(role) != {"state", "role", "enforcement", "generation"}
            or role["state"] not in ("absent", "unregistered", "unreadable", "record", "domain_ledger_mismatch")
            or role["role"] not in (None, "authority", EXIT_ONLY)
            or role["enforcement"] not in (None, "operational", "observe")
            or (role["generation"] is not None and type(role["generation"]) is not int)):
        raise ValueError(f"{where}: malformed role {role!r}")


def _validate_stamp(value: Any, where: str) -> None:
    if type(value) is not str:
        raise ValueError(f"{where}: not a stamp")
    datetime.strptime(value, _STAMP_FORMAT)


_REFUSAL_KEYS = frozenset({"schema", "domain", "slug", "scope", "role", "exit_code", "refused_at",
                           "producers", "producers_total"})
_RECEIPT_KEYS = frozenset({"schema", "domain", "as_if", "role", "evaluated", "conformant", "exit_code",
                           "config_digest", "status_digest", "generated_at", "since", "status", "selection",
                           "lane_mode", "producers", "producers_total"})


def validate_refusal(doc: Any) -> dict[str, Any]:
    """The refusal receipt schema (REFUSAL_SCHEMA); raises ValueError on any defect."""
    if type(doc) is not dict or set(doc) != _REFUSAL_KEYS:
        raise ValueError("refusal: unknown or missing keys")
    if doc["schema"] != REFUSAL_SCHEMA or type(doc["domain"]) is not str or _DOMAIN.fullmatch(doc["domain"]) is None:
        raise ValueError("refusal: schema or domain")
    if type(doc["slug"]) is not str or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,95}", doc["slug"]) is None:
        raise ValueError("refusal: slug")
    scope = doc["scope"]
    if (type(scope) is not dict or set(scope) != {"symbol", "producer"}
            or (scope["symbol"] is not None and type(scope["symbol"]) is not str)
            or scope["producer"] not in (None, "perp")):
        raise ValueError("refusal: scope")
    _validate_role(doc["role"], "refusal")
    if doc["exit_code"] != EXIT_REFUSED or type(doc["exit_code"]) is not int:
        raise ValueError("refusal: exit_code")
    _validate_stamp(doc["refused_at"], "refusal.refused_at")
    _validate_rows(doc["producers"], "refusal.producers", MAX_REFUSAL_ROWS)
    if not doc["producers"] or any(row["on"] is False for row in doc["producers"]):
        raise ValueError("refusal: names only the producers that are on or unreadable")
    if type(doc["producers_total"]) is not int or doc["producers_total"] < len(doc["producers"]):
        raise ValueError("refusal: producers_total")
    return doc


def validate_receipt(doc: Any) -> dict[str, Any]:
    """The conformance receipt schema (RECEIPT_SCHEMA, what X1 init and the X4 step read)."""
    if type(doc) is not dict or set(doc) != _RECEIPT_KEYS:
        raise ValueError("receipt: unknown or missing keys")
    if doc["schema"] != RECEIPT_SCHEMA or type(doc["domain"]) is not str or _DOMAIN.fullmatch(doc["domain"]) is None:
        raise ValueError("receipt: schema or domain")
    if doc["as_if"] not in (None, EXIT_ONLY):
        raise ValueError("receipt: as_if")
    _validate_role(doc["role"], "receipt")
    for key in ("evaluated", "conformant", "status"):
        if type(doc[key]) is not bool:
            raise ValueError(f"receipt: {key}")
    if doc["exit_code"] not in (EXIT_CONFORMANT, EXIT_UNREADABLE, EXIT_REFUSED) or type(doc["exit_code"]) is not int:
        raise ValueError("receipt: exit_code")
    if doc["conformant"] != (doc["exit_code"] == EXIT_CONFORMANT):
        raise ValueError("receipt: conformant disagrees with exit_code")
    for key in ("config_digest", "status_digest"):
        if type(doc[key]) is not str or _HEX64.fullmatch(doc[key]) is None:
            raise ValueError(f"receipt: {key}")
    _validate_stamp(doc["generated_at"], "receipt.generated_at")
    if doc["since"] is not None:
        _validate_stamp(doc["since"], "receipt.since")
    if type(doc["selection"]) is not dict or any(type(k) is not str or type(v) is not str
                                                 for k, v in doc["selection"].items()):
        raise ValueError("receipt: selection")
    if doc["lane_mode"] is not None and type(doc["lane_mode"]) is not str:
        raise ValueError("receipt: lane_mode")
    _validate_rows(doc["producers"], "receipt.producers", MAX_RECEIPT_ROWS)
    if type(doc["producers_total"]) is not int or doc["producers_total"] < len(doc["producers"]):
        raise ValueError("receipt: producers_total")
    return doc


def _fit(doc: dict[str, Any], rows: list[Producer], limit_rows: int, limit_bytes: int) -> bytes:
    """Canonical bytes of `doc` with as many rows as fit: every row, then only the non-off ones,
    then none. producers_total always carries the full count."""
    doc["producers_total"] = len(rows)
    for candidate in (rows, [row for row in rows if row["on"] is not False], []):
        doc["producers"] = candidate[:limit_rows]
        data = _canonical(doc) + b"\n"
        if len(data) <= limit_bytes:
            return data
    return data


# ---------------------------------------------------------------- prestart

def prestart(domain: str, *, symbol: str | None = None, producer: str | None = None,
             roles_dir: Path | str | None = None, files: DomainFiles | None = None,
             refusal_dir: Path | str | None = None, now: Callable[[], float] = time.time,
             err: TextIO | None = None) -> int:
    """0 start, 4 refuse (fails closed on any evaluation error), 2 usage. See the module docstring."""
    err = sys.stderr if err is None else err
    lane = domain != LEGACY_OWNER
    if (_DOMAIN.fullmatch(domain) is None or (symbol is not None and producer is not None)
            or (lane and (symbol is not None or producer is not None))
            or (not lane and symbol is None and producer is None)
            or producer not in (None, "perp")
            or (symbol is not None and _SYMBOL_LABEL.fullmatch(symbol) is None)):
        print(f"exposure prestart: usage: --domain legacy-owner (--symbol S | --producer perp) "
              f"or --domain account-lane:<uuid>; got {domain!r} {symbol!r} {producer!r}", file=err)
        return EXIT_USAGE
    view = read_role(domain, roles_dir)
    if not _refuses(view):
        return EXIT_CONFORMANT  # absent, observe or authority: today's behaviour
    role = _role_summary(view)
    scope = f" {symbol}" if symbol else " kalshi-perp-btc" if producer else ""
    try:
        files = domain_files(domain) if files is None else files
        inputs = _Inputs(files)
        if lane:
            mode = inputs.lane_mode()
            if mode is not None and mode != "live":
                print(f"exposure prestart: {domain} is {role['state']}/{role['role']}; lane mode {mode} "
                      f"opens no exposure, start allowed", file=err)
                return EXIT_CONFORMANT
        if producer == "perp":
            rows = [_row("perp", PERP_SYMBOL, "prestart", True)]  # the unit being started is the producer
        else:
            if symbol is not None and symbol not in _symbols():
                raise ValueError(f"unknown symbol {symbol}")
            rows = _configured(inputs, symbol)
    except Exception as exc:  # fails closed: an evaluation that cannot finish refuses
        rows = [_row("evaluation", symbol or ANY, f"error:{type(exc).__name__}", None)]
    on = [row for row in rows if row["on"] is not False]
    if not on:
        print(f"exposure prestart: {domain}{scope} is {role['state']}/{role['role']}; every opening "
              f"producer is off, start allowed", file=err)
        return EXIT_CONFORMANT
    for row in on:
        print(f"exposure prestart: REFUSED {domain}{scope} ({role['state']}/{role['role']}): "
              f"{row['producer']} {row['symbol']} {row['source']} "
              f"{'on' if row['on'] else 'unreadable, counts as on'}", file=err)
    slug = refusal_slug(domain, symbol=symbol, producer=producer)
    doc = {"schema": REFUSAL_SCHEMA, "domain": domain, "slug": slug,
           "scope": {"symbol": symbol, "producer": producer}, "role": role, "exit_code": EXIT_REFUSED,
           "refused_at": _stamp(now())}
    try:
        directory = Path(refusal_dir) if refusal_dir is not None else (LANE_REFUSALS_DIR if lane else BOOK_REFUSAL_SPOOL)
        if lane and refusal_dir is None:
            directory.mkdir(mode=0o755, parents=False, exist_ok=True)  # root; X4's collector target
        _write_atomic(directory / f"{slug}.json", _fit(doc, on, MAX_REFUSAL_ROWS, MAX_RECEIPT_BYTES))
    except (OSError, ValueError) as exc:
        print(f"exposure prestart: refusal receipt not written ({type(exc).__name__}); "
              f"the start is refused regardless", file=err)
    return EXIT_REFUSED


# ---------------------------------------------------------------- check

def _unit_active(unit: str) -> bool | None:
    try:
        result = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True, timeout=5,
                                check=False, env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8"})
    except (OSError, subprocess.SubprocessError):
        return None
    state = result.stdout.strip()
    if state in ("active", "activating", "reloading", "deactivating", "refreshing"):
        return True
    if state in ("inactive", "failed"):
        return False
    return None


def _iso_epoch(value: Any) -> float | None:
    """A status `generated_at` (ISO 8601 with an offset) as epoch seconds; None when naive or bad."""
    if type(value) is not str or len(value) > 64:
        return None
    try:
        moment = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return None if moment.tzinfo is None else moment.timestamp()


def select_statuses(files: DomainFiles, symbols: tuple[str, ...], *, since_s: float, now_s: float,
                    unit_active: UnitActive) -> tuple[dict[str, Any], dict[str, str], dict[str, str], list[Producer]]:
    """Per symbol, among the newest MAX_RUN_DIRS run directories by NAME (`probe-*` and `darkhorse`
    excluded), the statuses whose content `generated_at` is at or after `since_s` and at most 90 s
    old. Exactly one: used. None with the unit inactive: configured-only. None with the unit active,
    or more than one: unreadable. mtime only chooses which status files to open, never evidence.
    Returns (statuses, selection, status digests, extra rows)."""
    statuses: dict[str, Any] = {}
    selection: dict[str, str] = {}
    digests: dict[str, str] = {}
    extra: list[Producer] = []
    names: list[str] = []
    try:
        with os.scandir(files.runs) as entries:
            for index, entry in enumerate(entries):
                if index >= MAX_RUN_SCAN:
                    raise ValueError("run directory scan cap")
                name = entry.name
                if name.startswith("probe-") or name.startswith("darkhorse"):
                    continue
                try:
                    if entry.is_dir(follow_symlinks=False):
                        names.append(name)
                except OSError:
                    continue
    except FileNotFoundError:
        names = []
    except (OSError, ValueError) as exc:
        for symbol in symbols:
            statuses[symbol] = None
            selection[symbol] = f"unreadable:runs {type(exc).__name__}"
        return statuses, selection, digests, extra
    wanted = set(symbols)
    candidates: dict[str, list[tuple[str, Any]]] = {}
    for name in heapq.nlargest(MAX_RUN_DIRS, names):
        run = files.runs / name
        try:
            mtime = os.stat(run / STATUS_NAME).st_mtime
        except OSError:
            continue
        if mtime < since_s - MTIME_SLACK_S or now_s - mtime > STATUS_MAX_AGE_S + MTIME_SLACK_S:
            continue
        try:
            config = _decode(_read_capped(run / "config.json", MAX_RUN_CONFIG_BYTES))
        except (OSError, ValueError, UnicodeError, RecursionError):
            config = None
        if type(config) is not dict or type(config.get("symbol")) is not str:
            extra.append(_row("engine_binding", ANY, f"status_unattributed:{name[:96]}", None))
            continue
        if str(config.get("venue", "")).lower() != "kalshi":
            continue
        symbol = config["symbol"].upper()
        if symbol not in wanted or len(candidates.get(symbol, ())) >= 2:
            continue  # a third candidate changes nothing: two already make the symbol unreadable
        try:
            data = _read_capped(run / STATUS_NAME, MAX_STATUS_BYTES)
            status = _decode(data)
        except (OSError, ValueError, UnicodeError, RecursionError):
            candidates.setdefault(symbol, []).append((name, None))
            continue
        generated = _iso_epoch(status.get("generated_at")) if type(status) is dict else None
        if generated is None:
            candidates.setdefault(symbol, []).append((name, None))
            continue
        if generated < since_s or now_s - generated > STATUS_MAX_AGE_S or generated - now_s > STATUS_FUTURE_SKEW_S:
            continue
        digests[name] = _digest(data)
        candidates.setdefault(symbol, []).append((name, status))
    active_cache: dict[str, bool | None] = {}
    for symbol in symbols:
        found = candidates.get(symbol, [])
        if len(found) == 1 and found[0][1] is not None:
            statuses[symbol] = found[0][1]
            selection[symbol] = f"selected:{found[0][0][:96]}"
        elif not found:
            unit = book_unit(files, symbol)
            if unit not in active_cache:
                active_cache[unit] = unit_active(unit)
            active = active_cache[unit]
            if active is False:
                selection[symbol] = "configured_only"
            else:
                statuses[symbol] = None
                selection[symbol] = "unreadable:unit_active_without_fresh_status" if active else "unreadable:unit_state_unknown"
        else:
            statuses[symbol] = None
            selection[symbol] = "unreadable:ambiguous" if len(found) > 1 else "unreadable:status"
    if files.legacy:
        statuses[PERP_SYMBOL] = {"active": unit_active(PERP_UNIT)}
    return statuses, selection, digests, extra


def check(domain: str, *, as_if: str | None = None, status: bool = False, since: float | None = None,
          receipt: Path | str | None = None, roles_dir: Path | str | None = None,
          files: DomainFiles | None = None, now: Callable[[], float] = time.time,
          unit_active: UnitActive | None = None) -> tuple[int, dict[str, Any]]:
    """(exit code, receipt document). The receipt is written to `receipt` when given, conformant or
    not; with `as_if` exit_only the role file is not consulted for the decision."""
    if _DOMAIN.fullmatch(domain) is None:
        raise ValueError(f"invalid domain {domain!r}")
    if as_if not in (None, EXIT_ONLY):
        raise ValueError(f"invalid --as-if {as_if!r}")
    now_s = now()
    files = domain_files(domain) if files is None else files
    view = read_role(domain, roles_dir)
    evaluate = as_if == EXIT_ONLY or _refuses(view)
    inputs = _Inputs(files)
    rows: list[Producer] = []
    selection: dict[str, str] = {}
    status_digests: dict[str, str] = {}
    since_s = None
    lane_mode = None
    try:
        lane_mode = inputs.lane_mode()
        if evaluate:
            rows = _configured(inputs, None)
            if status:
                since_s = now_s - STATUS_MAX_AGE_S if since is None else since
                statuses, selection, status_digests, extra = select_statuses(
                    files, _symbols(), since_s=since_s, now_s=now_s, unit_active=unit_active or _unit_active)
                rows.extend(extra)
                rows.extend(_runtime(files, statuses))
        code = verdict(rows) if evaluate else EXIT_CONFORMANT
    except Exception as exc:  # an evaluation that cannot finish is unreadable, never conformant
        rows.append(_row("evaluation", ANY, f"error:{type(exc).__name__}", None))
        code = verdict(rows)
    doc: dict[str, Any] = {
        "schema": RECEIPT_SCHEMA, "domain": domain, "as_if": as_if, "role": _role_summary(view),
        "evaluated": evaluate, "conformant": code == EXIT_CONFORMANT, "exit_code": code,
        "config_digest": _digest(_canonical(sorted(inputs.digests.items()))),
        "status_digest": _digest(_canonical({"selection": selection, "statuses": status_digests})),
        "generated_at": _stamp(now_s), "since": None if since_s is None else _stamp(since_s),
        "status": bool(status), "selection": selection, "lane_mode": lane_mode,
    }
    data = _fit(doc, rows, MAX_RECEIPT_ROWS, MAX_RECEIPT_BYTES)
    if receipt is not None:
        _write_atomic(Path(receipt), data)
    return code, doc


# ---------------------------------------------------------------- command line

def _parse_since(text: str) -> float:
    try:
        return datetime.strptime(text, _STAMP_FORMAT).replace(tzinfo=timezone.utc).timestamp()
    except ValueError:
        epoch = _iso_epoch(text)
        if epoch is None:
            raise argparse.ArgumentTypeError(f"--since: {text!r} is not a UTC stamp") from None
        return epoch


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m leafhft.exposure_conformance",
                                     description="X5 exposure conformance: prestart gate and check.")
    verbs = parser.add_subparsers(dest="verb", required=True)
    commands = {name: verbs.add_parser(name) for name in ("prestart", "check")}
    for command in commands.values():
        command.add_argument("--domain", required=True)
        # Relocation for tests and dry harnesses only; no unit passes any of these.
        for flag in ("--roles-dir", "--etc", "--owner-state", "--lanes-state", "--lanes-config", "--systemd-dir"):
            command.add_argument(flag, type=Path, help=argparse.SUPPRESS)
    scope = commands["prestart"].add_mutually_exclusive_group()
    scope.add_argument("--symbol")
    scope.add_argument("--producer", choices=["perp"])
    commands["prestart"].add_argument("--refusal-dir", type=Path, help=argparse.SUPPRESS)
    commands["check"].add_argument("--as-if", choices=[EXIT_ONLY])
    commands["check"].add_argument("--status", action="store_true")
    commands["check"].add_argument("--since", type=_parse_since)
    commands["check"].add_argument("--receipt", type=Path)
    commands["check"].add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None, *, now: Callable[[], float] = time.time,
         unit_active: UnitActive | None = None, out: TextIO | None = None, err: TextIO | None = None) -> int:
    out = sys.stdout if out is None else out
    err = sys.stderr if err is None else err
    try:
        args = _parser().parse_args(argv)
    except SystemExit as exc:
        return EXIT_USAGE if exc.code else EXIT_CONFORMANT
    relocate = {"etc": args.etc, "owner_state": args.owner_state, "lanes_state": args.lanes_state,
                "lanes_config": args.lanes_config, "systemd_dir": args.systemd_dir}
    if args.verb == "prestart":
        files = None
        if _DOMAIN.fullmatch(args.domain) and any(value is not None for value in relocate.values()):
            files = domain_files(args.domain, **relocate)
        return prestart(args.domain, symbol=args.symbol, producer=args.producer, roles_dir=args.roles_dir,
                        files=files, refusal_dir=args.refusal_dir, now=now, err=err)
    if _DOMAIN.fullmatch(args.domain) is None:
        print(f"exposure check: invalid domain {args.domain!r}", file=err)
        return EXIT_USAGE
    try:
        code, doc = check(args.domain, as_if=args.as_if, status=args.status, since=args.since,
                          receipt=args.receipt, roles_dir=args.roles_dir,
                          files=domain_files(args.domain, **relocate), now=now, unit_active=unit_active)
    except OSError as exc:  # the receipt could not be written: never report conformant without it
        print(f"exposure check: receipt not written ({type(exc).__name__}: {exc})", file=err)
        return EXIT_UNREADABLE
    for row in doc["producers"]:
        if row["on"] is not False:
            print(f"exposure check: {args.domain} {row['producer']} {row['symbol']} {row['source']} "
                  f"{'on' if row['on'] else 'unreadable'}", file=err)
    if args.json:
        print(json.dumps(doc, sort_keys=True), file=out)
    else:
        print(f"exposure check: {args.domain} role={doc['role']['state']}/{doc['role']['role']} "
              f"as_if={args.as_if} evaluated={doc['evaluated']} exit={code} "
              f"producers={doc['producers_total']}", file=out)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
