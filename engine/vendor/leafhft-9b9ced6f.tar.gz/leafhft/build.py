"""no git call on any hot path; identity is read once at process start."""
from __future__ import annotations

import os
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from types import MappingProxyType
from typing import Mapping


def _read_identity() -> Mapping[str, str | bool | int]:
    started_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    package_dir = ""
    sha = ""
    dirty = False
    try:
        package_dir = str(Path(__file__).resolve().parent.parent)
        candidate = os.environ.get("LEAFHFT_BUILD_SHA", "")
        if re.fullmatch(r"[0-9a-f]{40}", candidate):
            sha = candidate
            dirty = os.environ.get("LEAFHFT_BUILD_DIRTY", "").lower() in ("1", "true")
        else:
            command = ["git", "-c", f"safe.directory={package_dir}"]
            revision = subprocess.run(
                command + ["rev-parse", "HEAD"], cwd=package_dir,
                capture_output=True, text=True, check=True, timeout=2.5,
            )
            status = subprocess.run(
                command + ["status", "--porcelain", "--untracked-files=no"], cwd=package_dir,
                capture_output=True, text=True, check=True, timeout=2.5,
            )
            candidate = revision.stdout.strip()
            if revision.returncode == 0 and status.returncode == 0 and re.fullmatch(r"[0-9a-f]{40}", candidate):
                sha = candidate
                dirty = bool(status.stdout)
    except Exception:  # Identity must never prevent the process from starting.
        sha, dirty = "", False
    return MappingProxyType({
        "git_sha": sha,
        "dirty": dirty,
        "package_dir": package_dir,
        "unit": os.environ.get("LEAFHFT_UNIT", "")[:128],
        "pid": os.getpid(),
        "started_at": started_at,
    })


_IDENTITY = _read_identity()


def build_identity() -> Mapping[str, str | bool | int]:
    """Return the same immutable process-start snapshot on every call."""
    return _IDENTITY
