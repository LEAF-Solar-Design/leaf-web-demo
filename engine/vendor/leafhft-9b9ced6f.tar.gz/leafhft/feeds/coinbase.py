"""Coinbase public level2, market_trades and heartbeats (no authentication).

Level2 snapshots and absolute updates drive BBO quotes between trades. Bounded books
reset on missing snapshots or connection sequence gaps. market_trades.side is the maker
side; its opposite is the aggressor. Quote inference is diagnostic only. Recording
retains trade IDs, exchange event times and raw quote arrival times.
"""
from __future__ import annotations

import asyncio

import orjson
import websockets

from ..clock import now_ns, parse_rfc3339_ns
from ..types import MalformedInput, Quote, Side, Trade, to_price_i
from .base import Feed, guard

WS_URL = "wss://advanced-trade-ws.coinbase.com"
EXCHANGE_WS_URL = "wss://ws-feed.exchange.coinbase.com"
COINBASE_MAX_MSG_BYTES = 32 * 1024 * 1024
MAX_BOOK_LEVELS = 100_000


class CoinbaseFeed(Feed):
    venue = "coinbase"

    def __init__(self, symbol: str, heartbeat_s: float = 20.0, url: str = WS_URL) -> None:
        super().__init__(symbol, heartbeat_s)
        self.url = url
        self._ws = None
        self._last_quote: Quote | None = None
        self._books: dict[str, dict[str, dict[int, int]]] = {}
        self._connection_sequence: int | None = None
        self._needs_reset = False
        self.oversize_prices = 0

    async def _run_once(self) -> None:
        async with websockets.connect(
            self.url, open_timeout=10, close_timeout=3, max_size=COINBASE_MAX_MSG_BYTES, ping_interval=20, ping_timeout=10
        ) as ws:
            self._ws = ws
            self._books.clear()
            self._last_quote = None
            self._connection_sequence = None
            self._needs_reset = False
            for ch in ("level2", "market_trades", "heartbeats"):
                sub = orjson.dumps({"type": "subscribe", "product_ids": [self.symbol], "channel": ch}).decode()
                await asyncio.wait_for(ws.send(sub), timeout=5)
            async for raw in ws:
                self._touch()
                self.handle(raw)
                if self._needs_reset:
                    await ws.close()
                    break
        self._ws = None

    async def _on_heartbeat_timeout(self) -> None:
        ws = self._ws
        if ws is not None:
            await ws.close()

    # ---- parsing (pure, testable) ---------------------------------------
    def handle(self, raw: str | bytes) -> None:
        arrival = now_ns()
        if self._needs_reset:
            return
        if len(raw) > COINBASE_MAX_MSG_BYTES:
            self._malformed("oversize message")
            return
        try:
            msg = orjson.loads(raw)
        except orjson.JSONDecodeError:
            self._malformed("bad json")
            return
        if not isinstance(msg, dict):
            self._malformed("non-object")
            return
        sequence = msg.get("sequence_num")
        if type(sequence) is int:
            if self._connection_sequence is not None and sequence != self._connection_sequence + 1:
                self._reset_book("level2 sequence gap")
                return
            self._connection_sequence = sequence
        ch = msg.get("channel")
        if ch == "l2_data":
            self._on_l2(msg, arrival)
        elif ch == "market_trades":
            self._on_trades(msg)
        # heartbeats / subscriptions: liveness only

    def _reset_book(self, why: str) -> None:
        if not self._needs_reset:
            self.stats.book_resets += 1
            self.stats.note_error(why)
        self._needs_reset = True
        self._books.clear()
        self._last_quote = None

    @guard
    def _on_l2(self, msg: dict, arrival: int) -> None:
        sequence = msg.get("sequence_num")
        if type(sequence) is not int or sequence < 0:
            self._reset_book("invalid level2 sequence")
            return
        ts = None
        try:
            for ev in msg["events"]:
                product = ev["product_id"]
                if product != self.symbol:
                    continue
                kind = ev["type"]
                if kind == "snapshot":
                    self._books[product] = {"bid": {}, "offer": {}}
                elif kind != "update":
                    raise MalformedInput(f"level2 event {kind!r}")
                if product not in self._books:
                    self._reset_book("level2 update before snapshot")
                    return
                book = self._books[product]
                for update in ev["updates"]:
                    side = update["side"]
                    if side not in ("bid", "offer"):
                        raise MalformedInput(f"level2 side {side!r}")
                    try:
                        price = to_price_i(update["price_level"])
                    except MalformedInput as exc:
                        # Range is checked only after decimal, sign and precision validation.
                        if not str(exc).startswith("price: out of range "):
                            raise
                        self.oversize_prices += 1
                        continue
                    size = self._size_i(update["new_quantity"])
                    ts = parse_rfc3339_ns(update["event_time"])
                    levels = book[side]
                    if size == 0:
                        levels.pop(price, None)
                    else:
                        if price not in levels and len(levels) >= MAX_BOOK_LEVELS:
                            self._reset_book("level2 level cap exceeded")
                            return
                        levels[price] = size
        except (MalformedInput, KeyError, TypeError, ValueError, IndexError):
            self._reset_book("malformed level2 book")
            raise
        book = self._books.get(self.symbol)
        if book is None or not book["bid"] or not book["offer"] or ts is None:
            return
        bid, ask = max(book["bid"]), min(book["offer"])
        if bid >= ask:
            self.stats.crossed_books += 1
            return
        best = (bid, book["bid"][bid], ask, book["offer"][ask])
        last = self._last_quote
        if last is not None and best == (last.bid_i, last.bid_size_i, last.ask_i, last.ask_size_i):
            return
        q = Quote(self.venue, self.symbol, *best, ts, now_ns(), self.next_seq(),
                  ts_arrival_ns=arrival)
        self._last_quote = q
        self._emit(q)

    @guard
    def _on_trades(self, msg: dict) -> None:
        recv = now_ns()
        for ev in msg["events"]:
            if ev.get("type") == "snapshot":
                continue  # historical prints, not live flow
            for tr in ev["trades"]:
                if tr.get("product_id") != self.symbol:
                    continue
                price_i = to_price_i(tr["price"])
                self._emit(
                    Trade(
                        self.venue,
                        self.symbol,
                        price_i,
                        self._size_i(tr["size"]),
                        self._infer_side(price_i, tr.get("side")),
                        parse_rfc3339_ns(tr["time"]),
                        recv,
                        self.next_seq(),
                        trade_id=tr.get("trade_id"),
                    )
                )

    def _infer_side(self, price_i: int, reported: object) -> Side:
        if reported == "BUY":
            side = Side.SELL
        elif reported == "SELL":
            side = Side.BUY
        else:
            raise MalformedInput(f"trade side {reported!r}")
        q = self._last_quote
        inferred = None
        if q is not None:
            if price_i >= q.ask_i:
                inferred = Side.BUY
            elif price_i <= q.bid_i:
                inferred = Side.SELL
        if inferred is not None and inferred is not side:
            self.stats.side_inference_disagreements += 1
        return side


class CoinbaseExchangeFeed(Feed):
    """Public Exchange channels only; level2_batch is batched every 50 ms by Coinbase.

    The public L2 feed carries no sequence number, so gaps cannot be detected.
    Book integrity relies on the per-connection snapshot and heartbeat-timeout
    reconnects.
    """

    venue = "coinbase"

    def __init__(self, symbol: str, heartbeat_s: float = 20.0, url: str = EXCHANGE_WS_URL) -> None:
        super().__init__(symbol, heartbeat_s)
        self.url = url
        self._ws = None
        self._last_quote: Quote | None = None
        self._books: dict[str, dict[str, dict[int, int]]] = {}
        self._needs_reset = False
        self.oversize_prices = 0

    # The maker-side diagnostic is identical after validating Exchange's lowercase side.
    _infer_side = CoinbaseFeed._infer_side

    async def _run_once(self) -> None:
        async with websockets.connect(
            self.url, open_timeout=10, close_timeout=3, max_size=COINBASE_MAX_MSG_BYTES, ping_interval=20, ping_timeout=10
        ) as ws:
            self._ws = ws
            self._books.clear()
            self._last_quote = None
            self._needs_reset = False
            sub = orjson.dumps({
                "type": "subscribe", "product_ids": [self.symbol],
                "channels": ["level2_batch", "matches", "heartbeat"],
            }).decode()
            await asyncio.wait_for(ws.send(sub), timeout=5)
            async for raw in ws:
                self._touch()
                self.handle(raw)
                if self._needs_reset:
                    await ws.close()
                    break
        self._ws = None

    async def _on_heartbeat_timeout(self) -> None:
        ws = self._ws
        if ws is not None:
            await ws.close()

    def handle(self, raw: str | bytes) -> None:
        arrival = now_ns()
        if self._needs_reset:
            return
        if len(raw) > COINBASE_MAX_MSG_BYTES:
            self._malformed("oversize message")
            return
        try:
            msg = orjson.loads(raw)
        except orjson.JSONDecodeError:
            self._malformed("bad json")
            return
        if not isinstance(msg, dict):
            self._malformed("non-object")
            return
        if "product_id" in msg and msg["product_id"] != self.symbol:
            return
        kind = msg.get("type")
        if kind in ("snapshot", "l2update"):
            self._on_l2(msg, arrival)
        elif kind == "match":
            self._on_match(msg)
        elif kind == "error":
            self._reset_book(f"Exchange error: {msg.get('message', '')}; {msg.get('reason', '')}")
        # last_match is historical; heartbeat / subscriptions are liveness only.

    def _reset_book(self, why: str) -> None:
        if not self._needs_reset:
            self.stats.book_resets += 1
            self.stats.note_error(why)
        self._needs_reset = True
        self._books.clear()
        self._last_quote = None

    def _apply_level(self, book: dict, side: str, price_raw, size_raw) -> None:
        try:
            price = to_price_i(price_raw)
        except MalformedInput as exc:
            if not str(exc).startswith("price: out of range "):
                raise
            self.oversize_prices += 1
            return
        size = self._size_i(size_raw)
        levels = book[side]
        if size == 0:
            levels.pop(price, None)
        else:
            if price not in levels and len(levels) >= MAX_BOOK_LEVELS:
                self._reset_book("level2 level cap exceeded")
                return
            levels[price] = size

    @guard
    def _on_l2(self, msg: dict, arrival: int) -> None:
        try:
            product = msg["product_id"]
            if product != self.symbol:
                return
            if msg["type"] == "snapshot":
                book = {"bid": {}, "offer": {}}
                self._books[product] = book
                self._last_quote = None
                for key, side in (("bids", "bid"), ("asks", "offer")):
                    rows = msg[key]
                    if not isinstance(rows, list):
                        raise MalformedInput("level2 snapshot levels must be a list")
                    for row in rows:
                        if not isinstance(row, list) or len(row) != 2:
                            raise MalformedInput("invalid level2 snapshot row")
                        self._apply_level(book, side, *row)
                        if self._needs_reset:
                            return
                return  # Exchange snapshots carry no event time.
            if product not in self._books:
                self._reset_book("level2 update before snapshot")
                return
            book = self._books[product]
            changes = msg["changes"]
            if not isinstance(changes, list):
                raise MalformedInput("level2 changes must be a list")
            for row in changes:
                if not isinstance(row, list) or len(row) != 3:
                    raise MalformedInput("invalid level2 change row")
                side, price, size = row
                if side not in ("buy", "sell"):
                    raise MalformedInput(f"level2 side {side!r}")
                self._apply_level(book, "bid" if side == "buy" else "offer", price, size)
                if self._needs_reset:
                    return
            ts = parse_rfc3339_ns(msg["time"])
        except (MalformedInput, KeyError, TypeError, ValueError, IndexError):
            self._reset_book("malformed level2 book")
            raise
        if not book["bid"] or not book["offer"]:
            return
        bid, ask = max(book["bid"]), min(book["offer"])
        if bid >= ask:
            self.stats.crossed_books += 1
            return
        best = (bid, book["bid"][bid], ask, book["offer"][ask])
        last = self._last_quote
        if last is not None and best == (last.bid_i, last.bid_size_i, last.ask_i, last.ask_size_i):
            return
        q = Quote(self.venue, self.symbol, *best, ts, now_ns(), self.next_seq(),
                  ts_arrival_ns=arrival)
        self._last_quote = q
        self._emit(q)

    @guard
    def _on_match(self, msg: dict) -> None:
        if msg["product_id"] != self.symbol:
            return
        maker = msg["side"]
        if maker not in ("buy", "sell"):
            raise MalformedInput(f"trade side {maker!r}")
        price = to_price_i(msg["price"])
        self._emit(Trade(
            self.venue, self.symbol, price, self._size_i(msg["size"]),
            self._infer_side(price, "BUY" if maker == "buy" else "SELL"),
            parse_rfc3339_ns(msg["time"]), now_ns(), self.next_seq(),
            trade_id=str(msg["trade_id"]),
        ))
