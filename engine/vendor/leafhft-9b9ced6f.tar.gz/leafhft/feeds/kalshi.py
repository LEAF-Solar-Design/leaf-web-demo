"""Kalshi signed WebSocket + REST discovery: trade, market_lifecycle_v2, orderbook_delta
(snapshot then deltas, gap forces a resnapshot), cfbenchmarks_value (CF Benchmarks), and
pyth_value (the exact Gold 15-minute settlement reference).

Wire shapes confirmed on the runner (2026-09-07, C:/tmp/leafhft-tf-runner-receipts/kalshi-shapes*.log,
read-only capture with the project's own signing): WS `wss://external-api-ws.kalshi.com/trade-api/ws/v2`
(demo `wss://external-api-ws.demo.kalshi.co/trade-api/ws/v2`), REST base
`https://api.elections.kalshi.com/trade-api/v2` (demo `https://external-api.demo.kalshi.co/trade-api/v2`).
Every request (WS handshake, REST call) carries KALSHI-ACCESS-KEY/-TIMESTAMP/-SIGNATURE, the
signature RSA-PSS-SHA256 over `timestamp + method + path` (path only, no query) with the account
private key. Frame envelope: `{"type": <channel>, "sid": <n>, "seq": <n>, "msg": {...}}`; `sid` scopes
`seq` ordering per subscription, so a delta whose `seq` is out of order for its own `sid` (not a
global counter) forces a resnapshot. REST markets carry `status` "active" (not "open"), dollar-string
prices/quantities on the WS (`orderbook_snapshot` ships `yes_dollars_fp`/`no_dollars_fp`,
`orderbook_delta` ships `price_dollars`/`delta_fp`, `trade` ships `yes_price_dollars`/`count_fp`), and
`cfbenchmarks_value` nests its point value as a JSON *string* under `data` plus a venue-computed
`avg_60s_data` running average. `ticker` frames were not observed in a 15s capture window: treated as
liveness-only, never required for quotes. `market_lifecycle_v2`'s frame shape was not captured; parsed
defensively (ticker/status/close_time if present, raw keys recorded once under `stats.lifecycle_keys`)
with the market's discovery-time close/strike/open used to backstop missing fields.

Series tickers: KXBTC15M is confirmed live (docs.kalshi.com). KXETH15M/KXBTC1H/KXETH1H below follow
the same naming convention (series prefix + tenor) but were not independently confirmed by a live
REST discovery call in this environment; verify with `GET /markets?series_ticker=KX{BTC,ETH}...`
once credentials are available and correct here first.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import os
import time
from collections import OrderedDict, deque
from threading import Lock

import aiohttp
import orjson
import websockets

from ..clock import now_ns, parse_rfc3339_ns
from ..types import (
    MalformedInput,
    MAX_SIZE_I,
    MAX_TS_NS,
    PRICE_UNIT,
    Quote,
    SIZE_SCALE,
    Side,
    Trade,
    _to_fixed,
    to_price_i,
    to_size_i,
)
from .base import Feed, IndexTick, IndexTickFast, Lifecycle, guard

WS_URL = "wss://external-api-ws.kalshi.com/trade-api/ws/v2"
WS_URL_DEMO = "wss://external-api-ws.demo.kalshi.co/trade-api/ws/v2"
WS_PATH = "/trade-api/ws/v2"
REST_URL = "https://api.elections.kalshi.com/trade-api/v2"
REST_URL_DEMO = "https://external-api.demo.kalshi.co/trade-api/v2"
REST_PATH_PREFIX = "/trade-api/v2"

KALSHI_MAX_MSG_BYTES = 64 * 1024
MAX_MARKETS = 50
DISCOVERY_PERIOD_S = 60.0
MAX_DISCOVERY_PAGES = 10
DISCOVERY_BUDGET_S = 20.0
DISCOVERY_MAX_BODY_BYTES = 2 * 1024 * 1024
BACKOFF_MIN_S = 1.0
BACKOFF_MAX_S = 60.0
CODE4_RESUBSCRIBE_COOLDOWN_S = 60.0
RESNAPSHOT_COOLDOWN_S = 2.0
CRED_KEY_ID_ENV = "LEAFHFT_KALSHI_KEY_ID"
CRED_PEM_ENV = "LEAFHFT_KALSHI_PRIVATE_KEY_PEM"

# KXGOLD15M settlement source since 2026-09-17, confirmed by the series metadata
# on 2026-09-21. Pyth feed ID 3712 is informational, not a subscription parameter.
GOLD_PYTH_TICKER = "Metal.Index.1OZGOLD/USD"


class FeedStartError(RuntimeError):
    """start() precondition failure: missing/unusable signing dependency, malformed PEM, or
    missing credentials. Never raised from the reconnect loop, never carries key material."""


def _load_private_key(pem: str):
    """Import the signing dependency and parse the PEM once, before any connection is opened."""
    try:
        from cryptography.hazmat.primitives import serialization
    except ImportError as e:
        raise FeedStartError(
            f"kalshi feed requires the 'cryptography' package (pip install cryptography>=42): {e}"
        ) from e
    normalized = pem.replace("\\n", "\n").encode()
    try:
        return serialization.load_pem_private_key(normalized, password=None)
    except Exception as e:
        raise FeedStartError(f"kalshi feed private key ({CRED_PEM_ENV}) is malformed: {type(e).__name__}") from e


# symbol -> (series_ticker, index_id); see module docstring on discovery confidence for the last three.
# KXBTC1H/KXETH1H are 404 on /series; KXBTCD/KXETHD are the hourly above/below ladders;
# KXBTC/KXETH are range series (measured 2026-09-09).
# Live trading registry: keep recorder-only symbols out of selectors and cohorts.
SYMBOL_MAP: dict[str, tuple[str, str]] = {
    "BTC-15M": ("KXBTC15M", "BRTI"),
    "ETH-15M": ("KXETH15M", "ETHUSD_RTI"),
    "BTC-1H": ("KXBTCD", "BRTI"),
    "ETH-1H": ("KXETHD", "ETHUSD_RTI"),
    # Probed against the venue 2026-09-09 08:0xZ: two-sided book on shard 2 for each 15-minute
    # series below and each hourly ladder below. KXSOLD (SOL-1H) was left out, it had no
    # two-sided book at probe time.
    "BNB-15M": ("KXBNB15M", "BNBUSD_RTI"),
    "DOGE-15M": ("KXDOGE15M", "DOGEUSD_RTI"),
    "HYPE-15M": ("KXHYPE15M", "HYPEUSD_RTI"),
    "NEAR-15M": ("KXNEAR15M", "NEARUSD_RTI"),
    "SOL-15M": ("KXSOL15M", "SOLUSD_RTI"),
    "XRP-15M": ("KXXRP15M", "XRPUSD_RTI"),
    "ZEC-15M": ("KXZEC15M", "ZECUSD_RTI"),
    "BNB-1H": ("KXBNBD", "BNBUSD_RTI"),
    "HYPE-1H": ("KXHYPED", "HYPEUSD_RTI"),
    "XRP-1H": ("KXXRPD", "XRPUSD_RTI"),
}


# Feed construction supports recording these symbols without admitting them to live trading.
RECORDER_SYMBOL_MAP: dict[str, tuple[str, str]] = {
    "GOLD-15M": ("KXGOLD15M", GOLD_PYTH_TICKER),
}


def symbol_to_series(symbol: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    mapping = SYMBOL_MAP if symbol in SYMBOL_MAP else RECORDER_SYMBOL_MAP
    if symbol not in mapping:
        raise ValueError(f"unknown kalshi symbol {symbol!r}")
    series, index_id = mapping[symbol]
    return (series,), (index_id,)


def uses_fast_index(symbol: str) -> bool:
    # Mirrors the index-ID rule in kalshi_live_runtime.py:8707-8713.
    fast_index_ids = {symbol_to_series(name)[1][0] for name in
                      ("BTC-15M", "ETH-15M", "SOL-15M", "XRP-15M", "DOGE-15M")}
    try:
        index_ids = symbol_to_series(symbol)[1]
    except ValueError:
        return False
    return any(index_id in fast_index_ids for index_id in index_ids)


_SIGNING_KEYS: OrderedDict[bytes, object] = OrderedDict()
_SIGNING_KEYS_LOCK = Lock()
_SIGNING_KEYS_MAXSIZE = 16


def _signing_key(pem_text: str, load_key):
    """Cache parsed keys by digest; serialize misses, never hold the lock while signing."""
    pem = pem_text.encode()
    digest = hashlib.sha256(pem).digest()
    with _SIGNING_KEYS_LOCK:
        if digest in _SIGNING_KEYS:
            _SIGNING_KEYS.move_to_end(digest)
            return _SIGNING_KEYS[digest]
        key = load_key(pem, password=None)
        _SIGNING_KEYS[digest] = key
        if len(_SIGNING_KEYS) > _SIGNING_KEYS_MAXSIZE:
            _SIGNING_KEYS.popitem(last=False)
        return key


def sign(ts_ms: int, method: str, path: str, private_key_pem: str) -> str:
    """RSA-PSS-SHA256 over `timestamp + method + path` (path only, no query string)."""
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding

    key = _signing_key(private_key_pem.replace("\\n", "\n"), serialization.load_pem_private_key)
    message = f"{ts_ms}{method}{path}".encode()
    signature = key.sign(
        message,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=hashes.SHA256.digest_size),
        hashes.SHA256(),
    )
    return base64.b64encode(signature).decode()


def _to_ms(x: object) -> int | None:
    """Accept an ISO8601 timestamp or an already-numeric ms value; None on anything else."""
    if x is None:
        return None
    if isinstance(x, bool):
        return None
    if isinstance(x, (int, float)):
        return int(x)
    if isinstance(x, str):
        try:
            return parse_rfc3339_ns(x) // 1_000_000
        except ValueError:
            return None
    return None


DISCOVERY_HORIZON_MS = 24 * 60 * 60 * 1000
MARKET_CHANNELS = ("orderbook_delta", "trade", "market_lifecycle_v2")


# Ceiling used only to let _to_fixed's own shape/precision/digit-count validation run; the
# MAX_SIZE_I bound below it is enforced by clamping, never by rejection.
_SIZE_PARSE_CEILING = 10**30


def _to_size_i_clamped(x: str) -> tuple[int, bool]:
    """Parse a decimal size string; clamp to MAX_SIZE_I (returns clamped=True) instead of raising
    when the only problem is exceeding the bound. The venue rests up to ~2.1M contracts at the
    minimum price on some crypto markets (recorded 2026-09-09), which used to raise MalformedInput
    and discard the whole snapshot. Any other malformed shape (bad type, negative, too many
    decimals, oversize digit count) still raises MalformedInput."""
    i = _to_fixed(x, SIZE_SCALE, _SIZE_PARSE_CEILING, "size")
    if i > MAX_SIZE_I:
        return MAX_SIZE_I, True
    return i, False


def _to_signed_size_i_clamped(x: str) -> tuple[int, bool]:
    """Signed counterpart of `_to_size_i_clamped`, for orderbook_delta's `delta_fp`."""
    if not isinstance(x, str) or not x:
        raise MalformedInput(f"signed size: bad string {x!r}")
    neg = x[0] == "-"
    body = x[1:] if neg else x
    magnitude, clamped = _to_size_i_clamped(body)
    return (-magnitude if neg else magnitude), clamped


def parse_markets(rows: list) -> dict[str, dict]:
    """Filter REST /markets rows to active markets closing within the next 24h, keyed by ticker.

    A market past its close_time, or one closing more than 24h out, is dropped: the discovery
    refresh is the only clock a caller should trust for "is this tradable soon".
    """
    now_ms = now_ns() // 1_000_000
    horizon_ms = now_ms + DISCOVERY_HORIZON_MS
    out: dict[str, dict] = {}
    for r in rows:
        if not isinstance(r, dict):
            continue
        ticker = r.get("ticker")
        if not isinstance(ticker, str) or not ticker:
            continue
        if r.get("status") not in ("active", "open"):
            continue
        close_ms = _to_ms(r.get("close_time"))
        if close_ms is None or close_ms <= now_ms or close_ms > horizon_ms:
            continue
        open_ms = _to_ms(r.get("open_time")) or 0
        exp_ms = _to_ms(r.get("expiration_time"))
        if exp_ms is None:
            exp_ms = close_ms
        strike = r.get("floor_strike")
        if strike is None:
            strike = r.get("cap_strike")
        if strike is None:
            strike = r.get("strike")
        try:
            strike_i = to_price_i(str(strike)) if strike is not None else 0
        except MalformedInput:
            strike_i = 0
        strike_type = r.get("strike_type")
        if not isinstance(strike_type, str):
            strike_type = ""
        out[ticker] = {
            "close_ms": close_ms,
            "expiration_ms": exp_ms,
            "strike_i": strike_i,
            "strike_type": strike_type,
            "open_ms": open_ms,
        }
    return out


_NO_STRIKE_DISTANCE = 2**62  # sentinel: sorts after every known distance, ticker still breaks the tie


def diff_subscriptions(
    current: set, discovered: dict, cap: int = MAX_MARKETS, index_i: int | None = None
) -> tuple[list, list]:
    """Cap-aware diff: `desired` is always the `cap` soonest-closing discovered markets, with a
    same-close tie broken by distance from `index_i` to the entry's `strike_i` (nearest first) when
    both are known, else by ticker for determinism (a discovered entry with no close_ms sorts last;
    one with no strike_i, or when `index_i` is None, sorts after every entry whose distance is
    known). On a strike ladder (KXBTCD/KXETHD: 188 markets sharing one close_ms) every strike is
    otherwise an equally-soonest-closing candidate, so without this the tie fell to the ticker
    string and produced an arbitrary lexicographic slice with no two-sided book. Behaviour change
    from the naive "keep whatever is already subscribed" diff: a currently subscribed market that is
    still discovered but no longer among the `cap` soonest/nearest is DROPPED even though it remains
    tradable."""
    def sort_key(t):
        info = discovered[t]
        close_ms = info.get("close_ms")
        strike_i = info.get("strike_i")
        distance = abs(strike_i - index_i) if index_i and strike_i else _NO_STRIKE_DISTANCE
        return (close_ms is None, close_ms if close_ms is not None else 0, distance, t)

    desired = sorted(discovered, key=sort_key)[:cap]
    desired_set = set(desired)
    to_add = [t for t in desired if t not in current]
    to_drop = [t for t in current if t not in desired_set]
    return to_add, to_drop


class KalshiFeed(Feed):
    venue = "kalshi"

    def __init__(
        self,
        series: tuple[str, ...] = ("KXBTC15M",),
        index_ids: tuple[str, ...] = ("BRTI",),
        *,
        demo: bool = False,
        index_5hz: bool = False,
        key_id: str | None = None,
        private_key_pem: str | None = None,
        heartbeat_s: float = 20.0,
        discovery_period_s: float = DISCOVERY_PERIOD_S,
        ws_url: str | None = None,
        rest_url: str | None = None,
        quote_interval_ms: int = 100,
    ) -> None:
        if not series:
            raise ValueError("series required")
        if len(index_ids) > 50:
            raise ValueError("too many index ids")
        if isinstance(quote_interval_ms, bool) or not isinstance(quote_interval_ms, int):
            raise ValueError(f"quote_interval_ms must be an int: {quote_interval_ms!r}")
        if not (0 <= quote_interval_ms <= 60_000):
            raise ValueError(f"quote_interval_ms out of range [0, 60000]: {quote_interval_ms}")
        symbol = ",".join(series)
        super().__init__(symbol, heartbeat_s, backoff_min_s=BACKOFF_MIN_S, backoff_max_s=BACKOFF_MAX_S)
        self.series = tuple(series)
        self.index_ids = tuple(index_ids)
        self._last_pyth_source_ts_ms: dict[str, int] = {}
        self.index_5hz = index_5hz
        self.demo = demo
        self._key_id = key_id
        self._private_key_pem = private_key_pem
        self.discovery_period_s = discovery_period_s
        self.ws_url = ws_url or (WS_URL_DEMO if demo else WS_URL)
        self.rest_url = rest_url or (REST_URL_DEMO if demo else REST_URL)
        self._ws = None
        self._markets: dict[str, dict] = {}
        self._subscribed: set[str] = set()
        self._books: dict[str, dict] = {}
        self._needs_resnapshot: set[str] = set()
        self._last_resnapshot_request_mono: dict[str, float] = {}
        self._msg_id = 0
        self.resnapshots = 0
        self.resnapshot_requests = 0
        self.seq_gaps = 0
        self.oversize_levels = 0
        # channel -> subscription sid from the venue's "subscribed" reply, required to target an
        # existing subscription with update_subscription/unsubscribe instead of a bare channel list.
        self._channel_sids: dict[str, int] = {}
        self.code4_resubscribes = 0
        self.code12_errors = 0
        self._needs_full_resubscribe = False
        self._last_code4_resubscribe_mono: float | None = None
        self._chan_counts: dict[str, int] = {}
        self._delay_samples_ms: deque[float] = deque(maxlen=2000)
        self._book_last_update_mono: dict[str, float] = {}
        self._last_index_window_size: int | None = None
        # Quote throttle: at most one Quote per market per quote_interval_ms, never a lost update.
        self.quote_interval_ms = quote_interval_ms
        self._quote_interval_s = quote_interval_ms / 1000.0
        self._pending_quote: dict[str, dict] = {}
        self._last_quote_emit_mono: dict[str, float] = {}
        self._flush_handles: dict[str, asyncio.TimerHandle] = {}
        self.deltas_seen = 0
        # index id -> last value_i received on cfbenchmarks_value, used only as a discovery-time
        # tie-break (see _reference_index_i); never read per tick.
        self._last_index_i: dict[str, int] = {}
        # True when the last _refresh_discovery ran with no reference index yet an entry with a
        # known strike_i existed: the slice was chosen by ticker order, not by distance, and needs
        # one re-centre once an index arrives. _needs_recentre is the loop-facing trigger set by
        # _on_index; both are cleared together once the recentre refresh runs.
        self._slice_without_index = False
        self._needs_recentre = False
        self.recentres = 0
        self.discovery_runs = 0
        self.discovery_pages_last = 0
        self.discovery_rows_last = 0
        self.discovery_incomplete = 0
        self.discovery_incomplete_last: tuple[str, ...] = ()

    # ---- credentials ----------------------------------------------------
    def _credentials(self) -> tuple[str, str]:
        key_id = self._key_id or os.environ.get(CRED_KEY_ID_ENV, "")
        pem = self._private_key_pem or os.environ.get(CRED_PEM_ENV, "")
        if not key_id or not pem:
            raise FeedStartError(f"kalshi feed requires {CRED_KEY_ID_ENV} and {CRED_PEM_ENV} to be set")
        return key_id, pem.replace("\\n", "\n")

    async def start(self) -> None:
        # Fail closed before any connection attempt: a missing dependency or an unusable key is a
        # startup defect, never a per-connect error the supervisor should retry forever.
        _, pem = self._credentials()
        _load_private_key(pem)
        await super().start()

    def _auth_headers(self, method: str, path: str) -> dict[str, str]:
        key_id, pem = self._credentials()
        ts_ms = int(time.time() * 1000)
        return {
            "KALSHI-ACCESS-KEY": key_id,
            "KALSHI-ACCESS-TIMESTAMP": str(ts_ms),
            "KALSHI-ACCESS-SIGNATURE": sign(ts_ms, method, path, pem),
        }

    # ---- lifecycle --------------------------------------------------------
    async def _run_once(self) -> None:
        key_id, pem = self._credentials()
        ts_ms = int(time.time() * 1000)
        headers = {
            "KALSHI-ACCESS-KEY": key_id,
            "KALSHI-ACCESS-TIMESTAMP": str(ts_ms),
            "KALSHI-ACCESS-SIGNATURE": sign(ts_ms, "GET", WS_PATH, pem),
        }
        async with websockets.connect(
            self.ws_url, additional_headers=headers, open_timeout=10, close_timeout=3,
            max_size=KALSHI_MAX_MSG_BYTES, ping_interval=20, ping_timeout=10,
        ) as ws:
            self._ws = ws
            self._subscribed.clear()
            self._books.clear()
            self._needs_resnapshot.clear()
            self._last_resnapshot_request_mono.clear()
            self._channel_sids.clear()
            self._needs_full_resubscribe = False
            self._needs_recentre = False
            for t in list(self._flush_handles):
                self._cancel_scheduled_flush(t)
            self._pending_quote.clear()
            self._last_quote_emit_mono.clear()
            await self._refresh_discovery()
            await self._subscribe_reference_feeds()
            last_discovery = time.monotonic()
            while True:
                remaining = self.discovery_period_s - (time.monotonic() - last_discovery)
                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=max(0.05, remaining))
                except asyncio.TimeoutError:
                    await self._refresh_discovery()
                    last_discovery = time.monotonic()
                    continue
                self._touch()
                self.handle_ws(raw)
                # Checked every iteration, not only on a socket timeout: a busy socket (quotes
                # flowing) never times out, so a period check gated on the timeout branch alone
                # never fires while the venue is live, the bug this loop exists to fix.
                if time.monotonic() - last_discovery >= self.discovery_period_s:
                    await self._refresh_discovery()
                    last_discovery = time.monotonic()
                if self._needs_recentre:
                    self._needs_recentre = False
                    self._slice_without_index = False
                    self.recentres += 1
                    await self._refresh_discovery()
                    last_discovery = time.monotonic()
                if self._needs_full_resubscribe:
                    self._needs_full_resubscribe = False
                    await self._full_resubscribe()
                if self._needs_resnapshot:
                    await self._resnapshot_pending()
        self._ws = None

    async def _on_heartbeat_timeout(self) -> None:
        ws = self._ws
        if ws is not None:
            await ws.close()

    # ---- discovery ----------------------------------------------------
    def _reference_index_i(self) -> int | None:
        """The last index value received for this feed's first configured index id, or None before
        one arrives or when the feed carries no index. Used only as the strike-distance tie-break
        in diff_subscriptions, computed once per discovery refresh, never per tick."""
        if not self.index_ids:
            return None
        return self._last_index_i.get(self.index_ids[0])

    async def _discover_once(self) -> dict[str, dict]:
        started = time.monotonic()
        self.discovery_pages_last = 0
        self.discovery_rows_last = 0
        self.discovery_incomplete_last = ()
        found: dict[str, dict] = {}
        incomplete: list[str] = []
        path = f"{REST_PATH_PREFIX}/markets"
        # bounded: MAX_DISCOVERY_PAGES per series and DISCOVERY_BUDGET_S per pass; an incomplete series never shrinks what is known.
        async with aiohttp.ClientSession() as session:
            for series in self.series:
                series_found: dict[str, dict] = {}
                cursor = None
                seen_cursors: set[str] = set()
                reason = None
                for _ in range(MAX_DISCOVERY_PAGES):
                    remaining = DISCOVERY_BUDGET_S - (time.monotonic() - started)
                    if remaining <= 0:
                        reason = "budget"
                        break
                    params = {"series_ticker": series, "status": "open", "limit": 200}
                    if cursor is not None:
                        params["cursor"] = cursor
                    timeout = aiohttp.ClientTimeout(total=max(0.5, min(10.0, remaining)))
                    try:
                        headers = self._auth_headers("GET", path)
                        async with session.get(
                            f"{self.rest_url}/markets", params=params, headers=headers, timeout=timeout,
                        ) as resp:
                            self.discovery_pages_last += 1
                            if resp.status != 200:
                                reason = f"http {resp.status}"
                                break
                            body = await resp.content.read(DISCOVERY_MAX_BODY_BYTES + 1)
                            if len(body) > DISCOVERY_MAX_BODY_BYTES:
                                self._malformed("oversize discovery body")
                                reason = "oversize"
                                break
                            data = orjson.loads(body)
                        rows = data.get("markets") if isinstance(data, dict) else None
                        if not isinstance(rows, list):
                            reason = "malformed"
                            break
                        self.discovery_rows_last += len(rows)
                        series_found.update(parse_markets(rows))
                        cursor = data.get("cursor")
                        if not rows or cursor is None or cursor == "":
                            break
                        if not isinstance(cursor, str):
                            reason = "malformed"
                            break
                        if cursor in seen_cursors:
                            break
                        seen_cursors.add(cursor)
                    except orjson.JSONDecodeError:
                        reason = "malformed"
                        break
                    except Exception as e:
                        reason = type(e).__name__
                        break
                else:
                    reason = "page_cap"
                if reason is not None:
                    incomplete.append(series)
                    self.stats.note_error(f"discovery incomplete {series}: {reason}")
                    found.update({
                        ticker: info for ticker, info in self._markets.items()
                        if ticker.startswith(f"{series}-")
                    })
                found.update(series_found)
        self.discovery_incomplete_last = tuple(incomplete)
        if incomplete:
            self.discovery_incomplete += 1
        return found

    async def _refresh_discovery(self) -> None:
        self.discovery_runs += 1
        discovered = await self._discover_once()
        self._markets = discovered
        index_i = self._reference_index_i()
        self._slice_without_index = index_i is None and any(
            info.get("strike_i") for info in discovered.values()
        )
        to_add, to_drop = diff_subscriptions(
            self._subscribed, discovered, MAX_MARKETS, index_i=index_i
        )
        if to_drop:
            await self._update_market_subscription("delete_markets", to_drop)
            for t in to_drop:
                self._subscribed.discard(t)
                self._books.pop(t, None)
                self._needs_resnapshot.discard(t)
                self._last_resnapshot_request_mono.pop(t, None)
                self._book_last_update_mono.pop(t, None)
                self._cancel_scheduled_flush(t)
                self._pending_quote.pop(t, None)
                self._last_quote_emit_mono.pop(t, None)
        if to_add:
            await self._update_market_subscription("add_markets", to_add)
            for t in to_add:
                self._subscribed.add(t)
                info = discovered.get(t, {})
                self._emit(
                    Lifecycle(
                        t,
                        "active",
                        int(info.get("close_ms", 0)),
                        int(info.get("expiration_ms", 0)),
                        int(info.get("strike_i", 0)),
                        info.get("strike_type", ""),
                        int(info.get("open_ms", 0)),
                        ts_recv_ns=now_ns(),
                    )
                )

    async def _resnapshot_pending(self) -> None:
        """Recover a market with no (or a stale) book via the venue's documented action on the
        existing orderbook subscription, never via unsubscribe: `unsubscribe {channels,
        market_tickers}` is unconditionally rejected with error 4 ("Subscription IDs required"),
        confirmed on the runner 2026-09-09 (C:/tmp/roll-probe3-result.txt)."""
        pending = list(self._needs_resnapshot)
        self._needs_resnapshot.clear()
        if not pending:
            return
        sid = self._channel_sids.get("orderbook_delta")
        if sid is not None:
            await self._send_cmd(
                "update_subscription",
                {"sid": sid, "market_tickers": pending, "action": "get_snapshot"},
            )
        else:
            await self._send_cmd("subscribe", {"channels": ["orderbook_delta"], "market_tickers": pending})
        self.resnapshot_requests += 1

    async def _update_market_subscription(self, action: str, tickers: list[str]) -> None:
        """Target the existing market-data subscription by sid when every channel's sid is known.
        The venue requires exactly one subscription id per update_subscription call (sending every
        sid at once returns error code 12, "Exactly one subscription ID is required"), so this sends
        one command per sid, never a `sids` list. Falls back to a plain subscribe/unsubscribe (the
        only option before any sid is known, e.g. the very first discovery pass on a fresh
        connection)."""
        if not tickers:
            return
        sids = [self._channel_sids[c] for c in MARKET_CHANNELS if c in self._channel_sids]
        if len(sids) == len(MARKET_CHANNELS):
            for sid in sids:
                await self._send_cmd(
                    "update_subscription",
                    {"sid": sid, "market_tickers": tickers, "action": action},
                )
        else:
            cmd = "subscribe" if action == "add_markets" else "unsubscribe"
            await self._send_cmd(cmd, {"channels": MARKET_CHANNELS, "market_tickers": tickers})

    async def _full_resubscribe(self) -> None:
        """Recover from a venue code 4 ("Subscription IDs required"): our sids are stale or
        unknown, so drop them and resubscribe from scratch. The targets are the desired capped set
        computed fresh from the last discovery (self._markets) via the same soonest-closing rule as
        diff_subscriptions, not the possibly-stale self._subscribed, so a resubscribe after a
        discovery change still holds the cap soonest-closing markets."""
        self._channel_sids.clear()
        desired, _ = diff_subscriptions(set(), self._markets, MAX_MARKETS, index_i=self._reference_index_i())
        if desired:
            await self._send_cmd("subscribe", {"channels": MARKET_CHANNELS, "market_tickers": desired})
        self._subscribed = set(desired)
        await self._subscribe_reference_feeds()

    async def _subscribe_reference_feeds(self) -> None:
        cf_ids = [i for i in self.index_ids if i != GOLD_PYTH_TICKER]
        pyth_ids = [i for i in self.index_ids if i == GOLD_PYTH_TICKER]
        if cf_ids:
            await self._send_cmd("subscribe", {"channels": ["cfbenchmarks_value"], "index_ids": cf_ids})
            if self.index_5hz:
                await self._send_cmd("subscribe", {"channels": ["cfbenchmarks_value_5hz"], "index_ids": cf_ids})
        if pyth_ids:
            await self._send_cmd("subscribe", {"channels": ["pyth_value"], "underlying_tickers": pyth_ids})

    async def _send_cmd(self, cmd: str, params: dict) -> None:
        self._msg_id += 1
        payload = orjson.dumps({"id": self._msg_id, "cmd": cmd, "params": params}).decode()
        await asyncio.wait_for(self._ws.send(payload), timeout=5)

    # ---- parsing (pure, testable) ---------------------------------------
    def handle_ws(self, raw: str | bytes) -> None:
        arrival = now_ns()
        if len(raw) > KALSHI_MAX_MSG_BYTES:
            self._malformed("oversize message")
            return
        try:
            msg = orjson.loads(raw)
        except orjson.JSONDecodeError:
            self._malformed("bad json")
            return
        if not isinstance(msg, dict):
            self._malformed("non-object")
            return
        t = msg.get("type")
        if isinstance(t, str):
            self._chan_counts[t] = self._chan_counts.get(t, 0) + 1
        if t == "trade":
            self._on_trade(msg)
        elif t == "orderbook_snapshot":
            self._on_snapshot(msg, arrival)
        elif t == "orderbook_delta":
            self._on_delta(msg, arrival)
        elif t == "market_lifecycle_v2":
            self._on_lifecycle(msg, arrival)
        elif t == "cfbenchmarks_value":
            self._on_index(msg)
        elif t == "pyth_value":
            self._on_pyth(msg)
        elif t == "cfbenchmarks_value_5hz":
            if self.index_5hz:
                self._on_index_fast(msg)
        elif t == "error":
            self._on_error(msg)
        elif t == "subscribed":
            self._on_subscribed(msg)
        # "ticker" (price-only, sizes come from orderbook_delta): liveness only

    def _on_subscribed(self, msg: dict) -> None:
        """Record the venue-assigned sid per channel so a later add/drop can target the existing
        subscription instead of re-sending a bare channel list (see _update_market_subscription)."""
        d = msg.get("msg")
        if not isinstance(d, dict):
            return
        channel = d.get("channel")
        sid = d.get("sid")
        if channel in MARKET_CHANNELS and isinstance(sid, int) and not isinstance(sid, bool):
            self._channel_sids[channel] = sid

    def _on_error(self, msg: dict) -> None:
        d = msg.get("msg")
        self.stats.note_error(f"kalshi error: {d}")
        code = d.get("code") if isinstance(d, dict) else None
        if code == 12:
            # "Exactly one subscription ID is required": a defect signal (a caller sent a `sids`
            # list or a stale/duplicate sid), counted but never a resubscribe trigger, to avoid a
            # resubscribe storm on a code the venue can return repeatedly.
            self.code12_errors += 1
            return
        if code != 4:
            return  # only "Subscription IDs required" (code 4) triggers a resubscribe
        now_mono = time.monotonic()
        last = self._last_code4_resubscribe_mono
        if last is not None and now_mono - last < CODE4_RESUBSCRIBE_COOLDOWN_S:
            return  # already resubscribing (or just did): never loop on a repeated code 4
        self._last_code4_resubscribe_mono = now_mono
        self.code4_resubscribes += 1
        self._needs_full_resubscribe = True

    @guard
    def _on_trade(self, msg: dict) -> None:
        d = msg["msg"]
        ticker = d["market_ticker"]
        recv = now_ns()
        side_s = d.get("taker_side")
        if side_s == "yes":
            side = Side.BUY
        elif side_s == "no":
            side = Side.SELL
        else:
            raise MalformedInput(f"trade taker_side {side_s!r}")
        price_i = to_price_i(str(d["yes_price_dollars"]))
        size_i = to_size_i(str(d["count_fp"]))
        if d.get("ts_ms") is not None:
            ts_ns = _to_fixed(d["ts_ms"], 6, MAX_TS_NS, "trade ts_ms")
        elif d.get("ts") is not None:
            ts_ns = _to_fixed(d["ts"], 9, MAX_TS_NS, "trade ts")
        else:
            ts_ns = recv
        self._emit(Trade(self.venue, ticker, price_i, size_i, side, ts_ns, recv, self.next_seq(),
                         trade_id=d.get("trade_id")))

    def _parse_book_rows(self, rows: list) -> dict[int, int]:
        out: dict[int, int] = {}
        for row in rows:
            if not (isinstance(row, list) and len(row) == 2):
                raise MalformedInput(f"book row shape {row!r}")
            price_i = to_price_i(str(row[0]))
            size_i, clamped = _to_size_i_clamped(str(row[1]))
            if clamped:
                self.oversize_levels += 1
                self.stats.oversize_sizes += 1
            if size_i > 0:
                out[price_i] = size_i
        return out

    @guard
    def _on_snapshot(self, msg: dict, arrival: int | None = None) -> None:
        arrival = now_ns() if arrival is None else arrival
        d = msg["msg"]
        ticker = d["market_ticker"]
        yes_rows = d.get("yes_dollars_fp", [])
        no_rows = d.get("no_dollars_fp", [])
        if not isinstance(yes_rows, list) or not isinstance(no_rows, list):
            raise MalformedInput("orderbook_snapshot book not a list")
        yes = self._parse_book_rows(yes_rows)
        no = self._parse_book_rows(no_rows)
        sid = msg.get("sid")
        seq = int(msg.get("seq", 0))
        previous = self._books.get(ticker)
        if previous is not None and previous["yes"] == yes and previous["no"] == no:
            arrival = previous.get("arrival_ns", arrival)
        self._books[ticker] = {"yes": yes, "no": no, "sid": sid, "seq": seq, "ready": True,
                               "arrival_ns": arrival, "venue_ns": None}
        self._book_last_update_mono[ticker] = time.monotonic()
        self._emit_quote(ticker)

    def _maybe_request_resnapshot(self, ticker: str) -> None:
        """A gap EVENT (book missing, or just marked not ready) is counted and queued for
        resnapshot at most once per ticker per RESNAPSHOT_COOLDOWN_S: a burst of deltas arriving
        while a resnapshot is already in flight is dropped silently, never re-counted and never
        re-queued, so one gap costs one resnapshot command, not one per delta."""
        now_mono = time.monotonic()
        last = self._last_resnapshot_request_mono.get(ticker)
        if last is not None and now_mono - last < RESNAPSHOT_COOLDOWN_S:
            return
        if last is None:
            expired = [
                t for t, requested_at in self._last_resnapshot_request_mono.items()
                if now_mono - requested_at >= RESNAPSHOT_COOLDOWN_S
            ]
            for t in expired:
                self._last_resnapshot_request_mono.pop(t)
            # Never evict an active cooldown to make room for an unknown ticker.
            if len(self._last_resnapshot_request_mono) >= 2 * MAX_MARKETS:
                return
        self._last_resnapshot_request_mono[ticker] = now_mono
        self.seq_gaps += 1
        self.resnapshots += 1
        self._needs_resnapshot.add(ticker)

    @guard
    def _on_delta(self, msg: dict, arrival: int | None = None) -> None:
        arrival = now_ns() if arrival is None else arrival
        d = msg["msg"]
        ticker = d["market_ticker"]
        sid = msg.get("sid")
        seq = int(msg.get("seq", 0))
        book = self._books.get(ticker)
        if book is None:
            # a delta for a market we hold no snapshot for: resubscribe to get one, rate-limited.
            self._maybe_request_resnapshot(ticker)
            return
        if not book["ready"]:
            self._maybe_request_resnapshot(ticker)  # resnapshot already pending, rate-limited
            return
        if sid != book["sid"] or seq != book["seq"] + 1:
            # seq ordering is scoped per sid: a jump within a sid, or an unexpected sid, is a gap.
            book["ready"] = False
            self._maybe_request_resnapshot(ticker)
            return
        # Only delta ts_ms is venue time; missing stamps never fall back to a local clock.
        venue_ns = (_to_fixed(d["ts_ms"], 6, MAX_TS_NS, "delta ts_ms")
                    if d.get("ts_ms") is not None else None)
        book["seq"] = seq
        side = d["side"]
        if side == "yes":
            side_book = book["yes"]
        elif side == "no":
            side_book = book["no"]
        else:
            raise MalformedInput(f"delta side {side!r}")
        price_i = to_price_i(str(d["price_dollars"]))
        delta_i, clamped = _to_signed_size_i_clamped(str(d["delta_fp"]))
        if clamped:
            self.oversize_levels += 1
            self.stats.oversize_sizes += 1
        new_size = side_book.get(price_i, 0) + delta_i
        new_size = max(0, min(MAX_SIZE_I, new_size))
        if new_size != side_book.get(price_i, 0):
            book["arrival_ns"] = arrival
            book["venue_ns"] = venue_ns
        if new_size <= 0:
            side_book.pop(price_i, None)
        else:
            side_book[price_i] = new_size
        self._book_last_update_mono[ticker] = time.monotonic()
        self._emit_quote(ticker)

    @guard
    def _emit_quote(self, ticker: str) -> None:
        """Compute the best-of-book on any change and hand it to the throttle: at most one Quote
        per market per quote_interval_ms goes out, always carrying the latest best (never a stale
        one), and a change withheld by the interval is never dropped, only delayed to the next
        tick boundary."""
        self.deltas_seen += 1
        book = self._books.get(ticker)
        if book is None or not book["ready"] or not book["yes"] or not book["no"]:
            return
        best_yes_bid_i = max(book["yes"])
        best_no_bid_i = max(book["no"])
        ask_i = PRICE_UNIT - best_no_bid_i  # yes ask = 1 - best no bid, in the same price_i fixed point
        if ask_i <= best_yes_bid_i:
            return  # crossed/degenerate implied book: skip rather than force a Quote invariant violation
        self._pending_quote[ticker] = {
            "bid_i": best_yes_bid_i,
            "bid_size_i": book["yes"][best_yes_bid_i],
            "ask_i": ask_i,
            "ask_size_i": book["no"][best_no_bid_i],
            "ts_arrival_ns": book.get("arrival_ns"),
            "ts_venue_ns": book.get("venue_ns"),
        }
        self._throttled_flush(ticker)

    def _throttled_flush(self, ticker: str) -> None:
        now_mono = time.monotonic()
        last = self._last_quote_emit_mono.get(ticker)
        if last is None or now_mono - last >= self._quote_interval_s:
            self._flush_pending_quote(ticker, now_mono)
        else:
            self._schedule_flush(ticker, last + self._quote_interval_s - now_mono)

    def _flush_pending_quote(self, ticker: str, now_mono: float) -> None:
        self._cancel_scheduled_flush(ticker)
        kwargs = self._pending_quote.pop(ticker, None)
        if kwargs is None:
            return
        self._last_quote_emit_mono[ticker] = now_mono
        recv = now_ns()
        self._emit(
            Quote(
                self.venue,
                ticker,
                kwargs["bid_i"],
                kwargs["bid_size_i"],
                kwargs["ask_i"],
                kwargs["ask_size_i"],
                recv,
                recv,
                self.next_seq(),
                ts_arrival_ns=kwargs["ts_arrival_ns"],
                ts_venue_ns=kwargs["ts_venue_ns"],
            )
        )

    def _schedule_flush(self, ticker: str, delay_s: float) -> None:
        """Guarantee the bounded delay in production (a live socket always has a running loop);
        a no-op outside one (e.g. a synchronous unit test) since the next state change or an
        explicit flush check then carries the pending quote instead."""
        self._cancel_scheduled_flush(ticker)
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        self._flush_handles[ticker] = loop.call_later(max(0.0, delay_s), self._fire_scheduled_flush, ticker)

    def _fire_scheduled_flush(self, ticker: str) -> None:
        self._flush_handles.pop(ticker, None)
        if ticker in self._pending_quote:
            self._flush_pending_quote(ticker, time.monotonic())

    def _cancel_scheduled_flush(self, ticker: str) -> None:
        handle = self._flush_handles.pop(ticker, None)
        if handle is not None:
            handle.cancel()

    @guard
    def _on_lifecycle(self, msg: dict, arrival: int | None = None) -> None:
        arrival = now_ns() if arrival is None else arrival
        d = msg["msg"]
        if not isinstance(d, dict):
            raise MalformedInput("lifecycle msg not an object")
        if not self.stats.lifecycle_keys:
            self.stats.lifecycle_keys = tuple(sorted(d.keys()))
        ticker = d.get("market_ticker") or d.get("ticker")
        if not isinstance(ticker, str) or not ticker:
            return  # unidentifiable frame: keys are already recorded above, nothing to emit
        status = d.get("status")
        if not isinstance(status, str) or not status:
            status = "unknown"
        close_ms = _to_ms(d.get("close_time"))
        market = self._markets.get(ticker, {})
        close_final = close_ms if close_ms is not None else market.get("close_ms", 0)
        exp_final = market.get("expiration_ms") or close_final
        self._emit(
            Lifecycle(
                ticker,
                status,
                int(close_final),
                int(exp_final),
                int(market.get("strike_i", 0)),
                market.get("strike_type", ""),
                int(market.get("open_ms", 0)),
                ts_recv_ns=arrival,
            )
        )

    @guard
    def _on_pyth(self, msg: dict) -> None:
        """Normalize Kalshi's Pyth USD point value; this channel supplies no 60s average.

        Wire contract: https://docs.kalshi.com/websockets/pyth-value
        """
        d = msg["msg"]
        index_id = d["underlying_ticker"]
        if index_id != GOLD_PYTH_TICKER or index_id not in self.index_ids:
            return
        value_i = to_price_i(d["value_usd"])
        tick = IndexTick(index_id, value_i, d["source_ts_ms"], d["received_at"], now_ns())
        last_source = self._last_pyth_source_ts_ms.get(index_id)
        if last_source is not None and tick.source_ts_ms <= last_source:
            return
        self._last_pyth_source_ts_ms[index_id] = tick.source_ts_ms
        self._last_index_i[index_id] = value_i
        if self._slice_without_index and self._reference_index_i() is not None:
            self._needs_recentre = True
        self._delay_samples_ms.append(tick.local_ns / 1_000_000 - tick.received_at_ms)
        self._last_index_window_size = None
        self._emit(tick)

    @guard
    def _on_index_fast(self, msg: dict) -> None:
        d = msg["msg"]
        index_id = d["index_id"]
        if index_id == GOLD_PYTH_TICKER or index_id not in self.index_ids:
            return
        received_at_ms = int(d["received_at"])
        raw_data = d["data"]
        if not isinstance(raw_data, str) or not raw_data or len(raw_data) > 1024:
            raise MalformedInput("cfbenchmarks_value_5hz data not a bounded string")
        try:
            inner = orjson.loads(raw_data)
        except orjson.JSONDecodeError as e:
            raise MalformedInput(f"cfbenchmarks_value_5hz data bad json: {e}") from e
        if not isinstance(inner, dict):
            raise MalformedInput("cfbenchmarks_value_5hz data not an object")
        value_i = to_price_i(str(inner["value"]))
        source_ts_ms = int(inner["time"])
        if "source_ts_ms" in d:
            source_ts_ms = int(d["source_ts_ms"])
        self._emit(IndexTickFast(self.venue, index_id, value_i, source_ts_ms,
                                 received_at_ms, now_ns(), self.next_seq()))

    @guard
    def _on_index(self, msg: dict) -> None:
        d = msg["msg"]
        index_id = d["index_id"]
        if index_id == GOLD_PYTH_TICKER or index_id not in self.index_ids:
            return
        received_at_ms = int(d["received_at"])
        raw_data = d["data"]
        if not isinstance(raw_data, str) or not raw_data or len(raw_data) > 1024:
            raise MalformedInput("cfbenchmarks_value data not a bounded string")
        try:
            inner = orjson.loads(raw_data)
        except orjson.JSONDecodeError as e:
            raise MalformedInput(f"cfbenchmarks_value data bad json: {e}") from e
        if not isinstance(inner, dict):
            raise MalformedInput("cfbenchmarks_value data not an object")
        value_i = to_price_i(str(inner["value"]))
        self._last_index_i[index_id] = value_i
        if self._slice_without_index and self._reference_index_i() is not None:
            self._needs_recentre = True
        source_ts_ms = int(inner["time"])
        local_ns = now_ns()
        self._delay_samples_ms.append(local_ns / 1_000_000 - received_at_ms)
        avg60_value_i = avg60_window_size = avg60_window_start_ms = None
        avg60 = d.get("avg_60s_data")
        if isinstance(avg60, dict):
            if "value" in avg60:
                try:
                    avg60_value_i = to_price_i(str(avg60["value"]))
                except MalformedInput:
                    avg60_value_i = None
            ws = avg60.get("window_size")
            if isinstance(ws, int) and not isinstance(ws, bool) and ws >= 0:
                avg60_window_size = ws
            wst = avg60.get("window_start_ts_ms")
            if isinstance(wst, (int, float)) and not isinstance(wst, bool) and wst >= 0:
                avg60_window_start_ms = int(wst)
        self._last_index_window_size = avg60_window_size
        self._emit(
            IndexTick(
                index_id,
                value_i,
                source_ts_ms,
                received_at_ms,
                local_ns,
                avg60_value_i,
                avg60_window_size,
                avg60_window_start_ms,
            )
        )

    def ready_tickers(self) -> frozenset[str]:
        """Return a detached view of books with an unbroken snapshot/delta chain."""
        return frozenset(ticker for ticker, book in self._books.items() if book["ready"])

    def last_message_age_s(self) -> float | None:
        """Monotonic age of the last upstream activity, or None before activity."""
        if self._last_msg_mono == 0.0:
            return None
        return max(0.0, time.monotonic() - self._last_msg_mono)

    # ---- quality ----------------------------------------------------------
    def quality(self) -> dict:
        delays = sorted(self._delay_samples_ms)
        n = len(delays)
        if n == 0:
            median_delay_ms = 0.0
        elif n % 2:
            median_delay_ms = delays[n // 2]
        else:
            median_delay_ms = (delays[n // 2 - 1] + delays[n // 2]) / 2
        now_mono = time.monotonic()
        close_mss = [
            self._markets[t]["close_ms"]
            for t in self._subscribed
            if t in self._markets and "close_ms" in self._markets[t]
        ]
        nearest_subscribed_close_ms = min(close_mss) if close_mss else 0
        strike_is = [
            self._markets[t]["strike_i"]
            for t in self._subscribed
            if t in self._markets and self._markets[t].get("strike_i")
        ]
        subscribed_strike_span = (max(strike_is) - min(strike_is)) if strike_is else 0
        return {
            "channels": dict(self._chan_counts),
            "reconnects": self.stats.reconnects,
            "seq_gaps": self.seq_gaps,
            "resnapshots": self.resnapshots,
            "resnapshot_requests": self.resnapshot_requests,
            "oversize_levels": self.oversize_levels,
            "oversize_sizes": self.oversize_sizes,
            "code4_resubscribes": self.code4_resubscribes,
            "code12_errors": self.code12_errors,
            "nearest_subscribed_close_ms": nearest_subscribed_close_ms,
            "subscribed_strike_span": subscribed_strike_span,
            "index_ticks": self.stats.index_ticks,
            "index_fast_ticks": self.stats.index_fast_ticks,
            "median_receipt_delay_ms": median_delay_ms,
            "subscribed_markets": len(self._subscribed),
            "market_subscriptions": {t: len(MARKET_CHANNELS) for t in self._subscribed},
            "book_age_ms": {t: (now_mono - ts) * 1000.0 for t, ts in self._book_last_update_mono.items()},
            "index_window_size": self._last_index_window_size,
            "deltas_seen": self.deltas_seen,
            "quotes_emitted": self.stats.quotes,
            "recentres": self.recentres,
            "discovery_runs": self.discovery_runs,
        }
