"""Feed base: bounded queue between the network task and the engine, drop-oldest on overflow
(a stale quote is worthless; a blocked socket is a dead feed), reconnect with capped backoff,
and a heartbeat watchdog so a silent socket is detected inside `heartbeat_s`."""
from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from typing import AsyncIterator

from ..types import MAX_SIZE_I, SIZE_SCALE, MalformedInput, Quote, Trade, _to_fixed

QUEUE_MAX = 4096
BACKOFF_MIN_S = 0.5
BACKOFF_MAX_S = 30.0
MAX_MSG_BYTES = 1 << 20


def to_size_i_clamped(x) -> tuple[int, bool]:
    """Clamp only valid oversize quantities; retain fixed-point shape validation."""
    size_i = _to_fixed(x, SIZE_SCALE, 10**30, "size")
    return min(size_i, MAX_SIZE_I), size_i > MAX_SIZE_I


@dataclass(frozen=True, slots=True)
class IndexTick:
    """A CF Benchmarks index value tick (e.g. Kalshi's BRTI), not a tradable market Quote/Trade."""

    index_id: str
    value_i: int
    source_ts_ms: int
    received_at_ms: int
    local_ns: int
    avg60_value_i: int | None = None
    avg60_window_size: int | None = None
    avg60_window_start_ms: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.index_id, str) or not self.index_id or len(self.index_id) > 32:
            raise MalformedInput(f"index_id: bad name {self.index_id!r}")
        for name, val in (
            ("value_i", self.value_i),
            ("source_ts_ms", self.source_ts_ms),
            ("received_at_ms", self.received_at_ms),
            ("local_ns", self.local_ns),
        ):
            if type(val) is not int or val < 0:
                raise MalformedInput(f"{name}: not a non-negative int: {val!r}")
        for name, val in (
            ("avg60_value_i", self.avg60_value_i),
            ("avg60_window_size", self.avg60_window_size),
            ("avg60_window_start_ms", self.avg60_window_start_ms),
        ):
            if val is not None and (type(val) is not int or val < 0):
                raise MalformedInput(f"{name}: not None or a non-negative int: {val!r}")


@dataclass(frozen=True, slots=True)
class IndexTickFast:
    """A recorder-only 5 Hz index predictor, never a settlement observation."""

    venue: str
    index_id: str
    value_i: int
    source_ts_ms: int
    received_at_ms: int
    ts_recv_ns: int
    seq: int

    def __post_init__(self) -> None:
        for name, val in (("venue", self.venue), ("index_id", self.index_id)):
            if not isinstance(val, str) or not val or len(val) > 32:
                raise MalformedInput(f"{name}: bad name {val!r}")
        for name, val in (
            ("value_i", self.value_i),
            ("source_ts_ms", self.source_ts_ms),
            ("received_at_ms", self.received_at_ms),
            ("ts_recv_ns", self.ts_recv_ns),
            ("seq", self.seq),
        ):
            if type(val) is not int or val < 0:
                raise MalformedInput(f"{name}: not a non-negative int: {val!r}")


@dataclass(frozen=True, slots=True)
class Lifecycle:
    """A market status transition (e.g. Kalshi market_lifecycle_v2): open/closed/settled."""

    ticker: str
    status: str
    close_time_ms: int
    expiration_time_ms: int
    strike_i: int
    strike_type: str = ""
    open_time_ms: int = 0
    # The frame's own receipt stamp, when the feed knows it; not part of the market's identity.
    ts_recv_ns: int | None = field(default=None, compare=False)

    def __post_init__(self) -> None:
        if not isinstance(self.ticker, str) or not self.ticker or len(self.ticker) > 64:
            raise MalformedInput(f"ticker: bad name {self.ticker!r}")
        if not isinstance(self.status, str) or not self.status or len(self.status) > 32:
            raise MalformedInput(f"status: bad name {self.status!r}")
        for name, val in (
            ("close_time_ms", self.close_time_ms),
            ("expiration_time_ms", self.expiration_time_ms),
            ("strike_i", self.strike_i),
            ("open_time_ms", self.open_time_ms),
        ):
            if type(val) is not int or val < 0:
                raise MalformedInput(f"{name}: not a non-negative int: {val!r}")
        if not isinstance(self.strike_type, str) or len(self.strike_type) > 32:
            raise MalformedInput(f"strike_type: bad value {self.strike_type!r}")
        if self.ts_recv_ns is not None and (type(self.ts_recv_ns) is not int or self.ts_recv_ns < 0):
            raise MalformedInput(f"ts_recv_ns: not None or a non-negative int: {self.ts_recv_ns!r}")


Event = Quote | Trade | IndexTick | IndexTickFast | Lifecycle


@dataclass(slots=True)
class FeedStats:
    connects: int = 0
    reconnects: int = 0
    disconnects: int = 0
    messages: int = 0
    quotes: int = 0
    trades: int = 0
    index_ticks: int = 0
    index_fast_ticks: int = 0
    lifecycles: int = 0
    dropped: int = 0
    malformed: int = 0
    oversize_sizes: int = 0
    book_resets: int = 0
    crossed_books: int = 0
    side_inference_disagreements: int = 0
    last_error: str = ""
    errors: list[str] = field(default_factory=list)
    lifecycle_keys: tuple[str, ...] = field(default_factory=tuple)

    def note_error(self, msg: str) -> None:
        self.last_error = msg[:200]
        if len(self.errors) < 50:
            self.errors.append(self.last_error)


_STOP = object()  # queue sentinel: stop() puts it so events() returns without waiting for a message


class Feed:
    """Subclasses implement `_run_once(self)`: connect, subscribe, and call `self._emit(ev)`
    until the socket closes or raises. Everything else (backoff, watchdog, queue) lives here."""

    venue: str = "base"

    def __init__(
        self,
        symbol: str,
        heartbeat_s: float = 20.0,
        backoff_min_s: float = BACKOFF_MIN_S,
        backoff_max_s: float = BACKOFF_MAX_S,
    ) -> None:
        if not symbol:
            raise ValueError("symbol required")
        if not (1.0 <= heartbeat_s <= 300.0):
            raise ValueError("heartbeat_s out of range")
        if not (0.0 < backoff_min_s <= backoff_max_s):
            raise ValueError("backoff bounds out of range")
        self.symbol = symbol
        self.heartbeat_s = heartbeat_s
        self.backoff_min_s = backoff_min_s
        self.backoff_max_s = backoff_max_s
        self.stats = FeedStats()
        self._q: asyncio.Queue[Event] = asyncio.Queue(maxsize=QUEUE_MAX)
        self._stop = asyncio.Event()
        self._task: asyncio.Task | None = None
        self._last_msg_mono = 0.0
        self._seq = 0

    # ---- lifecycle -----------------------------------------------------
    async def start(self) -> None:
        if self._task is not None:
            raise RuntimeError("feed already started")
        self._task = asyncio.create_task(self._supervise(), name=f"feed-{self.venue}-{self.symbol}")

    async def stop(self) -> None:
        self._stop.set()
        self._wake_consumer()
        if self._task is not None:
            self._task.cancel()
            try:
                await asyncio.wait_for(self._task, timeout=5)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
            self._task = None

    async def reconnect(self) -> None:
        """Restart after a consumer idle timeout, preserving queued market events."""
        self.stats.reconnects += 1
        await self.stop()
        # stop() wakes the old consumer. Its sentinel must not end the new one.
        queued = []
        while not self._q.empty():
            ev = self._q.get_nowait()
            if ev is not _STOP:
                queued.append(ev)
        for ev in queued:
            self._q.put_nowait(ev)
        self._stop.clear()
        self._last_msg_mono = time.monotonic()
        await self.start()

    async def _supervise(self) -> None:
        backoff = self.backoff_min_s
        while not self._stop.is_set():
            try:
                self.stats.connects += 1
                self._last_msg_mono = time.monotonic()
                watchdog = asyncio.create_task(self._watchdog())
                try:
                    await self._run_once()
                finally:
                    watchdog.cancel()
                backoff = self.backoff_min_s
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001 - any transport failure is a reconnect, never a crash
                self.stats.disconnects += 1
                self.stats.note_error(f"{type(e).__name__}: {e}")
            if self._stop.is_set():
                break
            await asyncio.sleep(backoff + random.uniform(0, backoff * 0.2))
            backoff = min(self.backoff_max_s, backoff * 2)

    async def _watchdog(self) -> None:
        while True:
            await asyncio.sleep(self.heartbeat_s / 2)
            if time.monotonic() - self._last_msg_mono > self.heartbeat_s:
                # Cancel the runner by raising in the supervisor: close the transport via the hook.
                self.stats.note_error("heartbeat timeout")
                await self._on_heartbeat_timeout()
                return

    async def _on_heartbeat_timeout(self) -> None:
        """Subclasses close their socket here so _run_once raises and the supervisor reconnects."""

    # ---- subclass hooks ------------------------------------------------
    async def _run_once(self) -> None:
        raise NotImplementedError

    def _touch(self) -> None:
        """Any well-formed message (heartbeat, subscription ack) proves the socket is alive."""
        self._last_msg_mono = time.monotonic()

    def _emit(self, ev: Event) -> None:
        self._last_msg_mono = time.monotonic()
        self.stats.messages += 1
        if isinstance(ev, Quote):
            self.stats.quotes += 1
        elif isinstance(ev, Trade):
            self.stats.trades += 1
        elif isinstance(ev, IndexTick):
            self.stats.index_ticks += 1
        elif isinstance(ev, IndexTickFast):
            self.stats.index_fast_ticks += 1
        elif isinstance(ev, Lifecycle):
            self.stats.lifecycles += 1
        if self._q.full():
            try:
                self._q.get_nowait()
                self.stats.dropped += 1
            except asyncio.QueueEmpty:
                pass
        self._q.put_nowait(ev)

    def _malformed(self, why: str) -> None:
        self.stats.malformed += 1
        self.stats.note_error(f"malformed: {why}")

    @property
    def oversize_sizes(self) -> int:
        return self.stats.oversize_sizes

    def _size_i(self, x) -> int:
        size_i, clamped = to_size_i_clamped(x)
        self.stats.oversize_sizes += int(clamped)
        return size_i

    def next_seq(self) -> int:
        self._seq += 1
        return self._seq

    # ---- consumer ------------------------------------------------------
    async def events(self, idle_timeout_s: float = 60.0) -> AsyncIterator[Event]:
        """Yield events until stop(); raises TimeoutError if nothing arrives for idle_timeout_s."""
        while not self._stop.is_set():
            try:
                ev = await asyncio.wait_for(self._q.get(), timeout=idle_timeout_s)
            except asyncio.TimeoutError as e:
                raise TimeoutError(f"feed {self.venue} idle for {idle_timeout_s}s") from e
            if ev is _STOP:
                return
            yield ev

    def _wake_consumer(self) -> None:
        """stop() must end events() NOW, not at the next message or the idle timeout: a dead feed
        would otherwise hold the engine's deadline and kill switch hostage for up to a minute.
        The sentinel takes the queue's newest slot if it is full (drop-oldest, like _emit)."""
        try:
            self._q.put_nowait(_STOP)
        except asyncio.QueueFull:
            try:
                self._q.get_nowait()
            except asyncio.QueueEmpty:
                pass
            try:
                self._q.put_nowait(_STOP)
            except asyncio.QueueFull:
                pass  # producer refilled it; events() re-checks _stop after the next message

    def try_get(self) -> Event | None:
        try:
            ev = self._q.get_nowait()
            return None if ev is _STOP else ev
        except asyncio.QueueEmpty:
            return None

    @property
    def backlog(self) -> int:
        return self._q.qsize()


def make_feed(venue: str, symbol: str, **kw) -> Feed:
    if venue == "coinbase":
        import os

        from .coinbase import CoinbaseExchangeFeed, CoinbaseFeed

        api = os.environ.get("LEAFHFT_COINBASE_API", "exchange")
        if api == "exchange":
            return CoinbaseExchangeFeed(symbol, **kw)
        if api == "advanced":
            return CoinbaseFeed(symbol, **kw)
        raise ValueError("LEAFHFT_COINBASE_API must be 'exchange' or 'advanced'")
    if venue == "kraken":
        from .kraken import KrakenFeed

        return KrakenFeed(symbol, **kw)
    if venue == "binanceus":
        from .binanceus import BinanceUSFeed

        return BinanceUSFeed(symbol, **kw)
    if venue == "kalshi":
        from .kalshi import KalshiFeed, symbol_to_series

        series, index_ids = symbol_to_series(symbol)
        return KalshiFeed(series=series, index_ids=index_ids, **kw)
    if venue == "polymarket_us":
        from .polymarket_us import PolymarketUSFeed

        return PolymarketUSFeed(symbol, **kw)
    raise ValueError(f"unknown venue {venue!r}")


def guard(fn):
    """Decorator for parse functions: MalformedInput -> counted and skipped, never propagated."""

    def wrapper(self, *a, **k):
        try:
            return fn(self, *a, **k)
        except MalformedInput as e:
            self._malformed(str(e))
            return None
        except (KeyError, TypeError, ValueError, IndexError) as e:
            self._malformed(f"{type(e).__name__}: {e}")
            return None

    return wrapper
