"""Polymarket US discovery and books for the multi-venue strategy feed.

Full-book wire shape: https://docs.polymarket.us/api-reference/websocket/markets.md.
The docs describe replacement books; explicit marketDataDelta support below is unverified.
No index is synthesized: compose Kalshi's CF Benchmarks feed for IndexTick events.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import logging
import os
import re
import time
from pathlib import Path

import aiohttp
import orjson
import websockets

from scripts.polymarket_us_watch import market_page, is_crypto, horizon as market_horizon
from ..broker.polymarket_us import PolymarketUSAuth
from ..clock import now_ns
from ..types import MalformedInput, PRICE_UNIT, Quote
from .base import Feed, IndexTick, Lifecycle, guard
from .kalshi import KalshiFeed, SYMBOL_MAP as KALSHI_SYMBOL_MAP, _to_ms, diff_subscriptions, to_price_i, to_size_i

GATEWAY_URL = "https://gateway.polymarket.us/v1/markets?categories=crypto&limit=50"
WS_URL = "wss://api.polymarket.us/v1/ws/markets"
WS_PATH = "/v1/ws/markets"
BODY_CAP = 2 * 1024 * 1024
MAX_MSG_BYTES = 64 * 1024
SUBSCRIPTION_TYPE = "SUBSCRIPTION_TYPE_MARKET_DATA"
SYMBOL_MAP = {s: s.lower() for s in ("BTC", "ETH", "SOL", "XRP", "DOGE", "BNB", "HYPE")}
POLYMARKET_US_SERIES = ("cpc", "pm")
LIVE_SYMBOL_MAP = {
    f"{coin}-{family}": next(value[1] for label, value in KALSHI_SYMBOL_MAP.items()
                              if label.split("-", 1)[0] == coin)
    for coin in SYMBOL_MAP for family in ("15M", "1H")
}


class KalshiIndexFeed(KalshiFeed):
    """Reuse Kalshi's signed socket and watchdog, without market subscriptions."""

    async def _refresh_discovery(self) -> None:
        pass

    def _emit(self, ev) -> None:
        if isinstance(ev, IndexTick):
            super()._emit(ev)


class PolymarketUSLiveFeed(Feed):
    """Two supervised sockets share one bounded queue and the driver's idle budget.

    Each socket retains its own heartbeat watchdog so active index traffic cannot
    hide a dead market socket, or the reverse.
    """
    venue = "polymarket_us"

    def __init__(self, symbol: str, auth: PolymarketUSAuth, *, index_from: str = "kalshi") -> None:
        if symbol not in LIVE_SYMBOL_MAP or index_from != "kalshi":
            raise ValueError("invalid Polymarket US live symbol or index source")
        super().__init__(symbol)
        self.market_feed = PolymarketUSFeed(symbol.split("-", 1)[0], auth=auth, horizon="short")
        self.index_feed = KalshiIndexFeed(series=POLYMARKET_US_SERIES,
                                         index_ids=(LIVE_SYMBOL_MAP[symbol],))
        for feed in (self.market_feed, self.index_feed):
            feed._q = self._q

    async def start(self) -> None:
        try:
            self.market_feed._stop.clear()
            self.index_feed._stop.clear()
            await self.market_feed.start()
            await self.index_feed.start()
        except BaseException:
            await self.stop()
            raise

    async def stop(self) -> None:
        try:
            await self.market_feed.stop()
        finally:
            try:
                await self.index_feed.stop()
            finally:
                await super().stop()

    async def reconnect(self) -> None:
        # Feed.reconnect drains the shared stop sentinels before starting again.
        await super().reconnect()



def auth_from_env() -> PolymarketUSAuth | None:
    """Optional credentials: a key file, or the recorder's legacy base64 seed."""
    key = os.environ.get("LEAFHFT_POLYMARKET_US_KEY_ID", "")
    seed = os.environ.get("LEAFHFT_POLYMARKET_US_PRIVATE_KEY_BASE64", "")
    key_file = os.environ.get("POLYMARKET_US_KEY_FILE", "")
    if key_file:
        try:
            with Path(key_file).open("rb") as stream:
                return PolymarketUSAuth(key, stream.read(4097))
        except Exception:
            raise ValueError("invalid Polymarket US recorder credentials") from None
    if not key and not seed:
        return None
    try:
        return PolymarketUSAuth(key, base64.b64decode(seed, validate=True))
    except Exception:
        raise ValueError("invalid Polymarket US recorder credentials") from None


def market_ticker(slug: str) -> str:
    """Quote symbols allow 32 chars. Preserve short slugs; map longer ones deterministically.

    _markets retains each ticker's full slug for subscriptions and driver lookup.
    """
    return slug if len(slug) <= 32 else "pm-" + hashlib.blake2s(slug.encode(), digest_size=14).hexdigest()


def strike(market: dict) -> tuple[int, str]:
    """Above means gt, otherwise ge. A range uses its first (lower) dollar bound.

    Missing thresholds remain zero. Do not mistake a slug's year for a strike.
    """
    text = str(market.get("description") or "")
    boundary = "gt" if re.search(r"\babove\b", text, re.I) else "ge"
    match = re.search(r"\$\s*([0-9][0-9,]*(?:\.[0-9]+)?)", text)
    if not match:
        slug = market["slug"]
        boundary = "gt" if "above" in slug.split("-") else boundary
        match = re.search(r"(?:above|over|below|under|between|range|gt|ge)-([0-9]+(?:\.[0-9]+)?)(k)?(?:-|$)", slug, re.I)
        if match:
            value = to_price_i(match[1])
            return value * (1000 if match[2] else 1), boundary
        # Public gateway slugs also use cpc-btc-150k-12-31-2026 and
        # cpc-btc-hitprice-high-yr-12-31-2026-200k. Require the k suffix
        # in this fallback so calendar numbers cannot become thresholds.
        match = re.search(r"(?:^|-)([0-9]+(?:\.[0-9]+)?)k(?:-|$)", slug, re.I)
        if match:
            return to_price_i(match[1]) * 1000, boundary
    return (to_price_i(match[1].replace(",", "")) if match else 0), boundary


class PolymarketUSFeed(Feed):
    venue = "polymarket_us"

    def __init__(self, symbol: str, auth: PolymarketUSAuth | None = None, *,
                 discovery_period_s: float = 60, max_markets: int = 10,
                 horizon: str = "any", quote_interval_ms: int = 100,
                 heartbeat_s: float = 20, backoff_min_s: float = 0.5,
                 backoff_max_s: float = 30) -> None:
        if symbol not in SYMBOL_MAP or horizon not in {"short", "any"}:
            raise ValueError("invalid Polymarket US symbol or horizon")
        if type(max_markets) is not int or not 1 <= max_markets <= 10:
            raise ValueError("max_markets must be in [1, 10]")
        if not 0 < discovery_period_s <= 86400:
            raise ValueError("invalid discovery period")
        if type(quote_interval_ms) is not int or not 0 <= quote_interval_ms <= 60000:
            raise ValueError("invalid quote interval")
        super().__init__(symbol, heartbeat_s, backoff_min_s, backoff_max_s)
        self.auth = auth
        self.discovery_period_s = discovery_period_s
        self.max_markets = max_markets
        self.horizon = horizon
        self.discovery_runs = 0
        self._ws = None
        self._markets: dict[str, dict] = {}
        self._ticker_slugs: dict[str, str] = {}
        self._subscribed: set[str] = set()
        self._books: dict[str, dict] = {}
        self._pending_quote: dict[str, dict] = {}
        self._last_quote_emit_mono: dict[str, float] = {}
        self._flush_handles: dict[str, asyncio.TimerHandle] = {}
        self._quote_interval_s = quote_interval_ms / 1000
        self._request_id = 0
        self._connections = 0
        self._logged_no_auth = False

    async def _fetch_page(self):
        for attempt in range(2):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                    async with session.get(GATEWAY_URL) as response:
                        response.raise_for_status()
                        body = bytearray()
                        async for chunk in response.content.iter_chunked(65536):
                            body.extend(chunk)
                            if len(body) > BODY_CAP:
                                raise ValueError("gateway body exceeds 2 MiB")
                        return orjson.loads(body)
            except (aiohttp.ClientError, asyncio.TimeoutError, ValueError):
                if attempt:
                    raise
                await asyncio.sleep(0.5)

    async def _discover_once(self) -> dict[str, dict]:
        try:
            rows, _ = market_page(await self._fetch_page())
        except (ValueError, TypeError):
            self._malformed("invalid gateway response")
            raise
        result = {}
        for row in rows:
            try:
                if not isinstance(row, dict):
                    raise ValueError("market is not an object")
                slug = row.get("slug")
                if not isinstance(slug, str) or len(slug) > 512:
                    raise ValueError("invalid market slug")
                parts = slug.split("-")
                if len(parts) < 2 or parts[1] != SYMBOL_MAP[self.symbol] or not is_crypto(row):
                    continue
                if self.horizon == "short" and market_horizon(row) != "short":
                    continue
                if row.get("status") not in {"MARKET_STATUS_OPEN", "open", "active"}:
                    continue
                close_ms = _to_ms(row.get("endDate"))
                if close_ms is None or close_ms <= int(time.time() * 1000):
                    continue
                strike_i, boundary = strike(row)
                ticker = market_ticker(slug)
                event = Lifecycle(ticker, "active", close_ms, close_ms, strike_i,
                                  boundary, _to_ms(row.get("startDate")) or 0)
                result[ticker] = {"slug": slug, "close_ms": close_ms,
                                  "strike_i": strike_i, "event": event}
            except (ValueError, TypeError, KeyError, IndexError):
                self._malformed("invalid discovery market")
        return result

    async def _refresh_discovery(self) -> None:
        self.discovery_runs += 1
        discovered = await self._discover_once()
        add, drop = diff_subscriptions(self._subscribed, discovered, self.max_markets)
        # Rotate the connection when the desired set changes. This avoids assuming an
        # undocumented unsubscribe message and never exceeds the per-connection cap.
        if self._ws is not None and (add or drop):
            await self._ws.close()
            raise ConnectionError("market subscriptions changed")
        self._markets = discovered
        for ticker in drop:
            self._subscribed.discard(ticker)
            self._clear_quote(ticker)
            self._books.pop(ticker, None)
        for ticker in add:
            if ticker not in self._ticker_slugs and len(self._ticker_slugs) >= 5000:
                raise RuntimeError("recorder market identity limit reached")
            self._ticker_slugs[ticker] = discovered[ticker]["slug"]
            self._subscribed.add(ticker)
        for ticker in sorted(self._subscribed):
            self._emit(discovered[ticker]["event"])

    async def _run_once(self) -> None:
        self._subscribed.clear()
        await self._refresh_discovery()
        if self.auth is None:
            if not self._logged_no_auth:
                logging.getLogger(__name__).warning("Polymarket US: no auth; recording discovery/lifecycle only")
                self._logged_no_auth = True
            while not self._stop.is_set():
                await asyncio.sleep(self.discovery_period_s)
                await self._refresh_discovery()
            return
        if self._connections:
            self.stats.reconnects += 1
        self._connections += 1
        headers = self.auth.headers("GET", WS_PATH, int(time.time() * 1000))
        try:
            async with websockets.connect(WS_URL, additional_headers=headers, open_timeout=10,
                                          close_timeout=3, max_size=MAX_MSG_BYTES,
                                          ping_interval=20, ping_timeout=10) as ws:
                self._ws = ws
                if self._subscribed:
                    self._request_id += 1
                    await ws.send(orjson.dumps({"subscribe": {
                        "requestId": f"md-{self._request_id}",
                        "subscriptionType": SUBSCRIPTION_TYPE,
                        "marketSlugs": [self._markets[t]["slug"] for t in sorted(self._subscribed)],
                    }}).decode())
                last_discovery = time.monotonic()
                while not self._stop.is_set():
                    remaining = self.discovery_period_s - (time.monotonic() - last_discovery)
                    try:
                        raw = await asyncio.wait_for(ws.recv(), max(0.01, remaining))
                    except asyncio.TimeoutError:
                        raw = None
                    if raw is not None:
                        self.handle_ws(raw)
                    if time.monotonic() - last_discovery >= self.discovery_period_s:
                        await self._refresh_discovery()
                        last_discovery = time.monotonic()
        finally:
            self._ws = None
            for ticker in list(self._pending_quote):
                self._clear_quote(ticker)
            self._books.clear()
            self._last_quote_emit_mono.clear()

    async def _on_heartbeat_timeout(self) -> None:
        if self._ws is not None:
            await self._ws.close()

    async def _watchdog(self) -> None:
        if self.auth is None:
            await self._stop.wait()  # discovery-only operation has no socket heartbeat
        else:
            await super()._watchdog()

    @guard
    def handle_ws(self, raw: str | bytes) -> None:
        if not isinstance(raw, (str, bytes)) or len(raw) > MAX_MSG_BYTES:
            raise MalformedInput("invalid or oversized message")
        if isinstance(raw, str) and len(raw.encode()) > MAX_MSG_BYTES:
            raise MalformedInput("oversized message")
        message = orjson.loads(raw)
        if not isinstance(message, dict):
            raise MalformedInput("message is not an object")
        delta = "marketDataDelta" in message
        data = message.get("marketDataDelta" if delta else "marketData")
        if data is None:
            self._touch()  # subscription acknowledgements and heartbeat envelopes
            return
        if not isinstance(data, dict):
            raise MalformedInput("book is not an object")
        slug = data["marketSlug"]
        if not isinstance(slug, str):
            raise MalformedInput("invalid book slug")
        ticker = market_ticker(slug)
        if ticker not in self._subscribed or self._markets[ticker]["slug"] != slug:
            return
        if delta and ticker not in self._books:
            raise MalformedInput("delta before snapshot")
        book = {side: dict(self._books[ticker][side]) if delta else {}
                for side in ("bids", "offers")}
        for side in book:
            rows = data.get(side, []) if delta else data[side]
            if not isinstance(rows, list):
                raise MalformedInput("book levels are not a list")
            for row in rows:
                if not isinstance(row, dict) or not isinstance(row.get("px"), dict):
                    raise MalformedInput("invalid level")
                if row["px"].get("currency", "USD") != "USD":
                    raise MalformedInput("non-USD price")
                price, size = to_price_i(row["px"]["value"]), to_size_i(row["qty"])
                if not 0 < price < PRICE_UNIT:
                    raise MalformedInput("price outside contract bounds")
                if size:
                    book[side][price] = size
                else:
                    book[side].pop(price, None)
            if len(book[side]) > 2048:
                raise MalformedInput("too many book levels")
        if book["bids"] and book["offers"] and max(book["bids"]) >= min(book["offers"]):
            raise MalformedInput("crossed book")
        self._touch()
        self._books[ticker] = book
        self._clear_quote(ticker)
        if data.get("state", "MARKET_STATE_OPEN") != "MARKET_STATE_OPEN":
            self._books.pop(ticker, None)
            return
        if not book["bids"] or not book["offers"]:
            return
        bid, ask = max(book["bids"]), min(book["offers"])
        self._pending_quote[ticker] = {"bid_i": bid, "bid_size_i": book["bids"][bid],
                                       "ask_i": ask, "ask_size_i": book["offers"][ask]}
        self._throttled_flush(ticker)

    def _clear_quote(self, ticker: str) -> None:
        self._pending_quote.pop(ticker, None)
        handle = self._flush_handles.pop(ticker, None)
        if handle is not None:
            handle.cancel()

    def _throttled_flush(self, ticker: str) -> None:
        self._flush_handles.pop(ticker, None)
        pending = self._pending_quote.get(ticker)
        if pending is None:
            return
        now = time.monotonic()
        last = self._last_quote_emit_mono.get(ticker)
        if last is not None and now - last < self._quote_interval_s:
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                return
            self._flush_handles[ticker] = loop.call_later(
                self._quote_interval_s - (now - last), self._throttled_flush, ticker)
            return
        self._pending_quote.pop(ticker)
        self._last_quote_emit_mono[ticker] = now
        recv = now_ns()
        self._emit(Quote(self.venue, ticker, **pending, ts_exch_ns=recv,
                         ts_recv_ns=recv, seq=self.next_seq()))

    def quality(self) -> dict:
        return {"discovery_runs": self.discovery_runs, "markets_subscribed": len(self._subscribed),
                "quotes_emitted": self.stats.quotes, "lifecycles_emitted": self.stats.lifecycles,
                "reconnects": self.stats.reconnects, "malformed": self.stats.malformed,
                "ticker_slugs": dict(self._ticker_slugs)}
