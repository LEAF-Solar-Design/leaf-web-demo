"""One reader contract for a recorder run directory's rotated tape (REC-tapeparts).

The Recorder (leafhft/feeds/recorder.py) rotates at 512 MiB: the active file is always
ticks.jsonl, and each completed part is renamed ticks.NNN.jsonl (1-based, three digits, at
most MAX_ROTATED_PARTS). A reader that opens only ticks.jsonl sees the newest part and drops
the older ones. Every run-dir consumer resolves its files here, oldest part first.

This module is outside the shadow evaluator's SOURCE_CLOSURE (leafhft/shadow_continuous.py)
on purpose: no closure file imports it, so adopting it never moves source_bundle_sha256.
Bounded: one directory listing per call, at most MAX_ROTATED_PARTS + 1 paths returned; no
file is opened by tape_parts. Symlinked entries are never returned.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Iterator

from ..types import Quote, Trade
from .recorder import MAX_ROTATED_PARTS, iter_file

TAPE_ACTIVE_NAME = "ticks.jsonl"
TAPE_PART_RE = re.compile(r"ticks\.(\d{3})\.jsonl\Z", re.ASCII)


def tape_parts(path: str | Path, *, newest_first: bool = False) -> list[Path]:
    """Every part of one recording, oldest first: ticks.001.jsonl ... ticks.NNN.jsonl in
    ascending numeric order, then ticks.jsonl. `path` is the run dir or its ticks.jsonl (the
    file need not exist). A missing run dir, or a path that is neither, gives []. Only regular,
    non-symlink files count; ticks.000.jsonl and any other name are ignored."""
    p = Path(path)
    run_dir = p.parent if p.name == TAPE_ACTIVE_NAME else p
    if not run_dir.is_dir():
        return []
    numbered: list[tuple[int, Path]] = []
    active: Path | None = None
    with os.scandir(run_dir) as entries:
        for entry in entries:
            if not entry.is_file(follow_symlinks=False):
                continue
            if entry.name == TAPE_ACTIVE_NAME:
                active = run_dir / entry.name
                continue
            match = TAPE_PART_RE.fullmatch(entry.name)
            if match is not None and 1 <= int(match[1]) <= MAX_ROTATED_PARTS:
                numbered.append((int(match[1]), run_dir / entry.name))
    parts = [part for _, part in sorted(numbered)]
    if active is not None:
        parts.append(active)
    return parts[::-1] if newest_first else parts


def iter_tape(path: str | Path, max_events: int = 0) -> Iterator[Quote | Trade]:
    """Replay every part of one recording, oldest first, through recorder.iter_file.
    Malformed lines are skipped; their total across parts is iter_tape.skipped."""
    iter_tape.skipped = 0  # type: ignore[attr-defined]
    n = 0
    for part in tape_parts(path):
        try:
            for ev in iter_file(part):
                yield ev
                n += 1
                if max_events and n >= max_events:
                    return
        finally:
            iter_tape.skipped += getattr(iter_file, "skipped", 0)  # type: ignore[attr-defined]
