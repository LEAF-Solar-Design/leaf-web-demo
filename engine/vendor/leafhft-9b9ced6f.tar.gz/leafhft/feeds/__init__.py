"""Market data feeds. Each feed is an async iterator of Quote|Trade with a bounded queue,
reconnect-with-backoff, heartbeat timeout and strict message validation."""
from .base import Feed, FeedStats, make_feed

__all__ = ["Feed", "FeedStats", "make_feed"]
