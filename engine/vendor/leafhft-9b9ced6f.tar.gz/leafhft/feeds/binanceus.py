"""Binance.US market data: WebSocket bookTicker+trade when reachable, REST polling otherwise.

Measured 2026-09-05 from this host: TCP to stream.binance.us:9443 connects in 0.23 s but the
WebSocket upgrade never completes (websockets and aiohttp both time out), while REST answers in
0.6 s. `transport="auto"` tries WS once per cycle with a short open timeout and falls back to REST
polling at a fixed cadence that stays under 10% of the venue's request-weight budget.
Symbol mapping: BTC-USD -> BTCUSD. Aggressor side: `m` (buyer is maker) true => SELL.
"""
from __future__ import annotations

import asyncio

import aiohttp
import orjson
import websockets

from ..clock import now_ns
from ..types import MalformedInput, Quote, Side, Trade, to_price_i, to_size_i
from .base import MAX_MSG_BYTES, Feed, guard

WS_URL = "wss://stream.binance.us:9443/ws"
REST_URL = "https://api.binance.us"
REST_BOOK_PERIOD_S = 0.5  # weight 2 per call  -> 240/min
REST_TRADES_PERIOD_S = 1.0  # weight 10 per call -> 600/min; total < 1200/min budget
REST_TIMEOUT_S = 5.0
WS_OPEN_TIMEOUT_S = 8.0
TRADES_LIMIT = 100


def binance_symbol(symbol: str) -> str:
    base, quote = symbol.split("-", 1)
    return f"{base}{quote}".upper()


class BinanceUSFeed(Feed):
    venue = "binanceus"

    def __init__(
        self,
        symbol: str,
        # us-east-1: bookTicker quiet gaps >= 20 s, 9 quotes in 45 s; WS ping/pong detects dead sockets.
        heartbeat_s: float = 120.0,
        transport: str = "auto",
        ws_url: str = WS_URL,
        rest_url: str = REST_URL,
    ) -> None:
        super().__init__(symbol, heartbeat_s)
        if transport not in ("auto", "ws", "rest"):
            raise ValueError("transport must be auto|ws|rest")
        self.transport = transport
        self.bsym = binance_symbol(symbol)
        self.ws_url = ws_url
        self.rest_url = rest_url
        self._ws = None
        self._last_trade_id = -1
        self.active_transport = ""
        # REST data-quality counters (astra build-order item 2): poll latency and cadence gaps
        self.poll_n = 0
        self.poll_lat_sum_ms = 0.0
        self.poll_lat_max_ms = 0.0
        self.poll_gaps = 0  # polls that ran more than 2x their period late
        self.poll_fail = 0
        self.trade_id_gaps = 0  # polls whose oldest new id skipped past last+1: prints were missed (astra r2)

    async def _run_once(self) -> None:
        if self.transport in ("auto", "ws"):
            try:
                await self._run_ws()
                return
            except (asyncio.TimeoutError, OSError, websockets.WebSocketException) as e:
                if self.transport == "ws":
                    raise
                self.stats.note_error(f"ws unavailable, falling back to rest: {type(e).__name__}")
        await self._run_rest()

    async def _on_heartbeat_timeout(self) -> None:
        ws = self._ws
        if ws is not None:
            await ws.close()

    # ---- websocket ----------------------------------------------------
    async def _run_ws(self) -> None:
        s = self.bsym.lower()
        url = f"{self.ws_url}/{s}@bookTicker/{s}@trade"
        async with websockets.connect(
            url, open_timeout=WS_OPEN_TIMEOUT_S, close_timeout=3, max_size=MAX_MSG_BYTES, ping_interval=20, ping_timeout=10
        ) as ws:
            self._ws = ws
            self.active_transport = "ws"
            async for raw in ws:
                self._touch()
                self.handle_ws(raw)
        self._ws = None

    def handle_ws(self, raw: str | bytes) -> None:
        if len(raw) > MAX_MSG_BYTES:
            self._malformed("oversize message")
            return
        try:
            msg = orjson.loads(raw)
        except orjson.JSONDecodeError:
            self._malformed("bad json")
            return
        if not isinstance(msg, dict):
            self._malformed("non-object")
            return
        if msg.get("e") == "trade":
            self._on_ws_trade(msg)
        elif "b" in msg and "a" in msg:
            self._on_book_ticker(msg)

    @guard
    def _on_book_ticker(self, d: dict) -> None:
        if d.get("s") != self.bsym:
            return
        recv = now_ns()
        self._emit(
            Quote(
                self.venue,
                self.symbol,
                to_price_i(d["b"]),
                to_size_i(d["B"]),
                to_price_i(d["a"]),
                to_size_i(d["A"]),
                recv,
                recv,
                self.next_seq(),
            )
        )

    @guard
    def _on_ws_trade(self, d: dict) -> None:
        if d.get("s") != self.bsym:
            return
        recv = now_ns()
        tid = int(d["t"])
        if tid <= self._last_trade_id:
            return
        self._last_trade_id = tid
        self._emit(
            Trade(
                self.venue,
                self.symbol,
                to_price_i(d["p"]),
                to_size_i(d["q"]),
                Side.SELL if bool(d["m"]) else Side.BUY,
                int(d["T"]) * 1_000_000,
                recv,
                self.next_seq(),
            )
        )

    # ---- rest polling -------------------------------------------------
    async def _run_rest(self) -> None:
        self.active_transport = "rest"
        timeout = aiohttp.ClientTimeout(total=REST_TIMEOUT_S)
        loop = asyncio.get_running_loop()
        next_book = loop.time()
        next_trades = loop.time()
        async with aiohttp.ClientSession(timeout=timeout, raise_for_status=False) as session:
            while not self._stop.is_set():
                now = loop.time()
                if now >= next_book:
                    if now - next_book > REST_BOOK_PERIOD_S:
                        self.poll_gaps += 1
                    next_book = now + REST_BOOK_PERIOD_S
                    t0 = loop.time()
                    await self._poll_book(session)
                    self._note_poll((loop.time() - t0) * 1000.0)
                if now >= next_trades:
                    next_trades = now + REST_TRADES_PERIOD_S
                    t0 = loop.time()
                    await self._poll_trades(session)
                    self._note_poll((loop.time() - t0) * 1000.0)
                await asyncio.sleep(max(0.01, min(next_book, next_trades) - loop.time()))

    def _note_poll(self, ms: float) -> None:
        self.poll_n += 1
        self.poll_lat_sum_ms += ms
        if ms > self.poll_lat_max_ms:
            self.poll_lat_max_ms = ms

    def quality(self) -> dict:
        return {
            "transport": self.active_transport,
            "polls": self.poll_n,
            "poll_lat_mean_ms": (self.poll_lat_sum_ms / self.poll_n) if self.poll_n else 0.0,
            "poll_lat_max_ms": self.poll_lat_max_ms,
            "poll_gaps": self.poll_gaps,
            "poll_fail": self.poll_fail,
            "trade_id_gaps": self.trade_id_gaps,
            "book_period_s": REST_BOOK_PERIOD_S,
            "trades_period_s": REST_TRADES_PERIOD_S,
        }

    async def _get_json(self, session: aiohttp.ClientSession, path: str, params: dict) -> object:
        try:
            async with session.get(f"{self.rest_url}{path}", params=params) as resp:
                if resp.status == 429 or resp.status == 418:
                    # venue rate-limit signal: back off hard rather than get banned
                    self.stats.note_error(f"rate limited {resp.status}")
                    self.poll_fail += 1
                    await asyncio.sleep(10)
                    return None
                if resp.status != 200:
                    self.stats.note_error(f"http {resp.status} {path}")
                    self.poll_fail += 1
                    return None
                body = await resp.content.read(MAX_MSG_BYTES + 1)
                if len(body) > MAX_MSG_BYTES:
                    self._malformed("oversize rest body")
                    return None
                return orjson.loads(body)
        except (aiohttp.ClientError, asyncio.TimeoutError, orjson.JSONDecodeError) as e:
            self.poll_fail += 1
            self.stats.note_error(f"poll {path}: {type(e).__name__}")
            return None

    async def _poll_book(self, session: aiohttp.ClientSession) -> None:
        d = await self._get_json(session, "/api/v3/ticker/bookTicker", {"symbol": self.bsym})
        if isinstance(d, dict):
            self._touch()
            self._on_rest_book(d)

    @guard
    def _on_rest_book(self, d: dict) -> None:
        recv = now_ns()
        self._emit(
            Quote(
                self.venue,
                self.symbol,
                to_price_i(d["bidPrice"]),
                to_size_i(d["bidQty"]),
                to_price_i(d["askPrice"]),
                to_size_i(d["askQty"]),
                recv,
                recv,
                self.next_seq(),
            )
        )

    async def _poll_trades(self, session: aiohttp.ClientSession) -> None:
        d = await self._get_json(session, "/api/v3/trades", {"symbol": self.bsym, "limit": TRADES_LIMIT})
        if isinstance(d, list):
            self._touch()
            self._on_rest_trades(d)

    @guard
    def _on_rest_trades(self, rows: list) -> None:
        recv = now_ns()
        if len(rows) > TRADES_LIMIT:
            raise MalformedInput("too many trades")
        first_poll = self._last_trade_id < 0
        if not first_poll and rows:
            oldest = min(int(r["id"]) for r in rows)
            if oldest > self._last_trade_id + 1:
                self.trade_id_gaps += 1
        for r in rows:
            tid = int(r["id"])
            if tid <= self._last_trade_id:
                continue
            self._last_trade_id = tid
            if first_poll:
                continue  # history, not live flow
            self._emit(
                Trade(
                    self.venue,
                    self.symbol,
                    to_price_i(r["price"]),
                    to_size_i(r["qty"]),
                    Side.SELL if bool(r["isBuyerMaker"]) else Side.BUY,
                    int(r["time"]) * 1_000_000,
                    recv,
                    self.next_seq(),
                )
            )
