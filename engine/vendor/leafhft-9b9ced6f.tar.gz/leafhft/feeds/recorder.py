"""Tick capture to JSONL (one orjson line per event) and deterministic replay.

Recorder writes its buffer at 500 rows or 1 s, whichever comes first, while events arrive.
A stream of only extra-kind rows still flushes by count.
Recorder buffers off the hot path and rotates its output at `rotate_bytes` (default
MAX_FILE_BYTES, 512 MiB) so a runaway feed can never fill the disk: the active file is always
`ticks.jsonl`; on rotation it is closed, renamed to `ticks.NNN.jsonl` (1-based, zero-padded to 3
digits, at most 999 parts), and a fresh `ticks.jsonl` is opened. `record-summary.json` beside it
lists every part (`ticks.jsonl` plus each `ticks.NNN.jsonl`) with its row count, refreshed after
every rotation and on close.

A reader over a run directory must replay `ticks.jsonl` and every `ticks.NNN.jsonl` in ascending
numeric order to see the whole recording. `scripts/kalshi_fair.py` and `scripts/fill_tape.py` read
a single `ticks.jsonl` today and are not updated here (out of scope for this change: a follow-up
record does that). Replay reconstructs the exact Quote/Trade objects, so a backtest sees the same
integers the live engine saw.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Iterator

import orjson

from ..types import MalformedInput, Quote, Side, Trade

MAX_FILE_BYTES = 512 * 1024 * 1024
FLUSH_ROWS = 500
# Longest a written row waits in the buffer while events keep arriving; a silent feed has nothing to flush.
FLUSH_INTERVAL_S = 1.0
MAX_LINE_BYTES = 4096
MAX_ROTATED_PARTS = 999


def encode(ev: Quote | Trade) -> bytes:
    return orjson.dumps(row(ev))


def row(ev: Quote | Trade) -> dict:
    if isinstance(ev, Quote):
        return {
                "t": "q",
                "v": ev.venue,
                "s": ev.symbol,
                "b": ev.bid_i,
                "bs": ev.bid_size_i,
                "a": ev.ask_i,
                "as": ev.ask_size_i,
                "te": ev.ts_exch_ns,
                "tr": ev.ts_recv_ns,
                "n": ev.seq,
                **({"ta": ev.ts_arrival_ns} if ev.ts_arrival_ns is not None else {}),
                **({"tv": ev.ts_venue_ns} if ev.ts_venue_ns is not None else {}),
            }
    return {
            "t": "x",
            "v": ev.venue,
            "s": ev.symbol,
            "p": ev.price_i,
            "z": ev.size_i,
            "d": int(ev.side),
            "te": ev.ts_exch_ns,
            "tr": ev.ts_recv_ns,
            "n": ev.seq,
            **({"id": ev.trade_id} if ev.trade_id is not None else {}),
        }


def decode(line: bytes) -> Quote | Trade:
    if len(line) > MAX_LINE_BYTES:
        raise MalformedInput("oversize line")
    d = orjson.loads(line)
    if not isinstance(d, dict):
        raise MalformedInput("non-object line")
    t = d.get("t")
    if t == "q":
        return Quote(d["v"], d["s"], int(d["b"]), int(d["bs"]), int(d["a"]), int(d["as"]), int(d["te"]), int(d["tr"]), int(d["n"]), ts_arrival_ns=d.get("ta"), ts_venue_ns=d.get("tv"))
    if t == "x":
        return Trade(d["v"], d["s"], int(d["p"]), int(d["z"]), Side(int(d["d"])), int(d["te"]), int(d["tr"]), int(d["n"]), trade_id=d.get("id"))
    raise MalformedInput(f"unknown record type {t!r}")


class Recorder:
    def __init__(self, path: str | Path, rotate_bytes: int = MAX_FILE_BYTES) -> None:
        if isinstance(rotate_bytes, bool) or not isinstance(rotate_bytes, int) or rotate_bytes <= 0:
            raise ValueError(f"rotate_bytes must be a positive int: {rotate_bytes!r}")
        self.base = Path(path)
        self.base.parent.mkdir(parents=True, exist_ok=True)
        self.rotate_bytes = rotate_bytes
        self.summary_path = self.base.parent / "record-summary.json"
        self._part = 0  # count of completed rotations; the parts already renamed out of the way
        self._fh = None
        self._buf: list[bytes] = []
        self._last_flush = time.monotonic()
        self._bytes = 0
        self.rows = 0  # rows written across this Recorder instance's whole lifetime
        self._parts: list[dict] = []  # completed parts: [{"file": "ticks.001.jsonl", "rows": N}, ...]
        self._open()

    @property
    def _part_rows(self) -> int:
        """Rows written to the currently open file only, derived from `self.rows` (which a
        subclass overriding write() for extra row kinds, e.g. cli.py's KalshiRecorder, still
        increments) rather than a second counter that override could silently leave stale."""
        return self.rows - sum(p["rows"] for p in self._parts)

    def _open(self) -> None:
        if self._fh is not None:
            self._fh.close()
        self._fh = open(self.base, "ab", buffering=1 << 16)
        self._bytes = self._fh.tell()
        self.path = self.base

    def write(self, ev: Quote | Trade) -> None:
        self._buf.append(encode(ev))
        self.rows += 1
        self._maybe_flush()

    def _maybe_flush(self) -> None:
        now = time.monotonic()
        if len(self._buf) >= FLUSH_ROWS or now - self._last_flush >= FLUSH_INTERVAL_S:
            self.flush()

    def flush(self) -> None:
        if not self._buf or self._fh is None:
            return
        blob = b"\n".join(self._buf) + b"\n"
        self._fh.write(blob)
        self._fh.flush()
        self._bytes += len(blob)
        self._buf.clear()
        self._last_flush = time.monotonic()
        if self._bytes >= self.rotate_bytes:
            self._rotate()

    def _rotate(self) -> None:
        if self._part >= MAX_ROTATED_PARTS:
            raise RuntimeError(f"recorder exceeded {MAX_ROTATED_PARTS} rotated parts at {self.base}")
        self._fh.flush()
        os.fsync(self._fh.fileno())
        self._fh.close()
        self._fh = None
        self._part += 1
        rotated = self.base.parent / f"{self.base.stem}.{self._part:03d}{self.base.suffix}"
        if rotated.exists():
            raise RuntimeError(f"refusing to overwrite an existing rotated part: {rotated}")
        os.replace(self.base, rotated)
        self._parts.append({"file": rotated.name, "rows": self._part_rows})
        self._open()
        self._write_summary()

    def _write_summary(self) -> None:
        parts = self._parts + [{"file": self.base.name, "rows": self._part_rows}]
        summary = {"parts": parts, "total_rows": self.rows}
        tmp = self.summary_path.with_suffix(self.summary_path.suffix + ".tmp")
        tmp.write_bytes(orjson.dumps(summary))
        os.replace(tmp, self.summary_path)

    def close(self) -> None:
        self.flush()
        if self._fh is not None:
            self._fh.flush()
            os.fsync(self._fh.fileno())
            self._fh.close()
            self._fh = None
        self._write_summary()


def iter_file(path: str | Path, max_events: int = 0) -> Iterator[Quote | Trade]:
    """Sync replay for backtests. Malformed lines are skipped and counted on the function attribute."""
    iter_file.skipped = 0  # type: ignore[attr-defined]
    n = 0
    with open(path, "rb") as fh:
        for line in fh:
            line = line.rstrip(b"\n")
            if not line:
                continue
            try:
                ev = decode(line)
            except (MalformedInput, KeyError, ValueError, TypeError, orjson.JSONDecodeError):
                iter_file.skipped += 1  # type: ignore[attr-defined]
                continue
            yield ev
            n += 1
            if max_events and n >= max_events:
                return
