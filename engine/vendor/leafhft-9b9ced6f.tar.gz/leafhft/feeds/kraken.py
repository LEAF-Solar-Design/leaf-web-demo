"""Kraken WebSocket v2 public: ticker (L1) + trade channels.

Measured 2026-09-05: connect 1347 ms. Kraken v2 sends numbers as JSON floats; they are parsed
through repr() -> Decimal so a float like 79622.1 lands on exactly 7962210000000 price units.
Symbol mapping: BTC-USD -> BTC/USD.
"""
from __future__ import annotations

import asyncio

import orjson
import websockets

from ..clock import now_ns, parse_rfc3339_ns
from ..types import MalformedInput, Quote, Side, Trade, to_price_i
from .base import MAX_MSG_BYTES, Feed, guard

WS_URL = "wss://ws.kraken.com/v2"


def kraken_symbol(symbol: str) -> str:
    base, quote = symbol.split("-", 1)
    return f"{base}/{quote}"


class KrakenFeed(Feed):
    venue = "kraken"

    def __init__(self, symbol: str, heartbeat_s: float = 20.0, url: str = WS_URL) -> None:
        super().__init__(symbol, heartbeat_s)
        self.url = url
        self.ksym = kraken_symbol(symbol)
        self._ws = None

    async def _run_once(self) -> None:
        async with websockets.connect(
            self.url, open_timeout=15, close_timeout=3, max_size=MAX_MSG_BYTES, ping_interval=20, ping_timeout=10
        ) as ws:
            self._ws = ws
            for ch in ("ticker", "trade"):
                params = {"channel": ch, "symbol": [self.ksym]}
                if ch == "ticker":
                    params["event_trigger"] = "bbo"
                sub = orjson.dumps({"method": "subscribe", "params": params}).decode()
                await asyncio.wait_for(ws.send(sub), timeout=5)
            async for raw in ws:
                self._touch()
                self.handle(raw)
        self._ws = None

    async def _on_heartbeat_timeout(self) -> None:
        ws = self._ws
        if ws is not None:
            await ws.close()

    def handle(self, raw: str | bytes) -> None:
        arrival = now_ns()
        if len(raw) > MAX_MSG_BYTES:
            self._malformed("oversize message")
            return
        try:
            msg = orjson.loads(raw)
        except orjson.JSONDecodeError:
            self._malformed("bad json")
            return
        if not isinstance(msg, dict):
            self._malformed("non-object")
            return
        ch = msg.get("channel")
        if ch == "ticker":
            self._on_ticker(msg, arrival)
        elif ch == "trade":
            self._on_trade(msg)

    @guard
    def _on_ticker(self, msg: dict, arrival: int | None = None) -> None:
        recv = now_ns()
        for d in msg["data"]:
            if d.get("symbol") != self.ksym:
                continue
            self._emit(
                Quote(
                    self.venue,
                    self.symbol,
                    to_price_i(d["bid"]),
                    self._size_i(d["bid_qty"]),
                    to_price_i(d["ask"]),
                    self._size_i(d["ask_qty"]),
                    parse_rfc3339_ns(d["timestamp"]) if d.get("timestamp") is not None else recv,
                    recv,
                    self.next_seq(),
                    ts_arrival_ns=arrival if arrival is not None else recv,
                )
            )

    @guard
    def _on_trade(self, msg: dict) -> None:
        if msg.get("type") == "snapshot":
            return
        recv = now_ns()
        for d in msg["data"]:
            if d.get("symbol") != self.ksym:
                continue
            side_s = d.get("side")
            if side_s == "buy":
                side = Side.BUY
            elif side_s == "sell":
                side = Side.SELL
            else:
                raise MalformedInput(f"trade side {side_s!r}")
            self._emit(
                Trade(
                    self.venue,
                    self.symbol,
                    to_price_i(d["price"]),
                    self._size_i(d["qty"]),
                    side,
                    parse_rfc3339_ns(d["timestamp"]),
                    recv,
                    self.next_seq(),
                    trade_id=str(d["trade_id"]) if d.get("trade_id") is not None else None,
                )
            )
