# Lossless: a graph keeps policy_document keys verbatim; compile never synthesizes or casts.
from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Mapping
from types import MappingProxyType

from leafhft.engine_layers import KERNEL_PARAM_KEYS, POLICY_FIELD_SECTIONS, _KERNEL_BOUNDS
from leafhft.policy import (
    OPTIONAL_POLICY_BOUNDS, POLICY_BOUNDS, KalshiPolicy, PolicyError,
    _validate_field, policy_document, policy_from_mapping,
)

GRAPH_SCHEMA = "leafhft.engine-graph.v1"
MAX_GRAPH_BYTES = 65536
SLOTS: tuple[str, ...] = (
    "level", "variance", "adjuster", "gates_admission", "gates_price",
    "gates_depth", "exits", "sizing", "stakes", "latches",
)
LOCKED_SLOTS = frozenset({"sizing", "stakes", "latches"})
BLOCKS: Mapping[str, dict] = MappingProxyType({
    "level.index_1hz": {"slot": "level", "version": 1},
    "level.fast_index": {"slot": "level", "version": 1},
    "variance.mad": {"slot": "variance", "version": 1},
    "variance.ew600": {"slot": "variance", "version": 1},
    "adjust.none": {"slot": "adjuster", "version": 1},
    "adjust.ridge_logistic": {"slot": "adjuster", "version": 1},
    "gates.admission_v1": {"slot": "gates_admission", "version": 1},
    "gates.price_v1": {"slot": "gates_price", "version": 1},
    "gates.depth_v1": {"slot": "gates_depth", "version": 1},
    "exits.value_vs_hold_v1": {"slot": "exits", "version": 1},
    "sizing.policy_v1": {"slot": "sizing", "version": 1},
    "stakes.policy_v1": {"slot": "stakes", "version": 1},
    "latches.policy_v1": {"slot": "latches", "version": 1},
})
_SECTION_SLOTS = {
    "admission_thresholds": "gates_admission", "price_bounds": "gates_price",
    "depth": "gates_depth", "sizing": "sizing", "stakes": "stakes",
    "drawdown_latches": "latches", "exits": "exits",
}
_POLICY_KEYS = frozenset(POLICY_BOUNDS) | frozenset(OPTIONAL_POLICY_BOUNDS)
_KERNEL_ID = re.compile(r"[a-z0-9][a-z0-9_.-]{0,63}")


class GraphError(ValueError):
    code: str
    detail: str

    def __init__(self, code: str, detail: str):
        self.code = code
        self.detail = detail
        super().__init__(f"{code}: {detail}")


def slot_of_key(key: str) -> str:
    if not isinstance(key, str) or key not in _POLICY_KEYS:
        raise GraphError("unknown_key", str(key))
    section = POLICY_FIELD_SECTIONS[key]
    if section != "transform":
        return _SECTION_SLOTS[section]
    if key == "mean_fast_index":
        return "level"
    if key == "variance_estimator":
        return "variance"
    if key.startswith("calibration_"):
        return "adjuster"
    if key in ("exit_variance_scale", "exit_variance_estimator"):
        return "exits"
    raise GraphError("unknown_key", key)


LOCKED_KEYS: frozenset[str] = frozenset(
    key for key in _POLICY_KEYS if slot_of_key(key) in LOCKED_SLOTS
) | frozenset({"reversal_mult", "reversal_input_age_ms", "reversal_execution_mode"})
_CALIBRATION_KEYS = frozenset(key for key in _POLICY_KEYS if slot_of_key(key) == "adjuster")


def block_for(slot: str, values: Mapping[str, object]) -> str:
    if not isinstance(slot, str) or slot not in SLOTS:
        raise GraphError("unknown_slot", str(slot))
    if not isinstance(values, Mapping):
        raise GraphError("bad_type", slot + ".values")
    if slot == "level":
        selector = values.get("mean_fast_index", 0)
        if selector == 0:
            return "level.index_1hz"
        if selector == 1:
            return "level.fast_index"
    elif slot == "variance":
        selector = values.get("variance_estimator", 1)
        if selector == 1:
            return "variance.mad"
        if selector == 2:
            return "variance.ew600"
    elif slot == "adjuster":
        present = _CALIBRATION_KEYS.intersection(values)
        if not present:
            return "adjust.none"
        if present == _CALIBRATION_KEYS:
            return "adjust.ridge_logistic"
    else:
        return next(block for block, spec in BLOCKS.items() if spec["slot"] == slot)
    raise GraphError("block_mismatch", slot)


def _keys(value, expected, where: str, *, unknown_code="unknown_key") -> None:
    if not isinstance(value, dict):
        raise GraphError("bad_type", where + " must be a dict")
    if any(type(key) is not str for key in value):
        raise GraphError("bad_type", where + " keys must be strings")
    unknown = set(value) - set(expected)
    if unknown:
        raise GraphError(unknown_code, sorted(unknown)[0])
    missing = set(expected) - set(value)
    if missing:
        raise GraphError("missing_key", sorted(missing)[0])


def _number(value, where: str) -> None:
    if type(value) not in (int, float):
        raise GraphError("bad_type", where)
    if type(value) is float and not math.isfinite(value):
        raise GraphError("nonfinite", where)


def _kernel(kernel_id, params) -> None:
    if type(kernel_id) is not str or _KERNEL_ID.fullmatch(kernel_id) is None:
        raise GraphError("bad_type", "kernel.id")
    if not isinstance(params, Mapping):
        raise GraphError("bad_type", "kernel.params")
    for key, value in params.items():
        if type(key) is not str:
            raise GraphError("bad_type", "kernel.params keys must be strings")
        if key not in KERNEL_PARAM_KEYS:
            raise GraphError("unknown_key", key)
        where = "kernel.params." + key
        if key == "settlement_method":
            if not isinstance(value, str) or value not in ("mean", "trimmed_mean_20"):
                raise GraphError("bad_type", where)
        else:
            _number(value, where)
            try:
                _validate_field(key, value, *_KERNEL_BOUNDS[key])
            except PolicyError as err:
                raise GraphError("bad_type", where) from err


def decompile(policy: KalshiPolicy, *, kernel_id: str,
              kernel_params: Mapping[str, object] | None = None) -> dict:
    params = {} if kernel_params is None else kernel_params
    _kernel(kernel_id, params)
    values = {slot: {} for slot in SLOTS}
    for key, value in policy_document(policy).items():
        values[slot_of_key(key)][key] = value
    return {
        "schema": GRAPH_SCHEMA,
        "kernel": {"id": kernel_id, "params": dict(sorted(params.items()))},
        "slots": {slot: {"block": block_for(slot, values[slot]), "version": 1,
                         "values": values[slot]} for slot in SLOTS},
    }


def _canonical(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def validate_graph(graph: object) -> None:
    _keys(graph, {"schema", "kernel", "slots"}, "graph")
    if graph["schema"] != GRAPH_SCHEMA:
        raise GraphError("schema_unsupported", "schema")
    kernel = graph["kernel"]
    _keys(kernel, {"id", "params"}, "kernel")
    if not isinstance(kernel["params"], dict):
        raise GraphError("bad_type", "kernel.params")
    _kernel(kernel["id"], kernel["params"])
    _keys(graph["slots"], SLOTS, "slots", unknown_code="unknown_slot")
    for slot in SLOTS:
        entry = graph["slots"][slot]
        _keys(entry, {"block", "version", "values"}, slot)
        block = entry["block"]
        if type(block) is not str or block not in BLOCKS:
            raise GraphError("unknown_block", str(block))
        if BLOCKS[block]["slot"] != slot:
            raise GraphError("wrong_slot", block)
        if type(entry["version"]) is not int or entry["version"] != BLOCKS[block]["version"]:
            raise GraphError("unknown_block", block + " version")
        values = entry["values"]
        if not isinstance(values, dict):
            raise GraphError("bad_type", slot + ".values")
        for key, value in values.items():
            if slot_of_key(key) != slot:
                raise GraphError("wrong_slot", key)
            _number(value, key)
        if block_for(slot, values) != block:
            raise GraphError("block_mismatch", slot)
    for key in sorted(POLICY_BOUNDS):
        if key not in graph["slots"][slot_of_key(key)]["values"]:
            raise GraphError("missing_key", key)
    if len(_canonical(graph)) > MAX_GRAPH_BYTES:
        raise GraphError("oversize", "graph exceeds byte limit")


def _compile_document_and_policy(graph) -> tuple[dict, KalshiPolicy]:
    validate_graph(graph)
    values = {key: value for slot in SLOTS
              for key, value in graph["slots"][slot]["values"].items()}
    document = dict(sorted(values.items()))
    try:
        policy = policy_from_mapping(document)
    except PolicyError as err:
        raise GraphError("policy_invalid", str(err)) from err
    effective = policy_document(policy)
    if _canonical(effective) != _canonical(document):
        normalized = sorted(
            key for key in set(document) | set(effective)
            if key not in document or key not in effective
            or _canonical(document[key]) != _canonical(effective[key])
        )
        raise GraphError("policy_invalid", "normalized: " + ",".join(normalized))
    return document, policy


def compile_document(graph) -> dict:
    return _compile_document_and_policy(graph)[0]


def compile_policy(graph) -> KalshiPolicy:
    return _compile_document_and_policy(graph)[1]


def graph_digest(graph) -> str:
    document = compile_document(graph)
    return hashlib.sha256(_canonical({"kernel": graph["kernel"], "policy": document}).encode()).hexdigest()


def assert_unlocked_unchanged(child: dict, parent: dict) -> None:
    child_document = compile_document(child)
    parent_document = compile_document(parent)
    for key in sorted(LOCKED_KEYS):
        if ((key in child_document) != (key in parent_document)
                or (key in child_document
                    and _canonical(child_document[key]) != _canonical(parent_document[key]))):
            raise GraphError("locked_key", key)
    if _canonical(child["kernel"]) != _canonical(parent["kernel"]):
        raise GraphError("locked_key", "kernel")
