"""leafhft command line.

  python -m leafhft paper  --venue binanceus --symbol BTC-USD --strategy mm --seconds 900
  python -m leafhft record --venue coinbase  --symbol BTC-USD --seconds 600
  python -m leafhft replay --venue coinbase  --symbol BTC-USD --strategy momentum --file runs/x/ticks.jsonl
  python -m leafhft goal
  python -m leafhft policy show|validate|set key=value ... [--path P] [--dry-run]
  python -m leafhft policy promote key --from shadow.json --require-ready report.json [--to P]
  python -m leafhft verify --ledger runs/x/ledger.sqlite
  python -m leafhft live   ... (refuses unless the live gate is armed; see broker/live_gate.py)
  python -m leafhft live-reconcile --venue binanceus --symbol BTC-USD [--cancel]
  python -m leafhft perp-replay <kalshi record dir>   (perp_breakout + PerpSleeve, no orders)
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import secrets
import signal
import shutil
import sys
import time
from pathlib import Path
from typing import Any

import orjson

from .broker.kalshi_all_in import KalshiAllInOnce, compute_all_in_count
from .broker.kalshi_book import KALSHI_LIMITS_PROFILES
from .broker.paper import PaperBroker
from .build import build_identity
from .config import EngineConfig, PaperModel, RiskLimits
from .engine import Engine
from .fees import schedule_for
from .feeds.base import IndexTick, IndexTickFast, Lifecycle, make_feed
from .feeds.recorder import FLUSH_ROWS, Recorder, iter_file
from .ledger import Ledger
from .policy import PolicyWatcher
from .risk import RiskManager
from .recorder_health import RecorderHealth
from .strategy import make_strategy
from .types import PRICE_UNIT, QUOTE_UNIT, Quote, to_quote_q

KALSHI_LIVE_IDLE_S = 300.0  # a quiet Kalshi socket is normal (thin markets); the venue heartbeat is slower than a taker feed
KALSHI_LIVE_MAX_RECONNECTS = 12  # bounded budget: past this a dead venue is a clean stop, never a crash-looped unit
KALSHI_STATUS_INTERVAL_S = 30.0  # at most one kalshi-edge-status.json write per this many seconds
_LIVE_READER_MAX_AGE_S = 6 * KALSHI_STATUS_INTERVAL_S  # six missed heartbeats: live books measured
# 2 to 9 s old, corpses from an 11-minute-old restart measured 716 to 724 s old (19:22:22Z), so six
# intervals leaves two orders of magnitude of margin between the two populations.
KALSHI_CRYPTO_EXCHANGE_INDEX = 2  # "Crypto & Commodities" (live /exchange/status, 2026-09-10)


def _encode_kalshi_extra(ev: IndexTick | IndexTickFast | Lifecycle) -> bytes:
    return orjson.dumps(_kalshi_extra_row(ev))


def _kalshi_extra_row(ev: IndexTick | IndexTickFast | Lifecycle) -> dict:
    """Row shapes for the Kalshi-only event kinds the base Recorder does not know about.
    `local_ns` is stamped here, at write time, beside the venue-carried timestamp on every row."""
    if isinstance(ev, IndexTickFast):
        return {
                "t": "i5",
                "index_id": ev.index_id,
                "value_i": ev.value_i,
                "source_ts_ms": ev.source_ts_ms,
                "received_at_ms": ev.received_at_ms,
                "local_ns": ev.ts_recv_ns,
            }
    if isinstance(ev, IndexTick):
        row = {
            "t": "i",
            "index_id": ev.index_id,
            "value_i": ev.value_i,
            "source_ts_ms": ev.source_ts_ms,
            "received_at_ms": ev.received_at_ms,
            "local_ns": ev.local_ns,
        }
        for name in ("avg60_value_i", "avg60_window_size", "avg60_window_start_ms"):
            try:
                value = getattr(ev, name, None)
                # Match IndexTick's integer contract and orjson's unsigned 64-bit limit.
                if type(value) is int and 0 <= value <= 18446744073709551615:
                    row[name] = value
            except Exception:
                # Optional venue state must not interrupt index recording.
                continue
        return row
    return {
            "t": "l",
            "ticker": ev.ticker,
            "status": ev.status,
            "close_time_ms": ev.close_time_ms,
            "expiration_time_ms": ev.expiration_time_ms,
            "strike_i": ev.strike_i,
            "local_ns": time.time_ns(),
        }


def _lifecycle_series_prefix(symbol):
    """'KXGOLD15M-' for a known Kalshi symbol; None exports every lifecycle (unknown symbol)."""
    try:
        from .feeds.kalshi import symbol_to_series

        (series,), _ = symbol_to_series(symbol)
        return series + "-"
    except Exception:
        return None


class _KalshiShadowExport:
    """Synchronous, fenced observation only; callers hold no lane/authority lock.

    Cost budget: one row construction and one nonblocking publish per event.
    The existing 512-sample reservoir reports the whole event cost in milliseconds,
    including encoding, separately from the publisher's own cost_us reservoir.
    """

    def __init__(self, path, symbol, epoch):
        self.enabled = bool(path)
        self.requested = self.enabled
        self.symbol = symbol
        self.publisher = None
        self.cost = None
        self.control_cost = None
        self.errors = 0
        self.last_error = ""
        self.binding = None
        self.paused = False
        self.heartbeat_at = None
        self.control_at = float("-inf")
        self._policy_obj = None
        self._policy_digest = None
        # Kalshi broadcasts every series' market_lifecycle_v2 to every recorder; at a quarter-hour
        # roll that burst overflowed the collector socket. Consumers discard foreign series, so
        # only this symbol's own lifecycles are exported. Trades, quotes and indexes are untouched.
        self._lifecycle_prefix = _lifecycle_series_prefix(symbol)
        self.lifecycle_skipped = 0
        if not self.enabled:
            return
        try:
            from .shadow_stream import ShadowPublisher
            from .broker.kalshi_live import LatencyReservoir

            socket_path = Path(path)
            if not socket_path.is_absolute():
                raise ValueError("socket path must be absolute")
            if len(os.fsencode(path)) >= 100:
                raise ValueError("socket path must be under 100 bytes")
            if not socket_path.parent.is_dir():
                raise ValueError("socket parent directory must exist")
            self.cost = LatencyReservoir()
            self.control_cost = LatencyReservoir()
            self.publisher = ShadowPublisher(path, epoch=epoch)
        except Exception as exc:
            self._error(exc)
            self.last_error = str(exc)
            self.enabled = False
        print(f"shadow export socket={os.fspath(path)!r} enabled={self.enabled}"
              + (f" reason={self.last_error}" if not self.enabled else ""),
              file=sys.stderr, flush=True)

    def _error(self, exc):
        # The S1 publisher normally catches/counts its own errors. This fence also
        # covers encoder failures and replacement publishers which raise.
        self.errors += 1
        self.last_error = type(exc).__name__
        try:
            if self.publisher is not None:
                self.publisher.errors += 1
                self.publisher.dropped += 1
                self.publisher.dropped_since_last += 1
                self.publisher.last_error = self.last_error
        except Exception:
            pass

    def event(self, ev, dequeued_ns):
        if self.publisher is None:
            return
        started = None
        try:
            started = time.perf_counter_ns()
            from .feeds.recorder import row as recorder_row

            if (isinstance(ev, Lifecycle) and self._lifecycle_prefix is not None
                    and not (isinstance(ev.ticker, str) and ev.ticker.startswith(self._lifecycle_prefix))):
                self.lifecycle_skipped += 1
                return
            if isinstance(ev, (IndexTick, IndexTickFast, Lifecycle)):
                row = _kalshi_extra_row(ev)
                if isinstance(ev, Lifecycle):
                    # The frame's own arrival keeps t_recv_ns monotone with the trades and
                    # quotes around it; dequeue time only for a Lifecycle that carries none.
                    kind = "lifecycle"
                    received = ev.ts_recv_ns if ev.ts_recv_ns is not None else dequeued_ns
                elif isinstance(ev, IndexTickFast):
                    kind, received = "index5", ev.ts_recv_ns
                else:
                    # IndexTick calls its receive timestamp local_ns.
                    kind, received = "index", ev.local_ns
            else:
                row = recorder_row(ev)
                kind, received = ("quote" if isinstance(ev, Quote) else "trade"), ev.ts_recv_ns
            self.publisher.publish(kind, self.symbol, row, received)
        except Exception as exc:
            self._error(exc)
        finally:
            try:
                if started is not None:
                    self.cost.record(time.perf_counter_ns() - started)
            except Exception as exc:
                self._error(exc)

    def control(self, now_ns, now_mono, engine, policy, lanes, darkhorse, paused,
                *, force_binding=False, entry_enabled=True):
        if self.publisher is None:
            return
        if now_mono - self.control_at < 1.0:
            return
        self.control_at = now_mono
        started = time.perf_counter_ns()
        try:
            binding = self.transition(now_ns, engine, policy, lanes, darkhorse, paused,
                                      force_binding=force_binding, entry_enabled=entry_enabled)
            if self.heartbeat_at is None:
                self.heartbeat_at = now_mono
            elif now_mono - self.heartbeat_at >= 30.0:
                self.heartbeat_at = now_mono
                self.publisher.publish("heartbeat", self.symbol, self.publisher.snapshot(),
                                       now_ns, binding=binding)
        except Exception as exc:
            self._error(exc)
        finally:
            try:
                self.control_cost.record(time.perf_counter_ns() - started)
            except Exception as exc:
                self._error(exc)

    def transition(self, now_ns, engine, policy, lanes, darkhorse, paused,
                   *, force_binding=False, entry_enabled=True):
        """Publish state in the synchronous stretch that applies a transition."""
        if self.publisher is None:
            return None
        from .policy import policy_digest

        if policy is not self._policy_obj:
            digest = policy_digest(policy) if policy is not None else None
            self._policy_obj, self._policy_digest = policy, digest
        binding = {"engine_id": engine.get("engine_id") if engine else None,
                   "policy_digest": self._policy_digest,
                   "entry_enabled": entry_enabled,
                   "lane_ids": ["engines"] + (["darkhorse"] if darkhorse.client is not None else [])
                               + [runner.lane_id for runner in lanes]}
        if force_binding or binding != self.binding:
            if self.publisher.publish("binding", self.symbol, binding, now_ns, binding=binding):
                self.binding = binding
        if paused != self.paused:
            if self.publisher.publish("pause", self.symbol, {"paused": paused}, now_ns):
                self.paused = paused
        return binding

    def snapshot(self):
        if not self.requested:
            return None
        try:
            result = dict(self.publisher.snapshot()) if self.publisher is not None else {}
            result["event_cost_ms"] = self.cost.snapshot() if self.cost is not None else None
            result["control_cost_ms"] = self.control_cost.snapshot() if self.control_cost is not None else None
            result["enabled"] = self.enabled
            result["fence_errors"] = self.errors
            result["lifecycle_skipped"] = self.lifecycle_skipped
            if self.publisher is None:
                result.update(errors=self.errors, last_error=self.last_error)
            return result
        except Exception as exc:
            self._error(exc)
            return {"fence_errors": self.errors, "last_error": self.last_error}

    def close(self):
        try:
            if self.publisher is not None:
                self.publisher.close()
        except Exception as exc:
            self._error(exc)


def cmd_shadow_collect(a: argparse.Namespace) -> int:
    from .shadow_collect import main as collect_main

    return collect_main(["--socket", a.socket, "--spool", a.spool,
                         "--max-spool-bytes", str(a.max_spool_bytes),
                         "--min-free-gb", str(a.min_free_gb)])


class KalshiRecorder(Recorder):
    """Recorder subclass that also accepts index, fast-index, and lifecycle rows,
    kept out of the shared Recorder so other venues' encode/decode contract is untouched."""

    def write(self, ev) -> None:
        if isinstance(ev, (IndexTick, IndexTickFast, Lifecycle)):
            self._buf.append(_encode_kalshi_extra(ev))
            self.rows += 1
            if len(self._buf) >= FLUSH_ROWS:
                self.flush()
            return
        super().write(ev)


class PolymarketUSRecorder(Recorder):
    """Polymarket US tape adds lifecycle rows; index rows belong to Kalshi's tape."""

    def write(self, ev) -> None:
        if isinstance(ev, Lifecycle):
            row = orjson.loads(_encode_kalshi_extra(ev))
            row.update(strike_type=ev.strike_type, open_time_ms=ev.open_time_ms)
            self._buf.append(orjson.dumps(row))
            self.rows += 1
            if len(self._buf) >= FLUSH_ROWS:
                self.flush()
            return
        super().write(ev)


def _run_dir(base: str, tag: str) -> Path:
    root = Path(base)
    root.mkdir(parents=True, exist_ok=True)
    prefix = f"{time.strftime('%Y%m%d-%H%M%S', time.gmtime())}-{tag}"
    for attempt in range(64):
        # Keep both the original prefix and the trailing tag used by discovery globs.
        name = prefix if attempt == 0 else f"{prefix}-{attempt + 1}-{tag}"
        p = root / name
        try:
            os.mkdir(p)
        except FileExistsError:
            continue
        return p
    raise FileExistsError(f"Could not allocate run directory after 64 attempts: {prefix}")


def _params(s: str) -> dict:
    if not s:
        return {}
    d = json.loads(s)
    if not isinstance(d, dict):
        raise SystemExit("--params must be a JSON object")
    return d


def _cost_rt_bps(cfg: EngineConfig, fees) -> float:
    """Round-trip cost: maker legs for mm/meanrev, taker legs for momentum/probe."""
    if cfg.strategy in ("momentum", "probe"):
        return 2.0 * (fees.taker_bps + cfg.paper.taker_slippage_bps)
    return 2.0 * (fees.maker_bps + cfg.paper.adverse_selection_bps)


def _build(cfg: EngineConfig, run_dir: Path, record: bool, clock=None) -> Engine:
    if cfg.strategy == "probe" and cfg.mode == "live":
        raise SystemExit("probe is paper-only")
    fees = schedule_for(cfg.venue if cfg.venue != "binanceus" or not cfg.strategy_params.get("tier0") else "binanceus_tier0")
    broker = PaperBroker(cfg.venue, cfg.symbol, fees, cfg.paper, cfg.starting_cash_q)
    risk = RiskManager(cfg.risk, cfg.starting_cash_q, kill_file=run_dir / "KILL")
    ledger = Ledger(run_dir / "ledger.sqlite")
    params = dict(cfg.strategy_params)
    params["cost_rt_bps"] = _cost_rt_bps(cfg, fees)  # authoritative: a caller cannot understate its costs
    params.setdefault("min_edge_bps", 0.25)
    strategy = make_strategy(cfg.strategy, params, cfg.venue)
    strategy.authorized_stake_cents = None
    if getattr(strategy, "is_probe", False):
        cost = strategy.cost_rt_bps
        target = strategy.state()["target_fills_per_hour"]
        print(f"PROBE: paper-only execution probe, expected cost {cost:.1f} bps per round trip, target {target:.0f} fills/hour", flush=True)
    elif getattr(strategy, "fee_dead", False):
        print(f"WARNING: {cfg.strategy} on {cfg.venue} is fee-dead by construction: take-profit <= round-trip cost {params['cost_rt_bps']:.1f} bps", flush=True)
    recorder = Recorder(run_dir / "ticks.jsonl") if record else None
    (run_dir / "config.json").write_text(json.dumps(_cfg_dict(cfg), indent=2), encoding="utf-8")
    return Engine(cfg, strategy, broker, risk, ledger, run_dir, recorder=recorder, clock=clock)


def _cfg_dict(cfg: EngineConfig) -> dict:
    from dataclasses import asdict

    d = asdict(cfg)
    if not cfg.classification_mode:
        # X3i: the digest's rule, so an unset config serializes exactly as before X3i and a
        # pre-X3i parser (cls(**d)) still loads it after a code rollback.
        del d["classification_mode"]
    if cfg.hot_observation_mode == "off":
        # Off preserves the pre-switch config.json bytes and digest.
        del d["hot_observation_mode"]
    if not getattr(cfg, "executor_mode", False):
        # C16c: the same rule, so a flag-off config loads in pre-C16c code after a rollback.
        d.pop("executor_mode", None)
    d["digest"] = cfg.digest()
    # Computed OUTSIDE the dataclass, so build can never enter EngineConfig.digest().
    d["build"] = dict(build_identity())
    return d


def cmd_paper(a: argparse.Namespace) -> int:
    if a.venue == "kalshi":
        return cmd_kalshi_paper_orders(a)
    if getattr(a, "fuzz_seed", None) is not None or getattr(a, "paper_orders", None):
        raise SystemExit("paper order fuzzing requires --venue kalshi")
    from dataclasses import replace

    limits = RiskLimits.conservative() if a.strategy == "anchor_mm" else RiskLimits()
    if a.stale_ms is not None:
        limits = replace(limits, stale_feed_ms=a.stale_ms)
    cfg = EngineConfig(
        venue=a.venue,
        symbol=a.symbol,
        strategy=a.strategy,
        mode="paper",
        reference_venue=getattr(a, "reference_venue", ""),
        starting_cash_q=to_quote_q(a.cash),
        goal_q=to_quote_q(a.goal),
        strategy_params=_params(a.params),
        risk=limits,
        paper=PaperModel(latency_ms=a.latency_ms, queue_model=a.queue_model, adverse_selection_bps=a.haircut_bps, snapshot_fills=a.snapshot_fills),
        run_seconds=a.seconds,
        record_path="ticks.jsonl",
        mark_interval_ms=a.mark_ms,  # 250 ms default: the UIs follow a live run at 4 Hz by ledger row
    )
    run_dir = _run_dir(a.runs, f"paper-{a.venue}-{a.strategy}")
    eng = _build(cfg, run_dir, record=True)
    feed = make_feed(a.venue, a.symbol, **({"transport": a.transport} if a.venue == "binanceus" else {}))
    # feed.json: what the surfaces need to label the feed tile before the receipt lands (transport is
    # not part of EngineConfig, so it is not in config.json and must not disturb the config digest)
    (run_dir / "feed.json").write_text(
        json.dumps({"venue": a.venue, "symbol": a.symbol, "transport": (a.transport if a.venue == "binanceus" else "ws"), "feed": type(feed).__name__}, indent=2),
        encoding="utf-8",
    )
    print(f"run_dir={run_dir}", flush=True)
    receipt = asyncio.run(eng.run_live(feed))
    _print_receipt(receipt)
    try:
        from .signals import compute

        compute(run_dir)  # context for the UI, after the run: never on the hot path
    except Exception as e:  # noqa: BLE001 - signals are optional decoration on a finished run
        print(f"signals skipped: {type(e).__name__}: {e}", flush=True)
    return 0


def cmd_record(a: argparse.Namespace) -> int:
    from dataclasses import asdict
    from datetime import datetime, timezone

    tag = f"record-kalshi-{a.symbol}" if a.venue == "kalshi" else f"record-{a.venue}"
    if a.venue == "polymarket_us":
        tag = f"record-polymarket_us-{a.symbol}"
    run_dir = _run_dir(a.runs, tag)
    started_at = datetime.now(timezone.utc).isoformat()
    started = time.monotonic()
    last_event = started
    idle_s = getattr(a, "idle_s", 900)
    max_reconnects = getattr(a, "max_reconnects", 96)
    quiet_periods = reconnects = 0
    max_quiet_s = 0.0
    stop_reason = "seconds elapsed"
    feed = rec = None
    shadow_export = None
    signal_received = False
    active_task = None
    active_loop = None
    handlers = {}

    def on_signal(signum, frame) -> None:
        nonlocal signal_received
        signal_received = True
        if active_task is not None and not active_task.done():
            active_loop.call_soon_threadsafe(active_task.cancel)

    def report_exception(exc: BaseException) -> None:
        nonlocal stop_reason
        if stop_reason == "seconds elapsed":
            stop_reason = f"exception: {type(exc).__name__}"
        print(f"record: {type(exc).__name__}", file=sys.stderr, flush=True)

    async def go() -> None:
        nonlocal active_task, active_loop, last_event, quiet_periods
        nonlocal max_quiet_s, reconnects, stop_reason
        active_loop = asyncio.get_running_loop()
        active_task = asyncio.current_task()
        health_task = asyncio.create_task(health.run(run_dir / "recorder-health.json", feed, rec, shadow_export))
        deadline = asyncio.timeout(max(0, a.seconds - (time.monotonic() - started)))
        try:
            if signal_received:
                stop_reason = "signal"
                return
            # The deadline also runs while the venue sends no events.
            async with deadline:
                await feed.start()
                reconnect_failed = False
                while True:
                    try:
                        if reconnect_failed:
                            # A failed reconnect still gets one full quiet period before retry.
                            await asyncio.sleep(idle_s)
                            raise TimeoutError("reconnect remained idle")
                        async for ev in feed.events(idle_timeout_s=idle_s):
                            dequeued_ns = time.time_ns() if shadow_export is not None else 0
                            rec.write(ev)
                            try:
                                health.observe(ev)
                            except Exception as exc:
                                health.error(exc)
                            if shadow_export is not None:
                                shadow_export.event(ev, dequeued_ns)
                            if quiet_periods:
                                max_quiet_s = max(max_quiet_s, time.monotonic() - last_event)
                            last_event = time.monotonic()
                            if time.monotonic() - started >= a.seconds:
                                return
                        raise RuntimeError("feed stopped before recording deadline")
                    except TimeoutError:
                        quiet_periods += 1
                        max_quiet_s = max(max_quiet_s, time.monotonic() - last_event)
                        if reconnects >= max_reconnects:
                            stop_reason = "quiet: reconnect budget exhausted"
                            return
                        reconnects += 1
                        try:
                            await asyncio.wait_for(feed.reconnect(), timeout=min(idle_s, 10.0))
                            reconnect_failed = False
                        except TimeoutError:
                            reconnect_failed = True
        except TimeoutError as exc:
            if not deadline.expired():
                report_exception(exc)
        except (KeyboardInterrupt, asyncio.CancelledError):
            stop_reason = "signal"
        except Exception as exc:
            report_exception(exc)
        finally:
            active_task = None
            health_task.cancel()
            await asyncio.gather(health_task, return_exceptions=True)
            if quiet_periods:
                max_quiet_s = max(max_quiet_s, time.monotonic() - last_event)
            try:
                await asyncio.wait_for(feed.stop(), timeout=10.0)
            except (KeyboardInterrupt, asyncio.CancelledError):
                stop_reason = "signal"
            except Exception as exc:
                report_exception(exc)

    try:
        for sig in (signal.SIGINT, signal.SIGTERM):
            handlers[sig] = signal.signal(sig, on_signal)
        feed_kwargs = {}
        if a.venue == "binanceus":
            feed_kwargs["transport"] = a.transport
        elif a.venue == "kalshi":
            feed_kwargs["demo"] = getattr(a, "demo", False)
            feed_kwargs["index_5hz"] = True
        elif a.venue == "polymarket_us":
            from .feeds.polymarket_us import auth_from_env

            feed_kwargs["auth"] = auth_from_env()
        feed = make_feed(a.venue, a.symbol, **feed_kwargs)
        if a.venue == "polymarket_us":
            rec = PolymarketUSRecorder(run_dir / "ticks.jsonl")
        else:
            rec = KalshiRecorder(run_dir / "ticks.jsonl") if a.venue == "kalshi" else Recorder(run_dir / "ticks.jsonl")
        if a.venue == "kalshi" and getattr(a, "shadow_socket", None):
            shadow_export = _KalshiShadowExport(a.shadow_socket, a.symbol, run_dir.name)
        health = RecorderHealth(a.symbol, run_dir.name,
                                unit=os.environ.get("SYSTEMD_UNIT", ""),
                                series_prefix=_lifecycle_series_prefix(a.symbol) if a.venue == "kalshi" else None)
        asyncio.run(go())
    except KeyboardInterrupt:
        stop_reason = "signal"
    except Exception as exc:
        report_exception(exc)
    finally:
        try:
            if rec is not None:
                rec.close()
        except KeyboardInterrupt:
            stop_reason = "signal"
        except Exception as exc:
            report_exception(exc)
        stats = {}
        try:
            if feed is not None:
                stats = {k: v for k, v in asdict(feed.stats).items() if k != "errors"}
                if hasattr(feed, "quality"):
                    stats["quality"] = feed.quality()
        except KeyboardInterrupt:
            stop_reason = "signal"
        except Exception as exc:
            report_exception(exc)
        if signal_received:
            stop_reason = "signal"
        summary = {"run_dir": str(run_dir), "rows": rec.rows if rec is not None else 0,
                   "feed": stats, "quiet_periods": quiet_periods, "max_quiet_s": max_quiet_s,
                   "reconnects": reconnects, "stop_reason": stop_reason,
                   "started_at": started_at, "ended_at": datetime.now(timezone.utc).isoformat()}
        if shadow_export is not None:
            shadow_export.close()
            summary["shadow_export"] = shadow_export.snapshot()
        try:
            (run_dir / "record-summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        finally:
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
    print(json.dumps(summary, indent=2))
    return 0 if stop_reason == "seconds elapsed" else 2


def cmd_replay(a: argparse.Namespace) -> int:
    if a.venue == "kalshi":
        return cmd_kalshi_paper_orders(a)
    if getattr(a, "fuzz_seed", None) is not None or getattr(a, "paper_orders", None):
        raise SystemExit("paper order fuzzing requires --venue kalshi")
    cfg = EngineConfig(
        venue=a.venue,
        symbol=a.symbol,
        strategy=a.strategy,
        mode="replay",
        starting_cash_q=to_quote_q(a.cash),
        goal_q=to_quote_q(a.goal),
        strategy_params=_params(a.params),
        paper=PaperModel(latency_ms=a.latency_ms, queue_model=a.queue_model, adverse_selection_bps=a.haircut_bps, snapshot_fills=a.snapshot_fills),
        replay_path=a.file,
        run_seconds=a.seconds,
    )
    run_dir = _run_dir(a.runs, f"replay-{a.venue}-{a.strategy}")
    eng = _build(cfg, run_dir, record=False, clock=lambda: 0)
    t0 = time.perf_counter()
    receipt = eng.run_replay(iter_file(a.file))
    receipt["replay_wall_s"] = round(time.perf_counter() - t0, 3)
    _print_receipt(receipt)
    return 0


def cmd_kalshi_paper_orders(a: argparse.Namespace) -> int:
    """Offline JSONL quote/order replay; never constructs an authenticated client.

    Lines are {"quote": <Quote fields>} or {"order": <place_ioc_buy kwargs>}.
    Order client_id is the stable event identity. All clocks come from the file.
    """
    from .broker.kalshi_paper import PaperKalshiClient
    from .config import paper_fuzz_config
    from .sim.fuzz import PaperFuzzer, require_paper_environment
    from .types import Quote

    require_paper_environment(a.cmd)
    source = getattr(a, "paper_orders", None) or getattr(a, "file", None)
    if not source:
        raise SystemExit("Kalshi paper mode requires --paper-orders JSONL")
    fuzzer = None
    if a.fuzz_seed is not None:
        options = {
            "seed": a.fuzz_seed,
            "size_scale_min_bps": a.fuzz_size_min_bps,
            "size_scale_max_bps": a.fuzz_size_max_bps,
            "timing_jitter_min_ms": a.fuzz_jitter_min_ms,
            "timing_jitter_max_ms": a.fuzz_jitter_max_ms,
            "no_fill_probability_bps": a.fuzz_no_fill_bps,
        }
        config = paper_fuzz_config({key: value for key, value in options.items() if value is not None}, mode=a.cmd)
        fuzzer = PaperFuzzer(config, mode=a.cmd)
    cash_cents = to_quote_q(a.cash) * 100 // QUOTE_UNIT
    client = PaperKalshiClient(None, cash_cents, fill_model="arrival",
                               latency_ms=a.latency_ms, fuzzer=fuzzer)
    run_dir = _run_dir(a.runs, "kalshi-paper-orders")
    manifest = {"mode": a.cmd, "live": False, "fuzzer": client.fuzz_manifest}
    (run_dir / "paper-manifest.json").write_text(json.dumps(manifest, sort_keys=True), encoding="utf-8")

    async def replay_orders():
        with Path(source).open(encoding="utf-8") as stream, (run_dir / "paper-orders.jsonl").open("w", encoding="utf-8") as output:
            for index, line in enumerate(stream):
                if index >= 1_000_000 or len(line) > 65536:
                    raise ValueError("paper input exceeds bounds")
                event = json.loads(line)
                if type(event) is not dict or len(event) != 1:
                    raise ValueError("expected one quote or order per line")
                if "quote" in event:
                    quote = Quote(**event["quote"])
                    if quote.venue != "kalshi":
                        raise ValueError("expected a Kalshi quote")
                    client.observe(quote)
                elif "order" in event:
                    order = event["order"]
                    if type(order) is not dict or "decision_ns" not in order:
                        raise ValueError("paper orders require an explicit decision_ns")
                    reply = await client.place_ioc_buy(**order)
                    output.write(json.dumps(reply, sort_keys=True, default=str) + "\n")
                else:
                    raise ValueError("expected quote or order")

    asyncio.run(replay_orders())
    print(json.dumps({**manifest, "run_dir": str(run_dir), "stats": client.stats}, sort_keys=True))
    return 0


def cmd_goal(a: argparse.Namespace) -> int:
    from .sim.goal import report

    print(json.dumps(report(a.cash, a.goal), indent=2))
    return 0


def cmd_verify(a: argparse.Namespace) -> int:
    led = Ledger(a.ledger)
    ok, rows = led.verify()
    print(json.dumps({"ledger": a.ledger, "chain_ok": ok, "rows": rows, "fills": led.count("fill"), "orders": led.count("order")}))
    return 0 if ok else 2


def cmd_perp_replay(a: argparse.Namespace) -> int:
    from .strategy.perp_breakout import replay

    report = replay(a.record_dir, _params(a.params), profile=a.profile)
    print(json.dumps(report, indent=2))
    return 0


def _account_ok_line(account: dict, symbol: str) -> str:
    """Diagnostic only: booleans and free-balance amounts from the account reply, never an id."""
    parts = symbol.upper().split("-")
    base, quote = parts if len(parts) == 2 else ("", "")
    free = {}
    if isinstance(account, dict) and isinstance(account.get("balances"), list):
        for row in account["balances"]:
            if isinstance(row, dict) and isinstance(row.get("asset"), str):
                free[row["asset"]] = row.get("free")
    can_trade = account.get("canTrade") if isinstance(account, dict) else None
    permissions = account.get("permissions") if isinstance(account, dict) else None
    permissions = permissions if isinstance(permissions, list) else []
    return (f"account ok: canTrade={can_trade} permissions={permissions} "
            f"{quote.lower()}_free={free.get(quote)} {base.lower()}_free={free.get(base)}")


def _exception_detail(e: Exception) -> dict:
    """{class, http, code, msg}; the latter three are null unless e is a VenueError."""
    from .broker.binanceus_live import VenueError

    if isinstance(e, VenueError):
        return {"class": type(e).__name__, "http": e.http, "code": e.code, "msg": e.msg}
    return {"class": type(e).__name__, "http": None, "code": None, "msg": None}


def _copy_live_ack(cfg: EngineConfig, source_dir: str | None, run_dir: Path) -> Path | None:
    from .broker.live_gate import ack_path

    if not source_dir:
        return None
    source = ack_path(cfg, source_dir)
    if source.is_file():
        shutil.copyfile(source, ack_path(cfg, run_dir))
        return source
    return None


def _discard_refused_run_dir(cfg: EngineConfig, run_dir: Path) -> None:
    """Undo only what the CLI itself wrote: its own ack copy, then the (now-empty) dir.

    Never recursive: a directory holding anything else (e.g. an in-progress driver
    write) is left alone rather than risk deleting state a caller still owns.
    """
    from .broker.live_gate import ack_path

    try:
        ack_path(cfg, run_dir).unlink()
    except FileNotFoundError:
        pass
    try:
        run_dir.rmdir()
    except OSError:
        return
    print(f"discarded refused run dir {run_dir}", file=sys.stderr)


class _RehearsalStrategy:
    """A single probe goes through the same engine risk and broker gates as quotes."""

    def __init__(self, strategy, enabled: bool, started_ns: int) -> None:
        self.strategy = strategy
        self.params = strategy.params
        self.enabled = enabled
        self.started_ns = started_ns
        self.probe_pending = False
        self.probe_done = not enabled
        self.probe_side = None

    def __getattr__(self, item):
        # Forwards on_reference/on_timer (present only when the wrapped strategy has them, so the
        # engine's `callable(getattr(strategy, "on_reference", None))` gate still fails closed for a
        # strategy that cannot consume a reference feed) and any block-alternation bookkeeping.
        return getattr(self.strategy, item)

    @property
    def name(self):
        return self.strategy.name  # live, not a snapshot: an Alternator's name changes on a block switch

    @property
    def switched(self):
        return getattr(self.strategy, "switched", None)

    @switched.setter
    def switched(self, value):
        if hasattr(self.strategy, "switched"):
            self.strategy.switched = value

    def on_event(self, book, view, now_ns):
        from .strategy.base import snap_down, snap_up
        from .types import QUOTE_UNIT, SIZE_UNIT, Intent, Side, TimeInForce

        if not self.probe_done:
            elapsed = now_ns - self.started_ns >= 3600 * 1_000_000_000
            if not book.ready or book.quote is None:
                if elapsed:
                    from .broker.live_gate import LiveGateClosed
                    raise LiveGateClosed("probe not completed within first hour")
                return [], []
            px = snap_down(book.quote.bid_i * 9950 // 10000, self.strategy.tick_i)
            if px <= 0:
                if elapsed:
                    from .broker.live_gate import LiveGateClosed
                    raise LiveGateClosed("probe not completed within first hour")
                return [], []
            minimum = max(2 * self.strategy.lot_i,
                          ((self.strategy.min_notional_q * SIZE_UNIT + px - 1) // px
                           + self.strategy.lot_i - 1) // self.strategy.lot_i * self.strategy.lot_i)
            needed = (minimum * px + SIZE_UNIT - 1) // SIZE_UNIT
            if needed <= view.cash_q:
                self.probe_pending = True
                self.probe_side = "buy"
                return [Intent(Side.BUY, px, minimum, TimeInForce.POST_ONLY, "live rehearsal probe")], []
            if view.pos_i >= minimum:
                ask_px = snap_up(book.quote.ask_i * 10050 // 10000, self.strategy.tick_i)
                if ask_px > 0:
                    self.probe_pending = True
                    self.probe_side = "sell"
                    return [Intent(Side.SELL, ask_px, minimum, TimeInForce.POST_ONLY,
                                   "live probe (sell side)")], []
            if elapsed:
                from .broker.live_gate import LiveGateClosed
                raise LiveGateClosed(
                    "probe not completed within first hour: cash "
                    f"${view.cash_q / QUOTE_UNIT:.2f} below the venue minimum ${needed / QUOTE_UNIT:.2f} "
                    f"and inventory {view.pos_i} below {minimum}"
                )
            # The maker emits the throttled venue-minimum notice.
            self.strategy.on_event(book, view, now_ns)
            return [], []
        return self.strategy.on_event(book, view, now_ns)

    def on_stop(self, book, view, now_ns):
        return self.strategy.on_stop(book, view, now_ns)

    def state(self):
        return dict(self.strategy.state(), probe_done=self.probe_done)


def _consume_shared_ack_and_arm(cfg: EngineConfig, run_dir: Path, source_ack: Path | None):
    from .broker.live_gate import LiveGateClosed, ack_path, assert_armed
    import secrets

    if os.environ.get("LEAFHFT_AUTHZ_V2") == "1":
        if source_ack is not None:
            try:
                # Preserve the original authorization age across fresh run directories.
                destination = ack_path(cfg, run_dir)
                if source_ack.resolve() != destination.resolve():
                    shutil.copy2(source_ack, destination)
            except OSError as e:
                raise LiveGateClosed("shared ack could not be copied") from e
        return assert_armed(cfg, run_dir, ack_dir=source_ack.parent if source_ack is not None else None)

    if source_ack is not None:
        # Claim the shared original atomically. A copied ack must not authorize restarts.
        claimed = source_ack.with_name(source_ack.stem + ".consumed-" + secrets.token_hex(8) + ".txt")
        try:
            source_ack.rename(claimed)
            if claimed.read_bytes() != ack_path(cfg, run_dir).read_bytes():
                raise LiveGateClosed("shared ack changed before arming")
        except OSError as e:
            raise LiveGateClosed("shared ack could not be consumed") from e
    return assert_armed(cfg, run_dir)




def _kalshi_authority_generation(path: str) -> str:
    generation_path = Path(path).with_suffix(".generation")
    try:
        generation = generation_path.read_text(encoding="utf-8").strip()
        if not generation or len(generation) > 256:
            raise ValueError("invalid generation id")
        return generation
    except (OSError, UnicodeError, ValueError) as exc:
        raise ValueError(f"authority generation unavailable: {generation_path}") from exc


def _reversal_mode_configure_refusal(engines_dir, engine_id, values, lifecycle_dir=None):
    """C13 boundary at the configure step: reversal_execution_mode 2 on a lifecycle-managed (probe)
    engine is refused with reversal_mode_lifecycle_unsupported. Fails closed: a lifecycle store
    that cannot be read refuses too. None when the change does not enable mode 2."""
    from .canary import CanaryStore, lifecycle_directory
    from .policy import REVERSAL_MODE_CASHOUT_FIRST

    if values.get("reversal_execution_mode") != REVERSAL_MODE_CASHOUT_FIRST:
        return None
    try:
        record = CanaryStore(lifecycle_directory(engines_dir, lifecycle_dir)).optional(engine_id)
    except Exception:
        return REVERSAL_MODE_LIFECYCLE_UNSUPPORTED
    return None if record is None else REVERSAL_MODE_LIFECYCLE_UNSUPPORTED


def _classification_mode_arg(a):
    """X3i: `leafhft live --classification-mode` to the config field. Legacy (and an in-process caller
    with no such attribute) maps to "", so the digest and the written config stay unchanged; "ticker"
    rotates the digest on purpose. Anything else fails closed at EngineConfig validation."""
    mode = getattr(a, "classification_mode", None) or "legacy"
    return "" if mode == "legacy" else mode
from .kalshi_live_runtime import (  # L18a-move: the moved runtime, re-exported under its old names
    kalshi_cash_capped_count,
    kalshi_all_in_classify,
    KALSHI_ALL_IN_MAX_WINDOWS,
    KalshiAllInWindowBuffer,
    kalshi_all_in_build_plan,
    _kalshi_all_in_append_row,
    _kalshi_all_in_record_buy,
    kalshi_all_in_execute_plan,
    _kalshi_all_in_offer,
    kalshi_shard_refresh,
    kalshi_apply_cash_balance,
    kalshi_equity_day_open,
    KalshiExposureCache,
    venue_paused_from_status,
    KalshiVenueStatus,
    _EnginePolicyWatcher,
    _KalshiEngineWatcher,
    _kalshi_policy_source,
    _kalshi_experiment_assignment,
    _kalshi_serialize_experiment_book,
    _kalshi_experiment_refusal,
    _kalshi_exit_record,
    _kalshi_reversal_budget,
    _kalshi_reversal_outcome,
    _kalshi_settle_reversal_claims,
    _KalshiAuthorityStartupError,
    _kalshi_authority_startup,
    _authority_entry_terms,
    _KalshiEngineAuthority,
    _DARKHORSE_CAPS,
    RECONCILE_SEND_GRACE_S,
    MAINTENANCE_TIMEOUT_S,
    DARKHORSE_SEND_LEDGER_NAME,
    MAX_SEND_LEDGER_BYTES,
    SEND_WRITE_BUDGET_MS,
    _send_ms,
    _darkhorse_code_sha,
    _DarkHorseLateSend,
    _KalshiDarkHorse,
    _kalshi_persist_reversal_rows,
    _kalshi_plain_exit,
    _kalshi_execute_exit,
    REVERSAL_MODE_LIFECYCLE_UNSUPPORTED,
    REVERSAL_MARKET_HELD,
    REVERSAL_JOURNAL_UNUSABLE,
    REVERSAL_EXIT_UNRECONCILED,
    REVERSAL_HEDGE_NOT_PENDING,
    REVERSAL_REASON_SENTENCES,
    REVERSAL_CASHOUT_LATENCY_WINDOW,
    REVERSAL_HEDGE_RETRY_LIMIT,
    REVERSAL_ACCOUNTED_STATES,
    _kalshi_routes_cashout_first,
    _reversal_reason_text,
    CashoutFirstLatency,
    _kalshi_reversal_txn_path,
    _kalshi_reversal_txns,
    _kalshi_reversal_venue_reads,
    _ReversalExitUnreconciled,
    _ReversalRecoveryLedgerFailed,
    _VenueLegSnapshot,
    _kalshi_reversal_exits_booked,
    _kalshi_note_exit_booked,
    _kalshi_reversal_ledger_paths,
    _kalshi_reversal_seed_booked,
    _kalshi_fill_ns,
    _kalshi_exit_proceeds_in_seed,
    _kalshi_reversal_accounting_persisted,
    _kalshi_reversal_accounting_holds,
    _kalshi_book_recovered_exit,
    _kalshi_reversal_book_exits,
    _reversal_hedge_state_refusal,
    _kalshi_hedge_stop_refusal,
    _kalshi_guard_send_lock,
    _kalshi_guard_mode2_send_lock,
    _kalshi_guarded_hedge_send,
    _kalshi_hedge_refusal_reason,
    _kalshi_reversal_recover,
    _kalshi_settle_cashout_claims,
    _reversal_txn_of_hedge,
    _kalshi_execute_cashout_first,
    _kalshi_refresh_cap_halt,
    _kalshi_status_payload,
    _kalshi_latency_block,
    _kalshi_hot_observation_block,
    KalshiStatusWriter,
    PROBE_FIRST_COME_PATH,
    PROBE_LIMIT_MIN_CENTS,
    PROBE_MAX_OPEN_TICKETS,
    PROBE_SUBMIT_TIMEOUT_S,
    PROBE_CALL_TIMEOUT_S,
    PROBE_CLOSE_TIMEOUT_S,
    PROBE_CLOSE_RETRY_POLL_S,
    INCUMBENT_RECONCILE_DEFERRED,
    PROBE_RECONCILE_NS,
    PROBE_REFRESH_NS,
    PROBE_TIMER_SAMPLES,
    PROBE_SETTLEMENT_ROWS,
    PROBE_JOURNAL_ROWS,
    PROBE_MAX_FRAMES,
    DEFAULT_EXECUTION_DOMAIN,
    PROBE_LIMITS,
    _probe_floor_cents,
    _ProbeFloorPolicy,
    _ProbeFloorRiskLedger,
    SHARED_LOCK_WAIT_SAMPLES,
    SHARED_INCUMBENT_PARTITION,
    _ProbeFloorStrategy,
    _SharedSendLockMeter,
    _is_floor_refusal,
    _ProbeRegistryGate,
    _probe_settlement_poller,
    _ProbeSettlementFeed,
    _ProbeSlot,
    _probe_worker_barrier,
    _probe_submitted,
    _probe_floor_refused,
    _ProbeHost,
    _kalshi_live_close_clients,
    _kalshi_probe_account_id,
    _probe_precheck,
    _kalshi_classification_mode,
    _kalshi_classification_kwargs,
    _kalshi_probe_client_factory,
    _kalshi_probe_kernel_factory,
    _probe_share_market_cache,
    _account_risk_path,
    _probe_close_client,
    _close_client_session,
    _incumbent_prior_tickets,
    PROBE_UNADOPTABLE_REPORT_MAX,
    _probe_root_row_refusal,
    _probe_restart_adopt,
    _executor_mode_refusal,
    _executor_mode_share,
    _probe_drop_client,
    _kalshi_probe_host,
    _kalshi_record_decided,
    _kalshi_record_lean,
    DAY_START_SOURCE,
    DAY_START_SOURCE_MEMBER_KEY,
    DAY_START_SOURCE_UNMAPPED,
    DAY_START_SOURCE_MISMATCH,
    DAY_START_SOURCE_REGISTRY_INVALID,
    _projection_status,
    _probe_day_start_account,
    _ProbeDayStartSource,
    _probe_day_start_source,
    _probe_status_block,
    _kalshi_submit_recording_decided,
    _kalshi_lane_turns,
    _run_kalshi_live,
)


async def _adopt_venue_perp_position(client, sleeve, ticker: str) -> None:
    """A position the venue holds that this process never booked (a fill answered with 201 while the
    client treated it as unknown, or a restart mid-position) is adopted into the sleeve so the stop,
    trailing and time stop manage it. Any parse failure is logged and the sleeve starts flat: the
    venue's isolated margin is the bound in that case."""
    import secrets as _secrets
    from decimal import Decimal
    try:
        rows = await client.positions()
    except Exception as e:  # noqa: BLE001
        print(f"kalshi-perp positions read failed at start: {type(e).__name__}", file=sys.stderr, flush=True)
        return
    tickers = [str(r.get("ticker", r.get("market_ticker", "?")))[:24] for r in rows if isinstance(r, dict)][:20]
    print(f"kalshi-perp positions at start: rows={len(rows)} tickers={tickers}", file=sys.stderr, flush=True)
    for row in rows:
        if not isinstance(row, dict) or row.get("ticker", row.get("market_ticker")) != ticker:
            continue
        print(f"kalshi-perp position row keys: {sorted(str(k) for k in row.keys())[:30]}", file=sys.stderr, flush=True)
        try:
            raw = row.get("position", row.get("count", row.get("position_count", row.get("quantity", 0))))
            count_d = Decimal(str(raw))
            side_raw = str(row.get("side", row.get("position_side", row.get("direction", "")))).lower()
            if side_raw in ("bid", "long", "buy", "yes"):
                side = "bid"
            elif side_raw in ("ask", "short", "sell", "no"):
                side = "ask"
            else:
                side = "bid" if count_d > 0 else "ask"
            count = int(abs(count_d).to_integral_value())
            if count <= 0:
                continue
            entry_raw = row.get("average_price", row.get("entry_price", row.get("position_price")))
            entry = Decimal(str(entry_raw)) if entry_raw is not None else await client.mark(ticker)
            if not entry.is_finite() or entry <= 0:
                entry = await client.mark(ticker)
            await sleeve.adopt(ticker, side, count, entry, time.time_ns(), "lh-adopt-" + _secrets.token_hex(6))
            print(f"kalshi-perp adopted venue position: {side} {count} {ticker} @ {entry}", file=sys.stderr, flush=True)
            return
        except Exception as e:  # noqa: BLE001
            print(f"kalshi-perp position adoption failed: {type(e).__name__}: {str(e)[:120]}", file=sys.stderr, flush=True)
            return


def _sleeve_status_payload(strategy, sleeve, ticks: int, mark, tick_age_s: float) -> dict[str, Any]:
    """Snapshot of strategy+sleeve counters for sleeve-status.json and the stderr status line.
    Plain JSON-safe numbers only (no Decimal); every field bounded well under 1 KiB serialized."""
    from datetime import datetime, timezone

    st = strategy.state()
    position = sleeve.position
    if position is None:
        position_str = "flat"
    else:
        position_str = f"{'long' if position.side == 'bid' else 'short'} {position.count}"
    attempts = sum(1 for r in sleeve.ledger_rows if r.get("kind") == "open")
    stops = sum(1 for r in sleeve.ledger_rows if r.get("kind") == "close")
    realized_usd = float(sleeve.realized_usd)
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
        "ticks": ticks,
        "bars": st["bars_formed"],
        "evaluations": st["evaluations"],
        "compressed": st["compressed_bars"],
        "breakouts": st["breakout_bars"],
        "attempts": attempts,
        "stops": stops,
        "realized_usd": realized_usd,
        "position": position_str,
        "mark": float(mark) if mark is not None else 0.0,
        "tick_age_s": round(max(0.0, tick_age_s), 3),
        "halted": bool(sleeve.halted),
        "cumulative_loss_usd": max(0.0, -realized_usd),
        "close_bound_usd": float(sleeve.params.close_bound_usd),
    }


def _sleeve_status_line(payload: dict[str, Any]) -> str:
    return (f"sleeve: ticks={payload['ticks']} bars={payload['bars']} evaluations={payload['evaluations']} "
            f"compressed={payload['compressed']} breakouts={payload['breakouts']} attempts={payload['attempts']} "
            f"stops={payload['stops']} realized=${payload['realized_usd']:.2f} position={payload['position']} "
            f"mark={payload['mark']} tick_age_s={payload['tick_age_s']:.1f}")


def _write_sleeve_status(run_dir: Path, payload: dict[str, Any]) -> None:
    """Atomic (temp file + os.replace) write; a failure is logged once and never stops the loop."""
    tmp = run_dir / "sleeve-status.json.tmp"
    try:
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        os.replace(tmp, run_dir / "sleeve-status.json")
    except OSError as e:
        print(f"kalshi-perp sleeve status write failed: {type(e).__name__}: {e}", file=sys.stderr, flush=True)


class PolymarketUSBookClient:
    """Keep compact feed tickers in the book and full market slugs on the wire."""

    def __init__(self, client, feed, run_dir: Path) -> None:
        self.client, self.feed = client, feed
        self.path = run_dir / "polymarket-us-market-slugs.json"
        self.slugs = {}
        # Shadow-only tickets also need their market identity after a restart.
        from itertools import islice
        from .feeds.polymarket_us import market_ticker

        for directory in islice(run_dir.parent.iterdir(), 200):
            try:
                with (directory / self.path.name).open("rb") as stream:
                    data = stream.read(2 * 1024 * 1024 + 1)
                if len(data) > 2 * 1024 * 1024:
                    continue
                rows = json.loads(data)
                for ticker, slug in rows.items():
                    if (isinstance(slug, str) and len(slug) <= 512
                            and market_ticker(slug) == ticker and len(self.slugs) < 5000):
                        self.slugs[ticker] = slug
            except (OSError, ValueError, AttributeError):
                continue

    def __getattr__(self, name):
        return getattr(self.client, name)

    def remember(self, slug: str) -> str:
        from .feeds.polymarket_us import market_ticker

        ticker = market_ticker(slug)
        if not slug.startswith("pm-"):
            self.slugs[ticker] = slug
        return ticker

    @property
    def _records(self):
        return {cid: dict(row, ticker=self.remember(row["ticker"]))
                for cid, row in self.client._records.items()}

    def capture_markets(self) -> None:
        market_feed = getattr(self.feed, "market_feed", self.feed)
        current = getattr(market_feed, "_ticker_slugs", {})
        if (current and not self.path.exists()) or any(self.slugs.get(t) != slug for t, slug in current.items()):
            if len(self.slugs.keys() | current.keys()) > 5000:
                raise ValueError("market identity limit reached")
            self.slugs.update(current)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.slugs), encoding="utf-8")
            os.replace(tmp, self.path)

    def _slug(self, ticker):
        self.capture_markets()
        if ticker.startswith("pm-") and ticker not in self.slugs:
            raise ValueError("market slug unavailable")
        return self.slugs.get(ticker, ticker)

    async def place_ioc_buy(self, ticker, side_yes, price_cents, count, client_id):
        return await self.client.place_ioc_buy(self._slug(ticker), side_yes, price_cents, count, client_id)

    async def market(self, ticker):
        return await self.client.market(self._slug(ticker))

    async def __aenter__(self):
        await self.client.__aenter__()
        return self

    async def __aexit__(self, *exc):
        return await self.client.__aexit__(*exc)


class PolymarketUSVenueStatus:
    """Cached exchange state shared by the live and shadow books."""

    def __init__(self) -> None:
        self.venue_paused = False
        self._paused_mono: float | None = None
        self._checked_mono = -float("inf")
        self._error_mono = -float("inf")
        self.block = dict(exchange_active=None, trading_active=None, estimated_resume=None,
                          paused_since=None, checked_at=None)

    async def refresh(self, client, now_mono: float) -> None:
        from datetime import datetime, timezone

        if now_mono - self._checked_mono < 30.0:
            return
        self._checked_mono = now_mono
        try:
            status = await client.exchange_status()
        except Exception as e:
            if not self.venue_paused:
                self._paused_mono = now_mono
                self.block["paused_since"] = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
            self.venue_paused = True
            if now_mono - self._error_mono >= 60.0:
                self._error_mono = now_mono
                print(f"polymarket_us exchange status failed: {type(e).__name__}", file=sys.stderr, flush=True)
            return  # retain the last successful status while trading stays paused
        checked_at = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
        paused, _ = venue_paused_from_status(status)
        if paused and not self.venue_paused:
            self._paused_mono = now_mono
            self.block["paused_since"] = checked_at
            print(f"polymarket_us trading paused until {status['estimated_resume'] or 'unknown'}",
                  file=sys.stderr, flush=True)
        elif self.venue_paused and not paused:
            print(f"polymarket_us trading active again after {now_mono - self._paused_mono:.0f} s",
                  file=sys.stderr, flush=True)
            self._paused_mono = None
            self.block["paused_since"] = None
        self.venue_paused = paused
        self.block.update(exchange_active=status["exchange_active"], trading_active=status["trading_active"],
                          estimated_resume=status["estimated_resume"], checked_at=checked_at)



class PolymarketUSStatusWriter(KalshiStatusWriter):
    """Use the shared cadence and payload for the sibling venue's status file."""

    def write(self, run_dir: Path, payload: dict[str, Any], now_mono: float) -> None:
        self._last_write_mono = now_mono
        payload = dict(payload, venue_name="polymarket_us")
        tmp = run_dir / "polymarket-us-edge-status.json.tmp"
        try:
            tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            os.replace(tmp, run_dir / "polymarket-us-edge-status.json")
        except OSError:
            pass


async def _run_polymarket_us_live(a: argparse.Namespace, cfg: EngineConfig, auth, run_dir: Path) -> dict:
    """Polymarket US live loop: reconcile the journal, seed KalshiBook from balance/positions, feed
    Quote/IndexTick/Lifecycle events to KalshiEdge, submit its intents through the book's caps,
    stop on KILL or the run's deadline, and halt new entries at the daily loss cap."""
    import secrets as _secrets
    from datetime import datetime, timezone

    from .broker.kalshi_book import (
        KALSHI_LIMITS_PROFILES,
        KalshiBook,
        KalshiBookError,
        SettlementPoller,
        prior_realized_today_cents,
        unsettled_prior_tickets,
    )
    from .broker.polymarket_us import PolymarketUSAuth, PolymarketUSLive
    from .broker.kalshi_pool import ProfitPool
    from .feeds.polymarket_us import POLYMARKET_US_SERIES, PolymarketUSLiveFeed
    from .policy import PolicyWatcher, load_policy, policy_digest
    from .strategy.kalshi_edge import KalshiEdge, KalshiExitIntent, kalshi_fee_cents

    kill_path = run_dir / "KILL"
    client = None
    book = None
    receipt = None
    try:
        with Path(os.environ["POLYMARKET_US_KEY_FILE"]).open("rb") as key_file:
            venue_auth = PolymarketUSAuth(os.environ["LEAFHFT_POLYMARKET_US_KEY_ID"], key_file.read(4097))
        feed = PolymarketUSLiveFeed(cfg.symbol, venue_auth, index_from=getattr(a, "index_from", "kalshi"))
        client = PolymarketUSBookClient(PolymarketUSLive(auth=venue_auth, journal_dir=run_dir), feed, run_dir)
        await client.__aenter__()
        await client.reconcile()
        balance_cents = await client.balance()
        positions = await client.positions()
        exposure_cache = KalshiExposureCache()
        exposure_cents = await exposure_cache.refresh(client, time.monotonic())
        equity_cents = balance_cents + exposure_cents
        policy = None
        watcher = None
        day_open_path = None
        day_open_cents = 0
        halted_for_day = False
        skip_drawdown_stop = 0
        shard_drawdown = 0.0
        shard_state = "normal"
        shard_balance_at: float | None = time.time()
        policy_applied_at: float | None = None
        startup_size_scale = None
        if cfg.policy_path:
            policy = load_policy(cfg.policy_path)
            watcher = PolicyWatcher(cfg.policy_path)
            day_open_path = run_dir.parent.parent / "polymarket-us-day-open.json"
            today = datetime.now(timezone.utc).date()
            day_open_cents = kalshi_equity_day_open(day_open_path, today, equity_cents)
        if policy is not None:
            shard_state, shard_drawdown, startup_size_scale, limits = kalshi_shard_refresh(
                policy, balance_cents, day_open_cents, equity_cents=equity_cents)
            halted_for_day = shard_state == "stop"
            print(f"limits from policy, profile {cfg.limits_profile} ignored", file=sys.stderr, flush=True)
        else:
            limits = KALSHI_LIMITS_PROFILES[cfg.limits_profile]()
        stake_cents = cfg.starting_cash_q * 100 // QUOTE_UNIT
        cash_cents = min(balance_cents, stake_cents)
        pool = None
        pool_cfg = cfg.strategy_params.get("profit_pool")
        if isinstance(pool_cfg, dict):
            deposit_cents = pool_cfg.get("deposit_cents")
            if type(deposit_cents) is not int or deposit_cents <= 0:
                raise ValueError("profit_pool.deposit_cents must be a positive int")
            extra_ceiling_cents = pool_cfg.get("extra_ceiling_cents", 2000)
            if type(extra_ceiling_cents) is not int or extra_ceiling_cents < 0:
                raise ValueError("profit_pool.extra_ceiling_cents must be a nonnegative int")
            pool_path = pool_cfg.get("path", "/var/lib/leafhft/polymarket-us-pool.json")
            if not isinstance(pool_path, str) or not pool_path:
                raise ValueError("profit_pool.path must be a non-empty string")
            pool = ProfitPool(Path(pool_path), deposit_cents, extra_ceiling_cents)
        ledger_path = run_dir / "polymarket-us-tickets.jsonl"
        settled_client_ids: set[str] = set()
        exit_counts: dict[str, int] = {}
        ledger_bad_lines = 0
        if ledger_path.exists():
            for line in ledger_path.read_text(encoding="utf-8").splitlines():
                try:
                    row = orjson.loads(line)
                    if row.get("kind") in ("settle", "void", "adopt") and isinstance(row.get("client_id"), str):
                        settled_client_ids.add(row["client_id"])
                    elif row.get("kind") == "exit" and isinstance(row.get("client_id"), str) and isinstance(row.get("count"), int):
                        exit_counts[row["client_id"]] = exit_counts.get(row["client_id"], 0) + row["count"]
                    elif row.get("kind") in ("settle", "void", "adopt", "exit"):
                        raise ValueError("malformed client id")
                except Exception:
                    ledger_bad_lines += 1
        if ledger_bad_lines:
            print(f"polymarket_us ticket ledger: skipped {ledger_bad_lines} malformed line(s)", file=sys.stderr, flush=True)
        prior_scan = {"dropped_dirs": 0}
        prior_realized, prior_rows, prior_bad = prior_realized_today_cents(
            run_dir.parent, cfg.venue, cfg.symbol, datetime.now(timezone.utc), run_dir,
            ledger_name="polymarket-us-tickets.jsonl", scan_stats=prior_scan)
        print(f"polymarket_us realized today before this run: {prior_realized}c from {prior_rows} rows "
              f"({prior_bad} bad, {prior_scan['dropped_dirs']} directories dropped)",
              file=sys.stderr, flush=True)
        book = KalshiBook.recover(client, limits, cash_cents, positions, frozenset(settled_client_ids),
                                  prior_realized_cents=prior_realized, exit_counts=exit_counts)
        poller = SettlementPoller(book, client, ledger_path)
        _kalshi_refresh_cap_halt(book, cfg, run_dir, time.time_ns())
        adopt_scan = {"dropped_dirs": 0}
        prior_tickets, adopt_bad_lines = unsettled_prior_tickets(
            run_dir.parent, cfg.venue, cfg.symbol, datetime.now(timezone.utc), run_dir,
            ledger_name="polymarket-us-tickets.jsonl", journal_name="polymarket-us-orders.jsonl", scan_stats=adopt_scan)
        prior_tickets = [dict(row, ticker=client.remember(row["ticker"])) for row in prior_tickets]
        adopted_n = book.adopt_prior(prior_tickets, time.time_ns())
        if adopted_n:
            adopt_rows = [r for r in book.ledger_rows if r["kind"] == "adopt"]
            poller.record_adopted(adopt_rows)
            if pool is not None:
                for row in adopt_rows:
                    ticket = book.open_tickets.get(row["client_id"])
                    if ticket is not None:
                        pool.register_existing(row["client_id"], cfg.symbol, ticket.cost_cents)
        print(f"polymarket_us adopted {adopted_n} unsettled ticket(s) from prior runs "
              f"({adopt_bad_lines} bad lines, {adopt_scan['dropped_dirs']} directories dropped)",
              file=sys.stderr, flush=True)
        family = "15m" if "15M" in cfg.symbol.upper() else "1h"
        fee_multiplier = 0.06
        strategy = KalshiEdge(dict(cfg.strategy_params), family=family, series=POLYMARKET_US_SERIES,
                             settlement_method="trimmed_mean_20", fee_multiplier=fee_multiplier)
        strategy.stats["skip_venue_paused"] = 0
        strategy.stats["cash_capped_trims"] = 0
        strategy.stats["cash_capped_zero"] = 0
        strategy.bind_open_tickets(book.open_tickets)
        if policy is not None:
            strategy.apply_policy(policy)
            strategy.set_balance(balance_cents)
            if startup_size_scale is not None:
                strategy.size_scale = startup_size_scale
            policy_applied_at = time.time()

        # Paper shadow: a second, fenced KalshiEdge running on PaperKalshiClient beside the live
        # book. `shadow` is None whenever --shadow-policy was not given (nothing below exists,
        # live behaviour is byte-for-byte today's) or once any shadow call has raised: the first
        # exception anywhere in the shadow's setup or loop disables it for the rest of this run
        # and the live loop continues unaffected. `shadow_disabled_reason` survives that
        # disablement so the status payload can keep reporting why.
        shadow: dict[str, Any] | None = None
        shadow_disabled_reason: str | None = None
        if cfg.shadow_policy_path:
            try:
                from .broker.kalshi_paper import PaperKalshiClient

                shadow_cash_cents = cfg.shadow_cash_q * 100 // QUOTE_UNIT
                shadow_policy = load_policy(cfg.shadow_policy_path)
                shadow_watcher = PolicyWatcher(cfg.shadow_policy_path)
                paper = PaperKalshiClient(client, cash_cents=shadow_cash_cents)
                shadow_day_open_path = run_dir.parent.parent / "polymarket-us-shadow-day-open.json"
                shadow_today = datetime.now(timezone.utc).date()
                shadow_day_open_cents = kalshi_equity_day_open(
                    shadow_day_open_path, shadow_today, shadow_cash_cents)
                shadow_state0, shadow_dd0, shadow_scale0, shadow_limits0 = kalshi_shard_refresh(
                    shadow_policy, shadow_cash_cents, shadow_day_open_cents)
                shadow_ledger_path = run_dir / "polymarket-us-shadow-tickets.jsonl"
                settled_shadow_ids: set[str] = set()
                if shadow_ledger_path.exists():
                    for line in shadow_ledger_path.read_text(encoding="utf-8").splitlines():
                        try:
                            row = orjson.loads(line)
                        except Exception:
                            continue
                        if isinstance(row, dict) and row.get("kind") in ("settle", "void", "adopt") \
                                and isinstance(row.get("client_id"), str):
                            settled_shadow_ids.add(row["client_id"])
                shadow_prior_realized, _, _ = prior_realized_today_cents(
                    run_dir.parent, cfg.venue, cfg.symbol, datetime.now(timezone.utc), run_dir,
                    ledger_name="polymarket-us-shadow-tickets.jsonl")
                # KalshiBook.recover() rebuilds open tickets from a KalshiLive client's own
                # journal (`client._records`); PaperKalshiClient carries no such journal, so the
                # plain constructor (an empty book plus the carried-forward realized P&L) is the
                # correct equivalent here, not .recover().
                shadow_book = KalshiBook(paper, shadow_limits0, shadow_cash_cents,
                                        prior_realized_cents=shadow_prior_realized)
                shadow_poller = SettlementPoller(shadow_book, paper, shadow_ledger_path)
                shadow_prior_tickets, _ = unsettled_prior_tickets(
                    run_dir.parent, cfg.venue, cfg.symbol, datetime.now(timezone.utc), run_dir,
                    ledger_name="polymarket-us-shadow-tickets.jsonl", journal_name=None)
                shadow_adopted_n = shadow_book.adopt_prior(shadow_prior_tickets, time.time_ns())
                if shadow_adopted_n:
                    shadow_poller.record_adopted([r for r in shadow_book.ledger_rows if r["kind"] == "adopt"])
                print(f"polymarket_us shadow: adopted {shadow_adopted_n} shadow ticket(s), "
                      f"prior realized {shadow_prior_realized}c", file=sys.stderr, flush=True)
                shadow_strategy = KalshiEdge({}, family=family, series=POLYMARKET_US_SERIES,
                             settlement_method="trimmed_mean_20", fee_multiplier=fee_multiplier)
                shadow_strategy.stats["skip_venue_paused"] = 0
                shadow_strategy.stats["cash_capped_trims"] = 0
                shadow_strategy.stats["cash_capped_zero"] = 0
                shadow_strategy.stats["shadow_buy_refused"] = 0
                shadow_strategy.stats["shadow_exit_refused"] = 0
                shadow_strategy.bind_open_tickets(shadow_book.open_tickets)
                shadow_strategy.apply_policy(shadow_policy)
                shadow_strategy.set_balance(shadow_cash_cents)
                if shadow_scale0 is not None:
                    shadow_strategy.size_scale = shadow_scale0
                shadow_since_path = run_dir.parent.parent / "polymarket-us-shadow-since"
                if not shadow_since_path.exists():
                    try:
                        shadow_since_path.write_text(datetime.now(timezone.utc).isoformat(), encoding="utf-8")
                    except OSError:
                        pass
                shadow = {
                    "policy": shadow_policy, "watcher": shadow_watcher, "paper": paper,
                    "book": shadow_book, "poller": shadow_poller, "strategy": shadow_strategy,
                    "day_open_path": shadow_day_open_path, "day_open_cents": shadow_day_open_cents,
                    "state": shadow_state0, "drawdown": shadow_dd0, "halted": shadow_state0 == "stop",
                    "policy_applied_at": time.time(), "refresh_mono": -30.0,
                }
                print(f"polymarket_us shadow armed: cash={shadow_cash_cents}c policy={cfg.shadow_policy_path}",
                      file=sys.stderr, flush=True)
            except Exception as e:
                shadow_disabled_reason = f"{type(e).__name__}: {e}"
                print(f"shadow disabled: {shadow_disabled_reason}", file=sys.stderr, flush=True)
                shadow = None

        def disable_shadow(exc: Exception) -> None:
            nonlocal shadow, shadow_disabled_reason
            shadow_disabled_reason = f"{type(exc).__name__}: {exc}"
            print(f"shadow disabled: {shadow_disabled_reason}", file=sys.stderr, flush=True)
            shadow = None

        def shadow_status_block() -> dict[str, Any] | None:
            if shadow is None:
                return {"disabled": True, "error": shadow_disabled_reason} if shadow_disabled_reason else None
            s_book, s_strategy, s_paper = shadow["book"], shadow["strategy"], shadow["paper"]
            return {
                "cash_cents": s_book.cash_cents,
                "realized_today_cents": s_book.realized_today_cents,
                "open_tickets": len(s_book.open_tickets),
                "params": dict(s_strategy.state().get("params") or {}),
                "stats": dict(s_strategy.stats),
                **({"eval": s_strategy.eval_block(time.time_ns() // 1_000_000)}
                   if callable(getattr(s_strategy, "eval_block", None)) else {}),
                "fills": dict(s_paper.stats),
                "disabled": False,
                "error": None,
                "policy_digest": s_strategy.policy_digest,
            }

        (run_dir / "config.json").write_text(json.dumps(_cfg_dict(cfg), indent=2), encoding="utf-8")
        deadline = time.monotonic() + cfg.run_seconds if cfg.run_seconds else None
        stop_reason = "seconds elapsed"
        quiet_periods = reconnects = 0
        events_seen = 0
        status_writer = PolymarketUSStatusWriter()
        poll_error_print_mono = -60.0
        shadow_poll_error_print_mono = -60.0
        shadow_buy_refused_print_mono = -60.0
        shadow_exit_refused_print_mono = -60.0
        shard_refresh_mono = time.monotonic()
        shard_refresh_error_print_mono = -60.0
        venue = PolymarketUSVenueStatus()

        async def poll_settlement(now_ns: int, now_mono: float) -> bool:
            """Runs the bounded settlement poll; returns True when the loop must stop (a ticket
            ledger write failure). Any other poll exception is rate-limited to one print per 60 s
            and swallowed, so a poll failure never reaches the trading loop. Every client id the
            poller settled in this poll (win, loss, or void) releases its pool reservation,
            regardless of whether the poll itself went on to fail. When a policy is active, this
            same cadence hook also polls the policy watcher (self-throttled to 5 s) and, at most
            once per 30 s, refreshes the shard balance, recomputes day-open/drawdown and the
            policy-derived limits: a balance-read failure keeps the last known values instead of
            stopping the loop."""
            nonlocal stop_reason, poll_error_print_mono
            nonlocal shadow_poll_error_print_mono
            nonlocal policy, day_open_cents, halted_for_day, shard_drawdown, shard_state
            nonlocal balance_cents, exposure_cents, equity_cents
            nonlocal shard_refresh_mono, shard_refresh_error_print_mono, policy_applied_at, shard_balance_at
            settled_before = len(book.settled_rows) if pool is not None else 0
            stop = False
            try:
                await poller.poll(now_ns, now_mono)
            except KalshiBookError:
                stop_reason = "ticket ledger write failed"
                stop = True
            except Exception as e:
                if now_mono - poll_error_print_mono >= 60.0:
                    poll_error_print_mono = now_mono
                    print(f"polymarket_us settlement poll failed: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
            if pool is not None:
                for row in book.settled_rows[settled_before:]:
                    pool.release(row["client_id"])
            if policy is not None:
                new_policy = watcher.poll(now_mono)
                if new_policy is not None:
                    policy = new_policy
                    strategy.apply_policy(policy)
                    shard_state, shard_drawdown, refreshed_scale, refreshed_limits = kalshi_shard_refresh(
                        policy, balance_cents, day_open_cents, equity_cents=equity_cents)
                    if refreshed_scale is not None:
                        strategy.size_scale = refreshed_scale
                    was_halted = halted_for_day
                    halted_for_day = shard_state == "stop"
                    if halted_for_day and not was_halted:
                        print(f"polymarket_us drawdown stop: trading halted for the day "
                              f"(dd={shard_drawdown:.3f} day_open={day_open_cents}c balance={book.cash_cents}c)",
                              file=sys.stderr, flush=True)
                    book.apply_limits(refreshed_limits)
                    policy_applied_at = time.time()
                    print(f"policy applied {policy_digest(policy)[:12]}", file=sys.stderr, flush=True)
                if now_mono - shard_refresh_mono >= 30.0:
                    shard_refresh_mono = now_mono
                    try:
                        balance = await client.balance()
                    except Exception as e:
                        if now_mono - shard_refresh_error_print_mono >= 60.0:
                            shard_refresh_error_print_mono = now_mono
                            print(f"polymarket_us balance refresh failed: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
                    else:
                        balance_cents = balance
                        exposure_cents = await exposure_cache.refresh(client, now_mono)
                        equity_cents = balance + exposure_cents
                        shard_balance_at = time.time()
                        strategy.set_balance(balance)
                        book.set_cash(min(balance, stake_cents))
                        today = datetime.now(timezone.utc).date()
                        day_open_cents = kalshi_equity_day_open(day_open_path, today, equity_cents)
                        shard_state, shard_drawdown, refreshed_scale, refreshed_limits = kalshi_shard_refresh(
                            policy, balance, day_open_cents, equity_cents=equity_cents)
                        if refreshed_scale is not None:
                            strategy.size_scale = refreshed_scale
                        was_halted = halted_for_day
                        halted_for_day = shard_state == "stop"
                        if halted_for_day and not was_halted:
                            print(f"polymarket_us drawdown stop: trading halted for the day "
                                  f"(dd={shard_drawdown:.3f} day_open={day_open_cents}c balance={balance}c)",
                                  file=sys.stderr, flush=True)
                        book.apply_limits(refreshed_limits)
            _kalshi_refresh_cap_halt(book, cfg, run_dir, now_ns)
            if shadow is not None:
                try:
                    try:
                        await shadow["poller"].poll(now_ns, now_mono)
                    except KalshiBookError:
                        raise
                    except Exception as e:
                        if now_mono - shadow_poll_error_print_mono >= 60.0:
                            shadow_poll_error_print_mono = now_mono
                            print(f"polymarket_us shadow settlement poll failed: {type(e).__name__}",
                                  file=sys.stderr, flush=True)
                    new_shadow_policy = shadow["watcher"].poll(now_mono)
                    if new_shadow_policy is not None:
                        shadow["policy"] = new_shadow_policy
                        shadow["strategy"].apply_policy(new_shadow_policy)
                        shadow["policy_applied_at"] = time.time()
                    if now_mono - shadow["refresh_mono"] >= 30.0:
                        shadow["refresh_mono"] = now_mono
                        s_book = shadow["book"]
                        shadow_balance_cents = s_book.cash_cents + s_book.worst_case_open_loss_cents()
                        shadow["strategy"].set_balance(s_book.cash_cents)
                        shadow_today = datetime.now(timezone.utc).date()
                        shadow["day_open_cents"] = kalshi_equity_day_open(
                            shadow["day_open_path"], shadow_today, shadow_balance_cents)
                        shadow_state, shadow_dd, shadow_scale, shadow_limits = kalshi_shard_refresh(
                            shadow["policy"], s_book.cash_cents, shadow["day_open_cents"],
                            equity_cents=shadow_balance_cents)
                        if shadow_scale is not None:
                            shadow["strategy"].size_scale = shadow_scale
                        shadow["state"] = shadow_state
                        shadow["drawdown"] = shadow_dd
                        shadow["halted"] = shadow_state == "stop"
                        s_book.apply_limits(shadow_limits)
                except Exception as e:
                    disable_shadow(e)
            return stop

        def policy_shard_blocks() -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
            if policy is None:
                return None, None
            policy_block = {
                "digest": policy_digest(policy),
                "applied_at": policy_applied_at,
                "error": watcher.last_error if watcher is not None else None,
                "error_at": watcher.last_error_at if watcher is not None else None,
            }
            shard_block = {
                "balance_cents": balance_cents,
                "exposure_cents": exposure_cents,
                "locked_cents": exposure_cents,
                "equity_cents": equity_cents,
                "exposure_errors": exposure_cache.errors,
                "day_open_cents": day_open_cents,
                "drawdown": shard_drawdown,
                "state": shard_state,
                "size_scale": strategy.size_scale,
                "balance_at": shard_balance_at,
                "skip_drawdown_stop": skip_drawdown_stop,
            }
            return policy_block, shard_block

        async def refresh_venue() -> None:
            # No HTTP on the event path. The cached flag also covers a quiet/reconnecting feed.
            while True:
                await asyncio.sleep(30.0)
                await venue.refresh(client, time.monotonic())
                policy_block, shard_block = policy_shard_blocks()
                status_writer.write(run_dir, _kalshi_status_payload(
                    strategy, events_seen, book, poller, pool, policy_block, shard_block,
                    shadow_status_block(), venue.block), time.monotonic())

        await venue.refresh(client, time.monotonic())
        await feed.start()
        venue_task = asyncio.create_task(refresh_venue())
        try:
            stopped = False
            while not stopped:
                try:
                    async for ev in feed.events(idle_timeout_s=KALSHI_LIVE_IDLE_S):
                        now_ns = time.time_ns()
                        _kalshi_refresh_cap_halt(book, cfg, run_dir, now_ns)
                        client.capture_markets()
                        events_seen += 1
                        ledger_write_failed = False
                        for intent in strategy.on_event(ev, now_ns // 1_000_000):
                            if venue.venue_paused:
                                strategy.stats["skip_venue_paused"] = strategy.stats.get("skip_venue_paused", 0) + 1
                                continue
                            if isinstance(intent, KalshiExitIntent):
                                # Risk-reducing: allowed even under halted_for_day, unlike a new buy.
                                fee = kalshi_fee_cents(intent.price_cents, 1, multiplier=fee_multiplier)
                                try:
                                    exit_row = await book.exit(intent.client_id, intent.price_cents, intent.count,
                                                               fee, intent.reason, now_ns)
                                except Exception as e:
                                    print(f"polymarket_us exit refused: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
                                    continue
                                if exit_row is not None:
                                    try:
                                        poller.record_exit(exit_row)
                                    except KalshiBookError:
                                        stop_reason = "ticket ledger write failed"
                                        ledger_write_failed = True
                                        break
                                continue
                            _kalshi_refresh_cap_halt(book, cfg, run_dir, now_ns)
                            if getattr(book, "halted_for_cap", False):
                                strategy.stats["skip_cap_halt"] = strategy.stats.get("skip_cap_halt", 0) + 1
                                continue
                            if halted_for_day:
                                skip_drawdown_stop += 1
                                continue
                            cid = "lh-" + _secrets.token_hex(12)
                            count = intent.count
                            if pool is not None:
                                base_cents = intent.count * intent.price_cents
                                try:
                                    balance = await client.balance_cents()
                                except Exception as e:
                                    balance = 0
                                    print(f"polymarket_us pool balance read failed: {type(e).__name__}: {e}",
                                          file=sys.stderr, flush=True)
                                extra = pool.reserve(cid, cfg.symbol, base_cents, intent.price_cents, balance)
                                count = (base_cents + extra) // intent.price_cents
                            free_cents = max(0, book.cash_cents - book.reserved_cents)
                            capped = kalshi_cash_capped_count(count, intent.price_cents, book.cash_cents,
                                                              book.reserved_cents, book.limits.cash_floor_cents,
                                                              multiplier=fee_multiplier)
                            if capped == 0:
                                strategy.stats["cash_capped_zero"] += 1
                            elif 0 < capped < count:
                                strategy.stats["cash_capped_trims"] += 1
                            if capped < 1:
                                print(f"polymarket_us order skipped: cash-capped to 0 "
                                      f"(count={count} price={intent.price_cents}c free={free_cents}c)",
                                      file=sys.stderr, flush=True)
                                if pool is not None:
                                    pool.release(cid)
                                continue
                            if capped < count:
                                print(f"polymarket_us order trimmed by cash: {count} -> {capped} (free={free_cents}c)",
                                      file=sys.stderr, flush=True)
                                count = capped
                            fee = kalshi_fee_cents(intent.price_cents, 1, multiplier=fee_multiplier)
                            try:
                                ticket = await book.buy(intent.ticker, intent.side_yes, intent.price_cents,
                                                        count, fee, intent.cluster_id, cid, now_ns)
                            except Exception as e:
                                print(f"polymarket_us order refused: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
                                if pool is not None:
                                    pool.release(cid)
                                continue
                            if pool is not None:
                                if ticket is not None:
                                    pool.commit(cid, ticket.cost_cents)
                                else:
                                    pool.release(cid)
                            if ticket is not None:
                                try:
                                    poller.record_buy(ticket, intent.reason)
                                except KalshiBookError:
                                    stop_reason = "ticket ledger write failed"
                                    ledger_write_failed = True
                                    break
                        if ledger_write_failed:
                            stopped = True
                            break
                        if shadow is not None:
                            try:
                                if isinstance(ev, Quote):
                                    shadow["paper"].observe(ev)
                                for s_intent in shadow["strategy"].on_event(ev, now_ns // 1_000_000):
                                    if venue.venue_paused:
                                        s_stats = shadow["strategy"].stats
                                        s_stats["skip_venue_paused"] = s_stats.get("skip_venue_paused", 0) + 1
                                        continue
                                    if isinstance(s_intent, KalshiExitIntent):
                                        s_book = shadow["book"]
                                        s_fee = kalshi_fee_cents(s_intent.price_cents, 1, multiplier=fee_multiplier)
                                        try:
                                            s_exit_row = await s_book.exit(s_intent.client_id, s_intent.price_cents,
                                                                           s_intent.count, s_fee, s_intent.reason, now_ns)
                                        except KalshiBookError as e:
                                            s_stats = shadow["strategy"].stats
                                            s_stats["shadow_exit_refused"] = s_stats.get("shadow_exit_refused", 0) + 1
                                            refuse_mono = time.monotonic()
                                            if refuse_mono - shadow_exit_refused_print_mono >= 60.0:
                                                shadow_exit_refused_print_mono = refuse_mono
                                                print(f"polymarket_us shadow exit refused: {type(e).__name__}: {e}",
                                                      file=sys.stderr, flush=True)
                                            continue
                                        if s_exit_row is not None:
                                            shadow["poller"].record_exit(s_exit_row)
                                        continue
                                    if shadow["halted"]:
                                        continue
                                    s_book = shadow["book"]
                                    s_capped = kalshi_cash_capped_count(
                                        s_intent.count, s_intent.price_cents, s_book.cash_cents,
                                        s_book.reserved_cents, s_book.limits.cash_floor_cents,
                                        multiplier=fee_multiplier)
                                    s_stats = shadow["strategy"].stats
                                    if s_capped == 0:
                                        s_stats["cash_capped_zero"] += 1
                                    elif 0 < s_capped < s_intent.count:
                                        s_stats["cash_capped_trims"] += 1
                                    if s_capped < 1:
                                        continue
                                    s_cid = "lh-shadow-" + _secrets.token_hex(12)
                                    s_fee = kalshi_fee_cents(s_intent.price_cents, 1, multiplier=fee_multiplier)
                                    try:
                                        s_ticket = await s_book.buy(s_intent.ticker, s_intent.side_yes, s_intent.price_cents,
                                                                    s_capped, s_fee, s_intent.cluster_id, s_cid, now_ns)
                                    except KalshiBookError as e:
                                        s_stats = shadow["strategy"].stats
                                        s_stats["shadow_buy_refused"] = s_stats.get("shadow_buy_refused", 0) + 1
                                        refuse_mono = time.monotonic()
                                        if refuse_mono - shadow_buy_refused_print_mono >= 60.0:
                                            shadow_buy_refused_print_mono = refuse_mono
                                            print(f"polymarket_us shadow order refused: {type(e).__name__}: {e}",
                                                  file=sys.stderr, flush=True)
                                        continue
                                    if s_ticket is not None:
                                        shadow["poller"].record_buy(s_ticket, s_intent.reason)
                            except Exception as e:
                                disable_shadow(e)
                        now_mono = time.monotonic()
                        if status_writer.due(now_mono):
                            policy_block, shard_block = policy_shard_blocks()
                            status_writer.write(run_dir, _kalshi_status_payload(
                                strategy, events_seen, book, poller, pool, policy_block, shard_block,
                                shadow_status_block(), venue.block), now_mono)
                        if await poll_settlement(now_ns, now_mono):
                            stopped = True
                            break
                        if kill_path.exists():
                            stop_reason = "KILL file present"
                            stopped = True
                            break
                        _kalshi_refresh_cap_halt(book, cfg, run_dir, now_ns)
                        if deadline is not None and time.monotonic() >= deadline:
                            stopped = True
                            break
                    else:
                        stopped = True  # events() returned normally: feed.stop() was called elsewhere
                except TimeoutError:
                    quiet_periods += 1
                    if await poll_settlement(time.time_ns(), time.monotonic()):
                        stopped = True
                    elif kill_path.exists():
                        stop_reason = "KILL file present"
                        stopped = True
                    elif deadline is not None and time.monotonic() >= deadline:
                        stopped = True
                    elif reconnects >= KALSHI_LIVE_MAX_RECONNECTS:
                        stop_reason = "feed idle: reconnect budget spent"
                        stopped = True
                    else:
                        reconnects += 1
                        print(f"polymarket_us feed idle {KALSHI_LIVE_IDLE_S:.0f} s, reconnect {reconnects} of {KALSHI_LIVE_MAX_RECONNECTS}",
                              file=sys.stderr, flush=True)
                        await asyncio.wait_for(feed.reconnect(), timeout=10.0)
        finally:
            venue_task.cancel()
            try:
                await venue_task
            except asyncio.CancelledError:
                pass
            await feed.stop()
        policy_block, shard_block = policy_shard_blocks()
        status_writer.write(run_dir, _kalshi_status_payload(
            strategy, events_seen, book, poller, pool, policy_block, shard_block,
            shadow_status_block(), venue.block), time.monotonic())
        receipt = {"config_digest": cfg.digest(), "stop_reason": stop_reason,
                  "cash_usd": book.cash_cents / 100, "realized_usd": book.realized_cents / 100,
                  "open_tickets": len(book.open_tickets), "limits_profile": cfg.limits_profile,
                  "feed": {"quiet_periods": quiet_periods, "reconnects": reconnects}}
    except Exception as e:
        print(f"polymarket_us live driver failed: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
        receipt = {"config_digest": cfg.digest(), "stop_reason": "live driver failed",
                  "exception": type(e).__name__, "exception_detail": {"class": type(e).__name__}}
    finally:
        live = {"unresolved": [], "clean": True}
        if client is not None:
            try:
                live["unresolved"] = await client.reconcile()
                live["clean"] = not live["unresolved"]
            except Exception as e:
                live["unresolved"] = ["client reconcile: " + type(e).__name__]
                live["clean"] = False
            try:
                await client.__aexit__(None, None, None)
            except Exception:
                live["clean"] = False
        receipt = receipt or {"config_digest": cfg.digest(), "stop_reason": "live driver interrupted"}
        receipt["live"] = live
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "receipt.json").write_text(json.dumps(receipt, indent=2, default=str), encoding="utf-8")
    return receipt


async def _run_kalshi_perp_live(a: argparse.Namespace, cfg: EngineConfig, auth, run_dir: Path) -> dict:
    """BTCPERP sleeve loop: reconcile the journal, feed the BRTI IndexTick stream (reused from the
    BTC-15M event feed: kalshi-perp has no dedicated make_feed branch, and BRTI is venue-wide) to
    PerpBreakout, run every mark through PerpSleeve's stop/trailing/time/bound checks, ratchet the
    trailing stop on completed minutes, poll funding once a minute, and stop on KILL, the run's
    --seconds deadline, or the sleeve halting itself."""
    import secrets as _secrets
    from decimal import Decimal

    from .broker.kalshi_perp import PERP_LIMITS_PROFILES, KalshiPerp, PerpSleeve
    from .feeds.base import IndexTick, make_feed
    from .strategy.perp_breakout import PerpBreakout

    kill_path = run_dir / "KILL"
    client = None
    sleeve = None
    receipt = None
    ticker = "KXBTCPERP"  # the venue lists the BTC perp as KXBTCPERP (GET /margin/markets); BTCPERP is not found
    try:
        client = KalshiPerp(auth, journal_dir=run_dir)
        await client.__aenter__()
        await client.reconcile()
        params = PERP_LIMITS_PROFILES[cfg.limits_profile]()
        sleeve = PerpSleeve(client, params)
        await _adopt_venue_perp_position(client, sleeve, ticker)
        strategy = PerpBreakout(dict(cfg.strategy_params))
        feed = make_feed("kalshi", "BTC-15M", demo=getattr(a, "demo", False))
        (run_dir / "config.json").write_text(json.dumps(_cfg_dict(cfg), indent=2), encoding="utf-8")
        deadline = time.monotonic() + cfg.run_seconds if cfg.run_seconds else None
        stop_reason = "seconds elapsed"
        cur_minute: int | None = None
        cur_close_i = 0
        last_funding_poll = 0.0
        ticks = 0
        last_status_write_mono = 0.0
        last_status_print_mono = 0.0
        prev_attempts = prev_stops = 0
        quiet_periods = reconnects = 0
        await feed.start()
        try:
            stopped = False
            while not stopped:
                try:
                    async for ev in feed.events(idle_timeout_s=KALSHI_LIVE_IDLE_S):
                        if not isinstance(ev, IndexTick):
                            continue
                        ticks += 1
                        now_ns = time.time_ns()
                        minute = ev.source_ts_ms // 60_000
                        if cur_minute is not None and minute != cur_minute:
                            closing_mark = Decimal(cur_close_i) / Decimal(PRICE_UNIT)
                            await sleeve.on_minute_close(closing_mark, now_ns, "lh-" + _secrets.token_hex(8))
                        cur_minute, cur_close_i = minute, ev.value_i
                        mark = Decimal(ev.value_i) / Decimal(PRICE_UNIT)
                        await sleeve.check_mark(mark, now_ns, "lh-" + _secrets.token_hex(8))
                        for intent in strategy.on_event(ev, now_ns // 1_000_000):
                            if sleeve.can_attempt(now_ns) is not None:
                                continue
                            try:
                                await sleeve.open(ticker, intent.side, mark, now_ns, "lh-" + _secrets.token_hex(8))
                            except Exception as e:
                                print(f"kalshi-perp order refused: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
                        now_mono = time.monotonic()
                        if now_mono - last_funding_poll >= 60:
                            last_funding_poll = now_mono
                            try:
                                sleeve.log_funding(await client.funding_historical())
                            except Exception as e:
                                print(f"kalshi-perp funding poll failed: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
                        tick_age_s = max(0.0, (now_ns // 1_000_000 - ev.received_at_ms) / 1000.0)
                        status = _sleeve_status_payload(strategy, sleeve, ticks, mark, tick_age_s)
                        events_fired = status["attempts"] != prev_attempts or status["stops"] != prev_stops
                        prev_attempts, prev_stops = status["attempts"], status["stops"]
                        if now_mono - last_status_write_mono >= 60:
                            last_status_write_mono = now_mono
                            _write_sleeve_status(run_dir, status)
                        if events_fired or now_mono - last_status_print_mono >= 300:
                            last_status_print_mono = now_mono
                            print(_sleeve_status_line(status), file=sys.stderr, flush=True)
                        if kill_path.exists():
                            stop_reason = "KILL file present"
                            stopped = True
                            break
                        if sleeve.halted:
                            stop_reason = "sleeve halted (bound or liquidation)"
                            stopped = True
                            break
                        if deadline is not None and now_mono >= deadline:
                            stopped = True
                            break
                    else:
                        stopped = True  # events() returned normally: feed.stop() was called elsewhere
                except TimeoutError:
                    quiet_periods += 1
                    if kill_path.exists():
                        stop_reason = "KILL file present"
                        stopped = True
                    elif deadline is not None and time.monotonic() >= deadline:
                        stopped = True
                    elif reconnects >= KALSHI_LIVE_MAX_RECONNECTS:
                        stop_reason = "feed idle: reconnect budget spent"
                        stopped = True
                    else:
                        reconnects += 1
                        print(f"kalshi feed idle {KALSHI_LIVE_IDLE_S:.0f} s, reconnect {reconnects} of {KALSHI_LIVE_MAX_RECONNECTS}",
                              file=sys.stderr, flush=True)
                        await asyncio.wait_for(feed.reconnect(), timeout=10.0)
        finally:
            await feed.stop()
        receipt = {"config_digest": cfg.digest(), "stop_reason": stop_reason,
                  "realized_usd": str(sleeve.realized_usd), "open_position": sleeve.position is not None,
                  "halted": sleeve.halted, "limits_profile": cfg.limits_profile,
                  "feed": {"quiet_periods": quiet_periods, "reconnects": reconnects}}
    except Exception as e:
        print(f"kalshi-perp live driver failed: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
        receipt = {"config_digest": cfg.digest(), "stop_reason": "live driver failed",
                  "exception": type(e).__name__, "exception_detail": {"class": type(e).__name__}}
    finally:
        live = {"unresolved": [], "clean": True}
        if client is not None:
            try:
                live["unresolved"] = await client.reconcile()
                live["clean"] = not live["unresolved"]
            except Exception as e:
                live["unresolved"] = ["client reconcile: " + type(e).__name__]
                live["clean"] = False
            try:
                await client.__aexit__(None, None, None)
            except Exception:
                live["clean"] = False
        receipt = receipt or {"config_digest": cfg.digest(), "stop_reason": "live driver interrupted"}
        receipt["live"] = live
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "receipt.json").write_text(json.dumps(receipt, indent=2, default=str), encoding="utf-8")
    return receipt


def cmd_live(a: argparse.Namespace) -> int:
    hot_observation_mode = getattr(a, "hot_observation_mode", "off")
    # Hot observations are restricted to the incumbent owner ticker book.
    if hot_observation_mode != "off":
        hot_reason = None
        if "LEAFHFT_ACCOUNT_LANE_ID" in os.environ:
            hot_reason = "tenant lane"
        elif a.venue != "kalshi" or a.strategy != "kalshi_edge":
            hot_reason = "not an owner kalshi_edge book"
        elif _classification_mode_arg(a) != "ticker":
            hot_reason = "classification is not ticker"
        if hot_reason is not None:
            print(f"kalshi hot observation: skipped ({hot_reason})", file=sys.stderr)
            hot_observation_mode = "off"
            a.hot_observation_mode = "off"
    account_budget = None
    if os.environ.get("LEAFHFT_ACCOUNT_LANE_ID"):
        from .account_lane_agent import validate_live_arguments
        account_budget = validate_live_arguments(a)
    if a.strategy == "probe":
        raise SystemExit("probe is paper-only")

    from .broker.live_gate import LIVE_DRIVER_AVAILABLE, LIVE_MAX_STAKE_Q, LiveGateClosed, ack_sentence, assert_armed, readiness

    stake_str = getattr(a, "stake_usd", getattr(a, "cash", "5.00"))
    starting_cash_q = to_quote_q(stake_str)
    if starting_cash_q > LIVE_MAX_STAKE_Q:
        print(f"LIVE GATE CLOSED: stake-usd {stake_str} exceeds the $500 ceiling", file=sys.stderr)
        return 4

    policy_arg = getattr(a, "policy", None) or ""
    engines_dir = getattr(a, "engines_dir", None) or ""
    engine_bindings = getattr(a, "engine_bindings", None) or ""
    engine_account_overrides = getattr(a, "engine_account_overrides", None) or ""
    dashboard_account_identity = getattr(a, "dashboard_account_identity", None) or ""
    execution_experiment_path = getattr(a, "execution_experiment", None) or ""
    if execution_experiment_path and a.venue != "kalshi":
        print("execution experiment requires --venue kalshi", file=sys.stderr)
        return 2
    if (engines_dir or engine_bindings or engine_account_overrides or dashboard_account_identity) and a.venue != "kalshi":
        print("engine selection options require --venue kalshi", file=sys.stderr)
        return 2
    probe_bindings = getattr(a, "probe_bindings", None) or ""
    engine_registry = getattr(a, "engine_registry", None) or ""
    lifecycle_dir = getattr(a, "lifecycle_dir", None) or ""
    execution_domain = ""
    if (probe_bindings or engine_registry) and a.venue != "kalshi":
        print("probe hosting options require --venue kalshi", file=sys.stderr)
        return 2
    parity_mirror = bool(getattr(a, "parity_mirror", False))
    if parity_mirror and a.venue != "kalshi":
        print("--parity-mirror requires --venue kalshi", file=sys.stderr)
        return 2
    executor_mode = bool(getattr(a, "executor_mode", False))
    if executor_mode and a.venue != "kalshi":
        print("--executor-mode requires --venue kalshi", file=sys.stderr)
        return 2
    if executor_mode and not parity_mirror:
        print("--executor-mode requires --parity-mirror", file=sys.stderr)
        return 2
    book_tap = getattr(a, "book_tap", "") or ""
    if book_tap and (a.venue != "kalshi" or len(book_tap) > 256):
        print("--book-tap requires --venue kalshi and a path of at most 256 characters", file=sys.stderr)
        return 2
    if a.venue == "kalshi":
        from .config import ENGINE_REGISTRY_ENV, EXECUTION_DOMAIN_ENV, PROBE_BINDINGS_ENV

        probe_bindings = probe_bindings or os.environ.get(PROBE_BINDINGS_ENV, "")
        if probe_bindings:
            # Only a probe host reads the other two, so no other book's digest can move with them.
            engine_registry = engine_registry or os.environ.get(ENGINE_REGISTRY_ENV, "")
            execution_domain = os.environ.get(EXECUTION_DOMAIN_ENV, "")
    if a.venue == "polymarket_us" and not policy_arg:
        policy_arg = "/etc/leafhft/polymarket-us-policy.json"
    policy_path = ""
    policy_bounds = ""
    if policy_arg and a.venue in ("kalshi", "polymarket_us"):
        from .policy import PolicyError, load_policy, policy_bounds_digest
        try:
            load_policy(policy_arg)
        except PolicyError as e:
            print(str(e), file=sys.stderr)
            return 2
        policy_path = policy_arg
        policy_bounds = policy_bounds_digest()

    shadow_policy_path = getattr(a, "shadow_policy", None) or ""
    shadow_cash_q = to_quote_q(str(getattr(a, "shadow_cash_usd", 500))) if shadow_policy_path else 0

    alternate = getattr(a, "alternate", "") or ""
    authority_path = getattr(a, "authority_path", "/var/lib/leafhft/kalshi-authority.json")
    authority_generation = ""
    if a.venue == "kalshi":
        try:
            authority_generation = _kalshi_authority_generation(authority_path)
        except ValueError as exc:
            print(f"LIVE GATE CLOSED: {exc}", file=sys.stderr)
            return 4
    cfg = EngineConfig(
        venue=a.venue,
        symbol=a.symbol,
        strategy=a.strategy,
        mode="live",
        starting_cash_q=starting_cash_q,
        goal_q=to_quote_q(a.goal),
        strategy_params=_params(a.params),
        run_seconds=a.seconds,
        limits_profile=getattr(a, "limits_profile", "s2c"),
        reference_venue=getattr(a, "reference_venue", "") or "",
        alternate_strategy=alternate,
        block_minutes=int(a.block_minutes) if alternate else 0,
        policy_path=policy_path,
        engines_dir=engines_dir,
        engine_bindings=engine_bindings,
        engine_account_overrides=engine_account_overrides,
        dashboard_account_identity=dashboard_account_identity,
        execution_experiment_path=execution_experiment_path,
        lifecycle_dir=lifecycle_dir,
        probe_bindings=probe_bindings,
        engine_registry=engine_registry,
        execution_domain=execution_domain,
        parity_mirror=parity_mirror,
        executor_mode=executor_mode,
        authority_path=authority_path,
        authority_generation=authority_generation,
        coordinated_mode=getattr(a, "coordinated_mode", "off"),
        darkhorse_config_path=getattr(a, "darkhorse_config", "/etc/leafhft/darkhorse.json"),
        lane_documents=tuple(getattr(a, "lane", ()) or ()),
        policy_bounds_digest=policy_bounds,
        shadow_policy_path=shadow_policy_path,
        shadow_cash_q=shadow_cash_q,
        classification_mode=_classification_mode_arg(a),
        **({"hot_observation_mode": hot_observation_mode} if hot_observation_mode != "off" else {}),
    )
    # Old in-process callers supply an already allocated directory. CLI runs always allocate.
    cli_allocated_run_dir = hasattr(a, "stake_usd")
    run_dir = (_run_dir(a.run_dir, f"live-{a.venue}-{a.strategy}")
               if cli_allocated_run_dir else Path(a.run_dir))
    source_ack = _copy_live_ack(cfg, getattr(a, "ack_dir", None), run_dir)
    blockers = readiness(cfg, run_dir)
    if LIVE_DRIVER_AVAILABLE and cfg.venue not in ("binanceus", "kalshi", "kalshi-perp", "polymarket_us"):
        blockers.append("live engine driver supports binanceus, kalshi, kalshi-perp and polymarket_us only")
    print(f"config digest: {cfg.digest()}\nack sentence: {ack_sentence(cfg)}", file=sys.stderr)
    if blockers:
        for blocker in blockers:
            print(f"LIVE GATE CLOSED: {blocker}", file=sys.stderr)
        if cli_allocated_run_dir:
            _discard_refused_run_dir(cfg, run_dir)
        return 4
    drivers = {"kalshi": _run_kalshi_live, "kalshi-perp": _run_kalshi_perp_live,
               "polymarket_us": _run_polymarket_us_live}
    if cfg.venue in drivers:
        try:
            auth = _consume_shared_ack_and_arm(cfg, run_dir, source_ack)
            if account_budget is not None:
                from dataclasses import replace
                auth = replace(auth, account_budget=account_budget)
        except LiveGateClosed as e:
            print(f"LIVE GATE CLOSED: {e}\nconfig digest: {cfg.digest()}", file=sys.stderr)
            if cli_allocated_run_dir:
                _discard_refused_run_dir(cfg, run_dir)
            return 4
        print(f"run_dir={run_dir}", flush=True)
        driver = drivers[cfg.venue]
        receipt = asyncio.run(driver(a, cfg, auth, run_dir))
        _print_receipt(receipt)
        print(json.dumps({"live": receipt["live"]}, indent=2), flush=True)
        if not receipt["live"]["clean"]:
            print("LIVE NOT CLEAN: unresolved execution; inspect receipt.json", file=sys.stderr)
            return 5
        return receipt.get("exit_code", 5) if receipt.get("exception") else 0
    try:
        auth = _consume_shared_ack_and_arm(cfg, run_dir, source_ack)
    except LiveGateClosed as e:
        print(f"LIVE GATE CLOSED: {e}\nconfig digest: {cfg.digest()}", file=sys.stderr)
        if cli_allocated_run_dir:
            _discard_refused_run_dir(cfg, run_dir)
        return 4
    from .broker.binanceus_live import BinanceUSLive
    from .broker.live_broker import LiveBroker, LiveClientIO, LiveEngine

    async def go() -> dict:
        io = LiveClientIO()
        client = broker = ledger = None
        receipt = None
        adopted_inventory_i = None
        try:
            client = BinanceUSLive(auth, journal_dir=run_dir)
            io.run(client.__aenter__())
            io.run(client.load_filters())
            account = io.run(client.account())
            print(_account_ok_line(account, cfg.symbol), file=sys.stderr, flush=True)
            fees = schedule_for("binanceus_tier0" if cfg.strategy_params.get("tier0") else "binanceus")
            broker = LiveBroker(client, auth, fees, cfg.symbol, account, io=io,
                                allow_existing_inventory=getattr(a, "adopt_inventory", False),
                                starting_cash_q=cfg.starting_cash_q,
                                taker_slippage_bps=cfg.paper.taker_slippage_bps)
            if getattr(a, "adopt_inventory", False):
                adopted_inventory_i = broker.pos_i
                amount = next(row["free"] for row in account["balances"]
                              if row["asset"] == broker.base_asset)
                print(f"adopting base inventory {amount} {broker.base_asset} (operator permission)",
                      file=sys.stderr, flush=True)
            # Allocate only the authorized cash; independent account-risk snapshots stay intact.
            broker.cash_q = min(broker.cash_q, cfg.starting_cash_q)
            risk = RiskManager(cfg.risk, cfg.starting_cash_q,
                               state_path=run_dir / "risk-state.json", kill_file=run_dir / "KILL")
            ledger = Ledger(run_dir / "ledger.sqlite")
            params = dict(cfg.strategy_params)
            params["cost_rt_bps"] = _cost_rt_bps(cfg, fees)
            params.setdefault("min_edge_bps", 0.25)
            # Positional-only when no alternation: existing monkeypatches of make_strategy
            # in the non-alternating tests accept only (name, params, venue).
            if cfg.alternate_strategy:
                strategy = make_strategy(cfg.strategy, params, cfg.venue,
                                         alternate=cfg.alternate_strategy, block_minutes=cfg.block_minutes)
            else:
                strategy = make_strategy(cfg.strategy, params, cfg.venue)
            from .types import to_price_i, to_size_i

            strategy.tick_i = to_price_i(str(client.filters["tick_size"]))
            strategy.lot_i = to_size_i(str(client.filters["step_size"]))
            strategy.min_notional_q = to_quote_q(str(client.filters["min_notional"]))
            if strategy.tick_i <= 0 or strategy.lot_i <= 0:
                raise LiveGateClosed("venue increments below supported precision")
            if cfg.venue == "binanceus":
                # binanceus is maker-only for this driver: never let the book emit a taker order.
                strategy.maker_only = True
            strategy = _RehearsalStrategy(strategy, getattr(a, "probe_order", False), auth.issued_ns)
            feed = make_feed("binanceus", cfg.symbol, transport=getattr(a, "transport", "auto"))
            (run_dir / "config.json").write_text(json.dumps(_cfg_dict(cfg), indent=2), encoding="utf-8")

            class RehearsalEngine(LiveEngine):
                def process_event(self, ev):
                    started = time.monotonic()
                    before = self.broker.orders_total
                    previous_ids = set(self.broker.client_ids)
                    try:
                        super().process_event(ev)
                    finally:
                        if strategy.probe_pending:
                            strategy.probe_pending = False
                            self.m.cancels += self.broker.cancel_all(time.time_ns())
                            probe_ids = set(self.broker.client_ids) - previous_ids
                            canceled = (len(probe_ids) == 1 and all(
                                self.broker.client._owned.get(self.broker.client_ids[oid]) == "CANCELED"
                                for oid in probe_ids))
                            if (self.broker.orders_total != before + 1 or self.broker.view().open_count
                                    or not canceled or self.broker.halted or time.monotonic() - started > 10):
                                self.risk.kill("live probe did not cancel cleanly within 10 seconds")
                                raise LiveGateClosed("live probe failed")
                            strategy.probe_done = True
                            self._ledger(time.time_ns(), "live-probe",
                                        {"cancelled": True, "side": strategy.probe_side})

            engine = RehearsalEngine(cfg, strategy, broker, risk, ledger, run_dir)
            receipt = await engine.run_live(feed)
        except Exception as e:
            # Every exception type raised inside this driver already excludes request
            # params, headers and key material (VenueError, OrderStateUnknown, LiveGateClosed);
            # printing the class and str() here is what makes a live failure diagnosable.
            print(f"live driver failed: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
            receipt = {"config_digest": cfg.digest(), "stop_reason": "live driver failed",
                       "exception": type(e).__name__, "exception_detail": _exception_detail(e)}
        finally:
            if broker is not None:
                if not broker._closed:
                    broker.finish(time.time_ns())
                    broker.close()
                live = broker.live_summary()
            else:
                live = {"unresolved": [], "failed_cancels": [], "clean": client is None}
                if client is not None:
                    try:
                        result = io.run(client.cancel_owned())
                        live["failed_cancels"].extend(result["failed"])
                    except Exception as e:
                        live["unresolved"].append("client cancel: " + type(e).__name__)
                    try:
                        live["unresolved"].extend(io.run(client.reconcile()))
                    except Exception as e:
                        live["unresolved"].append("client reconcile: " + type(e).__name__)
                    try:
                        io.run(client.__aexit__(None, None, None))
                        closed = client.shutdown_result
                        live["failed_cancels"].extend(closed["failed"])
                        live["unresolved"].extend(closed["unresolved"])
                    except Exception as e:
                        live["unresolved"].append("client close: " + type(e).__name__)
                    live["failed_cancels"] = sorted(set(live["failed_cancels"]))
                    live["unresolved"] = sorted(set(live["unresolved"]))
                    live["clean"] = not live["failed_cancels"] and not live["unresolved"]
                io.close()
            if ledger is not None:
                ledger.close()
            receipt = receipt or {"config_digest": cfg.digest(), "stop_reason": "live driver interrupted"}
            receipt["live"] = live
            from dataclasses import asdict as _asdict

            receipt["limits_profile"] = cfg.limits_profile
            receipt["limits"] = _asdict(cfg.risk)
            if adopted_inventory_i is not None:
                receipt["adopted_inventory_i"] = adopted_inventory_i
            run_dir.mkdir(parents=True, exist_ok=True)
            (run_dir / "receipt.json").write_text(json.dumps(receipt, indent=2, default=str), encoding="utf-8")
        return receipt

    print(f"run_dir={run_dir}", flush=True)
    receipt = asyncio.run(go())
    _print_receipt(receipt)
    print(json.dumps({"live": receipt["live"]}, indent=2), flush=True)
    if not receipt["live"]["clean"]:
        print("LIVE NOT CLEAN: unresolved execution or failed cancels; inspect receipt.json", file=sys.stderr)
        return 5
    return 5 if receipt.get("exception") else 0


def _reconcile_authorization(a: argparse.Namespace):
    """A read-only-shaped authorization for the reconcile client: it places nothing, so a fixed
    $100/s2c authorization (never the operator's real stake) is enough to construct the client."""
    from .broker.live_gate import LiveAuthorization
    from .config import EngineConfig
    from .types import to_quote_q

    cfg = EngineConfig(venue=a.venue, symbol=a.symbol, strategy="mm", mode="live",
                       starting_cash_q=to_quote_q("100"), goal_q=to_quote_q("1000"),
                       limits_profile="s2c", run_seconds=600)
    now_ns = time.time_ns()
    return LiveAuthorization(cfg.venue, cfg.symbol, cfg.digest(), "reconcile", now_ns,
                             now_ns + 3600 * 1_000_000_000, cfg.risk, cfg.starting_cash_q)


def _adopt_foreign_order(client, row: dict) -> None:
    """Bring an `lh-` order this process's own journal never saw into the client's owned table,
    so the tested `cancel()` path (which refuses an id it does not already own) can act on it."""
    from .types import Intent, Side, TimeInForce, to_price_i, to_size_i

    cid = row["clientOrderId"]
    side = Side.BUY if row.get("side") == "BUY" else Side.SELL
    price_i = to_price_i(str(row.get("price", "0")))
    size_i = to_size_i(str(row.get("origQty", "0")))
    executed_i = to_size_i(str(row.get("executedQty", "0")))
    intent = Intent(side, price_i, size_i, TimeInForce.POST_ONLY)
    client._records[cid] = {
        "intent": {"side": int(intent.side), "price_i": intent.price_i, "size_i": intent.size_i, "tif": int(intent.tif)},
        "ref_price_i": price_i, "venue_order_id": row.get("orderId"), "executed_qty_i": executed_i,
        "symbol": client.symbol,
    }
    client._transition(cid, "ACKED", "adopted for reconcile", venue_order_id=row.get("orderId"), executed_qty_i=executed_i)


def cmd_kalshi_reconcile(a: argparse.Namespace) -> int:
    from .broker.kalshi_live import KalshiLive
    from .broker.live_gate import CRED_ENV
    import tempfile

    names = CRED_ENV.get("kalshi") or ()
    blockers = [f"credential {n} missing or too short" for n in names if len(os.environ.get(n, "")) < 16]
    if blockers:
        for b in blockers:
            print(f"LIVE GATE CLOSED: {b}", file=sys.stderr)
        return 4
    auth = _reconcile_authorization(a)
    journal_dir = a.journal_dir or tempfile.mkdtemp(prefix="leafhft-kalshi-reconcile-")
    final: list = []

    async def go() -> None:
        nonlocal final
        client = KalshiLive(auth, journal_dir=journal_dir)
        await client.__aenter__()
        try:
            open_orders = [cid for cid, state in client._owned.items() if state not in ("FILLED", "PARTIAL", "CANCELED", "GONE")]
            for cid in open_orders:
                record = client._records[cid]
                print(f"open {record['ticker']} {'YES' if record['side_yes'] else 'NO'} "
                     f"{record['price_cents']}c x{record['count']} {client._owned[cid]} owned {cid[-8:]}")
            final = open_orders
            if a.cancel:
                await client.reconcile()
                open_orders = [cid for cid, state in client._owned.items() if state not in ("FILLED", "PARTIAL", "CANCELED", "GONE")]
                for cid in open_orders:
                    oid = client._records[cid].get("venue_order_id")
                    if oid is not None:
                        result = await client.cancel(oid)
                        print(f"cancel {cid[-8:]} {result.get('status', 'requested')}")
                final = open_orders
            balance_cents = await client.balance()
            print(f"balance USD free={balance_cents / 100:.2f}")
            if a.settle:
                for cid, row in list(client._records.items()):
                    if client._owned.get(cid) not in ("FILLED", "PARTIAL"):
                        continue
                    market = await client.market(row["ticker"])
                    result = market.get("result")
                    if result not in ("yes", "no"):
                        continue
                    print(f"settle {row['ticker']} result={result} client_id={cid[-8:]}")
        finally:
            if client._session is not None:
                await client._session.close()
                client._session = None

    asyncio.run(go())
    return 3 if final else 0


def cmd_live_reconcile(a: argparse.Namespace) -> int:
    from .broker.binanceus_live import BinanceUSLive
    from .broker.live_broker import LiveClientIO
    from .broker.live_gate import CRED_ENV
    import tempfile

    if a.venue == "kalshi":
        return cmd_kalshi_reconcile(a)
    if a.venue != "binanceus":
        print("LIVE GATE CLOSED: live-reconcile supports binanceus only", file=sys.stderr)
        return 4
    names = CRED_ENV.get(a.venue) or ()
    blockers = [f"credential {n} missing or too short" for n in names if len(os.environ.get(n, "")) < 16]
    if blockers:
        for b in blockers:
            print(f"LIVE GATE CLOSED: {b}", file=sys.stderr)
        return 4

    auth = _reconcile_authorization(a)
    journal_dir = a.journal_dir or tempfile.mkdtemp(prefix="leafhft-reconcile-")
    parts = a.symbol.upper().split("-")
    base, quote = parts if len(parts) == 2 else ("", "")

    io = LiveClientIO()
    final: list = []
    try:
        client = BinanceUSLive(auth, journal_dir=journal_dir)
        io.run(client.__aenter__())
        try:
            orders = io.run(client.open_orders())
            for row in orders:
                cid = row.get("clientOrderId", "")
                owned = "owned" if cid.startswith("lh-") else "foreign"
                print(f"open {row.get('side')} {row.get('price')} {row.get('origQty')} "
                     f"{row.get('status')} {owned} {cid[-8:]}")
            final = orders
            if a.cancel:
                io.run(client.cancel_owned())
                for row in io.run(client.open_orders()):
                    cid = row.get("clientOrderId", "")
                    if not cid.startswith("lh-"):
                        continue
                    if cid not in client._owned:
                        _adopt_foreign_order(client, row)
                    result = io.run(client.cancel(cid))
                    print(f"cancel {cid[-8:]} {result.get('status')}")
                final = io.run(client.open_orders())
            account = io.run(client.account())
            for row in account.get("balances", []):
                asset = row.get("asset")
                if asset in (base, quote):
                    print(f"balance {asset} free={row.get('free')} locked={row.get('locked')}")
        finally:
            async def _close_session():
                if client._session is not None:
                    await client._session.close()
                    client._session = None
            io.run(_close_session())
    finally:
        io.close()
    return 3 if final else 0


def cmd_signals(a: argparse.Namespace) -> int:
    from .signals import compute

    dirs = [Path(a.run_dir)] if a.run_dir else sorted(d for d in Path(a.runs).iterdir() if d.is_dir() and (d / "ticks.jsonl").is_file())
    for d in dirs:
        s = compute(d, with_sentiment=not a.no_sentiment)
        m = s.get("model", {})
        print(f"{d.name}: regime={s['regime'].get('status')} model={m.get('status')} oos_hit={m.get('oos_hit_rate')} n={m.get('oos_n')} edge={m.get('implied_edge_bps_per_trade')}bps sentiment={s['sentiment'].get('value')}", flush=True)
    return 0


def cmd_ui(a: argparse.Namespace) -> int:
    from .ui.server import serve

    serve(a.runs, port=a.port)
    return 0


def cmd_push(a: argparse.Namespace) -> int:
    if getattr(a, "tenant_id", None):
        return cmd_tenant_push(a)
    from .push import push_runs, watch_run

    if a.watch:
        return watch_run(Path(a.run_dir), a.url, interval_s=a.every, token_env=a.token_env)
    n = push_runs(Path(a.runs) if not a.run_dir else None, a.url, run_dir=Path(a.run_dir) if a.run_dir else None, token_env=a.token_env)
    print(json.dumps({"pushed": n}))
    return 0 if n >= 0 else 2


def cmd_tenant_push(a: argparse.Namespace) -> int:
    """Publish only this tenant's offline manifests; never poll/apply controls."""
    import re
    from .push import _post, _token
    from .sim.fuzz import require_paper_environment

    require_paper_environment("paper")
    if (not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", a.tenant_id) or
            os.environ.get("LEAFHFT_TENANT_ID") != a.tenant_id or a.watch or a.run_dir):
        raise SystemExit("invalid tenant push")
    root = Path("/var/lib/leafhft-tenants") / a.tenant_id / "runs"
    if Path(a.runs) != root or any(p.is_symlink() for p in (root, *root.parents)):
        raise SystemExit("invalid tenant runs path")
    if a.url != "https://ops-dashboard-seven.vercel.app":
        raise SystemExit("invalid tenant dashboard")
    token = _token(a.token_env)
    pushed = 0
    for directory in sorted(root.iterdir())[:1000]:
        manifest_path = directory / "paper-manifest.json"
        if directory.is_symlink() or not directory.is_dir() or manifest_path.is_symlink():
            continue
        manifest = _read_config_json_capped(manifest_path, 8192)
        if not manifest or manifest.get("live") is not False or manifest.get("mode") not in ("paper", "replay"):
            continue
        payload = {"host": "kashbot-" + a.tenant_id,
                   "run": {"run_id": directory.name, "venue": "kalshi", "mode": "paper",
                           "live": False, "config": manifest},
                   "marks": [], "fills": [], "markouts": [], "since_row": 0,
                   "last_row": 0, "truncated": False}
        _post(a.url, token, payload)
        pushed += 1
    print(json.dumps({"pushed": pushed, "mode": "dry_run"}))
    return 0


def _policy_default_path() -> str:
    return "/etc/leafhft/kalshi-policy.json"


def _load_effective_policy(path: Path):
    """Returns (policy, used_default): used_default is True only when the file is absent, so a
    malformed existing file still raises PolicyError rather than silently falling back."""
    if not path.is_file():
        from .policy import DEFAULT_POLICY

        return DEFAULT_POLICY, True
    from .policy import load_policy

    return load_policy(path), False


def _policy_runs_default_path() -> str:
    return str(Path(os.environ.get("LEAFHFT_STATE_DIR", "/var/lib/leafhft")) / "runs")


def _read_config_json_capped(path: Path, max_bytes: int = 1024 * 1024) -> dict | None:
    """One bounded read; over the cap, unreadable, unparseable, or not a JSON object all count
    as unreadable (None) to the caller, never partially trusted."""
    try:
        with path.open("rb") as fh:
            data = fh.read(max_bytes + 1)
    except OSError:
        return None
    if len(data) > max_bytes:
        return None
    try:
        obj = json.loads(data)
    except ValueError:
        return None
    return obj if isinstance(obj, dict) else None


def _is_bounds_digest(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def _live_policy_readers(runs: Path, policy_path: Path, max_age_s: float = _LIVE_READER_MAX_AGE_S,
                          max_dirs: int = 4096) -> list[tuple[str, str | None]]:
    """Every LIVE reader of the exact resolved `policy_path`: (run_dir_name, bounds_digest_or_None).

    A run dir is live when the NEWER of its kalshi-edge-status.json and config.json mtimes is
    within max_age_s of now: a book writes config.json at run-dir creation and its first status
    file only after the live gate and first event, so judging liveness on the status file alone
    misses a book that has started but not yet written one. A live run whose config.json cannot
    prove which bounds it understands (unreadable, unparseable, or a malformed digest) still
    counts, with digest None: failing to prove readability is a refusal, never a silent skip. A
    run naming a DIFFERENT resolved policy path is excluded entirely, it is not a reader of this
    file; a run whose named path cannot even be resolved (offline mount, rejected characters, a
    permission error) also counts, with digest None, for the same reason. Bounded enumeration: at
    most max_dirs entries, refuses past the cap rather than truncating (precedent: collect() in
    scripts/leafhft_alert.py).

    max_age_s defaults to six missed KALSHI_STATUS_INTERVAL_S heartbeats (180 s): refresh_venue
    writes kalshi-edge-status.json unconditionally on that interval, so a live book's status file
    is always seconds old, while a killed book's stops moving the moment it dies. DECLARED
    RESIDUAL: a live book whose status writes stall past the window stops counting, which is a
    false pass; a longer window trades that for readmitting corpses, and a book stalled that long
    is itself an incident the unit-down alert covers, not this preflight.
    """
    from .policy import PolicyError

    runs = Path(runs)
    try:
        target = Path(policy_path).resolve()
    except OSError as e:
        raise PolicyError(f"policy preflight: cannot resolve policy path {policy_path}: {e}") from e
    now = time.time()
    try:
        with os.scandir(runs) as it:
            candidates: list[str] = []
            for entry in it:
                if not entry.is_dir():
                    continue
                if len(candidates) >= max_dirs:
                    raise PolicyError(f"policy preflight: run directory cap ({max_dirs}) exceeded under {runs}")
                candidates.append(entry.path)
    except FileNotFoundError:
        return []
    readers: list[tuple[str, str | None]] = []
    for run_path_str in candidates:
        run_path = Path(run_path_str)
        mtimes: list[float] = []
        for fname in ("kalshi-edge-status.json", "config.json"):
            try:
                mtimes.append((run_path / fname).stat().st_mtime)
            except OSError:
                pass
        if not mtimes:
            continue
        if now - max(mtimes) > max_age_s:
            continue
        cfg = _read_config_json_capped(run_path / "config.json")
        if cfg is None:
            readers.append((run_path.name, None))
            continue
        cfg_policy_path = cfg.get("policy_path")
        if not isinstance(cfg_policy_path, str) or not cfg_policy_path:
            continue
        try:
            if Path(cfg_policy_path).resolve() != target:
                continue
        except OSError:
            readers.append((run_path.name, None))
            continue
        digest = cfg.get("policy_bounds_digest")
        readers.append((run_path.name, digest if _is_bounds_digest(digest) else None))
    return readers


def _policy_uptake_readback(policy_path: Path, runs: Path, expected_digest: str, *,
                            wait_s: float = 6.0, poll_s: float = 2.0,
                            now=time.time, sleep=time.sleep) -> dict:
    """Observe the write's live readers without ever invalidating the completed write.

    Keep the initial cohort: a reader disappearing during polling is not uptake.
    Missing digests are unknown, never inferred from the configured parameters.
    """
    result = {"expected": expected_digest, "books": 0, "matched": 0,
              "errors": [], "unknown": [], "waited_s": 0.0, "unconfirmed": []}
    started = None
    try:
        import math

        wait_s, poll_s = float(wait_s), float(poll_s)
        if not math.isfinite(wait_s) or not 0 <= wait_s <= 60:
            raise ValueError("wait_s must be between 0 and 60")
        if not math.isfinite(poll_s) or poll_s <= 0:
            raise ValueError("poll_s must be positive")
        started = now()
        readers = _live_policy_readers(runs, policy_path)
        result["books"] = len(readers)
        # The poll budget also bounds execution if an injected clock stops advancing.
        for attempt in range(math.ceil(wait_s / poll_s) + 1):
            result.update(matched=0, errors=[], unknown=[], unconfirmed=[])
            for name, _bounds in readers:
                payload = _read_config_json_capped(Path(runs) / name / "kalshi-edge-status.json")
                if payload is None:
                    result["errors"].append(f"{name}: unreadable")
                    result["unconfirmed"].append(name)
                    continue
                block = payload.get("policy")
                block = block if isinstance(block, dict) else {}
                digest, error = block.get("digest"), block.get("error")
                if error is not None:
                    result["errors"].append(f"{name}: {error}")
                if not isinstance(digest, str) or not digest:
                    result["unknown"].append(name)
                if digest == expected_digest and error is None:
                    result["matched"] += 1
                else:
                    result["unconfirmed"].append(name)
            result["waited_s"] = max(0.0, now() - started)
            remaining = wait_s - result["waited_s"]
            if result["matched"] == result["books"] or remaining <= 0:
                break
            if attempt < math.ceil(wait_s / poll_s):
                sleep(min(poll_s, remaining))
    except Exception as exc:
        result["errors"].append(f"readback: {type(exc).__name__}: {exc}")
        try:
            if started is not None:
                result["waited_s"] = max(0.0, now() - started)
        except Exception:
            pass
    return result


def _print_policy_uptake(a: argparse.Namespace, path: Path, digest: str) -> None:
    """Best-effort reporting only; the policy has already been committed."""
    try:
        if getattr(a, "no_uptake", False):
            print("policy uptake: skipped")
            return
        result = _policy_uptake_readback(path, Path(a.runs), digest,
                                         wait_s=getattr(a, "uptake_wait", 6.0))
        books, matched = result["books"], result["matched"]
        errors, unknown = len(result["errors"]), len(result["unknown"])
        print(f"policy uptake: books={books} matched={matched} errors={errors} "
              f"unknown={unknown} waited={result['waited_s']:.1f}s")
        if matched < books or errors:
            names = result.get("unconfirmed") or result["errors"]
            print(f"policy uptake: NOT CONFIRMED ({', '.join(names)})")
        print(f"IMPACT-EVIDENCE policy-uptake:digest={digest[:12]}:books={matched}/{books}:errors={errors}")
    except Exception:
        # Reporting failures must not change the successful write's exit status.
        try:
            print("policy uptake: NOT CONFIRMED (readback unavailable)")
            print(f"IMPACT-EVIDENCE policy-uptake:digest={digest[:12]}:books=0/0:errors=1")
        except Exception:
            pass


def _uptake_wait_arg(raw: str) -> float:
    value = float(raw)
    if not 0 <= value <= 60:
        raise argparse.ArgumentTypeError("uptake wait must be between 0 and 60 seconds")
    return value


def _policy_write_preflight(policy_path: Path, runs: Path, build_digest: str, *, force: bool) -> str:
    """Runs before ANY policy write. Raises PolicyError (file untouched) when a live reader's
    pinned bounds digest differs from this build's, unless force. Returns the trailing status
    line the caller prints after a successful write (or a no-op dry run)."""
    from .policy import PolicyError

    readers = _live_policy_readers(runs, policy_path)
    mismatched = [(name, digest) for name, digest in readers if digest != build_digest]
    if not mismatched:
        if not readers:
            return f"no live book is reading {policy_path}; it applies at the next book start"
        return "hot: applied by every book within 5 s"
    names = [name for name, _ in mismatched]
    shown = ", ".join(names[:6]) + (f" and {len(names) - 6} more" if len(names) > 6 else "")
    reader_digests = ", ".join(sorted({(d[:12] if d else "unreadable") for _, d in mismatched}))
    detail = (f"{len(mismatched)} live reader(s) of {policy_path} cannot parse this build's policy "
              f"({shown}); build digest {build_digest[:12]}, reader digest(s) {reader_digests}")
    if force:
        print(f"--force: waiving preflight, {detail}", file=sys.stderr, flush=True)
        return "--force: the mismatched books above will refuse this policy until restarted onto this build"
    raise PolicyError(f"policy write refused: {detail}; restart those books onto this build, or re-run with --force")


def cmd_policy_show(a: argparse.Namespace) -> int:
    from .policy import policy_bounds_digest, policy_digest, policy_document

    path = Path(a.path)
    policy, used_default = _load_effective_policy(path)
    # policy_document so the shown policy, hashed canonically, equals the digest beside it.
    payload = {"policy": policy_document(policy), "digest": policy_digest(policy),
               "bounds_digest": policy_bounds_digest()}
    if used_default:
        payload["note"] = f"policy file not found at {path}; showing DEFAULT_POLICY"
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def cmd_policy_validate(a: argparse.Namespace) -> int:
    from .policy import PolicyError, load_policy, policy_digest

    try:
        policy = load_policy(Path(a.path))
    except PolicyError as e:
        print(str(e))
        return 2
    print(f"ok {policy_digest(policy)}")
    return 0


def _parse_policy_value(key: str, raw: str) -> Any:
    """Required keys parse to their kind. An optional key also takes "unset" (or "none", or an
    empty value), which parses to None: the field is cleared and every serialized form omits it."""
    from .policy import OPTIONAL_POLICY_BOUNDS, POLICY_BOUNDS, PolicyError, validate_hard_maxima

    if key in OPTIONAL_POLICY_BOUNDS:
        if raw.strip().lower() in ("", "none", "unset"):
            return None
        _lo, _hi, kind = OPTIONAL_POLICY_BOUNDS[key]
    elif key in POLICY_BOUNDS:
        _lo, _hi, kind = POLICY_BOUNDS[key]
    else:
        raise PolicyError(f"policy set: unknown key {key!r}")
    try:
        value = kind(raw) if kind is int else float(raw)
    except ValueError as exc:
        raise PolicyError(f"policy set: {key}: {raw!r} is not a valid {kind.__name__}") from exc
    validate_hard_maxima({key: value})
    if key == "fixed_count" and value == 0:
        return None  # 0 is the unset legacy sizing law, the value KalshiPolicy normalizes it to
    return value


def _regime_clamped_fields(raw_policy) -> list[tuple[str, object, float]]:
    """(key, value, maximum) for every raw numeric field the current risk regime would silently
    clamp on parse, sorted by key. Empty in the owner regime. Pure: no I/O."""
    import math

    from .policy import hard_maxima

    clamped = []
    for key, maximum in sorted(hard_maxima().items()):
        value = raw_policy.get(key)
        if (isinstance(value, (int, float)) and not isinstance(value, bool)
                and math.isfinite(value) and value > maximum):
            clamped.append((key, value, maximum))
    return clamped


def _regime_clamp_refusal(command: str, raw_policy) -> str | None:
    """The one-line refusal naming each field the regime would clamp, or None when none would."""
    clamped = _regime_clamped_fields(raw_policy)
    if not clamped:
        return None
    fields = ", ".join(f"{key} {value} to {maximum}" for key, value, maximum in clamped)
    return (f"{command}: the account risk regime would clamp {fields}; nothing written "
            "(lower the field, or run on the owner host with LEAFHFT_RISK_REGIME=owner)")


def cmd_policy_set(a: argparse.Namespace) -> int:
    from .policy import (PolicyError, policy_bounds_digest, policy_digest, policy_document,
                         policy_from_mapping, write_policy)

    path = Path(a.path)
    try:
        current, _used_default = _load_effective_policy(path)
        pairs: dict[str, Any] = {}
        for kv in a.assignment:
            if "=" not in kv:
                raise PolicyError(f"policy set: {kv!r} is not key=value")
            key, raw = kv.split("=", 1)
            pairs[key] = _parse_policy_value(key, raw)
        # A None pair clears an optional key; policy_from_mapping reads it as unset.
        new_policy = policy_from_mapping({**policy_document(current), **pairs})
        trailing = _policy_write_preflight(path, Path(a.runs), policy_bounds_digest(), force=a.force)
    except PolicyError as e:
        print(str(e))
        return 2
    changed = {k: (getattr(current, k), v) for k, v in pairs.items() if getattr(current, k) != v}
    if not a.dry_run:
        write_policy(path, new_policy)
    for key, (old, new) in changed.items():
        print(f"{key}: {old} -> {new}")
    print(f"digest {policy_digest(new_policy)}")
    if not a.dry_run:
        _print_policy_uptake(a, path, policy_digest(new_policy))
    if "stake_ceiling_usd" in changed:
        print("re-ack: stake_ceiling_usd changed; the books need a new authorization sentence")
    else:
        print(trailing)
    return 0


def cmd_policy_promote(a: argparse.Namespace) -> int:
    from datetime import datetime, timezone
    import tempfile

    from .policy import (POLICY_BOUNDS, PolicyError, policy_bounds_digest, policy_digest, policy_document,
                         policy_from_mapping, write_policy)

    try:
        if not a.require_ready:
            raise PolicyError("policy promote: --require-ready PATH is required")
        key = a.key
        if key not in POLICY_BOUNDS:
            raise PolicyError(f"policy promote: unknown key {key!r}")
        live_path = Path(a.to_path).resolve()
        shadow_path = Path(a.from_path).resolve()
        live_bytes = live_path.read_bytes()
        live_raw = json.loads(live_bytes)
        shadow_raw = json.loads(shadow_path.read_bytes())
        if not isinstance(live_raw, dict) or not isinstance(shadow_raw, dict):
            raise PolicyError("policy promote: both policy files must contain JSON objects")
        if key not in live_raw or key not in shadow_raw:
            raise PolicyError(f"policy promote: {key!r} must exist in both files")
        current = policy_from_mapping(live_raw)
        shadow = policy_from_mapping(shadow_raw)
        old, new = getattr(current, key), getattr(shadow, key)
        if old == new:
            raise PolicyError(f"policy promote: {key!r} is already equal")
        report = json.loads(Path(a.require_ready).read_bytes())
        promotions = report.get("promotion") if isinstance(report, dict) else None
        evidence = promotions.get(key) if isinstance(promotions, dict) else None
        if not isinstance(evidence, dict) or evidence.get("state") != "READY":
            raise PolicyError(f"policy promote: {key!r} is not READY")
        if evidence.get("old", old) != old or evidence.get("new", new) != new:
            raise PolicyError("policy promote: READY evidence does not match current values")
        n = evidence.get("n")
        if type(n) is not int or n < 100:
            raise PolicyError("policy promote: READY evidence requires shadow n >= 100")
        from .policy import validate_hard_maxima
        validate_hard_maxima({key: shadow_raw.get(key, new)})
        candidate = policy_from_mapping({**policy_document(current), key: new})
        digest = policy_digest(candidate)
        trailing = _policy_write_preflight(live_path, Path(a.runs), policy_bounds_digest(), force=a.force)
        line = (json.dumps({"at": datetime.now(timezone.utc).isoformat(), "key": key,
                            "old": old, "new": new, "live_digest": digest,
                            "shadow_report_n": n, "operator_ack": True}) + "\n").encode("utf-8")
        journal_path = Path(os.environ.get("LEAFHFT_STATE_DIR", "/var/lib/leafhft")) / "policy-promotions.jsonl"
        # Stage on the destination filesystem. This avoids write_policy's in-place
        # fallback and keeps the live file intact on every pre-commit failure.
        with tempfile.TemporaryDirectory(prefix=".policy-promote-", dir=live_path.parent) as staging:
            staged = Path(staging) / live_path.name
            shutil.copy2(live_path, staged)
            st = live_path.stat()
            if hasattr(os, "geteuid") and os.geteuid() == 0:
                os.chown(staged, st.st_uid, st.st_gid)
            write_policy(staged, candidate)
            journal_path.parent.mkdir(parents=True, exist_ok=True)
            with journal_path.open("a+b") as journal:
                if os.name == "posix":
                    import fcntl

                    fcntl.flock(journal.fileno(), fcntl.LOCK_EX)
                journal.seek(0, os.SEEK_END)
                journal_end = journal.tell()
                try:
                    if live_path.read_bytes() != live_bytes:
                        raise PolicyError("policy promote: live policy changed; retry with current evidence")
                    journal.write(line)
                    journal.flush()
                    os.fsync(journal.fileno())
                    os.replace(staged, live_path)
                except (OSError, PolicyError):
                    journal.truncate(journal_end)
                    journal.flush()
                    os.fsync(journal.fileno())
                    raise
    except (OSError, ValueError, UnicodeError) as exc:
        print(f"policy promote: {exc}")
        return 2
    print(f"{key}: {old} -> {new} (from shadow)")
    print(f"digest {digest}")
    _print_policy_uptake(a, live_path, digest)
    if key == "stake_ceiling_usd":
        print("re-ack: stake_ceiling_usd changed; the books need a new authorization sentence")
    else:
        print(trailing)
    return 0


def cmd_policy(a: argparse.Namespace) -> int:
    return {"show": cmd_policy_show, "validate": cmd_policy_validate, "set": cmd_policy_set,
            "promote": cmd_policy_promote}[a.policy_cmd](a)


def cmd_authority(a: argparse.Namespace) -> int:
    from .broker.kalshi_authority import KalshiAuthority, Refusal, _key, _FileLock, LOCK_TIMEOUT_S
    from .broker.kalshi_live import KalshiLive
    import tempfile

    path = Path(a.authority_path)
    if getattr(a, "authority_cmd", "init") == "caps":
        import re

        try:
            if os.name == "posix" and os.geteuid() == 0:
                raise ValueError("run as the service user, e.g. sudo -u leafhft leafhft authority caps")
            lane = _key(a.lane)
            if any(char not in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in lane):
                raise ValueError("lane must contain only lowercase letters, digits, and hyphens")
            changes = {}
            for assignment in a.assignment:
                key, separator, value = assignment.partition("=")
                if not separator or not key or key in changes:
                    raise ValueError("expected unique key=value assignments")
                if value.lower() != "none" and re.fullmatch(r"-?[0-9]+", value) is None:
                    raise ValueError("cap must be an integer or none")
                changes[key] = None if value.lower() == "none" else int(value)
            before_doc = json.loads(path.read_text(encoding="utf-8"))
            authority = KalshiAuthority(path, generation_id=before_doc["generation_id"],
                                        floor_cents=before_doc["floor_cents"],
                                        max_cash_age_ms=before_doc["max_cash_age_ms"])
            if changes:
                result = authority.set_caps(lane, allow_unlimited=a.allow_unlimited, **changes)
            else:
                snapshot = authority.snapshot()
                result = (snapshot if isinstance(snapshot, Refusal) else
                          snapshot["budgets"].get(lane, Refusal("unknown_lane", lane)))
                if not isinstance(result, Refusal):
                    result = {**result, "before": result["caps"], "after": result["caps"],
                              "latched": snapshot["lanes"][lane]["latched"]}
            if isinstance(result, Refusal):
                print(f"authority caps refused: {result.reason} {result.detail}".rstrip(), file=sys.stderr)
                return 1
            print(json.dumps({"lane": lane, **result}))
            return 0
        except (OSError, ValueError, TypeError, KeyError) as exc:
            print(f"authority caps refused: {exc}", file=sys.stderr)
            return 2
    if getattr(a, "authority_cmd", "init") == "unlatch":
        try:
            if os.name == "posix" and os.geteuid() == 0:
                raise ValueError("run as the service user, e.g. sudo -u leafhft leafhft authority unlatch")
            lane = _key(a.lane)
            if any(char not in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in lane):
                raise ValueError("lane must contain only lowercase letters, digits, and hyphens")
            before_doc = json.loads(path.read_text(encoding="utf-8"))
            if lane not in before_doc["lanes"]:
                raise ValueError(f"unknown lane: {lane}")
            authority = KalshiAuthority(path, generation_id=before_doc["generation_id"],
                                        floor_cents=before_doc["floor_cents"],
                                        max_cash_age_ms=before_doc["max_cash_age_ms"])
            before = before_doc["lanes"][lane]
            result = authority.unlatch(lane, reset_daily_loss=a.reset_daily_loss,
                                       force=getattr(a, "force", False))
            if isinstance(result, Refusal):
                detail = (f" {result.detail} (use --force to override)"
                          if result.reason == "permanent_latch" else "")
                print(f"authority unlatch refused: {result.reason}{detail}", file=sys.stderr)
                return 1
            after = json.loads(path.read_text(encoding="utf-8"))["lanes"][lane]
            fields = ("latched", "gross_loss_today_cents", "latch_reasons")
            print(json.dumps({"lane": lane, "before": {key: before[key] for key in fields},
                              "after": {key: after[key] for key in fields}}))
            if a.reset_daily_loss:
                print("The daily cap is overridden for the rest of the UTC day.")
            return 0
        except (OSError, ValueError, TypeError, KeyError) as exc:
            print(f"authority unlatch refused: {exc}", file=sys.stderr)
            return 2
    generation_path = path.with_suffix(".generation")
    generation_temp = None
    try:
        if os.name == "posix" and os.geteuid() == 0:
            raise ValueError("run as the service user, e.g. sudo -u leafhft leafhft authority init ...")
        if path.exists() or generation_path.exists():
            raise ValueError("authority or generation file already exists")
        if not a.generation or a.generation != a.generation.strip():
            raise ValueError("generation must be a nonempty id without surrounding whitespace")
        authority = KalshiAuthority(path, generation_id=a.generation)
        if a.require_flat:
            async def require_flat():
                with tempfile.TemporaryDirectory(prefix="leafhft-authority-") as journal:
                    auth = _reconcile_authorization(argparse.Namespace(venue="kalshi", symbol="BTC-15M"))
                    async with KalshiLive(auth, journal_dir=journal) as client:
                        from decimal import Decimal
                        positions = await client.all_positions()
                        for position in positions:
                            value = position.get("position_fp", position.get("position"))
                            if value is None or not Decimal(str(value)).is_finite() or Decimal(str(value)) != 0:
                                raise ValueError("authority init requires flat venue positions")
            asyncio.run(require_flat())
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except PermissionError as exc:
            raise ValueError("authority state directory is not writable by the invoking user") from exc
        if not os.access(path.parent, os.W_OK | os.X_OK):
            raise ValueError("authority state directory is not writable by the invoking user")
        # Publish only a complete, synced generation after the authority exists.
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n", delete=False,
                                         dir=path.parent, prefix=generation_path.name + ".", suffix=".tmp") as stream:
            generation_temp = Path(stream.name)
            stream.write(a.generation + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(generation_temp, 0o644)
        try:
            result = authority.initialize(a.generation)
            if result is not True:
                raise ValueError("authority init refused: " + result.reason)
            with _FileLock(authority._lock_path, timeout_s=LOCK_TIMEOUT_S):
                pass
            os.link(generation_temp, generation_path)
        finally:
            generation_temp.unlink(missing_ok=True)
        print("authority initialized")
        return 0
    except Exception as exc:
        if generation_temp is not None:
            generation_temp.unlink(missing_ok=True)
        print(f"authority init refused: {exc}", file=sys.stderr)
        return 4


def cmd_canary(a: argparse.Namespace) -> int:
    from .canary import CanaryError, CanaryStore, lifecycle_directory, lifecycle_status
    from .engines import EngineRegistry, _id
    from .trials import _document

    try:
        directory = lifecycle_directory(a.engines_dir, a.lifecycle_dir)
        if a.canary_cmd in ("register", "advance", "probe"):
            # S7 A L4 (Q5): this lockless writer never touches tenant authority. A tenant lifecycle lives only
            # in the owner store under engine_ops' lock and reaches a book as a root lease; refuse a directory
            # under the projection root and an engine the registry assigns to a lane account.
            from . import account_lane_agent
            from .engine_registry import MAX_REGISTRY_BYTES, REGISTRY_FILE, Registry

            projections = os.path.normcase(os.path.realpath(account_lane_agent.PROJECTION_ROOT))
            for candidate in {os.path.abspath(directory), os.path.realpath(directory)}:
                candidate = os.path.normcase(candidate)
                if candidate == projections or candidate.startswith(projections.rstrip(os.sep) + os.sep):
                    raise CanaryError("lifecycle dir is under the tenant projection root")
            try:
                with open(Path(a.engine_registry_dir) / REGISTRY_FILE, "rb") as stream:
                    registry_bytes = stream.read(MAX_REGISTRY_BYTES + 1)
            except FileNotFoundError:
                registry_bytes = None  # no registry: no engine can be lane-assigned
            if registry_bytes is not None:
                registry = Registry.from_bytes(registry_bytes)  # malformed refuses (RegistryError is a ValueError)
                assignment = registry.assignments.get(a.engine_id)
                account = registry.accounts.get(assignment["account_id"]) if assignment else None
                if account is not None and account.get("lane_id") is not None:
                    raise CanaryError("engine is assigned to a tenant lane account; engine_ops owns its lifecycle")
        store = CanaryStore(directory)
        if a.canary_cmd == "register":
            engine = EngineRegistry(a.engines_dir).get(a.engine_id)
            record = store.register(engine, _document(Path(a.evidence), 1024 * 1024)[0])
        elif a.canary_cmd == "probe":
            engine = EngineRegistry(a.engines_dir).get(a.engine_id)
            other_engine_ids = set()
            for path in a.other_account_bindings:
                bindings = _document(Path(path), 4096)[0]
                if ("default" not in bindings or not isinstance(bindings.get("symbols"), dict)):
                    raise CanaryError("other account bindings require default and symbols")
                if bindings["default"] is not None:
                    other_engine_ids.add(_id(bindings["default"]))
                other_engine_ids.update(_id(value) for value in bindings["symbols"].values())
            record = store.probe(engine, account=a.account, authorization_ref=a.authorization_ref,
                                 expires_at=a.expires_at, other_account_engine_ids=other_engine_ids)
        elif a.canary_cmd == "advance":
            record = store.advance(a.engine_id, _document(Path(a.evidence), 1024 * 1024)[0],
                                   _document(Path(a.eligibility), 16384)[0])
        elif a.canary_cmd == "halt":
            record = store.halt(a.engine_id, a.reason)
        else:
            record = store.get(a.engine_id)
        print(json.dumps(lifecycle_status(record), sort_keys=True))
        return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(f"canary refused: {exc}", file=sys.stderr)
        return 2


def configure_engine(a: argparse.Namespace, *, output=None) -> int:
    """Shared CLI/lane configure boundary; values retain their CLI string parsing."""
    from .engines import AccountOverrides, EngineError, EngineRegistry
    from .policy import PolicyError

    try:
        provenance = getattr(a, "provenance", None)
        raw_provenance = getattr(a, "provenance_json", None)
        if provenance is None and raw_provenance is None:
            raw_provenance = os.environ.get("LEAFHFT_CONFIGURE_PROVENANCE")
        if provenance is None and raw_provenance is not None:
            try:
                if len(raw_provenance.encode("utf-8")) > 2048:
                    raise ValueError("exceeds 2 KiB")
                provenance = json.loads(raw_provenance)
                if not isinstance(provenance, dict):
                    raise ValueError("must be a JSON object")
            except (ValueError, UnicodeError, RecursionError) as exc:
                raise EngineError(f"provenance: {exc}") from exc
        registry = EngineRegistry(a.engines_dir)
        pairs = {}
        for assignment in a.set_values:
            if "=" not in assignment:
                raise EngineError(f"engine configure: {assignment!r} is not key=value")
            key, raw = assignment.split("=", 1)
            pairs[key] = _parse_policy_value(key, raw)
        if not pairs and not a.unset and a.enabled is None:
            raise EngineError("engine configure: no changes")
        if set(pairs) & set(a.unset):
            raise EngineError("policy: key cannot be set and unset")
        refusal = _reversal_mode_configure_refusal(a.engines_dir, a.engine_id, pairs)
        if refusal is not None:
            raise EngineError(f"engine configure: {refusal}: {_reversal_reason_text(refusal)}")
        enabled = ... if a.enabled is None else ({"true": True, "false": False, "inherit": None}[a.enabled])
        if a.account_id:
            overrides = AccountOverrides(a.account_overrides, registry)
            before_enabled, before_policy, before_override = overrides.resolve(a.account_id, a.engine_id)
            after_enabled, after_policy, after_override = overrides.configure(
                a.account_id, a.engine_id, a.expected_revision, enabled=enabled,
                set_values=pairs, unset=a.unset, provenance=provenance)
            if overrides.provenance_warning:
                print(overrides.provenance_warning, file=output)
            print(f"enabled: {before_enabled} -> {after_enabled}", file=output)
            for key in sorted(set(pairs) | set(a.unset)):
                print(f"{key}: {getattr(before_policy, key)} -> {getattr(after_policy, key)}", file=output)
            print("hot: account engine override saved; selected readers apply it within 5 s", file=output)
        else:
            if a.unset or enabled is None:
                raise EngineError("global scope cannot inherit or unset")
            before = registry.get(a.engine_id)
            overrides = AccountOverrides(a.account_overrides, registry)
            engine = registry.configure(a.engine_id, a.expected_revision,
                                        enabled=enabled, set_values=pairs,
                                        validator=overrides.validate_engine)
            print(f"enabled: {before.enabled} -> {engine.enabled}", file=output)
            for key in sorted(pairs):
                print(f"{key}: {getattr(before.policy, key)} -> {getattr(engine.policy, key)}", file=output)
            print("hot: engine configuration saved; selected readers apply it within 5 s", file=output)
            print(f"engine: {engine.engine_id} version {engine.version}", file=output)
        return 0
    except (EngineError, PolicyError, OSError) as exc:
        print(str(exc), file=output)
        return 2


def cmd_engine(a: argparse.Namespace) -> int:
    import traceback

    from .engines import AccountOverrides, Bindings, EngineError, EngineRegistry, capabilities
    from .engines import _read as engines_read
    from .feeds.kalshi import SYMBOL_MAP
    from .policy import PolicyError, load_policy, policy_digest, policy_document

    try:
        registry = EngineRegistry(a.engines_dir)
        bindings = Bindings(a.bindings, registry)
        if a.engine_cmd in ("list", "validate"):
            engines = registry.list()
            document = bindings.load()
            if a.engine_cmd == "list":
                print("id\tname\tversion\tbound books\tcapabilities")
                for engine in engines:
                    books = [symbol for symbol in sorted(SYMBOL_MAP)
                             if document.symbols.get(symbol, document.default) == engine.engine_id]
                    print(f"{engine.engine_id}\t{engine.name}\t{engine.version}\t{','.join(books) or '-'}\t"
                          + json.dumps(capabilities(engine.policy), sort_keys=True))
            for problem in registry.problems:
                print(problem)
            if registry.problems:
                return 2
            if a.engine_cmd == "validate":
                print(f"ok {len(engines)} engines")
        elif a.engine_cmd == "show":
            print(json.dumps(policy_document(registry.get(a.engine_id)), indent=2, sort_keys=True))
        elif a.engine_cmd == "create":
            policy = (registry.get(a.from_engine).policy if a.from_engine
                      else load_policy(Path(a.from_policy)))
            source = (engines_read(registry.path_for(a.from_engine), 8192).get("policy") if a.from_engine
                      else engines_read(Path(a.from_policy), 8192))
            refusal = _regime_clamp_refusal("engine create", source) if isinstance(source, dict) else None
            if refusal is not None:
                raise EngineError(refusal)
            engine = registry.create(a.engine_id, a.name, a.description, policy, a.from_engine)
            print(f"engine: {engine.engine_id} version {engine.version}")
        elif a.engine_cmd == "set":
            pairs = {}
            for assignment in a.assignment:
                if "=" not in assignment:
                    raise EngineError(f"engine set: {assignment!r} is not key=value")
                key, raw = assignment.split("=", 1)
                pairs[key] = _parse_policy_value(key, raw)
            refusal = _reversal_mode_configure_refusal(a.engines_dir, a.engine_id, pairs)
            if refusal is not None:
                raise EngineError(f"engine set: {refusal}: {_reversal_reason_text(refusal)}")
            stored = engines_read(registry.path_for(a.engine_id), 8192).get("policy")
            if isinstance(stored, dict):
                refusal = _regime_clamp_refusal("engine set", {**stored, **pairs})
                if refusal is not None:
                    raise EngineError(refusal)
            overrides = AccountOverrides(a.account_overrides, registry)
            engine = registry.set_values(a.engine_id, pairs, validator=overrides.validate_engine)
            print(f"digest {policy_digest(engine.policy)}")
            print("hot: engine policy saved; selected readers apply it within 5 s")
            print(f"engine: {engine.engine_id} version {engine.version}")
        elif a.engine_cmd == "configure":
            return configure_engine(a)
        elif a.engine_cmd == "bind":
            bindings.bind(a.symbol, a.engine_id)
            print(f"bound {a.symbol}: {a.engine_id}")
        elif a.engine_cmd == "unbind":
            bindings.unbind(a.symbol)
            print(f"unbound {a.symbol}")
        elif a.engine_cmd == "book":
            before = bindings.is_enabled(a.symbol)
            after = a.state == "on"
            bindings.set_enabled(a.symbol, after)
            print(f"book_enabled: {before} -> {after}")
            print("hot: book entry setting saved; selected readers apply it within 5 s")
        return 0
    except (EngineError, PolicyError) as exc:
        print(str(exc))
        return 2
    except Exception:
        traceback.print_exc()
        return 3


def _print_receipt(r: dict) -> None:
    keys = ("stop_reason", "equity_start_usd", "equity_end_usd", "pnl_usd", "pnl_bps", "fees_usd", "slip_usd", "goal_reached", "counts", "latency", "ledger")
    print(json.dumps({k: r.get(k) for k in keys}, indent=2, default=str))


def cmd_hot_refresher(a: argparse.Namespace) -> int:
    """Owner-only, explicitly enabled account observation publisher."""
    from .hot_refresher_runtime import check_enabled, load_config, run

    try:
        check_enabled(a.account)
        config = load_config(Path(a.config))
        return asyncio.run(run(config))
    except (OSError, ValueError):
        print("hot-refresher: startup refused", file=sys.stderr, flush=True)
        return 2


def main(argv: list[str] | None = None) -> int:
    account_argv = sys.argv[1:] if argv is None else argv
    if account_argv and account_argv[0] == "account-lane":
        from .account_lane_agent import main as account_main
        return account_main(account_argv[1:])
    if os.environ.get("LEAFHFT_ACCOUNT_LANE_ID"):
        from .account_lane_agent import LanePaths, canonical_symbols, live_arguments, load_runtime
        try:
            lane_id = os.environ["LEAFHFT_ACCOUNT_LANE_ID"]
            paths = LanePaths(lane_id)
            # The outer allowlist must use the same root-approved account sizing as
            # validate_live_arguments().  Comparing against live_arguments() without
            # the signed config silently hard-coded the legacy $5 stake and rejected
            # every proportional account before the live gate could run.
            runtime_paths, config, _ = load_runtime(lane_id)
            if runtime_paths != paths or not any(
                    list(account_argv) == live_arguments(paths, symbol, config)
                    for symbol in canonical_symbols()):
                raise ValueError
        except Exception:
            print("Account runtime arguments refused.", file=sys.stderr)
            return 2
    p = argparse.ArgumentParser(prog="leafhft")
    sub = p.add_subparsers(dest="cmd", required=True)
    envelope = sub.add_parser("envelope", help="capture and check the owner account envelope (dark)")
    envelope_commands = envelope.add_subparsers(dest="envelope_cmd", required=True)
    envelope_capture = envelope_commands.add_parser("capture")
    envelope_capture.add_argument("--out", type=Path, default=Path("/etc/leafhft-deployments"))
    envelope_check = envelope_commands.add_parser("check")
    envelope_check.add_argument("--envelope", type=Path,
                                default=Path("/etc/leafhft-deployments/account-envelope.json"))
    envelope_check.add_argument("--json", action="store_true")
    envelope_commands.add_parser("show")
    hot = sub.add_parser("hot-refresher", help="owner account observations (disabled by default)")
    hot.add_argument("--account", required=True)
    hot.add_argument("--config", required=True, type=Path)
    canary_parser = sub.add_parser("canary", help="shadow, probe and account canary lifecycle; no broad live promotion")
    canary_parser.add_argument("--engines-dir", required=True)
    canary_parser.add_argument("--lifecycle-dir", default=None,
                               help="lifecycle store; default $LEAFHFT_LIFECYCLE_DIR, else <engines-dir>/lifecycle")
    canary_parser.add_argument("--engine-registry-dir", default="/var/lib/leafhft/engine-registry",
                               help="engine registry directory; an engine assigned to a tenant lane account is refused")
    canary_commands = canary_parser.add_subparsers(dest="canary_cmd", required=True)
    for action in ("register", "advance", "probe", "status", "halt"):
        command = canary_commands.add_parser(action)
        command.add_argument("engine_id")
        if action in ("register", "advance"):
            command.add_argument("--evidence", required=True)
        if action == "advance":
            command.add_argument("--eligibility", required=True)
        if action == "probe":
            command.add_argument("--account", required=True)
            command.add_argument("--authorization-ref", required=True)
            command.add_argument("--expires-at", required=True)
            command.add_argument("--other-account-bindings", nargs="+", action="extend", default=[])
        if action == "halt":
            command.add_argument("--reason", required=True)
    collector_parser = sub.add_parser("shadow-collect", help="collect shadow envelopes into a bounded local spool")
    collector_parser.add_argument("--socket", required=True)
    collector_parser.add_argument("--spool", required=True)
    collector_parser.add_argument("--max-spool-bytes", type=int, default=1024**3)
    collector_parser.add_argument("--min-free-gb", type=float, default=5)

    def common(sp: argparse.ArgumentParser, strategy: bool = True, extra_venues: tuple = ()) -> None:
        sp.add_argument("--venue", required=True, choices=("coinbase", "kraken", "binanceus") + extra_venues)
        sp.add_argument("--symbol", default="BTC-USD")
        if strategy:
            if sp.prog.endswith(" paper"):
                strategy_choices = ("mm", "momentum", "meanrev", "probe", "anchor_mm")
            elif sp.prog.endswith(" live"):
                strategy_choices = ("mm", "momentum", "meanrev", "probe", "kalshi_edge", "perp_breakout")
            else:
                strategy_choices = ("mm", "momentum", "meanrev", "probe")
            sp.add_argument("--strategy", required=True, choices=strategy_choices)
            sp.add_argument("--params", default="", help="JSON object of strategy params")
            if not sp.prog.endswith(" live"):
                sp.add_argument("--cash", default="100")
            sp.add_argument("--goal", default="1000")
            sp.add_argument("--latency-ms", type=int, default=350)
            sp.add_argument("--queue-model", default="queue", choices=("queue", "touch"))
            sp.add_argument("--haircut-bps", type=int, default=1)  # matches PaperModel default (astra r2 C9)
            sp.add_argument("--mark-ms", type=int, default=250, help="equity mark cadence written to the ledger (100 to 60000)")
            sp.add_argument("--snapshot-fills", action="store_true", help="allow capped fills on crossed L1 snapshots (optimistic)")
        sp.add_argument("--seconds", type=int, default=600)
        sp.add_argument("--runs", default="runs")
        sp.add_argument("--transport", default="auto", choices=("auto", "ws", "rest"))

    def paper_fuzz_options(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--paper-orders", help="offline Kalshi quote/order JSONL")
        sp.add_argument("--fuzz-seed", type=int, default=None)
        sp.add_argument("--fuzz-size-min-bps", type=int, default=None)
        sp.add_argument("--fuzz-size-max-bps", type=int, default=None)
        sp.add_argument("--fuzz-jitter-min-ms", type=int, default=None)
        sp.add_argument("--fuzz-jitter-max-ms", type=int, default=None)
        sp.add_argument("--fuzz-no-fill-bps", type=int, default=None)

    sp = sub.add_parser("paper")
    common(sp, extra_venues=("kalshi",))
    paper_fuzz_options(sp)
    sp.add_argument("--stale-ms", type=int, default=None, help="paper quote staleness limit (100 to 600000 ms)")
    sp.add_argument("--reference-venue", default="", choices=("coinbase",))
    sp = sub.add_parser("record")
    common(sp, strategy=False, extra_venues=("kalshi", "polymarket_us"))
    sp.add_argument("--idle-s", type=int, default=900, help="quiet period before reconnect (30 to 86400 seconds)")
    sp.add_argument("--max-reconnects", type=int, default=96, help="reconnect budget per recording (1 to 10000)")
    sp.add_argument("--shadow-socket", default=os.environ.get("LEAFHFT_SHADOW_SOCKET") or None,
                    help="kalshi: optional observation-only shadow collector socket")
    sp.add_argument("--demo", action="store_true", help="kalshi only: use the demo WS/REST endpoints")
    sp = sub.add_parser("replay")
    common(sp, extra_venues=("kalshi",))
    paper_fuzz_options(sp)
    sp.add_argument("--file", required=True)
    sp = sub.add_parser("goal")
    sp.add_argument("--cash", type=float, default=100.0)
    sp.add_argument("--goal", type=float, default=1000.0)
    sp = sub.add_parser("verify")
    sp.add_argument("--ledger", required=True)
    sp = sub.add_parser("perp-replay", help="replay the frozen perp_breakout rule and PerpSleeve over a Kalshi record dir")
    sp.add_argument("record_dir")
    sp.add_argument("--params", default="", help="JSON object of strategy params")
    sp.add_argument("--profile", default="kalshi-sleeve", choices=("kalshi-sleeve", "kalshi-sleeve-fast"),
                    help="sleeve params profile to reproduce (must match the live config)")
    sp = sub.add_parser("live")
    common(sp, extra_venues=("kalshi", "kalshi-perp", "polymarket_us"))
    sp.add_argument("--index-from", choices=("kalshi",), default="kalshi")
    sp.add_argument("--run-dir", required=True)
    sp.add_argument("--stake-usd", default="5.00")
    sp.add_argument("--limits-profile", default="s2c",
                    choices=("s2c", "aggressive", "kalshi-sleeve", "kalshi-sleeve-fast") + tuple(sorted(KALSHI_LIMITS_PROFILES)))
    sp.add_argument("--ack-dir", default=None)
    sp.add_argument("--adopt-inventory", action="store_true")
    sp.add_argument("--probe-order", action=argparse.BooleanOptionalAction, default=True)
    sp.add_argument("--alternate", default="", choices=("", "anchor_mm"), help="run --strategy and this one in timed blocks")
    sp.add_argument("--block-minutes", type=int, default=240, help="block length when --alternate is set (5 to 1440)")
    sp.add_argument("--reference-venue", default="", choices=("", "coinbase"))
    sp.add_argument("--policy", default=None, help="kalshi/polymarket_us: path to a hot-reloadable policy JSON file")
    sp.add_argument("--engines-dir", default="", help="kalshi: named engine directory")
    sp.add_argument("--engine-bindings", default="", help="kalshi: hot-reloadable engine bindings file")
    sp.add_argument("--engine-account-overrides", default="", help="kalshi: sparse per-account engine overrides")
    sp.add_argument("--dashboard-account-identity", default="", help="kalshi: verified dashboard account identity file")
    sp.add_argument("--execution-experiment", default="", help="kalshi: optional reduction-only execution experiment JSON")
    sp.add_argument("--authority-path", default="/var/lib/leafhft/kalshi-authority.json")
    sp.add_argument("--coordinated-mode", choices=("off", "shadow", "live"), default="off")
    sp.add_argument("--lane", action="append", default=[], metavar="PATH",
                    help="live lane document (repeatable, at most four)")
    sp.add_argument("--darkhorse-config", default="/etc/leafhft/darkhorse.json",
                    help="kalshi: optional Dark Horse live pilot configuration")
    sp.add_argument("--shadow-policy", default=None,
                    help="kalshi/polymarket_us: path to a second, fenced paper-shadow policy JSON file")
    sp.add_argument("--shadow-socket", default=os.environ.get("LEAFHFT_SHADOW_SOCKET") or None,
                    help="kalshi: optional shadow collector socket (outside the config digest)")
    sp.add_argument("--shadow-cash-usd", type=int, default=500,
                    help="paper shadow cash allocation in whole USD (1 to 500)")
    sp.add_argument("--probe-bindings", default="", metavar="PATH",
                    help="kalshi: probe engines per symbol; hosts ProbeExecutors beside this book "
                         "(default $LEAFHFT_PROBE_BINDINGS)")
    sp.add_argument("--engine-registry", default="", metavar="PATH",
                    help="kalshi: engine registry projection the probes gate on (default $LEAFHFT_ENGINE_REGISTRY)")
    sp.add_argument("--lifecycle-dir", default="", metavar="PATH",
                    help="kalshi: probe lifecycle store; default $LEAFHFT_LIFECYCLE_DIR, else <engines-dir>/lifecycle")
    sp.add_argument("--lifecycle-lease", default="", metavar="PATH",
                    help="kalshi, tenant books: the root-owned lane lifecycle lease every probe entry is gated "
                         "on (default $LEAFHFT_LIFECYCLE_LEASE); outside the config digest")
    sp.add_argument("--hot-observation-mode", choices=("off", "shadow", "use"), default="off",
                    help="kalshi owner ticker book: hot observation mode; off preserves config and digest")
    sp.add_argument("--classification-mode", choices=("legacy", "ticker"), default="legacy",
                    help="kalshi: exposure classification for the book and probe clients; ticker rotates "
                         "the config digest, legacy leaves it and config.json unchanged")
    sp.add_argument("--parity-mirror", action="store_true",
                    help="kalshi: mirror the incumbent through the KalshiEdgeEntry adapter and count "
                         "divergences; never orders (off keeps the config digest)")
    sp.add_argument("--executor-mode", action="store_true",
                    help="kalshi: hosted probes share the incumbent's one KalshiLive client as per-engine "
                         "sub-books; requires --parity-mirror (off keeps the config digest)")
    sp.add_argument("--book-tap", default="", metavar="ADDRESS",
                    help="kalshi: stream this book's tap to a local consumer socket and publish book_hops "
                         "(B8; outside the config digest; set by live-run.sh from kalshi-book-taps)")
    sp = sub.add_parser("live-reconcile", help="list/cancel this book's resting venue orders (lh- only) and show balances")
    sp.add_argument("--venue", required=True, choices=("coinbase", "kraken", "binanceus", "kalshi"))
    sp.add_argument("--symbol", default="BTC-USD")
    sp.add_argument("--journal-dir", default=None)
    sp.add_argument("--cancel", action="store_true")
    sp.add_argument("--settle", action="store_true", help="kalshi only: settle expired tickets from the market result")
    sp = sub.add_parser("signals", help="compute regime, pattern, walk-forward model and sentiment context into signals.json")
    sp.add_argument("--runs", default="runs")
    sp.add_argument("--run-dir", default="")
    sp.add_argument("--no-sentiment", action="store_true")
    sp = sub.add_parser("ui", help="local read-only dashboard over the runs directory (127.0.0.1)")
    sp.add_argument("--runs", default="runs")
    sp.add_argument("--port", type=int, default=8811)
    sp = sub.add_parser("push", help="push run receipts/marks/fills to the ops dashboard ingest API")
    sp.add_argument("--tenant-id", default=None, help="isolated dry-run manifest push, no controls")
    sp.add_argument("--url", required=True, help="dashboard base URL, e.g. https://ops-dashboard-seven.vercel.app")
    sp.add_argument("--runs", default="runs")
    sp.add_argument("--run-dir", default="", help="push one run (with --watch: keep pushing deltas while it runs)")
    sp.add_argument("--watch", action="store_true")
    sp.add_argument("--every", type=float, default=5.0)
    sp.add_argument("--token-env", default="LEAFHFT_DASHBOARD_TOKEN", help="env var holding the bearer token (never passed on argv)")
    sp = sub.add_parser("policy", help="show/validate/set/promote the hot-reloadable Kalshi policy file")
    policy_sub = sp.add_subparsers(dest="policy_cmd", required=True)
    sp2 = policy_sub.add_parser("show")
    sp2.add_argument("--path", default=_policy_default_path())
    sp2 = policy_sub.add_parser("validate")
    sp2.add_argument("--path", default=_policy_default_path())
    sp2 = policy_sub.add_parser("set")
    sp2.add_argument("assignment", nargs="+", metavar="key=value")
    sp2.add_argument("--path", default=_policy_default_path())
    sp2.add_argument("--dry-run", action="store_true")
    sp2.add_argument("--runs", default=_policy_runs_default_path(), help="live run directories root, for the write preflight")
    sp2.add_argument("--force", action="store_true", help="waive the live-reader preflight refusal")
    sp2.add_argument("--no-uptake", action="store_true", help="skip post-write policy uptake read-back")
    sp2.add_argument("--uptake-wait", type=_uptake_wait_arg, default=6.0, metavar="SECONDS")

    sp2 = policy_sub.add_parser("promote", help="promote one READY shadow policy value")
    sp2.add_argument("key")
    sp2.add_argument("--from", dest="from_path", required=True)
    sp2.add_argument("--to", dest="to_path", default=_policy_default_path())
    sp2.add_argument("--require-ready", metavar="PATH", help="learning report with READY promotion evidence (required)")
    sp2.add_argument("--runs", default=_policy_runs_default_path(), help="live run directories root, for the write preflight")
    sp2.add_argument("--force", action="store_true", help="waive the live-reader preflight refusal")
    sp2.add_argument("--no-uptake", action="store_true", help="skip post-write policy uptake read-back")
    sp2.add_argument("--uptake-wait", type=_uptake_wait_arg, default=6.0, metavar="SECONDS")

    sp = sub.add_parser("deployed", help="read deployed code identity and live book status")
    sp.add_argument("--runs-root", default=_policy_runs_default_path())
    sp.add_argument("--live-units", action="store_true")
    sp.add_argument("--json", action="store_true")

    sp = sub.add_parser("authority", help="manage the Kalshi account authority")
    authority_sub = sp.add_subparsers(dest="authority_cmd", required=True)
    sp2 = authority_sub.add_parser("init")
    sp2.add_argument("--generation", required=True)
    sp2.add_argument("--require-flat", action="store_true")
    sp2.add_argument("--authority-path", default="/var/lib/leafhft/kalshi-authority.json")
    sp2 = authority_sub.add_parser("unlatch")
    sp2.add_argument("lane")
    sp2.add_argument("--authority-path", default="/var/lib/leafhft/kalshi-authority.json")
    sp2.add_argument("--reset-daily-loss", action="store_true")
    sp2.add_argument("--force", action="store_true")

    sp2 = authority_sub.add_parser("caps")
    sp2.add_argument("lane")
    sp2.add_argument("--allow-unlimited", action="store_true")
    sp2.add_argument("--authority-path", default="/var/lib/leafhft/kalshi-authority.json")
    sp2.add_argument("assignment", nargs="*", metavar="key=value")

    sp = sub.add_parser("engine", help="manage named Kalshi engine policies and bindings")
    sp.add_argument("--engines-dir", default="/etc/leafhft/engines")
    sp.add_argument("--bindings", default="/etc/leafhft/kalshi-engine-bindings.json")
    engine_sub = sp.add_subparsers(dest="engine_cmd", required=True)
    for command in ("list", "show", "validate", "create", "set", "configure", "bind", "unbind", "book"):
        sp2 = engine_sub.add_parser(command)
        sp2.add_argument("--engines-dir", default=argparse.SUPPRESS)
        sp2.add_argument("--bindings", default=argparse.SUPPRESS)
        if command in ("bind", "unbind", "book"):
            sp2.add_argument("symbol")
        if command in ("show", "create", "set", "configure", "bind"):
            sp2.add_argument("engine_id")
        if command == "create":
            sp2.add_argument("--name", required=True)
            sp2.add_argument("--description", default="")
            source = sp2.add_mutually_exclusive_group()
            source.add_argument("--from", dest="from_engine")
            source.add_argument("--from-policy", default=_policy_default_path())
        if command == "set":
            sp2.add_argument("assignment", nargs="+", metavar="key=value")
            sp2.add_argument("--account-overrides", default="/etc/leafhft/kalshi-engine-account-overrides.json")
        if command == "configure":
            sp2.add_argument("--expected-revision", required=True)
            sp2.add_argument("--provenance-json", help="Override provenance JSON object (at most 2 KiB)")
            sp2.add_argument("--account-id")
            sp2.add_argument("--account-overrides", default="/etc/leafhft/kalshi-engine-account-overrides.json")
            sp2.add_argument("--enabled", choices=("true", "false", "inherit"))
            sp2.add_argument("--set", dest="set_values", action="append", default=[], metavar="key=value")
            sp2.add_argument("--unset", action="append", default=[], metavar="key")
        if command == "book":
            sp2.add_argument("state", choices=("on", "off"))

    a, extra = p.parse_known_args(argv)
    if extra:
        if (a.cmd == "authority" and a.authority_cmd == "caps"
                and all("=" in value and not value.startswith("-") for value in extra)):
            a.assignment.extend(extra)
        else:
            p.error("unrecognized arguments: " + " ".join(extra))
    if a.cmd in ("paper", "replay"):
        fuzz_bounds = (a.fuzz_size_min_bps, a.fuzz_size_max_bps, a.fuzz_jitter_min_ms,
                       a.fuzz_jitter_max_ms, a.fuzz_no_fill_bps)
        if any(value is not None for value in fuzz_bounds) and a.fuzz_seed is None:
            p.error("fuzz bounds require --fuzz-seed")
        if (a.fuzz_seed is not None or a.paper_orders) and a.venue != "kalshi":
            p.error("paper order fuzzing requires --venue kalshi")
    if a.cmd == "envelope":
        from .account_envelope import cmd_envelope

        return cmd_envelope(a)
    if a.cmd == "authority":
        return cmd_authority(a)
    if a.cmd == "hot-refresher":
        return cmd_hot_refresher(a)
    if a.cmd == "deployed":
        from .deployed import cmd_deployed

        return cmd_deployed(a)
    if a.cmd == "engine":
        return cmd_engine(a)
    if a.cmd == "canary":
        return cmd_canary(a)
    if a.cmd == "paper":
        if a.reference_venue and a.strategy != "anchor_mm":
            p.error("--reference-venue requires --strategy anchor_mm")
        if a.strategy == "anchor_mm" and (a.reference_venue != "coinbase" or a.venue != "binanceus"):
            p.error("anchor_mm requires --venue binanceus --reference-venue coinbase")
    if a.cmd == "paper" and a.stale_ms is not None:
        try:
            RiskLimits(stale_feed_ms=a.stale_ms)
        except ValueError as exc:
            p.error(f"--stale-ms: {exc}")
    if a.cmd == "live":
        if a.venue == "kalshi":
            from .feeds.kalshi import SYMBOL_MAP as _kalshi_symbol_map

            kalshi_symbol_choices = sorted(_kalshi_symbol_map)
            if a.strategy != "kalshi_edge":
                p.error("--venue kalshi requires --strategy kalshi_edge")
            if a.symbol not in kalshi_symbol_choices:
                p.error(f"--venue kalshi requires --symbol one of {', '.join(kalshi_symbol_choices)}")
        elif a.venue == "polymarket_us":
            from .feeds.polymarket_us import LIVE_SYMBOL_MAP

            if a.strategy != "kalshi_edge":
                p.error("--venue polymarket_us requires --strategy kalshi_edge")
            if a.symbol not in LIVE_SYMBOL_MAP:
                p.error(f"--venue polymarket_us requires --symbol one of {', '.join(sorted(LIVE_SYMBOL_MAP))}")
        elif a.venue == "kalshi-perp":
            if a.strategy != "perp_breakout":
                p.error("--venue kalshi-perp requires --strategy perp_breakout")
            if a.symbol != "BTC-PERP":
                p.error("--venue kalshi-perp requires --symbol BTC-PERP")
        elif a.strategy == "kalshi_edge":
            p.error("--strategy kalshi_edge requires --venue kalshi")
        elif a.strategy == "perp_breakout":
            p.error("--strategy perp_breakout requires --venue kalshi-perp")
        if a.lifecycle_lease:
            if a.venue != "kalshi" or len(a.lifecycle_lease) > 4096:
                p.error("--lifecycle-lease requires --venue kalshi and a path of at most 4096 characters")
            # S7 A L4: _kalshi_probe_host reads it from the environment, like $LEAFHFT_LIFECYCLE_DIR,
            # because neither the config digest nor the pinned driver carries a field for it.
            os.environ["LEAFHFT_LIFECYCLE_LEASE"] = a.lifecycle_lease
        if getattr(a, "shadow_policy", None):
            if a.venue not in ("kalshi", "polymarket_us"):
                p.error("--shadow-policy requires --venue kalshi or polymarket_us")
            if not (1 <= a.shadow_cash_usd <= 500):
                p.error("--shadow-cash-usd must be between 1 and 500")
        if a.reference_venue and not a.alternate:
            p.error("--reference-venue requires --alternate anchor_mm")
        if a.alternate:
            if a.reference_venue != "coinbase":
                p.error("--alternate anchor_mm requires --reference-venue coinbase")
            if a.venue != "binanceus":
                p.error("--alternate anchor_mm requires --venue binanceus")
            if not (5 <= a.block_minutes <= 1440):
                p.error("--block-minutes must be between 5 and 1440")
    if a.cmd == "record":
        if a.venue == "polymarket_us":
            from .feeds.polymarket_us import SYMBOL_MAP as polymarket_symbol_map

            if a.symbol not in polymarket_symbol_map:
                p.error(f"--venue polymarket_us requires --symbol one of {', '.join(sorted(polymarket_symbol_map))}")
        if not 30 <= a.idle_s <= 86400:
            p.error("--idle-s must be between 30 and 86400")
        if not 1 <= a.max_reconnects <= 10000:
            p.error("--max-reconnects must be between 1 and 10000")
    return {"shadow-collect": cmd_shadow_collect, "paper": cmd_paper, "record": cmd_record, "replay": cmd_replay, "goal": cmd_goal, "verify": cmd_verify, "live": cmd_live, "live-reconcile": cmd_live_reconcile, "ui": cmd_ui, "push": cmd_push, "signals": cmd_signals, "perp-replay": cmd_perp_replay, "policy": cmd_policy}[a.cmd](a)


if __name__ == "__main__":
    raise SystemExit(main())
