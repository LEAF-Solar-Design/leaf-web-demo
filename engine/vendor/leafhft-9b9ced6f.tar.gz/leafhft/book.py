"""Top-of-book state plus a bounded trade tape and rolling features for strategies.

Hot path contract: update() is O(1) and bounded (fixed rings, small scalars only); it never
touches disk or the network. Events for another venue/symbol raise; a stale or duplicated
sequence number is dropped and counted (fail closed, never corrupt the history).

Numerics: rings store values as offsets from an anchor fixed at the first sample, so running
sum/sumsq of BTC mids (~8e12 price units) do not cancel catastrophically. A $1 move is 1e8
units; squared 1e16, summed over 256 samples ~1e19, well inside float64's exact range for
the small-move variances that matter (verified against a two-pass numpy std in tests).
"""
from __future__ import annotations

import math

import numpy as np

from .types import MalformedInput, Quote, Side, Trade, bps_of

NEVER = 2**62  # staleness sentinel for a book that has never seen a quote


class Ring:
    """Fixed-capacity float ring with O(1) push and O(1) mean/std via anchored running sums."""

    __slots__ = ("cap", "buf", "n", "head", "sum", "sumsq", "anchor", "anchored")

    def __init__(self, cap: int) -> None:
        if cap <= 0 or cap > 1_000_000:
            raise ValueError("ring cap out of range")
        self.cap = cap
        self.buf = np.zeros(cap, dtype=np.float64)
        self.n = 0
        self.head = 0
        self.sum = 0.0
        self.sumsq = 0.0
        self.anchor = 0.0
        self.anchored = False

    def push(self, x: float) -> None:
        if x != x or x in (math.inf, -math.inf):
            raise MalformedInput("non-finite sample")
        if not self.anchored:
            self.anchor = x
            self.anchored = True
        x -= self.anchor
        if self.n == self.cap:
            old = float(self.buf[self.head])
            self.sum -= old
            self.sumsq -= old * old
        else:
            self.n += 1
        self.buf[self.head] = x
        self.head = (self.head + 1) % self.cap
        self.sum += x
        self.sumsq += x * x

    @property
    def full(self) -> bool:
        return self.n == self.cap

    def mean(self) -> float:
        return 0.0 if self.n == 0 else self.sum / self.n + self.anchor

    def std(self) -> float:
        if self.n < 2:
            return 0.0
        m = self.sum / self.n
        v = self.sumsq / self.n - m * m
        if v <= 0.0:
            # cancellation guard: exact two-pass over the bounded window
            a = self.buf[: self.n]
            v = float(a.var())
        return math.sqrt(v) if v > 0 else 0.0

    def last(self) -> float:
        return 0.0 if self.n == 0 else float(self.buf[(self.head - 1) % self.cap]) + self.anchor

    def first(self) -> float:
        if self.n == 0:
            return 0.0
        idx = (self.head - self.n) % self.cap
        return float(self.buf[idx]) + self.anchor

    def total(self) -> float:
        """Sum of raw samples (only meaningful for rings whose anchor is 0, e.g. volumes)."""
        return self.sum + self.anchor * self.n


class Book:
    """L1 book + trade tape + rolling features. One instance per (venue, symbol)."""

    __slots__ = (
        "venue",
        "symbol",
        "quote",
        "last_trade",
        "n_quotes",
        "n_trades",
        "dropped_seq",
        "last_seq",
        "mid_ring",
        "ret_ring",
        "imb_ring",
        "spread_ring",
        "buy_vol_ring",
        "sell_vol_ring",
        "trade_px_ring",
        "_last_mid",
        "ts_quote_ns",
        "ts_trade_ns",
    )

    def __init__(self, venue: str, symbol: str, window: int = 256) -> None:
        if not venue or not symbol:
            raise ValueError("venue/symbol required")
        self.venue = venue
        self.symbol = symbol
        self.quote: Quote | None = None
        self.last_trade: Trade | None = None
        self.n_quotes = 0
        self.n_trades = 0
        self.dropped_seq = 0
        self.last_seq = 0
        self.mid_ring = Ring(window)
        self.ret_ring = Ring(window)
        self.imb_ring = Ring(window)
        self.spread_ring = Ring(window)
        self.buy_vol_ring = Ring(window)
        self.sell_vol_ring = Ring(window)
        self.trade_px_ring = Ring(window)
        self._last_mid = 0.0
        self.ts_quote_ns = 0
        self.ts_trade_ns = 0
        # volume rings must not anchor (their sum is the feature)
        for r in (self.buy_vol_ring, self.sell_vol_ring):
            r.anchored = True

    # ---- updates -------------------------------------------------------
    def _admit(self, venue: str, symbol: str, seq: int) -> bool:
        if venue != self.venue or symbol != self.symbol:
            raise MalformedInput(f"event for {venue}/{symbol} on book {self.venue}/{self.symbol}")
        if seq <= self.last_seq:
            self.dropped_seq += 1
            return False
        self.last_seq = seq
        return True

    def on_quote(self, q: Quote) -> bool:
        if not self._admit(q.venue, q.symbol, q.seq):
            return False
        self.quote = q
        self.n_quotes += 1
        self.ts_quote_ns = q.ts_recv_ns
        mid = float(q.mid_i)
        if self._last_mid > 0.0:
            self.ret_ring.push((mid - self._last_mid) / self._last_mid)
        self._last_mid = mid
        self.mid_ring.push(mid)
        self.imb_ring.push(q.imbalance)
        self.spread_ring.push(q.spread_bps)
        return True

    def on_trade(self, t: Trade) -> bool:
        if not self._admit(t.venue, t.symbol, t.seq):
            return False
        self.last_trade = t
        self.n_trades += 1
        self.ts_trade_ns = t.ts_recv_ns
        self.trade_px_ring.push(float(t.price_i))
        if t.side is Side.BUY:
            self.buy_vol_ring.push(float(t.size_i))
            self.sell_vol_ring.push(0.0)
        else:
            self.buy_vol_ring.push(0.0)
            self.sell_vol_ring.push(float(t.size_i))
        return True

    # ---- features ------------------------------------------------------
    @property
    def ready(self) -> bool:
        return self.quote is not None and self.mid_ring.n >= 8

    def mid_i(self) -> int:
        return 0 if self.quote is None else self.quote.mid_i

    def spread_bps(self) -> float:
        return 0.0 if self.quote is None else self.quote.spread_bps

    def avg_spread_bps(self) -> float:
        return self.spread_ring.mean()

    def momentum_bps(self) -> float:
        """Mid change over the whole ring window, in bps of the first mid."""
        f = self.mid_ring.first()
        return 0.0 if f == 0.0 else bps_of(int(self.mid_ring.last() - f), int(f))

    def zscore(self) -> float:
        """Where the current mid sits versus the window mean, in window std units."""
        sd = self.mid_ring.std()
        return 0.0 if sd == 0.0 else (self.mid_ring.last() - self.mid_ring.mean()) / sd

    def vol_bps(self) -> float:
        """Per-update return std in bps; the size of a typical mid move."""
        return self.ret_ring.std() * 10_000.0

    def imbalance(self) -> float:
        return self.imb_ring.mean()

    def flow_imbalance(self) -> float:
        """(buy - sell) / (buy + sell) traded volume over the tape window."""
        b, s = self.buy_vol_ring.total(), self.sell_vol_ring.total()
        tot = b + s
        return 0.0 if tot <= 0.0 else (b - s) / tot

    def stale_ns(self, now_ns: int) -> int:
        """Age of the QUOTE (the thing orders are priced off). NEVER when no quote has arrived."""
        if self.ts_quote_ns == 0:
            return NEVER
        return max(0, now_ns - self.ts_quote_ns)

    def trade_stale_ns(self, now_ns: int) -> int:
        if self.ts_trade_ns == 0:
            return NEVER
        return max(0, now_ns - self.ts_trade_ns)
