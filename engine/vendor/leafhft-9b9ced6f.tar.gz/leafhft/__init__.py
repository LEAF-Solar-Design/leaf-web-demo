"""leafhft: hardened, paper-first high-frequency crypto trading engine.

Contract for every module in this package:
  * every input is validated and the code fails closed on anything malformed;
  * every queue, buffer, cache and retry is bounded;
  * every I/O call carries a timeout;
  * the tick hot path (feed -> book -> strategy -> risk -> broker) allocates
    only small fixed-size objects and never touches disk or the network.
"""

__version__ = "0.1.0"

ENGINE_CATALOG_CAPACITY = 1024
ENGINE_CATALOG_MAX_ENTRIES = 4096
