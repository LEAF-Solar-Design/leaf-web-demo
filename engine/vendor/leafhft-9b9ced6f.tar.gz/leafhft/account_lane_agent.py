"""Kashbot account execution lanes over the shared Kalshi engine.

The root agent consumes root-owned queue/<lane>/<request UUID>.json files.
The dashboard adapter must authenticate the bound device before staging work;
host labels are never accepted in this protocol. Each command carries version,
id, sequence, tenant_id, lane_id, venue, subaccount, action and expires_at
(Unix seconds). Sequence is a strictly increasing integer within the lane.
Enrollment adds envelope; start adds approved=true. No caller supplies paths.

Envelope v1: RSA-OAEP-SHA256 wraps a 32-byte AES key; AES-256-GCM encrypts
UTF-8 JSON {key_id, private_key_pem}. Standard base64 fields are wrapped_key,
nonce (12 bytes), ciphertext (including tag). AAD is the canonical JSON scope
returned by envelope_aad. The enrollment private key never leaves the runner.
"""
from __future__ import annotations

import argparse
import base64
from contextlib import contextmanager, redirect_stderr
from dataclasses import dataclass
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import signal
import stat
import subprocess
import sys
import tempfile
import time
import uuid

try:
    import grp
    import pwd
except ImportError:  # POSIX only
    grp = None
    pwd = None

from . import probe_bindings as _probe_bindings
from .private_dir import ensure_private_dir

VERSION = 1
ALGORITHM = "RSA-OAEP-256+A256GCM"
UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}")
CONFIG_ROOT = Path("/etc/leafhft-accounts")
STATE_ROOT = Path("/var/lib/leafhft-accounts")
RUN_ROOT = Path("/run/leafhft-accounts")
AGENT_ROOT = Path("/var/lib/leafhft-account-agent")
OWNER_LANES_PATH = Path("/etc/leafhft-account-agent/owner-lanes.json")
OWNER_LANES_MAX = 65536
# The root provisioner owns every lane's registry projection (C14-A): a root-owned tree OUTSIDE
# every lane root, <root>/<lane>/engine-registry/projection.json (0444). leafhft-account@ and
# leafhft-account-push@ need it readable: ProtectSystem=strict leaves it visible read-only and no
# InaccessiblePaths entry covers it. The provision unit needs it in ReadWritePaths to write it.
# Lane directories are 0750 root:lane-group; the root and engine-registry levels stay 0755.
PROJECTION_ROOT = Path("/var/lib/leafhft-projections")
PROJECTION_OWNER = 0
# The replay floor, <root>/<lane>/floor.json (0444): written by the root provisioner on every publish,
# only ever read here, so a tenant cannot delete or lower it from its own lane root.
PROJECTION_FLOOR_FILE = "floor.json"
PROJECTION_FLOOR_MAX = 256  # bytes; the canonical floor document is under 80
# lane_id -> RegistryProjection; bounded by the 256-lane binding cap.
_PROJECTION_READERS = {}
# lane_id -> sha256 of the projection bytes its cached reader was built against. The reader's
# (mtime, inode, size) key cannot see a same-size copy put back in the same timestamp tick on a
# filesystem that reuses the inode (Linux CI did exactly that), so a changed digest rebuilds it.
_PROJECTION_FINGERPRINTS = {}
# lane_id -> ((path, st_mtime_ns, st_ino, st_size), probe_bindings_status result), bounded at 256 lanes.
_BINDINGS_STATUS = {}
PYTHON = "/opt/leafhft/.venv/bin/python"
SYMBOLS = ("BTC-15M", "ETH-15M", "BTC-1H", "ETH-1H", "BNB-15M",
           "DOGE-15M", "HYPE-15M", "NEAR-15M", "SOL-15M", "XRP-15M",
           "ZEC-15M", "BNB-1H", "HYPE-1H", "XRP-1H")
# EX_TEMPFAIL on a clean full-window end: the only exit systemd restarts; every other exit keeps the lane down.
WINDOW_RENEW_EXIT = 75
WINDOW_RENEW_MIN_S = 86400 - 600
WINDOW_RENEW_GRACE_S = 300  # books share one window; stragglers past this fail closed


class LaneRefused(ValueError):
    """Only static messages may cross the agent boundary."""


def identifier(value):
    if not isinstance(value, str) or not UUID.fullmatch(value):
        raise LaneRefused("invalid account scope")
    return value


def account_user(lane_id):
    # Keep below useradd's 32-character limit; the home check rejects collisions.
    return "leafacct-" + hashlib.sha256(identifier(lane_id).encode()).hexdigest()[:20]


def lane_gid(lane_id):
    """Resolve the lane's own group; never fall back to a shared group."""
    if pwd is None or grp is None:
        raise LaneRefused("lane_user_unresolved")
    try:
        name = account_user(lane_id)
        gid = pwd.getpwnam(name).pw_gid
        if grp.getgrgid(gid).gr_name != name:
            raise LaneRefused("lane_user_unresolved")
        return gid
    except (ImportError, KeyError, OSError):
        raise LaneRefused("lane_user_unresolved") from None


def lane_dir_mode_ok(info, lane_id):
    """Accept private, legacy, and the chown-before-chmod migration state."""
    if info.st_uid != 0:
        return False
    mode = stat.S_IMODE(info.st_mode)
    if mode == 0o755 and info.st_gid == 0:
        return True
    if mode not in (0o750, 0o755):
        return False
    try:
        return info.st_gid == lane_gid(lane_id)
    except LaneRefused:
        return False


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise LaneRefused("duplicate field")
        result[key] = value
    return result


def parse(data):
    try:
        if len(data) > 65536:
            raise ValueError
        return json.loads(data, object_pairs_hook=_pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except Exception:
        raise LaneRefused("invalid document") from None


def safe_path(path):
    path = Path(path)
    if not path.is_absolute() or ".." in path.parts:
        raise LaneRefused("invalid path")
    for part in (path, *path.parents):
        if part.is_symlink():
            raise LaneRefused("unsafe path")
    return path


@contextmanager
def private_parent(path):
    """Pin every directory before root accesses a lane-owned child path."""
    path = safe_path(path)
    if os.name != "posix":
        yield None
        return
    parts = path.parts[1:-1]
    path_only = getattr(os, "O_PATH", os.O_RDONLY)
    fd = os.open(path.anchor, (os.O_RDONLY if not parts else path_only) | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for index, part in enumerate(parts):
            # Execute-only shared parents prevent account enumeration. Pin
            # ancestors with O_PATH, then open only the account-owned final
            # parent for read so fsync remains available to atomic writers.
            mode = os.O_RDONLY if index == len(parts) - 1 else path_only
            child = os.open(part, mode | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        yield fd
    finally:
        os.close(fd)


def read_private(path, *, owner=0):
    path = safe_path(path)
    with private_parent(path) as parent:
        fd = os.open(path.name if parent is not None else path,
                     os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0),
                     dir_fd=parent)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 65536
                or (os.name == "posix" and (info.st_uid != owner or stat.S_IMODE(info.st_mode) != 0o600))):
            raise LaneRefused("unsafe private file")
        return stream.read(65537)


def _owner_marker_mode_ok(st_uid, mode):
    return st_uid == 0 and mode & 0o022 == 0 and mode & 0o004 != 0


def _owner_parent_mode_ok(st_uid, mode):
    return st_uid == 0 and mode & 0o022 == 0


def owner_lanes():
    """Read the root parking policy; only an absent file means no parked lanes."""
    try:
        # Probe absence before path validation: on Windows the default /etc
        # path is drive-relative and safe_path rejects it even when absent.
        path = Path(OWNER_LANES_PATH)
        path.lstat()
        path = safe_path(path)
        with private_parent(path) as parent:
            if os.name == "posix" and parent is not None:
                parent_info = os.fstat(parent)
                if not _owner_parent_mode_ok(parent_info.st_uid, parent_info.st_mode):
                    raise LaneRefused("owner_lanes_invalid")
            fd = os.open(path.name if parent is not None else path,
                         os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0),
                         dir_fd=parent)
        with os.fdopen(fd, "rb") as stream:
            info = os.fstat(stream.fileno())
            if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > OWNER_LANES_MAX
                    or (os.name == "posix" and not _owner_marker_mode_ok(info.st_uid, info.st_mode))):
                raise LaneRefused("owner_lanes_invalid")
            doc = parse(stream.read(OWNER_LANES_MAX + 1))
        if (type(doc) is not dict or set(doc) != {"schema", "lanes"}
                or type(doc["schema"]) is not int or doc["schema"] != 1 or type(doc["lanes"]) is not list):
            raise LaneRefused("owner_lanes_invalid")
        lanes = [identifier(value) for value in doc["lanes"]]
        if len(set(lanes)) != len(lanes):
            raise LaneRefused("owner_lanes_invalid")
        return set(lanes)
    except (FileNotFoundError, NotADirectoryError):
        # Includes missing ancestors and disappearance before the open.
        return set()
    except (OSError, ValueError):
        raise LaneRefused("owner_lanes_invalid") from None


def refuse_if_parked_in_unit(lane_id):
    """Tenant processes ignore invalid policy; root enforces the last good set."""
    identifier(lane_id)
    try:
        parked = owner_lanes()
    except LaneRefused:
        return
    if lane_id in parked:
        raise LaneRefused("owner_lane_parked")


def _owner_lanes_lkg():
    try:
        doc = parse(read_private(AGENT_ROOT / "owner-lanes-lkg.json"))
        if (type(doc) is not dict or set(doc) != {"schema", "lanes", "updated_at"}
                or type(doc["schema"]) is not int or doc["schema"] != 1
                or type(doc["updated_at"]) is not int or type(doc["lanes"]) is not list):
            return set()
        lanes = [identifier(value) for value in doc["lanes"]]
        return set(lanes) if len(set(lanes)) == len(lanes) else set()
    except Exception:
        return set()


def _owner_lanes_alarm(parked):
    """Best-effort root-only page, deduplicated by the bad marker's identity."""
    try:
        try:
            info = Path(OWNER_LANES_PATH).lstat()
            identity = canonical([info.st_ino, info.st_mtime_ns, info.st_size,
                                  info.st_mode, info.st_uid])
        except OSError as error:
            identity = ("unreadable:" + str(error.errno)).encode()
        key = "owner-lanes-invalid:" + hashlib.sha256(identity).hexdigest()
        path = AGENT_ROOT / "owner-lanes-refusal.json"
        now = int(time.time())
        previous = {}
        try:
            previous = parse(read_private(path))
            if type(previous) is not dict:
                previous = {}
        except (OSError, ValueError):
            pass
        same = previous.get("key") == key
        notified = same and previous.get("notified") is True
        attempted = previous.get("attempted_at") if same else None
        if notified or (type(attempted) is int and now - attempted < 300):
            return
        alarm = {"reason": "owner_lanes_invalid", "key": key,
                 "enforcing": sorted(parked), "notified": False,
                 "attempted_at": now, "updated_at": now}
        # Save the attempt before invoking the rail, including when it times out.
        write_private(path, alarm)
        env = {"PATH": "/usr/bin:/bin"}
        for name in ("TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID"):
            if name in os.environ:
                env[name] = os.environ[name]
        result = subprocess.run(
            [sys.executable, str(Path(__file__).resolve().parents[1] / "scripts" / "runner_notify.py"),
             "--event", "owner_lanes_invalid", "--dedupe-key", key, "--level", "urgent",
             "--text", f"Invalid owner-lane marker {OWNER_LANES_PATH}; enforcing {len(parked)} last-known-good lanes."],
            timeout=20, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, env=env)
        alarm["notified"] = result.returncode in (0, 4)
        alarm["updated_at"] = int(time.time())
        write_private(path, alarm)
    except Exception:
        pass


def root_parked_lanes(*, persist=False):
    previous = _owner_lanes_lkg()
    try:
        parked = owner_lanes()
    except LaneRefused:
        if persist:
            _owner_lanes_alarm(previous)
        return previous
    if persist:
        try:
            path = AGENT_ROOT / "owner-lanes-lkg.json"
            if parked != previous:
                write_private(path, {"schema": 1, "lanes": sorted(parked),
                                     "updated_at": int(time.time())})
            alarm = AGENT_ROOT / "owner-lanes-refusal.json"
            if alarm.exists():
                alarm.unlink(missing_ok=True)
        except Exception:
            pass
    return parked


def root_lane_parked(lane_id):
    identifier(lane_id)
    return lane_id in root_parked_lanes()


def record_owner_lane_refusal(lane_id, reason):
    # Root diagnostics must not create root-owned children in a tenant's state.
    try:
        directory = safe_path(AGENT_ROOT / "refusals")
        ensure_private_dir(directory, owner=0, refusal=LaneRefused("unsafe agent root"),
                           enforce=os.name == "posix")
        path = directory / (identifier(lane_id) + ".json")
        try:
            if parse(read_private(path)).get("reason") == reason:
                return
        except FileNotFoundError:
            pass
        write_private(path, {"lane_id": lane_id, "reason": reason, "updated_at": int(time.time())})
    except Exception:
        pass


def require_lane_unparked(lane_id):
    if root_lane_parked(lane_id):
        record_owner_lane_refusal(lane_id, "owner_lane_parked")
        raise LaneRefused("owner_lane_parked")


def write_private(path, value):
    path = safe_path(path)
    if os.name == "posix":
        with private_parent(path) as parent:
            name = ".lane-" + secrets.token_hex(16)
            fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o600, dir_fd=parent)
            try:
                with os.fdopen(fd, "wb") as stream:
                    os.fchmod(stream.fileno(), 0o600)
                    stream.write(value if isinstance(value, bytes) else canonical(value))
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(name, path.name, src_dir_fd=parent, dst_dir_fd=parent)
                os.fsync(parent)
            finally:
                try:
                    os.unlink(name, dir_fd=parent)
                except FileNotFoundError:
                    pass
        return
    fd, name = tempfile.mkstemp(prefix=".lane-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            os.fchmod(stream.fileno(), 0o600) if os.name == "posix" else None
            stream.write(value if isinstance(value, bytes) else canonical(value))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


@contextmanager
def exclusive(path):
    import fcntl
    fd = os.open(safe_path(path), os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally:
        os.close(fd)


@dataclass(frozen=True)
class LanePaths:
    lane_id: str

    def __post_init__(self):
        identifier(self.lane_id)

    @property
    def config(self):
        return safe_path(CONFIG_ROOT / self.lane_id)

    @property
    def state(self):
        return safe_path(STATE_ROOT / self.lane_id)

    @property
    def runtime(self):
        return safe_path(RUN_ROOT / self.lane_id)

    @property
    def unit(self):
        return "leafhft-account@" + self.lane_id + ".service"


class _RefusalStderr:
    """Forward stderr unchanged, retaining at most 8 KiB of line evidence."""

    def __init__(self, stream):
        self.stream = stream
        self.pending = b""
        self._pending_end = 0
        self.retained = b""
        self.recorded = None
        self.recorded_reason = None
        self.recorded_possible_credential = False
        self.line_open = False
        self.possible_credential = False
        self._scan_tail = ""

    @property
    def last_line(self):
        return self.retained.split(b"\n")[-1]

    def __getattr__(self, name):
        return getattr(self.stream, name)

    def write(self, text):
        result = self.stream.write(text)
        if text:
            self.line_open = not text.endswith(("\n", "\r"))
        # Diagnostics must never change the action's output or exit behavior.
        try:
            scanned = self._scan_tail + text
            self.possible_credential |= _credential_indicator(scanned)
            self._scan_tail = scanned[-64:]
            for part in text.splitlines(keepends=True):
                ended = part.endswith(("\n", "\r"))
                part = part.rstrip("\r\n") if ended else part
                if not self.pending:
                    part = part.lstrip()
                prefix = self.pending.decode("utf-8", errors="replace")
                # Keep the first 300 characters, but track the last non-space
                # even beyond that prefix so trimming precedes the size bound.
                if part.rstrip():
                    self._pending_end = min(300, len(prefix) + len(part.rstrip()))
                self.pending = (prefix + part)[:300].encode("utf-8", errors="replace")
                if ended:
                    if self.pending:
                        self.retained = self.pending.decode("utf-8", errors="replace")[:self._pending_end].encode("utf-8")
                    self.pending = b""
                    self._pending_end = 0
        except Exception:
            pass
        return result

    def reason(self):
        if self.pending:
            return self.pending.decode("utf-8", errors="replace")[:self._pending_end]
        return self.last_line.decode("utf-8", errors="replace")


def _credential_indicator(text):
    if re.search(r"-----\s*(?:BEGIN|END)\b", text, flags=re.IGNORECASE):
        return True
    if re.search(
        r"\b(?:token|bearer|secret|password|passwd|api_key|apikey|authorization|private_key|key|key_id|private_key_pem)"
        r"\b[\s\"']*[:=]|\bBearer\s+\S+", text, flags=re.IGNORECASE
    ):
        return True
    if re.search(r"[0-9a-fA-F]{32,}", text):
        return True
    return any(
        run.endswith("=") or (re.search(r"[A-Za-z]", run) and re.search(r"[0-9]", run))
        for run in re.findall(r"[A-Za-z0-9+/=]{16,}", text)
    )


def _refusal_reason(reason, possible_credential=False):
    prefix = ""
    if isinstance(reason, BaseException):
        prefix = f"{type(reason).__name__}: "
        reason = prefix + str(reason)
    else:
        reason = str(reason)
    # Suppress the whole reason before truncation; free text cannot be safely spliced.
    if possible_credential or _credential_indicator(reason):
        return prefix + "[redacted: possible credential]"
    return reason[:300]


def _cached_refusal_build():
    """Use an already loaded snapshot; importing build could run git on exit."""
    try:
        module = sys.modules.get("leafhft.build")
        sha = getattr(module, "_IDENTITY", {}).get("git_sha")
        if isinstance(sha, str) and re.fullmatch(r"[0-9a-fA-F]{40}", sha):
            return sha[:12]
    except Exception:
        pass
    return None


# Public reasons are a closed vocabulary, never sanitized exception text or names.
_JOURNAL_LANE_REASONS = frozenset({
    "account authority mismatch", "account authority unavailable", "account book refused",
    "account budget approval mismatch", "account budget state missing",
    "account command replay refused", "account coordinated override refused",
    "account credential mismatch", "account directory belongs to another user",
    "account not live", "account profit pool override refused", "account queue exceeds bounds",
    "account runtime override refused", "account runtime selection refused",
    "account scope mismatch", "account start failed", "account state mismatch",
    "account stopped", "account supervisor failed", "activation expired",
    "activation generation mismatch", "activation mismatch", "activation readiness timed out",
    "activation receipt mismatch", "approval expired", "book inventory changed",
    "credential already bound", "credential envelope refused", "credential generation mismatch",
    "credential revision refused", "credential validation failed", "dry run failed",
    "dry run generation mismatch", "dry run has activation marker", "dry run timed out",
    "duplicate field", "duplicate lane binding", "invalid account arguments",
    "invalid account command", "invalid account scope", "invalid account sizing",
    "invalid account user", "invalid account user binding", "invalid binding",
    "invalid bindings", "invalid command cursor", "invalid command sequence",
    "invalid coordinated selection", "invalid credential copy", "invalid credential fingerprint",
    "invalid credential registry", "invalid credential source", "invalid document",
    "invalid enrollment key", "invalid mode", "invalid path", "invalid profit pool setting",
    "invalid projection floor", "invalid runtime identity", "invalid unit action",
    "live approval required", "live book readiness mismatch", "live orders before readiness",
    "live prerequisites missing", "live readiness timed out", "live staging refused",
    "live unit inactive", "owner cannot receive coordinated intents",
    "owner_lane_parked",
    "profit pool credential unavailable", "request identity mismatch", "root agent required",
    "staged live configuration mismatch", "stale account command",
    "stop account before activation", "stop account before changing it", "unit action failed",
    "unit state unavailable", "unknown book", "unsafe account directory", "unsafe account root",
    "unsafe account unit directory", "unsafe activation directory", "unsafe activation marker",
    "unsafe activation root", "unsafe agent root", "unsafe config directory", "unsafe path",
    "unsafe private file", "unsafe profit pool path", "use a new lane for a different account",
    "invalid gold opt-in", "gold opt-in required", "gold requires account regime",
    "gold requires live mode", "gold requires clean build", "gold launch failed",
    "gold requires activation receipt", "gold activation receipt mismatch", "gold status write failed",
    "owner gold unit active", "owner gold unit state unavailable",
})
_JOURNAL_REFUSAL_CODES = frozenset({
    "projection_absent", "projection_unsafe", "projection_invalid", "projection_unreadable",
    "projection_replayed", "projection_floor_missing", "projection_floor_invalid",
})


def _journal_reason(captured, action, exit_code, reason, refusal_class="unclassified",
                    *, possible_credential=False):
    """Build the allowlisted reason shared by journal lines and usage receipts."""
    reason_code = getattr(reason, "code", None)
    text = str(reason)
    if (possible_credential or captured.possible_credential
            or _credential_indicator(text)
            or (isinstance(reason_code, str) and _credential_indicator(reason_code))):
        return "redacted"
    if refusal_class == "usage":
        return "usage"
    if isinstance(reason_code, str):
        return ("LaneRefused:" + reason_code if reason_code in _JOURNAL_REFUSAL_CODES
                and not isinstance(reason, SystemExit) else "unclassified")
    if type(reason) is LaneRefused and text in _JOURNAL_LANE_REASONS:
        return "LaneRefused"
    if type(reason) is SystemExit and (type(reason.code) is int or reason.code is None):
        return "SystemExit"
    if type(reason) is str and reason == f"{action} exited with code {exit_code}":
        return "exit"
    return "unclassified"


def _journal_refusal(captured, action, exit_code, reason, refusal_class="unclassified",
                     *, possible_credential=False):
    """Emit one allowlisted public reason without changing the private receipt."""
    if exit_code == 0 or action not in ("run", "push", "book", "gold", "gold-exclusive"):
        return
    try:
        token = _journal_reason(captured, action, exit_code, reason, refusal_class,
                                possible_credential=possible_credential)
        stream = captured.stream
        while isinstance(stream, _RefusalStderr):
            stream = stream.stream
        prefix = "\n" if captured.line_open else ""
        stream.write(f"{prefix}account lane {action} exit {exit_code}: {token}\n")
        stream.flush()
    except Exception:
        pass


def record_refusal(lane_id, action, exit_code, reason="", symbol=None, *, possible_credential=False):
    """Best-effort exit receipt, or removal on success; never called per order."""
    try:
        # gold-exclusive is journal-only: its root presence check must never write lane state.
        if action not in ("run", "push", "book", "gold"):
            return
        if (action == "book" and symbol not in SYMBOLS) or (action != "book" and symbol is not None):
            return
        paths = LanePaths(lane_id)
        directory = safe_path(paths.state / "refusals")
        target = safe_path(directory / (action + ("-" + symbol if symbol else "") + ".json"))
        if exit_code == 0:
            if directory.exists():
                with private_parent(target) as parent:
                    try:
                        os.unlink(target.name if parent is not None else target, dir_fd=parent)
                    except FileNotFoundError:
                        pass
            return
        _private_lane_dir(directory)
        if isinstance(sys.stderr, _RefusalStderr):
            possible_credential |= sys.stderr.possible_credential
        document = {"updated_at": int(time.time()), "action": action, "symbol": symbol,
                    "exit_code": int(exit_code), "reason": _refusal_reason(reason, possible_credential),
                    "build": _cached_refusal_build()}
        payload = canonical(document)
        if len(payload) > 4096:
            return
        write_private(target, payload)
        if isinstance(sys.stderr, _RefusalStderr):
            # Preserve supervise's more specific receipt when main sees its return.
            sys.stderr.recorded = (lane_id, action, symbol, exit_code)
            sys.stderr.recorded_reason = reason
            sys.stderr.recorded_possible_credential = possible_credential
    except Exception:
        pass


def scope(tenant_id, lane_id):
    return {"version": VERSION, "tenant_id": identifier(tenant_id),
            "lane_id": identifier(lane_id), "venue": "kalshi", "subaccount": 0}


def check_scope(doc, binding):
    if type(binding) is not dict:
        raise LaneRefused("account scope mismatch")
    expected = scope(binding.get("tenant_id"), binding.get("lane_id"))
    if type(doc) is not dict or any(type(doc.get(k)) is not type(v) or doc.get(k) != v
                                    for k, v in expected.items()):
        raise LaneRefused("account scope mismatch")


def envelope_aad(binding):
    return canonical(scope(binding["tenant_id"], binding["lane_id"]))


def enrollment_key():
    """Root-only enrollment initialization. Return only the public half."""
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    if os.name != "posix" or os.geteuid() != 0:
        raise LaneRefused("root agent required")
    safe_path(CONFIG_ROOT).mkdir(mode=0o711, exist_ok=True)
    info = CONFIG_ROOT.stat()
    if info.st_uid != 0 or stat.S_IMODE(info.st_mode) & 0o022:
        raise LaneRefused("unsafe account root")
    with exclusive(CONFIG_ROOT / "enrollment.lock"):
        path = CONFIG_ROOT / "enrollment-private.pem"
        if not path.exists():
            key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
            write_private(path, key.private_bytes(serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        key = serialization.load_pem_private_key(read_private(path), password=None)
        if not isinstance(key, rsa.RSAPrivateKey) or key.key_size < 2048:
            raise LaneRefused("invalid enrollment key")
        public = key.public_key().public_bytes(serialization.Encoding.PEM,
                                              serialization.PublicFormat.SubjectPublicKeyInfo)
        public_der = base64.b64encode(key.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)).decode("ascii")
        # The persisted private key is the durable identity, including after a
        # restart between key creation and returning its public registration.
        key_id = str(uuid.uuid5(uuid.NAMESPACE_OID, "leafhft-enrollment:" + public_der))
        write_private(CONFIG_ROOT / "enrollment-public.pem", public)
        return {"version": VERSION, "algorithm": ALGORITHM, "public_key_pem": public.decode(),
                "enrollment_key_id": key_id, "public_key_der": public_der}


def lane_enrollment_key(lane_id):
    """Read the lane's durable identity without creating or rotating material."""
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    key = serialization.load_pem_private_key(
        read_private(LanePaths(lane_id).config / "enrollment-private.pem"), password=None)
    if not isinstance(key, rsa.RSAPrivateKey) or key.key_size < 2048:
        raise LaneRefused("invalid enrollment key")
    public_der = base64.b64encode(key.public_key().public_bytes(
        serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)).decode("ascii")
    return {"enrollment_key_id": str(uuid.uuid5(uuid.NAMESPACE_OID,
            "leafhft-enrollment:" + public_der)), "public_key_der": public_der}


# S7A L5a: the lane's dashboard identity lives root-owned 0444 beside its credential, outside every
# lane-writable tree. engine_ops (S7A L2, --lane-identity-root) reads a lane's book_account_id only
# from here; a missing file leaves it None, so that lane's tenant probes refuse (fail closed).
LANE_IDENTITY_NAME = "dashboard-account-identity.json"
LANE_IDENTITY_MAX = 1024  # engines.load_dashboard_account_identity reads at most 1 KiB


def lane_identity_path(paths):
    return safe_path(paths.config / LANE_IDENTITY_NAME)


def lane_identity_bytes(binding, validated_at):
    """The identity document the root agent's own enrollment produced, as bytes.

    account_id is the tenant lane's dashboard account, derived only from the root-owned binding scope
    (the ["kashbot-<lane>","kalshi",<subaccount>] id the dashboard verifies for the lane and the
    provisioner seeds); verified_at is the root credential validation time. Pure: it never reads the
    lane state dir, so nothing a tenant writes can reach these bytes. Fails closed on bad input.
    The shape is engines.DashboardAccountIdentity's (schema 1, an account_id of at most 160 printable
    characters, an ISO UTC verified_at); no import here, because this file is in the shadow_continuous
    source closure and its lazy-import table pins every function-level import."""
    base = scope(binding.get("tenant_id"), binding.get("lane_id"))
    if type(validated_at) is not int or not 0 <= validated_at < 2**40:
        raise LaneRefused("invalid lane identity")
    account = json.dumps(["kashbot-" + base["lane_id"], base["venue"], base["subaccount"]],
                         separators=(",", ":"))
    if not 1 <= len(account) <= 160 or not account.isprintable():
        raise LaneRefused("invalid lane identity")
    document = {
        "schema_version": 1,
        "account_id": account,
        "subaccount_number": base["subaccount"],
        "verified_at": time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime(validated_at)),
    }
    data = canonical(document)
    if len(data) > LANE_IDENTITY_MAX:
        raise LaneRefused("invalid lane identity")
    return data


def _read_root_public(path):
    """The current bytes of an agent-owned 0444 regular file, or None when it is absent or anything
    else (wrong mode or owner, a directory, a link), so the caller rewrites it. Never follows a symlink."""
    with private_parent(path) as parent:
        try:
            fd = os.open(path.name if parent is not None else path,
                         os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0),
                         dir_fd=parent)
        except OSError:
            return None
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > LANE_IDENTITY_MAX
                or (os.name == "posix" and (info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o444))):
            return None
        return stream.read(LANE_IDENTITY_MAX + 1)


def write_lane_identity(paths, binding, validated_at):
    """Write the lane identity root 0444 from lane_identity_bytes: temp file plus fsync plus replace
    inside the pinned root-owned config dir, never following a symlink. A file already holding exactly
    these bytes at 0444 is left alone and None is returned; anything else (bad mode, truncated or
    foreign bytes) is replaced. Cost: one bounded read, and one <= 1 KiB write only on a change."""
    data = lane_identity_bytes(binding, validated_at)
    if paths.lane_id != binding["lane_id"]:
        raise LaneRefused("account scope mismatch")
    path = lane_identity_path(paths)
    if _read_root_public(path) == data:
        return None
    if os.name == "posix":
        with private_parent(path) as parent:
            name = ".lane-" + secrets.token_hex(16)
            fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o444, dir_fd=parent)
            try:
                with os.fdopen(fd, "wb") as stream:
                    os.fchmod(stream.fileno(), 0o444)
                    stream.write(data)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(name, path.name, src_dir_fd=parent, dst_dir_fd=parent)
                os.fsync(parent)
            finally:
                try:
                    os.unlink(name, dir_fd=parent)
                except FileNotFoundError:
                    pass
        return data
    fd, name = tempfile.mkstemp(prefix=".lane-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if path.exists():
            os.chmod(path, stat.S_IREAD | stat.S_IWRITE)  # Windows refuses to replace a read-only file
        os.replace(name, path)
        os.chmod(path, stat.S_IREAD)
    finally:
        Path(name).unlink(missing_ok=True)
    return data


def ensure_lane_identity(binding):
    """Backfill and repair: keep the root identity equal to the bytes the root-owned records of the
    lane's own enrollment produce (config.json and the root snapshot.json from validate_credential).
    Absent or invalid root records write nothing (the lane stays fail closed). A matching identity is
    left alone (None); a missing one, or one with a bad mode or bad bytes, is rewritten. Cost per agent
    pass: three bounded reads of <= 64 KiB, and a write only on a mismatch."""
    paths = LanePaths(binding["lane_id"])
    if not (paths.config / "config.json").exists() or not (paths.config / "snapshot.json").exists():
        return None
    config = parse(read_private(paths.config / "config.json"))
    check_scope(config, binding)
    if type(config.get("fingerprint")) is not str or not re.fullmatch(r"[0-9a-f]{64}", config["fingerprint"]):
        raise LaneRefused("invalid lane identity")
    snapshot = parse(read_private(paths.config / "snapshot.json"))
    check_scope(snapshot, binding)
    return write_lane_identity(paths, binding, snapshot.get("validated_at"))


def decrypt_envelope(envelope, binding, private_key):
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding, rsa
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    try:
        if type(envelope) is not dict or set(envelope) != {"version", "algorithm", "wrapped_key", "nonce", "ciphertext"}:
            raise ValueError
        if type(envelope["version"]) is not int or envelope["version"] != VERSION or envelope["algorithm"] != ALGORITHM:
            raise ValueError
        fields = []
        for name in ("wrapped_key", "nonce", "ciphertext"):
            value = envelope[name]
            if not isinstance(value, str) or len(value) > 32768:
                raise ValueError
            fields.append(base64.b64decode(value, validate=True))
        wrapped, nonce, ciphertext = fields
        key = serialization.load_pem_private_key(private_key, password=None)
        if not isinstance(key, rsa.RSAPrivateKey) or key.key_size < 2048 or len(nonce) != 12:
            raise ValueError
        symmetric = key.decrypt(wrapped, padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
        if len(symmetric) != 32:
            raise ValueError
        credential = parse(AESGCM(symmetric).decrypt(nonce, ciphertext, envelope_aad(binding)))
        if type(credential) is not dict or set(credential) != {"key_id", "private_key_pem"}:
            raise ValueError
        if not isinstance(credential["key_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{16,128}", credential["key_id"]):
            raise ValueError
        pem = credential["private_key_pem"]
        if not isinstance(pem, str) or not 100 <= len(pem) <= 16384:
            raise ValueError
        signing_key = serialization.load_pem_private_key(pem.encode(), password=None)
        if not isinstance(signing_key, rsa.RSAPrivateKey) or signing_key.key_size < 2048:
            raise ValueError
        public = signing_key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        return credential, hashlib.sha256(public).hexdigest()
    except Exception:
        raise LaneRefused("credential envelope refused") from None


def validate_credential(credential):
    """Only signed GETs to fixed Kalshi endpoints. Never constructs an order client."""
    import urllib.request
    from .feeds.kalshi import sign
    result = {}
    try:
        for name in ("balance", "positions"):
            path = "/trade-api/v2/portfolio/" + name
            stamp = time.time_ns() // 1_000_000
            request = urllib.request.Request("https://api.elections.kalshi.com" + path, method="GET", headers={
                "KALSHI-ACCESS-KEY": credential["key_id"], "KALSHI-ACCESS-TIMESTAMP": str(stamp),
                "KALSHI-ACCESS-SIGNATURE": sign(stamp, "GET", path, credential["private_key_pem"])})
            # Redirects must not forward signed headers to another host.
            class NoRedirect(urllib.request.HTTPRedirectHandler):
                def redirect_request(self, *args, **kwargs):
                    return None
            with urllib.request.build_opener(NoRedirect).open(request, timeout=10) as response:
                result[name] = parse(response.read(65537))
        balance = result["balance"]["balance"]
        positions = result["positions"]["market_positions"]
        if type(balance) is not int or balance < 0 or type(positions) is not list:
            raise ValueError
        return {"balance_cents": balance, "position_count": len(positions), "validated_at": int(time.time())}
    except Exception:
        raise LaneRefused("credential validation failed") from None


def canonical_symbols():
    from .feeds.kalshi import SYMBOL_MAP
    if len(SYMBOL_MAP) != 14 or set(SYMBOL_MAP) != set(SYMBOLS):
        raise LaneRefused("book inventory changed")
    return SYMBOLS


def account_stake(config):
    from .broker.account_live_budget import sizing_from_cash
    if "account_sizing" not in config:
        return "5.00"
    sizing = sizing_from_cash(config["account_sizing"]["free_cash_cents"])
    if canonical(sizing) != canonical(config["account_sizing"]):
        raise LaneRefused("invalid account sizing")
    cents = sizing["per_book_stake_cents"]
    return f"{cents // 100}.{cents % 100:02d}"


def coordinated_options(config):
    """Only the account's persisted configuration can select follower mode."""
    mode = config.get("coordinated_mode", "off")
    from .coordinated_cohort import OWNER_LANE
    if config.get("lane_id") == OWNER_LANE and mode != "off":
        raise LaneRefused("owner cannot receive coordinated intents")
    if mode not in ("off", "shadow", "live"):
        raise LaneRefused("invalid coordinated selection")
    return {"coordinated_mode": mode}


def profit_pool_params(paths):
    """Read only the unit's private credential, never the masked root config tree."""
    directory = os.environ.get("CREDENTIALS_DIRECTORY")
    if not directory:
        return None
    try:
        # Older units have no copy. lstat keeps a dangling link from looking absent.
        (Path(directory) / "profit-pool").lstat()
    except FileNotFoundError:
        return None
    except OSError:
        raise LaneRefused("profit pool credential unavailable") from None
    try:
        runtime_paths, _, read = load_runtime(paths.lane_id)
        if runtime_paths != paths:
            raise LaneRefused("account state mismatch")
        setting = read("profit-pool")
    except OSError:
        raise LaneRefused("profit pool credential unavailable") from None
    if setting is None:  # The literal SetCredential default, not JSON null.
        return None
    from .broker.kalshi_pool import MAX_INT_CENTS
    if (type(setting) is not dict
            or set(setting) != {"schema_version", "deposit_cents", "extra_ceiling_cents"}
            or type(setting["schema_version"]) is not int or setting["schema_version"] != 1
            or type(setting["deposit_cents"]) is not int
            or not 0 < setting["deposit_cents"] <= MAX_INT_CENTS
            or type(setting["extra_ceiling_cents"]) is not int
            or not 0 <= setting["extra_ceiling_cents"] <= MAX_INT_CENTS):
        raise LaneRefused("invalid profit pool setting")
    try:
        root = safe_path(paths.state)
        pool = safe_path(root / "kalshi-pool.json")
        # Windows junctions are reparse points but need not be is_symlink().
        # Check the lock too: ProfitPool opens it beside the pool document.
        for target in (pool, Path(str(pool) + ".lock"), *pool.parents):
            try:
                info = target.lstat()
            except FileNotFoundError:
                continue
            if (stat.S_ISLNK(info.st_mode)
                    or getattr(info, "st_file_attributes", 0) & 0x400):
                raise LaneRefused("unsafe profit pool path")
        resolved = pool.resolve()
        if resolved.parent != root.resolve():
            raise LaneRefused("unsafe profit pool path")
    except (OSError, RuntimeError):
        raise LaneRefused("unsafe profit pool path") from None
    return canonical({"profit_pool": {
        "deposit_cents": setting["deposit_cents"],
        "extra_ceiling_cents": setting["extra_ceiling_cents"],
        "path": str(resolved),
    }}).decode("utf-8")


def lifecycle_lease_path(paths):
    """Root-published sibling of probe bindings; passed through without reading the lease."""
    return str(probe_bindings_path(paths).with_name("lifecycle-lease.json"))


def live_arguments(paths, symbol, config=None):
    if symbol not in canonical_symbols():
        raise LaneRefused("unknown book")
    coordinated = coordinated_options(config or {})
    options = ([] if coordinated["coordinated_mode"] == "off" else
               ["--coordinated-mode", coordinated["coordinated_mode"]])
    options += ["--lifecycle-lease", lifecycle_lease_path(paths)]
    params = profit_pool_params(paths)
    if params is not None:
        options += ["--params", params]
    return ["live", "--venue", "kalshi", "--symbol", symbol, "--strategy", "kalshi_edge",
            "--stake-usd", account_stake(config or {}), "--limits-profile", "kalshi-experiment", "--seconds", "86400",
            "--run-dir", str(paths.state / "runs"), "--ack-dir", str(paths.state / "live-ack"),
            "--authority-path", str(paths.state / "kalshi-authority.json"),
            "--engines-dir", str(paths.state / "engine-catalog" / "engines"),
            "--engine-bindings", str(paths.state / "engine-bindings.json"),
            "--engine-account-overrides", str(paths.state / "engine-account-overrides.json"),
            "--dashboard-account-identity", str(paths.state / "dashboard-account-identity.json"),
            "--darkhorse-config", str(paths.state / "darkhorse.json")] + [
            item for name, value in probe_hosting_paths(paths).items()
            for item in ("--" + name.replace("_", "-"), value)] + options


def validate_live_arguments(args):
    """Reject optional path, venue and account selectors on the account rail."""
    paths, config, read = load_runtime(os.environ["LEAFHFT_ACCOUNT_LANE_ID"])
    credential = read("credential")
    if (os.environ.get("LEAFHFT_KALSHI_KEY_ID") != credential.get("key_id")
            or os.environ.get("LEAFHFT_KALSHI_PRIVATE_KEY_PEM") != credential.get("private_key_pem")
            or os.environ.get("LEAFHFT_LIVE") != "1"):
        raise LaneRefused("account credential mismatch")
    authorization = read("approval")
    require_live(config, credential, authorization, read("dry-run"), runtime_paths=paths)
    if getattr(args, "coordinated_mode", "off") != coordinated_options(config)["coordinated_mode"]:
        raise LaneRefused("account coordinated override refused")
    expected = {"venue": "kalshi", "strategy": "kalshi_edge", "stake_usd": account_stake(config),
                "limits_profile": "kalshi-experiment", "seconds": 86400, "goal": "1000",
                "run_dir": str(paths.state / "runs"), "ack_dir": str(paths.state / "live-ack"),
                "authority_path": str(paths.state / "kalshi-authority.json"),
                "engines_dir": str(paths.state / "engine-catalog" / "engines"),
                "engine_bindings": str(paths.state / "engine-bindings.json"),
                "engine_account_overrides": str(paths.state / "engine-account-overrides.json"),
                "dashboard_account_identity": str(paths.state / "dashboard-account-identity.json"),
                "darkhorse_config": str(paths.state / "darkhorse.json"),
                **probe_hosting_paths(paths), "lifecycle_lease": lifecycle_lease_path(paths)}
    if args.symbol not in canonical_symbols() or any(getattr(args, k, None) != v for k, v in expected.items()):
        raise LaneRefused("account runtime selection refused")
    params = profit_pool_params(paths)
    if getattr(args, "params", "") != (params if params is not None else ""):
        raise LaneRefused("account profit pool override refused")
    # cli.main's exact argv allowlist rejects repeated --params before argparse
    # can discard all but the last value. Here we pin the parsed value as well.
    for name in ("policy", "execution_experiment", "lane", "executor_mode", "parity_mirror",
                 "shadow_policy", "shadow_socket", "alternate", "reference_venue", "adopt_inventory"):
        if getattr(args, name, None):
            raise LaneRefused("account runtime override refused")
    if os.environ.get("LEAFHFT_STATE_DIR") != str(paths.state):
        raise LaneRefused("account state mismatch")
    if safe_path(paths.state / "KILL").exists():
        raise LaneRefused("account stopped")
    from .broker.account_live_budget import AccountLiveBudget
    class ActivatedBudget(AccountLiveBudget):
        def snapshot(self, **kwargs):
            require_activation(paths, config, authorization)
            return super().snapshot(**kwargs)

        def claim(self, *args, **kwargs):
            # The existing client calls this at its final send boundary.
            require_activation(paths, config, authorization)
            client_id = args[0] if args else kwargs.get("client_id", "")
            if client_id.startswith("lh-dh-"):
                from .engines import AccountDarkHorse, load_dashboard_account_identity
                identity = load_dashboard_account_identity(paths.state / "dashboard-account-identity.json")
                AccountDarkHorse(paths.state, identity.account_id).admitted()
            return super().claim(*args, **kwargs)
    binding = config["account_budget"]
    budget = ActivatedBudget(paths.state / "account-live-budget.json", lane_id=paths.lane_id,
                             generation=binding["generation"], digest=binding["digest"],
                             sizing=config.get("account_sizing"))
    budget.snapshot()
    return budget


def account_budget(paths, config, *, owner=None):
    from .broker.account_live_budget import AccountLiveBudget, approval_binding
    binding = config.get("account_budget")
    if type(binding) is not dict or binding != approval_binding(config, binding.get("generation")):
        raise LaneRefused("account budget approval mismatch")
    return AccountLiveBudget(paths.state / "account-live-budget.json", lane_id=paths.lane_id,
                             generation=binding["generation"], digest=binding["digest"], owner=owner,
                             sizing=config.get("account_sizing"))


def activation_path(paths, *, receipt=False):
    # Outside the lane-writable directory and the unit's inaccessible config tree.
    return safe_path(STATE_ROOT / "activations" / (paths.lane_id + (".receipt.json" if receipt else ".json")))


def activation_document(config, authorization):
    return {**scope(config["tenant_id"], config["lane_id"]),
            "start_request_id": identifier(authorization["request_id"]),
            "dry_run_request_id": identifier(config["dry_run_id"]),
            "fingerprint": config["fingerprint"], **config["account_budget"],
            "expires_at": authorization["expires_at"],
            "staged_digest": hashlib.sha256(canonical([config, authorization])).hexdigest()}


def _activation_read(path):
    path = safe_path(path)
    if os.name == "posix":
        info = safe_path(STATE_ROOT).stat()
        if info.st_uid != 0 or stat.S_IMODE(info.st_mode) & 0o022:
            raise LaneRefused("unsafe activation root")
    with private_parent(path) as parent:
        if os.name == "posix":
            info = os.fstat(parent)
            if info.st_uid != 0 or stat.S_IMODE(info.st_mode) != 0o755:
                raise LaneRefused("unsafe activation directory")
        fd = os.open(path.name if parent is not None else path,
                     os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0), dir_fd=parent)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 65536
                or (os.name == "posix" and (info.st_uid != 0 or stat.S_IMODE(info.st_mode) != 0o644))):
            raise LaneRefused("unsafe activation marker")
        return parse(stream.read(65537))


def _activation_write(path, value):
    directory = safe_path(path.parent)
    try:
        directory.mkdir(mode=0o755)
    except FileExistsError:
        pass
    else:
        # The root agent runs with UMask=0077; books need read/traverse access.
        directory.chmod(0o755)
    if os.name == "posix" and (directory.stat().st_uid != 0 or stat.S_IMODE(directory.stat().st_mode) != 0o755):
        raise LaneRefused("unsafe activation directory")
    # Publish complete, readable bytes atomically; the directory is root-writable only.
    temporary = directory / (".activation-" + secrets.token_hex(16))
    try:
        write_private(temporary, value)
        temporary.chmod(0o644)
        os.replace(temporary, safe_path(path))
        if os.name == "posix":
            fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
    finally:
        temporary.unlink(missing_ok=True)


def remove_activation(paths):
    directory = safe_path(STATE_ROOT / "activations")
    if not directory.exists():
        return
    names = (paths.lane_id + ".json", paths.lane_id + ".receipt.json")
    if os.name == "posix":
        fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            info = os.fstat(fd)
            if info.st_uid != 0 or stat.S_IMODE(info.st_mode) != 0o755:
                raise LaneRefused("unsafe activation directory")
            for name in names:
                try:
                    # Unlink a corrupt symlink itself, never its target.
                    os.unlink(name, dir_fd=fd)
                except FileNotFoundError:
                    pass
            os.fsync(fd)
        finally:
            os.close(fd)
    else:
        for name in names:
            (directory / name).unlink(missing_ok=True)


def require_activation(paths, config, authorization):
    if config.get("mode") != "live" or safe_path(paths.state / "KILL").exists():
        raise LaneRefused("account not live")
    expected = activation_document(config, authorization)
    if canonical(_activation_read(activation_path(paths))) != canonical(expected):
        raise LaneRefused("activation mismatch")
    # The deadline limits command replay, not the accepted activation's lifetime.
    # Stop and revoke end that lifetime by removing the published marker.
    if type(expected["expires_at"]) is not int:
        raise LaneRefused("activation expired")
    return expected


def live_receipt(config, authorization, *, activated=False):
    return {**activation_document(config, authorization),
            "activated" if activated else "ready": True,
            "symbols": list(canonical_symbols()), "order_placement_calls": 0}


def _private_lane_dir(path):
    """A lane-owned 0700 child of the lane's own state root, made by the lane user itself (load_runtime
    requires euid == lane uid). Created, owned by this process's euid, and a drifted mode is repaired
    to 0700; a directory anyone else owns refuses. Not enforced off POSIX (the Windows test path).
    Reads this module's `os`, so tests that patch agent.os steer it."""
    posix = os.name == "posix"
    return ensure_private_dir(safe_path(path), owner=os.geteuid() if posix else 0,
                              refusal=LaneRefused("unsafe account directory"), repair=True, enforce=posix)


def _book_barrier(paths, config, authorization, symbol):
    marker = require_activation(paths, config, authorization)
    ready = _private_lane_dir(paths.state / "live-books")
    write_private(ready / (symbol + ".json"), {**marker, "symbol": symbol,
                  "pid": os.getpid(), "ready": True, "order_placement_calls": 0})
    expected = live_receipt(config, authorization, activated=True)
    deadline = time.monotonic() + 120
    while True:
        require_activation(paths, config, authorization)
        try:
            if canonical(_activation_read(activation_path(paths, receipt=True))) != canonical(expected):
                raise LaneRefused("activation receipt mismatch")
            return
        except FileNotFoundError:
            if time.monotonic() >= deadline:
                raise LaneRefused("activation readiness timed out")
            time.sleep(0.05)


@contextmanager
def live_cycle_guard(paths, config, authorization):
    """Scope the feed guard to this dedicated account book process only."""
    from .feeds import base
    original = base.make_feed
    def guarded_feed(*args, **kwargs):
        require_activation(paths, config, authorization)
        feed = original(*args, **kwargs)
        events = feed.events
        async def guarded_events(*event_args, **event_kwargs):
            require_activation(paths, config, authorization)
            async for event in events(*event_args, **event_kwargs):
                require_activation(paths, config, authorization)
                yield event
        feed.events = guarded_events
        return feed
    base.make_feed = guarded_feed
    try:
        yield
    finally:
        base.make_feed = original


def prepare_state(paths, config, *, live=False):
    from .broker.kalshi_authority import KalshiAuthority
    for name in ("runs", "live-ack"):
        _private_lane_dir(paths.state / name)
    authority_path = safe_path(paths.state / "kalshi-authority.json")
    generation_path = safe_path(authority_path.with_suffix(".generation"))
    generation = config["lane_id"]
    authority = KalshiAuthority(authority_path, generation_id=generation)
    if not authority_path.exists():
        if live or authority.initialize(generation) is not True:
            raise LaneRefused("account authority unavailable")
        write_private(generation_path, generation.encode())
    if not isinstance(authority.snapshot(), dict):
        raise LaneRefused("account authority mismatch")
    if not generation_path.exists():
        if live:
            raise LaneRefused("account authority mismatch")
        write_private(generation_path, generation.encode())
    if generation_path.read_text() != generation:
        raise LaneRefused("account authority mismatch")
    if live:
        account_budget(paths, config).initialize()
        from .engines import AccountDarkHorse, DEFAULT_DARKHORSE_CONFIG, load_dashboard_account_identity
        try:
            if DEFAULT_DARKHORSE_CONFIG.is_file():
                identity_path = paths.state / "dashboard-account-identity.json"
                aid = (load_dashboard_account_identity(identity_path).account_id
                       if identity_path.exists() else paths.lane_id)
                AccountDarkHorse(paths.state, aid).materialize()
        except (OSError, ValueError):
            # Optional model failures stop Darkhorse at decision/send admission,
            # while the account's existing engines keep their independent state.
            print("account Darkhorse configuration unavailable", file=sys.stderr, flush=True)
        from .config import EngineConfig
        from .types import to_quote_q
        from .broker.live_gate import ack_path, ack_sentence
        params = profit_pool_params(paths)
        hosting = probe_hosting_paths(paths)
        probe = {"probe_bindings": hosting["probe_bindings"], "engine_registry": hosting["engine_registry"],
                 "execution_domain": execution_domain(paths.lane_id)}
        # Materialize only the fourteen frozen configs authorized by this start request.
        # The existing live gate consumes each ack and applies its own risk checks.
        for symbol in canonical_symbols():
            fields = dict(venue="kalshi", symbol=symbol, strategy="kalshi_edge", mode="live",
                strategy_params=parse(params) if params is not None else {},
                starting_cash_q=to_quote_q(account_stake(config)), limits_profile="kalshi-experiment", run_seconds=86400,
                authority_path=str(authority_path), authority_generation=generation,
                engines_dir=str(paths.state / "engine-catalog" / "engines"),
                engine_bindings=str(paths.state / "engine-bindings.json"),
                engine_account_overrides=str(paths.state / "engine-account-overrides.json"),
                dashboard_account_identity=str(paths.state / "dashboard-account-identity.json"),
                darkhorse_config_path=str(paths.state / "darkhorse.json"),
                lifecycle_dir=hosting["lifecycle_dir"], **coordinated_options(config))
            # cmd_live builds this config from live_arguments plus book_main's domain, and its
            # __post_init__ keeps or clears the three probe fields by the bindings file AS IT IS when
            # the book starts, which a root write may change after this runs. Both are legitimate
            # variants of the one approved lane config, so both acks are minted: any bindings state
            # at book start (absent, bound, unbound, corrupt) then passes the live gate.
            cleared = EngineConfig(**fields)
            hosted = EngineConfig(**fields, **probe)
            for name, value in probe.items():
                object.__setattr__(hosted, name, value)  # kept even when no probe is bound right now
            for variant in (cleared, hosted):
                write_private(ack_path(variant, paths.state / "live-ack"), ack_sentence(variant).encode())


def private_credential_copy(info, uid, gid):
    mode = stat.S_IMODE(info.st_mode)
    return ((info.st_uid == 0 and info.st_gid == 0 and mode == 0o440)
            or (info.st_uid == uid and info.st_gid == gid and mode == 0o400))


def read_credential_copy(directory, name, uid, gid):
    if name not in ("config", "credential", "approval", "dry-run", "push", "profit-pool", "gold", "book-source"):
        raise LaneRefused("invalid credential source")
    path = safe_path(directory / name)
    info = path.stat()
    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 65536
            or not private_credential_copy(info, uid, gid)):
        raise LaneRefused("invalid credential copy")
    data = path.read_bytes()
    if name == "book-source":
        return None if data == b"off" else data
    if name in ("profit-pool", "gold") and data == b"off":
        return None
    value = parse(data)
    if name == "profit-pool" and type(value) is not dict:
        raise LaneRefused("invalid profit pool setting")
    if name == "gold" and type(value) is not dict:
        raise LaneRefused("invalid gold opt-in")
    return value


def book_source(lane_id, symbol, read) -> str:
    try:
        try:
            data = read("book-source")
        except (FileNotFoundError, KeyError):
            # Units started before this credential existed have no file; absent means off.
            return "direct"
        if data is None:
            return "direct"
        from .bookd.lane_select import parse_selector
        return "shared" if symbol in parse_selector(data, lane_id, canonical_symbols()) else "direct"
    except Exception:
        # Fail closed: an unreadable or invalid selector never starts a book on a guessed source.
        raise LaneRefused("invalid book source selector") from None


def gold_opt_in(lane_id, read):
    try:
        opt = read("gold")
        if opt is None:
            return None
        if (type(opt) is not dict or set(opt) != {"schema", "lane_id", "stake_usd", "fixed_count"}
                or opt["schema"] != "leafhft.gold-lane-opt-in.v1" or opt["lane_id"] != lane_id):
            raise ValueError
        for name, maximum in (("stake_usd", "50.00"), ("fixed_count", "1.00")):
            value = opt[name]
            if (not isinstance(value, str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]{1,2})?", value)
                    or not Decimal("0.01") <= Decimal(value) <= Decimal(maximum)):
                raise ValueError
        return opt
    except Exception:
        raise LaneRefused("invalid gold opt-in") from None


def gold_exclusive(lane_id):
    if not hasattr(os, "geteuid") or os.geteuid() != 0:
        raise LaneRefused("root agent required")
    identifier(lane_id)
    present = []
    try:
        lanes = list(CONFIG_ROOT.iterdir())
    except FileNotFoundError:
        lanes = []
    for lane in lanes:
        mode = lane.lstat().st_mode
        if not (stat.S_ISDIR(mode) or stat.S_ISLNK(mode)):
            continue
        try:
            (lane / "gold.json").lstat()
        except FileNotFoundError:
            continue
        present.append(lane.name)
    if lane_id not in present:
        return 0
    if len(present) > 1:
        print("Gold exclusive refused: " + ", ".join(sorted(present)), file=sys.stderr)
        return 2
    try:
        owner = subprocess.run(
            ["systemctl", "is-active", "leafhft-gold-live.service"],
            timeout=5, capture_output=True, text=True, check=False)
        owner_state = owner.stdout.strip()
    except Exception:
        raise LaneRefused("owner gold unit state unavailable") from None
    if owner_state == "active":
        raise LaneRefused("owner gold unit active")
    if owner_state not in ("inactive", "failed"):
        raise LaneRefused("owner gold unit state unavailable")
    return 0


def load_runtime(lane_id):
    import pwd
    paths = LanePaths(lane_id)
    user = pwd.getpwnam(account_user(lane_id))
    uid = user.pw_uid
    if uid == 0 or user.pw_dir != str(paths.state) or user.pw_shell != "/usr/sbin/nologin":
        raise LaneRefused("invalid account user binding")
    if os.geteuid() != uid or os.environ.get("LEAFHFT_ACCOUNT_LANE_ID") != lane_id:
        raise LaneRefused("invalid runtime identity")
    directory = Path(os.environ.get("CREDENTIALS_DIRECTORY", ""))
    allowed = (Path("/run/credentials") / paths.unit,
               Path("/run/credentials") / ("leafhft-account-push@" + lane_id + ".service"))
    if directory not in allowed:
        raise LaneRefused("invalid credential source")
    # For a non-root service systemd normally exposes a credential as
    # root:root 0440 inside an id-mapped private mount. Some versions hand it
    # to the service account as 0400. Accept only those exact private shapes.
    def credential_file(name):
        return read_credential_copy(directory, name, uid, user.pw_gid)
    config = credential_file("config")
    check_scope(config, config)
    if config["lane_id"] != lane_id:
        raise LaneRefused("account scope mismatch")
    for path in (paths.state, paths.runtime):
        info = path.stat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != uid or stat.S_IMODE(info.st_mode) != 0o700:
            raise LaneRefused("unsafe account directory")
    return paths, config, credential_file


def require_live(config, credential, authorization, dry_run, *, now=None, runtime_paths=None):
    now = int(time.time()) if now is None else now
    check_scope(config, config)
    if not isinstance(config.get("fingerprint"), str) or not re.fullmatch(r"[0-9a-f]{64}", config["fingerprint"]):
        raise LaneRefused("invalid credential fingerprint")
    for doc in (credential, authorization, dry_run):
        check_scope(doc, config)
        if doc.get("fingerprint") != config.get("fingerprint"):
            raise LaneRefused("credential generation mismatch")
    identifier(config.get("dry_run_id"))
    if dry_run.get("request_id") != config["dry_run_id"]:
        raise LaneRefused("dry run generation mismatch")
    if (config.get("mode") != "live" or credential.get("validated") is not True
            or authorization.get("approved") is not True or dry_run.get("ok") is not True
            or type(dry_run.get("order_placement_calls")) is not int or dry_run["order_placement_calls"] != 0
            or dry_run.get("symbols") != list(canonical_symbols())):
        raise LaneRefused("live prerequisites missing")
    expires = authorization.get("expires_at")
    if type(expires) is not int or (runtime_paths is None and not now < expires <= now + 86400):
        raise LaneRefused("approval expired")
    from .broker.account_live_budget import approval_binding
    expected = approval_binding(config, authorization.get("request_id"))
    if config.get("account_budget") != expected or authorization.get("account_budget") != expected:
        raise LaneRefused("account budget approval mismatch")
    if runtime_paths is not None:
        # Only the exact accepted activation replaces the request deadline.
        # All prerequisites still apply, and stop/revoke remove this authority.
        require_activation(runtime_paths, config, authorization)


def dry_book(symbol, state, binding):
    """Exercise the existing book accounting with an adapter that cannot send."""
    from .broker.kalshi_book import KalshiBook, KalshiLimits
    from .broker.kalshi_paper import PaperKalshiClient
    if symbol not in canonical_symbols():
        raise LaneRefused("unknown book")
    check_scope(binding, binding)
    if safe_path(state) != LanePaths(binding["lane_id"]).state:
        raise LaneRefused("account state mismatch")
    if activation_path(LanePaths(binding["lane_id"])).exists():
        raise LaneRefused("dry run has activation marker")
    request_id = identifier(binding.get("dry_run_id"))
    fingerprint = binding.get("fingerprint")
    if not isinstance(fingerprint, str) or not re.fullmatch(r"[0-9a-f]{64}", fingerprint):
        raise LaneRefused("invalid credential fingerprint")
    client = PaperKalshiClient(None, 500, fill_model="arrival")
    # Construct the canonical book; dry verification never invokes place_ioc_buy.
    book = KalshiBook(client, KalshiLimits.experiment(), cash_cents=500)
    allowed = book.can_open(50, 1) is None
    capped = book.can_open(101, 1) is not None
    book.halted = True
    killed = book.can_open(50, 1) is not None
    _private_lane_dir(state / "dry-books")
    ok = allowed and capped and killed and book.cash_cents == 500 and client.stats["attempts"] == 0
    write_private(state / "dry-books" / (symbol + ".json"),
                  {**scope(binding["tenant_id"], binding["lane_id"]), "symbol": symbol,
                   "request_id": request_id, "fingerprint": fingerprint, "ok": ok,
                   "order_placement_calls": client.stats["attempts"]})
    return 0 if ok else 2


def _regime_passthrough(environ) -> dict:
    """Carry only the exact root-owned per-lane promotion through environment filters."""
    try:
        if environ.get("LEAFHFT_ACCOUNT_RISK_REGIME") == "owner":
            return {"LEAFHFT_ACCOUNT_RISK_REGIME": "owner"}
    except Exception:
        pass
    return {}


def book_main(lane_id, symbol):
    refuse_if_parked_in_unit(lane_id)
    paths, config, read = load_runtime(lane_id)
    if symbol not in canonical_symbols() or safe_path(paths.state / "KILL").exists():
        raise LaneRefused("account book refused")
    directory = os.environ["CREDENTIALS_DIRECTORY"]
    regime_env = _regime_passthrough(os.environ)
    os.environ.clear()
    os.environ.update(PATH="/usr/bin:/bin", HOME=str(paths.state), LEAFHFT_LIVE="0",
                      LEAFHFT_STATE_DIR=str(paths.state), LEAFHFT_ACCOUNT_LANE_ID=lane_id,
                      LEAFHFT_ACCOUNT_RISK_ROOT=str(paths.state / "account-risk"),
                      CREDENTIALS_DIRECTORY=directory, **regime_env)
    try:
        evidence_dir = _private_lane_dir(paths.state / "engine-evidence")
    except (OSError, ValueError):
        print("account probe evidence directory unavailable", file=sys.stderr, flush=True)
    else:
        os.environ["LEAFHFT_ENGINE_EVIDENCE_DIR"] = str(evidence_dir)
    if config.get("mode") == "dry_run":
        if activation_path(paths).exists():
            raise LaneRefused("dry run has activation marker")
        return dry_book(symbol, paths.state, config)
    credential, authorization, dry = read("credential"), read("approval"), read("dry-run")
    require_live(config, credential, authorization, dry, runtime_paths=paths)
    _book_barrier(paths, config, authorization, symbol)
    _private_lane_dir(paths.state / "engine-lifecycle")
    os.environ.update(LEAFHFT_LIVE="1", LEAFHFT_KALSHI_KEY_ID=credential["key_id"],
                      LEAFHFT_EXECUTION_DOMAIN=execution_domain(lane_id),
                      LEAFHFT_KALSHI_PRIVATE_KEY_PEM=credential["private_key_pem"])
    try:
        if book_source(lane_id, symbol, read) == "shared":
            os.environ["LEAFHFT_BOOK_SOURCE"] = "shared"
        else:
            os.environ.pop("LEAFHFT_BOOK_SOURCE", None)
        from .cli import main as cli_main
        with live_cycle_guard(paths, config, authorization):
            return cli_main(live_arguments(paths, symbol, config))
    finally:
        os.environ.pop("LEAFHFT_KALSHI_KEY_ID", None)
        os.environ.pop("LEAFHFT_KALSHI_PRIVATE_KEY_PEM", None)
        os.environ.pop("LEAFHFT_EXECUTION_DOMAIN", None)
        os.environ.pop("LEAFHFT_BOOK_SOURCE", None)
        os.environ["LEAFHFT_LIVE"] = "0"


def gold_book_main(lane_id):
    refuse_if_parked_in_unit(lane_id)
    paths, config, read = load_runtime(lane_id)
    if safe_path(paths.state / "KILL").exists():
        raise LaneRefused("account book refused")
    opt = gold_opt_in(lane_id, read)
    if opt is None:
        raise LaneRefused("gold opt-in required")
    regime_env = _regime_passthrough(os.environ)
    if regime_env.get("LEAFHFT_ACCOUNT_RISK_REGIME") == "owner":
        raise LaneRefused("gold requires account regime")
    if config.get("mode") != "live":
        raise LaneRefused("gold requires live mode")
    credential, authorization, dry = read("credential"), read("approval"), read("dry-run")
    require_live(config, credential, authorization, dry, runtime_paths=paths)
    require_activation(paths, config, authorization)
    try:
        if canonical(_activation_read(activation_path(paths, receipt=True))) != canonical(
                live_receipt(config, authorization, activated=True)):
            raise LaneRefused("gold requires activation receipt")
    except (OSError, ValueError, TypeError):
        raise LaneRefused("gold requires activation receipt") from None
    directory = os.environ["CREDENTIALS_DIRECTORY"]
    os.environ.clear()
    os.environ.update(PATH="/usr/bin:/bin", HOME=str(paths.state), LEAFHFT_LIVE="0",
                      LEAFHFT_STATE_DIR=str(paths.state), LEAFHFT_ACCOUNT_LANE_ID=lane_id,
                      LEAFHFT_ACCOUNT_RISK_ROOT=str(paths.state / "account-risk"),
                      CREDENTIALS_DIRECTORY=directory, **regime_env)
    try:
        evidence_dir = _private_lane_dir(paths.state / "engine-evidence")
    except (OSError, ValueError):
        print("account probe evidence directory unavailable", file=sys.stderr, flush=True)
    else:
        os.environ["LEAFHFT_ENGINE_EVIDENCE_DIR"] = str(evidence_dir)
    from .build import build_identity
    identity = build_identity()
    sha = identity.get("git_sha")
    if not isinstance(sha, str) or not re.fullmatch(r"[0-9a-fA-F]{40}", sha) or identity.get("dirty"):
        raise LaneRefused("gold requires clean build")
    try:
        os.environ.update(LEAFHFT_LIVE="1", LEAFHFT_KALSHI_KEY_ID=credential["key_id"],
                          LEAFHFT_KALSHI_PRIVATE_KEY_PEM=credential["private_key_pem"],
                          LEAFHFT_EXECUTION_DOMAIN=execution_domain(lane_id),
                          LEAFHFT_RISK_REGIME="account", LEAFHFT_BUILD_SHA=sha,
                          LEAFHFT_BUILD_DIRTY="0")
        gold_dir = _private_lane_dir(paths.state / "gold")
        ack_dir = _private_lane_dir(gold_dir / "ack")
        run_dir = _private_lane_dir(gold_dir / "run")
        from .gold_live_main import run_lane
        with live_cycle_guard(paths, config, authorization):
            return run_lane(lane_id=lane_id, ack_dir=ack_dir, run_dir=run_dir,
                            authority_path=PROJECTION_ROOT / lane_id / "gold-entry-arm.json",
                            stake_usd=Decimal(opt["stake_usd"]), seconds=WINDOW_RENEW_MIN_S,
                            fixed_count=Decimal(opt["fixed_count"]))
    finally:
        os.environ.pop("LEAFHFT_KALSHI_KEY_ID", None)
        os.environ.pop("LEAFHFT_KALSHI_PRIVATE_KEY_PEM", None)
        os.environ.pop("LEAFHFT_EXECUTION_DOMAIN", None)
        os.environ.pop("LEAFHFT_BUILD_SHA", None)
        os.environ.pop("LEAFHFT_BUILD_DIRTY", None)
        os.environ.pop("LEAFHFT_RISK_REGIME", None)
        os.environ["LEAFHFT_LIVE"] = "0"


def _gold_books_ready(paths, config, authorization, symbols, children):
    """One nonblocking readiness snapshot tied to this supervisor's book processes."""
    try:
        marker = require_activation(paths, config, authorization)
        for symbol, child in zip(symbols, children):
            ready = parse(read_private(paths.state / "live-books" / (symbol + ".json"),
                                       owner=os.geteuid() if os.name == "posix" else 0))
            expected = {**marker, "symbol": symbol, "pid": child.pid,
                        "ready": True, "order_placement_calls": 0}
            if canonical(ready) != canonical(expected):
                return False
        return True
    except (OSError, ValueError, TypeError):
        return False


def supervise(lane_id):
    refuse_if_parked_in_unit(lane_id)
    paths, config, read = load_runtime(lane_id)
    symbols = canonical_symbols()
    if config.get("mode") not in ("dry_run", "live"):
        raise LaneRefused("invalid mode")
    if config["mode"] == "live":
        require_live(config, read("credential"), read("approval"), read("dry-run"), runtime_paths=paths)
    elif activation_path(paths).exists():
        raise LaneRefused("dry run has activation marker")
    if safe_path(paths.state / "KILL").exists():
        raise LaneRefused("account stopped")
    children = []
    gold_child = None
    gold_state = None
    gold_code = None
    gold_status_failed = False
    gold_exit_written = False

    def write_gold_status(state, code):
        nonlocal gold_status_failed, gold_exit_written
        if state is None or gold_status_failed or gold_exit_written:
            return
        try:
            write_private(paths.state / "gold-status.json", {**scope(config["tenant_id"], lane_id),
                "pid": gold_child.pid if gold_child is not None else None,
                "state": state, "code": code, "updated_at": int(time.time())})
        except OSError:
            gold_status_failed = True
            record_refusal(lane_id, "gold", 2, LaneRefused("gold status write failed"))
        else:
            gold_exit_written = state == "exited"

    if config["mode"] == "live":
        try:
            if gold_opt_in(lane_id, read) is not None:
                gold_state = "waiting"
        except LaneRefused as exc:
            record_refusal(lane_id, "gold", 2, exc)
            gold_state, gold_code = "exited", 2
    stopped = False
    def stop(*_):
        nonlocal stopped
        stopped = True
    # A second supervisor cannot launch while the first is reaping its books.
    with exclusive(paths.runtime / "supervisor.lock"):
        previous = {}
        try:
            for sig in (signal.SIGTERM, signal.SIGINT):
                previous[sig] = signal.signal(sig, stop)
            prepare_state(paths, config, live=config["mode"] == "live")
            env = {"PATH": "/usr/bin:/bin", "HOME": str(paths.state), "PYTHONUNBUFFERED": "1",
                   "LEAFHFT_ACCOUNT_LANE_ID": lane_id,
                   "CREDENTIALS_DIRECTORY": os.environ["CREDENTIALS_DIRECTORY"],
                   **_regime_passthrough(os.environ)}
            started = time.monotonic()
            first_clean_exit = None
            for symbol in symbols:
                if stopped or safe_path(paths.state / "KILL").exists():
                    raise LaneRefused("account stopped")
                if config["mode"] == "live":
                    require_activation(paths, config, read("approval"))
                children.append(subprocess.Popen([PYTHON, "-m", "leafhft.account_lane_agent", "book", lane_id, symbol],
                    env=env, cwd="/opt/leafhft", stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
            while not stopped:
                codes = [child.poll() for child in children]
                write_private(paths.state / "status.json", {**scope(config["tenant_id"], lane_id),
                    "mode": config["mode"], "running_books": sum(c is None for c in codes),
                    "book_pids": {symbol: child.pid for symbol, child in zip(symbols, children)},
                    "account_budget": config.get("account_budget"),
                    "symbols": list(symbols), "updated_at": int(time.time()),
                    **registry_projection_status(paths), **probe_bindings_status(paths)})
                failed = next(((symbol, code) for symbol, code in zip(symbols, codes)
                               if code not in (None, 0)), None)
                if failed is not None:
                    symbol, code = failed
                    record_refusal(lane_id, "run", 2, f"book {symbol} exited with code {code}")
                if config["mode"] == "dry_run" and all(c is not None for c in codes):
                    return 0 if all(c == 0 for c in codes) else 2
                if config["mode"] == "live" and any(c is not None for c in codes):
                    # Renew only when every book ended cleanly after its full window; anything else stays down.
                    now = time.monotonic()
                    if any(c not in (None, 0) for c in codes) or now - started < WINDOW_RENEW_MIN_S:
                        return 2
                    if all(c == 0 for c in codes):
                        if stopped or safe_path(paths.state / "KILL").exists():
                            return 2
                        return WINDOW_RENEW_EXIT
                    if first_clean_exit is None:
                        first_clean_exit = now
                    elif now - first_clean_exit >= WINDOW_RENEW_GRACE_S:
                        return 2
                if any(c is not None and c != 0 for c in codes):
                    return 2
                if safe_path(paths.state / "KILL").exists():
                    return 2
                if config["mode"] == "live":
                    require_live(config, read("credential"), read("approval"), read("dry-run"), runtime_paths=paths)
                if gold_state == "waiting" and all(c is None for c in codes):
                    authorization = read("approval")
                    if _gold_books_ready(paths, config, authorization, symbols, children):
                        try:
                            if canonical(_activation_read(activation_path(paths, receipt=True))) != canonical(
                                    live_receipt(config, authorization, activated=True)):
                                raise LaneRefused("gold activation receipt mismatch")
                        except FileNotFoundError:
                            pass  # The root agent has not published the receipt yet.
                        except (OSError, ValueError, TypeError):
                            gold_state, gold_code = "exited", 2
                            record_refusal(lane_id, "gold", 2, LaneRefused("gold activation receipt mismatch"))
                        else:
                            try:
                                gold_child = subprocess.Popen(
                                    [PYTHON, "-m", "leafhft.account_lane_agent", "gold", lane_id],
                                    env=env, cwd="/opt/leafhft", stdin=subprocess.DEVNULL,
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                                gold_state = "running"
                            except OSError:
                                gold_state, gold_code = "exited", 2
                                record_refusal(lane_id, "gold", 2, LaneRefused("gold launch failed"))
                if gold_state == "running":
                    gold_code = gold_child.poll()
                    if gold_code is not None:
                        gold_state = "exited"
                        if gold_code != 0:
                            record_refusal(lane_id, "gold", gold_code,
                                           f"gold exited with code {gold_code}")
                write_gold_status(gold_state, gold_code)
                time.sleep(0.25)
            return 2
        finally:
            try:
                all_children = children + ([gold_child] if gold_child is not None else [])
                for child in all_children:
                    if child.poll() is None:
                        child.terminate()
                deadline = time.monotonic() + 15
                for child in all_children:
                    try:
                        child.wait(timeout=max(0.01, deadline - time.monotonic()))
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait()
                if gold_state is not None:
                    write_gold_status("exited", gold_child.poll() if gold_child is not None else gold_code)
                write_private(paths.state / "status.json", {**scope(config["tenant_id"], lane_id),
                    "mode": config["mode"], "running_books": 0, "symbols": list(symbols), "updated_at": int(time.time()),
                    **registry_projection_status(paths), **probe_bindings_status(paths)})
            finally:
                for sig, handler in previous.items():
                    signal.signal(sig, handler)


def systemctl(action, unit):
    if action not in ("start", "stop", "is-active", "enable", "disable", "is-enabled") or not re.fullmatch(r"leafhft-account(?:-push)?@[0-9a-f-]+\.(?:service|timer)", unit):
        raise LaneRefused("invalid unit action")
    if action in ("enable", "disable", "is-enabled") and not re.fullmatch(r"leafhft-account@" + UUID.pattern + r"\.service", unit):
        raise LaneRefused("invalid unit action")
    result = subprocess.run(["/usr/bin/systemctl", action, unit], stdin=subprocess.DEVNULL,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=90)
    if action not in ("is-active", "is-enabled") and result.returncode != 0:
        raise LaneRefused("unit action failed")
    if action == "is-active" and result.returncode not in (0, 3):
        raise LaneRefused("unit state unavailable")
    if action == "is-enabled" and result.returncode not in (0, 1):
        raise LaneRefused("unit state unavailable")
    return result.returncode == 0


def reconcile_boot(binding):
    """Only an accepted live activation may bring its supervisor back at boot."""
    paths = LanePaths(binding["lane_id"])
    try:
        require_lane_unparked(paths.lane_id)
    except LaneRefused as error:
        if str(error) == "owner_lane_parked":
            stop_parked_lane(paths.lane_id)
        raise
    desired = False
    try:
        config = parse(read_private(paths.config / "config.json"))
        check_scope(config, binding)
        authorization = parse(read_private(paths.config / "approval.json"))
        check_scope(authorization, binding)
        require_activation(paths, config, authorization)
        desired = True
    except (OSError, ValueError, KeyError, TypeError):
        pass
    if systemctl("is-enabled", paths.unit) != desired:
        systemctl("enable" if desired else "disable", paths.unit)


def stop_parked_lane(lane_id):
    """Root enforcement also covers parked lanes without a current binding."""
    paths = LanePaths(lane_id)
    try:
        remove_activation(paths)
        safe_path(paths.config / "approval.json").unlink(missing_ok=True)
    finally:
        try:
            if systemctl("is-active", paths.unit):
                systemctl("stop", paths.unit)
        finally:
            try:
                systemctl("disable", paths.unit)
            finally:
                record_owner_lane_refusal(lane_id, "owner_lane_parked")


def unit_succeeded(paths):
    result = subprocess.run(["/usr/bin/systemctl", "show", paths.unit,
                             "--property=Result,ExecMainStatus", "--no-pager"],
                            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL, timeout=10, text=True)
    if result.returncode != 0 or set(result.stdout.splitlines()) != {"Result=success", "ExecMainStatus=0"}:
        raise LaneRefused("account supervisor failed")


def provision(binding):
    import pwd
    paths = LanePaths(binding["lane_id"])
    name = account_user(paths.lane_id)
    try:
        user = pwd.getpwnam(name)
    except KeyError:
        subprocess.run(["/usr/sbin/useradd", "--system", "--no-create-home", "--user-group",
                        "--shell", "/usr/sbin/nologin", "--home-dir", str(paths.state), name],
                       check=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        user = pwd.getpwnam(name)
    if user.pw_uid == 0 or user.pw_dir != str(paths.state) or user.pw_shell != "/usr/sbin/nologin":
        raise LaneRefused("invalid account user")
    for root in (CONFIG_ROOT, STATE_ROOT, RUN_ROOT):
        safe_path(root).mkdir(mode=0o711, exist_ok=True)
        info = root.stat()
        if info.st_uid != 0 or stat.S_IMODE(info.st_mode) & 0o022:
            raise LaneRefused("unsafe account root")
    ensure_private_dir(safe_path(paths.config), owner=0, refusal=LaneRefused("unsafe config directory"))
    for directory in (paths.state, paths.runtime):
        directory.mkdir(mode=0o700, exist_ok=True)
        if directory.stat().st_uid not in (0, user.pw_uid):
            raise LaneRefused("account directory belongs to another user")
        os.chown(directory, user.pw_uid, user.pw_gid)
        os.chmod(directory, 0o700)
    # Root-owned per-instance identity overrides keep the templates portable and
    # the account principals short. A missing override leaves the unit unable to run.
    for unit in (paths.unit, "leafhft-account-push@" + paths.lane_id + ".service"):
        directory = safe_path(Path("/etc/systemd/system") / (unit + ".d"))
        directory.mkdir(mode=0o755, exist_ok=True)
        if directory.stat().st_uid != 0 or stat.S_IMODE(directory.stat().st_mode) & 0o022:
            raise LaneRefused("unsafe account unit directory")
        write_private(directory / "10-account-user.conf",
                      ("[Service]\nUser=" + name + "\nGroup=" + name + "\n").encode())
    subprocess.run(["/usr/bin/systemctl", "daemon-reload"], check=True,
                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
    return paths


def validate_command(binding, command):
    check_scope(binding, binding)
    check_scope(command, binding)
    action = command.get("action")
    keys = set(scope(binding["tenant_id"], binding["lane_id"])) | {"id", "sequence", "action", "expires_at"}
    keys |= {"envelope"} if action == "enroll" else {"approved"} if action == "start" else set()
    if action == "start" and "coordinated_mode" in command:
        keys.add("coordinated_mode")
        coordinated_options(command)
    if action in ("enroll", "start") and "credential_revision" in command:
        keys.add("credential_revision")
        if (type(command["credential_revision"]) is not str
                or not re.fullmatch(r"[1-9][0-9]{0,15}", command["credential_revision"])):
            raise LaneRefused("credential revision refused")
    if action == "activate":
        keys |= {"revision", "start_request_id"}
    if set(command) != keys or action not in ("enroll", "dry_run", "start", "activate", "stop", "status"):
        raise LaneRefused("invalid account command")
    if action == "start" and command.get("approved") is not True:
        raise LaneRefused("live approval required")
    identifier(command["id"])
    if type(command["sequence"]) is not int or not 1 <= command["sequence"] < 2**53:
        raise LaneRefused("invalid command sequence")
    now = int(time.time())
    if type(command["expires_at"]) is not int or not now < command["expires_at"] <= now + 86400:
        raise LaneRefused("stale account command")
    return action


def _live_ready(paths, config, authorization):
    import pwd
    uid = pwd.getpwnam(account_user(paths.lane_id)).pw_uid
    marker = require_activation(paths, config, authorization)
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        require_activation(paths, config, authorization)
        if not systemctl("is-active", paths.unit):
            raise LaneRefused("live unit inactive")
        try:
            status = parse(read_private(paths.state / "status.json", owner=uid))
            check_scope(status, config)
            pids = status.get("book_pids")
            if (status.get("mode") != "live" or type(status.get("running_books")) is not int
                    or status["running_books"] != 14 or status.get("symbols") != list(canonical_symbols())
                    or status.get("account_budget") != config["account_budget"]
                    or type(pids) is not dict or set(pids) != set(canonical_symbols())
                    or any(type(pid) is not int or pid <= 0 for pid in pids.values())
                    or len(set(pids.values())) != 14):
                raise FileNotFoundError
            for symbol in canonical_symbols():
                ready = parse(read_private(paths.state / "live-books" / (symbol + ".json"), owner=uid))
                expected = {**marker, "symbol": symbol, "pid": pids[symbol],
                            "ready": True, "order_placement_calls": 0}
                if canonical(ready) != canonical(expected):
                    raise LaneRefused("live book readiness mismatch")
            budget = account_budget(paths, config)
            snapshot = parse(read_private(budget.path, owner=uid))
            budget._validate(snapshot)
            if snapshot["total_claims"] != config.get("prior_budget_claims", 0):
                raise LaneRefused("live orders before readiness")
            return
        except FileNotFoundError:
            time.sleep(0.1)
    raise LaneRefused("live readiness timed out")


def _activate(binding, command, paths):
    require_lane_unparked(paths.lane_id)
    from .account_lane_sync import activation_authorized
    activation_authorized(binding, command)
    config = parse(read_private(paths.config / "config.json"))
    authorization = parse(read_private(paths.config / "approval.json"))
    credential = parse(read_private(paths.config / "credential.json"))
    dry = parse(read_private(paths.config / "dry-run.json"))
    check_scope(config, binding)
    require_live(config, credential, authorization, dry)
    if authorization["request_id"] != command["start_request_id"]:
        raise LaneRefused("activation generation mismatch")
    staged = parse(read_private(paths.config / "staged-live.json"))
    if canonical(staged) != canonical({"config": config, "approval": authorization}):
        raise LaneRefused("staged live configuration mismatch")
    expected = live_receipt(config, authorization, activated=True)
    if safe_path(paths.state / "KILL").exists():
        raise LaneRefused("account stopped")
    budget = account_budget(paths, config)
    receipt_path = activation_path(paths, receipt=True)
    if receipt_path.exists():
        require_activation(paths, config, authorization)
        if canonical(_activation_read(receipt_path)) != canonical(expected):
            raise LaneRefused("activation receipt mismatch")
        # A completed command never starts the unit a second time.
        return expected
    if budget.path.exists():
        import pwd
        uid = pwd.getpwnam(account_user(paths.lane_id)).pw_uid
        budget._validate(parse(read_private(budget.path, owner=uid)))
    elif budget.path.with_suffix(".initialized").exists():
        raise LaneRefused("account budget state missing")
    marker_path = activation_path(paths)
    active = systemctl("is-active", paths.unit)
    if marker_path.exists():
        require_activation(paths, config, authorization)
    else:
        if active:
            raise LaneRefused("stop account before activation")
        _activation_write(marker_path, activation_document(config, authorization))
    try:
        if not active:
            # Old child receipts cannot satisfy readiness for a new process tree.
            safe_path(paths.state / "status.json").unlink(missing_ok=True)
            for symbol in canonical_symbols():
                safe_path(paths.state / "live-books" / (symbol + ".json")).unlink(missing_ok=True)
            require_activation(paths, config, authorization)
            systemctl("start", paths.unit)
        _live_ready(paths, config, authorization)
        require_activation(paths, config, authorization)
        _activation_write(receipt_path, expected)
    except Exception:
        try:
            remove_activation(paths)
            write_private(paths.config / "approval.json", {**binding, "approved": False})
            write_private(paths.config / "config.json", {**config, "mode": "dry_run"})
        finally:
            systemctl("stop", paths.unit)
        raise LaneRefused("account start failed") from None
    return expected


def probe_bindings_path(paths):
    """Root-owned bindings, outside the lane's writable state tree."""
    return safe_path(PROJECTION_ROOT / identifier(paths.lane_id) / "probe-bindings.json")


def probe_hosting_paths(paths):
    """The one source for the probe paths a book's argv carries, validate_live_arguments pins and
    prepare_state digests into each LIVE-ACK; any drift between them strands every tenant book."""
    return {"probe_bindings": str(probe_bindings_path(paths)),
            "lifecycle_dir": str(paths.state / "engine-lifecycle"),
            "engine_registry": str(registry_projection_path(paths))}


def execution_domain(lane_id):
    """The domain book_main exports to cmd_live and prepare_state digests; one value for both."""
    return "account-lane:" + identifier(lane_id)


def registry_projection_path(paths):
    """Configured under PROJECTION_ROOT, never derived from the lane root the tenant owns."""
    return safe_path(PROJECTION_ROOT / identifier(paths.lane_id) / "engine-registry" / "projection.json")


def registry_projection_floor_path(paths):
    """PROJECTION_ROOT/<lane>/floor.json, beside the lane's projection directory in the root tree."""
    return safe_path(PROJECTION_ROOT / identifier(paths.lane_id) / PROJECTION_FLOOR_FILE)


def projection_floor_bytes(lane_id, generation):
    """The one floor encoding: the provisioner writes it, parse_projection_floor reads it."""
    if type(generation) is not int or not 0 <= generation < 2**53:
        raise LaneRefused("invalid projection floor")
    return canonical({"lane_id": identifier(lane_id), "generation": generation})


def parse_projection_floor(data, lane_id):
    """The floor generation in `data` for `lane_id`; raises LaneRefused on anything else (bounded,
    exact keys, the lane's own id), so a reader fails closed rather than accepting any generation."""
    if type(data) is not bytes or len(data) > PROJECTION_FLOOR_MAX:
        raise LaneRefused("invalid projection floor")
    try:
        doc = parse(data)
    except Exception:
        raise LaneRefused("invalid projection floor") from None
    if (type(doc) is not dict or set(doc) != {"lane_id", "generation"} or doc["lane_id"] != lane_id
            or type(doc["generation"]) is not int or not 0 <= doc["generation"] < 2**53):
        raise LaneRefused("invalid projection floor")
    return doc["generation"]


def _projection_floor(paths):
    """(floor, None) from the provisioner's root-owned floor.json, else (None, static reason):
    `projection_floor_missing` when absent (never zero: a projection without its floor is refused),
    `unsafe` or `projection_floor_invalid`. Read on every call and never written here."""
    path = registry_projection_floor_path(paths)
    try:
        info = _projection_tree_safe(path, owned=2)
    except FileNotFoundError:
        return None, "projection_floor_missing"
    if info is None:
        return None, "unsafe"
    try:
        with open(path, "rb") as stream:
            return parse_projection_floor(stream.read(PROJECTION_FLOOR_MAX + 1), paths.lane_id), None
    except FileNotFoundError:
        return None, "projection_floor_missing"
    except LaneRefused:
        return None, "projection_floor_invalid"


def _projection_tree_safe(path, owned=3):
    """`path` a root-owned 0444 regular file, its owned directories root-owned and
    no ancestor above them a non-root user owns or may rename entries in (one lstat per component).
    The projection has three owned levels (engine-registry, <lane>, root), the floor two."""
    info = os.lstat(path)
    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != PROJECTION_OWNER
            or (os.name == "posix" and stat.S_IMODE(info.st_mode) != 0o444)):
        return None
    for depth, part in enumerate(path.parents):
        level = os.lstat(part)
        if not stat.S_ISDIR(level.st_mode):
            return None
        if depth < owned:
            lane_level = depth == owned - 2
            if level.st_uid != PROJECTION_OWNER or (os.name == "posix" and (
                    not lane_dir_mode_ok(level, part.name) if lane_level
                    else stat.S_IMODE(level.st_mode) != 0o755)):
                return None
        elif os.name == "posix" and (level.st_uid not in (0, PROJECTION_OWNER)
                                     or (level.st_mode & 0o022 and not level.st_mode & stat.S_ISVTX)):
            return None
    return info


def _projection_fingerprint(path):
    """sha256 of the projection's bytes, one bounded read (the reader refuses anything larger)."""
    from .engine_registry import MAX_REGISTRY_BYTES
    with open(path, "rb") as stream:
        return hashlib.sha256(stream.read(MAX_REGISTRY_BYTES + 1)).digest()


def lane_projection(paths):
    """(reader, None, mtime) for the lane's accepted projection, else (None, static reason, None).
    The stat-cached RegistryProjection is monotonic from the provisioner's root-owned floor: a
    generation below it (or below the highest this process accepted) is `projection_replayed` and
    never applied; a projection whose floor is missing is `projection_floor_missing`. The cached reader
    is rebuilt (at that same high-water mark) whenever the file's bytes differ from the ones it was
    built against, so a replay the stat key cannot see is still refused. Never raises."""
    try:
        path = registry_projection_path(paths)
        try:
            info = _projection_tree_safe(path)
        except FileNotFoundError:
            return None, "absent", None
        if info is None:
            return None, "unsafe", None
        floor, reason = _projection_floor(paths)
        if reason is not None:
            return None, reason, None
        fingerprint = _projection_fingerprint(path)
        reader = _PROJECTION_READERS.get(paths.lane_id)
        same_file = reader is not None and reader.path == os.fspath(path)
        if (not same_file or (reader.floor or 0) < floor
                or _PROJECTION_FINGERPRINTS.get(paths.lane_id) != fingerprint):
            from .engine_registry import RegistryProjection
            if len(_PROJECTION_READERS) >= 256:
                _PROJECTION_READERS.clear()
                _PROJECTION_FINGERPRINTS.clear()
            # A rebuild keeps the highest generation this process accepted: never below the floor,
            # never below what the previous reader already applied, so a replay stays refused.
            high = max(floor, reader.floor or 0) if same_file else floor
            reader = _PROJECTION_READERS[paths.lane_id] = RegistryProjection(path, min_generation=high)
            _PROJECTION_FINGERPRINTS[paths.lane_id] = fingerprint
        reader.exit_only("account-lane:" + paths.lane_id)
        if reader.error == "projection_replayed":
            return None, "projection_replayed", None
        if reader.generation is None:
            return None, "invalid", None
        return reader, None, info.st_mtime
    except Exception:
        return None, "unreadable", None


def probe_bindings_status(paths):
    """Configured counts, not a claim that running books reloaded their bindings. Stat-cached like
    registry_projection_status: the supervisor ticks 4 times a second, so each call costs one stat
    and the bounded read, decode and sha256 run only when (st_mtime_ns, st_ino, st_size) changes.
    The cached dict is shared; callers only serialize it."""
    try:
        path = probe_bindings_path(paths)
        cached = _BINDINGS_STATUS.get(paths.lane_id)
        if cached is not None and cached[0] == _bindings_key(path, os.stat(path)):
            return cached[1]
        with open(path, "rb") as stream:
            key = _bindings_key(path, os.fstat(stream.fileno()))
            payload = stream.read(_probe_bindings.MAX_FILE_BYTES + 1)
        try:
            if len(payload) > _probe_bindings.MAX_FILE_BYTES:
                raise ValueError("oversized bindings")
            bindings = _probe_bindings._decode(payload)
            status = {"probe_bindings": {"digest": hashlib.sha256(payload).hexdigest(),
                      "probe_counts": {symbol: len(bindings.engines_for(symbol)) for symbol in canonical_symbols()}},
                      "probe_bindings_reason": None}
        except Exception:
            status = {"probe_bindings": None, "probe_bindings_reason": "invalid"}
        if len(_BINDINGS_STATUS) >= 256:
            _BINDINGS_STATUS.clear()
        _BINDINGS_STATUS[paths.lane_id] = (key, status)
        return status
    except FileNotFoundError:
        reason = "absent"
    except OSError:
        reason = "unreadable"
    except Exception:
        reason = "invalid"
    return {"probe_bindings": None, "probe_bindings_reason": reason}


def _bindings_key(path, info):
    return os.fspath(path), info.st_mtime_ns, info.st_ino, info.st_size


def registry_projection_status(paths, *, now=None):
    """C14-A phase A, report-only: `registry_projection` {generation, digest, age_s} read from the
    lane's root-owned 0444 view through the stat-cached monotonic RegistryProjection gate (a re-parse
    only on change), or None with a static `registry_projection_reason` (absent, unsafe, invalid,
    projection_replayed, projection_floor_missing, projection_floor_invalid, unreadable). Never raises."""
    reader, reason, mtime = lane_projection(paths)
    if reader is None:
        return {"registry_projection": None, "registry_projection_reason": reason}
    now = time.time() if now is None else now
    return {"registry_projection": {"generation": reader.generation, "digest": reader.digest,
                                    "age_s": max(0, int(now - mtime))},
            "registry_projection_reason": None}


def _enabling_row(row):
    """A control row that turns entries on: book.configure enabled:true, or engine.configure with
    enabled:true (or null, `--enabled inherit`, on any engine but darkhorse, whose null writes false)."""
    kind, value = row.get("kind"), row.get("value")
    if type(value) is not dict or value.get("enabled", False) is False:
        return False
    if kind == "book.configure":
        return value.get("enabled") is True
    if kind == "engine.configure":
        return value.get("enabled") is True or value.get("engine_id") != "darkhorse"
    return False


def _projection_refusal(reason):
    """The static entries-refused reason for a lane_projection failure."""
    return "entries refused: " + (reason if reason.startswith("projection_") else "projection_" + reason)


def gate_control_row(lane_id, row, apply):
    """The lane agent's control applier. The registry's entry authority is ADDITIVE: every enabling
    row passes it first and a refusal is a rejected ack naming the registry reason (`apply` never
    runs); on a pass `apply`, push's ORIGINAL applier, runs unchanged with every check it makes (the
    exposure-role refusal, book validation, the gated-engine restriction). Non-enabling rows go to
    `apply` untouched."""
    if not _enabling_row(row):
        return apply()
    from . import account_lane_provision as provision
    rid = row.get("id")
    try:
        reader, reason, _ = lane_projection(LanePaths(lane_id))
        if reader is None:
            raise provision.ProvisionRefused(_projection_refusal(reason))
        provision.require_entry_authority(lane_id, projection=reader)
    except Exception as exc:
        note = str(exc) if isinstance(exc, provision.ProvisionRefused) else "entries refused: " + type(exc).__name__
        return {"id": rid, "state": "rejected", "note": note[:200]}
    return apply()


def enable_book_in_lane(lane_id, row):
    """push's book-enable step for a lane (it replaces _run_book_configure under the gate, as
    _run_book_lowering replaces the lowering: cli.main refuses book arguments under a lane id).
    Reached only after the original applier's checks passed; enable_entries repeats the authority
    check against the same projection. Returns a CompletedProcess shaped like the CLI's."""
    from . import account_lane_provision as provision
    symbol = row["value"]["book_id"]
    try:
        reader, reason, _ = lane_projection(LanePaths(lane_id))
        if reader is None:
            raise provision.ProvisionRefused(_projection_refusal(reason))
        before = symbol not in provision.lane_bindings(lane_id).get("disabled", [])
        doc = provision.enable_entries(lane_id, [symbol], projection=reader)
    except Exception as exc:
        note = str(exc) if isinstance(exc, provision.ProvisionRefused) else "entries refused: " + type(exc).__name__
        return subprocess.CompletedProcess([], 2, "", note[:200])
    return subprocess.CompletedProcess([], 0, f"book_enabled: {before} -> {symbol not in doc['disabled']}\n"
                                       "hot: book entry setting saved; selected readers apply it within 5 s\n", "")


def install_control_gate(lane_id):
    """Route push's per-row control applier through gate_control_row for this lane's push run, and
    its book-enable step (the CLI subprocess a lane cannot run) through enable_book_in_lane; every
    other step of the original applier is untouched. Returns the restore callable."""
    from . import push
    identifier(lane_id)
    inner = push._apply_control_row
    inner_book = push._run_book_configure

    def gated(row, path, cwd, verified_account_id=None):
        return gate_control_row(lane_id, row, lambda: inner(row, path, cwd, verified_account_id))

    def book_configure(row, cwd):
        if row["value"]["enabled"] is True:
            return enable_book_in_lane(lane_id, row)
        return inner_book(row, cwd)

    push._apply_control_row = gated
    push._run_book_configure = book_configure

    def restore():
        push._apply_control_row = inner
        push._run_book_configure = inner_book
    return restore


def process_command(binding, command):
    """Called under the root agent lock; binding comes from root-owned registry."""
    action = validate_command(binding, command)
    if action in ("start", "activate", "enroll", "dry_run"):
        require_lane_unparked(binding["lane_id"])
    paths = LanePaths(binding["lane_id"])
    base = scope(binding["tenant_id"], binding["lane_id"])
    if (paths.config / "config.json").exists():
        check_scope(parse(read_private(paths.config / "config.json")), binding)
    if action == "status":
        return {**base, "active": systemctl("is-active", paths.unit),
                **registry_projection_status(paths), **probe_bindings_status(paths)}
    if action == "stop":
        try:
            if paths.state.exists():
                write_private(paths.state / "KILL", b"account stopped\n")
            remove_activation(paths)
        finally:
            systemctl("stop", paths.unit)
            # Boot enablement is secondary: a disable failure never blocks the kill.
            try:
                systemctl("disable", paths.unit)
            except (LaneRefused, OSError, subprocess.SubprocessError):
                pass
        if paths.config.exists():
            write_private(paths.config / "approval.json", {**base, "approved": False})
        return {**base, "stopped": True}
    if action == "activate":
        return _activate(binding, command, paths)
    if systemctl("is-active", paths.unit):
        raise LaneRefused("stop account before changing it")
    if action == "enroll":
        if (paths.config / "config.json").exists():
            check_scope(parse(read_private(paths.config / "config.json")), binding)
        credential, fingerprint = decrypt_envelope(command["envelope"], binding,
            read_private(paths.config / "enrollment-private.pem"))
        old_config = parse(read_private(paths.config / "config.json")) if (paths.config / "config.json").exists() else None
        if old_config and old_config.get("fingerprint") != fingerprint:
            raise LaneRefused("use a new lane for a different account")
        # One shared root-owned registry, serialized by agent.lock. Never copy a key.
        index_path = AGENT_ROOT / "fingerprints.json"
        index = parse(read_private(index_path)) if index_path.exists() else {}
        if (type(index) is not dict or any(not re.fullmatch(r"[0-9a-f]{64}", key)
                or not isinstance(value, str) or not UUID.fullmatch(value) for key, value in index.items())):
            raise LaneRefused("invalid credential registry")
        if fingerprint in index and index[fingerprint] != paths.lane_id:
            raise LaneRefused("credential already bound")
        snapshot = validate_credential(credential)
        paths = provision(binding)
        index[fingerprint] = paths.lane_id
        write_private(index_path, index)
        write_private(paths.config / "credential.json", {**base, **credential, "fingerprint": fingerprint, "validated": True})
        remove_activation(paths)
        write_private(paths.config / "config.json", {**base, "mode": "dry_run", "fingerprint": fingerprint,
                      "credential_revision": command.get("credential_revision")})
        write_private(paths.config / "approval.json", {**base, "approved": False})
        write_private(paths.config / "dry-run.json", {**base, "ok": False})
        write_private(paths.config / "snapshot.json", {**base, **snapshot})
        # S7A L5a: the identity comes from this enrollment's own scope and validation, never from the
        # lane state dir (which the lane user writes).
        # Isolated: a failed identity write never changes this command's result or its other files.
        # The identity stays absent (tenant probes refuse) and the next agent pass's backfill retries.
        # The one journal line (type only) is written under the agent entry point alone, so an
        # in-process caller's stderr stays exactly as before.
        try:
            write_lane_identity(paths, binding, snapshot.get("validated_at"))
        except Exception as error:
            if isinstance(sys.stderr, _RefusalStderr):
                print("account lane identity unavailable: " + type(error).__name__, file=sys.stderr, flush=True)
        return {**base, "validated": True}
    config = parse(read_private(paths.config / "config.json"))
    check_scope(config, binding)
    if action == "dry_run":
        paths = provision(binding)
        remove_activation(paths)
        write_private(paths.config / "dry-run.json", {**base, "ok": False})
        write_private(paths.config / "approval.json", {**base, "approved": False})
        safe_path(paths.state / "KILL").unlink(missing_ok=True)
        config = {**config, "mode": "dry_run", "dry_run_id": command["id"]}
        write_private(paths.config / "config.json", config)
        # Type=exec start confirms launch. Wait for the entire supervisor to exit.
        systemctl("start", paths.unit)
        deadline = time.monotonic() + 120
        while systemctl("is-active", paths.unit) and time.monotonic() < deadline:
            time.sleep(0.5)
        if systemctl("is-active", paths.unit):
            systemctl("stop", paths.unit)
            raise LaneRefused("dry run timed out")
        unit_succeeded(paths)
        import pwd
        uid = pwd.getpwnam(account_user(paths.lane_id)).pw_uid
        for symbol in canonical_symbols():
            path = paths.state / "dry-books" / (symbol + ".json")
            receipt = parse(read_private(path, owner=uid))
            check_scope(receipt, binding)
            expected = {**base, "symbol": symbol, "request_id": command["id"],
                        "fingerprint": config["fingerprint"], "ok": True, "order_placement_calls": 0}
            if (receipt != expected or receipt.get("ok") is not True
                    or type(receipt.get("order_placement_calls")) is not int):
                raise LaneRefused("dry run failed")
        receipt = {**base, "ok": True, "fingerprint": config["fingerprint"],
                   "request_id": command["id"],
                   "symbols": list(SYMBOLS), "order_placement_calls": 0, "completed_at": int(time.time())}
        write_private(paths.config / "dry-run.json", receipt)
        return receipt
    coordinated = coordinated_options({**config, **(
        {"coordinated_mode": command["coordinated_mode"]} if "coordinated_mode" in command else {})})
    config = {**config, **coordinated}
    credential = parse(read_private(paths.config / "credential.json"))
    if (safe_path(paths.state / "KILL").exists() or activation_path(paths).exists()
            or config.get("credential_revision") != command.get("credential_revision")):
        raise LaneRefused("live staging refused")
    staged_path = paths.config / "staged-live.json"
    if staged_path.exists():
        staged = parse(read_private(staged_path))
        if staged.get("approval", {}).get("request_id") == command["id"]:
            saved = staged["config"]
            if coordinated_options(saved) != coordinated:
                raise LaneRefused("staged live configuration mismatch")
            if any(saved.get(k) != config.get(k) for k in (*base, "fingerprint", "dry_run_id", "credential_revision")):
                raise LaneRefused("staged live configuration mismatch")
            require_live(saved, credential, staged["approval"], parse(read_private(paths.config / "dry-run.json")))
            budget = account_budget(paths, saved)
            if budget.path.exists():
                import pwd
                uid = pwd.getpwnam(account_user(paths.lane_id)).pw_uid
                budget._validate(parse(read_private(budget.path, owner=uid)))
            elif budget.path.with_suffix(".initialized").exists():
                raise LaneRefused("account budget state missing")
            write_private(paths.config / "approval.json", staged["approval"])
            write_private(paths.config / "config.json", saved)
            return live_receipt(saved, staged["approval"])
    authorization = {**base, "approved": command.get("approved"), "expires_at": command["expires_at"],
                     "fingerprint": config["fingerprint"], "request_id": command["id"]}
    from .broker.account_live_budget import approval_binding
    budget_binding = approval_binding(config, command["id"])
    authorization["account_budget"] = budget_binding
    config = {**config, "mode": "live", "account_budget": budget_binding}
    require_live(config, credential, authorization, parse(read_private(paths.config / "dry-run.json")))
    # Fresh read-only validation before each live activation; the book retains its live gate.
    snapshot = validate_credential(credential)
    from .broker.account_live_budget import sizing_from_cash
    config = {**config, "account_sizing": sizing_from_cash(snapshot["balance_cents"])}
    budget_binding = approval_binding(config, command["id"])
    config["account_budget"] = authorization["account_budget"] = budget_binding
    config["prior_budget_claims"] = 0
    paths = provision(binding)
    write_private(paths.config / "snapshot.json", {**base, **snapshot})
    budget = account_budget(paths, config)
    if budget.path.exists():
        import pwd
        uid = pwd.getpwnam(account_user(paths.lane_id)).pw_uid
        prior = account_budget(paths, config, owner=uid).rollover()
        config["prior_budget_claims"] = prior["total_claims"]
    elif budget.path.with_suffix(".initialized").exists():
        raise LaneRefused("account budget state missing")
    write_private(staged_path, {"config": config, "approval": authorization})
    write_private(paths.config / "approval.json", authorization)
    write_private(paths.config / "config.json", config)
    return live_receipt(config, authorization)


def agent_once():
    if os.name != "posix" or os.geteuid() != 0:
        raise LaneRefused("root agent required")
    ensure_private_dir(safe_path(AGENT_ROOT), owner=0, refusal=LaneRefused("unsafe agent root"))
    with exclusive(AGENT_ROOT / "agent.lock"):
        parked = root_parked_lanes(persist=True)
        for lane_id in sorted(parked):
            try:
                stop_parked_lane(lane_id)
            except (LaneRefused, OSError, subprocess.SubprocessError):
                pass  # Retry every pass; the start guards remain closed.
        bindings = parse(read_private(CONFIG_ROOT / "bindings.json"))
        if type(bindings) is not list or len(bindings) > 256:
            raise LaneRefused("invalid bindings")
        seen = set()
        tenants = set()
        for binding in bindings:
            if type(binding) is not dict or set(binding) != set(scope(binding.get("tenant_id"), binding.get("lane_id"))):
                raise LaneRefused("invalid binding")
            check_scope(binding, binding)
            if binding["lane_id"] in seen or binding["tenant_id"] in tenants:
                raise LaneRefused("duplicate lane binding")
            seen.add(binding["lane_id"])
            tenants.add(binding["tenant_id"])
        if not safe_path(CONFIG_ROOT / "ENABLED").exists():
            for binding in bindings:
                remove_activation(LanePaths(binding["lane_id"]))
                systemctl("stop", LanePaths(binding["lane_id"]).unit)
                systemctl("stop", "leafhft-account-push@" + binding["lane_id"] + ".timer")
                systemctl("stop", "leafhft-account-push@" + binding["lane_id"] + ".service")
                try:
                    systemctl("disable", LanePaths(binding["lane_id"]).unit)
                except (LaneRefused, OSError, subprocess.SubprocessError):
                    continue
            return 0
        for binding in bindings:
            queue = safe_path(AGENT_ROOT / "queue" / binding["lane_id"])
            if not queue.exists():
                continue
            cursor_path = AGENT_ROOT / (binding["lane_id"] + ".cursor.json")
            cursor = parse(read_private(cursor_path)) if cursor_path.exists() else {
                **scope(binding["tenant_id"], binding["lane_id"]), "sequence": 0}
            check_scope(cursor, binding)
            if type(cursor.get("sequence")) is not int or not 0 <= cursor["sequence"] < 2**53:
                raise LaneRefused("invalid command cursor")
            sources = list(queue.glob("*.json"))
            if len(sources) > 4096:
                raise LaneRefused("account queue exceeds bounds")
            result_path = safe_path(AGENT_ROOT / "results" / binding["lane_id"])
            result_path.mkdir(mode=0o700, parents=True, exist_ok=True)
            pending = []
            for source in sources:
                identifier(source.stem)
                recovering = False
                if (result_path / source.name).exists():
                    previous = parse(read_private(result_path / source.name))
                    check_scope(previous, binding)
                    recovering = (previous.get("id") == source.stem and previous.get("ok") is False
                                  and previous.get("error") == "account command in progress")
                    if not recovering:
                        continue
                try:
                    doc = parse(read_private(source))
                    validate_command(binding, doc)
                    if doc["id"] != source.stem:
                        raise LaneRefused("request identity mismatch")
                    if recovering and doc["action"] not in ("start", "activate", "stop"):
                        continue
                except Exception:
                    write_private(result_path / source.name, {**scope(binding["tenant_id"], binding["lane_id"]),
                        "id": source.stem, "ok": False, "error": "account command refused"})
                    continue
                pending.append((doc["sequence"], source, doc, recovering))
            processed = 0
            for sequence, source, command, recovering in sorted(pending, key=lambda item: (item[0], item[1].name)):
                identifier(source.stem)
                target = result_path / source.name
                if target.exists() and not recovering:
                    continue
                if processed >= 32:
                    break
                processed += 1
                # Live phases and idempotent stops can recover an interrupted action.
                write_private(target, {**scope(binding["tenant_id"], binding["lane_id"]),
                    "id": source.stem, "ok": False, "error": "account command in progress"})
                try:
                    if command.get("id") != source.stem:
                        raise LaneRefused("request identity mismatch")
                    if sequence < cursor["sequence"] or (sequence == cursor["sequence"] and not recovering):
                        raise LaneRefused("account command replay refused")
                    cursor = {**scope(binding["tenant_id"], binding["lane_id"]), "sequence": sequence}
                    write_private(cursor_path, cursor)
                    result = process_command(binding, command)
                    result = {"ok": True, "result": result}
                except Exception as error:
                    reason = "owner_lane_parked" if type(error) is LaneRefused and str(error) == "owner_lane_parked" else "account command refused"
                    result = {"ok": False, "error": reason}
                write_private(target, {**scope(binding["tenant_id"], binding["lane_id"]), "id": source.stem, **result})
        for binding in bindings:
            try:
                reconcile_boot(binding)
            except (LaneRefused, OSError, subprocess.SubprocessError):
                pass
            try:
                ensure_lane_identity(binding)
            except (LaneRefused, OSError, ValueError, KeyError, TypeError):
                continue  # the lane's tenant probes stay refused until a later pass writes it
    return 0


def main(argv=None):
    captured = _RefusalStderr(sys.stderr)
    with redirect_stderr(captured):
        return _main(argv, captured)


def _main(argv, captured):
    usage_error = False
    parse_scope = argparse.Namespace(action=None, lane_id=None, symbol=None)

    class PrivateParser(argparse.ArgumentParser):
        def parse_known_args(self, args=None, namespace=None):
            namespace = argparse.Namespace() if namespace is None else namespace
            try:
                return super().parse_known_args(args, namespace)
            finally:
                # A subparser may fail before returning its partial namespace.
                # Retain parsed scope only for the best-effort private receipt.
                for name in ("action", "lane_id", "symbol"):
                    if hasattr(namespace, name):
                        setattr(parse_scope, name, getattr(namespace, name))

        def error(self, message):
            nonlocal usage_error
            usage_error = True
            raise LaneRefused("invalid account arguments")
    parser = PrivateParser(allow_abbrev=False)
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("agent")
    sub.add_parser("enrollment-key")
    for action in ("run", "push", "book", "gold", "gold-exclusive"):
        command = sub.add_parser(action)
        command.add_argument("lane_id")
        if action == "book":
            command.add_argument("symbol", choices=SYMBOLS)
    args = parse_scope
    parsed = False
    try:
        args = parser.parse_args(argv)
        parsed = True
        if args.action == "enrollment-key":
            print(json.dumps(enrollment_key()))
            return 0
        if args.action == "agent":
            return agent_once()
        with redirect_stderr(captured):
            if args.action == "run":
                result = supervise(args.lane_id)
            elif args.action == "book":
                result = book_main(args.lane_id, args.symbol)
            elif args.action == "gold":
                result = gold_book_main(args.lane_id)
            elif args.action == "gold-exclusive":
                result = gold_exclusive(args.lane_id)
            else:
                from .push import push_account_lane
                restore = install_control_gate(args.lane_id)
                try:
                    result = push_account_lane(args.lane_id)
                finally:
                    restore()
            code = 0 if result is None else int(result)
            symbol = getattr(args, "symbol", None)
            reason = captured.reason() or f"{args.action} exited with code {code}"
            possible_credential = False
            if (code == 0 or captured.possible_credential
                    or captured.recorded != (args.lane_id, args.action, symbol, code)):
                record_refusal(args.lane_id, args.action, code, reason, symbol)
            else:
                reason = captured.recorded_reason
                possible_credential = captured.recorded_possible_credential
            _journal_refusal(captured, args.action, code, reason,
                             possible_credential=possible_credential)
            return result
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
        if args.action in ("run", "push", "book", "gold", "gold-exclusive") and (parsed or code != 0):
            record_refusal(args.lane_id, args.action, code, captured.reason() or exc,
                           getattr(args, "symbol", None),
                           possible_credential=captured.possible_credential or _credential_indicator(str(exc)))
            _journal_refusal(captured, args.action, code, captured.reason() or exc,
                             "unclassified" if parsed else "usage",
                             possible_credential=_credential_indicator(str(exc)))
        raise
    except Exception as exc:
        if args.action in ("run", "push", "book", "gold", "gold-exclusive"):
            reason = _journal_reason(captured, args.action, 2, exc, "usage") if usage_error else exc
            record_refusal(args.lane_id, args.action, 2, reason, getattr(args, "symbol", None),
                           possible_credential=captured.possible_credential)
            if usage_error:
                print("Account lane operation refused.", file=captured.stream)
            else:
                _journal_refusal(captured, args.action, 2, exc)
        else:
            print("Account lane operation refused.", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
