"""Dashboard adapter for isolated Kashbot lanes with acknowledged live activation.

Only queue files hold sealed envelopes. The root-owned sync cursor records
staging, a bounded pending acknowledgement, then the server's exact acceptance.
An ambiguous POST retries that receipt without running the local agent again.
"""
from __future__ import annotations

import argparse
import base64
from contextlib import contextmanager
import os
from pathlib import Path
import re
import stat
import sys
import time
import urllib.request
from urllib.parse import urlsplit, urlunsplit
import uuid

from . import account_lane_agent as agent
from .private_dir import ensure_private_dir

MAX_BYTES = 65536
TIMEOUT = 10
WORK_PATH = "/api/kashbot/runner/work"
RESULTS = {"start_dry_run": "dry_run", "start_live": "live", "pause": "paused", "revoke": "revoked"}


class SyncRefused(ValueError):
    """Boundary errors contain static text only."""


def dashboard_url(value):
    try:
        if not isinstance(value, str) or not value or any(ord(c) <= 32 or ord(c) >= 127 for c in value):
            raise ValueError
        parts = urlsplit(value)
        if (parts.scheme != "https" or not parts.hostname or parts.username is not None
                or parts.password is not None or "?" in value or "#" in value
                or "\\" in value or parts.path not in ("", "/", WORK_PATH)):
            raise ValueError
        _ = parts.port
        return urlunsplit((parts.scheme, parts.netloc, WORK_PATH, "", ""))
    except Exception:
        raise SyncRefused("dashboard URL refused") from None


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise SyncRefused("dashboard redirect refused")


class DashboardClient:
    def __init__(self, url, token, *, opener=None, url_validator=dashboard_url):
        self.url = url_validator(url)
        if not isinstance(token, str) or not re.fullmatch(r"[A-Za-z0-9_-]{43,128}", token):
            raise SyncRefused("runner credential refused")
        self._token = token
        self._opener = opener if opener is not None else urllib.request.build_opener(NoRedirect())

    def _request(self, body=None):
        try:
            headers = {"Authorization": "Bearer " + self._token, "Accept": "application/json",
                       "User-Agent": "KashbotAccountSync/1.0"}
            if body is not None:
                headers["Content-Type"] = "application/json"
            request = urllib.request.Request(self.url, headers=headers,
                data=None if body is None else agent.canonical(body),
                method="GET" if body is None else "POST")
            with self._opener.open(request, timeout=TIMEOUT) as response:
                if (type(response.status) is not int or not 200 <= response.status < 300
                        or response.geturl() != self.url):
                    raise ValueError
                data = response.read(MAX_BYTES + 1)
                if len(data) > MAX_BYTES:
                    raise ValueError
                if response.headers.get_content_type() != "application/json":
                    raise ValueError
                doc = agent.parse(data)
                if body is None:
                    return doc
                if (type(doc) is not dict or set(doc) != {"success", "accepted"}
                        or doc["success"] is not True or doc["accepted"] is not True):
                    raise ValueError
                return doc
        except Exception:
            raise SyncRefused("dashboard request refused") from None

    def get_work(self):
        return self._request()

    def acknowledge(self, receipt):
        return self._request(receipt)


def _require_root():
    if os.name != "posix" or os.geteuid() != 0:
        raise SyncRefused("root sync required")


def _private_directory(path):
    return ensure_private_dir(agent.safe_path(path), owner=0, refusal=SyncRefused("unsafe sync directory"))


@contextmanager
def _lane_lock(path):
    import fcntl
    fd = os.open(agent.safe_path(path), os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_nlink != 1
                or stat.S_IMODE(info.st_mode) != 0o600):
            raise SyncRefused("unsafe sync lock")
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally:
        os.close(fd)


def _credentials(lane_id):
    expected = Path("/run/credentials") / ("leafhft-account-sync@" + lane_id + ".service")
    directory = Path(os.environ.get("CREDENTIALS_DIRECTORY", ""))
    if directory != expected:
        raise SyncRefused("sync credential source refused")
    values = []
    for name in ("dashboard-url", "runner-token"):
        path = agent.safe_path(directory / name)
        with agent.private_parent(path) as parent:
            fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        with os.fdopen(fd, "rb") as stream:
            info = os.fstat(stream.fileno())
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_nlink != 1
                    or stat.S_IMODE(info.st_mode) not in (0o400, 0o600) or info.st_size > 8192):
                raise SyncRefused("sync credential refused")
            data = stream.read(8193)
            if len(data) > 8192:
                raise SyncRefused("sync credential refused")
            values.append(data.decode("ascii").rstrip("\r\n"))
    return values


def _binding(lane_id):
    bindings = agent.parse(agent.read_private(agent.CONFIG_ROOT / "bindings.json"))
    if type(bindings) is not list or len(bindings) > 256:
        raise SyncRefused("lane binding refused")
    lanes, tenants, found = set(), set(), None
    for binding in bindings:
        if type(binding) is not dict:
            raise SyncRefused("lane binding refused")
        expected = agent.scope(binding.get("tenant_id"), binding.get("lane_id"))
        agent.check_scope(binding, expected)
        if set(binding) != set(expected) or binding["lane_id"] in lanes or binding["tenant_id"] in tenants:
            raise SyncRefused("lane binding refused")
        lanes.add(binding["lane_id"])
        tenants.add(binding["tenant_id"])
        if binding["lane_id"] == lane_id:
            found = binding
    if found is None:
        raise SyncRefused("lane binding refused")
    return found


def _revision(value, *, allow_zero=False):
    if (not isinstance(value, str) or not re.fullmatch(r"0|[1-9][0-9]{0,15}", value)
            or (value == "0" and not allow_zero) or int(value) * 2 >= 2**53):
        raise SyncRefused("dashboard revision refused")
    return int(value)


def _work(doc, binding):
    required = {"success", "tenant_id", "lane_id", "revision", "kill_requested", "live_enabled", "work"}
    if type(doc) is not dict or set(doc) != required or doc["success"] is not True:
        raise SyncRefused("dashboard work refused")
    if (agent.identifier(doc["lane_id"]) != binding["lane_id"]
            or agent.identifier(doc["tenant_id"]) != binding["tenant_id"]
            or type(doc["live_enabled"]) is not bool or type(doc["kill_requested"]) is not bool):
        raise SyncRefused("dashboard scope refused")
    _revision(doc["revision"], allow_zero=True)
    work = doc["work"]
    if doc["revision"] == "0" and (work is not None or doc["live_enabled"]):
        raise SyncRefused("dashboard idle state refused")
    if doc["live_enabled"] and (work is not None or doc["kill_requested"] or doc["revision"] == "0"):
        raise SyncRefused("dashboard live state refused")
    if work is not None:
        if (type(work) is not dict or set(work) != {"action", "credential_revision", "credential"}
                or type(work["action"]) is not str or work["action"] not in RESULTS):
            raise SyncRefused("dashboard work refused")
        _revision(doc["revision"])
        _revision(work["credential_revision"], allow_zero=work["action"] in ("pause", "revoke"))
        if doc["kill_requested"] != (work["action"] in ("pause", "revoke")):
            raise SyncRefused("dashboard kill state refused")
        if work["action"] == "start_dry_run":
            if (type(work["credential"]) is not dict or set(work["credential"]) !=
                    {"algorithm", "enrollment_key_id", "wrapped_key", "nonce", "ciphertext"}):
                raise SyncRefused("sealed credential refused")
        elif work["credential"] is not None:
            raise SyncRefused("unexpected sealed credential")
    return doc


def _envelope(sealed, lane_id):
    fields = {"enrollment_key_id", "algorithm", "wrapped_key", "nonce", "ciphertext"}
    if type(sealed) is not dict or set(sealed) != fields:
        raise SyncRefused("sealed credential refused")
    key_id = agent.identifier(sealed["enrollment_key_id"])
    if sealed["algorithm"] != agent.ALGORITHM or key_id != agent.lane_enrollment_key(lane_id)["enrollment_key_id"]:
        raise SyncRefused("enrollment key refused")
    decoded = {}
    for name in ("wrapped_key", "nonce", "ciphertext"):
        value = sealed[name]
        if not isinstance(value, str) or len(value) > 32768:
            raise SyncRefused("sealed credential refused")
        try:
            decoded[name] = base64.b64decode(value, validate=True)
        except Exception:
            raise SyncRefused("sealed credential refused") from None
    if (not 256 <= len(decoded["wrapped_key"]) <= 1024 or len(decoded["nonce"]) != 12
            or not 16 <= len(decoded["ciphertext"]) <= 24576):
        raise SyncRefused("sealed credential refused")
    return {"version": 1, **{k: sealed[k] for k in fields - {"enrollment_key_id"}}}


def command_id(lane_id, revision, action):
    return str(uuid.uuid5(uuid.UUID(lane_id), "kashbot-work:" + revision + ":" + action))


def _actions(work):
    if work == "start_dry_run":
        return ("enroll", "dry_run")
    return ("start",) if work == "start_live" else ("stop",)


def _result(binding, revision, action):
    request_id = command_id(binding["lane_id"], revision, action)
    path = agent.safe_path(agent.AGENT_ROOT / "results" / binding["lane_id"] / (request_id + ".json"))
    if not path.exists():
        return None
    result = agent.parse(agent.read_private(path))
    agent.check_scope(result, binding)
    if (action in ("start", "activate", "enroll", "dry_run")
            and set(result) == set(binding) | {"id", "ok", "error"}
            and result.get("id") == request_id and result.get("ok") is False
            and result.get("error") == "owner_lane_parked"):
        raise agent.LaneRefused("owner_lane_parked")
    if (action in ("start", "activate", "stop") and result.get("ok") is False
            and result.get("id") == request_id and result.get("error") == "account command in progress"):
        return None
    if (set(result) != set(binding) | {"id", "ok", "result"}
            or result.get("id") != request_id or result.get("ok") is not True):
        raise SyncRefused("local command failed")
    payload = result["result"]
    agent.check_scope(payload, binding)
    if action == "enroll" and payload.get("validated") is not True:
        raise SyncRefused("enrollment validation missing")
    if action == "stop" and payload.get("stopped") is not True:
        raise SyncRefused("stop receipt missing")
    if action == "dry_run" and (payload.get("ok") is not True or payload.get("request_id") != request_id
            or payload.get("symbols") != list(agent.canonical_symbols()) or len(payload["symbols"]) != 14
            or type(payload.get("order_placement_calls")) is not int or payload["order_placement_calls"] != 0):
        raise SyncRefused("dry run receipt refused")
    if action in ("start", "activate"):
        paths = agent.LanePaths(binding["lane_id"])
        staged = agent.parse(agent.read_private(paths.config / "staged-live.json"))
        agent.check_scope(staged["config"], binding)
        expected = agent.live_receipt(staged["config"], staged["approval"], activated=action == "activate")
        if (expected["start_request_id"] != command_id(binding["lane_id"], revision, "start")
                or agent.canonical(payload) != agent.canonical(expected)):
            raise SyncRefused("live receipt refused")
        if action == "activate":
            agent.require_activation(paths, staged["config"], staged["approval"])
            if agent.canonical(agent._activation_read(agent.activation_path(paths, receipt=True))) != agent.canonical(expected):
                raise SyncRefused("activation receipt missing")
    return payload


def _ack(binding, revision, work):
    return {"lane_id": binding["lane_id"], "revision": revision, "result": RESULTS[work],
            "credential_validated": work in ("start_dry_run", "start_live"), "order_placement_calls": 0}


def _cleanup(binding, revision, work):
    queue = agent.safe_path(agent.AGENT_ROOT / "queue" / binding["lane_id"])
    for action in (*_actions(work), *(("activate",) if work == "start_live" else ())):
        agent.safe_path(queue / (command_id(binding["lane_id"], revision, action) + ".json")).unlink(missing_ok=True)
    if os.name == "posix" and queue.exists():
        fd = os.open(queue, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def _cursor(path, binding, url):
    if not path.exists():
        return None
    cursor = agent.parse(agent.read_private(path))
    agent.check_scope(cursor, binding)
    if (set(cursor) != set(binding) | {"url", "revision", "work", "phase", "ack"}
            or cursor["url"] != url or type(cursor["work"]) is not str or cursor["work"] not in RESULTS
            or cursor["phase"] not in ("staged", "pending", "accepted", "acknowledged", "refused")
            or (cursor["phase"] == "refused" and cursor["work"] not in ("start_live", "start_dry_run"))
            or (cursor["phase"] == "accepted" and cursor["work"] != "start_live")):
        raise SyncRefused("sync cursor refused")
    _revision(cursor["revision"])
    expected = None if cursor["phase"] in ("staged", "refused") else _ack(binding, cursor["revision"], cursor["work"])
    if agent.canonical(cursor["ack"]) != agent.canonical(expected):
        raise SyncRefused("sync receipt refused")
    return cursor


@contextmanager
def _parked_refusal(path, lane_id, url):
    """Consume a parked start locally, under the sync lock, without a success POST."""
    try:
        yield
    except agent.LaneRefused as error:
        if str(error) != "owner_lane_parked":
            raise
        binding = _binding(lane_id)
        cursor = _cursor(path, binding, url)
        if cursor is None or cursor["work"] not in ("start_live", "start_dry_run"):
            raise
        if cursor["work"] == "start_live" and cursor["phase"] in ("accepted", "acknowledged"):
            # Activation may already have happened before the cursor was saved.
            # Do not claim a terminal refusal until the stop has succeeded.
            _stop_superseding(None, path, cursor, binding, None)
        agent.record_owner_lane_refusal(lane_id, "owner_lane_parked")
        agent.write_private(path, {**cursor, "phase": "refused", "ack": None})
        _cleanup(binding, cursor["revision"], cursor["work"])


def _settle(client, path, cursor, binding):
    if cursor["work"] in ("start_live", "start_dry_run"):
        agent.require_lane_unparked(binding["lane_id"])
    if cursor["phase"] != "accepted":
        _cleanup(binding, cursor["revision"], cursor["work"])
        reply = client.acknowledge(cursor["ack"])
        if (type(reply) is not dict or set(reply) != {"success", "accepted"}
                or reply["success"] is not True or reply["accepted"] is not True):
            raise SyncRefused("dashboard acknowledgement refused")
        if cursor["work"] == "start_live":
            cursor = {**cursor, "phase": "accepted"}
            agent.write_private(path, cursor)
    if cursor["work"] == "start_live":
        # Re-read the dashboard after acceptance so a queued kill takes precedence.
        doc = _work(client.get_work(), binding)
        if doc["kill_requested"]:
            return _stop_superseding(client, path, cursor, binding, doc)
        if (doc["revision"] != cursor["revision"] or
                (doc["work"] is not None and doc["work"]["action"] != "start_live")):
            raise SyncRefused("activation revision conflict")
        _run_commands(binding, cursor["revision"], ("activate",))
        if _result(binding, cursor["revision"], "activate") is None:
            raise SyncRefused("activation receipt unavailable")
    agent.write_private(path, {**cursor, "phase": "acknowledged"})
    _cleanup(binding, cursor["revision"], cursor["work"])
    return cursor["ack"]


def activation_authorized(binding, command):
    path = agent.AGENT_ROOT / "sync" / binding["lane_id"] / "cursor.json"
    raw = agent.parse(agent.read_private(path))
    cursor = _cursor(path, binding, dashboard_url(raw.get("url")))
    revision = command.get("revision")
    _revision(revision)
    if (cursor["phase"] not in ("accepted", "acknowledged") or cursor["work"] != "start_live"
            or cursor["revision"] != revision
            or command["id"] != command_id(binding["lane_id"], revision, "activate")
            or command["start_request_id"] != command_id(binding["lane_id"], revision, "start")
            or command["sequence"] != _revision(revision) * 2):
        raise SyncRefused("activation not acknowledged")


def _run_commands(binding, revision, actions, *, envelope=None, credential_revision=None):
    lane_id = binding["lane_id"]
    if any(action in ("start", "activate", "enroll", "dry_run") for action in actions):
        agent.require_lane_unparked(lane_id)
    queue_root = _private_directory(agent.AGENT_ROOT / "queue")
    queue = _private_directory(queue_root / lane_id)
    missing = [action for action in actions if _result(binding, revision, action) is None]
    for action in missing:
        request_id = command_id(lane_id, revision, action)
        command = {**binding, "id": request_id,
                   "sequence": _revision(revision) * 2 - (action in ("enroll", "start")),
                   "action": action, "expires_at": int(time.time()) + 600}
        if action == "enroll":
            command.update(envelope=envelope, credential_revision=credential_revision)
        if action == "start":
            command.update(approved=True, credential_revision=credential_revision)
        if action == "activate":
            command.update(revision=revision, start_request_id=command_id(lane_id, revision, "start"))
        target = queue / (request_id + ".json")
        # Preserve the original approval deadline and command bytes on restart.
        if not target.exists():
            if action == "start":
                command["coordinated_mode"] = _coordinated_mode(lane_id)
            agent.write_private(target, command)
    if missing:
        agent.agent_once()
    if any(_result(binding, revision, action) is None for action in actions):
        raise SyncRefused("local receipt unavailable")


def _coordinated_mode(lane_id):
    """Bind a new dashboard start to the root-owned cohort authority."""
    from . import coordinated_cohort as cohort
    from . import signal_authority as authority

    if lane_id == cohort.OWNER_LANE:
        return "off"
    try:
        freeze_path = cohort.FREEZE_PATH
        config_path = freeze_path.parent / "config.json"
        try:
            freeze_path.lstat()
        except FileNotFoundError:
            return "off"
        authority.require_root_path(freeze_path)
        freeze = cohort.load_freeze(freeze_path)
        if lane_id not in freeze.testers:
            return "off"
        try:
            config_path.lstat()
        except FileNotFoundError:
            return "off"
        authority.require_root_path(config_path)
        config = authority.read_document(config_path, root_owned=True)
        if Path(config["freeze_path"]) != freeze_path:
            raise SyncRefused("noncanonical cohort freeze")
        config = authority.validate_config(config)
        if config["freeze_digest"] != freeze.digest:
            raise SyncRefused("cohort freeze changed")
        import pwd
        if config["accounts"][lane_id] != pwd.getpwnam(agent.account_user(lane_id)).pw_uid:
            raise SyncRefused("cohort account UID mismatch")
        return config["mode"]
    except Exception:
        raise SyncRefused("coordinated authority refused") from None


def _stop_superseding(client, path, cursor, binding, doc):
    paths = agent.LanePaths(binding["lane_id"])
    try:
        if paths.state.exists():
            agent.write_private(paths.state / "KILL", b"account stopped\n")
        agent.remove_activation(paths)
    except Exception:
        agent.systemctl("stop", paths.unit)
        raise
    if doc is None:
        agent.systemctl("stop", paths.unit)
        return
    work = doc["work"]
    if (work is None or work["action"] not in ("pause", "revoke")
            or _revision(doc["revision"]) <= _revision(cursor["revision"])):
        # No live acknowledgement may survive a kill, even without new work.
        agent.systemctl("stop", paths.unit)
        raise SyncRefused("dashboard kill requested")
    _cleanup(binding, cursor["revision"], cursor["work"])
    cursor = {**binding, "url": client.url, "revision": doc["revision"],
              "work": work["action"], "phase": "staged", "ack": None}
    agent.write_private(path, cursor)
    _run_commands(binding, doc["revision"], ("stop",))
    cursor = {**cursor, "phase": "pending", "ack": _ack(binding, doc["revision"], work["action"])}
    agent.write_private(path, cursor)
    return _settle(client, path, cursor, binding)


def _sync_once(lane_id, client):
    _require_root()
    agent.identifier(lane_id)
    _private_directory(agent.AGENT_ROOT)
    sync_root = _private_directory(agent.AGENT_ROOT / "sync")
    directory = _private_directory(sync_root / lane_id)
    with _lane_lock(directory / "sync.lock"), _parked_refusal(directory / "cursor.json", lane_id, client.url):
        binding = _binding(lane_id)
        path = directory / "cursor.json"
        cursor = _cursor(path, binding, client.url)
        doc = None
        if cursor and cursor["work"] == "start_live":
            doc = _work(client.get_work(), binding)
            if doc["kill_requested"]:
                return _stop_superseding(client, path, cursor, binding, doc)
        if (cursor and cursor["phase"] != "refused"
                and (cursor["work"] == "start_live" or
                     (cursor["work"] == "start_dry_run" and cursor["phase"] != "acknowledged"))):
            agent.require_lane_unparked(lane_id)
        if cursor and cursor["phase"] in ("pending", "accepted"):
            return _settle(client, path, cursor, binding)
        if cursor and cursor["phase"] == "staged":
            # Recover a crash after local completion but before recording the
            # pending POST. Exact result files are authoritative, not a new GET.
            if all(_result(binding, cursor["revision"], action) is not None
                   for action in _actions(cursor["work"])):
                cursor = {**cursor, "phase": "pending",
                          "ack": _ack(binding, cursor["revision"], cursor["work"])}
                agent.write_private(path, cursor)
                return _settle(client, path, cursor, binding)
        if cursor and cursor["phase"] in ("acknowledged", "refused"):
            _cleanup(binding, cursor["revision"], cursor["work"])
        doc = doc if doc is not None else _work(client.get_work(), binding)
        revision = doc["revision"]
        work = None if doc["work"] is None else doc["work"]["action"]
        if doc["kill_requested"] and work is None:
            paths = agent.LanePaths(lane_id)
            try:
                if paths.state.exists():
                    agent.write_private(paths.state / "KILL", b"account stopped\n")
                agent.remove_activation(paths)
            finally:
                agent.systemctl("stop", paths.unit)
            return None
        if cursor and cursor["phase"] == "staged" and (revision != cursor["revision"] or work != cursor["work"]):
            raise SyncRefused("unfinished dashboard revision")
        if cursor and _revision(revision, allow_zero=True) <= _revision(cursor["revision"]):
            if revision != cursor["revision"] or (work is not None and work != cursor["work"]):
                raise SyncRefused("dashboard revision conflict")
            if cursor["phase"] == "refused":
                return None
            if cursor["phase"] == "acknowledged":
                if doc["live_enabled"] and cursor["work"] != "start_live":
                    raise SyncRefused("unacknowledged live revision")
                if cursor["work"] == "start_live":
                    if not doc["live_enabled"] and work is None:
                        raise SyncRefused("dashboard live state refused")
                    if _result(binding, revision, "activate") is None:
                        raise SyncRefused("activation receipt unavailable")
                return cursor["ack"]
        if work is None:
            if doc["live_enabled"]:
                raise SyncRefused("unacknowledged live revision")
            return None
        if work in ("start_live", "start_dry_run") and agent.root_lane_parked(lane_id):
            cursor = {**binding, "url": client.url, "revision": revision, "work": work,
                      "phase": "staged", "ack": None}
            agent.write_private(path, cursor)
            raise agent.LaneRefused("owner_lane_parked")
        if not agent.safe_path(agent.CONFIG_ROOT / "ENABLED").exists():
            raise SyncRefused("account agent disabled")
        envelope = _envelope(doc["work"]["credential"], lane_id) if work == "start_dry_run" else None
        if work == "start_live" and not (cursor and cursor["work"] == "start_live" and cursor["phase"] == "staged"):
            if not cursor or cursor["work"] != "start_dry_run" or cursor["phase"] != "acknowledged":
                raise SyncRefused("acknowledged dry run required")
            dry = _result(binding, cursor["revision"], "dry_run")
            config = agent.parse(agent.read_private(agent.LanePaths(lane_id).config / "config.json"))
            if (dry is None or config.get("dry_run_id") != dry["request_id"]
                    or config.get("credential_revision") != doc["work"]["credential_revision"]):
                raise SyncRefused("current dry run required")
        cursor = {**binding, "url": client.url, "revision": revision, "work": work,
                  "phase": "staged", "ack": None}
        agent.write_private(path, cursor)
        actions = _actions(work)
        _run_commands(binding, revision, actions, envelope=envelope,
                      credential_revision=doc["work"]["credential_revision"])
        cursor = {**cursor, "phase": "pending", "ack": _ack(binding, revision, work)}
        agent.write_private(path, cursor)
        return _settle(client, path, cursor, binding)


def sync_once(lane_id, client):
    try:
        return _sync_once(lane_id, client)
    except Exception:
        raise SyncRefused("account sync refused") from None


def main(argv=None):
    class PrivateParser(argparse.ArgumentParser):
        def error(self, message):
            raise SyncRefused("invalid sync arguments")
    try:
        parser = PrivateParser(allow_abbrev=False)
        parser.add_argument("lane_id")
        args = parser.parse_args(argv)
        lane_id = agent.identifier(args.lane_id)
        _require_root()
        url, token = _credentials(lane_id)
        sync_once(lane_id, DashboardClient(url, token))
        return 0
    except Exception:
        print("Account lane sync refused.", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
