"""Detached C14-B binding preparation. Nothing here installs or enables a binding.

The runner host is single-tenant; file-swap races by another local principal in
the output directory are outside this threat model. Publisher calls serialize
under a kernel-released advisory lock in a persistent root-owned 0600 lock file,
waiting at most ten seconds. Under that lock, one matching stage hard link with
the expected destination bytes is a
crashed call's leftover and can be removed on retry. Other extra links refuse.
"""
from __future__ import annotations

from collections.abc import Mapping
from contextlib import contextmanager
import errno
import hashlib
import os
from pathlib import Path
import re
import secrets
import stat
import time

from . import account_lane_agent as agent
from . import account_lane_provision as provision
from .account_lane_catalog_audit import _Unavailable, _identity, _read
from .engine_registry import MAX_REGISTRY_BYTES, RegistryError, strict_loads, validate_projection

SCHEMA = "leafhft.account-lane-binding-candidate.v1"
BINDING_MAX = 4096
ENVELOPE_MAX = 8192
LOCK_WAIT_SECONDS = 10.0
_ENGINE_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,31}")
_STAGE_NAME = re.compile(r"\.binding-[0-9a-f]{32}")
_REASONS = frozenset({"absent", "unsafe", "invalid", "unreadable",
                      "projection_replayed", "projection_floor_missing",
                      "projection_floor_invalid"})


def _posix():
    return os.name == "posix"


def _capture(path, limit, label, owned):
    try:
        before = agent._projection_tree_safe(path, owned=owned)
        if before is None:
            raise _Unavailable("projection_unsafe")
        captured = _read(path, limit, label)
        after = agent._projection_tree_safe(path, owned=owned)
        if after is None:
            raise _Unavailable("projection_unsafe")
        if _identity(before) != captured[1] or _identity(after) != captured[1]:
            raise _Unavailable(label + "_changed")
        return captured
    except FileNotFoundError:
        raise _Unavailable("projection_absent" if label == "projection"
                           else "projection_floor_missing") from None


def _recheck(paths, projection, floor):
    for path, limit, label, owned, captured in (
        (agent.registry_projection_path(paths), MAX_REGISTRY_BYTES, "projection", 3, projection),
        (agent.registry_projection_floor_path(paths), agent.PROJECTION_FLOOR_MAX,
         "projection_floor", 2, floor),
    ):
        if _capture(path, limit, label, owned) != captured:
            raise _Unavailable(label + "_changed")


def _projection(paths):
    projection = _capture(agent.registry_projection_path(paths), MAX_REGISTRY_BYTES,
                          "projection", 3)
    floor = _capture(agent.registry_projection_floor_path(paths), agent.PROJECTION_FLOOR_MAX,
                     "projection_floor", 2)
    try:
        view = validate_projection(strict_loads(projection[0], MAX_REGISTRY_BYTES))
    except (RegistryError, ValueError, RecursionError):
        raise _Unavailable("projection_invalid") from None
    if view["domain"] != "account-lane:" + paths.lane_id:
        raise _Unavailable("projection_wrong_domain")
    try:
        minimum = agent.parse_projection_floor(floor[0], paths.lane_id)
    except agent.LaneRefused:
        raise _Unavailable("projection_floor_invalid") from None
    if int(view["generation"]) < minimum:
        raise _Unavailable("projection_replayed")
    reader, reason, _ = agent.lane_projection(paths)
    if reader is None:
        reason = reason if reason in _REASONS else "unreadable"
        raise _Unavailable(reason if reason.startswith("projection_") else "projection_" + reason)
    if (reader.generation, reader.digest) != (int(view["generation"]), view["digest"]):
        raise _Unavailable("projection_changed")
    _recheck(paths, projection, floor)
    return view, projection, floor


def _bindings(requested, view):
    # A JSON-object-shaped mapping is deliberate: no default, sequence, or inference.
    if type(requested) is not dict:
        raise _Unavailable("mapping_invalid")
    known = sorted(agent.canonical_symbols())
    result = {}
    for symbol, engine in requested.items():
        if type(symbol) is not str or type(engine) is not str or not _ENGINE_ID.fullmatch(engine):
            raise _Unavailable("mapping_invalid")
        if symbol not in known:
            raise _Unavailable("symbol_unknown")
        if engine not in view["assignments"]:
            raise _Unavailable("engine_unassigned")
        if symbol not in view["assignments"][engine]["symbols"]:
            raise _Unavailable("symbol_unassigned")
        result[symbol] = engine
    bindings = {"default": None, "symbols": result, "disabled": known}
    if len(agent.canonical(bindings)) > BINDING_MAX:
        raise _Unavailable("bindings_oversized")
    return bindings


def _snapshot_mapping(requested):
    try:
        if not isinstance(requested, Mapping):
            raise ValueError
        return {symbol: requested[symbol] for symbol in requested}
    except Exception:
        # Caller-controlled iteration/getitem can fail, including when a dict
        # changes size in another thread. Never expose its exception text.
        raise _Unavailable("mapping_invalid") from None


def _linked(info):
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & 0x400)


def _directory_metadata(info, publication, lane_id=None):
    if _linked(info) or not stat.S_ISDIR(info.st_mode):
        raise _Unavailable("output_unsafe")
    if _posix() and lane_id is not None:
        if not agent.lane_dir_mode_ok(info, lane_id):
            raise _Unavailable("output_unsafe")
    elif _posix() and (info.st_uid != 0 or
                     (stat.S_IMODE(info.st_mode) != 0o755 if publication else
                      bool(info.st_mode & 0o022) and not bool(info.st_mode & stat.S_ISVTX))):
        raise _Unavailable("output_unsafe")


def _tree(path, root, *, missing=False):
    for part in reversed((path, *path.parents)):
        try:
            info = part.lstat()
        except FileNotFoundError:
            if missing and (part == root or root in part.parents):
                continue
            raise _Unavailable("output_parent_missing") from None
        if part.parent == root:
            _directory_metadata(info, True, part.name)
        else:
            _directory_metadata(info, part == root or root in part.parents)


def _output_path(value):
    if not isinstance(value, (str, os.PathLike)):
        raise _Unavailable("output_invalid")
    try:
        raw = os.fspath(value)
        if not isinstance(raw, str) or raw.replace("/", "\\").startswith("\\\\"):
            raise agent.LaneRefused("invalid output path")
        if os.path.sep == "\\" and any(
                part.endswith((".", " ")) for part in re.split(r"[/\\]", raw)):
            raise agent.LaneRefused("invalid output path")
        root = Path(raw)
        if not root.is_absolute() or ".." in root.parts:
            raise agent.LaneRefused("invalid output path")
    except Exception:
        raise _Unavailable("output_invalid") from None
    return root


def _output_root(value):
    root = _output_path(value)
    # Exclude whole trees, including other lanes, plus the owner's catalog/bindings
    # directory. A parent of a protected tree is not a detached destination either.
    protected = (agent.STATE_ROOT, agent.CONFIG_ROOT, agent.RUN_ROOT, agent.AGENT_ROOT,
                 agent.PROJECTION_ROOT, provision.ENGINE_SOURCE, provision.REGISTRY_DIR,
                 provision.ENGINE_SOURCE.parent, Path("/var/lib/leafhft"))
    resolved = os.path.normcase(os.path.realpath(root))
    for item in protected:
        item = os.path.normcase(os.path.realpath(item))
        try:
            common = os.path.commonpath((resolved, item))
        except ValueError:  # Different drives cannot overlap.
            continue
        if common in (resolved, item):
            raise _Unavailable("output_overlap")
    _tree(root, root, missing=True)
    return root


def _mkdir(path, root, *, report=None):
    _tree(path, root, missing=True)
    lane_level = path.parent == root
    with agent.private_parent(path) as parent:
        target = path.name if parent is not None else path
        try:
            os.mkdir(target, 0o700 if lane_level and parent is not None else 0o755, dir_fd=parent)
        except FileExistsError:
            pass
        else:
            # Only objects created by this call may have their permissions set.
            if parent is not None:
                fd = os.open(target, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
                try:
                    # Establish the readable legacy mode before optional conversion.
                    os.fchmod(fd, 0o755)
                    if lane_level:
                        try:
                            gid = agent.lane_gid(path.name)
                        except agent.LaneRefused:
                            if report is not None:
                                report["lane_directory"] = "lane_user_unresolved"
                        else:
                            try:
                                os.fchown(fd, 0, gid)
                                os.fchmod(fd, 0o750)
                            except OSError:
                                if report is not None:
                                    report["lane_directory"] = "conversion_failed"
                finally:
                    os.close(fd)
    _tree(path, root)


def _recover_stage(path, data, info):
    # The publication lock proves that this matching stage has no live writer.
    if info.st_nlink != 2:
        raise _Unavailable("destination_unsafe")
    with agent.private_parent(path) as parent:
        matches = []
        with os.scandir(parent if parent is not None else path.parent) as entries:
            for entry in entries:
                if not _STAGE_NAME.fullmatch(entry.name):
                    continue
                candidate = (os.stat(entry.name, dir_fd=parent, follow_symlinks=False)
                             if parent is not None else (path.parent / entry.name).lstat())
                if not _linked(candidate) and _identity(candidate) == _identity(info):
                    matches.append(entry.name)
        if len(matches) != 1:
            raise _Unavailable("destination_unsafe")
        fd = os.open(path.name if parent is not None else path,
                     os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
                     | getattr(os, "O_NONBLOCK", 0), dir_fd=parent)
        with os.fdopen(fd, "rb") as stream:
            before = os.fstat(stream.fileno())
            if ((before.st_dev, before.st_ino, before.st_nlink, before.st_size) !=
                    (info.st_dev, info.st_ino, 2, len(data))):
                raise _Unavailable("destination_unsafe")
            if stream.read(ENVELOPE_MAX + 1) != data:
                raise _Unavailable("destination_unsafe")
            if _identity(before) != _identity(os.fstat(stream.fileno())):
                raise _Unavailable("destination_changed")
        stage = path.parent / matches[0]
        current = (os.stat(stage.name, dir_fd=parent, follow_symlinks=False)
                   if parent is not None else stage.lstat())
        if _identity(current) != _identity(info) or _identity(path.lstat()) != _identity(info):
            raise _Unavailable("destination_changed")
        os.unlink(stage.name if parent is not None else stage, dir_fd=parent)


def _existing(path, data):
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    if (_linked(info) or not stat.S_ISREG(info.st_mode)
            or (_posix() and (info.st_uid != 0 or stat.S_IMODE(info.st_mode) != 0o444))):
        raise _Unavailable("destination_unsafe")
    if info.st_nlink != 1:
        _recover_stage(path, data, info)
        return _existing(path, data)
    captured = _read(path, ENVELOPE_MAX, "destination")
    if captured[1] != _identity(info):
        raise _Unavailable("destination_changed")
    if captured[0] != data:
        raise _Unavailable("destination_conflict")
    return True


def _finalize(stage, destination, parent):
    if parent is not None:
        # link is atomic and cannot clobber a competing publication. Remove our
        # private name before inspecting the destination's single-link invariant.
        os.link(stage.name, destination.name, src_dir_fd=parent, dst_dir_fd=parent,
                follow_symlinks=False)
        os.unlink(stage.name, dir_fd=parent)
    else:
        # Windows rename has no replace semantics (unlike POSIX rename).
        os.rename(stage, destination)


def _remove_stage(stage, parent, created):
    try:
        info = (os.stat(stage.name, dir_fd=parent, follow_symlinks=False)
                if parent is not None else stage.lstat())
    except FileNotFoundError:
        return
    if (_linked(info) or not stat.S_ISREG(info.st_mode)
            or (info.st_dev, info.st_ino) != (created.st_dev, created.st_ino)):
        raise _Unavailable("staging_changed")
    if parent is None:
        # Only this invocation's file may be made writable for Windows unlink.
        os.chmod(stage, 0o600)
        os.unlink(stage)
    else:
        os.unlink(stage.name, dir_fd=parent)


def _lock_metadata(info):
    if (_linked(info) or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
            or (_posix() and (info.st_uid != 0 or stat.S_IMODE(info.st_mode) != 0o600))):
        raise _Unavailable("output_unsafe")


@contextmanager
def _publisher_lock(root):
    # Keep the lock file permanently: unlinking it permits two lock inodes.
    path = root / ".publisher.lock"
    with agent.private_parent(path) as parent:
        target = path.name if parent is not None else path
        flags = os.O_RDWR | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
        try:
            fd = os.open(target, flags | os.O_CREAT | os.O_EXCL, 0o600, dir_fd=parent)
        except FileExistsError:
            _lock_metadata(path.lstat())
            fd = os.open(target, flags, dir_fd=parent)
        locked = False
        try:
            info, current = os.fstat(fd), path.lstat()
            _lock_metadata(info)
            _lock_metadata(current)
            if (info.st_dev, info.st_ino) != (current.st_dev, current.st_ino):
                raise _Unavailable("output_changed")
            deadline = time.monotonic() + min(10.0, max(0.0, LOCK_WAIT_SECONDS))
            attempted = False
            while True:
                if attempted and time.monotonic() >= deadline:
                    raise _Unavailable("publisher_busy")
                attempted = True
                try:
                    if os.name == "nt":
                        import msvcrt
                        os.lseek(fd, 0, os.SEEK_SET)
                        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    locked = True
                    break
                except OSError as exc:
                    if exc.errno not in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                        raise
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise _Unavailable("publisher_busy") from None
                    time.sleep(min(0.05, remaining))
            yield
        finally:
            try:
                if locked:
                    if os.name == "nt":
                        os.lseek(fd, 0, os.SEEK_SET)
                        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
                    else:
                        fcntl.flock(fd, fcntl.LOCK_UN)
            finally:
                os.close(fd)


def _check_stage(fd, stage, parent, created, data):
    try:
        before = os.fstat(fd)
        current = (os.stat(stage.name, dir_fd=parent, follow_symlinks=False)
                   if parent is not None else stage.lstat())
        if (_linked(current) or not stat.S_ISREG(current.st_mode)
                or (before.st_dev, before.st_ino) != (created.st_dev, created.st_ino)
                or (before.st_dev, before.st_ino) != (current.st_dev, current.st_ino)
                or before.st_size != len(data) or current.st_size != len(data)
                or before.st_nlink != 1 or current.st_nlink != 1):
            raise _Unavailable("staging_changed")
        os.lseek(fd, 0, os.SEEK_SET)
        if os.read(fd, ENVELOPE_MAX + 1) != data:
            raise _Unavailable("staging_changed")
        if _identity(before) != _identity(os.fstat(fd)):
            raise _Unavailable("staging_changed")
    except OSError:
        raise _Unavailable("staging_changed") from None


def _publish_locked(root, lane_id, data, recheck, *, report=None):
    directory = root / lane_id
    _mkdir(directory, root, report=report)
    destination = directory / (hashlib.sha256(data).hexdigest() + ".json")
    recheck()
    if _existing(destination, data):
        return "unchanged", destination
    stage = directory / (".binding-" + secrets.token_hex(16))
    with agent.private_parent(destination) as parent:
        if parent is not None:
            _directory_metadata(os.fstat(parent), True, lane_id)
        fd = os.open(stage.name if parent is not None else stage,
                     os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                     0o600, dir_fd=parent)
        created = os.fstat(fd)
        try:
            with os.fdopen(fd, "wb") as stream:
                if stream.write(data) != len(data):
                    raise _Unavailable("publication_interrupted")
                stream.flush()
                os.fsync(stream.fileno())
                if parent is not None:
                    os.fchmod(stream.fileno(), 0o444)
                _tree(directory, root)
                if parent is not None:
                    pinned, current = os.fstat(parent), directory.lstat()
                    if (pinned.st_dev, pinned.st_ino) != (current.st_dev, current.st_ino):
                        raise _Unavailable("output_changed")
                recheck()
                _check_stage(stream.fileno(), stage, parent, created, data)
                if parent is None:
                    os.chmod(stage, 0o444)
            # Windows requires closing the verified descriptor before rename.
            try:
                _finalize(stage, destination, parent)
            except OSError:
                if not _existing(destination, data):
                    raise
                return "unchanged", destination
            return "published", destination
        finally:
            _remove_stage(stage, parent, created)


def _publish(root, lane_id, data, recheck, *, report=None):
    _mkdir(root, root)
    with _publisher_lock(root):
        return _publish_locked(root, lane_id, data, recheck, report=report)


def publish_lane_binding_candidate(lane_id, requested_symbols, output_root, *, enabled=False):
    """Prepare an immutable candidate only on explicit opt-in; never grant entry.

    Results contain static status/refusal codes and, on success, the detached
    destination. Projection data, manifests and credentials never enter errors.
    """
    report = {"status": "disabled", "refusal_codes": [], "path": None}
    if enabled is False:
        return report
    report["status"] = "refused"
    if enabled is not True:
        report["refusal_codes"] = ["enabled_invalid"]
        return report
    try:
        requested_symbols = _snapshot_mapping(requested_symbols)
    except _Unavailable as exc:
        report["refusal_codes"] = [str(exc)]
        return report
    try:
        lane_id = agent.identifier(lane_id)
    except Exception:
        report["refusal_codes"] = ["invalid_lane_id"]
        return report
    try:
        output_root = _output_path(output_root)  # Snapshot before reading filesystem inputs.
        paths = agent.LanePaths(lane_id)
        view, projection, floor = _projection(paths)
        bindings = _bindings(requested_symbols, view)
        data = agent.canonical({"schema": SCHEMA, "lane_id": lane_id,
                                "domain": view["domain"],
                                "projection_generation": view["generation"],
                                "projection_digest": view["digest"],
                                "exit_only": view["exit_only"], "bindings": bindings})
        if len(data) > ENVELOPE_MAX:
            raise _Unavailable("envelope_oversized")
        root = _output_root(output_root)
        status, destination = _publish(root, lane_id, data,
                                       lambda: _recheck(paths, projection, floor), report=report)
        report.update(status=status, path=str(destination))
    except _Unavailable as exc:
        report["refusal_codes"] = [str(exc)]
    except agent.LaneRefused:
        report["refusal_codes"] = ["projection_unsafe"]
    except (OSError, ValueError, TypeError):
        report["refusal_codes"] = ["publication_unreadable"]
    return report
