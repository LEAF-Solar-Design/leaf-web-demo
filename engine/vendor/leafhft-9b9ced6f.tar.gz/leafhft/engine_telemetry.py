"""Pure construction of Kashbot WIRE-v1 engine snapshots.

Storage contract: ops-dashboard 24d29be05670ac5358098126f747f909fddabd25.
Delivery, durable sequence allocation and authentication belong to the caller.
All public results own bytes; decoding a result never exposes mutable internal state.
"""
from __future__ import annotations

from dataclasses import dataclass
from collections import deque
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Context, Decimal, DecimalException, DivisionByZero, InvalidOperation, Overflow, ROUND_HALF_EVEN, Underflow, localcontext
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import re
import stat
from typing import Any, Callable, Mapping, Sequence


MAX_PAGES = 128
MAX_ENGINES = 1025  # Mirror ops-dashboard leafhft-engine-snapshots.ts ENGINE_SNAPSHOT_LIMITS, snap-limits-1024: 1024 catalog + Darkhorse.
MAX_CONTROLS = 2050  # Mirror ops-dashboard leafhft-engine-snapshots.ts ENGINE_SNAPSHOT_LIMITS, snap-limits-1024: 2 control states per engine.
ENGINES_PER_PAGE = 16
CONTROLS_PER_PAGE = 32
MAX_RECORD_BYTES = 163840
MAX_REQUEST_BYTES = 196608
MAX_SERVICE_ENVELOPE_BYTES = 196608
MAX_BINDING_BYTES = 4096
MAX_DEPTH = 32
MAX_PAGE_DEPTH = 30
MAX_DIRECTORY_ENTRIES = 65536
MAX_SELECTED_FILES = 8192
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_CAPTURE_BYTES = 64 * 1024 * 1024
MAX_PARSED_ROWS = 500000
MAX_CAPTURE_ATTEMPTS = 1
MAX_REASSEMBLY_BYTES = MAX_PAGES * MAX_REQUEST_BYTES + 2 * MAX_REQUEST_BYTES
MAX_SAFE_INTEGER = 9007199254740991
MAX_EVIDENCE_DECIMAL = Decimal("1e100")
MIN_EVIDENCE_DECIMAL = Decimal("1e-100")
RUNTIME_KEYS = frozenset({"engines", "engine_registry", "loss_breakers", "engine_rollups",
                          "probe_verdicts", "conform_receipts", "execution_events"})


class SnapshotConstructionError(ValueError):
    """No request is returned on failure. ``code`` is stable for callers."""

    def __init__(self, code: str, detail: str):
        self.code = code
        super().__init__(f"{code}: {detail}")


def _fail(code: str, detail: str) -> None:
    raise SnapshotConstructionError(code, detail)


def _strict_value(value: Any, kind: type, field: str, *, low: int | float = 0,
                  high: int | float = MAX_SAFE_INTEGER, pattern: str | None = None,
                  nullable: bool = False, code: str = "EVIDENCE_INVALID") -> Any:
    """Validate at the input boundary, before equality, coercion or projection."""
    if value is None and nullable:
        return None
    if kind is float:
        valid = type(value) in (int, float) and low <= value <= high and math.isfinite(value)
    elif kind is str:
        valid = type(value) is str and pattern is not None and re.fullmatch(pattern, value) is not None
    else:
        valid = type(value) is kind
        if valid and kind is int:
            valid = low <= value <= high
    if not valid:
        _fail(code, field)
    return value


@contextmanager
def _bounded_decimal_evidence():
    # Do not inherit the process's precision, exponent limits, or disabled traps.
    with localcontext(Context(prec=128, rounding=ROUND_HALF_EVEN, Emin=-100, Emax=100,
                              traps=[InvalidOperation, DivisionByZero, Overflow, Underflow])):
        try:
            yield
        except DecimalException:
            _fail("EVIDENCE_INVALID", "decimal evidence outside bounded context")


def _decimal_magnitude(number: Decimal, *, signed: bool = False) -> Decimal:
    if (not number.is_finite() or (not signed and number < 0) or abs(number) > MAX_EVIDENCE_DECIMAL
            or (number != 0 and abs(number) < MIN_EVIDENCE_DECIMAL)):
        _fail("EVIDENCE_INVALID", "decimal evidence magnitude")
    return number


def _evidence_decimal(value: Any, *, signed: bool = False) -> Decimal:
    with _bounded_decimal_evidence():
        if type(value) is int:
            _strict_value(value, int, "decimal integer", low=-10**100 if signed else 0, high=10**100)
        else:
            _strict_value(value, str, "decimal evidence", pattern=r"-?(?:0|[1-9][0-9]{0,100})(?:\.[0-9]{1,128})?(?:[eE][+-]?[0-9]{1,7})?")
        return _decimal_magnitude(Decimal(value), signed=signed)


def _number(value: int | float) -> str:
    # Both runtimes choose the closest shortest round-trip decimal, ties to even.
    try:
        value = float(value)
    except OverflowError:
        _fail("INVALID_RECORD", "number outside binary64")
    if not math.isfinite(value):
        _fail("INVALID_RECORD", "nonfinite number")
    if value == 0:
        return "0"
    if value < 0:
        return "-" + _number(-value)
    mantissa, _, exponent = repr(value).partition("e")
    whole, _, fraction = mantissa.partition(".")
    digits = whole + fraction
    point = len(whole) + (int(exponent) if exponent else 0)
    stripped = digits.lstrip("0")
    point -= len(digits) - len(stripped)
    digits = stripped.rstrip("0")
    if len(digits) <= point <= 21:
        return digits + "0" * (point - len(digits))
    if 0 < point <= 21:
        return digits[:point] + "." + digits[point:]
    if -6 < point <= 0:
        return "0." + "0" * -point + digits
    power = point - 1
    head = digits if len(digits) == 1 else digits[0] + "." + digits[1:]
    return f"{head}e{'+' if power >= 0 else '-'}{abs(power)}"


def _string(value: str) -> str:
    # Combine explicit surrogate pairs; JSON.stringify escapes only lone surrogates.
    value = value.encode("utf-16-le", "surrogatepass").decode("utf-16-le", "surrogatepass")
    encoded = json.dumps(value, ensure_ascii=False)
    return re.sub(r"[\ud800-\udfff]", lambda m: "\\u%04x" % ord(m[0]), encoded)


def canonical_engine_snapshot_json(value: Any, *, max_depth: int = MAX_DEPTH) -> str:
    active: set[int] = set()

    def encode(item: Any, depth: int) -> str:
        if depth > max_depth:
            _fail("SOURCE_LIMIT_EXCEEDED", "nesting depth")
        if item is None:
            return "null"
        if type(item) is bool:
            return "true" if item else "false"
        if type(item) is str:
            return _string(item)
        if type(item) in (int, float):
            return _number(item)
        if type(item) not in (dict, list, tuple) or id(item) in active:
            _fail("INVALID_RECORD", "non JSON value or cycle")
        active.add(id(item))
        try:
            if isinstance(item, dict):
                if any(type(key) is not str for key in item):
                    _fail("INVALID_RECORD", "non string key")
                keys = sorted(item, key=lambda key: key.encode("utf-16-be", "surrogatepass"))
                return "{" + ",".join(_string(key) + ":" + encode(item[key], depth + 1)
                                      for key in keys) + "}"
            return "[" + ",".join(encode(v, depth + 1) for v in item) + "]"
        finally:
            active.remove(id(item))
    return encode(value, 0)


def canonical_bytes(value: Any, *, max_depth: int = MAX_DEPTH) -> bytes:
    return canonical_engine_snapshot_json(value, max_depth=max_depth).encode("utf-8")


def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def engine_snapshot_page_digest(payload: Mapping[str, Any]) -> str:
    return _digest(canonical_bytes(dict(payload)))


def normalize_observed_at(value: str, *, preserve_precision: bool = False) -> str:
    pattern = (r"\d{4}-\d\d-\d\dT(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d"
               r"(?:\.(\d{1,9}))?(?:Z|[+-](?:0\d|1[0-5]):[0-5]\d)")
    match = re.fullmatch(pattern, value) if isinstance(value, str) else None
    if match is None or len(value) > 40:
        _fail("INVALID_IDENTITY", "observed_at")
    try:
        utc = datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)
    except (ValueError, OverflowError):
        _fail("INVALID_IDENTITY", "observed_at")
    fraction = (match[1] or "").rstrip("0").ljust(3, "0")
    if not preserve_precision:
        fraction = fraction[:3]
    return f"{utc.year:04d}-{utc.month:02d}-{utc.day:02d}T{utc.hour:02d}:{utc.minute:02d}:{utc.second:02d}.{fraction}Z"


def engine_snapshot_digest(host: str, venue: str, metadata: Mapping[str, Any],
                           pages: Sequence[Mapping[str, Any]]) -> str:
    meta = {key: metadata[key] for key in ("producer_epoch", "sequence", "observed_at",
                                         "page_count", "engine_count", "control_count")}
    # Storage digest vectors also cover pre-WIRE high-precision observations.
    # New wire snapshots have already been reduced to milliseconds at freeze.
    meta["observed_at"] = normalize_observed_at(meta["observed_at"], preserve_precision=True)
    return _digest(canonical_bytes({"host": host, "venue": venue, **meta, "pages": list(pages)}))


@dataclass(frozen=True)
class HostContext:
    """Authenticated scope supplied by delivery, never inferred from source files."""
    host: str
    account_lane_id: str | None = None


def _identity(context: HostContext, venue: str, epoch: int, sequence: int) -> None:
    if not isinstance(context, HostContext):
        _fail("INVALID_IDENTITY", "host context")
    _validate_schema({"host": context.host, "venue": venue, "producer_epoch": epoch, "sequence": sequence},
                     "scope", code="INVALID_IDENTITY")
    _validate_schema({"host": context.host, "account_lane_id": context.account_lane_id},
                     "host-context", code="INVALID_IDENTITY")
    if context.account_lane_id is not None and (
            context.host != "kashbot-" + context.account_lane_id or venue != "kalshi"):
        _fail("INVALID_IDENTITY", "account host binding")


@dataclass(frozen=True)
class CapturedSource:
    path: str
    fingerprint: tuple[int, ...] | None
    data: bytes | None


@dataclass(frozen=True)
class EngineSnapshot:
    context: HostContext
    venue: str
    observed_at: str
    producer_epoch: int
    sequence: int
    engines: tuple[bytes, ...]
    controls: tuple[bytes, ...]
    bindings: bytes | None
    runtime: bytes
    refusals: tuple[bytes, ...]
    sources: tuple[CapturedSource, ...] = ()
    runtime_fragments: tuple[bytes, ...] = ()

    def logical_input(self) -> dict[str, Any]:
        result = {"engines": [json.loads(v) for v in self.engines],
                  "controls": [json.loads(v) for v in self.controls],
                  "runtime": json.loads(self.runtime),
                  "refusals": [json.loads(v) for v in self.refusals]}
        if self.bindings is not None:
            result["engine_bindings"] = json.loads(self.bindings)
        return result


def freeze_engine_snapshot(logical: Mapping[str, Any], *, context: HostContext, venue: str,
                           observed_at: str, producer_epoch: int, sequence: int,
                           sources: tuple[CapturedSource, ...] = ()) -> EngineSnapshot:
    """Freeze receiver-normalized JSON. Useful for callers already holding a pure projection."""
    _identity(context, venue, producer_epoch, sequence)
    observed_at = normalize_observed_at(observed_at)
    if set(logical) - {"engines", "controls", "engine_bindings", "runtime", "refusals"}:
        _fail("INVALID_RECORD", "unknown logical field")
    engines, controls = logical.get("engines", []), logical.get("controls", [])
    if not isinstance(engines, (list, tuple)) or not isinstance(controls, (list, tuple)):
        _fail("INVALID_RECORD", "record arrays required")
    if len(engines) > MAX_ENGINES or len(controls) > MAX_CONTROLS:
        _fail("SNAPSHOT_LIMIT_EXCEEDED", "document or control count")
    runtime = logical.get("runtime", {})
    if not isinstance(runtime, dict) or set(runtime) - RUNTIME_KEYS:
        _fail("INVALID_RECORD", "runtime keys")
    breakers = runtime.get("loss_breakers")
    if isinstance(breakers, list):
        accounts = set()
        for block in breakers:
            if not isinstance(block, dict) or not isinstance(block.get("account_id"), str):
                _fail("INVALID_RECORD", "breaker account")
            if block["account_id"] in accounts:
                _fail("INVALID_RECORD", "duplicate logical breaker account")
            accounts.add(block["account_id"])
    bindings = logical.get("engine_bindings")
    if "engine_bindings" in logical and not isinstance(bindings, dict):
        _fail("INVALID_RECORD", "bindings must be absent or an object")
    refs = logical.get("refusals", [])
    if not isinstance(refs, (list, tuple)) or len(refs) > MAX_PAGES * 32:
        _fail("SNAPSHOT_LIMIT_EXCEEDED", "refusal count")
    # This public freeze boundary uses the receiver's number model. Disk and
    # request boundaries validate strict source types before normalization.
    def encode(value, schema):
        value = json.loads(canonical_bytes(value))
        _validate_schema(value, schema, code="INVALID_RECORD", normalize_timestamps=True)
        return canonical_bytes(value)

    runtime_bytes = encode(runtime, "runtime")
    engine_bytes = tuple(encode(v, "engine") for v in engines)
    control_bytes = tuple(encode(v, "control") for v in controls)
    binding_bytes = None if bindings is None else encode(bindings, "bindings")
    refusal_bytes = tuple(encode(v, "refusal") for v in refs)
    return EngineSnapshot(context, venue, observed_at, producer_epoch, sequence,
                          engine_bytes, control_bytes, binding_bytes,
                          runtime_bytes, refusal_bytes, sources,
                          tuple(_encoded_runtime_fragments(runtime_bytes)))


@dataclass(frozen=True)
class SnapshotRequests:
    begin: bytes
    pages: tuple[bytes, ...]
    complete: bytes
    service_envelopes: tuple[bytes, ...]
    content_digest: str
    wire_digest: str


def _object(fields: Mapping[str, bytes]) -> bytes:
    return b"{" + b",".join(canonical_bytes(k) + b":" + fields[k] for k in
                             sorted(fields, key=lambda k: k.encode("utf-16-be", "surrogatepass"))) + b"}"


def _array(rows: Sequence[bytes]) -> bytes:
    return b"[" + b",".join(rows) + b"]"


def _raw_parts(data: bytes) -> list[bytes]:
    """Split a canonical container at its own commas, retaining exact child bytes."""
    if data[1:-1] == b"":
        return []
    start, depth, quoted, escaped = 1, 0, False, False
    parts = []
    for index in range(1, len(data) - 1):
        byte = data[index]
        if quoted:
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                quoted = False
        elif byte == 34:
            quoted = True
        elif byte in (91, 123):
            depth += 1
        elif byte in (93, 125):
            depth -= 1
        elif byte == 44 and depth == 0:
            parts.append(data[start:index])
            start = index + 1
    parts.append(data[start:-1])
    return parts


def _raw_object(data: bytes) -> dict[str, bytes]:
    result = {}
    for field in _raw_parts(data):
        escaped = False
        for index in range(1, len(field)):
            byte = field[index]
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                result[json.loads(field[:index + 1])] = field[index + 2:]
                break
    return result


def _encoded_runtime_fragments(data: bytes, chunk_size: int = 16):
    """Fragment frozen canonical children without serializing any evidence record again."""
    def parts(collection):
        if collection.startswith(b"["):
            return [_array(chunk) for chunk in _chunks(_raw_parts(collection), chunk_size)]
        fields = _raw_object(collection)
        return [_object(dict(chunk)) for chunk in _chunks(list(fields.items()), chunk_size)]

    queues = []
    for key, value in _raw_object(data).items():
        fragments = []
        if key == "loss_breakers" and value.startswith(b"["):
            blocks = _raw_parts(value)
            if not blocks:
                fragments.append(value)
            for block in blocks:
                fields = _raw_object(block)
                if "engines" not in fields or not fields["engines"].startswith(b"{"):
                    _fail("INVALID_RECORD", "breaker map")
                fragments.extend(_array([_object({**fields, "engines": part})]) for part in parts(fields["engines"]))
        elif value.startswith(b"{"):
            fields = _raw_object(value)
            if key == "engine_registry" and "accounts" in fields:
                if not fields["accounts"].startswith(b"{"):
                    _fail("INVALID_RECORD", "registry accounts")
                accounts = _raw_object(fields["accounts"])
                if not accounts:
                    fragments.append(value)
                for aid, account in accounts.items():
                    body = _raw_object(account)
                    if "engines" not in body or not body["engines"].startswith(b"{"):
                        _fail("INVALID_RECORD", "registry engines")
                    fragments.extend(_object({**fields, "accounts": _object({aid: _object({**body, "engines": part})})})
                                     for part in parts(body["engines"]))
            else:
                collections = [name for name in ("rows", "engines", "assignments")
                               if fields.get(name, b"").startswith((b"[", b"{"))]
                if len(collections) > 1:
                    _fail("INVALID_RECORD", "ambiguous runtime collections")
                if collections:
                    name = collections[0]
                    fragments.extend(_object({**fields, name: part}) for part in parts(fields[name]))
                else:
                    fragments.append(value)
        elif value.startswith(b"["):
            fragments.extend(parts(value))
        else:
            fragments.append(value)
        queues.append(deque(_object({key: fragment}) for fragment in fragments))
    while any(queues):
        for queue in queues:
            if queue:
                yield queue.popleft()


def _check_depth(data: bytes, maximum: int) -> None:
    depth, quoted, escaped, scalar = 0, False, False, False
    for byte in data:
        if quoted:
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                quoted = False
        elif byte in (91, 123):
            if depth > maximum:
                _fail("SOURCE_LIMIT_EXCEEDED", "nesting depth")
            depth += 1
        elif byte in (93, 125):
            depth -= 1
        elif byte not in b" \r\n\t,:" and not scalar:
            if depth > maximum:
                _fail("SOURCE_LIMIT_EXCEEDED", "nesting depth")
            quoted = byte == 34
        scalar = not quoted and byte not in b" \r\n\t,:[]{}\""


def _chunks(rows: Sequence[Any], size: int = 16):
    if not rows:
        yield rows
    for start in range(0, len(rows), size):
        yield rows[start:start + size]


def _map_fragments(value: dict[str, Any]):
    items = [(key, value[key]) for key in sorted(value, key=lambda k: k.encode("utf-16-be", "surrogatepass"))]
    for chunk in _chunks(items):
        yield dict(chunk)


def _runtime_fragments(runtime: dict[str, Any]):
    """Only collection boundaries fragment; row contents remain indivisible."""
    for key, value in runtime.items():
        if key == "loss_breakers" and isinstance(value, list):
            if not value:
                yield {key: []}
            for block in value:
                if not isinstance(block, dict) or not isinstance(block.get("engines"), dict):
                    _fail("INVALID_RECORD", "breaker map")
                for engines in _map_fragments(block["engines"]):
                    yield {key: [{**block, "engines": engines}]}
        elif key == "engine_registry" and isinstance(value, dict) and "accounts" in value:
            accounts = value["accounts"]
            if not isinstance(accounts, dict):
                _fail("INVALID_RECORD", "registry accounts")
            if not accounts:
                yield {key: value}
            for aid in sorted(accounts, key=lambda k: k.encode("utf-16-be", "surrogatepass")):
                account = accounts[aid]
                if not isinstance(account, dict) or not isinstance(account.get("engines"), dict):
                    _fail("INVALID_RECORD", "registry engine map")
                for engines in _map_fragments(account["engines"]):
                    yield {key: {**value, "accounts": {aid: {**account, "engines": engines}}}}
        elif isinstance(value, list):
            for chunk in _chunks(value):
                yield {key: chunk}
        elif isinstance(value, dict):
            collections = [name for name in ("rows", "engines", "assignments")
                           if isinstance(value.get(name), (list, dict))]
            if len(collections) > 1:
                _fail("INVALID_RECORD", "ambiguous runtime collections")
            if not collections:
                yield {key: value}
            else:
                name = collections[0]
                parts = (_map_fragments(value[name]) if isinstance(value[name], dict)
                         else _chunks(value[name]))
                for part in parts:
                    yield {key: {**value, name: part}}
        else:
            # Preserve an explicit null (distinct from an absent block).
            yield {key: value}


def _merge_map(left: dict, right: dict) -> dict:
    if not isinstance(left, dict) or not isinstance(right, dict):
        _fail("INVALID_REQUEST", "fragment map type")
    if set(left) & set(right):
        _fail("INVALID_REQUEST", "duplicate fragment map key")
    return {**left, **right}


def _merge_headers(left: dict, right: dict, collection: str) -> dict:
    if (not isinstance(left, dict) or not isinstance(right, dict)
            or collection not in left or collection not in right):
        _fail("INVALID_REQUEST", "fragment collection missing or malformed")
    if canonical_bytes({k: v for k, v in left.items() if k != collection}) != canonical_bytes({
            k: v for k, v in right.items() if k != collection}):
        _fail("INVALID_REQUEST", "conflicting fragment headers")
    a, b = left[collection], right[collection]
    if isinstance(a, list) and isinstance(b, list):
        merged = a + b
    elif isinstance(a, dict) and isinstance(b, dict):
        merged = _merge_map(a, b)
    else:
        _fail("INVALID_REQUEST", "fragment type mismatch")
    return {**left, collection: merged}


# The path is supplied by the object/list/map edges in this table, never inferred
# from a key name or from the spelling of an arbitrary string. Source-only schemas
# describe disk records; projected schemas preserve the producer's optional fields.
# WIRE-v1, S1 24d29be0, and kashbot-engine-runtime.master.ts are the wire authorities.
def _field(kind, *, required=False, nullable=False, **rules):
    return {"type": kind, "required": required, "nullable": nullable, **rules}


def _str(pattern=r"[\s\S]*", **rules):
    return _field("str", pattern=pattern, **rules)


def _int(low=0, high=MAX_SAFE_INTEGER, **rules):
    return _field("int", low=low, high=high, **rules)


def _num(low=0, high=1e100, **rules):
    return _field("number", low=low, high=high, **rules)


def _ref(name, **rules):
    return _field("ref", schema=name, **rules)


def _list(item, high=MAX_PARSED_ROWS, **rules):
    return _field("list", item=item, high=high, **rules)


def _map(key, item, high=MAX_PARSED_ROWS, **rules):
    return _field("map", key=key, item=item, high=high, **rules)


def _obj(fields, *, closed=False, **rules):
    return _field("object", fields=fields, closed=closed, **rules)


_ENGINE_ID = r"[a-z0-9][a-z0-9-]{0,31}"
_TOKEN = r"[A-Za-z0-9._:-]{1,128}"
_STATE = r"[a-z][a-z0-9_]{0,31}"
_DIGEST = r"[a-f0-9]{64}"
_SYMBOL = r"[A-Z0-9-]{1,32}"
_ACCOUNT = r"[^\x00-\x1f\x7f]{1,160}"
_DAY = r"[0-9]{4}-[0-9]{2}-[0-9]{2}"
_STAMP = (r"\d{4}-\d\d-\d\dT(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d"
          r"(?:\.\d{1,9})?(?:Z|[+-](?:0\d|1[0-5]):[0-5]\d)")
# S2 kashbot-engine-runtime.ts:356-362: clocks on typed runtime objects only.
_RUNTIME_CLOCKS = ("observed_at", "at", "as_of", "decided_at", "issued_at", "occurred_at",
                   "expires_at", "updated_at", "ts", "entries_suspended_until", "probe_started_at",
                   "eligibility_expires_at", "halted_at")
_RUNTIME_CLOCK_SCHEMAS = frozenset({"runtime-engine", "registry", "registry-map", "assignment",
                                  "map-assignment", "rollups", "rollup", "verdict", "receipt", "event",
                                  "breaker-block", "lifecycle", "history", "eligibility"})
_TEXT = r"[^\x00-\x1f\x7f]{1,200}"
_I64 = (1 << 63) - 1


def _lifecycle_wire_fields():
    """D10 projection fields, keyed to parseLifecycle in kashbot-engine-runtime.ts."""
    stamp = _str(_STAMP, format="timestamp", nullable=True)
    return {
        "state": _str(_STATE),  # :560
        "entries_enabled": _field("bool", nullable=True),  # :561
        "entries_suspended_until": stamp,  # :562, D10 converts source seconds
        "stop_reasons": _list(_ref("stop-reason"), 16, nullable=True),  # :540-548
        "probe_started_at": stamp,  # :564
        "expires_at": stamp,  # :565
        "contracts": _num(0, 1000000000, nullable=True),  # :566
        "approval_id": _str(_TOKEN, nullable=True),  # :567
        "observations": _int(nullable=True),  # :568, D10 counts the source map
        "eligibility": _ref("eligibility", nullable=True),  # :550-551,569
        "halted_from": _str(_STATE, nullable=True),  # :570
        "halted_at": stamp,  # :571
        "history": _list(_ref("history"), 32, nullable=True),  # :552-557
        "snapshot_digest": _str(_TOKEN, nullable=True),  # :574
    }


# JSON.stringify(Number(INT64_MAX)) uses this shortest decimal spelling.
# Disk integers retain the exact _I64 bound; wire evidence has already rounded.
_WIRE_I64 = 9223372036854776000


def _schema_table():
    from .policy import POLICY_BOUNDS, OPTIONAL_POLICY_BOUNDS, HARD_MAXIMA
    from .canary import MAX_CENTS, STATES
    from .push import _DARKHORSE_COUNTERS, _PROBE_DECISIONS
    from .engine_pnl import ROLLUP_SCHEMA

    stamp = _str(_STAMP, format="timestamp", nullable=True)
    day = _str(_DAY, format="day", nullable=True)
    token = _str(_TOKEN, nullable=True)
    digest = _str(_DIGEST, nullable=True)
    flag = _field("bool", nullable=True)
    cents = _int(0, MAX_CENTS, nullable=True)
    signed_cents = _int(-MAX_CENTS, MAX_CENTS, nullable=True)
    eid = _str(_ENGINE_ID)
    account = _str(_ACCOUNT, nullable=True)
    # Assignments and breaker blocks require the dashboard's encoded triple. Legacy engine
    # account identities remain the strings accepted by engines.account_id.
    canonical_account = _str(r"\[[\s\S]{1,158}\]", format="account")
    policy = {name: (_int(low, high, nullable=name in OPTIONAL_POLICY_BOUNDS) if kind is int
                    else _num(low, high, nullable=name in OPTIONAL_POLICY_BOUNDS))
              for name, (low, high, kind) in {**POLICY_BOUNDS, **OPTIONAL_POLICY_BOUNDS}.items()}
    dark_policy = {"base_count": _num(.01, .50), "max_mult": _num(1, 10),
                   "score_threshold_120": _num(0, 1), "score_threshold_45": _num(0, 1)}
    life = {
        "schema_version": _int(1, 1), "engine_id": eid,
        "state": _str(_STATE, enum=tuple(sorted(STATES))),
        "entries_enabled": flag, "settlement_enabled": flag,
        "broad_live": _str(r"manual_only", enum=("manual_only",), nullable=True),
        "contracts": _int(nullable=True), "entries_suspended_until": _int(nullable=True),
        "shadow_eligible_decisions": _int(nullable=True), "size_fraction": _num(0, 1, nullable=True),
        # kashbot-engine-runtime.ts:568: the D10 wire value is a safe-integer count.
        "observations": _int(nullable=True),
        "utc_day": day, "account_id": account, "approval_id": token,
        "halted_from": _str(_STATE, nullable=True),
        **{name: stamp for name in ("registered_at", "shadow_started_at", "canary_started_at",
            "probe_started_at", "expires_at", "last_observed_at", "shadow_first_decision_at", "halted_at")},
        **{name: digest for name in ("policy_digest", "historical_evidence_digest", "shadow_evidence_digest",
                                    "eligibility_digest", "snapshot_digest")},
        "eligibility": _ref("eligibility", nullable=True), "breaker": _ref("lifecycle-breaker", nullable=True),
        "history": _list(_ref("history")), "stop_reasons": _list(_ref("stop-reason")),
        "policy": _ref("policy"), "historical_evidence": _ref("json-object"),
        "shadow_evidence": _ref("json-object", nullable=True),
        "pnl_baselines": _map(_str(_TEXT), _int(-MAX_CENTS, MAX_CENTS)),
        "shadow_decisions": _list(_ref("json")),
    }
    common_record = {
        "engine_id": eid, "version": _int(1), "revision": _str(_DIGEST),
        "policy_digest": _str(_DIGEST), "effective_policy_digest": _str(_DIGEST),
        "override_revision": _int(), "enabled": flag, "effective_enabled": _field("bool"),
        "override_enabled": flag, "updated_at": stamp,
        "policy": _ref("policy"), "effective_policy": _ref("policy"), "override_policy": _ref("policy"),
        "risk_envelope": _ref("risk-envelope"), "capabilities": _ref("capabilities"),
        "lifecycle": _ref("lifecycle", nullable=True), "darkhorse": _ref("darkhorse"),
    }
    runtime_record = {
        "engine_id": _str(_ENGINE_ID, nullable=True), "engine_id_reason": _str(_TEXT, nullable=True),
        "inputs": _list(_ref("input"), 16), "markets": _list(_str(r"[A-Za-z0-9._:-]{1,96}"), 64),
        "account_id": account, "claim": _ref("claim", nullable=True),
        "revision": token, "lifecycle": _ref("lifecycle", nullable=True),
    }
    breaker = {"pct": _int(0, 100, nullable=True),
               "loss_cents": {**signed_cents, "required": True, "nullable": False}, "limit_cents": cents,
               "suspended": _field("bool", required=True), "inherited": flag}
    assignment = {"engine_id": eid, "account_id": canonical_account, "role": _str(_STATE, nullable=True),
                  "domain": token, "symbols_mask": _int(), "breaker_pct": _int(0, 100, nullable=True)}
    decimal = _field("decimal", signed=False)
    table = {
        "json": _field("json", nullable=True),
        "json-object": _obj({}),
        "policy": _obj(policy),
        "source-policy": _obj(policy, closed=True),
        "dark-policy": _obj(dark_policy, closed=True),
        "engine": _obj({**common_record, "engine_id": {**eid, "required": True},
            "enabled": _field("bool"), "name": _str(r"[^\x00-\x1f\x7f]{1,64}"),
            "description": _str(r"[\s\S]{0,500}"), "parent_engine_id": _str(_ENGINE_ID, nullable=True),
            "created_at": stamp, "account": _ref("account")}, policy_selector=True),
        "control": _obj({**common_record, "engine_id": {**eid, "required": True},
            "effective_enabled": _field("bool", required=True),
            "account": _int(0, 1000000, nullable=True)}, policy_selector=True),
        "account": _obj({**common_record, "account_id": account}),
        "capabilities": _obj({
            **{name: _field("bool") for name in ("exit_rule", "favorites", "big_edge_cap", "reversal", "per_account")},
            "reversal_execution_mode": _int(1, 2), "risk_envelope": _ref("risk-envelope"),
            "variance_estimator": _int(1, 2),
            "exit_variance_estimator": _int(1, 2),
            "bands_open": _list(_str(r"[0-9]+_[0-9]+")), "drawdown_law": _ref("drawdown")}),
        "risk-envelope": _obj({**{name: policy[name] for name in HARD_MAXIMA}, "digest": _str(_DIGEST)}),
        "drawdown": _obj({"brake": _num(0, 1), "stop": _num(0, 1)}),
        "identity": _obj({"schema_version": _int(1, 1, required=True),
            "subaccount_number": _int(0, 1000000, required=True),
            "account_id": _str(_ACCOUNT, required=True),
            "verified_at": {**stamp, "required": True, "nullable": False}}, closed=True),
        "override": _obj({"enabled": {**flag, "required": True}, "policy": _ref("source-policy", required=True),
            "revision": _int(1, required=True), "updated_at": {**stamp, "required": True, "nullable": False}},
            closed=True),
        "overrides": _obj({"schema_version": _int(1, 1, required=True),
            "accounts": _map(_str(_ACCOUNT), _ref("override-account"), 128, required=True)}, closed=True),
        # Mirrors engines.EngineRegistry's 1024-engine catalog capacity (S1).
        "override-account": _obj({"engines": _map(eid, _ref("override"), 1024, required=True)}, closed=True),
        "bindings": _obj({"default": _str(_ENGINE_ID, required=True, nullable=True),
            "symbols": _map(_str(_SYMBOL), eid, required=True),
            "disabled": _list(_str(_SYMBOL), 64, unique=True)}, closed=True),
        "lifecycle": _obj({**life, **_lifecycle_wire_fields()}),
        "lifecycle-breaker": _obj({
            "utc_day": {**day, "required": True, "nullable": False},
            **{name: _int(0, 100, nullable=True) for name in ("engine_pct", "account_pct")},
            **{name: cents for name in ("day_start_marked_cents", "account_loss_cents", "account_limit_cents",
                                       "engine_loss_cents", "engine_limit_cents", "account_risk_net_loss_cents",
                                       "probe_attributed_loss_cents")},
            **{name: {**cents, "required": True, "nullable": False}
               for name in ("account_loss_cents", "engine_loss_cents")},
            **{name: _field("bool", required=True) for name in ("engine_suspended", "account_suspended")},
            "inherited": flag,
            "account_loss_basis": token, "probe_gate_loss_basis": token}),
        "eligibility": _obj({"expires_at": stamp, "issued_at": stamp, "account_id": account,
                             "engine_id": eid, "approval_id": token, "digest": digest}),
        "history": _obj({"state": _str(_STATE), "at": stamp, "ts": stamp,
            "contracts": _field("union", nullable=True, choices=(
                _int(), _num(.01, .99, enum=tuple(float(f"0.{rung:02d}") for rung in range(1, 100))))),
            "entries_suspended_until": _int(nullable=True), "realized_cents": signed_cents,
            "amount_cents": signed_cents, "balance_cents": cents, "reason": _str(r"[\s\S]{0,512}"),
            "approval_id": token, "account_id": account, "expires_at": stamp}),
        "stop-reason": _field("union", choices=(_str(r"[A-Za-z0-9._:-]{1,64}"),
            _obj({"code": _str(r"[A-Za-z0-9._:-]{1,64}", required=True),
                  "text": _str(r"[\s\S]{0,512}", nullable=True)}))),
        "input": _obj({"kind": _str(r"kalshi_book|index|feed|derived", required=True),
                      "id": _str(r"[A-Za-z0-9._:/-]{1,96}", required=True)}, closed=True),
        "claim": _obj({"account_id": account, "domain": token, "role": _str(_STATE, nullable=True)}),
        "runtime-engine": _obj(runtime_record),
        "assignment": _obj({**assignment,
            "engine_id": {**eid, "required": True}, "account_id": {**canonical_account, "required": True}}),
        "map-assignment": _obj(assignment),
        "registry-account": _obj({"label": _str(r"[\s\S]{0,512}"), "breaker_pct": _int(0, 100),
            "engines": _map(eid, _ref("map-assignment"), required=True)}),
        "registry": _obj({"schema": _str(r"[A-Za-z0-9._:/-]{1,64}"), "generation": _int(1, required=True),
            "digest": _str(_DIGEST, required=True), "updated_at": stamp,
            "default_breaker_pct": _int(0, 100), "max_concurrent_probes": _int(),
            "assignment_count": _int(), "assignments": _list(_ref("assignment")),
            "accounts": _map(_str(_ACCOUNT), _ref("registry-account")),
            "loss_breakers": _ref("json-object"), "exposure": _ref("json-object"), "audit": _ref("json")},
            variants=((("accounts",), ("assignments",), "registry-map"),)),
        "registry-map": _obj({"schema": _int(1, 1), "generation": _int(1),
            "accounts": _map(_str(_ACCOUNT), _ref("registry-account"), required=True)}),
        "breaker": _obj(breaker),
        "breaker-block": _obj({"schema": _str(r"[A-Za-z0-9._:/-]{1,64}"),
            "utc_day": {**day, "required": True, "nullable": False},
            "account_id": {**canonical_account, "required": True}, "day_start_portfolio_cents": cents,
            "account": _ref("breaker", required=True),
            "observed_at": {**stamp, "required": True, "nullable": False},
            "engines": _map(eid, _ref("breaker"), required=True)}),
        "rollups": _obj({"schema": (_int(ROLLUP_SCHEMA, ROLLUP_SCHEMA) if type(ROLLUP_SCHEMA) is int
                                   else _str(re.escape(ROLLUP_SCHEMA), enum=(ROLLUP_SCHEMA,))),
            "as_of": stamp, "utc_day": day,
            "lifetime_basis": _str(_TOKEN), "truncated": _int(), "rows": _list(_ref("rollup"), required=True)}),
        "rollup": _obj({**runtime_record, "role": _str(r"incumbent|probe"),
            "account_digest": digest, "symbols": _list(_str(r"[A-Za-z0-9._:-]{1,96}"), 64),
            "day": _ref("totals"), "lifetime": _ref("totals", nullable=True),
            "open": _ref("positions", nullable=True)}),
        "totals": _obj({**{name: _int(0, 1000000000) for name in ("entries", "settled", "won", "lost", "voided", "exits")},
            "realized_cents": _int(-100000000000, 100000000000), "contracts": _num(0, 1000000000)}),
        "positions": _obj({"positions": _int(0, 1000000000), "cost_cents": _int(0, 100000000000)}),
        "exposure": _obj({"schema": _int(1, 1, required=True), "engine_id": eid,
            "entries": _map(_str(r"[^\x00-\x1f\x7f]{1,128}"), _ref("exposure-entry"), required=True),
            "days": _map({**day, "nullable": False}, _ref("exposure-day"), required=True)}),
        "exposure-day": _obj({"realized_cents": {**signed_cents, "required": True, "nullable": False},
                             "consumed_cents": {**cents, "nullable": False}}),
        "exposure-entry": _obj({"state": _str(r"reserved|sent|unknown|open|closed|released|zero_fill", required=True),
            "reserved_day": {**day, "required": True, "nullable": False}, "closed_day": day,
            "count": {**decimal, "nullable": True}, "cost_cents": cents,
            "worst_case_cents": {**cents, "nullable": False},
            "realized_cents": signed_cents, "kind": _str(r"settled|voided|exit"),
            "ticker": _str(r"[A-Za-z0-9_-]{1,128}")},
            conditions=(("state", ("open", "closed"), {"count": {**decimal, "required": True},
                "cost_cents": {**cents, "required": True, "nullable": False}}),
                ("state", ("closed",), {"realized_cents": {**signed_cents, "required": True, "nullable": False},
                    "closed_day": {**day, "required": True, "nullable": False},
                    "kind": _str(r"settled|voided|exit", required=True)}),
                ("state", ("zero_fill",), {"cost_cents": {**cents, "nullable": False}}))),
        "population": _obj({name: _int(nullable=True) for name in ("tickets", "markets", "blocks", "days")}),
        "gate": _obj({"passed": _field("bool"), "failed_checks": _list(_str(r"[^\x00-\x1f\x7f]{1,32}"))}),
        "verdict": _obj({"schema": _str(r"leafhft\.engine_ops\.verdict\.v1"), "engine_id": eid,
            "at": stamp, "utc_day": day, "account_id": account,
            "trial_id": _str(r"[^\x00-\x1f\x7f]{1,64}", nullable=True),
            "decision": _str(_TOKEN, enum=tuple(sorted(_PROBE_DECISIONS))),
            "verdict": _str(r"[^\x00-\x1f\x7f]{1,16}", nullable=True),
            "read_kind": _str(r"[^\x00-\x1f\x7f]{1,32}", nullable=True),
            "activated": _field("bool"), "gate": _ref("gate", nullable=True), "gate_passed": flag,
            "failed_checks": _list(_str(r"[^\x00-\x1f\x7f]{1,32}")),
            "population": _ref("population", nullable=True), "next_read_at": stamp}),
        "receipt": _obj({"schema_version": _int(1), "engine_id": eid, "utc_day": day,
            "account_id": account, "at": stamp, "observed_at": stamp, "decided_at": stamp, "issued_at": stamp}),
        "event": _obj({"engine_id": eid, "at_ms": _int(),
            "kind": _str(r"proposal|sized|refused|conflict|superseded"),
            "counterpart_engine_ids": _list(eid), "event_id": token, "decision_id": token,
            "account_id": account, "at": stamp, "occurred_at": stamp, "ts": stamp,
            "ticker": _str(r"[^\x00-\x1f\x7f]{1,128}", nullable=True),
            "reason": _str(r"[^\x00-\x1f\x7f]{1,128}", nullable=True), "symbol": _str(_SYMBOL)}),
        "run-config": _obj({"venue": _str(r"[a-z_]{1,32}", required=True), "symbol": _str(_SYMBOL, required=True)}),
        "run-status": _obj({"executor": _ref("executor"), "darkhorse": _ref("source-telemetry")}),
        "executor": _obj({"events": _list(_ref("source-event"))}),
        "refusal": _obj({"code": _str(r"[A-Z][A-Z0-9_]{0,63}", required=True),
            "engine_id": {**eid, "required": True},
            "account_id": {**canonical_account, "required": True, "nullable": True}}, closed=True),
        "darkhorse": _obj({"available": _field("bool"), "error": _str(r"[\s\S]{0,4096}", nullable=True),
            "models": _list(_ref("model")), "bounds": _ref("dark-bounds"), "updated_at": stamp,
            "pending": _field("bool"), "stale": _field("bool"), "history": _list(_ref("dark-history")),
            "orders": _list(_ref("order")), "telemetry": _list(_ref("telemetry"))}),
        "dark-bounds": _obj({"base_count": _list(_num(0, 10), 2), "max_mult": _list(_num(0, 10), 2)}),
        "model": _obj({"offset": _num(), "sha": _str(_DIGEST),
            **{name: _num(0, 1) for name in ("trained_threshold", "score_p99", "score_threshold")}}),
        "dark-history": _obj({"revision": _int(1, required=True), "enabled": _field("bool", required=True),
            "policy": _ref("dark-policy", required=True), "updated_at": {**stamp, "required": True, "nullable": False}}),
        "order": _obj({**{name: _num(0, 1e12) for name in ("count", "price_cents", "cost_cents", "fee_cents")},
            "pnl_cents": _num(-1e12, 1e12), **{name: _int(0, _WIRE_I64) for name in ("ts_ns", "settled_ns", "opened_ns")},
            **{name: _str(r"[A-Za-z0-9_-]{1,128}") for name in ("kind", "ticker", "client_id")},
            "side_yes": _field("bool")}),
        "telemetry": _obj({**{name: _int(0, _WIRE_I64) for name in ("orders", "fills", "claims")},
            "days_left": _num(-1e12, 1e12), "armed": _field("bool"), "disabled": _field("bool"),
            "latched": _str(r"max_daily_gross_loss_cents|max_filled_tickets|pilot_days", nullable=True),
            "stats": _ref("dark-stats"), "refusals": _ref("dark-refusals"), "recent": _list(_ref("dark-recent")),
            "score_max": _list(_num(0, 1, nullable=True)), "last_score": _list(_num(0, 1, nullable=True)),
            "run_id": _str(r"[A-Za-z0-9._:-]{1,128}"), "observed_at": stamp, "stale": _field("bool")}),
        "dark-stats": _obj({name: _int(0, _WIRE_I64) for name in _DARKHORSE_COUNTERS}),
        "dark-refusals": _obj({name: _int(0, _WIRE_I64) for name in ("pilot_stop", "unknown_lane", "latched",
            "disabled", "expired", "max_daily_gross_loss_cents", "max_filled_tickets", "pilot_days")}),
        "dark-recent": _obj({"ticker": _str(r"[A-Za-z0-9_-]{1,128}"),
            "reason": _str(_TOKEN, enum=tuple(_DARKHORSE_COUNTERS)),
            **{name: _num(-1e12, 1e12) for name in ("offset", "score", "threshold", "cheap_ask")}}),
        "dark-config": _obj({"armed": _int(0, 1, required=True),
            "base_count": _field("decimal-string", pattern=r"[0-9]{1,3}(?:\.[0-9]{1,2})?",
                                 low=.01, high=.50, required=True),
            "max_mult": _field("decimal-string", pattern=r"[0-9]{1,3}(?:\.[0-9]{1,2})?",
                               low=1, high=10, required=True),
            "models": _list(_str(r"[^\x00-\x1f]{1,4096}"), 2, required=True, low=2, unique=True),
            "max_filled_tickets": _int(1, 500, required=True), "pilot_days": _int(1, 60, required=True),
            "pilot_start": {**day, "required": True, "nullable": False}}, closed=True),
        "dark-model": _obj({"schema_version": _int(1, 1, required=True),
            "feature_names": _list(_str(_TOKEN), required=True, unique=True, low=1),
            **{name: _map(_str(_TOKEN), _num(-1e100, 1e100), required=True)
               for name in ("standardiser_mean", "standardiser_std", "coefficients")},
            "entry_offset_s": _num(required=True), "score_threshold": _num(0, 1, required=True),
            "score_p99": _num(0, 1, required=True), "cheap_side_band": _ref("price-band", required=True),
            "max_quote_age_ms": _num()}),
        "price-band": _obj({"min_ask": _num(0, 100, required=True), "max_price": _num(0, 100, required=True)}),
        "dark-controls": _obj({"account_id": _str(_ACCOUNT, required=True),
            "enabled": _field("bool", required=True), "policy": _ref("dark-policy", required=True),
            "revision": _int(1, required=True), "updated_at": {**stamp, "required": True, "nullable": False},
            "history": _list(_ref("dark-history"), 20, required=True)}, closed=True),
        "ledger": _obj({"kind": _str(_STATE, required=True),
            **{name: _int(0, _I64) for name in ("ts_ns", "settled_ns", "opened_ns")},
            **{name: _int(0, _I64) for name in ("cost_cents", "price_cents", "fee_cents")},
            "pnl_cents": _int(-(1 << 63), _I64), "count": decimal,
            "client_id": _str(r"[A-Za-z0-9_-]{1,128}"), "ticker": _str(r"[A-Za-z0-9_-]{1,128}"),
            "attribution": _ref("attribution")}, conditions=(
                ("kind", ("buy",), {"ts_ns": _int(0, _I64, required=True), "count": {**decimal, "required": True}}),
                ("kind", ("settle", "void"), {"settled_ns": _int(0, _I64, required=True),
                    "pnl_cents": _int(-(1 << 63), _I64, required=True)}),
                ("kind", ("exit",), {"ts_ns": _int(0, _I64, required=True),
                    "pnl_cents": _int(-(1 << 63), _I64, required=True)}))),
        "attribution": _obj({"schema_version": _int(1, 1, required=True),
            "cluster_minute": _int(-1, required=True),
            **{name: _str(r"unknown|[a-f0-9]{32}|[a-f0-9]{64}", required=True)
               for name in ("decision_id", "account_digest", "policy_digest")},
            "engine_id": {**eid, "required": True}, "reason": _str(r"[\s\S]{0,400}", required=True),
            "digest": _str(_DIGEST, required=True), "market_inputs": _ref("market-inputs", required=True),
            "sizing_inputs": _ref("sizing-inputs", required=True)}),
        "market-inputs": _obj({"price_cents": decimal}),
        "sizing-inputs": _obj({"requested_count": decimal}),
    }

    registry_key = _str(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}")
    domain = _str(r"legacy-owner|account-lane:[a-z0-9][a-z0-9-]{0,63}")
    generation = _field("decimal-string", pattern=r"0|[1-9][0-9]{0,8}", low=1, high=999999999)
    pct = _field("decimal-string", pattern=r"0|[1-9][0-9]{0,8}", low=1, high=100)
    table.update({
        "source-registry": _obj({
            "schema": _str(r"leafhft\.engine_registry\.v[12]", required=True),
            "generation": {**generation, "required": True}, "previous_digest": {**digest, "required": True},
            "accounts": _map(registry_key, _ref("source-registry-account"), 32, required=True),
            # Mirrors engine_registry.MAX_ASSIGNMENTS (S1).
            "assignments": _map(eid, _ref("source-assignment"), 1024, required=True),
            "loss_breakers": _ref("source-registry-breakers", required=True),
            "exposure": _ref("source-registry-exposure", required=True),
            # Mirrors engine_registry's max_concurrent_probes bound (S1).
            "max_concurrent_probes": _field("decimal-string", pattern=r"0|[1-9][0-9]{0,8}",
                                          low=0, high=1024, required=True),
            "roles_by_generation": _map(generation, _map(domain, _str(r"authority|exit_only"), 32), 256, required=True),
            "digest": _str(_DIGEST, required=True)}, closed=True),
        "source-registry-account": _obj({
            "kind": _str(r"owner|tenant", required=True),
            "lane_id": _str(r"[a-z0-9][a-z0-9-]{0,63}", required=True, nullable=True),
            "label": _str(r"[^\x00-\x1f\x7f]{1,48}", required=True),
            "member_key": {**registry_key, "required": True}, "domain": {**domain, "required": True},
            "exit_only": _field("bool", required=True),
            "book_account_id": _str(r"[^\x00-\x1f\x7f]{1,128}", nullable=True)}, closed=True),
        "source-assignment": _obj({
            "account_id": {**registry_key, "required": True}, "domain": {**domain, "required": True},
            "role": _str(r"probe|graduated|legacy", required=True),
            "symbols": _list(_str(_SYMBOL), required=True, unique=True),
            "identity_digest": {**digest, "required": True}, "manifest_digest": {**digest, "required": True},
            "since": {**stamp, "required": True, "nullable": False},
            "request_id": {**token, "required": True}, "approval_id": {**token, "required": True},
            "previous_bindings": _map(_str(_SYMBOL), _str(_ENGINE_ID, nullable=True), required=True, nullable=True)},
            closed=True),
        "source-registry-breakers": _obj({"default_pct": {**pct, "required": True},
            "accounts": _map(registry_key, pct, required=True),
            "engines": _map(eid, {**pct, "nullable": True}, required=True)}, closed=True),
        "source-registry-exposure": _obj({"members": _map(registry_key, _ref("source-member"), required=True)}, closed=True),
        "source-member": _obj({"authority_domain": {**domain, "required": True, "nullable": True},
            "transfer": _ref("source-transfer", required=True, nullable=True)}, closed=True),
        "source-transfer": _obj({"draining_from": {**domain, "required": True},
            "started_at": {**stamp, "required": True, "nullable": False},
            "step": _str(r"draining|reconciling|flat_proven", required=True)}, closed=True),
        "publication": _obj({"generation": {**generation, "required": True},
            "digest": _str(_DIGEST, required=True), "state": _str(r"publishing|published", required=True)}, closed=True),
    })
    table["source-engine"] = _obj({
        **table["engine"]["fields"], "policy": _ref("source-policy", required=True),
        **{name: {**table["engine"]["fields"][name], "required": True, "nullable": name == "parent_engine_id"}
           for name in ("engine_id", "name", "description", "version", "parent_engine_id", "created_at", "updated_at")},
        "enabled": _field("bool")})
    # Frozen source evidence retains strict integers; only D10 wire history converts rungs.
    table["source-history"] = _obj({**table["history"]["fields"], "contracts": _int(nullable=True)})
    table["source-lifecycle"] = _obj({**life, "schema_version": _int(1, 1, required=True),
        "history": _list(_ref("source-history")),
        "observations": _map(_str(_TEXT), _int(-MAX_CENTS, MAX_CENTS), 32),
        "shadow_eligible_decisions": _int(), "entries_enabled": _field("bool"),
        "settlement_enabled": _field("bool"),
        "broad_live": _str(r"manual_only", enum=("manual_only",))})
    table["ledger-open"] = _obj({"cost_cents": _int(0, _I64, required=True)})
    table["source-event"] = _obj({**table["event"]["fields"], "at_ms": _int(required=True)})
    table["source-verdict"] = _obj({**table["verdict"]["fields"],
        **{name: {**table["verdict"]["fields"][name], "required": True, "nullable": False}
           for name in ("schema", "engine_id", "at", "decision")}})
    table["source-dark-stats"] = _obj({name: _int(0, _I64) for name in _DARKHORSE_COUNTERS})
    table["source-dark-refusals"] = _obj({name: _int(0, _I64) for name in table["dark-refusals"]["fields"]})
    table["source-telemetry"] = _obj({**table["telemetry"]["fields"],
        **{name: _int(0, _I64) for name in ("orders", "fills", "claims")},
        "stats": _ref("source-dark-stats"), "refusals": _ref("source-dark-refusals")})
    table["dark-ledger"] = _obj({**table["order"]["fields"],
        **{name: _int(0, _I64) for name in ("ts_ns", "settled_ns", "opened_ns")},
        "kind": _str(_STATE, required=True), "lane": _str(r"[a-z][a-z0-9_-]{0,31}", nullable=True),
        **{name: _field("decimal", signed=name == "pnl_cents")
           for name in ("count", "price_cents", "cost_cents", "fee_cents", "pnl_cents")}})
    table["runtime"] = _obj({
        "engines": _list(_ref("runtime-engine"), nullable=True),
        "engine_registry": _ref("registry"), "loss_breakers": _field("union", nullable=True,
            choices=(_list(_ref("breaker-block")), _ref("breaker-block"))),
        "engine_rollups": _ref("rollups", nullable=True),
        "probe_verdicts": _list(_ref("verdict"), nullable=True),
        "conform_receipts": _list(_ref("receipt"), nullable=True),
        "execution_events": _list(_ref("event"), nullable=True)}, closed=True)
    table["logical"] = _obj({"engines": _list(_ref("engine")), "controls": _list(_ref("control")),
        "engine_bindings": _ref("bindings"), "runtime": _ref("runtime"),
        "refusals": _list(_ref("refusal"))}, closed=True)
    table["records"] = _obj({"engines": _list(_ref("engine"), 16, required=True),
        "controls": _list(_ref("control"), 32, required=True)}, closed=True)
    table["auxiliary"] = _obj({"engine_bindings": _ref("bindings", required=True, nullable=True),
        "runtime": _ref("runtime", required=True), "refusals": _list(_ref("refusal"), 32, required=True)}, closed=True)
    scope = {"host": _str(r"[A-Za-z0-9._:-]{1,64}", required=True),
        "venue": _str(r"[a-z_]{1,32}", required=True),
        "producer_epoch": _int(1, required=True), "sequence": _int(1, required=True)}
    metadata = {**scope, "observed_at": {**stamp, "required": True, "nullable": False},
        "page_count": _int(1, MAX_PAGES, required=True), "engine_count": _int(0, MAX_ENGINES, required=True),
        "control_count": _int(0, MAX_CONTROLS, required=True)}
    digests = {name: _str(_DIGEST, required=True) for name in ("content_digest", "wire_digest")}
    for op, fields in (("begin", {**metadata, **digests}), ("complete", {**scope, **digests}),
                       ("page", {**scope, "page_index": _int(0, MAX_PAGES - 1, required=True),
                         "page_digest": _str(_DIGEST, required=True), "wire_page_digest": _str(_DIGEST, required=True),
                         "records": _ref("records", required=True), "auxiliary": _ref("auxiliary", required=True)})):
        table[op] = _obj({**fields, "version": _int(1, 1, required=True),
            "op": _str(op, enum=(op,), required=True)}, closed=True)
        table["request-" + op] = _obj({"engine_snapshot": _ref(op, required=True)}, closed=True)
    table["scope"] = _obj(scope, closed=True)
    table["host-context"] = _obj({"host": scope["host"],
        "account_lane_id": _str(r"[A-Za-z0-9._:-]{1,56}", nullable=True, required=True)}, closed=True)
    table["metadata"] = _obj(metadata, closed=True)
    table["service-page"] = _obj({**table["records"]["fields"], "page_index": _int(0, 127, required=True)}, closed=True)
    table["service-envelope"] = _obj({**scope, "page": _ref("service-page", required=True)}, closed=True)
    return table


# Built lazily to avoid importing push (the legacy delivery module) at module import.
SNAPSHOT_SCHEMA: dict[str, dict[str, Any]] = {}
_SCHEMA_ROLLUP_VERSION: int | str | None = None


def _schemas():
    from .engine_pnl import ROLLUP_SCHEMA

    global _SCHEMA_ROLLUP_VERSION
    if (not SNAPSHOT_SCHEMA or type(_SCHEMA_ROLLUP_VERSION) is not type(ROLLUP_SCHEMA)
            or _SCHEMA_ROLLUP_VERSION != ROLLUP_SCHEMA):
        SNAPSHOT_SCHEMA.update(_schema_table())
        _SCHEMA_ROLLUP_VERSION = ROLLUP_SCHEMA
    return SNAPSHOT_SCHEMA


def _validate_schema(value: Any, schema: str | dict, *, code="EVIDENCE_INVALID",
                     path: str | None = None, shallow=False, dark=False, depth=0,
                     normalize_timestamps=False) -> None:
    """One walker for source, projection and request boundaries; no coercion."""
    table = _schemas()
    rule = table[schema] if isinstance(schema, str) else schema
    where = path or (schema if isinstance(schema, str) else "value")
    if depth > MAX_DEPTH:
        _fail("SOURCE_LIMIT_EXCEEDED", where + ": nesting depth")
    if value is None and rule["nullable"]:
        return
    kind = rule["type"]

    def walk(item, child, label, **options):
        _validate_schema(item, child, code=code, path=label, dark=dark, depth=depth + 1,
                         normalize_timestamps=normalize_timestamps, **options)

    if kind == "ref":
        target = rule["schema"]
        if dark and target == "policy":
            target = "dark-policy"
        _validate_schema(value, target, code=code, path=where, shallow=shallow, dark=dark, depth=depth,
                         normalize_timestamps=normalize_timestamps)
        return
    if kind == "union":
        for choice in rule["choices"]:
            try:
                walk(value, choice, where)
                return
            except SnapshotConstructionError as exc:
                if exc.code == "SOURCE_LIMIT_EXCEEDED":
                    raise
        _fail(code, where + ": no declared type matches")
    if kind in ("object", "map"):
        _strict_value(value, dict, where, code=code)
        if kind == "map":
            if len(value) > rule["high"]:
                _fail(code, where + ": map bound")
            for key, item in value.items():
                walk(key, rule["key"], where + ".<key>")
                walk(item, rule["item"], where + "[" + key + "]")
            return
        for present, absent, target in rule.get("variants", ()):
            if all(field in value for field in present) and all(field not in value for field in absent):
                walk(value, target, where)
                return
        dark = dark or (rule.get("policy_selector", False) and value.get("engine_id") == "darkhorse")
        fields = dict(rule["fields"])
        for key, allowed, extra in rule.get("conditions", ()):
            if value.get(key) in allowed:
                fields.update(extra)
        if rule["closed"] and set(value) - set(fields):
            _fail(code, where + ": unknown field")
        for name, child in fields.items():
            label = where + "." + name
            if name not in value:
                if child["required"]:
                    _fail(code, label + ": required")
            elif not (shallow and child["type"] in ("ref", "object", "list", "map")):
                walk(value[name], child, label)
                if normalize_timestamps and child.get("format") == "timestamp" and value[name] is not None:
                    value[name] = normalize_observed_at(value[name])
        if normalize_timestamps and isinstance(schema, str) and schema in _RUNTIME_CLOCK_SCHEMAS:
            for name in _RUNTIME_CLOCKS:
                # Explicit integer clocks (e.g. lifecycle suspension) keep their units.
                if name not in fields and value.get(name) is not None:
                    value[name] = normalize_observed_at(value[name])
        # Extensions stay opaque JSON. A map key named "version" is not a field.
        for name in set(value) - set(fields):
            walk(value[name], "json", where + "." + str(name))
        return
    if kind == "list":
        _strict_value(value, list, where, code=code)
        if not rule.get("low", 0) <= len(value) <= rule["high"]:
            _fail(code, where + ": list bound")
        if rule.get("unique") and len({canonical_bytes(v) for v in value}) != len(value):
            _fail(code, where + ": duplicate item")
        for index, item in enumerate(value):
            walk(item, rule["item"], f"{where}[{index}]")
        return
    if kind == "json":
        canonical_bytes(value, max_depth=MAX_DEPTH - depth)
        return
    if kind in ("decimal", "decimal-string"):
        try:
            if kind == "decimal-string" and type(value) is not str:
                _fail(code, where)
            if "pattern" in rule and (type(value) is not str or re.fullmatch(rule["pattern"], value) is None):
                _fail(code, where + ": decimal spelling")
            number = _evidence_decimal(value, signed=rule.get("signed", False))
            if not Decimal(str(rule.get("low", "-1e100"))) <= number <= Decimal(str(rule.get("high", "1e100"))):
                _fail(code, where + ": decimal bound")
        except SnapshotConstructionError as exc:
            _fail(code, where + ": " + str(exc))
        return
    types = {"str": str, "int": int, "number": float, "bool": bool}
    _strict_value(value, types[kind], where, low=rule.get("low", 0),
                  high=rule.get("high", MAX_SAFE_INTEGER), pattern=rule.get("pattern"), code=code)
    if "enum" in rule and value not in rule["enum"]:
        _fail(code, where + ": enum")
    form = rule.get("format")
    if form == "timestamp":
        try:
            normalize_observed_at(value)
        except SnapshotConstructionError:
            _fail(code, where + ": timestamp")
    elif form == "day":
        from datetime import date
        try:
            date.fromisoformat(value)
        except ValueError:
            _fail(code, where + ": day")
    elif form == "account":
        if not _s2_accepts("account_id", value):
            _fail(code, where + ": canonical account id")


def _merge_runtime(target: dict, fragment: dict) -> None:
    _validate_schema(fragment, "runtime", code="INVALID_REQUEST")
    for key, value in fragment.items():
        if key not in target:
            target[key] = value
            continue
        prior = target[key]
        if key == "loss_breakers" and isinstance(prior, list) and isinstance(value, list):
            for block in value:
                match = next((i for i, row in enumerate(prior)
                              if row.get("account_id") == block.get("account_id")), None)
                if match is None:
                    prior.append(block)
                else:
                    prior[match] = _merge_headers(prior[match], block, "engines")
        elif key == "engine_registry" and isinstance(prior, dict) and "accounts" in prior:
            if not isinstance(value, dict) or not isinstance(value.get("accounts"), dict):
                _fail("INVALID_REQUEST", "registry fragment type")
            if canonical_bytes({k: v for k, v in prior.items() if k != "accounts"}) != canonical_bytes({
                    k: v for k, v in value.items() if k != "accounts"}):
                _fail("INVALID_REQUEST", "registry headers")
            for aid, account in value["accounts"].items():
                if aid in prior["accounts"]:
                    prior["accounts"][aid] = _merge_headers(prior["accounts"][aid], account, "engines")
                else:
                    prior["accounts"][aid] = account
        elif isinstance(prior, list) and isinstance(value, list):
            prior.extend(value)
        elif isinstance(prior, dict) and isinstance(value, dict):
            collection = next((name for name in ("rows", "engines", "assignments")
                               if isinstance(prior.get(name), (list, dict))), None)
            if collection is None:
                _fail("INVALID_REQUEST", "duplicate indivisible runtime block")
            target[key] = _merge_headers(prior, value, collection)
        else:
            _fail("INVALID_REQUEST", "duplicate runtime scalar")


def build_snapshot_requests(snapshot: EngineSnapshot) -> SnapshotRequests:
    """Pack retained record bytes; never reads sources and never returns a partial generation."""
    _identity(snapshot.context, snapshot.venue, snapshot.producer_epoch, snapshot.sequence)
    if len(snapshot.engines) > MAX_ENGINES or len(snapshot.controls) > MAX_CONTROLS:
        _fail("SNAPSHOT_LIMIT_EXCEEDED", "record count")
    if snapshot.bindings is not None and len(snapshot.bindings) > MAX_BINDING_BYTES:
        _fail("RECORD_TOO_LARGE", "bindings")
    scope = {"host": snapshot.context.host, "venue": snapshot.venue,
             "producer_epoch": snapshot.producer_epoch, "sequence": snapshot.sequence}
    scope_bytes = {key: canonical_bytes(value) for key, value in scope.items()}
    page_payloads: list[bytes] = []
    records_payloads: list[bytes] = []
    requests: list[bytes] = []
    services: list[bytes] = []
    engines: list[bytes] = []
    controls: list[bytes] = []
    refusals: list[bytes] = []
    pending_refusals = deque(snapshot.refusals)
    binding = b"null"
    runtime: dict[str, bytes] = {}

    def render():
        records = _object({"engines": _array(engines), "controls": _array(controls)})
        auxiliary = _object({"engine_bindings": binding, "runtime": _object(runtime),
                             "refusals": _array(refusals)})
        payload = _object({"records": records, "auxiliary": auxiliary})
        index = canonical_bytes(len(requests))
        envelope = _object({**scope_bytes, "version": b"1", "op": b'"page"', "page_index": index,
                            "page_digest": canonical_bytes(_digest(records)),
                            "wire_page_digest": canonical_bytes(_digest(payload)),
                            "records": records, "auxiliary": auxiliary})
        request = _object({"engine_snapshot": envelope})
        service = _object({**scope_bytes, "page": _object({"page_index": index,
                            "engines": _array(engines), "controls": _array(controls)})})
        fits = (len(engines) <= ENGINES_PER_PAGE and len(controls) <= CONTROLS_PER_PAGE
                and len(refusals) <= 32 and len(payload) <= MAX_RECORD_BYTES
                and len(request) <= MAX_REQUEST_BYTES and len(service) <= MAX_SERVICE_ENVELOPE_BYTES)
        return fits, records, payload, request, service

    def flush():
        nonlocal engines, controls, refusals, binding, runtime
        fits, records, payload, request, service = render()
        if not fits:
            _fail("RECORD_TOO_LARGE", "indivisible record")
        if len(requests) >= MAX_PAGES:
            _fail("SNAPSHOT_LIMIT_EXCEEDED", "page count")
        # Refusals fill spare capacity only after content fixes the page boundary.
        # They must never add pages or move records into a different content digest.
        while pending_refusals and len(refusals) < 32:
            refusals.append(pending_refusals[0])
            candidate = render()
            if not candidate[0]:
                refusals.pop()
                break
            pending_refusals.popleft()
            fits, records, payload, request, service = candidate
        # Wrapping in wire digest adds two levels; check before any request is exposed.
        _check_depth(payload, MAX_PAGE_DEPTH)
        records_payloads.append(records)
        page_payloads.append(payload)
        requests.append(request)
        services.append(service)
        engines, controls, refusals, binding, runtime = [], [], [], b"null", {}

    units = []
    # Interleave the independent record arrays so count limits do not waste pages.
    for start in range(max((len(snapshot.engines) + 15) // 16, (len(snapshot.controls) + 31) // 32)):
        units.extend(("engine", row) for row in snapshot.engines[start * 16:(start + 1) * 16])
        units.extend(("control", row) for row in snapshot.controls[start * 32:(start + 1) * 32])
    if snapshot.bindings is not None:
        units.append(("binding", snapshot.bindings))
    units += [("runtime", fragment) for fragment in snapshot.runtime_fragments]
    units = deque(units)
    while units:
        kind, value = units.popleft()
        if kind == "runtime":
            key, value_bytes = next(iter(_raw_object(value).items()))
        # Runtime fragments stay on separate pages when their collection key repeats. This
        # keeps the 16-row fragment bound independent of remaining byte capacity.
        if kind == "runtime" and key in runtime:
            flush()
        old = (list(engines), list(controls), list(refusals), binding, dict(runtime))
        if kind == "engine":
            engines.append(value)
        elif kind == "control":
            controls.append(value)
        elif kind == "binding":
            binding = value
        else:
            runtime[key] = value_bytes
        if not render()[0]:
            engines, controls, refusals, binding, runtime = old
            if engines or controls or refusals or binding != b"null" or runtime:
                flush()
                units.appendleft((kind, value))
            else:
                parts = None
                if kind == "runtime":
                    for size in (8, 4, 2, 1):
                        candidates = list(_encoded_runtime_fragments(value, size))
                        if len(candidates) > 1:
                            parts = candidates
                            break
                if parts is None:
                    _fail("RECORD_TOO_LARGE", kind)
                for part in reversed(parts):
                    units.appendleft((kind, part))
    if not requests or engines or controls or refusals or binding != b"null" or runtime:
        flush()
    if pending_refusals:
        _fail("SNAPSHOT_LIMIT_EXCEEDED", "refusals exceed content page capacity")
    if not snapshot.engines and not snapshot.controls and len(requests) != 1:
        _fail("SNAPSHOT_LIMIT_EXCEEDED", "empty catalog requires one page")
    metadata = {**scope, "observed_at": normalize_observed_at(snapshot.observed_at), "page_count": len(requests),
                "engine_count": len(snapshot.engines), "control_count": len(snapshot.controls)}
    meta_bytes = {k: canonical_bytes(v) for k, v in metadata.items()}
    content_digest = _digest(_object({**meta_bytes, "pages": _array(records_payloads)}))
    wire_digest = _digest(_object({"metadata": _object(meta_bytes), "pages": _array(page_payloads)}))
    digests = {"content_digest": canonical_bytes(content_digest), "wire_digest": canonical_bytes(wire_digest)}
    begin = _object({"engine_snapshot": _object({**meta_bytes, **digests, "version": b"1", "op": b'"begin"'})})
    complete = _object({"engine_snapshot": _object({**scope_bytes, **digests, "version": b"1", "op": b'"complete"'})})
    if any(len(v) > MAX_REQUEST_BYTES for v in (begin, *requests, complete)):
        _fail("SNAPSHOT_LIMIT_EXCEEDED", "final request bytes")
    return SnapshotRequests(begin, tuple(requests), complete, tuple(services), content_digest, wire_digest)


def _decode(data: bytes, *, max_bytes: int = MAX_REQUEST_BYTES,
            row_budget: int = MAX_PARSED_ROWS, shared_budget: list[int] | None = None) -> Any:
    if type(data) is not bytes or len(data) > max_bytes:
        _fail("SOURCE_LIMIT_EXCEEDED", "decode bytes")
    if shared_budget is not None:
        row_budget = min(row_budget, shared_budget[0])
    # Probe depth before allocating decoded containers (braces inside strings do not count).
    depth, quoted, escaped = 0, False, False
    tokens, in_scalar = 0, False
    for byte in data:
        if quoted:
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                quoted = False
        elif byte == 34:
            quoted = True
            tokens += 1
        elif byte in (91, 123):
            depth += 1
            tokens += 1
            if depth > MAX_DEPTH + 1:
                _fail("SOURCE_LIMIT_EXCEEDED", "nesting depth")
        elif byte in (93, 125):
            depth -= 1
        elif byte not in b" \r\n\t,:" and not in_scalar:
            tokens += 1
        in_scalar = not quoted and byte not in b" \r\n\t,:[]{}\""
        if tokens > row_budget:
            _fail("SOURCE_LIMIT_EXCEEDED", "parsed rows before decoding")
    if shared_budget is not None:
        shared_budget[0] -= tokens

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                _fail("SOURCE_INVALID", "duplicate JSON key")
            result[key] = value
        return result

    def constant(value):
        _fail("SOURCE_INVALID", "nonfinite JSON number")
    try:
        result = json.loads(data, object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, UnicodeError, RecursionError) as exc:
        if isinstance(exc, SnapshotConstructionError):
            raise
        _fail("SOURCE_INVALID", "invalid JSON")
    canonical_bytes(result)
    return result


def reassemble_snapshot_pages(requests: SnapshotRequests) -> EngineSnapshot:
    """Validate bounded framing and every digest, then restore the normalized logical input."""
    if not isinstance(requests, SnapshotRequests) or not 1 <= len(requests.pages) <= MAX_PAGES:
        _fail("SOURCE_LIMIT_EXCEEDED", "reassembly page count")
    bodies = (requests.begin, *requests.pages, requests.complete)
    if any(type(v) is not bytes or len(v) > MAX_REQUEST_BYTES for v in bodies):
        _fail("SOURCE_LIMIT_EXCEEDED", "reassembly body bytes")
    if sum(map(len, bodies)) > MAX_REASSEMBLY_BYTES:
        _fail("SOURCE_LIMIT_EXCEEDED", "reassembly aggregate")

    decode_budget = [MAX_PARSED_ROWS]

    def frame(data, op):
        outer = _decode(data, shared_budget=decode_budget)
        # Check framing first; nested page data is checked only after its digests.
        _validate_schema(outer, "request-" + op, code="INVALID_REQUEST", shallow=True)
        value = outer["engine_snapshot"]
        _validate_schema(value, op, code="INVALID_REQUEST", shallow=True)
        return value

    scope_keys = {"host", "venue", "producer_epoch", "sequence"}
    digest_keys = {"content_digest", "wire_digest"}
    meta_keys = scope_keys | {"observed_at", "page_count", "engine_count", "control_count"}
    begin = frame(requests.begin, "begin")
    context = HostContext(begin["host"])
    _identity(context, begin["venue"], begin["producer_epoch"], begin["sequence"])
    if (begin["page_count"] != len(requests.pages)
            or (begin["engine_count"] == begin["control_count"] == 0 and begin["page_count"] != 1)):
        _fail("INVALID_REQUEST", "page count")
    if normalize_observed_at(begin["observed_at"]) != begin["observed_at"]:
        _fail("INVALID_REQUEST", "observation time not normalized")
    if begin["content_digest"] != requests.content_digest or begin["wire_digest"] != requests.wire_digest:
        _fail("DIGEST_MISMATCH", "request metadata")
    logical: dict[str, Any] = {"engines": [], "controls": [], "runtime": {}, "refusals": []}
    storage, wire = [], []
    for index, body in enumerate(requests.pages):
        page = frame(body, "page")
        if page["page_index"] != index or any(page[k] != begin[k] for k in scope_keys):
            _fail("INVALID_REQUEST", "page identity or order")
        records, auxiliary = page["records"], page["auxiliary"]
        _validate_schema(records, "records", code="INVALID_REQUEST", shallow=True)
        _validate_schema(auxiliary, "auxiliary", code="INVALID_REQUEST", shallow=True)
        payload = {"records": records, "auxiliary": auxiliary}
        payload_bytes = canonical_bytes(payload, max_depth=MAX_PAGE_DEPTH)
        if len(payload_bytes) > MAX_RECORD_BYTES:
            _fail("SOURCE_LIMIT_EXCEEDED", "record bytes")
        if (_digest(canonical_bytes(records)) != page["page_digest"]
                or _digest(payload_bytes) != page["wire_page_digest"]):
            _fail("DIGEST_MISMATCH", "page")
        _validate_schema(records, "records", code="INVALID_REQUEST")
        _validate_schema(auxiliary, "auxiliary", code="INVALID_REQUEST")
        for key in ("engines", "controls"):
            logical[key].extend(records[key])
        logical["refusals"].extend(auxiliary["refusals"])
        bindings = auxiliary["engine_bindings"]
        if bindings is not None:
            if ("engine_bindings" in logical or len(canonical_bytes(bindings)) > MAX_BINDING_BYTES):
                _fail("INVALID_REQUEST", "bindings")
            logical["engine_bindings"] = bindings
        runtime = auxiliary["runtime"]
        for key, value in runtime.items():
            try:
                if len(list(_runtime_fragments({key: value}))) > 1:
                    _fail("SOURCE_LIMIT_EXCEEDED", "runtime fragment rows")
            except SnapshotConstructionError as exc:
                if exc.code == "INVALID_RECORD":
                    _fail("INVALID_REQUEST", "runtime fragment shape")
                raise
        # Reassembly must not mutate a page that remains in the generation preimage.
        _merge_runtime(logical["runtime"], deepcopy(runtime))
        service = {**{k: begin[k] for k in scope_keys}, "page": {**records, "page_index": index}}
        _validate_schema(service, "service-envelope", code="INVALID_REQUEST")
        if len(canonical_bytes(service)) > MAX_SERVICE_ENVELOPE_BYTES:
            _fail("SOURCE_LIMIT_EXCEEDED", "service envelope")
        storage.append(records)
        wire.append(payload)
    if (len(logical["engines"]) != begin["engine_count"] or len(logical["controls"]) != begin["control_count"]):
        _fail("INVALID_REQUEST", "generation record count")
    metadata = {k: begin[k] for k in meta_keys}
    if (engine_snapshot_digest(begin["host"], begin["venue"], metadata, storage) != begin["content_digest"]
            or _digest(canonical_bytes({"metadata": metadata, "pages": wire})) != begin["wire_digest"]):
        _fail("DIGEST_MISMATCH", "generation")
    end = frame(requests.complete, "complete")
    if any(end[k] != begin[k] for k in scope_keys | digest_keys):
        _fail("INVALID_REQUEST", "complete identity")
    return freeze_engine_snapshot(logical, context=context, venue=begin["venue"],
                                  observed_at=begin["observed_at"], producer_epoch=begin["producer_epoch"],
                                  sequence=begin["sequence"])


@dataclass(frozen=True)
class SnapshotSources:
    """Explicit source selection, with no environment lookup.

    Darkhorse model paths must include the two paths named by its host config. This
    permits the entire selection to be fingerprinted before any content is read.
    Registry identity paths pair lane UUIDs with trusted dashboard identity files.
    The identity_path supplies the registry owner's dashboard identity.
    None means unconfigured; a configured optional path may be absent, but cannot
    be unreadable. The engine directory itself is required, even when empty.
    """
    directory: Path
    binding_path: Path | None = None
    identity_path: Path | None = None
    overrides_path: Path | None = None
    lifecycle_dir: Path | None = None
    evidence_dir: Path | None = None
    registry_path: Path | None = None
    runs_dir: Path | None = None
    darkhorse_state: Path | None = None
    darkhorse_host_path: Path | None = None
    darkhorse_model_paths: tuple[Path, ...] = ()
    registry_identity_paths: tuple[tuple[str, Path], ...] = ()


def _fingerprint(path: Path) -> tuple[int, ...] | None:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None
    if stat.S_ISLNK(info.st_mode):
        _fail("SOURCE_INVALID", f"symlink source: {path}")
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


class _Selection:
    def __init__(self):
        self.entries = 0
        self.files: dict[Path, tuple[int, ...] | None] = {}
        self.directories: dict[Path, tuple[tuple[int, ...] | None, tuple[str, ...]]] = {}

    def directory(self, path: Path, *, required: bool = False) -> tuple[str, ...]:
        path = Path(path)
        if path in self.directories:
            return self.directories[path][1]
        before = _fingerprint(path)
        if before is None:
            if required:
                _fail("SOURCE_UNREADABLE", f"missing directory: {path}")
            names: list[str] = []
        else:
            if not stat.S_ISDIR(before[2]):
                _fail("SOURCE_INVALID", f"not a directory: {path}")
            names = []
            with os.scandir(path) as entries:
                for entry in entries:
                    self.entries += 1
                    if self.entries > MAX_DIRECTORY_ENTRIES:
                        _fail("SOURCE_LIMIT_EXCEEDED", "inspected directory entries")
                    names.append(entry.name)
        after = _fingerprint(path)
        if before != after:
            _fail("SOURCE_CHANGED", f"directory selection: {path}")
        result = tuple(sorted(names))
        self.directories[path] = (before, result)
        return result

    def file(self, path: Path | None) -> None:
        if path is None:
            return
        path = Path(path)
        if path in self.files:
            return
        if len(self.files) >= MAX_SELECTED_FILES:
            _fail("SOURCE_LIMIT_EXCEEDED", "selected files")
        info = _fingerprint(path)
        if info is not None:
            if not stat.S_ISREG(info[2]):
                _fail("SOURCE_INVALID", f"not a regular file: {path}")
            if info[3] > MAX_FILE_BYTES:
                _fail("SOURCE_LIMIT_EXCEEDED", f"file bytes: {path}")
        self.files[path] = info

    def validate(self) -> None:
        # All checks happen after all reads, including files captured first.
        for path, before in self.files.items():
            try:
                after = _fingerprint(path)
            except (OSError, SnapshotConstructionError):
                _fail("SOURCE_CHANGED", f"source replacement: {path}")
            if after != before:
                _fail("SOURCE_CHANGED", f"source fingerprint: {path}")
        check = _Selection()
        for path, before in self.directories.items():
            try:
                names = check.directory(path)
            except (OSError, SnapshotConstructionError):
                _fail("SOURCE_CHANGED", f"source inventory: {path}")
            if check.directories[path] != before or names != before[1]:
                _fail("SOURCE_CHANGED", f"source inventory: {path}")


def _read_source(path: Path, limit: int) -> bytes:
    """One bounded read with an overflow byte. A deterministic mutation seam for tests."""
    with path.open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        _fail("SOURCE_LIMIT_EXCEEDED", f"file or aggregate bytes: {path}")
    return data


class _Capture:
    def __init__(self, selected: _Selection):
        self.rows = 0
        self.parsed: dict[Path, Any] = {}
        self.sources: dict[Path, CapturedSource] = {}
        total = 0
        for path, fingerprint in selected.files.items():
            data = None
            if fingerprint is not None:
                data = _read_source(path, min(MAX_FILE_BYTES, MAX_CAPTURE_BYTES - total))
                total += len(data)
            self.sources[path] = CapturedSource(str(path), fingerprint, data)
        selected.validate()

    def data(self, path: Path | None) -> bytes | None:
        if path is None:
            return None
        source = self.sources.get(Path(path))
        if source is None:
            _fail("SOURCE_INVALID", f"source outside frozen selection: {path}")
        return source.data

    def _count(self, value: Any) -> None:
        # Count containers and scalar leaves too; huge object maps cannot evade the row budget.
        pending = [value]
        while pending:
            item = pending.pop()
            self.rows += 1
            if self.rows > MAX_PARSED_ROWS:
                _fail("SOURCE_LIMIT_EXCEEDED", "parsed rows")
            if isinstance(item, dict):
                pending.extend(item.values())
            elif isinstance(item, list):
                pending.extend(item)

    def document(self, path: Path | None, *, required: bool = False,
                 error_code: str = "SOURCE_INVALID") -> dict | None:
        data = self.data(path)
        if data is None:
            if required:
                _fail("SOURCE_UNREADABLE", f"missing source: {path}")
            return None
        path = Path(path)
        if path not in self.parsed:
            value = _decode(data, max_bytes=MAX_FILE_BYTES, row_budget=MAX_PARSED_ROWS - self.rows)
            self._count(value)
            self.parsed[path] = value
        if not isinstance(self.parsed[path], dict):
            _fail(error_code, f"source must contain an object: {path}")
        return self.parsed[path]

    def ledger(self, path: Path) -> list[dict]:
        if path in self.parsed:
            return self.parsed[path]
        data = self.data(path)
        rows = []
        if data is not None:
            # splitlines materializes only the already bounded file; no prefix is accepted.
            for line in data.splitlines():
                if not line.strip():
                    continue
                row = _decode(line, max_bytes=MAX_FILE_BYTES, row_budget=MAX_PARSED_ROWS - self.rows)
                self._count(row)
                if not isinstance(row, dict):
                    _fail("EVIDENCE_INVALID", f"ledger row: {path}")
                rows.append(row)
        self.parsed[path] = rows
        return rows


def _select(sources: SnapshotSources, now: datetime):
    from .push import _PROBE_VERDICT_FILE, is_run_name

    selected = _Selection()
    directory = Path(sources.directory)
    names = selected.directory(directory, required=True)
    engines = [directory / name for name in names if name.endswith(".json")]
    # Mirrors engines.EngineRegistry's 1024-engine catalog capacity (S1).
    if len(engines) > 1024:
        _fail("SNAPSHOT_LIMIT_EXCEEDED", "catalog inventory")
    for path in engines:
        selected.file(path)
    for path in (sources.binding_path, sources.identity_path, sources.overrides_path,
                 sources.registry_path, sources.darkhorse_host_path, *sources.darkhorse_model_paths,
                 *(path for _, path in sources.registry_identity_paths)):
        selected.file(path)
    if sources.registry_path is not None and Path(sources.registry_path).name == "projection.json":
        selected.file(Path(sources.registry_path).with_name("publication.json"))
    lifecycle = Path(sources.lifecycle_dir) if sources.lifecycle_dir is not None else directory / "lifecycle"
    selected.directory(lifecycle)
    exposure = lifecycle / "exposure"
    selected.directory(exposure)
    verdicts = {}
    if sources.evidence_dir is not None:
        selected.directory(Path(sources.evidence_dir))
    for path in engines:
        selected.file(lifecycle / path.name)
        selected.file(exposure / path.name)
        if sources.evidence_dir is not None:
            parent = Path(sources.evidence_dir) / path.stem
            selected.directory(parent)
            verdict_dir = parent / "verdicts"
            candidates = []
            for name in selected.directory(verdict_dir):
                match = _PROBE_VERDICT_FILE.fullmatch(name)
                if match:
                    candidates.append(((match[1], int(match[2] or 0)), name))
            if candidates:
                verdicts[path.stem] = verdict_dir / max(candidates)[1]
                selected.file(verdicts[path.stem])
    runs: list[Path] = []
    dark_runs: list[Path] = []
    prefixes = (now.strftime("%Y%m%d"), (now - timedelta(days=1)).strftime("%Y%m%d"))
    for run_root, dark in ((sources.runs_dir, False),
                           (None if sources.darkhorse_state is None else Path(sources.darkhorse_state) / "runs", True)):
        if run_root is None:
            continue
        run_root = Path(run_root)
        for name in reversed(selected.directory(run_root)):
            if (not (is_run_name(name) if dark else re.fullmatch(r"\d{8}-[^/\\]+", name))
                    or (not dark and not name.startswith(prefixes))):
                continue
            path = run_root / name
            info = _fingerprint(path)
            if info is None or not stat.S_ISDIR(info[2]):
                continue
            selected.directory(path)
            (dark_runs if dark else runs).append(path)
            for filename in ("config.json", "kalshi-tickets.jsonl", "kalshi-edge-status.json",
                             "kalshi-darkhorse-tickets.jsonl"):
                selected.file(path / filename)
    if sources.darkhorse_state is not None:
        state = Path(sources.darkhorse_state)
        selected.directory(state)
        selected.file(state / "darkhorse-controls.json")
        selected.file(state / "darkhorse.json")
    # The initial file fingerprints precede every content read. Inventory is rechecked
    # here as well so a mutation while selecting later directories cannot mix inventories.
    selected.validate()
    return selected, engines, lifecycle, verdicts, runs, dark_runs


def _identity_document(raw: dict) -> None:
    _validate_schema(raw, "identity", code="SOURCE_INVALID")

def _exposure_values(raw: dict) -> None:
    _validate_schema(raw, "exposure")

def _lifecycle_values(record: dict, *, projected: bool = False) -> None:
    _validate_schema(record, "lifecycle" if projected else "source-lifecycle")

def _ledger_attribution(raw: Any) -> None:
    from .attribution import DecisionAttributionV1

    _validate_schema(raw, "attribution")
    row = {key: value for key, value in raw.items() if key != "digest"}
    try:
        parsed = DecisionAttributionV1(**row)
    except (TypeError, ValueError):
        _fail("EVIDENCE_INVALID", "attribution shape")
    if parsed.to_dict()["digest"] != raw["digest"]:
        _fail("EVIDENCE_INVALID", "attribution digest mismatch")


def _overrides(document: Any, registry: dict) -> tuple[dict, list[dict]]:
    from .engines import AccountOverride, AccountOverrides

    if document is None:
        return {}, []
    _validate_schema(document, "overrides", code="SOURCE_INVALID")
    parsed, refusals = {}, []
    for aid, body in document["accounts"].items():
        parsed[aid] = {}
        for eid, raw in body["engines"].items():
            override = AccountOverride(**raw)
            if eid not in registry:
                refusals.append({"code": "OVERRIDE_ENGINE_MISSING", "engine_id": eid, "account_id": aid})
                continue
            AccountOverrides._effective(registry[eid], override)
            parsed[aid][eid] = override
    return parsed, refusals

def _bindings(raw: Any, registry: dict) -> dict | None:
    if raw is None:
        return None
    _validate_schema(raw, "bindings", code="SOURCE_INVALID")
    return raw  # Wire acceptance and generation membership use _s2_accepts before freezing.

def _verdict(doc: Any, eid: str) -> dict:
    from .push import _PROBE_POPULATION_KEYS, _short_text

    _validate_schema(doc, "source-verdict")
    if doc["engine_id"] != eid:
        _fail("EVIDENCE_INVALID", f"verdict: {eid}")
    gate = doc.get("gate") if isinstance(doc.get("gate"), dict) else None
    failed = gate.get("failed_checks") if gate is not None else None
    population = doc.get("population") if isinstance(doc.get("population"), dict) else None
    return {"engine_id": eid, "at": doc["at"], "trial_id": _short_text(doc.get("trial_id"), 64),
            "decision": doc["decision"], "verdict": _short_text(doc.get("verdict"), 16),
            "read_kind": _short_text(doc.get("read_kind"), 32), "activated": doc.get("activated") is True,
            "gate_passed": None if gate is None else gate.get("passed") is True,
            "failed_checks": [v for v in failed if _short_text(v, 32)][:8] if isinstance(failed, list) else [],
            "population": None if population is None else {
                key: population.get(key) if type(population.get(key)) is int else None for key in _PROBE_POPULATION_KEYS},
            "next_read_at": _short_text(doc.get("next_read_at"), 40)}


def _account_resolver(capture: _Capture, sources: SnapshotSources, identity: Any,
                      registry_block: dict | None) -> Callable[[str], str | None]:
    from . import engine_pnl as pnl
    from .engines import DashboardAccountIdentity

    # Same trusted identity mapping as engine_pnl._registry_block, using only
    # explicitly selected identity files rather than environment paths or caches.
    owner = identity.account_id if identity is not None else None
    owner_id = owner if _s2_accepts("account_id", owner) else None
    identities = {}
    for key, identity_path in sources.registry_identity_paths:
        if (not isinstance(key, str) or re.fullmatch(
                r"[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}", key) is None
                or key in identities):
            _fail("SOURCE_INVALID", "registry identity key")
        doc = capture.document(identity_path)
        if doc is not None:
            _identity_document(doc)
        account = None if doc is None else DashboardAccountIdentity(**doc).account_id
        identities[key] = account if _s2_accepts("account_id", account) else None

    # Only a validated, published registry block may supply these aliases.
    books = {row["account_id"]: row.get("book_account_id")
             for row in registry_block["assignments"]} if registry_block is not None else {}

    def resolve(key):
        book = books.get(key)
        if key == "owner" or (owner is not None and book == owner):
            return owner_id
        if key in identities:
            return identities[key]
        return key if _s2_accepts("account_id", key) else None

    return resolve


def _registry_source_block(capture: _Capture, sources: SnapshotSources, refusals: list[dict]) -> dict | None:
    from types import FunctionType
    from . import engine_registry as er

    path = Path(sources.registry_path)
    raw = capture.document(path, error_code="EVIDENCE_INVALID")
    if raw is None:
        return None
    assignments = raw.get("assignments")
    # Mirrors engine_registry.MAX_ASSIGNMENTS = 1024 in S1 (#762).
    if isinstance(assignments, dict) and len(assignments) > 1024:
        _fail("SOURCE_LIMIT_EXCEEDED", "registry assignments")
    # Parse under the collector's budget before the producer's catch-and-decline boundary.
    marker = (capture.document(path.with_name("publication.json"), error_code="EVIDENCE_INVALID")
              if path.name == "projection.json" else None)

    def validate(document):
        _validate_schema(document, "source-registry")
        assignments = document.get("assignments") if isinstance(document, dict) else None
        if not isinstance(assignments, dict) or len(assignments) <= er.MAX_ASSIGNMENTS:
            return er.validate_document(document)
        if document.get("digest") != er.document_digest(document):
            _fail("EVIDENCE_INVALID", "registry digest")
        # Retain the source-wide reference check before the bounded validator batches.
        breakers = document.get("loss_breakers")
        if (not isinstance(breakers, dict) or not isinstance(breakers.get("engines"), dict)
                or set(breakers["engines"]) - set(assignments)):
            _fail("EVIDENCE_INVALID", "registry breaker reference")
        for items in _chunks(list(assignments.items()), er.MAX_ASSIGNMENTS):
            subset = {**document, "assignments": dict(items)}
            subset["loss_breakers"] = {**breakers, "engines": {
                k: v for k, v in breakers["engines"].items() if k in subset["assignments"]}}
            subset["digest"] = er.document_digest(subset)
            er.validate_document(subset)
        return document

    def read(captured_path, limit):
        data = capture.data(Path(captured_path))
        if data is None or len(data) > limit:
            raise ValueError("registry source absent or oversized")
        return data

    def published(marker_path, generation, digest):
        _validate_schema(marker, "publication")
        er._exact(marker, er.PUBLICATION_KEYS, "publication")
        return (er._decimal(marker["generation"], "publication generation", 1, er.MAX_GENERATION) == generation
                and marker["digest"] == digest and marker["state"] == er.PUBLISHED)

    # Run the existing producer with capture-local I/O dependencies. A private
    # namespace avoids monkeypatching shared module globals or rereading live files.
    producer = er.RegistryProjection.push_block
    frozen_producer = FunctionType(producer.__code__, {
        **producer.__globals__, "_read_bounded": read,
        "validate_document": validate, "publication_matches": published},
        producer.__name__, producer.__defaults__, producer.__closure__)
    block = frozen_producer(er.RegistryProjection(path))
    if block is None:
        refusals.append({"code": "REGISTRY_PROJECTION_REFUSED", "source": str(path)})
    return block


def _registry_projection(block: dict, resolve_account: Callable[[str], str | None],
                         refusals: list[dict]) -> dict:
    rows = []
    for assignment in block["assignments"]:
        key = assignment["account_id"]
        account = resolve_account(key)
        if account is None:
            refusals.append({"code": "REGISTRY_ACCOUNT_ID_MISSING", "engine_id": assignment["engine_id"],
                             "account_id": key})
            continue
        row = {name: assignment[name] for name in ("engine_id", "role", "domain") if name in assignment}
        rows.append({**row, "account_id": account})
    return {**block, "assignments": rows}


@_bounded_decimal_evidence()
def _rollups(capture: _Capture, runs: list[tuple[Path, str]], exposures: dict,
             records: dict, identity: str | None, now: datetime, refusals: list[dict]) -> dict:
    from . import engine_pnl as pnl
    from .canary import ExposureLedger
    from types import FunctionType

    def contracts(value):
        number = _evidence_decimal(value)
        if number > 1000000000:
            _fail("EVIDENCE_INVALID", "totals.contracts")
        return number

    rollup_rows = FunctionType(pnl._rollup.__code__, {**pnl._rollup.__globals__,
                              "_contracts": contracts}, pnl._rollup.__name__)
    utc_day = now.date().isoformat()
    start, end, _ = pnl._day_bounds(utc_day)
    groups = {}
    for path, symbol in runs:
        for source in capture.ledger(path / "kalshi-tickets.jsonl"):
            attribution = source.get("attribution")
            engine = attribution.get("engine_id") if isinstance(attribution, dict) else None
            # Unattributed inputs have no shared identity: a malformed one cannot hide a valid sibling.
            key = engine if type(engine) is str else ("unknown", len(groups))
            groups.setdefault(key, []).append((source, symbol))

    def row(engine, role, day, lifetime, positions, symbols, digest):
        for rollup in (day, lifetime):
            _validate_schema(rollup.to_dict(), "totals")
        _validate_schema(positions, "positions")
        eid, reason = pnl.narrow_engine_id(None if engine == pnl.UNKNOWN_ENGINE else engine)
        record = records.get(engine, (None, None))[0] if eid else None
        life = ({"state": record.get("state"), "entries_enabled": record.get("entries_enabled")}
                if record is not None else None)
        account = record.get("account_id") if record else identity
        account = account or identity
        result = {"engine_id": eid, "engine_id_reason": reason,
                  "account_digest": None if digest == "unknown" else digest,
                  "role": role, "symbols": sorted(symbols)[:pnl.MAX_MARKETS], "day": day.to_dict(),
                  "open": positions, "lifetime": lifetime.to_dict(), "lifecycle": life}
        if account is not None:
            result["claim"] = {"account_id": account, "domain": pnl.DOMAIN, "role": role}
        return result

    rows, truncated = [], 0
    # ONE per-engine guard encloses source parsing, Decimal accumulation, conversions and row construction.
    for key in sorted(set(groups) | set(exposures), key=str):
        engine = key if type(key) is str else pnl.UNKNOWN_ENGINE
        pending, phase = [], "ledger"
        try:
            day, lifetime = pnl.DayRollup(), pnl.DayRollup()
            opened, closed, symbols, digest = {}, set(), set(), None
            for source, symbol in groups.get(key, []):
                phase = "ledger"
                _validate_schema(source, "ledger")
                if "attribution" in source:
                    _ledger_attribution(source["attribution"])
                if source.get("kind") in ("buy", "adopt") and "client_id" in source:
                    _validate_schema(source, "ledger-open")
                ident = pnl._ident(source)
                engine = ident[0]
                phase = "row"
                # Bound the Decimal BEFORE either addition or binary64 conversion.
                if source.get("kind") == "buy":
                    contracts(source.get("count"))
                for total, lower, upper in ((day, start, end), (lifetime, None, None)):
                    part = rollup_rows([source], [ident], lower, upper).get(engine, pnl.DayRollup())
                    if total.contracts + part.contracts > 1000000000:
                        _fail("EVIDENCE_INVALID", "totals.contracts")
                    total.add(part)
                    _validate_schema(total.to_dict(), "totals")
                symbols.add(symbol)
                digest = digest or ident[1]
                cid, kind = source.get("client_id"), source.get("kind")
                if isinstance(cid, str):
                    if kind in ("settle", "void"):
                        closed.add(cid)
                    elif kind in ("buy", "adopt") and cid not in opened:
                        opened[cid] = source["cost_cents"]
            if key in groups:
                costs = [cost for cid, cost in opened.items() if cid not in closed]
                pending.append(row(engine, "incumbent", day, lifetime,
                                   {"positions": len(costs), "cost_cents": sum(costs)}, symbols, digest))
            if key in exposures:
                phase = "row"
                doc = exposures[key]
                _exposure_values(doc)
                doc = ExposureLedger(Path("."), engine)._valid(doc)
                day, lifetime = pnl.DayRollup(), pnl.DayRollup()
                positions = cost = 0
                for entry in doc["entries"].values():
                    state = entry.get("state")
                    if state == "open":
                        positions += 1
                        cost += entry["cost_cents"]
                    if state in ("open", "closed"):
                        count = contracts(entry.get("count"))
                        for total, matches in ((day, entry.get("reserved_day") == utc_day), (lifetime, True)):
                            if matches:
                                if total.contracts + count > 1000000000:
                                    _fail("EVIDENCE_INVALID", "totals.contracts")
                                total.entries += 1
                                total.contracts += count
                    if state == "closed":
                        realized = entry["realized_cents"]
                        for total, matches in ((day, entry.get("closed_day") == utc_day), (lifetime, True)):
                            if matches:
                                if entry.get("kind") == "exit":
                                    total.exits += 1
                                else:
                                    total.settled += 1
                                    if entry.get("kind") == "voided":
                                        total.voided += 1
                                    elif realized > 0:
                                        total.won += 1
                                    else:
                                        total.lost += 1
                    for total in (day, lifetime):
                        _validate_schema(total.to_dict(), "totals")
                    _validate_schema({"positions": positions, "cost_cents": cost}, "positions")
                today = doc["days"].get(utc_day)
                day.realized_cents = 0 if today is None else today["realized_cents"]
                lifetime.realized_cents = sum(value["realized_cents"] for value in doc["days"].values())
                pending.append(row(engine, "probe", day, lifetime,
                                   {"positions": positions, "cost_cents": cost}, (), None))
            rows.extend(pending)
        except (SnapshotConstructionError, DecimalException, ValueError, TypeError, KeyError, OverflowError) as exc:
            if isinstance(exc, SnapshotConstructionError) and exc.code == "SOURCE_LIMIT_EXCEEDED":
                raise
            code = "LEDGER_ROW_INVALID" if phase == "ledger" else _runtime_row_code(exc)
            refusals.append({"code": code, "engine_id": engine, "account_id": identity,
                             "source": "engine_rollups.rows[]"})
            truncated += 1
    return {"schema": pnl.ROLLUP_SCHEMA, "as_of": now.isoformat().replace("+00:00", "Z"),
            "utc_day": utc_day, "lifetime_basis": "ledgers_since_yesterday_utc",
            "rows": rows, "truncated": truncated}

def _dark_config(raw: Any) -> dict:
    _validate_schema(raw, "dark-config")
    if any(not Path(path).is_absolute() for path in raw["models"]):
        _fail("EVIDENCE_INVALID", "Darkhorse model paths")
    return raw

def _dark_model(raw: Any):
    from .strategy.darkhorse import DarkHorseModel, FEATURE_NAMES, _number as model_number, feature_module

    _validate_schema(raw, "dark-model")

    def checked_number(value):
        return model_number(value)
    names = raw["feature_names"]
    if (not isinstance(names, list) or not names or any(not isinstance(n, str) or n not in FEATURE_NAMES for n in names)
            or len(set(names)) != len(names)):
        _fail("EVIDENCE_INVALID", "Darkhorse features")
    maps = []
    for key in ("standardiser_mean", "standardiser_std", "coefficients"):
        values = raw[key]
        expected = set(names) | ({"intercept"} if key == "coefficients" else set())
        if not isinstance(values, dict) or set(values) != expected:
            _fail("EVIDENCE_INVALID", "Darkhorse coefficient map")
        maps.append({n: checked_number(v) for n, v in values.items()})
    offset, threshold, p99 = (checked_number(raw[k]) for k in ("entry_offset_s", "score_threshold", "score_p99"))
    band = {n: checked_number(raw["cheap_side_band"][n]) for n in ("min_ask", "max_price")}
    age = checked_number(raw.get("max_quote_age_ms", feature_module.DEFAULT_MAX_QUOTE_AGE_MS))
    if (any(v <= 0 for v in maps[1].values()) or offset < 0 or not 0 <= threshold < p99 <= 1
            or not 0 < band["min_ask"] <= band["max_price"] <= 100 or age < 0):
        _fail("EVIDENCE_INVALID", "Darkhorse model bounds")
    return DarkHorseModel(int(offset) if offset.is_integer() else offset, tuple(names), *maps, threshold, p99, band, age)


def _dark_fields(source: Any, *, numbers=(), integers=(), booleans=(), identifiers=()) -> dict:
    _validate_schema(source, "order")
    return {name: source[name] for names in (numbers, integers, booleans, identifiers)
            for name in names if name in source}

def _dark_policy(raw: Any) -> None:
    from .engines import AccountDarkHorse

    _validate_schema(raw, "dark-policy")
    AccountDarkHorse.validate_values(raw)

def _dark_telemetry(raw: Any) -> dict:
    from . import push

    _validate_schema(raw, "source-telemetry")
    # Preserve the existing intentional per-record projection bounds.
    return push._darkhorse_telemetry({"stats": {}, **raw})

def _darkhorse(capture: _Capture, sources: SnapshotSources, identity: Any,
               runs: list[Path], now: datetime) -> tuple[dict, dict]:
    from .engines import AccountDarkHorse, _revision
    from .account_lane_agent import canonical_symbols
    from . import push

    state = Path(sources.darkhorse_state)
    doc = capture.document(state / "darkhorse-controls.json", error_code="EVIDENCE_INVALID")
    if doc is None:
        doc = {"account_id": identity.account_id, "enabled": False, "policy": {},
               "revision": 0, "updated_at": None, "history": []}
    else:
        _validate_schema(doc, "dark-controls")
        if doc["account_id"] != identity.account_id:
            _fail("EVIDENCE_INVALID", "Darkhorse account controls identity")
    host = capture.document(sources.darkhorse_host_path, error_code="EVIDENCE_INVALID")
    current = capture.document(state / "darkhorse.json", error_code="EVIDENCE_INVALID")
    if current is not None:
        _dark_config(current)
    values, models, history, override = {}, [], [], {}
    enabled = available = pending = False
    version, updated_at = 0, None
    revision = _revision({"account_id": identity.account_id, "engine_id": "darkhorse", "unavailable": True})
    error = "Host models or account configuration unavailable"
    if host is not None:
        raw = _dark_config(host)
        trained = [_dark_model(capture.document(Path(p), required=True, error_code="EVIDENCE_INVALID")) for p in raw["models"]]
        shas = tuple(_digest(capture.data(Path(p))) for p in raw["models"])
        if {m.entry_offset_s for m in trained} != {120, 45}:
            _fail("EVIDENCE_INVALID", "Darkhorse model offsets")
        values = {"base_count": float(raw["base_count"]), "max_mult": float(raw["max_mult"]),
                  **{f"score_threshold_{int(m.entry_offset_s)}": m.score_threshold for m in trained}, **doc["policy"]}
        AccountDarkHorse.validate_values(values)
        for model in trained:
            if not model.score_threshold <= values[f"score_threshold_{int(model.entry_offset_s)}"] < model.score_p99:
                _fail("EVIDENCE_INVALID", "Darkhorse threshold")
        runtime = {**raw, "armed": int(doc["enabled"]), "base_count": format(values["base_count"], ".2f"),
                   "max_mult": format(values["max_mult"], ".2f")}
        pending = doc["enabled"] if current is None else _dark_config(current) != runtime
        revision = _revision({"account_id": identity.account_id, "host": raw, "model_shas": shas, "controls": doc})
        enabled, available, error = doc["enabled"], True, None
        override, history = doc["policy"], push._darkhorse_history(doc["history"])
        version, updated_at = doc["revision"], doc["updated_at"]
        models = [{"offset": model.entry_offset_s, "sha": sha, "trained_threshold": model.score_threshold,
                   "score_p99": model.score_p99, "score_threshold": values[f"score_threshold_{int(model.entry_offset_s)}"]}
                  for model, sha in zip(trained, shas)]
    telemetry, orders = [], []
    # push._account_run_dirs chooses the newest run NAME per canonical symbol,
    # then emits symbols in sorted order. Apply that rule to the frozen capture.
    selected_runs = {}
    for run in sorted(runs, key=lambda path: path.name, reverse=True):
        config = capture.document(run / "config.json", error_code="EVIDENCE_INVALID")
        if config is not None:
            _validate_schema(config, "run-config")
        if config is not None and config.get("venue") == "kalshi" and config.get("symbol") in canonical_symbols():
            selected_runs.setdefault(config["symbol"], run)
    for symbol in sorted(selected_runs):
        run = selected_runs[symbol]
        path = run / "kalshi-edge-status.json"
        status = capture.document(path, error_code="EVIDENCE_INVALID")
        if status is not None:
            _validate_schema(status, "run-status")
        if status is not None and "darkhorse" in status:
            if not isinstance(status["darkhorse"], dict):
                _fail("EVIDENCE_INVALID", "Darkhorse telemetry")
            stamp = capture.sources[path].fingerprint[4] / 1e9
            projected = {"run_id": run.name, "observed_at": datetime.fromtimestamp(stamp, timezone.utc).isoformat(),
                         "stale": not 0 <= now.timestamp() - stamp <= 120, **_dark_telemetry(status["darkhorse"])}
            _validate_schema(projected, "telemetry", normalize_timestamps=True)
            if len(canonical_bytes(projected)) > 8192:
                _fail("EVIDENCE_INVALID", "Darkhorse telemetry row bound")
            telemetry.append(projected)
        for source in capture.ledger(run / "kalshi-darkhorse-tickets.jsonl"):
            _validate_schema(source, "dark-ledger")
            if source.get("lane") not in (None, "darkhorse"):
                continue
            source = dict(source)
            for name in ("count", "price_cents", "cost_cents", "fee_cents", "pnl_cents"):
                if name in source:
                    source[name] = float(_evidence_decimal(source[name], signed=name == "pnl_cents"))
            row = _dark_fields(source, identifiers=("kind", "ticker", "client_id"), booleans=("side_yes",),
                numbers=("count", "price_cents", "cost_cents", "fee_cents", "pnl_cents"), integers=("ts_ns", "settled_ns", "opened_ns"))
            if row.get("kind") in {"buy", "adopt", "settle", "void", "decision"}:
                orders.append(row)
    orders.sort(key=lambda r: r.get("settled_ns") or r.get("ts_ns") or r.get("opened_ns") or 0, reverse=True)
    stale = not telemetry or any(row["stale"] for row in telemetry)
    pending = pending or (enabled and stale) or any(row.get("armed") != enabled or not isinstance(row.get("stats"), dict)
               or row["stats"].get("account_control_revision") != version for row in telemetry)
    evidence = {"available": available, "error": error, "models": models, "bounds": {"base_count": [0.01, 0.50], "max_mult": [1, 10]},
                "updated_at": updated_at, "pending": pending, "stale": stale, "history": history,
                "orders": orders[:push.MAX_ACCOUNT_ACTIVITY_ROWS], "telemetry": telemetry}
    _validate_schema(evidence, "darkhorse", normalize_timestamps=True)
    while len(canonical_bytes(evidence)) > push.MAX_DARKHORSE_EVIDENCE_BYTES:
        if evidence["orders"]:
            evidence["orders"].pop()
        elif evidence["telemetry"]:
            evidence["telemetry"].pop()
        elif evidence["history"]:
            evidence["history"].pop(0)
        else:
            _fail("RECORD_TOO_LARGE", "Darkhorse evidence")
    account = {"account_id": identity.account_id, "enabled": enabled, "policy": override, "revision": revision,
               "override_revision": version, "effective_enabled": enabled and available, "effective_policy": values,
               "effective_policy_digest": _revision(values)}
    row = {"engine_id": "darkhorse", "name": "Darkhorse", "description": "Host-trained cheap-side models", "version": max(1, version),
           "revision": revision, "enabled": enabled and available, "parent_engine_id": None, "capabilities": {"per_account": True},
           "policy": values, "policy_digest": _revision(values), "account": account, "darkhorse": evidence}
    control = {"engine_id": "darkhorse", "account": identity.subaccount_number, "override_enabled": enabled,
               "override_policy": override, "effective_enabled": enabled and available, "effective_policy": values,
               "revision": revision, "darkhorse": evidence}
    return row, control


def _wire_strings_safe(value: Any) -> bool:
    # kashbot-engine-runtime.ts:1484-1494, including opaque values and map keys.
    if isinstance(value, str):
        value = json.loads(canonical_bytes(value))
        return "\x00" not in value and not any(0xd800 <= ord(c) <= 0xdfff for c in value)
    if isinstance(value, dict):
        return all(_wire_strings_safe(k) and _wire_strings_safe(v) for k, v in value.items())
    return all(_wire_strings_safe(v) for v in value) if isinstance(value, (list, tuple)) else True


def _s2_accepts(kind: str, value: Any) -> bool:
    """S2 wire acceptance. Optional (value, scope[, row_schema]) supplies page context."""
    scope, schema = {}, "runtime-engine"
    if isinstance(value, tuple):
        value, scope, *schemas = value
        schema = schemas[0] if schemas else schema

    def token(item, pattern):
        return type(item) is str and re.fullmatch(pattern, item) is not None

    def engine(item):
        # kashbot-engine-runtime.ts:370-372, 1674-1677.
        return token(item, r"[a-z0-9][a-z0-9-]{0,31}")

    def account(item):
        # leafhft-account-scope.ts:16-46, including byte-equal JSON re-encoding.
        if type(item) is not str or len(item) > 160:
            return False
        try:
            parts = json.loads(item)
        except (ValueError, TypeError):
            return False
        if (type(parts) is not list or len(parts) != 3
                or not token(parts[0], r"[A-Za-z0-9._:-]{1,64}")
                or not token(parts[1], r"[a-z_]{1,32}")
                or type(parts[2]) is not int or not 0 <= parts[2] <= 1000000
                or json.dumps(parts, separators=(",", ":"), ensure_ascii=False) != item):
            return False
        # kashbot-engine-runtime.ts:1498-1504: scope is the actual page, never the account's own host.
        return (not scope.get("accounts_disabled", False)
                and ("host" not in scope or parts[0] == scope["host"])
                and ("venue" not in scope or parts[1] == scope["venue"])
                and (scope.get("account") is None or parts[2] == scope["account"]))

    def document(item):
        # kashbot-engine-runtime.ts:1506-1523: only declared scope paths, not opaque payloads.
        return (type(item) is dict
                and all(key not in item or key not in scope or item[key] == scope[key]
                        for key in ("host", "venue"))
                and (item.get("account_id") is None or account(item["account_id"])))

    def scoped(item):
        # kashbot-engine-runtime.ts:1502-1527,1532-1550,1686: account
        # selectors and claims must agree with the authenticated page scope.
        if not document(item):
            return False
        claim = item.get("claim")
        if isinstance(claim, dict) and "account_id" in claim:
            if not account(claim["account_id"]):
                return False
            if item.get("account_id") is not None and item["account_id"] != claim["account_id"]:
                return False
        if schema == "control" and item.get("account") is not None:
            return (not scope.get("accounts_disabled", False)
                    and (scope.get("account") is None or item["account"] == scope["account"]))
        return True

    def clocks(item):
        # kashbot-engine-runtime.ts:303-318,351-362. The receiver only accepts
        # UTC dates from 1970 onward; byte checks below see normalized clocks.
        if item.get("utc_day") is not None:
            day = item["utc_day"]
            if not token(day, _DAY) or normalize_observed_at(day + "T00:00:00Z")[:4] < "1970":
                return False
        return all(normalize_observed_at(item[name])[:4] >= "1970"
                   for name in _RUNTIME_CLOCKS if item.get(name) is not None)

    def bounded(item, limit):
        return type(item) is dict and len(canonical_bytes(item)) <= limit

    def lifecycle(item):
        # kashbot-engine-runtime.ts:537-575. These are wire types, not CanaryStore types.
        if (not bounded(item, 16384) or not _wire_strings_safe(item)
                or not clocks(item) or not token(item.get("state"), _STATE)):
            return False
        for name, rule in _lifecycle_wire_fields().items():
            if name in item:
                _validate_schema(item[name], rule)
        # S2:282-283,548 measures text in JavaScript UTF-16 code units.
        for reason in item.get("stop_reasons") or []:
            if (isinstance(reason, dict) and reason.get("text") is not None
                    and len(reason["text"].encode("utf-16-le", "surrogatepass")) > 1024):
                return False
        eligibility = item.get("eligibility")
        if eligibility is not None:
            if type(eligibility) is not dict or not clocks(eligibility):
                return False
        history = item.get("history")
        if history is not None:
            if type(history) is not list or len(history) > 32:
                return False
            observations = {}
            for entry in history:
                if (not bounded(entry, 1024) or not clocks(entry)
                        or not token(entry.get("state"), _STATE)
                        or normalize_observed_at(entry.get("at") or entry.get("ts"))[:4] < "1970"):
                    return False
                # S2:1103-1105 merges history by engine/at/state. Its observation
                # must agree for repeated keys, even though the entry payload is first-wins.
                key = (entry["state"], normalize_observed_at(entry.get("at") or entry.get("ts")))
                observed = next(normalize_observed_at(entry[name]) for name in
                    ("observed_at", "occurred_at", "at", "as_of", "decided_at", "issued_at", "updated_at", "ts")
                    if entry.get(name) is not None)
                if key in observations and observations[key] != observed:
                    return False
                observations[key] = observed
        return True

    try:
        if kind in ("runtime_row", "lifecycle"):
            # Use the same timestamp walker as freeze before any row or nested
            # byte bound. A copied value preserves the caller's source evidence.
            value = deepcopy(value)
            _validate_schema(value, schema if kind == "runtime_row" else "lifecycle",
                             normalize_timestamps=True)
        if kind == "scope_row":
            return scoped(value)
        if kind == "lifecycle":
            return lifecycle(value)
        if kind == "account_id":
            return account(value)
        if kind == "claim":
            # kashbot-engine-runtime.ts:531-535: account mandatory; domain/role optional, extra keys allowed.
            return (type(value) is dict and account(value.get("account_id"))
                    and (value.get("domain") is None or token(value["domain"], r"[A-Za-z0-9._:-]{1,128}"))
                    and (value.get("role") is None or token(value["role"], r"[a-z][a-z0-9_]{0,31}")))
        if kind == "refusal":
            # kashbot-engine-runtime.ts:1593-1594,1609-1612 plus snapshotScope:1529-1530.
            if type(value) is list:
                return len(value) <= 32 and all(_s2_accepts(kind, (item, scope)) for item in value)
            return (document(value) and set(value) == {"code", "engine_id", "account_id"}
                    and token(value["code"], r"[A-Za-z0-9._:-]{1,64}") and engine(value["engine_id"]))
        if kind == "binding":
            # kashbot-engine-runtime.ts:1603-1607; leafhft-engines.ts:4-7,80-99.
            if value is None:
                return True
            books = {"BTC-15M", "ETH-15M", "BTC-1H", "ETH-1H", "BNB-15M", "DOGE-15M", "HYPE-15M",
                     "NEAR-15M", "SOL-15M", "XRP-15M", "ZEC-15M", "BNB-1H", "HYPE-1H", "XRP-1H"}
            if (type(value) is not dict or not {"default", "symbols"} <= set(value)
                    or set(value) - {"default", "symbols", "disabled"}
                    or type(value["symbols"]) is not dict or set(value["symbols"]) - books
                    or len(canonical_bytes(value)) > 4096):
                return False
            ids = [value["default"], *value["symbols"].values()]
            if value["default"] is not None and not engine(value["default"]):
                return False
            if not all(engine(eid) for eid in value["symbols"].values()):
                return False
            disabled = value.get("disabled", [])
            return (type(disabled) is list and all(type(book) is str and book in books for book in disabled)
                    and len(disabled) == len(set(disabled))
                    and ("engine_ids" not in scope or all(eid is None or eid in scope["engine_ids"] for eid in ids)))
        if kind != "runtime_row" or not document(value):
            return False
        # kashbot-engine-runtime.ts:1484-1494 rejects NUL and lone surrogates,
        # including opaque extensions. Paired surrogates are valid Unicode.
        if not _wire_strings_safe(value):
            return False
        # kashbot-engine-runtime.ts:533,599-600,644-646,737-738,1686: one account/claim rule everywhere.
        if schema not in ("breaker-block", "breaker") and not engine(value.get("engine_id")):
            return False
        if value.get("claim") is not None:
            if not _s2_accepts("claim", (value["claim"], scope)):
                return False
            if value.get("account_id") is not None and value["account_id"] != value["claim"]["account_id"]:
                return False
        if schema in ("assignment", "breaker-block") and not account(value.get("account_id")):
            return False
        # S2:657-694 limits wire cents to 1e11; the local breaker permits 1e12.
        if schema in ("breaker", "breaker-block"):
            state = value if schema == "breaker" else value.get("account")
            _strict_value(state, dict, "breaker state")
            _strict_value(state.get("loss_cents"), int, "breaker loss", low=-100000000000, high=100000000000)
            if state.get("limit_cents") is not None:
                _strict_value(state["limit_cents"], int, "breaker limit", high=100000000000)
            if schema == "breaker-block" and value.get("day_start_portfolio_cents") is not None:
                _strict_value(value["day_start_portfolio_cents"], int, "breaker portfolio", high=100000000000)
        counterparts = value.get("counterpart_engine_ids", [])
        if type(counterparts) is not list or len(counterparts) > 64 or any(not engine(eid) for eid in counterparts):
            return False
        if not clocks(value):
            return False
        if schema == "runtime-engine" and value.get("lifecycle") is not None and not lifecycle(value["lifecycle"]):
            return False
        # kashbot-engine-runtime.ts:732,758-759,785,814: bounds include opaque fields.
        if schema in ("rollup", "verdict", "receipt", "event") and not bounded(value, 4096):
            return False
        # kashbot-engine-runtime.ts:526-528,730-759,782-792,815-834.
        if value.get("markets") is not None and len(set(value["markets"])) != len(value["markets"]):
            return False
        if schema == "rollup":
            if value.get("role") not in ("incumbent", "probe") or type(value.get("day")) is not dict:
                return False
            if not {"realized_cents", "settled", "won", "lost", "voided", "exits", "entries", "contracts"} <= set(value["day"]):
                return False
            if value.get("open") is not None and not {"positions", "cost_cents"} <= set(value["open"]):
                return False
            for name, limit in (("lifetime", 1024), ("lifecycle", 2048)):
                if value.get(name) is not None and not bounded(value[name], limit):
                    return False
            if value.get("lifecycle") is not None and not clocks(value["lifecycle"]):
                return False
        if schema in ("verdict", "receipt") and not any(value.get(key) is not None for key in
                ("utc_day", "observed_at", "at", "decided_at", "issued_at", "occurred_at", "as_of", "updated_at", "ts")):
            return False
        if schema == "event" and value.get("kind") not in ("proposal", "sized", "refused", "conflict", "superseded"):
            return False
        # S2:657-695,743-759 numeric/count/cents bounds; the producer's field schemas also constrain digests.
        _validate_schema(value, schema)
        return True
    except (SnapshotConstructionError, ValueError, TypeError, KeyError, OverflowError):
        return False


def _runtime_row_code(exc: SnapshotConstructionError) -> str:
    return ("RUNTIME_ACCOUNT_DIGEST_INVALID" if ".account_digest" in str(exc) else
             "RUNTIME_ACCOUNT_INVALID" if ".account_id" in str(exc) else "RUNTIME_ROW_INVALID")


def _wire_lifecycle(value: dict, eid: str, refusals: list[dict]) -> dict | None:
    """Keep source integrity separate from the receiver's narrower lifecycle fields."""
    retained = {"state": value["state"]}
    for key, item in value.items():
        if key == "state":
            continue
        candidate = {**retained, key: item}
        if _s2_accepts("lifecycle", candidate):
            retained[key] = item
        else:
            refusals.append({"code": "LIFECYCLE_FIELD_INVALID", "engine_id": eid,
                             "source": "engines[].lifecycle." + key})
    return retained if _s2_accepts("lifecycle", retained) else None


def _lifecycle_wire_projection(record: dict) -> dict:
    """Normalize clocks before lifecycle_block measures its projection."""
    result = deepcopy(record)
    objects = [(result, "lifecycle"), (result.get("eligibility"), "eligibility")]
    objects.extend((entry, "history") for entry in result.get("history", []))
    for item, schema in objects:
        if not isinstance(item, dict):
            continue
        fields = _schemas()[schema]["fields"]
        for name in item:
            rule = fields.get(name)
            if item[name] is None or not (rule is not None and rule.get("format") == "timestamp"
                                         or rule is None and name in _RUNTIME_CLOCKS):
                continue
            try:
                item[name] = normalize_observed_at(item[name])
            except SnapshotConstructionError:
                # Optional invalid clocks still reach the counted wire filter.
                # Integer source clocks and opaque evidence retain their meaning.
                pass
    return result


def _runtime_event_key(row: dict) -> str:
    # S2:392-399,821-822 uses JSON.stringify after sorting object properties.
    # Unlike WIRE canonical JSON, stringify enumerates integer-index keys first.
    if row.get("event_id") is not None:
        return row["event_id"]
    normalized = deepcopy(row)
    _validate_schema(normalized, "event", normalize_timestamps=True)

    def encode(value):
        if isinstance(value, dict):
            indices = sorted((k for k in value if re.fullmatch(r"0|[1-9][0-9]*", k)
                              and len(k) <= 10 and int(k) < 4294967295), key=int)
            remaining = sorted(set(value) - set(indices), key=lambda k: k.encode("utf-16-be", "surrogatepass"))
            return "{" + ",".join(_string(k) + ":" + encode(value[k]) for k in indices + remaining) + "}"
        if isinstance(value, list):
            return "[" + ",".join(encode(v) for v in value) + "]"
        return canonical_engine_snapshot_json(value)

    return _digest(encode(normalized).encode("utf-8"))


def _filter_runtime_references(logical: dict, *, scope: dict | None = None) -> None:
    # Drops invalid ids, outside references, account digests/accounts/claims, scope, totals/counts/cents/timestamps and row shapes in runtime.engines, engine_registry.assignments, engine_rollups.rows, probe_verdicts, conform_receipts, execution_events/counterpart_engine_ids, loss_breakers/engines; checks controls, parent_engine_id, engine_bindings default/symbols.
    # Source defects remain errors. Check before filtering so a locally complete
    # graph cannot become SOURCE_INVALID because one of its targets was omitted.
    source_ids = {row["engine_id"] for row in logical["engines"]}
    for control in logical["controls"]:
        if control["engine_id"] not in source_ids:
            _fail("SOURCE_INVALID", "control engine absent")
    for row in logical["engines"]:
        if row.get("parent_engine_id") is not None and row["parent_engine_id"] not in source_ids:
            _fail("SOURCE_INVALID", "parent engine absent")
    # S2:1624 delegates mandatory document names to leafhft-engines.ts:64.
    # Python printable strings can be whitespace-only or exceed JS's UTF-16 bound.
    rejected = {row["engine_id"] for row in logical["engines"] if "name" in row and
                (not row["name"].strip() or len(row["name"].encode("utf-16-le", "surrogatepass")) > 128)}
    for eid in sorted(rejected):
        logical["refusals"].append({"code": "DOCUMENT_INVALID", "engine_id": eid})
    # Reach a fixed point before filtering any dependent collection. Descendants
    # can precede their parents in the source, and each dropped record counts once.
    while True:
        dependents = {row["engine_id"] for row in logical["engines"]
                      if row["engine_id"] not in rejected and row.get("parent_engine_id") in rejected}
        if not dependents:
            break
        for eid in sorted(dependents):
            logical["refusals"].append({"code": "DOCUMENT_REFERENCE_FILTERED", "engine_id": eid})
        rejected.update(dependents)
    for row in logical["controls"]:
        if row["engine_id"] in rejected:
            logical["refusals"].append({"code": "CONTROL_REFERENCE_FILTERED", "engine_id": row["engine_id"]})
    logical["engines"] = [row for row in logical["engines"] if row["engine_id"] not in rejected]
    logical["controls"] = [row for row in logical["controls"] if row["engine_id"] not in rejected]
    engine_ids = {row["engine_id"] for row in logical["engines"]}
    scope = {**(scope or {}), "engine_ids": engine_ids}
    bindings = logical.get("engine_bindings")
    refusals = logical["refusals"]
    for row in logical["engines"]:
        # Catalog descriptions and opaque Darkhorse evidence can contain strings
        # permitted on disk but forbidden by snapshotJson (S2:1484-1494).
        for key in list(row):
            if not _wire_strings_safe(row[key]):
                del row[key]
                refusals.append({"code": "DOCUMENT_FIELD_INVALID", "engine_id": row["engine_id"],
                                 "source": "engines[]." + key})
    if not _s2_accepts("binding", (bindings, scope)):
        refusals.append({"code": "BINDING_INVALID", "source": "engine_bindings"})
        logical.pop("engine_bindings", None)

    def drop(code: str, path: str, references: list[tuple[str, Any]], row: Any) -> bool:
        account = row.get("account_id") if isinstance(row, dict) else None
        if account is None and isinstance(row, dict) and isinstance(row.get("claim"), dict):
            account = row["claim"].get("account_id")
        if code == "RUNTIME_ACCOUNT_SCOPE_MISMATCH":
            account = None  # The omission diagnostic itself belongs to this page.
        refusals.append({"code": code, "source": path,
                         "engine_id": references[0][1] if references else None, "account_id": account})
        return False

    def keep(references: list[tuple[str, Any]], row: Any, schema: str, path: str) -> bool:
        for code, invalid in (
                ("RUNTIME_ENGINE_ID_INVALID", lambda eid: not _s2_accepts("runtime_row", {"engine_id": eid})),
                ("RUNTIME_REFERENCE_OUTSIDE_GENERATION", lambda eid: eid not in engine_ids)):
            for reference_path, eid in references:
                if invalid(eid):
                    return drop(code, reference_path, references, row)
        # Preserve format diagnostics for malformed accounts. Canonical accounts
        # outside the host identity are scope omissions, including with no identity.
        unscoped = {k: v for k, v in scope.items() if k not in ("account", "accounts_disabled")}
        accounts = ([row.get("account_id"), (row.get("claim") or {}).get("account_id")]
                    if isinstance(row, dict) and isinstance(row.get("claim", {}), dict)
                    else [row.get("account_id")] if isinstance(row, dict) else [])
        if any(account is not None and _s2_accepts("account_id", (account, unscoped))
               and not _s2_accepts("account_id", (account, scope)) for account in accounts):
            return drop("RUNTIME_ACCOUNT_SCOPE_MISMATCH", path, references, row)
        if _s2_accepts("runtime_row", (row, scope, schema)):
            return True
        if (isinstance(row, dict) and
                ((row.get("account_id") is not None and not _s2_accepts("account_id", (row["account_id"], scope)))
                 or (isinstance(row.get("claim"), dict)
                     and not _s2_accepts("account_id", (row["claim"].get("account_id"), scope)))
                 or (row.get("account_id") is not None and isinstance(row.get("claim"), dict)
                     and row["account_id"] != row["claim"].get("account_id")))):
            code = "RUNTIME_ACCOUNT_INVALID"
        else:
            try:
                _validate_schema(row, schema, path=path)
            except SnapshotConstructionError as exc:
                code = _runtime_row_code(exc)
            else:
                code = "RUNTIME_ROW_INVALID"
        return drop(code, path, references, row)

    logical["controls"] = [row for row in logical["controls"]
                           if _s2_accepts("scope_row", (row, scope, "control"))
                           or drop("RUNTIME_ACCOUNT_SCOPE_MISMATCH", "controls[]",
                                   [("controls[].engine_id", row["engine_id"])], row)]
    runtime = logical["runtime"]
    collections = [(runtime, key, key, schema) for key, schema in
                   (("engines", "runtime-engine"), ("probe_verdicts", "verdict"),
                    ("conform_receipts", "receipt"), ("execution_events", "event"))]
    for key, field, schema in (("engine_registry", "assignments", "assignment"), ("engine_rollups", "rows", "rollup")):
        if runtime.get(key) is not None:
            collections.append((runtime[key], field, key + "." + field, schema))
    for block, key, path, schema in collections:
        if block.get(key) is None:
            continue
        retained = []
        seen = set()
        for row in block[key]:
            references = [(path + "[].engine_id", row.get("engine_id") if isinstance(row, dict) else None)]
            if key == "execution_events" and isinstance(row, dict) and isinstance(row.get("counterpart_engine_ids"), list):
                references.extend((path + "[].counterpart_engine_ids[]", eid)
                                  for eid in row["counterpart_engine_ids"])
            if keep(references, row, schema, path + "[]"):
                # kashbot-engine-runtime.ts:643,736,1697,1853-1859: uniqueness
                # is generation-wide, even when duplicates would land on different pages.
                identity = row["engine_id"]
                if schema == "event":
                    identity = _runtime_event_key(row)
                elif schema in ("verdict", "receipt"):
                    day = row.get("utc_day") or next(normalize_observed_at(row[k])[:10] for k in
                        ("observed_at", "occurred_at", "at", "as_of", "decided_at", "issued_at", "updated_at", "ts")
                        if row.get(k) is not None)
                    identity = (identity, day)
                if identity in seen:
                    drop("RUNTIME_DUPLICATE_RECORD", path + "[]", references, row)
                    continue
                if schema == "rollup":
                    # kashbot-engine-runtime.ts:705-709,1215: registry assignment
                    # is not an account fallback. Only retained runtime engine rows are.
                    account = row.get("account_id") or (row.get("claim") or {}).get("account_id")
                    if account is None:
                        account = next((r.get("account_id") or (r.get("claim") or {}).get("account_id")
                                        for r in runtime.get("engines", []) if r["engine_id"] == row["engine_id"]), None)
                    if account is None:
                        drop("RUNTIME_ACCOUNT_UNRESOLVED", path + "[]", references, row)
                        continue
                seen.add(identity)
                retained.append(row)
        if path == "engine_rollups.rows":
            block["truncated"] = block.get("truncated", 0) + len(block[key]) - len(retained)
        block[key] = retained
    retained = []
    for block in runtime.get("loss_breakers") or []:
        if not keep([], {**block, "engines": {}}, "breaker-block", "loss_breakers[]"):
            continue
        block["engines"] = {eid: row for eid, row in block["engines"].items()
                            if keep([("loss_breakers[].engines", eid)], row, "breaker", "loss_breakers[].engines")}
        retained.append(block)
    if runtime.get("loss_breakers") is not None:
        runtime["loss_breakers"] = retained

    # Local diagnostics may lack an identity; WIRE refusals never may. Missing
    # override targets are S2's explicit exception to generation membership.
    counts, wire, seen = {}, [], set()
    for refusal in refusals:
        code, eid = refusal["code"], refusal.get("engine_id")
        kind = code + (":" + refusal.get("source", "runtime") if code.startswith("RUNTIME_") else "")
        counts[kind] = counts.get(kind, 0) + 1
        if (not _s2_accepts("runtime_row", {"engine_id": eid})
                or (eid not in engine_ids and code != "OVERRIDE_ENGINE_MISSING")):
            continue
        account = refusal.get("account_id")
        unscoped = {k: v for k, v in scope.items() if k not in ("account", "accounts_disabled")}
        if (account is not None and _s2_accepts("account_id", (account, unscoped))
                and not _s2_accepts("account_id", (account, scope))):
            kind = "RUNTIME_ACCOUNT_SCOPE_MISMATCH:refusals[]"
            counts[kind] = counts.get(kind, 0) + 1
            continue
        if account is not None and not _s2_accepts("account_id", (account, scope)):
            account = None
        item = {"code": code, "engine_id": eid, "account_id": account}
        if not _s2_accepts("refusal", (item, scope)):
            continue
        key = canonical_bytes(item)
        if key not in seen:
            seen.add(key)
            wire.append(item)
    if len(wire) > MAX_PAGES * 32:
        _fail("SNAPSHOT_LIMIT_EXCEEDED", "refusal count")
    logical["refusals"] = wire
    if counts:
        logging.getLogger(__name__).warning("Engine snapshot omissions: %s", json.dumps(counts, sort_keys=True))


def _breaker_observation(record: dict) -> str | None:
    try:
        return normalize_observed_at(record.get("last_observed_at"), preserve_precision=True)
    except SnapshotConstructionError:
        return None


def _snapshot_loss_breakers(records: dict, utc_day: str, refusals: list[dict],
                            resolve_account: Callable[[str], str | None], *, identity: Any = None,
                            observed_at: str | None = None, registry_path: Path | None = None,
                            domain: str = "legacy-owner") -> list[dict]:
    """Project complete breaker states, retaining the latest source observation per account, plus the
    identity's computed ACCOUNT observation when no decision covers it (engine_pnl.account_breaker_block)."""
    from . import engine_pnl as pnl

    accounts, latest = {}, {}
    for eid, (record, _) in sorted(records.items()):
        breaker = record.get("breaker")
        if breaker is None:
            continue
        _validate_schema(breaker, "lifecycle-breaker")
        stamp = _breaker_observation(record)
        if stamp is None:
            refusals.append({"code": "BREAKER_OBSERVATION_INVALID", "engine_id": eid})
            continue
        if breaker["utc_day"] != utc_day:
            continue
        account = resolve_account(record.get("account_id"))
        if account is None:
            refusals.append({"code": "BREAKER_ACCOUNT_UNRESOLVED", "engine_id": eid})
            continue
        block = accounts.setdefault(account, {"utc_day": utc_day, "account_id": account, "engines": {}})
        # Pad the fraction for comparison: .1234 is later than .123, regardless
        # of the terminating Z. Keep millisecond precision on the receiver wire.
        second, fraction = stamp[:-1].split(".")
        order = second + "." + fraction.ljust(9, "0")
        if account not in latest or order > latest[account]:
            latest[account] = order
            block.update(day_start_portfolio_cents=breaker.get("day_start_marked_cents"),
                         observed_at=normalize_observed_at(stamp),
                         account={"pct": breaker.get("account_pct"),
                                  "loss_cents": breaker["account_loss_cents"],
                                  "limit_cents": breaker.get("account_limit_cents"),
                                  "suspended": breaker["account_suspended"]})
        block["engines"][eid] = {"pct": breaker.get("engine_pct"), "inherited": breaker.get("inherited"),
                                  "loss_cents": breaker["engine_loss_cents"],
                                  "limit_cents": breaker.get("engine_limit_cents"),
                                  "suspended": breaker["engine_suspended"]}
    account = resolve_account(identity.account_id) if identity is not None and observed_at is not None else None
    if account is not None and account not in accounts:
        computed = pnl.account_breaker_block(utc_day, observed_at, skip=accounts, identity=identity,
                                            registry_path=registry_path, domain=domain)
        if computed is not None and computed["account_id"] == account:
            accounts[account] = computed
    return [accounts[account] for account in sorted(accounts)]


@_bounded_decimal_evidence()
def collect_engine_snapshot(sources: SnapshotSources, *, context: HostContext, venue: str,
                            observed_at: str, producer_epoch: int, sequence: int) -> EngineSnapshot:
    """Capture once, validate against that capture, and freeze. No retries or source mutations.

    Source budgets are hard failures. Malformed optional evidence is EVIDENCE_INVALID,
    never a silent empty block. Dropped runtime rows are counted in one local log.
    Missing optional files retain their absent meaning.
    """
    from .engines import (Engine, DashboardAccountIdentity, AccountOverrides, capabilities,
                          engine_revision, account_revision)
    from .policy import policy_document, policy_digest, policy_from_mapping, risk_envelope
    from .canary import STATES, ExposureLedger, evidence_digest, lifecycle_status
    from . import engine_pnl as pnl
    from .engine_feeds import KALSHI_BOOK_KIND, kalshi_book_feed_id

    _identity(context, venue, producer_epoch, sequence)
    stamp = normalize_observed_at(observed_at, preserve_precision=True)
    # S2:304-309,1577 applies the runtime epoch bound to begin.observed_at too.
    if stamp[:4] < "1970":
        _fail("INVALID_IDENTITY", "observed_at before receiver epoch")
    now = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    envelope = risk_envelope()
    try:
        selected, engine_paths, lifecycle, verdict_paths, run_paths, dark_runs = _select(sources, now)
        try:
            capture = _Capture(selected)
        except (OSError, SnapshotConstructionError):
            selected.validate()
            raise
        registry = {}
        for path in engine_paths:
            raw = capture.document(path, required=True)
            _validate_schema(raw, "source-engine", code="SOURCE_INVALID")
            engine = Engine(**{**raw, "policy": policy_from_mapping(raw["policy"])})
            if engine.engine_id != path.stem:
                _fail("SOURCE_INVALID", "engine filename mismatch")
            registry[engine.engine_id] = engine
        identity_doc = capture.document(sources.identity_path)
        if identity_doc is not None:
            _identity_document(identity_doc)
        identity = DashboardAccountIdentity(**identity_doc) if identity_doc is not None else None
        if context.account_lane_id is not None and identity is None:
            _fail("SOURCE_INVALID", "account scope requires identity")
        overrides, refusals = _overrides(capture.document(sources.overrides_path), registry)
        bindings = _bindings(capture.document(sources.binding_path), registry)
        rows, controls, runtime_rows, records, exposures = [], [], [], {}, {}
        markets_by_engine = pnl._markets(bindings)
        for eid, engine in registry.items():
            global_policy, revision = policy_document(engine.policy), engine_revision(engine)
            row = {"engine_id": eid, "name": engine.name, "description": engine.description, "version": engine.version,
                   "revision": revision, "enabled": engine.enabled, "parent_engine_id": engine.parent_engine_id,
                   "capabilities": {**capabilities(engine.policy), "risk_envelope": envelope}, "risk_envelope": envelope,
                   "policy": global_policy, "policy_digest": policy_digest(engine.policy)}
            controls.append({"engine_id": eid, "account": None, "override_enabled": engine.enabled,
                             "override_policy": global_policy, "effective_enabled": engine.enabled,
                             "effective_policy": global_policy, "revision": revision})
            if identity is not None:
                override = overrides.get(identity.account_id, {}).get(eid)
                enabled, policy = (AccountOverrides._effective(engine, override) if override is not None
                                   else (engine.enabled, engine.policy))
                mapping = policy_document(policy)
                policy_override = dict(override.policy) if override else {}
                override_enabled = override.enabled if override else None
                scoped_revision = account_revision(identity.account_id, engine, override)
                row["account"] = {"account_id": identity.account_id, "enabled": override_enabled, "policy": policy_override,
                                  "revision": scoped_revision, "override_revision": override.revision if override else 0,
                                  "effective_enabled": enabled, "effective_policy": mapping,
                                  "effective_policy_digest": policy_digest(policy)}
                controls.append({"engine_id": eid, "account": identity.subaccount_number, "override_enabled": override_enabled,
                                 "override_policy": policy_override, "effective_enabled": enabled, "effective_policy": mapping,
                                 "revision": scoped_revision})
            record = capture.document(lifecycle / (eid + ".json"), error_code="EVIDENCE_INVALID")
            if record is not None:
                projection = record
                if record.get("breaker") is not None and _breaker_observation(record) is None:
                    # The original record still supplies integrity checks and the
                    # named refusal below. Do not emit its unreadable timestamp.
                    projection = {k: v for k, v in projection.items() if k not in ("last_observed_at", "breaker")}
                # D10 validates observation entries and produces the receiver's count.
                # Keep the source map intact for that single conversion below.
                _lifecycle_values({**projection, "observations": {}}
                                  if isinstance(projection.get("observations"), dict) else projection)
                if (not isinstance(record, dict) or record.get("schema_version") != 1 or record.get("engine_id") != eid
                        or record.get("state") not in STATES
                        or record.get("snapshot_digest") != evidence_digest({k: v for k, v in record.items() if k != "snapshot_digest"})
                        or record.get("historical_evidence_digest") != evidence_digest(record.get("historical_evidence"))):
                    _fail("EVIDENCE_INVALID", f"lifecycle: {eid}")
                projection = _lifecycle_wire_projection(projection)
                block, problem = pnl.lifecycle_block(projection)
                if problem == "lifecycle_oversize":
                    refusals.append({"code": "LIFECYCLE_OVERSIZE", "engine_id": eid})
                elif problem:
                    _fail("EVIDENCE_INVALID", f"lifecycle: {eid}: {problem}")
                else:
                    wire_lifecycle = _wire_lifecycle({**lifecycle_status(projection), **block}, eid, refusals)
                    if wire_lifecycle is not None:
                        row["lifecycle"] = wire_lifecycle
                records[eid] = (record, None)
            exposure = capture.document(lifecycle / "exposure" / (eid + ".json"), error_code="EVIDENCE_INVALID")
            if exposure is not None:
                exposures[eid] = exposure
            markets = markets_by_engine.get(eid, [])[:pnl.MAX_MARKETS]
            account = (record.get("account_id") if record else None) or (identity.account_id if identity else None)
            state = record.get("state") if record else None
            role = "probe" if state in pnl.PROBE_STATES else "incumbent" if markets else None
            runtime_row = {"engine_id": eid, "inputs": [{"kind": KALSHI_BOOK_KIND, "id": kalshi_book_feed_id(s)}
                                                       for s in markets][:pnl.MAX_INPUTS], "markets": markets,
                           "account_id": account}
            if account is not None:
                runtime_row["claim"] = {"account_id": account, "domain": pnl.DOMAIN, "role": role}
            if "lifecycle" in row:
                runtime_row["lifecycle"] = row["lifecycle"]
            runtime_rows.append(runtime_row)
            rows.append(row)
        if sources.darkhorse_state is not None:
            if identity is None or "darkhorse" in registry:
                _fail("SOURCE_INVALID", "Darkhorse needs an identity and a reserved catalog id")
            row, control = _darkhorse(capture, sources, identity, dark_runs, now)
            rows.append(row)
            controls.append(control)
        runs, events = [], []
        for path in run_paths:
            config = capture.document(path / "config.json", required=True, error_code="EVIDENCE_INVALID")
            _validate_schema(config, "run-config")
            if config.get("venue") != "kalshi":
                continue
            symbol = config["symbol"]
            runs.append((path, symbol))
            status_path = path / "kalshi-edge-status.json"
            status = capture.document(status_path, error_code="EVIDENCE_INVALID")
            if status is not None:
                _validate_schema({k: v for k, v in status.items() if k != "executor"}, "run-status")
                age = now.timestamp() - capture.sources[status_path].fingerprint[4] / 1e9
                executor = status.get("executor")
                if "executor" in status:
                    _strict_value(executor, dict, "executor")
                    _validate_schema({k: v for k, v in executor.items() if k != "events"}, "executor")
                if age <= pnl.MAX_STATUS_AGE_S and isinstance(executor, dict) and "events" in executor:
                    if not isinstance(executor["events"], list):
                        _fail("EVIDENCE_INVALID", "executor events")
                    for item in executor["events"]:
                        try:
                            _strict_value(item, dict, "source-event")
                            # Preserve references for the single acceptance filter, including invalid ids.
                            _validate_schema({k: v for k, v in item.items()
                                              if k not in ("engine_id", "counterpart_engine_ids")}, "source-event")
                            events.append({**item, "symbol": symbol,
                                           "counterpart_engine_ids": item.get("counterpart_engine_ids", []),
                                           "ticker": item.get("ticker"), "reason": item.get("reason")})
                        except (SnapshotConstructionError, ValueError, TypeError, OverflowError) as exc:
                            if isinstance(exc, SnapshotConstructionError) and exc.code == "SOURCE_LIMIT_EXCEEDED":
                                raise
                            refusals.append({"code": _runtime_row_code(exc), "source": "execution_events[]",
                                             "engine_id": item.get("engine_id") if isinstance(item, dict) else None})
        events.sort(key=lambda e: e["at_ms"], reverse=True)
        verdicts = []
        for eid, path in verdict_paths.items():
            doc = capture.document(path, required=True, error_code="EVIDENCE_INVALID")
            try:
                verdicts.append(_verdict(doc, eid))
            except (SnapshotConstructionError, ValueError, TypeError, OverflowError) as exc:
                if isinstance(exc, SnapshotConstructionError) and exc.code == "SOURCE_LIMIT_EXCEEDED":
                    raise
                refusals.append({"code": _runtime_row_code(exc), "source": "probe_verdicts[]", "engine_id": eid})
        verdicts.sort(key=lambda row: row["at"], reverse=True)
        registry_block = (_registry_source_block(capture, sources, refusals)
                          if sources.registry_path is not None else None)
        resolve_account = _account_resolver(capture, sources, identity, registry_block)
        runtime = {"engines": runtime_rows,
                   "loss_breakers": _snapshot_loss_breakers(records, now.date().isoformat(), refusals, resolve_account,
                                                            identity=identity, observed_at=normalize_observed_at(stamp),
                                                            registry_path=sources.registry_path,
                                                            domain=("account-lane:" + context.account_lane_id
                                                                    if context.account_lane_id else "legacy-owner")),
                   "engine_rollups": _rollups(capture, runs, exposures, records, identity.account_id if identity else None, now, refusals),
                   "probe_verdicts": verdicts, "execution_events": events}
        if registry_block is not None:
            runtime["engine_registry"] = _registry_projection(registry_block, resolve_account, refusals)
        logical = {"engines": rows, "controls": controls, "runtime": runtime, "refusals": refusals}
        if bindings is not None:
            logical["engine_bindings"] = bindings
        _filter_runtime_references(logical, scope={"host": context.host, "venue": venue,
                                   "account": identity.subaccount_number if identity is not None else None,
                                   "accounts_disabled": identity is None})
        _validate_schema(logical, "logical")
        return freeze_engine_snapshot(logical, context=context, venue=venue, observed_at=stamp,
                                      producer_epoch=producer_epoch, sequence=sequence, sources=tuple(capture.sources.values()))
    except SnapshotConstructionError:
        raise
    except OSError as exc:
        _fail("SOURCE_UNREADABLE", str(exc))
    except (ValueError, TypeError, KeyError, OverflowError, AttributeError) as exc:
        _fail("SOURCE_INVALID", str(exc))
