"""D5a UTC-day loss breaker. Pure: no I/O, no clock, O(engines) per call.

One rule shape everywhere: a loss is a PERCENTAGE of the account's marked portfolio at
the UTC-day start. A trip SUSPENDS new entries until the next 00:00Z (settlement and
exits continue); it is never a halt. A missing day start fails closed: every room is 0
and every scope is suspended with reason `day_start_unknown`.

Account numerator: the caller's net account loss (realized plus open mark, the whole
account, never a sum of losing engines). Engine numerator: that engine's attributed
realized loss plus its open mark loss. Foreign or unknown venue quantity is admission
consumption only and never reaches either numerator.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Mapping

DEFAULT_PCT = 50
MIN_PCT = 1
MAX_PCT = 100
MAX_SCOPES = 1024
MAX_CENTS = 10 ** 12
MAX_ID_LEN = 160  # engines.account_id bound
DAY_START_UNKNOWN = "day_start_unknown"
BREAKER_ACCOUNT = "breaker_account"


def clamp_pct(value) -> int:
    """Fails closed on a non-int (bool included); clamps an int to 1..100."""
    if type(value) is not int:
        raise ValueError("breaker pct must be an int")
    return min(MAX_PCT, max(MIN_PCT, value))


def _cents(value, name, *, signed=False) -> int:
    if type(value) is not int or abs(value) > MAX_CENTS or (not signed and value < 0):
        raise ValueError(f"invalid {name}")
    return value


def _scope_id(value) -> str:
    if type(value) is not str or not 1 <= len(value) <= MAX_ID_LEN:
        raise ValueError("invalid breaker scope id")
    return value


@dataclass(frozen=True)
class LossBreakers:
    """The registry's `loss_breakers` block. An engine value of None inherits the account pct."""
    default_pct: int = DEFAULT_PCT
    accounts: Mapping[str, int] = field(default_factory=dict)
    engines: Mapping[str, int | None] = field(default_factory=dict)

    def __post_init__(self):
        object.__setattr__(self, "default_pct", clamp_pct(self.default_pct))
        for name, inheritable in (("accounts", False), ("engines", True)):
            raw = getattr(self, name)
            if not isinstance(raw, Mapping) or len(raw) > MAX_SCOPES:
                raise ValueError(f"invalid loss_breakers {name}")
            clean = {}
            for key, pct in raw.items():
                clean[_scope_id(key)] = None if (inheritable and pct is None) else clamp_pct(pct)
            object.__setattr__(self, name, MappingProxyType(clean))

    @classmethod
    def from_dict(cls, raw) -> "LossBreakers":
        """Strict decode of `{default_pct, accounts, engines}`; unknown keys refused."""
        if not isinstance(raw, Mapping) or not set(raw) <= {"default_pct", "accounts", "engines"}:
            raise ValueError("invalid loss_breakers block")
        return cls(default_pct=raw.get("default_pct", DEFAULT_PCT),
                   accounts=raw.get("accounts", {}), engines=raw.get("engines", {}))


@dataclass(frozen=True)
class EngineLoss:
    """realized_cents is signed P&L (negative is a loss); open_mark_loss_cents is a nonnegative loss."""
    realized_cents: int
    open_mark_loss_cents: int

    def __post_init__(self):
        _cents(self.realized_cents, "engine realized_cents", signed=True)
        _cents(self.open_mark_loss_cents, "engine open_mark_loss_cents")

    @property
    def loss_cents(self) -> int:
        return max(0, self.open_mark_loss_cents - self.realized_cents)


@dataclass(frozen=True)
class EngineRoom:
    pct: int
    inherited: bool
    limit_cents: int
    loss_cents: int
    remaining_cents: int
    suspended: bool


@dataclass(frozen=True)
class BreakerDecision:
    account_pct: int
    account_limit_cents: int
    account_loss_cents: int
    account_remaining_cents: int
    account_suspended: bool
    engines: Mapping[str, EngineRoom]
    day_start_marked_cents: int | None
    reason: str | None


def effective_pct(breakers: LossBreakers, account_id: str, engine_id: str | None) -> tuple[int, bool]:
    """(pct, inherited). Account scope inherits default_pct; engine scope inherits the account pct."""
    account_pct = breakers.accounts.get(account_id)
    if engine_id is None:
        return (breakers.default_pct, True) if account_pct is None else (account_pct, False)
    if account_pct is None:
        account_pct = breakers.default_pct
    engine_pct = breakers.engines.get(engine_id)
    return (account_pct, True) if engine_pct is None else (engine_pct, False)


def _room(pct, day_start, loss):
    """(limit, remaining, suspended); suspended once the loss reaches the limit."""
    limit = pct * day_start // 100
    return limit, max(0, limit - loss), loss >= limit


def breaker_room(day_start_marked_cents: int | None, account_net_loss_cents: int,
                 losses_by_engine: Mapping[str, EngineLoss], breakers: LossBreakers,
                 account_id: str) -> BreakerDecision:
    """One evaluation per account. Fails closed on a missing or malformed day start."""
    if not isinstance(breakers, LossBreakers):
        raise TypeError("breakers must be LossBreakers")
    _scope_id(account_id)
    account_loss = max(0, _cents(account_net_loss_cents, "account_net_loss_cents", signed=True))
    if not isinstance(losses_by_engine, Mapping) or len(losses_by_engine) > MAX_SCOPES:
        raise ValueError("invalid losses_by_engine")
    known = (type(day_start_marked_cents) is int
             and 0 <= day_start_marked_cents <= MAX_CENTS)
    day_start = day_start_marked_cents if known else None
    account_pct, _ = effective_pct(breakers, account_id, None)
    engines = {}
    for engine_id, loss in losses_by_engine.items():
        _scope_id(engine_id)
        if not isinstance(loss, EngineLoss):
            raise TypeError("losses_by_engine values must be EngineLoss")
        pct, inherited = effective_pct(breakers, account_id, engine_id)
        if day_start is None:
            engines[engine_id] = EngineRoom(pct, inherited, 0, loss.loss_cents, 0, True)
        else:
            limit, remaining, suspended = _room(pct, day_start, loss.loss_cents)
            engines[engine_id] = EngineRoom(pct, inherited, limit, loss.loss_cents, remaining, suspended)
    if day_start is None:
        return BreakerDecision(account_pct, 0, account_loss, 0, True, MappingProxyType(engines),
                               None, DAY_START_UNKNOWN)
    limit, remaining, suspended = _room(account_pct, day_start, account_loss)
    return BreakerDecision(account_pct, limit, account_loss, remaining, suspended,
                           MappingProxyType(engines), day_start,
                           BREAKER_ACCOUNT if suspended else None)
