"""Tester lane Kalshi deposits: fetched by root, published root-owned, shipped by the keyless push.

The unit that talks to the dashboard never holds the Kalshi key, and the unit that holds the key
never talks to the dashboard. This module runs as root in leafhft-account-deposits.service. For each
lane bound in CONFIG_ROOT/bindings.json it reads the lane credential with the agent's own reader,
fetches ONE deposits page with no cursor (so a pending row is re-read on every run until the venue
finalizes it), keeps only the rows the ops-dashboard receiver accepts (validateKalshiLaneDeposits,
LD1), and publishes PROJECTION_ROOT/<lane>/kalshi-deposits.json root-owned, lane-group 0440, atomically. The
tenant push (push.push_account_lane) reads it back through read_published and ships the rows when
their digest changes.

Contract: each lane's credential read and venue fetch run in a CHILD PROCESS the parent kills at
LANE_WALL_S, so a slow-drip venue, a stalled DNS lookup or a hung read costs one lane at most
LANE_WALL_S + KILL_GRACE_S and never the lanes after it. The child reads the lane credential itself:
the parent never holds it, and it never reaches argv, the environment or a log (the child is handed
only the non-secret binding on stdin, and its stderr is discarded). A lane's failure writes nothing
for that lane and never stops another; every refusal is a static code, every other exception is
reported by type name only.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from . import account_lane_agent as agent

SCHEMA = "leafhft.lane-kalshi-deposits.v1"
FILE_NAME = "kalshi-deposits.json"
OUTCOME_PATH = Path("/var/lib/leafhft-account-deposits/outcomes.json")
MAX_LANES = 256  # the agent's bindings cap (agent_once)
LANE_BUDGET_S = 12.0  # the venue budget inside the child: every attempt's socket timeout fits in it
# The hard wall per lane, from child start to its result: the venue budget plus interpreter start
# and imports. Past it the child is killed, whatever it is blocked on.
LANE_WALL_S = 20.0
KILL_GRACE_S = 5.0  # the bounded wait for a killed child to be reaped
# leafhft-account-deposits.service TimeoutStartSec: every lane hitting the wall and its kill grace,
# plus setup.
UNIT_TIMEOUT_S = int(MAX_LANES * (LANE_WALL_S + KILL_GRACE_S)) + 60
CHILD_FLAG = "--lane-child"
MAX_CHILD_REQUEST_BYTES = 4096  # one binding: tenant and lane ids
# One venue page is read capped at 1 MiB (kalshi_account._make_default_fetch); its rows re-encoded
# as JSON stay well inside this.
MAX_CHILD_RESULT_BYTES = 4 << 20
_ERROR_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]{0,63}")
_REFUSAL_CODES = frozenset({"no_credential", "credential_invalid", "venue_error"})
CLOCK_SKEW_S = 300
# The receiver's own bounds (ops-dashboard src/lib/services/leafhft-runs.ts): one refused row refuses
# the WHOLE push, so a row outside any of them is dropped here and never sent.
MAX_ROWS = 200  # MAX_KALSHI_LANE_DEPOSITS
MAX_ROWS_BYTES = 65_536  # MAX_KALSHI_LANE_DEPOSITS_BYTES, UTF-8 bytes of JSON.stringify(rows)
MAX_STR = 64  # MAX_KALSHI_ACCOUNT_STR, measured like JS String.length (UTF-16 code units)
MAX_CENTS = 1_000_000_000  # MAX_KALSHI_ACCOUNT_SIGNED_CENTS, either sign
MAX_EPOCH_S = 4_102_444_800  # MAX_KALSHI_ACCOUNT_EPOCH_S
MAX_SAFE_INT = 2**53 - 1  # Number.isSafeInteger, the receiver's numeric id rule
FIELDS = ("id", "amount_cents", "fee_cents", "type", "status", "created_ts", "finalized_ts")
# Every count a published file may carry; `unkeyed` is a venue row with no usable id at all.
DROP_REASONS = ("shape", *FIELDS, "duplicate", "row_cap", "byte_cap", "unkeyed")
# The file is ASCII-escaped canonical JSON: a UTF-8 character of 2 to 4 bytes escapes to at most
# 3x as many, so this bounds a file carrying MAX_ROWS_BYTES of rows plus its small envelope.
MAX_FILE_BYTES = 3 * MAX_ROWS_BYTES + 4096
_DOC_KEYS = frozenset({"schema", "lane", "fetched_at", "rows", "dropped", "digest"})


class DocumentRefused(ValueError):
    """A published file the push must not forward. The message is a static code only:
    absent, unsafe, unreadable, invalid or stale."""


class PublishRefused(ValueError):
    """A lane the root fetch published nothing for. The message is a static code only."""


def _js_length(value):
    try:
        return len(value.encode("utf-16-le")) // 2
    except UnicodeEncodeError:  # a lone surrogate: not a string the receiver can hold
        return None


def _text(value):
    if type(value) is not str:
        return False
    length = _js_length(value)
    return length is not None and 1 <= length <= MAX_STR


def _int_within(value, low, high):
    return type(value) is int and low <= value <= high  # type() is int: never bool, never float


def row_refusal(row):
    """None when the receiver accepts `row` exactly as it is, else the first failing field (or
    `shape` for anything but a dict of exactly the seven receiver keys)."""
    if type(row) is not dict or set(row) != set(FIELDS):
        return "shape"
    if not (_text(row["id"]) or _int_within(row["id"], -MAX_SAFE_INT, MAX_SAFE_INT)):
        return "id"
    for name in ("amount_cents", "fee_cents"):
        if not _int_within(row[name], -MAX_CENTS, MAX_CENTS):
            return name
    for name in ("type", "status"):
        if not _text(row[name]):
            return name
    if not _int_within(row["created_ts"], 0, MAX_EPOCH_S):
        return "created_ts"
    if row["finalized_ts"] is not None and not _int_within(row["finalized_ts"], 0, MAX_EPOCH_S):
        return "finalized_ts"
    return None


def _json_bytes(value):
    """The receiver's measure: Buffer.byteLength(JSON.stringify(value)), compact and unescaped."""
    return len(json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))


def rows_digest(rows):
    return hashlib.sha256(agent.canonical(rows)).hexdigest()


def select_rows(rows):
    """(kept rows newest first, dropped counts by reason). Drops every row the receiver would
    refuse, a repeated id (the receiver's upsert key, String(id)), then the OLDEST rows past
    MAX_ROWS and past MAX_ROWS_BYTES. O(n log n) over at most one venue page."""
    dropped = dict.fromkeys(DROP_REASONS, 0)
    kept, seen = [], set()
    for row in rows:
        reason = row_refusal(row)
        if reason is None:
            key = str(row["id"])
            if key in seen:
                reason = "duplicate"
            else:
                seen.add(key)
                kept.append({name: row[name] for name in FIELDS})
        if reason is not None:
            dropped[reason] += 1
    kept.sort(key=lambda row: row["created_ts"], reverse=True)
    if len(kept) > MAX_ROWS:
        dropped["row_cap"] += len(kept) - MAX_ROWS
        kept = kept[:MAX_ROWS]
    sizes = [_json_bytes(row) for row in kept]
    total = sum(sizes) + max(0, len(kept) - 1) + 2  # the commas and the brackets
    while kept and total > MAX_ROWS_BYTES:
        total -= sizes.pop() + (1 if len(kept) > 1 else 0)
        kept.pop()
        dropped["byte_cap"] += 1
    return kept, {reason: count for reason, count in dropped.items() if count}


def document_bytes(lane_id, rows, dropped, fetched_at):
    return agent.canonical({"schema": SCHEMA, "lane": agent.identifier(lane_id), "fetched_at": fetched_at,
                            "rows": rows, "dropped": dropped, "digest": rows_digest(rows)})


def _refuse_constant(_):
    raise ValueError


def parse_document(data, lane_id, *, now_s, max_age_s):
    """(rows, digest) from a published file's bytes, else DocumentRefused("invalid"|"stale").
    Every row and every cap is checked again here, so a reader never forwards a row the receiver
    would refuse even if the file was written by something other than this module."""
    if type(data) is not bytes or len(data) > MAX_FILE_BYTES:
        raise DocumentRefused("invalid")
    try:
        doc = json.loads(data, object_pairs_hook=agent._pairs, parse_constant=_refuse_constant)
    except Exception:
        raise DocumentRefused("invalid") from None
    if type(doc) is not dict or set(doc) != _DOC_KEYS or doc["schema"] != SCHEMA or doc["lane"] != lane_id:
        raise DocumentRefused("invalid")
    fetched, rows, dropped = doc["fetched_at"], doc["rows"], doc["dropped"]
    if (type(fetched) is not int or fetched < 0 or type(rows) is not list or len(rows) > MAX_ROWS
            or type(dropped) is not dict
            or any(reason not in DROP_REASONS or type(count) is not int or count < 0
                   for reason, count in dropped.items())):
        raise DocumentRefused("invalid")
    seen = set()
    for row in rows:
        if row_refusal(row) is not None or str(row["id"]) in seen:
            raise DocumentRefused("invalid")
        seen.add(str(row["id"]))
    if _json_bytes(rows) > MAX_ROWS_BYTES:
        raise DocumentRefused("invalid")
    digest = rows_digest(rows)
    if doc["digest"] != digest or fetched > now_s + CLOCK_SKEW_S:
        raise DocumentRefused("invalid")
    if now_s - fetched > max_age_s:
        raise DocumentRefused("stale")
    return rows, digest


def published_path(lane_id):
    return agent.safe_path(agent.PROJECTION_ROOT / agent.identifier(lane_id) / FILE_NAME)


def _file_safe(info):
    return (stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == 0
            and (os.name != "posix" or (info.st_gid == os.getgid()
                                       and stat.S_IMODE(info.st_mode) == 0o440)))


def _published_tree_safe(path):
    info = os.lstat(path)
    if not _file_safe(info):
        return None
    for depth, part in enumerate(path.parents):
        level = os.lstat(part)
        if not stat.S_ISDIR(level.st_mode) or level.st_uid != 0:
            return None
        if os.name == "posix" and level.st_mode & 0o022:
            if depth < 2 or not level.st_mode & stat.S_ISVTX:
                return None
    return info


def read_published(lane_id, *, now_s, max_age_s):
    """(rows, digest) from PROJECTION_ROOT/<lane>/kalshi-deposits.json, else DocumentRefused with a
    static code. The file must be root-owned, own-group 0440 and single-link, in root-owned
    directories that are not group/other-writable with trusted ancestors; it is opened O_NOFOLLOW
    and read through the very inode that check saw, bounded."""
    try:
        # Nothing at the name at all (a host the root fetch never ran on) is `absent`, checked with
        # lstat before any path rule, so a link planted at the name is still `unsafe` below.
        os.lstat(agent.PROJECTION_ROOT / agent.identifier(lane_id) / FILE_NAME)
        path = published_path(lane_id)
        info = _published_tree_safe(path)
    except FileNotFoundError:
        raise DocumentRefused("absent") from None
    except agent.LaneRefused:
        raise DocumentRefused("unsafe") from None
    except OSError:
        raise DocumentRefused("unreadable") from None
    if info is None:
        raise DocumentRefused("unsafe")
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
                     | getattr(os, "O_BINARY", 0))
    except FileNotFoundError:
        raise DocumentRefused("absent") from None
    except OSError:
        raise DocumentRefused("unsafe") from None
    try:
        with os.fdopen(fd, "rb") as stream:
            opened = os.fstat(stream.fileno())
            if not _file_safe(opened) or (opened.st_dev, opened.st_ino) != (info.st_dev, info.st_ino):
                raise DocumentRefused("unsafe")
            data = stream.read(MAX_FILE_BYTES + 1)
    except DocumentRefused:
        raise
    except OSError:
        raise DocumentRefused("unreadable") from None
    return parse_document(data, lane_id, now_s=now_s, max_age_s=max_age_s)


def _bindings():
    """The agent's bindings, validated as agent_once validates them."""
    bindings = agent.parse(agent.read_private(agent.CONFIG_ROOT / "bindings.json"))
    if type(bindings) is not list or len(bindings) > MAX_LANES:
        raise agent.LaneRefused("invalid bindings")
    seen = set()
    for binding in bindings:
        if (type(binding) is not dict
                or set(binding) != set(agent.scope(binding.get("tenant_id"), binding.get("lane_id")))):
            raise agent.LaneRefused("invalid binding")
        agent.check_scope(binding, binding)
        if binding["lane_id"] in seen:
            raise agent.LaneRefused("duplicate lane binding")
        seen.add(binding["lane_id"])
    return bindings


def _credential(paths, binding):
    """The lane credential through the root agent's own reader (read_private + parse of
    CONFIG_ROOT/<lane>/credential.json), reduced to the two fields the signer needs."""
    try:
        doc = agent.parse(agent.read_private(paths.config / "credential.json"))
        agent.check_scope(doc, binding)
    except FileNotFoundError:
        raise PublishRefused("no_credential") from None
    except Exception:
        raise PublishRefused("credential_invalid") from None
    if type(doc.get("key_id")) is not str or type(doc.get("private_key_pem")) is not str:
        raise PublishRefused("credential_invalid")
    return doc["key_id"], doc["private_key_pem"]


def _trusted_directory(path, lane_id=None, *, report=None):
    """Create if missing; verify root ownership without changing the agent's directory mode."""
    try:
        os.mkdir(path, 0o700 if lane_id is not None else 0o755)
        if os.name == "posix" and lane_id is not None:
            with agent.private_parent(path / FILE_NAME) as fd:
                # Leave a readable, reconcilable state if chown or chmod is interrupted.
                os.fchmod(fd, 0o755)
                try:
                    gid = agent.lane_gid(lane_id)
                except agent.LaneRefused:
                    if report is not None:
                        report["lane_directory"] = "lane_user_unresolved"
                else:
                    try:
                        os.fchown(fd, 0, gid)
                        os.fchmod(fd, 0o750)
                    except OSError:
                        if report is not None:
                            report["lane_directory"] = "conversion_failed"
        else:
            os.chmod(path, 0o755)  # the root unit's UMask=0077 must not hide the projection
    except FileExistsError:
        pass
    info = os.lstat(path)
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != 0
            or (os.name == "posix" and (
                not agent.lane_dir_mode_ok(info, lane_id) if lane_id is not None
                else info.st_mode & 0o022))):
        raise PublishRefused("projection_unsafe")


def _lane_directory(lane_id, *, report=None):
    try:
        return _lane_directory_checked(lane_id, report=report)
    except agent.LaneRefused:  # safe_path: a link somewhere in the path
        raise PublishRefused("projection_unsafe") from None


def _lane_directory_checked(lane_id, *, report=None):
    root = agent.safe_path(agent.PROJECTION_ROOT)
    if os.name == "posix":
        for part in root.parents:
            info = os.lstat(part)
            if (not stat.S_ISDIR(info.st_mode) or info.st_uid != 0
                    or (info.st_mode & 0o022 and not info.st_mode & stat.S_ISVTX)):
                raise PublishRefused("projection_unsafe")
    _trusted_directory(root)
    directory = agent.safe_path(root / agent.identifier(lane_id))
    _trusted_directory(directory, lane_id, report=report)
    return directory


def _lane_gid(lane_id):
    try:
        return agent.lane_gid(lane_id)
    except agent.LaneRefused:
        raise PublishRefused("lane_user_unresolved") from None


def _write_published(target, data, *, gid):
    """Atomic dir-fd replace, already root-owned and lane-group 0440 when visible."""
    if os.name == "posix":
        with agent.private_parent(target) as parent:
            info = os.fstat(parent)
            if not agent.lane_dir_mode_ok(info, target.parent.name):
                raise PublishRefused("projection_unsafe")
            name = ".deposits-" + secrets.token_hex(16)
            fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o600, dir_fd=parent)
            try:
                with os.fdopen(fd, "wb") as stream:
                    os.fchown(stream.fileno(), 0, gid)
                    os.fchmod(stream.fileno(), 0o440)
                    stream.write(data)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(name, target.name, src_dir_fd=parent, dst_dir_fd=parent)
                os.fsync(parent)
            finally:
                try:
                    os.unlink(name, dir_fd=parent)
                except FileNotFoundError:
                    pass
        return
    fd, name = tempfile.mkstemp(prefix=".deposits-", dir=target.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, target)
    finally:
        try:
            os.unlink(name)
        except FileNotFoundError:
            pass


def _fetch_rows(key_id, pem, deadline):
    """(raw deposit rows newest first, count of unkeyed venue rows): ONE deposits page, no cursor,
    no balances, every attempt inside `deadline`, type and status read up to the receiver's 64.
    Any venue error refuses the lane."""
    from . import kalshi_account
    fetch = kalshi_account._make_default_fetch(key_id, pem, kalshi_account.REST_URL, deadline=deadline)
    sync = kalshi_account.AccountSync(None, "", "", fetch=fetch, lists=("deposits",), balances=False,
                                      lane_deposits=True)
    result = sync.sync()
    stats = result["stats"]
    if stats["errors"] or type(result.get("deposits")) is not list:
        raise PublishRefused("venue_error")
    return result["deposits"], stats["bad_rows"]


def lane_fetch(binding):
    """CHILD SIDE. (raw rows, unkeyed count) for one lane: reads the lane credential itself through
    the root agent's reader and spends at most LANE_BUDGET_S at the venue."""
    if type(binding) is not dict or set(binding) != set(agent.scope(binding.get("tenant_id"),
                                                                      binding.get("lane_id"))):
        raise agent.LaneRefused("invalid binding")
    agent.check_scope(binding, binding)
    key_id, pem = _credential(agent.LanePaths(binding["lane_id"]), binding)
    deadline = time.monotonic() + LANE_BUDGET_S
    try:
        return _fetch_rows(key_id, pem, deadline)
    finally:
        del key_id, pem


def child_main(stdin, stdout):
    """CHILD SIDE. Reads one binding from `stdin` (bounded), writes one canonical JSON outcome line
    to `stdout`: ok with the raw rows, a static refusal code, or an exception's type name only."""
    try:
        request = stdin.read(MAX_CHILD_REQUEST_BYTES + 1)
        if len(request) > MAX_CHILD_REQUEST_BYTES:
            raise ValueError
        raw, unkeyed = lane_fetch(agent.parse(request))
        line = agent.canonical({"status": "ok", "rows": raw, "unkeyed": unkeyed})
    except PublishRefused as exc:
        line = agent.canonical({"status": "refused", "code": str(exc)})
    except Exception as exc:
        line = agent.canonical({"status": "error", "code": type(exc).__name__})
    stdout.write(line + b"\n")
    stdout.flush()
    return 0


def _child_command():
    # A literal module name: under `python -m` this module's __name__ is "__main__".
    return [sys.executable, "-m", "leafhft.account_lane_deposits", CHILD_FLAG]


def _run_child(command, request, wall_s):
    """PARENT SIDE. stdout of one child that exited 0 inside `wall_s`, else PublishRefused
    ("timeout" | "child_failed"). The child is killed at the wall wherever it is blocked (DNS, a
    slow-drip read) and reaped within KILL_GRACE_S; its stderr goes to /dev/null, never a log."""
    try:
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.DEVNULL, close_fds=True)
    except (OSError, ValueError):
        raise PublishRefused("child_failed") from None
    try:
        try:
            out, _ = child.communicate(request, timeout=wall_s)
        except subprocess.TimeoutExpired:
            raise PublishRefused("timeout") from None
    finally:
        if child.poll() is None:
            child.kill()
            try:
                child.communicate(timeout=KILL_GRACE_S)
            except (subprocess.TimeoutExpired, OSError, ValueError):
                pass
    if child.returncode != 0 or len(out) > MAX_CHILD_RESULT_BYTES:
        raise PublishRefused("child_failed")
    return out


def decode_outcome(out):
    """PARENT SIDE. (raw rows, unkeyed count) from a child's last stdout line, else PublishRefused
    with the child's static code, "error:<TypeName>", or "child_failed" for anything malformed."""
    line = out.rstrip(b"\r\n").rsplit(b"\n", 1)[-1]
    try:
        outcome = json.loads(line, object_pairs_hook=agent._pairs, parse_constant=_refuse_constant)
    except Exception:
        raise PublishRefused("child_failed") from None
    status = outcome.get("status") if type(outcome) is dict else None
    if (status == "ok" and set(outcome) == {"status", "rows", "unkeyed"} and type(outcome["rows"]) is list
            and type(outcome["unkeyed"]) is int and outcome["unkeyed"] >= 0):
        return outcome["rows"], outcome["unkeyed"]
    code = outcome.get("code") if type(outcome) is dict and set(outcome) == {"status", "code"} else None
    if status == "refused" and code in _REFUSAL_CODES:
        raise PublishRefused(code)
    if status == "error" and type(code) is str and _ERROR_NAME.fullmatch(code):
        raise PublishRefused("error:" + code)
    raise PublishRefused("child_failed")


def fetch_isolated(binding):
    """PARENT SIDE. One lane's (raw rows, unkeyed count) from a child process under the hard wall.
    The child is handed only the non-secret binding, on stdin."""
    return decode_outcome(_run_child(_child_command(), agent.canonical(binding), LANE_WALL_S))


def publish_lane(binding, *, now_s=None):
    """One lane: {lane, rows, dropped} after one atomic publish, or PublishRefused and nothing written."""
    lane_id = agent.identifier(binding.get("lane_id") if type(binding) is dict else None)
    gid = _lane_gid(lane_id)
    report = {"lane": lane_id}
    directory = _lane_directory(lane_id, report=report)
    raw, unkeyed = fetch_isolated(binding)
    rows, dropped = select_rows(raw)
    if unkeyed:
        dropped["unkeyed"] = unkeyed
    fetched_at = int(time.time()) if now_s is None else now_s
    data = document_bytes(lane_id, rows, dropped, fetched_at)
    try:
        # safe_path refuses a link at the name itself, so a planted link is never written through.
        _write_published(agent.safe_path(directory / FILE_NAME), data, gid=gid)
    except agent.LaneRefused:
        raise PublishRefused("projection_unsafe") from None
    report.update(rows=len(rows), dropped=dropped)
    return report


def publish_all(*, now_s=None):
    """{lane_id: static status} for every bound lane; nothing at all while CONFIG_ROOT/ENABLED is
    absent. One lane's failure is recorded as its status and never stops the next lane."""
    if not agent.safe_path(agent.CONFIG_ROOT / "ENABLED").exists():
        return {}
    report = {}
    for binding in _bindings():
        lane_id = binding["lane_id"]
        try:
            publish_lane(binding, now_s=now_s)
            report[lane_id] = "published"
        except PublishRefused as exc:
            report[lane_id] = str(exc)
        except Exception as exc:
            report[lane_id] = "error:" + type(exc).__name__
    return report


def run_once(*, now_s=None):
    if os.name != "posix" or os.geteuid() != 0:
        raise agent.LaneRefused("root agent required")
    return publish_all(now_s=now_s)


def write_outcomes(report, *, now_s=None):
    """Replace this run's bounded, secret-free status snapshot in the unit's private state dir."""
    at = int(time.time()) if now_s is None else now_s
    codes = _REFUSAL_CODES | {"published", "timeout", "child_failed", "projection_unsafe",
                              "lane_user_unresolved"}
    outcomes = {}
    for lane_id, status in list(report.items())[:MAX_LANES]:
        if status not in codes and not (status.startswith("error:")
                                       and _ERROR_NAME.fullmatch(status[6:])):
            status = "error"
        outcomes[agent.identifier(lane_id)] = {"status": status, "at": at}
    target = agent.safe_path(OUTCOME_PATH)
    if os.name != "posix":
        agent.write_private(target, outcomes)
        return
    with agent.private_parent(target) as parent:
        info = os.fstat(parent)
        if (info.st_uid != 0 or info.st_gid != 0 or stat.S_IMODE(info.st_mode) != 0o700):
            raise agent.LaneRefused("unsafe outcome directory")
        name = ".outcomes-" + secrets.token_hex(16)
        fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                os.fchown(stream.fileno(), 0, 0)
                os.fchmod(stream.fileno(), 0o600)
                stream.write(agent.canonical(outcomes))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(name, target.name, src_dir_fd=parent, dst_dir_fd=parent)
            os.fsync(parent)
        finally:
            try:
                os.unlink(name, dir_fd=parent)
            except FileNotFoundError:
                pass


def main(argv=None):
    if list(sys.argv[1:] if argv is None else argv) == [CHILD_FLAG]:
        return child_main(sys.stdin.buffer, sys.stdout.buffer)
    try:
        report = run_once()
        write_outcomes(report)
    except agent.LaneRefused as exc:
        print(f"kalshi deposits: {exc}", flush=True)
        return 2
    except Exception as exc:
        print(f"kalshi deposits: {type(exc).__name__}", flush=True)
        return 2
    for lane_id, status in sorted(report.items()):
        print(f"kalshi deposits {lane_id[:8]}: {status}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
