"""Durable research -> shadow -> probe -> account canary lifecycle.

This registry never grants venue authority or broad live rollout. Each transition
replaces one locked snapshot, including its evidence and history, atomically.
Existing live authority remains necessary in addition to these restrictions.

Losses never halt (D5a): the UTC-day loss breaker in leafhft/breaker.py SUSPENDS new
entries until the next 00:00Z, and settlement continues. Halts are reserved for the
integrity codes and for the kill criterion (three breaker trips in seven UTC days).
The lock is an OS flock (kalshi_pool._FileLock) that a dead process cannot leave held;
a busy lock raises LifecycleBusy within 250 ms so the caller refuses ONE entry and never
latches the book.
"""
from __future__ import annotations

from contextlib import contextmanager
import copy
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
import hashlib
import json
import math
import os
from pathlib import Path
import re
import secrets
import tempfile
import time

from .breaker import DAY_START_UNKNOWN, MAX_CENTS, EngineLoss, LossBreakers, breaker_room
from .engines import DEFAULT_CAPACITY, SUPPORTED_CAPACITIES, _id, account_id
from .policy import HARD_MAXIMA, _canonical as _policy_canonical, policy_digest, policy_document
from .trials import TrialError, _canonical, _document, _loads, _safe_stat, research_promotion_gate

MAX_BYTES = 1024 * 1024
MAX_RECORDS = DEFAULT_CAPACITY  # the lifecycle store capacity, 1024 records (follows the engine catalog)
CANARY_SIZE_FRACTION = .05
PROBE_CONTRACTS = 1
PROBE_SIZED_CONTRACTS = (2, 5)
_NEXT_RUNG = {1: 2, 2: 5}
LOCK_TIMEOUT_S = .25
LIFECYCLE_DIR_ENV = "LEAFHFT_LIFECYCLE_DIR"
HISTORY_LIMIT = 32
STOP_REASON_LIMIT = 32
OBSERVED_SYMBOL_LIMIT = 32
KILL_TRIPS = 3
KILL_WINDOW_DAYS = 7
REWRITE_AFTER_S = 60  # an unchanged snapshot is rewritten at most once a minute

# C-DS: the probe breaker's day-start portfolio value, write-once per account per UTC day.
DAY_START_SCHEMA = 2
DAY_START_MAX_BYTES = 4096
DAY_START_WINDOW_S = 15 * 60  # capture window [00:00Z, 00:15Z], both ends inclusive
DAY_START_DAYS_KEEP = 8
DAY_START_MISSED = "window_missed"
# A supplied capture record never becomes a value when its day or account disagrees (never written).
DAY_START_DAY_MISMATCH = "day_mismatch"
DAY_START_ACCOUNT_MISMATCH = "account_mismatch"
# A configured registry projection that is invalid or unreadable: the capture fails closed.
DAY_START_REGISTRY_INVALID = "registry_invalid"
# X-F3 (b): only these records read the account/day record and run the D5a breaker; every other
# lifecycle state keeps its paid-basis term and never consumes the probes' day start.
PROBE_LIFECYCLE_STATES = frozenset({"probe", "probe_sized"})
# D5a / X-F3: the probe ENTRY gate (ProbeExecutor through cli._ProbeHost.breakers) takes its account
# numerator from the shared AccountRiskLedger: the account's attributed net loss since the UTC day
# open (PROBE_GATE_LOSS_BASIS). This store's own breaker block is never handed that figure by the
# cli observe path, so its account_loss_cents is the net of the engines this store observes
# (ACCOUNT_LOSS_FALLBACK), and the block names both so the reader knows which one gates probes.
ACCOUNT_LOSS_FALLBACK = "probe_attributed_fallback"
PROBE_GATE_LOSS_BASIS = "account_risk_net_loss"
# C13 fix f, fix g: a trial's opening balance (the balance read taken at ACTIVATION, write-once per
# trial) and the deposits and withdrawals the balance reconciliation adds to it.
TRANSFER_KINDS = ("deposit", "withdrawal")
OPENING_TRANSFER_LIMIT = 256
_OPENING_KEYS = frozenset({"trial_id", "balance_cents", "observed_at", "updated_ts", "recorded_at", "transfers"})

# Legacy shadow and canary stay readable; new code never enters them.
STATES = frozenset({"shadow", "canary", "probe", "probe_sized", "halted", "graduated", "retired"})
ENTRY_STATES = frozenset({"canary", "probe", "probe_sized", "graduated"})
GRADUATE_FROM = frozenset({"probe", "probe_sized"})
INTEGRITY_CODES = ("risk_invariant", "attribution_gap", "data_integrity_failure",
                   "policy_changed", "account_attribution_gap")
SUSPEND_CODES = ("breaker_engine", "breaker_account", "foreign_exposure")
# S7 A: a retired tenant record exports LEASE_RETIRED; a halted one whose reasons are not otherwise
# whitelisted exports OPERATOR_HALT (lifecycle_lease.restriction_facts). HARVEST_HALT_CODES is the
# outbox whitelist; ACK_LIMIT bounds a record's harvested_halts (a lease's acknowledged_halts).
LEASE_RETIRED = "lease_retired"
OPERATOR_HALT = "operator_halt"
HARVEST_HALT_CODES = frozenset(INTEGRITY_CODES) | {
    "policy_changed", "account_attribution_gap", "shadow_setup_failed", "shadow_data_integrity_failure",
    "kill_criterion", LEASE_RETIRED, OPERATOR_HALT}
ACK_LIMIT = STOP_REASON_LIMIT
# Ordering is by counters, never by wall clock: a record's halt_seq counts its halts, and the store's
# revision counts its record writes (CanaryStore.snapshot, lifecycle_lease.build_lease).
HALT_SEQ_MAX = 2 ** 53
# A root harvest never takes a halt_seq more than this far above the highest it has already harvested
# for the record (a book raises one per new halt; a forged outbox cannot jump the counter).
HARVEST_SEQ_BOUND = 4096
# Every record carries the store revision it was written at (store_revision); store.revision is only
# an atomic, non-fsynced cache; recovery scans records outside the flock and includes removals.
REVISION_NAME = "store.revision"  # not *.json, so list() never reads it as a record
REMOVAL_FLOOR_NAME = "store.removal-floor"  # durable highest revision used by a removal
REVISION_MAX_BYTES = 32
# Present when the revision could not be established: record writes (halts first) still land, and
# lease builds refuse lease_revision_unknown until repair_store_revision.
REVISION_UNKNOWN_NAME = "store.revision-unknown"
LEASE_REVISION_UNKNOWN = "lease_revision_unknown"
# A random id minted once per store; a new epoch (a restore, a repair) resets lease ordering per lane.
EPOCH_NAME = "store.epoch"
EPOCH_RE = re.compile(r"[0-9a-f]{32}")
LEASE_ORIGIN = "lease"  # _halt(origin=): the root raised it, so it is kept in lease_halts, not halt_seqs
_O_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)
_O_BINARY = getattr(os, "O_BINARY", 0)

_REASON_TEXT = {
    "risk_invariant": "A risk invariant failed; entries are halted until a new approval.",
    "attribution_gap": "An order could not be attributed to this engine; entries are halted.",
    "data_integrity_failure": "Runner data failed an integrity check; entries are halted.",
    "policy_changed": "The engine policy changed after approval; entries are halted.",
    "account_attribution_gap": "The book's account is not the approved account; entries are halted.",
    "kill_criterion": "Three loss breaker trips in seven UTC days; entries are halted.",
    "breaker_engine": "This engine's UTC-day loss reached its breaker; entries resume at 00:00Z.",
    "breaker_account": "The account's UTC-day loss reached its breaker; entries resume at 00:00Z.",
    "foreign_exposure": "Foreign exposure used the account's room; entries resume at 00:00Z.",
    "day_start_unknown": "The day-start portfolio value is not reported; no entries until it is.",
    "account_eligibility_expired": "The probe authorization expired; entries stopped.",
    "lease_retired": "A tenant book retired this engine under its lease; entries are halted.",
    "lease_halted": "The lifecycle lease halted this engine; entries are halted.",
    "operator_halt": "A tenant book halted this engine for a reason outside the harvest codes; entries are halted.",
}


class CanaryError(TrialError):
    pass


class LifecycleBusy(CanaryError):
    """The lifecycle or exposure lock is held elsewhere: refuse ONE entry, never latch."""
    code = "exposure_ledger_busy"


def evidence_digest(value):
    return hashlib.sha256(_canonical(value)).hexdigest()


def lifecycle_directory(engines_dir, lifecycle_dir=None):
    """Explicit directory, then LEAFHFT_LIFECYCLE_DIR, then today's <engines_dir>/lifecycle."""
    for candidate in (lifecycle_dir, os.environ.get(LIFECYCLE_DIR_ENV)):
        if candidate:
            if len(str(candidate)) > 4096:
                raise CanaryError("lifecycle directory path too long")
            return Path(candidate)
    return Path(engines_dir) / "lifecycle"


def _time(now=None):
    now = datetime.now(timezone.utc) if now is None else now
    if not isinstance(now, datetime) or now.tzinfo is None:
        raise CanaryError("timezone-aware timestamp required")
    return now.astimezone(timezone.utc)


def _finite(value):
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def _epoch_s(now):
    return int(now.timestamp())


def _next_midnight_s(now):
    return int(datetime.combine(now.date() + timedelta(days=1), datetime.min.time(),
                                timezone.utc).timestamp())


def _ns_day(now_ns):
    if type(now_ns) is not int or now_ns < 0:
        raise CanaryError("invalid timestamp")
    return datetime.fromtimestamp(now_ns // 10**9, timezone.utc).date().isoformat()


def _utc_day(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise CanaryError("invalid UTC day")
    try:
        date.fromisoformat(value)
    except ValueError as exc:
        raise CanaryError("invalid UTC day") from exc
    return value


def _cents(value, name, *, signed=False):
    if type(value) is not int or abs(value) > MAX_CENTS or (not signed and value < 0):
        raise CanaryError(f"invalid {name}")
    return value


def _bounded_ref(value, name):
    if not isinstance(value, str) or not value.strip() or len(value) > 200:
        raise CanaryError(f"bounded {name} required")
    return value


def _aware_text(value, name):
    """A timezone-aware time (datetime or ISO text) as UTC ISO text; CanaryError otherwise."""
    moment = value
    if isinstance(value, str) and 0 < len(value) <= 64:
        try:
            moment = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            moment = None
    if not isinstance(moment, datetime) or moment.tzinfo is None:
        raise CanaryError(f"timezone-aware {name} required")
    return moment.astimezone(timezone.utc).isoformat()


def _aware_or_none(value):
    try:
        return _aware_text(value, "time")
    except CanaryError:
        return None


def opening_balance(record, trial_id):
    """The opening balance (C13 fix f) a lifecycle record persists for `trial_id`, as a copy: {trial_id,
    balance_cents, observed_at, updated_ts, recorded_at, transfers}; None when the record carries none
    for that trial or it is malformed (a reconciliation without it is inconclusive). Pure."""
    doc = record.get("opening_balance") if isinstance(record, dict) else None
    if not isinstance(doc, dict) or set(doc) != _OPENING_KEYS or doc["trial_id"] != trial_id:
        return None
    cents, updated, transfers = doc["balance_cents"], doc["updated_ts"], doc["transfers"]
    if (type(cents) is not int or not 0 <= cents <= MAX_CENTS
            or _aware_or_none(doc["observed_at"]) is None or _aware_or_none(doc["recorded_at"]) is None
            or (updated is not None and (type(updated) is not int or updated < 0))
            or not isinstance(transfers, list) or len(transfers) > OPENING_TRANSFER_LIMIT):
        return None
    for row in transfers:
        if (not isinstance(row, dict) or set(row) != {"kind", "amount_cents", "at"} or row["kind"] not in TRANSFER_KINDS
                or type(row["amount_cents"]) is not int or not 0 < row["amount_cents"] <= MAX_CENTS
                or _aware_or_none(row["at"]) is None):
            return None
    return copy.deepcopy(doc)


def _reason(code):
    return {"code": code, "text": _REASON_TEXT.get(code, code)}


def _reason_codes(record):
    """stop_reasons as codes; legacy snapshots carry bare strings."""
    codes = []
    for item in record.get("stop_reasons") or ():
        code = item if isinstance(item, str) else item.get("code") if isinstance(item, dict) else None
        if isinstance(code, str) and code:
            codes.append(code)
    return codes


def _merge_reasons(record, codes):
    merged = set(_reason_codes(record)) | set(codes)
    record["stop_reasons"] = [_reason(code) for code in sorted(merged)][:STOP_REASON_LIMIT]


def _drop_reasons(record, codes):
    kept = [code for code in _reason_codes(record) if code not in codes]
    record["stop_reasons"] = [_reason(code) for code in sorted(set(kept))][:STOP_REASON_LIMIT]


def _halt_seq(value):
    """A stored halt_seq, or 0 when absent or malformed."""
    return value if type(value) is int and 0 <= value <= HALT_SEQ_MAX else 0


def halt_marks(record):
    """({stop reason code: the halt_seq it was raised at}, {codes a lease applied}), both limited to
    the record's current stop reasons. The marks live beside stop_reasons (halt_seqs, lease_halts),
    so stop_reasons keeps its public {code, text} shape."""
    codes = set(_reason_codes(record))
    seqs = record.get("halt_seqs") if isinstance(record.get("halt_seqs"), dict) else {}
    lease = record.get("lease_halts") if isinstance(record.get("lease_halts"), list) else ()
    return ({code: seq for code, seq in seqs.items() if code in codes and type(seq) is int},
            {code for code in lease if code in codes})


def _set_halt_marks(record, seqs, lease):
    codes = set(_reason_codes(record))
    seqs = {code: seq for code, seq in seqs.items() if code in codes}
    lease = sorted(code for code in lease if code in codes and code not in seqs)
    for key, value in (("halt_seqs", dict(sorted(seqs.items()))), ("lease_halts", lease)):
        if value:
            record[key] = value
        else:
            record.pop(key, None)


def _take_halt_seq(record):
    """The record's next halt_seq. A counter already at HALT_SEQ_MAX fails closed: the record is
    marked halt_seq_saturated, which makes every local halt it carries unacknowledgeable until an
    operator repair, so a saturated counter never stamps a value an acknowledgment already covers."""
    current = _halt_seq(record.get("halt_seq"))
    if current >= HALT_SEQ_MAX:
        record["halt_seq_saturated"] = True
        return HALT_SEQ_MAX
    record["halt_seq"] = current + 1
    return current + 1


def _unmarked(record, seqs, lease):
    """Stop reasons with no halt_seq and not lease-applied (a suspension marks itself): merged before
    a halt (day_start_unknown, account_eligibility_expired) or carried by a legacy record."""
    return [code for code in _reason_codes(record) if code not in seqs and code not in lease
            and code not in SUSPEND_CODES]


def _stamp_unmarked(record):
    """A halted record's unmarked stop reasons take one new halt_seq, so they export and acknowledge
    like any other local halt (a legacy halted record, on its first adopt). No-op when none is."""
    if record.get("state") != "halted":
        return
    seqs, lease = halt_marks(record)
    unmarked = _unmarked(record, seqs, lease)
    if unmarked:
        seq = _take_halt_seq(record)
        seqs.update((code, seq) for code in unmarked)
        _set_halt_marks(record, seqs, lease)


def _history(record, state, now, **extra):
    history = record.setdefault("history", [])
    history.append({"state": state, "at": now.isoformat(), **extra})
    del history[:-HISTORY_LIMIT]


def _expired(record, now):
    """A probe or canary without a readable expiry is expired (fail closed)."""
    expires = (record.get("eligibility") or {}).get("expires_at")
    if expires is None:
        return record.get("state") != "graduated"
    try:
        return now >= _time(datetime.fromisoformat(expires))
    except (TypeError, ValueError):
        return True


def _suspend(record, until_s, code):
    current = record.get("entries_suspended_until")
    record["entries_suspended_until"] = until_s if current is None else max(current, until_s)
    _merge_reasons(record, [code])


def _material(record):
    return _canonical({k: v for k, v in record.items() if k not in ("last_observed_at", "snapshot_digest")})


def _replace_bytes(path, data):
    """Sibling temp, fsync, atomic replace. A failed replace leaves the old document."""
    _safe_stat(path.parent, directory=True)
    _safe_stat(path, missing=True)
    fd, temporary = tempfile.mkstemp(prefix=".canary-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def _replace_json(path, value, limit):
    data = _canonical(value)
    if len(data) > limit:
        raise CanaryError("lifecycle document exceeds limit")
    path.parent.mkdir(parents=True, exist_ok=True)
    _replace_bytes(path, data)


@contextmanager
def _flock(path):
    """OS flock for at most LOCK_TIMEOUT_S. The kernel drops a dead holder's lock, so a
    stale lock file never blocks. Busy raises LifecycleBusy; nothing else waits."""
    from .broker.kalshi_pool import _FileLock

    lock = _FileLock(path, LOCK_TIMEOUT_S)
    try:
        lock.__enter__()
    except TimeoutError as exc:
        raise LifecycleBusy("exposure_ledger_busy: lifecycle lock held") from exc
    except OSError as exc:
        raise CanaryError("lifecycle lock unavailable") from exc
    try:
        yield
    finally:
        lock.__exit__(None, None, None)


class _DocCache:
    """Parsed documents keyed by (inode, mtime, size): re-parse only when the file moved.
    Bounded; callers never mutate a returned document."""

    def __init__(self, limit=256):
        self.limit = limit
        self._docs = {}

    def read(self, path, max_bytes):
        info = _safe_stat(path, missing=True)
        if info is None:
            self._docs.pop(path, None)
            return None
        key = (info.st_ino, info.st_mtime_ns, info.st_size)
        hit = self._docs.get(path)
        if hit is not None and hit[0] == key:
            return hit[1]
        doc = _document(path, max_bytes)[0]
        if len(self._docs) >= self.limit:
            self._docs.clear()
        self._docs[path] = (key, doc)
        return doc


def shadow_gate(evidence, *, started_at, now=None):
    now = _time(now)
    reasons = []
    if not isinstance(evidence, dict):
        return {"eligible": False, "reasons": ["missing_shadow_evidence"]}
    elapsed = (now - _time(datetime.fromisoformat(started_at))).total_seconds()
    if elapsed < 86400:
        reasons.append("shadow_less_than_24_hours")
    decisions = evidence.get("eligible_decisions")
    if type(decisions) is not int or decisions < 50:
        reasons.append("shadow_fewer_than_50_decisions")
    for key in ("risk_invariants_ok", "attribution_complete", "data_integrity_ok"):
        if evidence.get(key) is not True:
            reasons.append(key)
    for key, floor, strict in (("log_growth", 0, True), ("lower_95", 0, False),
                               ("recorder_coverage", .95, False)):
        value = evidence.get(key)
        if not _finite(value) or (value <= floor if strict else value < floor):
            reasons.append(key)
    if _finite(evidence.get("recorder_coverage")) and evidence["recorder_coverage"] > 1:
        reasons.append("invalid_coverage")
    for key in ("drawdown", "window_loss"):
        value, baseline = evidence.get(key), evidence.get("baseline_" + key)
        if (not _finite(value) or not _finite(baseline)
                or min(value, baseline) < 0 or value > baseline):
            reasons.append(key)
    return {"eligible": not reasons, "reasons": reasons}


def probe_fixed_count(value=None) -> Decimal:
    """Normalize the library sizing dial without rounding; zero selects legacy mode."""
    if value is None:
        return Decimal(0)
    if type(value) not in (int, float, Decimal):
        raise CanaryError("invalid fixed_count")
    count = Decimal(str(value))
    if (not count.is_finite() or not 0 <= count <= 1
            or (count != 0 and (count < Decimal("0.01")
                               or count % Decimal("0.01") != 0))):
        raise CanaryError("invalid fixed_count")
    return count


def probe_successor(current, *, fixed_count) -> Decimal | None:
    """The next separately approved fractional rung, bounded by the frozen initial size."""
    initial = probe_fixed_count(fixed_count)
    count = probe_fixed_count(current)
    if initial <= 0 or count < initial:
        raise CanaryError("invalid fractional probe rung")
    return count + Decimal("0.01") if count < 1 else None


def _record_fixed_count(record):
    contracts = record.get("contracts")
    fractional_rung = (type(contracts) is str
                      and re.fullmatch(r"(?:0\.[0-9]{2}|1\.00)", contracts) is not None
                      and contracts != "0.00")
    # Missing policy retains legacy sizing unless a positive-mode rung string proves it was frozen.
    if "policy" not in record:
        if fractional_rung:
            raise CanaryError("missing frozen probe policy")
        return Decimal(0)
    policy = record["policy"]
    if not isinstance(policy, dict):
        raise CanaryError("invalid frozen probe policy")
    value = policy.get("fixed_count")
    if value is not None and type(value) not in (int, float):
        raise CanaryError("invalid frozen fixed_count")
    initial = probe_fixed_count(value)
    # Empty legacy policy documents predate this binding; positive rung strings never bypass it.
    if initial or fractional_rung or ("policy_digest" in record and policy):
        # Unset and zero have the same policy identity. Check this even when the
        # dial is off so deleting a frozen positive dial cannot widen it to one.
        bound_policy = policy if initial else {k: v for k, v in policy.items() if k != "fixed_count"}
        if record.get("policy_digest") != hashlib.sha256(_policy_canonical(bound_policy)).hexdigest():
            raise CanaryError("probe policy digest mismatch")
    return initial


def _record_probe_count(record, initial):
    value = record.get("contracts")
    if type(value) is str:
        if not re.fullmatch(r"(?:0\.[0-9]{2}|1\.00)", value):
            raise CanaryError("invalid recorded probe count")
        value = Decimal(value)
    count = probe_fixed_count(value)
    state = record.get("state")
    if not ((state == "probe" and count == initial)
            or (state == "probe_sized" and initial < count <= 1)):
        raise CanaryError("invalid recorded probe rung")
    return count


def probe_policy_fixed_count(record) -> Decimal:
    """Read the frozen, digest-bound sizing mode for probe accounting consumers."""
    if not isinstance(record, dict):
        raise CanaryError("invalid frozen probe record")
    return _record_fixed_count(record)


def entry_count(record, nominal) -> Decimal:
    """Clamp to the validated fractional rung or legacy probe size; graduated gets nominal.
    Never rounds a sub-contract allocation upward. This is an allocation cap,
    not permission to submit a ticket smaller than the approved current rung."""
    if type(nominal) not in (int, Decimal) or (type(nominal) is Decimal and not nominal.is_finite()):
        raise CanaryError("invalid nominal size")
    value = Decimal(nominal)
    if value <= 0:
        return Decimal(0)
    state = record.get("state")
    try:
        initial = _record_fixed_count(record)
        if initial and state in PROBE_LIFECYCLE_STATES:
            return min(value, _record_probe_count(record, initial))
    except CanaryError:
        return Decimal(0)
    if state == "probe":
        return min(value, Decimal(PROBE_CONTRACTS))
    if state == "probe_sized":
        contracts = record.get("contracts")
        if type(contracts) is not int or contracts not in PROBE_SIZED_CONTRACTS:
            return Decimal(0)
        return min(value, Decimal(contracts))
    if state == "graduated":
        return value
    return Decimal(0)


def probe_book_contracts(record) -> int | Decimal:
    """Pure: the contract multiple of a probe book's order and cluster caps (C13), the lifecycle's
    contracts on a probe_sized record (2 or 5), else 1. A missing, malformed or other-state record
    is 1 for legacy records. Positive-mode records expose the validated current
    rung to OL9; malformed sizing returns zero, never a one-contract fallback.
    This cap does not replace the store's authorization and entry checks."""
    if isinstance(record, dict):
        try:
            initial = _record_fixed_count(record)
            if initial:
                return _record_probe_count(record, initial)
        except CanaryError:
            return Decimal(0)
    if isinstance(record, dict) and record.get("state") == "probe_sized":
        contracts = record.get("contracts")
        if type(contracts) is int and contracts in PROBE_SIZED_CONTRACTS:
            return contracts
    return PROBE_CONTRACTS


def maxima_breaches(policy) -> list[str]:
    """The HARD_MAXIMA fractions a recorded policy document exceeds, or does not state as a
    finite number in 0..maximum (fails closed). The constants apply whatever the risk regime:
    a graduated engine sizes at its nominal count, so its fractions are the only bound left."""
    if not isinstance(policy, dict):
        return sorted(HARD_MAXIMA)
    return [key for key, maximum in HARD_MAXIMA.items()
            if not _finite(policy.get(key)) or not 0 <= policy[key] <= maximum]


# ---------------------------------------------------------------- exposure ledger

LEDGER_SCHEMA = 1
LEDGER_MAX_BYTES = 1024 * 1024
LEDGER_LIVE_LIMIT = 512
LEDGER_ENTRY_LIMIT = 1024
LEDGER_DAYS_KEEP = 8
LIVE_STATES = frozenset({"reserved", "sent", "unknown", "open"})
TERMINAL_STATES = frozenset({"closed", "released", "zero_fill"})
SETTLE_KINDS = frozenset({"settled", "voided", "exit"})
_CLIENT_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,79}")


def _client_id(value):
    if not isinstance(value, str) or not _CLIENT_ID.fullmatch(value):
        raise CanaryError("invalid client id")
    return value


def _count(value):
    if type(value) not in (int, Decimal) or (type(value) is Decimal and not value.is_finite()):
        raise CanaryError("invalid filled count")
    value = Decimal(value)
    if not 0 <= value <= 10**6:
        raise CanaryError("invalid filled count")
    return value


@dataclass(frozen=True)
class ExposureSnapshot:
    realized_today_cents: int
    open_worst_case_cents: int
    open_mark_loss_cents: int
    unknown_cents: int
    reserved_cents: int
    consumed_today_cents: int


class ExposureLedger:
    """Durable per-engine pre-trade exposure, one JSON document keyed by client id.

    Reserve the fee-inclusive worst case BEFORE submission; an unknown send never
    expires; a reservation is released only when the send provably never left the
    process; a fill replaces its reservation in one atomic write; settlement is recorded
    whatever the lifecycle state. Open, sent and unknown exposure carries across UTC
    midnight; a day's consumption survives reauthorization because nothing here is
    keyed by approval. Every write is flock + tmp + fsync + replace; a busy lock raises
    LifecycleBusy (refusal code exposure_ledger_busy)."""

    def __init__(self, directory, engine_id):
        self.engine_id = _id(engine_id)
        self.directory = Path(directory)
        self.path = self.directory / (self.engine_id + ".json")
        self.lock_path = self.directory / (self.engine_id + ".lock")
        self._cache = _DocCache(limit=1)

    def _empty(self):
        return {"schema": LEDGER_SCHEMA, "engine_id": self.engine_id, "entries": {}, "days": {}}

    def _valid(self, doc):
        if (not isinstance(doc, dict) or doc.get("schema") != LEDGER_SCHEMA
                or doc.get("engine_id") != self.engine_id
                or not isinstance(doc.get("entries"), dict) or len(doc["entries"]) > LEDGER_ENTRY_LIMIT
                or not isinstance(doc.get("days"), dict)
                or any(not isinstance(entry, dict) or entry.get("state") not in LIVE_STATES | TERMINAL_STATES
                       for entry in doc["entries"].values())):
            raise CanaryError("invalid exposure ledger")
        return doc

    def _read(self):
        doc = self._cache.read(self.path, LEDGER_MAX_BYTES)
        return self._empty() if doc is None else self._valid(doc)

    @contextmanager
    def _transaction(self):
        self.directory.mkdir(parents=True, exist_ok=True)
        _safe_stat(self.directory, directory=True)
        with _flock(self.lock_path):
            doc = copy.deepcopy(self._read())
            before = _canonical(doc)
            yield doc
            if _canonical(doc) != before:
                _replace_json(self.path, doc, LEDGER_MAX_BYTES)

    @staticmethod
    def _day(doc, day):
        return doc["days"].setdefault(day, {"realized_cents": 0, "consumed_cents": 0})

    @staticmethod
    def _entry(doc, client_id):
        entry = doc["entries"].get(client_id)
        if entry is None:
            raise CanaryError("unknown client id")
        return entry

    @staticmethod
    def _prune(doc, day):
        today = date.fromisoformat(day)
        closed_cutoff = (today - timedelta(days=1)).isoformat()
        for cid in [cid for cid, entry in doc["entries"].items()
                    if entry["state"] in TERMINAL_STATES
                    and (entry.get("closed_day") or entry["reserved_day"]) < closed_cutoff]:
            del doc["entries"][cid]
        days_cutoff = (today - timedelta(days=LEDGER_DAYS_KEEP - 1)).isoformat()
        for old in [key for key in doc["days"] if key < days_cutoff]:
            del doc["days"][old]

    def reserve(self, client_id, worst_case_cents, ticker, now_ns):
        cid = _client_id(client_id)
        cents = _cents(worst_case_cents, "worst_case_cents")
        if not isinstance(ticker, str) or not 1 <= len(ticker) <= 128:
            raise CanaryError("invalid ticker")
        day = _ns_day(now_ns)
        with self._transaction() as doc:
            entry = doc["entries"].get(cid)
            if entry is not None:
                if (entry["state"] == "reserved" and entry["ticker"] == ticker
                        and entry["worst_case_cents"] == cents):
                    return
                raise CanaryError("client id already recorded")
            self._prune(doc, day)
            if sum(1 for entry in doc["entries"].values() if entry["state"] in LIVE_STATES) >= LEDGER_LIVE_LIMIT:
                raise CanaryError("exposure ledger full")
            if len(doc["entries"]) >= LEDGER_ENTRY_LIMIT:
                raise CanaryError("exposure ledger full")
            doc["entries"][cid] = {"state": "reserved", "ticker": ticker, "worst_case_cents": cents,
                                   "reserved_day": day, "count": None, "cost_cents": None,
                                   "realized_cents": None, "kind": None, "closed_day": None}
            self._day(doc, day)["consumed_cents"] += cents

    def mark_sent(self, client_id):
        with self._transaction() as doc:
            entry = self._entry(doc, _client_id(client_id))
            if entry["state"] == "reserved":
                entry["state"] = "sent"
            elif entry["state"] in ("released", "zero_fill"):
                raise CanaryError("send recorded after the reservation closed")

    def mark_unknown(self, client_id):
        """An unknown send is exposure until a fill or settlement resolves it; it never expires."""
        with self._transaction() as doc:
            entry = self._entry(doc, _client_id(client_id))
            if entry["state"] in ("reserved", "sent"):
                entry["state"] = "unknown"
            elif entry["state"] == "released":
                raise CanaryError("unknown send recorded after a never-left release")

    def release_never_left(self, client_id):
        """Only for a send that provably never left the process; anything later is refused."""
        with self._transaction() as doc:
            entry = self._entry(doc, _client_id(client_id))
            if entry["state"] == "released":
                return
            if entry["state"] != "reserved":
                raise CanaryError("send may have left; release refused")
            entry.update(state="released", closed_day=entry["reserved_day"])
            day = self._day(doc, entry["reserved_day"])
            day["consumed_cents"] = max(0, day["consumed_cents"] - entry["worst_case_cents"])

    def replace_with_fill(self, client_id, filled_count, cost_cents):
        """Reservation -> open exposure (cumulative count and cost) in one atomic write.
        A zero fill closes the reservation with no open exposure."""
        count = _count(filled_count)
        cost = _cents(cost_cents, "cost_cents")
        with self._transaction() as doc:
            entry = self._entry(doc, _client_id(client_id))
            if entry["state"] not in ("reserved", "sent", "unknown", "open"):
                raise CanaryError("fill recorded after the position closed")
            if count == 0:
                if entry["state"] == "open" or cost:
                    raise CanaryError("zero fill cannot carry cost or follow a fill")
                entry.update(state="zero_fill", count="0", cost_cents=0,
                             closed_day=entry["reserved_day"])
            else:
                entry.update(state="open", count=str(count), cost_cents=cost)

    def settle(self, client_id, realized_cents, kind, *, now_ns=None):
        """Recorded whatever the lifecycle state (suspended and halted included)."""
        cid = _client_id(client_id)
        realized = _cents(realized_cents, "realized_cents", signed=True)
        if kind not in SETTLE_KINDS:
            raise CanaryError("invalid settlement kind")
        day = _ns_day(time.time_ns() if now_ns is None else now_ns)
        with self._transaction() as doc:
            entry = self._entry(doc, cid)
            if entry["state"] == "closed":
                if entry["realized_cents"] == realized and entry["kind"] == kind:
                    return
                raise CanaryError("client id already settled differently")
            if entry["state"] != "open":
                raise CanaryError("settlement before a recorded fill")
            entry.update(state="closed", realized_cents=realized, kind=kind, closed_day=day)
            self._day(doc, day)["realized_cents"] += realized

    def snapshot(self, utc_day, marks=None):
        """marks: optional {client_id: current marked value in cents} for open positions;
        a missing mark adds no mark loss. Lock-free read of the last atomic write."""
        day = _utc_day(utc_day)
        if marks is not None and not isinstance(marks, dict):
            raise CanaryError("invalid marks")
        doc = self._read()
        reserved = unknown = open_cost = mark_loss = 0
        for cid, entry in doc["entries"].items():
            state = entry["state"]
            if state in ("reserved", "sent"):
                reserved += entry["worst_case_cents"]
            elif state == "unknown":
                unknown += entry["worst_case_cents"]
            elif state == "open":
                open_cost += entry["cost_cents"]
                if marks is not None and cid in marks:
                    mark = _cents(marks[cid], "mark")
                    mark_loss += max(0, entry["cost_cents"] - mark)
        totals = doc["days"].get(day) or {}
        return ExposureSnapshot(realized_today_cents=totals.get("realized_cents", 0),
                                open_worst_case_cents=open_cost, open_mark_loss_cents=mark_loss,
                                unknown_cents=unknown, reserved_cents=reserved,
                                consumed_today_cents=totals.get("consumed_cents", 0))


# ---------------------------------------------------------------- day start (C-DS)

def _window_offset_s(moment, day):
    """Seconds from `day`'s 00:00Z to `moment` (negative before it)."""
    start = datetime.combine(date.fromisoformat(day), datetime.min.time(), timezone.utc)
    return (moment - start).total_seconds()


def _day_start_record(account, day, value, captured_at, source, reason=None):
    return {"schema": DAY_START_SCHEMA, "account_id": account, "utc_day": day,
            "day_start_portfolio_cents": value, "captured_at": captured_at.isoformat(),
            "source": source, "reason": reason}


def _valid_day_start(doc, account, day):
    """A captured value (int, reason None) or a missed day (None, reason window_missed)."""
    if (not isinstance(doc, dict) or doc.get("schema") != DAY_START_SCHEMA
            or doc.get("account_id") != account or doc.get("utc_day") != day
            or not isinstance(doc.get("captured_at"), str) or not isinstance(doc.get("source"), str)):
        return False
    value = doc.get("day_start_portfolio_cents")
    if value is None:
        return doc.get("reason") == DAY_START_MISSED
    return type(value) is int and 0 <= value <= MAX_CENTS and doc.get("reason") is None


def day_start_decision(account, day, portfolio_cents, observed_at, now, source):
    """The first record for `day`, or None to keep waiting. Pure; fails closed.

    A well-formed portfolio value OBSERVED inside [00:00Z, 00:15Z] of `day` is captured. Once
    `now` is past the window with nothing captured, the day is recorded missed: null with
    reason window_missed, which fails closed for probes all day. Anything else waits, so a
    value observed before 00:00Z (a stale read) or a malformed one never becomes the day start."""
    if (type(portfolio_cents) is int and 0 <= portfolio_cents <= MAX_CENTS
            and isinstance(observed_at, datetime) and observed_at <= now
            and 0 <= _window_offset_s(observed_at, day) <= DAY_START_WINDOW_S):
        return _day_start_record(account, day, portfolio_cents, observed_at, source)
    if _window_offset_s(now, day) > DAY_START_WINDOW_S:
        return _day_start_record(account, day, None, now, source, DAY_START_MISSED)
    return None


def day_start_refusal(account, now, source, reason):
    """A null capture record that is never written: the day's value is unknown for `reason`
    (account_mismatch from the cli keying check). It carries its own utc_day and captured_at."""
    now = _time(now)
    return _day_start_record(account, now.date().isoformat(), None, now, source, reason)


def _supplied_day_start(account, day, supplied, now):
    """(record to file, None) or (None, reason) for a C-DS capture record handed to observe. Pure.

    The record carries its own utc_day and captured_at from the capture's clock read, so one made
    before 00:00Z and consumed after it is filed under ITS day, never today's: a utc_day or
    captured_at on another day is day_mismatch. A null record keeps its own reason, another
    account is account_mismatch, and anything malformed is day_start_unknown. Only a well-formed
    value captured inside `day`'s window is ever returned to file."""
    if supplied.get("utc_day") != day:
        return None, DAY_START_DAY_MISMATCH
    value = supplied.get("day_start_portfolio_cents")
    if value is None:
        reason = supplied.get("reason")
        return None, (reason if reason in (DAY_START_MISSED, DAY_START_DAY_MISMATCH, DAY_START_ACCOUNT_MISMATCH,
                                           DAY_START_REGISTRY_INVALID)
                      else DAY_START_UNKNOWN)
    if supplied.get("account_id") != account:
        return None, DAY_START_ACCOUNT_MISMATCH
    source = supplied.get("source")
    try:
        captured = _time(datetime.fromisoformat(supplied.get("captured_at")))
    except (TypeError, ValueError, CanaryError):
        return None, DAY_START_UNKNOWN
    if captured.date().isoformat() != day:
        return None, DAY_START_DAY_MISMATCH
    if not isinstance(source, str) or not 1 <= len(source) <= 200 or supplied.get("reason") is not None:
        return None, DAY_START_UNKNOWN
    record = day_start_decision(account, day, value, captured, now, source)
    if record is None or record["day_start_portfolio_cents"] is None:
        return None, DAY_START_MISSED if record is not None else DAY_START_UNKNOWN
    return record, None


def day_start_portfolio_cents(cash_cents, positions):
    """Cash plus the venue mark of open positions (each row's `market_exposure`, in cents).
    None on any malformed input, so the capture waits instead of recording a wrong value."""
    if type(cash_cents) is not int or not 0 <= cash_cents <= MAX_CENTS:
        return None
    if not isinstance(positions, (list, tuple)) or len(positions) > 10_000:
        return None
    total = cash_cents
    for row in positions:
        exposure = row.get("market_exposure") if isinstance(row, dict) else None
        if type(exposure) is not int or not 0 <= exposure <= MAX_CENTS:
            return None
        total += exposure
        if total > MAX_CENTS:
            return None
    return total


# ---------------------------------------------------------------- lifecycle store

INDEX_SCHEMA = 1
INDEX_ENGINE_LIMIT = 256


def _valid_index(doc):
    try:
        if (not isinstance(doc, dict) or doc.get("schema") != INDEX_SCHEMA
                or not isinstance(doc.get("engines"), dict) or len(doc["engines"]) > INDEX_ENGINE_LIMIT
                or not isinstance(doc.get("accounts"), dict)):
            return False
        _utc_day(doc.get("utc_day"))
        for value in doc["engines"].values():
            if (not isinstance(value, dict) or not isinstance(value.get("account_id"), str)
                    or type(value.get("realized_cents")) is not int
                    or type(value.get("open_mark_loss_cents")) is not int
                    or value["open_mark_loss_cents"] < 0):
                return False
        for value in doc["accounts"].values():
            if (not isinstance(value, dict) or type(value.get("suspended_until")) is not int
                    or not isinstance(value.get("reason"), str)):
                return False
    except CanaryError:
        return False
    return True


def _probe_skeleton(engine, now):
    """A direct-probe record before its first entry (CanaryStore.probe, CanaryStore.adopt)."""
    stamp = now.isoformat()
    evidence = {"source": "probe_direct"}
    return {"schema_version": 1, "engine_id": engine.engine_id,
            "policy_digest": policy_digest(engine.policy), "policy": policy_document(engine.policy),
            "registered_at": stamp, "shadow_started_at": None,
            "historical_evidence": evidence,
            "historical_evidence_digest": evidence_digest(evidence),
            "shadow_evidence_digest": None,
            "settlement_enabled": True, "broad_live": "manual_only",
            "history": [], "observations": {}, "pnl_baselines": {},
            "utc_day": None, "shadow_decisions": [],
            "shadow_first_decision_at": None, "shadow_eligible_decisions": 0}


def _enter_probe(record, aid, authorization_ref, approval, expires_at, contracts, initial, now):
    """Move `record` into probe under a new authorization, in memory. A breaker suspension
    outlives reauthorization until its 00:00Z."""
    stamp = now.isoformat()
    until = record.get("entries_suspended_until")
    suspended = until is not None and _epoch_s(now) < until
    kept = [code for code in _reason_codes(record) if code in SUSPEND_CODES] if suspended else []
    for key in ("outbox_ref", "halt_seqs", "lease_halts"):  # entered: no halt left to mark or re-export
        record.pop(key, None)
    eligibility = {"account_id": aid, "expires_at": expires_at,
                   "authorization_ref": authorization_ref}
    record.update(state="probe", account_id=aid, entries_enabled=True, size_fraction=0,
                  contracts=contracts, approval_id=approval, expires_at=expires_at,
                  entries_suspended_until=until if suspended else None,
                  canary_started_at=stamp, probe_started_at=stamp,
                  stop_reasons=[_reason(code) for code in sorted(kept)],
                  eligibility=eligibility, eligibility_digest=evidence_digest(eligibility))
    record.setdefault("breaker_trips", [])
    _history(record, "probe", now, **({"contracts": contracts} if initial else {}))


def due_trip_days(days, today):
    """Midnight skew: the trip days up to `today` (a date). A day one UTC day ahead is SKIPPED, never
    rewritten: the source is re-read every tick, so it counts once, on its own day. CanaryError on
    anything further ahead. Returns the set of UTC day strings."""
    today_text = today.isoformat()
    tomorrow = (today + timedelta(days=1)).isoformat()
    due = set()
    for day in days:
        if day > tomorrow:
            raise CanaryError("breaker trip in the future")
        if day <= today_text:
            due.add(day)
    return due


def _trip_days(days, now):
    """Validated breaker trip days inside the kill window, sorted; CanaryError on a malformed day or
    one more than a UTC day ahead (a day ahead is skipped until it is today, due_trip_days). Older
    days are dropped (they no longer count toward the kill criterion)."""
    if isinstance(days, (str, bytes)) or len(days) > KILL_WINDOW_DAYS * 2:
        raise CanaryError("invalid breaker trips")
    floor = (now.date() - timedelta(days=KILL_WINDOW_DAYS - 1)).isoformat()
    valid = due_trip_days({_utc_day(day) for day in days}, now.date())
    return sorted(day for day in valid if day >= floor)


def _merge_trips(record, days, now, *, evaluate=True, origin=None):
    """Union trip days into the record. Writes the list only when a day is new, so a repeat is a
    no-op. With `evaluate`, a new day re-evaluates the kill criterion exactly as CanaryStore._trip
    does: KILL_TRIPS days in the window halt kill_criterion, as a halt of `origin` (LEASE_ORIGIN when
    the lease's own days reach it: the root's kill, lifted by the next re-grant without an
    acknowledgment). A re-grant (adopt with a new authorization_ref) passes evaluate=False: the root
    re-granted with that trip history on the card."""
    floor = (now.date() - timedelta(days=KILL_WINDOW_DAYS - 1)).isoformat()
    current = {trip for trip in record.get("breaker_trips") or () if isinstance(trip, str) and trip >= floor}
    new = set(days) - current
    if new:
        record["breaker_trips"] = sorted(current | new)[-KILL_WINDOW_DAYS:]
        if evaluate and len(record["breaker_trips"]) >= KILL_TRIPS:
            CanaryStore._halt(record, ["kill_criterion"], now, origin=origin)


_RUNG_PROBE_NOMINAL = 1000  # above every lease rung (lifecycle_lease caps contracts at 1000)


def _apply_lease_rung(record, entry, now):
    """Same-grant resize: a probe record takes the lease entry's state and contracts (up or down)
    when that rung fits the record's frozen policy, i.e. the record would then size at exactly the
    lease's contracts; otherwise nothing changes (the lease's own cap still bounds entry_count)."""
    state, contracts = entry.get("state"), entry.get("contracts")
    if (record.get("state"), record.get("contracts")) == (state, contracts) or contracts is None:
        return
    candidate = {**record, "state": state, "contracts": contracts}
    try:
        fits = entry_count(candidate, _RUNG_PROBE_NOMINAL) == Decimal(str(contracts))
    except (CanaryError, ArithmeticError, ValueError):
        fits = False
    if not fits:
        return
    approval = entry.get("approval_id")
    record.update(state=state, contracts=contracts)
    if isinstance(approval, str) and approval:
        record["approval_id"] = approval
    _history(record, state, now, contracts=contracts)


# A new grant in one of these states is not a probe entry, so a probe-rung record rebinds to it in
# place (_rebind_grant) instead of re-entering.
REBIND_GRANT_STATES = frozenset({"shadow", "canary", "graduated"})


def _rebind_grant(record, entry, now):
    """New grant, no re-entry: a probe-rung record whose lease entry carries a NEW authorization_ref in
    a non-probe, non-terminal state (REBIND_GRANT_STATES) moves its eligibility (ref, approval,
    account, expiry) and state to the lease's and keeps its rung, stop reasons, halt marks,
    halt_seq, harvested acknowledgments and suspension. A halted record is not rebound.
    The rung is never raised here; the lease's contracts cap still bounds every entry
    (lifecycle_lease.leased_view, LeasedLifecycle.entry_count). Unchanged when the grant is
    unreadable, already expired or for another frozen policy. Returns whether the record changed."""
    try:
        ref = _bounded_ref(entry.get("authorization_ref"), "probe authorization reference")
        approval = entry.get("approval_id")
        approval = ref if approval is None else _bounded_ref(approval, "approval id")
        aid = account_id(entry.get("account_id"))
        expires_at = entry.get("expires_at")
        expires = _time(datetime.fromisoformat(expires_at))
    except (CanaryError, ValueError, TypeError):
        return False
    if now >= expires or record.get("policy_digest") != entry.get("policy_digest"):
        return False
    eligibility = {"account_id": aid, "expires_at": expires_at, "authorization_ref": ref}
    record.update(state=entry["state"], account_id=aid, approval_id=approval, expires_at=expires_at,
                  eligibility=eligibility, eligibility_digest=evidence_digest(eligibility))
    _history(record, record["state"], now, rebound=ref)
    return True


def harvest_code(code):
    """The code a tenant outbox exports a local halt reason as: itself when whitelisted, else
    OPERATOR_HALT (lifecycle_lease.restriction_facts)."""
    return code if code in HARVEST_HALT_CODES else OPERATOR_HALT


def _unacknowledged_halts(record, acknowledged):
    """The record's non-suspension stop reasons a re-grant may not lift. Acknowledgment is by
    counter, never by time: a reason raised locally at halt_seq N is acknowledged only when
    `acknowledged` (the root's harvested {code: highest halt_seq applied}) holds N or more for its
    code or the code it is harvested as. A reason a lease applied (lease_halts) was raised by
    the root and needs no acknowledgment. Fails closed: a reason without a halt_seq, or any local
    reason of a record whose halt_seq counter saturated, is unacknowledged."""
    acknowledged = acknowledged if isinstance(acknowledged, dict) else {}
    saturated = record.get("halt_seq_saturated") is True
    seqs, lease = halt_marks(record)
    missing = []
    for code in _reason_codes(record):
        if code in SUSPEND_CODES or code in lease:
            continue
        seq = seqs.get(code)
        if saturated or type(seq) is not int or not any(
                type(acknowledged.get(key)) is int and seq <= acknowledged[key] for key in (code, harvest_code(code))):
            missing.append(code)
    return missing


def _record_revision(record):
    """The store revision a record was written at, or None (a record written before revisions)."""
    value = record.get("store_revision") if isinstance(record, dict) else None
    return value if type(value) is int and 0 <= value <= HALT_SEQ_MAX else None


def _seed_halt_seq(record, acknowledged):
    """Raise the record's halt_seq to at least the highest acknowledged one, so a re-created book
    record never raises a new halt at a halt_seq an older acknowledgment already covers."""
    top = max(acknowledged.values(), default=0)
    if top > _halt_seq(record.get("halt_seq")):
        record["halt_seq"] = top


def _harvested(value):
    """A valid {halt code: halt_seq} map (harvested_halts, acknowledged_halts), or None."""
    if (not isinstance(value, dict) or len(value) > ACK_LIMIT
            or any(not isinstance(code, str) or not 1 <= len(code) <= 200
                   or type(seq) is not int or not 0 <= seq <= HALT_SEQ_MAX for code, seq in value.items())):
        return None
    return value


ADOPT_TRIPS_REFUSED = "lease_trips_refused"


@dataclass(frozen=True)
class AdoptRefusal:
    """CanaryStore.adopt refused a lease entry without writing anything (never a dict, so
    LeasedLifecycle exports nothing for it). The book retries on its next tick."""
    code: str
    detail: str = ""


class CanaryStore:
    def __init__(self, directory, *, capacity=DEFAULT_CAPACITY):
        if type(capacity) is not int or capacity not in SUPPORTED_CAPACITIES:
            raise CanaryError("capacity: must be 64, 256, 512 or 1024")
        self.capacity = capacity
        self.directory = Path(directory)
        self._docs = _DocCache()
        self._ledgers = {}
        self._verified = {}  # path -> (stat key, verified snapshot bytes); at most 2 * MAX_RECORDS
        self._index_valid = None  # the breaker index object last validated
        self._revision_recovery = None  # established revision, installed only while holding the flock
        self._revision_seen = 0  # the highest revision this instance wrote (never reissued)

    def path_for(self, engine_id):
        return self.directory / (_id(engine_id) + ".json")

    @property
    def _index_path(self):
        return self.directory / "breaker" / "probe-day.json"

    @staticmethod
    def _day_start_key(account):
        return hashlib.sha256(account.encode()).hexdigest()[:32]

    def _day_start_path(self, account, day):
        """One file per account per UTC day: day-start/<sha256(account)[:32]>-<utc_day>.json."""
        return self.directory / "day-start" / f"{self._day_start_key(account)}-{_utc_day(day)}.json"

    def exposure(self, engine_id):
        """The engine's ExposureLedger under <lifecycle_dir>/exposure/."""
        ledger = self._ledgers.get(engine_id)
        if ledger is None:
            if len(self._ledgers) >= MAX_RECORDS:
                self._ledgers.clear()
            ledger = self._ledgers[engine_id] = ExposureLedger(self.directory / "exposure", engine_id)
        return ledger

    @contextmanager
    def _lock(self, *, recover_revision=True):
        if _safe_stat(self.directory, directory=True, missing=True) is None:
            self.directory.mkdir(parents=True, exist_ok=True)
            _safe_stat(self.directory, directory=True)
        scan_retries = 0
        while True:
            recovery = None
            recovery_token = None
            if recover_revision:
                value, valid = self._revision_file()
                if not valid:
                    try:
                        recovery_token = self._revision_scan_token()
                        records = self.list()
                        top, carried = self._records_revision(records)
                        recovery = top, value is not None or carried or not records
                    except Exception:  # recovery must never prevent an owner halt
                        recovery = 0, False
                        recovery_token = None  # retry a transient list race under the flock
            with _flock(self.directory / ".lock"):
                if recover_revision:
                    value, valid = self._revision_file()
                    if valid:
                        # Trust the cache, including a racing writer's replacement. Permission
                        # ordering prevents a reissued revision from resurrecting an older grant.
                        recovery = value, True
                    elif recovery is None:
                        continue  # cache disappeared while acquiring: scan outside the flock
                    elif recovery_token is None or recovery_token != self._revision_scan_token():
                        if recovery_token is not None and scan_retries < 3:
                            scan_retries += 1
                            continue  # release the flock before retrying a moving scan
                        # The cache is still invalid and unlocked recovery could not stabilize.
                        try:
                            records = self.list()
                            top, carried = self._records_revision(records)
                            recovery = top, value is not None or carried or not records
                        except Exception:  # only failure under the flock may mark unknown
                            recovery = 0, False
                self._revision_recovery = recovery
                try:
                    yield
                finally:
                    self._revision_recovery = None
                return

    def _revision_scan_token(self):
        """Directory, record identities, cache and removal floor fence an unlocked recovery scan."""
        try:
            info = os.stat(self.directory)
        except OSError:
            return None
        try:
            cache = os.stat(self.directory / REVISION_NAME, follow_symlinks=False)
            cache_key = cache.st_ino, cache.st_size
        except FileNotFoundError:
            cache_key = None
        except OSError:
            return None
        # Invalid-cache recovery only: one scandir, O(n) metadata stats, O(n log n) sorting;
        # no record opens. Budget at 512 records (WSL root): <5 ms under the flock.
        # A record replace changes its inode even within one directory timestamp tick.
        records = []
        try:
            with os.scandir(self.directory) as entries:
                for entry in entries:
                    if entry.name.endswith(".json"):
                        record = entry.stat(follow_symlinks=False)
                        records.append((entry.name, record.st_ino, record.st_size, record.st_mtime_ns))
        except OSError:
            return None  # a moving/unreadable entry requires recovery under the flock
        digest = hashlib.sha256(repr(sorted(records)).encode("utf-8")).digest()
        return (info.st_ino, info.st_mtime_ns, cache_key,
                self._revision_file(REMOVAL_FLOOR_NAME), digest)

    def _write(self, record):
        """Callers hold the store lock. The record carries the store revision it is written at
        (store_revision, fsynced with it); store.revision is a cache of the highest, written first
        and without fsync, so a crash between the two leaves a revision with no new content
        (harmless); a record write that fails removes a cache file it created. Never fails because of the revision cache: record writes, halts first, land
        whatever store.revision holds (_next_revision)."""
        record["store_revision"] = revision = self._next_revision()
        record["snapshot_digest"] = evidence_digest(
            {k: v for k, v in record.items() if k != "snapshot_digest"})
        data = _canonical(record)
        if len(data) > MAX_BYTES:
            raise CanaryError("lifecycle snapshot exceeds limit")
        created = self._write_revision_file(revision)
        try:
            _replace_bytes(self.path_for(record["engine_id"]), data)
        except BaseException:
            if created:  # a failed first write leaves no revision cache behind (main's store layout)
                try:
                    os.unlink(self.directory / REVISION_NAME)
                except OSError:
                    pass
            raise
        self._revision_seen = revision

    def _revision_file(self, name=REVISION_NAME):
        """(value, valid) of the store.revision cache: (0, False) when absent,
        (None, False) when unreadable or malformed. Never raises."""
        try:
            fd = os.open(self.directory / name, os.O_RDONLY | _O_NOFOLLOW | _O_BINARY)
        except FileNotFoundError:
            return 0, False
        except OSError:
            return None, False
        try:
            data = os.read(fd, REVISION_MAX_BYTES + 1)
        except OSError:
            return None, False
        finally:
            os.close(fd)
        text = data.strip()
        if len(data) > REVISION_MAX_BYTES or not 1 <= len(text) <= 16 or not text.isdigit():
            return None, False
        return int(text), True

    def _write_revision_file(self, revision):
        """Best effort sibling temp + rename, without fsync. Never expose a truncated valid number.
        Returns whether this call created the cache. Lost/invalid caches normally recover outside
        the flock; an unstable or failed scan is retried under it."""
        path = self.directory / REVISION_NAME
        created = False
        try:
            created = not path.exists()
            fd, temporary = tempfile.mkstemp(prefix=".revision-", dir=self.directory)
            try:
                with os.fdopen(fd, "wb") as stream:
                    stream.write(f"{revision}\n".encode("ascii"))
                os.replace(temporary, path)
            finally:
                Path(temporary).unlink(missing_ok=True)
        except OSError:
            # Do not leave a valid but stale cache for an already-reconciled instance to trust.
            try:
                path.unlink(missing_ok=True)
            except OSError:
                self._mark_revision_unknown()
        return created

    def _records_revision(self, records):
        """(highest store_revision the records carry, whether any carries one)."""
        values = [value for value in map(_record_revision, records) if value is not None]
        return max(values, default=0), bool(values)

    def _revision_established(self, records):
        """The store revision for `records` (read under the lock): max(cache, per-record max,
        removal floor), or None when it cannot be established (the unknown marker is set, or the file is
        unreadable or malformed and no record carries a revision). An absent cache is recovered
        from the records; a pre-revision store has revision zero."""
        if _safe_stat(self.directory / REVISION_UNKNOWN_NAME, missing=True) is not None:
            return None
        value, valid = self._revision_file()
        top, carried = self._records_revision(records)
        floor, floor_valid = self._revision_file(REMOVAL_FLOOR_NAME)
        if floor is None and not floor_valid:
            return None
        if not valid and value is None and not carried and not floor_valid and records:
            return None
        return max(value or 0, top, floor or 0)

    def _next_revision(self):
        """Callers hold the flock. A valid cache is trusted, including on the first write.
        For an invalid cache, _lock scans OUTSIDE the flock and checks its token inside it.
        A moving token gets three unlocked retries before a locked scan; failed scans retry inside.
        Include any racing writer's cache, scan max, durable removal floor and
        _revision_seen. Budget at 512 records (WSL root): first-write flock <10 ms and zero busy
        halts in 300 iterations against fresh-instance writers with valid or invalid caches.
        Failed recovery still lets owner halts land, but marks leases unknown until repair."""
        value, valid = self._revision_file()
        top, recovered = self._revision_recovery or (0, False)
        floor, floor_valid = self._revision_file(REMOVAL_FLOOR_NAME)
        known = (recovered if self._revision_recovery is not None else valid) and (floor_valid or floor == 0)
        value = max(value or 0, top, floor or 0, self._revision_seen)
        if value >= HALT_SEQ_MAX:
            known, value = False, HALT_SEQ_MAX - 1
        if not known:
            self._mark_revision_unknown()
        return value + 1

    def _mark_revision_unknown(self):
        try:
            _replace_bytes(self.directory / REVISION_UNKNOWN_NAME, b"1\n")
        except (CanaryError, TrialError, OSError):
            pass  # the write itself still lands; an unmarked store keeps the older revision floor

    def _store_epoch(self):
        """Callers hold the store lock. The store's epoch, minted (32 hex, fsynced) when absent;
        CanaryError when present and malformed."""
        path = self.directory / EPOCH_NAME
        if _safe_stat(path, missing=True) is None:
            epoch = secrets.token_hex(16)
            _replace_bytes(path, f"{epoch}\n".encode("ascii"))
            return epoch
        with path.open("rb") as stream:
            text = stream.read(64).decode("ascii", "replace").strip()
        if not EPOCH_RE.fullmatch(text):
            raise CanaryError("invalid store epoch")
        return text

    def snapshot(self):
        """(store revision, {engine_id: record}) read in ONE pass under the store lock, so the
        revision names exactly this content (lifecycle_lease.build_lease orders leases by it). The
        revision is max(store.revision, per-record max, removal floor); None when it is unknown."""
        with self._lock(recover_revision=False):
            records = {record["engine_id"]: record for record in self.list()}
            return self._revision_established(list(records.values())), records

    def _lease_snapshot(self):
        """Seqlock snapshot: read (epoch, revision) R1 under the flock, release it, read records,
        then read R2 under the flock. Accept only R1 == R2 and no record revision above R1.
        Writers bump the revision under the flock and replace records atomically, so this proves
        a consistent read without holding up halts for a records scan. A lost cache is recovered
        from a stable scan and retried; an unknown revision returns None. After three attempts,
        raise LifecycleBusy for this snapshot only: the publisher skips this tick."""
        for _attempt in range(3):
            with self._lock(recover_revision=False):
                before = self._lease_revision()
            try:
                records = {record["engine_id"]: record for record in self.list()}
            except (OSError, TrialError):
                # A concurrent removal can invalidate list()'s directory scan.
                with self._lock(recover_revision=False):
                    if self._lease_revision() != before:
                        continue
                raise
            top, carried = self._records_revision(records.values())
            with self._lock(recover_revision=False):
                if self._lease_revision() != before:
                    continue
                epoch, (revision, valid), unknown = before
                if unknown or (revision is None and not carried and records):
                    return epoch, None, records
                if top <= (revision or 0) and (valid or revision == 0):
                    return epoch, revision, records
                # Recovery uses the unlocked scan only after its revision check succeeds.
                self._write_revision_file(max(revision or 0, top))
        raise LifecycleBusy("lifecycle snapshot changed during three reads")

    def _lease_revision(self):
        """Callers hold the flock; never reads record files."""
        value, valid = self._revision_file()
        floor, floor_valid = self._revision_file(REMOVAL_FLOOR_NAME)
        if floor_valid:
            value = max(value or 0, floor)
        return (self._store_epoch(), (value, valid or floor_valid),
                (floor is None and not floor_valid)
                or _safe_stat(self.directory / REVISION_UNKNOWN_NAME, missing=True) is not None)

    def repair_store_revision(self):
        """Operator repair: re-establish the revision from the records (they must all read), mint a
        NEW store epoch (so every lane's lease ordering resets lawfully) and clear the unknown marker.
        Returns (epoch, revision)."""
        with self._lock(recover_revision=False):
            records = self.list()
            value, valid = self._revision_file()
            top, _carried = self._records_revision(records)
            floor, floor_valid = self._revision_file(REMOVAL_FLOOR_NAME)
            if floor is None and not floor_valid:
                raise CanaryError("invalid removal revision floor")
            revision = max(value if valid else 0, top, floor or 0, self._revision_seen)
            epoch = secrets.token_hex(16)
            _replace_bytes(self.directory / EPOCH_NAME, f"{epoch}\n".encode("ascii"))
            _replace_bytes(self.directory / REVISION_NAME, f"{revision}\n".encode("ascii"))
            (self.directory / REVISION_UNKNOWN_NAME).unlink(missing_ok=True)
            self._revision_seen = revision
            return epoch, revision

    def get(self, engine_id):
        """A fresh, verified record. Bytes verified once are re-parsed from memory until the
        file's (inode, mtime, size) moves; every write is an atomic replace, so a new inode."""
        path = self.path_for(engine_id)
        info = _safe_stat(path)
        key = (info.st_ino, info.st_mtime_ns, info.st_size)
        hit = self._verified.get(path)
        if hit is not None and hit[0] == key:
            return json.loads(hit[1])
        record, data = _document(path, MAX_BYTES)
        self._validate_record(record, engine_id)
        if len(self._verified) >= MAX_RECORDS * 2:
            self._verified.clear()
        self._verified[path] = (key, data)
        return record

    @staticmethod
    def _validate_record(record, engine_id):
        if (not isinstance(record, dict) or record.get("schema_version") != 1 or record.get("engine_id") != engine_id
                or record.get("state") not in STATES
                or record.get("snapshot_digest") != evidence_digest(
                    {k: v for k, v in record.items() if k != "snapshot_digest"})
                or record.get("historical_evidence_digest") != evidence_digest(record.get("historical_evidence"))):
            raise CanaryError("invalid lifecycle snapshot")
        initial = _record_fixed_count(record)
        if initial and record["state"] in PROBE_LIFECYCLE_STATES:
            _record_probe_count(record, initial)

    def restore_record(self, engine_id, data, *, expected_digest):
        """Restore validated record bytes, or remove a record for None, under the bounded flock.
        Compare SHA256 of the CURRENT raw bytes (None for absence) with expected_digest under the
        flock; mismatch raises restore_conflict and writes nothing. Both operations advance the
        revision; a removal first persists its fsynced floor. Even a matching CAS cannot undo a
        halt or retirement (restore_unhalt). Returns the restored record or None."""
        path = self.path_for(engine_id)
        with self._lock():
            current_digest = None
            current_bytes = None
            if _safe_stat(path, missing=True) is not None:
                with path.open("rb") as stream:
                    current_bytes = stream.read(MAX_BYTES + 1)
                if len(current_bytes) > MAX_BYTES:
                    raise CanaryError("lifecycle snapshot exceeds limit")
                current_digest = hashlib.sha256(current_bytes).hexdigest()
            if current_digest != expected_digest:
                error = CanaryError("restore_conflict: lifecycle record changed")
                error.code = "restore_conflict"
                raise error
            record = None
            if data is not None:
                if not isinstance(data, bytes):
                    raise CanaryError("restore requires record bytes or None")
                record = _loads(data, MAX_BYTES)
                self._validate_record(record, engine_id)
            if current_bytes is not None:
                current = _loads(current_bytes, MAX_BYTES)
                self._validate_record(current, engine_id)
                if current["state"] in ("halted", "retired") and (
                        record is None or record["state"] != current["state"]):
                    error = CanaryError("restore_unhalt: cannot undo a halt or retirement")
                    error.code = "restore_unhalt"
                    raise error
            if record is not None:
                self._write(record)
            else:
                revision = self._next_revision()
                floor, floor_valid = self._revision_file(REMOVAL_FLOOR_NAME)
                if floor is None and not floor_valid:
                    raise CanaryError("invalid removal revision floor")
                _replace_bytes(self.directory / REMOVAL_FLOOR_NAME, f"{max(floor or 0, revision)}\n".encode("ascii"))
                if os.name == "posix":
                    fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY)
                    try:
                        os.fsync(fd)
                    finally:
                        os.close(fd)
                self._write_revision_file(revision)
                path.unlink(missing_ok=True)
                if os.name == "posix":
                    fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY)
                    try:
                        os.fsync(fd)
                    finally:
                        os.close(fd)
                self._revision_seen = revision
            self._verified.pop(path, None)
            return record

    def optional(self, engine_id):
        path = self.path_for(engine_id)
        if _safe_stat(path, missing=True) is None:
            return None
        return self.get(engine_id)

    def list(self):
        if not self.directory.exists():
            return []
        paths = list(self.directory.glob("*.json"))
        if len(paths) > self.capacity:
            raise CanaryError("too many lifecycle candidates")
        return [self.get(path.stem) for path in sorted(paths)]

    def register(self, engine, evidence, *, now=None):
        """Register and activate only shadow in the same durable snapshot."""
        gate = research_promotion_gate(evidence)
        if not gate["eligible"]:
            raise CanaryError("historical qualification failed: " + ", ".join(gate["reasons"]))
        if evidence.get("policy_digest") != policy_digest(engine.policy):
            raise CanaryError("historical evidence does not bind the engine policy")
        stamp = _time(now).isoformat()
        record = {"schema_version": 1, "engine_id": engine.engine_id,
                  "policy_digest": policy_digest(engine.policy), "policy": policy_document(engine.policy),
                  "state": "shadow", "registered_at": stamp, "shadow_started_at": stamp,
                  "historical_evidence": evidence,
                  "historical_evidence_digest": evidence_digest(evidence),
                  "shadow_evidence_digest": None, "account_id": None,
                  "size_fraction": 0, "entries_enabled": False,
                  "settlement_enabled": True, "broad_live": "manual_only",
                  "stop_reasons": [], "history": [{"state": "shadow", "at": stamp}],
                  "observations": {}, "pnl_baselines": {}, "utc_day": None, "shadow_decisions": [],
                  "shadow_first_decision_at": None, "shadow_eligible_decisions": 0}
        with self._lock():
            if self.optional(engine.engine_id) is not None:
                raise CanaryError("candidate already registered")
            if len(self.list()) >= self.capacity:
                raise CanaryError("too many lifecycle candidates")
            self._write(record)
        return record

    def probe(self, engine, *, account, authorization_ref, expires_at,
              other_account_engine_ids, now=None, approval_id=None):
        """Authorize a policy-sized live probe without shadow qualification. The loss
        breaker (D5a) applies from the first entry; there is no dollar budget."""
        now = _time(now)
        initial = probe_fixed_count(engine.policy.fixed_count)
        contracts = format(initial, ".2f") if initial else PROBE_CONTRACTS
        if engine.engine_id in other_account_engine_ids:
            raise CanaryError("engine is bound on another account")
        _bounded_ref(authorization_ref, "probe authorization reference")
        approval = authorization_ref if approval_id is None else _bounded_ref(approval_id, "approval id")
        try:
            aid = account_id(account)
        except ValueError as exc:
            raise CanaryError("invalid probe account_id") from exc
        try:
            expires = _time(datetime.fromisoformat(expires_at))
        except (ValueError, TypeError) as exc:
            raise CanaryError("future timezone-aware probe expiry required") from exc
        if now >= expires:
            raise CanaryError("probe authorization expired")
        with self._lock():
            record = self.optional(engine.engine_id)
            if record is None:
                if len(self.list()) >= self.capacity:
                    raise CanaryError("too many lifecycle candidates")
                record = _probe_skeleton(engine, now)
            else:
                if record["state"] not in ("shadow", "halted"):
                    raise CanaryError("only shadow or halted may enter probe")
                if (record["state"] == "halted"
                        and (authorization_ref == record.get("eligibility", {}).get("authorization_ref")
                             or approval == record.get("approval_id"))):
                    raise CanaryError("halted probe requires a new authorization reference")
                if record["policy_digest"] != policy_digest(engine.policy):
                    raise CanaryError("probe engine policy changed")
            _enter_probe(record, aid, authorization_ref, approval, expires_at, contracts, initial, now)
            self._write(record)
            return record

    def probe_size(self, engine_id, *, contracts, approval_id, now=None):
        """One rung per approval: legacy 1/2/5 or policy-sized increments of 0.01."""
        now = _time(now)
        approval = _bounded_ref(approval_id, "approval id")
        with self._lock():
            record = self.get(engine_id)
            if record["state"] not in ("probe", "probe_sized"):
                raise CanaryError("only a probe may be sized")
            initial = _record_fixed_count(record)
            if initial:
                current = _record_probe_count(record, initial)
                requested = probe_fixed_count(contracts)
                if requested != probe_successor(current, fixed_count=initial):
                    raise CanaryError("the size ladder moves up exactly one rung per approval")
                contracts = format(requested, ".2f")
            else:
                current = record.get("contracts", PROBE_CONTRACTS)
                if type(contracts) is not int or contracts != _NEXT_RUNG.get(current):
                    raise CanaryError("the size ladder moves up exactly one rung per approval")
            if approval == record.get("approval_id"):
                raise CanaryError("a size rung requires a new approval")
            if _expired(record, now):
                raise CanaryError("probe authorization expired")
            record.update(state="probe_sized", contracts=contracts, approval_id=approval)
            _history(record, "probe_sized", now, contracts=contracts)
            self._write(record)
            return record

    def graduate(self, engine_id, *, approval_id, now=None):
        """probe or probe_sized -> graduated on its own approval. Entries then size at the nominal
        count, bounded by the policy's HARD_MAXIMA fractions (refused here when the recorded policy
        exceeds one). The probe expiry stops applying; the D5a breaker, its suspensions and its
        trip history carry over unchanged."""
        now = _time(now)
        approval = _bounded_ref(approval_id, "approval id")
        with self._lock():
            record = self.get(engine_id)
            if record["state"] not in GRADUATE_FROM:
                raise CanaryError("only a probe may graduate")
            if approval == record.get("approval_id"):
                raise CanaryError("graduation requires a new approval")
            breaches = maxima_breaches(record.get("policy"))
            if breaches:
                raise CanaryError("graduated sizing exceeds HARD_MAXIMA: " + ", ".join(breaches))
            eligibility = {"account_id": record["account_id"], "expires_at": None,
                           "authorization_ref": approval}
            record.update(state="graduated", contracts=None, approval_id=approval, expires_at=None,
                          graduated_at=now.isoformat(), entries_enabled=True, size_fraction=0,
                          eligibility=eligibility, eligibility_digest=evidence_digest(eligibility))
            _drop_reasons(record, ("account_eligibility_expired",))
            _history(record, "graduated", now)
            self._write(record)
            return record

    def retire(self, engine_id, reason, *, now=None):
        """Terminal: entries off for good, settlement continues, and no transition leaves retired
        (probe, probe_size, graduate and advance all refuse it). A rerun writes nothing new."""
        if not isinstance(reason, str) or not reason or len(reason) > 200:
            raise CanaryError("bounded retire reason required")
        now = _time(now)
        with self._lock():
            record = self.get(engine_id)
            before = _canonical(record)
            if record["state"] != "retired":
                record.update(retired_from=record["state"], retired_at=now.isoformat())
                _history(record, "retired", now)
            record.update(state="retired", entries_enabled=False, size_fraction=0,
                          settlement_enabled=True, entries_suspended_until=None)
            _merge_reasons(record, [reason])
            if _canonical(record) != before:
                self._write(record)
            return record

    def record_opening_balance(self, engine_id, *, trial_id, balance_cents, observed_at, updated_ts=None,
                               now=None, replace=False):
        """C13 fix f, fix g: persist `trial_id`'s opening balance, the balance read the judge takes when
        it activates the trial (engine_ops._judge_one; qualification only reads it), with its venue
        timestamps, WRITE-ONCE: a record already carrying an opening for this trial is returned
        unchanged and never recomputed; another trial's opening is replaced (a new trial starts from
        its own activation read). Returns the stored opening (opening_balance).

        C13 fix i: the opening is captured BEFORE the activation is written (engine_ops
        _capture_opening_then_activate), so no activation exists without one. `replace=True` is that
        pre-activation capture: a retry after a crash between the two steps replaces the stale
        capture of the earlier attempt with its own fresh read (the caller asserts the trial is not
        activated). Every other caller keeps write-once."""
        now = _time(now)
        trial = _bounded_ref(trial_id, "trial id")
        cents = _cents(balance_cents, "opening balance")
        observed = _aware_text(observed_at, "opening observed_at")
        if updated_ts is not None and (type(updated_ts) is not int or not 0 <= updated_ts <= 2**40):
            raise CanaryError("invalid opening updated_ts")
        with self._lock():
            record = self.get(engine_id)
            current = opening_balance(record, trial)
            if current is not None and not replace:
                return current
            record["opening_balance"] = {"trial_id": trial, "balance_cents": cents, "observed_at": observed,
                                         "updated_ts": updated_ts, "recorded_at": now.isoformat(),
                                         "transfers": []}
            self._write(record)
            return copy.deepcopy(record["opening_balance"])

    def record_transfer(self, engine_id, *, trial_id, kind, amount_cents, at):
        """C13 fix f: one deposit or withdrawal on the probe account during `trial_id`'s qualification,
        appended to that trial's opening (at most OPENING_TRANSFER_LIMIT). Refused without an opening
        for the trial, so a movement is never attributed to a qualification that has none."""
        trial = _bounded_ref(trial_id, "trial id")
        if kind not in TRANSFER_KINDS:
            raise CanaryError("transfer kind is deposit or withdrawal")
        cents = _cents(amount_cents, "transfer amount")
        if cents == 0:
            raise CanaryError("invalid transfer amount")
        stamp = _aware_text(at, "transfer time")
        with self._lock():
            record = self.get(engine_id)
            current = opening_balance(record, trial)
            if current is None:
                raise CanaryError("no opening balance recorded for this trial")
            if len(current["transfers"]) >= OPENING_TRANSFER_LIMIT:
                raise CanaryError("too many transfers for one qualification")
            current["transfers"].append({"kind": kind, "amount_cents": cents, "at": stamp})
            record["opening_balance"] = current
            self._write(record)
            return copy.deepcopy(current)

    def record_shadow_decision(self, engine_id, opportunity_id, *, now=None):
        """Count each eligible market once; replaying events cannot speed promotion."""
        if not isinstance(opportunity_id, str) or not 1 <= len(opportunity_id) <= 200:
            raise CanaryError("bounded shadow opportunity id required")
        now = _time(now)
        with self._lock():
            record = self.get(engine_id)
            if record["state"] != "shadow":
                return record
            if now < _time(datetime.fromisoformat(record["shadow_started_at"])):
                raise CanaryError("shadow clock regressed")
            key = evidence_digest(opportunity_id)
            if key in record["shadow_decisions"]:
                return record
            # The promotion minimum is 50; cap retained identifiers at 1000.
            if len(record["shadow_decisions"]) >= 1000:
                return record
            record["shadow_decisions"].append(key)
            record["shadow_eligible_decisions"] = len(record["shadow_decisions"])
            if record["shadow_first_decision_at"] is None:
                record["shadow_first_decision_at"] = now.isoformat()
            self._write(record)
            return record

    def advance(self, engine_id, evidence, eligibility, *, now=None):
        """Account eligibility is a separate operator-owned input, never research evidence."""
        now = _time(now)
        with self._lock():
            record = self.get(engine_id)
            if record["state"] != "shadow":
                raise CanaryError("only shadow may advance; broad live is manual")
            if not isinstance(evidence, dict):
                raise CanaryError("shadow evidence required")
            failures = [key for key in ("risk_invariants_ok", "attribution_complete", "data_integrity_ok")
                        if evidence.get(key) is not True]
            if failures:
                self._halt(record, failures, now)
                self._write(record)
                raise CanaryError("shadow safety stop: " + ", ".join(failures))
            if (evidence.get("policy_digest") != record["policy_digest"]
                    or evidence.get("shadow_started_at") != record["shadow_started_at"]):
                raise CanaryError("shadow evidence binding mismatch")
            gate = shadow_gate(evidence, started_at=record["shadow_started_at"], now=now)
            first = record["shadow_first_decision_at"]
            if (first is None or (now - _time(datetime.fromisoformat(first))).total_seconds() < 86400
                    or record["shadow_eligible_decisions"] < 50):
                gate["eligible"] = False
                gate["reasons"].append("insufficient_recorded_shadow_exposure")
            if not gate["eligible"]:
                raise CanaryError("shadow qualification failed: " + ", ".join(gate["reasons"]))
            if (not isinstance(eligibility, dict) or eligibility.get("canary_eligible") is not True
                    or eligibility.get("engine_id") != engine_id
                    or eligibility.get("policy_digest") != record["policy_digest"]
                    or not isinstance(eligibility.get("authorization_ref"), str)
                    or not eligibility["authorization_ref"].strip()
                    or type(eligibility.get("capital_cents")) is not int
                    or eligibility["capital_cents"] <= 0):
                raise CanaryError("separate account canary eligibility required")
            aid = account_id(eligibility.get("account_id"))
            expires = _time(datetime.fromisoformat(eligibility["expires_at"]))
            if now >= expires:
                raise CanaryError("account canary eligibility expired")
            record.update(state="canary", account_id=aid, size_fraction=CANARY_SIZE_FRACTION,
                          entries_enabled=True, entries_suspended_until=None,
                          canary_started_at=now.isoformat(),
                          shadow_evidence=evidence, shadow_evidence_digest=evidence_digest(evidence),
                          eligibility=eligibility, eligibility_digest=evidence_digest(eligibility))
            _history(record, "canary", now)
            self._write(record)
            return record

    def halt(self, engine_id, reason, *, now=None):
        if not isinstance(reason, str) or not reason or len(reason) > 200:
            raise CanaryError("bounded stop reason required")
        with self._lock():
            record = self.get(engine_id)
            self._halt(record, [reason], _time(now))
            self._write(record)
            return record

    def suspend(self, engine_id, until_epoch_s, reason_code, *, now=None):
        """Suspend new entries until an epoch second (a breaker trip: next 00:00Z). Not a halt."""
        now = _time(now)
        if type(until_epoch_s) is not int or until_epoch_s <= _epoch_s(now):
            raise CanaryError("suspension must end in the future")
        if not isinstance(reason_code, str) or not 1 <= len(reason_code) <= 64:
            raise CanaryError("bounded suspension reason required")
        with self._lock():
            record = self.get(engine_id)
            if record["state"] in ENTRY_STATES:
                _suspend(record, until_epoch_s, reason_code)
                self._write(record)
            return record

    def restrict(self, engine_id, *, authorization_ref, halt_reasons=(), suspend_until=None, trips=(),
                 now=None, suspend_code="breaker_engine"):
        """S7 A: apply a tenant book's harvested restrictions to this (canonical) record.

        Contract: can only reduce risk. It applies _halt, _suspend and _trip and nothing else, so it
        never enters, lifts, resizes or extends anything, and the third trip in the kill window halts
        kill_criterion exactly as a local trip does. Under the store lock it returns None and writes
        nothing when the record is absent or its authorization_ref is not `authorization_ref` (an
        outbox left by an earlier grant). Otherwise it returns the record, rewritten only when its
        material bytes changed, so a repeated identical restriction writes nothing.
        A halt reason is a code, or a harvested (code, halt_seq) pair from a tenant outbox: a pair's
        code must be in HARVEST_HALT_CODES, and the record's harvested_halts keeps, per code, the
        highest halt_seq applied (the lease carries it as acknowledged_halts); it only grows, and
        never by more than HARVEST_SEQ_BOUND past its highest value in one harvest."""
        now = _time(now)
        reasons, harvested = [], {}
        items = tuple(halt_reasons)
        if len(items) > STOP_REASON_LIMIT:
            raise CanaryError("bounded halt reasons required")
        for item in items:
            if isinstance(item, (tuple, list)):
                if (len(item) != 2 or item[0] not in HARVEST_HALT_CODES or type(item[1]) is not int
                        or not 0 <= item[1] <= HALT_SEQ_MAX):
                    raise CanaryError("bounded halt reasons required")
                code = item[0]
                harvested[code] = max(harvested.get(code, 0), item[1])
            else:
                code = item
            if not isinstance(code, str) or not 1 <= len(code) <= 64:
                raise CanaryError("bounded halt reasons required")
            reasons.append(code)
        if suspend_until is not None and type(suspend_until) is not int:
            raise CanaryError("invalid suspension")
        if suspend_code not in SUSPEND_CODES:
            raise CanaryError("invalid suspension reason")
        days = _trip_days(tuple(trips), now)
        with self._lock():
            record = self.optional(engine_id)
            if (record is None or not isinstance(authorization_ref, str)
                    or (record.get("eligibility") or {}).get("authorization_ref") != authorization_ref):
                return None
            before = _material(record)
            if reasons:
                self._halt(record, reasons, now)
            current = _harvested(record.get("harvested_halts")) or {}
            # An outbox claiming a halt_seq beyond HARVEST_SEQ_BOUND above the highest already
            # harvested is ignored for acknowledgment (its halts above still apply): harvested_halts
            # never jumps, so a forged outbox cannot pre-acknowledge future halts.
            if harvested and max(harvested.values()) <= max(current.values(), default=0) + HARVEST_SEQ_BOUND:
                merged = {**current, **{code: max(seq, current.get(code, 0)) for code, seq in harvested.items()}}
                if merged != current:
                    record["harvested_halts"] = dict(sorted(merged.items()))
            if suspend_until is not None and suspend_until > _epoch_s(now) and record["state"] != "retired":
                _suspend(record, suspend_until, suspend_code)
            for day in days:
                if day not in (record.get("breaker_trips") or ()):
                    self._trip(record, day, now)
            if _material(record) != before:
                self._write(record)
            return record

    def adopt(self, entry, now=None, *, engine=None):
        """S7 A: fold one lease entry (lifecycle_lease.adoption) into this book-local record.

        A NEW authorization_ref on a probe or probe_sized entry runs CanaryStore.probe semantics for
        the lease's fields: the record enters probe at the policy's first rung (never the lease's
        rung), keeps a live breaker suspension, and takes the lease's account_id (the registry
        account key). Creating a record needs `engine`, whose policy digest must be the lease's.
        An existing record follows probe()'s rules with the same outcomes: only shadow or halted may
        enter (a retired or entering record refuses with CanaryError, so retired never leaves retired),
        and a halted record whose authorization_ref or approval_id equals the lease's refuses.
        A new grant never lifts a local halt the root has not seen: a halted record re-enters only
        when every locally raised non-suspension stop reason's halt_seq is at or below the entry's
        acknowledged_halts for its code (_unacknowledged_halts; counters, never clocks). Otherwise it
        stays halted, only the restrictive moves below apply, and the record's outbox_ref becomes the
        lease's ref, so the book re-exports its halts under the CURRENT grant and the next harvest
        applies them there (the operator's next re-grant can then acknowledge them).
        Otherwise (the same authorization_ref, or a non-entry
        lease state) only moves toward halted or retired apply, plus the lease's future suspension
        and trip days (a new trip day re-evaluates the kill criterion); a local halt is never lifted
        (mirrors probe's halted-needs-a-new-ref rule). A NEW authorization_ref in a shadow, canary
        or graduated entry rebinds a probe-rung record's eligibility to the lease's grant in place,
        taking the grant's state while keeping its rung and every halt mark (_rebind_grant).
        A halted record stays halted. A halt the lease applies is marked in
        lease_halts. On the same authorization_ref a probe record takes the lease's rung (state and
        contracts, up or down) when it fits the frozen policy, so a root resize reaches the book.
        The record's halt_seq is raised to at least the highest acknowledged one, so a re-created
        record's new halts are never covered by an older acknowledgment. A trip day one UTC day
        ahead is skipped until it is today; one further ahead refuses the whole entry (AdoptRefusal,
        nothing written). Idempotent: a no-op writes nothing. Returns the record, None when there is
        none, or an AdoptRefusal."""
        now = _time(now)
        if not isinstance(entry, dict) or entry.get("state") not in STATES:
            raise CanaryError("invalid lease entry")
        try:
            engine_id = _id(entry.get("engine_id"))
        except ValueError as exc:
            raise CanaryError("invalid lease entry engine_id") from exc
        halts = entry.get("halt_reasons") or ()
        until = entry.get("entries_suspended_until")
        if (not isinstance(halts, (list, tuple)) or len(halts) > STOP_REASON_LIMIT
                or any(not isinstance(code, str) or not 1 <= len(code) <= 200 for code in halts)
                or (until is not None and type(until) is not int)):
            raise CanaryError("invalid lease entry restrictions")
        acknowledged = entry.get("acknowledged_halts")
        if acknowledged is None:
            acknowledged = {}
        elif _harvested(acknowledged) is None:
            raise CanaryError("invalid lease entry restrictions")
        try:
            days = _trip_days(tuple(entry.get("breaker_trips") or ()), now)
        except (CanaryError, TypeError) as exc:
            # A trip dated beyond tomorrow at this book's clock (a skewed root or book clock): refuse
            # the whole entry, write and export nothing, and retry on the next tick.
            return AdoptRefusal(ADOPT_TRIPS_REFUSED, str(exc))
        # The root's own kill: the lease's days alone reach the criterion, so a kill_criterion they
        # raise here is lease-applied (lifted by the next re-grant without an acknowledgment).
        trip_origin = LEASE_ORIGIN if len(days) >= KILL_TRIPS else None
        ref = entry.get("authorization_ref")
        with self._lock():
            record = self.optional(engine_id)
            local_ref = (record.get("eligibility") or {}).get("authorization_ref") if record else None
            before = None if record is None else _material(record)
            if record is not None:
                # Seed first, so a legacy halted record's unmarked reasons are stamped ABOVE every
                # acknowledgment the lease carries (acknowledgeable only by a later harvest).
                _seed_halt_seq(record, acknowledged)
                _stamp_unmarked(record)
            if entry["state"] in PROBE_LIFECYCLE_STATES and isinstance(ref, str) and ref != local_ref:
                entered = self._adopt_probe(record, engine_id, entry, engine, now)
                if entered is not None:
                    _seed_halt_seq(entered, acknowledged)
                    if until is not None and until > _epoch_s(now):
                        _suspend(entered, until, "breaker_engine")
                    _merge_trips(entered, days, now, evaluate=False)
                    self._write(entered)
                    return entered
                # A local halt the root never acknowledged, a retired record or a grant this
                # record cannot take: the grant lifts nothing, and only the restrictive moves below apply.
            if record is None:
                return None
            _seed_halt_seq(record, acknowledged)
            if record["state"] != "retired":
                if entry["state"] == "retired":
                    record.update(retired_from=record["state"], retired_at=now.isoformat())
                    _history(record, "retired", now)
                    record.update(state="retired", entries_enabled=False, size_fraction=0,
                                  settlement_enabled=True, entries_suspended_until=None)
                    _merge_reasons(record, list(halts) or ["lease_retired"])
                else:
                    if entry["state"] == "halted":
                        self._halt(record, list(halts) or ["lease_halted"], now, origin=LEASE_ORIGIN)
                    elif (entry["state"] in PROBE_LIFECYCLE_STATES and record["state"] in PROBE_LIFECYCLE_STATES
                          and ref == local_ref):
                        _apply_lease_rung(record, entry, now)
                    elif (entry["state"] in REBIND_GRANT_STATES and record["state"] in PROBE_LIFECYCLE_STATES
                          and isinstance(ref, str) and ref != local_ref):
                        _rebind_grant(record, entry, now)
                    if until is not None and until > _epoch_s(now):
                        _suspend(record, until, "breaker_engine")
                    _merge_trips(record, days, now, origin=trip_origin)
            if (record["state"] == "halted" and isinstance(ref, str) and 1 <= len(ref) <= 200
                    and ref != local_ref):
                record["outbox_ref"] = ref  # re-export the kept halts under the lease's current grant
            if _material(record) != before:
                self._write(record)
            return record

    def _adopt_probe(self, record, engine_id, entry, engine, now):
        """The lease-derived probe record for a new grant, in memory, or None with `record` untouched
        when this record cannot take the grant: a retired record (retired never leaves retired), a
        halted one reusing its own reference or approval, a local halt the entry's acknowledged_halts
        do not cover, a frozen policy other than the lease's, an expired or unreadable grant field.
        Never raises for an existing record, so a valid lease never fails adopt; a record in any
        entering state (canary, probe, probe_sized, graduated) is rewritten into probe under the new
        grant at the policy's first rung. Creating a record still needs `engine` (CanaryError)."""
        try:
            ref = _bounded_ref(entry.get("authorization_ref"), "probe authorization reference")
            approval = entry.get("approval_id")
            approval = ref if approval is None else _bounded_ref(approval, "approval id")
            aid = account_id(entry.get("account_id"))
            expires_at = entry.get("expires_at")
            expires = _time(datetime.fromisoformat(expires_at))
        except (CanaryError, ValueError, TypeError):
            return None
        if now >= expires:
            return None
        if record is None:
            if (engine is None or getattr(engine, "engine_id", None) != engine_id
                    or policy_digest(engine.policy) != entry.get("policy_digest")):
                raise CanaryError("adopting a new record needs the leased engine policy")
            if len(self.list()) >= self.capacity:
                raise CanaryError("too many lifecycle candidates")
            record = _probe_skeleton(engine, now)
            initial = probe_fixed_count(engine.policy.fixed_count)
        else:
            if record["state"] == "retired" or record.get("policy_digest") != entry.get("policy_digest"):
                return None
            if (record["state"] == "halted"
                    and (ref == (record.get("eligibility") or {}).get("authorization_ref")
                         or approval == record.get("approval_id")
                         or _unacknowledged_halts(record, entry.get("acknowledged_halts")))):
                return None
            try:
                initial = _record_fixed_count(record)
            except (CanaryError, ArithmeticError, TypeError, ValueError):
                return None
        contracts = format(initial, ".2f") if initial else PROBE_CONTRACTS
        _enter_probe(record, aid, ref, approval, expires_at, contracts, initial, now)
        return record

    @staticmethod
    def _halt(record, reasons, now, *, origin=None):
        """Halt with `reasons`. A local halt (no `origin`) that halts the record or raises a code it
        does not carry locally yet increments the record's halt_seq and stamps every one of its
        reasons with it; repeating a halt already in force changes nothing (idempotent). A halt a
        lease applies (origin LEASE_ORIGIN) takes no halt_seq and lists only the codes it adds in lease_halts.
        When the record transitions to halted, every stop reason it already carries without a halt_seq
        (merged earlier without a halt) is stamped with a local halt_seq too, so it exports and can be
        acknowledged like the halt itself. A saturated counter fails closed (_take_halt_seq)."""
        if record["state"] == "retired":
            _merge_reasons(record, reasons)
            return
        seqs, lease = halt_marks(record)
        present = set(_reason_codes(record))
        unmarked = _unmarked(record, seqs, lease) if record["state"] != "halted" else []
        if origin is None:
            if record["state"] != "halted" or any(code not in present or code in lease for code in reasons):
                seq = _take_halt_seq(record)
                seqs.update((code, seq) for code in (*reasons, *unmarked))
                lease -= set(reasons)
        else:
            lease |= {code for code in reasons if code not in present}
            if unmarked:
                seq = _take_halt_seq(record)
                seqs.update((code, seq) for code in unmarked)
        if record["state"] != "halted":
            record.update(halted_from=record["state"], halted_at=now.isoformat())
            _history(record, "halted", now)
        # Halting does not end a UTC-day breaker suspension.
        record.update(state="halted", entries_enabled=False, size_fraction=0,
                      settlement_enabled=True)
        _merge_reasons(record, reasons)
        _set_halt_marks(record, seqs, lease)

    def _breaker_index(self):
        """The UTC-day breaker index, validated once per parsed file version; fails closed.
        Callers never mutate the returned document."""
        doc = self._docs.read(self._index_path, MAX_BYTES)
        if doc is not None and doc is not self._index_valid:
            if not _valid_index(doc):
                raise CanaryError("invalid breaker day index")
            self._index_valid = doc
        return doc

    def _account_suspended_until(self, account, day):
        """0 when the account has no live suspension; fails closed on an unreadable index."""
        doc = self._breaker_index()
        if doc is None:
            return 0
        if doc["utc_day"] != day:
            return 0
        block = doc["accounts"].get(account)
        return block["suspended_until"] if block else 0

    def _entries_open(self, record, now):
        if record.get("state") not in ENTRY_STATES or record.get("entries_enabled") is not True:
            return False
        now_s = _epoch_s(now)
        until = record.get("entries_suspended_until")
        if until is not None and now_s < until:
            return False
        if record.get("state") in PROBE_LIFECYCLE_STATES:
            # The D5a breaker gates probe records only (X-F3 (b)).
            day = now.date().isoformat()
            breaker = record.get("breaker") or {}
            if breaker.get("utc_day") == day and breaker.get("reason") == DAY_START_UNKNOWN:
                return False
            if self._account_suspended_until(record.get("account_id"), day) > now_s:
                return False
        return not _expired(record, now)

    def entries_enabled(self, engine_id, now=None):
        """False while suspended, halted, retired, expired, or not in ENTRY_STATES."""
        try:
            return self._entries_open(self.get(engine_id), _time(now))
        except CanaryError:
            return False

    def _read_day_start(self, account, day):
        """(present, record) for the account's `day`. A malformed, foreign or unreadable file
        still occupies the day, as unknown (record None): it fails closed and is never
        overwritten. One lstat when nothing moved."""
        try:
            doc = self._docs.read(self._day_start_path(account, day), DAY_START_MAX_BYTES)
        except TrialError:
            return True, None
        if doc is None:
            return False, None
        return True, (doc if _valid_day_start(doc, account, day) else None)

    def _day_start(self, account, day, supplied, writes, now=None):
        """The account's write-once day-start portfolio value for `day`, or None (fails closed)."""
        return self._day_start_entry(account, day, supplied, writes, now)[0]

    def _day_start_entry(self, account, day, supplied, writes, now=None):
        """(value, reason): the account's write-once day-start value for `day` and, when it is
        None, why (window_missed, day_mismatch, account_mismatch, registry_invalid, else
        day_start_unknown).

        A record already written for `day` wins, captured or missed: a same-day replacement is
        refused, never overwritten, and survives a restart. With nothing written yet, a supplied
        C-DS capture record (a dict) is filed only under its own utc_day (_supplied_day_start), and
        a bare int is taken as observed at `now` (day_start_decision); the first record is queued
        on `writes`, never written here. supplied None (or no `now`) is a pure read."""
        present, record = self._read_day_start(account, day)
        reason = None
        if not present and supplied is not None and now is not None:
            if isinstance(supplied, dict):
                record, reason = _supplied_day_start(account, day, supplied, now)
            else:
                record = day_start_decision(account, day, supplied, now, now, "observe")
            if record is not None:
                writes.append((self._day_start_path(account, day), record, DAY_START_MAX_BYTES))
        if record is None or record["day_start_portfolio_cents"] is None:
            return None, (record or {}).get("reason") or reason or DAY_START_UNKNOWN
        return record["day_start_portfolio_cents"], None

    def day_start(self, account, day):
        """Today's record for the account (read only), or None when none is readable."""
        return self._read_day_start(account, _utc_day(day))[1]

    def capture_day_start(self, account, portfolio_cents, *, observed_at, source, now=None):
        """C-DS capture: the account's day-start portfolio value, written once per UTC day.

        `portfolio_cents` is cash plus the venue mark of open positions (day_start_portfolio_cents)
        as observed at `observed_at` (aware datetime or epoch seconds); `account` is the dashboard
        account id the book's lifecycle observes (cli.py lifecycle_count). The first observation
        inside [00:00Z, 00:15Z] writes the value; past the window with none, the day is written
        null with reason window_missed. An existing record is returned unchanged (a replacement is
        refused). Returns today's record, or None while the window is open and nothing good has
        been observed. The record carries its own utc_day and captured_at, so a consumer files it
        under that day only (observe refuses another day as day_mismatch). Lock-free read on the
        steady state; the lock is taken only to write.

        Numerator (D5a, X-F3): the probe entry gate that consumes this value (cli._ProbeHost.breakers)
        divides the ACCOUNT's attributed net loss from the shared AccountRiskLedger
        (PROBE_GATE_LOSS_BASIS) by it; this store's own breaker block, which the cli never hands
        that figure, reports the observed-engine net (ACCOUNT_LOSS_FALLBACK) and names both.
        Deposits and withdrawals are not adjusted here (X2/P2a)."""
        now = _time(now)
        try:
            account = account_id(account)
        except ValueError as exc:
            raise CanaryError("invalid day-start account_id") from exc
        _bounded_ref(source, "day-start source")
        if type(observed_at) in (int, float):
            try:
                if not _finite(observed_at) or observed_at < 0:
                    raise ValueError(observed_at)
                observed_at = datetime.fromtimestamp(observed_at, timezone.utc)
            except (OverflowError, OSError, ValueError) as exc:
                raise CanaryError("invalid day-start observation time") from exc
        observed = None if observed_at is None else _time(observed_at)
        day = now.date().isoformat()
        present, record = self._read_day_start(account, day)
        if present:
            return record
        record = day_start_decision(account, day, portfolio_cents, observed, now, source)
        if record is None:
            return None
        with self._lock():
            present, stored = self._read_day_start(account, day)
            if present:
                return stored  # another writer was first: refused, never overwritten
            _replace_json(self._day_start_path(account, day), record, DAY_START_MAX_BYTES)
            self._prune_day_starts(account, day)
        return record

    def _prune_day_starts(self, account, day):
        """Drop this account's day-start files older than DAY_START_DAYS_KEEP days. Under the lock."""
        cutoff = (date.fromisoformat(day) - timedelta(days=DAY_START_DAYS_KEEP - 1)).isoformat()
        prefix = self._day_start_key(account) + "-"
        stale = []
        for path in (self.directory / "day-start").glob(prefix + "*.json"):
            if path.stem[len(prefix):] < cutoff:
                stale.append(path)
                if len(stale) >= 4 * DAY_START_DAYS_KEEP:
                    break  # bounded per write; the next day's capture continues
        for path in stale:
            path.unlink(missing_ok=True)

    def _observe_book(self, record, day, symbol, day_pnl_cents, book_total):
        """Book-path P&L (the engine bound as a book's engine). False on malformed input."""
        if record.get("utc_day") != day:
            record.update(utc_day=day, observations={}, pnl_baselines={})
        if symbol is None and day_pnl_cents is None:
            return True
        if (type(day_pnl_cents) is not int or abs(day_pnl_cents) > MAX_CENTS
                or not isinstance(symbol, str) or not 1 <= len(symbol) <= 32):
            return False
        observations = record["observations"]
        if symbol not in observations and len(observations) >= OBSERVED_SYMBOL_LIMIT:
            return False
        baseline = 0
        started = record.get("canary_started_at")
        if book_total and started:
            # The first runner observation precedes every lifecycle send. Exclude the
            # pre-lifecycle book so it cannot mask a loss. Retain this offset on restart.
            start_day = _time(datetime.fromisoformat(started)).date().isoformat()
            baseline = record["pnl_baselines"].setdefault(
                symbol, day_pnl_cents if day == start_day else 0)
        observations[symbol] = day_pnl_cents - baseline
        return True

    def _trip(self, record, day, now):
        """Count one breaker trip per UTC day; the third in seven days is the kill criterion."""
        floor = (now.date() - timedelta(days=KILL_WINDOW_DAYS - 1)).isoformat()
        trips = sorted({trip for trip in record.get("breaker_trips") or () if isinstance(trip, str)
                        and trip >= floor} | {day})
        record["breaker_trips"] = trips[-KILL_WINDOW_DAYS:]
        if len(record["breaker_trips"]) >= KILL_TRIPS:
            self._halt(record, ["kill_criterion"], now)
            return True
        return False

    def _apply_breaker(self, record, now, day, account, day_start, account_net_loss, marks, breakers,
                       writes):
        """Mutates `record` in memory and queues index and day-start writes on `writes`."""
        now_s = _epoch_s(now)
        engine_id = record["engine_id"]
        record.setdefault("entries_suspended_until", None)  # legacy canary snapshots lack it
        until = record["entries_suspended_until"]
        if until is not None and now_s >= until:
            record["entries_suspended_until"] = None
            _drop_reasons(record, SUSPEND_CODES)
        _drop_reasons(record, (DAY_START_UNKNOWN,))
        snapshot = self.exposure(engine_id).snapshot(day, marks)
        own = {"account_id": account,
               "realized_cents": snapshot.realized_today_cents + sum(record["observations"].values()),
               "open_mark_loss_cents": snapshot.open_mark_loss_cents}
        cached = self._breaker_index()
        if cached is None or cached["utc_day"] != day:
            index = {"schema": INDEX_SCHEMA, "utc_day": day, "engines": {}, "accounts": {}}
            changed = True
        else:
            # Entries are replaced, never mutated, so copying the two maps is enough.
            index = {**cached, "engines": dict(cached["engines"]), "accounts": dict(cached["accounts"])}
            changed = False
        if index["engines"].get(engine_id) != own:
            if engine_id not in index["engines"] and len(index["engines"]) >= INDEX_ENGINE_LIMIT:
                raise CanaryError("breaker day index full")
            index["engines"][engine_id] = own
            changed = True
        loss_basis = "account_net_loss"
        if account_net_loss is None:
            # The cli observe path never supplies the whole-account figure, so this block's account
            # numerator is the net of the engines this store observes (gains offset losses), named
            # account_loss_basis; the probe entry gate itself uses the AccountRiskLedger net loss,
            # named probe_gate_account_loss_basis (D5a, X-F3).
            loss_basis = ACCOUNT_LOSS_FALLBACK
            account_net_loss = sum(value["open_mark_loss_cents"] - value["realized_cents"]
                                   for value in index["engines"].values() if value["account_id"] == account)
        _cents(account_net_loss, "account_net_loss_cents", signed=True)
        # An engine's room depends only on its own loss, so evaluate this engine alone:
        # O(1) objects per observe instead of one per engine on the account.
        losses = {engine_id: EngineLoss(own["realized_cents"], own["open_mark_loss_cents"])}
        day_start_value, day_start_reason = self._day_start_entry(account, day, day_start, writes, now)
        decision = breaker_room(day_start_value, account_net_loss, losses, breakers, account)
        room = decision.engines[engine_id]
        known = decision.reason != DAY_START_UNKNOWN
        # An unknown day start is Not reported: every limit and remaining room is null, never a
        # monetary zero, while the losses stay reported.
        record["breaker"] = {
            "utc_day": day, "reason": decision.reason,
            "day_start_marked_cents": decision.day_start_marked_cents,
            "day_start_portfolio_cents": decision.day_start_marked_cents,
            "day_start_reason": None if known else (day_start_reason or DAY_START_UNKNOWN),
            "account_loss_basis": loss_basis, "probe_gate_account_loss_basis": PROBE_GATE_LOSS_BASIS,
            "engine_pct": room.pct, "inherited": room.inherited,
            "engine_limit_cents": room.limit_cents if known else None, "engine_loss_cents": room.loss_cents,
            "engine_remaining_cents": room.remaining_cents if known else None,
            "engine_suspended": room.suspended,
            "account_pct": decision.account_pct,
            "account_limit_cents": decision.account_limit_cents if known else None,
            "account_loss_cents": decision.account_loss_cents,
            "account_remaining_cents": decision.account_remaining_cents if known else None,
            "account_suspended": decision.account_suspended}
        if not known:
            # Not a trip: entries are refused until a day start is reported.
            _merge_reasons(record, [DAY_START_UNKNOWN])
        else:
            midnight = _next_midnight_s(now)
            killed = room.suspended and self._trip(record, day, now)
            if room.suspended and not killed:
                _suspend(record, midnight, "breaker_engine")
            block = index["accounts"].get(account)
            if decision.account_suspended and (block is None or block["suspended_until"] < midnight):
                block = index["accounts"][account] = {"suspended_until": midnight,
                                                      "reason": "breaker_account"}
                changed = True
            if not killed and block is not None and block["suspended_until"] > now_s:
                _suspend(record, block["suspended_until"], block["reason"])
        if changed:
            writes.append((self._index_path, index, MAX_BYTES))

    def _evaluate(self, record, now, observation):
        """Apply one observation to `record` in memory. Returns (writes, dirty): the
        (path, document, limit) side documents to replace and whether the snapshot itself
        must be rewritten. Never writes; every read is stat-cached."""
        (account, policy, risk_invariants_ok, attribution_complete, data_integrity_ok, symbol,
         day_pnl_cents, book_total, day_start_marked_cents, account_net_loss_cents, marks,
         breakers) = observation
        writes = []
        before = _material(record)
        codes = [code for code, ok in (("risk_invariant", risk_invariants_ok),
                                       ("attribution_gap", attribution_complete),
                                       ("data_integrity_failure", data_integrity_ok))
                 if ok is not True]
        if policy != record["policy_digest"]:
            codes.append("policy_changed")
        active = record["state"] in ENTRY_STATES
        day = now.date().isoformat()
        if active:
            if account != record.get("account_id"):
                codes.append("account_attribution_gap")
            if record.get("utc_day") is not None and day < record["utc_day"]:
                codes.append("data_integrity_failure")
            elif not self._observe_book(record, day, symbol, day_pnl_cents, book_total):
                codes.append("data_integrity_failure")
        if codes:
            self._halt(record, codes, now)
        elif active:
            if _expired(record, now):
                _merge_reasons(record, ["account_eligibility_expired"])
            if record["state"] in PROBE_LIFECYCLE_STATES:
                # Isolated at the consumer (X-F3 (b)): a graduated or legacy canary record never
                # reads the account/day record, whatever the caller hands it.
                self._apply_breaker(record, now, day, account, day_start_marked_cents,
                                    account_net_loss_cents, marks, breakers, writes)
        last = record.get("last_observed_at")
        stale = last is None or (now - _time(datetime.fromisoformat(last))).total_seconds() >= REWRITE_AFTER_S
        dirty = stale or _material(record) != before
        if dirty:
            record["last_observed_at"] = now.isoformat()
        return writes, dirty

    def observe(self, engine_id, *, account, policy, risk_invariants_ok, attribution_complete,
                data_integrity_ok, now=None, symbol=None, day_pnl_cents=None, book_total=False,
                day_start_marked_cents=None, account_net_loss_cents=None, marks=None,
                breakers=None):
        """Integrity failures halt; losses only suspend (D5a) until the next 00:00Z.

        No O(N) scan: reads this record, this engine's exposure ledger, the account's day
        start and one UTC-day breaker index, each parsed once per (inode, mtime, size) and
        evaluated for this engine alone. No file reads on the hot path when nothing changed:
        the steady state is four lstat calls, no lock and no write. An observation that
        would write anything (a halt, a suspension, a new day, the once-a-minute snapshot
        refresh) is re-evaluated under the lock against fresh reads before it commits.

        day_start_marked_cents is the C-DS day start: the capture record capture_day_start returned
        (filed only under its own utc_day, so a capture made before 00:00Z and consumed after it
        writes nothing for the new day) or a bare int taken as observed now. The account's record
        for the UTC day is write-once, so a supplied value only ever fills an empty day, and None
        reads the record (a missed or absent day fails closed with day_start_unknown, and the
        breaker block reports its limits as null). Only probe and probe_sized records run the
        breaker and read that record; every other state ignores day_start_marked_cents and keeps
        its paid-basis term (X-F3 (b)).
        """
        now = _time(now)
        breakers = LossBreakers() if breakers is None else breakers
        if not isinstance(breakers, LossBreakers):
            raise CanaryError("breakers must be LossBreakers")
        observation = (account, policy, risk_invariants_ok, attribution_complete, data_integrity_ok,
                       symbol, day_pnl_cents, book_total, day_start_marked_cents,
                       account_net_loss_cents, marks, breakers)
        # Lock-free probe: every document is replaced atomically, so an evaluation that
        # changes nothing on disk is a correct answer without the lock.
        record = self.get(engine_id)
        writes, dirty = self._evaluate(record, now, observation)
        if not writes and not dirty:
            return record
        with self._lock():
            record = self.get(engine_id)
            writes, dirty = self._evaluate(record, now, observation)
            for path, document, limit in writes:
                _replace_json(path, document, limit)
            if dirty:
                self._write(record)
            return record

    def entry_count(self, engine_id, nominal_count, *, account, policy, now=None):
        """Re-read at submission. Never round a sub-contract allocation upward."""
        record = self.get(engine_id)
        now = _time(now)
        if (not self._entries_open(record, now) or record.get("account_id") != account
                or record.get("policy_digest") != policy):
            return 0
        if _record_fixed_count(record) and record["state"] in PROBE_LIFECYCLE_STATES:
            return entry_count(record, nominal_count)
        if type(nominal_count) is not int:
            raise CanaryError("invalid nominal size")
        if record["state"] == "canary":
            if nominal_count < 0:
                raise CanaryError("invalid nominal size")
            return nominal_count // 20
        if record["state"] == "graduated" and maxima_breaches(record.get("policy")):
            return 0  # the nominal count is only as safe as its HARD_MAXIMA fractions
        return int(entry_count(record, nominal_count))


def lifecycle_status(record):
    """Bounded public status, without policy payloads or account authorization text."""
    return {key: record.get(key) for key in (
        "engine_id", "state", "policy_digest", "registered_at", "shadow_started_at",
        "canary_started_at", "probe_started_at", "account_id", "size_fraction", "entries_enabled",
        "settlement_enabled", "broad_live", "stop_reasons", "historical_evidence_digest",
        "shadow_evidence_digest", "eligibility_digest", "snapshot_digest", "utc_day",
        "last_observed_at", "history", "shadow_first_decision_at", "shadow_eligible_decisions",
        "contracts", "expires_at", "entries_suspended_until", "breaker")}


@contextmanager
def submission_guard(check):
    """Compose with execution experiments at the client's actual send lock."""
    from .execution_experiment import _submission_guard

    previous = _submission_guard.get()
    def combined():
        return (previous() if previous is not None else None) or check()
    token = _submission_guard.set(combined)
    try:
        yield
    finally:
        _submission_guard.reset(token)
