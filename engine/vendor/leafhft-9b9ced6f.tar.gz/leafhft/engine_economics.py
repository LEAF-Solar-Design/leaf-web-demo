"""Read-only daily economics projection for canonical engine status.

This is dated accounting evidence, not runner freshness or a probe verdict.
No report is generated, refreshed, or written by this module.
"""
from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, DecimalException, Inexact, localcontext
from pathlib import Path
from typing import Any

SCHEMA = "leafhft.engine-economics.v1"
SOURCE_SCHEMA = "leafhft.economics.v1"
MAX_REPORT_BYTES = 1024 * 1024
# Per-entry venue/cost bound in kalshi_daily_read.py:633,697-707.
# Sums and derived P&L do not inherit this per-entry ceiling.
MAX_SOURCE_CENTS = 10**12
# Two ledger lanes, each bounded by scoring.py:24,474.
MAX_SAMPLE_COUNT = 2 * 200_000


class _Invalid(ValueError):
    pass


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise _Invalid("duplicate_keys")
        result[key] = value
    return result


def _constant(value):
    raise _Invalid("nonfinite_number")


def _numbers(value):
    """Check finiteness globally; monetary types belong to projection paths."""
    if isinstance(value, dict):
        for item in value.values():
            _numbers(item)
    elif isinstance(value, list):
        for item in value:
            _numbers(item)
    elif type(value) in (float, Decimal) and not math.isfinite(value):
        raise _Invalid("nonfinite_number")


def _text(value):
    """Reject non-encodable JSON text before retaining any report metadata."""
    if isinstance(value, str):
        try:
            value.encode("utf-8")
        except UnicodeError:
            raise _Invalid("invalid_unicode") from None
    elif isinstance(value, dict):
        for key, item in value.items():
            _text(key)
            _text(item)
    elif isinstance(value, list):
        for item in value:
            _text(item)


def _safe_text(value):
    if not isinstance(value, str):
        return None
    try:
        _text(value)
    except _Invalid:
        return None
    return value


@dataclass(frozen=True)
class EconomicsReport:
    document: dict[str, Any] | None = None
    reason: str | None = "report_not_configured"
    source_schema: str | None = None
    day: str | None = None
    source_status: str | None = None


def read_report(path: str | Path | None = None) -> EconomicsReport:
    """Read at most 1 MiB plus one size-check byte, once per status command."""
    if path is None:
        return EconomicsReport()
    try:
        with Path(path).open("rb") as stream:
            data = stream.read(MAX_REPORT_BYTES + 1)
    except FileNotFoundError:
        return EconomicsReport(reason="report_missing")
    except Exception:
        return EconomicsReport(reason="report_unreadable")
    if len(data) > MAX_REPORT_BYTES:
        return EconomicsReport(reason="report_oversized")
    metadata = {}
    try:
        doc = json.loads(data, object_pairs_hook=_pairs, parse_constant=_constant,
                         parse_float=Decimal)
        if not isinstance(doc, dict):
            raise _Invalid("invalid_report")
        _text(doc)
        metadata = {"source_schema": doc.get("schema") if isinstance(doc.get("schema"), str) else None,
                    "day": doc.get("day") if isinstance(doc.get("day"), str) else None,
                    "source_status": doc.get("status") if doc.get("status") in ("COMPLETE", "INCOMPLETE") else None}
        if metadata["source_schema"] != SOURCE_SCHEMA:
            raise _Invalid("unsupported_schema")
        day = metadata["day"]
        if day is None or re.fullmatch(r"\d{4}-\d{2}-\d{2}", day) is None:
            raise _Invalid("invalid_day")
        try:
            date.fromisoformat(day)
        except ValueError:
            raise _Invalid("invalid_day") from None
        if metadata["source_status"] is None or not isinstance(doc.get("accounts"), dict):
            raise _Invalid("invalid_report")
        missing = doc.get("missing")
        if not isinstance(missing, list) or any(not isinstance(item, str) for item in missing):
            raise _Invalid("invalid_report")
        # build_economics derives this label from missing (kalshi_daily_read.py:936).
        source_status = "INCOMPLETE" if missing else "COMPLETE"
        if metadata["source_status"] != source_status:
            metadata["source_status"] = source_status
            raise _Invalid("source_status_inconsistent")
        _numbers(doc)
        return EconomicsReport(document=doc, reason=None, **metadata)
    except _Invalid as exc:
        return EconomicsReport(reason=str(exc), **metadata)
    except DecimalException:
        return EconomicsReport(reason="nonfinite_number", **metadata)
    except (ValueError, UnicodeError, RecursionError):
        return EconomicsReport(reason="malformed_json", **metadata)
    except Exception:
        # Economics is optional evidence and must not stop lifecycle status.
        return EconomicsReport(reason="invalid_report", **metadata)


# Only these account fields are public. Never copy diagnostics, report totals,
# account aliases, or sibling engine rows into a single engine's status.
_SECTIONS = {
    "reconciliation": {key: None for key in (
        "opening_balance_cents", "trade_cash_cents", "settlements_cents", "fees_cents",
        "capital_events_cents", "closing_balance_cents", "explained_closing_cents",
        "unattributed_cents", "balanced")},
    "capital_events": {"deposits_cents": None, "withdrawals_cents": None, "count": None},
    "trading": {"cash_pnl_cents": None, "marked_pnl_cents": None,
                "open_exposure": {"closing_mark_cents": None, "opening_mark_cents": None,
                                  "positions": None}},
    "compute_cost": {"cents": None, "net_after_compute_cents": None},
    "attribution": {"account_trading_cash_cents": None, "engines_total_cash_cents": None,
                    "unattributed_cents": None,
                    "unattributed_breakdown": {"ledger_rows_without_engine_cents": None,
                                               "not_in_ledgers_cents": None}},
}
_ENGINE = {"cash_cents": None, "realized_pnl_cents": None, "fees_cents": None,
           "open_cost_cents": None,
           "sample": {"tickets": None, "settled_markets": None, "days": None, "sufficiency": None}}


def _object_schema(properties, nullable=False):
    return {"type": ["object", "null"] if nullable else "object",
            "required": list(properties), "additionalProperties": False, "properties": properties}


def _fields_schema(fields, nullable=False):
    properties = {}
    for key, nested in fields.items():
        if isinstance(nested, dict):
            properties[key] = _fields_schema(nested)
        else:
            kind = ("number" if key == "cents" or key.endswith("_cents") else
                    "boolean" if key == "balanced" else
                    "string" if key == "sufficiency" else "integer")
            properties[key] = {"type": [kind, "null"]}
    return _object_schema(properties, nullable)


ECONOMICS_SCHEMA = _object_schema({
    "schema": {"type": "string", "enum": [SCHEMA]},
    "source_schema": {"type": ["string", "null"]}, "day": {"type": ["string", "null"]},
    "availability": {"type": "string", "enum": ["available", "partial", "unavailable"]},
    "source_status": {"type": ["string", "null"]}, "account_id": {"type": ["string", "null"]},
    "reasons": {"type": "array", "items": {"type": "string"}},
    "engine": _fields_schema(_ENGINE, nullable=True),
    "account_context": _fields_schema(_SECTIONS, nullable=True),
})


def _validate_schema(value, schema):
    """Validate the closed output contract without an optional dependency."""
    kinds = schema["type"]
    kinds = [kinds] if isinstance(kinds, str) else kinds
    kind = {dict: "object", list: "array", str: "string", int: "integer",
            float: "number", Decimal: "number", bool: "boolean", type(None): "null"}.get(type(value))
    if kind not in kinds and not (kind == "integer" and "number" in kinds):
        raise _Invalid("invalid_snapshot")
    if "enum" in schema and value not in schema["enum"]:
        raise _Invalid("invalid_snapshot")
    if kind == "object":
        properties = schema["properties"]
        if not set(schema["required"]) <= set(value) or set(value) - set(properties):
            raise _Invalid("invalid_snapshot")
        for key, item in value.items():
            _validate_schema(item, properties[key])
    elif kind == "array":
        for item in value:
            _validate_schema(item, schema["items"])
    elif kind == "number" and not math.isfinite(value):
        raise _Invalid("invalid_snapshot")
    elif kind == "string":
        _text(value)


def _json_numbers(value):
    """Keep ordinary JSON numbers native only when their decimal text is exact."""
    if isinstance(value, dict):
        return {key: _json_numbers(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_numbers(item) for item in value]
    if isinstance(value, Decimal):
        number = float(value)
        return number if Decimal(str(number)) == value else value
    return value


def dumps_status(value):
    """Serialize status with exact decimal JSON tokens, never quoted money."""
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("nonfinite_number")
        return str(value)
    if isinstance(value, dict):
        return "{" + ", ".join(json.dumps(key, ensure_ascii=False) + ": " + dumps_status(value[key])
                                for key in sorted(value)) + "}"
    if isinstance(value, list):
        return "[" + ", ".join(dumps_status(item) for item in value) + "]"
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


def _project(value, fields, reason, reasons):
    """Visit only declared schema fields, never account or engine map keys."""
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise _Invalid("invalid_report")
    result = {}
    for key, nested in fields.items():
        item = value.get(key)
        if isinstance(nested, dict):
            result[key] = _project(item, nested, reason, reasons)
            continue
        if item is None:
            reasons.add(reason)
        elif key == "balanced":
            if type(item) is not bool:
                raise _Invalid("invalid_report")
        elif key == "sufficiency":
            if item not in ("sufficient", "insufficient"):
                raise _Invalid("invalid_report")
        elif key == "cents" or key.endswith("_cents"):
            if type(item) not in (int, float, Decimal):
                raise _Invalid("invalid_monetary_type")
        elif type(item) is not int or item < 0:
            raise _Invalid("invalid_report")
        result[key] = item
    return result


def _equal(total, *terms):
    """Terms are (sign, operand); unknown operands do not become zero."""
    if total is None or any(value is None for _, value in terms):
        return
    # Parse decimals before any float conversion. Allow all explicit digits in
    # the bounded report, and never accept an equality after lost precision.
    with localcontext() as ctx:
        ctx.prec = MAX_REPORT_BYTES + 16
        ctx.traps[Inexact] = True
        try:
            expected = sum((sign * Decimal(str(value)) for sign, value in terms), Decimal(0))
        except Inexact:
            raise _Invalid("reconciliation_mismatch") from None
        if Decimal(str(total)) != expected:
            raise _Invalid("reconciliation_mismatch")


def _derived(total, *terms):
    """A producer-derived total cannot be known when an input is unknown."""
    if any(value is None for _, value in terms):
        if total is not None:
            raise _Invalid("reconciliation_incomplete")
        return
    _equal(total, *terms)


def _bounds(context):
    """Enforce the producer's bounds on the projected schema paths."""
    rec, capital, trading, cost, _ = (context[key] for key in _SECTIONS)
    if cost["cents"] is not None and not 0 <= cost["cents"] <= MAX_SOURCE_CENTS:
        raise _Invalid("invalid_compute_cost")
    for key in ("opening_balance_cents", "closing_balance_cents"):
        if rec[key] is not None and not -MAX_SOURCE_CENTS <= rec[key] <= MAX_SOURCE_CENTS:
            raise _Invalid("invalid_monetary_range")
    marks = trading["open_exposure"]
    # Venue fees, revenue, transfers and marked inventory sum nonnegative
    # inputs (kalshi_daily_read.py:726-736,759-778). Signed cash, residuals,
    # realized P&L and ledger remaining cost have no such source constraint.
    for value in (rec["settlements_cents"], rec["fees_cents"],
                  capital["deposits_cents"], capital["withdrawals_cents"],
                  marks["opening_mark_cents"], marks["closing_mark_cents"]):
        if value is not None and value < 0:
            raise _Invalid("invalid_monetary_range")
    deposits, withdrawals, count = (capital[key] for key in ("deposits_cents", "withdrawals_cents", "count"))
    if count is not None:
        # Each transfer has exactly one kind (kalshi_daily_read.py:772,775).
        if count < sum(value is not None and value > 0 for value in (deposits, withdrawals)):
            raise _Invalid("reconciliation_mismatch")
        for value in (deposits, withdrawals):
            if value is not None and value > count * MAX_SOURCE_CENTS:
                raise _Invalid("reconciliation_mismatch")
        if deposits is not None and withdrawals is not None:
            # Each transfer contributes to exactly one side, with the same cap.
            with localcontext() as ctx:
                ctx.prec = MAX_REPORT_BYTES + 16
                if deposits + withdrawals > count * MAX_SOURCE_CENTS:
                    raise _Invalid("reconciliation_mismatch")
    if marks["positions"] is not None and marks["closing_mark_cents"] is not None:
        # Per position: contracts <= 10**12 and mark <= 100, including empty lists.
        if marks["closing_mark_cents"] > marks["positions"] * MAX_SOURCE_CENTS * 100:
            raise _Invalid("reconciliation_mismatch")


def _venue_counts(account, context, reasons):
    # The fill/settlement loops increment these counts with their amounts;
    # account_model exports them at kalshi_daily_read.py:759-769,895.
    sample = _project(account.get("sample"), {"fills": None, "settlements": None},
                      "venue_sample_incomplete", reasons)
    rec = context["reconciliation"]
    for count, fields in ((sample["fills"], ("trade_cash_cents", "fees_cents")),
                          (sample["settlements"], ("settlements_cents",))):
        if count == 0 and any(rec[key] is not None and rec[key] != 0 for key in fields):
            raise _Invalid("reconciliation_mismatch")


def _ledger_money(context, engines):
    # Ledger parsing requires integer money (scoring.py:235,254,264).
    # Account cash and attribution residuals can include fractional venue money.
    attr = context["attribution"]
    values = [attr["engines_total_cash_cents"],
              attr["unattributed_breakdown"]["ledger_rows_without_engine_cents"]]
    for row in (engines or {}).values():
        values.extend(row[key] for key in ("cash_cents", "fees_cents", "open_cost_cents", "realized_pnl_cents"))
    for value in values:
        if value is not None:
            number = Decimal(str(value))
            if number != number.to_integral_value():
                raise _Invalid("invalid_ledger_money")


def _reconcile(context, engines):
    rec, capital, trading, cost, attr = (context[key] for key in _SECTIONS)
    cash, events, residual = trading["cash_pnl_cents"], rec["capital_events_cents"], rec["unattributed_cents"]
    _derived(events, (1, capital["deposits_cents"]), (-1, capital["withdrawals_cents"]))
    _derived(cash, (1, rec["trade_cash_cents"]), (1, rec["settlements_cents"]), (-1, rec["fees_cents"]))
    _derived(rec["explained_closing_cents"], (1, rec["opening_balance_cents"]), (1, cash), (1, events))
    # Closing is an observation, not a derived total. Follow account_model's
    # direction (kalshi_daily_read.py:868-874) when propagating unknown inputs.
    _derived(residual, (1, rec["closing_balance_cents"]), (-1, rec["explained_closing_cents"]))
    _equal(rec["closing_balance_cents"], (1, rec["opening_balance_cents"]), (1, cash), (1, events), (1, residual))
    _equal(rec["closing_balance_cents"], (1, rec["explained_closing_cents"]), (1, residual))
    _derived(attr["account_trading_cash_cents"], (1, cash), (1, residual))
    _derived(attr["account_trading_cash_cents"], (1, rec["closing_balance_cents"]),
           (-1, rec["opening_balance_cents"]), (-1, events))
    _equal(attr["account_trading_cash_cents"], (1, attr["engines_total_cash_cents"]),
           (1, attr["unattributed_cents"]))
    if engines is not None:
        _derived(attr["engines_total_cash_cents"], *((1, row.get("cash_cents")) for row in engines.values()))
    elif attr["engines_total_cash_cents"] is not None:
        raise _Invalid("reconciliation_incomplete")
    _derived(attr["unattributed_cents"], (1, attr["account_trading_cash_cents"]),
             (-1, attr["engines_total_cash_cents"]))
    breakdown = attr["unattributed_breakdown"]
    _equal(attr["unattributed_cents"], (1, breakdown["ledger_rows_without_engine_cents"]),
           (1, breakdown["not_in_ledgers_cents"]))
    _derived(breakdown["not_in_ledgers_cents"], (1, attr["unattributed_cents"]),
             (-1, breakdown["ledger_rows_without_engine_cents"]))
    _derived(cost["net_after_compute_cents"], (1, cash), (-1, cost["cents"]))
    marks = trading["open_exposure"]
    _derived(trading["marked_pnl_cents"], (1, cash), (1, marks["closing_mark_cents"]),
           (-1, marks["opening_mark_cents"]))
    if residual is None and rec["balanced"] is not None:
        raise _Invalid("reconciliation_incomplete")
    if residual is not None and rec["balanced"] is not None and rec["balanced"] != (residual == 0):
        raise _Invalid("reconciliation_mismatch")


def _engine_snapshot(report: EconomicsReport | None, account_id: str | None, engine_id: str) -> dict[str, Any]:
    report = report if report is not None else EconomicsReport()
    result = {"schema": SCHEMA, "source_schema": report.source_schema, "day": report.day,
              "availability": "unavailable", "source_status": report.source_status,
              "reasons": [], "account_id": account_id, "engine": None, "account_context": None}
    if report.reason is not None:
        result["reasons"] = [report.reason]
        return result
    if account_id is None:
        result["reasons"] = ["engine_unassigned"]
        return result
    account = report.document["accounts"].get(account_id)
    if account is None:
        result["reasons"] = ["account_not_reported"]
        return result
    if not isinstance(account, dict) or account.get("account") != account_id:
        result["reasons"] = ["account_identity_mismatch"]
        return result
    reasons = {"source_incomplete"} if report.source_status == "INCOMPLETE" else set()
    try:
        context = {key: _project(account.get(key), fields, key + "_incomplete", reasons)
                   for key, fields in _SECTIONS.items()}
        _bounds(context)
        _venue_counts(account, context, reasons)
        attribution = account.get("attribution") or {}
        engines = attribution.get("engines")
        if engines is not None:
            if not isinstance(engines, dict):
                raise _Invalid("invalid_report")
            projected = {}
            for key, row in engines.items():
                if not isinstance(row, dict):
                    raise _Invalid("invalid_report")
                row_reasons = set()
                projected[key] = _project(row, _ENGINE, "engine_incomplete", row_reasons)
                if row_reasons:
                    raise _Invalid("engine_incomplete")
                # Validate before field lookups so a broken projection fails
                # closed here and retains the report's valid source metadata.
                _validate_schema(projected[key], ECONOMICS_SCHEMA["properties"]["engine"])
                if projected[key]["fees_cents"] < 0:
                    raise _Invalid("invalid_monetary_range")
                sample = projected[key]["sample"]
                # Every bucket comes from a buy before day end, including
                # held/prior-day tickets (kalshi_daily_read.py:814-815,827-839).
                # Tickets and settled markets count this day; days is historical,
                # so neither tickets >= settled_markets nor days <= tickets holds.
                if sample["days"] < 1:
                    raise _Invalid("sample_inconsistent")
                if any(sample[field] > MAX_SAMPLE_COUNT for field in ("tickets", "days", "settled_markets")):
                    raise _Invalid("sample_inconsistent")
                # Producer definition: kalshi_daily_read.py:634,849-851.
                sufficiency = "sufficient" if sample["settled_markets"] >= 30 else "insufficient"
                if sample["sufficiency"] != sufficiency:
                    raise _Invalid("sample_label_inconsistent")
                sample["sufficiency"] = sufficiency
            engines = projected
        else:
            reasons.add("attribution_incomplete")
        _reconcile(context, engines)
        _ledger_money(context, engines)
        engine = None if engines is None else engines.get(engine_id)
        if engine is None:
            reasons.add("engine_not_reported")
        result.update(engine=engine, account_context=context,
                      availability="partial" if reasons else "available", reasons=sorted(reasons))
    except (_Invalid, RecursionError) as exc:
        result["reasons"] = [str(exc) if isinstance(exc, _Invalid) else "invalid_report"]
    return result


def engine_snapshot(report: EconomicsReport | None, account_id: str | None, engine_id: str) -> dict[str, Any]:
    result = {}
    try:
        _text(account_id)
        _text(engine_id)
        result = _json_numbers(_engine_snapshot(report, account_id, engine_id))
        _validate_schema(result, ECONOMICS_SCHEMA)
    except Exception:
        # Preserve only typed source metadata when even our projection violates
        # the output contract. No partially validated economics may escape.
        result = {"schema": SCHEMA, "availability": "unavailable", "reasons": ["invalid_snapshot"],
                  "engine": None, "account_context": None,
                  **{key: _safe_text(result.get(key))
                     for key in ("source_schema", "day", "source_status", "account_id")}}
    return result
