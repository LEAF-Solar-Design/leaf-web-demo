"""Read-only C14-B catalog comparison. No entry or widening authority is granted.

A match is a point-in-time byte comparison, never a clean 48-hour watch receipt.
Invoke explicitly with ``python -m leafhft.account_lane_catalog_audit LANE_ID``.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
import re
import stat
import sys

from . import account_lane_agent as agent
from . import account_lane_provision as provision
from .engine_registry import MAX_REGISTRY_BYTES, RegistryError, strict_loads, validate_projection
from .engines import DEFAULT_CAPACITY, EngineError, EngineRegistry

SCHEMA = "leafhft.account-lane-catalog-audit.v1"
MANIFEST_MAX = 8192
CATALOG_MAX = DEFAULT_CAPACITY
_ENGINE_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,31}")
_PROJECTION_REASONS = frozenset({
    "absent", "unsafe", "invalid", "unreadable", "projection_replayed",
    "projection_floor_missing", "projection_floor_invalid",
})


class _Unavailable(Exception):
    """Only locally selected static codes cross the report boundary."""


def _identity(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns, info.st_uid, info.st_gid)


def _shared_identity(info):
    # Windows lstat and fstat can disagree on ctime for an unchanged file.
    # Compare full metadata only between observations from the same API.
    return (info.st_dev, info.st_ino, stat.S_IFMT(info.st_mode), info.st_nlink,
            info.st_size, info.st_mtime_ns)


def _safe(path, label):
    try:
        path = agent.safe_path(path)
        # Windows junctions are reparse points but need not be symlinks.
        for part in (path, *path.parents):
            if getattr(part.lstat(), "st_file_attributes", 0) & 0x400:
                raise _Unavailable(label + "_unsafe")
        return path
    except agent.LaneRefused:
        raise _Unavailable(label + "_unsafe") from None


def _read(path, limit, label):
    """Bounded regular-file read with pinned POSIX parents and identity checks."""
    try:
        path = _safe(path, label)
        before = path.lstat()
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
            raise _Unavailable(label + "_unsafe")
        if before.st_size > limit:
            raise _Unavailable(label + "_oversized")
        with agent.private_parent(path) as parent:
            fd = os.open(path.name if parent is not None else path,
                         os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
                         | getattr(os, "O_NONBLOCK", 0), dir_fd=parent)
        with os.fdopen(fd, "rb") as stream:
            opened = os.fstat(stream.fileno())
            if _shared_identity(before) != _shared_identity(opened):
                raise _Unavailable(label + "_changed")
            data = stream.read(limit + 1)
            after = os.fstat(stream.fileno())
        if len(data) > limit:
            raise _Unavailable(label + "_oversized")
        if len(data) != opened.st_size:
            raise _Unavailable(label + "_incomplete")
        final_path = _safe(path, label).lstat()
        if (_identity(opened) != _identity(after)
                or _identity(before) != _identity(final_path)
                or _shared_identity(after) != _shared_identity(final_path)):
            raise _Unavailable(label + "_changed")
        return data, _identity(final_path)
    except FileNotFoundError:
        raise _Unavailable(label + "_missing") from None
    except agent.LaneRefused:
        raise _Unavailable(label + "_unsafe") from None
    except OSError:
        raise _Unavailable(label + "_unreadable") from None


def _directory(path, label):
    try:
        info = _safe(path, label).lstat()
        if not stat.S_ISDIR(info.st_mode):
            raise _Unavailable(label + "_unsafe")
        # Even an empty desired set must not turn an inaccessible directory into
        # a clean result. Opening it proves readability without listing sources
        # assigned to other domains.
        with agent.private_parent(path / ".audit") as parent:
            with os.scandir(parent if parent is not None else path):
                pass
        return _identity(info)
    except agent.LaneRefused:
        raise _Unavailable(label + "_unsafe") from None
    except FileNotFoundError:
        raise _Unavailable(label + "_missing") from None
    except OSError:
        raise _Unavailable(label + "_unreadable") from None


def _catalog(path):
    before = _directory(path, "catalog")
    files = {}
    try:
        # Exhaust enumeration. A partially consumed or failed iterator is never empty.
        with agent.private_parent(path / ".audit") as parent:
            with os.scandir(parent if parent is not None else path) as entries:
                for entry in entries:
                    if not entry.name.endswith(".json"):
                        continue
                    engine_id = entry.name[:-5]
                    if not _ENGINE_ID.fullmatch(engine_id):
                        raise _Unavailable("catalog_unsafe")
                    if len(files) >= CATALOG_MAX:
                        raise _Unavailable("catalog_oversized")
                    files[engine_id] = _read(path / entry.name, MANIFEST_MAX, "catalog")
    except agent.LaneRefused:
        raise _Unavailable("catalog_unsafe") from None
    except OSError:
        raise _Unavailable("catalog_unreadable") from None
    if before != _directory(path, "catalog"):
        raise _Unavailable("catalog_changed")
    return files, before


def _projection(paths):
    try:
        path = agent.registry_projection_path(paths)
        captured = _read(path, MAX_REGISTRY_BYTES, "projection")
    except agent.LaneRefused:
        raise _Unavailable("projection_unsafe") from None
    except _Unavailable as exc:
        if str(exc) == "projection_missing":
            raise _Unavailable("projection_absent") from None
        raise
    try:
        # Validate the bounded domain view before asking a reader that also supports
        # private whole registries. Never load a whole registry through that reader.
        view = validate_projection(strict_loads(captured[0], MAX_REGISTRY_BYTES))
    except (RegistryError, ValueError, RecursionError):
        raise _Unavailable("projection_invalid") from None
    if view["domain"] != "account-lane:" + paths.lane_id:
        raise _Unavailable("projection_wrong_domain")
    reader, reason, _ = agent.lane_projection(paths)
    if reader is None:
        reason = reason if reason in _PROJECTION_REASONS else "unreadable"
        raise _Unavailable(reason if reason.startswith("projection_") else "projection_" + reason)
    accepted = (reader.generation, reader.digest)
    if accepted != (int(view["generation"]), view["digest"]):
        raise _Unavailable("projection_changed")
    try:
        floor = _read(agent.registry_projection_floor_path(paths),
                      agent.PROJECTION_FLOOR_MAX, "projection_floor")
    except agent.LaneRefused:
        raise _Unavailable("projection_unsafe") from None
    if captured != _read(path, MAX_REGISTRY_BYTES, "projection"):
        raise _Unavailable("projection_changed")
    return view, captured, floor, accepted


def _report(lane_id=None):
    return {"schema": SCHEMA, "lane_id": lane_id,
            "domain": None if lane_id is None else "account-lane:" + lane_id,
            "projection_generation": None, "projection_digest": None, "exit_only": None,
            "assigned_engine_ids": None, "catalog_differences": None, "byte_digests": None,
            "refusal_codes": [], "status": "unavailable"}


@dataclass(frozen=True)
class _AcceptedCatalog:
    projection: tuple
    source_dir: Path
    source_identity: tuple
    sources: dict


def _capture_assigned(paths, *, assignment_limit=None):
    """Capture accepted assignments and validated bytes, without reading a lane catalog."""
    snapshot = _projection(paths)
    assigned = sorted(snapshot[0]["assignments"])
    if assignment_limit is not None and len(assigned) > assignment_limit:
        raise _Unavailable("source_oversized")
    source_dir = Path(provision.ENGINE_SOURCE)
    source_identity = _directory(source_dir, "source")
    registry = EngineRegistry(source_dir)
    sources = {}
    for engine_id in assigned:
        path = registry.path_for(engine_id)
        before = _read(path, MANIFEST_MAX, "source")
        try:
            registry.get(engine_id)
        except Exception:
            # Parser/conversion errors must never leak manifest text.
            raise _Unavailable("source_invalid") from None
        after = _read(path, MANIFEST_MAX, "source")
        if before != after:
            raise _Unavailable("source_changed")
        sources[engine_id] = before
    return _AcceptedCatalog(snapshot, source_dir, source_identity, sources)


def _revalidate_sources(capture):
    registry = EngineRegistry(capture.source_dir)
    for engine_id, captured in capture.sources.items():
        if captured != _read(registry.path_for(engine_id), MANIFEST_MAX, "source"):
            raise _Unavailable("source_changed")
    if capture.source_identity != _directory(capture.source_dir, "source"):
        raise _Unavailable("source_changed")


def _revalidate_projection(paths, capture):
    if capture.projection != _projection(paths):
        raise _Unavailable("projection_changed")


def audit_lane_catalog(lane_id):
    """Compare only the accepted lane assignments; never mutate or authorize entries.

    Unavailable reports have no desired set or partial differences. In particular,
    null assignments are not the valid, explicitly empty assignment list.
    """
    try:
        lane_id = agent.identifier(lane_id)
    except agent.LaneRefused:
        report = _report()
        report["refusal_codes"] = ["invalid_lane_id"]
        return report
    report = _report(lane_id)
    try:
        paths = agent.LanePaths(lane_id)
        capture = _capture_assigned(paths)
        snapshot = capture.projection
        view = snapshot[0]
        assigned = sorted(view["assignments"])
        sources = capture.sources
        catalog_path = paths.state / "engine-catalog" / "engines"
        copies, catalog_identity = _catalog(catalog_path)
        # Recheck every captured source and copy, including extras, before publishing
        # a result. Same-content replacement still invalidates this collection.
        _revalidate_sources(capture)
        if (copies, catalog_identity) != _catalog(catalog_path):
            raise _Unavailable("catalog_changed")
        _revalidate_projection(paths, capture)
        wanted, present = set(assigned), set(copies)
        differences = {"missing": sorted(wanted - present), "extra": sorted(present - wanted),
                       "changed": sorted(eid for eid in wanted & present
                                         if sources[eid][0] != copies[eid][0])}
        report.update(
            projection_generation=snapshot[3][0], projection_digest=snapshot[3][1],
            exit_only=view["exit_only"], assigned_engine_ids=assigned,
            catalog_differences=differences,
            byte_digests={"source": {eid: hashlib.sha256(sources[eid][0]).hexdigest()
                                     for eid in assigned},
                          "lane": {eid: hashlib.sha256(copies[eid][0]).hexdigest()
                                   for eid in sorted(copies)}},
            status="difference" if any(differences.values()) else "match")
    except _Unavailable as exc:
        report["refusal_codes"] = [str(exc)]
    except agent.LaneRefused:
        report["refusal_codes"] = ["catalog_unsafe"]
    except (OSError, EngineError):
        report["refusal_codes"] = ["audit_unreadable"]
    return report


def main(argv=None):
    args = sys.argv[1:] if argv is None else argv
    report = audit_lane_catalog(args[0] if len(args) == 1 else None)
    print(json.dumps(report, sort_keys=True, allow_nan=False))
    return {"match": 0, "difference": 1, "unavailable": 2}[report["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
