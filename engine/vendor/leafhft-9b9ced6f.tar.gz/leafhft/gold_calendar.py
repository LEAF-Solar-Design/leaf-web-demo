"""Scheduled US macro releases that black out Gold paper decisions.

Verified against official BLS, BEA, Census, DOL and Federal Reserve schedules on
2026-09-22; FOMC minutes follow the Fed's stated three-weeks-after-decision rule.
Each release is (utc_ms, local America/New_York time, event, agency). Official 2027
schedules were not yet published, so coverage ends 2026-12-31 ET; outside
COVERAGE_MS every decision is blacked out until a new version is added.
"""
from __future__ import annotations

VERIFIED_ON = '2026-09-22'
SOURCES = (
    ('BLS', 'https://www.bls.gov/schedule/news_release/'),
    ('BEA', 'https://www.bea.gov/news/schedule/full'),
    ('Census Bureau', 'https://www.census.gov/retail/release_schedule.html'),
    ('DOL', 'https://oui.doleta.gov/unemploy/claims_arch.asp'),
    ('Federal Reserve', 'https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm'),
    ('Federal Reserve Beige Book', 'https://www.federalreserve.gov/monetarypolicy/publications/beige-book-default.htm'),
)
COVERAGE_MS = (1790049600000, 1798779599000)  # 2026-09-22T00:00 to 2026-12-31T23:59:59 ET
RELEASES = (
    (1790253000000, '2026-09-24T08:30', 'Initial Jobless Claims', 'DOL'),
    (1790690400000, '2026-09-29T10:00', 'JOLTS', 'BLS'),
    (1790771400000, '2026-09-30T08:30', 'GDP', 'BEA'),
    (1790771400000, '2026-09-30T08:30', 'Personal Income and Outlays', 'BEA'),
    (1790857800000, '2026-10-01T08:30', 'Initial Jobless Claims', 'DOL'),
    (1790944200000, '2026-10-02T08:30', 'Employment Situation', 'BLS'),
    (1791396000000, '2026-10-07T14:00', 'FOMC Minutes (three weeks after decision)', 'Federal Reserve'),
    (1791462600000, '2026-10-08T08:30', 'Initial Jobless Claims', 'DOL'),
    (1791981000000, '2026-10-14T08:30', 'CPI', 'BLS'),
    (1792000800000, '2026-10-14T14:00', 'Beige Book', 'Federal Reserve'),
    (1792067400000, '2026-10-15T08:30', 'Advance Monthly Retail Sales', 'Census Bureau'),
    (1792067400000, '2026-10-15T08:30', 'Initial Jobless Claims', 'DOL'),
    (1792067400000, '2026-10-15T08:30', 'PPI', 'BLS'),
    (1792672200000, '2026-10-22T08:30', 'Initial Jobless Claims', 'DOL'),
    (1793210400000, '2026-10-28T14:00', 'FOMC Statement', 'Federal Reserve'),
    (1793212200000, '2026-10-28T14:30', 'FOMC Press Conference', 'Federal Reserve'),
    (1793277000000, '2026-10-29T08:30', 'GDP', 'BEA'),
    (1793277000000, '2026-10-29T08:30', 'Initial Jobless Claims', 'DOL'),
    (1793277000000, '2026-10-29T08:30', 'Personal Income and Outlays', 'BEA'),
    (1793718000000, '2026-11-03T10:00', 'JOLTS', 'BLS'),
    (1793885400000, '2026-11-05T08:30', 'Initial Jobless Claims', 'DOL'),
    (1793971800000, '2026-11-06T08:30', 'Employment Situation', 'BLS'),
    (1794317400000, '2026-11-10T08:30', 'CPI', 'BLS'),
    (1794490200000, '2026-11-12T08:30', 'Initial Jobless Claims', 'DOL'),
    (1794576600000, '2026-11-13T08:30', 'PPI', 'BLS'),
    (1794922200000, '2026-11-17T08:30', 'Advance Monthly Retail Sales', 'Census Bureau'),
    (1795028400000, '2026-11-18T14:00', 'FOMC Minutes (three weeks after decision)', 'Federal Reserve'),
    (1795095000000, '2026-11-19T08:30', 'Initial Jobless Claims', 'DOL'),
    (1795613400000, '2026-11-25T08:30', 'GDP', 'BEA'),
    (1795613400000, '2026-11-25T08:30', 'Initial Jobless Claims', 'DOL'),
    (1795613400000, '2026-11-25T08:30', 'Personal Income and Outlays', 'BEA'),
    (1795633200000, '2026-11-25T14:00', 'Beige Book', 'Federal Reserve'),
    (1796137200000, '2026-12-01T10:00', 'JOLTS', 'BLS'),
    (1796304600000, '2026-12-03T08:30', 'Initial Jobless Claims', 'DOL'),
    (1796391000000, '2026-12-04T08:30', 'Employment Situation', 'BLS'),
    (1796842800000, '2026-12-09T14:00', 'FOMC Statement', 'Federal Reserve'),
    (1796842800000, '2026-12-09T14:00', 'FOMC Summary of Economic Projections', 'Federal Reserve'),
    (1796844600000, '2026-12-09T14:30', 'FOMC Press Conference', 'Federal Reserve'),
    (1796909400000, '2026-12-10T08:30', 'CPI', 'BLS'),
    (1796909400000, '2026-12-10T08:30', 'Initial Jobless Claims', 'DOL'),
    (1797341400000, '2026-12-15T08:30', 'PPI', 'BLS'),
    (1797427800000, '2026-12-16T08:30', 'Advance Monthly Retail Sales', 'Census Bureau'),
    (1797514200000, '2026-12-17T08:30', 'Initial Jobless Claims', 'DOL'),
    (1798032600000, '2026-12-23T08:30', 'GDP', 'BEA'),
    (1798032600000, '2026-12-23T08:30', 'Personal Income and Outlays', 'BEA'),
    (1798119000000, '2026-12-24T08:30', 'Initial Jobless Claims', 'DOL'),
    (1798657200000, '2026-12-30T14:00', 'FOMC Minutes (three weeks after decision)', 'Federal Reserve'),
    (1798723800000, '2026-12-31T08:30', 'Initial Jobless Claims', 'DOL'),
)
