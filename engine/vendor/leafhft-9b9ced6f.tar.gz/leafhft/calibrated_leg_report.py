"""T2-v4 R5: the paired report that measures what the testers approved for a calibrated leg.

A calibrated leg is a co-hosted tenant probe named "<parent>-t2cal". The host gate admits a leg
proposal only behind a filled same-side position of its parent, so every leg ticket should have a
parent ticket on the same (ticker, window, side). This report pairs them from the ledgers alone,
for ONE book: the run dirs whose config.json names this venue and symbol in live mode.

- pairs_n by (ticker, window), and the parent's and the leg's per-contract net cents on the
  paired, settled trades, both pooled (contract-weighted) and as an equal-weight mean per pair,
  so the parent's larger size never masquerades as a per-trade difference;
- the parent's per-contract net on trades the gate admitted (a leg rode behind them) versus
  refused (a t2cal_refused row names the market), each with its n: the selection effect T2 claims;
- the Jeffreys 10th-percentile hit rate per entry-price bucket, for the leg and its parent, where a
  win is the ticket's SIDE winning (never pnl > 0: fees make a winning 0.25 leg at 96c net <= 0);
- refusals by reason; and two must-be-zero VIOLATION counts: orphans (a leg ticket with no
  same-side parent ticket) and disturbance (parent refusals, a latched leg, leg rows inside the
  parent's own ledger). Violation counts carry reads_zero (True, False, or None when unproven),
  never a sample label. reads_zero is True only when every row in scope was read and joined: an
  unreadable or absent run root, a cut or skipped file, a skipped row (a closed run's torn last
  row included), an unjoined leg outcome, a leg entry duplicated onto another market or side, a
  cut run dir or an unread lifecycle record makes a zero count None, never True.

Every sample figure carries its n and any n below MIN_N is labelled "insufficient". Nothing the
report prints is untrue: a leg whose parent history could not be read in full (always when its
own run's parent ledger was cut) is "unverifiable (truncated)", never an orphan; a ticket whose outcomes contradict each other is kept (its leg
still pairs) but excluded from every net figure and named in a diagnostic.

Hardening contract: a pure function of the file bytes under run_root and the leg's lifecycle
record (no clock, no network, no broker import, no writes). Bounds are R1's lane history reader's
(calibrated_stake.HISTORY_MAX_*): one 4 MiB ledger-byte budget and one 20000-row budget shared by
every file, the newest 64 run dirs by name, each config.json read separately at most 64 KiB. The
run dirs are selected newest-first over ALL entries with a bounded heap (never a prefix of scandir
order). Every ledger and run dir is lstat-checked: a symlinked or non-regular one is refused with
one diagnostic. Row content can never raise out: a malformed row is skipped with exactly one
diagnostic and never zeroes any other row. Any cut (tail window, row cap, budget, run-dir cap)
sets reader.truncated and names itself in a diagnostic. Only the open run (this book's newest,
with no crash leftover newer than it) may drop an unterminated last row as still being written.
A run dir with no config.json and neither a parent ledger nor the leg's probe dir is what the
runtime leaves when it dies before writing config.json; it is skipped silently, as R1's lane
history and the runtime's prior-run scan skip it. Any other config-less run dir is a gap.

Local stand-ins, reconciled by the planner when R1 (leafhft/t2cal.py, calibrated_stake's
lane_history_fractions) lands: REFUSAL_KIND, REFUSAL_ROW_KEYS and _run_identity_matches below are
copied from R1 by name; PARENT_REFUSAL_KIND is R3's draft item 5; REFUSAL_JOURNAL is a local name.
R1's window_id is read as the market close in integer ms (engine_cells.window_ms), the key every
ticket row carries; any other window_id is refused with one diagnostic.
"""
from __future__ import annotations

import argparse
from collections import Counter
from decimal import Decimal, localcontext
import heapq
import json
import os
from pathlib import Path
import stat
import sys

from leafhft.engine_cells import CellRejected, exact, identifier, window_ms
from leafhft.owner_live_ledger import _engine, _entry, _episode, _outcome, _timestamp
from leafhft.research import calibrated_sizing

SCHEMA = "leafhft.calibrated-leg-report.v2"
LEG_SUFFIX = "-t2cal"
MIN_N = 20  # below this a figure is labelled "insufficient" (tester card T2's sample floor)
INCUMBENT_TICKETS = "kalshi-tickets.jsonl"
PROBE_TICKETS = "kalshi-probe-tickets.jsonl"
REFUSAL_JOURNAL = "t2cal-journal.jsonl"  # local stand-in for R1's journal name
# R1 (t2cal.py) names, kept local and identical until R1 lands.
REFUSAL_KIND = "t2cal_refused"
REFUSAL_ROW_KEYS = ("kind", "ts_ms", "engine_id", "ticker", "window_id", "bucket", "reason")
PARENT_REFUSAL_KIND = "t2cal_parent_refusal"  # R3 draft item 5
LATCH_REASON = "incumbent_disturbed"  # the canary halt a disturbing leg latches with
# R1's lane history bounds (calibrated_stake.HISTORY_MAX_BYTES, _ROWS, _FILES, CONFIG_MAX_BYTES):
# the report reads the same history the gate's refresher reads, so no figure needs more.
MAX_TOTAL_BYTES = 4 * 1024 * 1024  # one ledger-byte budget shared by every file
MAX_TOTAL_ROWS = 20000  # one row budget shared the same way
MAX_FILE_BYTES = MAX_TOTAL_BYTES
MAX_ROWS_PER_FILE = MAX_TOTAL_ROWS
MAX_RUN_DIRS = 64
CONFIG_MAX_BYTES = 64 * 1024
MAX_DIAGNOSTIC_SAMPLES = 20
MAX_TEXT = 200
_SYMBOL = "tenant-book"  # engine_cells needs a symbol; one book keys every ticket
_ENTRY_KINDS = ("buy", "entry", "fill")
_OUTCOME_KINDS = ("settle", "exit", "void")
_TICKET_KINDS = _ENTRY_KINDS + _OUTCOME_KINDS
_QUANTILE = 0.10


def _read_window(path, limit):
    """At most limit bytes from the tail of path, and whether the window starts mid-file.

    The one ledger read the report makes; it never asks for more than limit bytes. Returns None
    for a missing file and raises OSError for an unreadable one."""
    try:
        with Path(path).open("rb") as stream:
            size = stream.seek(0, 2)
            start = max(0, size - limit)
            stream.seek(start)
            return stream.read(limit), start > 0
    except FileNotFoundError:
        return None


class _Diagnostics:
    def __init__(self):
        self.by_reason = Counter()
        self.skipped_rows = 0
        self.samples = []

    def note(self, label, line_no, reason, *, skipped=False, n=1):
        self.by_reason[reason] += n
        self.skipped_rows += n if skipped else 0
        if len(self.samples) < MAX_DIAGNOSTIC_SAMPLES:
            self.samples.append({"file": label, "line": line_no, "reason": reason})

    def document(self):
        return {"skipped_rows": self.skipped_rows, "by_reason": dict(sorted(self.by_reason.items())),
                "samples": list(self.samples)}


class _Reader:
    """Bounded line reader shared by every ledger in one report; spends one byte and one row budget."""

    def __init__(self, max_file_bytes, max_total_bytes, max_rows_per_file, max_total_rows):
        self.max_file_bytes = max_file_bytes
        self.max_rows_per_file = max_rows_per_file
        self.remaining_bytes = max_total_bytes
        self.remaining_rows = max_total_rows
        self.bytes_read = 0
        self.rows_read = 0
        self.files_read = 0
        self.truncated = False

    def lines(self, path, diagnostics, label, *, open_run=False):
        """(lines, status): status "absent", "full", "cut" (the oldest rows were not read) or
        "skipped" (nothing read: refused, unreadable, or the budget is spent). An unterminated
        last row is dropped; outside the open run it is a lost row, noted as a skipped row."""
        try:
            info = os.lstat(path)
        except FileNotFoundError:
            return [], "absent"
        except OSError:
            diagnostics.note(label, None, "unreadable_file")
            return [], "skipped"
        if not stat.S_ISREG(info.st_mode):
            diagnostics.note(label, None, "non_regular_file")  # a symlink or a directory: refused
            return [], "skipped"
        limit = min(self.max_file_bytes, self.remaining_bytes)
        rows_left = min(self.max_rows_per_file, self.remaining_rows)
        if limit <= 0 or rows_left <= 0:
            if info.st_size == 0:
                return [], "full"
            self.truncated = True
            diagnostics.note(label, None, "byte_budget_exhausted" if limit <= 0 else "row_budget_exhausted")
            return [], "skipped"
        try:
            found = _read_window(path, limit)
        except OSError:
            diagnostics.note(label, None, "unreadable_file")
            return [], "skipped"
        if found is None:
            return [], "absent"
        data, cut = found
        data = data[:limit]  # a misbehaving read can never spend past the budget
        self.bytes_read += len(data)
        self.remaining_bytes -= len(data)
        self.files_read += 1
        lines = data.split(b"\n")
        tail = lines.pop()  # empty after a final newline, else a row still being written
        if tail.strip() and not open_run:
            # a closed run writes nothing more: its torn last row is a row lost, never ignored
            diagnostics.note(label, None, "torn_last_row", skipped=True)
        status = "full"
        if cut:
            self.truncated, status = True, "cut"
            diagnostics.note(label, None, "file_tail_cut")
            if lines:
                lines.pop(0)  # the window cut this line, or it is the empty head before a newline
        if len(lines) > rows_left:
            self.truncated, status = True, "cut"
            diagnostics.note(label, None, "row_cap")
            lines = lines[-rows_left:]
        self.remaining_rows -= len(lines)
        self.rows_read += len(lines)
        return lines, status


def _text(value, reason):
    if not isinstance(value, str) or not value or len(value) > MAX_TEXT:
        raise CellRejected(reason)
    return value


def _side(row):
    side = row.get("side_yes")
    if type(side) is not bool:
        raise CellRejected("invalid_side")
    return side


def _refusal_row(row, leg):
    """R1's t2cal_refused row read exactly (REFUSAL_ROW_KEYS): (ticker, window, bucket, reason)."""
    if any(key not in row for key in REFUSAL_ROW_KEYS):
        raise CellRejected("invalid_refusal_row")
    if row["engine_id"] != leg:
        raise CellRejected("engine_mismatch")
    if exact(row["ts_ms"], "invalid_timestamp") < 0:
        raise CellRejected("invalid_timestamp")
    ticker = _text(row["ticker"], "invalid_ticker")
    window = window_ms({"window": row["window_id"]})  # local reading of window_id: close in ms
    return ticker, window, _text(row["bucket"], "invalid_bucket"), _text(row["reason"], "invalid_reason")


def _parent_refusal_row(row, leg, parent):
    """A t2cal_parent_refusal row: the parent's own order refused because of the leg."""
    if row.get("engine_id") not in (leg, parent):
        raise CellRejected("engine_mismatch")
    return _text(row.get("reason"), "invalid_reason")


def _won(row):
    """Whether the ticket's side won, from a settle row; None when the row cannot say."""
    if row["kind"] != "settle":
        return None
    if row.get("result") in ("yes", "no") and type(row.get("side_yes")) is bool:
        return (row["result"] == "yes") == row["side_yes"]
    if type(row.get("won")) is bool:
        return row["won"]
    if "payout_cents" in row:
        return exact(row["payout_cents"], "invalid_pnl") > 0
    return None


def _economics(event, time_key="settled_at_ms"):
    return {k: v for k, v in event.items() if k != time_key}


class _Book:
    """Tickets of one role (parent or leg), deduplicated by (engine, client_id) across run dirs.

    Conflicts follow owner_live_ledger._consume: a duplicate event with different economics is
    kept as a conflict, never silently dropped, and its ticket is excluded from net figures. A
    duplicate entry with different money keeps the first seen (owner_live_ledger's INSERT OR
    IGNORE) and is counted in entry_conflicts, reported as duplicate_entry_conflict; one that also
    names another market or side is counted in market_conflicts, since the entry it lost may be
    an orphan."""

    def __init__(self):
        self.entries = {}
        self.meta = {}
        self.origin = {}  # the run dir whose ledger held the entry kept
        self.outcomes = {}
        self.outcome_market = {}
        self.won = {}
        self.conflicts = set()
        self.entry_conflicts = 0
        self.market_conflicts = 0

    def add(self, row, engine, run):
        kind = row["kind"]
        cid = _text(row.get("client_id"), "invalid_client_id")
        key = (engine, cid)
        if kind in _ENTRY_KINDS:
            entry = _entry(row, _SYMBOL)
            meta = (_text(row.get("ticker"), "invalid_ticker"), entry["window"], _side(row))
            if key not in self.entries:
                self.entries[key] = entry
                self.meta[key] = meta
                self.origin[key] = run
            elif self.meta[key] != meta:
                self.entry_conflicts += 1
                self.market_conflicts += 1
            elif _economics(self.entries[key], "filled_at_ms") != _economics(entry, "filled_at_ms"):
                self.entry_conflicts += 1
            return
        outcome = _outcome(row)
        won = _won(row)
        event = ("terminal" if kind != "exit" else
                 str(row["exit_client_id"]) if row.get("exit_client_id") else
                 json.dumps(outcome, sort_keys=True, default=str))
        events = self.outcomes.setdefault(key, {})
        old = events.get(event)
        if old is None:
            events[event] = outcome
            if won is not None:
                self.won[key] = won
        elif _economics(old) != _economics(outcome) or (won is not None and self.won.get(key, won) != won):
            self.conflicts.add(key)
        if key not in self.outcome_market:
            try:
                self.outcome_market[key] = (_text(row.get("ticker"), "invalid_ticker"), window_ms(row))
            except CellRejected:
                self.outcome_market[key] = None  # an outcome that cannot name its market

    def tickets(self, diagnostics, label):
        """One dict per ticket; status settled, open or conflict (pnl only when settled)."""
        found = []
        for key in sorted(self.entries, key=lambda k: (self.entries[k]["filled_at_ms"], k[1])):
            entry = self.entries[key]
            ticker, window, side = self.meta[key]
            events = self.outcomes.get(key, {})
            status, pnl, settled_at = "open", None, None
            try:
                if key in self.conflicts:
                    raise CellRejected("conflicting_outcomes")
                outcome = _episode(entry, [events[e] for e in sorted(events)])
            except Exception as exc:  # the ticket stays (its leg still pairs); its net is excluded
                status = "conflict"
                diagnostics.note(label, None, exc.reason if isinstance(exc, CellRejected) else "invalid_row")
            else:
                if outcome is not None:
                    status, pnl = "settled", Decimal(str(outcome["pnl_cents"]))
                    settled_at = outcome["settled_at_ms"]
            found.append({"ticker": ticker, "window": window, "side_yes": side, "status": status,
                          "run": self.origin[key],
                          "count": Decimal(str(entry["count"])),
                          "entry_price_cents": Decimal(str(entry["entry_price_cents"])),
                          "filled_at_ms": entry["filled_at_ms"], "settled_at_ms": settled_at,
                          "pnl_cents": pnl, "won": self.won.get(key) if status == "settled" else None})
        return found

    def unjoined(self):
        """Outcome keys with no entry read: (count, markets named, count naming no market)."""
        keys = [k for k in self.outcomes if k not in self.entries]
        markets = {self.outcome_market[k] for k in keys if self.outcome_market.get(k) is not None}
        return len(keys), markets, sum(1 for k in keys if self.outcome_market.get(k) is None)


def _consume(lines, label, diagnostics, on_row):
    for line_no, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line, parse_float=Decimal)
            if not isinstance(row, dict):
                raise CellRejected("invalid_row")
            if not isinstance(row.get("kind"), str):
                raise CellRejected("invalid_kind")
            on_row(row)
        except Exception as exc:  # any bad row is skipped once; nothing it holds may raise out
            reason = exc.reason if isinstance(exc, CellRejected) else "invalid_row"
            diagnostics.note(label, line_no, reason, skipped=True)


def _run_dirs(run_root, max_run_dirs, diagnostics):
    """(the newest max_run_dirs run dir names, newest first; how many older dirs were cut).

    Every entry is visited (scandir order is hash order, so a prefix is not the newest); a bounded
    heap keeps max_run_dirs + 1 names. A symlinked entry is refused with one diagnostic."""
    total = 0

    def names(scan):
        nonlocal total
        for entry in scan:
            if entry.is_symlink():
                diagnostics.note(entry.name, None, "symlinked_run_dir")
                continue
            if entry.is_dir(follow_symlinks=False):
                total += 1
                yield entry.name

    with os.scandir(run_root) as scan:
        top = heapq.nlargest(max_run_dirs, names(scan))
    return top, total - len(top)


def _run_identity_matches(directory, venue, symbol):
    """R1's identity rule (calibrated_stake._run_identity_matches, local until R1 lands): True
    when directory's config.json names this venue and symbol in live mode. Reads at most
    CONFIG_MAX_BYTES; raises on a missing, linked, oversized or malformed config."""
    config = directory / "config.json"
    info = os.lstat(config)
    if not stat.S_ISREG(info.st_mode):
        raise ValueError("run config is not a plain file")
    if info.st_size > CONFIG_MAX_BYTES:
        raise ValueError("run config over 64 KiB")
    with config.open("rb") as stream:
        raw = stream.read(CONFIG_MAX_BYTES)
    identity = json.loads(raw)
    if not isinstance(identity, dict):
        raise ValueError("run config is not an object")
    return (identity.get("venue"), identity.get("symbol"), identity.get("mode")) == (venue, symbol, "live")


def _crash_leftover(directory, engine):
    """True when a config-less run dir holds neither a parent ledger nor the leg's probe dir: the
    state the runtime leaves when it dies between reconcile and the config.json write (R1's
    _lane_history rule). Anything present, or any lstat that fails otherwise, is not a leftover."""
    for name in (INCUMBENT_TICKETS, f"probe-{engine}"):
        try:
            os.lstat(directory / name)
        except FileNotFoundError:
            continue
        except OSError:
            return False
        return False
    return True


def _latched(lifecycle_dir, engine, diagnostics, traded):
    """(latched 0, 1 or None, source), read-only through CanaryStore: 1 when the leg's lifecycle
    record is halted (or retired) with stop reason incumbent_disturbed; None when not read, and
    None when the record is absent for a leg that traded (an absent latch is unread, not 0)."""
    if lifecycle_dir is None:
        return None, "not_read"
    from leafhft.canary import CanaryStore

    try:
        record = CanaryStore(lifecycle_dir).optional(engine)
    except Exception:  # an invalid or unreadable record says nothing; it never reads as 0
        diagnostics.note(f"lifecycle/{engine}.json", None, "unreadable_lifecycle_record")
        return None, "unreadable"
    if record is None:
        return (None if traded else 0), "absent"
    codes = set()
    for item in record.get("stop_reasons") or ():
        code = item if isinstance(item, str) else item.get("code") if isinstance(item, dict) else None
        if isinstance(code, str):
            codes.add(code)
    return int(record.get("state") in ("halted", "retired") and LATCH_REASON in codes), "lifecycle_record"


def _label(n):
    return "ok" if n >= MIN_N else "insufficient"


def _number(value):
    return int(value) if value == value.to_integral_value() else format(value.normalize(), "f")


def _reads_zero(counts, all_read):
    """False when any known count is positive; None when one is unknown or any row in scope went
    unread (a zero over a partial read proves nothing); else True."""
    if any(c for c in counts if c is not None):
        return False
    return None if not all_read or any(c is None for c in counts) else True


def _figure(trades):
    """Per-contract net over settled trades (net, contracts): pooled is contract-weighted, mean
    weighs every trade equally (the per-trade figure); n counts the trades."""
    n = len(trades)
    net = sum((t[0] for t in trades), Decimal(0))
    contracts = sum((t[1] for t in trades), Decimal(0))
    per_trade = [t[0] / t[1] for t in trades if t[1] > 0]
    return {"n": n, "net_cents": _number(net), "contracts": _number(contracts),
            "pooled_per_contract_net_cents": None if contracts <= 0 else round(float(net / contracts), 4),
            "mean_per_contract_net_cents": (None if not per_trade else
                                            round(float(sum(per_trade, Decimal(0)) / len(per_trade)), 4)),
            "label": _label(n)}


def _hit_rates(tickets):
    """Jeffreys p10 hit rate per entry-price bucket; a win is the side winning; windows cluster."""
    cells = {}
    for t in tickets:
        if t["won"] is None:
            continue
        bucket = calibrated_sizing.claimed_bucket(float(t["entry_price_cents"]) / 100.0)
        if bucket is None:
            continue
        cell = cells.setdefault(bucket, {"n": 0, "wins": 0, "windows": Counter()})
        cell["n"] += 1
        cell["wins"] += int(t["won"])
        cell["windows"][t["window"]] += 1
    out = {}
    for bucket in sorted(cells):
        cell = cells[bucket]
        n_eff = calibrated_sizing.effective_n(list(cell["windows"].values()))
        p10 = calibrated_sizing.posterior_quantile(cell["wins"], cell["n"], n_eff, _QUANTILE)
        out[bucket] = {"n": cell["n"], "wins": cell["wins"], "n_eff": round(n_eff, 4),
                       "jeffreys_p10": round(p10, 6), "label": _label(cell["n"])}
    return out


def _group(tickets):
    groups = {}
    for t in tickets:
        groups.setdefault((t["ticker"], t["window"], t["side_yes"]), []).append(t)
    return groups


def _group_state(group):
    """"conflict", "open" or "settled" for a group of tickets on one (ticker, window, side)."""
    states = {t["status"] for t in group}
    return "conflict" if "conflict" in states else "open" if "open" in states else "settled"


def _settled_sum(group):
    return (sum((t["pnl_cents"] for t in group), Decimal(0)), sum((t["count"] for t in group), Decimal(0)))


class _Coverage:
    """Where the parent's history is known complete: every parent row at or after from_ms was
    read. Runs are walked newest first, so the first gap ends the complete region."""

    def __init__(self):
        self.complete = True
        self.from_ms = None  # meaningful only once incomplete; None then means nothing is covered
        self.earliest = None

    def seen(self, ts):
        self.earliest = ts if self.earliest is None else min(self.earliest, ts)

    def gap(self, earliest_kept=None):
        if self.complete:
            self.complete = False
            self.from_ms = earliest_kept if earliest_kept is not None else self.earliest


def _verifiable(group, coverage, unjoined_markets, unjoined_unnamed, parent_last_ms, run_parent_full):
    """Whether an unpaired leg group is provably unpaired. Complete history proves it. Under a
    truncated history it is proven only for settled legs whose own run's parent ledger was read
    in full, entered at or after from_ms, when no unjoined parent outcome names (or could name)
    the market and the parent ledger has rows at or after the leg's settlement: a parent that
    held at the leg's entry leaves a terminal row after that entry, inside the read region."""
    if coverage.complete:
        return True
    if not all(run_parent_full.get(t["run"], False) for t in group):
        return False  # a leg settling near parent_last is no proof the parent's terminal row exists
    if coverage.from_ms is None or unjoined_unnamed or parent_last_ms is None:
        return False
    if (group[0]["ticker"], group[0]["window"]) in unjoined_markets:
        return False
    return all(t["status"] == "settled" and t["filled_at_ms"] >= coverage.from_ms
               and t["settled_at_ms"] <= parent_last_ms for t in group)


def build_report(run_root, engine, *, symbol, venue="kalshi", lifecycle_dir=None,
                 max_file_bytes=MAX_FILE_BYTES, max_total_bytes=MAX_TOTAL_BYTES,
                 max_rows_per_file=MAX_ROWS_PER_FILE, max_total_rows=MAX_TOTAL_ROWS,
                 max_run_dirs=MAX_RUN_DIRS):
    """The paired report for leg engine "<parent>-t2cal" on one book (venue, symbol) under
    run_root; never raises on file content."""
    if not identifier(engine) or not engine.endswith(LEG_SUFFIX) or len(engine) <= len(LEG_SUFFIX):
        raise ValueError(f"engine must be an identifier ending in {LEG_SUFFIX!r}")
    if not isinstance(symbol, str) or not symbol or not isinstance(venue, str) or not venue:
        raise ValueError("venue and symbol must be non-empty strings")
    for name, value in (("max_file_bytes", max_file_bytes), ("max_total_bytes", max_total_bytes),
                        ("max_rows_per_file", max_rows_per_file), ("max_total_rows", max_total_rows),
                        ("max_run_dirs", max_run_dirs)):
        if type(value) is not int or value < 1:
            raise ValueError(f"{name} must be a positive integer")
    parent = engine[:-len(LEG_SUFFIX)]
    reader = _Reader(max_file_bytes, max_total_bytes, max_rows_per_file, max_total_rows)
    diagnostics = _Diagnostics()
    coverage = _Coverage()
    parent_book, leg_book = _Book(), _Book()
    refusals = []
    disturbance = Counter()
    runs = {"selected": 0, "matched": 0, "other_book": 0, "cut": 0}
    parent_last = [None]
    run_parent_full = {}  # run dir name -> its parent ledger was read in full (or is absent)
    # leg: every leg-side row in scope was read and parsed; rows: no row in any file was skipped;
    # scope: the run root itself was listed (an absent or unreadable root proves no zero)
    read_all = {"leg": True, "rows": True, "scope": True}
    try:
        run_dirs, runs["cut"] = _run_dirs(run_root, max_run_dirs, diagnostics)
    except OSError:
        run_dirs = []
        diagnostics.note(str(run_root), None, "unreadable_run_root")
        read_all["scope"] = read_all["leg"] = False
        coverage.gap()
    runs["selected"] = len(run_dirs)
    if runs["cut"]:
        reader.truncated = True
        read_all["leg"] = False
        diagnostics.note(str(run_root), None, "run_dirs_cut", n=runs["cut"])

    def read(path, label, handler, open_run):
        """(read status, whether any row was skipped) for one bounded ledger read."""
        before = diagnostics.skipped_rows
        lines, status = reader.lines(path, diagnostics, label, open_run=open_run)
        _consume(lines, label, diagnostics, handler)
        skipped = diagnostics.skipped_rows > before
        if skipped:
            read_all["rows"] = False
        return status, skipped

    def parent_row(row, file_ts):
        kind = row["kind"]
        if kind == PARENT_REFUSAL_KIND:
            _parent_refusal_row(row, engine, parent)
            disturbance["parent_refusals"] += 1
            return
        if kind not in _TICKET_KINDS:
            return  # decisions, adopts and other ledgers' kinds are not tickets
        try:  # every ticket row in the file bounds what the file covers, whoever's it is
            ts = _timestamp(row, settled=kind in _OUTCOME_KINDS)
        except CellRejected:
            ts = None
        if ts is not None:
            file_ts.append(ts)
        named = _engine(row, None)
        if named == engine:
            disturbance["leg_rows_in_parent_ledger"] += 1  # the in-book leak v2 and v3 had
            return
        if named != parent:
            return  # another engine's book (a hedge twin); not this leg's parent
        parent_book.add(row, named, None)

    def leg_row(row, run):
        kind = row["kind"]
        if kind == REFUSAL_KIND:
            refusals.append(_refusal_row(row, engine))
            return
        if kind == PARENT_REFUSAL_KIND:
            _parent_refusal_row(row, engine, parent)
            disturbance["parent_refusals"] += 1
            return
        if kind not in _TICKET_KINDS:
            raise CellRejected("unknown_kind")  # never silently ignored in the leg's own rows
        if _engine(row, None) != engine:
            raise CellRejected("engine_mismatch")
        leg_book.add(row, engine, run)

    def journal_row(row, run):
        if row["kind"] not in (REFUSAL_KIND, PARENT_REFUSAL_KIND):
            raise CellRejected("unknown_kind")
        leg_row(row, run)

    with localcontext() as context:
        context.prec = 120  # owner_live_ledger.build_ledger's precision, for identical episodes
        # Newest run dirs first, so a spent budget drops the oldest history, never the newest.
        newer_leftover = False  # a crash leftover newer than a run means that run has ended
        for name in run_dirs:
            run = Path(run_root) / name
            try:
                if not _run_identity_matches(run, venue, symbol):
                    runs["other_book"] += 1
                    continue  # another book's, or a paper run's, ledgers never feed this report
            except (Exception, RecursionError) as exc:  # one run's failure never hides the others
                missing = isinstance(exc, FileNotFoundError)
                if missing and _crash_leftover(run, engine):
                    newer_leftover = True
                    continue  # died before config.json and wrote no ledger: nothing unread here
                diagnostics.note(f"{name}/config.json", None,
                                 "run_config_missing" if missing else "run_config_refused")
                coverage.gap()  # the run may have been this book's
                read_all["leg"] = False  # and its leg-side rows went unread
                continue
            runs["matched"] += 1
            # only this book's newest run may still be writing; any older run's ledger is closed
            open_run = runs["matched"] == 1 and not newer_leftover
            file_ts = []
            status, skipped = read(run / INCUMBENT_TICKETS, f"{name}/{INCUMBENT_TICKETS}",
                                   lambda row: parent_row(row, file_ts), open_run)
            run_parent_full[name] = status in ("full", "absent") and not skipped
            if file_ts:
                parent_last[0] = max(file_ts) if parent_last[0] is None else max(parent_last[0], max(file_ts))
            if skipped or status == "skipped":
                coverage.gap()  # a skipped row may be the parent's, anywhere in this file
            elif status == "cut":
                coverage.gap(min(file_ts) if file_ts else None)
            for ts in file_ts:
                coverage.seen(ts)
            probe = run / f"probe-{engine}"
            try:
                probe_info = os.lstat(probe)
            except FileNotFoundError:
                continue
            except OSError:
                diagnostics.note(f"{name}/probe-{engine}", None, "unreadable_file")
                read_all["leg"] = False
                continue
            if not stat.S_ISDIR(probe_info.st_mode):
                diagnostics.note(f"{name}/probe-{engine}", None, "non_regular_probe_dir")
                read_all["leg"] = False
                continue
            for file_name, handler in ((PROBE_TICKETS, leg_row), (REFUSAL_JOURNAL, journal_row)):
                status, skipped = read(probe / file_name, f"{name}/probe-{engine}/{file_name}",
                                       lambda row, handler=handler, name=name: handler(row, name), open_run)
                if skipped or status not in ("full", "absent"):
                    read_all["leg"] = False  # a cut, skipped or unparsed leg row may be an orphan
        if runs["cut"]:
            coverage.gap()
        parent_tickets = parent_book.tickets(diagnostics, "parent")
        leg_tickets = leg_book.tickets(diagnostics, "leg")
        parent_unjoined, unjoined_markets, unjoined_unnamed = parent_book.unjoined()
        leg_unjoined = leg_book.unjoined()[0]
        if parent_unjoined:
            diagnostics.note("parent", None, "unjoined_parent_outcome", n=parent_unjoined)
        if leg_unjoined:
            read_all["leg"] = False  # an outcome whose entry went unread may be an orphan's
            diagnostics.note("leg", None, "unjoined_leg_outcome", n=leg_unjoined)
        for label, book in (("parent", parent_book), ("leg", leg_book)):
            if book.entry_conflicts:
                diagnostics.note(label, None, "duplicate_entry_conflict", n=book.entry_conflicts)
        if leg_book.market_conflicts:
            read_all["leg"] = False  # the leg entry kept may hide another market's orphan

        parent_groups = _group(parent_tickets)
        leg_groups = _group(leg_tickets)
        parent_markets = {(k[0], k[1]) for k in parent_groups}
        paired, orphans, unverifiable = [], Counter(), 0
        for key in sorted(leg_groups, key=lambda k: (k[1], k[0], k[2])):
            if key in parent_groups:
                paired.append(key)
            elif _verifiable(leg_groups[key], coverage, unjoined_markets, unjoined_unnamed, parent_last[0],
                             run_parent_full):
                reason = "opposite_side" if (key[0], key[1]) in parent_markets else "no_parent_ticket"
                orphans[reason] += len(leg_groups[key])
            else:
                unverifiable += len(leg_groups[key])
        parent_paired, leg_paired, per_pair_diff = [], [], []
        paired_parent_tickets, paired_leg_tickets = [], []
        open_pairs = conflict_pairs = 0
        for key in paired:
            states = (_group_state(parent_groups[key]), _group_state(leg_groups[key]))
            if "conflict" in states:
                conflict_pairs += 1  # the leg is paired; its contradicting net is never counted
                continue
            if "open" in states:
                open_pairs += 1
                continue
            p, g = _settled_sum(parent_groups[key]), _settled_sum(leg_groups[key])
            parent_paired.append(p)
            leg_paired.append(g)
            if p[1] > 0 and g[1] > 0:
                per_pair_diff.append(g[0] / g[1] - p[0] / p[1])
            paired_parent_tickets.extend(parent_groups[key])
            paired_leg_tickets.extend(leg_groups[key])

        refused_markets = set()
        refusal_reasons = Counter()
        for ticker, window, _bucket, reason in refusals:
            refusal_reasons[reason] += 1
            refused_markets.add((ticker, window))
        admitted, refused, unevaluated = [], [], []
        excluded_conflict = 0
        for key in sorted(parent_groups, key=lambda k: (k[1], k[0], k[2])):
            state = _group_state(parent_groups[key])
            if state == "conflict":
                excluded_conflict += 1
                continue
            if state == "open":
                continue
            settled = _settled_sum(parent_groups[key])
            if key in leg_groups:
                admitted.append(settled)
            elif (key[0], key[1]) in refused_markets:
                refused.append(settled)
            else:
                unevaluated.append(settled)
        mean_diff = (None if not per_pair_diff else
                     round(float(sum(per_pair_diff, Decimal(0)) / len(per_pair_diff)), 4))

    latched, latched_source = _latched(lifecycle_dir, engine, diagnostics, bool(leg_tickets or leg_unjoined))
    dist = {"parent_refusals": disturbance["parent_refusals"], "latched": latched,
            "leg_rows_in_parent_ledger": disturbance["leg_rows_in_parent_ledger"]}
    # parent refusals and leaked leg rows live in both ledgers: zero is proven only by reading all
    dist["reads_zero"] = _reads_zero(list(dist.values()), read_all["scope"] and read_all["leg"]
                                     and read_all["rows"] and coverage.complete)
    dist["latched_source"] = latched_source
    orphan_n = sum(orphans.values())

    def count(tickets, status):
        return sum(1 for t in tickets if t["status"] == status)

    return {
        "schema": SCHEMA,
        "engine": engine,
        "parent": parent,
        "venue": venue,
        "symbol": symbol,
        "min_n": MIN_N,
        "run_dirs": runs,
        "pairs": {"pairs_n": len(paired), "settled_n": len(leg_paired), "open_n": open_pairs,
                  "conflict_n": conflict_pairs, "label": _label(len(leg_paired)),
                  "parent": _figure(parent_paired), "leg": _figure(leg_paired),
                  "per_pair": {"n": len(per_pair_diff), "mean_leg_minus_parent_per_contract_cents": mean_diff,
                               "label": _label(len(per_pair_diff))}},
        "orphans": {"n": orphan_n, "by_reason": dict(sorted(orphans.items())),
                    "unverifiable_truncated": unverifiable,
                    "reads_zero": _reads_zero([orphan_n], read_all["scope"] and read_all["leg"]
                                              and not unverifiable)},
        "selection": {"admitted": _figure(admitted), "refused": _figure(refused),
                      "unevaluated": _figure(unevaluated), "excluded_conflict_n": excluded_conflict},
        "hit_rate": {"basis": "entry_price", "win": "side_won", "quantile": _QUANTILE,
                     "leg": _hit_rates(paired_leg_tickets), "parent": _hit_rates(paired_parent_tickets)},
        "refusals": {"n": sum(refusal_reasons.values()), "by_reason": dict(sorted(refusal_reasons.items())),
                     "label": _label(sum(refusal_reasons.values()))},
        "disturbance": dist,
        "tickets": {"leg_n": len(leg_tickets), "leg_settled_n": count(leg_tickets, "settled"),
                    "leg_conflict_n": count(leg_tickets, "conflict"), "leg_unjoined_outcomes": leg_unjoined,
                    "parent_n": len(parent_tickets), "parent_settled_n": count(parent_tickets, "settled"),
                    "parent_conflict_n": count(parent_tickets, "conflict"),
                    "parent_unjoined_outcomes": parent_unjoined},
        "reader": {"bytes_read": reader.bytes_read, "rows_read": reader.rows_read, "files_read": reader.files_read,
                   "max_total_bytes": max_total_bytes, "max_total_rows": max_total_rows,
                   "truncated": reader.truncated,
                   "parent_history": {"complete": coverage.complete,
                                      "from_ms": None if coverage.complete else coverage.from_ms}},
        "diagnostics": diagnostics.document(),
    }


def _cents(value):
    return "n/a" if value is None else f"{value}c"


def _zero(value):
    return "unproven" if value is None else str(value)


def _text_summary(report):
    pairs = report["pairs"]
    parent, leg = pairs["parent"], pairs["leg"]
    orphans, dist = report["orphans"], report["disturbance"]
    lines = [f"{report['engine']} (parent {report['parent']}, {report['venue']} {report['symbol']}): "
             f"pairs_n={pairs['pairs_n']} settled={pairs['settled_n']} open={pairs['open_n']} "
             f"conflict={pairs['conflict_n']} [{pairs['label']}]",
             f"  per-contract net, mean per pair: parent {_cents(parent['mean_per_contract_net_cents'])}, "
             f"leg {_cents(leg['mean_per_contract_net_cents'])}; pooled by contracts: parent "
             f"{_cents(parent['pooled_per_contract_net_cents'])}, leg {_cents(leg['pooled_per_contract_net_cents'])} "
             f"(n={pairs['settled_n']})"]
    for name in ("admitted", "refused", "unevaluated"):
        fig = report["selection"][name]
        lines.append(f"  parent {name}: mean {_cents(fig['mean_per_contract_net_cents'])} "
                     f"pooled {_cents(fig['pooled_per_contract_net_cents'])} n={fig['n']} [{fig['label']}]")
    latched = "unread" if dist["latched"] is None else dist["latched"]
    lines.append(f"  violations: orphans={orphans['n']} unverifiable={orphans['unverifiable_truncated']} "
                 f"orphans_zero={_zero(orphans['reads_zero'])} parent_refusals={dist['parent_refusals']} "
                 f"latched={latched} ({dist['latched_source']}) disturbance_zero={_zero(dist['reads_zero'])}")
    lines.append(f"  refusals={report['refusals']['n']} truncated={str(report['reader']['truncated']).lower()} "
                 f"skipped_rows={report['diagnostics']['skipped_rows']}")
    return "\n".join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(prog="python -m leafhft.calibrated_leg_report",
                                     description="Paired report for a calibrated '<parent>-t2cal' leg.")
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--engine", required=True, help="the leg engine id, '<parent>-t2cal'")
    parser.add_argument("--symbol", required=True, help="the book's symbol, as its run config.json names it")
    parser.add_argument("--venue", default="kalshi")
    parser.add_argument("--lifecycle-dir", default=None, help="read the leg's latch from its lifecycle record")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    try:
        report = build_report(args.run_root, args.engine, symbol=args.symbol, venue=args.venue,
                              lifecycle_dir=args.lifecycle_dir)
    except ValueError as exc:
        print(f"calibrated_leg_report: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(report, indent=2, sort_keys=True) if args.json else _text_summary(report))
    return 0


if __name__ == "__main__":
    sys.exit(main())
