"""Root-only, document-only deployment authority. No live book reads this store.

All mutations serialize on writer.lock. ENABLED and CONTAINMENT are checked
before input access and publication. Importing this module performs no I/O.
"""
from __future__ import annotations

import base64
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import sys
import time

from .safe_read import SafeReadError, read_regular
from .tuning_plan_v2 import (BOOKS, LEVERAGES, MAX_PLAN_BYTES, MAX_POLICY_BYTES,
                             PlanV2Error, canonical_bytes, compute_effects,
                             decode_plan_v2, envelope_digest)

PUBLISHED = Path("/etc/leafhft-deployments")
STATE = Path("/var/lib/leafhft-deployments")
LEGACY_ENGINES = Path("/etc/leafhft/engines")
LEGACY_MANIFESTS = Path("/etc/leafhft/engine-manifests")
LEGACY_ACCOUNTS = Path("/etc/leafhft-accounts")
CONTAINMENT = Path("/etc/leafhft/CONTAINMENT")
SCHEMA = "leafhft.deployments.v1"
MAX_DOCUMENT_BYTES = 2 * 1024 * 1024
MAX_RECORD_BYTES = 8 * 1024 * 1024
RECOVERY_LIMIT = 64
_SHA = r"[0-9a-f]{64}"
_TX = r"[0-9a-f]{32}"
_ID = r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}"
_REQUEST = r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}"
_CLAIM = "plan_sha256 proposal_id plan_seq account runner_nonce"
_PREPARED = ("tx_id request_id approval_id plan_sha256 change_sha256 assertion_sha256 claim "
             "account expected_generation resulting_generation before_document_sha256 "
             "after_document after_document_sha256 catalog_writes")


class DeploymentRefused(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def _require(condition, code):
    if not condition:
        raise DeploymentRefused(code)


def _root():
    _require(os.name != "posix" or os.geteuid() == 0, "not_root")


def _match(value, pattern):
    return type(value) is str and re.fullmatch(pattern, value) is not None


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _closed(doc, fields, code="invalid_document"):
    _require(type(doc) is dict and set(doc) == set(fields.split()), code)


def _json(raw, limit=MAX_RECORD_BYTES):
    _require(type(raw) is bytes and len(raw) <= limit, "invalid_document")

    def pairs(items):
        result = {}
        for key, value in items:
            _require(key not in result, "invalid_document")
            result[key] = value
        return result

    def number(_):
        raise DeploymentRefused("invalid_document")

    try:
        doc = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                         parse_float=number, parse_constant=number)
        canonical_bytes(doc)
        return doc
    except (ValueError, UnicodeError, RecursionError):
        raise DeploymentRefused("invalid_document") from None


def decode_document(raw):
    doc = _json(raw, MAX_DOCUMENT_BYTES)
    _closed(doc, "schema account registry_account generation paused books_off rows catalog "
            "last_tx_id prev_document_sha256")
    _require(doc["schema"] == SCHEMA and _match(doc["account"], r"[0-9a-f]{8}") and
             doc["registry_account"] == "owner", "invalid_document")
    _require(type(doc["generation"]) is int and 0 <= doc["generation"] < 2**53 and
             type(doc["paused"]) is bool, "invalid_document")
    _require(type(doc["books_off"]) is list and all(type(b) is str and b in BOOKS
             for b in doc["books_off"]) and doc["books_off"] == sorted(set(doc["books_off"])),
             "invalid_document")
    _require(type(doc["catalog"]) is list and len(doc["catalog"]) <= 16384,
             "invalid_document")
    catalog = {}
    for entry in doc["catalog"]:
        _closed(entry, "engine_id policy_sha256")
        _require(_match(entry["engine_id"], _ID) and _match(entry["policy_sha256"], _SHA),
                 "invalid_document")
        catalog[entry["engine_id"]] = entry["policy_sha256"]
    _require([e["engine_id"] for e in doc["catalog"]] == sorted(catalog), "invalid_document")
    _require(type(doc["rows"]) is list and len(doc["rows"]) <= 16384, "invalid_document")
    keys = []
    for row in doc["rows"]:
        _closed(row, "engine book leverage on changed_at_ms approval_id")
        _require(_match(row["engine"], _ID) and row["engine"] in catalog and
                 type(row["book"]) is str and row["book"] in BOOKS and
                 type(row["leverage"]) is int and row["leverage"] in LEVERAGES and
                 type(row["on"]) is bool and type(row["changed_at_ms"]) is int and
                 0 <= row["changed_at_ms"] < 2**53 and _match(row["approval_id"], _SHA),
                 "invalid_document")
        keys.append((row["book"], row["engine"]))
    _require(keys == sorted(set(keys)), "invalid_document")
    _require((doc["last_tx_id"] is None and doc["prev_document_sha256"] is None) or
             (_match(doc["last_tx_id"], _TX) and _match(doc["prev_document_sha256"], _SHA)),
             "invalid_document")
    _require(raw == canonical_bytes(doc), "invalid_document")
    return doc


def _read(root, name, *, limit=MAX_RECORD_BYTES, optional=False, legacy=False):
    try:
        return read_regular(root, name, max_bytes=limit,
                            expect_uid=None if legacy or os.name != "posix" else 0,
                            forbid_group_other_write=not legacy)
    except SafeReadError as exc:
        if optional and exc.code == "missing":
            return None
        raise DeploymentRefused(exc.code) from None


def _exists(path):
    # lstat deliberately treats a broken symlink as present (fail closed).
    try:
        path.lstat()
        return True
    except FileNotFoundError:
        return False


def _enabled(published):
    _require(_read(published, "ENABLED", limit=1024, optional=True) is not None,
             "deployments_disabled")


def _uncontained(containment):
    _require(not _exists(Path(containment)), "deployments_contained")


def _directory(path, mode, *, create=False):
    created = False
    if create:
        try:
            path.mkdir(mode=mode, parents=False)
            created = True
        except FileExistsError:
            pass
    info = path.lstat()
    _require(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode), "unsafe_directory")
    if os.name == "posix":
        _require(info.st_uid == 0, "unsafe_directory")
        if created:
            fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
            try:
                os.fchmod(fd, mode)  # Executor UMask=0077 must not hide published documents.
            finally:
                os.close(fd)
        else:
            _require(stat.S_IMODE(info.st_mode) == mode, "unsafe_directory")
    if created:
        _fsync_dir(path)
        _fsync_dir(path.parent)


def _fsync_dir(path):
    if os.name != "posix":
        return
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _atomic(path, raw, mode=0o600):
    temporary = path.with_name("." + path.name + "." + secrets.token_hex(16))
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                 getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0), mode)
    try:
        if os.name == "posix":
            os.fchmod(fd, mode)
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        _fsync_dir(path.parent)
    finally:
        if _exists(temporary):
            temporary.unlink()


def _write_json(path, value, mode=0o600):
    _atomic(path, canonical_bytes(value), mode)


@contextmanager
def _lock(published, state, *, initialize=False):
    _directory(published, 0o755, create=initialize)
    _directory(state, 0o700, create=initialize)
    fd = os.open(state / "writer.lock", os.O_RDWR | os.O_CREAT |
                 getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0), 0o600)
    try:
        info = os.fstat(fd)
        _require(stat.S_ISREG(info.st_mode) and (os.name != "posix" or
                 (info.st_uid == 0 and stat.S_IMODE(info.st_mode) == 0o600)), "unsafe_lock")
        if os.name == "posix":
            import fcntl
            fcntl.flock(fd, fcntl.LOCK_EX)
        else:
            import msvcrt
            if info.st_size == 0:
                os.write(fd, b"0")
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_LOCK, 1)
        os.fsync(fd)
        _fsync_dir(state)
        for name in ("tx", "consumed", "requests", "pending", "quarantine"):
            _directory(state / name, 0o700, create=initialize)
        _directory(published / "catalog", 0o755, create=initialize)
        yield
    finally:
        os.close(fd)


def init_deployments(account, *, published=PUBLISHED, state=STATE):
    _root()
    _require(_match(account, r"[0-9a-f]{8}"), "account_mismatch")
    published, state = Path(published), Path(state)
    doc = dict(schema=SCHEMA, account=account, registry_account="owner", generation=0,
               paused=False, books_off=[], rows=[], catalog=[], last_tx_id=None,
               prev_document_sha256=None)
    raw = canonical_bytes(doc)
    with _lock(published, state, initialize=True):
        previous = _read(published, "owner.json", optional=True)
        _require(previous is None or previous == raw, "document_exists")
        if previous is None:
            _atomic(published / "owner.json", raw, 0o644)
        _fsync_dir(state)
    return doc


def project_baseline(document, books):
    catalog = {e["engine_id"]: e["policy_sha256"] for e in document["catalog"]}
    return dict(paused=document["paused"],
                books=[dict(book=b, book_off=b in document["books_off"]) for b in sorted(books)],
                rows=[dict(book=r["book"], engine=r["engine"], leverage=r["leverage"], on=r["on"],
                           engine_policy_digest=catalog[r["engine"]])
                      for r in document["rows"] if r["book"] in books])


def _entries(path, limit=4096):
    if not _exists(path):
        return []
    info = path.lstat()
    _require(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode), "unsafe_directory")
    result = []
    with os.scandir(path) as entries:
        for entry in entries:
            _require(len(result) < limit, "scan_limit")
            result.append(Path(entry.path))
    return sorted(result)


def _other_accounts(plan, published, accounts):
    engines = {e["engine"] for e in plan["catalog"]} | {i["engine"] for i in plan["items"]}
    # Only account document names participate; envelope/provenance files and
    # other published artifacts are not deployment documents.
    for path in _entries(published):
        if not _match(path.name, r"[0-9a-f]{8}\.json"):
            continue
        raw = _read(published, path.name, limit=MAX_DOCUMENT_BYTES)
        if raw is not None:
            other = decode_document(raw)
            _require(other["account"] == plan["account"] or
                     not engines.intersection(r["engine"] for r in other["rows"]),
                     "engine_on_other_account")
    for account in _entries(accounts, 128):
        if account.name == plan["account"]:
            continue
        _require(_match(account.name, r"[0-9a-f]{8}"), "invalid_bindings")
        for filename in ("owner.json", "kalshi-engine-bindings.json", "probe-bindings.json"):
            raw = _read(accounts, account.name + "/" + filename, optional=True, legacy=True)
            if raw is None:
                continue
            if filename == "owner.json":
                used = {r["engine"] for r in decode_document(raw)["rows"]}
            else:
                doc = _json(raw)
                if filename == "probe-bindings.json":
                    from .probe_bindings import _decode
                    try:
                        used = {e for rows in _decode(raw).symbols.values() for e in rows}
                    except ValueError:
                        raise DeploymentRefused("invalid_bindings") from None
                else:
                    _require(type(doc) is dict and set(doc) in (
                        {"default", "symbols"}, {"default", "symbols", "disabled"}) and
                        type(doc["symbols"]) is dict, "invalid_bindings")
                    used = list(doc["symbols"].values()) + [doc["default"]]
                    _require(all(e is None or _match(e, _ID) for e in used), "invalid_bindings")
            _require(not engines.intersection(used), "engine_on_other_account")


def _legacy_policy(raw, engine):
    """Decode the legacy Engine wrapper without using its path-based loader.

    Legacy catalog digests identify the policy, not the Engine metadata JSON.
    Bare policy bytes are also accepted for catalogs already materialized in
    the document format. The signed digest still pins their exact bytes.
    """
    def pairs(items):
        result = {}
        for key, value in items:
            _require(key not in result, "invalid_catalog")
            result[key] = value
        return result

    def bad_number(_):
        raise DeploymentRefused("invalid_catalog")

    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_constant=bad_number)
        _require(type(value) is dict, "invalid_catalog")
        if "engine_id" not in value:
            return raw
        from .policy import OPTIONAL_POLICY_BOUNDS, POLICY_BOUNDS, _validate_field
        fields = "engine_id name description policy version parent_engine_id created_at updated_at"
        _closed(value, fields + (" enabled" if "enabled" in value else ""), "invalid_catalog")
        _require(value["engine_id"] == engine and type(value["policy"]) is dict, "invalid_catalog")
        policy = value["policy"]
        bounds = {**POLICY_BOUNDS, **OPTIONAL_POLICY_BOUNDS}
        _require(set(POLICY_BOUNDS) <= set(policy) <= set(bounds), "invalid_catalog")
        for key, number in policy.items():
            if key not in OPTIONAL_POLICY_BOUNDS or number is not None:
                _validate_field(key, number, *bounds[key])
        policy = {k: v for k, v in policy.items() if not (k in OPTIONAL_POLICY_BOUNDS and v is None)}
        # Do not instantiate KalshiPolicy: its constructor clamps values using
        # the process risk regime, which could silently change the owner digest.
        return json.dumps(policy, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=True, allow_nan=False).encode("ascii")
    except (ValueError, TypeError, KeyError, UnicodeError, RecursionError):
        raise DeploymentRefused("invalid_catalog") from None


def _manifest(engine, digest, manifests):
    from .engine_manifest import MAX_MANIFEST_BYTES, ManifestInvalid, manifest_from_mapping

    raw = _read(manifests, engine + ".json", limit=MAX_MANIFEST_BYTES, optional=True, legacy=True)
    _require(raw is not None, "manifest_missing")
    try:
        manifest = manifest_from_mapping(_json(raw), expected_engine_id=engine)
    except (ManifestInvalid, DeploymentRefused):
        raise DeploymentRefused("manifest_invalid") from None
    _require(manifest.kernel["kind"] == "policy" and
             manifest.kernel["policy_engine_id"] == engine and
             manifest.kernel["policy_digest"] == digest, "manifest_invalid")


def _external(plan, change, document, published, legacy_engines, legacy_accounts, manifests,
              *, pending=False):
    _require(plan["account"] == document["account"], "account_mismatch")
    _require(_sha(change) == plan["change_sha256"], "change_mismatch")
    _require(plan["expected_generation"] == document["generation"], "generation_conflict")
    books = (set(BOOKS) if any(c["scope"] == "account" for c in plan["controls"]) else
             {b["book"] for b in plan["baseline"]["books"]})
    _require(canonical_bytes(project_baseline(document, books)) ==
             canonical_bytes(plan["baseline"]), "baseline_mismatch")
    envelope = _read(published, "account-envelope.json", optional=True)
    _require(envelope is not None, "envelope_missing")
    _require(envelope_digest(_json(envelope)) == plan["envelope"]["digest"], "envelope_mismatch")
    catalog = {e["engine_id"]: e["policy_sha256"] for e in document["catalog"]}
    writes = []
    creates = {i["engine"] for i in plan["items"] if i["kind"] == "create"}
    for item in plan["items"]:
        if item["kind"] == "create":
            engine = item["engine"]
            existing = _read(published, "catalog/" + engine + ".json", optional=True)
            # Recovery may resume after this transaction published its catalog
            # bytes but before the owner-document replacement.
            _require(engine not in catalog and (existing is None or
                     (pending and existing == base64.b64decode(item["policy_bytes"], validate=True)))
                     and not _exists(legacy_engines / (engine + ".json")), "immutable_engine")
            _require(item["parent"] not in creates, "immutable_engine")
    policies = {}
    for entry in plan["catalog"]:
        engine, digest = entry["engine"], entry["engine_policy_digest"]
        raw = _read(published, "catalog/" + engine + ".json", limit=MAX_POLICY_BYTES, optional=True)
        if raw is None:
            raw = _legacy_policy(_read(legacy_engines, engine + ".json",
                                      limit=MAX_POLICY_BYTES, legacy=True), engine)
        _require(_sha(raw) == digest and catalog.get(engine, digest) == digest, "immutable_engine")
        policies[engine] = raw
        _manifest(engine, digest, manifests)
    for item in plan["items"]:
        if item["kind"] != "create":
            continue
        parent = policies[item["parent"]]
        _require(_sha(parent) == item["parent_policy_digest"], "immutable_engine")
        from .engine_ops import resolve_variant_policy
        try:
            resolved = resolve_variant_policy(json.loads(parent), item["set"])
        except (ValueError, TypeError, KeyError, OverflowError, RecursionError):
            raise DeploymentRefused("create_policy_mismatch") from None
        _require(resolved == base64.b64decode(item["policy_bytes"], validate=True),
                 "create_policy_mismatch")
        writes.append(dict(engine_id=item["engine"], policy_bytes=item["policy_bytes"],
                           sha256=item["policy_digest"]))
    _other_accounts(plan, published, legacy_accounts)
    # Reproduce intent from the exact authenticated request, before preparing or
    # consuming anything. Identity, clocks and sizing remain the signed plan's;
    # baseline, policies and envelope are independently read local authority.
    from .deployment_change import ChangeRefused, catalog_reader, decode_change, derive
    try:
        request = decode_change(change)
    except ChangeRefused as exc:
        raise DeploymentRefused(exc.code) from None
    lookup = catalog_reader(published / "catalog", legacy_engines)
    try:
        # The prepared transaction may have published its exact create bytes.
        # Those bytes were checked above; reproduce intent against the original
        # absence rather than treating our partial publication as a collision.
        derived = derive(request, document,
                         lambda engine: None if pending and engine in creates else lookup(engine),
                         _json(envelope), plan["sizing_basis"], plan, plan)
    except (ChangeRefused, PlanV2Error, DeploymentRefused):
        raise DeploymentRefused("change_plan_mismatch") from None
    _require(all(canonical_bytes(derived[key]) == canonical_bytes(plan[key])
                 for key in ("controls", "items", "baseline", "catalog")), "change_plan_mismatch")
    return writes


def _after(document, plan, approval_id, tx_id, before_hash, now_ms):
    after = _json(canonical_bytes(document))
    rows = {(r["book"], r["engine"]): r for r in after["rows"]}
    catalog = {e["engine_id"]: e["policy_sha256"] for e in after["catalog"]}
    for entry in plan["catalog"]:
        catalog[entry["engine"]] = entry["engine_policy_digest"]
    off = set(after["books_off"])
    for control in plan["controls"]:
        if control["scope"] == "account":
            after["paused"] = control["to"]
        elif control["to"]:
            off.add(control["book"])
        else:
            off.discard(control["book"])
    for item in plan["items"]:
        if item["kind"] == "create":
            catalog[item["engine"]] = item["policy_digest"]
        else:
            rows[item["book"], item["engine"]] = dict(
                engine=item["engine"], book=item["book"], **item["to"],
                changed_at_ms=now_ms, approval_id=approval_id)
    # Controls also change the effective state of rows not named by deploys.
    for effect in plan["effects"]:
        key = effect["book"], effect["engine"]
        if key in rows and effect["effect"] != "neutral":
            rows[key].update(changed_at_ms=now_ms, approval_id=approval_id)
    after.update(rows=[rows[key] for key in sorted(rows)], books_off=sorted(off),
                 catalog=[dict(engine_id=e, policy_sha256=catalog[e]) for e in sorted(catalog)],
                 generation=plan["resulting_generation"], last_tx_id=tx_id,
                 prev_document_sha256=before_hash)
    return decode_document(canonical_bytes(after))


def _boundary(step):
    """Crash-injection seam; production performs no work here."""


def _result(record):
    return dict(ok=True, tx_id=record["tx_id"], approval_id=record["approval_id"],
                proposal_id=record["claim"]["proposal_id"], plan_seq=record["claim"]["plan_seq"],
                resulting_generation=record["resulting_generation"],
                document_sha256=record["after_document_sha256"])


def _identity(record):
    return {key: record[key] for key in ("account", "plan_sha256", "change_sha256",
                                         "assertion_sha256", "tx_id", "claim")}


def _record(record, state):
    result = _result(record)
    committed = dict(tx_id=record["tx_id"], result=result)
    _write_json(state / "tx" / record["tx_id"] / "committed.json", committed)
    _boundary("record")
    index = dict(_identity(record), result=result)
    previous = _read(state, "requests/" + record["request_id"], optional=True)
    _require(previous is None or previous == canonical_bytes(index), "request_conflict")
    _write_json(state / "requests" / record["request_id"], index)
    _remove_pending(record, state)
    return result


def _remove_pending(record, state):
    path = state / "pending" / record["request_id"]
    raw = _read(state, "pending/" + record["request_id"], limit=64, optional=True)
    if raw is not None:
        _require(raw == record["tx_id"].encode("ascii"), "request_conflict")
        path.unlink()
        _fsync_dir(path.parent)


def _pending_record(state, request_id):
    _require(_match(request_id, _REQUEST), "invalid_request_id")
    raw = _read(state, "pending/" + request_id, limit=64, optional=True)
    if raw is None:
        return None
    _require(re.fullmatch(rb"[0-9a-f]{32}", raw) is not None, "invalid_transaction")
    record = _load_prepared(state, raw.decode("ascii"))
    _require(record["request_id"] == request_id, "request_conflict")
    return record


def _commit(record, published, containment=CONTAINMENT):
    # The approval is already spent. needs_recovery keeps the executor's active
    # claim intact if containment arrives after consumption.
    try:
        _uncontained(containment)
        _enabled(published)
    except DeploymentRefused as exc:
        if exc.code == "deployments_contained":
            raise DeploymentRefused("needs_recovery") from None
        if exc.code == "deployments_disabled":
            return dict(ok=False, code="deferred_disabled", tx_id=record["tx_id"])
        raise
    before = _read(published, "owner.json", limit=MAX_DOCUMENT_BYTES)
    _require(_sha(before) == record["before_document_sha256"], "generation_conflict")
    for write in record["catalog_writes"]:
        raw = base64.b64decode(write["policy_bytes"], validate=True)
        existing = _read(published, "catalog/" + write["engine_id"] + ".json", optional=True)
        _require(existing is None or existing == raw, "immutable_engine")
        if existing is None:
            _atomic(published / "catalog" / (write["engine_id"] + ".json"), raw, 0o644)
    # Catalog publication may be interrupted. Equal bytes are idempotent, and
    # rows become visible together in the single owner-document replacement.
    try:
        _uncontained(containment)
        _enabled(published)
    except DeploymentRefused as exc:
        if exc.code == "deployments_contained":
            raise DeploymentRefused("needs_recovery") from None
        if exc.code == "deployments_disabled":
            return dict(ok=False, code="deferred_disabled", tx_id=record["tx_id"])
        raise
    _require(_sha(_read(published, "owner.json", limit=MAX_DOCUMENT_BYTES)) ==
             record["before_document_sha256"], "generation_conflict")
    _atomic(published / "owner.json", canonical_bytes(record["after_document"]), 0o644)
    _boundary("commit")
    return None


def apply_deployment(plan_bytes, change_bytes, assertion_bytes, claim, request_id, *,
                     now_ms, runner_host, code_sha, published=PUBLISHED, state=STATE,
                     legacy_engines=LEGACY_ENGINES, legacy_accounts=LEGACY_ACCOUNTS,
                     manifests=LEGACY_MANIFESTS, containment=CONTAINMENT):
    _root()
    published, state = Path(published), Path(state)
    _uncontained(containment)
    _enabled(published)
    _require(_read(published, "owner.json", limit=MAX_DOCUMENT_BYTES, optional=True) is not None,
             "deployments_uninitialized")
    with _lock(published, state):
        _uncontained(containment)
        _enabled(published)
        before = _read(published, "owner.json", limit=MAX_DOCUMENT_BYTES, optional=True)
        _require(before is not None, "deployments_uninitialized")
        document = decode_document(before)
        _require(_match(request_id, _REQUEST), "invalid_request_id")
        _closed(claim, _CLAIM, "claim_mismatch")
        for raw in (plan_bytes, change_bytes, assertion_bytes):
            _require(type(raw) is bytes and len(raw) <= MAX_PLAN_BYTES, "input_too_large")
        identity = dict(account=claim["account"], plan_sha256=_sha(plan_bytes),
                        change_sha256=_sha(change_bytes), assertion_sha256=_sha(assertion_bytes), claim=claim)
        previous = _read(state, "requests/" + request_id, optional=True)
        if previous is not None:
            index = _json(previous)
            _closed(index, "account plan_sha256 change_sha256 assertion_sha256 claim tx_id result", "request_conflict")
            _require(all(canonical_bytes(index[k]) == canonical_bytes(v) for k, v in identity.items()) and
                     _match(index["tx_id"], _TX), "request_conflict")
            record = _load_prepared(state, index["tx_id"])
            _require(record["request_id"] == request_id and _identity(record) ==
                     {**identity, "tx_id": index["tx_id"]}, "request_conflict")
            _require(_committed(record, state) and canonical_bytes(index["result"]) ==
                     canonical_bytes(_result(record)), "request_conflict")
            return index["result"]
        # A crash may precede the final request index. The durable prepared
        # record already reserves the request, including before consumption.
        pending = _pending_record(state, request_id)
        if pending is not None:
            _require(all(canonical_bytes(pending[k]) == canonical_bytes(v)
                         for k, v in identity.items()), "request_conflict")
            if _committed(pending, state):
                return _record(pending, state)
            raise DeploymentRefused("needs_recovery")
        try:
            plan = decode_plan_v2(plan_bytes)
            compute_effects(plan)
            from .tuning_presence import PresenceRefused, verify_deployment_decision
            verified_authorization = verify_deployment_decision(assertion_bytes, plan_bytes, now_ms=now_ms,
                runner_host=runner_host, code_sha=code_sha, first_bind=True)
        except PlanV2Error as exc:
            raise DeploymentRefused(exc.code) from None
        except PresenceRefused as exc:
            raise DeploymentRefused(exc.reason) from None
        _require(claim["account"] == plan["account"] == document["account"], "account_mismatch")
        verified_claim = {k: verified_authorization[k] for k in _CLAIM.split() if k != "runner_nonce"}
        verified_claim["runner_nonce"] = plan["runner_nonce"]
        _require(canonical_bytes(claim) == canonical_bytes(verified_claim), "claim_mismatch")
        approval_id = verified_authorization["approval_id"]
        _require(_read(state, "consumed/" + approval_id, optional=True) is None, "approval_consumed")
        writes = _external(plan, change_bytes, document, published,
                           Path(legacy_engines), Path(legacy_accounts), Path(manifests))
        tx_id = secrets.token_hex(16)
        after = _after(document, plan, approval_id, tx_id, _sha(before), now_ms)
        record = dict(identity, tx_id=tx_id, request_id=request_id, approval_id=approval_id,
                      expected_generation=plan["expected_generation"], resulting_generation=plan["resulting_generation"],
                      before_document_sha256=_sha(before), after_document=after,
                      after_document_sha256=_sha(canonical_bytes(after)), catalog_writes=writes)
        directory = state / "tx" / tx_id
        directory.mkdir(mode=0o700)
        _fsync_dir(directory.parent)
        for name, raw in (("plan.bin", plan_bytes), ("change.bin", change_bytes), ("assertion.bin", assertion_bytes)):
            _atomic(directory / name, raw)
        # Root-generated predecessor bytes make bounded ancestry walks possible
        # without scanning all transactions or trusting generation alone.
        _atomic(directory / "before-document.json", before)
        _write_json(directory / "prepared.json", record)
        _atomic(state / "pending" / request_id, tx_id.encode("ascii"))
        _boundary("prepare")
        marker = state / "consumed" / approval_id
        try:
            fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
        except FileExistsError:
            raise DeploymentRefused("approval_consumed") from None
        with os.fdopen(fd, "wb") as stream:
            stream.write(tx_id.encode("ascii"))
            stream.flush()
            os.fsync(stream.fileno())
        _fsync_dir(marker.parent)
        _boundary("consume")
        deferred = _commit(record, published, containment)
        return deferred if deferred is not None else _record(record, state)


def _load_prepared(state, tx_id):
    _require(_match(tx_id, _TX), "invalid_transaction")
    record = _json(_read(state, "tx/" + tx_id + "/prepared.json"))
    _closed(record, _PREPARED, "invalid_transaction")
    _closed(record["claim"], _CLAIM, "invalid_transaction")
    _require(record["tx_id"] == tx_id and _match(record["request_id"], _REQUEST), "invalid_transaction")
    for key in ("approval_id", "plan_sha256", "change_sha256", "assertion_sha256",
                "before_document_sha256", "after_document_sha256"):
        _require(_match(record[key], _SHA), "invalid_transaction")
    inputs = {}
    for name in ("plan", "change", "assertion"):
        raw = _read(state, "tx/" + tx_id + "/" + name + ".bin", limit=MAX_PLAN_BYTES)
        _require(_sha(raw) == record[name + "_sha256"], "invalid_transaction")
        inputs[name] = raw
    plan = decode_plan_v2(inputs["plan"])
    _require(plan["change_sha256"] == record["change_sha256"], "invalid_transaction")
    claim = {k: plan[k] for k in _CLAIM.split() if k != "plan_sha256"}
    claim["plan_sha256"] = record["plan_sha256"]
    _require(canonical_bytes(claim) == canonical_bytes(record["claim"]), "invalid_transaction")
    authorization_fields = {k: plan[k] for k in ("proposal_id", "plan_seq", "account",
                                           "expected_generation", "resulting_generation")}
    authorization_fields["plan_sha256"] = record["plan_sha256"]
    _require(record["approval_id"] == _sha(canonical_bytes(authorization_fields)), "invalid_transaction")
    after_raw = canonical_bytes(record["after_document"])
    after = decode_document(after_raw)
    _require(record["account"] == plan["account"] == after["account"] and
             type(record["expected_generation"]) is int and
             record["expected_generation"] == plan["expected_generation"] and
             type(record["resulting_generation"]) is int and
             record["resulting_generation"] == plan["resulting_generation"] == after["generation"] and
             after["last_tx_id"] == tx_id and
             after["prev_document_sha256"] == record["before_document_sha256"] and
             _sha(after_raw) == record["after_document_sha256"], "invalid_transaction")
    writes = [dict(engine_id=i["engine"], policy_bytes=i["policy_bytes"], sha256=i["policy_digest"])
              for i in plan["items"] if i["kind"] == "create"]
    _require(canonical_bytes(record["catalog_writes"]) == canonical_bytes(writes), "invalid_transaction")
    before_raw = _read(state, "tx/" + tx_id + "/before-document.json", limit=MAX_DOCUMENT_BYTES)
    before = decode_document(before_raw)
    _require(_sha(before_raw) == record["before_document_sha256"] and
             before["account"] == record["account"] and
             before["generation"] == record["expected_generation"], "invalid_transaction")
    changed_keys = {(i["book"], i["engine"]) for i in plan["items"] if i["kind"] == "deploy"}
    changed_keys.update((e["book"], e["engine"]) for e in plan["effects"]
                        if e["book"] and e["effect"] != "neutral")
    timestamps = {r["changed_at_ms"] for r in after["rows"] if (r["book"], r["engine"]) in changed_keys}
    _require(len(timestamps) <= 1, "invalid_transaction")
    derived = _after(before, plan, record["approval_id"], tx_id, record["before_document_sha256"],
                     next(iter(timestamps), 0))
    _require(canonical_bytes(derived) == after_raw, "invalid_transaction")
    return record


def _consumed(record, state):
    raw = _read(state, "consumed/" + record["approval_id"], limit=64, optional=True)
    if raw is None:
        return False
    _require(raw == record["tx_id"].encode("ascii"), "approval_consumed")
    return True


def _committed(record, state):
    raw = _read(state, "tx/" + record["tx_id"] + "/committed.json", optional=True)
    if raw is None:
        return False
    _require(canonical_bytes(_json(raw)) == canonical_bytes(dict(tx_id=record["tx_id"], result=_result(record))) and
             _consumed(record, state), "invalid_transaction")
    return True


def _status(record, state):
    raw = _read(state, "tx/" + record["tx_id"] + "/status.json", optional=True)
    if raw is None:
        return None
    result = _json(raw)
    _closed(result, "state reason", "invalid_transaction")
    _require(result["state"] in ("superseded_unapplied", "needs_operator") and
             type(result["reason"]) is str, "invalid_transaction")
    return result


def _mark(record, state, status, reason):
    _write_json(state / "tx" / record["tx_id"] / "status.json", dict(state=status, reason=reason))
    return dict(tx_id=record["tx_id"], state=status)


def _ancestor(record, document, state):
    """True = proven applied, False = proven disjoint, None = incomplete chain.

    Each edge must hash to the complete stored after-document and descend by
    exactly one generation. Missing evidence and the 64-step limit are never
    interpreted as proof of non-application.
    """
    current = document
    for _ in range(RECOVERY_LIMIT):
        digest = _sha(canonical_bytes(current))
        if digest == record["after_document_sha256"]:
            return True
        if current["generation"] <= record["resulting_generation"]:
            return False
        if current["last_tx_id"] is None:
            return False
        try:
            tip = _load_prepared(state, current["last_tx_id"])
            if tip["after_document_sha256"] != digest or not _consumed(tip, state):
                return None
            previous = tip["before_document_sha256"]
            if previous == record["after_document_sha256"]:
                return True
            parent_raw = _read(state, "tx/" + tip["tx_id"] + "/before-document.json",
                               limit=MAX_DOCUMENT_BYTES, optional=True)
            if parent_raw is None or _sha(parent_raw) != previous:
                return None
            parent = decode_document(parent_raw)
            if parent["generation"] != current["generation"] - 1 or parent["account"] != current["account"]:
                return None
            current = parent
        except (DeploymentRefused, PlanV2Error, OSError):
            return None
    return None


def recover(*, published=PUBLISHED, state=STATE, containment=CONTAINMENT, now_ms=None,
            legacy_engines=LEGACY_ENGINES, legacy_accounts=LEGACY_ACCOUNTS,
            manifests=LEGACY_MANIFESTS):
    _root()
    published, state = Path(published), Path(state)
    # Disabled recovery is entirely read-only, including indexes and cleanup.
    if _exists(Path(containment)) or not _exists(published / "ENABLED"):
        return []
    _enabled(published)
    outcomes = []
    with _lock(published, state):
        # Bound enumeration itself, not just work after enumerating history.
        from itertools import islice
        with os.scandir(state / "pending") as entries:
            pending_paths = sorted(Path(entry.path) for entry in islice(entries, RECOVERY_LIMIT))
        for pending_path in pending_paths:
            if _exists(Path(containment)) or not _exists(published / "ENABLED"):
                break
            directory = None
            try:
                raw = _read(state, "pending/" + pending_path.name, limit=64)
                _require(re.fullmatch(rb"[0-9a-f]{32}", raw) is not None, "invalid_transaction")
                directory = state / "tx" / raw.decode("ascii")
                _directory(directory, 0o700)
                record = _pending_record(state, pending_path.name)
                consumed = _consumed(record, state)
                committed = _committed(record, state)
                status = _status(record, state)
            except (DeploymentRefused, PlanV2Error, OSError, ValueError, KeyError, TypeError):
                # Rename the entry itself; never recurse through corrupt links.
                source = directory if directory is not None and _exists(directory) else pending_path
                destination = state / "quarantine" / source.name
                if _exists(destination):
                    destination = destination.with_name(source.name + "-" + secrets.token_hex(8))
                os.replace(source, destination)
                _fsync_dir(source.parent)
                _fsync_dir(destination.parent)
                if source != pending_path:
                    pending_path.unlink()
                    _fsync_dir(pending_path.parent)
                print("deployments alarm: quarantined transaction " + source.name, file=sys.stderr)
                outcomes.append(dict(tx_id=source.name, state="quarantined"))
                continue
            if not consumed:
                shutil.rmtree(directory)
                _fsync_dir(directory.parent)
                _remove_pending(record, state)
                outcomes.append(dict(tx_id=record["tx_id"], state="discarded"))
                continue
            if committed:
                _record(record, state)
                outcomes.append(dict(tx_id=record["tx_id"], state="committed"))
                continue
            before = _read(published, "owner.json", limit=MAX_DOCUMENT_BYTES)
            document = decode_document(before)
            if _sha(before) == record["after_document_sha256"]:
                _record(record, state)
                outcomes.append(dict(tx_id=record["tx_id"], state="committed"))
            elif status is not None:
                outcomes.append(dict(tx_id=record["tx_id"], state=status["state"]))
            elif _sha(before) == record["before_document_sha256"]:
                plan = decode_plan_v2(_read(state, "tx/" + record["tx_id"] + "/plan.bin",
                                             limit=MAX_PLAN_BYTES))
                moment = time.time_ns() // 1_000_000 if now_ms is None else now_ms
                if plan["expires_at_ms"] <= moment:
                    outcomes.append(_mark(record, state, "needs_operator", "expired_pending"))
                    continue
                try:
                    change = _read(state, "tx/" + record["tx_id"] + "/change.bin", limit=MAX_PLAN_BYTES)
                    _external(plan, change, document, published, Path(legacy_engines),
                              Path(legacy_accounts), Path(manifests), pending=True)
                except (DeploymentRefused, PlanV2Error, OSError, ValueError, KeyError, TypeError) as exc:
                    outcomes.append(_mark(record, state, "needs_operator",
                                          getattr(exc, "code", "input_unreadable")))
                    continue
                moment = time.time_ns() // 1_000_000 if now_ms is None else now_ms
                if plan["expires_at_ms"] <= moment:
                    outcomes.append(_mark(record, state, "needs_operator", "expired_pending"))
                    continue
                try:
                    deferred = _commit(record, published, containment)
                except DeploymentRefused as exc:
                    if exc.code != "needs_recovery":
                        raise
                    outcomes.append(dict(tx_id=record["tx_id"], state="consumed"))
                    break
                if deferred is None:
                    _record(record, state)
                    outcomes.append(dict(tx_id=record["tx_id"], state="committed"))
                else:
                    outcomes.append(dict(tx_id=record["tx_id"], state="consumed"))
            else:
                ancestor = _ancestor(record, document, state)
                if ancestor is True:
                    _record(record, state)
                    outcomes.append(dict(tx_id=record["tx_id"], state="committed"))
                elif ancestor is False and document["generation"] > record["resulting_generation"]:
                    outcomes.append(_mark(record, state, "superseded_unapplied", "disjoint_document_chain"))
                else:
                    outcomes.append(_mark(record, state, "needs_operator", "unproven_document_chain"))
    return outcomes


def inspect(*, published=PUBLISHED, state=STATE):
    _root()
    state = Path(state)
    result = []
    for directory in _entries(state / "tx"):
        try:
            record = _load_prepared(state, directory.name)
            status = _status(record, state)
            phase = ("committed" if _committed(record, state) else status["state"] if status else
                     "consumed" if _consumed(record, state) else "prepared")
        except (DeploymentRefused, PlanV2Error, OSError, ValueError, KeyError, TypeError):
            phase = "needs_operator"
        result.append(dict(tx_id=directory.name, state=phase))
    result.extend(dict(tx_id=p.name, state="quarantined") for p in _entries(state / "quarantine"))
    return result


def settle(tx_id, *, finalize=False, abandon=False, reason="", confirmed_ancestor=False,
           published=PUBLISHED, state=STATE):
    _root()
    _require(_match(tx_id, _TX) and type(finalize) is bool and type(abandon) is bool and
             finalize != abandon, "invalid_settlement")
    _require(type(reason) is str and 0 < len(reason) <= 300 and
             all(32 <= ord(c) <= 126 for c in reason), "settlement_reason_required")
    published, state = Path(published), Path(state)
    _enabled(published)
    with _lock(published, state):
        _enabled(published)
        record = _load_prepared(state, tx_id)
        status = _status(record, state)
        _require(_consumed(record, state) and not _committed(record, state) and
                 (abandon or (status is not None and status["state"] == "needs_operator")),
                 "not_needs_operator")
        raw = _read(published, "owner.json", limit=MAX_DOCUMENT_BYTES)
        document = decode_document(raw)
        ancestor = _ancestor(record, document, state)
        if finalize:
            _require(_sha(raw) == record["after_document_sha256"] or ancestor is True or
                     (confirmed_ancestor is True and document["account"] == record["account"] and
                      document["generation"] > record["resulting_generation"]), "finalize_unproven")
            _write_json(state / "tx" / tx_id / "settlement.json",
                        dict(action="finalize", reason=reason, confirmed_ancestor=confirmed_ancestor))
            return _record(record, state)
        _require(ancestor is not True and _sha(raw) != record["after_document_sha256"], "already_applied")
        # Abandon means no future commit; it does not claim the transaction was
        # never applied. Keep needs_operator plus the explicit settlement audit.
        result = _mark(record, state, "needs_operator", "abandoned:" + reason)
        _write_json(state / "tx" / tx_id / "settlement.json", dict(action="abandon", reason=reason))
        return result


def apply_transaction_directory(directory, *, published=PUBLISHED, state=STATE,
                                legacy_engines=LEGACY_ENGINES, legacy_accounts=LEGACY_ACCOUNTS,
                                manifests=LEGACY_MANIFESTS, containment=CONTAINMENT):
    """Operator CLI ingress: signed inputs and claim from one private directory.

    Clock and identity come from the same process clock, protected executor
    config and build metadata used by tuning_execute, never transaction input.
    """
    _root()
    _uncontained(containment)
    _enabled(Path(published))
    _require(_read(published, "owner.json", limit=MAX_DOCUMENT_BYTES, optional=True) is not None,
             "deployments_uninitialized")
    directory = Path(directory)
    _directory(directory, 0o700)
    context = _json(_read(directory, "context.json"))
    _closed(context, "claim request_id", "invalid_context")
    from .tuning_execute import load_config
    from .build import build_identity
    try:
        config = load_config(Path("/etc/leafhft-tuning/executor.json"))
        identity = build_identity()
        _require(_match(identity.get("git_sha"), r"[0-9a-f]{40}") and
                 not identity.get("dirty"), "trusted_identity_unavailable")
        runner_host, code_sha = config["runner_host"], identity["git_sha"]
    except (OSError, ValueError, KeyError, TypeError):
        raise DeploymentRefused("trusted_identity_unavailable") from None
    inputs = [_read(directory, name + ".bin", limit=MAX_PLAN_BYTES)
              for name in ("plan", "change", "assertion")]
    return apply_deployment(*inputs, **context, now_ms=time.time_ns() // 1_000_000,
                            runner_host=runner_host, code_sha=code_sha, published=published, state=state,
                            legacy_engines=legacy_engines, legacy_accounts=legacy_accounts,
                            manifests=manifests, containment=containment)


def run_command(args):
    """Separate dispatch keeps existing engine_ops handlers and receipts untouched."""
    try:
        _root()
        if args.deploy_verb == "init":
            result = init_deployments(args.account)
        elif args.deploy_verb == "apply":
            result = apply_transaction_directory(args.input_directory)
        elif args.deploy_verb == "recover":
            result = recover()
        elif args.deploy_verb == "inspect":
            result = inspect()
        else:
            result = settle(args.tx_id, finalize=args.finalize, abandon=args.abandon,
                            reason=args.reason, confirmed_ancestor=args.confirmed_ancestor)
        print(json.dumps(result, sort_keys=True))
        return 0 if not isinstance(result, dict) or result.get("ok", True) else 2
    except (DeploymentRefused, PlanV2Error) as exc:
        print("refused: " + exc.code, file=sys.stderr)
        return 2
