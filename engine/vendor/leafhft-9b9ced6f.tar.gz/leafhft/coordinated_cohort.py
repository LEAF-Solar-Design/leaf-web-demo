"""Immutable owner snapshot and future-engine selection for coordinated testers."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile

from .coordinated_signal import ContractError, _reject_constant, _unique_object

OWNER_LANE = "e6216739-a5c2-4a10-9457-c2b52a96288a"
FREEZE_PATH = Path("/etc/leafhft-signal-authority/cohort-freeze.json")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def decode(raw):
    """The one strict decoder: duplicate keys and non-finite numbers are refused."""
    return json.loads(raw, object_pairs_hook=_unique_object, parse_constant=_reject_constant)


def read_bytes(path, limit=262144):
    path = Path(path)
    if path.is_symlink():
        raise ContractError("symlink cohort input")
    with path.open("rb") as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ContractError("cohort input too large")
    return raw


def lane_id(value):
    if type(value) is not str or re.fullmatch(
            r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", value) is None:
        raise ContractError("invalid cohort lane")
    return value


def binding_books(binding):
    """Every canonical book and the engine ID the binding assigns to it."""
    from .feeds.kalshi import SYMBOL_MAP
    return {symbol: binding["symbols"].get(symbol, binding["default"]) for symbol in SYMBOL_MAP}


@dataclass(frozen=True)
class CohortFreeze:
    """Only immutable bytes are retained; validated views are computed once."""

    raw: bytes

    def __post_init__(self):
        if type(self.raw) is not bytes or len(self.raw) > 262144:
            raise ContractError("invalid immutable cohort bytes")
        from .engines import Engine, _id
        from .feeds.kalshi import SYMBOL_MAP
        from .policy import policy_from_mapping
        value = decode(self.raw)
        if type(value) is not dict or set(value) != {
                "schema", "owner_lane_id", "tester_lane_ids", "binding_bytes",
                "binding_digest", "engines"}:
            raise ContractError("invalid cohort freeze fields")
        if (value["schema"] != "leafhft.cohort-freeze.v1"
                or value["owner_lane_id"] != OWNER_LANE):
            raise ContractError("invalid cohort owner")
        testers = value["tester_lane_ids"]
        if (type(testers) is not list or len(testers) != 3
                or len(set(map(lane_id, testers))) != 3 or OWNER_LANE in testers):
            raise ContractError("freeze requires three distinct tester lanes")
        binding = value["binding_bytes"]
        if type(binding) is not str or digest(binding.encode()) != value["binding_digest"]:
            raise ContractError("binding digest mismatch")
        binding = decode(binding)
        if (type(binding) is not dict or set(binding) not in (
                {"default", "symbols"}, {"default", "symbols", "disabled"})
                or type(binding["symbols"]) is not dict
                or set(binding["symbols"]) - set(SYMBOL_MAP)
                or binding.get("disabled", []) != []):
            raise ContractError("freeze requires all fourteen enabled books")
        engines = value["engines"]
        if type(engines) is not dict or len(engines) != 9:
            raise ContractError("freeze requires nine baseline engines")
        for eid, document in engines.items():
            _id(eid)
            if type(document) is not dict or set(document) != {"bytes", "digest"}:
                raise ContractError("invalid baseline document")
            if type(document["bytes"]) is not str or digest(document["bytes"].encode()) != document["digest"]:
                raise ContractError("baseline digest mismatch")
            engine = decode(document["bytes"])
            if type(engine) is not dict:
                raise ContractError("invalid baseline engine")
            engine = Engine(**(engine | {"policy": policy_from_mapping(engine["policy"])}))
            if engine.engine_id != eid or not engine.enabled:
                raise ContractError("baseline engine must be enabled")
        books = binding_books(binding)
        if len(books) != 14 or any(eid not in engines for eid in books.values()):
            raise ContractError("freeze book binding mismatch")
        object.__setattr__(self, "_testers", tuple(testers))
        object.__setattr__(self, "_baseline", frozenset(engines))
        object.__setattr__(self, "_digest", digest(self.raw))

    @property
    def document(self):
        return decode(self.raw)

    @property
    def digest(self):
        return self._digest

    @property
    def testers(self):
        return self._testers

    @property
    def baseline(self):
        return self._baseline

    def role(self, lane):
        if lane == OWNER_LANE:
            return "owner"
        if lane in self._testers:
            return "tester"
        raise ContractError("lane is outside frozen cohort")

    def admits(self, engine_id):
        return engine_id not in self._baseline


def load_freeze(path=FREEZE_PATH):
    return CohortFreeze(read_bytes(path))


_CACHE = {}


def cached_freeze(path=None):
    """Decode an immutable freeze once per stat identity; absence returns None.

    A single os.stat per call. A replaced or touched file has a new identity and
    is decoded again, so a cached copy can never outlive the bytes it came from.
    """
    path = Path(FREEZE_PATH if path is None else path)
    try:
        info = os.stat(path)
    except FileNotFoundError:
        _CACHE.pop(path, None)
        return None
    key = (info.st_dev, info.st_ino, info.st_mtime_ns, info.st_size)
    hit = _CACHE.get(path)
    if hit is not None and hit[0] == key:
        return hit[1]
    freeze = load_freeze(path)
    _CACHE.clear()  # bounded: one live freeze path per process
    _CACHE[path] = (key, freeze)
    return freeze


def capture_freeze(bindings_path, engines_dir, testers):
    """Capture exact bytes, then reject concurrent changes before publication."""
    from .engines import EngineRegistry
    registry = EngineRegistry(engines_dir)
    engines = registry.list()
    if registry.problems:
        raise ContractError("invalid baseline catalog")
    binding_bytes = read_bytes(bindings_path, 4096)
    selected = {engine.engine_id: read_bytes(registry.path_for(engine.engine_id), 8192)
                for engine in engines if engine.enabled}
    value = {"schema": "leafhft.cohort-freeze.v1", "owner_lane_id": OWNER_LANE,
             "tester_lane_ids": sorted(testers), "binding_bytes": binding_bytes.decode(),
             "binding_digest": digest(binding_bytes),
             "engines": {eid: {"bytes": raw.decode(), "digest": digest(raw)}
                         for eid, raw in selected.items()}}
    frozen = CohortFreeze(canonical(value))
    if (read_bytes(bindings_path, 4096) != binding_bytes
            or {e.engine_id for e in registry.list() if e.enabled} != set(selected)
            or registry.problems
            or any(read_bytes(registry.path_for(eid), 8192) != raw for eid, raw in selected.items())):
        raise ContractError("baseline changed during capture")
    return frozen


def publish_freeze(freeze, path):
    """Publish the complete snapshot once; never replace an existing freeze.

    The hard link is the commit. The writable temporary name is removed before
    the final name is made read-only, so no platform is left with an
    undeletable read-only temporary file.
    """
    path = Path(path)
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix=".cohort-")
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(freeze.raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)
    finally:
        os.unlink(temporary)
    os.chmod(path, 0o444)
    if os.name == "posix":
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)


def owner_paths(freeze, root):
    """Verify the read-only owner materialization before using its paths."""
    root = Path(root) / "owner"
    document = freeze.document
    bindings = root / "engine-bindings.json"
    engines = root / "engines"
    if digest(read_bytes(bindings)) != document["binding_digest"]:
        raise ContractError("owner binding changed")
    for eid, row in document["engines"].items():
        if digest(read_bytes(engines / (eid + ".json"))) != row["digest"]:
            raise ContractError("owner engine changed")
    return str(bindings), str(engines)


def selected_books(freeze, bindings_path, engines_dir):
    """Re-read evolving tester bindings; baseline IDs can never be admitted."""
    from .engines import Engine, EngineRegistry, _id
    from .feeds.kalshi import SYMBOL_MAP
    from .policy import policy_digest, policy_document, policy_from_mapping
    registry = EngineRegistry(engines_dir)
    before = read_bytes(bindings_path, 4096)
    document = decode(before)
    if (type(document) is not dict or set(document) not in (
            {"default", "symbols"}, {"default", "symbols", "disabled"})
            or type(document["symbols"]) is not dict
            or set(document["symbols"]) - set(SYMBOL_MAP)):
        raise ContractError("invalid tester bindings")
    disabled = document.get("disabled", [])
    if (type(disabled) is not list or any(type(symbol) is not str for symbol in disabled)
            or len(disabled) != len(set(disabled)) or set(disabled) - set(SYMBOL_MAP)):
        raise ContractError("invalid disabled tester books")
    for eid in [document["default"], *document["symbols"].values()]:
        if eid is not None:
            _id(eid)
    books = {}
    for symbol, eid in binding_books(document).items():
        if eid is None or symbol in disabled or not freeze.admits(eid):
            continue
        raw = read_bytes(registry.path_for(eid), 8192)
        body = decode(raw)
        engine = Engine(**(body | {"policy": policy_from_mapping(body["policy"])}))
        if engine.engine_id != eid:
            raise ContractError("engine ID mismatch")
        if raw != read_bytes(registry.path_for(eid), 8192):
            raise ContractError("engine changed during selection")
        if engine.enabled:
            books[symbol] = {"engine_id": eid, "engine_digest": digest(raw),
                             "policy": policy_document(engine.policy), "policy_digest": policy_digest(engine.policy)}
    if read_bytes(bindings_path, 4096) != before:
        raise ContractError("tester bindings changed during selection")
    return books


def local_entry_allowed(cfg):
    """The one send-boundary check for a local (non-coordinated) entry.

    Exits never call it. Cost is one os.stat; the freeze decodes once per file
    identity. The freeze's presence is the all-tester local-entry barrier and its
    removal restores every tester's local mode in one step. The owner is local by
    definition: a process started before the freeze (empty cohort_digest) keeps
    its entries, and a process bound to a digest refuses a different freeze.
    Fails closed on an unreadable or malformed freeze for everyone else.
    """
    lane = Path(cfg.authority_path).parent.name
    try:
        freeze = cached_freeze()
    except (OSError, ValueError, TypeError, KeyError, RecursionError):
        return lane == OWNER_LANE and not cfg.cohort_digest
    if freeze is None:
        return True
    if lane == OWNER_LANE:
        return not cfg.cohort_digest or cfg.cohort_digest == freeze.digest
    return lane not in freeze.testers and not cfg.cohort_digest
