"""Read-only account ledger adapter: tenant bytes cross through a private stage."""
from __future__ import annotations

import argparse
from contextlib import closing, contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import stat
import sys

from . import account_lane_agent as agent
from . import account_lane_sync as sync
from . import owner_live_ledger as ledger
from . import owner_live_mirror as mirror

UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
OUTPUT_ROOT = Path("/var/lib/leafhft-account-live")
BUCKET = "leaf-leafhft-tapes-807034087062-us-east-1"
PREFIX = "runner/account-live/v1"
ROOT_UID = 0
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_STAGE_BYTES = 256 * 1024 * 1024
MAX_ENTRIES = 10000
RUN_FILES = {"config.json", "kalshi-edge-status.json", "kalshi-tickets.jsonl",
             "kalshi-probe-tickets.jsonl"}


class AccountLedgerRefused(ValueError):
    """Static refusal messages, without tenant paths or file contents."""


def lane_uuid(value):
    if not isinstance(value, str) or UUID.fullmatch(value) is None:
        raise AccountLedgerRefused("full lane UUID required")
    return value


def resolve_lane(value):
    lane_id = lane_uuid(value)
    binding = sync._binding(lane_id)
    journal = agent.parse(agent.read_private(agent.CONFIG_ROOT / (lane_id + ".provision.json")))
    if (not isinstance(journal, dict) or journal.get("binding") != binding
            or journal.get("phase") not in ("registered", "complete")):
        raise AccountLedgerRefused("provisioned lane required")
    return agent.LanePaths(lane_id)


def _identity(info):
    return info.st_dev, info.st_ino


def _component(name):
    if not name or name in (".", "..") or any(c in name for c in ("/", "\\", "\0")):
        raise AccountLedgerRefused("path component refused")


@contextmanager
def _open_dir(path):
    """Open every component, including the anchor, without following links."""
    if os.name != "posix" or not hasattr(os, "O_NOFOLLOW"):
        raise AccountLedgerRefused("POSIX no-follow reads required")
    path = Path(path)
    if not path.is_absolute() or ".." in path.parts:
        raise AccountLedgerRefused("absolute contained path required")
    fd = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.parts[1:]:
            _component(part)
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        yield fd
    finally:
        os.close(fd)


def _private_dir(path):
    with _open_dir(path.parent) as parent:
        try:
            os.mkdir(path.name, 0o700, dir_fd=parent)
        except FileExistsError:
            pass
        fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        try:
            info = os.fstat(fd)
            if info.st_uid != ROOT_UID or stat.S_IMODE(info.st_mode) != 0o700:
                raise AccountLedgerRefused("private output directory required")
        finally:
            os.close(fd)


def _copy_file(parent, name, before, target, budget):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                or _identity(info) != _identity(before) or info.st_size > MAX_FILE_BYTES):
            raise AccountLedgerRefused("input file refused")
        digest = hashlib.sha256()
        with target.open("xb") as output:
            left = info.st_size
            while left:
                chunk = os.read(fd, min(left, 1024 * 1024))
                if not chunk:
                    raise AccountLedgerRefused("input shortened during copy")
                budget["bytes"] += len(chunk)
                if budget["bytes"] > MAX_STAGE_BYTES:
                    raise AccountLedgerRefused("stage byte limit exceeded")
                output.write(chunk)
                digest.update(chunk)
                left -= len(chunk)
        after = os.fstat(fd)
        current = os.stat(name, dir_fd=parent, follow_symlinks=False)
        if (after.st_nlink != 1 or _identity(current) != _identity(info)
                or after.st_size < info.st_size
                or (after.st_size == info.st_size and after.st_mtime_ns != info.st_mtime_ns)):
            raise AccountLedgerRefused("input changed during copy")
        # Status without at_ms uses mtime. Preserve it, never the copy time.
        os.utime(target, ns=(info.st_atime_ns, info.st_mtime_ns))
        return {"identity": list(_identity(info)), "size": info.st_size,
                "digest": digest.hexdigest()}
    except BaseException:
        target.unlink(missing_ok=True)
        raise
    finally:
        os.close(fd)


def stage_tree(source, target, *, catalog=False, budget=None):
    """Copy regular inputs via pinned descriptors; count rejected entries once."""
    budget = budget if budget is not None else {"bytes": 0, "entries": 0}
    sources = {}
    refused = 0

    def walk(parent, destination, depth):
        nonlocal refused
        for name in sorted(os.listdir(parent)):
            budget["entries"] += 1
            if budget["entries"] > MAX_ENTRIES:
                raise AccountLedgerRefused("stage entry limit exceeded")
            try:
                _component(name)
                info = os.stat(name, dir_fd=parent, follow_symlinks=False)
                if stat.S_ISDIR(info.st_mode):
                    if depth >= 2 or catalog:
                        raise AccountLedgerRefused("input depth refused")
                    child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
                    try:
                        if _identity(os.fstat(child)) != _identity(info):
                            raise AccountLedgerRefused("directory changed")
                        folder = destination / name
                        folder.mkdir(mode=0o700)
                        walk(child, folder, depth + 1)
                    finally:
                        os.close(child)
                elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                    raise AccountLedgerRefused("non-regular input refused")
                elif (name.endswith(".json") if catalog else name in RUN_FILES):
                    output = destination / name
                    sources[output] = _copy_file(parent, name, info, output, budget)
            except (OSError, AccountLedgerRefused):
                refused += 1

    try:
        with _open_dir(source) as root:
            walk(root, target, 0)
    except (OSError, AccountLedgerRefused):
        refused += 1
    return refused, sources


def _prefix_digest(path, size):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while size:
            chunk = stream.read(min(size, 1024 * 1024))
            if not chunk:
                return None
            digest.update(chunk)
            size -= len(chunk)
    return digest.hexdigest()


def _rebind_offsets(state, sources):
    """Rebind owner offsets to fresh copies only for unchanged source prefixes.

    The stage is wiped each run, so its inode alone is not an input identity.
    Commit the source mapping and offset identities together before ingestion;
    a crash before/after the owner's transaction can then resume either state.
    """
    with closing(sqlite3.connect(state / "ledger.sqlite3")) as db, db:
        db.execute("CREATE TABLE IF NOT EXISTS account_stage_sources (file TEXT PRIMARY KEY, data TEXT)")
        has_offsets = db.execute("SELECT 1 FROM sqlite_master WHERE name='offsets'").fetchone()
        for path, source in sources.items():
            if path.name not in ("kalshi-tickets.jsonl", "kalshi-probe-tickets.jsonl"):
                continue
            key = hashlib.sha256(str(path.resolve()).encode()).hexdigest()
            previous = db.execute("SELECT data FROM account_stage_sources WHERE file=?", (key,)).fetchone()
            previous = json.loads(previous[0]) if previous else None
            same = (previous is not None and previous["identity"] == source["identity"]
                    and previous["size"] <= source["size"]
                    and _prefix_digest(path, previous["size"]) == previous["digest"])
            if has_offsets:
                if same:
                    info = path.stat()
                    db.execute("UPDATE offsets SET identity=? WHERE file=?",
                               (f"{info.st_dev}:{info.st_ino}", key))
                else:
                    db.execute("DELETE FROM offsets WHERE file=?", (key,))
            db.execute("INSERT OR REPLACE INTO account_stage_sources VALUES (?, ?)",
                       (key, json.dumps(source, sort_keys=True)))


def _regular_export(tree):
    for path in tree.rglob("*"):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise AccountLedgerRefused("non-regular export refused")


def export_lane(lane_id, client, *, host, dry_run=False):
    lane_id = resolve_lane(lane_id).lane_id
    root = OUTPUT_ROOT / lane_uuid(lane_id)
    _private_dir(root)
    # systemd serializes each instance; the lock also protects manual invocations.
    with agent.exclusive(root / "export.lock"):
        state, out, stage = (root / name for name in ("state", "export", "stage"))
        for directory in (state, out, stage):
            _private_dir(directory)
        shutil.rmtree(stage)
        stage.mkdir(mode=0o700)
        runs, catalog = stage / "runs", stage / "engines"
        runs.mkdir(mode=0o700)
        catalog.mkdir(mode=0o700)
        budget = {"bytes": 0, "entries": 0}
        # Do not call LanePaths.state: its preflight rejects a tenant link before
        # the descriptor reader can account for it in ingestion.refused.
        source = agent.STATE_ROOT / lane_id
        refused, sources = stage_tree(source / "runs", runs, budget=budget)
        catalog_refused, _ = stage_tree(source / "engine-catalog" / "engines", catalog,
                                        catalog=True, budget=budget)
        _rebind_offsets(state, sources)
        result = ledger.build_ledger(runs, out, state)
        result["diagnostics"]["refused"] = refused + catalog_refused
        ledger._atomic(out / "ingestion.json", ledger.canonical(result["diagnostics"]))
        _regular_export(out)
        latest = f"{PREFIX}/{lane_id}/{host}/latest.json"

        class TrackedClient:
            published = False

            def put_object(self, **request):
                response = client.put_object(**request)
                if request["Key"] == latest:
                    self.published = True
                return response

        tracked = TrackedClient()
        status = mirror.mirror(out, tracked, host=host, bucket=BUCKET,
                               prefix=f"{PREFIX}/{lane_id}", engines_dir=catalog, dry_run=dry_run)
        # Owner mirror intentionally returns 0 for several best-effort failures.
        # Account unit health requires an actual latest pointer publication.
        if status != 0 or (not dry_run and not tracked.published):
            raise AccountLedgerRefused("account mirror did not publish")
        return result


def main(argv=None, *, client_factory=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lane", required=True)
    parser.add_argument("--host", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    try:
        lane_uuid(args.lane)
        if os.name != "posix" or os.geteuid() != ROOT_UID:
            raise AccountLedgerRefused("root exporter required")
        if client_factory is None:
            from scripts.owner_live_mirror import _S3Client
            client_factory = _S3Client
        export_lane(args.lane, client_factory(), host=args.host, dry_run=args.dry_run)
    except Exception as exc:
        print(f"account-live-ledger: refused ({type(exc).__name__})", file=sys.stderr)
        return 2
    return 0
