"""Versioned, fail-closed inputs for the frozen Gold evaluator. Paper only.

Every artifact is a frozen document whose SHA-256 joins the Gold generation
contract, so any change starts a new, separately scored generation. All
functions are pure: no network, clock, broker or feed access.
"""
from __future__ import annotations

import math

from . import paper_results as results
from .costs import DEFAULT_TAKER_MULTIPLIER, contract_fee_cents, order_fee_cents
from .gold_calendar import COVERAGE_MS, RELEASES, SOURCES, VERIFIED_ON
from .types import PRICE_UNIT

SERIES = 'KXGOLD15M'
REFERENCE = 'Metal.Index.1OZGOLD/USD'
CENT_I = PRICE_UNIT // 100

RULES = dict(
    version=1, series_ticker=SERIES, reference_ticker=REFERENCE,
    market_duration_ms=900_000, strike_type='greater_or_equal', settlement_decimals=2,
    settlement='Pyth 1-minute candle close at close time: the last reference tick with '
               'source_ts_ms < close_ms, compared with the market strike_i',
    official_settlement='strike_i of the contiguous next market, whose strike is the same '
                        'candle close', crosscheck_tolerance_cents=1, unsettled_expiry_ms=86_400_000,
    sightings='every lifecycle row echoes the recorder\'s latest REST discovery snapshot, so '
              'repeated reports of one value are a single source, not corroboration',
    settle_grace_ms=120_000, reconstruct_max_age_ms=10_000, mismatch_after_ms=600_000,
    reconstruction_broken_by='any stream disruption, an out-of-order reference tick, or a '
                             'revised close time; a last pre-close tick older than '
                             'reconstruct_max_age_ms is no cross-check at all',
    corroboration='a fresh reconstructed close agreeing with a reported value settles cleanly; '
                  'otherwise unanimous reports settle on Kalshi\'s value and are recorded as '
                  'uncrosschecked or disagreed, which destabilizes the lane; conflicting reports '
                  'with no agreeing cross-check by mismatch_after_ms are a mismatch',
    own_strike='the first reported strike, replaced when the latest discovery snapshot reports '
               'another value twice; a replacement is recorded and destabilizes the lane',
    disputes='a reconstructed or unverified settlement that a later report contradicts becomes '
             'disputed and counts as a loss; the lane stands down',
    reconstructed_fallback='only when no contiguous market appears within the delay and the '
                           'intact reconstructed close clears the strike by the margin',
    reconstructed_after_ms=1_800_000, reconstructed_margin_cents=50,
    setups=dict(A='enabled', B='disabled: its exit policy, minute closes and exit calibration '
                               'have no versioned artifacts'),
    journal='first evaluation per market, every reason change, every paper candidate')
# Gold moves ~0.034% a minute, a per-second variance near 2e-9 of price squared; the floor
# sits there so quiet stretches cannot shrink the model below ordinary volatility.
MODEL = dict(
    version=1, kind='driftless-gaussian-point-close', history_window_s=1800, min_history_s=1200,
    max_history_gap_s=30, coarse_step_s=30, recent_window_s=300, min_recent_s=120,
    variance_floor_frac_per_s=2e-9, variance_z=1.645,
    variance_inflation=3.0, no_side_margin_cents=1, probability_ceiling=0.995)
CALIBRATION = dict(
    version=1, window='a market counts once its first usable quote lands in the entry window',
    probe='the first quote in the entry window that meets the bucket and could trade (spread '
          'at most 2 cents, depth above zero), mirroring when an entry would fire',
    excluded='release blackout or an unhealthy feed; a settlement-mismatch stand-down pauses '
             'trading only', probe_window_s=[60, 180], min_resolved_windows=200,
    bucket_q_low=0.85, bucket_max_ask_cents=90, ask_tier_cents=10, q_low_bands=[0.85, 0.95],
    min_tier_n=50, min_tier_days=5, max_tier_days=32, probe_min_cycles=20,
    wilson_z=1.96, overhead_cents=2, empty_bucket_edge_cents=-100)
FEE = dict(
    version=1, fee_type='quadratic', fee_multiplier=1, taker_rate=str(DEFAULT_TAKER_MULTIPLIER),
    entry='one-contract taker fee rounded up', order='whole-order taker fee rounded up')
STABILITY = dict(
    version=1, quiet_after_disruption_s=300, settlement_mismatch_quiet_s=86_400,
    max_cycle_ms=5000, max_reference_gap_s=20, reference_gap_lookback_s=300)
ACCOUNT = dict(
    version=1, account_id='paper-default', capital_basis_cents=5000, day='UTC',
    fills='paper fills at the displayed touch; pending_entries is always 0',
    open_positions='candidates whose market has not closed',
    reserved='cost of every candidate without a recorded outcome; a position whose market '
             'expires or mismatches stays reserved permanently, as if lost',
    balance='capital basis plus realized P&L, floored at zero')
RELEASE_CALENDAR = dict(
    version=1, before_s=300, after_s=900, coverage_ms=list(COVERAGE_MS),
    verified_on=VERIFIED_ON, sources=dict(SOURCES), releases=[list(event) for event in RELEASES])
SETTLEMENT = dict(version=1, rules=results.sha256(RULES), outcome='win or loss from official strike',
                  profit='payout minus contracts times ask minus whole-order fee')

ARTIFACTS = dict(
    versioned_model=MODEL, versioned_calibration=CALIBRATION, versioned_account=ACCOUNT,
    versioned_fee=FEE, versioned_release_calendar=RELEASE_CALENDAR,
    versioned_stability=STABILITY, versioned_settlement=SETTLEMENT,
    versioned_rules_and_setup=RULES)
DIGESTS = {name: results.sha256(document) for name, document in ARTIFACTS.items()}
RULES_HASH = DIGESTS['versioned_rules_and_setup']
MODEL_VERSION = 'gold-close-gaussian-v1-' + DIGESTS['versioned_model'][:12]
_RELEASE_MS = tuple(sorted(event[0] for event in RELEASES))


def price_cents(price_i, *, up):
    """Fixed-point dollars to integer cents, rounded toward the conservative side."""
    whole, rest = divmod(price_i, CENT_I)
    return whole + (1 if up and rest else 0)


def entry_fee_cents(ask_cents):
    return contract_fee_cents(ask_cents)


def order_cost_cents(ask_cents, count):
    return count * ask_cents + order_fee_cents(ask_cents, count)


def _chi2_upper_factor(n):
    """Wilson-Hilferty one-sided upper bound on a variance estimated from n effective samples."""
    a = 2 / (9 * n)
    denominator = 1 - a - MODEL['variance_z'] * math.sqrt(a)
    return math.inf if denominator <= 0 else 1 / denominator ** 3


def history_variance(history):
    """[(variance rate in dollars squared per second, effective n)] at two scales, or None.

    history holds [second, value_i] pairs, the last reference value per second.
    A missing second means the price did not change, so squared moves over the
    covered span estimate the variance rate. Coverage gaps fail closed. The fine
    scale uses every increment with effective count span^2 / sum(gap^2); the
    coarse scale resamples at coarse_step_s so persistence that one-second
    moves understate still shows. q_low takes the larger upper bound.
    """
    if len(history) < 2:
        return None
    span = history[-1][0] - history[0][0]
    if span < MODEL['min_history_s']:
        return None
    total = gaps = 0.0
    for (s0, v0), (s1, v1) in zip(history, history[1:]):
        gap = s1 - s0
        if not 0 < gap <= MODEL['max_history_gap_s']:
            return None
        total += ((v1 - v0) / PRICE_UNIT) ** 2
        gaps += gap * gap
    step, points, index, value = MODEL['coarse_step_s'], [], 0, history[0][1]
    for second in range(history[0][0], history[-1][0] + 1, step):
        while index < len(history) and history[index][0] <= second:
            value = history[index][1]
            index += 1
        points.append(value)
    coarse = sum(((b - a) / PRICE_UNIT) ** 2 for a, b in zip(points, points[1:]))
    scales = [(total / span, span * span / gaps), (coarse / (step * (len(points) - 1)), len(points) - 1)]
    # A burst already under way shows in the last few minutes before the half hour catches up.
    recent = [pair for pair in history if pair[0] >= history[-1][0] - MODEL['recent_window_s']]
    recent_span = recent[-1][0] - recent[0][0]
    if recent_span >= MODEL['min_recent_s']:
        moves = sum(((v1 - v0) / PRICE_UNIT) ** 2 for (_, v0), (_, v1) in zip(recent, recent[1:]))
        squares = sum((s1 - s0) ** 2 for (s0, _), (s1, _) in zip(recent, recent[1:]))
        scales.append((moves / recent_span, recent_span * recent_span / squares))
    return scales


def q_low(side, reference_i, strike_i, scales, seconds_left, reference_age_s):
    """Conservative probability that side wins at the candle close.

    Each scale's variance rate is floored relative to price and raised to a
    one-sided upper confidence bound; the largest is inflated and applied over
    a horizon that includes the reference's age. YES ignores the favorable
    half-cent rounding and NO needs a full cent below the strike.
    """
    price, strike = reference_i / PRICE_UNIT, strike_i / PRICE_UNIT
    floor = MODEL['variance_floor_frac_per_s'] * price * price
    upper = max(max(rate, floor) * _chi2_upper_factor(n) for rate, n in scales)
    if not math.isfinite(upper):
        return 0.0
    sd = math.sqrt(upper * MODEL['variance_inflation']
                   * (max(seconds_left, 0) + max(reference_age_s, 0)))
    distance = (price - strike if side == 'yes'
                else strike - MODEL['no_side_margin_cents'] / 100 - price)
    probability = (1.0 if distance > 0 else 0.0) if sd == 0 else \
        0.5 * math.erfc(-distance / (sd * math.sqrt(2)))
    # Rounded so a last-bit libm difference in erfc cannot split replicas' state.
    return round(min(probability, MODEL['probability_ceiling']), 9)


def wilson_lower(wins, n, z=CALIBRATION['wilson_z']):
    if n <= 0:
        return 0.0
    p = wins / n
    center = p + z * z / (2 * n)
    margin = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return max(0.0, (center - margin) / (1 + z * z / n))


def ask_tier(ask_cents, q_low_value):
    """Calibration cell: the 10-cent ask tier and the q_low band, so neither cheap nor
    near-certain probes vouch for a dearer or more marginal quote."""
    band = sum(q_low_value >= edge for edge in CALIBRATION['q_low_bands']) - 1
    return '%d:%d' % ((ask_cents - 1) // CALIBRATION['ask_tier_cents'], band)


def in_bucket(probe):
    return (probe['q_low'] >= CALIBRATION['bucket_q_low']
            and probe['ask_cents'] <= CALIBRATION['bucket_max_ask_cents'])


def calibration_edge_cents(tier, cost_cents):
    """Lower 95% Wilson bound on one ask tier's hit rate, in cents, minus this quote's cost.

    Tiers keep cheap near-certain probes from vouching for expensive ones, and
    the live all-in cost keeps a tier's cheaper end from covering its dearer
    end. A tier with fewer than min_tier_n resolved probes stays closed.
    """
    n = tier['n'] if tier else 0
    # Adjacent windows share one price path; evidence must also span several days.
    if n < CALIBRATION['min_tier_n'] or len(tier.get('days', [])) < CALIBRATION['min_tier_days']:
        return float(CALIBRATION['empty_bucket_edge_cents'])
    return round(wilson_lower(tier['wins'], n) * 100 - cost_cents, 6)


def release_blackout(now_ms, close_ms):
    """True when [now, close] meets any release window or leaves calendar coverage."""
    start, end = COVERAGE_MS
    if not start <= now_ms <= end or close_ms > end:
        return True
    before, after = RELEASE_CALENDAR['before_s'] * 1000, RELEASE_CALENDAR['after_s'] * 1000
    return any(event - before <= close_ms and event + after >= now_ms for event in _RELEASE_MS)


def unstable(now_ms, last_disruption_ms, last_mismatch_ms, cycles, history):
    """True after a stream disruption or settlement mismatch, or on a thin feed."""
    s = STABILITY
    if last_disruption_ms is not None and now_ms - last_disruption_ms < s['quiet_after_disruption_s'] * 1000:
        return True
    if last_mismatch_ms is not None and now_ms - last_mismatch_ms < s['settlement_mismatch_quiet_s'] * 1000:
        return True
    if cycles and max(cycles) > s['max_cycle_ms']:
        return True
    now_s = now_ms // 1000
    recent = [second for second, _ in history if second >= now_s - s['reference_gap_lookback_s']]
    if not recent or now_s - recent[-1] > s['max_reference_gap_s']:
        return True
    return any(b - a > s['max_reference_gap_s'] for a, b in zip(recent, recent[1:]))


def settle(strike_i, official_i, crosscheck_i):
    """Official result, and whether the reconstructed candle close agrees with it."""
    result = 'yes' if official_i >= strike_i else 'no'
    if crosscheck_i is None:
        return result, None
    rounded = (crosscheck_i + CENT_I // 2) // CENT_I * CENT_I
    return result, abs(rounded - official_i) <= RULES['crosscheck_tolerance_cents'] * CENT_I
