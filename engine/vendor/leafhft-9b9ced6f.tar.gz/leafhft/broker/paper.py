"""Paper broker: fills against the live book with latency, queue position, slippage and an
adverse-selection haircut. Every rule below errs toward NOT filling; the residual optimism is named.

Fill rules (buy side shown; sell is mirrored). "Print" means a public trade.
  * Orders and cancels both arrive `latency_ms` after they are sent. A fill that lands before a
    cancel takes effect stands.
  * At arrival, MARKET / marketable LIMIT fills against DISPLAYED depth only: min(size, touch size)
    at touch plus `taker_slippage_bps`; a MARKET remainder gets one more level, assumed equal to the
    touch depth, one spread deeper; anything beyond is canceled "no displayed depth". Zero displayed
    depth means zero fill. Arrival against a quote older than `max_quote_age_ms` is rejected.
  * POST_ONLY that would cross at arrival is REJECTED. A non-marketable IOC is CANCELED at arrival.
  * Resting bid at P fills only on print evidence stamped at or after arrival:
      - a print below P (trade-through): fill min(remaining, print size)
      - a SELL-aggressor print at P: consumes queue ahead first, then us, only once our price has
        been observed as the best bid (queue position is unknown elsewhere on an L1 feed)
      - a crossed snapshot (ask <= P) is ambiguous and fills nothing unless `snapshot_fills`, and
        then at most the displayed ask size
    Each print's volume is allocated once across our orders in price-time order.
  * Buys reserve notional plus taker fee plus haircut at submit; at fill the debit is re-checked and
    the size clamped to what cash can pay. Sells never exceed the free position (spot, long-only).
  * Every maker fill pays `adverse_selection_bps` of notional as slip_q, on top of the fee.

Known residual optimism (astra round 2): cancellations ahead of us in the queue are not modeled
(only displayed-size shrinkage), hidden liquidity is ignored, and on a polled feed missing prints
can hide both fills we would have had and volume that would have depleted our queue.
"""
from __future__ import annotations

from collections import deque

from ..config import PaperModel
from ..fees import FeeSchedule
from ..types import (
    SIZE_UNIT,
    Fill,
    Intent,
    Liquidity,
    Order,
    OrderStatus,
    OrderType,
    Quote,
    Side,
    TimeInForce,
    Trade,
    notional_q,
)
from .base import Broker, BrokerView, OpenOrderView

BPS = 10_000
MAX_LIVE_ORDERS = 256  # hard cap on tracked orders; risk limits sit far below this


class PaperBroker(Broker):
    def __init__(self, venue: str, symbol: str, fees: FeeSchedule, model: PaperModel, starting_cash_q: int) -> None:
        if starting_cash_q <= 0:
            raise ValueError("starting cash must be positive")
        self.venue = venue
        self.symbol = symbol
        self.fees = fees
        self.model = model
        self.cash_q = starting_cash_q
        self.pos_i = 0
        self.avg_cost_i = 0
        self.realized_q = 0
        self.fees_paid_q = 0
        self.slip_paid_q = 0
        self.fills_total = 0
        self.orders_total = 0
        self.rejected_total = 0
        self.maker_fills = 0
        self.taker_fills = 0
        self.fill_rules: dict[str, int] = {"trade_through": 0, "queue": 0, "snapshot": 0, "taker": 0, "unfilled_no_depth": 0, "clamped_cash": 0}
        self._orders: dict[int, Order] = {}
        self._pending: deque[tuple[int, int]] = deque()  # (activate_ns, order_id) FIFO
        self._cancel_pending: dict[int, int] = {}  # order_id -> effective ns
        self._next_id = 1
        self._quote: Quote | None = None
        self._quote_ts_ns = 0
        self.last_fills: deque[Fill] = deque(maxlen=256)
        self._latency_ns = model.latency_ms * 1_000_000
        self._max_quote_age_ns = model.max_quote_age_ms * 1_000_000

    # ---- order entry ----------------------------------------------------
    def submit(self, intent: Intent, strategy: str, now_ns: int) -> Order:
        if len(self._orders) >= MAX_LIVE_ORDERS:
            raise RuntimeError("paper broker order table full")
        otype = OrderType.MARKET if intent.is_market else OrderType.LIMIT
        tif = TimeInForce.IOC if intent.is_market else intent.tif
        o = Order(
            id=self._next_id,
            venue=self.venue,
            symbol=self.symbol,
            side=intent.side,
            type=otype,
            tif=tif,
            price_i=intent.price_i,
            size_i=intent.size_i,
            ts_created_ns=now_ns,
            strategy=strategy,
            reason=intent.reason,
            ts_active_ns=now_ns + self._latency_ns,
        )
        self._next_id += 1
        self.orders_total += 1
        if o.side is Side.SELL:
            if o.size_i > self.pos_i - self._reserved_sell_i():
                return self._reject(o, "spot: sell exceeds free position", now_ns)
        else:
            need = self._buy_reserve_q(o)
            if need <= 0 or need > self.cash_q - self._reserved_buy_q():
                return self._reject(o, "spot: insufficient free cash", now_ns)
        self._orders[o.id] = o
        self._pending.append((o.ts_active_ns, o.id))
        return o

    def _reject(self, o: Order, reason: str, now_ns: int) -> Order:
        o.status = OrderStatus.REJECTED
        o.reason = reason
        o.ts_updated_ns = now_ns
        self.rejected_total += 1
        self._orders.pop(o.id, None)
        return o

    def cancel(self, order_id: int, now_ns: int) -> bool:
        """Schedules a cancel that takes effect after latency. False if unknown, terminal or already pending."""
        o = self._orders.get(order_id)
        if o is None or o.status.terminal or order_id in self._cancel_pending:
            return False
        self._cancel_pending[order_id] = now_ns + self._latency_ns
        return True

    def cancel_all(self, now_ns: int) -> int:
        return sum(1 for oid in list(self._orders) if self.cancel(oid, now_ns))

    def order(self, order_id: int) -> Order | None:
        return self._orders.get(order_id)

    # ---- market events --------------------------------------------------
    def on_quote(self, q: Quote, now_ns: int) -> list[Fill]:
        self._quote = q
        self._quote_ts_ns = q.ts_recv_ns
        fills = self.settle(now_ns)
        for o in list(self._orders.values()):
            if not o.is_open:
                continue
            if o.side is Side.BUY:
                if q.bid_i == o.price_i:
                    if not o.queue_known:
                        o.queue_known = True
                        o.queue_ahead_i = q.bid_size_i
                    elif o.queue_ahead_i > q.bid_size_i:
                        o.queue_ahead_i = q.bid_size_i
                if self.model.snapshot_fills and q.ask_i <= o.price_i:
                    take = min(o.remaining_i, q.ask_size_i)
                    if take > 0:
                        self._maker_fill(o, take, now_ns, "snapshot", fills)
            else:
                if q.ask_i == o.price_i:
                    if not o.queue_known:
                        o.queue_known = True
                        o.queue_ahead_i = q.ask_size_i
                    elif o.queue_ahead_i > q.ask_size_i:
                        o.queue_ahead_i = q.ask_size_i
                if self.model.snapshot_fills and q.bid_i >= o.price_i:
                    take = min(o.remaining_i, q.bid_size_i)
                    if take > 0:
                        self._maker_fill(o, take, now_ns, "snapshot", fills)
        return fills

    def on_trade(self, t: Trade, now_ns: int) -> list[Fill]:
        fills = self.settle(now_ns)
        avail = t.size_i  # a print's volume is allocated once across our orders, price-time priority
        for o in sorted((o for o in self._orders.values() if o.is_open), key=lambda o: (-o.price_i if o.side is Side.BUY else o.price_i, o.ts_created_ns)):
            if avail <= 0:
                break
            if t.ts_exch_ns < o.ts_active_ns:
                continue  # the print predates our arrival at the venue
            if o.side is Side.BUY:
                if t.price_i < o.price_i:
                    take = min(o.remaining_i, avail)
                    avail -= take
                    self._maker_fill(o, take, now_ns, "trade_through", fills)
                elif t.price_i == o.price_i and t.side is Side.SELL and o.queue_known:
                    take, used = self._consume_queue(o, avail)
                    avail -= used
                    if take > 0:
                        self._maker_fill(o, take, now_ns, "queue", fills)
            else:
                if t.price_i > o.price_i:
                    take = min(o.remaining_i, avail)
                    avail -= take
                    self._maker_fill(o, take, now_ns, "trade_through", fills)
                elif t.price_i == o.price_i and t.side is Side.BUY and o.queue_known:
                    take, used = self._consume_queue(o, avail)
                    avail -= used
                    if take > 0:
                        self._maker_fill(o, take, now_ns, "queue", fills)
        return fills

    def _consume_queue(self, o: Order, avail_i: int) -> tuple[int, int]:
        """Returns (our fill size, print volume used including the queue ahead of us)."""
        if self.model.queue_model == "touch":
            take = min(o.remaining_i, avail_i)
            return take, take
        ahead = min(o.queue_ahead_i, avail_i)
        o.queue_ahead_i -= ahead
        take = min(o.remaining_i, avail_i - ahead)
        return take, ahead + take

    def settle(self, now_ns: int) -> list[Fill]:
        """Apply arrivals and cancel effects due by now_ns. Public so shutdown can flush cancels."""
        fills: list[Fill] = []
        while self._pending and self._pending[0][0] <= now_ns:
            _, oid = self._pending.popleft()
            o = self._orders.get(oid)
            if o is None or o.status is not OrderStatus.NEW:
                continue
            self._arrive(o, now_ns, fills)
        for oid, eff in list(self._cancel_pending.items()):
            if eff <= now_ns:
                del self._cancel_pending[oid]
                o = self._orders.get(oid)
                if o is not None and not o.status.terminal:
                    o.status = OrderStatus.CANCELED
                    o.ts_updated_ns = now_ns
                    o.reason = (o.reason + "; canceled").strip("; ")
                    del self._orders[oid]
        return fills

    def _arrive(self, o: Order, now_ns: int, fills: list[Fill]) -> None:
        q = self._quote
        if q is None:
            self._reject(o, "no book", now_ns)
            return
        stale = (now_ns - self._quote_ts_ns) > self._max_quote_age_ns
        crosses = (o.side is Side.BUY and o.price_i >= q.ask_i) or (o.side is Side.SELL and o.price_i <= q.bid_i)
        marketable = o.type is OrderType.MARKET or crosses
        if marketable:
            if o.tif is TimeInForce.POST_ONLY:
                self._reject(o, "post-only would cross", now_ns)
                return
            if stale:
                self._reject(o, "stale book at arrival", now_ns)
                return
            self._take(o, q, now_ns, fills)
            if o.is_open or o.status is OrderStatus.NEW:
                if o.tif is TimeInForce.IOC or o.type is OrderType.MARKET:
                    self._finish(o, OrderStatus.CANCELED, "unfilled remainder: no displayed depth", now_ns)
                    self.fill_rules["unfilled_no_depth"] += 1
                else:
                    self._rest(o, q, now_ns)
            return
        if o.tif is TimeInForce.IOC:
            self._finish(o, OrderStatus.CANCELED, "ioc not marketable", now_ns)
            return
        self._rest(o, q, now_ns)

    def _rest(self, o: Order, q: Quote, now_ns: int) -> None:
        o.status = OrderStatus.OPEN if o.filled_i == 0 else OrderStatus.PARTIAL
        o.ts_updated_ns = now_ns
        at_touch = (o.side is Side.BUY and o.price_i == q.bid_i) or (o.side is Side.SELL and o.price_i == q.ask_i)
        o.queue_known = at_touch
        o.queue_ahead_i = (q.bid_size_i if o.side is Side.BUY else q.ask_size_i) if at_touch else 0

    def _finish(self, o: Order, status: OrderStatus, reason: str, now_ns: int) -> None:
        o.status = status
        o.reason = reason
        o.ts_updated_ns = now_ns
        self._orders.pop(o.id, None)
        self._cancel_pending.pop(o.id, None)

    def _take(self, o: Order, q: Quote, now_ns: int, fills: list[Fill]) -> None:
        """Aggressive fill against DISPLAYED depth only. Zero displayed depth fills nothing."""
        slip = self.model.taker_slippage_bps
        if o.side is Side.BUY:
            touch, depth = q.ask_i, q.ask_size_i
            px1 = touch + -(-touch * slip // BPS)
            px2 = px1 + q.spread_i
            if o.type is OrderType.LIMIT:
                px1, px2 = min(px1, o.price_i), min(px2, o.price_i)
        else:
            touch, depth = q.bid_i, q.bid_size_i
            px1 = touch - (touch * slip // BPS)
            px2 = max(1, px1 - q.spread_i)
            if o.type is OrderType.LIMIT:
                px1, px2 = max(px1, o.price_i), max(px2, o.price_i)
        first = min(o.remaining_i, depth)
        if first > 0:
            f = self._fill(o, first, px1, Liquidity.TAKER, now_ns)
            if f is not None:
                fills.append(f)
                self.fill_rules["taker"] += 1
        if o.remaining_i > 0 and o.type is OrderType.MARKET and depth > 0 and not o.status.terminal:
            second = min(o.remaining_i, depth)  # explicit assumption: one more level equal to the touch depth
            f = self._fill(o, second, px2, Liquidity.TAKER, now_ns)
            if f is not None:
                fills.append(f)
                self.fill_rules["taker"] += 1

    def _maker_fill(self, o: Order, size_i: int, now_ns: int, rule: str, fills: list[Fill]) -> None:
        f = self._fill(o, size_i, o.price_i, Liquidity.MAKER, now_ns)
        if f is not None:
            fills.append(f)
            self.fill_rules[rule] += 1

    # ---- accounting -----------------------------------------------------
    def _fill(self, o: Order, size_i: int, price_i: int, liq: Liquidity, now_ns: int) -> Fill | None:
        fee_bps = self.fees.maker_bps if liq is Liquidity.MAKER else self.fees.taker_bps
        slip_bps = self.model.adverse_selection_bps if liq is Liquidity.MAKER else 0
        if o.side is Side.BUY:
            # re-check cash at the actual fill price; clamp rather than let cash go negative
            affordable = self.cash_q * SIZE_UNIT * BPS // (price_i * (BPS + fee_bps + slip_bps) + 1)
            if affordable < size_i:
                self.fill_rules["clamped_cash"] += 1
                size_i = affordable
            if size_i <= 0:
                self._finish(o, OrderStatus.REJECTED, "insufficient cash at fill", now_ns)
                self.rejected_total += 1
                return None
        o.record_fill(size_i, now_ns)  # enforces 0 < size <= remaining and the status machine
        fee_q = self.fees.fee_q(price_i, size_i, liq)
        slip_q = -(-notional_q(price_i, size_i) * slip_bps // BPS) if slip_bps else 0
        n_q = notional_q(price_i, size_i)
        if o.side is Side.BUY:
            self.cash_q -= n_q + fee_q + slip_q
            new_pos = self.pos_i + size_i
            self.avg_cost_i = (self.avg_cost_i * self.pos_i + price_i * size_i) // new_pos
            self.pos_i = new_pos
        else:
            self.cash_q += n_q - fee_q - slip_q
            self.realized_q += (price_i - self.avg_cost_i) * size_i // SIZE_UNIT
            self.pos_i -= size_i
            if self.pos_i == 0:
                self.avg_cost_i = 0
        if self.cash_q < 0:
            raise AssertionError("paper broker cash went negative; reservation logic broken")
        self.fees_paid_q += fee_q
        self.slip_paid_q += slip_q
        self.fills_total += 1
        if liq is Liquidity.MAKER:
            self.maker_fills += 1
        else:
            self.taker_fills += 1
        if o.status is OrderStatus.FILLED:
            self._orders.pop(o.id, None)
            self._cancel_pending.pop(o.id, None)
        f = Fill(o.id, self.venue, self.symbol, o.side, price_i, size_i, fee_q, liq, now_ns, o.strategy, slip_q)
        self.last_fills.append(f)
        return f

    def _buy_reserve_q(self, o: Order) -> int:
        q = self._quote
        if o.price_i:
            px = o.price_i
        elif q is not None:
            px = q.ask_i + -(-q.ask_i * self.model.taker_slippage_bps // BPS)
        else:
            return 0
        n = notional_q(px, o.remaining_i)
        return n + -(-n * (self.fees.taker_bps + self.model.adverse_selection_bps) // BPS)

    def _reserved_sell_i(self) -> int:
        return sum(o.remaining_i for o in self._orders.values() if o.side is Side.SELL and not o.status.terminal)

    def _reserved_buy_q(self) -> int:
        return sum(self._buy_reserve_q(o) for o in self._orders.values() if o.side is Side.BUY and not o.status.terminal)

    def equity_q(self, mid_i: int) -> int:
        return self.cash_q + notional_q(mid_i, self.pos_i)

    def liquidation_q(self) -> int:
        """Cash plus what selling the whole position at the bid, taker fee and slippage would leave."""
        q = self._quote
        if q is None or self.pos_i == 0:
            return self.cash_q
        px = q.bid_i - (q.bid_i * self.model.taker_slippage_bps // BPS)
        n = notional_q(px, self.pos_i)
        return self.cash_q + n - self.fees.fee_q(px, self.pos_i, Liquidity.TAKER)

    def open_notional_q(self) -> int:
        q = self._quote
        tot = 0
        for o in self._orders.values():
            if not o.status.terminal:
                px = o.price_i if o.price_i else (q.mid_i if q else 0)
                tot += notional_q(px, o.remaining_i)
        return tot

    def pending_i(self, side: Side) -> int:
        return sum(o.remaining_i for o in self._orders.values() if o.side is side and not o.status.terminal)

    def view(self) -> BrokerView:
        return BrokerView(
            cash_q=self.cash_q,
            pos_i=self.pos_i,
            avg_cost_i=self.avg_cost_i,
            open_orders=tuple(
                OpenOrderView(o.id, o.side, o.price_i, o.remaining_i, o.ts_created_ns, o.strategy)
                for o in self._orders.values()
                if not o.status.terminal
            ),
            fills_total=self.fills_total,
            fees_paid_q=self.fees_paid_q,
            realized_q=self.realized_q,
        )

    def snapshot(self) -> dict:
        return {
            "cash_q": self.cash_q,
            "pos_i": self.pos_i,
            "avg_cost_i": self.avg_cost_i,
            "realized_q": self.realized_q,
            "fees_paid_q": self.fees_paid_q,
            "slip_paid_q": self.slip_paid_q,
            "fills_total": self.fills_total,
            "maker_fills": self.maker_fills,
            "taker_fills": self.taker_fills,
            "orders_total": self.orders_total,
            "rejected_total": self.rejected_total,
            "open_orders": len(self._orders),
            "fill_rules": dict(self.fill_rules),
            "liquidation_q": self.liquidation_q(),
        }
