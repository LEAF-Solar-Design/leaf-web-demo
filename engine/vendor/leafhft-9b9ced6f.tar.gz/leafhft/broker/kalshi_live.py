"""Kalshi signed REST order adapter (RSA-PSS-SHA256 signed IOC buys). UNEXERCISED against the
venue: no credentials existed when this was built, so only request construction, signing,
authorization checks and response parsing are covered by tests.

Paths used here (docs.kalshi.com, read 2026-09-06), base `https://api.elections.kalshi.com`
(demo `https://external-api.demo.kalshi.co`), every path prefixed `/trade-api/v2` and signed
whole (the signature covers method + path, no query string), same convention as
feeds/kalshi.py:

  POST   /trade-api/v2/portfolio/events/orders   create order (used here for IOC buys only)
  GET    /trade-api/v2/portfolio/orders          list orders (?ticker=)
  GET    /trade-api/v2/portfolio/orders/{id}     one order's status
  DELETE /trade-api/v2/portfolio/orders/{id}     cancel
  GET    /trade-api/v2/portfolio/fills           fills (?min_ts=)
  GET    /trade-api/v2/portfolio/positions       positions
  GET    /trade-api/v2/portfolio/balance         balance, in cents
  GET    /trade-api/v2/markets/{ticker}          market, for the settlement result

These were not independently re-verified against a live account in this environment (no network
access here); confirm on first live connect, same caveat as feeds/kalshi.py.

YES/NO mapping (documented, tested both ways): every Kalshi market has one order book, quoted in
the YES contract. Buying YES at P cents submits side="bid" at P. Buying NO at P cents submits
side="ask" (selling YES) at 100-P cents: economically, paying P for NO is the same exposure as
asking 100-P for YES (a filled ask leaves this account short YES, which settles identically to a
long NO position). place_ioc_buy's `price_cents` is always what this book pays per contract for
the leg it asked for (YES or NO); _order_body performs the flip for the NO case.

Hardened: RSA signing is deterministic-input only (ts_ms, method, path); the journal follows the
same discipline as binanceus_live.py (SENT before transmission, terminal states derived only from
a validated venue reply, OrderStateUnknown on anything ambiguous, restart rebuilds owned state
from the journal). Ticket volume here is small by design (bounded per KalshiLimits), so the
journal is bounded but not compacted/rotated; MAX_JOURNAL_BYTES failing closed is the intended
stop, not a bug, at the caps this adapter is authorized for.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import os
import random
import re
import stat
import time
import weakref
from collections import OrderedDict, deque
from contextvars import ContextVar
from queue import Queue, Empty, Full
from threading import Event, Thread
from datetime import datetime
from decimal import ROUND_CEILING, ROUND_DOWN, ROUND_HALF_UP, Decimal, InvalidOperation
from numbers import Real
from pathlib import Path
from typing import Any

import aiohttp
import orjson

from ..feeds.kalshi import CRED_KEY_ID_ENV, CRED_PEM_ENV, sign
from ..types import MalformedInput
from .. import refusal_journal
from ..attribution import new_attribution, attribution_or_unknown, scope_attribution, execution_account
from .kalshi_perp import _whole_count
from .live_gate import LiveAuthorization, LiveGateClosed
from .account_risk import AccountRiskRefused, classify_tickers
from ..attribution import account_digest
from ..strategy.settlement import fee_per_contract
from ..policy import DEFAULT_POLICY

REST_URL = "https://api.elections.kalshi.com"
REST_URL_DEMO = "https://external-api.demo.kalshi.co"
PATH_PREFIX = "/trade-api/v2"
ORDER_CREATE_PATH = PATH_PREFIX + "/portfolio/events/orders"
ORDERS_PATH = PATH_PREFIX + "/portfolio/orders"
FILLS_PATH = PATH_PREFIX + "/portfolio/fills"
POSITIONS_PATH = PATH_PREFIX + "/portfolio/positions"
BALANCE_PATH = PATH_PREFIX + "/portfolio/balance"
TIMEOUT_S = 5.0
# Retain idle connections longer to avoid TCP/TLS setup on the next order.
KEEPALIVE_S = 75.0
MAX_JOURNAL_BYTES = 1024 * 1024
# Keep the final 256 KiB of decision journals available only to order rows.
DECISION_ORDER_RESERVE_BYTES = 256 * 1024
MAX_OWNED = 2_000
MAX_POSITION_PAGES = 100
MAX_RECONCILE_FAILURES = 3
# owner-domain-control v1: engine_ops.DEFAULT_REGISTRY_DIR, without importing the writer.
DOMAIN_PAUSE_REGISTRY_DIR = Path("/var/lib/leafhft/engine-registry")
_DOMAIN_PAUSE_CACHE: OrderedDict = OrderedDict()
_DOMAIN_PAUSE_KEYS = frozenset((
    "schema", "member_key", "domain", "generation", "state", "reason", "request_id",
    "requested_by", "paused_at", "resumed_at", "resume_nonce", "evidence_sha256",
    "previous_digest", "digest",
))
_DOMAIN_PAUSE_UUID = r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"


def _pause_pairs(pairs):
    record = {}
    for key, value in pairs:
        if key in record:
            raise ValueError("duplicate pause key")
        record[key] = value
    return record


def _pause_noninteger(value):
    raise ValueError("noninteger pause number")


def _parse_domain_pause(data: bytes, domain: str) -> tuple[int, str]:
    """Strict, digest-checked owner-domain-control v1 record; never accept a partial resume."""
    record = json.loads(data.decode("utf-8"), object_pairs_hook=_pause_pairs,
                        parse_float=_pause_noninteger, parse_constant=_pause_noninteger)
    if type(record) is not dict or record.keys() != _DOMAIN_PAUSE_KEYS:
        raise ValueError("pause keys")
    if (type(record["schema"]) is not int or record["schema"] != 1
            or record["member_key"] != "owner" or record["domain"] != domain
            or type(record["generation"]) is not int or record["generation"] < 1
            or record["state"] not in ("paused", "resumed")):
        raise ValueError("pause identity")

    def matches(key, pattern):
        value = record[key]
        return type(value) is str and re.fullmatch(pattern, value) is not None

    if (not matches("reason", r"[a-z][a-z0-9_]{0,63}")
            or not matches("request_id", _DOMAIN_PAUSE_UUID)
            or not matches("requested_by", "device:" + _DOMAIN_PAUSE_UUID)
            or not matches("digest", r"[0-9a-f]{64}")
            or (record["previous_digest"] is not None
                and not matches("previous_digest", r"[0-9a-f]{64}"))):
        raise ValueError("pause provenance")
    for key in ("paused_at", "resumed_at"):
        if key == "resumed_at" and record["state"] == "paused":
            if record[key] is not None:
                raise ValueError("paused resume timestamp")
        else:
            if not matches(key, r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z"):
                raise ValueError("pause timestamp")
            datetime.fromisoformat(record[key].replace("Z", "+00:00"))
    if record["state"] == "paused":
        if not matches("resume_nonce", r"[0-9a-f]{32}") or record["evidence_sha256"] is not None:
            raise ValueError("paused evidence")
    elif record["resume_nonce"] is not None or not matches("evidence_sha256", r"[0-9a-f]{64}"):
        raise ValueError("resumed evidence")
    digest = record.pop("digest")
    canonical = json.dumps(record, sort_keys=True, separators=(",", ":")).encode("utf-8")
    if hashlib.sha256(canonical).hexdigest() != digest:
        raise ValueError("pause digest")
    return record["generation"], record["state"]


def _domain_pause_status(domain: str) -> dict[str, Any]:
    """One stat per observation; at most 4 KiB read and 64 cached domain records."""
    unreadable = {"generation": None, "state": "unreadable"}
    if type(domain) is not str or re.fullmatch(r"[a-z0-9][a-z0-9:-]{0,63}", domain) is None:
        return unreadable
    path = Path(DOMAIN_PAUSE_REGISTRY_DIR) / "domain-pause" / (domain.replace(":", "_") + ".json")
    try:
        info = os.stat(path)
    except FileNotFoundError:
        _DOMAIN_PAUSE_CACHE.pop(path, None)
        return {"generation": None, "state": "absent"}
    except OSError:
        _DOMAIN_PAUSE_CACHE.pop(path, None)
        return unreadable
    key = (info.st_mtime_ns, info.st_ino, info.st_size)
    if not stat.S_ISREG(info.st_mode) or not 0 < info.st_size <= 4096:
        _DOMAIN_PAUSE_CACHE.pop(path, None)
        return unreadable
    cached = _DOMAIN_PAUSE_CACHE.get(path)
    if cached is not None and cached[0] == key:
        _DOMAIN_PAUSE_CACHE.move_to_end(path)
        return {"generation": cached[1], "state": cached[2]}
    try:
        # NONBLOCK also bounds a race replacing the regular file with a FIFO.
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_BINARY", 0))
        with os.fdopen(fd, "rb") as stream:
            opened = os.fstat(stream.fileno())
            if (not stat.S_ISREG(opened.st_mode)
                    or (opened.st_mtime_ns, opened.st_ino, opened.st_size) != key):
                raise OSError("pause record changed during open")
            data = stream.read(4097)
        if len(data) > 4096:
            raise ValueError("pause record too large")
        generation, state = _parse_domain_pause(data, domain)
    except OSError:
        _DOMAIN_PAUSE_CACHE.pop(path, None)
        return unreadable
    except (ValueError, TypeError, RecursionError):
        generation, state = None, "unreadable"
    _DOMAIN_PAUSE_CACHE[path] = (key, generation, state)
    _DOMAIN_PAUSE_CACHE.move_to_end(path)
    if len(_DOMAIN_PAUSE_CACHE) > 64:
        _DOMAIN_PAUSE_CACHE.popitem(last=False)
    return {"generation": generation, "state": state}


# Account-risk classification (X3). "legacy" decides exactly as before; "ticker" classifies each
# held ticker (account_risk.classify_tickers). Only the construction wiring (X3i) selects ticker.
CLASSIFICATION_MODES = ("legacy", "ticker")
# Ticker mode: the whole venue-read chain (settlement recovery, balance, positions, minutes and the
# one revision retry) runs under this budget; expiry refuses venue_read_timeout. The synchronous
# ledger calls inside it are bounded by SQLite's 2 s busy timeout, not by this clock.
TICKER_READ_BUDGET_S = 15.0
# RC1: an account-risk revision_conflict (another writer moved the ledger between this admission's
# read and its reserve) is retried ONCE with fresh reads after a uniform random delay in these
# bounds, so a settlement-second crowd spreads out instead of meeting again; never any other code.
# Both modes: the first attempt, the delay and the retry share one TICKER_READ_BUDGET_S budget, and a
# retry the remaining budget cannot hold (the delay plus the first attempt's own duration) refuses.
REVISION_RETRY_JITTER_MIN_S = 0.050
REVISION_RETRY_JITTER_MAX_S = 0.250
# At most this many market reads in flight (minute reads and settlement recovery), four worker
# tasks, never one task per ticker. A venue 429 surfaces as venue_read_failed (conservative).
MARKET_READ_CONCURRENCY = 4
# Per-process LRU of settlement minutes by ticker: close_time is immutable per market, so a hit
# is always current. Market status is never cached.
MINUTE_CACHE_MAX = 4096
# fills_all: signed pages per walk; a walk stopped by this bound reports incomplete=True.
FILLS_MAX_PAGES = 10
# fills_all: rows asked for per page, sent as `limit`. Kalshi GetFills documents limit 1..1000,
# default 100 (docs.kalshi.com get-fills, read 2026-09-24); without it every page held 100 rows.
FILLS_PAGE_LIMIT = 1000
# At most ~1.6 s added sleep plus two bounded walks, only for a reply without basis.
FILLS_BASIS_RETRIES = 2
FILLS_BASIS_RETRY_DELAYS_S = (0.4, 1.2)
FILLS_BASIS_RETRY_BUDGET_S = 3.0
_FILLS_BASIS_RETRY_WALKS = deque(maxlen=20)
_fills_basis_retry_active = ContextVar("fills_basis_retry_active", default=False)
# Beside the order journal: proven-unsent reservations whose resolve-to-0 failed (cid -> 0).
RISK_CLEANUP_FILE = "risk-cleanup-pending.json"


def _reconcile_grace_ns() -> int:
    """Kill switch, read once at import: LEAFHFT_RECONCILE_GRACE_S in float seconds, bounded to
    0..30, default 5.0. Anything unparseable or out of range falls back to the default, so a bad
    environment can never disarm the grace silently or stall reconciliation for an hour."""
    try:
        seconds = float(os.environ.get("LEAFHFT_RECONCILE_GRACE_S", "5.0"))
    except (TypeError, ValueError):
        return 5_000_000_000
    if not 0.0 <= seconds <= 30.0:  # NaN and both infinities fail this bound
        return 5_000_000_000
    return int(seconds * 1_000_000_000)


# The venue may take up to its own five-second publication timeout (TIMEOUT_S) to show a sent
# order, so an absence inside this window is not evidence and must never establish GONE. It
# protects every reconcile caller that has no grace of its own: the engines lane's startup,
# 30 s cadence and close (lanes/live_runner.py:435, :657, :736) and any recovery read. The
# Dark Horse lane's own in-memory grace (cli.py RECONCILE_SEND_GRACE_S) stays as belt and braces.
RECONCILE_GRACE_NS = _reconcile_grace_ns()
# A journalled send stamp this far ahead of the reader's clock is a broken clock, not an episode.
JOURNAL_FUTURE_SKEW_NS = 60_000_000_000
TERMINAL = {"FILLED", "PARTIAL", "CANCELED", "GONE", "UNRECONCILABLE"}
STATES = TERMINAL | {"SENT", "UNKNOWN"}


def _hot_module():
    """Load the observation reader only when a book enables it; mode off never imports it."""
    from . import kalshi_hot_observation
    return kalshi_hot_observation


class _HotClock:
    """A process cannot survive a reboot; pin its boot identity before the order path."""

    def __init__(self):
        self._clock = _hot_module().system_clock()
        self._boot = self._clock.boot_id()

    def boot_id(self):
        return self._boot

    def boottime_ns(self):
        return self._clock.boottime_ns()


class LatencyReservoir:
    """Latest 512 nanosecond durations; nearest-rank percentiles only on snapshot."""

    def __init__(self) -> None:
        self.samples: deque[int] = deque(maxlen=512)

    def record(self, duration_ns: int) -> None:
        if type(duration_ns) is int and 0 <= duration_ns <= 2**63 - 1:
            self.samples.append(duration_ns)

    def snapshot(self) -> dict[str, int | float] | None:
        values = sorted(self.samples)
        n = len(values)
        if not n:
            return None
        return {"n": n, "p50": values[math.ceil(n * .50) - 1] / 1_000_000,
                "p90": values[math.ceil(n * .90) - 1] / 1_000_000,
                "p99": values[math.ceil(n * .99) - 1] / 1_000_000,
                "max": values[-1] / 1_000_000}


_decision_row: ContextVar[dict | None] = ContextVar("kalshi_decision_row", default=None)


def _decision_stage(stage: str, **values) -> None:
    """Instrumentation must not turn an observation failure into an order failure."""
    try:
        row = _decision_row.get()
        if row is not None:
            row[stage] = time.perf_counter_ns()
            row.update(values)
    except Exception:
        pass


def _decision_add(key: str, delta: int) -> None:
    """Accumulate counters without letting a broken observer affect an order."""
    try:
        row = _decision_row.get()
        if row is not None:
            row[key] = int(row.get(key, 0)) + delta
    except Exception:
        pass


def _decision_values(**values) -> None:
    try:
        row = _decision_row.get()
        if row is not None:
            row.update(values)
    except Exception:
        pass


def _decision_clock():
    try:
        if _decision_row.get() is None:
            return None
        return time.perf_counter_ns()
    except Exception:
        return None


def _decision_ledger_call(call, *args, **kwargs):
    """Time ledger calls only for a bound observer, preserving results and exceptions."""
    started = _decision_clock()
    try:
        return call(*args, **kwargs)
    finally:
        try:
            if started is not None:
                _decision_add("ledger_tx_ns_total", time.perf_counter_ns() - started)
        except Exception:
            pass


def _decision_sign_elapsed(started) -> None:
    try:
        if started is not None:
            _decision_add("sign_ns_total", time.perf_counter_ns() - started)
    except Exception:
        pass


async def _decision_connection_reused(session, context, params) -> None:
    _decision_add("conn_reused", 1)


async def _decision_connection_created(session, context, params) -> None:
    _decision_add("conn_new", 1)


def decision_code_sha() -> str | None:
    """Read checkout identity once at startup, without launching a process."""
    try:
        root = Path(__file__).resolve().parents[2]
        git = root / ".git"
        if git.is_file():
            git = (root / git.read_text().strip().split(": ", 1)[1]).resolve()
        head = (git / "HEAD").read_text().strip()
        if head.startswith("ref: "):
            ref = head[5:]
            common = git
            if (git / "commondir").exists():
                common = (git / (git / "commondir").read_text().strip()).resolve()
            if (common / ref).exists():
                head = (common / ref).read_text().strip()
            else:
                head = next(line.split()[0] for line in (common / "packed-refs").read_text().splitlines()
                            if line.endswith(" " + ref))
        return head if len(head) == 40 and all(c in "0123456789abcdef" for c in head) else None
    except Exception:
        return None


class DecisionWriter:
    """Bounded per-run evidence. A single worker appends and fsyncs each accepted row.

    Queue admission never waits for disk. Failed writes and exhausted bounds drop evidence,
    not orders. close() drains at shutdown only, with a bounded join for a stalled disk.
    Receipt clocks are local strategy-consumer receipts, not venue or wall clocks.
    """

    def __init__(self, path: Path, *, symbol: str, code_sha: str | None = None,
                 max_rows: int = 2000, queue_size: int = 512,
                 max_order_rows: int = 5000, max_attempt_rows: int = 4000) -> None:
        self.path, self.symbol, self.code_sha = Path(path), symbol, code_sha
        self.max_rows = max_rows
        self.max_order_rows = max_order_rows
        self.max_attempt_rows = max_attempt_rows
        self.rows = self.dropped = self.errors = self.accepted = 0
        self.order_rows = self.order_rows_dropped = self.order_rows_accepted = 0
        self.attempt_accepted = self.attempt_dropped = self.skip_dropped = 0
        self.latency = LatencyReservoir()
        self._queue = Queue(maxsize=max(1, queue_size))
        self._stop = Event()
        self._pending: dict[str, dict] = {}
        self._buffered: dict[int, dict] = {}
        self._book = None
        self._thread = Thread(target=self._run, name="kalshi-decisions", daemon=True)
        try:
            self._thread.start()
        except Exception:
            self.errors += 1
            self._stop.set()

    @staticmethod
    def _is_attempt(row: dict) -> bool:
        return row.get("gate") == "passed" or bool(row.get("client_id") or row.get("refuse_reason"))

    def _drop(self, attempt: bool, *, order_row: bool = False) -> None:
        self.dropped += 1
        if order_row:
            self.order_rows_dropped += 1
        elif attempt:
            self.attempt_dropped += 1
        else:
            self.skip_dropped += 1

    def snapshot(self) -> dict[str, int]:
        return {key: int(getattr(self, key)) for key in (
            "accepted", "rows", "dropped", "errors", "attempt_accepted",
            "attempt_dropped", "skip_dropped", "order_rows",
            "order_rows_dropped", "order_rows_accepted")}

    def append(self, row: dict, *, order_row: bool = False) -> None:
        started = time.perf_counter_ns()
        attempt = False
        try:
            # Order rows retain their own admission rules, independent of attempts.
            if order_row:
                exhausted = self.order_rows_accepted >= self.max_order_rows
            else:
                attempt = self._is_attempt(row)
                admitted = self.attempt_accepted if attempt else self.accepted - self.attempt_accepted
                cap = self.max_attempt_rows if attempt else self.max_rows
                exhausted = admitted >= cap
            if self._stop.is_set() or exhausted:
                self._drop(attempt, order_row=order_row)
                return
            payload = orjson.dumps(row, default=_json_count) + b"\n"
            if len(payload) > 8192:
                self._drop(attempt, order_row=order_row)
                return
            self._queue.put_nowait((payload, order_row, attempt))
            if order_row:
                self.order_rows_accepted += 1
            else:
                self.accepted += 1
                if attempt:
                    self.attempt_accepted += 1
        except Full:
            self._drop(attempt, order_row=order_row)
        except Exception:
            self.errors += 1
            self._drop(attempt, order_row=order_row)
        finally:
            self.latency.record(time.perf_counter_ns() - started)

    def _run(self) -> None:
        while not self._stop.is_set() or not self._queue.empty():
            try:
                payload, order_row, attempt = self._queue.get(timeout=.05)
            except Empty:
                continue
            try:
                with self.path.open("ab") as stream:
                    byte_limit = (MAX_JOURNAL_BYTES if order_row else
                                  MAX_JOURNAL_BYTES - DECISION_ORDER_RESERVE_BYTES)
                    if stream.tell() + len(payload) > byte_limit:
                        self._drop(attempt, order_row=order_row)
                        continue
                    if stream.write(payload) != len(payload):
                        raise OSError("short decision write")
                    stream.flush()
                    os.fsync(stream.fileno())
                self.rows += 1
                if order_row:
                    self.order_rows += 1
            except Exception:
                self.errors += 1
                self._drop(attempt, order_row=order_row)
            finally:
                self._queue.task_done()

    def observe(self, row: dict, *, defer: bool = False) -> None:
        attempt = False
        try:
            attempt = self._is_attempt(row)
            if (self._book is not None and isinstance(self._book.client, KalshiLive)
                    and row.get("attribution") is not None):
                row["attribution"] = scope_attribution(
                    row["attribution"], execution_account(self._book.client))
                if defer:
                    self._book.client.record_attribution(
                        row["attribution"], "proposal",
                        row["attribution"]["decision_id"], reason=row.get("gate"))
            row.update(symbol=self.symbol, code_sha=self.code_sha)
            if self._book is not None:
                row.update(cash_cents=self._book.cash_cents, reserved_cents=self._book.reserved_cents,
                           open_tickets=len(self._book.open_tickets))
            if defer:
                old = self._pending.pop(row["ticker"], None)
                if old is not None:
                    self.append(old)
                if len(self._pending) >= 256:
                    self._drop(attempt)
                else:
                    self._pending[row["ticker"]] = row
            else:
                self.append(row)
        except Exception:
            self.errors += 1
            self._drop(attempt)

    def refuse(self, ticker: str, reason: str) -> None:
        row = self._pending.pop(ticker, None)
        if row is not None:
            row["refuse_reason"] = reason[:400]
            if (self._book is not None and isinstance(self._book.client, KalshiLive)
                    and row.get("attribution") is not None):
                try:
                    self._book.client.record_attribution(row["attribution"], "rejected",
                                                         row["attribution"]["decision_id"], reason=reason[:400])
                except Exception:
                    self.errors += 1  # The client latch blocks entries; maintenance continues.
            self.append(row)

    def bind_book(self, book) -> None:
        """Observe the existing buy call, including its original exceptions and return value."""
        self._book = book
        book.decision_writer = self
        original = book.buy

        async def buy(ticker, side_yes, price_cents, count, *args, **kwargs):
            row = self._pending.pop(ticker, None)
            token = _decision_row.set(row)
            try:
                if row is not None:
                    row["requested_count"] = _count_number(count) if isinstance(count, Decimal) else count
                    if row.get("attribution") is not None and len(args) >= 3:
                        book.entry_attributions[args[2]] = attribution_or_unknown(row["attribution"])
                return await original(ticker, side_yes, price_cents, count, *args, **kwargs)
            except BaseException as exc:
                if row is not None:
                    row["refuse_reason"] = str(exc)[:400]
                raise
            finally:
                _decision_row.reset(token)
                if row is not None:
                    self.append(row, order_row=True)

        book.buy = buy

    def hold(self, ticker: str) -> int | None:
        row = self._pending.pop(ticker, None)
        if row is None:
            return None
        if len(self._buffered) >= 256:
            self._drop(self._is_attempt(row))
            return None
        key = id(row)
        self._buffered[key] = row
        return key

    def activate(self, key: int | None) -> None:
        row = self._buffered.pop(key, None)
        if row is not None:
            previous = self._pending.pop(row["ticker"], None)
            if previous is not None:
                self.append(previous)
            self._pending[row["ticker"]] = row

    def finish_buffered(self, key: int | None, reason: str) -> None:
        row = self._buffered.pop(key, None)
        if row is not None:
            row["refuse_reason"] = reason
            self.append(row)

    def flush_pending(self, reason: str = "not_submitted") -> None:
        for ticker in tuple(self._pending):
            self.refuse(ticker, reason)

    def close(self) -> None:
        self.flush_pending()
        for key in tuple(self._buffered):
            self.finish_buffered(key, "all_in_not_submitted")
        self._stop.set()
        if self._thread.is_alive():
            self._thread.join(timeout=5)


def order_path(order_id: int | str) -> str:
    return f"{ORDERS_PATH}/{order_id}"


def market_path(ticker: str) -> str:
    return f"{PATH_PREFIX}/markets/{ticker}"


# widen-reqcounter: every venue request a KalshiLive issues, counted by route at issue and by
# outcome once the status line is known. Both sets are closed, so the counters are bounded by
# these tuples and never by traffic.
REQUEST_ROUTES = ("order_create", "order_get", "order_cancel", "orders_list", "fills", "positions",
                  "balance", "market", "exchange_status", "other")
REQUEST_OUTCOMES = ("ok", "http_429", "http_4xx", "http_5xx", "transport")
REQUEST_WRITE_ROUTES = ("order_create", "order_cancel")
MAX_REQUEST_CLIENTS = 32
# Computed once at import, never per request. Exact paths are matched before the prefixes.
_EXACT_REQUEST_ROUTES = {ORDER_CREATE_PATH: "order_create", ORDERS_PATH: "orders_list", FILLS_PATH: "fills",
                         POSITIONS_PATH: "positions", BALANCE_PATH: "balance"}
_ORDER_PATH_PREFIX = order_path("")
_MARKET_PATH_PREFIX = market_path("")
_LABEL_UNSAFE = re.compile(r"[^A-Za-z0-9._-]")
# Every constructed KalshiLive in this process; weak, so a collected client drops out.
_CLIENTS: "weakref.WeakSet[KalshiLive]" = weakref.WeakSet()


def _request_route(method: str, path: str) -> str:
    """Route of a signed request from its bare path (never the url with its query). Never raises."""
    try:
        route = _EXACT_REQUEST_ROUTES.get(path)
        if route is not None:
            return route
        if path.startswith(_ORDER_PATH_PREFIX):
            return "order_get" if method == "GET" else "order_cancel" if method == "DELETE" else "other"
        if path.startswith(_MARKET_PATH_PREFIX):
            return "market"
    except Exception:
        pass
    return "other"


def _request_outcome(http: int) -> str:
    """Outcome class of a known status line; 429 is its own class and never http_4xx."""
    if http == 200 or http == 201:
        return "ok"
    if http == 429:
        return "http_429"
    if 400 <= http < 500:
        return "http_4xx"
    if 200 <= http < 300:
        return "ok"  # an unexpected 2xx: the venue answered and charged the limit
    return "http_5xx"  # 5xx, and any 1xx/3xx the closed outcome set has no other class for


# B12-read: routes whose reads an order's own bookkeeping needs (reconcile, resolution, fill
# basis); a read budget always admits them. Every other signed GET is discretionary.
_CRITICAL_READ_ROUTES = frozenset({"order_get", "orders_list", "fills", "balance", "positions"})


def _read_kind(route: str) -> str:
    """Classify signed GETs: order status, orders, fills, balance and positions are critical.
    With a read budget these consume reserve and are admitted in debt or when the bucket is
    unavailable; market and other reads are discretionary. Without a budget this is unused.
    O(1), never raises.
    """
    return "critical" if route in _CRITICAL_READ_ROUTES else "discretionary"


def request_demand_snapshot(now_ms: int | None = None) -> dict[str, Any] | None:
    """Measured request demand of every live KalshiLive in this process: None with no client,
    at most MAX_REQUEST_CLIENTS listed (the rest counted and still summed), never raises."""
    try:
        clients = list(_CLIENTS)
        if not clients:
            return None
        snapshots = sorted((client.request_snapshot() for client in clients),
                           key=lambda snap: (snap["label"], snap["since_ms"]))
        by_route = dict.fromkeys(REQUEST_ROUTES, 0)
        by_outcome = dict.fromkeys(REQUEST_OUTCOMES, 0)
        reads = writes = 0
        for snap in snapshots:
            for route in REQUEST_ROUTES:
                by_route[route] += snap["by_route"][route]
            for outcome in REQUEST_OUTCOMES:
                by_outcome[outcome] += snap["by_outcome"][outcome]
            reads += snap["reads"]
            writes += snap["writes"]
        return {"schema": 1, "at_ms": int(time.time() * 1000) if now_ms is None else int(now_ms),
                "clients": snapshots[:MAX_REQUEST_CLIENTS], "clients_total": len(snapshots),
                "clients_omitted": max(0, len(snapshots) - MAX_REQUEST_CLIENTS),
                "total": {"by_route": by_route, "by_outcome": by_outcome, "reads": reads, "writes": writes}}
    except Exception as exc:
        return {"schema": 1, "error": type(exc).__name__}


class VenueError(RuntimeError):
    def __init__(self, http: int, code: str | None, msg: str) -> None:
        self.http, self.code, self.msg = http, code, msg
        super().__init__(f"kalshi http {http} code {code}: {msg}")


class OrderStateUnknown(RuntimeError):
    def __init__(self, client_id: str, why: str) -> None:
        super().__init__(f"order {client_id} state unknown: {why}")
        self.client_id = client_id


# A failed venue read (transport, timeout or malformed reply) during account admission.
_VENUE_READ_ERRORS = (VenueError, asyncio.TimeoutError, aiohttp.ClientError, ConnectionError)


# Adapter-only fence classes (A6). account_risk's closed REFUSAL_CODES set is not this
# module's to extend, so these ride an AccountRiskRefused whose code is set after construction.
_ADAPTER_REFUSAL_CODES = frozenset({"exposure_reader_unavailable", "ledger_root_unmapped",
                                    "domain_paused", "domain_pause_unreadable",
                                    "risk_book_unknown", "book_stale",
                                    # B12: the account write budget (kalshi_rate_budget).
                                    "rate_budget_exhausted", "rate_budget_suspended",
                                    "rate_budget_unavailable"})
# C16a: risk books per client-id partition. Bounded: the incumbent, MAX_PROBES_PER_BOOK probes
# and headroom; a registration past it raises instead of growing the map.
MAX_RISK_BOOKS = 16
_RISK_PROBE_PREFIX = "lp-"
_RISK_INCUMBENT_PREFIX = "lh-"
_RISK_PROBE_KEY_LEN = len(_RISK_PROBE_PREFIX) + 4 + 1  # "lp-<4 hex>-"
_RISK_HEX = frozenset("0123456789abcdef")
# A zero-fill retry id (kalshi_book._buy); it names no partition, so it binds to its originating book.
_RISK_RETRY_PREFIX = "lb-r1-"
# A mode-1 reversal leg (kalshi_book.flatten_and_reverse); it names no partition, so it binds to the book whose _reversals holds it.
_RISK_REVERSAL_PREFIX = "lr-"


def _build_risk_probe_index(books) -> dict:
    """The derived probe index of a risk-book map: "lp-abcd-" -> {"a": {"b": {"c": {"d": book}}}}.
    Cold path (register_risk_book only); bounded by MAX_RISK_BOOKS."""
    index: dict = {}
    for partition, book in books.items():
        if partition is not None and partition.startswith(_RISK_PROBE_PREFIX):
            node = index
            for ch in partition[len(_RISK_PROBE_PREFIX):_RISK_PROBE_KEY_LEN - 2]:
                node = node.setdefault(ch, {})
            node[partition[_RISK_PROBE_KEY_LEN - 2]] = book
    return index


def _risk_partition(client_id) -> str:
    """The partition key of a client id: "lp-<code>-" for a probe, "lh-" for the incumbent, else
    "" (never a registered key). Pure, O(1), at most one short slice; never raises."""
    if type(client_id) is not str:
        return ""
    if client_id.startswith(_RISK_PROBE_PREFIX):
        if len(client_id) > _RISK_PROBE_KEY_LEN and client_id[_RISK_PROBE_KEY_LEN - 1] == "-":
            return client_id[:_RISK_PROBE_KEY_LEN]
        return ""
    return _RISK_INCUMBENT_PREFIX if client_id.startswith(_RISK_INCUMBENT_PREFIX) else ""


def _valid_risk_partition(partition) -> bool:
    """True for "lh-" or "lp-<4 lowercase hex>-"; the only keys a partitioned book may take."""
    if partition == _RISK_INCUMBENT_PREFIX:
        return True
    return (type(partition) is str and len(partition) == _RISK_PROBE_KEY_LEN
            and partition.startswith(_RISK_PROBE_PREFIX) and partition[-1] == "-"
            and all(ch in _RISK_HEX for ch in partition[len(_RISK_PROBE_PREFIX):-1]))


def _settled_probe_loss(client_id, row, market):
    """RC2 v3: a settled entry's realized loss for release(probe_loss_cents=): None when the entry
    is not a probe's ("pr" 1, or no "pr" and an "lp-" id; release() ignores the value). A winner
    records cost minus its payout (100c per remaining contract); a loser records its whole cost.
    Unknown side, result or remaining count counts the whole cost conservatively. The remaining
    row count, never the original p.n, is the quantity this full settlement releases. Pure, O(1),
    never raises."""
    try:
        tag = row.get("pr")
        if not ((tag == 1) if tag is not None else
                (type(client_id) is str and client_id.startswith(_RISK_PROBE_PREFIX))):
            return None
        cost = row["cost_cents"]
        provenance = row.get("p")
        side = provenance.get("s") if isinstance(provenance, dict) else None
        result = market.get("result") if isinstance(market, dict) else None
        if side in ("y", "n") and result in ("yes", "no") and (side == "y") == (result == "yes"):
            count = row.get("count")
            if row.get("exact") is False or type(count) not in (str, int, Decimal) or len(str(count)) > 12:
                return cost
            try:
                quantity = Decimal(str(count))
            except (InvalidOperation, ValueError):
                return cost
            if not quantity.is_finite() or not 0 < quantity <= 2**53 - 1:
                return cost
            payout = quantity * 100
            if payout != payout.to_integral_value() or payout > 2**53 - 1:
                return cost
            return cost - int(payout)
        return cost
    except Exception:
        return None


def _refusal_code(exc: BaseException) -> str:
    """The typed code an admission failure keeps through the live wrapper: a recognized
    AccountRiskRefused code, venue_read_failed for a venue read error, else wrapped_error.
    An AccountRiskRefused without a recognized code (uncoded) is wrapped_error, never uncoded."""
    from .account_risk import REFUSAL_CODES, AccountRiskRefused

    if isinstance(exc, AccountRiskRefused):
        code = getattr(exc, "code", None)
        if (code in REFUSAL_CODES and code != "uncoded") or code in _ADAPTER_REFUSAL_CODES:
            return code
        return "wrapped_error"
    if isinstance(exc, _VENUE_READ_ERRORS):
        return "venue_read_failed"
    return "wrapped_error"


def _typed_refusal(message: str, code: str):
    """An AccountRiskRefused carrying code, including the adapter-only A6 classes, without
    tripping the uncoded counter. code must already be recognized (_refusal_code's output)."""
    from .account_risk import AccountRiskRefused

    if code in _ADAPTER_REFUSAL_CODES:
        exc = AccountRiskRefused(message, code="domain_not_exposure_authority")
        exc.code = code
        return exc
    return AccountRiskRefused(message, code=code)


def _open_entries_by_ticker(entries) -> dict[str, list]:
    """One O(E) pass over the ledger: ticker -> [open entries in ledger order, reserved count].
    Replaces the per-position O(P x E) scan; every E0 message field reads from it."""
    index: dict[str, list] = {}
    for entry in entries.values():
        state = entry["state"]
        if state != "open" and state != "reserved":
            continue
        slot = index.get(entry["ticker"])
        if slot is None:
            slot = index[entry["ticker"]] = [[], 0]
        if state == "open":
            slot[0].append(entry)
        else:
            slot[1] += 1
    return index


def _hot_quantities(rows):
    quantities = {}
    for row in rows:
        quantity = Decimal(str(row.get("position_fp", row.get("position"))))
        if quantity:
            quantities[row["ticker"]] = quantities.get(row["ticker"], Decimal(0)) + quantity
    return quantities


def _held_tickers(rows) -> list[str]:
    """Venue tickers with a nonzero position, in venue order, deduplicated. Fails closed
    (venue_malformed) on a row classify_tickers would also refuse."""
    from .account_risk import AccountRiskRefused

    held: dict[str, None] = {}
    for row in rows:
        try:
            market = row.get("ticker")
            quantity = Decimal(str(row.get("position_fp", row.get("position"))))
        except (AttributeError, InvalidOperation, ValueError) as exc:
            raise AccountRiskRefused("invalid account position", code="venue_malformed") from exc
        if not isinstance(market, str) or not market or not quantity.is_finite():
            raise AccountRiskRefused("invalid account position", code="venue_malformed")
        if quantity:
            held[market] = None
    return list(held)


def _foreign_residuals(foreign, entries, rows, now_ns) -> dict[str, str]:
    """ticker -> F, the residual foreign quantity classify_tickers charged at worst case, as
    fixed-point text: |venue| - exact open counts - min(uncovered, fresh same-side v2 cover).
    Mirrors account_risk.classify_tickers' foreign branch; one pass over rows and entries,
    restricted to the (FOREIGN_OPEN_MAX-bounded) foreign tickers."""
    from .account_risk import COVER_WINDOW_NS, _decimal_of, _exact_count

    if not foreign:
        return {}
    wanted = set(foreign)
    quantity: dict[str, Decimal] = {}
    for row in rows:
        market = row.get("ticker") if isinstance(row, dict) else None
        if market in wanted:
            try:
                quantity[market] = _decimal_of(row.get("position_fp", row.get("position")))
            except (InvalidOperation, ValueError):
                continue
    held: dict[str, Decimal] = {}
    cover: dict[str, Decimal] = {}
    for entry in entries.values():
        market = entry.get("ticker")
        if market not in quantity:
            continue
        state = entry.get("state")
        if state == "open":
            count = _exact_count(entry)
            if count is not None:
                held[market] = held.get(market, Decimal(0)) + count
        elif state == "reserved":
            p = entry.get("p")
            if type(p) is not dict or p.get("v") != 2:
                continue
            side = "y" if quantity[market] > 0 else "n"
            age = now_ns - p["t"] if type(p.get("t")) is int else -1
            if p.get("s") != side or not 0 <= age < COVER_WINDOW_NS:
                continue
            try:
                reserved_count = _decimal_of(p["n"])
            except (KeyError, InvalidOperation, ValueError):
                continue
            if reserved_count.is_finite() and reserved_count > 0:
                cover[market] = cover.get(market, Decimal(0)) + reserved_count
    residuals: dict[str, str] = {}
    for market in foreign:
        if market not in quantity:
            continue
        uncovered = abs(quantity[market]) - held.get(market, Decimal(0))
        residual = uncovered - min(uncovered, cover.get(market, Decimal(0)))
        residuals[market] = format(residual, "f")
    return residuals


class _RoleUnreadable:
    """Fail-closed role view (and reader) when the exposure role cannot be read at all."""

    state = "unreadable"
    role = enforcement = generation = None

    def read(self) -> "_RoleUnreadable":
        return self


class _ReaderUnavailable:
    """Enforced fence (A6) only: no role reader could be built (code exposure_reader_unavailable)
    or the ledger has no mapped root (ledger_root_unmapped). Refused, never cached."""

    __slots__ = ("code",)

    def __init__(self, code: str) -> None:
        self.code = code


def _fence_refusal(view) -> str | None:
    """The refusal code when this domain may not open exposure, else None. Mirrors
    exposure_authority.RoleView.refuses_opening: exit_only under operational enforcement, or any
    state that cannot prove authority (unregistered, unreadable, an unmapped ledger root under a
    marker). absent (no marker), observe and authority are byte-identical."""
    state = getattr(view, "state", "unreadable")
    if state == "record":
        if getattr(view, "role", None) == "exit_only" and getattr(view, "enforcement", None) == "operational":
            return "domain_not_exposure_authority"
        return None
    if state == "absent":
        return None
    if state == "domain_ledger_mismatch":
        return "domain_ledger_mismatch"
    return "domain_not_exposure_authority"


def _cents_str(cents: int) -> str:
    if type(cents) is not int or not 1 <= cents <= 99:
        raise MalformedInput(f"price cents out of bounds: {cents!r}")
    return format(Decimal(cents) / Decimal(100), ".2f")


def _decimal(value: Any) -> Decimal:
    if not isinstance(value, str) or not 0 < len(value) <= 40:
        raise ValueError("malformed decimal")
    try:
        d = Decimal(value)
    except InvalidOperation as e:
        raise ValueError("malformed decimal") from e
    if not d.is_finite() or d < 0:
        raise ValueError("malformed decimal")
    return d


def _order_body(ticker: str, side_yes: bool, price_cents: int, count: int, client_id: str,
                expiration_ts: int | None = None) -> dict[str, Any]:
    """expiration_ts (H2a2 mode 2 only): the venue-side expiry in unix seconds, after which the
    venue neither accepts nor rests the order. None (every other caller) leaves the body's keys
    and bytes exactly as before: an IOC with no expiry field.

    Given, the order is a good-till-time limit order, never an IOC: time_in_force
    good_till_canceled plus the wire field expiration_time, the one combination Kalshi documents
    for a venue-enforced expiry. Create Order (V2), POST /portfolio/events/orders, read
    2026-09-23 from https://docs.kalshi.com/api-reference/orders/create-order-v2 :
      expiration_time: "Optional Unix timestamp in seconds for when the order expires. To place
        an expiring order, set `time_in_force` to `good_till_canceled` and provide this
        `expiration_time`. `GTT` is an internal execution type and is not a valid API value for
        `time_in_force`. The `immediate_or_cancel` time-in-force value cannot be combined with
        `expiration_time`."
      time_in_force: "Use `good_till_canceled` with `expiration_time` for an order that should
        rest until a specific expiration time; without `expiration_time`,
        `good_till_canceled` is a true good-till-canceled order."
    Changelog, Nov 21 2025 (https://docs.kalshi.com/changelog), "Order expiration and IoC
    behavior changes": "Orders cannot specify both `time_in_force: "immediate_or_cancel"` and
    `expiration_ts`. This will be rejected at the API level" and "Orders with `expiration_ts` in
    the past will be rejected with error "Expiration timestamp must be in the future"".
    So the body never pairs IOC with an expiry, and V2's field is expiration_time (expiration_ts
    is the legacy name; this module's parameter keeps it). A transaction order that rests is
    accepted: the create reply then shows remaining contracts, _validate_order_reply refuses
    that as not final, the send is UNKNOWN, and the transaction resolves it from order status
    once the venue has expired the remainder (status canceled or executed, nothing remaining)."""
    if not isinstance(ticker, str) or not ticker or len(ticker) > 64:
        raise MalformedInput("ticker")
    if not isinstance(client_id, str) or not 0 < len(client_id) <= 36:
        raise MalformedInput("client id")
    quantity = _fixed_count(str(count)) if isinstance(count, Decimal) else _fixed_count(count)
    if quantity is None or not 0 < quantity <= 100_000:
        raise MalformedInput("count")
    venue_side, venue_cents = ("bid", price_cents) if side_yes else ("ask", 100 - price_cents)
    if type(venue_cents) is not int or not 1 <= venue_cents <= 99:
        raise MalformedInput("price")
    if expiration_ts is not None and (type(expiration_ts) is not int
                                      or not 0 < expiration_ts < 1 << 40):
        raise MalformedInput("expiration_ts")
    body = {
        "ticker": ticker,
        "side": venue_side,
        "count": str(count) if type(count) is int else format(quantity, ".2f"),
        "price": _cents_str(venue_cents),
        "time_in_force": "immediate_or_cancel",
        "self_trade_prevention_type": "taker_at_cross",
        "client_order_id": client_id,
        "post_only": False,
        "reduce_only": False,
    }
    if expiration_ts is not None:
        # Good-till-time, never IOC plus an expiry (the venue rejects that pair; see above).
        body["time_in_force"] = "good_till_canceled"
        body["expiration_time"] = expiration_ts
    return body


class _WireBody(dict):
    """The order body plus its wire text, serialized before SENT (H2a3 fix i), so nothing of ours
    that can fail runs between SENT and the send. Equal to the plain body dict."""
    __slots__ = ("wire",)


def _wire_json(body: dict) -> str:
    """aiohttp's default json_serialize with default arguments, so the wire bytes are unchanged.
    The one serialization seam; it runs before SENT."""
    return json.dumps(body)


def _wire_dumps(obj) -> str:
    """The live session's json_serialize. A _WireBody carries its precomputed wire, so this only
    reads an attribute and cannot fail after SENT; anything else serializes as aiohttp's default."""
    if isinstance(obj, _WireBody):
        return obj.wire
    return json.dumps(obj)


def _fixed_count(value: Any) -> Decimal | None:
    """Exact binary contract count, in contracts with at most two decimal places."""
    if type(value) is int:
        return Decimal(value) if value >= 0 else None
    if not isinstance(value, str) or not 0 < len(value) <= 40:
        return None
    if re.fullmatch(r"[0-9]+(?:\.[0-9]{1,2})?", value) is None:
        return None
    return Decimal(value)


def _count_number(value: Decimal | int) -> int | float:
    """JSON number preserving whole-count bytes and hundredth-contract fractions."""
    return int(value) if value == int(value) else float(value)


def _json_count(value):
    """Preserve Decimal counts nested in execution audits without rounding them: a JSON number,
    the one representation every fractional count takes (ledger, journal, decision rows)."""
    if isinstance(value, Decimal) and _fixed_count(str(value)) is not None:
        return _count_number(value)
    raise TypeError("not a fixed-point count")


def _entry_debit_cents(price_cents: int, count, fee_per_contract_cents: int) -> int:
    """Whole-cent reserve: ceil(price x quantity) + per_contract_ceil fee.

    Keep the existing integer-cent ledger and never round a fractional reserve down.
    The fee's unit has already been rounded by the caller's venue fee model.
    """
    quantity = Decimal(str(count))
    return (int((price_cents * quantity).to_integral_value(rounding=ROUND_CEILING))
            + int((fee_per_contract_cents * quantity).to_integral_value(rounding=ROUND_CEILING)))


def _fill_level_basis(fill, side_yes, *, include_fee=True):
    """Exact per-contract price and total level fee, both in cents."""
    side = "yes" if side_yes else "no"
    key = side + "_price_dollars"
    price = (_decimal(fill[key]) * 100 if key in fill
             else _decimal(str(fill[side + "_price"])))
    if price > 100:
        raise ValueError("fill price out of bounds")
    fee = (Decimal(0) if not include_fee else
           _decimal(str(fill["fee_cents"])) if "fee_cents" in fill else
           _decimal(fill["fee_cost"]) * 100)
    return price, fee


def _embedded_fills(value) -> tuple:
    """Only materialized fill sequences are evidence; malformed values are absent."""
    return tuple(value) if isinstance(value, (list, tuple)) else ()


def _fill_identity_conflict(reply, fills, client_id):
    fills = _embedded_fills(fills)
    oid = reply.get("order_id")
    if client_id and "client_order_id" in reply and reply["client_order_id"] != client_id:
        return True
    for fill in fills:
        if not isinstance(fill, dict):
            continue
        if ((oid and fill.get("order_id") == oid) or
                (client_id and fill.get("client_order_id") == client_id)):
            if ((oid and "order_id" in fill and fill["order_id"] != oid) or
                    (client_id and "client_order_id" in fill and fill["client_order_id"] != client_id)):
                return True
    return False


def _fill_basis(reply, side_yes, fills=(), client_id=None):
    """Whole cents from exact venue dollars, rounded once over the order.

    Absent or incomplete details never masquerade as an actual cost basis.
    The cost is for the outcome bought, including on an opposite-side exit.
    """
    if _fill_identity_conflict(reply, fills, client_id):
        return {}
    cents = lambda value: int(value.quantize(Decimal(1), rounding=ROUND_HALF_UP))
    try:
        if "taker_fill_cost" in reply and "taker_fees" in reply:
            return {"venue_cost_cents": cents(_decimal(reply["taker_fill_cost"]) * 100),
                    "venue_fee_cents": cents(_decimal(reply["taker_fees"]) * 100)}
        total = Decimal(0)
        cost = Decimal(0)
        fees = Decimal(0)
        seen = {}
        for fill in fills:
            if not isinstance(fill, dict) or not (
                    (reply.get("order_id") and fill.get("order_id") == reply["order_id"]) or
                    (client_id and fill.get("client_order_id") == client_id)):
                continue
            identity = fill.get("fill_id", fill.get("trade_id"))
            if not isinstance(identity, str) or not identity:
                return {}
            if identity in seen:
                if seen[identity] != fill:
                    return {}
                continue
            seen[identity] = fill
            count = _fixed_count(fill.get("count_fp", fill.get("count")))
            if count is None or count <= 0:
                return {}
            price, fee = _fill_level_basis(fill, side_yes, include_fee="taker_fees" not in reply)
            total += count
            cost += price * count
            fees += fee
        if total > 0 and total == Decimal(str(reply["fill_count"])):
            return {"venue_cost_cents": cents(cost),
                    "venue_fee_cents": cents(_decimal(reply["taker_fees"]) * 100
                                             if "taker_fees" in reply else fees)}
    except (ValueError, TypeError, KeyError, InvalidOperation):
        pass
    return {}


class KalshiLive:
    """Thin signed client. Holds the PEM in a string that is never formatted anywhere."""

    # Legacy adapters created via __new__ have no instance budget. Normal
    # construction always binds and validates the authorization's budget below.
    account_budget = None
    # Same pattern for the classification mode, so __new__ adapters decide in legacy mode.
    classification_mode = "legacy"
    # Lazily resolved exposure-role reader: None unresolved, False when no fence applies.
    _exposure_role = None
    _refusals_by_code = None
    _exposure_status = None
    _minute_cache = None
    # Proven-unsent send-boundary cleanups still to resolve: cid -> 0 (the count). Non-empty
    # keeps the entry stop (risk_posting_failed); mirrored to RISK_CLEANUP_FILE.
    _risk_cleanup = None
    # RISK_CLEANUP_FILE writes that failed (logged; reported by latency_snapshot while nonzero).
    risk_cleanup_write_failed = 0
    # Ticker-mode admissions that charged a worst-case consumption, and its cents, since start.
    _worst_case_admissions = 0
    _worst_case_cents = 0
    # RC1: admissions whose one jittered revision_conflict retry admitted (latency_snapshot while
    # nonzero); a double conflict is a final refusal journaled with retried=true instead.
    revision_conflict_recovered = 0
    # RC1 seams, class-level so __new__ adapters work: the retry delay in seconds, and its sleep.
    _risk_retry_jitter = staticmethod(lambda: random.uniform(REVISION_RETRY_JITTER_MIN_S,
                                                             REVISION_RETRY_JITTER_MAX_S))
    _risk_retry_sleep = staticmethod(lambda delay: asyncio.sleep(delay))
    # C16a: partition key -> risk book; None is the default slot (the legacy single pointer).
    # Lazily created on the instance, so __new__ adapters work unchanged.
    _risk_books = None
    # C16a: the probe partitions of _risk_books keyed by hex character (_build_risk_probe_index);
    # rebuilt by register_risk_book on every set or clear, never written anywhere else.
    _risk_probe_index = None
    # widen-reqcounter: request counters (route -> n, outcome -> n) and their wall-clock start;
    # created lazily on __new__ adapters, exactly as _signed creates its latency reservoirs.
    _req_by_route = None
    _req_by_outcome = None
    _req_since_ms = 0
    # Counter updates that failed; counting never raises into a request.
    request_counter_errors = 0
    # B12: the account-wide write budget (KalshiRateBudget); None skips every budget path.
    _rate_budget = None
    # B12-read: the account-wide read budget (a KalshiRateBudget with scope "read"); None skips it.
    _read_budget = None
    hot_observation_mode = "off"
    _fills_basis_counts = None
    _fills_basis_counted = None
    _fills_basis_suspended_until = 0.0

    def _count_fills_basis(self, name, amount=1):
        if self._fills_basis_counts is None:
            self._fills_basis_counts = {}
        key = "fills_basis_" + name
        self._fills_basis_counts[key] = min(2**63 - 1, self._fills_basis_counts.get(key, 0) + amount)

    def _count_fills_resolution(self, cid, outcome):
        if outcome is None:
            return
        if self._fills_basis_counted is None:
            self._fills_basis_counted = set()
        # UNKNOWN account-budget outcomes can be revisited; count the risk posting once.
        # Like _records, this set cannot exceed MAX_OWNED.
        if cid not in self._fills_basis_counted:
            self._fills_basis_counted.add(cid)
            self._count_fills_basis(outcome)

    def _fills_retry_suspended(self):
        if time.monotonic() < self._fills_basis_suspended_until:
            return True
        for budget in (self._rate_budget, self._read_budget):
            if budget is None:
                continue
            try:
                suspended = budget.snapshot().get("probe_suspended_for_s", 0)
                if (not isinstance(suspended, Real) or isinstance(suspended, bool)
                        or not math.isfinite(suspended) or suspended > 0):
                    return True
            except Exception:
                # Missing or broken budget evidence must only suppress the retry.
                return True
        return False

    def _count_fills_evidence(self, reply, fills, cid):
        fills = _embedded_fills(fills)
        matches = [f for f in fills if isinstance(f, dict) and (
            (reply.get("order_id") and f.get("order_id") == reply["order_id"]) or
            f.get("client_order_id") == cid)]
        if not matches:
            unsupported = any(key in reply for key in ("taker_fill_cost_dollars", "taker_fees_dollars"))
            self._count_fills_basis("evidence_unsupported" if unsupported else "evidence_empty")
            return
        quantities, seen = [], {}
        for fill in matches:
            identity = fill.get("fill_id", fill.get("trade_id"))
            count = _fixed_count(fill.get("count_fp", fill.get("count")))
            if (not isinstance(identity, str) or not identity or count is None or count <= 0
                    or (identity in seen and seen[identity] != fill)):
                self._count_fills_basis("evidence_malformed")
                return
            if identity not in seen:
                quantities.append(count)
                seen[identity] = fill
        self._count_fills_basis("evidence_partial" if sum(quantities) < Decimal(str(reply["fill_count"]))
                                else "evidence_unsupported")

    async def _entry_fill_basis(self, cid, reply, *, prepared=False, exit_only=False, deadline=None):
        """The caller holds the shared send lock: sends, exits and reconcile wait, shared
        probes refuse shared_client_busy, and exposure publication waits. No SQLite
        transaction spans these awaits; the event loop can continue feed heartbeats.
        Only the added retries share the deadline; the existing first walk is unchanged.
        """
        record = self._records[cid]
        side = record["side_yes"]
        fills = _embedded_fills(reply.get("fills"))
        basis = _fill_basis(reply, side, fills, cid)
        if not reply["fill_count"]:
            return basis, fills, None
        if prepared:
            return basis, fills, "exit_skipped" if exit_only else "prepared_skipped"
        if exit_only:
            # Exits retain the existing first walk, but never use added retries.
            if _fill_identity_conflict(reply, fills, cid):
                return {}, fills, "exit_skipped"
            if not basis:
                try:
                    fills = _embedded_fills(await self.fills_complete(record.get("sent_ts_ns")))
                    basis = ({} if _fill_identity_conflict(reply, fills, cid) else
                             _fill_basis(reply, side, fills, cid))
                except (VenueError, asyncio.TimeoutError, aiohttp.ClientError, ConnectionError):
                    pass
            return basis, fills, "exit_skipped"
        if _fill_identity_conflict(reply, fills, cid):
            return {}, fills, "identity_conflict"
        if basis:
            return basis, fills, "direct"
        deadline = [None] if deadline is None else deadline
        started = None
        try:
            for attempt in range(FILLS_BASIS_RETRIES + 1):
                if attempt:
                    if self._fills_retry_suspended():
                        return {}, fills, "rate_limited"
                    now = time.monotonic()
                    while _FILLS_BASIS_RETRY_WALKS and _FILLS_BASIS_RETRY_WALKS[0] <= now - 60:
                        _FILLS_BASIS_RETRY_WALKS.popleft()
                    if len(_FILLS_BASIS_RETRY_WALKS) >= 20:
                        return {}, fills, "rate_limited"
                    if started is None:
                        started = now
                    if deadline[0] is None:
                        deadline[0] = now + FILLS_BASIS_RETRY_BUDGET_S
                    delay = FILLS_BASIS_RETRY_DELAYS_S[attempt - 1]
                    if deadline[0] - now < delay + 0.5:
                        break
                    await asyncio.sleep(delay)
                    now = time.monotonic()
                    remaining = deadline[0] - now
                    if remaining < 0.5:
                        break
                    # Recheck after yielding: another client may have consumed the last slot.
                    while _FILLS_BASIS_RETRY_WALKS and _FILLS_BASIS_RETRY_WALKS[0] <= now - 60:
                        _FILLS_BASIS_RETRY_WALKS.popleft()
                    if len(_FILLS_BASIS_RETRY_WALKS) >= 20 or self._fills_retry_suspended():
                        return {}, fills, "rate_limited"
                    _FILLS_BASIS_RETRY_WALKS.append(now)
                    token = _fills_basis_retry_active.set(True)
                    try:
                        fills = await asyncio.wait_for(
                            self.fills_complete(record.get("sent_ts_ns")), remaining)
                    finally:
                        _fills_basis_retry_active.reset(token)
                else:
                    fills = await self.fills_complete(record.get("sent_ts_ns"))
                fills = _embedded_fills(fills)
                if _fill_identity_conflict(reply, fills, cid):
                    return {}, fills, "identity_conflict"
                basis = _fill_basis(reply, side, fills, cid)
                if basis:
                    return basis, fills, "first_lookup" if not attempt else f"retry_{attempt}"
                self._count_fills_evidence(reply, fills, cid)
        except (VenueError, asyncio.TimeoutError, aiohttp.ClientError, ConnectionError) as exc:
            if isinstance(exc, VenueError) and exc.http == 429:
                from .kalshi_rate_budget import PROBE_SUSPEND_S
                self._fills_basis_suspended_until = time.monotonic() + PROBE_SUSPEND_S
                self._count_fills_basis("evidence_transport")
                return {}, fills, "rate_limited"
            diagnostic = ("incomplete" if isinstance(exc, VenueError) and "incomplete" in exc.msg else
                          "malformed" if isinstance(exc, VenueError) and exc.http == 200 else "transport")
            self._count_fills_basis("evidence_" + diagnostic)
        finally:
            if started is not None:
                self._count_fills_basis("retry_elapsed_ms", max(0, int((time.monotonic() - started) * 1000)))
        return {}, fills, "missing"

    @property
    def _risk_book(self):
        """The default-slot risk book (the legacy single pointer); None when none is registered."""
        books = self._risk_books
        return books.get(None) if books else None

    @_risk_book.setter
    def _risk_book(self, book) -> None:
        self.register_risk_book(book)

    def register_risk_book(self, book, partition=None) -> None:
        """Bind book to a client-id partition ("lh-" or "lp-<code>-"); partition None is the
        default slot, where a later registration replaces the book. A partitioned slot keeps its
        owner: another book raises (risk book partition occupied) and leaves the slot unchanged,
        the same book is a no-op, and book None clears it (the explicit release). Fails closed on
        a malformed partition or a full map (MAX_RISK_BOOKS). Cold path: rebuilds the probe index."""
        if partition is not None and not _valid_risk_partition(partition):
            raise ValueError(f"risk book partition must be None, 'lh-' or 'lp-<4 hex>-': {partition!r}"[:120])
        books = self.__dict__.get("_risk_books")
        if books is None:
            books = self._risk_books = {}
        if book is None:
            books.pop(partition, None)
        else:
            if partition is not None and partition in books and books[partition] is not book:
                raise ValueError(f"risk book partition occupied: {partition}")
            if partition not in books and len(books) >= MAX_RISK_BOOKS:
                raise ValueError(f"risk book map full ({MAX_RISK_BOOKS})")
            books[partition] = book
        self._risk_probe_index = _build_risk_probe_index(books)

    def _risk_book_for(self, client_id):
        """The risk book that owns client_id. O(1), no scan and no allocation: the constant
        "lh-" key, or at most four one-character dict gets on the probe index for an
        "lp-<code>-" id (single characters of a str are cached, so nothing is sliced). With only
        the default slot registered this is that book for every id, byte-identical to the single
        pointer. Once a partitioned book is registered, an "lb-r1-" zero-fill retry binds to the
        one partitioned book whose _risk_requests holds the exact id (retries only, at most
        MAX_RISK_BOOKS membership tests), and an id whose partition has no book refuses
        risk_book_unknown and is never routed to the default. An "lr-" reversal leg binds the same
        way to the one partitioned book whose _reversals holds the exact id (flatten_and_reverse
        records it before the send)."""
        books = self._risk_books
        if not books:
            return None
        if len(books) == 1 and None in books:
            return books[None]
        book = None
        if type(client_id) is str:
            if client_id.startswith(_RISK_PROBE_PREFIX):
                # "lp-<4 hex>-...": index 7 is the dash, indexes 3..6 the code.
                if len(client_id) > 8 and client_id[7] == "-":
                    node = self._risk_probe_index
                    node = node.get(client_id[3]) if node else None
                    node = node.get(client_id[4]) if node else None
                    node = node.get(client_id[5]) if node else None
                    book = node.get(client_id[6]) if node else None
            elif client_id.startswith(_RISK_INCUMBENT_PREFIX):
                book = books.get(_RISK_INCUMBENT_PREFIX)
            elif client_id.startswith(_RISK_RETRY_PREFIX):
                return self._risk_retry_book(client_id)
            elif client_id.startswith(_RISK_REVERSAL_PREFIX):
                return self._risk_holder_book(client_id, "_reversals", _RISK_REVERSAL_PREFIX, "reversal")
        if book is None:
            partition = _risk_partition(client_id)
            raise _typed_refusal("no risk book registered for client id partition "
                                 f"{partition or '(none)'}", "risk_book_unknown")
        return book

    def _risk_retry_book(self, client_id):
        """The originating book of an "lb-r1-" zero-fill retry: the unique partitioned book (never
        the default slot) whose _risk_requests holds the exact id, which _buy records before the
        send. Zero or two distinct holders refuse risk_book_unknown. Bounded by MAX_RISK_BOOKS."""
        return self._risk_holder_book(client_id, "_risk_requests", _RISK_RETRY_PREFIX, "retry")

    def _risk_holder_book(self, client_id, attr, prefix, noun):
        """C16a-b: the unique partitioned book (never the default slot) whose `attr` mapping holds
        client_id exactly; zero or two distinct holders refuse risk_book_unknown. Cold path (retries
        and reversal legs only): at most MAX_RISK_BOOKS membership tests, no I/O."""
        found = None
        for partition, book in self._risk_books.items():
            if partition is None or book is found:
                continue
            held = getattr(book, attr, None)
            if held is not None and client_id in held:
                if found is not None:
                    raise _typed_refusal("no risk book registered for client id partition "
                                         f"{prefix} (two books hold the {noun} id)", "risk_book_unknown")
                found = book
        if found is None:
            raise _typed_refusal("no risk book registered for client id partition "
                                 f"{prefix} (no book holds the {noun} id)", "risk_book_unknown")
        return found

    def shared_send_blocker(self, ticker) -> str | None:
        """C16a-b: what place_ioc_buy would refuse a NEW send on `ticker` for, asked before any
        journal row or authority claim, and only on a client that holds a partitioned risk book
        (Stage B executor mode); None on a default-slot-only client, so a flag-off book never
        changes. "market_locked" when a locked reversal sits on ticker; "unresolved_orders" when any
        other order is SENT or UNKNOWN (a locked reversal on ANOTHER market does not count, exactly
        as in place_ioc_buy). Advisory: the send lock is not held, so a send that races it still
        meets place_ioc_buy's own check. Read-only, no I/O, O(records + owned), bounded by
        MAX_OWNED. Never raises: an internal error answers "unresolved_orders" (nothing is sent)."""
        books = self._risk_books
        if not books or all(partition is None for partition in books):
            return None
        try:
            records = self._records
            for record in records.values():
                reversal = record.get("reversal")
                if isinstance(reversal, dict) and reversal.get("locked") and record.get("ticker") == ticker:
                    return "market_locked"
            for cid, state in self._owned.items():
                if state != "SENT" and state != "UNKNOWN":
                    continue
                record = records.get(cid) or {}
                reversal = record.get("reversal")
                if isinstance(reversal, dict) and reversal.get("locked") and record.get("ticker") != ticker:
                    continue
                return "unresolved_orders"
            return None
        except Exception:
            return "unresolved_orders"

    def _risk_probe_terms(self, client_id, default_policy):
        """RC2/N20: (probe, account_policy, drawdown_policy) for reserve(). An "lp-" id, and
        an "lb-r1-" retry or "lr-" reversal leg of a book registered under an "lp-" partition, are
        probes. _rate_kind's error fallback is "probe"; unavailable incumbent drawdown policy
        fails closed at reserve(). Reduce-only sends never
        reserve entry risk, so "exit" cannot arise. account_policy is the ACCOUNT base policy the
        incumbent book registered under "lh-" uses. Stage A uses the default book's policy for an
        incumbent and DEFAULT_POLICY for a probe, never the probe engine's own policy. No book
        means None. Tenant lanes also get None: incumbents keep reserve 0 and explicit probes
        fail closed until a tenant reserve is designed. Probe drawdown uses the current incumbent
        policy: Stage A's incumbent_policy_source callable or the shared lh- book. Its lookup
        fails independently to DRAWDOWN_POLICY_UNAVAILABLE for a usable account_policy,
        never changing account_policy. O(1) plus _rate_kind."""
        probe = self._rate_kind(client_id, {}) == "probe"
        try:
            book = (self._risk_books or {}).get(_RISK_INCUMBENT_PREFIX)
            stage_a = book is None
            if stage_a:
                book = (self._risk_books or {}).get(None)
                if book is None:
                    return probe, None, None
                # Stage A binds the probe-only _ProbeFloorRiskLedger to book.account_risk.
                # Its floor_refused method is the existing probe signal, including lb-r1-/lr-
                # legs whose ids lose lp-. A book without that signal keeps the id-based class.
                probe = probe or callable(getattr(getattr(book, "account_risk", None), "floor_refused", None))
            # The root-owned tenant drop-in is the scope signal, exactly as in risk_regime().
            # Owner books can run the account regime too; LEAFHFT_RISK_REGIME is not this gate.
            if os.environ.get("LEAFHFT_ACCOUNT_LANE_ID"):
                return probe, None, None
            if stage_a and probe:
                from ..policy import DEFAULT_POLICY

                # Stage A probes use DEFAULT_POLICY, incumbents the file policy. Both are 0.15
                # today and clamped by hard_maxima; they diverge only if the file falls below 0.15.
                account_policy = DEFAULT_POLICY
            else:
                account_policy = getattr(getattr(book, "risk_strategy", book), "risk_policy", default_policy)
        except Exception:
            return probe, None, None
        drawdown_policy = None
        if probe:
            try:
                if stage_a:
                    source = getattr(self, "incumbent_policy_source", None)
                    drawdown_policy = source() if callable(source) else None
                else:
                    drawdown_policy = getattr(getattr(book, "risk_strategy", book), "risk_policy", None)
            except Exception:
                drawdown_policy = None
            from .account_risk import DRAWDOWN_POLICY_UNAVAILABLE, _drawdown_fractions, _reserve_fraction

            if _reserve_fraction(account_policy)[0] is not None and _drawdown_fractions(drawdown_policy) is None:
                drawdown_policy = DRAWDOWN_POLICY_UNAVAILABLE
        return probe, account_policy, drawdown_policy

    def _rate_kind(self, client_id, body) -> str:
        """B12 write class of a send, from the id it already carries: reduce-only is "exit", an
        "lp-<code>-" id is "probe", an "lb-r1-" retry or an "lr-" reversal leg is "probe" when its book is registered under
        an "lp-" partition (reverse lookup over at most MAX_RISK_BOOKS), else everything is
        "entry". Never raises: an unresolvable retry, or any error, is "probe" (the stricter)."""
        try:
            if body.get("reduce_only"):
                return "exit"
            if _risk_partition(client_id).startswith(_RISK_PROBE_PREFIX):
                return "probe"
            if type(client_id) is str and client_id.startswith((_RISK_RETRY_PREFIX, _RISK_REVERSAL_PREFIX)):
                book = self._risk_book_for(client_id)
                for partition, held in (self._risk_books or {}).items():
                    if held is book and partition is not None and partition.startswith(_RISK_PROBE_PREFIX):
                        return "probe"
            return "entry"
        except Exception:
            return "probe"

    def __init__(self, auth: LiveAuthorization, key_id: str | None = None, private_key_pem: str | None = None,
                 base_url: str = REST_URL, *, journal_dir: str | Path, account_budget=None,
                 identity_path=None, classification_mode: str = "legacy", rate_budget=None,
                 read_budget=None, hot_observation_mode="off",
                 hot_observation_path="/run/leafhft-hot/observation.json") -> None:
        if not isinstance(auth, LiveAuthorization):
            raise LiveGateClosed("live client requires a LiveAuthorization from assert_armed()")
        if auth.venue != "kalshi":
            raise LiveGateClosed("authorization is for another venue")
        if classification_mode not in CLASSIFICATION_MODES:
            raise ValueError("classification_mode must be 'legacy' or 'ticker'")
        self.classification_mode = classification_mode
        if hot_observation_mode not in ("off", "shadow", "use"):
            raise ValueError("hot_observation_mode must be 'off', 'shadow' or 'use'")
        self.hot_observation_mode = hot_observation_mode
        if hot_observation_mode != "off":
            self.hot_observation_path = hot_observation_path
            self._hot_clock = _HotClock()
            self._hot_counts = dict.fromkeys(("hot_eligible", "hot_hit", "hot_used", "hot_equal",
                                             "hot_diverged", "hot_incomparable", "hot_revision_conflict"), 0)
            self._hot_misses = {}
            self._hot_latency = LatencyReservoir()
        auth.check(time.time_ns())
        key_id = key_id if key_id is not None else os.environ.get(CRED_KEY_ID_ENV, "")
        pem = private_key_pem if private_key_pem is not None else os.environ.get(CRED_PEM_ENV, "")
        if len(key_id) < 8 or len(pem) < 32:
            raise PermissionError("kalshi credentials missing")
        self.auth = auth
        from ..bookd.freshness import pin_configured_source
        pin_configured_source(auth.symbol)
        self.account_budget = account_budget if account_budget is not None else auth.account_budget
        if self.account_budget is not None:
            from .account_live_budget import AccountLiveBudget
            if not isinstance(self.account_budget, AccountLiveBudget):
                raise LiveGateClosed("invalid account live budget")
        if rate_budget is not None or read_budget is not None:
            from .kalshi_rate_budget import KalshiRateBudget
            if rate_budget is not None:
                if not isinstance(rate_budget, KalshiRateBudget) or rate_budget.scope != "write":
                    raise LiveGateClosed("invalid kalshi rate budget")
                if not rate_budget.matches_key(key_id):  # a budget on another credential bounds nothing
                    raise LiveGateClosed("kalshi rate budget is for another credential")
                self._rate_budget = rate_budget
            if read_budget is not None:
                if not isinstance(read_budget, KalshiRateBudget) or read_budget.scope != "read":
                    raise LiveGateClosed("invalid kalshi read budget")
                if not read_budget.matches_key(key_id):
                    raise LiveGateClosed("kalshi read budget is for another credential")
                self._read_budget = read_budget
        self._key_id = key_id
        self._pem = pem.replace("\\n", "\n")
        self.base_url = base_url
        from .account_risk import VerifiedAccountRiskLedger
        identity_path = identity_path or os.environ.get("LEAFHFT_DASHBOARD_ACCOUNT_IDENTITY_PATH")
        if not identity_path:
            identity_path = (self.account_budget.path.parent / "dashboard-account-identity.json"
                             if self.account_budget is not None else
                             Path("/var/lib/leafhft/dashboard-account.json"))
        self.account_risk = VerifiedAccountRiskLedger(
            Path(os.environ.get("LEAFHFT_ACCOUNT_RISK_ROOT", "/var/lib/leafhft/account-risk")),
            identity_path, legacy_paths=[
                (self.account_budget.path.parent if self.account_budget is not None else
                 Path(os.environ.get("LEAFHFT_STATE_DIR", "/var/lib/leafhft"))) / "account-risk.sqlite3"])
        self._session: aiohttp.ClientSession | None = None
        self._order_latency = LatencyReservoir()
        self._read_latency = LatencyReservoir()
        self._init_request_counters()
        self.price_refused = 0
        self.risk_trims = 0
        self.venue_rejections: dict[str, int] = {}
        self.reconcile_deferred_grace = 0
        self.reconcile_journal_ts_invalid = 0
        # cid -> monotonic ns of its FIRST deferral in this process. Bounds the deferral against
        # a backward wall-clock step; cleared the moment a record is read, so it is bounded by
        # the number of currently deferred records and therefore by MAX_OWNED.
        self._first_deferred_mono: dict[str, int] = {}
        self._owned: dict[str, str] = {}
        self.unresolved: list[str] = []
        self._records: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()
        self._journal_failed = False
        self._attribution_failed = False
        self._entry_attributions = {}
        # client_id -> model fee per contract of a fixed_count entry, set by KalshiBook just before
        # place_ioc_buy and popped there (or by the book when the send never arrives). A side
        # channel, so no owner's place_ioc_buy wrapper ever sees a new keyword. Bounded by sends
        # in flight.
        self._entry_model_fees: dict[str, int] = {}
        self.shutdown_result: dict[str, Any] | None = None
        self.journal_path = Path(journal_dir) / "live-orders.jsonl"
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)
        self.load_journal()
        self._load_risk_cleanup()
        self._scan_durable_risk_cleanup()
        try:
            with self.journal_path.with_name("decision-attribution.jsonl").open("rb") as stream:
                evidence = stream.read(MAX_JOURNAL_BYTES + 1)
            if len(evidence) >= MAX_JOURNAL_BYTES or (evidence and not evidence.endswith(b"\n")):
                self._attribution_failed = True
            else:
                for line in evidence.splitlines():
                    row = orjson.loads(line)
                    if attribution_or_unknown(row.get("attribution"))["status"] != "known":
                        self._attribution_failed = True
                        break
        except FileNotFoundError:
            pass
        except Exception:
            self._attribution_failed = True
        _CLIENTS.add(self)  # last: a constructor that raised never registers

    def __repr__(self) -> str:
        return f"KalshiLive(nonce={self.auth.nonce})"

    def attribution_account(self):
        return self.account_risk.principal

    def _refresh_unresolved(self) -> None:
        self.unresolved = [cid for cid, state in self._owned.items() if state in {"SENT", "UNKNOWN"}]

    @property
    def unreconcilable(self) -> int:
        return sum(state == "UNRECONCILABLE" for state in self._owned.values())

    def load_journal(self) -> None:
        records: dict[str, dict[str, Any]] = {}
        # Legacy rows carry no send episode, so reconstruct one from the rows themselves: the
        # latest SENT row's clock, else the cid's earliest row. Both dicts are bounded by the
        # MAX_OWNED check below, so this stays O(rows) with no unbounded state.
        latest_sent_ts: dict[str, int] = {}
        earliest_ts: dict[str, int] = {}
        try:
            with self.journal_path.open("rb") as journal:
                data = journal.read(MAX_JOURNAL_BYTES + 1)
        except FileNotFoundError:
            data = b""
        if len(data) > MAX_JOURNAL_BYTES:
            raise RuntimeError("kalshi live order journal exceeds 1 MB; archive and restart")
        if data and not data.endswith(b"\n"):
            raise RuntimeError("kalshi live order journal has an incomplete row")
        try:
            for line in data.splitlines():
                row = orjson.loads(line)
                cid, state = row["client_id"], row["state"]
                if not isinstance(cid, str) or not 0 < len(cid) <= 36 or state not in STATES:
                    raise ValueError("invalid identity or state")
                if not isinstance(row["ticker"], str) or not row["ticker"]:
                    raise ValueError("invalid ticker")
                if not isinstance(row["side_yes"], bool):
                    raise ValueError("invalid side")
                if type(row["price_cents"]) is not int or not 1 <= row["price_cents"] <= 99:
                    raise ValueError("invalid price")
                requested = (_fixed_count(str(row["count"])) if "reversal" in row or type(row["count"]) is float else
                             _fixed_count(row["count"]) if type(row["count"]) is int else None)
                if requested is None or requested <= 0:
                    raise ValueError("invalid count")
                filled = row.get("fill_count", 0)
                filled = _fixed_count(str(filled)) if type(filled) is float else _fixed_count(filled)
                if filled is None or not 0 <= filled <= requested:
                    raise ValueError("invalid fill count")
                row["fill_count"] = _count_number(filled)
                oid = row.get("venue_order_id")
                oid_ok = isinstance(oid, str) and 0 < len(oid) <= 64
                oid_ok_legacy = type(oid) is int and oid >= 0  # tolerate an int id from an old journal
                if oid is not None and not oid_ok and not oid_ok_legacy:
                    raise ValueError("invalid order id")
                if not isinstance(row["note"], str) or type(row["ts_ns"]) is not int:
                    raise ValueError("invalid note or timestamp")
                episode = row.get("sent_ts_ns")  # optional: absent on every pre-grace journal
                if episode is not None and (type(episode) is not int or episode <= 0):
                    raise ValueError("invalid send episode timestamp")
                if state == "SENT":
                    latest_sent_ts[cid] = row["ts_ns"]
                earliest_ts.setdefault(cid, row["ts_ns"])
                records[cid] = row
                if len(records) > MAX_OWNED:
                    raise RuntimeError("owned order table exceeds MAX_OWNED")
        except (ValueError, TypeError, KeyError) as e:
            raise RuntimeError("malformed kalshi live order journal") from e
        for cid, row in records.items():
            row["attribution"] = attribution_or_unknown(row.get("attribution"))
            if row.get("sent_ts_ns") is None:  # in memory only; the journal is never rewritten
                reconstructed = latest_sent_ts.get(cid, earliest_ts[cid])
                if reconstructed > 0:  # a non-positive clock is no episode; fail closed instead
                    row["sent_ts_ns"] = reconstructed
        self._records = records
        self._owned = {cid: row["state"] for cid, row in records.items()}
        self._refresh_unresolved()

    def _transition(self, client_id: str, state: str, note: str, *, send_episode: bool = False,
                    **updates: Any) -> None:
        """`send_episode` opens a new send episode: `sent_ts_ns` takes this row's own `ts_ns`
        from a single clock read. Every later row copies it unchanged through the row copy
        below, so a repeated UNKNOWN never extends the reconcile grace."""
        row = dict(self._records[client_id])
        row["attribution"] = attribution_or_unknown(row.get("attribution"))
        now = time.time_ns()
        if send_episode:
            updates = dict(updates, sent_ts_ns=now)
        row.update(updates, ts_ns=now, client_id=client_id, state=state, note=note)
        if isinstance(row.get("fill_count"), Decimal):
            row["fill_count"] = _count_number(row["fill_count"])
        payload = orjson.dumps(row) + b"\n"
        try:
            current_size = self.journal_path.stat().st_size
        except FileNotFoundError:
            current_size = 0
        if current_size + len(payload) > MAX_JOURNAL_BYTES:
            self._journal_failed = True
            raise RuntimeError("kalshi live order journal at 1 MB; archive and restart")
        try:
            with self.journal_path.open("ab") as journal:
                journal.write(payload)
                journal.flush()
                os.fsync(journal.fileno())
        except OSError:
            self._journal_failed = True
            self._owned[client_id] = "UNKNOWN"
            self._refresh_unresolved()
            raise
        self._records[client_id] = row
        self._owned[client_id] = state
        self._refresh_unresolved()

    async def __aenter__(self) -> "KalshiLive":
        trace = aiohttp.TraceConfig()
        trace.on_connection_reuseconn.append(_decision_connection_reused)
        trace.on_connection_create_end.append(_decision_connection_created)
        self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=TIMEOUT_S),
                                              connector=aiohttp.TCPConnector(keepalive_timeout=KEEPALIVE_S),
                                              json_serialize=_wire_dumps, trace_configs=[trace])
        return self

    async def __aexit__(self, *exc) -> None:
        try:
            self.shutdown_result = await self.cancel_owned()
        finally:
            if self._session is not None:
                await self._session.close()
                self._session = None

    def _validate_order_reply(self, reply: Any, count: int) -> Any:
        """V2 create-order reply: order_id a string, fill_count/remaining_count fixed-point
        strings ("1.00") parsed to exact contract counts."""
        try:
            if not isinstance(reply, dict):
                raise ValueError("object")
            oid = reply.get("order_id")
            if not isinstance(oid, str) or not 0 < len(oid) <= 64:
                raise ValueError("order id")
            filled = _fixed_count(reply.get("fill_count_fp", reply.get("fill_count")))
            remaining = _fixed_count(reply.get("remaining_count_fp", reply.get("remaining_count")))
            if filled is None or remaining is None:
                raise ValueError("counts")
            if filled > count:
                raise ValueError("fill_count exceeds requested count")
            if remaining != 0:
                raise ValueError("IOC order left contracts resting")
            if "average_fill_price" in reply:
                _decimal(reply["average_fill_price"])
            if "average_fee_paid" in reply:
                _decimal(reply["average_fee_paid"])
            ts_ms = reply.get("ts_ms")
            if ts_ms is not None and (type(ts_ms) is not int or ts_ms < 0):
                raise ValueError("ts_ms")
        except (ValueError, TypeError, KeyError, InvalidOperation) as e:
            raise VenueError(200, None, "malformed") from e
        out = dict(reply)
        out["fill_count"] = int(filled) if filled == int(filled) else filled
        out["remaining_count"] = int(remaining)
        return out

    def _validate_status_reply(self, reply: Any, count: int | None = None) -> Any:
        """V2 get-order reply: order_id a string; counts preferred from fill_count_fp/
        remaining_count_fp, falling back to the legacy fill_count/remaining_count ints."""
        if type(count) is float:
            count = Decimal(str(count))
        try:
            if not isinstance(reply, dict):
                raise ValueError("object")
            oid = reply.get("order_id")
            if not isinstance(oid, str) or not 0 < len(oid) <= 64:
                raise ValueError("order id")
            if "fill_count_fp" in reply or "remaining_count_fp" in reply:
                filled = _fixed_count(reply.get("fill_count_fp"))
                remaining = _fixed_count(reply.get("remaining_count_fp"))
            else:
                filled = _fixed_count(reply.get("fill_count"))
                remaining = _fixed_count(reply.get("remaining_count"))
            if filled is None or remaining is None:
                raise ValueError("counts")
            if count is not None and (filled > count or remaining > count or filled + remaining > count):
                raise ValueError("counts exceed requested count")
            status = reply.get("status")
            if status is not None and (not isinstance(status, str) or not status):
                raise ValueError("status")
        except (ValueError, TypeError, KeyError) as e:
            raise VenueError(200, None, "malformed") from e
        out = dict(reply)
        out["fill_count"] = int(filled) if filled == int(filled) else filled
        out["remaining_count"] = int(remaining) if remaining == int(remaining) else remaining
        return out

    def _init_request_counters(self) -> dict[str, int]:
        self._req_since_ms = int(time.time() * 1000)
        self._req_by_outcome = dict.fromkeys(REQUEST_OUTCOMES, 0)
        self._req_by_route = dict.fromkeys(REQUEST_ROUTES, 0)
        return self._req_by_route

    def _request_counter_failed(self) -> None:
        try:
            self.request_counter_errors += 1
        except Exception:
            pass

    def _count_request(self, route: str) -> None:
        """Hot path: one int increment at issue. No allocation, no lock, no I/O; never raises."""
        try:
            by_route = self._req_by_route
            if by_route is None:
                by_route = self._init_request_counters()
            by_route[route] += 1
        except Exception:
            self._request_counter_failed()

    def _count_outcome(self, outcome: str) -> None:
        """Hot path: one int increment once the outcome is known. Never raises."""
        try:
            by_outcome = self._req_by_outcome
            if by_outcome is None:
                self._init_request_counters()
                by_outcome = self._req_by_outcome
            by_outcome[outcome] += 1
        except Exception:
            self._request_counter_failed()

    def request_snapshot(self) -> dict[str, Any]:
        """This client's request counts since construction; writes are creates plus cancels."""
        if self._req_by_route is None or self._req_by_outcome is None:
            self._init_request_counters()
        by_route = {route: int(self._req_by_route[route]) for route in REQUEST_ROUTES}
        by_outcome = {outcome: int(self._req_by_outcome[outcome]) for outcome in REQUEST_OUTCOMES}
        writes = sum(by_route[route] for route in REQUEST_WRITE_ROUTES)
        journal = getattr(self, "journal_path", None)
        label = _LABEL_UNSAFE.sub("_", str(journal.parent.name)[:64]) if journal is not None else ""
        return {"schema": 1, "label": label or "unknown", "since_ms": int(self._req_since_ms),
                "by_route": by_route, "by_outcome": by_outcome,
                "reads": sum(by_route.values()) - writes, "writes": writes}

    async def _execute(self, method: str, path: str, url: str, *, mutating: bool, cid: str) -> Any:
        if self._session is None:
            raise RuntimeError("client not entered")
        http = 0
        headers = self._headers(method, path)
        try:
            self._count_request(_request_route(method, path))
            if method == "GET":
                _decision_add("http_reads", 1)
            async with self._session.request(method, url, headers=headers) as resp:
                http = resp.status
                self._count_outcome(_request_outcome(http))
                body = bytearray()
                async for chunk in resp.content.iter_chunked(65536):
                    body.extend(chunk)
                    if len(body) > 1 << 20:
                        raise VenueError(http, None, "malformed")
                try:
                    reply = orjson.loads(body) if body else {}
                except ValueError as e:
                    raise VenueError(http, None, "malformed") from e
                if http != 200:
                    if 400 <= http < 500 and isinstance(reply, dict) and isinstance(reply.get("error"), dict):
                        err = reply["error"]
                        code = err.get("code")
                        msg = err.get("message", "")
                        if (code is None or isinstance(code, str)) and isinstance(msg, str):
                            raise VenueError(http, code, msg)
                    raise VenueError(http, None, "malformed")
                return reply
        except VenueError as e:
            if e.http == 429 and self._rate_budget is not None:
                self._rate_budget.note_http(429)  # suspends probes in every process; never raises
            if mutating and not (400 <= e.http < 500 and e.code is not None):
                raise OrderStateUnknown(cid, f"http {e.http}: malformed or ambiguous reply") from e
            raise
        except (asyncio.TimeoutError, aiohttp.ClientError, ConnectionError) as e:
            if not http:  # no status line: the transport failed before the venue answered
                self._count_outcome("transport")
            if mutating:
                raise OrderStateUnknown(cid, type(e).__name__) from e
            raise VenueError(http, None, "malformed") from e

    def _headers(self, method: str, path: str) -> dict[str, str]:
        ts_ms = int(time.time() * 1000)
        started = _decision_clock()
        try:
            signature = sign(ts_ms, method, path, self._pem)
        finally:
            _decision_sign_elapsed(started)
        return {
            "KALSHI-ACCESS-KEY": self._key_id,
            "KALSHI-ACCESS-TIMESTAMP": str(ts_ms),
            "KALSHI-ACCESS-SIGNATURE": signature,
        }

    async def exchange_status(self) -> dict[str, Any]:
        """Public maintenance status, bounded independently of signed order requests."""
        if self._session is None:
            raise RuntimeError("client not entered")
        answered = False
        try:
            # The path is built inline here, so the route is recorded directly (no classifier).
            self._count_request("exchange_status")
            async with self._session.request(
                "GET", f"{self.base_url}{PATH_PREFIX}/exchange/status",
                timeout=aiohttp.ClientTimeout(total=10.0),
            ) as resp:
                answered = True
                self._count_outcome(_request_outcome(resp.status))
                if resp.status != 200:
                    raise VenueError(resp.status, None, "exchange status unavailable")
                body = bytearray()
                async for chunk in resp.content.iter_chunked(65536):
                    body.extend(chunk)
                    if len(body) > 65536:
                        raise VenueError(resp.status, None, "malformed exchange status")
                try:
                    reply = orjson.loads(body)
                    flags = ("exchange_active", "trading_active", "intra_exchange_transfers_active")
                    if not isinstance(reply, dict) or any(type(reply.get(k)) is not bool for k in flags):
                        raise ValueError("flags")
                    resume = reply.get("exchange_estimated_resume_time")
                    if resume is not None:
                        if not isinstance(resume, str) or not 1 <= len(resume) <= 64:
                            raise ValueError("resume time")
                        if datetime.fromisoformat(resume.replace("Z", "+00:00")).tzinfo is None:
                            raise ValueError("resume timezone")
                    shards = reply.get("exchange_index_statuses", [])
                    if not isinstance(shards, list) or len(shards) > 256:
                        raise ValueError("shards")
                    bounded_shards = []
                    for shard in shards:
                        if not isinstance(shard, dict) or any(type(shard.get(k)) is not bool for k in flags):
                            raise ValueError("shard flags")
                        index, description = shard.get("exchange_index"), shard.get("description")
                        if type(index) is not int or not 0 <= index <= 2**31 - 1:
                            raise ValueError("shard index")
                        if not isinstance(description, str) or len(description) > 1024:
                            raise ValueError("shard description")
                        bounded_shards.append(dict({k: shard[k] for k in flags},
                                                   exchange_index=index, description=description))
                    return dict({k: reply[k] for k in flags}, exchange_estimated_resume_time=resume,
                                exchange_index_statuses=bounded_shards)
                except (ValueError, TypeError, KeyError) as e:
                    raise VenueError(resp.status, None, "malformed exchange status") from e
        except (asyncio.TimeoutError, aiohttp.ClientError, ConnectionError):
            if not answered:  # no status line: the transport failed before the venue answered
                self._count_outcome("transport")
            raise

    async def _signed(self, method: str, path: str, params: dict[str, str] | None = None, *,
                      mutating: bool = False, cid: str = "") -> Any:
        read_budget = self._read_budget
        if read_budget is not None and method == "GET" and not mutating:
            # B12-read: the account read budget, before the request is signed, counted or timed,
            # so a refused read never reaches the venue, the request counters or venue_read_ms.
            # http 0 is "no status line", the class a transport failure already raises for reads.
            decision = read_budget.acquire(_read_kind(_request_route(method, path)))
            if not decision.admitted:
                raise VenueError(0, decision.code, f"kalshi read budget refused {decision.kind}")
        started_ns = time.perf_counter_ns()
        try:
            qs = f"?{'&'.join(f'{k}={v}' for k, v in (params or {}).items())}" if params else ""
            url = f"{self.base_url}{path}{qs}"
            return await self._execute(method, path, url, mutating=mutating, cid=cid)
        finally:
            attribute = "_read_latency" if method == "GET" else "_order_latency"
            reservoir = getattr(self, attribute, None)
            if reservoir is None:
                reservoir = LatencyReservoir()
                setattr(self, attribute, reservoir)
            reservoir.record(time.perf_counter_ns() - started_ns)

    def latency_snapshot(self) -> dict[str, Any]:
        result = {}
        result.update(self._fills_basis_counts or {})
        if self.price_refused:
            result["price_refused"] = self.price_refused
        if self.venue_rejections:
            result["venue_rejections"] = dict(self.venue_rejections)
        for name, counter in (("risk_trims", self.risk_trims),
                              ("reconcile_deferred_grace", self.reconcile_deferred_grace),
                              ("reconcile_journal_ts_invalid", self.reconcile_journal_ts_invalid),
                              ("risk_cleanup_write_failed", self.risk_cleanup_write_failed),
                              ("revision_conflict_recovered", self.revision_conflict_recovered)):
            if counter:  # omitted while zero: a fresh client still reports {}
                result[name] = counter
        for name, reservoir in (("venue_order_ms", self._order_latency),
                                ("venue_read_ms", self._read_latency)):
            block = reservoir.snapshot()
            if block is not None:
                result[name] = block
        if self.classification_mode == "ticker":  # legacy output stays byte-identical
            result["exposure"] = self._exposure_block()
        if self._rate_budget is not None:  # absent without a budget: output stays byte-identical
            result["rate_budget"] = self._rate_budget.snapshot()
        if self._read_budget is not None:  # absent without a read budget: byte-identical output
            result["read_budget"] = self._read_budget.snapshot()
        if self.hot_observation_mode != "off":
            result["hot_observation"] = dict(self._hot_counts, mode=self.hot_observation_mode,
                                             hot_miss=dict(self._hot_misses),
                                             decision_to_submit_ms=self._hot_latency.snapshot())
        return result

    def _exposure_block(self) -> dict[str, Any]:
        """Ticker-mode admission status: the last observation plus refusal counts (bounded by
        the closed code set; foreign_open by account_risk.FOREIGN_OPEN_MAX). Contract names:
        exposure_refusals (class -> count since this client started), foreign_open (ticker ->
        residual foreign quantity F from the last classification, fixed-point text),
        worst_case_admissions and worst_case_cents (accumulated). refusals_by_code is kept."""
        status = self._exposure_status or {}
        return {
            "classification_mode": self.classification_mode,
            "refusals_by_code": dict(self._refusals_by_code or {}),
            "exposure_refusals": dict(self._refusals_by_code or {}),
            "worst_case_admissions": self._worst_case_admissions,
            "worst_case_cents": self._worst_case_cents,
            "classes": dict(status.get("classes") or {}),
            "foreign_open": dict(status.get("foreign_open") or {}),
            "admission_consumption_cents": status.get("admission_consumption_cents"),
            "widened": status.get("widened"),
            "legacy_entries": status.get("legacy_entries"),
            "legacy_side_unknown_exact": status.get("legacy_side_unknown_exact"),
            "ledger_entries": status.get("ledger_entries"),
            "body_bytes": status.get("body_bytes"),
        }

    def _count_refusal(self, code: str) -> None:
        counts = self._refusals_by_code
        if counts is None:
            counts = self._refusals_by_code = {}
        counts[code] = counts.get(code, 0) + 1

    def _journal_digest(self) -> str | None:
        """16 hex naming this client's order journal (reservation provenance p.j), computed once."""
        digest = getattr(self, "_journal_digest_value", None)
        if digest is None:
            path = getattr(self, "journal_path", None)
            if path is None:
                return None
            digest = self._journal_digest_value = hashlib.sha256(os.fspath(path).encode()).hexdigest()[:16]
        return digest

    def _provenance_kwargs(self, side_yes, count, price_cents, prepared, generation) -> dict[str, Any]:
        """reserve() provenance keywords; none without a side (direct callers keep legacy entries)."""
        from .account_risk import holder_identity

        if side_yes is None:
            return {}
        return {"side": bool(side_yes), "count": count, "price_cents": price_cents,
                "prepared": bool(prepared), "holder": holder_identity(),
                "journal_digest": self._journal_digest(), "authority_generation": generation}

    def _fence_enforced(self) -> bool:
        """A6: the fence is enforced (fails closed on an unavailable reader or an unmapped
        ledger root) in ticker mode. Legacy mode keeps its no-fence fallbacks unchanged."""
        return self.classification_mode == "ticker"

    def _resolve_exposure_role(self):
        """The DomainRole reader for this client's ledger root, or False when no fence applies:
        a ledger with no root, or no exposure_authority module on this checkout. Resolved once.
        Enforced (ticker mode), those cases are a _ReaderUnavailable carrying ledger_root_unmapped
        or exposure_reader_unavailable instead, which _exposure_fence refuses and never caches."""
        enforced = self._fence_enforced()
        root = getattr(getattr(self, "account_risk", None), "root", None)
        if root is None:
            return _ReaderUnavailable("ledger_root_unmapped") if enforced else False
        try:
            from ..exposure_authority import DomainRole
        except ModuleNotFoundError as exc:
            if enforced:
                return _ReaderUnavailable("exposure_reader_unavailable")
            if (exc.name or "").endswith("exposure_authority"):
                return False
            return _RoleUnreadable()
        except Exception:
            return _ReaderUnavailable("exposure_reader_unavailable") if enforced else _RoleUnreadable()
        try:
            reader = DomainRole.for_ledger_root(root)
        except Exception:
            return _ReaderUnavailable("exposure_reader_unavailable") if enforced else _RoleUnreadable()
        if reader is None and enforced:
            return _ReaderUnavailable("ledger_root_unmapped")
        return reader

    def domain_pause_status(self) -> dict[str, Any]:
        """Use the fence's ledger-root domain; unset domains retain legacy-owner identity."""
        # Tenant lanes are isolated from the owner registry (InaccessiblePaths); owner pause never applies (M2.md:32), and their own lane controls pause them.
        if os.environ.get("LEAFHFT_ACCOUNT_LANE_ID"):
            return {"generation": None, "state": "absent"}
        reader = self._exposure_role
        if reader is None or (reader is False and self._fence_enforced()):
            reader = self._resolve_exposure_role()
            if not isinstance(reader, _ReaderUnavailable):
                self._exposure_role = reader
        return _domain_pause_status(getattr(reader, "domain", None) or "legacy-owner")

    def _exposure_fence(self, where: str) -> int | None:
        """Defense-in-depth exposure fence (X-F2): one stat of the domain role file per call.
        Refuses when this domain may not open exposure; otherwise returns the role record's
        generation (None without a record) for the reservation's authority_generation.
        Enforced (A6), an unavailable reader or an unmapped root refuses by its own class and is
        re-resolved on the next call; a proven absent marker (state absent) still admits."""
        from .account_risk import AccountRiskRefused

        pause = self.domain_pause_status()
        if pause["state"] in ("paused", "unreadable"):
            code = "domain_paused" if pause["state"] == "paused" else "domain_pause_unreadable"
            raise _typed_refusal(f"domain pause fence refused {where}: {pause['state']}", code)
        enforced = self._fence_enforced()
        reader = self._exposure_role
        if reader is None or (reader is False and enforced):
            reader = self._resolve_exposure_role()
            if not isinstance(reader, _ReaderUnavailable):
                self._exposure_role = reader
        if reader is False:
            return None
        if isinstance(reader, _ReaderUnavailable):
            raise _typed_refusal(f"exposure authority unavailable {where}: {reader.code}", reader.code)
        try:
            view = reader.read()
        except Exception as exc:
            if enforced:
                # Never cached: the next admission re-resolves (and re-reads) the reader.
                self._exposure_role = None
                raise _typed_refusal(f"exposure authority unavailable {where}: role read failed "
                                     f"{type(exc).__name__[:64]}", "exposure_reader_unavailable") from exc
            view = _RoleUnreadable()
        code = _fence_refusal(view)
        state = getattr(view, "state", "unreadable")
        if code is not None:
            bounded = lambda value: str(value)[:64]
            raise AccountRiskRefused(
                f"domain is not the exposure authority {where}: state={bounded(state)} "
                f"role={bounded(getattr(view, 'role', None))} "
                f"enforcement={bounded(getattr(view, 'enforcement', None))}", code=code)
        generation = getattr(view, "generation", None) if state == "record" else None
        return generation if type(generation) is int and 0 <= generation <= 2**53 - 1 else None

    def _refuse_at_send(self, client_id, risk_context, attribution, exc,
                        reason="exposure authority fence refused at send") -> None:
        """The send-boundary fence (or the B12 write budget) refused: the order was never sent,
        so the reservation is resolved to 0 and a rejected attribution row carries the class."""
        if risk_context[3] > 0:
            try:
                self.account_risk.resolve(client_id, 0, count=0)
            except Exception:
                # The order is proven unsent: persist the cleanup intent (cid, count 0). It is
                # retried at the next admission and in settlement recovery, and entry stays
                # stopped (risk_posting_failed) until it succeeds.
                pending = self._risk_cleanup
                if pending is None:
                    pending = self._risk_cleanup = {}
                pending[client_id] = 0
                self._write_risk_cleanup()
        self._count_refusal(exc.code)
        self.record_attribution(attribution, "rejected", client_id,
                                reason=reason, refusal_class=exc.code)

    def _unwind_before_sent(self, client_id, prior_record, claimed, risk_context, attribution,
                            exc: BaseException) -> None:
        """H2a3-resv: a local step between the send record and SENT raised (auth.check, the account
        budget claim, _headers, _wire_json), so the order was proven never sent. Restores the
        pre-call record, resolves a claim this call made to 0, and resolves the entry risk
        reservation to 0 through _refuse_at_send (a failed resolve persists the cleanup intent).
        risk_context is None for a reduce-only exit, which reserves nothing. Never raises: the
        caller re-raises exc unchanged; each failure here fails closed on its own latch."""
        if prior_record is None:
            self._records.pop(client_id, None)
        else:
            self._records[client_id] = prior_record
        if claimed:
            try:
                self.account_budget.resolve(client_id, 0)
            except Exception:
                self._risk_error = "account_budget_unwind_failed"  # entry stays stopped
        if risk_context is None:
            return
        try:
            refusal = _typed_refusal("pre-send step failed before SENT: " + type(exc).__name__[:64],
                                     _refusal_code(exc))
            self._refuse_at_send(client_id, risk_context, attribution, refusal,
                                 reason="pre-send step failed before SENT")
        except Exception:
            pass  # an attribution write failure has already latched _attribution_failed

    def _risk_cleanup_path(self) -> Path | None:
        path = getattr(self, "journal_path", None)
        return None if path is None else path.with_name(RISK_CLEANUP_FILE)

    def _load_risk_cleanup(self) -> None:
        """Restore cleanup intents a previous process could not resolve. Bounded read; an
        unreadable or malformed file keeps the entry stop (fails closed)."""
        path = self._risk_cleanup_path()
        if path is None:
            return
        try:
            with path.open("rb") as stream:
                data = stream.read(MAX_JOURNAL_BYTES + 1)
        except FileNotFoundError:
            return
        except OSError:
            self._risk_error = "risk_cleanup_unreadable"
            return
        try:
            doc = orjson.loads(data) if len(data) <= MAX_JOURNAL_BYTES else None
            if (not isinstance(doc, dict) or len(doc) > MAX_OWNED
                    or any(not isinstance(cid, str) or not 0 < len(cid) <= 36 or count != 0
                           for cid, count in doc.items())):
                raise ValueError("malformed risk cleanup intents")
        except ValueError:
            self._risk_error = "risk_cleanup_unreadable"
            return
        if doc:
            self._risk_cleanup = dict(doc)

    def _write_risk_cleanup(self) -> None:
        """Mirror the pending intents to RISK_CLEANUP_FILE (atomic replace, fsync); removed when
        empty. A write failure keeps the in-memory intent and the stop for this process."""
        path = self._risk_cleanup_path()
        if path is None:
            return
        pending = self._risk_cleanup or {}
        try:
            if not pending:
                path.unlink(missing_ok=True)
                return
            scratch = path.with_name(path.name + ".tmp")
            with scratch.open("wb") as stream:
                stream.write(orjson.dumps(pending))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(scratch, path)
        except OSError as exc:
            # Never silent: counted and logged. The intent and the stop stay in memory, and a
            # restarted process recovers it from the durable ledger (_scan_durable_risk_cleanup).
            self.risk_cleanup_write_failed += 1
            logging.getLogger(__name__).error(
                "kalshi risk cleanup intent write failed (%s); pending=%s",
                type(exc).__name__[:64], len(pending))

    def _adopt_durable_risk_cleanup(self, entries) -> bool:
        """Adopt stranded reservations from DURABLE ledger state, so a lost RISK_CLEANUP_FILE
        cannot lose them: an entry still reserved under this client's journal digest (p.j) with
        no journal record (hence no SENT row, never sent) is a proven-unsent cleanup (cid -> 0).
        Walks and admission hold self._lock and reserve after this scan, so no live client id
        is reserved here. O(entries); True when an intent was added."""
        digest = self._journal_digest()
        if digest is None or not isinstance(entries, dict):
            return False
        owned = getattr(self, "_owned", None) or {}
        records = getattr(self, "_records", None) or {}
        pending = self._risk_cleanup
        adopted = False
        for cid, row in entries.items():
            if (not isinstance(row, dict) or row.get("state") != "reserved"
                    or not isinstance(cid, str) or not 0 < len(cid) <= 36
                    or cid in owned or cid in records or (pending and cid in pending)):
                continue
            provenance = row.get("p")
            if not isinstance(provenance, dict) or provenance.get("j") != digest:
                continue
            if pending is None:
                pending = self._risk_cleanup = {}
            if len(pending) >= MAX_OWNED:
                break  # the intents already present keep the stop; the rest wait for a later walk
            pending[cid] = 0
            adopted = True
        return adopted

    def _scan_durable_risk_cleanup(self) -> None:
        """Init: adopt stranded reservations from a read-only ledger snapshot and mirror them to
        RISK_CLEANUP_FILE. A read failure adopts nothing here; both settlement walks rescan the
        durable state before any new reservation, and admission refuses while any remain."""
        try:
            snapshot = _decision_ledger_call(self.account_risk.read_snapshot, hot=True)
        except Exception:
            return
        if isinstance(snapshot, dict) and self._adopt_durable_risk_cleanup(snapshot.get("entries")):
            self._write_risk_cleanup()

    def _retry_risk_cleanup(self) -> None:
        """Resolve every pending proven-unsent reservation to 0 (count 0). A success, or an entry
        the ledger provably no longer holds, drops its intent; a failure keeps it (and the stop)."""
        pending = self._risk_cleanup
        if not pending:
            return
        for cid in list(pending):
            try:
                self.account_risk.resolve(cid, 0, count=0)
            except KeyError:
                try:
                    # A failed cleanup can refer to an archived id and needs the complete history.
                    if cid in _decision_ledger_call(self.account_risk.read_snapshot)["entries"]:
                        continue
                except Exception:
                    continue
            except Exception:
                continue
            del pending[cid]
        self._write_risk_cleanup()

    async def _reserve_entry_risk(self, ticker, price_cents, count, client_id, side_yes=None, prepared=False):
        from .account_risk import AccountRiskRefused

        if self._risk_cleanup:
            self._retry_risk_cleanup()
        if getattr(self, "_risk_error", None) or self._risk_cleanup:
            raise AccountRiskRefused("account risk posting failed; reconcile before entry",
                                     code="risk_posting_failed")
        # C16a: the requesting book, before any read; an unknown partition refuses here.
        book = self._risk_book_for(client_id)
        # Before any venue read. With no role file this is byte-identical.
        generation = self._exposure_fence("before venue reads")
        if self.classification_mode == "ticker":
            return await self._reserve_entry_risk_ticker(ticker, price_cents, count, client_id,
                                                         side_yes, prepared, generation, book)
        # RC1: one jittered retry of a revision_conflict with fresh reads, inside one
        # TICKER_READ_BUDGET_S budget; a second conflict refuses. No conflict: exactly as before.
        budget = TICKER_READ_BUDGET_S
        started = time.perf_counter()
        try:
            return await self._legacy_admission(ticker, price_cents, count, client_id, side_yes, prepared,
                                                generation, book, retried=False)
        except AccountRiskRefused as exc:
            if exc.code != "revision_conflict":
                raise
            await self._revision_retry_wait(exc, started, budget)
        scope = asyncio.timeout(budget - (time.perf_counter() - started))
        try:
            async with scope:
                admitted = await self._legacy_admission(ticker, price_cents, count, client_id, side_yes,
                                                        prepared, generation, book, retried=True)
        except TimeoutError as exc:
            if not scope.expired():
                raise
            raise AccountRiskRefused(f"account venue reads exceeded the {budget}s budget",
                                     code="venue_read_timeout") from exc
        self.revision_conflict_recovered += 1
        return admitted

    async def _revision_retry_wait(self, exc, started, budget):
        """RC1: sleep the jittered delay before the one revision_conflict retry, or raise `exc`
        (writing its deferred journal row, retried=false) when the retry must not run: a seam value
        outside [0, REVISION_RETRY_JITTER_MAX_S] (fails closed), or a remaining budget that cannot
        hold the delay plus a read as long as the first attempt took."""
        from .account_risk import journal_deferred_refusal

        spent = time.perf_counter() - started
        try:
            delay = self._risk_retry_jitter()
        except Exception:
            delay = None
        if (type(delay) not in (int, float) or not 0 <= delay <= REVISION_RETRY_JITTER_MAX_S
                or budget - spent < delay + spent):
            journal_deferred_refusal(exc)
            raise exc
        await self._risk_retry_sleep(delay)

    async def _admission_reads(self):
        """Overlap observation reads, retaining balance-first exception precedence."""
        async def stamped(read, stage):
            result = await read()
            _decision_stage(stage)
            return result

        _decision_values(n_pages=0, n_minute_miss=0)
        balance = asyncio.create_task(stamped(self.balance, "balance_end_ns"))
        positions = asyncio.create_task(stamped(self.all_positions, "positions_end_ns"))

        def balance_done(task):
            if task.cancelled() or task.exception() is not None:
                if not positions.cancelling():
                    positions.cancel()

        balance.add_done_callback(balance_done)
        # Gather drains both tasks, including their cancellation cleanup when the
        # caller is cancelled. Inspect results in the original exception order.
        await asyncio.gather(balance, positions, return_exceptions=True)
        return balance.result(), positions.result()

    async def _legacy_admission(self, ticker, price_cents, count, client_id, side_yes, prepared, generation,
                                book, retried=None):
        """One legacy-mode observation (settlement recovery, snapshot, balance, positions, minute)
        and reserve(expected_revision=r). retried: reserve()'s RC1 journal flag."""
        _decision_stage("admission_enter_ns")
        from .account_risk import AccountRiskRefused
        from ..policy import DEFAULT_POLICY
        from ..strategy.settlement import fee_per_contract

        ledger = self.account_risk
        await self._reconcile_risk_settlements()
        _decision_stage("settle_walk_end_ns")
        if self._risk_cleanup:  # a durable stranded reservation the walk could not resolve
            raise AccountRiskRefused("account risk posting failed; reconcile before entry",
                                     code="risk_posting_failed")
        # Keep the legacy write/audit transaction; active entries and bases suffice for admission.
        snapshot = _decision_ledger_call(ledger.snapshot, hot=True)
        _decision_stage("snapshot_end_ns")
        revision = snapshot["revision"]
        cash, rows = await self._admission_reads()
        positions = {}
        index = None
        for row in rows:
            market = row.get("ticker")
            quantity = Decimal(str(row.get("position_fp", row.get("position"))))
            if not isinstance(market, str) or not quantity.is_finite():
                raise AccountRiskRefused("invalid account position", code="venue_malformed")
            if quantity:
                if index is None:
                    index = _open_entries_by_ticker(snapshot["entries"])
                known, pending = index.get(market, ((), 0))
                # fees_paid is lifetime market fees, including closed lots. It is
                # not the fee basis of the remaining position after a partial exit.
                if (not known or any("count" not in entry or not entry.get("exact") for entry in known)
                        or sum(Decimal(entry["count"]) for entry in known) != abs(quantity)):
                    try:
                        known_count = sum((Decimal(e["count"]) for e in known if "count" in e), Decimal(0))
                        inexact = sum("count" not in e or not e.get("exact") for e in known)
                        refusal_journal.journal_refusal(
                            ledger, "ticker_reconciliation_required", client_id, ticker, None,
                            revision=revision, detail={
                                "recon_market": market,
                                "recon_class": "unknown" if not known else "inexact" if inexact else "count_mismatch",
                                "recon_venue_count": f"{abs(quantity).normalize():f}",
                                "recon_known_count": f"{known_count.normalize():f}",
                                "recon_entries": len(known), "recon_inexact": inexact,
                                "recon_pending": pending})  # Reserved entries, not fills.
                    except Exception:
                        pass  # Instrumentation cannot replace the admission refusal.
                    raise AccountRiskRefused(
                        "exact open-position cost basis requires reconciliation: "
                        f"{market[:64]} venue={abs(quantity).normalize():f} "
                        f"known={sum((Decimal(entry['count']) for entry in known if 'count' in entry), Decimal(0)).normalize():f} "
                        f"entries={len(known)} "
                        f"inexact={sum('count' not in entry or not entry.get('exact') for entry in known)} "
                        f"pending={pending}", code="ticker_reconciliation_required")
                positions[market] = (await self._risk_settlement_minute(market),
                                     sum(entry["cost_cents"] for entry in known))
        book_request = book._risk_requests.get(client_id) if book is not None else None
        if book_request is not None:
            reserved_cents, minute = book_request
            if type(minute) is not int or minute < 0:
                raise AccountRiskRefused("cluster minute must be a nonnegative int", code="input_invalid")
            if ticker in positions and positions[ticker][0] != minute:
                raise AccountRiskRefused("cluster minute conflicts with existing position",
                                         code="settlement_minute_reconcile")
        else:
            minute = positions[ticker][0] if ticker in positions else await self._risk_settlement_minute(ticker)
        _decision_stage("minutes_end_ns")
        fee = fee_per_contract(price_cents)
        policy = getattr(getattr(book, "risk_strategy", book), "risk_policy", DEFAULT_POLICY)
        # fixed_count 0 keeps origin/main's one-ceiling request byte for byte (Dark Horse included).
        requested = (_entry_debit_cents(price_cents, count, fee) if getattr(policy, "fixed_count", 0) else
                     int((Decimal(str(count)) * (price_cents + fee)).to_integral_value(rounding=ROUND_CEILING)))
        resize = bool(getattr(policy, "risk_resize_live", 0)) and not getattr(policy, "fixed_count", 0)
        # Tenants trim to the brake room; a prepared or fixed-count order is never trimmed.
        brake_trim = bool(os.environ.get("LEAFHFT_ACCOUNT_LANE_ID")) and not getattr(policy, "fixed_count", 0) and not prepared
        # The book may have a stricter fee schedule than the venue's default.
        if book_request is not None:
            requested = max(requested, reserved_cents)
        probe, account_policy, drawdown_policy = self._risk_probe_terms(client_id, DEFAULT_POLICY)
        allowed = _decision_ledger_call(ledger.reserve, client_id, ticker, minute, requested, cash_cents=cash,
                       open_cost_cents=sum(cost for _, cost in positions.values()),
                       positions=positions, policy=policy, expected_revision=revision, resize=resize,
                       brake_trim=brake_trim,
                       retried=retried, probe=probe, account_policy=account_policy, drawdown_policy=drawdown_policy,
                       **self._provenance_kwargs(side_yes, count, price_cents, prepared, generation))
        _decision_stage("reserve_end_ns", revision_retry=int(bool(retried)), admission_mode="legacy")
        return minute, policy, requested, allowed

    async def _reserve_entry_risk_ticker(self, ticker, price_cents, count, client_id, side_yes,
                                         prepared, generation, book):
        """Ticker-mode admission: the venue-read chain and ONE revision retry share one
        TICKER_READ_BUDGET_S budget; self._lock stays held by the caller throughout. book is
        the caller's one _risk_book_for lookup, shared by both attempts."""
        from .account_risk import AccountRiskRefused

        budget = TICKER_READ_BUDGET_S
        started = time.perf_counter()
        try:
            async with asyncio.timeout(budget):
                try:
                    return await self._ticker_admission(ticker, price_cents, count, client_id,
                                                        side_yes, prepared, generation, book, retried=False)
                except AccountRiskRefused as exc:
                    if exc.code != "revision_conflict":
                        raise
                    # RC1: the jittered delay counts against the same budget (or refuses here).
                    await self._revision_retry_wait(exc, started, budget)
                # One retry with fresh reads inside the same budget; a second conflict refuses.
                admitted = await self._ticker_admission(ticker, price_cents, count, client_id,
                                                        side_yes, prepared, generation, book, retried=True)
                self.revision_conflict_recovered += 1
                return admitted
        except TimeoutError as exc:
            # Venue read errors are converted inside the attempt, so this is the budget expiring.
            raise AccountRiskRefused(f"account venue reads exceeded the {budget}s budget",
                                     code="venue_read_timeout") from exc

    def _hot_miss(self, reason):
        self._hot_misses[reason] = self._hot_misses.get(reason, 0) + 1
        _decision_values(hot_source="fresh", hot_miss_reason=reason)

    def _hot_submit_latency(self):
        try:
            row = _decision_row.get()
            if row is not None and row.get("hot_source") == "hot":
                start, end = row.get("decide_end_ns"), row.get("submit_ns")
                if type(start) is int and type(end) is int:
                    self._hot_latency.record(end - start)
        except Exception:
            pass

    @staticmethod
    def _hot_phase(book, ticker, now_ns):
        strategy = getattr(book, "risk_strategy", book)
        state = (getattr(strategy, "_markets", None) or {}).get(ticker)
        close = getattr(state, "expiry_ms", None)
        window = getattr(strategy, "window_s", _hot_module().DEFAULT_WINDOW_S)
        if type(close) is not int or close <= 0:
            return "unknown"
        if not isinstance(window, Real) or isinstance(window, bool) or not 0 < window <= 600:
            return "unknown"
        return _hot_module().phase(now_ns // 1_000_000, (close,), window)

    def _hot_candidate(self, snapshot, book, ticker, retried):
        started = time.perf_counter_ns()
        _decision_values(hot_mode=self.hot_observation_mode, hot_source="fresh",
                         hot_miss_reason=None, hot_cycle_id=None, hot_revision=None,
                         hot_age_ns=None, hot_compare=None, hot_check_ns=0)
        try:
            reason = None
            now = time.time_ns()
            if retried:
                reason = "retry"
            elif self.classification_mode != "ticker":
                reason = "legacy"
            elif "LEAFHFT_ACCOUNT_LANE_ID" in os.environ:
                reason = "tenant"
            elif self._hot_phase(book, ticker, now) not in ("early", "final"):
                reason = "phase"
            elif not isinstance(snapshot, dict):
                reason = "snapshot"
            elif snapshot.get("fault"):
                reason = "fault"
            elif "restore_marker" in snapshot:
                reason = "restore"
            elif self._risk_cleanup or any(e.get("cleanup_pending") for e in snapshot["entries"].values()):
                reason = "cleanup"
            elif self.unresolved or any(e.get("state") in ("reserved", "pending", "UNKNOWN", "unknown")
                                       for e in snapshot["entries"].values()):
                reason = "unresolved"
            elif any(e.get("state") == "open" and e["minute"] <= now // 60_000_000_000
                     for e in snapshot["entries"].values()):
                reason = "due"
            if reason:
                self._hot_miss(reason)
                return None
            self._hot_counts["hot_eligible"] += 1
            clock = self._hot_clock
            boot = clock.boot_id()
            observation = _hot_module().read_hot(
                self.hot_observation_path, account_digest(self.account_risk.account_id),
                snapshot["revision"], clock=clock,
                expected_uid=os.geteuid() if os.name == "posix" else None)
            if isinstance(observation, _hot_module().Miss):
                self._hot_miss(observation.reason)
                return None
            if observation.age_ns >= _hot_module().age_limit_ns(observation.cycle_ns):
                self._hot_miss("stale")
                return None
            _decision_values(hot_cycle_id=observation.cycle_id,
                             hot_revision=observation.ledger_revision, hot_age_ns=observation.age_ns)
            return observation, clock, boot
        except Exception:
            self._hot_miss("malformed")
            return None
        finally:
            _decision_add("hot_check_ns", time.perf_counter_ns() - started)

    def _hot_bundle(self, candidate, snapshot, ticker, book_request, now_ns):
        """Pure candidate classification: no venue reads, reporting, or reservation."""
        observation = candidate[0]
        rows = observation.positions_rows
        held = _held_tickers(rows)
        cache = self._minute_cache or {}
        minutes = {market: cache.get(market) for market in held}
        if any(type(m) is not int or m < 0 for m in minutes.values()):
            return None, "minutes"
        if book_request is None:
            minutes.setdefault(ticker, cache.get(ticker))
        else:
            minute = book_request[1]
            if type(minute) is not int or minute < 0:
                return None, "minutes"
            if ticker in minutes and minutes[ticker] != minute:
                return None, "minute_conflict"
            minutes.setdefault(ticker, minute)
        if type(minutes.get(ticker)) is not int or minutes[ticker] < 0:
            return None, "minutes"
        entries = snapshot["entries"]
        records = self._records or {}
        sides = {cid: records[cid].get("side_yes") for cid, entry in entries.items()
                 if entry.get("state") == "open" and cid in records}
        observed = classify_tickers(entries, rows, requested=ticker, now_ns=now_ns,
                                    worst_cents=99 + fee_per_contract(99), minutes=minutes,
                                    journal_sides=sides)
        if observed.refusal:
            return None, "candidate_refusal"
        if observed.widened:
            return None, "candidate_widened"
        return (observation.cash_cents, rows, minutes, observed), None

    def _hot_handoff(self, candidate, book, ticker):
        started = time.perf_counter_ns()
        try:
            observation, clock, boot = candidate
            if self._hot_phase(book, ticker, time.time_ns()) not in ("early", "final"):
                return "phase"
            now = clock.boottime_ns()
            if now is None or boot is None or clock.boot_id() != boot:
                return "stale"
            age = now - observation.read_start_ns
            _decision_values(hot_age_ns=age)
            # Bounds staleness at the reserve handoff, not inside the ledger transaction.
            if now < observation.read_end_ns or not 0 <= age < _hot_module().age_limit_ns(observation.cycle_ns):
                return "stale"
            return None
        except Exception:
            return "malformed"
        finally:
            _decision_add("hot_check_ns", time.perf_counter_ns() - started)

    def _hot_compare(self, candidate, bundle, snapshot, book, ticker, book_request, now_ns):
        outcome = "incomparable"
        try:
            hot, reason = self._hot_bundle(candidate, snapshot, ticker, book_request, now_ns)
            current = self.account_risk.read_snapshot(hot=True)
            if (reason is None and current is not None
                    and current["revision"] == snapshot["revision"]
                    and self._hot_handoff(candidate, book, ticker) is None):
                cash, rows, minutes, observed = bundle
                hcash, hrows, hminutes, hobserved = hot
                # Inputs share policy, fees, request debit, provenance and the same wall time.
                outcome = "equal" if (
                    cash == hcash and minutes == hminutes
                    and _hot_quantities(rows) == _hot_quantities(hrows)
                    and observed.classes == hobserved.classes
                    and observed.refusal == hobserved.refusal
                    and observed.reserve_kwargs() == hobserved.reserve_kwargs()) else "diverged"
        except Exception:
            pass
        self._hot_counts["hot_" + outcome] += 1
        _decision_values(hot_compare=outcome)

    async def _ticker_admission(self, ticker, price_cents, count, client_id, side_yes, prepared, generation,
                                book, retried=None):
        """One fixed-order observation (settlement recovery, read_snapshot, balance,
        all_positions, settlement minutes), classify_tickers, the balance-skew check on a
        widened observation, then reserve(mode="ticker", expected_revision=r). retried:
        reserve()'s RC1 journal flag."""
        if self.hot_observation_mode != "off":
            return await self._hot_ticker_admission(ticker, price_cents, count, client_id, side_yes,
                                                    prepared, generation, book, retried=retried)
        _decision_stage("admission_enter_ns")
        from .account_risk import AccountRiskRefused, classify_tickers
        from ..policy import DEFAULT_POLICY
        from ..strategy.settlement import fee_per_contract

        ledger = self.account_risk
        book_request = book._risk_requests.get(client_id) if book is not None else None
        try:
            await self._reconcile_risk_settlements_concurrent()
            _decision_stage("settle_walk_end_ns")
            if self._risk_cleanup:  # a durable stranded reservation the walk could not resolve
                raise AccountRiskRefused("account risk posting failed; reconcile before entry",
                                         code="risk_posting_failed")
            snapshot = _decision_ledger_call(ledger.read_snapshot, hot=True)
            _decision_stage("snapshot_end_ns")
            entries = snapshot["entries"] if snapshot is not None else {}
            revision = snapshot["revision"] if snapshot is not None else 0
            cash, rows = await self._admission_reads()
            wanted = dict.fromkeys(_held_tickers(rows))
            if book_request is None:
                wanted[ticker] = None
            tickers = list(wanted)
            minutes = dict(zip(tickers, await self._bounded_map(self._ticker_settlement_minute, tickers)))
            _decision_stage("minutes_end_ns")
            if book_request is not None:
                reserved_cents, minute = book_request
                if type(minute) is not int or minute < 0:
                    raise AccountRiskRefused("cluster minute must be a nonnegative int", code="input_invalid")
                minutes.setdefault(ticker, minute)
            records = getattr(self, "_records", None) or {}
            # Legacy entries carry no side; the journal's SENT row supplies it when one exists (Q6).
            journal_sides = {cid: records[cid].get("side_yes") for cid, entry in entries.items()
                             if entry.get("state") == "open" and cid in records}
            now_ns = time.time_ns()
            observed = classify_tickers(entries, rows, requested=ticker, now_ns=now_ns,
                                        worst_cents=99 + fee_per_contract(99), minutes=minutes,
                                        journal_sides=journal_sides)
            self._exposure_observed(observed, entries, rows, now_ns)
            try:
                observed.raise_for_refusal()
            except AccountRiskRefused as exc:
                if exc.code == "ticker_reconciliation_required":
                    try:
                        detail = {"recon_market": ticker}
                        recon_class = observed.classes.get(ticker)
                        if recon_class in ("opposed", "legacy_side_unknown", "inexact", "legacy_unmatched"):
                            detail["recon_class"] = recon_class
                        refusal_journal.journal_refusal(
                            ledger, exc.code, client_id, ticker, None, revision=revision, detail=detail)
                    except Exception:
                        pass  # Instrumentation cannot replace the admission refusal.
                raise
            if book_request is None:
                minute = minutes[ticker]
            elif ticker in observed.positions and observed.positions[ticker][0] != minute:
                raise AccountRiskRefused("cluster minute conflicts with existing position",
                                         code="settlement_minute_reconcile")
            if observed.widened:
                cash = await self._skew_checked_balance(cash)
        except _VENUE_READ_ERRORS as exc:
            raise AccountRiskRefused("account venue read failed: " + type(exc).__name__,
                                     code="venue_read_failed") from exc
        fee = fee_per_contract(price_cents)
        policy = getattr(getattr(book, "risk_strategy", book), "risk_policy", DEFAULT_POLICY)
        # fixed_count 0 keeps origin/main's one-ceiling request byte for byte (Dark Horse included).
        requested = (_entry_debit_cents(price_cents, count, fee) if getattr(policy, "fixed_count", 0) else
                     int((Decimal(str(count)) * (price_cents + fee)).to_integral_value(rounding=ROUND_CEILING)))
        resize = bool(getattr(policy, "risk_resize_live", 0)) and not getattr(policy, "fixed_count", 0)
        brake_trim = bool(os.environ.get("LEAFHFT_ACCOUNT_LANE_ID")) and not getattr(policy, "fixed_count", 0) and not prepared
        if book_request is not None:
            requested = max(requested, reserved_cents)
        probe, account_policy, drawdown_policy = self._risk_probe_terms(client_id, DEFAULT_POLICY)
        try:
            allowed = _decision_ledger_call(ledger.reserve, client_id, ticker, minute, requested, cash_cents=cash, policy=policy,
                                     expected_revision=revision, resize=resize, now_ns=now_ns, retried=retried,
                                     brake_trim=brake_trim,
                                     probe=probe, account_policy=account_policy, drawdown_policy=drawdown_policy,
                                     **self._provenance_kwargs(side_yes, count, price_cents, prepared, generation),
                                     **observed.reserve_kwargs())
            _decision_stage("reserve_end_ns", revision_retry=int(bool(retried)), admission_mode="ticker")
        finally:
            self._exposure_reserved(getattr(ledger, "last_reserve", None))
        consumption = (getattr(ledger, "last_reserve", None) or {}).get("admission_consumption_cents")
        if allowed and type(consumption) is int and consumption > 0:
            self._worst_case_admissions += 1
            self._worst_case_cents += consumption
        return minute, policy, requested, allowed

    async def _hot_ticker_admission(self, ticker, price_cents, count, client_id, side_yes, prepared, generation,
                                book, retried=None):
        """One fixed-order observation (settlement recovery, read_snapshot, balance,
        all_positions, settlement minutes), classify_tickers, the balance-skew check on a
        widened observation, then reserve(mode="ticker", expected_revision=r). retried:
        reserve()'s RC1 journal flag."""
        _decision_stage("admission_enter_ns")

        ledger = self.account_risk
        book_request = book._risk_requests.get(client_id) if book is not None else None
        try:
            await self._reconcile_risk_settlements_concurrent()
            _decision_stage("settle_walk_end_ns")
            if self._risk_cleanup:  # a durable stranded reservation the walk could not resolve
                raise AccountRiskRefused("account risk posting failed; reconcile before entry",
                                         code="risk_posting_failed")
            snapshot = _decision_ledger_call(ledger.read_snapshot, hot=True)
            _decision_stage("snapshot_end_ns")
            entries = snapshot["entries"] if snapshot is not None else {}
            revision = snapshot["revision"] if snapshot is not None else 0
            candidate = self._hot_candidate(snapshot, book, ticker, retried)
            if candidate is not None:
                try:
                    hot_bundle, miss = self._hot_bundle(candidate, snapshot, ticker, book_request, time.time_ns())
                except Exception:
                    hot_bundle, miss = None, "malformed"
                if miss:
                    self._hot_miss(miss)
                    candidate = None
            hit_counted = compared = False
            if candidate is None and self.hot_observation_mode == "shadow":
                self._hot_counts["hot_incomparable"] += 1
                _decision_values(hot_compare="incomparable")
                compared = True
            while True:
                using_hot = candidate is not None and self.hot_observation_mode == "use"
                if using_hot:
                    cash, rows = candidate[0].cash_cents, candidate[0].positions_rows
                else:
                    cash, rows = await self._admission_reads()
                wanted = dict.fromkeys(_held_tickers(rows))
                if book_request is None:
                    wanted[ticker] = None
                tickers = list(wanted)
                minutes = (dict(hot_bundle[2]) if using_hot else
                           dict(zip(tickers, await self._bounded_map(self._ticker_settlement_minute, tickers))))
                _decision_stage("minutes_end_ns")
                if book_request is not None:
                    reserved_cents, minute = book_request
                    if type(minute) is not int or minute < 0:
                        raise AccountRiskRefused("cluster minute must be a nonnegative int", code="input_invalid")
                    minutes.setdefault(ticker, minute)
                records = getattr(self, "_records", None) or {}
                # Legacy entries carry no side; the journal's SENT row supplies it when one exists (Q6).
                journal_sides = {cid: records[cid].get("side_yes") for cid, entry in entries.items()
                                 if entry.get("state") == "open" and cid in records}
                now_ns = time.time_ns()
                if candidate is not None:
                    try:
                        hot_bundle, miss = self._hot_bundle(candidate, snapshot, ticker, book_request, now_ns)
                    except Exception:
                        hot_bundle, miss = None, "malformed"
                    if miss:
                        self._hot_miss(miss)
                        candidate = None
                        if using_hot:
                            continue
                        if not compared:
                            self._hot_counts["hot_incomparable"] += 1
                            _decision_values(hot_compare="incomparable")
                            compared = True
                    elif not hit_counted:
                        self._hot_counts["hot_hit"] += 1
                        hit_counted = True
                observed = classify_tickers(entries, rows, requested=ticker, now_ns=now_ns,
                                            worst_cents=99 + fee_per_contract(99), minutes=minutes,
                                            journal_sides=journal_sides)
                if candidate is not None and self.hot_observation_mode == "shadow" and observed.refusal:
                    self._hot_compare(candidate, (cash, rows, minutes, observed), snapshot,
                                      book, ticker, book_request, now_ns)
                    compared = True
                if not using_hot:
                    self._exposure_observed(observed, entries, rows, now_ns)
                try:
                    observed.raise_for_refusal()
                except AccountRiskRefused as exc:
                    if exc.code == "ticker_reconciliation_required":
                        try:
                            detail = {"recon_market": ticker}
                            recon_class = observed.classes.get(ticker)
                            if recon_class in ("opposed", "legacy_side_unknown", "inexact", "legacy_unmatched"):
                                detail["recon_class"] = recon_class
                            refusal_journal.journal_refusal(
                                ledger, exc.code, client_id, ticker, None, revision=revision, detail=detail)
                        except Exception:
                            pass  # Instrumentation cannot replace the admission refusal.
                    raise
                if book_request is None:
                    minute = minutes[ticker]
                elif ticker in observed.positions and observed.positions[ticker][0] != minute:
                    raise AccountRiskRefused("cluster minute conflicts with existing position",
                                             code="settlement_minute_reconcile")
                if observed.widened:
                    cash = await self._skew_checked_balance(cash)
                fee = fee_per_contract(price_cents)
                policy = getattr(getattr(book, "risk_strategy", book), "risk_policy", DEFAULT_POLICY)
                # fixed_count 0 keeps origin/main's one-ceiling request byte for byte (Dark Horse included).
                requested = (_entry_debit_cents(price_cents, count, fee) if getattr(policy, "fixed_count", 0) else
                             int((Decimal(str(count)) * (price_cents + fee)).to_integral_value(rounding=ROUND_CEILING)))
                resize = bool(getattr(policy, "risk_resize_live", 0)) and not getattr(policy, "fixed_count", 0)
                brake_trim = bool(os.environ.get("LEAFHFT_ACCOUNT_LANE_ID")) and not getattr(policy, "fixed_count", 0) and not prepared
                if book_request is not None:
                    requested = max(requested, reserved_cents)
                probe, account_policy, drawdown_policy = self._risk_probe_terms(client_id, DEFAULT_POLICY)
                reserve_kwargs = dict(cash_cents=cash, policy=policy, expected_revision=revision,
                                      resize=resize, now_ns=now_ns, retried=retried, probe=probe,
                                      brake_trim=brake_trim,
                                      account_policy=account_policy, drawdown_policy=drawdown_policy,
                                      **self._provenance_kwargs(side_yes, count, price_cents, prepared, generation),
                                      **observed.reserve_kwargs())
                if candidate is not None and self.hot_observation_mode == "shadow" and not compared:
                    self._hot_compare(candidate, (cash, rows, minutes, observed), snapshot,
                                      book, ticker, book_request, now_ns)
                    compared = True
                if using_hot:
                    miss = self._hot_handoff(candidate, book, ticker)
                    if miss:
                        self._hot_miss(miss)
                        candidate = None
                        continue
                    self._hot_counts["hot_used"] += 1
                    _decision_values(hot_source="hot", hot_miss_reason=None)
                if self.hot_observation_mode == "shadow" and not compared:
                    self._hot_counts["hot_incomparable"] += 1
                    _decision_values(hot_compare="incomparable")
                break
        except _VENUE_READ_ERRORS as exc:
            raise AccountRiskRefused("account venue read failed: " + type(exc).__name__,
                                     code="venue_read_failed") from exc
        try:
            allowed = _decision_ledger_call(ledger.reserve, client_id, ticker, minute, requested, **reserve_kwargs)
            _decision_stage("reserve_end_ns", revision_retry=int(bool(retried)), admission_mode="ticker")
        except AccountRiskRefused as exc:
            if exc.code == "revision_conflict" and using_hot:
                self._hot_counts["hot_revision_conflict"] += 1
            raise
        finally:
            if using_hot:
                self._exposure_observed(observed, entries, rows, now_ns)
            self._exposure_reserved(getattr(ledger, "last_reserve", None))
        consumption = (getattr(ledger, "last_reserve", None) or {}).get("admission_consumption_cents")
        if allowed and type(consumption) is int and consumption > 0:
            self._worst_case_admissions += 1
            self._worst_case_cents += consumption
        return minute, policy, requested, allowed

    def _exposure_observed(self, observed, entries, rows, now_ns) -> None:
        classes: dict[str, int] = {}
        for name in observed.classes.values():
            classes[name] = classes.get(name, 0) + 1
        self._exposure_status = {
            "classes": classes,
            "foreign_open": _foreign_residuals(observed.foreign_open, entries, rows, now_ns),
            "widened": observed.widened, "legacy_side_unknown_exact": observed.legacy_side_unknown_exact,
            "admission_consumption_cents": None, "legacy_entries": None, "ledger_entries": None,
            "body_bytes": None}

    def _exposure_reserved(self, stats) -> None:
        if self._exposure_status is None or not isinstance(stats, dict):
            return
        self._exposure_status.update(
            admission_consumption_cents=stats.get("admission_consumption_cents"),
            legacy_entries=stats.get("legacy_entries"), ledger_entries=stats.get("entries"),
            body_bytes=stats.get("body_bytes"))

    async def _skew_checked_balance(self, first: int) -> int:
        """Widened observations only: re-read the balance after all_positions; on a difference
        re-read once more, and refuse venue_read_skew if it still moved."""
        from .account_risk import AccountRiskRefused

        second = await self.balance()
        if second == first:
            return second
        third = await self.balance()
        if third != second:
            raise AccountRiskRefused(f"account balance moved during venue reads: {first}c {second}c {third}c",
                                     code="venue_read_skew")
        return third

    async def _bounded_map(self, fn, items) -> list:
        """fn over items with at most MARKET_READ_CONCURRENCY calls in flight, results in item
        order. A fixed pool of workers shares one iterator (no task per item); the first failure
        cancels and drains the rest before it propagates."""
        items = list(items)
        results: list = [None] * len(items)
        feed = iter(range(len(items)))

        async def worker():
            for position in feed:
                results[position] = await fn(items[position])

        workers = [asyncio.ensure_future(worker()) for _ in range(min(MARKET_READ_CONCURRENCY, len(items)))]
        try:
            await asyncio.gather(*workers)
        except BaseException:
            for task in workers:
                task.cancel()
            await asyncio.gather(*workers, return_exceptions=True)
            raise
        return results

    async def _ticker_settlement_minute(self, ticker):
        """The settlement minute through the per-process LRU, or None when the market has no
        usable close time (the classification decides what an unknown minute means). Venue
        read errors propagate."""
        from .account_risk import AccountRiskRefused

        cache = self._minute_cache
        if cache is None:
            cache = self._minute_cache = OrderedDict()
        minute = cache.get(ticker)
        if minute is not None:
            cache.move_to_end(ticker)
            return minute
        try:
            minute = await self._risk_settlement_minute(ticker)
        except AccountRiskRefused:
            return None
        if type(minute) is not int or minute < 0:
            return None
        cache[ticker] = minute
        while len(cache) > MINUTE_CACHE_MAX:
            cache.popitem(last=False)
        return minute

    def _apply_risk_trim(self, count, body, risk_context, client_id, *, prepared=False):
        from .account_risk import AccountRiskRefused, admitted_count

        minute, policy, requested, allowed = risk_context
        if allowed >= requested or prepared:
            return count, body
        if (getattr(policy, "fixed_count", None) or 0) > 0:
            if allowed > 0:
                self.account_risk.resolve(client_id, 0, count=0)
            raise AccountRiskRefused("account risk room below fixed_count", code="below_fixed_count")
        # The shared pure trim, so the ledger's p.n always equals the transmitted count.
        trimmed = admitted_count(count, requested, allowed, prepared=False)
        whole = type(count) is int
        if trimmed < (1 if whole else Decimal("0.01")):
            # A zero-room admission creates no reservation to resolve.
            if allowed > 0:
                self.account_risk.resolve(client_id, 0, count=0)
            raise AccountRiskRefused(f"account risk room {allowed}c below one contract",
                                     code="below_one_contract")
        body["count"] = str(trimmed) if whole else format(trimmed, ".2f")
        # Keep allowed reserved as a conservative bound until actual fill cost resolves it.
        self.risk_trims += 1
        bounded = lambda value: repr(str(value)[:256])[:1024]
        logging.getLogger(__name__).warning(
            "kalshi risk trim ticker=%s requested_count=%s trimmed_count=%s requested_cents=%s allowed_cents=%s",
            *(bounded(value) for value in (body["ticker"], count, trimmed, requested, allowed)))
        return trimmed, body

    async def _reconcile_risk_settlements(self):
        """Recover settled risk even for raw adapter users or a crashed book."""
        from .account_risk import AccountRiskRefused

        if self._risk_cleanup:
            self._retry_risk_cleanup()
            _decision_stage("settle_cleanup_ns")
        # Closed archived entries cannot be due; preserve the legacy transaction and audit.
        entries = _decision_ledger_call(self.account_risk.snapshot, hot=True)["entries"]
        _decision_stage("settle_snapshot_ns")
        if self._adopt_durable_risk_cleanup(entries):
            self._retry_risk_cleanup()  # a resolved entry is closed, never in the due set below
            _decision_stage("settle_cleanup_ns")
        due = {cid: row for cid, row in entries.items()
               if row["state"] == "open" and row["minute"] <= time.time_ns() // 60_000_000_000}
        _decision_values(n_due=len(due))
        tickers = {row["ticker"] for row in due.values()}
        if len(tickers) > 1000:
            raise AccountRiskRefused("risk settlement recovery exceeds bound", code="settlement_recovery_bound")
        for ticker in sorted(tickers):
            market = await self.market(ticker)
            if market.get("status") not in {"settled", "finalized"}:
                continue
            for cid, row in due.items():
                if row["ticker"] == ticker:
                    # RC2 v3: a probe entry's realized loss rides the same release event.
                    self.account_risk.release(cid, "venue-settle:" + cid, row["cost_cents"],
                                              probe_loss_cents=_settled_probe_loss(cid, row, market))

    async def _reconcile_risk_settlements_concurrent(self):
        """Ticker mode's settlement recovery: the same due set, bound and releases (same order,
        same event ids) as _reconcile_risk_settlements, read without a write transaction and
        with the market reads under MARKET_READ_CONCURRENCY. Market status is never cached."""
        from .account_risk import AccountRiskRefused

        if self._risk_cleanup:
            self._retry_risk_cleanup()
            _decision_stage("settle_cleanup_ns")
        snapshot = _decision_ledger_call(self.account_risk.read_snapshot, hot=True)
        _decision_stage("settle_snapshot_ns")
        entries = snapshot["entries"] if snapshot is not None else {}
        if self._adopt_durable_risk_cleanup(entries):
            self._retry_risk_cleanup()  # a resolved entry is closed, never in the due set below
            _decision_stage("settle_cleanup_ns")
        now_minute = time.time_ns() // 60_000_000_000
        due_by_ticker: dict[str, list] = {}
        _decision_values(n_due=0)
        for cid, row in entries.items():
            if row["state"] == "open" and row["minute"] <= now_minute:
                _decision_add("n_due", 1)
                due_by_ticker.setdefault(row["ticker"], []).append((cid, row))
        if len(due_by_ticker) > 1000:
            raise AccountRiskRefused("risk settlement recovery exceeds bound", code="settlement_recovery_bound")
        tickers = sorted(due_by_ticker)
        markets = await self._bounded_map(self.market, tickers)
        for ticker, market in zip(tickers, markets):
            if market.get("status") not in {"settled", "finalized"}:
                continue
            for cid, row in due_by_ticker[ticker]:
                self.account_risk.release(cid, "venue-settle:" + cid, row["cost_cents"],
                                          probe_loss_cents=_settled_probe_loss(cid, row, market))

    async def _risk_settlement_minute(self, ticker):
        from .account_risk import AccountRiskRefused

        _decision_add("n_minute_miss", 1)
        market = await self.market(ticker)
        close = market.get("close_time") or market.get("expiration_time")
        try:
            stamp = datetime.fromisoformat(close.replace("Z", "+00:00"))
            if stamp.utcoffset() is None:
                raise ValueError("timezone required")
            return int(stamp.timestamp()) // 60
        except (ValueError, TypeError, AttributeError) as exc:
            raise AccountRiskRefused("market settlement time unavailable",
                                     code="settlement_minute_unavailable") from exc

    def _resolve_entry_risk(self, client_id, reply):
        if client_id.startswith("lx-"):
            return
        if not reply["fill_count"]:
            cost = 0
        elif all(type(reply.get(key)) is int for key in ("venue_cost_cents", "venue_fee_cents")):
            cost = reply["venue_cost_cents"] + reply["venue_fee_cents"]
        else:
            row = self._records[client_id]
            snapshot = _decision_ledger_call(self.account_risk.snapshot, hot=True)
            entries = snapshot["entries"]
            # Recovery may replay an archived id; current sends always retain their reservation hot.
            if snapshot.get("version") == 2 and client_id not in entries:
                entries = _decision_ledger_call(self.account_risk.read_snapshot)["entries"]
            reserved = entries[client_id]["reserved_cents"]
            cost = int((Decimal(str(reply["fill_count"])) * reserved / Decimal(str(row["count"])))
                       .to_integral_value(rounding=ROUND_CEILING))
        self.account_risk.resolve(client_id, cost, count=reply["fill_count"],
                                  exact=all(type(reply.get(key)) is int
                                            for key in ("venue_cost_cents", "venue_fee_cents")))

    def _post_entry_risk(self, client_id, reply):
        if client_id.startswith("lx-"):
            return
        try:
            snapshot = _decision_ledger_call(self.account_risk.snapshot, hot=True)
            entries = snapshot["entries"]
            # Historical replay needs the complete view only when the id is absent from the hot body.
            if snapshot.get("version") == 2 and client_id not in entries:
                entries = _decision_ledger_call(self.account_risk.read_snapshot)["entries"]
            if client_id in entries:
                self._resolve_entry_risk(client_id, reply)
        except Exception as exc:
            # Retain the durable reservation and stop entry, but record the known
            # venue outcome so exit and settlement recovery remain available.
            self._risk_error = type(exc).__name__

    def record_attribution(self, attribution, stage, client_id, **details):
        """Entry write-ahead evidence is synchronous and separate from exit availability."""
        if self._attribution_failed:
            raise RuntimeError("decision attribution persistence failed; new entries stopped")
        try:
            payload = orjson.dumps(dict(attribution=attribution, stage=stage,
                                        client_id=client_id, **details)) + b"\n"
            path = self.journal_path.with_name("decision-attribution.jsonl")
            with path.open("ab") as stream:
                if stream.tell() + len(payload) > MAX_JOURNAL_BYTES:
                    raise OSError("decision attribution journal full")
                if stream.write(payload) != len(payload):
                    raise OSError("short attribution write")
                stream.flush()
                os.fsync(stream.fileno())
        except Exception:
            self._attribution_failed = True
            raise

    async def place_ioc_buy(self, ticker: str, side_yes: bool, price_cents: int, count: int, client_id: str,
                            expiration_ts: int | None = None, *,
                            model_fee_per_contract_cents: int | None = None) -> dict[str, Any]:
        """expiration_ts is passed to the order body only when given (H2a2 mode 2)."""
        _decision_stage("buy_enter_ns")
        if self.hot_observation_mode != "off":
            _decision_values(hot_mode=self.hot_observation_mode, hot_source="fresh",
                             hot_miss_reason=None, hot_cycle_id=None, hot_revision=None,
                             hot_age_ns=None, hot_compare=None, hot_check_ns=0)
        _decision_add("http_reads", 0)
        _decision_add("conn_reused", 0)
        _decision_add("conn_new", 0)
        _decision_add("sign_ns_total", 0)
        _decision_add("ledger_tx_ns_total", 0)
        if model_fee_per_contract_cents is None:
            model_fee_per_contract_cents = getattr(self, "_entry_model_fees", {}).pop(client_id, None)
        if model_fee_per_contract_cents is not None and (
                type(model_fee_per_contract_cents) is not int or model_fee_per_contract_cents < 0):
            raise ValueError("model_fee_per_contract_cents must be nonnegative")
        async with self._lock:
            _decision_stage("lock_acquired_ns")
            attribution = self._entry_attributions.pop(client_id, None)
            if attribution is None:
                attribution = self._records.get(client_id, {}).get("attribution")
            if not client_id.startswith("lx-"):
                if self._attribution_failed:
                    raise RuntimeError("decision attribution persistence failed; new entries stopped")
                if attribution is not None:
                    attribution = scope_attribution(attribution, self.attribution_account())
                    if attribution["status"] != "known":
                        raise RuntimeError("new entry attribution invalid")
                    self.record_attribution(attribution, "placement", client_id)
                    _decision_stage("placement_recorded_ns")
            prepared = self._records.get(client_id, {}).get("reversal")
            for cid, record in self._records.items():
                reversal = record.get("reversal")
                if record.get("ticker") == ticker and reversal and reversal["locked"]:
                    if cid != client_id or reversal.get("submitted"):
                        raise OrderStateUnknown(cid, "market locked by reversal")
            self._refresh_unresolved()
            # H1c: a locked reversal on ANOTHER market is bounded by its own market lock (above) and
            # its held reserve, so it does not block this order; anything else unresolved still does.
            blocking = [cid for cid in self.unresolved
                        if not (isinstance((self._records.get(cid) or {}).get("reversal"), dict)
                                and self._records[cid]["reversal"].get("locked")
                                and self._records[cid].get("ticker") != ticker)]
            if any(cid != client_id or not prepared for cid in blocking):
                raise OrderStateUnknown(blocking[0], "resolve before placing anything new")
            if self._journal_failed:
                raise RuntimeError("kalshi live order journal failed; restart required")
            if len(self._owned) >= MAX_OWNED:
                raise RuntimeError("owned order table full")
            if client_id in self._owned and not (prepared and not prepared.get("submitted")):
                raise LiveGateClosed("client id already owned")
            try:
                if prepared:
                    requested = _fixed_count(str(count))
                    if requested is None or not 0 < requested <= 100_000:
                        raise MalformedInput("count")
                    body = _order_body(ticker, side_yes, price_cents, 1, client_id, expiration_ts)
                    body["count"] = str(requested)
                    body.pop("reduce_only")
                    prepared = dict(prepared, submitted=True)
                else:
                    body = _order_body(ticker, side_yes, price_cents, count, client_id, expiration_ts)
                    if client_id.startswith("lx-"):
                        body["reduce_only"] = True
            except MalformedInput as e:
                if e.args == ("price",):
                    self.price_refused += 1
                raise
            if type(count) is not int:
                count = Decimal(body["count"])
            if not body.get("reduce_only"):
                from .account_risk import AccountRiskRefused
                try:
                    _decision_stage("prechecks_end_ns")
                    risk_context = await self._reserve_entry_risk(ticker, price_cents, count, client_id,
                                                                  side_yes, bool(prepared))
                    count, body = self._apply_risk_trim(count, body, risk_context, client_id, prepared=prepared)
                except Exception as exc:
                    code = _refusal_code(exc)
                    self._count_refusal(code)
                    if attribution is None:
                        from ..policy import DEFAULT_POLICY, policy_digest
                        try:
                            principal = self.attribution_account()
                        except Exception:
                            principal = None
                        attribution = new_attribution(
                            ticker=ticker, side_yes=side_yes, price_cents=price_cents, count=count,
                            cluster_minute=-1, reason="direct IOC entry", engine_id="kalshi_direct",
                            policy_digest=policy_digest(DEFAULT_POLICY), account=principal)
                    self.record_attribution(attribution, "rejected", client_id,
                                            reason="account risk admission refused", refusal_class=code)
                    raise _typed_refusal("account risk admission refused: " + type(exc).__name__ +
                                         ": " + str(exc)[:200], code) from exc
                if attribution is None:
                    from ..policy import DEFAULT_POLICY, policy_digest
                    _ctx = risk_context or (-1, DEFAULT_POLICY, 0, 0)
                    minute, policy = _ctx[0], _ctx[1]
                    attribution = new_attribution(
                        ticker=ticker, side_yes=side_yes, price_cents=price_cents, count=count,
                        cluster_minute=minute, reason="direct IOC entry", engine_id="kalshi_direct",
                        policy_digest=policy_digest(policy), account=self.attribution_account())
                    self.record_attribution(attribution, "proposal", client_id)
                    self.record_attribution(attribution, "placement", client_id)
                    _decision_stage("proposal_recorded_ns")
            attribution = attribution_or_unknown(attribution)
            if not body.get("reduce_only"):
                from .account_risk import AccountRiskRefused
                try:
                    # The send-boundary fence, the last check before the budget claim and SENT.
                    self._exposure_fence("at the send boundary")
                    _decision_stage("fence_end_ns")
                    from ..bookd.freshness import require_fresh
                    require_fresh(ticker, symbol=getattr(getattr(self, "auth", None), "symbol", None))
                except AccountRiskRefused as exc:
                    self._refuse_at_send(client_id, risk_context, attribution, exc,
                                        reason=("shared book refused at send" if exc.code == "book_stale"
                                                else "exposure authority fence refused at send"))
                    raise
                budget = self._rate_budget
                if budget is not None:
                    # B12: the account write budget, after the fence and before the record,
                    # the account budget claim and SENT. A refusal is never sent.
                    kind = self._rate_kind(client_id, body)
                    decision = budget.acquire(kind)
                    if not decision.admitted:
                        exc = _typed_refusal(f"kalshi write budget refused {kind}: {decision.code}",
                                             decision.code)
                        self._refuse_at_send(client_id, risk_context, attribution, exc,
                                             reason="kalshi write budget refused at send")
                        raise exc
            prior_record = self._records.get(client_id)  # H2a3-resv: restored if a pre-send step raises
            self._records[client_id] = dict(self._records.get(client_id, {}), **{
                "ticker": ticker, "side_yes": side_yes, "price_cents": price_cents, "count": _count_number(count),
                "venue_order_id": None, "fill_count": 0,
                "attribution": attribution,
                "settlement_minute": (risk_context[0] if not body.get("reduce_only")
                                      else attribution["cluster_minute"]),
                "reduce_only": bool(body.get("reduce_only")),
            })
            # Only KalshiBook's fixed_count entry passes the model fee, so a Dark Horse
            # fixed-point IOC keeps origin/main's journal record byte for byte.
            if (model_fee_per_contract_cents is not None and isinstance(count, Decimal)
                    and not prepared and not body.get("reduce_only")):
                self._records[client_id]["fractional_sizing"] = True
                self._records[client_id]["model_fee_per_contract_cents"] = model_fee_per_contract_cents
            if prepared:
                self._records[client_id]["count"] = _count_number(requested)
                self._records[client_id]["reversal"] = prepared
            claimed = False
            try:
                if self.account_budget is not None and not body.get("reduce_only"):
                    self.auth.check(time.time_ns())
                    requested_cents = int((Decimal(str(count)) * price_cents).to_integral_value(rounding=ROUND_CEILING))
                    self.account_budget.claim(client_id, requested_cents, body)
                    claimed = True
                _decision_stage("budget_end_ns")
                # H2a3 fix h, fix i: SENT means the request is leaving. Every local step that can fail
                # (the signature and the body serialization) runs before SENT, so a failure there
                # leaves the order in its pre-send state.
                url = f"{self.base_url}{ORDER_CREATE_PATH}"
                headers = self._headers("POST", ORDER_CREATE_PATH)
                wire_body = _WireBody(body)
                wire_body.wire = _wire_json(body)
                _decision_stage("signed_ns")
            except Exception as exc:
                # H2a3-resv: nothing was sent, so nothing this call reserved may stay held.
                self._unwind_before_sent(client_id, prior_record, claimed,
                                         None if body.get("reduce_only") else risk_context,
                                         attribution, exc)
                raise
            if self._rate_budget is not None and body.get("reduce_only"):
                self._rate_budget.acquire("exit")  # counted; an exit is always admitted
            self._transition(client_id, "SENT", "place requested", send_episode=True)
            _decision_stage("sent_durable_ns")
            started_ns = time.perf_counter_ns()
            answered = False
            try:
                _decision_stage("submit_ns", client_id=client_id)
                if self.hot_observation_mode != "off":
                    self._hot_submit_latency()
                self._count_request("order_create")
                async with self._session.request("POST", url, json=wire_body, headers=headers) as resp:
                    _decision_stage("ack_ns")
                    http = resp.status
                    answered = True
                    self._count_outcome(_request_outcome(http))
                    payload = bytearray()
                    async for chunk in resp.content.iter_chunked(65536):
                        payload.extend(chunk)
                        if len(payload) > 1 << 20:
                            raise VenueError(http, None, "malformed")
                    try:
                        reply = orjson.loads(payload) if payload else {}
                    except ValueError as e:
                        raise VenueError(http, None, "malformed") from e
                    if http not in (200, 201):  # the venue answers a create with 201
                        if 400 <= http < 500 and isinstance(reply, dict) and isinstance(reply.get("error"), dict):
                            err = reply["error"]
                            code, msg = err.get("code"), err.get("message", "")
                            if (code is None or isinstance(code, str)) and isinstance(msg, str):
                                raise VenueError(http, code, msg)
                        raise VenueError(http, None, "malformed")
                    reply = self._validate_order_reply(reply, count)
                    _decision_stage("fill_recv_ns", filled_count=_count_number(reply["fill_count"]))
            except asyncio.CancelledError:
                self._transition(client_id, "UNKNOWN", "place task cancelled")
                raise
            except VenueError as e:
                if e.http == 429 and self._rate_budget is not None:
                    self._rate_budget.note_http(429)  # suspends probes in every process; never raises
                if 400 <= e.http < 500 and e.code is not None:
                    code = e.code[:128]
                    self.venue_rejections[code] = self.venue_rejections.get(code, 0) + 1
                    try:
                        # repr escapes newlines; truncate before and after escaping each field.
                        bounded = lambda value: repr(str(value)[:256])[:1024]
                        logging.getLogger(__name__).warning(
                            "kalshi order refused: VenueError: kalshi http %s code %s: %s "
                            "ticker=%s side=%s price=%s price_cents=%s side_yes=%s "
                            "count=%s client_order_id=%s",
                            *(bounded(value) for value in (
                                e.http, e.code, e.msg, body["ticker"], body["side"],
                                body["price"], price_cents, side_yes, body["count"],
                                body["client_order_id"])))
                    except Exception:
                        pass
                duplicate = (prepared or self.account_budget is not None) and (e.http == 409 or any(
                    word in ((e.code or "") + " " + str(e)).lower()
                    for word in ("duplicate", "already_exists", "already exists")))
                rejected = 400 <= e.http < 500 and e.code is not None and not duplicate
                if self.account_budget is not None and e.http == 408:
                    # A request timeout does not prove that the venue rejected the send.
                    rejected = False
                if rejected:
                    if not body.get("reduce_only"):
                        self._post_entry_risk(client_id, {"fill_count": 0})
                    if self.account_budget is not None and not body.get("reduce_only"):
                        self.account_budget.resolve(client_id, 0)
                    self._transition(client_id, "GONE", f"place failed: http={e.http} code={e.code}")
                    raise
                self._transition(client_id, "UNKNOWN", f"place failed: http={e.http}")
                raise OrderStateUnknown(client_id, "VenueError") from e
            except (asyncio.TimeoutError, aiohttp.ClientError, ConnectionError) as e:
                if not answered:  # no status line: the transport failed before the venue answered
                    self._count_outcome("transport")
                self._transition(client_id, "UNKNOWN", f"place failed: {type(e).__name__}")
                raise OrderStateUnknown(client_id, type(e).__name__) from e
            except Exception as e:
                if self.account_budget is None:
                    raise
                self._transition(client_id, "UNKNOWN", "account send outcome unknown")
                raise OrderStateUnknown(client_id, "account send outcome unknown") from e
            finally:
                self._order_latency.record(time.perf_counter_ns() - started_ns)
            filled = reply["fill_count"]
            try:
                basis, account_fills, outcome = await self._entry_fill_basis(
                    client_id, reply, prepared=bool(prepared), exit_only=bool(body.get("reduce_only")))
            except asyncio.CancelledError:
                self._transition(client_id, "UNKNOWN", "place task cancelled")
                raise
            reply.update(basis)
            self._post_entry_risk(client_id, reply)
            self._count_fills_resolution(client_id, outcome)
            self._resolve_account_reply(client_id, reply, account_fills)
            state = "FILLED" if filled == count else ("PARTIAL" if filled else "GONE")
            self._transition(client_id, state, "venue reply", venue_order_id=reply["order_id"], fill_count=filled,
                             **basis)
            return reply

    def _resolve_account_reply(self, client_id, reply, fills=(), *, side_yes=None):
        if self.account_budget is None or client_id.startswith("lx-"):
            return
        try:
            if "client_order_id" in reply and reply["client_order_id"] != client_id:
                raise ValueError("different order")
            if reply.get("remaining_count", 0) or reply.get("status") in {"resting", "pending", "open"}:
                raise ValueError("not final")
            if not reply["fill_count"]:
                cost = 0
            elif "taker_fill_cost" in reply:
                cost = int((_decimal(reply["taker_fill_cost"]) * 100).to_integral_value(rounding=ROUND_CEILING))
            else:
                total, notional, seen = Decimal(0), Decimal(0), {}
                for fill in fills:
                    if not isinstance(fill, dict) or not (
                            fill.get("order_id") == reply.get("order_id") or
                            fill.get("client_order_id") == client_id):
                        continue
                    if (("order_id" in fill and fill["order_id"] != reply.get("order_id")) or
                            ("client_order_id" in fill and fill["client_order_id"] != client_id)):
                        raise ValueError("conflicting fill order identity")
                    identity = fill.get("fill_id", fill.get("trade_id"))
                    if not isinstance(identity, str) or not identity:
                        raise ValueError("unknown fill identity")
                    if identity in seen:
                        if seen[identity] != fill:
                            raise ValueError("conflicting fill")
                        continue
                    seen[identity] = fill
                    count = _fixed_count(fill.get("count_fp", fill.get("count")))
                    if count is None or count <= 0:
                        raise ValueError("unknown fill count")
                    side = self._records[client_id]["side_yes"] if side_yes is None else side_yes
                    price, _ = _fill_level_basis(fill, side, include_fee=False)
                    total += count
                    notional += price * count
                if total != Decimal(str(reply["fill_count"])):
                    raise ValueError("unknown fill notional")
                cost = int(notional.to_integral_value(rounding=ROUND_CEILING))
            self.account_budget.reconcile(client_id, cost)
        except Exception:
            if client_id in self._records:
                self._transition(client_id, "UNKNOWN", "account fill outcome unresolved")
            raise OrderStateUnknown(client_id, "account fill outcome unresolved") from None

    async def order_for_client(self, client_id: str, ticker: str, count, side_yes: bool) -> dict[str, Any]:
        """Read a prior-run intent without adopting it into this run's journal."""
        async with asyncio.timeout(10.0):
            reply = await self._get_order_for_client(client_id, {"ticker": ticker, "count": count})
            basis = _fill_basis(reply, side_yes, _embedded_fills(reply.get("fills")), client_id)
            side = "yes" if side_yes else "no"
            if side + "_price_dollars" in reply:
                price = _decimal(reply[side + "_price_dollars"]) * 100
                if price > 100:
                    raise VenueError(200, None, "malformed price")
                reply = {**reply, "price_cents": price}
            elif type(reply.get(side + "_price")) is int:
                price = reply[side + "_price"]
                if not 0 <= price <= 100:
                    raise VenueError(200, None, "malformed price")
                reply = {**reply, "price_cents": price}
            if "venue_fee_cents" not in basis and "taker_fees" in reply:
                basis["venue_fee_cents"] = int((_decimal(reply["taker_fees"]) * 100).to_integral_value(rounding=ROUND_CEILING))
            if self.account_budget is not None:
                claim = self.account_budget.snapshot()["claims"].get(client_id)
                if claim is not None:
                    if reply.get("not_found"):
                        now = time.time_ns()
                        if not 0 <= claim["claimed_ns"] <= now - RECONCILE_GRACE_NS:
                            raise OrderStateUnknown(client_id, "account reconciliation grace")
                        self.account_budget.reconcile(client_id, 0)
                    else:
                        fills = _embedded_fills(reply.get("fills"))
                        if reply["fill_count"] and "taker_fill_cost" not in reply and not fills:
                            fills = _embedded_fills(await self.fills_complete(claim.get("claimed_ns")))
                        self._resolve_account_reply(client_id, reply, fills, side_yes=side_yes)
                        basis.update(_fill_basis(reply, side_yes, fills, client_id))
            return {**reply, **basis}

    async def _get_order_for_client(self, client_id: str, record=None) -> dict[str, Any]:
        from urllib.parse import quote

        record = self._records[client_id] if record is None else record
        oid = record.get("venue_order_id")
        if oid is not None:
            reply = await self._signed("GET", order_path(oid))
            return self._validate_status_reply(reply, Decimal(str(record["count"])))
        cursor, seen = "", set()
        for _ in range(MAX_POSITION_PAGES):
            params = {"ticker": record["ticker"]}
            if cursor:
                params["cursor"] = quote(cursor, safe="")
            reply = await self._signed("GET", ORDERS_PATH, params)
            orders = reply.get("orders") if isinstance(reply, dict) else None
            if not isinstance(orders, list) or len(orders) > 1000:
                raise VenueError(200, None, "malformed")
            match = next((o for o in orders if isinstance(o, dict) and o.get("client_order_id") == client_id), None)
            if match is not None:
                return self._validate_status_reply(match, Decimal(str(record["count"])))
            cursor = reply.get("cursor", "")
            if not isinstance(cursor, str) or len(cursor) > 1024 or cursor in seen:
                raise VenueError(200, None, "malformed or repeated cursor")
            if not cursor:
                # No venue_ts: GetOrdersResponse carries only orders and cursor, no server time,
                # and the local clock never stands in for venue time. A reversal transaction
                # therefore never confirms this absence by the expiry rule: a leg with such an id
                # settles only when its primary id is fully resolved (terminal status and fills
                # by client id equal to the leg's whole count), else it stays UNKNOWN until the
                # operator's approval-gated clear.
                return {"order_id": "", "fill_count": 0, "remaining_count": 0, "not_found": True}
            seen.add(cursor)
        raise VenueError(200, None, "orders page limit")

    def _reconcile_failed(self, cid: str, note: str) -> None:
        """One unresolved pass; the existing threshold, not this call, makes a record terminal."""
        failures = self._records[cid].get("reconcile_failures", 0) + 1
        terminal = failures >= MAX_RECONCILE_FAILURES
        self._transition(cid, "UNRECONCILABLE" if terminal else "UNKNOWN", note,
                         reconcile_failures=failures)
        if terminal:
            logging.getLogger(__name__).error("order %s UNRECONCILABLE: %s", cid, note.replace("\n", " ").replace("\r", " "))

    async def reconcile(self) -> list[str]:
        async with self._lock:
            fills_deadline = [None]  # one added-retry allowance across every record in this pass
            for cid, state in list(self._owned.items()):
                if state in TERMINAL and not (state == "UNRECONCILABLE" and
                        self._records[cid].get("reversal", {}).get("locked")):
                    continue
                # The send episode comes from the journal, so every caller without a grace of its
                # own inherits one. Fails closed on a missing or future stamp: the venue is still
                # read, but an absence may not establish GONE. A reversal is exempt from all of
                # it, because only its ABSENCE branch below refuses to reject, and that branch
                # needs no grace; a POSITIVE reply carrying a zero fill still reaches the GONE
                # line below and can still make a sent reversal GONE, exactly as before this
                # change. So a grace here could only hold its market lock and cash reservation
                # longer without protecting anything.
                absence_accepted = True
                if state in {"SENT", "UNKNOWN"} and "reversal" not in self._records[cid]:
                    now, mono = time.time_ns(), time.monotonic_ns()
                    episode = self._records[cid].get("sent_ts_ns")
                    if episode is None or episode > now + JOURNAL_FUTURE_SKEW_NS:
                        self.reconcile_journal_ts_invalid += 1
                        absence_accepted = False
                    elif now < episode + RECONCILE_GRACE_NS and mono - self._first_deferred_mono.setdefault(
                            cid, mono) < RECONCILE_GRACE_NS:
                        # Monotonic bound, one grace of REAL elapsed time per deferral EPISODE and
                        # re-armed after each real read: a wall clock stepped backwards can delay
                        # this record by at most that, never indefinitely.
                        self.reconcile_deferred_grace += 1
                        continue  # ownership, reservation and unresolved status all retained
                self._first_deferred_mono.pop(cid, None)  # read this pass: the deferral is over
                try:
                    reply = await self._get_order_for_client(cid)
                    reset = {"reconcile_failures": 0} if "reconcile_failures" in self._records[cid] else {}
                    if reply.get("not_found"):
                        if "reversal" in self._records[cid]:
                            self._transition(cid, "UNKNOWN", "reversal not found; absence is not rejection")
                            continue
                        if not absence_accepted:
                            self._reconcile_failed(cid, "absence not accepted: journal timestamp invalid")
                            continue
                        self._post_entry_risk(cid, {"fill_count": 0})
                        if self.account_budget is not None and not cid.startswith("lx-"):
                            self.account_budget.reconcile(cid, 0)
                        self._transition(cid, "GONE", "order not found on venue", **reset)
                        continue
                    filled, count = reply["fill_count"], self._records[cid]["count"]
                    if "reversal" in self._records[cid]:
                        # Prepared reconciliation keeps its existing reply-only basis policy.
                        account_fills = _embedded_fills(reply.get("fills"))
                        basis = ({} if _fill_identity_conflict(reply, account_fills, cid) else
                                 _fill_basis(reply, self._records[cid]["side_yes"], client_id=cid))
                        outcome = "prepared_skipped" if filled else None
                    else:
                        basis, account_fills, outcome = await self._entry_fill_basis(
                            cid, reply,
                            exit_only=bool(self._records[cid].get("reduce_only") or cid.startswith("lx-")),
                            deadline=fills_deadline)
                    if not basis and Decimal(str(filled)) != Decimal(str(self._records[cid].get("fill_count", 0))) and (
                            "venue_cost_cents" in self._records[cid]):
                        basis = {"venue_cost_cents": None, "venue_fee_cents": None}
                    new_state = "FILLED" if Decimal(str(filled)) >= Decimal(str(count)) else ("PARTIAL" if filled > 0 else "GONE")
                    if "reversal" in self._records[cid] and (reply.get("remaining_count", 0) or
                            reply.get("status") in {"resting", "pending", "open"}):
                        new_state = "UNKNOWN"
                    if new_state != "UNKNOWN":
                        self._post_entry_risk(cid, dict(reply, **basis))
                        self._count_fills_resolution(cid, outcome)
                    self._resolve_account_reply(cid, reply, account_fills)
                    self._transition(cid, new_state, "reconciled from venue", venue_order_id=reply["order_id"], fill_count=filled, **basis, **reset)
                except asyncio.CancelledError:
                    self._transition(cid, "UNKNOWN", "reconcile task cancelled")
                    raise
                except Exception as e:
                    self._reconcile_failed(cid, f"reconcile failed: {type(e).__name__}: {e}")
            return list(self.unresolved)

    async def cancel_owned(self) -> dict[str, Any]:
        """IOC tickets never rest, so shutdown is a reconciliation, not a cancellation sweep."""
        async with self._lock:
            pass
        unresolved = await self.reconcile()
        result = {"cancelled": [], "failed": [], "unresolved": unresolved, "clean": not unresolved}
        self.shutdown_result = result
        return result

    async def order(self, order_id: int) -> dict[str, Any]:
        if type(order_id) is not int or order_id < 0:
            raise MalformedInput("order id")
        return self._validate_status_reply(await self._signed("GET", order_path(order_id)))

    async def cancel(self, order_id: int) -> dict[str, Any]:
        if type(order_id) is not int or order_id < 0:
            raise MalformedInput("order id")
        if self._rate_budget is not None:
            self._rate_budget.acquire("exit")  # B12: a cancel is exit-class, always admitted
        return await self._signed("DELETE", order_path(order_id), mutating=True, cid=str(order_id))

    async def fills(self, since_ms: int = 0) -> list[dict[str, Any]]:
        params = {"min_ts": str(int(since_ms))} if since_ms else {}
        reply = await self._signed("GET", FILLS_PATH, params)
        rows = reply.get("fills") if isinstance(reply, dict) else None
        if not isinstance(rows, list) or len(rows) > 1000:
            raise VenueError(200, None, "malformed")
        return rows

    async def fills_all(self, since_ms: int = 0) -> dict[str, Any]:
        """Every fill since since_ms, paged: at most FILLS_MAX_PAGES signed pages of at most
        FILLS_PAGE_LIMIT rows each (sent as limit) under one 10 s timeout, so at most 10,000 rows
        held; a page over FILLS_PAGE_LIMIT rows is malformed. Cursors are bounded text and never repeat (a
        repeat is malformed); a fill id seen twice keeps the first row when identical and is
        malformed when the rows differ. A walk stopped by the page bound with a cursor still
        open returns incomplete=True, which callers must treat as unreadable, never as clean.
        Returns {"fills": [...], "incomplete": bool, "pages": int}."""
        from urllib.parse import quote

        if type(since_ms) is not int or since_ms < 0:
            raise MalformedInput("since_ms")
        fills: list[dict[str, Any]] = []
        seen_fills: dict[str, dict[str, Any]] = {}
        seen_cursors: set[str] = set()
        cursor = ""
        # Kalshi's min_ts is Unix SECONDS; floor so the filter never starts after since_ms.
        since_s = since_ms // 1000
        async with asyncio.timeout(10.0):
            for page in range(1, FILLS_MAX_PAGES + 1):
                params = {"limit": str(FILLS_PAGE_LIMIT)}
                if since_s:
                    params["min_ts"] = str(since_s)
                if cursor:
                    params["cursor"] = quote(cursor, safe="")
                if _fills_basis_retry_active.get():
                    self._count_fills_basis("retry_pages")
                reply = await self._signed("GET", FILLS_PATH, params)
                rows = reply.get("fills") if isinstance(reply, dict) else None
                if (not isinstance(rows, list) or len(rows) > FILLS_PAGE_LIMIT
                        or any(not isinstance(row, dict) for row in rows)):
                    raise VenueError(200, None, "malformed fills")
                for row in rows:
                    identity = row.get("fill_id", row.get("trade_id"))
                    if not isinstance(identity, str) or not 0 < len(identity) <= 128:
                        raise VenueError(200, None, "malformed fill identity")
                    previous = seen_fills.get(identity)
                    if previous is not None:
                        if previous != row:
                            raise VenueError(200, None, "conflicting duplicate fill")
                        continue
                    seen_fills[identity] = row
                    fills.append(row)
                cursor = reply.get("cursor", "")
                if not isinstance(cursor, str) or len(cursor) > 1024:
                    raise VenueError(200, None, "malformed cursor")
                if not cursor:
                    return {"fills": fills, "incomplete": False, "pages": page}
                if cursor in seen_cursors:
                    raise VenueError(200, None, "repeated cursor")
                seen_cursors.add(cursor)
        return {"fills": fills, "incomplete": True, "pages": FILLS_MAX_PAGES}

    async def fills_complete(self, since_ns=None) -> list[dict[str, Any]]:
        """Every account fill at or after since_ns less JOURNAL_FUTURE_SKEW_NS, from the paged
        fills_all walk: the only reader for resolving or reversing an order. A walk stopped by the
        page bound is unreadable and raises VenueError, never a short list. A since_ns that is not
        a positive int (None, 0, a bool, a string) walks from the start, which fails closed on a
        busy account rather than guessing a window."""
        since_ms = 0
        if type(since_ns) is int and since_ns > 0:
            since_ms = max(0, (since_ns - JOURNAL_FUTURE_SKEW_NS) // 1_000_000)
        walk = await self.fills_all(since_ms)
        if walk["incomplete"]:
            raise VenueError(200, None, "incomplete fills walk")
        return walk["fills"]

    async def market(self, ticker: str) -> dict[str, Any]:
        if not isinstance(ticker, str) or not ticker:
            raise MalformedInput("ticker")
        reply = await self._signed("GET", market_path(ticker))
        market = reply.get("market") if isinstance(reply, dict) else None
        if not isinstance(market, dict):
            raise VenueError(200, None, "malformed")
        return market

    async def positions(self) -> list[dict[str, Any]]:
        reply = await self._signed("GET", POSITIONS_PATH)
        rows = reply.get("market_positions") if isinstance(reply, dict) else None
        if not isinstance(rows, list) or len(rows) > 1000:
            raise VenueError(200, None, "malformed")
        return rows

    async def balance(self) -> int:
        reply = await self._signed("GET", BALANCE_PATH)
        if not isinstance(reply, dict) or type(reply.get("balance")) is not int or reply["balance"] < 0:
            raise VenueError(200, None, "malformed")
        return reply["balance"]

    async def all_positions(self) -> list[dict[str, Any]]:
        """Read all nonzero positions for the authority's flat-account preflight."""
        from urllib.parse import quote

        positions = []
        cursor, seen = "", set()
        async with asyncio.timeout(10.0):
            for _ in range(MAX_POSITION_PAGES):
                params = {"limit": "1000", "count_filter": "position"}
                if cursor:
                    params["cursor"] = quote(cursor, safe="")
                reply = await self._signed("GET", POSITIONS_PATH, params)
                _decision_add("n_pages", 1)
                rows = reply.get("market_positions") if isinstance(reply, dict) else None
                if not isinstance(rows, list) or len(rows) > 1000 or any(not isinstance(row, dict) for row in rows):
                    raise VenueError(200, None, "malformed positions")
                positions.extend(rows)
                cursor = reply.get("cursor", "")
                if not isinstance(cursor, str) or len(cursor) > 1024:
                    raise VenueError(200, None, "malformed cursor")
                if not cursor:
                    return positions
                if cursor in seen:
                    raise VenueError(200, None, "repeated cursor")
                seen.add(cursor)
        raise VenueError(200, None, "positions page limit")

    async def positions_exposure_cents(self) -> int:
        """Sum shard exposure with a bounded, signed and paged positions read."""
        from urllib.parse import quote

        total = 0
        cursor = ""
        seen = set()
        async with asyncio.timeout(10.0):
            for _ in range(MAX_POSITION_PAGES):
                params = {"limit": "1000", "count_filter": "position"}
                if cursor:
                    params["cursor"] = quote(cursor, safe="")
                reply = await self._signed("GET", POSITIONS_PATH, params)
                rows = reply.get("market_positions") if isinstance(reply, dict) else None
                if not isinstance(rows, list) or len(rows) > 1000:
                    raise VenueError(200, None, "malformed positions")
                for row in rows:
                    exposure = row.get("market_exposure") if isinstance(row, dict) else None
                    if type(exposure) is not int or not 0 <= exposure <= 2**53 - 1:
                        raise VenueError(200, None, "malformed exposure")
                    total += exposure
                    if total > 2**53 - 1:
                        raise VenueError(200, None, "exposure exceeds bound")
                cursor = reply.get("cursor", "")
                if not isinstance(cursor, str) or len(cursor) > 1024:
                    raise VenueError(200, None, "malformed cursor")
                if not cursor:
                    return total
                if cursor in seen:
                    raise VenueError(200, None, "repeated cursor")
                seen.add(cursor)
        raise VenueError(200, None, "positions page limit")

    async def balance_cents(self) -> int:
        """Whole-cent balance for pool sizing (ProfitPool): prefers the balance_breakdown entry
        for this venue's exchange_index (2), which the venue serializes as a decimal-dollar
        string ("44.6446") rounded down to cents, falling back to the top-level `balance` field
        (already whole cents) when no such entry exists."""
        reply = await self._signed("GET", BALANCE_PATH)
        if not isinstance(reply, dict):
            raise MalformedInput("balance reply")
        breakdown = reply.get("balance_breakdown")
        if isinstance(breakdown, list):
            match = next(
                (b for b in breakdown if isinstance(b, dict) and b.get("exchange_index") == 2), None)
            if match is not None:
                value = match.get("balance")
                if not isinstance(value, str) or not 0 < len(value) <= 40:
                    raise MalformedInput("balance_breakdown balance")
                try:
                    dollars = Decimal(value)
                except InvalidOperation as e:
                    raise MalformedInput("balance_breakdown balance") from e
                if not dollars.is_finite() or dollars < 0:
                    raise MalformedInput("balance_breakdown balance")
                return int((dollars * 100).to_integral_value(rounding=ROUND_DOWN))
        value = reply.get("balance")
        if type(value) is not int or value < 0:
            raise MalformedInput("balance")
        return value
