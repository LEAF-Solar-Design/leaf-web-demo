"""Account execution authority for Dark Horse live, stage 3a (not wired live).

All money is integer cents; costs include fees. Resolve reports are cumulative.
Only reconciled residuals may exit. Unknown submissions retain their full debit
reservation, even when a partial fill is known. A new fill invalidates cached cash
until update_cash supplies a fresh venue observation. Caps and latches are durable;
constructor settings cannot silently replace an existing account policy.

Claim cost (lock + read + durable write) is recorded by the planner's verification
run. test_claim_cost records the measurement via pytest's record_property with
1,000 active and 1,000 terminal intents and no timing threshold.
Cash as_of_ms is the time the balance request was SENT, not its response time.
Initialization fsyncs a unique temporary file before consuming its generation;
failed publication releases the sentinel, but lost published state cannot be recreated.
"""
from __future__ import annotations

import hashlib
import os
import secrets
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from pathlib import Path
from typing import Any, Callable

import orjson

from leafhft.broker.kalshi_reversal_budget import LOCK_TIMEOUT_S, _FileLock

MAX_INTENTS = 1000
MAX_TERMINAL_INTENTS = 1000
MAX_PRUNED_CLIENT_IDS = 10000
TERMINAL_GRACE_MS = 3600000
MAX_TICKERS = 2000
MAX_STATE_BYTES = 16 * 1024 * 1024
POSTING_AGE_MS = 7 * 86400000
MAX_INTEGER = 2**63 - 1
ACTIVE = {"pending", "unknown", "filled", "partial"}
FINAL = {"zero", "settled", "exited"}


@dataclass(frozen=True)
class Grant:
    client_id: str
    worst_case_debit_cents: int
    available_cash_cents: int


@dataclass(frozen=True)
class Refusal:
    reason: str
    detail: str = ""

    def __bool__(self) -> bool:
        return False


@dataclass(frozen=True)
class OutcomeUnknown(Refusal):
    client_id: str = ""


@dataclass(frozen=True)
class GroupGrant:
    """COMBINE-S1: one claim_group's N leg grants, in the caller's precedence order."""
    wire_client_id: str
    grants: tuple
    worst_case_debit_cents: int
    available_cash_cents: int


class _ReplacedError(OSError):
    pass


@dataclass(frozen=True)
class LaneCaps:
    max_order_debit_cents: int | None = None
    max_open_loss_cents: int | None = None
    max_cohort_exposure_cents: int | None = None
    max_daily_gross_loss_cents: int | None = None
    max_pilot_net_loss_cents: int | None = None
    daily_loss_bp: int | None = None
    loss_window_hours: int | None = None

    def __post_init__(self) -> None:
        for key, value in asdict(self).items():
            if value is not None:
                _integer(value, key)
                if key == "daily_loss_bp" and value > 5000:
                    raise ValueError("daily_loss_bp must be in 0..5000")
                if key == "loss_window_hours" and not 1 <= value <= 168:
                    raise ValueError("loss_window_hours must be in 1..168")


def _integer(value: int, name: str, *, signed: bool = False) -> int:
    if type(value) is not int or not (-MAX_INTEGER if signed else 0) <= value <= MAX_INTEGER:
        raise ValueError(f"{name} must be integer cents/timestamp in range")
    return value


def _key(value: str) -> str:
    if not isinstance(value, str) or not 0 < len(value) <= 256:
        raise ValueError("identifier must contain 1..256 characters")
    return value


def _count(value: Decimal | str, *, positive: bool = False) -> Decimal:
    if not isinstance(value, (Decimal, str)):
        raise ValueError("count must be Decimal or a decimal string")
    number = Decimal(value)
    if (not number.is_finite() or number < 0 or number > Decimal("1000000000")
            or (positive and not number) or number != number.quantize(Decimal("0.01"))):
        raise ValueError("count must be nonnegative with at most two decimal places")
    return number.quantize(Decimal("0.01"))


def _day(now_ms: int) -> str:
    return datetime.fromtimestamp(now_ms / 1000, timezone.utc).date().isoformat()


def _promote_after_daily(entry: dict) -> dict | None:
    return next((event for event in entry.get("latch_reasons", [])
                 if event["reason"] != "max_daily_gross_loss_cents"
                 and event["at_ms"] >= entry["latched"]["at_ms"]), None)


class KalshiAuthority:
    def __init__(self, path: Path | str = "/var/lib/leafhft/kalshi-authority.json", *,
                 generation_id: str,
                 floor_cents: int = 1000, max_cash_age_ms: int = 120000,
                 lane_caps: dict[str, LaneCaps | dict] | None = None,
                 clock: Callable[[], int] | None = None) -> None:
        self.path = Path(path)
        self.generation_id = _key(generation_id)
        self._lock_path = Path(str(self.path) + ".lock")
        self.floor_cents = _integer(floor_cents, "floor_cents")
        self.max_cash_age_ms = _integer(max_cash_age_ms, "max_cash_age_ms")
        self.clock = clock or (lambda: time.time_ns() // 1000000)
        self.caps = {_key(lane): {key: value for key, value in
                     asdict(caps if isinstance(caps, LaneCaps) else LaneCaps(**caps)).items()
                     if value is not None}
                     for lane, caps in (lane_caps or {}).items()}

    def _empty(self) -> dict:
        return {"version": 1, "generation_id": self.generation_id, "floor_cents": self.floor_cents,
                "max_cash_age_ms": self.max_cash_age_ms,
                "cash": {"free_cash_cents": 0, "as_of_ms": 0,
                         "needs_reconciliation": True, "reconcile_after_ms": 0},
                "tickers": {}, "intents": {}, "lanes": {}, "postings": {},
                "pruned_client_ids": [], "floor_breach": False}

    @staticmethod
    def _ticker_entries(entries: list) -> dict | None:
        if not entries:
            return None
        first = entries[0][1]
        if any((e["lane"], e["side_yes"], e["close_ms"]) !=
               (first["lane"], first["side_yes"], first["close_ms"]) for _, e in entries):
            raise ValueError("conflicting ticker ownership")
        states = {e["state"] for _, e in entries}
        if any(e["exit_claims"] for _, e in entries):
            states.add("unknown")
        return {"lane": first["lane"], "side_yes": first["side_yes"],
                "state": "unknown" if "unknown" in states else
                         "pending" if "pending" in states else "open",
                "client_ids": sorted(cid for cid, _ in entries),
                "filled_count": str(sum((_count(e["residual_count"]) for _, e in entries), Decimal("0.00"))),
                "reserved_debit_cents": sum(e["reserved_debit_cents"] + sum(
                    x["debit_cents"] for x in e["exit_claims"].values()) for _, e in entries),
                "cost_cents": sum(e["cost_cents"] for _, e in entries),
                "close_ms": first["close_ms"],
                "opened_ms": min(e["created_ms"] for _, e in entries)}

    def _refresh(self, doc: dict, ticker: str) -> None:
        entry = self._ticker_entries([(cid, e) for cid, e in doc["intents"].items()
                                     if e["ticker"] == ticker and e["state"] in ACTIVE])
        if entry is None:
            doc["tickers"].pop(ticker, None)
        else:
            doc["tickers"][ticker] = entry

    def _validate(self, doc: dict) -> None:
        _key(doc["generation_id"])
        if doc["version"] != 1:
            raise ValueError("unsupported version")
        if type(doc.get("floor_breach", False)) is not bool:
            raise ValueError("invalid floor breach marker")
        for key in ("floor_cents", "max_cash_age_ms"):
            _integer(doc[key], key)
        cash = doc["cash"]
        for key in ("free_cash_cents", "as_of_ms", "reconcile_after_ms"):
            _integer(cash[key], key)
        if type(cash["needs_reconciliation"]) is not bool:
            raise ValueError("invalid cash reconciliation flag")
        for key in ("intents", "tickers", "lanes", "postings"):
            if not isinstance(doc[key], dict):
                raise ValueError(f"invalid {key}")
        for lane, entry in doc["lanes"].items():
            _key(lane)
            LaneCaps(**entry["caps"])
            if "period" in entry:
                _integer(entry["period"], "period")
            if entry.get("daily_cap_cents") is not None:
                _integer(entry["daily_cap_cents"], "daily cap")
            for key in ("realized_today_cents", "pilot_net_cents"):
                _integer(entry[key], key, signed=True)
            _integer(entry["gross_loss_today_cents"], "gross loss")
            datetime.strptime(entry["day"], "%Y-%m-%d")
            if entry["latched"] is not None:
                _key(entry["latched"]["reason"])
                _integer(entry["latched"]["at_ms"], "latch time")
        ring = doc.get("pruned_client_ids", [])
        history = doc.get("caps_history", [])
        if not isinstance(history, list) or len(history) > 32:
            raise ValueError("invalid caps history")
        for event in history:
            if event["kind"] != "caps_set":
                raise ValueError("invalid caps event")
            _key(event["lane"])
            _integer(event["at_ms"], "caps time")
            LaneCaps(**event["before"])
            LaneCaps(**event["after"])
        if not isinstance(ring, list) or len(ring) > MAX_PRUNED_CLIENT_IDS:
            raise ValueError("invalid pruned client ids")
        for cid in ring:
            _key(cid)
        for entry in doc["lanes"].values():
            reasons = entry.get("latch_reasons", [])
            if not isinstance(reasons, list) or len(reasons) > 10:
                raise ValueError("invalid latch reasons")
            for reason in reasons:
                _key(reason["reason"])
                _integer(reason["at_ms"], "latch time")
        grouped = {}
        for cid, e in doc["intents"].items():
            _key(cid)
            _key(e["ticker"])
            if e["lane"] not in doc["lanes"] or type(e["side_yes"]) is not bool:
                raise ValueError("invalid intent owner/side")
            if e["state"] not in ACTIVE | FINAL:
                raise ValueError("invalid intent state")
            for key in ("limit_price_cents", "fee_cents", "worst_case_debit_cents",
                        "reserved_debit_cents", "actual_cost_cents", "cost_cents",
                        "created_ms", "close_ms"):
                _integer(e[key], key)
            if not 1 <= e["limit_price_cents"] <= 99:
                raise ValueError("invalid limit price")
            requested = _count(e["count"], positive=True)
            filled = _count(e["filled_count"])
            residual = _count(e["residual_count"])
            _integer(e["updated_ms"], "updated_ms")
            for field in ("exit_claims", "applied_exits", "applied_settlements"):
                if not isinstance(e[field], dict):
                    raise ValueError("invalid posting ledger")
            held = Decimal("0.00")
            for xid, reservation in e["exit_claims"].items():
                _key(xid)
                held += _count(reservation["count"], positive=True)
                _integer(reservation["debit_cents"], "exit debit")
                if xid in e["applied_exits"] or e["state"] not in {"filled", "partial"}:
                    raise ValueError("invalid exit reservation")
            if held > residual:
                raise ValueError("exit reservation exceeds residual")
            for field in ("applied_exits", "applied_settlements"):
                for pid, at in e[field].items():
                    _key(pid)
                    _integer(at, "posting timestamp")
            if e["state"] in ACTIVE:
                grouped.setdefault(e["ticker"], []).append((cid, e))
            if any(e[key] != str(_count(e[key])) for key in ("count", "filled_count", "residual_count")):
                raise ValueError("noncanonical count")
            if not residual <= filled <= requested or e["cost_cents"] > e["actual_cost_cents"]:
                raise ValueError("invalid fill/residual")
            expected = int((requested * e["limit_price_cents"] + e["fee_cents"]).to_integral_value(rounding=ROUND_CEILING))
            if e["worst_case_debit_cents"] != expected:
                raise ValueError("invalid worst case debit")
            reserved = expected if e["state"] in {"pending", "unknown"} else 0
            if e["reserved_debit_cents"] != reserved:
                raise ValueError("invalid reservation")
            if e["state"] in FINAL and (residual or e["cost_cents"]):
                raise ValueError("terminal exposure")
            if e["state"] == "pending" and (filled or e["actual_cost_cents"]):
                raise ValueError("pending fill")
            if e["state"] == "unknown" and (residual != filled or e["cost_cents"] != e["actual_cost_cents"]):
                raise ValueError("unknown residual cannot be released")
            if e["state"] == "zero" and filled:
                raise ValueError("zero state has fills")
            if e["state"] in {"filled", "partial"} and not residual:
                raise ValueError("open state has no residual")
            if not filled and e["actual_cost_cents"]:
                raise ValueError("cost without fill")
        if doc["tickers"] != {ticker: self._ticker_entries(entries)
                              for ticker, entries in grouped.items()}:
            raise ValueError("ticker exposure mismatch")
        for key, at_ms in doc["postings"].items():
            if not isinstance(key, str) or not key:
                raise ValueError("invalid posting key")
            _integer(at_ms, "posting time")

    def _load(self) -> dict:
        with self.path.open("rb") as stream:
            payload = stream.read(MAX_STATE_BYTES + 1)
        if len(payload) > MAX_STATE_BYTES:
            raise ValueError("state exceeds byte limit")
        doc = orjson.loads(payload)
        self._validate(doc)
        return doc

    def _write(self, doc: dict) -> None:
        payload = orjson.dumps(doc)
        if len(payload) > MAX_STATE_BYTES:
            raise ValueError("state exceeds byte limit")
        tmp = self.path.with_name(self.path.name + f".tmp{os.getpid()}")
        try:
            with tmp.open("wb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(tmp, self.path)
            try:
                self._sync_directory()
            except OSError as exc:
                raise _ReplacedError(str(exc)) from exc
        finally:
            tmp.unlink(missing_ok=True)

    def _sync_directory(self) -> None:
        if os.name != "nt":
            fd = os.open(self.path.parent, os.O_RDONLY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)

    def initialize(self, generation_id: str) -> bool | Refusal:
        try:
            if _key(generation_id) != self.generation_id:
                return Refusal("generation_mismatch")
            sentinel = self.path.with_name(self.path.name + ".generation-" +
                hashlib.sha256(generation_id.encode()).hexdigest())
            with _FileLock(self._lock_path, timeout_s=LOCK_TIMEOUT_S):
                if self.path.exists():
                    return Refusal("already_initialized")
                if sentinel.exists():
                    return Refusal("generation_consumed")
                tmp = self.path.with_name(self.path.name + f".tmp{os.getpid()}-{secrets.token_hex(16)}")
                consumed = False
                published = False
                try:
                    with tmp.open("xb") as stream:
                        stream.write(orjson.dumps(self._empty()))
                        stream.flush()
                        os.fsync(stream.fileno())
                    try:
                        with sentinel.open("xb") as stream:
                            consumed = True
                            stream.write(generation_id.encode())
                            stream.flush()
                            os.fsync(stream.fileno())
                    except FileExistsError:
                        return Refusal("generation_consumed")
                    self._sync_directory()
                    os.link(tmp, self.path)
                    published = True
                    self._sync_directory()
                finally:
                    tmp.unlink(missing_ok=True)
                    if consumed and not published:
                        sentinel.unlink()
                        self._sync_directory()
                return True
        except TimeoutError:
            return Refusal("lock_timeout")
        except OSError as exc:
            return Refusal("initialization_failed", str(exc))

    def _run(self, operation: Callable[[dict, int], Any], now_ms: int | None = None,
             *, readonly: bool = False, client_id: str = "", check_skew: bool = False,
             initialize_caps: bool = True, maintenance_after: bool = False) -> Any:
        try:
            with _FileLock(self._lock_path, timeout_s=LOCK_TIMEOUT_S):
                now = _integer(self.clock(), "clock")
                if check_skew and now_ms is not None and abs(_integer(now_ms, "now_ms") - now) > 5000:
                    return Refusal("clock_skew")
                try:
                    doc = self._load()
                except FileNotFoundError:
                    return Refusal("state_missing")
                except OSError as exc:
                    return Refusal("state_unreadable", str(exc))
                except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
                    return Refusal("state_corrupt", str(exc))
                if doc["generation_id"] != self.generation_id:
                    return Refusal("generation_mismatch")
                if (doc["floor_cents"] != self.floor_cents or
                        doc["max_cash_age_ms"] != self.max_cash_age_ms):
                    return Refusal("policy_mismatch")
                if readonly:
                    return operation(doc, now)
                if not maintenance_after:
                    self._maintain(doc, now, initialize_caps=initialize_caps)
                result = operation(doc, now)
                if maintenance_after:
                    self._maintain(doc, now, initialize_caps=initialize_caps)
                self._prune(doc, now)
                self._write(doc)
                return result
        except TimeoutError:
            return Refusal("lock_timeout")
        except _ReplacedError as exc:
            if readonly:
                return Refusal("state_unreadable", str(exc))
            return OutcomeUnknown("outcome_unknown", str(exc), client_id)
        except OSError as exc:
            return Refusal("state_unreadable" if readonly else "write_failure", str(exc))
        except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
            return Refusal("invalid_operation", str(exc))

    @staticmethod
    def _entry_period(entry: dict) -> int:
        hours = entry["caps"].get("loss_window_hours") or 24
        day_index = (datetime.strptime(entry["day"], "%Y-%m-%d").date()
                     - datetime(1970, 1, 1).date()).days
        return entry.get("period", (day_index * 24) // hours)

    def _rebase(self, doc: dict, entry: dict, now: int) -> None:
        cash = doc["cash"]
        if (cash["needs_reconciliation"] or cash["as_of_ms"] == 0
                or not 0 <= now - cash["as_of_ms"] <= doc["max_cash_age_ms"]):
            return
        entry["daily_cap_cents"] = self._daily_cap(doc, entry["caps"])

    def _maintain(self, doc: dict, now: int, *, initialize_caps: bool) -> None:
        for lane in self.caps if initialize_caps else ():
            self._lane(doc, lane, now)
        for entry in doc["lanes"].values():
            hours = entry["caps"].get("loss_window_hours") or 24
            period = now // (hours * 3_600_000)
            entry.setdefault("period", self._entry_period(entry))
            # At the 24 h default the period IS the UTC day, so a stale period whose day the previous
            # code already rolled (a mixed fleet at 00:00Z) must not reset the counters a second time.
            if period > entry["period"] and (hours != 24 or _day(now) > entry["day"]):
                entry.update(period=period, realized_today_cents=0, gross_loss_today_cents=0)
                self._rebase(doc, entry, now)
                if (entry["latched"] is not None
                        and entry["latched"]["reason"] == "max_daily_gross_loss_cents"):
                    entry["latched"] = _promote_after_daily(entry)
            if "daily_cap_cents" not in entry:
                self._rebase(doc, entry, now)
            if _day(now) > entry["day"]:
                entry["day"] = _day(now)
        doc["postings"] = {key: at for key, at in doc["postings"].items()
                           if at >= now - POSTING_AGE_MS}
        self._prune(doc, now)

    @staticmethod
    def _prune(doc: dict, now: int) -> None:
        # COMBINE-S1b: a terminal wire intent is never pruned while any intent whose group names it is
        # still active: orphan recovery joins that leg's plan to the WIRE's venue truth. O(intents).
        wires = {e["group"].get("wire_cid") for e in doc["intents"].values()
                 if e["state"] in ACTIVE and isinstance(e.get("group"), dict)}
        terminals = sorted(((cid, e) for cid, e in doc["intents"].items()
                            if e["state"] in FINAL and cid not in wires),
                           key=lambda item: (item[1]["updated_ms"], item[1]["created_ms"], item[0]))
        expired = {cid for cid, e in terminals if e["ticker"] not in doc["tickers"]
                   and now > e["close_ms"] + TERMINAL_GRACE_MS}
        remaining = [(cid, e) for cid, e in terminals if cid not in expired]
        expired.update(cid for cid, _ in remaining[:max(0, len(remaining) - MAX_TERMINAL_INTENTS)])
        ring = doc.setdefault("pruned_client_ids", [])
        for cid, e in terminals:
            if cid in expired:
                ring.extend([cid, *e["applied_exits"]])
                del doc["intents"][cid]
        del ring[:-MAX_PRUNED_CLIENT_IDS]

    @staticmethod
    def _latch(entry: dict, reason: str, now: int) -> None:
        event = {"reason": _key(reason), "at_ms": now}
        reasons = entry.setdefault("latch_reasons", [])
        if entry["latched"] is not None and not reasons:
            reasons.append(dict(entry["latched"]))
        if entry["latched"] is None:
            entry["latched"] = event
        reasons.append(event)
        del reasons[:-10]

    @staticmethod
    def _client_id_used(doc: dict, client_id: str) -> bool:
        return (client_id in doc["intents"] or client_id in doc["pruned_client_ids"]
                or any(client_id in e["exit_claims"] or client_id in e["applied_exits"]
                       for e in doc["intents"].values()))

    def _lane(self, doc: dict, lane: str, now: int) -> dict:
        _key(lane)
        if lane in doc["lanes"]:
            return doc["lanes"][lane]
        entry = doc["lanes"].setdefault(lane, {
            "caps": dict(self.caps.get(lane, {})), "realized_today_cents": 0,
            "gross_loss_today_cents": 0, "day": _day(now), "pilot_net_cents": 0,
            "latched": None, "latch_reasons": []})
        entry["period"] = now // ((entry["caps"].get("loss_window_hours") or 24) * 3_600_000)
        self._rebase(doc, entry, now)
        if doc.get("floor_breach", False) and any(value is not None for value in entry["caps"].values()):
            self._latch(entry, "floor_breach", now)
        return entry

    @staticmethod
    def _reserved(doc: dict) -> int:
        return sum(e["reserved_debit_cents"] + sum(x["debit_cents"] for x in
                   e["exit_claims"].values()) for e in doc["intents"].values())

    def _daily_cap(self, doc: dict, caps: dict) -> int | None:
        bp = caps.get("daily_loss_bp")
        if bp is None:
            return caps.get("max_daily_gross_loss_cents")
        portfolio = doc["cash"]["free_cash_cents"] + sum(
            e["cost_cents"] for e in doc["intents"].values()
            if e["state"] in {"filled", "partial"})
        return bp * portfolio // 10000

    @staticmethod
    def _risk(e: dict) -> int:
        # Unknown partial fills are covered by the original full-order debit.
        return max(e["reserved_debit_cents"], e["cost_cents"]) + sum(
            x["debit_cents"] for x in e["exit_claims"].values())

    @staticmethod
    def _admits_pending(doc: dict, owner: dict, lane: str, side_yes: bool, close_ms: int,
                        pending_admit: frozenset[str]) -> bool:
        """COMBINE-S0: True iff a pending owner may share ticker with this claim. O(intents on ticker).

        Every active intent on the ticker must be in pending_admit (the caller's co-hosted cids), in
        the claimant's lane, on the same side and close, and neither unknown nor holding an exit
        claim. An unknown owner is never admitted, whatever the set holds.
        """
        if owner["state"] != "pending" or owner["lane"] != lane:
            return False
        for cid in owner["client_ids"]:
            e = doc["intents"][cid]
            if (cid not in pending_admit or e["state"] == "unknown" or e["exit_claims"]
                    or e["lane"] != lane or e["side_yes"] is not side_yes or e["close_ms"] != close_ms):
                return False
        return True

    @staticmethod
    def _valid_pending_admit(pending_admit) -> None:
        if pending_admit is not None and (type(pending_admit) is not frozenset or any(
                not isinstance(cid, str) for cid in pending_admit)):
            raise ValueError("pending_admit must be None or a frozenset of client ids")

    def _owner_refusal(self, doc: dict, ticker: str, lane: str, side_yes: bool, close_ms: int,
                       pending_admit: frozenset[str] | None) -> Refusal | None:
        """The ticker-owner guard of claim() and claim_group(): one rule, one place."""
        owner = doc["tickers"].get(ticker)
        if owner:
            if owner["lane"] != lane:
                return Refusal("ticker_owned")
            if owner["state"] in {"unknown", "pending"} and not (
                    pending_admit is not None
                    and self._admits_pending(doc, owner, lane, side_yes, close_ms, pending_admit)):
                return Refusal("ticker_" + owner["state"])
            if owner["side_yes"] != side_yes or owner["close_ms"] != close_ms:
                return Refusal("ticker_conflict")
        return None

    def _cap_bases(self, doc: dict, entry: dict, lane: str, close_ms: int) -> tuple[dict, dict]:
        """Each lane cap's usage BEFORE a new debit, in claim()'s check order, and its limits."""
        exposures = [e for e in doc["intents"].values() if e["lane"] == lane]
        risk = sum(self._risk(e) for e in exposures)
        cohort = sum(self._risk(e) for e in exposures if e["close_ms"] == close_ms)
        bases = {"max_order_debit_cents": 0, "max_open_loss_cents": risk,
                 "max_cohort_exposure_cents": cohort,
                 "max_daily_gross_loss_cents": entry["gross_loss_today_cents"] + risk,
                 "max_pilot_net_loss_cents": max(0, -entry["pilot_net_cents"]) + risk}
        limits = {**entry["caps"], "max_daily_gross_loss_cents": entry["daily_cap_cents"]}
        return bases, limits

    @staticmethod
    def _cap_reason(doc: dict, bases: dict, limits: dict, available: int, debit: int) -> str | None:
        """The first refusal for `debit` (floor first, then the caps in claim()'s order), or None."""
        if available < doc["floor_cents"]:
            return "floor"
        return next((key for key, base in bases.items() if limits.get(key) is not None
                     and base + debit > limits[key]), None)

    def debit_room(self, snapshot: dict, lane: str, close_ms: int) -> int:
        """COMBINE-S1: the largest new debit the cash floor and the lane's caps admit in this
        snapshot (snapshot() or the document), for sizing a group before its claim. 0 when a claim
        would refuse outright (latched lane, unreconciled or stale cash). Advisory only: the claim
        itself re-checks every cap under the lock. O(intents)."""
        cash = snapshot["cash"]
        now = self.clock()
        if (cash["needs_reconciliation"] or cash["as_of_ms"] == 0
                or not 0 <= now - cash["as_of_ms"] <= snapshot["max_cash_age_ms"]):
            return 0
        entry = snapshot["lanes"].get(lane)
        if entry is None:
            caps = dict(self.caps.get(lane, {}))
            entry = {"caps": caps, "gross_loss_today_cents": 0, "pilot_net_cents": 0,
                     "daily_cap_cents": self._daily_cap(snapshot, caps), "latched": None}
        if entry["latched"]:
            return 0
        room = cash["free_cash_cents"] - self._reserved(snapshot) - snapshot["floor_cents"]
        bases, limits = self._cap_bases(snapshot, {**entry, "daily_cap_cents": entry.get("daily_cap_cents")},
                                        lane, close_ms)
        for key, base in bases.items():
            if limits.get(key) is not None:
                room = min(room, limits[key] - base)
        return max(0, room)

    def claim(self, lane: str, ticker: str, side_yes: bool, limit_price_cents: int,
              count: Decimal | str, fee_cents: int, client_id: str, close_ms: int,
              now_ms: int, *, pending_admit: frozenset[str] | None = None) -> Grant | Refusal:
        """pending_admit=None is today's claim. A frozenset of co-hosted client ids admits a pending
        owner that _admits_pending accepts; every later check and cap runs unchanged."""
        def apply(doc: dict, now: int) -> Grant | Refusal:
            for key in (lane, ticker, client_id):
                _key(key)
            self._valid_pending_admit(pending_admit)
            quantity = _count(count, positive=True)
            _integer(limit_price_cents, "limit price")
            _integer(fee_cents, "fee")
            _integer(close_ms, "close_ms")
            if type(side_yes) is not bool or not 1 <= limit_price_cents <= 99:
                raise ValueError("invalid side/price")
            debit = int((quantity * limit_price_cents + fee_cents).to_integral_value(rounding=ROUND_CEILING))
            _integer(debit, "debit")
            entry = self._lane(doc, lane, now)
            if entry["latched"]:
                return Refusal("latched", entry["latched"]["reason"])
            if self._client_id_used(doc, client_id):
                return Refusal("duplicate_client_id")
            if close_ms <= now:
                return Refusal("market_closed")
            refusal = self._owner_refusal(doc, ticker, lane, side_yes, close_ms, pending_admit)
            if refusal is not None:
                return refusal
            if sum(e["state"] in ACTIVE for e in doc["intents"].values()) >= MAX_INTENTS:
                return Refusal("intent_limit")
            if (len(doc["tickers"]) > MAX_TICKERS or
                    (ticker not in doc["tickers"] and len(doc["tickers"]) >= MAX_TICKERS)):
                return Refusal("ticker_limit")
            cash = doc["cash"]
            if cash["needs_reconciliation"]:
                return Refusal("cash_unreconciled")
            if cash["as_of_ms"] == 0 or not 0 <= now - cash["as_of_ms"] <= doc["max_cash_age_ms"]:
                return Refusal("stale_cash")
            available = cash["free_cash_cents"] - self._reserved(doc) - debit
            bases, limits = self._cap_bases(doc, entry, lane, close_ms)
            reason = self._cap_reason(doc, bases, limits, available, debit)
            if reason:
                if reason in {"max_daily_gross_loss_cents", "max_pilot_net_loss_cents"}:
                    self._latch(entry, reason, now)
                return Refusal(reason)
            doc["intents"][client_id] = {
                "lane": lane, "ticker": ticker, "side_yes": side_yes,
                "limit_price_cents": limit_price_cents, "fee_cents": fee_cents,
                "count": str(quantity), "worst_case_debit_cents": debit,
                "reserved_debit_cents": debit, "filled_count": "0.00", "residual_count": "0.00",
                "actual_cost_cents": 0, "cost_cents": 0, "state": "pending",
                "created_ms": now, "close_ms": close_ms, "updated_ms": now,
                "exit_claims": {}, "applied_exits": {}, "applied_settlements": {}}
            self._refresh(doc, ticker)
            return Grant(client_id, debit, available)
        return self._run(apply, now_ms, client_id=client_id, check_skew=True)

    def claim_group(self, lane: str, ticker: str, side_yes: bool, limit_price_cents: int,
                    legs, wire_client_id: str, close_ms: int, now_ms: int, *,
                    pending_admit: frozenset[str] | None = None, n: int = 1,
                    m: str = "1.00") -> GroupGrant | Refusal:
        """COMBINE-S1: N ordinary intents for one combined venue order, atomically in ONE _run.

        legs: [(client_id, count, fee_cents)], precedence order; wire_client_id is one of them (the
        anchor's). Every check claim() makes runs once for the group, in claim()'s order, and the
        caps run once on the SUMMED debit (max_order_debit_cents included). Any refusal refuses the
        WHOLE group with today's reason and writes nothing; any used client id refuses it as
        duplicate_client_id. pending_admit is claim()'s rule (_admits_pending), unchanged. Each
        intent carries group {wire_cid, n, m, leg}: the recovery plan for the wire's venue truth."""
        def apply(doc: dict, now: int) -> GroupGrant | Refusal:
            for key in (lane, ticker, wire_client_id):
                _key(key)
            self._valid_pending_admit(pending_admit)
            if type(n) is not int or not 1 <= n <= 1000 or not isinstance(m, str) or not 0 < len(m) <= 8:
                raise ValueError("group n and m required")
            _integer(limit_price_cents, "limit price")
            _integer(close_ms, "close_ms")
            if type(side_yes) is not bool or not 1 <= limit_price_cents <= 99:
                raise ValueError("invalid side/price")
            rows, seen = [], set()
            for leg in legs:
                client_id, count, fee_cents = leg
                _key(client_id)
                if client_id in seen:
                    raise ValueError("a client id appears twice in one group")
                seen.add(client_id)
                quantity = _count(count, positive=True)
                _integer(fee_cents, "fee")
                debit = int((quantity * limit_price_cents + fee_cents).to_integral_value(rounding=ROUND_CEILING))
                _integer(debit, "debit")
                rows.append((client_id, quantity, fee_cents, debit))
            if not 2 <= len(rows) <= 64 or wire_client_id not in seen:
                raise ValueError("a group is 2..64 legs and names its wire client id")
            total = _integer(sum(row[3] for row in rows), "group debit")
            entry = self._lane(doc, lane, now)
            if entry["latched"]:
                return Refusal("latched", entry["latched"]["reason"])
            if any(self._client_id_used(doc, row[0]) for row in rows):
                return Refusal("duplicate_client_id")
            if close_ms <= now:
                return Refusal("market_closed")
            refusal = self._owner_refusal(doc, ticker, lane, side_yes, close_ms, pending_admit)
            if refusal is not None:
                return refusal
            if sum(e["state"] in ACTIVE for e in doc["intents"].values()) + len(rows) > MAX_INTENTS:
                return Refusal("intent_limit")
            if (len(doc["tickers"]) > MAX_TICKERS or
                    (ticker not in doc["tickers"] and len(doc["tickers"]) >= MAX_TICKERS)):
                return Refusal("ticker_limit")
            cash = doc["cash"]
            if cash["needs_reconciliation"]:
                return Refusal("cash_unreconciled")
            if cash["as_of_ms"] == 0 or not 0 <= now - cash["as_of_ms"] <= doc["max_cash_age_ms"]:
                return Refusal("stale_cash")
            available = cash["free_cash_cents"] - self._reserved(doc) - total
            bases, limits = self._cap_bases(doc, entry, lane, close_ms)
            reason = self._cap_reason(doc, bases, limits, available, total)
            if reason:
                # Never latches: a boosted total over a loss cap is refused whole, and each leg's solo
                # claim() at its base size applies today's latch rule.
                return Refusal(reason)
            grants = []
            for index, (client_id, quantity, fee_cents, debit) in enumerate(rows):
                doc["intents"][client_id] = {
                    "lane": lane, "ticker": ticker, "side_yes": side_yes,
                    "limit_price_cents": limit_price_cents, "fee_cents": fee_cents,
                    "count": str(quantity), "worst_case_debit_cents": debit,
                    "reserved_debit_cents": debit, "filled_count": "0.00", "residual_count": "0.00",
                    "actual_cost_cents": 0, "cost_cents": 0, "state": "pending",
                    "created_ms": now, "close_ms": close_ms, "updated_ms": now,
                    "exit_claims": {}, "applied_exits": {}, "applied_settlements": {},
                    "group": {"wire_cid": wire_client_id, "n": n, "m": m, "leg": index}}
                grants.append(Grant(client_id, debit, available))
            self._refresh(doc, ticker)
            return GroupGrant(wire_client_id, tuple(grants), total, available)
        return self._run(apply, now_ms, client_id=wire_client_id, check_skew=True)

    @staticmethod
    def _resolution_check(e: dict, filled: Decimal, cost: int, terminal: bool) -> bool | Refusal | None:
        """resolve()'s checks for one intent: None to apply, False for an identical replay, or the refusal."""
        old_fill = _count(e["filled_count"])
        if e["state"] not in {"pending", "unknown"}:
            if terminal and filled == old_fill and cost == e["actual_cost_cents"]:
                return False
            return Refusal("already_resolved")
        if not old_fill <= filled <= _count(e["count"]) or cost < e["actual_cost_cents"]:
            return Refusal("conflicting_resolution")
        return None

    def _apply_resolution(self, doc: dict, e: dict, filled: Decimal, cost: int, terminal: bool, now: int) -> None:
        """resolve()'s write for one checked intent (the caller refreshes its ticker)."""
        old_fill = _count(e["filled_count"])
        if cost != e["actual_cost_cents"] or filled != old_fill:
            doc["cash"]["needs_reconciliation"] = True
            doc["cash"]["reconcile_after_ms"] = max(now, doc["cash"]["reconcile_after_ms"])
        e.update(filled_count=str(filled), residual_count=str(filled),
                 actual_cost_cents=cost, cost_cents=cost,
                 state=("zero" if not filled else "filled" if filled == _count(e["count"])
                        else "partial") if terminal else "unknown")
        if terminal:
            e["reserved_debit_cents"] = 0
        e["updated_ms"] = now
        if cost > e["worst_case_debit_cents"]:
            self._latch(doc["lanes"][e["lane"]], "accounting_discrepancy", now)

    def resolve(self, client_id: str, filled_count: Decimal | str, actual_cost_cents: int,
                terminal: bool, now_ms: int | None = None) -> bool | Refusal:
        def apply(doc: dict, now: int) -> bool | Refusal:
            filled = _count(filled_count)
            cost = _integer(actual_cost_cents, "actual cost")
            if type(terminal) is not bool or (not filled and cost):
                raise ValueError("invalid resolution")
            e = doc["intents"].get(client_id)
            if e is None:
                return Refusal("unknown_intent")
            verdict = self._resolution_check(e, filled, cost, terminal)
            if verdict is not None:
                return verdict
            self._apply_resolution(doc, e, filled, cost, terminal, now)
            self._refresh(doc, e["ticker"])
            return True
        return self._run(apply, now_ms, client_id=client_id)

    def resolve_group(self, wire_client_id: str, legs, terminal: bool,
                      now_ms: int | None = None) -> bool | Refusal:
        """COMBINE-S1: resolve() for every leg of ONE combined order in ONE _run: all land or none.

        legs: [(client_id, filled_count, actual_cost_cents)], each an intent whose group names
        wire_client_id. Every leg is checked (resolve()'s rule) before any is written, so any refusal
        refuses the whole call and writes nothing. A leg already resolved to exactly these values is
        skipped (a replay); True when at least one leg moved, False when every leg was a replay."""
        def apply(doc: dict, now: int) -> bool | Refusal:
            _key(wire_client_id)
            if type(terminal) is not bool:
                raise ValueError("invalid resolution")
            rows, seen = [], set()
            for leg in legs:
                client_id, filled_count, actual_cost_cents = leg
                _key(client_id)
                if client_id in seen:
                    raise ValueError("a client id appears twice in one group resolution")
                seen.add(client_id)
                filled = _count(filled_count)
                cost = _integer(actual_cost_cents, "actual cost")
                if not filled and cost:
                    raise ValueError("invalid resolution")
                rows.append((client_id, filled, cost))
            if not 1 <= len(rows) <= 64:
                raise ValueError("a group resolution is 1..64 legs")
            todo = []
            for client_id, filled, cost in rows:
                e = doc["intents"].get(client_id)
                if e is None:
                    return Refusal("unknown_intent")
                group = e.get("group")
                if not isinstance(group, dict) or group.get("wire_cid") != wire_client_id:
                    return Refusal("group_mismatch")
                verdict = self._resolution_check(e, filled, cost, terminal)
                if verdict is False:
                    continue
                if verdict is not None:
                    return verdict
                todo.append((e, filled, cost))
            for e, filled, cost in todo:
                self._apply_resolution(doc, e, filled, cost, terminal, now)
            for ticker in dict.fromkeys(e["ticker"] for e, _, _ in todo):
                self._refresh(doc, ticker)
            return bool(todo)
        return self._run(apply, now_ms, client_id=wire_client_id)

    def reconciled(self, client_id: str, filled_count: Decimal | str,
                   actual_cost_cents: int, now_ms: int | None = None) -> bool | Refusal:
        return self.resolve(client_id, filled_count, actual_cost_cents, True, now_ms)

    def mark_unknown(self, client_id: str, now_ms: int | None = None) -> bool | Refusal:
        def apply(doc: dict, now: int) -> bool | Refusal:
            e = doc["intents"].get(client_id)
            if e is None:
                return Refusal("unknown_intent")
            if e["state"] not in {"pending", "unknown"}:
                return Refusal("already_resolved")
            e["state"] = "unknown"
            e["updated_ms"] = now
            self._refresh(doc, e["ticker"])
            return True
        return self._run(apply, now_ms, client_id=client_id)

    @staticmethod
    def _post(doc: dict, lane: str, pnl: int) -> None:
        entry = doc["lanes"][lane]
        entry["realized_today_cents"] += pnl
        entry["gross_loss_today_cents"] += max(0, -pnl)
        entry["pilot_net_cents"] += pnl

    def post_exit(self, client_id: str, exit_id: str, count: Decimal | str,
                  proceeds_cents: int, fee_cents: int, now_ms: int | None = None,
                  *, terminal: bool = True) -> bool | Refusal:
        def apply(doc: dict, now: int) -> bool | Refusal:
            key = orjson.dumps(["exit", _key(client_id), _key(exit_id)]).decode()
            e = doc["intents"].get(client_id)
            if key in doc["postings"] or (e and exit_id in e["applied_exits"]):
                return False
            quantity = _count(count)
            proceeds = _integer(proceeds_cents, "proceeds") - _integer(fee_cents, "fee")
            if type(terminal) is not bool:
                raise ValueError("invalid terminal flag")
            if e is None or exit_id not in e["exit_claims"]:
                return Refusal("exit_not_claimed")
            reservation = e["exit_claims"][exit_id]
            residual = _count(e["residual_count"])
            if quantity > residual or quantity > _count(reservation["count"]):
                e.setdefault("exit_discrepancies", {})[exit_id] = {
                    "count": str(quantity), "proceeds_cents": proceeds_cents,
                    "fee_cents": fee_cents, "terminal": terminal, "at_ms": now}
                self._latch(doc["lanes"][e["lane"]], "accounting_discrepancy", now)
                doc["cash"]["needs_reconciliation"] = True
                doc["cash"]["reconcile_after_ms"] = max(now, doc["cash"]["reconcile_after_ms"])
                return Refusal("accounting_discrepancy")
            if e["state"] not in {"filled", "partial"}:
                return Refusal("exit_not_reconciled_or_exceeds_residual")
            if not terminal:
                # An uncertain result cannot release either the residual or debit.
                return True
            if not quantity and proceeds:
                raise ValueError("proceeds without exit fill")
            basis = (e["cost_cents"] if quantity == residual else
                     int((Decimal(e["cost_cents"]) * quantity / residual).to_integral_value(rounding=ROUND_FLOOR)))
            self._post(doc, e["lane"], proceeds - basis)
            if proceeds < 0:
                doc["cash"]["needs_reconciliation"] = True
                doc["cash"]["reconcile_after_ms"] = max(now, doc["cash"]["reconcile_after_ms"])
            if -proceeds > reservation["debit_cents"]:
                self._latch(doc["lanes"][e["lane"]], "accounting_discrepancy", now)
            e["residual_count"] = str(residual - quantity)
            e["cost_cents"] -= basis
            if quantity == residual:
                e["state"] = "exited"
            del e["exit_claims"][exit_id]
            e["applied_exits"][exit_id] = now
            e["updated_ms"] = now
            doc["postings"][key] = now
            self._refresh(doc, e["ticker"])
            return True
        return self._run(apply, now_ms, client_id=client_id)

    def claim_exit(self, lane: str, client_id: str, exit_id: str, count: Decimal | str,
                   fee_cents: int, now_ms: int, *, reduce_only: bool) -> Grant | Refusal:
        """Reserve only the fee for an exit the caller asserts is reduce_only.

        The hold itself denotes a potentially unknown submission. Only a terminal
        post_exit or settlement releases it; restart, timeout and read-only exit_allowed cannot.
        Exits may reduce risk even when the purchase lane is latched.
        """
        def apply(doc: dict, now: int) -> Grant | Refusal:
            if reduce_only is not True:
                return Refusal("not_reduce_only")
            for identifier in (lane, client_id, exit_id):
                _key(identifier)
            quantity = _count(count, positive=True)
            debit = _integer(fee_cents, "exit fee")
            e = doc["intents"].get(client_id)
            if e is None or e["lane"] != lane:
                return Refusal("exit_not_owned")
            if self._client_id_used(doc, exit_id):
                return Refusal("duplicate_exit_id")
            owner = doc["tickers"].get(e["ticker"])
            if e["state"] not in {"filled", "partial"} or not owner or owner["state"] != "open":
                return Refusal("exit_not_reconciled_or_exceeds_residual")
            held = sum((_count(x["count"]) for x in e["exit_claims"].values()), Decimal("0.00"))
            if quantity > _count(e["residual_count"]) - held:
                return Refusal("exit_not_reconciled_or_exceeds_residual")
            cash = doc["cash"]
            available = cash["free_cash_cents"] - self._reserved(doc) - debit
            if available < 0:
                return Refusal("insufficient_cash")
            e["exit_claims"][exit_id] = {"count": str(quantity), "debit_cents": debit}
            e["updated_ms"] = now
            self._refresh(doc, e["ticker"])
            return Grant(client_id, debit, available)
        return self._run(apply, now_ms, client_id=client_id, check_skew=True)

    def post_settlement(self, ticker: str, settlement_id: str, payout_cents: int,
                        now_ms: int | None = None) -> bool | Refusal:
        def apply(doc: dict, now: int) -> bool | Refusal:
            key = orjson.dumps(["settlement", _key(ticker), _key(settlement_id)]).decode()
            if not any(e["ticker"] == ticker for e in doc["intents"].values()):
                return Refusal("unknown_intent")
            if key in doc["postings"] or any(
                    e["ticker"] == ticker and settlement_id in e["applied_settlements"]
                    for e in doc["intents"].values()):
                return False
            payout = _integer(payout_cents, "payout")
            owner = doc["tickers"].get(ticker)
            if owner is None:
                return Refusal("ticker_not_owned")
            if any(doc["intents"][cid]["state"] not in {"filled", "partial"}
                   for cid in owner["client_ids"]):
                return Refusal("ticker_not_reconciled")
            self._post(doc, owner["lane"], payout - owner["cost_cents"])
            for cid in owner["client_ids"]:
                doc["intents"][cid].update(state="settled", residual_count="0.00", cost_cents=0,
                                           updated_ms=now, exit_claims={})
                doc["intents"][cid]["applied_settlements"][settlement_id] = now
            doc["postings"][key] = now
            self._refresh(doc, ticker)
            return True
        return self._run(apply, now_ms)

    def update_cash(self, free_cash_cents: int, as_of_ms: int) -> bool | Refusal:
        """Apply a balance whose request was sent at as_of_ms, after all known fills."""
        def apply(doc: dict, now: int) -> bool | Refusal:
            _integer(free_cash_cents, "free cash")
            _integer(as_of_ms, "as_of_ms")
            cash = doc["cash"]
            if (as_of_ms < cash["as_of_ms"] or as_of_ms <= cash["reconcile_after_ms"]
                    or as_of_ms > now):
                return Refusal("cash_out_of_order")
            cash.update(free_cash_cents=free_cash_cents, as_of_ms=as_of_ms, needs_reconciliation=False)
            doc["floor_breach"] = free_cash_cents < doc["floor_cents"]
            for lane in self.caps:
                self._lane(doc, lane, now)
            if doc["floor_breach"]:
                for entry in doc["lanes"].values():
                    if any(value is not None for value in entry["caps"].values()):
                        self._latch(entry, "floor_breach", now)
            return True
        return self._run(apply, maintenance_after=True)

    def latch(self, lane: str, reason: str, now_ms: int | None = None) -> bool | Refusal:
        def apply(doc: dict, now: int) -> bool:
            entry = self._lane(doc, lane, now)
            self._latch(entry, reason, now)
            return True
        return self._run(apply, now_ms)

    def set_caps(self, lane: str, *, allow_unlimited: bool = False, **changes) -> dict | Refusal:
        def apply(doc: dict, now: int) -> dict | Refusal:
            entry = doc["lanes"].get(_key(lane))
            if entry is None:
                return Refusal("unknown_lane", lane)
            if any(e["lane"] == lane and e["state"] == "unknown" for e in doc["intents"].values()):
                return Refusal("unknown_intent", lane)
            before = dict(entry["caps"])
            after = {key: value for key, value in asdict(LaneCaps(**{**before, **changes})).items()
                     if value is not None}
            had_cap = (entry.get("daily_cap_cents") is not None
                       or before.get("daily_loss_bp") is not None
                       or before.get("max_daily_gross_loss_cents") is not None)
            if (had_cap and after.get("daily_loss_bp") is None
                    and after.get("max_daily_gross_loss_cents") is None and not allow_unlimited):
                return Refusal("unlimited_daily_cap")
            entry["caps"] = after
            if any(before.get(key) != after.get(key) for key in ("daily_loss_bp", "loss_window_hours")):
                entry["period"] = now // ((after.get("loss_window_hours") or 24) * 3_600_000)
                self._rebase(doc, entry, now)
            elif after.get("daily_loss_bp") is None:
                self._rebase(doc, entry, now)
            event = {"kind": "caps_set", "lane": lane, "before": before, "after": after, "at_ms": now}
            history = doc.setdefault("caps_history", [])
            history.append(event)
            del history[:-32]
            return {**event, "daily_cap_cents": entry.get("daily_cap_cents"),
                    "period_ends_ms": (entry["period"] + 1) *
                        (after.get("loss_window_hours") or 24) * 3_600_000,
                    "latched": entry["latched"]}
        return self._run(apply, initialize_caps=False)

    def unlatch(self, lane: str, now_ms: int | None = None, *,
                reset_daily_loss: bool = False, force: bool = False) -> bool | Refusal:
        def apply(doc: dict, now: int) -> bool | Refusal:
            entry = self._lane(doc, lane, now)
            if entry["latched"] is not None:
                reason = entry["latched"]["reason"]
                if reason == "max_daily_gross_loss_cents":
                    entry["latched"] = _promote_after_daily(entry)
                elif force:
                    entry["latched"] = None
                else:
                    return Refusal("permanent_latch", reason)
            if reset_daily_loss:
                entry["gross_loss_today_cents"] = 0
            return True
        return self._run(apply, now_ms)

    def exit_allowed(self, lane: str, ticker: str, count: Decimal | str) -> Decimal | Refusal:
        def apply(doc: dict, now: int) -> Decimal:
            quantity = _count(count)
            owner = doc["tickers"].get(ticker)
            if owner is None or owner["lane"] != lane or owner["state"] != "open":
                return Decimal("0.00")
            return min(quantity, _count(owner["filled_count"]))
        return self._run(apply, readonly=True)

    def snapshot(self, now_ms: int | None = None) -> dict | Refusal:
        def apply(doc: dict, now: int) -> dict:
            budgets = {}
            for lane, entry in doc["lanes"].items():
                risk = sum(self._risk(e) for e in doc["intents"].values() if e["lane"] == lane)
                budgets[lane] = {"open_pending_loss_cents": risk,
                                 "caps": dict(entry["caps"]),
                                 "daily_cap_cents": entry.get("daily_cap_cents"),
                                 "period": self._entry_period(entry),
                                 "period_ends_ms": (self._entry_period(entry) + 1) *
                                     (entry["caps"].get("loss_window_hours") or 24) * 3_600_000,
                                 "daily_used_cents": entry["gross_loss_today_cents"] + risk,
                                 "pilot_used_cents": max(0, -entry["pilot_net_cents"]) + risk}
            return {**doc, "reserved_debit_cents": self._reserved(doc), "budgets": budgets,
                    "intent_count": len(doc["intents"]), "ticker_count": len(doc["tickers"])}
        return self._run(apply, now_ms, readonly=True)
