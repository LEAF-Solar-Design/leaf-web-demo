"""Offline, non-destructive ledger conversion. Never rename a live ledger here."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3

from . import account_risk as risk
from . import account_risk_rows as rows


ROWS_POISON_BODY = rows.ROWS_POISON_BODY


def export_bytes(state):
    """Canonical public JSON bytes, independent of storage metadata field order."""
    return json.dumps(state, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("utf-8")


def _state(db, format_name):
    if format_name == "rows":
        rows._verify_restored_rows(db)
        state, counters, _ = rows._load(db)
        # Reconstruct the current split body, including hot insertion order and
        # archive sequence/age. Never consult a retained account_risk body.
        body = rows._metadata(state)
        body["entries"] = dict(state["entries"])
        body["events"] = dict(state["events"])
        if "legacy_imports" in state:
            body["legacy_imports"] = state["legacy_imports"]
        if body["version"] == 2:
            records = db.execute("SELECT client_id,sequence,closed_day FROM risk_entry "
                                 "ORDER BY hot_order").fetchall()
            body[risk._ARCHIVE] = dict(
                count=counters["archived"], legacy_count=counters["archive_legacy"],
                next=counters["next_entry"], order={cid: seq for cid, seq, _ in records},
                closed={cid: day for cid, _, day in records if day is not None})
    else:
        record = db.execute("SELECT body FROM account_risk WHERE id=1").fetchone()
        if record is None:
            raise risk.AccountRiskRefused("empty conversion source", code="ledger_corrupt")
        body = json.loads(record[0])
    if (type(body) is not dict or type(body.get("version")) is not int
            or body["version"] not in (1, 2) or type(body.get("account_id")) is not str
            or not body["account_id"]):
        raise risk.AccountRiskRefused("invalid conversion schema", code="ledger_corrupt")
    full = risk._archive_view(db, body)
    if risk._ledger_structure_error(full) is not None:
        raise risk.AccountRiskRefused("invalid conversion source", code="ledger_corrupt")
    hot = risk._archive_view(db, body, hot=True)
    archive = []
    if body["version"] == 2:
        archive = db.execute("SELECT kind,id,body,sequence,day FROM account_risk_archive").fetchall()
    return body, archive, full, hot


def _write_rows(db, body, archive):
    rows._format(db, create=True)
    counters = rows._counters()
    meta = body.get(risk._ARCHIVE)
    bounds = {}
    for hot_order, (cid, entry) in enumerate(body["entries"].items()):
        sequence = meta["order"][cid] if meta else hot_order
        closed_day = meta["closed"].get(cid) if meta else None
        payload = rows._json(entry)
        rows._contribute(db, counters, cid, entry, 1)
        rows._entry_chars(counters, cid, payload, sequence, closed_day, 1)
        db.execute("INSERT INTO risk_entry VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (cid, sequence, hot_order, entry["ticker"], entry["minute"], entry["state"],
                    str(entry["cost_cents"]), str(entry["reserved_cents"]),
                    int(risk._probe_entry(cid, entry)), entry.get("pd"), rows._json(entry.get("pl")),
                    closed_day, len(payload.encode("utf-8")), payload))
        if entry["state"] != "closed":
            minute = entry["minute"]
            low, high = bounds.get(entry["ticker"], (minute, minute))
            bounds[entry["ticker"]] = min(low, minute), max(high, minute)
    for ticker, (low, high) in bounds.items():
        db.execute("UPDATE risk_ticker SET min_minute=?,max_minute=? WHERE ticker=?", (low, high, ticker))
    for sequence, (key, event) in enumerate(body["events"].items()):
        payload = rows._json(event)
        moved = risk._transfer_value(event) if key.startswith(risk._TRANSFER_PREFIX) else None
        db.execute("INSERT INTO risk_event VALUES(?,?,?,?,?)",
                   (key, sequence, payload, moved[1] if moved else None, str(moved[0]) if moved else None))
        counters["events"] += 1
        counters["event_chars"] += len(rows._json(key)) + 1 + len(payload)
    risk._archive_insert(db, archive)
    counters.update(next_entry=meta["next"] if meta else len(body["entries"]),
                    next_hot=len(body["entries"]), next_event=len(body["events"]),
                    archived=meta["count"] if meta else 0,
                    archive_legacy=meta["legacy_count"] if meta else 0,
                    has_imports="legacy_imports" in body)
    db.executemany("INSERT INTO risk_legacy VALUES(?,?)", body.get("legacy_imports", {}).items())
    counters["logical_bytes"] = rows._body_chars(body, counters)
    db.execute("INSERT INTO risk_account VALUES(1,?,?,?,?,?,?,?,?,?,?)",
               (1, body["revision"], body["day"], str(body["day_open_cents"]),
                str(body["equity_cents"]), str(body["high_water_cents"]),
                rows._json([body.get(risk._MARKED_CENTS), body.get(risk._MARKED_NS)]),
                body["fault"], rows._json(rows._metadata(body)), rows._json(counters)))
    rows._verify_restored_rows(db)


def _fsync_directory(path):
    if os.name != "nt":
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def convert(source_path, destination_path, *, to):
    """Keep SRC locked through verification and receipt durability; never overwrite DST.

    BEGIN EXCLUSIVE fences active write transactions in both WAL and DELETE mode.
    It cannot prove an idle process is dead: the operator must stop every writer.
    """
    if to not in ("rows", "body"):
        raise risk.AccountRiskRefused("invalid conversion format", code="input_invalid")
    source_path = Path(source_path).resolve()
    destination_path = Path(destination_path).absolute()
    receipt_path = destination_path.with_name(destination_path.name + ".receipt.json")
    if (source_path == destination_path.resolve() or destination_path.is_symlink()
            or source_path.parent != destination_path.parent.resolve()
            or destination_path.exists() or receipt_path.exists() or receipt_path.is_symlink()):
        raise risk.AccountRiskRefused("conversion requires unused sibling destination", code="input_invalid")
    started = datetime.now(timezone.utc).isoformat()
    source = dest = None
    try:
        source = sqlite3.connect(source_path.as_uri() + "?mode=rw", uri=True,
                                 timeout=2, isolation_level=None)
        source.execute("BEGIN EXCLUSIVE")
        source_format = rows._ledger_format(source)
        expected = "body" if to == "rows" else "rows"
        if source_format != expected:
            code = {"rows": "ledger_format_rows", "body": "ledger_format_body"}.get(
                source_format, "ledger_corrupt")
            raise risk.AccountRiskRefused("conversion source must be " + expected, code=code)
        body, archive, full, hot = _state(source, source_format)
        # Exclusive creation, even if another converter raced the initial checks.
        with destination_path.open("xb"):
            pass
        dest = sqlite3.connect(str(destination_path), timeout=2, isolation_level=None)
        dest.execute("PRAGMA synchronous=FULL")
        dest.execute("BEGIN EXCLUSIVE")
        if to == "rows":
            _write_rows(dest, body, archive)
        else:
            dest.execute("CREATE TABLE account_risk(id INTEGER PRIMARY KEY, body TEXT NOT NULL)")
            dest.execute("INSERT INTO account_risk VALUES(1,?)", (rows._json(body),))
            if body["version"] == 2:
                risk._archive_create(dest)
                risk._archive_insert(dest, archive)
        _, _, target_full, target_hot = _state(dest, to)
        for before, after in ((full, target_full), (hot, target_hot)):
            if (export_bytes(before) != export_bytes(after)
                    or list(before["entries"]) != list(after["entries"])
                    or list(before["events"]) != list(after["events"])):
                raise risk.AccountRiskRefused("conversion export mismatch", code="ledger_corrupt")
        dest.execute("COMMIT")
        dest.close()
        dest = None
        with destination_path.open("r+b") as file:
            os.fsync(file.fileno())
        # Reopen the durable file while SRC remains locked, and verify again.
        dest = risk._connect_ro(destination_path)
        dest.execute("BEGIN")
        _, _, durable_full, durable_hot = _state(dest, to)
        if (export_bytes(full), export_bytes(hot)) != (export_bytes(durable_full), export_bytes(durable_hot)):
            raise risk.AccountRiskRefused("durable conversion export mismatch", code="ledger_corrupt")
        digest = lambda value: hashlib.sha256(export_bytes(value)).hexdigest()
        receipt = dict(schema="leafhft-ledger-conversion-v1", source=str(source_path),
                       destination=str(destination_path), source_format=source_format, destination_format=to,
                       account_id=body["account_id"], revision=body["revision"],
                       entry_count=len(full["entries"]), hot_entry_count=len(hot["entries"]),
                       event_count=len(full["events"]), archive_count=len(archive),
                       source_digests=dict(full=digest(full), hot=digest(hot)),
                       destination_digests=dict(full=digest(durable_full), hot=digest(durable_hot)),
                       started_at=started, completed_at=datetime.now(timezone.utc).isoformat())
        if to == "rows":
            receipt["legacy_slot"] = "poisoned"
        with receipt_path.open("x", encoding="utf-8", newline="\n") as file:
            file.write(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
            file.flush()
            os.fsync(file.fileno())
        _fsync_directory(destination_path.parent)
        return receipt
    except (sqlite3.Error, OSError, ValueError, KeyError, TypeError, RecursionError) as exc:
        raise risk.AccountRiskRefused("ledger conversion unavailable or corrupt", code="ledger_corrupt") from exc
    finally:
        for db in (dest, source):
            if db is not None:
                if db.in_transaction:
                    db.execute("ROLLBACK")
                db.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("direction", choices=("to-rows", "to-body"))
    parser.add_argument("source")
    parser.add_argument("destination")
    args = parser.parse_args(argv)
    try:
        receipt = convert(args.source, args.destination, to=args.direction.removeprefix("to-"))
    except risk.AccountRiskRefused as exc:
        parser.exit(1, f"{exc.code}: {exc}\n")
    print(json.dumps(receipt, sort_keys=True))


if __name__ == "__main__":
    main()
