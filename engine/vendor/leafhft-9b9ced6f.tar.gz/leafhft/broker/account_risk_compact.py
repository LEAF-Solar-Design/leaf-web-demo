"""Explicit entry-archive migration; deploy compatible writers before compacting.

Run ``python -m leafhft.broker.account_risk_compact --help`` for commands.
Stop all other writers before uncompact: its write lock covers the entire merge.
Events remain in the hot body. Dry runs and status never create or change a file.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sqlite3
import sys

from . import account_risk as risk
from .account_risk_rows import ledger_format


MAX_RETRIES = 8


def _refuse_rows(path=None, db=None):
    rows = (ledger_format(path) == "rows" if db is None else
            db.execute("SELECT 1 FROM sqlite_master WHERE name='risk_format'").fetchone())
    if rows:
        raise risk.AccountRiskRefused("body archive refuses rows ledger", code="ledger_format_rows")


def _decode(body, account_id=None):
    if body is None:
        raise risk.AccountRiskRefused("risk ledger is empty", code="ledger_corrupt")
    state = json.loads(body)
    if (type(state) is not dict or type(state.get("version")) is not int
            or state["version"] not in (1, 2)
            or type(state.get("account_id")) is not str or not state["account_id"]
            or (account_id is not None and state["account_id"] != account_id)):
        raise risk.AccountRiskRefused("risk ledger identity/schema mismatch", code="ledger_identity")
    reason = risk._ledger_structure_error(state)
    if reason:
        raise risk.AccountRiskRefused(reason, code="ledger_corrupt")
    if state["version"] == 2:
        risk._archive_meta(state)
    return state


def _prepare(body, account_id, max_entries, max_bytes):
    state = _decode(body, account_id)
    if state["version"] == 1:
        state["version"] = 2
        risk._archive_init(state)
    rows, oversize = risk._archive_prepare(state, max_entries=max_entries, max_bytes=max_bytes)
    payload = risk._archive_json(state)
    if payload != body:
        state["revision"] += 1
        payload = risk._archive_json(state)
    return payload, rows, oversize


def _commit_batch(path, source, payload, rows):
    """Only byte comparison, prepared inserts and prepared body replacement hold the write lock."""
    db = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=rw", uri=True,
                         timeout=2, isolation_level=None)
    try:
        db.execute("PRAGMA synchronous=FULL")
        db.execute("BEGIN IMMEDIATE")
        _refuse_rows(db=db)
        row = db.execute("SELECT body FROM account_risk WHERE id=1").fetchone()
        if row is None or row[0] != source:
            db.execute("ROLLBACK")
            return False
        if payload == source:
            db.execute("ROLLBACK")
            return True
        risk._archive_create(db)
        risk._archive_insert(db, rows)
        db.execute("UPDATE account_risk SET body=? WHERE id=1", (payload,))
        db.execute("COMMIT")
        return True
    finally:
        if db.in_transaction:
            db.execute("ROLLBACK")
        db.close()


def compact(path, account_id, *, max_entries=128, max_bytes=65536, dry_run=False):
    """Each batch retries from a fresh read at most eight times; failed batches change nothing."""
    _refuse_rows(path)
    if (type(max_entries) is not int or not 1 <= max_entries <= risk.ARCHIVE_BATCH_ENTRIES
            or type(max_bytes) is not int or not 1 <= max_bytes <= risk.ARCHIVE_BATCH_BYTES):
        raise ValueError("batch limits must be 1..128 entries and 1..65536 bytes")
    moved = batches = retries = largest_entries = largest_bytes = 0
    while True:
        for attempt in range(MAX_RETRIES):
            source = risk._read_body_ro(path)
            payload, rows, oversize = _prepare(source, account_id, max_entries, max_bytes)
            if dry_run or _commit_batch(path, source, payload, rows):
                break
            retries += 1
        else:
            raise risk.AccountRiskRefused("compaction concurrent-change retry limit", code="revision_conflict")
        if payload != source:
            batches += 1
        moved += len(rows)
        largest_entries = max(largest_entries, len(rows))
        largest_bytes = max(largest_bytes, sum(len(row[2].encode("utf-8")) for row in rows))
        if dry_run or not rows:
            return {"dry_run": dry_run, "moved": moved, "batches": batches, "retries": retries,
                    "max_batch_entries": largest_entries, "max_batch_bytes": largest_bytes,
                    "oversize_kept": oversize}


def uncompact(path, account_id):
    """Requires all other writers stopped; merge, revision advance and archive deletion are atomic."""
    _refuse_rows(path)
    db = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=rw", uri=True,
                         timeout=2, isolation_level=None)
    try:
        db.execute("PRAGMA synchronous=FULL")
        db.execute("BEGIN IMMEDIATE")
        _refuse_rows(db=db)
        row = db.execute("SELECT body FROM account_risk WHERE id=1").fetchone()
        state = _decode(None if row is None else row[0], account_id)
        state = risk._archive_view(db, state)
        state["version"] = 1
        state["revision"] += 1
        payload = risk._archive_json(state)
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='account_risk_archive'").fetchone():
            db.execute("DELETE FROM account_risk_archive")
        db.execute("UPDATE account_risk SET body=? WHERE id=1", (payload,))
        db.execute("COMMIT")
        return {"version": 1, "hot_entries": len(state["entries"]), "archived_entries": 0,
                "body_bytes": len(payload.encode("utf-8"))}
    finally:
        if db.in_transaction:
            db.execute("ROLLBACK")
        db.close()


def status(path):
    """Counts only: no entry, ticker, principal or event contents are emitted."""
    _refuse_rows(path)
    db = risk._connect_ro(path)
    try:
        db.execute("BEGIN")
        row = db.execute("SELECT body FROM account_risk WHERE id=1").fetchone()
        body = None if row is None else row[0]
        state = _decode(body)
        archived = 0
        if state["version"] == 2:
            archived = db.execute("SELECT count(*) FROM account_risk_archive").fetchone()[0]
            if archived != state[risk._ARCHIVE]["count"]:
                raise risk._archive_error()
        oversize = sum(entry.get("state") == "closed" and
                       len(risk._archive_json(entry).encode("utf-8")) > risk.ARCHIVE_ENTRY_MAX_BYTES
                       for entry in state["entries"].values())
        return {"version": state["version"], "body_bytes": len(body.encode("utf-8")),
                "hot_entries": len(state["entries"]), "archived_entries": archived,
                "oversize_kept": oversize}
    finally:
        db.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("compact", "uncompact", "status"):
        command = commands.add_parser(name)
        command.add_argument("--path", required=True)
        if name != "status":
            command.add_argument("--account-id", required=True)
        if name == "compact":
            command.add_argument("--max-entries", type=int, default=128)
            command.add_argument("--max-bytes", type=int, default=65536)
            command.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.command == "compact":
            result = compact(args.path, args.account_id, max_entries=args.max_entries,
                             max_bytes=args.max_bytes, dry_run=args.dry_run)
        elif args.command == "uncompact":
            result = uncompact(args.path, args.account_id)
        else:
            result = status(args.path)
    except (risk.AccountRiskRefused, sqlite3.Error, OSError, ValueError, TypeError, KeyError):
        print("account risk archive command refused", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
