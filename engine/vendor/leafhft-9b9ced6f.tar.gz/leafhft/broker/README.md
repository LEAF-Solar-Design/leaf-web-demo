# Account-risk ledger restores

The broker's account-risk state document is one SQLite row,
`account_risk.id=1`. Restore it only as one atomic snapshot. Capture its events,
entries, paid bases and derived fields together from one read.

Before a restore, stop every writer on that ledger. This includes frozen-version
books that share the file. Pass the complete JSON body to
`restore_snapshot(path, body, account_id=account_id, note=note)`. Use a note of
1 to 200 characters that names who restored it, when, and the source snapshot
digest. The helper validates the body, sets `restore_marker`, replaces the whole
row in one transaction and returns the SHA-256 digest of the stored payload.
The one other lawful form is a whole-file copy of a complete ledger file while
every writer is stopped.

Never edit fields in place. A partial restore is a hand edit and is outside the
guarantee, even if each field came from a valid ledger.

On the first current-writer transaction, the marker triggers an audit of the
body and a recount of its transfer events. A mismatch drops the four derived
X2b fields together: the transfer index, the marked day's transfer record, the
marked start and its timestamp. The next non-widened mark can install them
again. A matching start and record are kept, and the recount replaces the index.
The transaction clears the marker in the same commit as its own operation. If
it rolls back, the stored body and marker stay unchanged.
An integer marked start outside 0 to 2**53 - 1 cents is corrupt, not repairable
by recount. The audit refuses it and keeps the stored body and marker unchanged.

The frozen writer carries the marker but does not act on it. The paid term
plus that first current-writer transaction decide; the frozen writer alone
does not audit the restored derived fields.

Check the result with `read_ledger(path, account_id)`. Its `status` must be
`"ok"`. A valid marker can still be present until the first current-writer
transaction commits. Compaction stays off.
