"""B12: one account-wide Kalshi write budget, shared by every book process on a credential.

Fourteen book processes hold their own KalshiLive on the same credential, so a per-process or
per-engine cap bounds nothing at the account. This is one token bucket per credential, kept in a
small state file under a shared root (production: /var/lib/leafhft), keyed by the first 16 hex of
sha256(key id). The key id itself is never stored, logged, reported or put in an exception.

Contract:
  - exit: always admitted. Takes one token from the main bucket and may drive it into debt,
    clamped at -burst. Never touches the probe sub-bucket.
  - entry: admitted only while the main bucket keeps at least exit_reserve tokens after taking
    one (the reserve is exit capacity entries and probes can never take).
  - probe: refused rate_budget_suspended for PROBE_SUSPEND_S after any process saw a 429; else
    admitted only if the probe sub-bucket has a token AND the main bucket keeps its reserve.
  - Fails closed: a lock past its 250 ms bound or an unreadable, oversize, non-regular, symlinked
    or malformed state file refuses entries and probes rate_budget_unavailable and admits exits.
    A malformed file is never reset here; an operator removes it.

Hot path: one non-blocking lock (bounded attempts, at most LOCK_RETRY_S between them), one
bounded read, one temp write in the same directory and one os.replace. O(1), no allocation that
grows, and it NEVER sleeps to wait for a token. No fsync: the bucket is a rate limit, not a
ledger, and a torn or lost write fails closed (malformed) or re-grants at most one refill.
Tokens are integer milli-tokens. Every figure is a validated constructor input with NO default:
the account figure is operator fork (2).

B12-read: scope="read" keeps a SECOND bucket per credential (kalshi-read-<digest>.json beside the
write file) for the account's read limit. Its kinds are critical (exit semantics: always admitted,
may run into debt clamped at -burst, admitted when the state is unavailable) and discretionary
(entry semantics: kept above exit_reserve, refused rate_budget_unavailable when the state is
unavailable). write_per_s is read tokens per second there; the probe fields are validated and
unused. The default scope is write, byte-identical to B12.
"""
from __future__ import annotations

import errno
import hashlib
import json
import os
import secrets
import stat
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

PROBE_SUSPEND_S = 60
PROBE_SUSPEND_NS = PROBE_SUSPEND_S * 1_000_000_000
MAX_STATE_BYTES = 4096
LOCK_WAIT_NS = 250_000_000
LOCK_RETRY_S = 0.001  # never above 5 ms per attempt
MILLI = 1000
STATE_VERSION = 1
COUNTER_MAX = 2**53
_NS_MAX = 2**63 - 1
_TOKENS_ABS_MAX = 10_000 * MILLI  # the largest legal burst (10 x 1000), in milli-tokens

EXHAUSTED = "rate_budget_exhausted"
SUSPENDED = "rate_budget_suspended"
UNAVAILABLE = "rate_budget_unavailable"
REFUSAL_CODES = frozenset({EXHAUSTED, SUSPENDED, UNAVAILABLE})
KINDS = ("exit", "entry", "probe")
# B12-read: the read scope's two classes. critical takes exit semantics (always admitted, may run
# into debt clamped at -burst); discretionary takes entry semantics (kept above exit_reserve).
READ_KINDS = ("critical", "discretionary")
SCOPES = ("write", "read")
_ALWAYS_ADMITTED = frozenset({"exit", "critical"})
_RESERVE_KEPT = frozenset({"entry", "discretionary"})

_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)
_BINARY = getattr(os, "O_BINARY", 0)
_LOCK_BUSY = frozenset({errno.EACCES, errno.EAGAIN, getattr(errno, "EWOULDBLOCK", errno.EAGAIN),
                        getattr(errno, "EDEADLK", 36), 13, 33, 36})
_STATE_KEYS = frozenset({"version", "key", "config", "tokens", "probe_tokens", "last_ns",
                         "probe_last_ns", "probe_suspended_until_ns", "counters"})
_COUNTER_KEYS = frozenset({"admitted", "refused", "exit_debt"})
_HEX = frozenset("0123456789abcdef")


class _Unavailable(Exception):
    """The shared state cannot be read, locked or written; callers fail closed."""


@dataclass(frozen=True)
class RateBudgetConfig:
    """The account write budget. Integers only, validated here; no field has a default."""

    write_per_s: int
    burst: int
    exit_reserve: int
    probe_per_s: int
    probe_burst: int

    def __post_init__(self) -> None:
        for name in ("write_per_s", "burst", "exit_reserve", "probe_per_s", "probe_burst"):
            if type(getattr(self, name)) is not int:
                raise ValueError(f"rate budget {name} must be an int")
        if not 1 <= self.write_per_s <= 1000:
            raise ValueError("rate budget write_per_s must be 1..1000")
        if not 1 <= self.burst <= 10 * self.write_per_s:
            raise ValueError("rate budget burst must be 1..10 x write_per_s")
        if not 0 <= self.exit_reserve <= self.burst - 1:
            raise ValueError("rate budget exit_reserve must be 0..burst-1")
        if not 1 <= self.probe_per_s <= self.write_per_s:
            raise ValueError("rate budget probe_per_s must be 1..write_per_s")
        if not 1 <= self.probe_burst <= self.burst:
            raise ValueError("rate budget probe_burst must be 1..burst")

    def digest(self) -> str:
        text = (f"{self.write_per_s},{self.burst},{self.exit_reserve},"
                f"{self.probe_per_s},{self.probe_burst}")
        return hashlib.sha256(text.encode()).hexdigest()[:16]


@dataclass(frozen=True)
class Decision:
    """admitted is the only field a caller gates on. code names a refusal; an exit admitted while
    the state was unavailable carries code rate_budget_unavailable with admitted True."""

    admitted: bool
    kind: str
    code: str | None = None


def _refill(tokens: int, last_ns: int, capacity: int, rate_milli_per_s: int, now_ns: int):
    """(tokens, last_ns) after refilling to now_ns. last_ns never moves backward and advances only
    by the time the credited milli-tokens represent, so frequent calls lose no fractional refill;
    a forward step refills at most to capacity. Pure integer arithmetic, O(1)."""
    if now_ns <= last_ns:
        return tokens, last_ns
    need = capacity - tokens
    if need <= 0 or (now_ns - last_ns) * rate_milli_per_s >= need * 1_000_000_000:
        return capacity, now_ns
    added = (now_ns - last_ns) * rate_milli_per_s // 1_000_000_000
    return tokens + added, last_ns + added * 1_000_000_000 // rate_milli_per_s


class KalshiRateBudget:
    """The shared write bucket for one credential. See the module docstring for the contract."""

    def __init__(self, root: Path, key_id: str, config: RateBudgetConfig, *, clock_ns=time.time_ns,
                 scope: str = "write") -> None:
        if not isinstance(root, (str, os.PathLike)):
            raise ValueError("rate budget root must be a path")
        if type(key_id) is not str or not key_id:
            raise ValueError("rate budget key id missing")
        if not isinstance(config, RateBudgetConfig):
            raise ValueError("rate budget config must be a RateBudgetConfig")
        if not callable(clock_ns):
            raise ValueError("rate budget clock must be callable")
        if type(scope) is not str or scope not in SCOPES:
            raise ValueError("rate budget scope must be write or read")
        self.scope = scope
        self._kinds = KINDS if scope == "write" else READ_KINDS
        self._root = Path(root)
        self._key_digest = hashlib.sha256(key_id.encode()).hexdigest()[:16]
        self._stem = (f"kalshi-rate-{self._key_digest}" if scope == "write"
                      else f"kalshi-read-{self._key_digest}")
        self._state_path = self._root / f"{self._stem}.json"
        self._lock_path = self._root / f"{self._stem}.lock"
        self.config = config
        self._config_digest = config.digest()
        self._capacity = config.burst * MILLI
        self._probe_capacity = config.probe_burst * MILLI
        self._reserve = config.exit_reserve * MILLI
        self._rate = config.write_per_s * MILLI
        self._probe_rate = config.probe_per_s * MILLI
        self._clock_ns = clock_ns
        self._lock_fd: int | None = None
        self._owner = os.geteuid() if os.name == "posix" else None
        # Process-local counts for status, bounded by the closed kind and code sets.
        self._admitted = {kind: 0 for kind in self._kinds}
        self._refused = {kind: {} for kind in self._kinds}
        self._unavailable = 0
        self._note_failed = 0
        self._suspensions = 0

    def __repr__(self) -> str:
        return "KalshiRateBudget()"

    def matches_key(self, key_id) -> bool:
        return type(key_id) is str and hashlib.sha256(key_id.encode()).hexdigest()[:16] == self._key_digest

    def close(self) -> None:
        fd, self._lock_fd = self._lock_fd, None
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass

    # ---- file handling (fails closed; every error is _Unavailable to the callers) ----

    def _now(self, now_ns) -> int:
        now = self._clock_ns() if now_ns is None else now_ns
        if type(now) is not int or not 0 <= now <= _NS_MAX:
            raise _Unavailable("clock")
        return now

    def _check_fd(self, fd: int, expected=None) -> os.stat_result:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_STATE_BYTES:
            raise _Unavailable("unsafe file")
        if expected is not None and (info.st_dev, info.st_ino) != (expected.st_dev, expected.st_ino):
            raise _Unavailable("file replaced")
        if os.name == "posix" and (info.st_nlink != 1 or info.st_uid != self._owner
                                   or stat.S_IMODE(info.st_mode) & 0o077):
            raise _Unavailable("unsafe file")
        return info

    def _check_root(self) -> None:
        info = os.lstat(self._root)
        if not stat.S_ISDIR(info.st_mode):
            raise _Unavailable("unsafe root")
        if os.name == "posix" and (info.st_uid not in (0, self._owner)
                                   or stat.S_IMODE(info.st_mode) & 0o022):
            raise _Unavailable("unsafe root")

    def _open_lock(self) -> int:
        fd = self._lock_fd
        if fd is not None:
            return fd
        if not _NOFOLLOW:  # Windows has no O_NOFOLLOW: refuse a link before opening
            try:
                if stat.S_ISLNK(os.lstat(self._lock_path).st_mode):
                    raise _Unavailable("lock is a link")
            except FileNotFoundError:
                pass
        fd = os.open(self._lock_path, os.O_RDWR | os.O_CREAT | _NOFOLLOW | _BINARY, 0o600)
        try:
            self._check_fd(fd)
        except BaseException:
            os.close(fd)
            raise
        self._lock_fd = fd
        return fd

    @staticmethod
    def _try_lock(fd: int) -> None:
        if os.name == "posix":
            import fcntl
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        else:
            import msvcrt
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)

    @staticmethod
    def _unlock(fd: int) -> None:
        try:
            if os.name == "posix":
                import fcntl
                fcntl.flock(fd, fcntl.LOCK_UN)
            else:
                import msvcrt
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        except OSError:
            pass

    @contextmanager
    def _locked(self):
        """Exclusive across processes. Non-blocking attempts on both platforms, bounded by
        LOCK_WAIT_NS in total; a timeout is _Unavailable, never an unbounded wait."""
        self._check_root()
        fd = self._open_lock()
        deadline = None
        while True:
            try:
                self._try_lock(fd)
                break
            except OSError as exc:
                if exc.errno not in _LOCK_BUSY:
                    self.close()
                    raise _Unavailable("lock failed") from None
                now = time.monotonic_ns()
                if deadline is None:
                    deadline = now + LOCK_WAIT_NS
                elif now >= deadline:
                    raise _Unavailable("lock timed out") from None
                time.sleep(LOCK_RETRY_S)
        try:
            # A substituted lock file must never create a second serialization domain.
            current = os.lstat(self._lock_path)
            held = os.fstat(fd)
            if stat.S_ISLNK(current.st_mode) or (current.st_dev, current.st_ino) != (held.st_dev, held.st_ino):
                self._unlock(fd)
                self.close()
                fd = None
                raise _Unavailable("lock replaced")
            yield
        finally:
            if fd is not None:
                self._unlock(fd)

    def _fresh(self, now: int) -> dict:
        return {"version": STATE_VERSION, "key": self._key_digest, "config": self._config_digest,
                "tokens": self._capacity, "probe_tokens": self._probe_capacity, "last_ns": now,
                "probe_last_ns": now, "probe_suspended_until_ns": 0,
                "counters": {"admitted": 0, "refused": 0, "exit_debt": 0}}

    def _load(self, now: int) -> dict:
        """The validated shared state (a fresh full bucket when no file exists). Anything else
        raises _Unavailable and leaves the file as it is."""
        try:
            info = os.lstat(self._state_path)
        except FileNotFoundError:
            return self._fresh(now)
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_STATE_BYTES:
            raise _Unavailable("unsafe state")
        fd = os.open(self._state_path, os.O_RDONLY | _NOFOLLOW | _BINARY)
        try:
            self._check_fd(fd, info)
            data = b""
            while len(data) <= MAX_STATE_BYTES:
                chunk = os.read(fd, MAX_STATE_BYTES + 1 - len(data))
                if not chunk:
                    break
                data += chunk
        finally:
            os.close(fd)
        if len(data) > MAX_STATE_BYTES:
            raise _Unavailable("state too large")
        try:
            value = json.loads(data, parse_constant=_reject_constant)
        except (ValueError, RecursionError):
            raise _Unavailable("malformed state") from None
        return self._validated(value)

    def _validated(self, value) -> dict:
        def whole(item, low, high):
            return type(item) is int and low <= item <= high

        if type(value) is not dict or set(value) != _STATE_KEYS:
            raise _Unavailable("malformed state")
        counters = value["counters"]
        config = value["config"]
        if (value["version"] != STATE_VERSION or type(value["version"]) is not int
                or value["key"] != self._key_digest
                or type(config) is not str or len(config) != 16 or not set(config) <= _HEX
                or not whole(value["tokens"], -_TOKENS_ABS_MAX, _TOKENS_ABS_MAX)
                or not whole(value["probe_tokens"], 0, _TOKENS_ABS_MAX)
                or not all(whole(value[k], 0, _NS_MAX)
                           for k in ("last_ns", "probe_last_ns", "probe_suspended_until_ns"))
                or type(counters) is not dict or set(counters) != _COUNTER_KEYS
                or not all(whole(counters[k], 0, COUNTER_MAX) for k in _COUNTER_KEYS)):
            raise _Unavailable("malformed state")
        if config == self._config_digest:
            if (not -self._capacity <= value["tokens"] <= self._capacity
                    or value["probe_tokens"] > self._probe_capacity):
                raise _Unavailable("malformed state")
        else:
            # Re-base to this caller's config: clamp to the new capacities, never raise the
            # balance, so a config change cannot mint a burst on top of existing debt.
            value["config"] = self._config_digest
            value["tokens"] = max(-self._capacity, min(value["tokens"], self._capacity))
            value["probe_tokens"] = min(value["probe_tokens"], self._probe_capacity)
        return value

    def _store(self, state: dict) -> None:
        data = json.dumps(state, separators=(",", ":"), sort_keys=True).encode()
        if len(data) > MAX_STATE_BYTES:
            raise _Unavailable("state too large")
        temp = self._root / f".{self._stem}.{secrets.token_hex(8)}.tmp"
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | _NOFOLLOW | _BINARY, 0o600)
        try:
            try:
                view = memoryview(data)
                while view:
                    view = view[os.write(fd, view):]
            finally:
                os.close(fd)
            os.replace(temp, self._state_path)
        except BaseException:
            try:
                os.unlink(temp)
            except OSError:
                pass
            raise

    def _refill_state(self, state: dict, now: int) -> None:
        state["tokens"], state["last_ns"] = _refill(
            state["tokens"], state["last_ns"], self._capacity, self._rate, now)
        state["probe_tokens"], state["probe_last_ns"] = _refill(
            state["probe_tokens"], state["probe_last_ns"], self._probe_capacity, self._probe_rate, now)

    # ---- the three calls ----

    def acquire(self, kind: str, now_ns: int | None = None) -> Decision:
        """Admit or refuse one request of kind ("exit", "entry", "probe" in the write scope;
        "critical", "discretionary" in the read scope). O(1); never sleeps for
        a token; never raises for a valid kind (every state failure is rate_budget_unavailable)."""
        if kind not in self._kinds:
            raise ValueError("rate budget kind must be exit, entry or probe" if self.scope == "write"
                             else "read budget kind must be critical or discretionary")
        try:
            now = self._now(now_ns)
            with self._locked():
                state = self._load(now)
                self._refill_state(state, now)
                tokens = state["tokens"]
                if kind in _ALWAYS_ADMITTED:
                    code = None
                elif kind in _RESERVE_KEPT:
                    code = None if tokens - MILLI >= self._reserve else EXHAUSTED
                elif now < state["probe_suspended_until_ns"]:
                    code = SUSPENDED
                else:
                    code = (None if state["probe_tokens"] >= MILLI and tokens - MILLI >= self._reserve
                            else EXHAUSTED)
                counters = state["counters"]
                if code is None:
                    state["tokens"] = max(tokens - MILLI, -self._capacity)
                    if kind == "probe":
                        state["probe_tokens"] -= MILLI
                    counters["admitted"] = min(counters["admitted"] + 1, COUNTER_MAX)
                    if state["tokens"] < 0:
                        counters["exit_debt"] = min(counters["exit_debt"] + 1, COUNTER_MAX)
                else:
                    counters["refused"] = min(counters["refused"] + 1, COUNTER_MAX)
                self._store(state)
        except Exception:
            self._unavailable += 1
            if kind in _ALWAYS_ADMITTED:
                self._admitted[kind] += 1
                return Decision(True, kind, UNAVAILABLE)
            self._count_refused(kind, UNAVAILABLE)
            return Decision(False, kind, UNAVAILABLE)
        if code is None:
            self._admitted[kind] += 1
            return Decision(True, kind, None)
        self._count_refused(kind, code)
        return Decision(False, kind, code)

    def _count_refused(self, kind: str, code: str) -> None:
        counts = self._refused[kind]
        counts[code] = counts.get(code, 0) + 1

    def note_http(self, status, now_ns: int | None = None) -> None:
        """A 429 suspends probes in every process for PROBE_SUSPEND_S (never shortens a longer
        suspension). Any other status is a no-op and takes no lock. Never raises."""
        if type(status) is not int or status != 429:
            return
        try:
            now = self._now(now_ns)
            with self._locked():
                state = self._load(now)
                state["probe_suspended_until_ns"] = max(state["probe_suspended_until_ns"],
                                                        min(now + PROBE_SUSPEND_NS, _NS_MAX))
                self._store(state)
            self._suspensions += 1
        except Exception:
            self._note_failed += 1

    def snapshot(self) -> dict:
        """Bounded status: whole tokens (None when unreadable), the reserve, the probe suspension
        left, and this process's counts. No key id and no path. Never writes, never raises."""
        view = {"tokens": None, "probe_tokens": None, "exit_reserve": self.config.exit_reserve,
                "probe_suspended_for_s": 0, "admitted": dict(self._admitted),
                "refused": {kind: dict(codes) for kind, codes in self._refused.items()},
                "unavailable": self._unavailable, "note_failed": self._note_failed,
                "suspensions": self._suspensions}
        try:
            now = self._now(None)
            with self._locked():
                state = self._load(now)
            self._refill_state(state, now)
            view["tokens"] = state["tokens"] // MILLI
            view["probe_tokens"] = state["probe_tokens"] // MILLI
            left = state["probe_suspended_until_ns"] - now
            view["probe_suspended_for_s"] = -(-left // 1_000_000_000) if left > 0 else 0
        except Exception:
            pass
        return view


def _reject_constant(name):
    raise ValueError("non-finite number")
