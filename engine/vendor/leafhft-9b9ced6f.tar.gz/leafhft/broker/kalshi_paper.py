"""PaperKalshiClient: the KalshiBook client surface (place_ioc_buy, market, balance, positions,
reconcile, cancel_owned, async context manager), filled on paper instead of against the venue.

A buy fills only once its limit reaches the resting ask on the bought side (derived from the
latest observed Quote, YES from ask_i, NO from 100 minus bid_i); the fill quantity never exceeds
the currently displayed depth on that side. Every filled contract is charged at the caller's own
limit price, cents times count, the same accounting KalshiBook already applies to a live IOC fill.

The opt-in arrival model instead uses receive-time quote history and resting prices,
with versioned fees and fractional depth. The host supplies the decision or landing
time and observes available quotes before requesting the synchronous result.
"""
from __future__ import annotations

import asyncio
import json
import time
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_DOWN, ROUND_FLOOR, ROUND_HALF_UP
from types import MappingProxyType
from typing import Any

from ..types import PRICE_UNIT, SIZE_UNIT, Quote, buy_cents_ceil, sell_cents_floor
from ..sim.fuzz import PaperFuzzer, require_paper_environment
from ..venue_facts import PER_CONTRACT_CEIL, fee_cents as venue_fee_cents

MAX_FILLS = 10_000
STALE_QUOTE_S = 60.0

# Cents per contract, rounded up first, from venue_facts per_contract_ceil at quantity 1, pinned at
# the schedule's 0.07 rate. Fractional orders round the resulting
# fee up once more to whole cents per order; cost rounds half up per fill level.
FEE_SCHEDULES = MappingProxyType({
    "kalshi-2026-07": MappingProxyType({
        p: venue_fee_cents(PER_CONTRACT_CEIL, p, 1, rate=Decimal("0.07")) for p in range(1, 100)
    })
})


class PaperKalshiClient:
    def __init__(self, real: Any | None, cash_cents: int, slippage_cents: int = 0,
                max_quotes: int = 512, *, fill_model: str = "decision_time",
                latency_ms: int = 0, max_quote_age_ms: int = 5000,
                fee_schedule: str = "kalshi-2026-07", fuzzer: PaperFuzzer | None = None) -> None:
        if fuzzer is not None:
            if type(fuzzer) is not PaperFuzzer:
                raise ValueError("expected PaperFuzzer")
            require_paper_environment(fuzzer.mode)
            if real is not None:
                raise ValueError("fuzzed paper clients cannot wrap a live client")
        self.fuzzer = fuzzer
        self.fuzz_manifest = fuzzer.manifest if fuzzer is not None else None
        self._fuzz_results: dict[str, dict[str, Any]] = {}
        if type(cash_cents) is not int or cash_cents < 0:
            raise ValueError("cash_cents must be a nonnegative int")
        if type(slippage_cents) is not int or slippage_cents < 0:
            raise ValueError("slippage_cents must be a nonnegative int")
        if type(max_quotes) is not int or max_quotes < 1:
            raise ValueError("max_quotes must be a positive int")
        if fill_model not in ("decision_time", "arrival"):
            raise ValueError("unknown fill_model")
        for name, value in (("latency_ms", latency_ms), ("max_quote_age_ms", max_quote_age_ms)):
            if type(value) is not int or value < 0:
                raise ValueError(f"{name} must be a nonnegative int")
        if fee_schedule not in FEE_SCHEDULES:
            raise ValueError("unknown fee_schedule")
        self.fill_model = fill_model
        self.latency_ms = latency_ms
        self.max_quote_age_ms = max_quote_age_ms
        self.fee_schedule = fee_schedule
        self._now_ns: int | None = None
        self._history: dict[str, list[Quote]] = {}
        self._states: dict[str, list[tuple[int, bool, bool]]] = {}
        self._consumed: dict[tuple[str, int, bool], Decimal] = {}
        self._inventory: dict[str, Decimal] = {}  # signed YES contracts
        self._results: dict[str, dict[str, Any]] = {}
        self.real = real
        self.cash_cents = cash_cents
        self.slippage_cents = slippage_cents
        self.max_quotes = max_quotes
        self._quotes: dict[str, tuple[Quote, float]] = {}  # ticker -> (quote, observed monotonic)
        self.fills: list[dict[str, Any]] = []
        self.stats = {"attempts": 0, "fills": 0, "partial_fills": 0, "no_quote": 0,
                      "stale_quote": 0, "price_below_ask": 0}
        if fill_model == "arrival":
            self.stats["unknown"] = 0

    def observe(self, quote: Quote) -> None:
        """Records the latest Quote for its ticker, bounded to max_quotes tickers total."""
        if quote.symbol not in self._quotes and len(self._quotes) >= self.max_quotes:
            oldest = min(self._quotes, key=lambda t: self._quotes[t][1])
            del self._quotes[oldest]
        self._quotes[quote.symbol] = (quote, time.monotonic())
        if self.fill_model == "arrival":
            self._history.setdefault(quote.symbol, []).append(quote)

    def observe_quote(self, quote: Quote) -> None:
        self.observe(quote)

    def set_now(self, now_ns: int) -> None:
        """Set the host's decision clock, in the same time domain as ts_recv_ns.

        Hosts that land an already delayed intent pass its original decision_ns
        or explicit arrival_ns to place_ioc_buy, avoiding a second latency delay.
        Observing quotes does not move this clock.
        """
        if type(now_ns) is not int or now_ns < 0:
            raise ValueError("now_ns must be a nonnegative int")
        if self._now_ns is not None and now_ns < self._now_ns:
            raise ValueError("clock cannot move backwards")
        self._now_ns = now_ns

    def advance(self, now_ns: int) -> None:
        self.set_now(now_ns)

    def set_market_state(self, ticker: str, *, paused: bool = False,
                         feed_gap: bool = False, now_ns: int | None = None) -> None:
        """Record a complete venue/feed state snapshot for causal as-of lookup."""
        stamp = self._now_ns if now_ns is None else now_ns
        if type(stamp) is not int or stamp < 0:
            raise ValueError("set the host clock or supply now_ns")
        self._states.setdefault(ticker, []).append((stamp, bool(paused), bool(feed_gap)))

    def _as_of(self, ticker: str, stamp: int) -> Quote | None:
        # Receive time is when this model could know a quote. Exchange time may
        # precede delivery, so using it would allow unavailable data into a fill.
        return max((q for q in self._history.get(ticker, ()) if q.ts_recv_ns <= stamp),
                   key=lambda q: (q.ts_recv_ns, q.seq), default=None)

    def _arrival_buy(self, ticker: str, side_yes: bool, price_cents: int,
                     count: Any, client_id: str, decision_ns: int | None,
                     arrival_ns: int | None, fuzz_delay_ms: int = 0) -> dict[str, Any]:
        if client_id in self._results:
            return dict(self._results[client_id])
        decision = self._now_ns if decision_ns is None else decision_ns
        if arrival_ns is not None and (type(arrival_ns) is not int or arrival_ns < 0):
            raise ValueError("arrival_ns must be a nonnegative int")
        if decision_ns is None and arrival_ns is not None:
            decision = arrival_ns - (self.latency_ms + fuzz_delay_ms) * 1_000_000
        if type(decision) is not int or decision < 0:
            raise ValueError("arrival mode requires a host clock or decision_ns")
        arrival = decision + (self.latency_ms + fuzz_delay_ms) * 1_000_000
        if arrival_ns is not None and arrival_ns != arrival:
            raise ValueError("arrival_ns must equal decision_ns plus latency")
        try:
            requested = Decimal(str(count))
            if (isinstance(count, bool) or not requested.is_finite() or
                    not 0 < requested <= 100_000 or
                    requested != requested.quantize(Decimal("0.01"))):
                raise ValueError("invalid count")
        except (InvalidOperation, ValueError) as exc:
            raise ValueError("count must be positive contracts in hundredths") from exc
        if type(price_cents) is not int or not 1 <= price_cents <= 99:
            raise ValueError("price_cents out of bounds")
        self.stats["attempts"] += 1
        proposal_quote = self._as_of(ticker, decision)
        quote = self._as_of(ticker, arrival)
        state = max((s for s in self._states.get(ticker, ()) if s[0] <= arrival),
                    key=lambda s: s[0], default=(0, False, False))
        fill = Decimal("0.00")
        price = None
        outcome = "zero"
        reduce_only = client_id.startswith("lx-")
        if state[1] or state[2]:
            outcome = "unknown"
            self.stats["unknown"] += 1
        elif quote is None:
            self.stats["no_quote"] += 1
            self.stats["unknown"] += 1
            outcome = "unknown"
        elif arrival - quote.ts_recv_ns > self.max_quote_age_ms * 1_000_000:
            self.stats["stale_quote"] += 1
            outcome = "stale"
        else:
            price = (int((Decimal(quote.ask_i) * 100 / PRICE_UNIT).to_integral_value(rounding=ROUND_CEILING)) if side_yes else
                     100 - int((Decimal(quote.bid_i) * 100 / PRICE_UNIT).to_integral_value(rounding=ROUND_FLOOR)))
            if not 1 <= price <= 99 or price_cents < price + self.slippage_cents:
                self.stats["price_below_ask"] += 1
            else:
                key = (ticker, quote.seq, side_yes)
                used = self._consumed.get(key, Decimal(0))
                displayed = Decimal(quote.ask_size_i if side_yes else quote.bid_size_i) / SIZE_UNIT
                available = max(Decimal(0), displayed - used)
                if reduce_only:
                    held = self._inventory.get(ticker, Decimal(0))
                    available = min(available, max(Decimal(0), -held if side_yes else held))
                fill = min(requested, available).quantize(Decimal("0.01"), rounding=ROUND_DOWN)
                if fill:
                    self._consumed[key] = used + fill
                    self._inventory[ticker] = self._inventory.get(ticker, Decimal(0)) + (
                        fill if side_yes else -fill)
                    outcome = "filled" if fill == requested else "partial"
                    self.stats["fills"] += 1
                    self.stats["partial_fills"] += int(fill < requested)
        fee = (int((fill * FEE_SCHEDULES[self.fee_schedule][price]).to_integral_value(
            rounding=ROUND_CEILING)) if fill else 0)
        cost = int((fill * price).to_integral_value(rounding=ROUND_HALF_UP)) if fill else 0
        reply = {**self._reply(client_id, fill), "outcome": outcome,
                 "filled_count": fill, "price": price, "fee_cents": fee,
                 "venue_cost_cents": cost, "venue_fee_cents": fee,
                 "arrival_ns": arrival, "quote_seq_used": quote.seq if quote else None,
                 "decision_ns": decision, "requested_count": requested,
                 "input_quote_seq": proposal_quote.seq if proposal_quote else None,
                 "input_quote_ts_ns": proposal_quote.ts_recv_ns if proposal_quote else None,
                 "side_yes": side_yes, "limit_price_cents": price_cents,
                 "remaining_count": Decimal("0.00"),
                 "canceled_count": requested - fill if outcome != "unknown" else None,
                 "reduce_only": reduce_only, "fee_schedule": self.fee_schedule}
        if outcome == "unknown":
            reply["status"] = "unknown"
        if fill:
            if len(self.fills) >= MAX_FILLS:
                self.fills.pop(0)
            self.fills.append({"ticker": ticker, "side_yes": side_yes, "price_cents": price,
                               "count": fill, "client_id": client_id})
        self._results[client_id] = dict(reply)
        return reply

    def _reply(self, client_id: str, fill_count: int) -> dict[str, Any]:
        return {"order_id": f"paper-{client_id}", "fill_count": fill_count,
                "status": "executed" if fill_count else "canceled", "paper": True}

    async def place_ioc_buy(self, ticker: str, side_yes: bool, price_cents: int, count: int,
                            client_id: str, *, decision_ns: int | None = None,
                            arrival_ns: int | None = None) -> dict[str, Any]:
        if self.fuzzer is None:
            return await self._place_ioc_buy(ticker, side_yes, price_cents, count, client_id,
                                             decision_ns=decision_ns, arrival_ns=arrival_ns)
        require_paper_environment(self.fuzzer.mode)
        if client_id in self._fuzz_results:
            return dict(self._fuzz_results[client_id])
        try:
            quantity = Decimal(str(count))
            units = quantity * (100 if self.fill_model == "arrival" else 1)
            if (isinstance(count, bool) or not units.is_finite() or
                    not 0 < units <= 10_000_000 or units != int(units)):
                raise ValueError("invalid fuzzed count")
        except InvalidOperation as exc:
            raise ValueError("invalid fuzzed count") from exc
        if not client_id or type(side_yes) is not bool or type(price_cents) is not int or not 1 <= price_cents <= 99:
            raise ValueError("invalid fuzzed order")
        identity = json.dumps([client_id, ticker, side_yes, price_cents], separators=(",", ":"))
        draw = self.fuzzer.draw(identity, int(units))
        if draw.forced_no_fill or draw.size == 0:
            self.stats["attempts"] += 1
            result = {**self._reply(client_id, 0), "outcome": "zero"}
        else:
            adjusted = Decimal(draw.size) / 100 if self.fill_model == "arrival" else draw.size
            if self.fill_model != "arrival" and draw.delay_ms:
                await asyncio.sleep(draw.delay_ms / 1000)
            require_paper_environment(self.fuzzer.mode)
            if client_id in self._fuzz_results:
                return dict(self._fuzz_results[client_id])
            result = await self._place_ioc_buy(ticker, side_yes, price_cents, adjusted, client_id,
                decision_ns=decision_ns,
                arrival_ns=None if arrival_ns is None else arrival_ns + draw.delay_ms * 1_000_000,
                fuzz_delay_ms=draw.delay_ms)
        result["fuzz"] = draw.audit()
        self._fuzz_results[client_id] = dict(result)
        return result

    async def _place_ioc_buy(self, ticker: str, side_yes: bool, price_cents: int, count: int,
                             client_id: str, *, decision_ns: int | None = None,
                             arrival_ns: int | None = None, fuzz_delay_ms: int = 0) -> dict[str, Any]:
        if self.fill_model == "arrival":
            return self._arrival_buy(ticker, side_yes, price_cents, count, client_id,
                                     decision_ns, arrival_ns, fuzz_delay_ms)
        self.stats["attempts"] += 1
        entry = self._quotes.get(ticker)
        if entry is None:
            self.stats["no_quote"] += 1
            return self._reply(client_id, 0)
        quote, observed_mono = entry
        if time.monotonic() - observed_mono > STALE_QUOTE_S:
            self.stats["stale_quote"] += 1
            return self._reply(client_id, 0)
        if type(price_cents) is not int or not 1 <= price_cents <= 99 or type(count) is not int or count < 1:
            self.stats["price_below_ask"] += 1
            return self._reply(client_id, 0)
        if side_yes:
            ask_cents = buy_cents_ceil(quote.ask_i)
            depth = quote.ask_size_i // SIZE_UNIT
        else:
            ask_cents = 100 - sell_cents_floor(quote.bid_i)
            depth = quote.bid_size_i // SIZE_UNIT
        if price_cents < ask_cents + self.slippage_cents:
            self.stats["price_below_ask"] += 1
            return self._reply(client_id, 0)
        fill = min(count, depth)
        if fill > 0:
            self.stats["fills"] += 1
            if fill < count:
                self.stats["partial_fills"] += 1
            if len(self.fills) >= MAX_FILLS:
                self.fills.pop(0)
            self.fills.append({"ticker": ticker, "side_yes": side_yes, "price_cents": price_cents,
                               "count": fill, "client_id": client_id})
        return self._reply(client_id, fill)

    async def market(self, ticker: str) -> dict[str, Any]:
        if self.real is None:
            raise RuntimeError("paper client has no market source")
        return await self.real.market(ticker)

    async def balance(self) -> int:
        return self.cash_cents

    async def balance_cents(self) -> int:
        return self.cash_cents

    async def positions(self) -> list:
        return []

    async def reconcile(self) -> list:
        return []

    async def cancel_owned(self) -> dict:
        return {}

    async def __aenter__(self) -> "PaperKalshiClient":
        return self

    async def __aexit__(self, *exc) -> None:
        return None
