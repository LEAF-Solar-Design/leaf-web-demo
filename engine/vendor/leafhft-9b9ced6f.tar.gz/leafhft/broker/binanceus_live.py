"""Binance.US live order adapter (REST, HMAC-SHA256 signed). UNEXERCISED against the venue:
no credentials existed on 2026-09-05, so only request construction, signing, authorization
checks and response parsing are covered by tests.

Authorization boundary (astra round 2 C10): the client cannot be constructed without a
LiveAuthorization from live_gate.assert_armed(), and place() re-checks expiry and the authorized
per-order notional on every call. Credentials alone place nothing.

Order-state discipline: ambiguous mutations raise OrderStateUnknown carrying the client id.
An fsynced append-only journal preserves ownership across restarts; reconcile() settles fills
before declaring an order gone. Shutdown exposes every cancellation it could not confirm.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import os
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import aiohttp
import orjson

from ..feeds.binanceus import binance_symbol
from ..types import PRICE_UNIT, SIZE_UNIT, Intent, MalformedInput, Side, TimeInForce, notional_q
from .live_gate import LiveAuthorization, LiveGateClosed, OrderRefused

REST_URL = "https://api.binance.us"
TIMEOUT_S = 5.0
RECV_WINDOW_MS = 5000
_PUBLIC_PATHS = frozenset({"/api/v3/exchangeInfo"})
MAX_OWNED = 10_000
MAX_JOURNAL_BYTES = 4 * 1024 * 1024
ROTATE_BYTES = 3 * 1024 * 1024
MAX_ROTATIONS = 256
TERMINAL = {"FILLED", "CANCELED", "GONE", "REJECTED"}
STATES = TERMINAL | {"SENT", "ACKED", "UNKNOWN", "PARTIAL"}
VENUE_STATES = {
    "NEW": "ACKED", "PENDING_NEW": "ACKED", "PARTIALLY_FILLED": "PARTIAL",
    "FILLED": "FILLED", "CANCELED": "CANCELED", "PENDING_CANCEL": "UNKNOWN",
    "REJECTED": "GONE", "EXPIRED": "CANCELED", "EXPIRED_IN_MATCH": "CANCELED",
}


class VenueError(RuntimeError):
    def __init__(self, http: int, code: int | None, msg: str) -> None:
        self.http, self.code, self.msg = http, code, msg
        super().__init__(f"binanceus http {http} code {code}: {msg}")

    @property
    def kind(self) -> str:
        """Classify a -2010 NEW_ORDER_REJECTED by its venue message.

        An unrecognized or empty message fails toward "balance", the stricter path.
        """
        if self.code != -2010:
            return "other"
        low = self.msg.lower() if isinstance(self.msg, str) else ""
        return "cross" if "immediately match" in low else "balance"


def _decimal(value: Any, *, positive: bool = False) -> Decimal:
    """Bound venue numbers before doing any Decimal arithmetic."""
    if not isinstance(value, str) or not 0 < len(value) <= 40:
        raise ValueError("malformed decimal")
    try:
        d = Decimal(value)
    except InvalidOperation as e:
        raise ValueError("malformed decimal") from e
    if not d.is_finite() or d < 0 or (positive and d == 0):
        raise ValueError("malformed decimal")
    if d.as_tuple().exponent < -8 or d.adjusted() > 12:
        raise ValueError("decimal out of bounds")
    return d


def _quantity_i(value: Any) -> int:
    return int(_decimal(value) * SIZE_UNIT)


def _places(d: Decimal) -> int:
    return max(0, -d.normalize().as_tuple().exponent)


class OrderStateUnknown(RuntimeError):
    def __init__(self, client_id: str, why: str) -> None:
        super().__init__(f"order {client_id} state unknown: {why}")
        self.client_id = client_id


def sign(secret: bytes, query: str) -> str:
    return hmac.new(secret, query.encode(), hashlib.sha256).hexdigest()


def dec_str(x_i: int, unit: int, places: int) -> str:
    """Fixed-point int -> decimal string with `places` decimals, truncated (never rounded up)."""
    d = Decimal(x_i) / Decimal(unit)
    q = Decimal(1).scaleb(-places)
    return str(d.quantize(q, rounding="ROUND_DOWN"))


def order_params(symbol: str, intent: Intent, client_id: str, ts_ms: int, *, filters: dict[str, Any] | None = None) -> dict[str, str]:
    if not isinstance(client_id, str) or not client_id or len(client_id) > 36:
        raise MalformedInput("client id")
    # Standalone request construction stays exact; live submissions always supply filters.
    qty_places = _places(filters["step_size"] if filters else Decimal(intent.size_i) / SIZE_UNIT)
    px_places = _places(filters["tick_size"] if filters else Decimal(intent.price_i) / PRICE_UNIT)
    p: dict[str, str] = {
        "symbol": binance_symbol(symbol),
        "side": "BUY" if intent.side is Side.BUY else "SELL",
        "quantity": dec_str(intent.size_i, SIZE_UNIT, qty_places),
        "newClientOrderId": client_id,
        "newOrderRespType": "RESULT",
        "recvWindow": str(RECV_WINDOW_MS),
        "timestamp": str(ts_ms),
    }
    if intent.is_market:
        p["type"] = "MARKET"
    elif intent.tif is TimeInForce.POST_ONLY:
        p["type"] = "LIMIT_MAKER"
        p["price"] = dec_str(intent.price_i, PRICE_UNIT, px_places)
    else:
        p["type"] = "LIMIT"
        p["timeInForce"] = "IOC" if intent.tif is TimeInForce.IOC else "GTC"
        p["price"] = dec_str(intent.price_i, PRICE_UNIT, px_places)
    return p


def signed_query(params: dict[str, str], secret: bytes) -> str:
    qs = urlencode(params)
    return qs + "&signature=" + sign(secret, qs)


class BinanceUSLive:
    """Thin signed client. Holds the secret in a bytes object that is never formatted anywhere."""

    def __init__(self, auth: LiveAuthorization, key: str | None = None, secret: str | None = None, base_url: str = REST_URL, *, journal_dir: str | Path) -> None:
        if not isinstance(auth, LiveAuthorization):
            raise LiveGateClosed("live client requires a LiveAuthorization from assert_armed()")
        if auth.venue != "binanceus":
            raise LiveGateClosed("authorization is for another venue")
        auth.check(time.time_ns())
        key = key if key is not None else os.environ.get("LEAFHFT_BINANCEUS_KEY", "")
        secret = secret if secret is not None else os.environ.get("LEAFHFT_BINANCEUS_SECRET", "")
        if len(key) < 16 or len(secret) < 16:
            raise PermissionError("binanceus credentials missing")
        self.auth = auth
        self.symbol = auth.symbol
        self.position_i: int = 0
        self._key = key
        self._secret = secret.encode()
        self.base_url = base_url
        self._session: aiohttp.ClientSession | None = None
        self._owned: dict[str, str] = {}  # client id -> last known state
        self.unresolved: list[str] = []
        self._records: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()
        self._journal_failed = False
        self.filters: dict[str, Any] | None = None
        self.shutdown_result: dict[str, Any] | None = None
        self.journal_path = Path(journal_dir) / "live-orders.jsonl"
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)
        self.load_journal()

    def _refresh_unresolved(self) -> None:
        self.unresolved = [cid for cid, state in self._owned.items() if state in {"SENT", "UNKNOWN"}]

    def load_journal(self) -> None:
        new_path = self.journal_path.with_name(self.journal_path.name + ".new")
        if new_path.exists():
            if self.journal_path.exists():
                new_path.unlink()  # snapshot never promoted; the live file is complete
            else:
                new_path.rename(self.journal_path)  # crashed between rotation steps (b) and (c)
        records: dict[str, dict[str, Any]] = {}
        try:
            with self.journal_path.open("rb") as journal:
                data = journal.read(MAX_JOURNAL_BYTES + 1)
        except FileNotFoundError:
            data = b""
        if len(data) > MAX_JOURNAL_BYTES:
            raise RuntimeError("live order journal exceeds 4 MB")
        if data and not data.endswith(b"\n"):
            raise RuntimeError("live order journal has an incomplete row")
        try:
            for line in data.splitlines():
                row = orjson.loads(line)
                cid, state, intent = row["client_id"], row["state"], row["intent"]
                if not isinstance(cid, str) or not 0 < len(cid) <= 36 or state not in STATES:
                    raise ValueError("invalid identity or state")
                Intent(Side(intent["side"]), intent["price_i"], intent["size_i"], TimeInForce(intent["tif"]))
                if type(row["ts_ns"]) is not int or row["ts_ns"] < 0:
                    raise ValueError("invalid timestamp")
                if type(row["ref_price_i"]) is not int or row["ref_price_i"] < 0:
                    raise ValueError("invalid reference price")
                oid = row["venue_order_id"]
                if oid is not None and (type(oid) is not int or oid < 0):
                    raise ValueError("invalid order id")
                if not isinstance(row["note"], str) or row.get("symbol", self.symbol) != self.symbol:
                    raise ValueError("invalid note or symbol")
                filled = row.get("executed_qty_i", 0)
                if type(filled) is not int or not 0 <= filled <= intent["size_i"]:
                    raise ValueError("invalid executed quantity")
                records[cid] = row
                if len(records) > MAX_OWNED:
                    raise RuntimeError("owned order table exceeds MAX_OWNED")
        except (ValueError, TypeError, KeyError) as e:
            raise RuntimeError("malformed live order journal") from e
        self._records = records
        self._owned = {cid: row["state"] for cid, row in records.items()}
        self._refresh_unresolved()

    def _rotate(self) -> None:
        """Snapshot every still-open record, retire the full journal, prune terminal state."""
        n = 1
        while self.journal_path.with_name(f"live-orders.{n:03d}.jsonl").exists():
            n += 1
        if n > MAX_ROTATIONS:
            raise RuntimeError("live order journal rotation limit")
        new_path = self.journal_path.with_name(self.journal_path.name + ".new")
        ts_ns = time.time_ns()
        with new_path.open("wb") as snapshot:
            for row in self._records.values():
                state = row.get("state")  # a record mid-place() has no state yet: not journaled, skip
                if state is None or state in TERMINAL:
                    continue
                snapshot.write(orjson.dumps(dict(row, ts_ns=ts_ns, note="compaction snapshot")) + b"\n")
            snapshot.flush()
            os.fsync(snapshot.fileno())
        self.journal_path.rename(self.journal_path.with_name(f"live-orders.{n:03d}.jsonl"))
        new_path.rename(self.journal_path)
        self._records = {cid: row for cid, row in self._records.items() if row.get("state") not in TERMINAL}
        self._owned = {cid: state for cid, state in self._owned.items() if state not in TERMINAL}

    def _transition(self, client_id: str, state: str, note: str, **updates: Any) -> None:
        row = dict(self._records[client_id])
        row.update(updates, ts_ns=time.time_ns(), client_id=client_id, state=state, note=note)
        payload = orjson.dumps(row) + b"\n"
        try:
            current_size = self.journal_path.stat().st_size
        except FileNotFoundError:
            current_size = 0
        if current_size + len(payload) >= ROTATE_BYTES:
            self._rotate()
        try:
            with self.journal_path.open("ab") as journal:
                journal.write(payload)
                journal.flush()
                os.fsync(journal.fileno())
        except OSError:
            self._journal_failed = True
            self._owned[client_id] = "UNKNOWN"
            self._refresh_unresolved()
            raise
        self._records[client_id] = row
        self._owned[client_id] = state
        self._refresh_unresolved()

    @staticmethod
    def _failure_note(action: str, error: BaseException) -> str:
        if isinstance(error, VenueError):
            note = f"{action} failed: http={error.http} code={error.code}"
            if error.code == -2010:
                note += f" kind={error.kind}"
            return note
        return f"{action} failed: {type(error).__name__}"

    def __repr__(self) -> str:  # never leak
        return f"BinanceUSLive({self.symbol}, nonce={self.auth.nonce})"

    async def __aenter__(self) -> "BinanceUSLive":
        self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=TIMEOUT_S), headers={"X-MBX-APIKEY": self._key})
        return self

    async def __aexit__(self, *exc) -> None:
        try:
            self.shutdown_result = await self.cancel_owned()
        finally:
            if self._session is not None:
                await self._session.close()
                self._session = None

    def _validate_reply(self, path: str, reply: Any, params: dict[str, str]) -> Any:
        try:
            if path == "/api/v3/order":
                if not isinstance(reply, dict) or type(reply.get("orderId")) is not int or reply["orderId"] < 0:
                    raise ValueError("order id")
                if reply.get("status") not in VENUE_STATES:
                    raise ValueError("order status")
                _quantity_i(reply["executedQty"])
                cid = params.get("newClientOrderId", params.get("origClientOrderId"))
                reply_cid = reply.get("origClientOrderId", reply.get("clientOrderId", cid))
                if reply_cid != cid:
                    raise ValueError("client id mismatch")
                if "symbol" in reply and reply["symbol"] != binance_symbol(self.symbol):
                    raise ValueError("symbol mismatch")
            elif path in {"/api/v3/myTrades", "/api/v3/openOrders"}:
                if not isinstance(reply, list) or len(reply) > 1000:
                    raise ValueError("list")
                for item in reply:
                    if not isinstance(item, dict):
                        raise ValueError("item")
                    if path.endswith("myTrades"):
                        _decimal(item["qty"], positive=True)
                        if type(item.get("orderId")) is not int and not isinstance(item.get("clientOrderId"), str):
                            raise ValueError("trade identity")
                        if "orderId" in item and (type(item["orderId"]) is not int or item["orderId"] < 0):
                            raise ValueError("trade order id")
                        if "clientOrderId" in item and (not isinstance(item["clientOrderId"], str) or not 0 < len(item["clientOrderId"]) <= 36):
                            raise ValueError("trade client id")
                        if "symbol" in item and item["symbol"] != binance_symbol(self.symbol):
                            raise ValueError("trade symbol")
                    else:
                        self._validate_reply("/api/v3/order", item, {"origClientOrderId": item.get("clientOrderId")})
            elif path == "/api/v3/exchangeInfo":
                if not isinstance(reply, dict) or not isinstance(reply.get("symbols"), list):
                    raise ValueError("symbols")
            elif path == "/api/v3/account":
                if not isinstance(reply, dict) or not isinstance(reply.get("balances"), list):
                    raise ValueError("balances")
            elif not isinstance(reply, dict):
                raise ValueError("object")
        except (ValueError, TypeError, KeyError, InvalidOperation) as e:
            raise VenueError(200, None, "malformed") from e
        return reply

    async def _execute(self, method: str, path: str, url: str, params: dict[str, str], *, mutating: bool, cid: str) -> Any:
        if self._session is None:
            raise RuntimeError("client not entered")
        http = 0
        try:
            async with self._session.request(method, url) as resp:
                http = resp.status
                body = bytearray()
                async for chunk in resp.content.iter_chunked(65536):
                    body.extend(chunk)
                    if len(body) > 1 << 20:
                        raise VenueError(http, None, "malformed")
                try:
                    reply = orjson.loads(body)
                except ValueError as e:
                    raise VenueError(http, None, "malformed") from e
                if http != 200:
                    if 400 <= http < 500 and isinstance(reply, dict) and type(reply.get("code")) is int and isinstance(reply.get("msg"), str):
                        raise VenueError(http, reply["code"], reply["msg"])
                    raise VenueError(http, None, "malformed")
                return self._validate_reply(path, reply, params)
        except VenueError as e:
            if mutating and not (400 <= e.http < 500 and e.code is not None):
                raise OrderStateUnknown(cid, f"http {e.http}: malformed or ambiguous reply") from e
            raise
        except (asyncio.TimeoutError, aiohttp.ClientError, ConnectionError) as e:
            if mutating:
                raise OrderStateUnknown(cid, type(e).__name__) from e
            raise VenueError(http, None, "malformed") from e

    async def _request(self, method: str, path: str, params: dict[str, str], *, signed: bool) -> Any:
        params = dict(params)
        if signed:
            params.setdefault("timestamp", str(int(time.time() * 1000)))
            params.setdefault("recvWindow", str(RECV_WINDOW_MS))
            url = f"{self.base_url}{path}?{signed_query(params, self._secret)}"
            mutating = method in {"POST", "DELETE"}
            cid = params.get("newClientOrderId", params.get("origClientOrderId", ""))
        else:
            url = f"{self.base_url}{path}?{urlencode(params)}"
            mutating = False
            cid = ""
        return await self._execute(method, path, url, params, mutating=mutating, cid=cid)

    async def _public(self, method: str, path: str, params: dict[str, str]) -> Any:
        """Unsigned request: no timestamp, no recvWindow, no signature. Public endpoints only."""
        return await self._request(method, path, params, signed=False)

    async def _signed(self, method: str, path: str, params: dict[str, str]) -> Any:
        # exchangeInfo is the one public endpoint the driver calls; every fake transport in the
        # non-owned live-driver tests patches only _signed, so the public routing must live here.
        if path in _PUBLIC_PATHS:
            return await self._public(method, path, params)
        return await self._request(method, path, params, signed=True)

    async def load_filters(self) -> None:
        async with self._lock:
            if self.filters is not None:
                return
            p = {"symbol": binance_symbol(self.symbol)}
            r = self._validate_reply("/api/v3/exchangeInfo", await self._signed("GET", "/api/v3/exchangeInfo", p), p)
            try:
                if len(r["symbols"]) > 1000:
                    raise ValueError("too many symbols")
                matches = [s for s in r["symbols"] if isinstance(s, dict) and s.get("symbol") == p["symbol"]]
                if len(matches) != 1:
                    raise ValueError("symbol missing or duplicated")
                symbol = matches[0]
                if not isinstance(symbol["status"], str) or not 0 < len(symbol["status"]) <= 32:
                    raise ValueError("status")
                if not isinstance(symbol["filters"], list) or len(symbol["filters"]) > 100:
                    raise ValueError("filters")
                filters = {f["filterType"]: f for f in symbol["filters"]}
                if len(filters) != len(symbol["filters"]):
                    raise ValueError("duplicate filters")
                notionals = [_decimal(filters[k]["minNotional"], positive=True) for k in ("MIN_NOTIONAL", "NOTIONAL") if k in filters]
                self.filters = {
                    "tick_size": _decimal(filters["PRICE_FILTER"]["tickSize"], positive=True),
                    "step_size": _decimal(filters["LOT_SIZE"]["stepSize"], positive=True),
                    "min_notional": max(notionals), "status": symbol["status"],
                }
            except (ValueError, TypeError, KeyError, InvalidOperation) as e:
                raise VenueError(200, None, "malformed filters") from e

    def _params(self, intent: Intent, client_id: str, ref_price_i: int) -> dict[str, str]:
        if self.filters is None:
            raise VenueError(0, None, "filters not loaded")
        if self.filters["status"] != "TRADING":
            raise VenueError(0, None, "symbol is not TRADING")
        quantity = Decimal(intent.size_i) / SIZE_UNIT
        price = Decimal(intent.price_i or ref_price_i) / PRICE_UNIT
        if quantity % self.filters["step_size"]:
            raise VenueError(0, None, "quantity is not a multiple of step_size")
        if not intent.is_market and price % self.filters["tick_size"]:
            raise VenueError(0, None, "price is not a multiple of tick_size")
        p = order_params(self.symbol, intent, client_id, int(time.time() * 1000), filters=self.filters)
        if Decimal(p["quantity"]) * Decimal(p.get("price", str(price))) < self.filters["min_notional"]:
            raise VenueError(0, None, "notional below min_notional")
        return p

    def _record_reply(self, client_id: str, reply: Any) -> dict[str, Any]:
        r = self._validate_reply("/api/v3/order", reply, {"origClientOrderId": client_id})
        filled = _quantity_i(r["executedQty"])
        previous = self._records[client_id]
        if filled > previous["intent"]["size_i"] or filled < previous.get("executed_qty_i", 0):
            raise VenueError(200, None, "malformed")
        if previous["venue_order_id"] is not None and previous["venue_order_id"] != r["orderId"]:
            raise VenueError(200, None, "malformed")
        if r["status"] == "FILLED" and filled != previous["intent"]["size_i"]:
            raise VenueError(200, None, "malformed")
        if r["status"] == "PARTIALLY_FILLED" and not 0 < filled < previous["intent"]["size_i"]:
            raise VenueError(200, None, "malformed")
        if r["status"] in {"NEW", "PENDING_NEW", "REJECTED"} and filled:
            raise VenueError(200, None, "malformed")
        state = VENUE_STATES[r["status"]]
        if state == previous.get("state") and previous["venue_order_id"] == r["orderId"] and filled == previous.get("executed_qty_i", 0):
            return r  # no-op venue reply: nothing changed, nothing to journal
        self._transition(client_id, state, "venue reply", venue_order_id=r["orderId"], executed_qty_i=filled)
        return r

    async def place(self, intent: Intent, client_id: str, ref_price_i: int) -> dict[str, Any]:
        async with self._lock:
            open_notional_q = sum(
                notional_q(
                    self._records[cid]["intent"]["price_i"] or self._records[cid]["ref_price_i"],
                    self._records[cid]["intent"]["size_i"],
                )
                for cid, state in self._owned.items() if state not in TERMINAL
            )
            try:
                self.auth.check_order(intent, ref_price_i, time.time_ns(),
                                      pos_i=self.position_i, open_notional_q=open_notional_q)
            except OrderRefused as e:
                # A per-order rule refusal is a rejected order, not a dead run: the authorization
                # itself is still good, so journal it terminal and hand the caller a normal reply.
                if self._journal_failed:
                    raise RuntimeError("live order journal failed; restart required")
                if len(self._owned) >= MAX_OWNED:
                    raise RuntimeError("owned order table full")
                if client_id in self._owned:
                    raise LiveGateClosed("client id already owned")
                self._records[client_id] = {
                    "intent": {"side": int(intent.side), "price_i": intent.price_i, "size_i": intent.size_i, "tif": int(intent.tif)},
                    "ref_price_i": ref_price_i, "venue_order_id": None, "executed_qty_i": 0, "symbol": self.symbol,
                }
                self._transition(client_id, "REJECTED", f"gate: {e}")
                return {"clientOrderId": client_id, "orderId": None, "status": "REJECTED", "executedQty": "0.00000000"}
            self._refresh_unresolved()
            if self.unresolved:
                raise OrderStateUnknown(self.unresolved[0], "resolve before placing anything new")
            if self._journal_failed:
                raise RuntimeError("live order journal failed; restart required")
            if len(self._owned) >= MAX_OWNED:
                raise RuntimeError("owned order table full")
            p = self._params(intent, client_id, ref_price_i)
            if client_id in self._owned:
                raise LiveGateClosed("client id already owned")
            if self.journal_path.exists() and self.journal_path.stat().st_size >= MAX_JOURNAL_BYTES:
                raise RuntimeError("live order journal at 4 MB; reconcile before starting another run")
            self._records[client_id] = {
                "intent": {"side": int(intent.side), "price_i": intent.price_i, "size_i": intent.size_i, "tif": int(intent.tif)},
                "ref_price_i": ref_price_i, "venue_order_id": None, "executed_qty_i": 0, "symbol": self.symbol,
            }
            self._transition(client_id, "SENT", "place requested")
            try:
                return self._record_reply(client_id, await self._signed("POST", "/api/v3/order", p))
            except asyncio.CancelledError:
                self._transition(client_id, "UNKNOWN", "place task cancelled")
                raise
            except Exception as e:
                rejected = isinstance(e, VenueError) and 400 <= e.http < 500 and e.code is not None
                self._transition(client_id, "GONE" if rejected else "UNKNOWN", self._failure_note("place", e))
                if rejected:
                    raise
                raise OrderStateUnknown(client_id, type(e).__name__) from e

    async def get_order(self, client_id: str) -> dict[str, Any]:
        async with self._lock:
            return await self._get_order(client_id)

    async def _get_order(self, client_id: str) -> dict[str, Any]:
        p = {"symbol": binance_symbol(self.symbol), "origClientOrderId": client_id}
        r = await self._signed("GET", "/api/v3/order", p)
        if client_id in self._owned:
            return self._record_reply(client_id, r)
        return self._validate_reply("/api/v3/order", r, p)

    async def _settle_missing(self, client_id: str) -> dict[str, Any]:
        """Inspect bounded, paginated trade history; never settle a truncated scan."""
        record = self._records[client_id]
        order_id = record["venue_order_id"]
        executed = 0
        from_id = 0
        for _ in range(100):
            trades = await self.my_trades(from_id=from_id, limit=1000)
            ids = [t["id"] for t in trades if "id" in t]
            if any(type(i) is not int or i < from_id for i in ids) or ids != sorted(set(ids)):
                raise VenueError(200, None, "malformed trade pagination")
            for trade in trades:
                matches = (order_id is not None and trade.get("orderId") == order_id) or trade.get("clientOrderId") == client_id
                if matches:
                    executed += _quantity_i(trade["qty"])
                elif order_id is None and "clientOrderId" not in trade:
                    raise VenueError(200, None, "trade cannot be attributed without venue order id")
            if len(trades) < 1000:
                break
            if len(ids) != len(trades):
                raise VenueError(200, None, "malformed trade pagination")
            from_id = ids[-1] + 1
        else:
            raise VenueError(200, None, "trade history scan limit reached")
        executed = max(executed, record.get("executed_qty_i", 0))
        if executed > record["intent"]["size_i"]:
            raise VenueError(200, None, "malformed executed quantity")
        state = "FILLED" if executed else "GONE"
        self._transition(client_id, state, "unknown order settled from myTrades", executed_qty_i=executed)
        return {"clientOrderId": client_id, "orderId": order_id, "status": state, "executedQty": dec_str(executed, SIZE_UNIT, 8)}

    async def reconcile(self) -> list[str]:
        async with self._lock:
            for cid, state in list(self._owned.items()):
                if state in TERMINAL:
                    continue
                try:
                    try:
                        await self._get_order(cid)
                    except VenueError as e:
                        if e.code != -2011:
                            raise
                        await self._settle_missing(cid)
                except asyncio.CancelledError:
                    self._transition(cid, "UNKNOWN", "reconcile task cancelled")
                    raise
                except Exception as e:
                    self._transition(cid, "UNKNOWN", self._failure_note("reconcile", e))
            return list(self.unresolved)

    async def cancel(self, client_id: str) -> dict[str, Any]:
        async with self._lock:
            return await self._cancel(client_id)

    async def _cancel(self, client_id: str) -> dict[str, Any]:
        if client_id not in self._owned:
            raise LiveGateClosed(f"refusing to cancel an order this run did not place: {client_id}")
        if self._owned[client_id] in TERMINAL:
            return {"clientOrderId": client_id, "status": self._owned[client_id]}
        self._transition(client_id, "UNKNOWN", "cancel requested")
        try:
            try:
                r = await self._signed("DELETE", "/api/v3/order", {"symbol": binance_symbol(self.symbol), "origClientOrderId": client_id})
            except VenueError as e:
                if e.code != -2011:
                    raise
                return await self._settle_missing(client_id)
            result = self._record_reply(client_id, r)
            if self._owned[client_id] not in TERMINAL:
                raise OrderStateUnknown(client_id, "cancel did not confirm a terminal state")
            return result
        except asyncio.CancelledError:
            self._transition(client_id, "UNKNOWN", "cancel task cancelled")
            raise
        except Exception as e:
            self._transition(client_id, "UNKNOWN", self._failure_note("cancel", e))
            if isinstance(e, VenueError) and 400 <= e.http < 500 and e.code is not None:
                raise
            raise OrderStateUnknown(client_id, type(e).__name__) from e

    async def cancel_owned(self) -> dict[str, Any]:
        """Return explicit shutdown evidence; failures and resting orders are never clean."""
        async with self._lock:
            cancelled: list[str] = []
            failed: list[str] = []
            for cid, state in list(self._owned.items()):
                if state in TERMINAL:
                    continue
                try:
                    await self._cancel(cid)
                    if self._owned[cid] == "CANCELED":
                        cancelled.append(cid)
                except Exception:
                    failed.append(cid)  # _cancel journals the failure before raising
            unresolved = [cid for cid, state in self._owned.items() if state not in TERMINAL]
            result = {"cancelled": cancelled, "failed": failed, "unresolved": unresolved, "clean": not failed and not unresolved}
            self.shutdown_result = result
            return result

    async def open_orders(self) -> list[dict[str, Any]]:
        p = {"symbol": binance_symbol(self.symbol)}
        return self._validate_reply("/api/v3/openOrders", await self._signed("GET", "/api/v3/openOrders", p), p)

    async def account(self) -> dict[str, Any]:
        return self._validate_reply("/api/v3/account", await self._signed("GET", "/api/v3/account", {}), {})

    async def my_trades(self, from_id: int | None = None, limit: int = 500) -> list[dict[str, Any]]:
        p = {"symbol": binance_symbol(self.symbol), "limit": str(max(1, min(limit, 1000)))}
        if from_id is not None:
            p["fromId"] = str(from_id)
        return self._validate_reply("/api/v3/myTrades", await self._signed("GET", "/api/v3/myTrades", p), p)
