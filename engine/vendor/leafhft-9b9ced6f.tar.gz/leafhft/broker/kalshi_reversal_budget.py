"""Inert account-wide gate for the Kalshi reversal experiment.

Claim immediately before submission. A returned token consumes the lifecycle forever,
including rejected/cancelled submissions. UNKNOWN retains every reservation. Report a
partial fill as filled only once submission resolves; its cost includes all fees.
No caller is wired here. Missing or malformed storage starts empty by specification.
"""
from __future__ import annotations

import os
from collections import Counter
from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from pathlib import Path
from typing import Any, Iterable
from uuid import uuid4

import orjson

from leafhft.broker.kalshi_pool import MAX_KEY_LEN, MAX_POOL_BYTES, _FileLock

LOCK_TIMEOUT_S = 2


class RefusalReason(str, Enum):
    ALREADY_REVERSED = "already_reversed"
    OPEN_CAP = "open_cap"
    BUDGET_CAP = "budget_cap"
    FLOOR = "floor"
    EXTRA_COST_CAP = "extra_cost_cap"
    LOCK_TIMEOUT = "lock_timeout"
    WRITE_FAILURE = "write_failure"
    EXIT_LEG_PENDING = "exit_leg_pending"
    FREED_CASH_CAP = "freed_cash_cap"


# H2a2 mode 2 (cashout-first): the exit-leg outcomes at which the hedge leg may be counted.
HEDGE_COUNTABLE_EXIT_LEGS = frozenset({"COMPLETE", "PARTIAL"})
MAX_HEDGE_COUNT = 100_000


@dataclass(frozen=True)
class Refusal:
    reason: RefusalReason

    def __bool__(self) -> bool:
        return False


def _cents(value: int, name: str, *, signed: bool = False) -> int:
    if type(value) is not int or (not signed and value < 0):
        raise ValueError(f"{name} must be integer cents")
    return value


@dataclass(frozen=True)
class PartialFillPrefix:
    """Cumulative gross debit at a permitted prefix, before any netting proceeds."""

    count: Decimal
    cost_cents: int
    fees_cents: int

    def __post_init__(self) -> None:
        if (not isinstance(self.count, Decimal) or not self.count.is_finite()
                or self.count <= 0):
            raise ValueError("count must be a positive finite Decimal")
        _cents(self.cost_cents, "cost_cents")
        _cents(self.fees_cents, "fees_cents")


@dataclass(frozen=True)
class Filled:
    cost_cents: int

    def __post_init__(self) -> None:
        _cents(self.cost_cents, "cost_cents")


class ReversalBudget:
    def __init__(self, path: Path, *, max_extra_cents: int, max_open_cents: int,
                 budget_cents: int, floor_cents: int) -> None:
        self.path = Path(path)
        self._lock_path = Path(str(self.path) + ".lock")
        self.max_extra_cents = _cents(max_extra_cents, "max_extra_cents")
        self.max_open_cents = _cents(max_open_cents, "max_open_cents")
        self.budget_cents = _cents(budget_cents, "budget_cents")
        self.floor_cents = _cents(floor_cents, "floor_cents")
        # IO failures cannot safely update the shared file; publish these local counters.
        self.stats: Counter[str] = Counter()

    @staticmethod
    def _empty() -> dict[str, Any]:
        return {"version": 1, "entries": {}, "history": [],
                "totals": {"claims": 0, "realized_loss_cents": 0,
                           "realized_pnl_cents": 0, "refusals": {}}}

    def _load(self) -> dict[str, Any]:
        try:
            with self.path.open("rb") as fh:
                payload = fh.read(MAX_POOL_BYTES + 1)
        except OSError:
            return self._empty()
        try:
            if not payload or len(payload) > MAX_POOL_BYTES:
                raise ValueError("invalid size")
            doc = orjson.loads(payload)
            if not isinstance(doc, dict) or doc.get("version") != 1:
                raise ValueError("invalid document")
            entries, history, totals = doc["entries"], doc["history"], doc["totals"]
            if not isinstance(entries, dict) or not isinstance(history, list) or len(history) > 200:
                raise ValueError("invalid entries/history")
            _cents(totals["claims"], "claims")
            _cents(totals["realized_loss_cents"], "loss")
            _cents(totals["realized_pnl_cents"], "pnl", signed=True)
            if not isinstance(totals["refusals"], dict):
                raise ValueError("invalid counters")
            for reason, count in totals["refusals"].items():
                RefusalReason(reason)
                _cents(count, "counter")
            lifecycles = set()
            for token, entry in entries.items():
                if not isinstance(token, str) or len(token) != 32:
                    raise ValueError("invalid token")
                for key in ("ticker", "client_id"):
                    self._key(entry[key], key)
                _cents(entry["close_ns"], "close_ns")
                lifecycle = (entry["ticker"], entry["close_ns"])
                if lifecycle in lifecycles:
                    raise ValueError("duplicate lifecycle")
                lifecycles.add(lifecycle)
                if entry["state"] not in {"submitted", "unknown", "filled", "rejected", "cancelled", "settled"}:
                    raise ValueError("invalid state")
                for key in ("worst_case_cents", "exposure_cents", "cash_cents"):
                    _cents(entry[key], key)
                if entry["state"] in {"rejected", "cancelled", "settled"} and any(
                    entry[key] for key in ("worst_case_cents", "exposure_cents", "cash_cents")
                ):
                    raise ValueError("terminal reservation")
            if any(token not in entries for token in history):
                raise ValueError("invalid history")
            return doc
        except (ValueError, TypeError, KeyError, OverflowError):
            self.stats["corrupt_files"] += 1
            return self._empty()

    def _write(self, doc: dict[str, Any]) -> None:
        payload = orjson.dumps(doc)
        if len(payload) > MAX_POOL_BYTES:
            raise ValueError("reversal document would exceed MAX_POOL_BYTES")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + f".tmp{os.getpid()}")
        tmp.write_bytes(payload)
        os.replace(tmp, self.path)

    @staticmethod
    def _key(value: str, name: str) -> None:
        if not isinstance(value, str) or not 0 < len(value) <= MAX_KEY_LEN:
            raise ValueError(f"{name} invalid")

    def _refuse(self, reason: RefusalReason) -> Refusal:
        self.stats[reason.value] += 1
        return Refusal(reason)

    @staticmethod
    def _reservations(doc: dict[str, Any]) -> tuple[int, int, int]:
        entries = doc["entries"].values()
        return tuple(sum(e[key] for e in entries) for key in
                     ("exposure_cents", "worst_case_cents", "cash_cents"))

    def claim(self, ticker: str, close_ns: int, client_id: str, worst_case_cents: int,
              *, free_cash_cents: int, partial_fill_prefixes: Iterable[PartialFillPrefix],
              extra_cost_cents: int | None = None,
              existing_reservations_cents: int = 0) -> str | Refusal:
        """Return a durable token or refusal, never a resized leg.

        Prefixes must enumerate all permitted cumulative costs plus fees, including
        the full fill. External reservations are additional to this file's ledger.
        free_cash_cents excludes hypothetical proceeds. Worst case is the maximum
        possible loss; extra cost defaults conservatively to that amount.
        """
        self._key(ticker, "ticker")
        self._key(client_id, "client_id")
        _cents(close_ns, "close_ns")
        _cents(worst_case_cents, "worst_case_cents")
        _cents(free_cash_cents, "free_cash_cents")
        _cents(existing_reservations_cents, "existing_reservations_cents")
        extra = worst_case_cents if extra_cost_cents is None else extra_cost_cents
        _cents(extra, "extra_cost_cents")
        prefixes = tuple(partial_fill_prefixes)
        if not prefixes or any(not isinstance(p, PartialFillPrefix) for p in prefixes):
            raise ValueError("all permitted partial-fill prefixes are required")
        if any(a.count >= b.count for a, b in zip(prefixes, prefixes[1:])):
            raise ValueError("prefix counts must increase")
        cash = max(worst_case_cents, *(p.cost_cents + p.fees_cents for p in prefixes))
        try:
            with _FileLock(self._lock_path, timeout_s=LOCK_TIMEOUT_S):
                doc = self._load()
                exposure, pending, reserved = self._reservations(doc)
                reason = None
                if any(e["ticker"] == ticker and e["close_ns"] == close_ns
                       for e in doc["entries"].values()):
                    reason = RefusalReason.ALREADY_REVERSED
                elif extra > self.max_extra_cents:
                    reason = RefusalReason.EXTRA_COST_CAP
                elif exposure + cash > self.max_open_cents:
                    reason = RefusalReason.OPEN_CAP
                elif doc["totals"]["realized_loss_cents"] + pending + worst_case_cents > self.budget_cents:
                    reason = RefusalReason.BUDGET_CAP
                elif free_cash_cents - reserved - existing_reservations_cents - cash < self.floor_cents:
                    reason = RefusalReason.FLOOR
                if reason is not None:
                    counters = doc["totals"]["refusals"]
                    counters[reason.value] = counters.get(reason.value, 0) + 1
                    self._write(doc)
                    return self._refuse(reason)
                token = uuid4().hex
                doc["entries"][token] = {
                    "ticker": ticker, "close_ns": close_ns, "client_id": client_id,
                    "state": "submitted", "worst_case_cents": worst_case_cents,
                    "exposure_cents": cash, "cash_cents": cash,
                }
                doc["history"] = (doc["history"] + [token])[-200:]
                doc["totals"]["claims"] += 1
                self._write(doc)
                self.stats["claims"] += 1
                return token
        except TimeoutError:
            return self._refuse(RefusalReason.LOCK_TIMEOUT)
        except (OSError, ValueError, TypeError):
            return self._refuse(RefusalReason.WRITE_FAILURE)

    def claim_hedge(self, ticker: str, close_ns: int, client_id: str, *, exit_leg: str,
                    freed_cash_cents: int | None, count: int, price_cents: int,
                    fee_per_contract_cents: int, free_cash_cents: int,
                    existing_reservations_cents: int = 0,
                    max_debit_cents: int | None = None) -> str | Refusal:
        """Mode 2: count the hedge leg only after the exit leg is COMPLETE or PARTIAL with its
        freed cash known (an int). Anything else refuses EXIT_LEG_PENDING before the lock and
        writes nothing: a hedge is never counted against a cashout that has not happened.

        The claim is the hedge leg alone (the exit leg is reduce-only and debits no premium):
        worst case and extra cost are the pipeline's maximum debit for the count, max_debit_cents
        (the buy pipeline's price buffer plus fees), which defaults to count * (price + fee) and
        may never be below it. A buy-only leg's gross debit is nondecreasing in the filled count,
        so the full-fill prefix bounds every hundredth prefix exactly; one prefix, not count * 100
        of them. free_cash_cents is the book's free cash AFTER the exit leg, so it already holds
        the freed proceeds.

        The hedge debit ceiling is min(caps, freed_cash_cents, free cash): a maximum debit above
        the cash the exit leg actually freed refuses FREED_CASH_CAP before the lock and writes
        nothing, however much other free cash the book holds (the hedge is funded by the
        cashout, never by the rest of the book).
        """
        if exit_leg not in HEDGE_COUNTABLE_EXIT_LEGS or type(freed_cash_cents) is not int:
            return self._refuse(RefusalReason.EXIT_LEG_PENDING)
        if type(count) is not int or not 1 <= count <= MAX_HEDGE_COUNT:
            raise ValueError("count must be a whole contract count in bounds")
        if type(price_cents) is not int or not 1 <= price_cents <= 99:
            raise ValueError("price_cents out of bounds")
        _cents(fee_per_contract_cents, "fee_per_contract_cents")
        fees = count * fee_per_contract_cents
        debit = count * price_cents + fees
        if max_debit_cents is not None:
            _cents(max_debit_cents, "max_debit_cents")
            if max_debit_cents < debit:
                raise ValueError("max_debit_cents is below count * (price + fee)")
            debit = max_debit_cents
        if debit > freed_cash_cents:
            return self._refuse(RefusalReason.FREED_CASH_CAP)
        cost = debit - fees
        return self.claim(ticker, close_ns, client_id, debit,
                          free_cash_cents=free_cash_cents,
                          partial_fill_prefixes=(PartialFillPrefix(Decimal(count), cost, fees),),
                          extra_cost_cents=debit,
                          existing_reservations_cents=existing_reservations_cents)

    def release(self, token: str, outcome: Filled | str) -> bool | Refusal:
        """Resolve submission. UNKNOWN is a durable no-release state.

        Rejected/cancelled mean confirmed zero fill. Any partial execution must be
        reported as Filled(actual gross cost). Filled keeps loss cover until settle.
        """
        if not isinstance(outcome, Filled) and outcome not in {"rejected", "cancelled", "UNKNOWN"}:
            raise ValueError("invalid outcome")
        return self._update(token, outcome=outcome)

    def settle(self, token: str, pnl_cents: int) -> bool | Refusal:
        """Record a confirmed final P&L once. Gains do not replenish loss budget."""
        _cents(pnl_cents, "pnl_cents", signed=True)
        return self._update(token, pnl_cents=pnl_cents)

    def _update(self, token: str, *, outcome: Filled | str | None = None,
                pnl_cents: int | None = None) -> bool | Refusal:
        try:
            with _FileLock(self._lock_path, timeout_s=LOCK_TIMEOUT_S):
                doc = self._load()
                entry = doc["entries"].get(token)
                if entry is None:
                    raise ValueError("unknown token")
                if entry["state"] in {"rejected", "cancelled", "settled"}:
                    return False
                if pnl_cents is not None:
                    doc["totals"]["realized_pnl_cents"] += pnl_cents
                    doc["totals"]["realized_loss_cents"] += max(0, -pnl_cents)
                    entry.update(state="settled", worst_case_cents=0, exposure_cents=0, cash_cents=0)
                elif isinstance(outcome, Filled):
                    # Actual execution is a fact, even if it exceeded its reservation.
                    entry.update(state="filled", exposure_cents=outcome.cost_cents,
                                 cash_cents=outcome.cost_cents,
                                 worst_case_cents=max(entry["worst_case_cents"], outcome.cost_cents))
                elif entry["state"] == "filled":
                    raise ValueError("filled exposure requires settlement")
                elif outcome == "UNKNOWN":
                    entry["state"] = "unknown"
                else:
                    entry.update(state=outcome, worst_case_cents=0, exposure_cents=0, cash_cents=0)
                try:
                    self._write(doc)
                except (OSError, ValueError, TypeError):
                    return self._refuse(RefusalReason.WRITE_FAILURE)
                return True
        except TimeoutError:
            return self._refuse(RefusalReason.LOCK_TIMEOUT)
        except OSError:
            return self._refuse(RefusalReason.WRITE_FAILURE)

    def snapshot(self) -> dict[str, Any] | Refusal:
        try:
            with _FileLock(self._lock_path, timeout_s=LOCK_TIMEOUT_S):
                doc = self._load()
                exposure, pending, cash = self._reservations(doc)
                return {**doc, "open_cents": exposure, "pending_worst_case_cents": pending,
                        "reserved_cash_cents": cash,
                        "budget_used_cents": doc["totals"]["realized_loss_cents"] + pending}
        except TimeoutError:
            return self._refuse(RefusalReason.LOCK_TIMEOUT)
        except OSError:
            return self._refuse(RefusalReason.WRITE_FAILURE)
