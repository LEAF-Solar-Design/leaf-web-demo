"""KalshiBook: cash, reservation and settlement accounting over KalshiLive. The ticket-book
analogue of LiveBroker for a market that resolves to $1 or $0 per contract instead of a
continuously marked position. Every cap here is enforced locally, before an order reaches the
venue: the venue's own risk checks are never trusted as the only backstop (astra C10 lineage).

All money in this module is cents (Kalshi's own unit); equity_q() is the one place that converts
to leafhft's QUOTE_UNIT-scaled quote_q for the engine's marks.
"""
from __future__ import annotations

import os
import hashlib
import re
import secrets
import tempfile
import time
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_HALF_UP
from pathlib import Path
from typing import Any

import orjson

from ..policy import DEFAULT_POLICY, KalshiPolicy, hard_maxima, per_order_balance_cap_cents
from ..policy import policy_digest
from ..attribution import (new_attribution, attribution_or_unknown, unknown_attribution,
                           scope_attribution, execution_account, recovered_settlement_minute,
                           valid_engine_revision)
from .account_risk import AccountRiskLedger, AccountRiskRefused
from ..execution_experiment import SubmissionRefused
from ..strategy.settlement import fee_per_contract
from ..types import QUOTE_UNIT
from ..venue_facts import reconcile_fee
from .kalshi_live import (KalshiLive, OrderStateUnknown, _count_number, _fixed_count,
                          _fill_basis, _fill_level_basis, _entry_debit_cents)


_ENTRY_STOP_CAUSES = frozenset({
    "finish_reversal_failed", "hedge_send_unknown", "buy_send_failed",
    "risk_release_failed", "risk_adopt_failed", "restore_finish_reversal_failed",
    "unknown",
})


def _book_count(value):
    """JSON-compatible exact hundredths; do count arithmetic through Decimal."""
    parsed = _fixed_count(str(value)) if type(value) in (float, Decimal) else _fixed_count(value)
    return None if parsed is None else _count_number(parsed)


def _contract_cents(price_cents, count) -> int:
    return int((Decimal(price_cents) * Decimal(str(count))).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def _remaining_count(count, exited):
    return _count_number(Decimal(str(count)) - Decimal(str(exited)))

def _raw_price_from_buy_row_price_cents(per_contract_cents: int) -> int | None:
    """A persisted "buy" ledger row's price_cents (SettlementPoller.record_buy) stores
    cost_cents // count, i.e. the fee-inclusive raw_price + fee_per_contract(raw_price), not the
    raw quoted price adopt_prior expects. Kalshi prices are bounded to 1..99 cents, so a 99-step
    search recovers the exact raw price cheaply; returns None when no price in range matches (a
    corrupt or out-of-range row)."""
    for p in range(1, 100):
        if p + fee_per_contract(p) == per_contract_cents:
            return p
    return None


MAX_TICKET_LEDGER_BYTES = 1024 * 1024
# H2a2: a predetermined mode-2 exit id has the random lx- id's exact shape (KalshiLive sends lx- reduce-only).
_PREDETERMINED_EXIT_ID = re.compile(r"lx-[0-9a-f]{21}")
MAX_NOTED_REASONS = 1000
MAX_PRIOR_RUN_DIRS = 200  # bounded ledger IO per venue/symbol
TERMINAL_MARKET_STATUSES = ("settled", "finalized")


def _check_expiration_ts(expiration_ts: Any) -> None:
    """H2a2: a venue-side expiry is None or positive int unix seconds; refused before any send."""
    if expiration_ts is not None and (type(expiration_ts) is not int
                                      or not 0 < expiration_ts < 1 << 40):
        raise KalshiBookError("expiration_ts must be positive int unix seconds")


def _expiry_kwargs(expiration_ts: int | None) -> dict[str, int]:
    """The client keyword only when an expiry is given, so every other caller's call is unchanged."""
    return {} if expiration_ts is None else {"expiration_ts": expiration_ts}


@dataclass(frozen=True, slots=True)
class KalshiLimits:
    max_loss_per_order_cents: int
    max_cluster_exposure_cents: int
    max_cumulative_loss_cents: int
    max_open_tickets: int
    cash_floor_cents: int = 0
    risk_policy: KalshiPolicy | None = field(default=None, compare=False, repr=False)

    def __post_init__(self) -> None:
        if type(self.cash_floor_cents) is not int or self.cash_floor_cents < 0:
            raise ValueError("cash_floor_cents must be a nonnegative int in cents")
        for name in ("max_loss_per_order_cents", "max_cluster_exposure_cents", "max_cumulative_loss_cents"):
            v = getattr(self, name)
            if type(v) is not int or not 0 < v <= 10_000_000:
                raise ValueError(f"{name} must be a positive int in cents")
        if self.max_cluster_exposure_cents < self.max_loss_per_order_cents:
            raise ValueError("max_cluster_exposure_cents must be at least max_loss_per_order_cents")
        if self.max_cumulative_loss_cents < self.max_cluster_exposure_cents:
            raise ValueError("max_cumulative_loss_cents must be at least max_cluster_exposure_cents")
        if type(self.max_open_tickets) is not int or not 1 <= self.max_open_tickets <= 1000:
            raise ValueError("max_open_tickets out of range")

    @classmethod
    def from_policy(cls, p: KalshiPolicy, balance_cents: int,
                    day_open_cents: int) -> "KalshiLimits":
        """Scale caps to the shard while preserving the class bounds and ordering.

        Zero balance produces legal minimum caps; can_open still refuses on cash. The account
        regime (policy.hard_maxima) also clamps the cluster to the settlement ceiling and the
        order to the regime's per-order fraction of the balance; the owner regime honours the engine's own fractions.
        """
        maxima = hard_maxima()
        per_order = min(10_000_000, round(p.stake_ceiling_usd * 100),
                        max(1, int(balance_cents * p.per_order_fraction)))
        cluster_fraction = min(p.cluster_fraction, maxima.get("cluster_fraction", 1.0))
        cluster = min(10_000_000, max(1, int(balance_cents * cluster_fraction)))
        cumulative = min(10_000_000, max(1, int(day_open_cents * p.daily_loss_fraction)))
        cluster = min(cluster, cumulative)
        per_order = min(per_order, cluster)
        capped = per_order_balance_cap_cents(balance_cents)
        if capped is not None:
            per_order = min(per_order, capped)
        return cls(per_order, cluster, cumulative, 3, cash_floor_cents=p.cash_floor_cents, risk_policy=p)

    @classmethod
    def experiment(cls) -> "KalshiLimits":
        """PLAN-S2D day-3 caps: $1 per order, $3 per cluster, $5 cumulative, 3 open tickets."""
        return cls(100, 300, 500, 3)

    @classmethod
    def week2(cls) -> "KalshiLimits":
        return cls(500, 1000, 10_000, 10)

    @classmethod
    def experiment_5x(cls) -> "KalshiLimits":
        """Operator instruction 2026-09-09: 5x the day-3 experiment sizing ($5 per order, $15 per
        cluster, $25 cumulative, 3 open), after day one's 28 tickets, 24 won, +256c at $1 sizing."""
        return cls(500, 1500, 2500, 3)

    @classmethod
    def house_money(cls) -> "KalshiLimits":
        """Operator instruction 2026-09-09: $25 per order, $75 per expiry cluster (three strikes
        of one ladder hour, or one 15-minute market three times), $75 cumulative, 3 open. The
        cumulative cap counts today's loss PLUS the new ticket's full cost (can_open), so $75
        lets a book lose three $25 tickets in a day before it stops. The venue balance stays the
        hard floor across the fourteen books."""
        return cls(2500, 7500, 7500, 3)

    @classmethod
    def favorites_5x(cls) -> "KalshiLimits":
        """Operator instruction 2026-09-09: favorite legs (fav=1) size to 5x the contracts, so
        the per-order cap must admit a $125 ticket (25 * $5): $125 per order, $125 per expiry
        cluster, $125 cumulative, 3 open. One 5x loss or five $25 losses stop that book for the
        day. The venue balance stays the hard floor."""
        return cls(12500, 12500, 12500, 3)


KALSHI_LIMITS_PROFILES = {
    "kalshi-experiment": KalshiLimits.experiment,
    "kalshi-week2": KalshiLimits.week2,
    "kalshi-experiment-5x": KalshiLimits.experiment_5x,
    "kalshi-house-money": KalshiLimits.house_money,
    "kalshi-favorites-5x": KalshiLimits.favorites_5x,
}


def day_open_read(path: Path, today: date) -> int | None:
    """Read today's nonnegative opening balance from at most 1 KiB of JSON."""
    try:
        with Path(path).open("rb") as f:
            payload = f.read(1025)
        if len(payload) > 1024:
            return None
        row = orjson.loads(payload)
    except (OSError, ValueError):
        return None
    if not isinstance(row, dict) or row.get("date") != today.isoformat():
        return None
    balance = row.get("balance_cents")
    return balance if type(balance) is int and balance >= 0 else None


def day_open_write(path: Path, today: date, balance_cents: int) -> None:
    """Atomically replace the day-open record with permissions 0640."""
    if type(balance_cents) is not int or balance_cents < 0:
        raise ValueError("balance_cents must be a nonnegative int")
    payload = orjson.dumps({"date": today.isoformat(), "balance_cents": balance_cents})
    path = Path(path)
    fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    tmp = Path(name)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o640)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def drawdown_fraction(day_open_cents: int, balance_cents: int) -> float:
    if day_open_cents <= 0 or balance_cents >= day_open_cents:
        return 0.0
    return min(1.0, max(0.0, (day_open_cents - balance_cents) / day_open_cents))


def drawdown_state(p: KalshiPolicy, dd: float) -> str:
    if dd >= p.drawdown_stop_fraction:
        return "stop"
    if dd >= p.drawdown_brake_fraction:
        return "brake"
    return "normal"


def prior_realized_today_cents(runs_root: Path, venue: str, symbol: str, now_utc: datetime,
                               exclude_run_dir: Path | None = None,
                               ledger_name: str = "kalshi-tickets.jsonl", *,
                               scan_stats: dict[str, int] | None = None) -> tuple[int, int, int]:
    """Realized P&L for this venue+symbol already booked today (UTC) by prior runs, read from
    their immutable kalshi-tickets.jsonl ledgers, so a restart cannot reset the daily loss cap.
    `ledger_name` defaults to the live ledger's name so every existing caller is untouched; the
    paper shadow lane passes "kalshi-shadow-tickets.jsonl" to score its own ledger instead.
    Bounded ledger IO: at most MAX_PRIOR_RUN_DIRS venue/symbol-matched directories whose name
    starts with today's or yesterday's YYYYMMDD, each ledger read at
    most MAX_TICKET_LEDGER_BYTES. Any settle/void row that cannot be trusted (bad JSON, wrong
    field types) is skipped and counted in bad_lines rather than silently dropped or trusted.
    Returns (realized_cents, rows_read, bad_lines). If supplied, scan_stats receives the count
    of matching directories dropped by the budget in "dropped_dirs"."""
    day_start = datetime(now_utc.year, now_utc.month, now_utc.day, tzinfo=timezone.utc)
    day_start_ns = int(day_start.timestamp() * 1_000_000_000)
    day_end_ns = day_start_ns + 86_400_000_000_000
    today_str = day_start.strftime("%Y%m%d")
    yesterday_str = (day_start - timedelta(days=1)).strftime("%Y%m%d")
    realized_cents = 0
    rows_read = 0
    bad_lines = 0
    reversal_best: dict[str, tuple[Decimal, int, int]] = {}  # H1c: cid -> (processed, pnl, ts_ns)
    if scan_stats is not None:
        scan_stats["dropped_dirs"] = 0
    try:
        entries = list(os.scandir(runs_root))
    except OSError:
        return (0, 0, 0)
    candidate_entries = [entry for entry in entries
                         if (entry.name.startswith(today_str) or entry.name.startswith(yesterday_str))
                         and (exclude_run_dir is None or entry.name != exclude_run_dir.name)
                         and entry.is_dir()]
    candidate_entries.sort(key=lambda entry: entry.name, reverse=True)
    matching_dirs: list[Path] = []
    for entry in candidate_entries:
        run_path = Path(entry.path)
        try:
            cfg_row = orjson.loads((run_path / "config.json").read_bytes())
        except Exception:
            continue
        if not isinstance(cfg_row, dict) or cfg_row.get("venue") != venue or cfg_row.get("symbol") != symbol:
            continue
        matching_dirs.append(run_path)
    if scan_stats is not None:
        scan_stats["dropped_dirs"] = max(0, len(matching_dirs) - MAX_PRIOR_RUN_DIRS)
    for run_path in matching_dirs[:MAX_PRIOR_RUN_DIRS]:
        try:
            with (run_path / ledger_name).open("rb") as f:
                data = f.read(MAX_TICKET_LEDGER_BYTES)
        except OSError:
            continue
        for line in data.split(b"\n"):
            if not line.strip():
                continue
            try:
                row = orjson.loads(line)
            except Exception:
                bad_lines += 1
                continue
            if not isinstance(row, dict):
                bad_lines += 1
                continue
            kind = row.get("kind")
            if kind == "reversal":
                # H1c: cumulative snapshots; only the greatest processed per client id counts.
                cid = row.get("client_id")
                tx = row.get("transaction")
                try:
                    processed = Decimal(str(tx["processed"])) if isinstance(tx, dict) else None
                except Exception:
                    processed = None
                if (not isinstance(cid, str) or not cid or processed is None or not processed.is_finite()
                        or type(tx.get("pnl")) is not int or type(row.get("ts_ns")) is not int):
                    bad_lines += 1
                    continue
                best = reversal_best.get(cid)
                if best is None or processed > best[0]:  # bounded by the capped ledger bytes read
                    reversal_best[cid] = (processed, tx["pnl"], row["ts_ns"])
                continue
            if kind not in ("settle", "void", "exit"):
                continue
            # An exit row realizes on ts_ns (it has no settled_ns: nothing settled at the venue),
            # a settle/void row on settled_ns.
            settled_ns = row.get("ts_ns") if kind == "exit" else row.get("settled_ns")
            pnl_cents = row.get("pnl_cents")
            if type(settled_ns) is not int or type(pnl_cents) is not int:
                bad_lines += 1
                continue
            if not (day_start_ns <= settled_ns < day_end_ns):
                continue
            realized_cents += pnl_cents
            rows_read += 1
    for _, pnl_cents, ts_ns in reversal_best.values():
        if day_start_ns <= ts_ns < day_end_ns:
            realized_cents += pnl_cents
            rows_read += 1
    return (realized_cents, rows_read, bad_lines)


def unsettled_prior_tickets(runs_root: Path, venue: str, symbol: str, now_utc: datetime,
                            exclude_run_dir: Path | None = None,
                            ledger_name: str = "kalshi-tickets.jsonl",
                            journal_name: str | None = "live-orders.jsonl", *,
                            scan_stats: dict[str, int] | None = None,
                            exits_out: dict[str, Any] | None = None) -> tuple[list[dict[str, Any]], int]:
    """Filled or partially-filled tickets from prior runs of this venue+symbol that no scanned
    ledger has settled or adopted, so a restart between a fill and its settlement can recover
    them (astra C10 lineage: nothing here is trusted from the venue's own position list, which a
    settled-while-down market has already dropped). `ledger_name` defaults to the live ledger's
    name so every existing caller is untouched; the paper shadow lane passes
    "kalshi-shadow-tickets.jsonl" so its own settle/void/adopt rows gate its own recovery.
    `journal_name` defaults to the live client's own journal, read exactly as before for every
    existing caller (byte-for-byte); the paper shadow lane passes journal_name=None because
    PaperKalshiClient writes no journal at all, and because that journal is shared per run_dir
    with the live lane (a live buy's journal row would otherwise look like an orphaned shadow
    ticket). With journal_name=None, candidates come only from "buy" rows already inside the
    scanned ledger_name file itself, so a live ticket (which never appears in the shadow's own
    ledger) can never be recovered by the shadow. Same bounded scan as prior_realized_today_cents:
    at most MAX_PRIOR_RUN_DIRS run dirs matching today's or yesterday's UTC date and this
    venue/symbol, excluding exclude_run_dir, each ledger (ledger_name) and journal (journal_name)
    read at most MAX_TICKET_LEDGER_BYTES. A settle, void or adopt row anywhere in a scanned ledger
    removes its client_id from candidacy. Within a journal, the LAST line for a client_id wins
    (later journal rows supersede earlier state transitions). Returns (rows, bad_lines) where each
    row is {ticker, side_yes, price_cents, count, client_id, venue_order_id, opened_ns, run_dir}.
    If supplied, scan_stats receives the count of matching directories dropped by the budget
    in "dropped_dirs". If supplied, exits_out receives each client id's exited count from the
    scanned ledgers (COMBINE-S1b c1: combined_restart_rows subtracts them from a split share)."""
    day_start = datetime(now_utc.year, now_utc.month, now_utc.day, tzinfo=timezone.utc)
    today_str = day_start.strftime("%Y%m%d")
    yesterday_str = (day_start - timedelta(days=1)).strftime("%Y%m%d")
    bad_lines = 0
    if scan_stats is not None:
        scan_stats["dropped_dirs"] = 0
    try:
        entries = list(os.scandir(runs_root))
    except OSError:
        return ([], 0)
    matching_dirs: list[Path] = []
    candidate_entries = [entry for entry in entries
                         if (entry.name.startswith(today_str) or entry.name.startswith(yesterday_str))
                         and (exclude_run_dir is None or entry.name != exclude_run_dir.name)
                         and entry.is_dir()]
    candidate_entries.sort(key=lambda entry: entry.name, reverse=True)
    for entry in candidate_entries:
        run_path = Path(entry.path)
        try:
            cfg_row = orjson.loads((run_path / "config.json").read_bytes())
        except Exception:
            continue
        if not isinstance(cfg_row, dict) or cfg_row.get("venue") != venue or cfg_row.get("symbol") != symbol:
            continue
        matching_dirs.append(run_path)

    if scan_stats is not None:
        scan_stats["dropped_dirs"] = max(0, len(matching_dirs) - MAX_PRIOR_RUN_DIRS)
    matching_dirs = matching_dirs[:MAX_PRIOR_RUN_DIRS]

    settled_ids: set[str] = set()
    exit_counts: dict[str, int] = {}
    buy_candidates: dict[str, dict[str, Any]] = {}
    buy_reasons: dict[tuple[str, str], str] = {}
    # COMBINE-S1 (journal mode): this ledger's own share of a combined fill, by its client id. The venue
    # and journal only ever saw the wire id with the WHOLE fill, so the share, never the journal row,
    # is what this book re-opens; a share is re-opened only when its wire's journal row is FILLED or PARTIAL.
    combined_shares: dict[str, dict[str, Any]] = {}
    for run_path in matching_dirs:
        try:
            with (run_path / ledger_name).open("rb") as f:
                data = f.read(MAX_TICKET_LEDGER_BYTES)
        except OSError:
            continue
        for line in data.split(b"\n"):
            if not line.strip():
                continue
            try:
                row = orjson.loads(line)
            except Exception:
                bad_lines += 1
                continue
            if not isinstance(row, dict):
                bad_lines += 1
                continue
            kind = row.get("kind")
            if kind == "buy" and isinstance(row.get("client_id"), str):
                reason = row.get("reason")
                buy_reasons[(run_path.name, row["client_id"])] = reason[:400] if isinstance(reason, str) else ""
            if (journal_name is not None and kind in ("buy", "combined_zero") and row.get("combined") is True
                    and isinstance(row.get("client_id"), str) and row["client_id"]
                    and isinstance(row.get("physical_client_id"), str) and row["physical_client_id"]):
                combined_shares[row["client_id"]] = {**row, "run_dir": run_path.name}
                continue
            if journal_name is None and kind == "buy":
                # No journal to recover from (the paper client writes none): a "buy" row already
                # in this same ledger is the only candidate source, so a live ticket (which never
                # appears in the shadow's own ledger) can never surface here.
                cid = row.get("client_id")
                ticker = row.get("ticker")
                side_yes = row.get("side_yes")
                stored_price_cents = row.get("price_cents")
                count = _book_count(row.get("count"))
                if not isinstance(cid, str) or not cid or not isinstance(ticker, str) or not ticker \
                        or type(side_yes) is not bool or type(stored_price_cents) is not int \
                        or count is None:
                    bad_lines += 1
                    continue
                fractional = row.get("fractional_sizing") is True
                raw_price_cents = (row.get("intent_price_cents") if fractional else
                                   _raw_price_from_buy_row_price_cents(stored_price_cents))
                if fractional and (type(raw_price_cents) is not int or not 1 <= raw_price_cents <= 99
                                   or any(type(row.get(key)) is not int or row[key] < 0
                                          for key in ("cost_cents", "fee_cents"))):
                    bad_lines += 1
                    continue
                if raw_price_cents is None:
                    bad_lines += 1
                    continue
                buy_candidates[cid] = {
                    "attribution": attribution_or_unknown(row.get("attribution")),
                    "settlement_minute": row.get("settlement_minute", -1),
                    "ticker": ticker, "side_yes": side_yes, "price_cents": raw_price_cents, "count": count,
                    "venue_order_id": None, "ts_ns": row.get("ts_ns", 0), "run_dir": run_path.name,
                }
                if fractional:
                    buy_candidates[cid].update(fractional_sizing=True, cost_cents=row["cost_cents"],
                                               fee_cents=row["fee_cents"])
                continue
            if kind not in ("settle", "void", "adopt", "exit"):
                continue
            cid = row.get("client_id")
            if not isinstance(cid, str) or not cid:
                bad_lines += 1
                continue
            if kind == "exit":
                # A partial exit reduces the recovered ticket's count rather than removing it
                # outright (settled_ids stays for settle/void/adopt only); a fully exited ticket
                # is filtered out below once its reduced count reaches zero.
                exited = _book_count(row.get("count"))
                if exited is None or exited <= 0:
                    bad_lines += 1
                    continue
                exit_counts[cid] = _count_number(Decimal(str(exit_counts.get(cid, 0))) + Decimal(str(exited)))
                continue
            settled_ids.add(cid)

    candidates: dict[str, dict[str, Any]] = {}
    if journal_name is None:
        candidates = buy_candidates
    else:
        for run_path in matching_dirs:
            try:
                with (run_path / journal_name).open("rb") as f:
                    data = f.read(MAX_TICKET_LEDGER_BYTES)
            except OSError:
                continue
            for line in data.split(b"\n"):
                if not line.strip():
                    continue
                try:
                    row = orjson.loads(line)
                except Exception:
                    bad_lines += 1
                    continue
                if not isinstance(row, dict):
                    bad_lines += 1
                    continue
                cid = row.get("client_id")
                if not isinstance(cid, str) or not cid:
                    bad_lines += 1
                    continue
                candidates[cid] = {**row, "run_dir": run_path.name}  # last line for cid wins

    rows: list[dict[str, Any]] = []
    for cid, share in combined_shares.items():
        wire = share["physical_client_id"]
        physical = candidates.get(wire)
        if cid == wire:
            candidates.pop(cid, None)  # the anchor's carved share replaces the wire's whole-fill journal row
        if cid in settled_ids or not isinstance(physical, dict) or physical.get("state") not in ("FILLED", "PARTIAL"):
            continue
        count = _book_count(share.get("count"))
        if count is None or count <= 0:
            continue  # a zero share (combined_zero): nothing of this fill is this book's
        ticker, side_yes = share.get("ticker"), share.get("side_yes")
        cost, fee, price_cents = share.get("cost_cents"), share.get("fee_cents"), share.get("price_cents")
        if (not isinstance(ticker, str) or not ticker or type(side_yes) is not bool or type(price_cents) is not int
                or type(cost) is not int or type(fee) is not int or not 0 <= fee <= cost):
            bad_lines += 1
            continue
        if share.get("price_basis", "intent") != "fill":
            # COMBINE-S1b: an intent-basis buy row stores cost // count (fee included); the ticket's own
            # price is recovered exactly as the paper path does, so a restarted combined ticket has the
            # live ticket's price_cents. Cost and fee still come from the row.
            # COMBINE-S1b c1: the raw entry price the row carries wins; the inversion is only for older rows.
            entry_price = share.get("entry_price_cents")
            price_cents = (share.get("intent_price_cents") if share.get("fractional_sizing") is True
                           else entry_price if type(entry_price) is int and 1 <= entry_price <= 99
                           else _raw_price_from_buy_row_price_cents(price_cents))
            if type(price_cents) is not int or not 1 <= price_cents <= 99:
                bad_lines += 1
                continue
        exited = exit_counts.get(cid, 0)
        remaining = _remaining_count(count, exited)
        if remaining <= 0:
            continue
        rows.append({
            "attribution": attribution_or_unknown(share.get("attribution")),
            "settlement_minute": share.get("settlement_minute", -1),
            "ticker": ticker, "side_yes": side_yes, "price_cents": price_cents, "count": remaining,
            "client_id": cid, "venue_order_id": physical.get("venue_order_id"),
            "opened_ns": share.get("opened_ns", share.get("ts_ns", 0)), "run_dir": share["run_dir"],
            "reason": buy_reasons.get((share["run_dir"], cid), ""),
            "price_basis": share.get("price_basis", "intent"), "intent_price_cents": share.get("intent_price_cents"),
            "combined": True, "physical_client_id": wire,
            "cost_cents": cost - _integer_split(cost, count, exited) if exited else cost,
            "fee_cents": fee - _integer_split(fee, count, exited) if exited else fee,
        })
    for cid, row in candidates.items():
        if cid in settled_ids:
            continue
        if cid.startswith("lx-"):
            # An exit order closes the ticket its ledger exit row names (exit_counts above); its own
            # FILLED journal row is never an open ticket, exactly as KalshiBook.recover skips it.
            continue
        if journal_name is None:
            count = row.get("count", 0)
        else:
            if row.get("state") not in ("FILLED", "PARTIAL"):
                continue
            count = row.get("fill_count", 0)
        ticker = row.get("ticker")
        side_yes = row.get("side_yes")
        price_cents = row.get("price_cents")
        count = _book_count(count)
        if count is None or count <= 0:
            continue
        if not isinstance(ticker, str) or not ticker or type(side_yes) is not bool or type(price_cents) is not int:
            bad_lines += 1
            continue
        original_count = count
        count = _remaining_count(count, exit_counts.get(cid, 0))
        if count <= 0:
            continue  # fully exited before this restart: not reopened
        rows.append({
            "attribution": attribution_or_unknown(row.get("attribution")),
            "settlement_minute": row.get("settlement_minute", -1),
            "ticker": ticker, "side_yes": side_yes, "price_cents": price_cents, "count": count,
            "client_id": cid, "venue_order_id": row.get("venue_order_id"),
            "opened_ns": row.get("ts_ns", 0), "run_dir": row["run_dir"],
            "reason": buy_reasons.get((row["run_dir"], cid), ""),
        })
        # Only a fixed_count entry carries the marker. A legacy fractional fill (a partial IOC or
        # Dark Horse) keeps origin/main's recovery byte for byte.
        if row.get("fractional_sizing") is True:
            if journal_name is None:
                total, fee = row["cost_cents"], row["fee_cents"]
            else:
                # The basis recover() rebuilds from the same journal record: the entry's own model
                # fee per contract and the venue's reported fee, so adopting a fixed ticket into a
                # new run never gives it a second cost. Malformed fee fields fail closed.
                try:
                    model_fee = _entry_debit_cents(
                        0, original_count,
                        row.get("model_fee_per_contract_cents", fee_per_contract(price_cents)))
                    fee = reconcile_fee(row.get("venue_fee_cents"), model_fee).fee_cents
                except (TypeError, ValueError, ArithmeticError):
                    rows.pop()
                    bad_lines += 1
                    continue
                total = _entry_debit_cents(price_cents, original_count, 0) + fee
            exited = exit_counts.get(cid, 0)
            rows[-1].update(cost_cents=total - _integer_split(total, original_count, exited),
                            fee_cents=fee - _integer_split(fee, original_count, exited),
                            fractional_sizing=True, intent_price_cents=price_cents,
                            exit_basis=(original_count, total, fee))
        if all(type(row.get(key)) is int and row[key] >= 0
               for key in ("venue_cost_cents", "venue_fee_cents")):
            total = row["venue_cost_cents"] + row["venue_fee_cents"]
            exited = exit_counts.get(cid, 0)
            rows[-1].update(
                cost_cents=total - _integer_split(total, original_count, exited),
                fee_cents=row["venue_fee_cents"] - _integer_split(row["venue_fee_cents"], original_count, exited),
                price_basis="fill", intent_price_cents=price_cents,
                price_cents=int((Decimal(row["venue_cost_cents"]) / Decimal(str(original_count))).quantize(
                    Decimal(1), rounding=ROUND_HALF_UP)))
            if "exit_basis" in rows[-1]:
                rows[-1]["exit_basis"] = (original_count, total, row["venue_fee_cents"])
    if exits_out is not None:
        exits_out.update(exit_counts)
    return (rows, bad_lines)


_AUTHORITY_TERMINAL = ("filled", "partial", "zero")


def _group_wire_restart_share(cid: str, intent: dict, intents: dict) -> tuple[str, Any] | None:
    """COMBINE-S1b c1: the anchor's own share of a combined wire whose account-risk entry holds no
    combined_split, read from the authority group record claim_group wrote before the send.
    ("share", (count, cost)): resolve_group landed, so the wire intent holds exactly the anchor's
    share. ("whole", None): the invariant path (the wire unknown, no other leg holds a positive
    share) kept the whole fill on the anchor, and no other book re-opens any of it. None: anything
    else (the group write never landed, a sibling holds a share behind a non-terminal wire), which
    the caller refuses rather than risk crediting the same contracts twice. O(intents)."""
    state = intent.get("state")
    if state in _AUTHORITY_TERMINAL:
        return ("share", (intent.get("filled_count"), intent.get("actual_cost_cents")))
    if state != "unknown":
        return None
    for other_cid, other in intents.items():
        group = other.get("group") if isinstance(other, dict) else None
        if other_cid == cid or not isinstance(group, dict) or group.get("wire_cid") != cid:
            continue
        filled = _book_count(other.get("filled_count"))
        if filled is None or filled:
            return None
    return ("whole", None)


def combined_restart_rows(rows: list[dict[str, Any]], entries: dict[str, Any] | None,
                          exits: dict[str, Any] | None = None,
                          intents: dict[str, Any] | None = None) -> tuple[list[dict[str, Any]], list[tuple]]:
    """COMBINE-S1b: a restart never credits a book with more than its own share of a combined wire.

    rows: unsettled_prior_tickets output for one book. entries: that book's account-risk entries
    (AccountRiskLedger snapshot "entries"), or None when unreadable. exits: each client id's exited
    count from the same scan (unsettled_prior_tickets exits_out). intents: the authority snapshot's
    intents, or None when unreadable. A combined share row (combined=True) is already this book's
    exact share and passes. Any other row whose client id's entry carries a combined_split
    (split_entry writes it before any leg's ticket-ledger row, so it survives a failed record_buy) is
    a combined wire whose share row is missing: it re-opens at the wire's OWN split share less the
    exits already taken under the wire id (cost and fee reduced the way the share branch reduces
    them), and a zero remainder re-opens nothing. A combined wire (sealed attribution or authority
    group record) whose entry has no split takes its share from the authority group record
    (_group_wire_restart_share), the whole fill only on the invariant path, and is otherwise refused
    as combine_restart_ambiguous; with no ledger entry at all it is refused as combine_split_unknown.
    Never adopted whole on a guess. Returns (rows to adopt, [(client_id, run_dir, reason)] refused).
    Pure, O(rows * (split legs + group intents))."""
    kept, refused = [], []
    exits = exits if isinstance(exits, dict) else {}
    for row in rows:
        cid = row["client_id"]
        if row.get("combined") is True:
            kept.append(row)
            continue
        entry = entries.get(cid) if isinstance(entries, dict) else None
        split = entry.get("combined_split") if isinstance(entry, dict) else None
        if split is None:
            attribution = row.get("attribution")
            inputs = attribution.get("market_inputs") if isinstance(attribution, dict) else None
            attributed = isinstance(inputs, dict) and inputs.get("combined") is True
            intent = intents.get(cid) if isinstance(intents, dict) else None
            group = intent.get("group") if isinstance(intent, dict) else None
            grouped = isinstance(group, dict) and group.get("wire_cid") == cid
            if not attributed and not grouped:
                kept.append(row)
                continue
            if not isinstance(entry, dict):
                refused.append((cid, row.get("run_dir", ""), "combine_split_unknown"))
                continue
            verdict = _group_wire_restart_share(cid, intent, intents) if grouped else None
            if verdict is None:
                refused.append((cid, row.get("run_dir", ""), "combine_restart_ambiguous"))
                continue
            if verdict[0] == "whole":
                kept.append(row)
                continue
            share = [cid, *verdict[1]]
        else:
            share = (next((item for item in split if isinstance(item, list) and len(item) == 3 and item[0] == cid),
                          None) if isinstance(split, list) else None)
        count = _book_count(share[1]) if share is not None else None
        cost = share[2] if share is not None else None
        whole = _book_count(row.get("count"))  # the wire's journal fill less the exits already taken
        exited = _book_count(exits.get(cid, 0))
        if (count is None or whole is None or exited is None or type(cost) is not int or cost < 0
                or (not count and cost)):
            refused.append((cid, row.get("run_dir", ""), "combine_split_invalid"))
            continue
        remaining = _remaining_count(count, exited)
        if remaining <= 0:
            continue  # a zero share, or one already fully exited: nothing of this wire's fill is this book's
        if Decimal(str(remaining)) > Decimal(str(whole)):
            refused.append((cid, row.get("run_dir", ""), "combine_split_invalid"))
            continue
        fee, price = row.get("fee_cents"), row.get("price_cents")
        if type(fee) is int and fee >= 0 and whole:
            fee = int(Decimal(fee) * Decimal(str(count)) / Decimal(str(whole)))
        else:
            fee = _contract_cents(fee_per_contract(price), count) if type(price) is int and 1 <= price <= 99 else 0
        fee = min(fee, cost)
        adopted = dict(row, count=remaining,
                       cost_cents=cost - _integer_split(cost, count, exited) if exited else cost,
                       fee_cents=fee - _integer_split(fee, count, exited) if exited else fee,
                       combined=True, physical_client_id=cid)
        adopted["fee_cents"] = min(adopted["fee_cents"], adopted["cost_cents"])
        if "exit_basis" in row:
            adopted["exit_basis"] = (count, cost, fee)
        kept.append(adopted)
    return kept, refused


def _integer_split(total_cents: int, total_count: int, take: int) -> int:
    """Cost (or fee) of `take` contracts out of `total_count` costing `total_cents` altogether,
    with the remainder-carrying cent assigned to the LAST contracts: base = total // count, and a
    take of the last `take` units picks up min(take, total_cents - base*count) of the remainder.
    Applied fresh against the ticket's CURRENT count/cost on every exit, so a sequence of partial
    exits always sums back to the original total with no fabricated gain or loss."""
    if type(total_count) is not int or type(take) is not int:
        return int((Decimal(total_cents) * Decimal(str(take)) / Decimal(str(total_count))).quantize(
            Decimal(1), rounding=ROUND_HALF_UP))
    base = total_cents // total_count
    rem = total_cents - base * total_count
    return base * take + min(take, rem)


def expiry_cluster_id(expiry_ms: int) -> int:
    """Expiry rounded down to the minute: BTC and ETH markets expiring in the same minute share a cluster."""
    if type(expiry_ms) is not int or expiry_ms < 0:
        raise ValueError("expiry_ms must be a nonnegative int")
    return expiry_ms // 60_000


@dataclass(slots=True)
class Ticket:
    ticker: str
    side_yes: bool
    count: int | float
    cost_cents: int  # what this book actually paid, including fee
    fee_cents: int
    cluster_id: int
    client_id: str
    opened_ns: int
    venue_order_id: str | None = None
    reason: str = ""
    kind: str = "buy"
    physical_client_id: str | None = None
    price_basis: str = "intent"
    intent_price_cents: int | None = None
    price_cents: int | None = None
    attribution: dict = field(default_factory=unknown_attribution)


class KalshiBookError(RuntimeError):
    pass


_TICKET_REFUSAL_MESSAGES = {
    # The legacy one-ticket-per-market message, byte for byte: a single-engine book's refusals
    # (and the authority golden trace that records them) are unchanged by C16b.
    "ticket_engine_open": "one open ticket per market at a time",
    "ticket_opposite_side": "ticket_opposite_side: the other side is open on this market",
}
_MAX_TICKET_ENGINES = 64
_MAX_ENGINE_ID_CHARS = 128
_MAX_REFUSAL_REASON_CHARS = 64

# FU-REFUSAL-CODES: every STABLE message this module raises or returns as a refusal (literal
# KalshiBookError text, can_open's returns, the reversal preflight refusals, the C16b ticket
# messages). An attribution row may carry one of these verbatim; tests/test_kalshi_book_refusal_codes.py
# scans this file so the set cannot drift from the raise sites. No amount, ticker or free text.
_STABLE_REFUSAL_MESSAGES = frozenset(m for m in (
    # can_open (and the pre-can_open cash check in _buy and flatten_and_reverse)
    "kill file or halt active",
    "exceeds per-order loss cap",
    "exceeds max open tickets",
    "exceeds cluster exposure cap",
    "exceeds cumulative experiment loss cap",
    "insufficient cash including fee",
    "below cash floor",
    # flatten_and_reverse preflight
    "no open ticket for that client id",
    "second reversal on market refused",
    "market locked by reversal",
    "exit_count must equal reconciled remaining count",
    "reversal_count out of bounds",
    "invalid reversal price or fee",
    # literal KalshiBookError messages
    "expiration_ts must be positive int unix seconds",
    "limits required",
    "cash_cents must be a nonnegative int",
    "prior_realized_cents must be an int",
    "invalid reversal cumulative fill",
    "missing or invalid actual fill price/fee",
    "missing reversal fill identity/count",
    "fill timestamp lacks timezone",
    "conflicting venue fill identity",
    "inconsistent fill timestamps",
    "cash_cents must be an int",
    "incumbent_engine_id must be a named engine id",
    "engine_ids must be a collection of engine ids",
    "too many ticket engines",
    "engine_ids must be named engine ids",
    "no open ticket to carve for that client id",
    "carve share outside the ticket",
    "leg share invalid",
    "leg client id already open",
    "new entry attribution invalid",
    "price_cents out of bounds",
    "count must be positive",
    "fee_per_contract_cents must be nonnegative",
    "cluster_id must be a nonnegative int",
    "count must be positive on the 0.01 grid",
    "count out of bounds for this ticket",
    "exit_price_cents out of bounds",
    "predetermined exit id invalid or already used",
    "transaction_id invalid",
    *_TICKET_REFUSAL_MESSAGES.values(),
) if m.isascii() and len(m) <= _MAX_REFUSAL_REASON_CHARS)


def _refusal_reason(exc: BaseException) -> str:
    """The attribution reason for a refused or failed entry: a KalshiBookError whose text is exactly
    one of _STABLE_REFUSAL_MESSAGES records that text; anything else (dynamic text, an
    AccountRiskRefused passthrough, any other exception) records its class name, as before. Bounded
    to 64 ASCII characters; no allocation beyond the returned string."""
    if isinstance(exc, KalshiBookError):
        try:
            message = str(exc)
        except Exception:
            message = None
        if message in _STABLE_REFUSAL_MESSAGES:
            return message
    return type(exc).__name__.encode("ascii", "replace").decode("ascii")[:_MAX_REFUSAL_REASON_CHARS]


def _zero_fill_retry_id(client_id: str) -> str:
    """The one zero-fill retry's client id: deterministic in the entry's own id."""
    return "lb-r1-" + hashlib.sha256(client_id.encode()).hexdigest()[:24]


def client_send_started(client, client_id: str) -> bool | None:
    """H2a3 fix g: the send state machine's answer for client_id, never the exception's class.
    True once the client COMMITTED a send state for the id (the write-ahead SENT, journaled as the
    request leaves, after signing, fix h; or any later state); False when the client keeps a send
    journal (a _records dict, KalshiLive's shape) holding no committed send state for the id, which
    proves nothing reached the venue; None when the client keeps no send journal, so nothing is
    proven and the caller keeps the ambiguous side. Fix h: _owned membership alone is not a send.
    KalshiLive commits _records only after the row is durable, and a SENT whose journal write fails
    marks _owned UNKNOWN with no HTTP call ever issued. One dict read, no I/O."""
    records = getattr(client, "_records", None)
    if not isinstance(records, dict):
        return None
    record = records.get(client_id)
    return bool(isinstance(record, dict) and record.get("state"))


def _ticket_refusal(code: str) -> KalshiBookError:
    """C16b: the per-(market, engine) rule's refusal. Stays a plain KalshiBookError (callers and the
    golden trace key on the class name) and carries its stable reason in `code`."""
    exc = KalshiBookError(_TICKET_REFUSAL_MESSAGES[code])
    exc.code = code
    return exc


def _reversal_preflight_refusal(exc: KalshiBookError, code: str | None) -> KalshiBookError:
    """H1c: marks a flatten_and_reverse refusal raised before any journal record exists, so the
    caller may fall back to a plain exit. Class and message stay unchanged; `code` is stable."""
    exc.reversal_preflight = True
    if code is not None:
        exc.code = code
    return exc


class KalshiExitCashRefused(KalshiBookError):
    """KalshiBook.exit's pre-send cash refusal: raised before any exit id exists or the venue is
    touched, so a caller may retry once at a count that fits without ever sending twice."""

    def __init__(self, count: int, need_cents: int, free_cents: int, per_contract_cents: int) -> None:
        super().__init__(f"insufficient cash for exit including fee "
                         f"(count={count} need={need_cents}c free={free_cents}c)")
        self.count = count
        self.need_cents = need_cents
        self.free_cents = free_cents
        self.per_contract_cents = per_contract_cents


class KalshiBook:
    def __init__(self, client: KalshiLive, limits: KalshiLimits, cash_cents: int,
                prior_realized_cents: int = 0, *, account_risk=None) -> None:
        if not isinstance(limits, KalshiLimits):
            raise KalshiBookError("limits required")
        if type(cash_cents) is not int or cash_cents < 0:
            raise KalshiBookError("cash_cents must be a nonnegative int")
        if type(prior_realized_cents) is not int:
            raise KalshiBookError("prior_realized_cents must be an int")
        self.client = client
        self.account_risk = account_risk or getattr(client, "account_risk", None) or AccountRiskLedger()
        self.risk_policy = limits.risk_policy or DEFAULT_POLICY
        self._risk_requests = {}
        self._risk_failed = False
        self._entry_stop = None
        self.attribution_source = None
        self.entry_attributions = {}
        # C16b: open tickets are one per (market, engine). Only an engine id named in
        # ticket_engine_ids holds its own slot; any other id (none, unknown, kalshi_direct,
        # kalshi_reversal, a rebound strategy) is the incumbent's, so a book that names none keeps
        # the one-ticket-per-market rule exactly. set_ticket_engines is the only writer.
        self.incumbent_engine_id = "incumbent"
        self.ticket_engine_ids: frozenset[str] = frozenset()
        # client_id -> (ticker, side_yes, slot engine) for entries sent and not yet resolved, so two
        # engines' concurrent sends cannot both pass the rule; bounded by the sends in flight.
        self._entries_in_flight: dict[str, tuple[str, bool, str]] = {}
        if isinstance(client, KalshiLive):
            client._risk_book = self
        self.limits = limits
        self.cash_cents = cash_cents
        self.reserved_cents = 0
        self.open_tickets: dict[str, Ticket] = {}  # client_id -> Ticket
        # client_id -> immutable (count, cost, fee) of a fixed-size (fixed_count) ticket. Membership
        # is what marks a ticket fixed-size; every other ticket keeps origin/main's accounting.
        self._exit_basis: dict[str, tuple] = {}
        # A Decimal-count entry is a fixed_count entry unless the book's owner opts out. The Dark
        # Horse lane sends its own fixed-point IOCs and opts out, so its sends, fees, ledger rows
        # and recovery stay origin/main's byte for byte.
        self.fixed_size_entries = True
        self.settled_rows: list[dict[str, Any]] = []
        self.ledger_rows: list[dict[str, Any]] = []
        self.realized_cents = 0
        self.prior_realized_cents = prior_realized_cents
        self.halted = False
        self.exit_fills_contracts = 0
        self.exit_pnl_cents = 0
        self.reversal_intents = 0
        self.reversal_fills = 0
        self.reversal_refused = 0
        self.reversal_unknown = 0
        self._reversals: dict[str, dict[str, Any]] = {}
        # H1c: reversal client id -> its latest unpersisted ticket-ledger row; bounded by _reversals.
        self._pending_reversal_rows: dict[str, dict[str, Any]] = {}
        # H2a2: predetermined exit ids this book has sent (one per mode-2 exit attempt).
        self._predetermined_exit_ids: set[str] = set()

    @property
    def execution_locks(self) -> dict[str, str]:
        return {r["old"]["ticker"]: cid for cid, r in self._reversals.items() if r["locked"]}

    def status(self) -> dict[str, Any]:
        return {"price_basis_counts": {basis: sum(row.get("price_basis") == basis for row in self.ledger_rows)
                                        for basis in ("fill", "intent")},
                "reversals": {"intents": self.reversal_intents, "fills": self.reversal_fills,
                              "refused": self.reversal_refused, "unknown": self.reversal_unknown}}

    def _latch_entry_stop(self, cause: str):
        """Keep the first cause of this book's permanent entry halt."""
        self._risk_failed = True
        if self._entry_stop is None:
            if not isinstance(cause, str) or cause not in _ENTRY_STOP_CAUSES:
                cause = "unknown"
            assert cause in _ENTRY_STOP_CAUSES
            self._entry_stop = {
                "cause": cause,
                "at_ns": time.time_ns(),
            }

    async def flatten_and_reverse(self, client_id: str, exit_price: int, exit_count: Decimal,
                                  reversal_count: Decimal, fee: Decimal, reason: str) -> dict[str, Any]:
        """One inert, explicitly invoked IOC. `fee` is the reversal leg's total reserve fee.

        The live journal row holds both ticket snapshots as one transaction. Actual fills,
        including actual fees, must be known before releasing the market execution lock.
        No caller in the strategy or engine enables this operation.
        """
        ticket = self.open_tickets.get(client_id)
        q = _fixed_count(str(exit_count))
        r = _fixed_count(str(reversal_count))
        try:
            fee = Decimal(str(fee))
            valid_fee = fee.is_finite() and fee >= 0
        except Exception:
            valid_fee = False
        refusal = code = None
        if ticket is None:
            refusal, code = "no open ticket for that client id", "no_open_ticket"
        elif ticket.kind == "reversal" or any(
                entry["old"]["ticker"] == ticket.ticker and Decimal(entry["processed"]) > Decimal(entry["q"])
                for entry in self._reversals.values()):
            refusal, code = "second reversal on market refused", "second_reversal"
        elif ticket.ticker in self.execution_locks:
            refusal, code = "market locked by reversal", "market_locked"
        elif self.halted:
            refusal, code = "kill file or halt active", "halted"
        elif q is None or q <= 0 or q != Decimal(str(ticket.count)):
            refusal, code = "exit_count must equal reconciled remaining count", "exit_count_mismatch"
        elif r is None or r <= 0 or q + r > 100_000:
            refusal, code = "reversal_count out of bounds", "reversal_count_bounds"
        elif type(exit_price) is not int or not 1 <= exit_price <= 99 or not valid_fee:
            refusal, code = "invalid reversal price or fee", "invalid_price_or_fee"
        if refusal is not None:
            self.reversal_refused += 1
            raise _reversal_preflight_refusal(KalshiBookError(refusal), code)
        reserve = int((r * (100 - exit_price) + fee).to_integral_value(rounding=ROUND_CEILING))
        if reserve > self.cash_cents - self.reserved_cents:
            self.reversal_refused += 1
            raise _reversal_preflight_refusal(KalshiBookError("insufficient cash including fee"),
                                              "insufficient_cash")
        # C16a-b: on a shared (partitioned) client a probe's unresolved order would make
        # place_ioc_buy refuse this leg AFTER its write-ahead SENT, leaving the reversal UNKNOWN and
        # locked with nothing sent; refuse it here instead, before any id, attribution or journal
        # row, as a marked preflight (unresolved_orders falls back to a plain exit; market_locked stays
        # a rejected reversal, as the driver treats it today). None on a flag-off client.
        blocker = self.client.shared_send_blocker(ticket.ticker) if isinstance(self.client, KalshiLive) else None
        if blocker is not None:
            self.reversal_refused += 1
            raise _reversal_preflight_refusal(
                KalshiBookError(f"shared client would refuse the reversal leg: {blocker}"), blocker)
        cid = "lr-" + secrets.token_hex(12)
        # C16b: the reversal leg keeps the originating ticket's engine identity, so the new ticket
        # holds that engine's slot; kalshi_reversal is only a marker in the inputs, never an engine id.
        origin_engine_id = (ticket.attribution.get("engine_id")
                            if isinstance(ticket.attribution, dict) else None)
        if not isinstance(origin_engine_id, str) or not origin_engine_id or origin_engine_id == "unknown":
            origin_engine_id = self.incumbent_engine_id
        engine_revision = None
        try:
            source = self.attribution_source() if self.attribution_source else {}
            revision = source.get("engine_revision")
            if source.get("engine_id") == origin_engine_id and valid_engine_revision(revision):
                engine_revision = revision
        except Exception:
            # Current metadata is optional and cannot prevent a reversal.
            pass
        attribution = new_attribution(
            ticker=ticket.ticker, side_yes=not ticket.side_yes, price_cents=100 - exit_price,
            count=str(r), cluster_minute=ticket.cluster_id, reason=reason,
            engine_id=origin_engine_id, policy_digest=policy_digest(self.risk_policy),
            engine_revision=engine_revision,
            account=execution_account(self.client),
            inputs={"reversal_marker": "kalshi_reversal", "reversal_of": ticket.client_id})
        if isinstance(self.client, KalshiLive):
            self.client.record_attribution(attribution, "proposal", cid)
        try:
            self._check_reversal_slot(ticket)
        except KalshiBookError as exc:
            # Refused whole before any reservation, journal transition or send: no flatten leg either.
            self.reversal_refused += 1
            _reversal_preflight_refusal(exc, getattr(exc, "code", None))
            if isinstance(self.client, KalshiLive):
                self.client.record_attribution(attribution, "rejected_or_unknown", cid, reason=exc.code)
            raise
        if not isinstance(self.client, KalshiLive):
            positions = {t.ticker: (t.cluster_id, t.cost_cents) for t in self.open_tickets.values()}
            self.account_risk.reserve(cid, ticket.ticker, ticket.cluster_id, reserve,
                                      cash_cents=self.cash_cents,
                                      open_cost_cents=self.worst_case_open_loss_cents(),
                                      positions=positions, policy=self.risk_policy)
        original = dict(asdict(ticket), count=str(ticket.count))
        reversal = {"old": original, "new_id": "rt-" + secrets.token_hex(12),
                    "q": str(q), "r": str(r), "processed": "0", "levels": [], "fill_updates": 0,
                    "reserve": reserve, "locked": True, "submitted": False,
                    "reason": reason[:400] if isinstance(reason, str) else "",
                    "old_after": original, "new_after": None,
                    "cash_delta": 0, "pnl": 0, "unknown": False}
        self.client._records[cid] = {
            "ticker": ticket.ticker, "side_yes": not ticket.side_yes,
            "price_cents": 100 - exit_price, "count": _count_number(q + r),
            "venue_order_id": None, "fill_count": 0, "reversal": reversal,
            "attribution": attribution}
        # Write-ahead: neither a send nor an in-memory close precedes this durable intent.
        self.client._transition(cid, "SENT", "reversal intent and cash reservation")
        self._reversals[cid] = reversal
        self.reserved_cents += reserve
        self.reversal_intents += 1
        try:
            reply = await self.client.place_ioc_buy(ticket.ticker, not ticket.side_yes,
                                                   100 - exit_price, q + r, cid)
            fills = await self._venue_fills(self.client._records[cid].get("sent_ts_ns")) if Decimal(str(reply["fill_count"])) else []
            return self.process_reversal_fills(cid, reply["fill_count"], fills,
                                               self.client._owned[cid])
        except AccountRiskRefused:
            self.reversal_refused += 1
            self.client._transition(cid, "GONE", "account risk refused before send")
            self.process_reversal_fills(cid, 0, [], "GONE")
            raise
        except BaseException:
            record = self.client._records[cid]
            if self.client._owned.get(cid) == "GONE" and not record.get("fill_count"):
                self.process_reversal_fills(cid, 0, [], "GONE")
            else:
                self._mark_reversal_unknown(cid)
            raise

    def _mark_reversal_unknown(self, cid: str) -> None:
        reversal = dict(self.client._records[cid]["reversal"], unknown=True, locked=True)
        if not self._reversals[cid].get("unknown"):
            self.reversal_unknown += 1
        if not self._reversals[cid]["locked"]:
            self.reserved_cents += reversal["reserve"]
        # An interrupted snapshot publication may have a newer durable split than memory.
        # Preserve memory's processed watermark so an in-process retry still applies it.
        self._reversals[cid] = dict(self._reversals[cid], unknown=True, locked=True)
        self.client._transition(cid, "UNKNOWN", "reversal exposure unresolved", reversal=reversal)

    def process_reversal_fills(self, cid: str, cumulative, fills: list[dict[str, Any]],
                               state: str = "UNKNOWN") -> dict[str, Any]:
        try:
            return self._process_reversal_fills(cid, cumulative, fills, state)
        except Exception:
            self._mark_reversal_unknown(cid)
            raise

    def _process_reversal_fills(self, cid: str, cumulative, fills: list[dict[str, Any]],
                                state: str) -> dict[str, Any]:
        """Apply authoritative cumulative fills once, using venue identities and fill levels.

        A stale cumulative update cannot roll back a later fill. Missing or contradictory
        details leave the write-ahead reservation locked for reconciliation of this same id.
        """
        previous = self._reversals[cid]
        f = _fixed_count(str(cumulative))
        q, r = Decimal(previous["q"]), Decimal(previous["r"])
        processed = Decimal(previous["processed"])
        if f is None or f > q + r:
            raise KalshiBookError("invalid reversal cumulative fill")
        if f < processed or (f == processed and not previous["locked"]):
            return previous
        record = self.client._records[cid]
        levels = {row["id"]: dict(row) for row in previous["levels"]}
        for fill in fills:
            if not ((record.get("venue_order_id") is not None and
                     fill.get("order_id") == record["venue_order_id"]) or fill.get("client_order_id") == cid):
                continue
            identity = fill.get("fill_id", fill.get("trade_id"))
            count = _fixed_count(str(fill.get("count_fp", fill.get("count"))))
            try:
                price, fees = _fill_level_basis(fill, record["side_yes"])
            except Exception as e:
                raise KalshiBookError("missing or invalid actual fill price/fee") from e
            if not isinstance(identity, str) or not identity or count is None or count <= 0:
                raise KalshiBookError("missing reversal fill identity/count")
            level = {"id": identity, "count": str(count), "price": str(price), "fee": str(fees)}
            if "created_time" in fill:
                stamp = datetime.fromisoformat(fill["created_time"].replace("Z", "+00:00"))
                if stamp.tzinfo is None:
                    raise KalshiBookError("fill timestamp lacks timezone")
                level["created_time"] = stamp.astimezone(timezone.utc).isoformat()
            if identity in levels and levels[identity] != level:
                raise KalshiBookError("conflicting venue fill identity")
            levels[identity] = level
        if any("created_time" in level for level in levels.values()):
            if not all("created_time" in level for level in levels.values()):
                raise KalshiBookError("inconsistent fill timestamps")
            levels = dict(sorted(levels.items(), key=lambda pair: (pair[1]["created_time"], pair[0])))
        if sum((Decimal(row["count"]) for row in levels.values()), Decimal(0)) != f:
            raise OrderStateUnknown(cid, "cumulative fill lacks matching actual fill levels")
        closed = Decimal(0)
        proceeds = new_cost = new_fee = Decimal(0)
        for level in levels.values():
            count, price, fees = (Decimal(level[key]) for key in ("count", "price", "fee"))
            close = min(count, q - closed)
            close_fee = fees * close / count
            proceeds += close * (100 - price) - close_fee
            new_cost += (count - close) * price + fees - close_fee
            new_fee += fees - close_fee
            closed += close
        cents = lambda value: int(value.quantize(Decimal(1), rounding=ROUND_HALF_UP))
        old = dict(previous["old"])
        cost_share = _integer_split(old["cost_cents"], q, closed)
        fee_share = _integer_split(old["fee_cents"], q, closed)
        old.update(count=str(q - closed), cost_cents=old["cost_cents"] - cost_share,
                   fee_cents=old["fee_cents"] - fee_share)
        new = None
        if f > q:
            new = asdict(Ticket(old["ticker"], not old["side_yes"], _count_number(f - q),
                                cents(new_cost), cents(new_fee), old["cluster_id"], previous["new_id"],
                                record["ts_ns"], record.get("venue_order_id"), previous["reason"],
                                "reversal", cid, price_basis="fill",
                                intent_price_cents=record["price_cents"],
                                price_cents=cents((new_cost - new_fee) / (f - q)),
                                attribution=attribution_or_unknown(record.get("attribution"))))
            new["count"] = str(f - q)
        locked = state not in {"FILLED", "PARTIAL", "GONE"}
        reversal = dict(previous, processed=str(f), levels=list(levels.values()),
                        fill_updates=previous.get("fill_updates", 0) + int(f > processed),
                        old_after=old if closed < q else None, new_after=new, locked=locked,
                        submitted=record["reversal"].get("submitted", True),
                        cash_delta=cents(proceeds) - cents(new_cost), pnl=cents(proceeds) - cost_share)
        # One fsynced row contains BOTH sides. Recovery never sees an isolated close.
        self.client._transition(cid, state, "atomic reversal fill split", reversal=reversal,
                                fill_count=_count_number(f))
        self._apply_reversal_snapshot(cid, reversal)
        return reversal

    def _apply_reversal_snapshot(self, cid: str, reversal: dict[str, Any]) -> None:
        previous = self._reversals[cid]
        tickets = dict(self.open_tickets)
        tickets.pop(reversal["old"]["client_id"], None)
        tickets.pop(reversal["new_id"], None)
        for row in (reversal["old_after"], reversal["new_after"]):
            if row is not None:
                tickets[row["client_id"]] = Ticket(**dict(row, count=Decimal(str(row["count"]))))
        self.open_tickets = tickets
        self.cash_cents += reversal["cash_delta"] - previous["cash_delta"]
        self.realized_cents += reversal["pnl"] - previous["pnl"]
        self.reserved_cents += reversal["reserve"] * (int(reversal["locked"]) - int(previous["locked"]))
        advanced = Decimal(reversal["processed"]) > Decimal(previous["processed"])
        if advanced:
            self.reversal_fills += 1
        self._reversals[cid] = reversal
        self.ledger_rows.append({"kind": "reversal", "client_id": cid, "transaction": reversal,
                                 "price_basis": "fill",
                                 "intent_price_cents": self.client._records[cid]["price_cents"]})
        if advanced:
            # H1c: only a snapshot that moves the processed watermark carries new economics, so a
            # repeated reconcile of a locked reversal never re-queues the same row.
            self._pending_reversal_rows[cid] = self._reversal_ledger_row(cid, reversal)
        if not reversal["locked"]:
            try:
                self.account_risk.finish_reversal(
                    cid, reversal["old"]["client_id"], reversal["new_id"],
                    (reversal["old_after"] or {}).get("cost_cents", 0),
                    (reversal["new_after"] or {}).get("cost_cents", 0),
                    old_count=(reversal["old_after"] or {}).get("count", 0),
                    new_count=(reversal["new_after"] or {}).get("count", 0))
            except Exception:
                self._latch_entry_stop("finish_reversal_failed")

    def _reversal_ledger_row(self, cid: str, reversal: dict[str, Any]) -> dict[str, Any]:
        """H1c: the persisted kalshi-tickets.jsonl form of one reversal snapshot: the in-memory
        ledger row plus the transition's ts_ns, the original ticket's settlement minute and
        attribution. kind stays "reversal", which no startup exit/settle scan reads."""
        record = self.client._records.get(cid) or {}
        ts_ns = record.get("ts_ns")
        old = reversal["old"]
        return {"kind": "reversal", "client_id": cid, "transaction": reversal,
                "price_basis": "fill", "intent_price_cents": record.get("price_cents"),
                "ts_ns": ts_ns if type(ts_ns) is int and ts_ns > 0 else time.time_ns(),
                "settlement_minute": old.get("cluster_id", -1),
                "attribution": attribution_or_unknown(old.get("attribution"))}

    def drain_reversal_rows(self) -> list[dict[str, Any]]:
        """H1c: the reversal snapshots not yet persisted to the ticket ledger, in insertion order,
        and clears them. The caller persists each through SettlementPoller.record_reversal."""
        rows = list(self._pending_reversal_rows.values())
        self._pending_reversal_rows.clear()
        return rows

    def queue_unpersisted_reversals(self, persisted: dict[str, Any]) -> int:
        """H1c restart repair: queue the row of every recovered reversal whose journal processed
        watermark (> 0) exceeds the greatest one persisted in the ticket ledger (`persisted`,
        client id -> processed). A clean restart queues nothing. Returns the number queued."""
        queued = 0
        for cid, reversal in self._reversals.items():
            try:
                processed = Decimal(str(reversal.get("processed", "0")))
                watermark = Decimal(str(persisted.get(cid, "0")))
            except Exception:
                continue
            if processed > 0 and processed > watermark:
                self._pending_reversal_rows[cid] = self._reversal_ledger_row(cid, reversal)
                queued += 1
        return queued

    async def _venue_fills(self, since_ns) -> list[dict[str, Any]]:
        """X3b: a live KalshiLive client answers from the complete paged walk bounded by the
        order's send stamp (fails closed on an incomplete walk); any other client keeps its own
        fills() reader."""
        if isinstance(self.client, KalshiLive):
            return await self.client.fills_complete(since_ns)
        return await self.client.fills()

    async def reconcile_reversals(self) -> None:
        """Resolve original physical orders only; never resubmit an ambiguous intent."""
        await self.client.reconcile()
        for cid, reversal in list(self._reversals.items()):
            if not reversal["locked"]:
                continue
            try:
                record = self.client._records[cid]
                fills = await self._venue_fills(record.get("sent_ts_ns")) if record.get("fill_count") else []
                self.process_reversal_fills(cid, record.get("fill_count", 0), fills,
                                            self.client._owned[cid])
            except Exception:
                self._mark_reversal_unknown(cid)
                raise

    def apply_limits(self, limits: KalshiLimits) -> None:
        """Use new caps for future opens without changing existing tickets."""
        if not isinstance(limits, KalshiLimits):
            raise KalshiBookError("limits required")
        self.limits = limits
        self.risk_policy = limits.risk_policy or DEFAULT_POLICY

    def set_cash(self, cash_cents: int) -> None:
        """Refresh cash without consuming or underfunding an in-flight reservation."""
        if type(cash_cents) is not int:
            raise KalshiBookError("cash_cents must be an int")
        self.cash_cents = max(0, self.reserved_cents, cash_cents)

    @property
    def realized_today_cents(self) -> int:
        """Realized P&L for the current UTC day across every run of this venue+symbol: prior
        runs' ledger total plus this run's own. The daily loss cap is enforced against this,
        never against realized_cents alone, so a restart cannot reset it."""
        return self.prior_realized_cents + self.realized_cents

    def cluster_exposure_cents(self, cluster_id: int) -> int:
        return sum(t.cost_cents for t in self.open_tickets.values() if t.cluster_id == cluster_id)

    def worst_case_open_loss_cents(self) -> int:
        return sum(t.cost_cents for t in self.open_tickets.values())

    def set_ticket_engines(self, incumbent_engine_id: str, engine_ids) -> None:
        """C16b: name the incumbent and the co-hosted engines that each hold their own open ticket
        per market. Fails closed: a malformed or oversized input raises and changes nothing.
        Existing tickets keep their attribution; only the slot they map to follows the new names."""
        def valid(engine_id) -> bool:
            return (isinstance(engine_id, str) and 0 < len(engine_id) <= _MAX_ENGINE_ID_CHARS
                    and engine_id != "unknown")
        if not valid(incumbent_engine_id):
            raise KalshiBookError("incumbent_engine_id must be a named engine id")
        if isinstance(engine_ids, (str, bytes)) or not hasattr(engine_ids, "__iter__"):
            raise KalshiBookError("engine_ids must be a collection of engine ids")
        names = []
        for engine_id in engine_ids:
            if len(names) >= _MAX_TICKET_ENGINES:
                raise KalshiBookError("too many ticket engines")
            if not valid(engine_id):
                raise KalshiBookError("engine_ids must be named engine ids")
            names.append(engine_id)
        self.incumbent_engine_id = incumbent_engine_id
        self.ticket_engine_ids = frozenset(names)

    def ticket_engine_id(self, attribution) -> str:
        """The engine whose slot a ticket holds: its attribution's engine id when this book names it,
        the incumbent otherwise (no attribution, no engine id, or an id this book never named)."""
        engine_id = attribution.get("engine_id") if isinstance(attribution, dict) else None
        if isinstance(engine_id, str) and engine_id in self.ticket_engine_ids:
            return engine_id
        return self.incumbent_engine_id

    def _check_ticket_slot(self, ticker: str, side_yes: bool, engine_id: str) -> None:
        """C16b: one open ticket per (market, engine); open and in-flight entries both count. The
        same-engine refusal is checked first and keeps the legacy message, so a single-engine book
        (every ticket the incumbent's) refuses exactly as before. Any engine's opposite side refuses.
        One pass over the open tickets, as before; no allocation beyond the market's own entries."""
        held = [(t.side_yes, self.ticket_engine_id(t.attribution))
                for t in self.open_tickets.values() if t.ticker == ticker]
        held.extend((side, engine) for market, side, engine in self._entries_in_flight.values()
                    if market == ticker)
        # C16b: a locked reversal is its new leg in flight (the target side, the originating
        # engine) until it completes or resolves, so no entry can land beside or opposite it.
        held.extend((not r["old"]["side_yes"], self.ticket_engine_id(r["old"].get("attribution")))
                    for r in self._reversals.values() if r["locked"] and r["old"]["ticker"] == ticker)
        if any(engine == engine_id for _, engine in held):
            raise _ticket_refusal("ticket_engine_open")
        if any(bool(side) != bool(side_yes) for side, _ in held):
            raise _ticket_refusal("ticket_opposite_side")

    def _check_reversal_slot(self, ticket: Ticket) -> None:
        """C16b: a reversal's new leg (the opposite side, the originating ticket's engine) obeys the
        opposite-side rule as an entry does: while ANOTHER engine holds, open or in flight, the side
        being flattened on this market, the reversal is refused whole. The flattened ticket itself is
        excluded (it closes in the same transaction), so a single-engine book is never refused here.
        One pass over the open tickets and the in-flight entries; no allocation."""
        engine_id = self.ticket_engine_id(ticket.attribution)
        for other in self.open_tickets.values():
            if (other.ticker == ticket.ticker and other.client_id != ticket.client_id
                    and bool(other.side_yes) == bool(ticket.side_yes)
                    and self.ticket_engine_id(other.attribution) != engine_id):
                raise _ticket_refusal("ticket_opposite_side")
        for market, side, other_engine in self._entries_in_flight.values():
            if market == ticket.ticker and bool(side) == bool(ticket.side_yes) and other_engine != engine_id:
                raise _ticket_refusal("ticket_opposite_side")

    def can_open(self, cost_cents: int, cluster_id: int) -> str | None:
        """None if the order clears every cap; the refusal reason (a stable substring) otherwise."""
        if self.halted or self._risk_failed:
            return "kill file or halt active"
        if cost_cents > self.limits.max_loss_per_order_cents:
            return "exceeds per-order loss cap"
        if len(self.open_tickets) >= self.limits.max_open_tickets:
            return "exceeds max open tickets"
        if self.cluster_exposure_cents(cluster_id) + cost_cents > self.limits.max_cluster_exposure_cents:
            return "exceeds cluster exposure cap"
        cumulative_cents = max(0, -self.realized_today_cents) + self.worst_case_open_loss_cents() + cost_cents
        if cumulative_cents > self.limits.max_cumulative_loss_cents:
            return "exceeds cumulative experiment loss cap"
        if cost_cents > self.cash_cents - self.reserved_cents:
            return "insufficient cash including fee"
        if self.cash_cents - self.reserved_cents - cost_cents < self.limits.cash_floor_cents:
            return "below cash floor"
        return None

    # ------------------------------------------------ COMBINE-S1: combined legs, no network
    def open_headroom_cents(self, cluster_id: int) -> int:
        """The largest cost can_open admits now on this cluster (0 when it admits none). O(tickets)."""
        if self.halted or self._risk_failed or len(self.open_tickets) >= self.limits.max_open_tickets:
            return 0
        free = self.cash_cents - self.reserved_cents
        room = min(self.limits.max_loss_per_order_cents,
                   self.limits.max_cluster_exposure_cents - self.cluster_exposure_cents(cluster_id),
                   self.limits.max_cumulative_loss_cents
                   - max(0, -self.realized_today_cents) - self.worst_case_open_loss_cents(),
                   free, free - self.limits.cash_floor_cents)
        return max(0, room)

    def slot_refusal(self, ticker: str, side_yes: bool, attribution=None) -> str | None:
        """The C16b ticket-slot refusal code a leg adopted here would meet, or None."""
        try:
            self._check_ticket_slot(ticker, side_yes, self.ticket_engine_id(attribution))
        except KalshiBookError as exc:
            return getattr(exc, "code", "ticket_engine_open")
        return None

    def carve_ticket(self, wire_client_id: str, keep_count, keep_cost_cents: int, keep_fee_cents: int,
                     attribution=None) -> Ticket | None:
        """The anchor book keeps only its own share of a combined fill: the ticket, its fixed-size
        basis and its buy ledger row shrink to (keep_count, keep_cost, keep_fee) and the carved cost
        returns to this book's cash (the other legs' books pay it through adopt_leg_ticket), so this
        book's cluster exposure falls by exactly the carved cost. A zero share removes the ticket.
        Nothing reserved remains after a completed buy, so reserved_cents is unchanged. No network,
        no account-risk write (AccountRiskLedger.split_entry moves the risk). Raises on a share
        larger than the ticket or on a missing ticket, and changes nothing then."""
        ticket = self.open_tickets.get(wire_client_id)
        if ticket is None:
            raise KalshiBookError("no open ticket to carve for that client id")
        keep = Decimal(str(keep_count))
        if (not keep.is_finite() or keep < 0 or keep > Decimal(str(ticket.count))
                or type(keep_cost_cents) is not int or not 0 <= keep_cost_cents <= ticket.cost_cents
                or type(keep_fee_cents) is not int or not 0 <= keep_fee_cents <= keep_cost_cents
                or (not keep and keep_cost_cents)):
            raise KalshiBookError("carve share outside the ticket")
        self.cash_cents += ticket.cost_cents - keep_cost_cents
        for row in reversed(self.ledger_rows):
            if row.get("kind") == "buy" and row.get("client_id") == wire_client_id:
                row.update(count=_count_number(keep), cost_cents=keep_cost_cents, fee_cents=keep_fee_cents,
                           combined=True)
                break
        if not keep:
            del self.open_tickets[wire_client_id]
            self._exit_basis.pop(wire_client_id, None)
            return None
        ticket.count = _count_number(keep)
        ticket.cost_cents = keep_cost_cents
        ticket.fee_cents = keep_fee_cents
        ticket.physical_client_id = wire_client_id  # record_buy persists the share as combined (restart reads it)
        if wire_client_id in self._exit_basis:
            self._exit_basis[wire_client_id] = (ticket.count, keep_cost_cents, keep_fee_cents)
        if attribution is not None:
            ticket.attribution = attribution
        return ticket

    def adopt_leg_ticket(self, ticker: str, side_yes: bool, count, cost_cents: int, fee_cents: int,
                         cluster_id: int, client_id: str, now_ns: int, reason: str = "", *,
                         price_cents: int | None = None, intent_price_cents: int | None = None,
                         price_basis: str = "intent", venue_order_id: str | None = None,
                         physical_client_id: str | None = None, attribution=None,
                         fixed_size: bool = False) -> Ticket:
        """A leg's share of a combined fill another book sent: an open ticket here under the leg's
        own client id, its cost debited from this book's cash, with no network call and no
        account-risk write. Refuses (KalshiBookError, nothing changed) a nonpositive share, a
        client id already open, or a ticket slot the C16b rule refuses."""
        quantity = Decimal(str(count))
        if (not quantity.is_finite() or quantity <= 0 or type(cost_cents) is not int or cost_cents < 0
                or type(fee_cents) is not int or not 0 <= fee_cents <= cost_cents
                or type(cluster_id) is not int or cluster_id < 0):
            raise KalshiBookError("leg share invalid")
        if client_id in self.open_tickets:
            raise KalshiBookError("leg client id already open")
        self._check_ticket_slot(ticker, side_yes, self.ticket_engine_id(attribution))
        ticket = Ticket(ticker, side_yes, _count_number(quantity), cost_cents, fee_cents, cluster_id, client_id,
                        now_ns, venue_order_id=venue_order_id, reason=reason[:400] if isinstance(reason, str) else "",
                        physical_client_id=physical_client_id, price_basis=price_basis,
                        intent_price_cents=intent_price_cents, price_cents=price_cents)
        if attribution is not None:
            ticket.attribution = attribution
        self.cash_cents -= cost_cents
        self.open_tickets[client_id] = ticket
        if fixed_size:
            self._exit_basis[client_id] = (ticket.count, cost_cents, fee_cents)
        self.ledger_rows.append({"kind": "buy", "ticker": ticker, "side_yes": side_yes, "count": ticket.count,
                                 "cost_cents": cost_cents, "client_id": client_id, "ts_ns": now_ns,
                                 "reason": ticket.reason, "price_basis": price_basis,
                                 "price_cents": price_cents, "fee_cents": fee_cents, "combined": True,
                                 "physical_client_id": physical_client_id})
        return ticket

    async def buy(self, ticker: str, side_yes: bool, price_cents: int, count: int | Decimal,
                  fee_per_contract_cents: int, cluster_id: int, client_id: str,
                  now_ns: int | None = None, reason: str = "", *,
                  expiration_ts: int | None = None) -> Ticket | None:
        """expiration_ts (H2a2 mode 2 only): the venue-side expiry, unix seconds, sent with this
        order and its one zero-fill retry. None (every other caller) sends exactly as before."""
        source = self.attribution_source() if self.attribution_source else {}
        attribution = self.entry_attributions.pop(client_id, None)
        if attribution is None:
            engine_revision = None
            try:
                revision = source.get("engine_revision")
                if valid_engine_revision(revision):
                    engine_revision = revision
            except Exception:
                # Preserve the existing source and identity reads below.
                pass
            attribution = new_attribution(
                ticker=ticker, side_yes=side_yes, price_cents=price_cents, count=count,
                cluster_minute=cluster_id, reason=reason or source.get("reason", "entry"),
                engine_id=source.get("engine_id", "kalshi_direct"),
                engine_revision=engine_revision,
                policy_digest=source.get("policy_digest") or policy_digest(self.risk_policy),
                account=execution_account(self.client),
                # The client order id is unique for live placement and stable
                # for replay, so the same proposal keeps one decision identity.
                deterministic_key=client_id,
                inputs={"fee_per_contract_cents": fee_per_contract_cents,
                        "cash_cents": self.cash_cents, "reserved_cents": self.reserved_cents},
                sizing={"cash_cents": self.cash_cents, "reserved_cents": self.reserved_cents,
                        "fee_per_contract_cents": fee_per_contract_cents,
                        "open_cost_cents": self.worst_case_open_loss_cents()})
        attribution = scope_attribution(attribution, execution_account(self.client))
        if attribution["status"] != "known":
            raise KalshiBookError("new entry attribution invalid")
        if isinstance(self.client, KalshiLive):
            self.client.record_attribution(attribution, "proposal", client_id,
                                           requested_count=str(count))
            self.client._entry_attributions[client_id] = attribution
        guard_ids = (client_id, _zero_fill_retry_id(client_id))
        guards_before = tuple(self._entries_in_flight.get(guard_id) for guard_id in guard_ids)
        try:
            ticket = await self._buy(ticker, side_yes, price_cents, count,
                                     fee_per_contract_cents, cluster_id, client_id, now_ns, reason,
                                     attribution=attribution, expiration_ts=expiration_ts)
        except BaseException as exc:
            # C16b: an entry that raised after its send never published a ticket, so the guard THIS
            # call registered (its own or its zero-fill retry's) is released here; a guard another
            # call holds is left alone, and one _buy already released is a no-op.
            for guard_id, before in zip(guard_ids, guards_before):
                held = self._entries_in_flight.get(guard_id)
                if held is not None and held is not before:
                    del self._entries_in_flight[guard_id]
            if isinstance(self.client, KalshiLive):
                self.client._entry_attributions.pop(client_id, None)
                if not self.client._attribution_failed:
                    self.client.record_attribution(attribution, "rejected_or_unknown", client_id,
                                                   reason=_refusal_reason(exc))
            raise
        if ticket is not None:
            ticket.attribution = attribution
        return ticket

    def _client_sent(self, client_id: str) -> bool:
        """True once the client recorded any send state for client_id (write-ahead SENT onward),
        the same test the authority wrapper applies. False proves nothing reached the venue."""
        return client_id in getattr(self.client, "_owned", {}) or bool(
            getattr(self.client, "_records", {}).get(client_id, {}).get("state"))

    def _client_send_started(self, client_id: str) -> bool | None:
        """H2a3 fix g: client_send_started for this book's client."""
        return client_send_started(self.client, client_id)

    def _hedge_send_failed(self, client_id: str, reserve_cents: int, live_risk: bool,
                           exc: BaseException) -> None:
        """H2a3 fix h: _buy's exception handling when the mode-2 hedge transaction owns the call
        (expiration_ts given). Modes None and 1 never reach it, so their handling stays origin/main's.
        Fix g's rule, decided by the client's send state machine: once the send started, or for a
        BaseException, or with no send journal and a class not raised before the venue by
        construction, the outcome is ambiguous and the book latches. Otherwise nothing reached the
        venue: the reservation is released and the book stays open (fix d and e: a SubmissionRefused,
        or any class proven unsent, also resolves a non-live account reservation to zero)."""
        self.reserved_cents -= reserve_cents
        self._entries_in_flight.pop(client_id, None)
        started = self._client_send_started(client_id)
        typed = isinstance(exc, (AccountRiskRefused, SubmissionRefused))
        if started is True or not isinstance(exc, Exception) or (started is None and not typed):
            self._latch_entry_stop("hedge_send_unknown")
            return
        if not live_risk and not isinstance(exc, AccountRiskRefused):
            try:
                self.account_risk.resolve(client_id, 0)
            except Exception:
                pass  # a failed resolve keeps the reservation, which is the conservative side

    async def _buy(self, ticker: str, side_yes: bool, price_cents: int, count: int | Decimal,
                   fee_per_contract_cents: int, cluster_id: int, client_id: str,
                   now_ns: int | None = None, reason: str = "", *,
                   attribution=None, retry: bool = False,
                   expiration_ts: int | None = None,
                   decision_price_cents: int | None = None) -> Ticket | None:
        """Returns the opened Ticket, or None when the IOC filled zero contracts. Raises
        KalshiBookError before the venue is ever touched when a cap or existing position refuses it.
        decision_price_cents is internal: the one zero-fill retry receives the primary's pre-buffer
        price there, so its cash reservation takes the same fee step (AUTH-buy-feestep)."""
        now_ns = time.time_ns() if now_ns is None else now_ns
        if type(price_cents) is not int or not 1 <= price_cents <= 99:
            raise KalshiBookError("price_cents out of bounds")
        _check_expiration_ts(expiration_ts)
        if not retry or decision_price_cents is None:
            decision_price_cents = price_cents
        if not retry:
            price_cents = self.send_limit_cents(price_cents)
        quantity = _fixed_count(str(count)) if isinstance(count, Decimal) else _fixed_count(count)
        if quantity is None or quantity <= 0:
            raise KalshiBookError("count must be positive")
        if type(fee_per_contract_cents) is not int or fee_per_contract_cents < 0:
            raise KalshiBookError("fee_per_contract_cents must be nonnegative")
        if type(cluster_id) is not int or cluster_id < 0:
            raise KalshiBookError("cluster_id must be a nonnegative int")
        slot_engine_id = self.ticket_engine_id(attribution)
        self._check_ticket_slot(ticker, side_yes, slot_engine_id)
        reserve_fee_cents = self.reserve_fee_per_contract_cents(decision_price_cents, price_cents,
                                                                fee_per_contract_cents)
        reserve_cents = _entry_debit_cents(price_cents, quantity, reserve_fee_cents)
        if reserve_cents > self.cash_cents - self.reserved_cents:
            raise KalshiBookError("insufficient cash including fee")
        refusal = self.can_open(reserve_cents, cluster_id)
        if refusal is not None:
            raise KalshiBookError(refusal)
        live_risk = isinstance(self.client, KalshiLive)
        if not live_risk:
            positions = {}
            for ticket in self.open_tickets.values():
                minute, cost = positions.get(ticket.ticker, (ticket.cluster_id, 0))
                positions[ticket.ticker] = (minute, cost + ticket.cost_cents)
            try:
                self.account_risk.reserve(client_id, ticker, cluster_id, reserve_cents,
                                          cash_cents=self.cash_cents,
                                          open_cost_cents=self.worst_case_open_loss_cents(),
                                          positions=positions, policy=self.risk_policy, now_ns=now_ns)
            except AccountRiskRefused as exc:
                raise KalshiBookError(str(exc)) from exc
        self._risk_requests[client_id] = (reserve_cents, cluster_id)
        self._entries_in_flight[client_id] = (ticker, side_yes, slot_engine_id)
        self.reserved_cents += reserve_cents
        fixed_size = isinstance(count, Decimal) and self.fixed_size_entries
        # A fixed_count entry hands KalshiLive its model fee through a side channel, never a new
        # keyword: owners wrap place_ioc_buy with positional-only shims (Dark Horse, lanes), and
        # a keyword there raised TypeError and stranded the IOC. The call stays origin/main's.
        model_fees = getattr(self.client, "_entry_model_fees", None) if live_risk and fixed_size else None
        if model_fees is not None:
            model_fees[client_id] = fee_per_contract_cents
        try:
            reply = await self.client.place_ioc_buy(ticker, side_yes, price_cents, count, client_id,
                                                     **_expiry_kwargs(expiration_ts))
        except AccountRiskRefused as exc:
            # H2a3 fix h: only the mode-2 hedge (expiration_ts given) classifies by send state; the
            # handling below it, for modes None and 1, is origin/main's byte for byte.
            if expiration_ts is not None:
                self._hedge_send_failed(client_id, reserve_cents, live_risk, exc)
                raise
            self.reserved_cents -= reserve_cents
            self._entries_in_flight.pop(client_id, None)
            raise
        except BaseException as exc:
            if expiration_ts is not None:
                self._hedge_send_failed(client_id, reserve_cents, live_risk, exc)
                raise
            # The account ledger retains ambiguous exposure. Preserve the existing
            # local exit cash mechanics and halt only new entries here.
            self.reserved_cents -= reserve_cents
            self._latch_entry_stop("buy_send_failed")
            self._entries_in_flight.pop(client_id, None)
            raise
        finally:
            self._risk_requests.pop(client_id, None)
            if model_fees is not None:
                model_fees.pop(client_id, None)  # a send that never reached KalshiLive leaves none
        # C16b: the entry keeps its (market, engine) guard across every await below (a fill-price
        # lookup may yield) and releases it only on a zero fill or in the same step that publishes
        # its ticket; buy() releases it if anything here raises.
        self.reserved_cents -= reserve_cents
        filled = _book_count(reply["fill_count"])
        if filled == 0:
            self._entries_in_flight.pop(client_id, None)
            if not live_risk:
                self.account_risk.resolve(client_id, 0)
            definitive = (
                not reply.get("error") and not reply.get("not_found")
                and reply.get("status", "canceled") in ("canceled", "cancelled", "executed", "filled")
                and _book_count(reply.get("remaining_count", 0)) == 0
                and reply.get("client_order_id", client_id) == client_id
            )
            if (not retry and self.risk_policy.execution_zero_fill_retries == 1
                    and definitive and attribution is not None):
                retry_id = _zero_fill_retry_id(client_id)
                if live_risk:
                    self.client.record_attribution(attribution, "proposal", retry_id,
                                                   requested_count=str(count))
                    self.client._entry_attributions[retry_id] = attribution
                try:
                    return await self._buy(ticker, side_yes, price_cents, count,
                                           fee_per_contract_cents, cluster_id, retry_id,
                                           now_ns, reason, attribution=attribution, retry=True,
                                           expiration_ts=expiration_ts,
                                           decision_price_cents=decision_price_cents)
                except BaseException as exc:
                    if live_risk:
                        self.client._entry_attributions.pop(retry_id, None)
                        if not self.client._attribution_failed:
                            self.client.record_attribution(attribution, "rejected_or_unknown", retry_id,
                                                           reason=_refusal_reason(exc))
                    if expiration_ts is not None and (
                            (isinstance(exc, (SubmissionRefused, AccountRiskRefused, KalshiBookError))
                             and not self._client_sent(retry_id))
                            or (isinstance(exc, Exception) and self._client_send_started(retry_id) is False)):
                        # H2a3 fix e: the retry was refused before any send, so the primary's
                        # venue-confirmed zero fill is the whole outcome. The tag tells an authority
                        # wrapper to resolve this id to zero rather than mark it unknown. Fix g: any
                        # exception the send state machine proves unsent qualifies, whatever its class.
                        # Fix h: only the mode-2 hedge transaction's retry is tagged; modes None and 1
                        # raise exactly as origin/main does.
                        try:
                            exc.zero_fill_primary = client_id
                        except Exception:
                            pass  # an exception that takes no attribute stays untagged: unknown, the safe side
                    raise
            return None
        # KalshiLive already reconciles prices before returning its validated reply.
        # Other clients may expose fills without attaching accounting to the order.
        interrupted = None
        if not isinstance(self.client, KalshiLive) and "venue_cost_cents" not in reply:
            reply = dict(reply)
            details = _fill_basis(reply, side_yes, reply.get("fills", ()), client_id)
            if not details and callable(getattr(self.client, "fills", None)):
                try:
                    details = _fill_basis(reply, side_yes, await self.client.fills(), client_id)
                except Exception:
                    pass  # Optional price lookup cannot invalidate a confirmed fill count.
                except BaseException as exc:
                    # C16b: a cancellation inside the optional lookup follows a confirmed fill, so
                    # the ticket is published at the intent basis before it propagates; the guard
                    # is never released without the ticket row landing.
                    interrupted = exc
            reply.update(details)
        actual_cents = _contract_cents(price_cents, filled) + _contract_cents(fee_per_contract_cents, filled)
        fee_cents = _contract_cents(fee_per_contract_cents, filled)
        if fixed_size:
            model_fee = _entry_debit_cents(0, filled, fee_per_contract_cents)
            fee_cents = reconcile_fee(reply.get("venue_fee_cents"), model_fee).fee_cents
            actual_cents = _entry_debit_cents(price_cents, filled, 0) + fee_cents
        elif type(count) is not int:
            fee_cents = int((Decimal(str(filled)) * fee_per_contract_cents).to_integral_value(rounding=ROUND_CEILING))
            actual_cents = int((Decimal(str(filled)) * price_cents).to_integral_value(rounding=ROUND_CEILING)) + fee_cents
        basis = "intent"
        actual_price = price_cents
        if all(type(reply.get(key)) is int and reply[key] >= 0
               for key in ("venue_cost_cents", "venue_fee_cents")):
            basis = "fill"
            fee_cents = reply["venue_fee_cents"]
            actual_cents = reply["venue_cost_cents"] + fee_cents
            actual_price = int((Decimal(reply["venue_cost_cents"]) / Decimal(str(filled))).quantize(
                Decimal(1), rounding=ROUND_HALF_UP))
        self.cash_cents -= actual_cents
        ticket = Ticket(ticker, side_yes, filled, actual_cents, fee_cents,
                        cluster_id, client_id, now_ns, venue_order_id=reply.get("order_id"),
                        reason=reason[:400] if isinstance(reason, str) else "", price_basis=basis,
                        intent_price_cents=price_cents if basis == "fill" or fixed_size else None,
                        price_cents=actual_price)
        if attribution is not None:
            ticket.attribution = attribution  # buy() sets the same object; an interrupted buy() never does
        self.open_tickets[client_id] = ticket
        if fixed_size:
            self._exit_basis[client_id] = (filled, actual_cents, fee_cents)
        self._entries_in_flight.pop(client_id, None)
        if not live_risk:
            self.account_risk.resolve(client_id, actual_cents)
        self.ledger_rows.append({"kind": "buy", "ticker": ticker, "side_yes": side_yes, "count": filled,
                                 "cost_cents": actual_cents, "client_id": client_id, "ts_ns": now_ns,
                                 "reason": ticket.reason, "price_basis": basis,
                                 "price_cents": actual_price, "fee_cents": fee_cents,
                                 **({"intent_price_cents": price_cents} if basis == "fill" else {})})
        if interrupted is not None:
            raise interrupted
        return ticket

    def max_buy_debit_cents(self, price_cents: int, count: int | Decimal, fee_per_contract_cents: int) -> int:
        """H2a2: the most buy() can debit: the limit price after this book's
        execution price buffer (the one zero-fill retry reuses that limit, never re-buffers) plus
        the fee _buy reserves at that limit (reserve_fee_per_contract_cents), per contract, and
        never below price + fee. The mode-2 hedge claims this figure before it sends, so the
        buffer cannot push a fill past the reversal caps. Pure; raises KalshiBookError on the
        inputs buy() itself refuses."""
        if type(price_cents) is not int or not 1 <= price_cents <= 99:
            raise KalshiBookError("price_cents out of bounds")
        quantity = _fixed_count(str(count)) if isinstance(count, Decimal) else _fixed_count(count)
        if quantity is None or quantity <= 0:
            raise KalshiBookError("count must be positive on the 0.01 grid")
        if type(fee_per_contract_cents) is not int or fee_per_contract_cents < 0:
            raise KalshiBookError("fee_per_contract_cents must be nonnegative")
        limit = self.send_limit_cents(price_cents)
        fee = self.reserve_fee_per_contract_cents(price_cents, limit, fee_per_contract_cents)
        return _entry_debit_cents(max(price_cents, limit), quantity, fee)

    def send_limit_cents(self, price_cents: int) -> int:
        """The venue limit buy() sends for a first (non-retry) entry at price_cents: the price plus
        this book's execution price buffer, capped at max_price_cents (0 means 99). The one zero-fill
        retry reuses that limit. The single source for _buy, max_buy_debit_cents and the authority
        claim (AUTH-feeslack), so the claim cannot drift from the send. Pure, no allocation; the
        caller validates price_cents."""
        return min(price_cents + self.risk_policy.execution_price_buffer_cents,
                   self.risk_policy.max_price_cents or 99)

    @staticmethod
    def reserve_fee_per_contract_cents(price_cents: int, limit_cents: int,
                                       fee_per_contract_cents: int) -> int:
        """AUTH-buy-feestep: the per-contract fee _buy's cash reservation and max_buy_debit_cents
        charge when buy() sends at limit_cents for a decision at price_cents. The caller's fee is
        quoted at price_cents; when the execution price buffer lifts the limit above it, the default
        taker fee can step up (17c pays 1c, 18c pays 2c), so the reservation adds that step:
        fee + max(0, fee_per_contract(limit) - fee_per_contract(price)). A limit at or below the
        price (buffer off, or capped by max_price_cents) keeps the caller's fee exactly as before.
        For a caller whose fee is fee_per_contract(price) this equals max(fee, fee_per_contract(limit)).
        Never below the caller's fee. Pure, no allocation; the caller validates price_cents and
        limit_cents in 1..99 and the fee as a nonnegative int."""
        if limit_cents <= price_cents:
            return fee_per_contract_cents
        return fee_per_contract_cents + max(0, fee_per_contract(limit_cents) - fee_per_contract(price_cents))

    def exits_reduce_only(self) -> bool:
        """True only when this book's client is KalshiLive, which sends every lx- exit reduce-only.
        No other client can opt in: paper and replay keep the gross opposite-leg reserve."""
        return isinstance(self.client, KalshiLive)

    def exit_reserve_per_contract_cents(self, exit_price_cents: int, fee_per_contract_cents: int) -> int:
        """Per-contract cash an exit reserves: the fee alone when reduce-only (the venue nets the
        leg to cash), else the gross opposite-leg cost plus fee. Pure, no allocation."""
        if self.exits_reduce_only():
            return fee_per_contract_cents
        return 100 - exit_price_cents + fee_per_contract_cents

    async def exit(self, client_id: str, exit_price_cents: int, count: int | Decimal,
                   fee_per_contract_cents: int, reason: str, now_ns: int | None = None, *,
                   exit_client_id: str | None = None,
                   transaction_id: str | None = None,
                   expiration_ts: int | None = None) -> dict[str, Any] | None:
        """Sells an open ticket back before close: an opposite-side IOC at 100 - exit_price_cents
        (the venue nets the pair to cash; see leafhft.strategy.kalshi_edge module docstring for
        the YES/NO convention). Returns the exit ledger row on a nonzero fill, None on a zero
        fill. Raises KalshiBookError before the venue is ever touched on a bad client id, an
        out-of-bounds count/price, or insufficient cash for the opposite leg's own reservation,
        exactly like buy().

        Reduce-only exits reserve the fee only; the venue nets the leg to cash. A client that
        does not send exits reduce-only (paper, replay) keeps the gross opposite-leg reserve.

        H2a2 (mode 2 only): exit_client_id is a PREDETERMINED lx- id (kalshi_reversal_txn derives
        it from the transaction id) so a restart finds the leg on the venue by id; it is refused
        before the venue is touched when malformed or already used by this book. transaction_id
        links the exit row to its two-leg transaction. expiration_ts is the venue-side expiry
        (unix seconds) the transaction binds the order to. All default to None, which keeps the
        random id, the order body and the row bytes of every existing caller unchanged."""
        now_ns = time.time_ns() if now_ns is None else now_ns
        ticket = self.open_tickets.get(client_id)
        if ticket is None:
            raise KalshiBookError("no open ticket for that client id")
        # Only a fixed-size ticket exits on the 0.01 grid; every other ticket keeps origin/main's
        # whole-count bound.
        if client_id not in self._exit_basis and (type(count) is not int or not 1 <= count <= ticket.count):
            raise KalshiBookError("count out of bounds for this ticket")
        quantity = _fixed_count(str(count)) if type(count) in (Decimal, float) else _fixed_count(count)
        if quantity is None or not 0 < quantity <= Decimal(str(ticket.count)):
            raise KalshiBookError("count out of bounds for this ticket")
        if type(count) is not int:
            count = quantity
        if type(exit_price_cents) is not int or not 1 <= exit_price_cents <= 99:
            raise KalshiBookError("exit_price_cents out of bounds")
        if type(fee_per_contract_cents) is not int or fee_per_contract_cents < 0:
            raise KalshiBookError("fee_per_contract_cents must be nonnegative")
        if exit_client_id is not None and (
                not isinstance(exit_client_id, str) or not _PREDETERMINED_EXIT_ID.fullmatch(exit_client_id)
                or exit_client_id in self._predetermined_exit_ids
                or exit_client_id in (getattr(self.client, "_records", None) or {})):
            raise KalshiBookError("predetermined exit id invalid or already used")
        if transaction_id is not None and (not isinstance(transaction_id, str)
                                           or not 0 < len(transaction_id) <= 64):
            raise KalshiBookError("transaction_id invalid")
        _check_expiration_ts(expiration_ts)
        venue_price_cents = 100 - exit_price_cents
        reduce_only = self.exits_reduce_only()
        per_contract_cents = self.exit_reserve_per_contract_cents(exit_price_cents, fee_per_contract_cents)
        reserve_cents = per_contract_cents * count
        if type(count) is not int:
            reserve_cents = _entry_debit_cents(0 if reduce_only else venue_price_cents,
                                               count, fee_per_contract_cents)
        free_cents = self.cash_cents - self.reserved_cents
        if reserve_cents > free_cents:
            raise KalshiExitCashRefused(count, reserve_cents, free_cents, per_contract_cents)
        if exit_client_id is None:
            exit_client_id = "lx-" + secrets.token_hex(11)[:21]
        else:
            # Consumed before the send: a predetermined id is never sent twice by this book.
            self._predetermined_exit_ids.add(exit_client_id)
        if isinstance(self.client, KalshiLive):
            self.client._entry_attributions[exit_client_id] = attribution_or_unknown(ticket.attribution)
        self.reserved_cents += reserve_cents
        try:
            reply = await self.client.place_ioc_buy(ticket.ticker, not ticket.side_yes, venue_price_cents,
                                                     count, exit_client_id,
                                                     **_expiry_kwargs(expiration_ts))
        except Exception:
            self.reserved_cents -= reserve_cents
            raise
        self.reserved_cents -= reserve_cents
        filled = _book_count(reply["fill_count"])
        if filled == 0:
            return None
        proceeds_cents = _contract_cents(exit_price_cents - fee_per_contract_cents, filled)
        fee_cents = _contract_cents(fee_per_contract_cents, filled)
        if type(count) is not int:
            model_fee = _entry_debit_cents(0, filled, fee_per_contract_cents)
            fee_cents = reconcile_fee(reply.get("venue_fee_cents"), model_fee).fee_cents
            proceeds_cents = _contract_cents(exit_price_cents, filled) - fee_cents
        basis = "intent"
        actual_price = exit_price_cents
        if all(type(reply.get(key)) is int and reply[key] >= 0
               for key in ("venue_cost_cents", "venue_fee_cents")):
            basis = "fill"
            gross = _contract_cents(100, filled) - reply["venue_cost_cents"]
            fee_cents = reply["venue_fee_cents"]
            proceeds_cents = gross - fee_cents
            actual_price = int((Decimal(gross) / Decimal(str(filled))).quantize(
                Decimal(1), rounding=ROUND_HALF_UP))
        cost_share = _integer_split(ticket.cost_cents, ticket.count, filled)
        fee_share = _integer_split(ticket.fee_cents, ticket.count, filled)
        if client_id in self._exit_basis:
            original_count, original_cost, original_fee = self._exit_basis[client_id]
            exited = _count_number(Decimal(str(original_count)) - Decimal(str(ticket.count))
                                   + Decimal(str(filled)))
            # Allocate from the original basis, exactly as recover() does with
            # the ledger's cumulative exit count. Sequential rounding drifts.
            cost_share = ticket.cost_cents - (original_cost - _integer_split(
                original_cost, original_count, exited))
            fee_share = ticket.fee_cents - (original_fee - _integer_split(
                original_fee, original_count, exited))
        pnl_cents = proceeds_cents - cost_share
        self.cash_cents += proceeds_cents
        self.realized_cents += pnl_cents
        self.exit_fills_contracts = _count_number(Decimal(str(self.exit_fills_contracts)) + Decimal(str(filled)))
        self.exit_pnl_cents += pnl_cents
        ticket.count = _remaining_count(ticket.count, filled)
        ticket.cost_cents -= cost_share
        ticket.fee_cents -= fee_share
        row = {"kind": "exit", "ticker": ticket.ticker, "client_id": client_id,
              "exit_client_id": exit_client_id, "side_yes": ticket.side_yes, "count": filled,
              "price_cents": actual_price, "fee_cents": fee_cents, "price_basis": basis,
              **({"intent_price_cents": exit_price_cents} if basis == "fill" else {}),
              "proceeds_cents": proceeds_cents, "pnl_cents": pnl_cents,
              "reason": ticket.reason, "ts_ns": now_ns, "attribution": ticket.attribution,
              "settlement_minute": ticket.cluster_id}
        if client_id in self._exit_basis:
            # Additive, fixed-size tickets only: the driver's ledger replay accepts a 0.01-grid exit
            # count only from a row carrying this marker; every other row keeps origin/main's bytes.
            row["fractional_sizing"] = True
        if reduce_only:
            # Additive: the persisted ticket row carries the exit's own reason (record_exit),
            # and the lx- fill is this book's own reduce-only order.
            own = reason if isinstance(reason, str) else ""
            row["exit_reason"] = f"{own[:340]} requested={count} filled={filled}"[:400]
            row["reduce_only"] = True
            row["is_ours"] = True
        if transaction_id is not None:
            row["transaction_id"] = transaction_id
            row["transaction_leg"] = "exit"
        self.ledger_rows.append(row)
        self.settled_rows.append(row)  # it is realized
        if ticket.count <= 0:
            del self.open_tickets[client_id]
            self._exit_basis.pop(client_id, None)
        self._release_risk(client_id, exit_client_id, cost_share, count=filled, now_ns=now_ns,
                           probe_loss_cents=(-pnl_cents if ticket.price_basis == "fill"
                                             and basis == "fill" and type(ticket.side_yes) is bool
                                             else None))
        return row

    def link_hedge_row(self, client_id: str, transaction_id: str) -> bool:
        """H2a2: tag the buy row of a mode-2 hedge leg with its transaction id, so the exit row and
        the buy row link where the atomic reversal row used to stand. Matches the hedge id or the
        book's own one zero-fill retry id for it; newest row first, bounded by the ledger. True
        when a row was tagged. Never touches cash, tickets or the venue."""
        if not isinstance(transaction_id, str) or not 0 < len(transaction_id) <= 64:
            raise KalshiBookError("transaction_id invalid")
        ids = {client_id, "lb-r1-" + hashlib.sha256(str(client_id).encode()).hexdigest()[:24]}
        for row in reversed(self.ledger_rows):
            if row.get("kind") == "buy" and row.get("client_id") in ids:
                row["transaction_id"] = transaction_id
                row["transaction_leg"] = "hedge"
                return True
        return False

    def _release_risk(self, client_id, event_id, cost_cents, *, count=None, now_ns=None,
                      probe_loss_cents=None):
        try:
            # The ledger's persisted pr tag (including retry/reversal ids) decides probe identity.
            # Unknown fill accounting passes None, so release charges the full cost conservatively.
            # Non-probe entries ignore the P&L; the release event records probe P&L idempotently.
            self.account_risk.release(client_id, event_id, cost_cents, count=count, now_ns=now_ns,
                                      probe_loss_cents=probe_loss_cents)
        except Exception:
            # A ledger fault must stop entry, never undo a completed risk reduction.
            self._latch_entry_stop("risk_release_failed")

    def _adopt_risk(self, ticket):
        if ticket.price_basis != "fill":
            return
        try:
            if ticket.cluster_id < 0:
                prior = self.account_risk.snapshot()["entries"].get(ticket.client_id)
                if prior is not None and prior["ticker"] == ticket.ticker:
                    ticket.cluster_id = prior["minute"]
            self.account_risk.adopt(ticket.client_id, ticket.ticker, ticket.cost_cents,
                                    ticket.count, ticket.cluster_id, probe=callable(getattr(self.account_risk, "floor_refused", None)))
        except Exception:
            self._latch_entry_stop("risk_adopt_failed")

    def settle(self, client_id: str, result_yes: bool, now_ns: int | None = None) -> dict[str, Any]:
        now_ns = time.time_ns() if now_ns is None else now_ns
        ticket = self.open_tickets.get(client_id)
        if ticket is None:
            raise KalshiBookError("no open ticket for that client id")
        payout_per_contract = 100 if result_yes == ticket.side_yes else 0
        proceeds_cents = _contract_cents(payout_per_contract, ticket.count)
        pnl_cents = proceeds_cents - ticket.cost_cents
        self.cash_cents += proceeds_cents
        self.realized_cents += pnl_cents
        del self.open_tickets[client_id]
        self._exit_basis.pop(client_id, None)
        row = {"kind": "settle", "ticker": ticket.ticker, "client_id": client_id,
              "payout_cents": proceeds_cents, "pnl_cents": pnl_cents, "ts_ns": now_ns,
              "settled_ns": now_ns, "reason": ticket.reason, "attribution": ticket.attribution}
        self.settled_rows.append(row)
        self.ledger_rows.append(row)
        self._release_risk(client_id, "settle:" + client_id, ticket.cost_cents, now_ns=now_ns,
                           probe_loss_cents=(-pnl_cents if ticket.price_basis == "fill"
                                             and type(result_yes) is bool and type(ticket.side_yes) is bool
                                             and (_book_count(ticket.count) or 0) > 0 else None))
        return row

    def settle_void(self, client_id: str, now_ns: int | None = None) -> dict[str, Any]:
        """A voided market refunds the cost (Kalshi voids by refunding, never a partial payout)."""
        now_ns = time.time_ns() if now_ns is None else now_ns
        ticket = self.open_tickets.get(client_id)
        if ticket is None:
            raise KalshiBookError("no open ticket for that client id")
        self.cash_cents += ticket.cost_cents
        del self.open_tickets[client_id]
        self._exit_basis.pop(client_id, None)
        row = {"kind": "void", "ticker": ticket.ticker, "client_id": client_id,
              "payout_cents": ticket.cost_cents, "pnl_cents": 0, "ts_ns": now_ns,
              "settled_ns": now_ns, "reason": ticket.reason, "attribution": ticket.attribution}
        self.settled_rows.append(row)
        self.ledger_rows.append(row)
        self._release_risk(client_id, "void:" + client_id, ticket.cost_cents, now_ns=now_ns,
                           probe_loss_cents=0 if ticket.price_basis == "fill" else None)
        return row

    def equity_q(self, fair_value_cents: dict[str, int] | None = None) -> int:
        """cash plus open tickets marked at fair value (fallback: cost, never an assumed gain)."""
        fair_value_cents = fair_value_cents or {}
        # A fixed-size ticket falls back to its exact remaining cost; every other ticket keeps
        # origin/main's whole-cent per-contract mark byte for byte.
        open_value_cents = sum(
            ((_contract_cents(Decimal(str(fair_value_cents[t.ticker])), t.count)
              if t.ticker in fair_value_cents else t.cost_cents)
             if t.client_id in self._exit_basis else
             _contract_cents(int(fair_value_cents.get(t.ticker, t.cost_cents // t.count)), t.count))
            for t in self.open_tickets.values()
        )
        return (self.cash_cents + open_value_cents) * QUOTE_UNIT // 100

    @classmethod
    def recover(cls, client: KalshiLive, limits: KalshiLimits, cash_cents: int,
               positions: list[dict[str, Any]],
               settled_client_ids: frozenset[str] = frozenset(),
               prior_realized_cents: int = 0,
               exit_counts: dict[str, int] | None = None) -> "KalshiBook":
        """Rebuild open tickets from the client's journal. Every FILLED/PARTIAL row with
        fill_count > 0 is rebuilt as an open ticket unless its client id is in
        settled_client_ids (a settle/void row already in kalshi-tickets.jsonl accounts for it):
        the venue position list no longer gates this, since a ticket the venue already settled or
        netted away while we were down still needs the poller to book it from the market result
        rather than being silently dropped. cluster_id is not persisted in the journal, so a
        recovered ticket carries cluster_id=-1 (excluded from cluster caps) until the strategy
        re-tags it on the next Lifecycle event for that ticker. `exit_counts` (client_id -> total
        contracts already exited, summed from kalshi-tickets.jsonl's own "exit" rows) reduces the
        recovered ticket's count and cost accordingly; a ticket exited down to zero is not
        reopened."""
        exit_counts = exit_counts or {}
        book = cls(client, limits, cash_cents, prior_realized_cents=prior_realized_cents)
        for cid, row in client._records.items():
            if cid.startswith("lx-"):
                continue
            if "reversal" in row:
                continue  # its physical fill is split below, never adopted as a second buy
            if client._owned.get(cid) not in ("FILLED", "PARTIAL"):
                continue
            if cid in settled_client_ids:
                continue
            count = _book_count(row.get("fill_count", 0))
            if count is None or count <= 0:
                continue
            count = _remaining_count(count, exit_counts.get(cid, 0))
            if count <= 0:
                continue  # fully exited before this restart: not reopened
            cost_cents = _contract_cents(row["price_cents"], count)
            ticket = Ticket(row.get("ticker"), row["side_yes"], count, cost_cents, 0, -1, cid,
                            row.get("ts_ns", 0), venue_order_id=row.get("venue_order_id"))
            ticket.attribution = attribution_or_unknown(row.get("attribution"))
            ticket.cluster_id = recovered_settlement_minute(row)
            ticket.reason = ticket.attribution["reason"]
            if row.get("fractional_sizing") is True:
                # Only a fixed_count entry's journal record carries the marker; a Dark Horse or
                # legacy fractional fill recovers exactly as origin/main does.
                original_count = _book_count(row["fill_count"])
                exited = exit_counts.get(cid, 0)
                model_fee = _entry_debit_cents(
                    0, original_count,
                    row.get("model_fee_per_contract_cents", fee_per_contract(row["price_cents"])))
                fee = reconcile_fee(row.get("venue_fee_cents"), model_fee).fee_cents
                total = _entry_debit_cents(row["price_cents"], original_count, 0) + fee
                ticket.cost_cents = total - _integer_split(total, original_count, exited)
                ticket.fee_cents = fee - _integer_split(fee, original_count, exited)
                book._exit_basis[cid] = (original_count, total, fee)
                ticket.price_cents = row["price_cents"]
                ticket.intent_price_cents = row["price_cents"]
            if all(type(row.get(key)) is int and row[key] >= 0
                   for key in ("venue_cost_cents", "venue_fee_cents")):
                original_count = _book_count(row["fill_count"])
                exited = exit_counts.get(cid, 0)
                total = row["venue_cost_cents"] + row["venue_fee_cents"]
                ticket.cost_cents = total - _integer_split(total, original_count, exited)
                ticket.fee_cents = row["venue_fee_cents"] - _integer_split(
                    row["venue_fee_cents"], original_count, exited)
                if cid in book._exit_basis:
                    book._exit_basis[cid] = (original_count, total, row["venue_fee_cents"])
                ticket.price_basis = "fill"
                ticket.intent_price_cents = row["price_cents"]
                ticket.price_cents = int((Decimal(row["venue_cost_cents"]) / Decimal(str(original_count))).quantize(
                    Decimal(1), rounding=ROUND_HALF_UP))
            book.open_tickets[cid] = ticket
        for cid, record in client._records.items():
            reversal = record.get("reversal")
            if reversal is None:
                continue
            book._reversals[cid] = reversal
            book.reversal_intents += 1
            book.reversal_unknown += int(reversal.get("unknown", False))
            book.reversal_fills += reversal.get("fill_updates", 0)
            book.realized_cents += reversal["pnl"]
            book.reserved_cents += reversal["reserve"] if reversal["locked"] else 0
            book.open_tickets.pop(reversal["old"]["client_id"], None)
            book.open_tickets.pop(reversal["new_id"], None)
            for snapshot in (reversal["old_after"], reversal["new_after"]):
                if snapshot is None or snapshot["client_id"] in settled_client_ids:
                    continue
                snapshot = dict(snapshot)
                exited = exit_counts.get(snapshot["client_id"], 0)
                if exited:
                    original_count = snapshot["count"]
                    snapshot["count"] = _remaining_count(original_count, exited)
                    if snapshot["count"] <= 0:
                        continue
                    for key in ("cost_cents", "fee_cents"):
                        snapshot[key] -= _integer_split(snapshot[key], original_count, exited)
                snapshot["count"] = Decimal(str(snapshot["count"]))
                book.open_tickets[snapshot["client_id"]] = Ticket(**snapshot)
            if not reversal["locked"]:
                try:
                    book.account_risk.finish_reversal(
                        cid, reversal["old"]["client_id"], reversal["new_id"],
                        (reversal["old_after"] or {}).get("cost_cents", 0),
                        (reversal["new_after"] or {}).get("cost_cents", 0),
                        old_count=(reversal["old_after"] or {}).get("count", 0),
                        new_count=(reversal["new_after"] or {}).get("count", 0))
                except Exception:
                    book._latch_entry_stop("restore_finish_reversal_failed")
        for ticket in book.open_tickets.values():
            book._adopt_risk(ticket)
        return book

    def adopt_prior(self, rows: list[dict[str, Any]], now_ns: int) -> int:
        """Adopts filled prior-run tickets (unsettled_prior_tickets' output) as open tickets so
        the poller can settle them into this book. The journal carries no fee, so the fee is
        rebuilt from fee_per_contract(price_cents) per contract, same as a live buy would have
        paid. Appends an in-memory 'adopt' ledger row per ticket (the caller is responsible for
        persisting it to the ticket ledger before trading starts, so a later restart's scan
        treats the client id as already accounted for). Skips a row whose client id is already
        open. Returns the number of tickets adopted."""
        adopted = 0
        for row in rows:
            cid = row["client_id"]
            if cid in self.open_tickets:
                continue
            price_cents = row["price_cents"]
            count = _book_count(row["count"])
            fee_cents = _contract_cents(fee_per_contract(price_cents), count)
            cost_cents = _contract_cents(price_cents, count) + fee_cents
            if (row.get("price_basis") == "fill" or row.get("lane") == "darkhorse"
                    or row.get("fractional_sizing") is True or row.get("combined") is True):
                cost_cents, fee_cents = row["cost_cents"], row["fee_cents"]
            reason = row.get("reason")
            ticket = Ticket(row["ticker"], row["side_yes"], count, cost_cents, fee_cents, -1, cid,
                            row.get("opened_ns", now_ns), venue_order_id=row.get("venue_order_id"),
                            reason=reason[:400] if isinstance(reason, str) else "",
                            price_basis=row.get("price_basis", "intent"),
                            intent_price_cents=row.get("intent_price_cents"), price_cents=price_cents,
                            attribution=attribution_or_unknown(row.get("attribution")))
            ticket.cluster_id = recovered_settlement_minute(row)
            self.open_tickets[cid] = ticket
            if "exit_basis" in row:
                self._exit_basis[cid] = tuple(row["exit_basis"])
            self._adopt_risk(ticket)
            self.ledger_rows.append({"kind": "adopt", "ticker": row["ticker"], "client_id": cid,
                                     "recovered_from": row.get("run_dir", ""), "ts_ns": now_ns,
                                     "reason": ticket.reason, "attribution": ticket.attribution})
            adopted += 1
        return adopted


def cap_reached(book: "KalshiBook", limits: KalshiLimits) -> bool:
    """The predicate the live loop stops on: realized P&L for this venue+symbol today, across
    every run, has hit the daily loss cap."""
    return -book.realized_today_cents >= limits.max_cumulative_loss_cents


class SettlementPoller:
    """Bounded venue settlement poll: at most one `client.market()` read per open ticket per
    `interval_s`, every venue read failure is swallowed and counted so a poll error can never
    reach the trading loop, and every settle/void/unsettled row is written to `ledger_path`
    (fsync'd, capped at 1 MB like KalshiLive's own journal) BEFORE the book is asked to commit the
    settlement: a ledger write that fails leaves the ticket open and raises, so a book that cannot
    record a settlement never silently keeps trading on top of an unrecorded one."""

    def __init__(self, book: KalshiBook, client: Any, ledger_path: str | Path,
                interval_s: float = 30.0, unsettled_report_s: float = 3600.0,
                lane: str | None = None) -> None:
        self.book = book
        self.client = client
        self.ledger_path = Path(ledger_path)
        self.interval_s = interval_s
        self.unsettled_report_s = unsettled_report_s
        self.lane = lane
        self._last_poll_mono = -interval_s
        self._reasons: dict[str, str] = {}
        self._last_unsettled_report_ns: dict[str, int] = {}
        self.stats: dict[str, Any] = {
            "polls": 0, "settled": 0, "won": 0, "lost": 0, "voided": 0,
            "unsettled_reports": 0, "poll_errors": 0, "last_poll_error": None,
            "ledger_failed": False, "last_poll_ns": None,
        }

    def note_reason(self, client_id: str, reason: str) -> None:
        reason = reason[:400] if isinstance(reason, str) else ""
        ticket = self.book.open_tickets.get(client_id)
        if ticket is not None:
            ticket.reason = reason
        if client_id not in self._reasons and len(self._reasons) >= MAX_NOTED_REASONS:
            return
        self._reasons[client_id] = reason

    def record_buy(self, ticket: Ticket, reason: str, now_ns: int | None = None) -> dict[str, Any]:
        """Persists the buy the same way a settle row is persisted (fsync'd, capped at
        MAX_TICKET_LEDGER_BYTES): a failed append raises KalshiBookError with ledger_failed set,
        exactly like a settle-row write failure, so an unrecorded buy never silently keeps trading.
        Notes the reason so the later settle row for this ticket keeps carrying it."""
        now_ns = time.time_ns() if now_ns is None else now_ns
        reason = reason[:400] if isinstance(reason, str) else ""
        ticket.reason = reason
        self.note_reason(ticket.client_id, reason)
        row = {
            "kind": "buy",
            "attribution": ticket.attribution,
            "settlement_minute": ticket.cluster_id,
            "ticker": ticket.ticker,
            "client_id": ticket.client_id,
            "side_yes": ticket.side_yes,
            "count": _book_count(ticket.count),
            "price_cents": (ticket.price_cents if ticket.price_basis == "fill" else
                            int(Decimal(ticket.cost_cents) // Decimal(str(ticket.count)))),
            "price_basis": ticket.price_basis,
            **({"intent_price_cents": ticket.intent_price_cents} if ticket.price_basis == "fill" else {}),
            "fee_cents": ticket.fee_cents,
            "cost_cents": ticket.cost_cents,
            "opened_ns": ticket.opened_ns,
            "ts_ns": now_ns,
            "reason": reason,
        }
        if ticket.price_basis == "intent" and ticket.intent_price_cents is not None:
            row.update(fractional_sizing=True, intent_price_cents=ticket.intent_price_cents)
        if ticket.physical_client_id is not None:
            # COMBINE-S1: this book's share of a combined fill the venue saw under physical_client_id;
            # unsettled_prior_tickets re-opens exactly this share on restart, never the whole fill.
            row.update(combined=True, physical_client_id=ticket.physical_client_id)
            if type(ticket.price_cents) is int and 1 <= ticket.price_cents <= 99:
                # COMBINE-S1b c1: the raw entry price, so a restart never inverts the fee-inclusive
                # cost // count (not injective: 82 and 83 both store 84).
                row["entry_price_cents"] = ticket.price_cents
        self._append_row(row)
        return row

    def record_combined_zero(self, client_id: str, ticker: str, side_yes: bool, reason: str,
                             now_ns: int | None = None) -> dict[str, Any]:
        """COMBINE-S1: the anchor kept a zero share of a combined fill sent under its own client id.
        Persisted like record_buy, so a restart re-opens nothing of that fill on this book (the other
        legs' books hold it). Raises KalshiBookError on a failed write, as record_buy does."""
        now_ns = time.time_ns() if now_ns is None else now_ns
        row = {"kind": "combined_zero", "client_id": client_id, "physical_client_id": client_id,
               "ticker": ticker, "side_yes": side_yes, "count": 0, "cost_cents": 0, "fee_cents": 0,
               "combined": True, "ts_ns": now_ns, "reason": reason[:400] if isinstance(reason, str) else "",
               "settlement_minute": -1, "attribution": attribution_or_unknown(None)}
        self._append_row(row)
        return row

    def record_exit(self, row: dict[str, Any]) -> None:
        """Persists a KalshiBook.exit() row the same way record_buy persists a buy: fsync'd,
        capped at MAX_TICKET_LEDGER_BYTES. Raises KalshiBookError before trading continues on a
        write failure, exactly like a settle-row write failure. A reduce-only exit row persists
        its own reason (exit p_side=... requested=... filled=...) with the parent's entry reason
        kept additively as entry_reason; the in-memory book row is left as exit() built it."""
        exit_reason = row.get("exit_reason")
        if not isinstance(exit_reason, str):
            self._append_row(row)
            return
        persisted = dict(row, reason=exit_reason, entry_reason=row.get("reason", ""))
        self._append_row(persisted)
        for key in ("settlement_minute", "attribution", "lane"):
            if key in persisted:
                row[key] = persisted[key]

    def record_reversal(self, row: dict[str, Any]) -> None:
        """H1c: persists one KalshiBook.drain_reversal_rows() row the same way record_exit persists
        an exit (fsync'd, capped at MAX_TICKET_LEDGER_BYTES; a write failure sets ledger_failed and
        raises KalshiBookError), then notes the new ticket's reason so its later settle row carries it."""
        self._append_row(row)
        tx = row.get("transaction")
        if isinstance(tx, dict) and tx.get("new_after") is not None and isinstance(tx.get("new_id"), str):
            self.note_reason(tx["new_id"], tx.get("reason", ""))

    def _ledger_row(self, kind: str, ticket: Ticket, market: dict[str, Any], payout_cents: int,
                    pnl_cents: int, now_ns: int) -> dict[str, Any]:
        result = market.get("result")
        expiration_value = market.get("expiration_value")
        return {
            "kind": kind,
            "attribution": ticket.attribution,
            "settlement_minute": ticket.cluster_id,
            "ticker": ticket.ticker,
            "client_id": ticket.client_id,
            "side_yes": ticket.side_yes,
            "count": _book_count(ticket.count),
            "price_cents": int(Decimal(ticket.cost_cents) // Decimal(str(ticket.count))),
            "fee_cents": ticket.fee_cents,
            "cost_cents": ticket.cost_cents,
            "result": result if isinstance(result, str) else "",
            "expiration_value": expiration_value if isinstance(expiration_value, str) else "",
            "payout_cents": payout_cents,
            "pnl_cents": pnl_cents,
            "opened_ns": ticket.opened_ns,
            "settled_ns": now_ns,
            "reason": ticket.reason,
        }

    def _append_row(self, row: dict[str, Any]) -> None:
        if "settlement_minute" not in row:
            ticket = self.book.open_tickets.get(row.get("client_id"))
            row["settlement_minute"] = ticket.cluster_id if ticket else recovered_settlement_minute(row)
        if "attribution" not in row:
            ticket = self.book.open_tickets.get(row.get("client_id"))
            row["attribution"] = attribution_or_unknown(ticket.attribution if ticket else None)
        if self.lane is not None:
            row["lane"] = self.lane
            if row.get("kind") == "buy":
                ticket = self.book.open_tickets[row["client_id"]]
                row["price_cents"] = ticket.price_cents
        payload = orjson.dumps(row) + b"\n"
        try:
            current_size = self.ledger_path.stat().st_size
        except FileNotFoundError:
            current_size = 0
        if current_size + len(payload) > MAX_TICKET_LEDGER_BYTES:
            self.stats["ledger_failed"] = True
            raise KalshiBookError(f"kalshi ticket ledger {self.ledger_path} at 1 MB; archive and restart")
        try:
            self.ledger_path.parent.mkdir(parents=True, exist_ok=True)
            with self.ledger_path.open("ab") as f:
                f.write(payload)
                f.flush()
                os.fsync(f.fileno())
        except OSError as e:
            self.stats["ledger_failed"] = True
            raise KalshiBookError(f"kalshi ticket ledger {self.ledger_path} write failed: {type(e).__name__}") from e

    def record_adopted(self, rows: list[dict[str, Any]]) -> None:
        """Persists KalshiBook.adopt_prior's in-memory 'adopt' ledger rows the same way a settle
        row is persisted (fsync'd, capped at MAX_TICKET_LEDGER_BYTES): raises before trading
        starts on a write failure rather than leaving an adoption unrecorded."""
        for row in rows:
            self._append_row(row)

    def _forget(self, client_id: str) -> None:
        self._reasons.pop(client_id, None)
        self._last_unsettled_report_ns.pop(client_id, None)

    def _settle_won_or_lost(self, ticket: Ticket, market: dict[str, Any], result_yes: bool, now_ns: int) -> None:
        payout_cents = _contract_cents(100, ticket.count) if result_yes == ticket.side_yes else 0
        pnl_cents = payout_cents - ticket.cost_cents
        row = self._ledger_row("settle", ticket, market, payout_cents, pnl_cents, now_ns)
        self._append_row(row)  # raises before the book is touched: an unrecorded settle never commits
        self.book.settle(ticket.client_id, result_yes, now_ns)
        self._forget(ticket.client_id)
        self.stats["settled"] += 1
        if result_yes == ticket.side_yes:
            self.stats["won"] += 1
        else:
            self.stats["lost"] += 1

    def _settle_voided(self, ticket: Ticket, market: dict[str, Any], now_ns: int) -> None:
        row = self._ledger_row("void", ticket, market, ticket.cost_cents, 0, now_ns)
        self._append_row(row)
        self.book.settle_void(ticket.client_id, now_ns)
        self._forget(ticket.client_id)
        self.stats["voided"] += 1

    def _maybe_report_unsettled(self, ticket: Ticket, market: dict[str, Any], now_ns: int) -> None:
        cid = ticket.client_id
        last_report_ns = self._last_unsettled_report_ns.get(cid, ticket.opened_ns)
        report_period_ns = int(self.unsettled_report_s * 1_000_000_000)
        if now_ns - last_report_ns < report_period_ns:
            return
        row = self._ledger_row("unsettled", ticket, market, 0, 0, now_ns)
        self._append_row(row)
        self._last_unsettled_report_ns[cid] = now_ns
        self.stats["unsettled_reports"] += 1

    async def poll(self, now_ns: int, now_mono: float) -> None:
        """One bounded pass over every currently open ticket, at most once per `interval_s`."""
        if now_mono - self._last_poll_mono < self.interval_s:
            return
        self._last_poll_mono = now_mono
        self.stats["polls"] += 1
        self.stats["last_poll_ns"] = now_ns
        for cid in list(self.book.open_tickets.keys()):
            ticket = self.book.open_tickets.get(cid)
            if ticket is None:
                continue  # settled earlier in this same pass, or by another path
            try:
                market = await self.client.market(ticket.ticker)
            except Exception as e:
                self.stats["poll_errors"] += 1
                self.stats["last_poll_error"] = type(e).__name__
                continue
            status = market.get("status")
            result = market.get("result")
            if status in TERMINAL_MARKET_STATUSES and result in ("yes", "no"):
                self._settle_won_or_lost(ticket, market, result == "yes", now_ns)
            elif status in TERMINAL_MARKET_STATUSES:
                self._settle_voided(ticket, market, now_ns)
            else:
                self._maybe_report_unsettled(ticket, market, now_ns)
