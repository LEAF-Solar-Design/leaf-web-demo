"""Revision-bound, short-lived account observations; no live adapter construction."""
from __future__ import annotations

import asyncio
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass
import json
from functools import partial
import math
import os
from pathlib import Path
import re
import secrets
import stat
import time
from urllib.parse import quote

SCHEMA_VERSION = 1
EARLY_CYCLE_NS = 200_000_000
MIN_CYCLE_NS = 60_000_000
FINAL_PHASE_S = 60
DEFAULT_WINDOW_S = 120
AGE_SLACK_NS = 50_000_000
AGE_CAP_NS = 250_000_000
RESERVE_READS = 30
ROUTINE_MILLI_PER_S = 1600
TOKEN_BACKOFF_NS = 50_000_000
HTTP429_BACKOFF_S = 1
CONNECT_TIMEOUT_S = 0.1
MAX_RECORD_BYTES = 1_048_576
MAX_PAGES = 100
PAGE_ROWS = 1000
OBSERVATION_NAME = "observation.json"
LOCK_NAME = "publisher.lock"
BALANCE_PATH = "/trade-api/v2/portfolio/balance"
POSITIONS_PATH = "/trade-api/v2/portfolio/positions"
SENTINEL_TICKER = "~leafhft-hot-sentinel~"
MISS_REASONS = ("absent", "malformed", "wrong_account", "stale", "revision_mismatch", "widened")
_KEYS = frozenset(("schema_version", "account_digest", "ledger_revision", "cash_cents",
                   "positions_rows", "read_start_ns", "read_end_ns", "cycle_id", "cycle_ns",
                   "widened", "boot_id"))


@dataclass(frozen=True)
class Observation:
    account_digest: str
    ledger_revision: int
    cash_cents: int
    positions_rows: tuple
    read_start_ns: int
    read_end_ns: int
    age_ns: int
    cycle_id: str
    cycle_ns: int


@dataclass(frozen=True)
class Miss:
    reason: str
    detail: str = ""

    def __post_init__(self):
        if self.reason not in MISS_REASONS:
            raise ValueError("unknown miss")


@dataclass(frozen=True)
class WindowView:
    closes_ms: tuple[int, ...]
    minutes: Mapping[str, int]


@dataclass(frozen=True)
class HttpReply:
    status: int
    body: object
    retry_after_s: float | None = None


@dataclass(frozen=True)
class CycleResult:
    status: str
    detail: str
    gets: int

    def __post_init__(self):
        if self.status not in ("published", "idle", "skipped", "backoff", "refused"):
            raise ValueError("unknown cycle status")


@dataclass(frozen=True)
class RefresherConfig:
    account_id: str
    ledger_path: object
    legacy_paths: tuple
    key_id: str
    worst_cents: int
    read_budget_wired: bool
    window_s: int = DEFAULT_WINDOW_S
    routine_milli_per_s: int = ROUTINE_MILLI_PER_S

    @property
    def account_digest(self):
        from ..attribution import account_digest
        return account_digest(self.account_id)


def age_limit_ns(cycle_ns):
    return min(cycle_ns + AGE_SLACK_NS, AGE_CAP_NS)


def cycle_plan(refill_per_s, routine_milli_per_s, reads_per_cycle):
    spare = refill_per_s * 1000 - routine_milli_per_s
    if spare <= 0:
        return None
    sustain = -(-(reads_per_cycle * 10**12) // spare)
    return max(EARLY_CYCLE_NS, sustain), max(MIN_CYCLE_NS, sustain)


def phase(now_ms, closes_ms, window_s):
    active = [close - now_ms for close in closes_ms if 0 < close - now_ms <= window_s * 1000]
    if any(delta <= FINAL_PHASE_S * 1000 for delta in active):
        return "final"
    return "early" if active else "idle"


def _whole(value, high, low=0):
    return type(value) is int and low <= value <= high


def _validate(record):
    if type(record) is not dict or set(record) != _KEYS:
        raise ValueError("schema")
    r = record
    if (type(r["schema_version"]) is not int or r["schema_version"] != 1
            or type(r["account_digest"]) is not str
            or not re.fullmatch(r"[0-9a-f]{64}", r["account_digest"])
            or not all(_whole(r[k], 2**53 - 1) for k in ("ledger_revision", "cash_cents"))
            or not all(_whole(r[k], 2**63 - 1) for k in ("read_start_ns", "read_end_ns"))
            or r["read_start_ns"] > r["read_end_ns"]
            or not _whole(r["cycle_ns"], AGE_CAP_NS, MIN_CYCLE_NS)
            or type(r["positions_rows"]) is not list
            or any(type(row) is not dict for row in r["positions_rows"])
            or type(r["widened"]) is not bool
            or type(r["boot_id"]) is not str
            or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", r["boot_id"])
            or type(r["cycle_id"]) is not str
            or not re.fullmatch(r"[0-9a-f]{32}-[1-9][0-9]{0,15}", r["cycle_id"])
            or int(r["cycle_id"].split("-")[1]) > 2**53 - 1):
        raise ValueError("schema")
    return r


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("json")
        result[key] = value
    return result


def _constant(value):
    raise ValueError("json")


def decode_record(data):
    if len(data) > MAX_RECORD_BYTES:
        raise ValueError("oversize")
    try:
        record = json.loads(data, object_pairs_hook=_pairs, parse_constant=_constant)
    except (ValueError, TypeError, RecursionError) as exc:
        raise ValueError("json") from exc
    return _validate(record)


def encode_record(*, account_digest, ledger_revision, cash_cents, positions_rows,
                  read_start_ns, read_end_ns, cycle_id, cycle_ns, widened, boot_id):
    record = dict(schema_version=SCHEMA_VERSION, account_digest=account_digest,
                  ledger_revision=ledger_revision, cash_cents=cash_cents,
                  positions_rows=list(positions_rows), read_start_ns=read_start_ns,
                  read_end_ns=read_end_ns, cycle_id=cycle_id, cycle_ns=cycle_ns,
                  widened=widened, boot_id=boot_id)
    _validate(record)
    data = json.dumps(record, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    if len(data) > MAX_RECORD_BYTES:
        raise ValueError("oversize")
    return data


def system_clock():
    from .. import lifecycle_lease

    class Clock:
        boottime_ns = staticmethod(lifecycle_lease.host_boottime_ns)
        boot_id = staticmethod(lifecycle_lease.host_boot_id)
        wall_ns = staticmethod(time.time_ns)

        async def sleep_ns(self, ns):
            await asyncio.sleep(ns / 1_000_000_000)

    return Clock()


def default_read_ledger():
    from .account_risk import read_ledger
    # Classification uses active entries; the ticker query covers archived sentinel collisions.
    return partial(read_ledger, hot=True, ticker=SENTINEL_TICKER)


def _safe_file(info, uid):
    return (stat.S_ISREG(info.st_mode) and info.st_nlink == 1
            and (os.name != "posix" or (info.st_uid == uid and not info.st_mode & 0o002)))


def read_hot(path, expected_account_digest, expected_revision, *, clock=None, expected_uid=None):
    try:
        uid = os.geteuid() if expected_uid is None and os.name == "posix" else expected_uid
        try:
            info = os.lstat(path)
        except FileNotFoundError:
            return Miss("absent")
        if not _safe_file(info, uid):
            return Miss("malformed", "unsafe_file")
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0))
        with os.fdopen(fd, "rb") as stream:
            held = os.fstat(stream.fileno())
            if not _safe_file(held, uid) or (info.st_dev, info.st_ino) != (held.st_dev, held.st_ino):
                return Miss("malformed", "unsafe_file")
            data = stream.read(MAX_RECORD_BYTES + 1)
        try:
            r = decode_record(data)
        except ValueError as exc:
            return Miss("malformed", str(exc))
        if r["account_digest"] != expected_account_digest:
            return Miss("wrong_account")
        clock = system_clock() if clock is None else clock
        now, boot = clock.boottime_ns(), clock.boot_id()
        if now is None or boot is None:
            return Miss("stale", "clock_unavailable")
        if boot != r["boot_id"]:
            return Miss("stale", "boot_mismatch")
        if r["read_end_ns"] > now:
            return Miss("stale", "future")
        age = now - r["read_start_ns"]
        if age > age_limit_ns(r["cycle_ns"]):
            return Miss("stale", "age")
        if r["ledger_revision"] != expected_revision:
            return Miss("revision_mismatch")
        if r["widened"]:
            return Miss("widened")
        return Observation(r["account_digest"], r["ledger_revision"], r["cash_cents"],
                           tuple(r["positions_rows"]), r["read_start_ns"], r["read_end_ns"],
                           age, r["cycle_id"], r["cycle_ns"])
    except Exception:
        return Miss("malformed", "error")


class FilePublisher:
    def __init__(self, directory, *, expected_uid=None):
        self.directory = Path(directory)
        self.uid = os.geteuid() if expected_uid is None and os.name == "posix" else expected_uid
        self.fd = None

    def check_directory(self):
        try:
            info = os.lstat(self.directory)
            if (not stat.S_ISDIR(info.st_mode) or (os.name == "posix"
                    and (info.st_uid != self.uid or info.st_mode & 0o002))):
                return "unsafe_directory"
        except OSError:
            return "unsafe_directory"
        return None

    def acquire(self):
        if self.fd is not None:
            return None
        if self.check_directory():
            return "unsafe_directory"
        fd = None
        try:
            path = self.directory / LOCK_NAME
            if path.is_symlink():
                return "unsafe_directory"
            fd = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o640)
            if not _safe_file(os.fstat(fd), self.uid):
                os.close(fd)
                return "unsafe_directory"
            if os.name == "posix":
                import fcntl
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            else:
                import msvcrt
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            self.fd = fd
            return None
        except OSError:
            if fd is not None:
                os.close(fd)
            return "publisher_busy"

    def publish(self, data):
        if self.fd is None or self.check_directory():
            raise ValueError("publisher not acquired")
        temp = self.directory / (".observation-" + secrets.token_hex(16) + ".tmp")
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0), 0o640)
        try:
            try:
                view = memoryview(data)
                while view:
                    count = os.write(fd, view)
                    if count <= 0:
                        raise OSError("short write")
                    view = view[count:]
            finally:
                os.close(fd)
            os.replace(temp, self.directory / OBSERVATION_NAME)
        finally:
            try:
                temp.unlink()
            except FileNotFoundError:
                pass

    __call__ = publish

    def close(self):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None


def signed_getter(key_id, private_key_pem, base_url):
    class Getter:
        session = None

        async def __call__(self, path, params):
            if path not in (BALANCE_PATH, POSITIONS_PATH):
                raise ValueError("path not allowed")
            import aiohttp
            from ..feeds.kalshi import sign
            if self.session is None:
                self.session = aiohttp.ClientSession(
                    connector=aiohttp.TCPConnector(limit=2, keepalive_timeout=75),
                    timeout=aiohttp.ClientTimeout(total=None, connect=CONNECT_TIMEOUT_S))
            ts = time.time_ns() // 1_000_000
            headers = {"KALSHI-ACCESS-KEY": key_id, "KALSHI-ACCESS-TIMESTAMP": str(ts),
                       "KALSHI-ACCESS-SIGNATURE": sign(ts, "GET", path, private_key_pem)}
            async with self.session.get(base_url.rstrip("/") + path, params=params,
                                        headers=headers, allow_redirects=False) as response:
                try:
                    retry = float(response.headers.get("Retry-After", "0"))
                    retry = min(300, max(0, retry)) if math.isfinite(retry) else 0
                except (TypeError, ValueError):
                    retry = 0
                body = await response.json() if response.status == 200 else None
                return HttpReply(response.status, body, retry)

        async def close(self):
            if self.session is not None:
                await self.session.close()
                self.session = None

    return Getter()


class _CycleFailure(Exception):
    def __init__(self, detail, retry=0):
        self.detail, self.retry = detail, retry


class HotRefresher:
    def __init__(self, config, *, clock, read_ledger, budget, get, windows, publish):
        self.config, self.clock, self.read_ledger = config, clock, read_ledger
        self.budget, self.get, self.windows, self.publish = budget, get, windows, publish
        self.last_gets = 2
        self.cycle_ns = EARLY_CYCLE_NS
        self._token_delay, self._http_delay = TOKEN_BACKOFF_NS, HTTP429_BACKOFF_S
        self._started = False
        self._start_error = None
        self._prefix, self._seq = secrets.token_hex(16), 0

    def check_start(self):
        if self._started:
            return self._start_error
        self._started = True
        b, c = self.budget, self.config
        if b is None:
            code = "budget_missing"
        elif b.scope != "read":
            code = "budget_scope"
        elif not b.matches_key(c.key_id):
            code = "budget_key"
        elif b.config.exit_reserve < RESERVE_READS:
            code = "budget_reserve"
        elif c.read_budget_wired is not True:
            code = "budget_unwired"
        elif self.clock.boottime_ns() is None or self.clock.boot_id() is None:
            code = "clock_unavailable"
        else:
            code = self.publish.acquire()
        self._start_error = code
        return code

    def _token(self):
        if not self.budget.acquire("discretionary").admitted:
            raise _CycleFailure("token_refused")

    async def _request(self, path, params):
        reply = await self.get(path, params)
        if reply.status == 429:
            raise _CycleFailure("http_429", reply.retry_after_s)
        if reply.status != 200:
            raise _CycleFailure("http_error")
        return reply.body

    async def _first(self):
        tasks = [asyncio.create_task(self._request(BALANCE_PATH, {})),
                 asyncio.create_task(self._request(POSITIONS_PATH,
                     {"limit": "1000", "count_filter": "position"}))]
        try:
            return await asyncio.gather(*tasks)
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _backoff(self, detail, gets, retry=0):
        if detail == "http_429":
            self.budget.note_http(429)
            retry = retry if type(retry) in (int, float) and math.isfinite(retry) else 0
            delay = max(self._http_delay, min(300, max(0, retry))) * 1_000_000_000
            self._http_delay = min(30, self._http_delay * 2)
        else:
            delay = self._token_delay
            self._token_delay = min(1_000_000_000, delay * 2)
        await self.clock.sleep_ns(int(delay))
        return CycleResult("backoff", detail, gets)

    async def run_cycle(self):
        code = self.check_start()
        if code:
            return CycleResult("refused", code, 0)
        try:
            view = self.windows()
            if (not isinstance(view, WindowView) or type(view.closes_ms) is not tuple
                    or len(view.closes_ms) > 256 or any(type(x) is not int for x in view.closes_ms)
                    or not isinstance(view.minutes, Mapping)
                    or any(type(k) is not str or not _whole(v, 2**63 - 1) for k, v in view.minutes.items())):
                return CycleResult("idle", "", 0)
            current = phase(self.clock.wall_ns() // 1_000_000, view.closes_ms, self.config.window_s)
        except Exception:
            return CycleResult("idle", "", 0)
        plan = cycle_plan(self.budget.config.write_per_s, self.config.routine_milli_per_s, self.last_gets)
        if current == "idle" or plan is None:
            return CycleResult("idle", "", 0)
        self.cycle_ns = plan[current == "final"]
        if self.cycle_ns > AGE_CAP_NS:
            return CycleResult("idle", "", 0)
        try:
            ledger = self.read_ledger(self.config.ledger_path, self.config.account_id,
                                      legacy_paths=self.config.legacy_paths)
            if ledger["status"] != "ok" or not ledger["healthy"]:
                raise ValueError("unhealthy")
            revision = ledger["state"]["revision"]
            entries = deepcopy(ledger["state"]["entries"])
            if not _whole(revision, 2**53 - 1) or type(entries) is not dict:
                raise ValueError("unhealthy")
        except Exception:
            return CycleResult("skipped", "ledger_unhealthy", 0)
        gets = 0
        try:
            self._token()
            self._token()
            start = self.clock.boottime_ns()
            if start is None:
                raise _CycleFailure("deadline")
            deadline = start + age_limit_ns(self.cycle_ns)
            async with asyncio.timeout(age_limit_ns(self.cycle_ns) / 1_000_000_000):
                gets = 2
                balance, page = await self._first()
                if type(balance) is not dict or not _whole(balance.get("balance"), 2**53 - 1):
                    raise _CycleFailure("malformed_balance")
                rows, seen = [], set()
                for index in range(MAX_PAGES):
                    batch = page.get("market_positions") if type(page) is dict else None
                    cursor = page.get("cursor", "") if type(page) is dict else None
                    if (type(batch) is not list or len(batch) > PAGE_ROWS
                            or any(type(row) is not dict for row in batch)
                            or type(cursor) is not str or len(cursor) > 1024):
                        raise _CycleFailure("malformed_positions")
                    rows.extend(batch)
                    if not cursor:
                        break
                    if cursor in seen:
                        raise _CycleFailure("cursor_loop")
                    seen.add(cursor)
                    if index == MAX_PAGES - 1:
                        raise _CycleFailure("page_limit")
                    now = self.clock.boottime_ns()
                    if now is None or not start <= now <= deadline:
                        raise _CycleFailure("deadline")
                    self._token()
                    gets += 1
                    page = await self._request(POSITIONS_PATH, {"limit": "1000",
                        "count_filter": "position", "cursor": quote(cursor, safe="")})
            end = self.clock.boottime_ns()
            self.last_gets = max(2, gets)
            if end is None or not start <= end <= deadline:
                raise _CycleFailure("deadline")
        except _CycleFailure as exc:
            if exc.detail in ("token_refused", "http_429", "http_error"):
                return await self._backoff(exc.detail, gets, exc.retry)
            return CycleResult("skipped", exc.detail, gets)
        except TimeoutError:
            return await self._backoff("timeout", gets)
        except Exception:
            return await self._backoff("http_error", gets)
        from .account_risk import AccountRiskRefused, classify_tickers
        if (any(row.get("ticker") == SENTINEL_TICKER for row in rows)
                or any(entry.get("ticker") == SENTINEL_TICKER for entry in entries.values())
                or ledger["state"].get("archive", {}).get("ticker_exists", False)):
            return CycleResult("skipped", "sentinel_collision", gets)
        try:
            result = classify_tickers(entries, rows, requested=SENTINEL_TICKER,
                now_ns=self.clock.wall_ns(), worst_cents=self.config.worst_cents, minutes=view.minutes)
        except AccountRiskRefused:
            return CycleResult("skipped", "classification_refused", gets)
        self._seq += 1
        try:
            data = encode_record(account_digest=self.config.account_digest, ledger_revision=revision,
                cash_cents=balance["balance"], positions_rows=rows, read_start_ns=start,
                read_end_ns=end, cycle_id=f"{self._prefix}-{self._seq}", cycle_ns=self.cycle_ns,
                widened=bool(result.widened or result.refusal is not None), boot_id=self.clock.boot_id())
        except ValueError as exc:
            return CycleResult("skipped", "oversize" if str(exc) == "oversize" else "publish_failed", gets)
        try:
            self.publish(data)
        except Exception:
            return CycleResult("skipped", "publish_failed", gets)
        self._token_delay, self._http_delay = TOKEN_BACKOFF_NS, HTTP429_BACKOFF_S
        return CycleResult("published", "", gets)

    async def run(self, stop):
        if self.check_start():
            return
        try:
            while not stop.is_set():
                start = self.clock.boottime_ns()
                result = await self.run_cycle()
                if result.status == "refused":
                    return
                if result.status == "idle":
                    await self.clock.sleep_ns(1_000_000_000)
                else:
                    now = self.clock.boottime_ns()
                    if start is None or now is None:
                        return
                    await self.clock.sleep_ns(max(0, start + self.cycle_ns - now))
        finally:
            self.publish.close()
