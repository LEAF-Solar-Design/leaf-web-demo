"""Live execution for leafhft, still disabled by live_gate.LIVE_DRIVER_AVAILABLE.

The engine's synchronous calls share one private asyncio loop for the signed client.
LiveEngine supplies the mark and shutdown hooks without changing the paper engine.
Only venue trades, never public prints or order status, produce accounting fills.
"""
from __future__ import annotations

import asyncio
import json
import logging
import secrets
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from datetime import datetime, timezone

from ..engine import Engine
from ..fees import FeeSchedule
from ..types import (
    QUOTE_UNIT, SIZE_UNIT, Fill, Intent, Liquidity, Order, OrderStatus, OrderType, Quote,
    Side, Trade, notional_q, to_price_i, to_quote_q, to_size_i,
)
from .base import Broker, BrokerView, OpenOrderView
from .binanceus_live import BinanceUSLive, OrderStateUnknown, TERMINAL, VenueError, _decimal
from .live_gate import LiveAuthorization, LiveGateClosed, OrderRefused

POLL_NS = 1_000_000_000
ACCOUNT_NS = 5_000_000_000
BALANCE_DUST_Q = 1
MIN_START_CASH_Q = 1 * QUOTE_UNIT  # venue minimum order notional; floor when adopting inventory
log = logging.getLogger(__name__)


class LiveClientIO:
    """Keep the session, locks and all signed requests on the same event loop.

Create/enter the client through run() too. Blocking here is intentional: the
Broker contract is synchronous, including when called inside Engine.run_live.
"""

    def __init__(self) -> None:
        self._pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="leafhft-live")
        self._runner = asyncio.Runner()
        self._closed = False

    def run(self, coroutine):
        if self._closed:
            coroutine.close()
            raise LiveGateClosed("live client loop closed")
        return self._pool.submit(self._runner.run, coroutine).result()

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            try:
                self._pool.submit(self._runner.close).result()
            finally:
                self._pool.shutdown(wait=True)


def _number(value, parse):
    # Bound exponent/length before the fixed-point parser does integer arithmetic.
    _decimal(value)
    return parse(value)


class LiveBroker(Broker):
    venue = "binanceus"

    def __init__(
        self, client: BinanceUSLive, auth: LiveAuthorization, fees: FeeSchedule,
        symbol: str, account_snapshot: dict, *, allow_existing_inventory: bool = False,
        starting_cash_q: int | None = None, taker_slippage_bps: int = 2,
        io: LiveClientIO | None = None,
    ) -> None:
        if client.auth is not auth or auth.venue != self.venue or symbol != auth.symbol:
            raise LiveGateClosed("live broker authorization mismatch")
        auth.check(time.time_ns())
        if len(symbol.split("-")) != 2:
            raise LiveGateClosed("live symbol must name base and quote assets")
        self.symbol, self.client, self.auth, self.fees = symbol, client, auth, fees
        self.base_asset, self.quote_asset = symbol.upper().split("-")
        stake = auth.max_stake_q if starting_cash_q is None else starting_cash_q
        if type(stake) is not int or not 0 < stake <= auth.max_stake_q:
            raise LiveGateClosed("starting cash exceeds authorization")
        if type(taker_slippage_bps) is not int or not 0 <= taker_slippage_bps <= 500:
            raise LiveGateClosed("invalid liquidation slippage")
        self.taker_slippage_bps = taker_slippage_bps
        balances = self._balances(account_snapshot)
        cash, cash_locked, pos, pos_locked = balances
        self.start_cash_below_stake = False
        if allow_existing_inventory and pos > 0:
            if cash < MIN_START_CASH_Q:
                raise LiveGateClosed("free quote balance below the venue minimum")
            if cash < stake - BALANCE_DUST_Q:
                log.warning("live start with cash below stake: cash=%s stake=%s inventory=%s adopted",
                            cash / QUOTE_UNIT, stake / QUOTE_UNIT, pos / SIZE_UNIT)
                self.start_cash_below_stake = True
        elif cash < stake - BALANCE_DUST_Q:
            raise LiveGateClosed("free quote balance below starting cash")
        self.start_cash_q = cash
        if pos + pos_locked and not allow_existing_inventory:
            raise LiveGateClosed("existing base inventory requires explicit permission")
        if cash_locked or pos_locked:
            raise LiveGateClosed("locked balances must be reconciled before seeding")
        if any(state not in TERMINAL for state in client._owned.values()):
            raise LiveGateClosed("existing journal orders must be reconciled before seeding")
        self.cash_q, self.pos_i = cash, pos
        self.adopted_inventory_i = pos
        self.avg_cost_i = self.realized_q = self.fees_paid_q = 0
        self.fills_total = self.orders_total = self.rejected_total = 0
        self.maker_fills = self.taker_fills = 0
        self.halted = False
        self._quote: Quote | None = None
        self._orders: dict[int, Order] = {}
        self.client_ids: dict[int, str] = {}
        self._live_ids: dict[int, str] = {}  # non-terminal orders only; bounds _sync_orders to O(open)
        self._next_id = 1
        self._pending_fills: deque[Fill] = deque()
        self._failed_cancels: set[str] = set()
        self._cancel_ack: dict[Side, bool] = {}
        self._soft_rejects = {Side.BUY: 0, Side.SELL: 0}
        self._balance_soft_rejects_total = 0
        self._cross_rejects_total = 0
        self._cross_reject_ts: deque[int] = deque(maxlen=64)  # ring for the 60s storm bound
        self._skipped_cycle: dict[Side, int] = {}
        self._unknown: set[str] = set()
        self._poll_error = ""
        self._last_poll_ns: int | None = None
        self._last_account_ns = time.time_ns()  # the supplied account snapshot is the first read
        self._last_trade_id = -1
        self._account = balances
        self._initial_account = balances
        self._account_day = ""
        self._account_start_q: int | None = None
        self._account_state = client.journal_path.parent / "live-account-state.json"
        self._load_account_epoch()
        self.io = io or LiveClientIO()
        self._closed = False
        self.client.position_i = pos

    def _balances(self, snapshot: dict) -> tuple[int, int, int, int]:
        try:
            if not isinstance(snapshot, dict) or not isinstance(snapshot.get("balances"), list):
                raise ValueError("balances")
            if len(snapshot["balances"]) > 10_000 or snapshot.get("canTrade", True) is not True:
                raise ValueError("account unavailable")
            rows = {}
            for row in snapshot["balances"]:
                if not isinstance(row, dict):
                    raise ValueError("balance row")
                asset = row["asset"]
                if not isinstance(asset, str) or not asset or len(asset) > 32 or asset in rows:
                    raise ValueError("balance asset")
                parse = to_size_i if asset == self.base_asset else to_quote_q
                rows[asset] = (_number(row["free"], parse), _number(row["locked"], parse))
            return (*rows[self.quote_asset], *rows[self.base_asset])
        except (KeyError, ValueError, TypeError) as e:
            raise LiveGateClosed("malformed account balances") from e

    def _load_account_epoch(self) -> None:
        try:
            with self._account_state.open("rb") as stream:
                raw = stream.read(4097)
        except FileNotFoundError:
            return
        try:
            state = json.loads(raw)
            day = state["day"]
            if (len(raw) > 4096 or state["symbol"] != self.symbol
                    or datetime.strptime(day, "%Y-%m-%d").date().isoformat() != day
                    or day > datetime.now(timezone.utc).date().isoformat()
                    or type(state["equity_q"]) is not int or state["equity_q"] < 0):
                raise ValueError("account epoch")
            self._account_day, self._account_start_q = day, state["equity_q"]
        except (KeyError, ValueError, TypeError) as e:
            raise LiveGateClosed("malformed account loss epoch") from e

    def _account_value(self, balances) -> int:
        cash, locked, pos, pos_locked = balances
        mid = self._quote.mid_i if self._quote is not None else 0
        return cash + locked + notional_q(mid, pos + pos_locked)

    def account_equity_q(self) -> int:
        return self._account_value(self._account)

    def account_risk_equity_q(self, day_start_q: int) -> int:
        today = datetime.now(timezone.utc).date().isoformat()
        if self._account_start_q is None or today != self._account_day:
            initial = self._initial_account if self._account_start_q is None else self._account
            self._account_start_q = self._account_value(initial)
            self._account_day = today
            data = {"symbol": self.symbol, "day": today, "equity_q": self._account_start_q}
            temp = self._account_state.with_suffix(".tmp")
            temp.write_text(json.dumps(data), encoding="utf-8")
            temp.replace(self._account_state)
        return day_start_q + self.account_equity_q() - self._account_start_q

    def _refresh_balances(self, now_ns: int) -> None:
        self._last_account_ns = now_ns
        try:
            self._account = self._balances(self.io.run(self.client.account()))
        except Exception as e:
            self.halted = True
            raise LiveGateClosed("live balance refresh failed: " + type(e).__name__) from e
        log.warning("live balances quote_free_q=%d quote_locked_q=%d base_free_i=%d base_locked_i=%d",
                    *self._account)

    def submit(self, intent: Intent, strategy: str = "live", now_ns: int | None = None) -> Order:
        if type(strategy) is int and now_ns is None:
            now_ns, strategy = strategy, "live"
        now_ns = time.time_ns() if now_ns is None else now_ns
        if self.halted or self._closed:
            raise LiveGateClosed("live broker halted; reconcile before submitting")
        ref = self._quote.mid_i if self._quote is not None else intent.price_i
        gate_reject = None
        try:
            self.auth.check_order(intent, ref, now_ns, self.pos_i, self.open_notional_q(), reserve=False)
        except OrderRefused as e:
            # A per-order rule refusal is a rejected order, never a dead run; authorization state
            # failures (expired, killed) still raise LiveGateClosed above this line.
            gate_reject = f"gate: {e}"
        already_skipped = self._skipped_cycle.get(intent.side) == now_ns
        balance_reject = None
        if gate_reject is None and not already_skipped:
            if intent.side is Side.SELL:
                balance_reject = "sell exceeds free base balance" if (
                    intent.size_i > self.pos_i - self.pending_i(Side.SELL)) else None
            else:
                reserved = sum(notional_q(o.price_i, o.remaining_i) + self.fees.fee_q(
                    o.price_i, o.remaining_i, Liquidity.TAKER) for o in self._active() if o.side is Side.BUY)
                required = notional_q(intent.price_i, intent.size_i) + self.fees.fee_q(
                    intent.price_i, intent.size_i, Liquidity.TAKER)
                balance_reject = "buy exceeds free quote balance" if required > self.cash_q - reserved else None
        order = Order(self._next_id, self.venue, self.symbol, intent.side, OrderType.LIMIT,
                      intent.tif, intent.price_i, intent.size_i, now_ns, strategy,
                      reason=intent.reason, ts_active_ns=now_ns)
        self._next_id += 1
        cid = "lh-" + secrets.token_hex(12)
        self._orders[order.id], self.client_ids[order.id] = order, cid
        self.orders_total += 1
        if gate_reject is not None:
            order.status = OrderStatus.REJECTED
            order.reason = gate_reject
            self.rejected_total += 1
            log.warning("live gate refused order side=%d reason=%s", int(intent.side), gate_reject)
            return order
        if balance_reject is not None:
            order.status = OrderStatus.REJECTED
            order.reason = balance_reject
            self.rejected_total += 1
            self._skipped_cycle[intent.side] = now_ns
            log.warning("live balance preflight rejected side=%d reason=%s", int(intent.side), balance_reject)
            return order
        if already_skipped:
            order.status = OrderStatus.REJECTED
            order.reason = "side skipped for quote cycle"
            self.rejected_total += 1
            return order
        if intent.side in self._cancel_ack:
            if not self._cancel_ack[intent.side]:
                order.status = OrderStatus.REJECTED
                self.rejected_total += 1
                raise LiveGateClosed("replacement requires CANCELED acknowledgement")
            needed = (intent.size_i if intent.side is Side.SELL else
                      notional_q(intent.price_i, intent.size_i) + self.fees.fee_q(
                          intent.price_i, intent.size_i, Liquidity.TAKER))
            balance_index = 2 if intent.side is Side.SELL else 0
            if self._account[balance_index] < needed:
                self._refresh_balances(now_ns)
            if self._account[balance_index] < needed:
                order.status = OrderStatus.REJECTED
                order.reason = "replacement awaiting free balance"
                self.rejected_total += 1
                self._skipped_cycle[intent.side] = now_ns
                log.warning("live replacement skipped side=%d free=%d required=%d",
                            int(intent.side), self._account[balance_index], needed)
                return order
        self.client.position_i = self.pos_i
        self._live_ids[order.id] = cid
        reserved_before = self.auth.budget.reserved_notional_q
        reply = None
        try:
            reply = self.io.run(self.client.place(intent, cid, ref))
        except OrderStateUnknown:
            self.halted = True
            self._unknown.add(cid)
            raise
        except Exception as e:
            if self.client._owned.get(cid) in (None, "GONE"):
                order.status = OrderStatus.REJECTED
                self.rejected_total += 1
                self.auth.budget.on_cancel(max(0, self.auth.budget.reserved_notional_q - reserved_before))
                if (isinstance(e, VenueError) and e.code == -2010
                        and 400 <= e.http < 500 and self.client._owned.get(cid) == "GONE"):
                    if e.kind == "cross":
                        self._cross_rejects_total += 1
                        self._skipped_cycle[intent.side] = now_ns
                        order.reason = "post-only would cross (-2010)"
                        self._cross_reject_ts.append(now_ns)
                        while self._cross_reject_ts and now_ns - self._cross_reject_ts[0] > 60_000_000_000:
                            self._cross_reject_ts.popleft()
                        if len(self._cross_reject_ts) <= 20:
                            return order
                        self.halted = True
                        raise LiveGateClosed("post-only cross storm; feed too stale") from e
                    self._soft_rejects[intent.side] += 1
                    self._balance_soft_rejects_total += 1
                    self._skipped_cycle[intent.side] = now_ns
                    order.reason = "venue insufficient balance (-2010)"
                    log.warning("live soft reject code=-2010 side=%d consecutive=%d",
                                int(intent.side), self._soft_rejects[intent.side])
                    self._refresh_balances(now_ns)
                    if self._soft_rejects[intent.side] < 3:
                        return order
            else:
                self.halted = True
                self._unknown.add(cid)
            raise LiveGateClosed("live submission failed: " + type(e).__name__) from e
        if isinstance(reply, dict) and reply.get("status") == "REJECTED" and reply.get("orderId") is None:
            # The client refused this order on a per-order gate rule before transmission (OrderRefused):
            # nothing was sent and nothing was reserved, so it is a rejected order and never a release.
            order.status = OrderStatus.REJECTED
            order.reason = "gate refusal before transmission"
            self.rejected_total += 1
            self._skipped_cycle[intent.side] = now_ns
            self._live_ids.pop(order.id, None)
            log.warning("live gate refused order side=%d before transmission", int(intent.side))
            return order
        self._soft_rejects[intent.side] = 0
        self._cancel_ack.pop(intent.side, None)
        self._sync_orders(now_ns)
        return order

    def _active(self):
        return (o for o in self._orders.values() if not o.status.terminal)

    def _sync_orders(self, now_ns: int) -> None:
        # Iterate only live (non-terminal) orders: a terminal order pruned from the client's
        # journal by compaction must never be re-looked-up, or it would read back as UNKNOWN.
        for oid, cid in list(self._live_ids.items()):
            order = self._orders[oid]
            if order.status is OrderStatus.REJECTED and cid not in self.client._owned:
                del self._live_ids[oid]
                continue  # preflight refused before this client id could be sent
            state = self.client._owned.get(cid, "UNKNOWN")
            executed = self.client._records.get(cid, {}).get("executed_qty_i", 0)
            if state in {"SENT", "UNKNOWN"} or executed > order.filled_i:
                self._unknown.add(cid)
                self.halted = True
                continue  # a terminal status cannot discard an unaccounted execution
            self._unknown.discard(cid)
            if state in TERMINAL and not order.status.terminal:
                self.auth.budget.on_cancel(notional_q(order.price_i, order.remaining_i))
                order.status = OrderStatus.FILLED if order.remaining_i == 0 else OrderStatus.CANCELED
            elif not order.status.terminal:
                order.status = OrderStatus.PARTIAL if order.filled_i else OrderStatus.OPEN
            order.ts_updated_ns = now_ns
            if order.status.terminal and state in TERMINAL:
                del self._live_ids[oid]

    def cancel(self, order_id: int, now_ns: int | None = None) -> bool:
        order = self._orders.get(order_id)
        if order is None or order.status.terminal:
            return False
        cid = self.client_ids[order_id]
        now_ns = time.time_ns() if now_ns is None else now_ns
        try:
            reply = self.io.run(self.client.cancel(cid))
            self._cancel_ack[order.side] = reply.get("status") == "CANCELED"
            executed = self.client._records.get(cid, {}).get("executed_qty_i", 0)
            if executed > order.filled_i:
                # The venue may have filled this order before the cancel landed; pull myTrades
                # and book it before syncing, so a fill discovered here is not mistaken for an
                # unaccounted execution and halted.
                self.io.run(self._refresh(now_ns, False))
                if order.status.terminal:
                    # A filled order needs no CANCELED acknowledgement to unblock replacement.
                    self._cancel_ack[order.side] = True
            else:
                self._sync_orders(now_ns)
            return cid not in self._unknown
        except Exception:
            self._failed_cancels.add(cid)
            self._unknown.add(cid)
            self.halted = True
            return False

    def cancel_all(self, now_ns: int) -> int:
        return sum(self.cancel(o.id, now_ns) for o in list(self._active()))

    def _trade(self, row: dict) -> tuple[int, Order | None, Fill | None, int, int]:
        if not isinstance(row, dict) or row.get("symbol") != self.symbol.replace("-", "").upper():
            raise ValueError("trade symbol")
        tid, venue_id = row.get("id"), row.get("orderId")
        if type(tid) is not int or not 0 <= tid < 2**63 or type(venue_id) is not int or venue_id < 0:
            raise ValueError("trade identity")
        if type(row.get("isBuyer")) is not bool or type(row.get("isMaker")) is not bool:
            raise ValueError("trade flags")
        ts = row.get("time")
        if type(ts) is not int or not 0 <= ts <= 4_102_444_800_000:
            raise ValueError("trade timestamp")
        price, size = _number(row["price"], to_price_i), _number(row["qty"], to_size_i)
        if not price or not size:
            raise ValueError("empty trade")
        commission = _number(row["commission"], to_quote_q)
        asset = row["commissionAsset"]
        if not isinstance(asset, str) or not asset or len(asset) > 32:
            raise ValueError("commission asset")
        reply_cid = row.get("clientOrderId")
        if reply_cid is not None and (not isinstance(reply_cid, str) or not 0 < len(reply_cid) <= 36):
            raise ValueError("trade client id")
        matches = [(oid, cid) for oid, cid in self.client_ids.items()
                   if self.client._records.get(cid, {}).get("venue_order_id") == venue_id
                   or cid == reply_cid]
        if len(matches) > 1:
            raise ValueError("ambiguous trade identity")
        order = self._orders[matches[0][0]] if matches else None
        if order is None:
            if reply_cid is None and any(
                self.client._records.get(self.client_ids[o.id], {}).get("venue_order_id") is None
                for o in self._active()
            ):
                # Do not advance past a trade that a timed-out submit may own.
                raise ValueError("trade ownership unresolved")
            return tid, None, None, 0, 0  # historical or foreign account trades do not fill our orders
        cid = self.client_ids[order.id]
        known_id = self.client._records.get(cid, {}).get("venue_order_id")
        if (reply_cid is not None and reply_cid != cid) or (known_id is not None and known_id != venue_id):
            raise ValueError("trade client id mismatch")
        side = Side.BUY if row["isBuyer"] else Side.SELL
        if side is not order.side or (side is Side.BUY and price > order.price_i) or (side is Side.SELL and price < order.price_i):
            raise ValueError("trade disagrees with order")
        base_fee = commission if asset == self.base_asset else 0
        if commission and asset not in (self.base_asset, self.quote_asset):
            raise ValueError("cannot value third-asset commission")
        fee_q = -(-price * base_fee // SIZE_UNIT) if base_fee else commission
        quote_fee = commission if asset == self.quote_asset else 0
        fill = Fill(order.id, self.venue, self.symbol, side, price, size, fee_q,
                    Liquidity.MAKER if row["isMaker"] else Liquidity.TAKER, ts * 1_000_000, order.strategy)
        return tid, order, fill, base_fee, quote_fee

    def _ingest(self, rows: list) -> None:
        if not isinstance(rows, list) or len(rows) > 1000:
            raise ValueError("trade page")
        parsed = [self._trade(row) for row in rows]
        ids = [item[0] for item in parsed]
        if ids != sorted(set(ids)):
            raise ValueError("trade pagination")
        # Validate the whole page before mutating balances or advancing the cursor.
        quantities: dict[int, int] = {}
        cash, pos = self.cash_q, self.pos_i
        for tid, order, fill, base_fee, quote_fee in parsed:
            if tid <= self._last_trade_id or fill is None:
                continue
            total = quantities.get(order.id, 0) + fill.size_i
            if order.status.terminal or total > order.remaining_i:
                raise ValueError("trade exceeds remaining order")
            quantities[order.id] = total
            cash -= fill.side.sign * fill.notional_q + quote_fee
            pos += fill.side.sign * fill.size_i - base_fee
            if cash < 0 or pos < 0:
                raise ValueError("trade exceeds account balances")
        for tid, order, fill, base_fee, quote_fee in parsed:
            if tid <= self._last_trade_id:
                continue
            if fill is not None:
                old_pos = self.pos_i
                order.record_fill(fill.size_i, fill.ts_ns)
                self.cash_q -= fill.side.sign * fill.notional_q + quote_fee
                self.pos_i += fill.side.sign * fill.size_i - base_fee
                if fill.side is Side.BUY and self.pos_i:
                    self.avg_cost_i = (self.avg_cost_i * old_pos + fill.price_i * fill.size_i) // self.pos_i
                elif fill.side is Side.SELL:
                    self.realized_q += (fill.price_i - self.avg_cost_i) * fill.size_i // SIZE_UNIT
                if not self.pos_i:
                    self.avg_cost_i = 0
                self.fees_paid_q += fill.fee_q
                self.fills_total += 1
                self.maker_fills += fill.liquidity is Liquidity.MAKER
                self.taker_fills += fill.liquidity is Liquidity.TAKER
                reserved_q = self.auth.budget.reserved_notional_q
                self.auth.budget.on_fill(fill.side, fill.notional_q)
                # Release the limit-price reservation even with price improvement.
                self.auth.budget.reserved_notional_q = max(
                    0, reserved_q - notional_q(order.price_i, fill.size_i))
                self._pending_fills.append(fill)
            self._last_trade_id = tid
        self.client.position_i = self.pos_i

    async def _refresh(self, now_ns: int, reconcile: bool) -> None:
        opened = await self.client.open_orders()
        if not isinstance(opened, list) or len(opened) > 1000:
            raise ValueError("open orders")
        seen = set()
        seen_ids = set()
        for row in opened:
            self.client._validate_reply("/api/v3/order", row, {"origClientOrderId": row.get("clientOrderId")})
            cid = row.get("clientOrderId")
            if not isinstance(cid, str) or not cid or cid in seen or row["orderId"] in seen_ids:
                raise ValueError("open order identity")
            seen.add(cid)
            seen_ids.add(row["orderId"])
        # The client alone journals state, including missing orders and ambiguous cancels.
        await self.client.reconcile()
        for _ in range(100):
            cursor = self._last_trade_id
            rows = await self.client.my_trades(from_id=cursor + 1, limit=1000)
            self._ingest(rows)
            if len(rows) < 1000:
                break
            if self._last_trade_id <= cursor:
                raise ValueError("trade pagination made no progress")
        else:
            raise ValueError("trade history scan limit")
        if now_ns - self._last_account_ns >= ACCOUNT_NS:
            self._last_account_ns = now_ns  # failed reads are bounded too
            self._account = self._balances(await self.client.account())
        self._sync_orders(now_ns)
        self._poll_error = ""
        if reconcile:
            self._failed_cancels = {cid for cid in self._failed_cancels
                                    if self.client._owned.get(cid) not in TERMINAL or cid in self._unknown}
            self.halted = bool(self._unknown or self.client.unresolved or self._failed_cancels
                               or self.client._journal_failed)

    def poll(self, now_ns: int, *, force: bool = False) -> list[Fill]:
        if not self._closed and (force or self._last_poll_ns is None or now_ns - self._last_poll_ns >= POLL_NS):
            self._last_poll_ns = now_ns
            try:
                self.io.run(self._refresh(now_ns, False))
            except Exception as e:
                self._poll_error = "execution reports: " + type(e).__name__
                self.halted = True
        fills = list(self._pending_fills)
        self._pending_fills.clear()
        return fills

    def reconcile(self, now_ns: int | None = None) -> dict:
        now_ns = time.time_ns() if now_ns is None else now_ns
        self._last_poll_ns = now_ns
        try:
            self.io.run(self._refresh(now_ns, True))
        except Exception as e:
            self._poll_error = "reconcile: " + type(e).__name__
            self.halted = True
        return self.live_summary()

    def on_quote(self, q: Quote, now_ns: int) -> list[Fill]:
        if q.venue != self.venue or q.symbol != self.symbol:
            raise LiveGateClosed("quote identity mismatch")
        self._skipped_cycle.clear()
        self._quote = q
        return self.poll(now_ns)

    def on_trade(self, t: Trade, now_ns: int) -> list[Fill]:
        return self.poll(now_ns)

    def on_mark(self, now_ns: int) -> list[Fill]:
        return self.poll(now_ns)

    def settle(self, now_ns: int) -> list[Fill]:
        return self.poll(now_ns, force=True)

    def equity_q(self, mid_i: int) -> int:
        return self.cash_q + notional_q(mid_i, self.pos_i)

    def liquidation_q(self, bid_i: int | None = None) -> int:
        bid = bid_i if bid_i is not None else (self._quote.bid_i if self._quote else 0)
        px = bid - bid * self.taker_slippage_bps // 10_000
        return self.cash_q + notional_q(px, self.pos_i) - self.fees.fee_q(px, self.pos_i, Liquidity.TAKER)

    def open_notional_q(self) -> int:
        return sum(notional_q(o.price_i, o.remaining_i) for o in self._active())

    def pending_i(self, side: Side) -> int:
        return sum(o.remaining_i for o in self._active() if o.side is side)

    def view(self) -> BrokerView:
        return BrokerView(self.cash_q, self.pos_i, self.avg_cost_i,
                          tuple(OpenOrderView(o.id, o.side, o.price_i, o.remaining_i,
                                              o.ts_created_ns, o.strategy) for o in self._active()),
                          self.fills_total, self.fees_paid_q, self.realized_q)

    def live_summary(self) -> dict:
        unresolved = self._unknown | {cid for cid, state in self.client._owned.items() if state not in TERMINAL}
        if self._poll_error:
            unresolved = unresolved | {self._poll_error}
        if self.halted and not unresolved and not self._failed_cancels:
            unresolved = {"reconcile required"}
        return {"unresolved": sorted(unresolved), "failed_cancels": sorted(self._failed_cancels),
                "clean": not unresolved and not self._failed_cancels and not self.halted,
                "start_cash_usd": self.start_cash_q / QUOTE_UNIT,
                "start_cash_below_stake": self.start_cash_below_stake,
                "cross_rejects_total": self._cross_rejects_total,
                "balance_soft_rejects_total": self._balance_soft_rejects_total}

    def snapshot(self) -> dict:
        return {"cash_q": self.cash_q, "pos_i": self.pos_i, "fees_paid_q": self.fees_paid_q,
                "maker_fills": self.maker_fills, "taker_fills": self.taker_fills,
                "orders_total": self.orders_total, "rejected_total": self.rejected_total,
                "account_equity_q": self.account_equity_q(), "live": self.live_summary()}

    def finish(self, now_ns: int) -> dict:
        try:
            result = self.io.run(self.client.cancel_owned())
            self._failed_cancels.update(result["failed"])
        except Exception as e:
            self._poll_error = "shutdown: " + type(e).__name__
            self.halted = True
        return self.reconcile(now_ns)

    def close(self) -> None:
        if self._closed:
            return
        try:
            self.io.run(self.client.__aexit__(None, None, None))
            result = self.client.shutdown_result
            if result is not None:
                self._failed_cancels.update(result["failed"])
                self._unknown.update(result["unresolved"])
            # __aexit__ attempts cancellation again. Any execution it discovers
            # after the last poll must keep the receipt unclean until accounted.
            self._sync_orders(time.time_ns())
        except Exception as e:
            self._poll_error = "client close: " + type(e).__name__
            self.halted = True
        finally:
            self._closed = True
            self.io.close()


class LiveEngine(Engine):
    """Engine hooks confined to this driver while the shared engine is unowned."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        if not isinstance(self.broker, LiveBroker) or self.cfg.mode != "live" or self.cfg.limits_profile != "s2c":
            raise LiveGateClosed("live engine requires a live broker and s2c configuration")
        self._live_marking = False
        self._live_receipt: dict | None = None
        self.adopted_inventory_value_q: int | None = None
        self.start_cash_delta_q: int = 0

    def _mark(self, now: int, persist: bool = True) -> None:
        if self._live_marking:
            return
        self._live_marking = True
        try:
            fills = self.broker.on_mark(now)
            if fills:
                self._on_fills(fills, now)
            if self.broker.halted:
                self.risk.kill("live broker requires reconciliation", persist=persist)
            mid = self.book.mid_i()
            if mid <= 0:
                self.risk.poll(now, self.book.stale_ns(now) // 1_000_000, persist=persist)
                if self.risk.killed:
                    self.m.cancels += self.broker.cancel_all(now)
                    self.stop_reason = self.stop_reason or "risk kill: " + self.risk.kill_reason
                return
            if self.adopted_inventory_value_q is None:
                adopted_q = notional_q(self.first_mid_i or mid, self.broker.adopted_inventory_i)
                # Cash above the stake is never allocated to trading (the live CLI clamps
                # cash_q to the stake after seeding), so only a shortfall below the stake
                # shifts the basis; extra account funds must not enlarge it.
                cash_delta_q = min(self.broker.start_cash_q, self.cfg.starting_cash_q) - self.cfg.starting_cash_q
                basis_q = adopted_q + cash_delta_q
                # Journal the basis BEFORE any state moves: if the append raises, nothing below
                # has changed and the next mark retries. A ledger that already carries a basis
                # event (an engine restarted on the same run_dir) keeps its first one; the
                # dashboard reads the earliest, so the run's basis never drifts across restarts.
                if not self.ledger.rows("basis", limit=1):
                    self._ledger(now, "basis", {
                        "equity_start_q": self.equity_start_q + basis_q,
                        "adopted_q": adopted_q,
                        "cash_delta_q": cash_delta_q,
                        "start_cash_q": self.broker.start_cash_q,
                        "configured_cash_q": self.cfg.starting_cash_q,
                    })
                self.adopted_inventory_value_q = adopted_q
                self.start_cash_delta_q = cash_delta_q
                self.equity_start_q += basis_q
                self.equity_peak_q += basis_q
                self.equity_min_q += basis_q
                self.equity_exec_min_q += basis_q
                # Loaded same-day risk history already carries its own equity basis.
                if not self.risk.updated_ns:
                    self.risk.day_start_equity_q += basis_q
                    self.risk.hwm_q += basis_q
                    self.risk._last_equity_q += basis_q
            self.equity_q = self.broker.equity_q(mid)
            self.equity_exec_q = self.broker.liquidation_q()
            self.equity_exec_min_q = min(self.equity_exec_min_q, self.equity_exec_q)
            self.equity_peak_q = max(self.equity_peak_q, self.equity_q)
            self.equity_min_q = min(self.equity_min_q, self.equity_q)
            account_q = self.broker.account_risk_equity_q(self.risk.day_start_equity_q)
            self.risk.on_mark(min(self.equity_q, self.equity_exec_q, account_q), persist=persist)
            view = self.broker.view()
            watch = self.risk.poll(now, self.book.stale_ns(now) // 1_000_000, persist=persist)
            if watch == "stale" and view.open_count:
                n = self.broker.cancel_all(now)
                self.m.stale_cancels += n
                self._ledger(now, "stale-cancel", {"orders": n})
            if persist:
                self.ledger.mark(now, self.equity_q, view.cash_q, view.pos_i, mid,
                                 {"open": view.open_count, "fees_q": view.fees_paid_q,
                                  "exec_q": self.equity_exec_q, "account_risk_q": account_q})
                self.ledger.flush()
                self._next_mark_ns = now + self.cfg.mark_interval_ms * 1_000_000
            if self.equity_q >= self.cfg.goal_q and not self.goal_hit_ns:
                self.goal_hit_ns, self.stop_reason = now, "goal reached"
            if self.risk.killed:
                self.m.cancels += self.broker.cancel_all(now)
                self.stop_reason = self.stop_reason or "risk kill: " + self.risk.kill_reason
                if persist:
                    self._handle_residual(now)
        finally:
            self._live_marking = False

    async def _heartbeat(self, feed) -> None:
        try:
            # Poll even without an initial quote, with no slower than one-second cadence.
            while True:
                await asyncio.sleep(min(1.0, self.cfg.mark_interval_ms / 1000))
                now = self._clock()
                self._mark(now, persist=now >= self._next_mark_ns)
                if self._should_stop(now):
                    await feed.stop()
                    return
        except Exception as e:
            self.exception = "live heartbeat: " + type(e).__name__
            self.stop_reason = "exception: " + self.exception
            await feed.stop()

    def _shutdown(self, feed_stats: dict) -> dict:
        if self._live_receipt is None:
            self.broker.finish(self._clock())
            self._live_receipt = super()._shutdown(feed_stats)
        return self._live_receipt

    def receipt(self, feed_stats: dict, ledger_ok: bool, ledger_rows: int) -> dict:
        receipt = super().receipt(feed_stats, ledger_ok, ledger_rows)
        receipt["live"] = self.broker.live_summary()
        receipt["adopted_inventory_i"] = self.broker.adopted_inventory_i
        receipt["start_cash_usd"] = self.broker.start_cash_q / QUOTE_UNIT
        receipt["adopted_inventory_value_usd"] = (
            self.adopted_inventory_value_q / QUOTE_UNIT
            if self.adopted_inventory_value_q is not None else None)
        return receipt

    async def run_live(self, feed) -> dict:
        try:
            return await super().run_live(feed)
        finally:
            try:
                if self._live_receipt is None:
                    self.stop_reason = self.stop_reason or "live driver interrupted"
                    try:
                        await feed.stop()
                    finally:
                        self._shutdown(asdict(feed.stats))
            finally:
                self.broker.close()
                if self._live_receipt is not None:
                    self._live_receipt["live"] = self.broker.live_summary()
                    (self.run_dir / "receipt.json").write_text(
                        json.dumps(self._live_receipt, indent=2, default=str), encoding="utf-8")
