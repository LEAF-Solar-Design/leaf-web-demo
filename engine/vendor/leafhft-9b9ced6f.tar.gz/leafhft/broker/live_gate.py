"""The only door to real money. Fails closed unless every condition holds at once, and the door
closes behind you by default: arming CONSUMES the ack file (renamed with a nonce).
LEAFHFT_AUTHZ_V2=1 instead retains the ack with bounded age and restart count.

  1. LEAFHFT_LIVE=1 in the environment of THIS process.
  2. An ack file `<run_dir>/LIVE-ACK-<first 12 of config digest>.txt` whose text contains the exact
     sentence returned by ack_sentence(), including the stake (the operator writes it by hand
     after reading the config; a stale ack for another config does not open the door).
  3. Venue credentials present as environment variables (values never read into any log, receipt
     or exception message).
  4. Starting cash in the config at most LIVE_MAX_STAKE_Q (hard-coded $500, the mandate).

assert_armed() returns a LiveAuthorization; the live client refuses to construct without one and
refuses to place an order once it has expired or when the order exceeds the authorized limits
(astra round 2 C10: credentials alone must never be enough to place an order).

Spending real money is a named exception in the operator's standing authority; this gate exists
so that no session, prompt or bug can open it without a fresh, explicit, human-written yes.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import time
from collections import deque
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path

from ..config import EngineConfig, RiskLimits
from ..types import QUOTE_UNIT, Intent, Side, TimeInForce, notional_q

LIVE_MAX_STAKE_Q = 500 * QUOTE_UNIT
LIVE_DRIVER_AVAILABLE = True
MAX_ORDERS_PER_AUTH = 20_000
AUTH_GRACE_S = 900
LEAFHFT_ACK_TTL_S = 7 * 86_400
LEAFHFT_ACK_MAX_STARTS = 64
_ARMS_READ_BYTES = 64 * 1024
# The buy-turnover kill is a rolling bound, not a lifetime one: a healthy maker that keeps
# running for days is not a runaway that traded once. Ring-bounded so a pathological fill
# rate cannot grow memory; the ring itself can only drop the OLDEST entry, never the newest.
TURNOVER_WINDOW_NS = 24 * 3600 * 1_000_000_000
MAX_TURNOVER_ENTRIES = 100_000
CRED_ENV = {
    "binanceus": ("LEAFHFT_BINANCEUS_KEY", "LEAFHFT_BINANCEUS_SECRET"),
    "coinbase": ("LEAFHFT_COINBASE_KEY", "LEAFHFT_COINBASE_SECRET"),
    "kraken": ("LEAFHFT_KRAKEN_KEY", "LEAFHFT_KRAKEN_SECRET"),
    "kalshi": ("LEAFHFT_KALSHI_KEY_ID", "LEAFHFT_KALSHI_PRIVATE_KEY_PEM"),
    # The perps exchange signs with its own key, not the event exchange's: the first live margin
    # order (2026-09-07 14:30Z) got HTTP 500 under the event credential, and the reference SDK
    # (TexasCoding/kalshi-python-sdk) documents "separate API keys issued for the perps exchange".
    "kalshi-perp": ("LEAFHFT_KALSHI_PERPS_KEY_ID", "LEAFHFT_KALSHI_PERPS_PRIVATE_KEY_PEM"),
    "polymarket_us": ("LEAFHFT_POLYMARKET_US_KEY_ID", "POLYMARKET_US_KEY_FILE"),
}
# Raised to $150 on the operator's 2026-09-10 approval (one 5x favorite plus one base ticket
# per book), then to the $500 mandate on 2026-09-18 after he funded the shard to $501.95 and
# the old ceiling held every book to $150 of it. The books size off min(stake, venue balance),
# so a ceiling below the balance caps ticket size; $500 is the mandate, which still blocks above.
KALSHI_LIVE_MAX_STAKE_Q = 500 * QUOTE_UNIT
# The sleeve's own collateral is $20; this ceiling leaves headroom for a deliberate stake change
# while staying far inside the $500 mandate, since 5x leverage multiplies the venue's own risk.
KALSHI_PERP_LIVE_MAX_STAKE_Q = 25 * QUOTE_UNIT
POLYMARKET_US_LIVE_MAX_STAKE_Q = 50 * QUOTE_UNIT


class LiveGateClosed(PermissionError):
    pass


class OrderRefused(LiveGateClosed):
    """A single order failed a per-order rule (shape, size, notional, exposure cap).

    The authorization itself is still good: the caller journals this order as rejected
    and keeps trading. Never raised for authorization state (expired, killed, wrong venue),
    which stays LiveGateClosed and is fatal to the run.
    """


@dataclass(slots=True)
class LiveBudget:
    """Per-authorization totals never reset when an order fills or is cancelled.

    buy_notional_q is the lifetime total (reported in receipts); the turnover ceiling in
    check_order reads buy_notional_window_q instead, a bounded ring of the trailing
    TURNOVER_WINDOW_NS of buy fills, so it can only under-count old history and never lets a
    new fill escape the ceiling.
    """

    orders_total: int = 0
    buy_notional_q: int = 0
    reserved_notional_q: int = 0
    fills_total: int = 0
    _buy_window: deque = field(default_factory=lambda: deque(maxlen=MAX_TURNOVER_ENTRIES))
    _buy_window_sum_q: int = 0

    def on_cancel(self, notional_q: int) -> None:
        self.reserved_notional_q = max(0, self.reserved_notional_q - max(0, notional_q))

    def on_fill(self, side: Side, notional_q: int, now_ns: int | None = None) -> None:
        # Only executed buys consume turnover; sells also prove activity.
        self.on_cancel(notional_q)
        if notional_q > 0:
            self.fills_total += 1
            if side is Side.BUY:
                self.buy_notional_q += notional_q
                ts = time.time_ns() if now_ns is None else now_ns
                w = self._buy_window
                if len(w) == w.maxlen:
                    self._buy_window_sum_q -= w[0][1]  # this append evicts the oldest entry
                w.append((ts, notional_q))
                self._buy_window_sum_q += notional_q
                self._prune_window(ts)

    def _prune_window(self, now_ns: int) -> None:
        cutoff = now_ns - TURNOVER_WINDOW_NS
        w = self._buy_window
        while w and w[0][0] < cutoff:
            self._buy_window_sum_q -= w.popleft()[1]

    def buy_notional_window_q(self, now_ns: int) -> int:
        self._prune_window(now_ns)
        return self._buy_window_sum_q


@dataclass(frozen=True, slots=True)
class LiveAuthorization:
    venue: str
    symbol: str
    config_digest: str
    nonce: str
    issued_ns: int
    expires_ns: int
    limits: RiskLimits
    max_stake_q: int
    budget: LiveBudget = field(default_factory=LiveBudget)
    # Set only after the root-owned account runtime context has been validated.
    account_budget: object | None = field(default=None, repr=False, compare=False)

    def check(self, now_ns: int) -> None:
        if now_ns >= self.expires_ns:
            raise LiveGateClosed("authorization expired")

    def check_order(self, intent: Intent, ref_price_i: int, now_ns: int, pos_i: int = 0, open_notional_q: int = 0, *, reserve: bool = True) -> None:
        self.check(now_ns)
        if intent.tif is not TimeInForce.POST_ONLY or intent.price_i <= 0:
            raise OrderRefused("live orders must be maker-only with a positive limit price")
        px = intent.price_i
        order_q = notional_q(px, intent.size_i)
        if order_q > self.limits.max_order_q:
            raise OrderRefused("order exceeds authorized max_order_q")
        if open_notional_q < 0:
            raise LiveGateClosed("open_notional_q must be nonnegative")
        if notional_q(px, abs(pos_i)) + open_notional_q + order_q > self.limits.max_position_q:
            raise OrderRefused("aggregate notional exceeds authorized max_position_q")
        if self.budget.orders_total >= MAX_ORDERS_PER_AUTH:
            raise LiveGateClosed("authorization order budget exhausted")
        if self.budget.orders_total >= 2_000 and self.budget.fills_total == 0:
            raise LiveGateClosed("placement churn without fills")
        buy_q = order_q if intent.side is Side.BUY else 0
        if buy_q and self.budget.buy_notional_window_q(now_ns) + self.budget.reserved_notional_q + buy_q > 20 * self.max_stake_q:
            raise LiveGateClosed("buy turnover exceeds 20x authorized stake in 24h")
        # The synchronous driver previews exposure; place() reserves once at transmission.
        if reserve:
            self.budget.orders_total += 1
            self.budget.reserved_notional_q += order_q


def ack_path(cfg: EngineConfig, run_dir: str | Path) -> Path:
    return Path(run_dir) / f"LIVE-ACK-{cfg.digest()[:12]}.txt"


def ack_sentence(cfg: EngineConfig) -> str:
    dollars = Decimal(cfg.starting_cash_q) / QUOTE_UNIT
    if cfg.policy_bounds_digest:
        return (f"I authorize live trading with config {cfg.digest()} under policy bounds "
                f"{cfg.policy_bounds_digest[:12]} and a stake of at most ${dollars:.2f}")
    return f"I authorize live trading with config {cfg.digest()} and a stake of at most ${dollars:.2f}"


def readiness(cfg: EngineConfig, run_dir: str | Path, env: dict[str, str] | None = None, now_ns: int | None = None) -> list[str]:
    """Report every blocker without consuming the ack or changing any state.

    Block alternation (cfg.alternate_strategy / cfg.block_minutes) adds no blocker of its own: those
    fields are part of the dataclass the digest is hashed over, so a change to either invalidates the
    ack sentence exactly like any other config field and needs a fresh, hand-written yes.
    """
    env = os.environ if env is None else env
    blockers = []
    if cfg.mode != "live":
        blockers.append("config mode is not live")
    if env.get("LEAFHFT_LIVE") != "1":
        blockers.append("LEAFHFT_LIVE is not 1")
    if cfg.starting_cash_q > LIVE_MAX_STAKE_Q:
        blockers.append("starting cash exceeds the $500 mandate")
    if cfg.venue == "kalshi" and cfg.starting_cash_q > KALSHI_LIVE_MAX_STAKE_Q:
        blockers.append("kalshi live requires a stake of at most $500")
    if cfg.venue == "kalshi-perp" and cfg.starting_cash_q > KALSHI_PERP_LIVE_MAX_STAKE_Q:
        blockers.append("kalshi-perp live requires a stake of at most $25")
    if cfg.venue == "polymarket_us" and cfg.starting_cash_q > POLYMARKET_US_LIVE_MAX_STAKE_Q:
        blockers.append("polymarket_us live requires a stake of at most $50")
    p = ack_path(cfg, run_dir)
    try:
        with p.open("rb") as ack:
            data = ack.read(4097)
        if len(data) > 4096:
            blockers.append("ack file exceeds 4096 bytes")
        else:
            text = data.decode("utf-8", errors="strict")
            # Do not accept the expected dollar amount as a prefix of another amount.
            sentence = re.escape(ack_sentence(cfg)) + r"(?!\w|\.\d|,\d)"
            if re.search(sentence, text) is None:
                blockers.append("ack file does not contain the exact authorization sentence for this config")
    except FileNotFoundError:
        blockers.append(f"ack file missing: {p.name}")
    except (OSError, UnicodeDecodeError) as e:
        blockers.append(f"ack unreadable: {type(e).__name__}")
    names = CRED_ENV.get(cfg.venue)
    if names is None:
        blockers.append(f"no live adapter for venue {cfg.venue}")
    for n in names or ():
        if cfg.venue == "polymarket_us":
            continue  # This venue carries a file path, not an inline signing secret.
        if len(env.get(n, "")) < 16:
            blockers.append(f"credential {n} missing or too short")
    if cfg.venue == "polymarket_us":
        import stat

        if not env.get("LEAFHFT_POLYMARKET_US_KEY_ID", "").strip():
            blockers.append("credential LEAFHFT_POLYMARKET_US_KEY_ID missing")
        try:
            key_path = Path(env.get("POLYMARKET_US_KEY_FILE", ""))
            key_stat = key_path.stat()
            if not stat.S_ISREG(key_stat.st_mode) or not 32 <= key_stat.st_size <= 4096:
                blockers.append("POLYMARKET_US_KEY_FILE must be a regular file of 32 to 4096 bytes")
            if os.name != "nt" and stat.S_IMODE(key_stat.st_mode) != 0o600:
                blockers.append("POLYMARKET_US_KEY_FILE must have mode 0600")
        except (OSError, ValueError):
            blockers.append("POLYMARKET_US_KEY_FILE missing or unreadable")
        if not cfg.policy_path:
            blockers.append("polymarket_us live requires a policy file")
    if cfg.venue in ("kalshi", "polymarket_us"):
        from .kalshi_book import KALSHI_LIMITS_PROFILES  # lazy: kalshi_book -> kalshi_live -> live_gate
        if cfg.limits_profile not in KALSHI_LIMITS_PROFILES:
            blockers.append(
                f"live requires a kalshi limits profile ({', '.join(sorted(KALSHI_LIMITS_PROFILES))}), got {cfg.limits_profile}"
            )
        if cfg.policy_path:
            from ..policy import PolicyError, load_policy, policy_bounds_digest  # lazy: avoid a hard policy dependency for non-kalshi venues
            try:
                policy = load_policy(cfg.policy_path)
            except PolicyError as e:
                blockers.append(str(e))
            else:
                if policy_bounds_digest() != cfg.policy_bounds_digest:
                    blockers.append("policy bounds changed; re-ack")
                elif round(policy.stake_ceiling_usd * 100) != cfg.starting_cash_q * 100 // QUOTE_UNIT:
                    blockers.append("stake in the sentence does not match the policy ceiling")
    elif cfg.venue == "kalshi-perp":
        if cfg.limits_profile not in ("kalshi-sleeve", "kalshi-sleeve-fast"):
            blockers.append(f"live requires limits_profile kalshi-sleeve or kalshi-sleeve-fast, got {cfg.limits_profile}")
    elif cfg.limits_profile not in ("s2c", "aggressive"):
        blockers.append(f"live requires limits_profile s2c or aggressive, got {cfg.limits_profile}")
    if cfg.strategy == "probe":
        blockers.append("probe is paper-only")
    if not LIVE_DRIVER_AVAILABLE:
        blockers.append("live driver not wired in this build")
    return blockers


def _record_arm(cfg: EngineConfig, ack: Path, ack_dir: Path, nonce: str, now_ns: int) -> None:
    """Serialize the guard and durable append; never reset counts on a new run dir.

    Each row carries the cumulative count so a bounded tail can retain the count.
    If a digest has fallen out of that tail, refuse rather than guess its history.
    """
    from ..build import build_identity

    try:
        if now_ns > ack.stat().st_mtime_ns + LEAFHFT_ACK_TTL_S * 1_000_000_000:
            raise LiveGateClosed("ack expired")
        fd = os.open(ack_dir / "arms.jsonl", os.O_RDWR | os.O_CREAT | os.O_APPEND, 0o640)
        with os.fdopen(fd, "r+b", buffering=0) as journal:
            if os.name == "posix":
                import fcntl

                fcntl.flock(journal.fileno(), fcntl.LOCK_EX)
            else:
                import msvcrt

                msvcrt.locking(journal.fileno(), msvcrt.LK_LOCK, 1)
            size = journal.seek(0, os.SEEK_END)
            journal.seek(max(0, size - _ARMS_READ_BYTES))
            data = journal.read(_ARMS_READ_BYTES)
            truncated = size > _ARMS_READ_BYTES
            if truncated:
                data = data.partition(b"\n")[2]
            rows = [json.loads(line) for line in data.splitlines()]
            digest = cfg.digest()
            matching = [row for row in rows if row["digest"] == digest]
            if truncated and not matching:
                raise LiveGateClosed("ack history outside bounded arms journal; operator renewal required")
            if any((row["venue"], row["symbol"]) != (cfg.venue, cfg.symbol) for row in matching):
                raise LiveGateClosed("ack digest already armed a different venue or symbol")
            starts = max(len(matching), max((row.get("starts", 0) for row in matching), default=0))
            if starts >= LEAFHFT_ACK_MAX_STARTS:
                raise LiveGateClosed("ack max_starts reached")
            row = {"unit": build_identity()["unit"], "venue": cfg.venue,
                   "symbol": cfg.symbol, "digest": digest, "nonce": nonce,
                   "ts": now_ns / 1_000_000_000, "starts": starts + 1}
            line = (json.dumps(row, sort_keys=True) + "\n").encode()
            if journal.write(line) != len(line):
                raise OSError("short arms journal write")
            os.fsync(journal.fileno())
    except LiveGateClosed:
        raise
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
        raise LiveGateClosed(f"could not record arm: {type(exc).__name__}") from exc


def assert_armed(cfg: EngineConfig, run_dir: str | Path, env: dict[str, str] | None = None, now_ns: int | None = None, *, ack_dir: str | Path | None = None) -> LiveAuthorization:
    blockers = readiness(cfg, run_dir, env, now_ns)
    if blockers:
        raise LiveGateClosed("; ".join(blockers))
    now_ns = time.time_ns() if now_ns is None else now_ns
    p = ack_path(cfg, run_dir)
    nonce = secrets.token_hex(8)
    if (os.environ if env is None else env).get("LEAFHFT_AUTHZ_V2") == "1":
        _record_arm(cfg, p, Path(ack_dir) if ack_dir is not None else p.parent, nonce, now_ns)
    else:
        consumed = p.with_name(f"{p.stem}.consumed-{nonce}{p.suffix}")
        try:
            p.rename(consumed)  # one-shot: the same ack can never arm a second run
        except OSError as e:
            raise LiveGateClosed(f"could not consume ack: {type(e).__name__}") from e
    ttl_s = (cfg.run_seconds or 3600) + AUTH_GRACE_S
    return LiveAuthorization(
        venue=cfg.venue,
        symbol=cfg.symbol,
        config_digest=cfg.digest(),
        nonce=nonce,
        issued_ns=now_ns,
        expires_ns=now_ns + ttl_s * 1_000_000_000,
        limits=cfg.risk,
        max_stake_q=cfg.starting_cash_q,
        budget=LiveBudget(),
    )
