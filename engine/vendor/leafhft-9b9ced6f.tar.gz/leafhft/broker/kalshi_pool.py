"""ProfitPool: a shared, locked reservation of realized Kalshi winnings, so the size above the
$5 base ticket ("extra") is paid only from profit already realized, never from principal.
Fourteen books share ONE venue balance, so this pool is one JSON document under an exclusive OS
lock (fcntl.flock on POSIX, msvcrt.locking on Windows): without a shared lock, every book would
size its own extra against the same winnings and fourteen books would double, triple, or worse,
spend the same dollar.

The pool balance is `balance_cents + open_costs_cents - deposit_cents - open_extra_cents`: the
venue balance plus committed purchase costs, minus the deposit and minus all reserved extra.
Pending reservations contribute no purchase cost, but keep their full extra reserved. On disk,
their cost is zero so legacy readers also exclude it. Entries without a committed flag are
treated as pending: an old writer may have reserved without purchasing. An old rewrite can
also strip the flag from purchased inventory, so this may conservatively withhold its credit.
An entry is trusted only when all its fields and markers are valid and mutually consistent.
Untrusted entries receive no purchase credit and hold the largest valid integer extra or cost
they carry, without a ceiling. A commit on an untrusted entry holds its full actual cost as
extra with base zero. Required-field validation failures instead block writes and return a
named refusal from commit; snapshots identify the rejected entry and invalid field.
Trusted entries retain actual-cost-minus-base accounting, including fees.

The lock does not make venue cash reads atomic with committed inventory. If another book reads
cash before a purchase but reserves after its commit, the stale cash plus committed cost can
still allocate the same profit twice. This pool fixes crediting pending costs, not that race.
All books sharing a pool file must run this fix before profit_pool is enabled.
Enablement needs the operator's fresh yes; the runner owner executes this policy change.
Old processes, if enabled, retain their original over-grant among themselves and are unsafe
to mix with this code.
Expiry assumes every Kalshi book trades markets that settle within STALE_S (15-minute and
hourly): orders are filled and committed or cancelled and released, and committed positions
settle and are released within STALE_S. Expiry recovers holds from crashed processes.
"""
from __future__ import annotations

import errno
import hashlib
import os
import shlex
import shutil
import stat
import sys
import time
from pathlib import Path
from typing import Any

import orjson

if sys.platform == "win32":
    import msvcrt
else:
    import fcntl

MAX_POOL_BYTES = 1024 * 1024
MAX_INT_CENTS = 100_000_000
MAX_KEY_LEN = 64
STALE_S = 4 * 3600
LOCK_TIMEOUT_S = 5.0
LOCK_POLL_S = 0.05


class _FileLock:
    """Exclusive lock on a dedicated `<path>.lock` file, held only for the duration of one
    load-decide-write cycle. A separate lock file (rather than locking the data file itself)
    means the data file can always be replaced atomically (temp + os.replace) without fighting
    an open, locked handle on the same path, which os.replace cannot reliably displace on
    Windows."""

    def __init__(self, lock_path: Path, timeout_s: float = LOCK_TIMEOUT_S) -> None:
        self.lock_path = lock_path
        self.timeout_s = timeout_s
        self._fh = None

    def __enter__(self) -> "_FileLock":
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        parent = self.lock_path.parent.stat()
        try:
            try:
                fd = os.open(self.lock_path, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o660)
                created = True
            except FileExistsError:
                fd = os.open(self.lock_path, os.O_RDWR | getattr(os, "O_NOFOLLOW", 0))
                created = False
        except OSError as exc:
            if exc.errno != errno.EACCES:
                raise
            try:
                info = self.lock_path.stat()
            except OSError:
                raise exc
            path = shlex.quote(str(self.lock_path))
            raise PermissionError(
                errno.EACCES,
                f"cannot open lock {self.lock_path}: owner:group "
                f"{info.st_uid}:{info.st_gid}, mode {stat.S_IMODE(info.st_mode):04o}; "
                f"fix: chown {parent.st_uid}:{parent.st_gid} {path} && chmod 0660 {path}",
                str(self.lock_path),
            ) from exc
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise PermissionError(
                    errno.EACCES,
                    f"lock {self.lock_path} is not a regular single-link file; refusing",
                    str(self.lock_path),
                )
            root = getattr(os, "geteuid", lambda: -1)() == 0
            # Repair only the file this call created; never an existing file.
            if root and created and (info.st_uid != parent.st_uid or info.st_gid != parent.st_gid):
                try:
                    os.fchown(fd, parent.st_uid, parent.st_gid)
                except OSError:
                    # Ownership repair is best effort once the file is open.
                    pass
            if created:
                # Creation's mode is filtered by umask; set it explicitly afterwards.
                try:
                    if hasattr(os, "fchmod"):
                        os.fchmod(fd, 0o660)
                    else:
                        os.chmod(self.lock_path, 0o660)
                except OSError:
                    # Keep the usable descriptor even if mode repair is denied.
                    pass
            fh = os.fdopen(fd, "r+b")
        except BaseException:
            os.close(fd)
            raise
        if fh.seek(0, os.SEEK_END) == 0:
            fh.write(b"\0")
            fh.flush()
        deadline = time.monotonic() + self.timeout_s
        while True:
            try:
                if sys.platform == "win32":
                    fh.seek(0)
                    msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                self._fh = fh
                return self
            except OSError:
                if time.monotonic() >= deadline:
                    fh.close()
                    raise TimeoutError(f"could not acquire pool lock {self.lock_path}")
                time.sleep(LOCK_POLL_S)

    def __exit__(self, *exc: Any) -> bool:
        fh = self._fh
        self._fh = None
        try:
            if sys.platform == "win32":
                fh.seek(0)
                msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        finally:
            fh.close()
        return False


class ProfitPool:
    def __init__(self, path: Path, deposit_cents: int, extra_ceiling_cents: int) -> None:
        if type(deposit_cents) is not int or not 0 < deposit_cents <= MAX_INT_CENTS:
            raise ValueError("deposit_cents must be a positive int in cents")
        if type(extra_ceiling_cents) is not int or not 0 <= extra_ceiling_cents <= MAX_INT_CENTS:
            raise ValueError("extra_ceiling_cents must be a nonnegative int in cents")
        self.path = Path(path)
        self._lock_path = Path(str(self.path) + ".lock")
        self.deposit_cents = deposit_cents
        self.extra_ceiling_cents = extra_ceiling_cents
        self.stats: dict[str, int] = {
            "loads": 0, "corrupt_files": 0, "stale_dropped": 0, "grants": 0, "denials": 0,
        }
        self._last_pool_cents = 0
        self._load_blocked = False
        self._blocked_entries: dict[str, Any] = {}

    @staticmethod
    def _decide(base_cents: int, price_cents: int, balance_cents: int, deposit_cents: int,
               extra_ceiling_cents: int, open_costs_cents: int, open_extra_cents: int) -> tuple[int, int]:
        """Pure arithmetic core: returns (granted_cents, pool_cents). granted is the largest
        multiple of price_cents at or below the available winnings, capped at
        extra_ceiling_cents; 0 whenever price_cents is not positive."""
        pool_cents = balance_cents + open_costs_cents - deposit_cents - open_extra_cents
        if price_cents <= 0:
            return (0, pool_cents)
        available = min(max(pool_cents, 0), extra_ceiling_cents)
        granted = (available // price_cents) * price_cents
        return (max(0, granted), pool_cents)

    @classmethod
    def _is_trusted(cls, entry: Any, *, cid: str = "entry", on_disk: bool = False) -> bool:
        """One trust rule for purchase credit, reserved extra and cost-basis accounting.

        Pending costs are zero on disk and restored to the reservation cost in memory.
        Unknown fields cannot establish trust until their semantics are understood.
        """
        if cls._entry_rejection_reason(cid, entry) is not None:
            return False
        fields = {
            "book", "cost_cents", "extra_cents", "ts_ns", "committed",
            "reserved_cost_cents", "base_cents", "granted_extra_cents", "extra_capped",
        }
        if set(entry) - fields or entry.get("extra_capped", False) is not False:
            return False
        committed = entry.get("committed")
        if type(committed) is not bool:
            return False
        cost = entry.get("cost_cents")
        extra = entry.get("extra_cents")
        base = entry.get("base_cents")
        grant = entry.get("granted_extra_cents")
        reserved = entry.get("reserved_cost_cents")
        if not on_disk and not committed and "reserved_cost_cents" not in entry:
            reserved = cost
        cost_limit = MAX_INT_CENTS if on_disk or committed else 2 * MAX_INT_CENTS
        for value, limit in (
            (cost, cost_limit), (extra, MAX_INT_CENTS), (base, MAX_INT_CENTS),
            (grant, MAX_INT_CENTS), (reserved, 2 * MAX_INT_CENTS),
        ):
            if type(value) is not int or not 0 <= value <= limit:
                return False
        if base + grant != reserved:
            return False
        if committed:
            return extra == max(0, cost - base)
        return cost == (0 if on_disk else reserved) and extra == grant

    @classmethod
    def _held_extra(cls, entry: dict[str, Any], *, cid: str = "entry") -> int:
        if cls._is_trusted(entry, cid=cid):
            return entry["extra_cents"]
        # Do not cap damaged values at the grant, configured ceiling or schema limit.
        return max((
            value for key, value in entry.items()
            if ("extra" in key or key in ("cost_cents", "reserved_cost_cents"))
            and type(value) is int and value >= 0
        ), default=0)

    @staticmethod
    def _entry_rejection_reason(cid: Any, entry: Any) -> str | None:
        if not isinstance(cid, str) or not 0 < len(cid) <= MAX_KEY_LEN:
            return "client_id invalid"
        if not isinstance(entry, dict):
            return "entry must be an object"
        book = entry.get("book")
        cost_cents = entry.get("cost_cents")
        extra_cents = entry.get("extra_cents")
        ts_ns = entry.get("ts_ns")
        if not isinstance(book, str) or not 0 < len(book) <= MAX_KEY_LEN:
            return "book invalid"
        if type(cost_cents) is not int or cost_cents < 0:
            return "cost_cents invalid"
        if type(extra_cents) is not int or extra_cents < 0:
            return "extra_cents invalid"
        if type(ts_ns) is not int or ts_ns < 0:
            return "ts_ns invalid"
        return None

    def _validate_entry(self, cid: Any, entry: Any) -> dict[str, Any] | None:
        if self._entry_rejection_reason(cid, entry) is not None:
            return None
        cost_cents = entry["cost_cents"]
        trusted = self._is_trusted(entry, cid=cid, on_disk=True)
        validated = dict(entry)
        validated["committed"] = entry.get("committed") is True
        # Keep every extra-like field, even unknown ones, so a rewrite cannot erase a hold.
        # The sticky marker prevents normalization from repairing damaged provenance.
        # A malformed marker must survive too: an integer can itself carry the hold.
        if not trusted and type(entry.get("extra_capped", False)) is bool:
            validated["extra_capped"] = True
        reserved_cost = entry.get("reserved_cost_cents")
        if not validated["committed"]:
            if type(reserved_cost) is int and reserved_cost >= 0:
                validated["cost_cents"] = max(cost_cents, reserved_cost)
            validated.pop("reserved_cost_cents", None)
        return validated

    def _load(self, now_ns: int) -> dict[str, dict[str, Any]]:
        """Drop stale entries; only a missing file is empty. Corruption blocks writes until
        the file is stale and its complete bytes have been copied aside."""
        self.stats["loads"] += 1
        self._load_blocked = False
        self._blocked_entries = {}
        try:
            with self.path.open("rb") as source:
                data = source.read(MAX_POOL_BYTES + 1)
        except FileNotFoundError:
            return {}
        except OSError:
            self.stats["corrupt_files"] += 1
            self._load_blocked = True
            return {}
        if not data or len(data) > MAX_POOL_BYTES:
            return self._corrupt_pool(now_ns)
        try:
            doc = orjson.loads(data)
        except Exception:
            return self._corrupt_pool(now_ns)
        if not isinstance(doc, dict) or not isinstance(doc.get("open"), dict):
            return self._corrupt_pool(now_ns)
        stale_cutoff_ns = now_ns - STALE_S * 1_000_000_000
        fresh: dict[str, dict[str, Any]] = {}
        damaged_timestamps: list[int] = []
        for cid, raw_entry in doc["open"].items():
            entry = self._validate_entry(cid, raw_entry)
            if entry is None:
                self._blocked_entries[cid] = raw_entry
                timestamp = raw_entry.get("ts_ns") if isinstance(raw_entry, dict) else None
                if type(timestamp) is not int or timestamp < 0:
                    try:
                        timestamp = self.path.stat().st_mtime_ns
                    except OSError:
                        self.stats["corrupt_files"] += 1
                        self._load_blocked = True
                        return {}
                damaged_timestamps.append(timestamp)
                continue
            if entry["ts_ns"] < stale_cutoff_ns:
                self.stats["stale_dropped"] += 1
                continue
            fresh[cid] = entry
        if damaged_timestamps:
            self._corrupt_pool(now_ns, damaged_ts_ns=max(damaged_timestamps))
            if self._load_blocked:
                self._blocked_entries.update(fresh)
                return {}
        self._blocked_entries = {}
        return fresh

    @staticmethod
    def _backup_matches(backup: Path, source: Any, expected_digest: str) -> bool:
        """Only complete, matching bytes in a regular file count as a backup."""
        try:
            if not stat.S_ISREG(os.lstat(backup).st_mode):
                return False
            source.seek(0)
            digest = hashlib.sha256()
            with backup.open("rb") as saved:
                while chunk := saved.read(64 * 1024):
                    if chunk != source.read(len(chunk)):
                        return False
                    digest.update(chunk)
            return not source.read(1) and digest.hexdigest() == expected_digest
        except OSError:
            return False

    def _corrupt_pool(self, now_ns: int, *, damaged_ts_ns: int | None = None) -> dict[str, dict[str, Any]]:
        self.stats["corrupt_files"] += 1
        self._load_blocked = True
        try:
            timestamp = self.path.stat().st_mtime_ns if damaged_ts_ns is None else damaged_ts_ns
            if timestamp >= now_ns - STALE_S * 1_000_000_000:
                return {}
            # Hash all bytes, including oversized files, so snapshots reuse one backup.
            with self.path.open("rb") as source:
                digest = hashlib.sha256()
                while chunk := source.read(64 * 1024):
                    digest.update(chunk)
                expected_digest = digest.hexdigest()
                backup = self.path.with_name(
                    self.path.name + f".corrupt.{expected_digest}.bak"
                )
                if not self._backup_matches(backup, source, expected_digest):
                    source.seek(0)
                    tmp = backup.with_name(backup.name + f".tmp{os.getpid()}")
                    target = tmp.open("xb")
                    try:
                        with target:
                            shutil.copyfileobj(source, target, length=64 * 1024)
                            target.flush()
                            os.fsync(target.fileno())
                        os.replace(tmp, backup)
                    finally:
                        tmp.unlink(missing_ok=True)
                    if not self._backup_matches(backup, source, expected_digest):
                        return {}
        except OSError:
            return {}
        self._load_blocked = False
        return {}

    def _write(self, open_entries: dict[str, dict[str, Any]]) -> None:
        if self._load_blocked:
            return
        # The legacy reserve() sums cost_cents unconditionally (origin/main, line 190).
        # Keep the proposed cost separately for partial-fill accounting. An old rewrite
        # may remove both new fields, but the remaining zero cost cannot create credit.
        persisted = {
            cid: entry if entry["committed"] else {
                **entry, "cost_cents": 0, "reserved_cost_cents": entry["cost_cents"],
            }
            for cid, entry in open_entries.items()
        }
        payload = orjson.dumps({"open": persisted})
        if len(payload) > MAX_POOL_BYTES:
            raise ValueError("pool document would exceed MAX_POOL_BYTES")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + f".tmp{os.getpid()}")
        tmp.write_bytes(payload)
        os.replace(tmp, self.path)

    def reserve(self, client_id: str, book: str, base_cents: int, price_cents: int,
               balance_cents: int, now_ns: int | None = None) -> int:
        if not isinstance(client_id, str) or not 0 < len(client_id) <= MAX_KEY_LEN:
            raise ValueError("client_id invalid")
        if not isinstance(book, str) or not 0 < len(book) <= MAX_KEY_LEN:
            raise ValueError("book invalid")
        if type(base_cents) is not int or not 0 <= base_cents <= MAX_INT_CENTS:
            raise ValueError("base_cents invalid")
        if type(price_cents) is not int:
            raise ValueError("price_cents invalid")
        if type(balance_cents) is not int or not 0 <= balance_cents <= MAX_INT_CENTS:
            raise ValueError("balance_cents invalid")
        now_ns = time.time_ns() if now_ns is None else now_ns
        with _FileLock(self._lock_path):
            open_entries = self._load(now_ns)
            if self._load_blocked:
                self._last_pool_cents = 0
                self.stats["denials"] += 1
                return 0
            entry = open_entries.get(client_id)
            if entry is not None and not self._is_trusted(entry, cid=client_id):
                raise ValueError("entry_untrusted")
            others = [(cid, e) for cid, e in open_entries.items() if cid != client_id]
            open_costs = sum(
                e["cost_cents"] for cid, e in others
                if self._is_trusted(e, cid=cid) and e["committed"]
            )
            open_extra = sum(self._held_extra(e, cid=cid) for cid, e in others)
            granted, pool_cents = self._decide(base_cents, price_cents, balance_cents,
                                               self.deposit_cents, self.extra_ceiling_cents,
                                               open_costs, open_extra)
            open_entries[client_id] = {
                "book": book, "cost_cents": base_cents + granted, "extra_cents": granted, "ts_ns": now_ns,
                "committed": False,
                "base_cents": base_cents, "granted_extra_cents": granted,
            }
            self._write(open_entries)
            self._last_pool_cents = pool_cents
            self.stats["grants" if granted > 0 else "denials"] += 1
            return granted

    def register_existing(self, client_id: str, book: str, cost_cents: int,
                          now_ns: int | None = None) -> None:
        """Hold an absent ticket's full cost as extra, or reconcile an existing ticket while
        preserving its reservation basis and refreshing its timestamp. A different book cannot replace it."""
        if not isinstance(client_id, str) or not 0 < len(client_id) <= MAX_KEY_LEN:
            raise ValueError("client_id invalid")
        if not isinstance(book, str) or not 0 < len(book) <= MAX_KEY_LEN:
            raise ValueError("book invalid")
        if type(cost_cents) is not int or not 0 <= cost_cents <= MAX_INT_CENTS:
            raise ValueError("cost_cents invalid")
        now_ns = time.time_ns() if now_ns is None else now_ns
        with _FileLock(self._lock_path):
            open_entries = self._load(now_ns)
            if self._load_blocked:
                return
            entry = open_entries.get(client_id)
            if entry is not None:
                if entry["book"] != book or not self._is_trusted(entry, cid=client_id):
                    raise ValueError("existing reservation conflicts with adoption")
                base = entry.get("base_cents", max(0, entry["cost_cents"] - entry["extra_cents"]))
                open_entries[client_id] = {
                    **entry, "cost_cents": cost_cents, "ts_ns": now_ns,
                    "extra_cents": max(0, cost_cents - base), "committed": True,
                    "base_cents": base,
                    "granted_extra_cents": entry.get("granted_extra_cents", entry["extra_cents"]),
                    "reserved_cost_cents": entry.get(
                        "reserved_cost_cents", base + entry["granted_extra_cents"],
                    ),
                }
            else:
                open_entries[client_id] = {
                    "book": book, "cost_cents": cost_cents, "extra_cents": cost_cents, "ts_ns": now_ns,
                    "committed": True, "base_cents": 0, "granted_extra_cents": cost_cents,
                    "reserved_cost_cents": cost_cents,
                }
            self._write(open_entries)

    def commit(self, client_id: str, actual_cost_cents: int) -> str | None:
        """Commit a fill, or return a named refusal when corruption blocks writes."""
        if not isinstance(client_id, str) or not client_id:
            raise ValueError("client_id invalid")
        if type(actual_cost_cents) is not int or not 0 <= actual_cost_cents <= MAX_INT_CENTS:
            raise ValueError("actual_cost_cents invalid")
        now_ns = time.time_ns()
        with _FileLock(self._lock_path):
            open_entries = self._load(now_ns)
            if self._load_blocked:
                blocked_entry = self._blocked_entries.get(client_id)
                if client_id in self._blocked_entries and self._entry_rejection_reason(
                    client_id, blocked_entry,
                ) is not None:
                    return "entry_untrusted"
                return "pool_corrupt"
            entry = open_entries.get(client_id)
            if entry is None:
                return
            if actual_cost_cents == 0:
                del open_entries[client_id]
            else:
                if not self._is_trusted(entry, cid=client_id):
                    extra = actual_cost_cents
                    entry["base_cents"] = 0
                    if type(entry.get("extra_capped", False)) is bool:
                        entry["extra_capped"] = True
                else:
                    # Intact basis keeps the existing actual-cost arithmetic, including fees.
                    base = entry["base_cents"]
                    extra = max(0, actual_cost_cents - base)
                    entry["reserved_cost_cents"] = entry.get(
                        "reserved_cost_cents", base + entry["granted_extra_cents"],
                    )
                open_entries[client_id] = {
                    **entry,
                    "cost_cents": actual_cost_cents,
                    "extra_cents": extra,
                    "committed": True,
                }
            self._write(open_entries)

    def release(self, client_id: str) -> None:
        now_ns = time.time_ns()
        with _FileLock(self._lock_path):
            open_entries = self._load(now_ns)
            if client_id not in open_entries:
                return
            del open_entries[client_id]
            self._write(open_entries)

    def snapshot(self) -> dict[str, Any]:
        now_ns = time.time_ns()
        with _FileLock(self._lock_path):
            open_entries = self._load(now_ns)
            entries = {**open_entries, **self._blocked_entries}
            details = {}
            for cid, raw_entry in entries.items():
                entry = raw_entry if isinstance(raw_entry, dict) else {"raw_entry": raw_entry}
                trusted = self._is_trusted(entry, cid=cid)
                details[cid] = {
                    **entry,
                    "trusted": trusted,
                    "untrusted": not trusted,
                    "reason": None if trusted else "entry_untrusted",
                    "held_extra_cents": self._held_extra(entry, cid=cid),
                }
                rejection_reason = self._entry_rejection_reason(cid, raw_entry)
                if rejection_reason is not None:
                    details[cid]["rejection_reason"] = rejection_reason
            blocked = self._load_blocked
        return {
            "open": len(details),
            "open_extra_cents": sum(e["held_extra_cents"] for e in details.values()),
            "entries": details,
            "blocked": blocked,
            "last_pool_cents": self._last_pool_cents,
            "stats": dict(self.stats),
        }
