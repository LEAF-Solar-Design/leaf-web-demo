"""Kalshi BTCPERP margin adapter: KalshiPerp (signed REST client over the margin API) and
PerpSleeve (the book that turns a frozen breakout rule into a bounded $20-collateral, 5x
sleeve). UNEXERCISED against the venue, same caveat as kalshi_live.py: no credentials existed
when this was built, so only request construction, signing, journal transitions and the local
bound are covered by tests.

Paths (perps_openapi.yaml / help center, read 2026-09-06), base
`https://external-api.kalshi.com`, every path prefixed `/trade-api/v2/margin`, signed whole
(method + path, no query string), same RSA-PSS convention as feeds/kalshi.py and kalshi_live.py:

  POST   /trade-api/v2/margin/orders                  create order
  DELETE /trade-api/v2/margin/orders/{order_id}        cancel
  GET    /trade-api/v2/margin/positions                open positions
  GET    /trade-api/v2/margin/balance                  cash, position value, total, maintenance
  GET    /trade-api/v2/margin/risk                      leverage, liquidation price
  GET    /trade-api/v2/margin/funding_rates/estimate    next funding estimate
  GET    /trade-api/v2/margin/funding_rates/historical  paid funding rows
  GET    /trade-api/v2/margin/markets/{ticker}          mark price
  GET    /trade-api/v2/margin/markets/{ticker}/orderbook
  GET    /trade-api/v2/margin/trades

Not independently re-verified against a live account (no network access here); confirm on first
live connect. The margin API publishes no GET-order-by-id or list-orders endpoint (unlike the
event API), so an ambiguous placement or cancel is reconciled against `positions()`, not a
per-order status fetch: `reconcile()` compares each unresolved record's expected effect (an
entry adds count, a reduce_only order removes it) against the venue's current position for that
ticker. A record that cannot be explained by the current position stays UNKNOWN and blocks
further placement, same fail-closed discipline as kalshi_live.py.

Hardened: RSA signing is deterministic-input only (ts_ms, method, path); the journal follows the
same discipline as kalshi_live.py (SENT before transmission, terminal states derived only from a
validated venue reply, UNKNOWN on anything ambiguous, restart rebuilds owned state from the
journal, fsync on every row). PerpSleeve enforces every safety number locally: the venue's own
margin/risk figures are read for logging and never trusted as the only backstop (astra C10
lineage, same as KalshiBook). One position at a time; every closing order is reduce_only; a
protective stop rests on the venue when accepted, and the loop re-checks the mark every tick so
an absent or rejected resting stop still closes within one tick (bounded at 5 s by the caller's
poll interval, not by this module).

Price units: the venue quotes KXBTCPERP per contract (contract_size 0.0001 BTC), so its wire
prices sit near single-digit dollars (e.g. "7.9205") while the sleeve, PerpBreakout and every
number this module hands back to a caller work in BTC dollars (79205). The BTC-dollar/per-contract
conversion happens only at this client's wire boundary: `place()` takes and journals `price` in
BTC dollars and converts to the venue's per-contract dollars (price x BTC_CONTRACT_BTC, quantized
to the 4-decimal tick) only for the request body, journaling that wire string alongside the BTC
price; `mark()`, and any average fill / entry / liquidation / position price returned by
`positions()`, `risk()` or `trades()`, convert the venue's per-contract dollars back to BTC dollars
before returning. Nothing above this client (PerpSleeve, PerpPosition, PerpBreakout) ever sees a
per-contract number.
"""
from __future__ import annotations

import asyncio
import math
import os
import re
import time
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

import aiohttp
import orjson

from ..feeds.kalshi import CRED_KEY_ID_ENV, CRED_PEM_ENV, sign
from ..types import MalformedInput
from .live_gate import LiveAuthorization, LiveGateClosed

MARGIN_REST_URL = "https://external-api.kalshi.com"
PATH_PREFIX = "/trade-api/v2/margin"
ORDERS_PATH = PATH_PREFIX + "/orders"
POSITIONS_PATH = PATH_PREFIX + "/positions"
BALANCE_PATH = PATH_PREFIX + "/balance"
RISK_PATH = PATH_PREFIX + "/risk"
FUNDING_ESTIMATE_PATH = PATH_PREFIX + "/funding_rates/estimate"
FUNDING_HISTORICAL_PATH = PATH_PREFIX + "/funding_rates/historical"
TRADES_PATH = PATH_PREFIX + "/trades"
TIMEOUT_S = 5.0
MAX_JOURNAL_BYTES = 1024 * 1024
MAX_OWNED = 2_000
TIF_VALUES = frozenset({"fill_or_kill", "good_till_canceled", "immediate_or_cancel"})
RESTING_TIF = frozenset({"good_till_canceled"})
VENUE_ALLOWS_RESTING_REDUCE_ONLY = False  # Kalshi: "reduce_only can only be used with IoC or FoK orders"
CLOSE_CROSS_BPS = 10  # a stop or time-stop close crosses the spread by this much so the IOC fills
TERMINAL = {"FILLED", "CANCELED", "GONE"}
STATES = TERMINAL | {"SENT", "RESTING", "PARTIAL", "UNKNOWN"}
BTC_CONTRACT_BTC = Decimal("0.0001")  # one BTCPERP contract, per help center
MIN_SUBACCOUNT, MAX_SUBACCOUNT = 0, 63


_POSITION_PRICE_KEYS = ("average_price", "entry_price", "position_price")
_RISK_PRICE_KEYS = ("liquidation_price",)
_TRADE_PRICE_KEYS = ("price",)


def _row_to_btc_dollars(row: Any, keys: tuple[str, ...]) -> Any:
    """Returns a copy of `row` with any of `keys` present converted from the venue's per-contract
    dollars to BTC dollars; a key whose value is not a well-formed decimal string is left as the
    raw venue value (this client does not otherwise validate the deep row schema of positions()/
    risk()/trades(), only that the reply is a dict/list of the expected shape)."""
    if not isinstance(row, dict):
        return row
    out = dict(row)
    for key in keys:
        if key in out:
            try:
                out[key] = str(_decimal(out[key]) / BTC_CONTRACT_BTC)
            except (ValueError, TypeError):
                pass
    return out


def order_path(order_id: int) -> str:
    return f"{ORDERS_PATH}/{order_id}"


def market_path(ticker: str) -> str:
    return f"{PATH_PREFIX}/markets/{ticker}"


def orderbook_path(ticker: str) -> str:
    return f"{PATH_PREFIX}/markets/{ticker}/orderbook"


REPLY_SCRUB_MAX_CHARS = 300
_REPLY_TOKEN_RE = re.compile(r"[A-Za-z0-9+/=_-]{24,}")


def _scrub_reply(http: int, payload: bytes | bytearray) -> str:
    """First 300 chars of the raw reply body, any 24+-char base64/hex-looking run replaced."""
    text = bytes(payload).decode("utf-8", errors="replace")[:REPLY_SCRUB_MAX_CHARS]
    return f"{http} {_REPLY_TOKEN_RE.sub('[redacted]', text)}"


class VenueError(RuntimeError):
    def __init__(self, http: int, code: str | None, msg: str, reply: str = "") -> None:
        self.http, self.code, self.msg, self.reply = http, code, msg, reply
        suffix = f' reply="{reply}"' if reply else ""
        super().__init__(f"kalshi-perp http {http} code {code}: {msg}{suffix}")


class OrderStateUnknown(RuntimeError):
    def __init__(self, client_id: str, why: str, reply: str = "") -> None:
        suffix = f' reply="{reply}"' if reply else ""
        super().__init__(f"order {client_id} state unknown: {why}{suffix}")
        self.client_id = client_id
        self.reply = reply


def _decimal(value: Any, *, max_digits: int = 20, allow_negative: bool = False) -> Decimal:
    if not isinstance(value, str) or not 0 < len(value) <= max_digits:
        raise ValueError("malformed decimal")
    try:
        d = Decimal(value)
    except InvalidOperation as e:
        raise ValueError("malformed decimal") from e
    if not d.is_finite() or (d < 0 and not allow_negative):
        raise ValueError("malformed decimal")
    return d


def _wire_price(price: Decimal) -> Decimal:
    """BTC dollars -> the venue's per-contract dollars (BTC price x one contract's BTC size)."""
    if not isinstance(price, Decimal) or not price.is_finite():
        raise MalformedInput(f"price out of bounds: {price!r}")
    return price * BTC_CONTRACT_BTC


def _price_str(per_contract_price: Decimal) -> str:
    """Formats an already-converted per-contract price for the wire: positive, below the venue's
    $1,000,000 ceiling, quantized to its 4-decimal tick ("79246.7" -> refused live as
    "invalid dollar precision: -1" on the (unconverted) event API's 2-decimal venue; BTCPERP's
    tick is 0.0001)."""
    if not isinstance(per_contract_price, Decimal) or not per_contract_price.is_finite() \
            or not (0 < per_contract_price < Decimal(1_000_000)):
        raise MalformedInput(f"price out of bounds: {per_contract_price!r}")
    return str(per_contract_price.quantize(Decimal("0.0001")))


def _whole_count(v: Any) -> int | None:
    """The venue reports counts as fixed-point strings ("12.00"); accept an int or a whole-number
    decimal string, refuse fractions, negatives and anything else (None)."""
    if type(v) is int:
        return v if v >= 0 else None
    if isinstance(v, str) and 0 < len(v) <= 24:
        try:
            d = Decimal(v)
        except Exception:  # noqa: BLE001
            return None
        if d.is_finite() and d >= 0 and d == d.to_integral_value():
            return int(d)
    return None


def _order_body(ticker: str, side: str, count: int, price: Decimal, tif: str, reduce_only: bool,
                 client_id: str, subaccount: int) -> dict[str, Any]:
    if not isinstance(ticker, str) or not ticker or len(ticker) > 64:
        raise MalformedInput("ticker")
    if side not in ("bid", "ask"):
        raise MalformedInput("side must be 'bid' or 'ask'")
    if type(count) is not int or not 0 < count <= 100_000:
        raise MalformedInput("count")
    if tif not in TIF_VALUES:
        raise MalformedInput("time_in_force")
    if not isinstance(reduce_only, bool):
        raise MalformedInput("reduce_only")
    if not isinstance(client_id, str) or not 0 < len(client_id) <= 36:
        raise MalformedInput("client id")
    if type(subaccount) is not int or not MIN_SUBACCOUNT <= subaccount <= MAX_SUBACCOUNT:
        raise MalformedInput("subaccount")
    return {
        "ticker": ticker,
        "side": side,
        "count": str(count),
        "price": _price_str(_wire_price(price)),
        "time_in_force": tif,
        "self_trade_prevention_type": "taker_at_cross",
        "reduce_only": reduce_only,
        "client_order_id": client_id,
        "subaccount": subaccount,
    }


class KalshiPerp:
    """Thin signed margin-API client. Holds the PEM in a string that is never formatted anywhere."""

    def __init__(self, auth: LiveAuthorization, key_id: str | None = None, private_key_pem: str | None = None,
                 base_url: str = MARGIN_REST_URL, *, subaccount: int = 0, journal_dir: str | Path) -> None:
        if not isinstance(auth, LiveAuthorization):
            raise LiveGateClosed("live client requires a LiveAuthorization from assert_armed()")
        if auth.venue != "kalshi-perp":
            raise LiveGateClosed("authorization is for another venue")
        auth.check(time.time_ns())
        if type(subaccount) is not int or not MIN_SUBACCOUNT <= subaccount <= MAX_SUBACCOUNT:
            raise ValueError("subaccount out of range")
        key_id = key_id if key_id is not None else os.environ.get(CRED_KEY_ID_ENV, "")
        pem = private_key_pem if private_key_pem is not None else os.environ.get(CRED_PEM_ENV, "")
        if len(key_id) < 8 or len(pem) < 32:
            raise PermissionError("kalshi credentials missing")
        self.auth = auth
        self.subaccount = subaccount
        self._key_id = key_id
        self._pem = pem.replace("\\n", "\n")
        self.base_url = base_url
        self._session: aiohttp.ClientSession | None = None
        self._owned: dict[str, str] = {}
        self.unresolved: list[str] = []
        self._records: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()
        self._journal_failed = False
        self.journal_path = Path(journal_dir) / "perp-orders.jsonl"
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)
        self.load_journal()

    def __repr__(self) -> str:
        return f"KalshiPerp(subaccount={self.subaccount}, nonce={self.auth.nonce})"

    def _refresh_unresolved(self) -> None:
        self.unresolved = [cid for cid, state in self._owned.items() if state == "UNKNOWN"]

    def load_journal(self) -> None:
        records: dict[str, dict[str, Any]] = {}
        try:
            with self.journal_path.open("rb") as journal:
                data = journal.read(MAX_JOURNAL_BYTES + 1)
        except FileNotFoundError:
            data = b""
        if len(data) > MAX_JOURNAL_BYTES:
            raise RuntimeError("kalshi perp order journal exceeds 1 MB; archive and restart")
        if data and not data.endswith(b"\n"):
            raise RuntimeError("kalshi perp order journal has an incomplete row")
        try:
            for line in data.splitlines():
                row = orjson.loads(line)
                cid, state = row["client_id"], row["state"]
                if not isinstance(cid, str) or not 0 < len(cid) <= 36 or state not in STATES:
                    raise ValueError("invalid identity or state")
                if not isinstance(row["ticker"], str) or not row["ticker"]:
                    raise ValueError("invalid ticker")
                if row["side"] not in ("bid", "ask"):
                    raise ValueError("invalid side")
                if type(row["count"]) is not int or row["count"] <= 0:
                    raise ValueError("invalid count")
                if not isinstance(row["reduce_only"], bool):
                    raise ValueError("invalid reduce_only")
                filled = row.get("fill_count", 0)
                if type(filled) is not int or not 0 <= filled <= row["count"]:
                    raise ValueError("invalid fill count")
                oid = row.get("venue_order_id")
                if oid is not None and (type(oid) is not int or oid < 0):
                    raise ValueError("invalid order id")
                if not isinstance(row["note"], str) or type(row["ts_ns"]) is not int:
                    raise ValueError("invalid note or timestamp")
                records[cid] = row
                if len(records) > MAX_OWNED:
                    raise RuntimeError("owned order table exceeds MAX_OWNED")
        except (ValueError, TypeError, KeyError) as e:
            raise RuntimeError("malformed kalshi perp order journal") from e
        self._records = records
        self._owned = {cid: row["state"] for cid, row in records.items()}
        self._refresh_unresolved()

    def _transition(self, client_id: str, state: str, note: str, **updates: Any) -> None:
        row = dict(self._records[client_id])
        row.update(updates, ts_ns=time.time_ns(), client_id=client_id, state=state, note=note)
        payload = orjson.dumps(row) + b"\n"
        try:
            current_size = self.journal_path.stat().st_size
        except FileNotFoundError:
            current_size = 0
        if current_size + len(payload) > MAX_JOURNAL_BYTES:
            self._journal_failed = True
            raise RuntimeError("kalshi perp order journal at 1 MB; archive and restart")
        try:
            with self.journal_path.open("ab") as journal:
                journal.write(payload)
                journal.flush()
                os.fsync(journal.fileno())
        except OSError:
            self._journal_failed = True
            self._owned[client_id] = "UNKNOWN"
            self._refresh_unresolved()
            raise
        self._records[client_id] = row
        self._owned[client_id] = state
        self._refresh_unresolved()

    async def __aenter__(self) -> "KalshiPerp":
        self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=TIMEOUT_S))
        return self

    async def __aexit__(self, *exc) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None

    def _headers(self, method: str, path: str) -> dict[str, str]:
        ts_ms = int(time.time() * 1000)
        return {
            "KALSHI-ACCESS-KEY": self._key_id,
            "KALSHI-ACCESS-TIMESTAMP": str(ts_ms),
            "KALSHI-ACCESS-SIGNATURE": sign(ts_ms, method, path, self._pem),
        }

    async def _execute(self, method: str, path: str, *, body: dict[str, Any] | None = None,
                        mutating: bool = False, cid: str = "") -> Any:
        if self._session is None:
            raise RuntimeError("client not entered")
        http = 0
        url = f"{self.base_url}{path}"
        headers = self._headers(method, path)
        try:
            kwargs = {"json": body} if body is not None else {}
            async with self._session.request(method, url, headers=headers, **kwargs) as resp:
                http = resp.status
                payload = bytearray()
                async for chunk in resp.content.iter_chunked(65536):
                    payload.extend(chunk)
                    if len(payload) > 1 << 20:
                        raise VenueError(http, None, "malformed", _scrub_reply(http, payload))
                try:
                    reply = orjson.loads(payload) if payload else {}
                except ValueError as e:
                    raise VenueError(http, None, "malformed", _scrub_reply(http, payload)) from e
                if not 200 <= http < 300:  # the venue answers a filled create with 201
                    scrubbed = _scrub_reply(http, payload)
                    if 400 <= http < 500 and isinstance(reply, dict) and isinstance(reply.get("error"), dict):
                        err = reply["error"]
                        code, msg = err.get("code"), err.get("message", "")
                        if (code is None or isinstance(code, str)) and isinstance(msg, str):
                            raise VenueError(http, code, msg, scrubbed)
                    raise VenueError(http, None, "malformed", scrubbed)
                return reply
        except VenueError as e:
            if mutating and not (400 <= e.http < 500 and e.code is not None):
                raise OrderStateUnknown(cid, f"http {e.http}: malformed or ambiguous reply", e.reply) from e
            raise
        except (asyncio.TimeoutError, aiohttp.ClientError, ConnectionError) as e:
            if mutating:
                raise OrderStateUnknown(cid, type(e).__name__) from e
            raise VenueError(http, None, "malformed") from e

    def _validate_order_reply(self, reply: Any, count: int, tif: str) -> Any:
        try:
            if not isinstance(reply, dict):
                raise ValueError("object")
            # Documented margin-rest create-order reply: order_id (string), client_order_id, fill_count and
            # remaining_count as fixed-point strings; average_fill_price and average_fee_paid only when
            # fill_count > 0. For immediate_or_cancel and fill_or_kill, remaining_count is the unfilled
            # quantity after the venue canceled it, never a resting remainder. No timestamp field.
            oid = reply.get("order_id")
            if type(oid) is int:
                if oid < 0:
                    raise ValueError("order id")
            elif not isinstance(oid, str) or not 0 < len(oid) <= 64:
                raise ValueError("order id")
            filled = _whole_count(reply.get("fill_count"))
            remaining = _whole_count(reply.get("remaining_count"))
            if filled is None or remaining is None:
                raise ValueError("counts")
            if filled + remaining > count:
                raise ValueError("fill_count + remaining_count exceeds requested count")
        except (ValueError, TypeError, KeyError) as e:
            raise VenueError(200, None, "malformed", f"200 {_scrub_reply(200, orjson.dumps(reply) if isinstance(reply, (dict, list)) else b'')}") from e
        return reply

    async def place(self, ticker: str, side: str, count: int, price: Decimal, tif: str,
                     reduce_only: bool, client_id: str) -> dict[str, Any]:
        async with self._lock:
            self._refresh_unresolved()
            if self.unresolved:
                raise OrderStateUnknown(self.unresolved[0], "resolve before placing anything new")
            if self._journal_failed:
                raise RuntimeError("kalshi perp order journal failed; restart required")
            if len(self._owned) >= MAX_OWNED:
                raise RuntimeError("owned order table full")
            if client_id in self._owned:
                raise LiveGateClosed("client id already owned")
            body = _order_body(ticker, side, count, price, tif, reduce_only, client_id, self.subaccount)
            self._records[client_id] = {
                "ticker": ticker, "side": side, "count": count, "price": str(price),
                "wire_price": body["price"], "tif": tif,
                "reduce_only": reduce_only, "venue_order_id": None, "fill_count": 0,
            }
            self._transition(client_id, "SENT", "place requested")
            try:
                reply = await self._execute("POST", ORDERS_PATH, body=body, mutating=True, cid=client_id)
                reply = self._validate_order_reply(reply, count, tif)
            except asyncio.CancelledError:
                self._transition(client_id, "UNKNOWN", "place task cancelled")
                raise
            except VenueError as e:
                rejected = 400 <= e.http < 500 and e.code is not None
                reply_suffix = f' reply="{e.reply}"' if e.reply else ""
                if rejected:
                    self._transition(client_id, "GONE", f"place failed: http={e.http} code={e.code}{reply_suffix}")
                    raise
                self._transition(client_id, "UNKNOWN", f"place failed: http={e.http}{reply_suffix}")
                raise OrderStateUnknown(client_id, "VenueError", e.reply) from e
            except OrderStateUnknown as e:
                reply_suffix = f' reply="{e.reply}"' if e.reply else ""
                self._transition(client_id, "UNKNOWN", f"place failed: ambiguous{reply_suffix}")
                raise
            filled, remaining = _whole_count(reply["fill_count"]), _whole_count(reply["remaining_count"])
            if remaining > 0 and tif in RESTING_TIF:
                state = "RESTING"
            elif filled == count:
                state = "FILLED"
            elif filled:
                state = "PARTIAL"
            else:
                state = "GONE"
            self._transition(client_id, state, "venue reply", venue_order_id=reply["order_id"], fill_count=filled)
            return reply

    async def cancel(self, order_id: int) -> dict[str, Any]:
        if type(order_id) is not int or order_id < 0:
            raise MalformedInput("order id")
        return await self._execute("DELETE", order_path(order_id), mutating=True, cid=str(order_id))

    async def reconcile(self) -> list[str]:
        """No GET-order-by-id exists on the margin API: an unresolved (UNKNOWN) record is
        explained only by comparing it against the venue's current position for that ticker."""
        async with self._lock:
            if not self.unresolved:
                return []
            positions = await self.positions()
            by_ticker: dict[str, int] = {}
            for p in positions:
                tk = p.get("market_ticker", p.get("ticker")) if isinstance(p, dict) else None
                if isinstance(tk, str):
                    # the venue row is {"market_ticker", "position": signed fixed-point count, ...}
                    raw = p.get("position", p.get("count", 0)) or 0
                    try:
                        c = abs(int(Decimal(str(raw)).to_integral_value()))
                    except Exception:  # noqa: BLE001
                        c = 0
                    by_ticker[tk] = by_ticker.get(tk, 0) + c
            for cid in list(self.unresolved):
                record = self._records[cid]
                held = by_ticker.get(record["ticker"], 0)
                if record["reduce_only"]:
                    explained = held < record["count"]  # some or all of the reduce leg took effect
                else:
                    explained = held > 0
                if explained:
                    self._transition(cid, "FILLED", "reconciled from positions", fill_count=record["count"])
            return list(self.unresolved)

    async def positions(self) -> list[dict[str, Any]]:
        reply = await self._execute("GET", POSITIONS_PATH)
        rows = reply.get("positions") if isinstance(reply, dict) else None
        if not isinstance(rows, list) or len(rows) > 1000:
            raise VenueError(200, None, "malformed")
        return [_row_to_btc_dollars(row, _POSITION_PRICE_KEYS) for row in rows]

    async def balance(self) -> dict[str, int]:
        reply = await self._execute("GET", BALANCE_PATH)
        try:
            if not isinstance(reply, dict):
                raise ValueError("object")
            out = {}
            for key in ("cash", "position_value", "total", "maintenance_requirement"):
                v = reply.get(key)
                if type(v) is not int or v < 0:
                    raise ValueError(key)
                out[key] = v
        except (ValueError, TypeError, KeyError) as e:
            raise VenueError(200, None, "malformed") from e
        return out

    async def risk(self) -> dict[str, Any]:
        reply = await self._execute("GET", RISK_PATH)
        if not isinstance(reply, dict):
            raise VenueError(200, None, "malformed")
        return _row_to_btc_dollars(reply, _RISK_PRICE_KEYS)

    async def funding_estimate(self) -> Decimal:
        reply = await self._execute("GET", FUNDING_ESTIMATE_PATH)
        try:
            if not isinstance(reply, dict):
                raise ValueError("object")
            return _decimal(reply["estimate"], allow_negative=True)
        except (ValueError, TypeError, KeyError) as e:
            raise VenueError(200, None, "malformed") from e

    async def funding_historical(self) -> list[dict[str, Any]]:
        reply = await self._execute("GET", FUNDING_HISTORICAL_PATH)
        rows = reply.get("funding_rates") if isinstance(reply, dict) else None
        if not isinstance(rows, list) or len(rows) > 10_000:
            raise VenueError(200, None, "malformed")
        return rows

    async def mark(self, ticker: str) -> Decimal:
        if not isinstance(ticker, str) or not ticker:
            raise MalformedInput("ticker")
        reply = await self._execute("GET", market_path(ticker))
        market = reply.get("market") if isinstance(reply, dict) else None
        if not isinstance(market, dict):
            raise VenueError(200, None, "malformed")
        try:
            return _decimal(market["mark_price"]) / BTC_CONTRACT_BTC
        except (ValueError, TypeError, KeyError) as e:
            raise VenueError(200, None, "malformed") from e

    async def orderbook(self, ticker: str) -> dict[str, Any]:
        if not isinstance(ticker, str) or not ticker:
            raise MalformedInput("ticker")
        reply = await self._execute("GET", orderbook_path(ticker))
        if not isinstance(reply, dict):
            raise VenueError(200, None, "malformed")
        return reply

    async def trades(self) -> list[dict[str, Any]]:
        reply = await self._execute("GET", TRADES_PATH)
        rows = reply.get("trades") if isinstance(reply, dict) else None
        if not isinstance(rows, list) or len(rows) > 1000:
            raise VenueError(200, None, "malformed")
        return [_row_to_btc_dollars(row, _TRADE_PRICE_KEYS) for row in rows]


# --- PerpSleeve: the bounded $20/5x book -----------------------------------------------------


class PerpSleeveError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class PerpSleeveParams:
    collateral_usd: Decimal = Decimal("20")
    leverage: int = 5
    stop_pct: Decimal = Decimal("0.01")
    trailing_pct: Decimal = Decimal("0.015")
    time_stop_s: int = 24 * 3600
    max_attempts_per_hour: int = 1
    reentry_cooldown_s: int = 30 * 60
    close_bound_usd: Decimal = Decimal("20")
    fee_bps: Decimal = Decimal("0")

    def __post_init__(self) -> None:
        if not (Decimal("1") <= self.collateral_usd <= Decimal("10000")):
            raise ValueError("collateral_usd out of range")
        if type(self.leverage) is not int or not 1 <= self.leverage <= 10:
            raise ValueError("leverage must be an int in [1, 10]")
        if not (Decimal("0") < self.stop_pct <= Decimal("0.5")):
            raise ValueError("stop_pct out of range")
        if not (Decimal("0") < self.trailing_pct <= Decimal("0.5")):
            raise ValueError("trailing_pct out of range")
        if not (60 <= self.time_stop_s <= 7 * 86400):
            raise ValueError("time_stop_s out of range")
        if not (1 <= self.max_attempts_per_hour <= 60):
            raise ValueError("max_attempts_per_hour out of range")
        if not (0 <= self.reentry_cooldown_s <= 86400):
            raise ValueError("reentry_cooldown_s out of range")
        if not (Decimal("1") <= self.close_bound_usd <= Decimal("10000")):
            raise ValueError("close_bound_usd out of range")
        if not (Decimal("0") <= self.fee_bps <= Decimal("1000")):
            raise ValueError("fee_bps out of range")

    @classmethod
    def sleeve(cls) -> "PerpSleeveParams":
        """The frozen day-1 sleeve: $20 collateral, 5x, 1%/1.5% stops, -$20 close bound."""
        return cls()

    @classmethod
    def sleeve_fast(cls) -> "PerpSleeveParams":
        """The operator's fastest measured-flat cadence cell: sleeve() with a 30-minute time stop
        and a 15-minute re-entry cooldown (2026-09-07 sweep, PLAN-S2D day-1 pick)."""
        return cls(time_stop_s=1800, reentry_cooldown_s=900)


PERP_LIMITS_PROFILES = {"kalshi-sleeve": PerpSleeveParams.sleeve, "kalshi-sleeve-fast": PerpSleeveParams.sleeve_fast}


def contracts_for(collateral_usd: Decimal, leverage: int, mark_usd: Decimal) -> int:
    """floor(notional / (0.0001 BTC * mark)); notional = collateral * leverage."""
    if not isinstance(mark_usd, Decimal) or mark_usd <= 0:
        raise PerpSleeveError("mark_usd must be a positive Decimal")
    notional = collateral_usd * leverage
    per_contract = BTC_CONTRACT_BTC * mark_usd
    return int((notional / per_contract).to_integral_value(rounding="ROUND_FLOOR"))


@dataclass
class PerpPosition:
    ticker: str
    side: str  # "bid" (long) or "ask" (short)
    count: int
    entry_price: Decimal
    opened_ns: int
    best_price: Decimal  # best mark since entry, for the trailing stop
    stop_order_id: int | None = None
    stop_client_id: str | None = None

    def unrealized_usd(self, mark: Decimal) -> Decimal:
        direction = Decimal(1) if self.side == "bid" else Decimal(-1)
        return direction * (mark - self.entry_price) * self.count * BTC_CONTRACT_BTC


class PerpSleeve:
    """One position at a time, bounded by its own numbers before the venue's margin is ever
    trusted. `client` is duck-typed to KalshiPerp's async place/cancel/funding_historical."""

    def __init__(self, client: Any, params: PerpSleeveParams) -> None:
        if not isinstance(params, PerpSleeveParams):
            raise PerpSleeveError("params required")
        self.client = client
        self.params = params
        self.position: PerpPosition | None = None
        self.realized_usd = Decimal("0")
        self.attempts_this_hour: list[int] = []  # entry timestamps, ns
        self.last_stop_ns: int | None = None
        self.halted = False
        self.ledger_rows: list[dict[str, Any]] = []
        self.funded_ns: set[str] = set()  # dedupe funding rows already logged, keyed on payment id
        self._known_fee_warned = False
        self.stats: dict[str, Any] = {"resting_stop_supported": VENUE_ALLOWS_RESTING_REDUCE_ONLY}

    def sizing(self, mark_usd: Decimal) -> int:
        return contracts_for(self.params.collateral_usd, self.params.leverage, mark_usd)

    def can_attempt(self, now_ns: int) -> str | None:
        if self.halted:
            return "sleeve halted for the window"
        if self.position is not None:
            return "one open position at a time"
        hour_ago = now_ns - 3600 * 1_000_000_000
        self.attempts_this_hour = [t for t in self.attempts_this_hour if t > hour_ago]
        if len(self.attempts_this_hour) >= self.params.max_attempts_per_hour:
            return "one attempt per hour"
        if self.last_stop_ns is not None and now_ns - self.last_stop_ns < self.params.reentry_cooldown_s * 1_000_000_000:
            return "re-entry cooldown after a stop"
        return None

    def unrealized_usd(self, mark: Decimal) -> Decimal:
        return self.position.unrealized_usd(mark) if self.position is not None else Decimal("0")

    def cumulative_usd(self, mark: Decimal) -> Decimal:
        return self.realized_usd + self.unrealized_usd(mark)

    def _stop_price(self, side: str, entry: Decimal) -> Decimal:
        adverse = Decimal(1) - self.params.stop_pct if side == "bid" else Decimal(1) + self.params.stop_pct
        return entry * adverse

    async def open(self, ticker: str, side: str, mark_usd: Decimal, now_ns: int, client_id: str) -> PerpPosition | None:
        reason = self.can_attempt(now_ns)
        if reason is not None:
            raise PerpSleeveError(reason)
        count = self.sizing(mark_usd)
        if count <= 0:
            raise PerpSleeveError("collateral too small to size one contract at this mark")
        self.attempts_this_hour.append(now_ns)
        reply = await self.client.place(ticker, side, count, mark_usd, "immediate_or_cancel", False, client_id)
        filled = _whole_count(reply.get("fill_count")) or 0  # the venue reports "12.00"; never a str downstream
        if not filled:
            return None
        entry_price = mark_usd
        position = PerpPosition(ticker, side, filled, entry_price, now_ns, entry_price)
        if VENUE_ALLOWS_RESTING_REDUCE_ONLY:
            stop_price = self._stop_price(side, entry_price)
            stop_side = "ask" if side == "bid" else "bid"
            try:
                stop_reply = await self.client.place(ticker, stop_side, filled, stop_price, "good_till_canceled",
                                                      True, client_id + "-stop")
                position.stop_order_id = stop_reply.get("order_id")
                position.stop_client_id = client_id + "-stop"
            except Exception:
                position.stop_order_id = None  # loop check below is the backstop
        else:
            position.stop_order_id = None  # venue refuses a resting reduce_only order; loop check is the backstop
            position.stop_client_id = None
        self.position = position
        self.ledger_rows.append({"kind": "open", "ticker": ticker, "side": side, "count": filled,
                                 "entry_price": str(entry_price), "client_id": client_id, "ts_ns": now_ns})
        return position

    async def adopt(self, ticker: str, side: str, count: int, entry_price: Decimal, now_ns: int,
                    client_id: str) -> PerpPosition:
        """Take over a position the venue already holds (a fill this process never booked, e.g. after
        a restart): same stop, trailing and time-stop bookkeeping as open(), no attempt counted."""
        if side not in ("bid", "ask") or type(count) is not int or count <= 0:
            raise PerpSleeveError("adopt: bad side or count")
        position = PerpPosition(ticker, side, count, entry_price, now_ns, entry_price)
        if VENUE_ALLOWS_RESTING_REDUCE_ONLY:
            stop_price = self._stop_price(side, entry_price)
            stop_side = "ask" if side == "bid" else "bid"
            try:
                stop_reply = await self.client.place(ticker, stop_side, count, stop_price, "good_till_canceled",
                                                      True, client_id + "-stop")
                position.stop_order_id = stop_reply.get("order_id")
                position.stop_client_id = client_id + "-stop"
            except Exception:  # noqa: BLE001 - the loop check is the backstop
                position.stop_order_id = None
        else:
            position.stop_order_id = None  # venue refuses a resting reduce_only order; loop check is the backstop
            position.stop_client_id = None
        self.position = position
        self.ledger_rows.append({"kind": "adopt", "ticker": ticker, "side": side, "count": count,
                                 "entry_price": str(entry_price), "client_id": client_id, "ts_ns": now_ns})
        return position

    async def close(self, reason: str, mark_usd: Decimal, now_ns: int, client_id: str) -> dict[str, Any] | None:
        position = self.position
        if position is None:
            return None
        if position.stop_order_id is not None:
            try:
                await self.client.cancel(position.stop_order_id)
            except Exception:
                pass  # a stop that already filled or is gone is not a reason to block the close
        close_side = "ask" if position.side == "bid" else "bid"
        # A close must execute: cross the spread by CLOSE_CROSS_BPS so the IOC fills at the mark region.
        cross = Decimal(CLOSE_CROSS_BPS) / Decimal(10_000)
        close_px = mark_usd * (Decimal(1) + cross) if close_side == "bid" else mark_usd * (Decimal(1) - cross)
        await self.client.place(position.ticker, close_side, position.count, close_px,
                                "immediate_or_cancel", True, client_id)
        pnl = position.unrealized_usd(mark_usd)
        self.realized_usd += pnl
        self.position = None
        if reason in ("stop", "trailing_stop", "time_stop", "liquidation"):
            self.last_stop_ns = now_ns
        if reason == "liquidation" or self.realized_usd <= -self.params.close_bound_usd:
            self.halted = True
        row = {"kind": "close", "reason": reason, "ticker": position.ticker, "count": position.count,
              "pnl_usd": str(pnl), "client_id": client_id, "ts_ns": now_ns}
        self.ledger_rows.append(row)
        return row

    async def check_mark(self, mark_usd: Decimal, now_ns: int, client_id: str) -> dict[str, Any] | None:
        """Loop check on every mark: the backstop for a resting stop that is absent or rejected,
        the 24h time stop, and the -$close_bound cumulative bound. Call at least every 5 s live."""
        if self.position is not None:
            elapsed_s = (now_ns - self.position.opened_ns) / 1_000_000_000
            if elapsed_s >= self.params.time_stop_s:
                return await self.close("time_stop", mark_usd, now_ns, client_id)
            stop_price = self._stop_price(self.position.side, self.position.entry_price)
            adverse = mark_usd <= stop_price if self.position.side == "bid" else mark_usd >= stop_price
            if adverse:
                return await self.close("stop", mark_usd, now_ns, client_id)
        if self.cumulative_usd(mark_usd) <= -self.params.close_bound_usd:
            if self.position is not None:
                return await self.close("cumulative_bound", mark_usd, now_ns, client_id)
            self.halted = True
        return None

    async def on_minute_close(self, closing_mark_usd: Decimal, now_ns: int, client_id: str) -> dict[str, Any] | None:
        """Ratchets the trailing stop only on a completed minute bar, never intra-minute."""
        position = self.position
        if position is None:
            return None
        if position.side == "bid":
            position.best_price = max(position.best_price, closing_mark_usd)
            trail_level = position.best_price * (Decimal(1) - self.params.trailing_pct)
            breached = closing_mark_usd <= trail_level
        else:
            position.best_price = min(position.best_price, closing_mark_usd)
            trail_level = position.best_price * (Decimal(1) + self.params.trailing_pct)
            breached = closing_mark_usd >= trail_level
        if breached:
            return await self.close("trailing_stop", closing_mark_usd, now_ns, client_id)
        return None

    async def on_liquidation(self, mark_usd: Decimal, now_ns: int, client_id: str) -> dict[str, Any] | None:
        self.halted = True
        if self.position is not None:
            pnl = self.position.unrealized_usd(mark_usd)
            self.realized_usd += pnl
            self.position = None
            row = {"kind": "close", "reason": "liquidation", "pnl_usd": str(pnl), "client_id": client_id, "ts_ns": now_ns}
            self.ledger_rows.append(row)
            return row
        return None

    def log_funding(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Appends account-reported funding payments not already logged (deduped by payment id)."""
        logged = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            payment_id = str(row.get("id") or row.get("ts_ms") or "")
            if not payment_id or payment_id in self.funded_ns:
                continue
            fee_bps = row.get("fee_bps")
            if fee_bps not in (None, 0) and not self._known_fee_warned:
                self._known_fee_warned = True
            self.funded_ns.add(payment_id)
            entry = {"kind": "funding", **row}
            self.ledger_rows.append(entry)
            logged.append(entry)
        return logged
