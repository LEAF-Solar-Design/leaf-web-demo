"""Broker interface shared by the paper broker and the live adapters.

Spot only: positions are long-only, a sell larger than the position is rejected (no shorting).
"""
from __future__ import annotations

from dataclasses import dataclass

from ..types import Fill, Intent, Order, Quote, Side, Trade


@dataclass(frozen=True, slots=True)
class OpenOrderView:
    id: int
    side: Side
    price_i: int
    remaining_i: int
    ts_created_ns: int
    strategy: str


@dataclass(frozen=True, slots=True)
class BrokerView:
    """Read-only snapshot handed to strategies. Never exposes mutable broker state."""

    cash_q: int
    pos_i: int
    avg_cost_i: int
    open_orders: tuple[OpenOrderView, ...]
    fills_total: int
    fees_paid_q: int
    realized_q: int

    @property
    def open_count(self) -> int:
        return len(self.open_orders)


class Broker:
    venue: str = "base"
    symbol: str = ""

    def submit(self, intent: Intent, strategy: str, now_ns: int) -> Order:
        raise NotImplementedError

    def cancel(self, order_id: int, now_ns: int) -> bool:
        raise NotImplementedError

    def cancel_all(self, now_ns: int) -> int:
        raise NotImplementedError

    def on_quote(self, q: Quote, now_ns: int) -> list[Fill]:
        raise NotImplementedError

    def on_trade(self, t: Trade, now_ns: int) -> list[Fill]:
        raise NotImplementedError

    def settle(self, now_ns: int) -> list[Fill]:
        """Apply arrivals and cancel effects due by now_ns without a market event."""
        raise NotImplementedError

    def equity_q(self, mid_i: int) -> int:
        raise NotImplementedError

    def liquidation_q(self) -> int:
        raise NotImplementedError

    def view(self) -> BrokerView:
        raise NotImplementedError

    def open_notional_q(self) -> int:
        raise NotImplementedError

    def pending_i(self, side: Side) -> int:
        """Remaining size of open orders on `side` (worst-case exposure if they all fill)."""
        raise NotImplementedError
