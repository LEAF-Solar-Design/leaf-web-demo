"""Account entry risk shared by books, lanes and replay.

SQLite's write transaction serializes processes before an order may be sent.
Unknown sends retain their full fee-inclusive reservation without a timeout.
Exits and settlements release cost only on an identified, confirmed event.
See README.md in this directory for the atomic snapshot restore rule.
"""
from __future__ import annotations

from collections.abc import Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_DOWN, ROUND_FLOOR
import json
import hashlib
import heapq
import os
from pathlib import Path
import sqlite3
import threading
import time

from ..refusal_journal import binding_detail, journal_heartbeat, journal_refusal
from ..policy import DEFAULT_POLICY, hard_maxima, entry_risk_room, entry_risk_caps


_perf_counter_ns = time.perf_counter_ns
LEDGER_FORMATS = ("body", "rows-v1")


# F2 GATE: venue market_exposure is unconfirmed on live rows, so residual (foreign)
# valuation ships DISABLED. Every ticker class that needs X refuses the whole
# reservation with foreign_value_unavailable until this is flipped by a reviewed change.
RESIDUAL_VALUATION_ENABLED = False
# A v2 reservation covers venue quantity only while 0 <= age < 60 s (never negative).
COVER_WINDOW_NS = 60_000_000_000
PROVENANCE_MAX_BYTES = 128
_HOLDER_MAX_CHARS = 40
_COUNT_TEXT_MAX_CHARS = 12
FOREIGN_OPEN_MAX = 64

# Archive limits never constrain version-1 entries or prevent a hot write.
ARCHIVE_ENTRY_MAX_BYTES = 16384
ARCHIVE_BATCH_ENTRIES = 128
ARCHIVE_BATCH_BYTES = 65536
_ARCHIVE = "entry_archive"


def _archive_json(value):
    return json.dumps(value, separators=(",", ":"), allow_nan=False)


def _archive_error():
    return AccountRiskRefused("risk entry archive corrupt", code="ledger_corrupt")


def _archive_create(db):
    db.execute("CREATE TABLE IF NOT EXISTS account_risk_archive "
               "(kind TEXT, id TEXT, body TEXT, sequence INTEGER, day TEXT, PRIMARY KEY(kind, id))")
    db.execute("CREATE INDEX IF NOT EXISTS account_risk_archive_ticker ON "
               "account_risk_archive(kind, json_extract(body, '$.ticker'))")


def _archive_init(state):
    state[_ARCHIVE] = {"count": 0, "legacy_count": 0, "next": len(state["entries"]),
                       "order": {cid: n for n, cid in enumerate(state["entries"])}, "closed": {}}


def _archive_meta(state):
    meta = state.get(_ARCHIVE)
    if meta is None:
        raise AccountRiskRefused("unsupported version 2 without archive metadata", code="ledger_corrupt")
    if (type(meta) is not dict or any(type(meta.get(key)) is not int or meta[key] < 0
                                    for key in ("count", "legacy_count", "next"))
            or meta["legacy_count"] > meta["count"]
            or not meta["count"] <= meta["next"] < _NS_MAX
            or type(meta.get("order")) is not dict or type(meta.get("closed")) is not dict
            or set(meta["order"]) != set(state["entries"])
            or any(type(n) is not int or not 0 <= n < meta["next"] for n in meta["order"].values())
            or len(set(meta["order"].values())) != len(meta["order"])
            or any(cid not in meta["order"] or type(day) is not str
                   for cid, day in meta["closed"].items())):
        raise _archive_error()
    return meta


def _archive_entry(body):
    if type(body) is not str or len(body.encode("utf-8")) > ARCHIVE_ENTRY_MAX_BYTES:
        raise _archive_error()
    entry = json.loads(body)
    if (type(entry) is not dict or entry.get("state") != "closed"
            or type(entry.get("ticker")) is not str or type(entry.get("minute")) is not int
            or any(type(entry.get(k)) is not int or not 0 <= entry[k] <= _CENTS_MAX
                   for k in ("cost_cents", "reserved_cents"))):
        raise _archive_error()
    return entry


class _ArchiveEntries(dict):
    """Iteration is hot-only; keyed access checks cold history in the owning transaction."""

    def __init__(self, entries, db, meta):
        super().__init__(entries)
        self.db, self.meta, self.cold = db, meta, {}
        self.views = []

    def __missing__(self, cid):
        if cid not in self.cold:
            row = self.db.execute("SELECT body, sequence, day FROM account_risk_archive "
                                  "WHERE kind='entry' AND id=?", (cid,)).fetchone()
            if row is None:
                raise KeyError(cid)
            entry = _archive_entry(row[0])
            self.cold[cid] = (entry, row)
        return self.cold[cid][0]

    def __contains__(self, cid):
        if dict.__contains__(self, cid):
            return True
        try:
            self[cid]
            return True
        except KeyError:
            return False

    def get(self, cid, default=None):
        try:
            return self[cid]
        except KeyError:
            return default

    def __setitem__(self, cid, entry):
        if not dict.__contains__(self, cid) and cid in self:
            self.cold[cid] = (entry, self.cold[cid][1])
        else:
            super().__setitem__(cid, entry)
            if cid not in self.meta["order"]:
                self.meta["order"][cid] = self.meta["next"]
                self.meta["next"] += 1

    def changed(self):
        return any(_archive_json(entry) != row[0] for entry, row in self.cold.values())

    def flush(self):
        for cid, (entry, row) in self.cold.items():
            payload = _archive_json(entry)
            if payload == row[0]:
                continue
            old = _archive_entry(row[0])
            pd = entry.get("pd")
            if (entry["state"] != "closed" or len(payload.encode("utf-8")) > ARCHIVE_ENTRY_MAX_BYTES
                    or (pd is not None and (type(pd) is not str or pd >= _utc_day(time.time_ns())))):
                self.db.execute("DELETE FROM account_risk_archive WHERE kind='entry' AND id=?", (cid,))
                dict.__setitem__(self, cid, entry)
                self.meta["order"][cid] = row[1]
                self.meta["count"] -= 1
                self.meta["legacy_count"] -= int(not _v2(old))
                if entry["state"] == "closed":
                    self.meta["closed"][cid] = row[2]
            else:
                self.db.execute("UPDATE account_risk_archive SET body=? WHERE kind='entry' AND id=?",
                                (payload, cid))
                self.meta["legacy_count"] += int(not _v2(entry)) - int(not _v2(old))


def _archive_prepare(state, *, max_entries=ARCHIVE_BATCH_ENTRIES, max_bytes=ARCHIVE_BATCH_BYTES):
    """Bookkeeping is revisioned with its write, but excluded from complete public exports."""
    meta, entries = state[_ARCHIVE], state["entries"]
    today = _utc_day(time.time_ns())
    rows, size, oversize = [], 0, 0
    for cid, entry in list(entries.items()):
        if cid not in meta["order"]:
            meta["order"][cid] = meta["next"]
            meta["next"] += 1
        if entry["state"] != "closed":
            meta["closed"].pop(cid, None)
            continue
        observed = meta["closed"].setdefault(cid, today)
        payload = _archive_json(entry)
        entry_bytes = len(payload.encode("utf-8"))
        if entry_bytes > ARCHIVE_ENTRY_MAX_BYTES:
            oversize += 1
            continue
        pd = entry.get("pd")
        if observed >= today or (pd is not None and (type(pd) is not str or pd >= today)):
            continue
        if len(rows) >= max_entries or size + entry_bytes > max_bytes:
            continue
        rows.append(("entry", cid, payload, meta["order"].pop(cid), observed))
        meta["closed"].pop(cid, None)
        del entries[cid]
        meta["count"] += 1
        meta["legacy_count"] += int(not _v2(entry))
        size += entry_bytes
    return rows, oversize


def _archive_insert(db, rows):
    db.executemany("INSERT INTO account_risk_archive(kind,id,body,sequence,day) VALUES (?,?,?,?,?)", rows)


def _archive_view(db, state, *, hot=False, ticker=None):
    if state.get("version") != 2:
        return state
    meta = _archive_meta(state)
    result = dict(state)
    result.pop(_ARCHIVE)
    if hot:
        result["entries"] = dict(state["entries"])
        result["archive"] = {"entries": meta["count"], "legacy_entries": meta["legacy_count"]}
        if ticker is not None:
            result["archive"]["ticker_exists"] = db.execute(
                "SELECT 1 FROM account_risk_archive WHERE kind='entry' "
                "AND json_extract(body, '$.ticker')=? LIMIT 1", (ticker,)).fetchone() is not None
        return result
    # Fetch at most the declared count plus one sentinel; excess history is corruption, never truncated.
    rows = db.execute("SELECT id,body,sequence,day,kind FROM account_risk_archive LIMIT ?",
                      (meta["count"] + 1,)).fetchall()
    if len(rows) != meta["count"]:
        raise _archive_error()
    ordered = {meta["order"][cid]: (cid, entry) for cid, entry in state["entries"].items()}
    ids, legacy = set(state["entries"]), 0
    for cid, body, sequence, day, kind in rows:
        if (kind != "entry" or type(cid) is not str or cid in ids
                or type(sequence) is not int or not 0 <= sequence < meta["next"]
                or sequence in ordered or type(day) is not str):
            raise _archive_error()
        entry = _archive_entry(body)
        if isinstance(state["entries"], _ArchiveEntries) and cid in state["entries"].cold:
            entry = state["entries"].cold[cid][0]
        ordered[sequence] = (cid, entry)
        ids.add(cid)
        legacy += int(not _v2(entry))
    if legacy != meta["legacy_count"]:
        raise _archive_error()
    result["entries"] = dict(ordered[key] for key in sorted(ordered))
    # Complete exports use portable v1; only the on-disk split body and explicit hot views use v2.
    result["version"] = 1
    return result

# Only live adapters opt into fail-closed incumbent-policy discovery.
DRAWDOWN_POLICY_UNAVAILABLE = object()
# Bound the incumbent-adopted probe thresholds in every regime.
PROBE_DRAWDOWN_BRAKE_MAX = 0.25
PROBE_DRAWDOWN_STOP_MAX = 0.40


def _drawdown_fractions(policy):
    try:
        values = (policy.drawdown_brake_fraction, policy.drawdown_stop_fraction)
        if all(type(value) in (int, float) and 0 <= value <= 1 for value in values):
            return values
    except Exception:
        pass
    return None

# Closed refusal code set; "uncoded" is the counted default for any other value.
REFUSAL_CODES = frozenset({
    "uncoded", "input_invalid", "ledger_identity", "ledger_corrupt", "clock_backwards",
    "ledger_format_rows", "ledger_format_body",
    "revision_conflict", "duplicate_client_id", "ledger_fault", "settlement_minute_reconcile",
    "invariant", "ticker_cap", "window", "daily_loss", "cash_floor", "drawdown_brake",
    "drawdown_stop", "ticker_reconciliation_required", "ticker_foreign_exposure",
    "ticker_position_shortfall", "foreign_value_unavailable", "settlement_minute_unavailable",
    "venue_read_skew", "day_baseline_unknown",
    # Raised by the live adapter (X3) with the same exception type.
    "risk_posting_failed", "venue_malformed", "below_one_contract", "settlement_recovery_bound",
    "venue_read_failed", "venue_read_timeout", "domain_not_exposure_authority",
    "domain_ledger_mismatch", "wrapped_error",
    # T2-v4 R2: a headroom reservation that would leave the parent less than its stated capacity.
    "t2cal_headroom",
})
_BINDING_CODES = {"daily loss": "daily_loss", "marked daily loss": "daily_loss", "cash floor": "cash_floor",
                  "drawdown brake": "drawdown_brake", "drawdown stop": "drawdown_stop"}
# X2b (D5a): the marked day start. Both fields (and, since fix c, the day's transfer record
# _MARKED_TRANSFERS) are written together, once per UTC day, only
# by reserve() on a non-widened observation that carries a venue mark (fix d: a start with no
# record gets it on its next reservation, widened or not, since it records no observation); the frozen 4bb2f23
# writer never reads them and carries them through unchanged, and a record (or a current mark)
# whose venue timestamp names another UTC day is treated as missing (the paid term alone binds).
_MARKED_CENTS, _MARKED_NS = "day_open_marked_cents", "day_open_marked_ns"
# X2b fix c: [sum of the transfers recorded on the marked start's UTC day, latest such instant or
# -1], written with the start at install and moved by transfer(), so the marked term reads one
# stored value and never scans the event history. Absent on a body a pre-fix-c writer made.
_MARKED_TRANSFERS = "day_open_marked_transfers"
# X2b fix e/f: [newest UTC day (ns // _DAY_NS) holding a transfer event or -1, [the event keys
# ("transfer:" + id) of the transfers on that day, in append order], seen], built by the first
# marked install or record rebuild (one full pass per ledger lifetime) and moved in O(1) by
# transfer() and the legacy import (_index_add), so an install or rebuild reads today's transfers by
# key and never walks the events. Absent until then. seen is len(events) at the last point where
# the index, the day record and today's marked start reflected every transfer event before it: every
# writer version only ever appends events (none pops, deletes or reorders one), so len(events) is the
# completeness stamp every writer grows, the frozen 4bb2f23 writer included, and the events after
# seen are exactly the last len(events) - seen keys in body order (_catch_up applies them).
_TRANSFER_INDEX = "transfer_day_index"
_RESTORE_MARKER = "restore_marker"
_NS_MAX = 2**63 - 1
_DAY_NS = 86_400 * 10**9
_EPOCH_ORDINAL = date(1970, 1, 1).toordinal()
_TRANSFER_PREFIX = "transfer:"
# RISK-SPIKE-GUARD (2026-09-27, owner ledger 067c8339): one basis write carried equity 180399c
# against a 55586c day open, became the high water, and every later entry read a 69.5% drawdown
# (drawdown_stop) until a manual rebase. A real account cannot gain half its value in one
# observation without a transfer, so a basis write above bound * 3/2 is refused venue_read_skew
# and writes nothing (_basis), and a widened observation above it is refused the same way before
# it can size an entry off itself (_scratch_basis). Integer arithmetic only.
EQUITY_JUMP_NUM, EQUITY_JUMP_DEN = 3, 2
# Who raised the high water last (_basis): optional, overwritten on each raise, absent on every
# body a frozen or pre-guard writer made (they carry it through unchanged).
_RAISED = "high_water_raised"
_RAISED_KEYS = frozenset({"at_ns", "from_cents", "to_cents", "equity_cents", "client_id", "cash_cents",
                          "open_cost_cents"})
_RAISED_TEXT_MAX = 128
# RC2 (operator 2026-09-28, "Reserve a probe slice"): a slice of each daily-loss term that only
# probe reservations may use. Code constants on purpose: not a policy field, not a tuner dial and
# in no book config, so a change never rotates a live book's config digest; it rides a reviewed
# runner flip, which is its receipt. Revisit the cap per probe wave.
# A probe's client-id prefix (probe=None callers); pinned equal to kalshi_live._RISK_PROBE_PREFIX.
PROBE_CLIENT_PREFIX = "lp-"
# Operator 2026-09-29: raise the probe slice and give probes their own daily-loss budget.
PROBE_LOSS_RESERVE_CENTS = 5000
# Share of floor(base * account fraction); exact Decimal, never float.
PROBE_LOSS_RESERVE_SHARE = Decimal("0.30")


def _probe_entry(client_id, entry):
    """RC2: a ledger entry is a probe's when it carries "pr": 1; one without "pr" (written before
    RC2, or imported) is a probe's only when its id starts PROBE_CLIENT_PREFIX. O(1), never raises.
    reserve()'s entry loop inlines this same rule."""
    tag = entry.get("pr")
    if tag is not None:
        return tag == 1
    return type(client_id) is str and client_id.startswith(PROBE_CLIENT_PREFIX)


def _reserve_fraction(account_policy):
    """RC2 v3: (the account base policy's daily_loss_fraction clamped by hard_maxima() exactly as
    the daily-loss term clamps it, as an exact Decimal in [0, 1], None) or (None, reason) when the
    policy is missing or malformed. Explicit probes then fail closed; legacy callers and
    incumbents keep reserve 0. Decimal of each value's shortest repr (0.15 is exactly 0.15);
    no float arithmetic."""
    if account_policy is None:
        return None, "account_policy_missing"
    try:
        fraction = min(Decimal(str(account_policy.daily_loss_fraction)),
                       Decimal(str(hard_maxima().get("daily_loss_fraction", 1))))
        if not fraction.is_finite() or fraction < 0:
            return None, "account_policy_invalid"
    except (AttributeError, TypeError, ValueError, InvalidOperation):
        return None, "account_policy_invalid"
    return min(fraction, Decimal(1)), None


def _probe_reserve(base_cents, fraction):
    """RC2: one daily-loss term's probe slice in integer cents: min(PROBE_LOSS_RESERVE_CENTS,
    floor(PROBE_LOSS_RESERVE_SHARE * floor(base_cents * fraction))), at least 0. Decimal and int
    only, never float; 0 without an account fraction or a positive base. O(1)."""
    if fraction is None or type(base_cents) is not int or base_cents <= 0:
        return 0
    room = int((Decimal(base_cents) * fraction).to_integral_value(rounding=ROUND_FLOOR))
    share = int((PROBE_LOSS_RESERVE_SHARE * room).to_integral_value(rounding=ROUND_FLOOR))
    return max(0, min(PROBE_LOSS_RESERVE_CENTS, share))


def _record_probe_loss(entry, released_cents, loss_cents, at_ns):
    """RC2 v3: add one release's realized loss to a probe entry's "pl" for the release's UTC day
    "pd" (additive entry fields; the body validator and the frozen 4bb2f23 reader check only the
    core fields). A later day replaces the value; an earlier day is ignored unless the stored day
    is ahead of the wall-clock UTC day (clock skew), so the record stays two
    bounded fields. loss_cents None or malformed counts the whole released cost (conservative),
    and a loss never exceeds the released cost. Gains are negative losses; both signs and the
    accumulated record are bounded by _CENTS_MAX. O(1), never raises."""
    if type(loss_cents) is not int or not -_CENTS_MAX <= loss_cents <= min(released_cents, _CENTS_MAX):
        loss_cents = released_cents
    if type(at_ns) is not int or not 0 <= at_ns <= _NS_MAX:
        at_ns = time.time_ns()
    day = _utc_day(at_ns)
    if type(entry.get("pd")) is str and day < entry["pd"] <= _utc_day(time.time_ns()):
        return
    prior = entry.get("pl") if entry.get("pd") == day else 0
    if type(prior) is not int or not -_CENTS_MAX <= prior <= _CENTS_MAX:
        prior = 0
    entry["pl"] = max(-_CENTS_MAX, min(_CENTS_MAX, prior + loss_cents))
    entry["pd"] = day


def _binding_room(room, paid, cash, marked, brake, stop):
    """reserve()'s binding term, O(1) and pure: the smallest of the per-order/cluster room, the
    paid daily-loss term and the cash floor (a tie keeps the earlier), then a strictly smaller
    marked daily-loss term (None when absent) or drawdown brake room (None when inactive), then
    the drawdown stop."""
    room, binding = min(((room, "per-order/cluster"), (paid, "daily loss"), (cash, "cash floor")),
                        key=lambda term: term[0])
    if marked is not None and marked < room:
        # D5a: one extra comparison; a tie keeps the paid binding.
        room, binding = marked, "marked daily loss"
    if brake is not None and brake < room:
        room, binding = brake, "drawdown brake"
    if stop and 0 < room:
        room, binding = 0, "drawdown stop"
    return room, binding


class AccountRiskRefused(RuntimeError):
    """Typed refusal. Message/args are unchanged; .detail is optional bounded binding evidence."""

    uncoded = 0  # process-wide count of refusals raised without a known code
    # RC1: (ledger, client_id, ticker, cents, revision) of a revision_conflict whose journal row
    # reserve(retried=False) deferred for the caller's one retry; None on every other refusal.
    journal_deferred = None

    def __init__(self, message="", code="uncoded", *, detail=None):
        super().__init__(message)
        if code not in REFUSAL_CODES:
            code = "uncoded"
        if code == "uncoded":
            AccountRiskRefused.uncoded += 1
        self.code = code
        try:
            self.detail = binding_detail(detail)
        except Exception:
            self.detail = {}


def journal_deferred_refusal(exc) -> bool:
    """RC1: journal, once, the revision_conflict row reserve(retried=False) deferred on `exc`, as
    a final refusal with retried=False (the caller's retry did not run). False when nothing was
    deferred or the row could not be written. Never raises."""
    deferred = getattr(exc, "journal_deferred", None)
    if not isinstance(deferred, tuple) or len(deferred) != 5:
        return False
    exc.journal_deferred = None
    ledger, client_id, ticker, cents, revision = deferred
    return journal_refusal(ledger, exc.code, client_id, ticker, cents, revision=revision, retried=False)


def _cents(value):
    if type(value) is not int or not 0 <= value <= 2**53 - 1:
        raise AccountRiskRefused("invalid risk cents", code="input_invalid")
    return value


def _headroom_cents(value):
    """A (market, window, total) tuple of non-negative int cents, else input_invalid (fails closed)."""
    if type(value) is not tuple or len(value) != 3 or any(
            type(cents) is not int or not 0 <= cents <= 2**53 - 1 for cents in value):
        raise AccountRiskRefused("invalid t2cal headroom", code="input_invalid")
    return value


def _headroom_inputs(headroom, expected_revision):
    """reserve()'s headroom before any ledger I/O: None, or a revision-bound tuple. No caller code
    ever runs inside the reserve transaction, so a callable refuses input_invalid like any other type."""
    if headroom is None:
        return None
    headroom = _headroom_cents(headroom)
    if expected_revision is None:
        raise AccountRiskRefused("t2cal headroom requires expected_revision", code="input_invalid")
    return headroom


def _utc_day(now_ns):
    """ISO date of the UTC day holding integer ns now_ns: exact floor division, never a float.

    1 ns before 00:00Z is yesterday (a float seconds value rounded it onto midnight).
    """
    return date.fromordinal(_EPOCH_ORDINAL + now_ns // _DAY_NS).isoformat()


def _marked_inputs(marked_cents, marked_ns):
    """Validate reserve()'s venue mark before any ledger I/O; None when no mark was observed.

    An unavailable marked value (None), with or without a timestamp, is the paid fallback and
    never refuses; a value without a timestamp, or a malformed one, is an input error.
    """
    if marked_cents is None:
        return None
    if type(marked_ns) is not int or not 0 <= marked_ns <= _NS_MAX:
        raise AccountRiskRefused("invalid marked portfolio observation", code="input_invalid")
    return _cents(marked_cents), marked_ns


def _marked_day_open(state, day):
    """Today's marked day start in cents, else None. day is an integer day (ns // _DAY_NS). O(1)."""
    cents, opened = state.get(_MARKED_CENTS), state.get(_MARKED_NS)
    if type(cents) is int and type(opened) is int and 0 <= opened <= _NS_MAX and opened // _DAY_NS == day:
        return cents
    return None


def _marked_transfers(state):
    """The start's day transfer record [sum cents, latest ns or -1], else None (absent or malformed). O(1)."""
    record = state.get(_MARKED_TRANSFERS)
    if (type(record) is list and len(record) == 2 and type(record[0]) is int and type(record[1]) is int
            and -1 <= record[1] <= _NS_MAX):
        return record
    return None


def _index_shaped(state):
    """The transfer index when it is [int day in -1..max, list, int seen in 0..max], else None.

    O(1): the container shape only, never a walk of its keys (_transfer_index checks those).
    """
    index = state.get(_TRANSFER_INDEX)
    if (type(index) is list and len(index) == 3 and type(index[0]) is int
            and -1 <= index[0] <= _NS_MAX // _DAY_NS and type(index[1]) is list
            and type(index[2]) is int and 0 <= index[2] <= _NS_MAX):
        return index
    return None


def _transfer_index(state):
    """The transfer index [newest day or -1, [its transfer keys], seen], else None (absent or malformed).

    O(k) in the k keys on the newest day: distinct "transfer:" strings, empty exactly when the day
    is -1. Called only where the index is read (_day_transfers) and by the auditor, never per add.
    """
    index = _index_shaped(state)
    if index is None:
        return None
    top, keys = index[0], index[1]
    if (top == -1) != (not keys):
        return None
    for key in keys:
        if type(key) is not str or not key.startswith(_TRANSFER_PREFIX):
            return None
    if len(set(keys)) != len(keys):
        return None
    return index


def _index_add(state, key, at_ns):
    """Move a present transfer index by one new transfer event (key, at_ns): O(1), never a walk
    of the events or of the index's keys.

    A later day replaces it with [that day, [key], seen], the same day appends key, an older day
    leaves it. The caller guarantees key is a new event key (transfer() returns on a replay, the
    legacy import skips an event already present, _catch_up passes only keys appended after
    seen), and a sound index names only existing events, so key is never already in it. An
    absent or malformed index stays so: it is never started here, because it cannot be proved
    complete without the one full pass (_day_transfers). Shared through _apply_transfer by
    transfer(), the legacy import and _catch_up so they cannot drift.
    """
    index = _index_shaped(state)
    if index is None:
        return
    at_day = at_ns // _DAY_NS
    if at_day > index[0]:
        state[_TRANSFER_INDEX] = [at_day, [key], index[2]]
    elif at_day == index[0]:
        index[1].append(key)


def _apply_transfer(state, key, amount, at_ns):
    """transfer()'s marked rule for one new transfer event: O(1).

    A marked start on the movement's UTC day that was observed strictly before it is restated
    by its amount (floored at 0; a start at or after it already contains it), and that day's
    record moves (sum and latest instant); an absent or malformed record stays so and the next
    reservation rebuilds it from the events. Then the index moves (_index_add). The paid basis
    is the caller's (transfer() moves it; the legacy import keeps its own rule).
    """
    if _marked_day_open(state, at_ns // _DAY_NS) is not None:
        if state[_MARKED_NS] < at_ns:
            state[_MARKED_CENTS] = min(2**53 - 1, max(0, state[_MARKED_CENTS] + amount))
        record = _marked_transfers(state)
        if record is not None:
            state[_MARKED_TRANSFERS] = [record[0] + amount, max(record[1], at_ns)]
    _index_add(state, key, at_ns)


def _append_event(state, key, value):
    """Append one new event, advancing a current index's stamp with it: O(1).

    A stamp that was current before the append stays current; one already behind stays behind,
    so _catch_up still applies the events a non-maintaining writer appended. A stamp ahead of
    the events (no writer produces it: events are append-only) drops the index, the day record
    and the marked start together BEFORE the append, as _catch_up does, so no append can bring
    the count up to it and make it look current; the next non-widened mark reinstalls them.
    Every writer of an event goes through here (release, finish_reversal, transfer, the import).
    """
    events = state["events"]
    index = _index_shaped(state)
    if index is not None and index[2] > len(events):
        for field in (_TRANSFER_INDEX, _MARKED_TRANSFERS, _MARKED_CENTS, _MARKED_NS):
            state.pop(field, None)
        index = None
    events[key] = value
    if index is not None and index[2] == len(events) - 1:
        index[2] = len(events)


def _catch_up(state):
    """Bring the index, the day record and today's marked start up to every event: O(1) when the
    stamp is current, else O(events appended since it), never the retained history.

    Events appended after the stamp by a writer that does not maintain it (the frozen 4bb2f23
    writer) are the last len(events) - seen keys; each well-formed transfer among them goes
    through transfer()'s marked rule (_apply_transfer) in append order, then the stamp moves.
    A stamp ahead of the events no writer can produce (events are append-only): the index, the
    record and the marked start are dropped together, so the next non-widened mark reinstalls
    all four exactly through the one full pass; until then the paid term decides.
    """
    index = _index_shaped(state)
    if index is None:
        return
    events = state["events"]
    count = len(events)
    if index[2] == count:
        return
    if index[2] > count:
        for field in (_TRANSFER_INDEX, _MARKED_TRANSFERS, _MARKED_CENTS, _MARKED_NS):
            state.pop(field, None)
        return
    tail, wanted = [], count - index[2]
    for key in reversed(events):
        tail.append(key)
        if len(tail) == wanted:
            break
    for key in reversed(tail):
        if key.startswith(_TRANSFER_PREFIX):
            moved = _transfer_value(events[key])
            if moved is not None:
                _apply_transfer(state, key, moved[0], moved[1])
    state[_TRANSFER_INDEX][2] = count


def _transfer_value(value):
    """(amount, at_ns) of a well-formed transfer event body, else None. O(1)."""
    if type(value) is not list or len(value) != 2:
        return None
    amount, at_ns = value
    if type(amount) is not int or type(at_ns) is not int or not 0 <= at_ns <= _NS_MAX:
        return None
    return amount, at_ns


def _day_transfers(state, day, after_ns):
    """(sum, latest ns or -1, sum strictly after after_ns) of the transfers on integer UTC day `day`.

    O(k) lookups for the k transfers on `day` once _catch_up has run, never a walk of the events.
    The transfer index names the newest UTC day holding a transfer and the keys of its transfers:
    that day reads exactly those keys, and a later day (none yet) reads nothing. The index is read
    only when it is current (its stamp equals len(events)); an index key that is missing,
    malformed or on another day is discarded and the exact full pass below rewrites the index (a
    repair, never a silent undercount). The full pass runs where no index-maintaining writer has
    built the index (once per ledger lifetime) or where the index is unusable (absent, malformed,
    not current, or holding a stale key): it sums the day and stores the index, stamped with
    len(events), in state for the caller's transaction. A transfer stamped on a later day than
    `day` also takes the (exact) full pass and stores nothing. Days are integer ns // _DAY_NS.
    """
    events = state["events"]
    index = _transfer_index(state)
    if index is not None and index[2] != len(events):
        index = None
    if index is not None and day > index[0]:
        return 0, -1, 0
    if index is not None and day == index[0]:
        total, latest, pending = 0, -1, 0
        for key in index[1]:
            transfer = _transfer_value(events.get(key))
            if transfer is None or transfer[1] // _DAY_NS != day:
                index = None  # a stale key: the exact pass below repairs the index
                break
            amount, at_ns = transfer
            total += amount
            latest = max(latest, at_ns)
            if at_ns > after_ns:
                pending += amount
        else:
            return total, latest, pending
    total, latest, pending = 0, -1, 0
    top, keys = -1, []
    for key, value in events.items():
        transfer = _transfer_value(value) if key.startswith(_TRANSFER_PREFIX) else None
        if transfer is None:
            continue
        amount, at_ns = transfer
        at_day = at_ns // _DAY_NS
        if at_day > top:
            top, keys = at_day, [key]
        elif at_day == top:
            keys.append(key)
        if at_day == day:
            total += amount
            latest = max(latest, at_ns)
            if at_ns > after_ns:
                pending += amount
    if index is None:
        state[_TRANSFER_INDEX] = [top, keys, len(events)]
    return total, latest, pending


def _audit_restore(state):
    """Audit a marked restore and recount its derived transfer state before any caller reads it."""
    fields = (_TRANSFER_INDEX, _MARKED_TRANSFERS, _MARKED_CENTS, _MARKED_NS)
    base = {key: value for key, value in state.items() if key not in fields}
    reason = _ledger_structure_error(base)
    if reason is not None:
        raise AccountRiskRefused(reason, code="ledger_corrupt")
    cents, opened = state.get(_MARKED_CENTS), state.get(_MARKED_NS)
    # Setting derived fields aside must not bypass X2c's money range on a restored start.
    if type(cents) is int and not 0 <= cents <= _CENTS_MAX:
        raise AccountRiskRefused(f"{_MARKED_CENTS} out of range", code="ledger_corrupt")
    start = type(cents) is int and type(opened) is int and 0 <= opened <= _NS_MAX
    day = opened // _DAY_NS if start else None
    total, latest = 0, -1
    top, keys = -1, []
    events = state["events"]
    for key, value in events.items():
        transfer = _transfer_value(value) if key.startswith(_TRANSFER_PREFIX) else None
        if transfer is None:
            continue
        amount, at_ns = transfer
        at_day = at_ns // _DAY_NS
        if at_day > top:
            top, keys = at_day, [key]
        elif at_day == top:
            keys.append(key)
        if at_day == day:
            total += amount
            latest = max(latest, at_ns)
    if ((start and _marked_transfers(state) != [total, latest])
            or (not start and (_MARKED_CENTS in state or _MARKED_NS in state))):
        for field in fields:
            state.pop(field, None)
    else:
        state[_TRANSFER_INDEX] = [top, keys, len(events)]
    del state[_RESTORE_MARKER]


def marked_portfolio_cents(cash_cents, venue_rows):
    """Cash plus the venue mark (market_exposure) of every held row, own and foreign alike.

    Foreign or unknown quantity is valued at its venue mark, so buying it moves cash into
    mark and never reads as breaker loss (its cost reaches reserve() as admission only).
    None when any held row carries no usable mark: the breaker then keeps the paid term
    and never refuses for it. O(P); malformed rows refuse venue_malformed as classify does.
    """
    total = _cents(cash_cents)
    for quantity, value in _venue_index(venue_rows, True).values():
        if not quantity:
            continue
        if value is None:
            return None
        total += value
    return total if total <= 2**53 - 1 else None


def _v2(entry):
    """A v2 entry carries reservation provenance; anything else is LEGACY (side and count UNKNOWN)."""
    p = entry.get("p")
    return type(p) is dict and p.get("v") == 2


def _side_code(side):
    if side is True or side in ("yes", "y"):
        return "y"
    if side is False or side in ("no", "n"):
        return "n"
    return None


def _decimal_text(value):
    """Canonical decimal text without exponent or trailing zeros ("10", "1.5")."""
    return format(Decimal(str(value)).normalize(), "f")


def _ceil(value):
    return int(Decimal(value).to_integral_value(rounding=ROUND_CEILING))


def _floor(value):
    return int(Decimal(value).to_integral_value(rounding=ROUND_FLOOR))


def admitted_count(count, requested_cents, allowed_cents, *, prepared):
    """The count the live adapter transmits after its risk trim (kalshi_live _apply_risk_trim).

    Pure and shared so the ledger's p.n always equals the sent body["count"]: whole
    contracts floor to int, fractional counts quantize to 0.01 ROUND_DOWN, and a
    prepared order (or a full admission) is sent untrimmed.
    """
    if allowed_cents >= requested_cents or prepared:
        return count
    per_contract = Decimal(requested_cents) / Decimal(str(count))
    trimmed = Decimal(allowed_cents) / per_contract
    whole = type(count) is int
    return int(trimmed) if whole else trimmed.quantize(Decimal("0.01"), rounding=ROUND_DOWN)


_HOLDER = None


def holder_identity():
    """"<boot_id[:8]>:<pid>:<proc starttime>", else "unknown:<pid>" (auditors treat as live)."""
    global _HOLDER
    pid = os.getpid()
    if _HOLDER is not None and _HOLDER[0] == pid:
        return _HOLDER[1]
    try:
        boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()[:8]
        stat = Path("/proc/self/stat").read_text()
        start = stat[stat.rindex(")") + 2:].split()[19]
        if len(boot) != 8 or not start.isdigit():
            raise ValueError("unreadable process identity")
        value = f"{boot}:{pid}:{start}"
    except (OSError, ValueError, IndexError):
        value = f"unknown:{pid}"
    _HOLDER = (pid, value)
    return value


def _provenance_inputs(side, count, price_cents, holder, journal_digest, authority_generation):
    """Validate reserve() provenance keywords before any ledger I/O; None when not requested."""
    if side is None and count is None:
        return None
    code = _side_code(side)
    if code is None or count is None or isinstance(count, bool):
        raise AccountRiskRefused("invalid reservation provenance", code="input_invalid")
    try:
        quantity = Decimal(str(count))
    except (InvalidOperation, ValueError) as exc:
        raise AccountRiskRefused("invalid reservation provenance", code="input_invalid") from exc
    if not quantity.is_finite() or quantity <= 0 or len(_decimal_text(quantity)) > _COUNT_TEXT_MAX_CHARS:
        raise AccountRiskRefused("invalid reservation provenance", code="input_invalid")
    if price_cents is not None and (type(price_cents) is not int or not 0 <= price_cents <= 100):
        raise AccountRiskRefused("invalid reservation provenance", code="input_invalid")
    if holder is None:
        holder = holder_identity()
    if not isinstance(holder, str) or not 0 < len(holder) <= _HOLDER_MAX_CHARS or not holder.isascii():
        raise AccountRiskRefused("invalid reservation provenance", code="input_invalid")
    if journal_digest is not None:
        if (not isinstance(journal_digest, str) or len(journal_digest) < 16
                or any(ch not in "0123456789abcdefABCDEF" for ch in journal_digest)):
            raise AccountRiskRefused("invalid reservation provenance", code="input_invalid")
        journal_digest = journal_digest[:16].lower()
    if authority_generation is not None and (type(authority_generation) is not int
                                             or not 0 <= authority_generation <= 2**53 - 1):
        raise AccountRiskRefused("invalid reservation provenance", code="input_invalid")
    return code, count, price_cents, holder, journal_digest, authority_generation


def _provenance(inputs, admitted, created_ns):
    """The compact v2 record, asserted <= PROVENANCE_MAX_BYTES as compact JSON."""
    side, _, price_cents, holder, journal_digest, generation = inputs
    p = {"v": 2, "s": side, "n": _decimal_text(admitted), "px": price_cents, "t": created_ns,
         "h": holder, "j": journal_digest, "g": generation}
    # An oversized holder degrades to "unknown" (auditors treat it as live) rather than refuse.
    for fallback in (None, f"unknown:{os.getpid()}", "unknown"):
        if fallback is not None:
            p["h"] = fallback
        if len(json.dumps(p, separators=(",", ":"))) <= PROVENANCE_MAX_BYTES:
            return p
    raise AccountRiskRefused("reservation provenance exceeds bound", code="invariant")


def _ticket_provenance(reservation, order_id):
    """The netted ticket's compact v2 record {v, s, d}, <= PROVENANCE_MAX_BYTES by construction.

    An open ticket is read by count, exact and p.s only (p.n, p.t, h, j, g are reservation
    phase and stay on the closed physical entry), so the ticket keeps side and derivation.
    p.d is the physical order id, or "#" + its sha256 hex[:16] when the id would push the
    record past the bound; events["reversal:" + id] keeps the full id either way.
    """
    side = reservation.get("s")
    p = {"v": 2, "s": side if side in ("y", "n") else None, "d": order_id}
    if len(json.dumps(p, separators=(",", ":"))) > PROVENANCE_MAX_BYTES:
        p["d"] = "#" + hashlib.sha256(order_id.encode()).hexdigest()[:16]
    return p


def reversal_parent(state, client_id):
    """The physical order a netted ticket came from, by the reversal event old and new code write."""
    for event_id, value in state.get("events", {}).items():
        if (event_id.startswith("reversal:") and isinstance(value, list) and len(value) == 4
                and value[1] == client_id):
            return event_id[len("reversal:"):]
    return None


def _ticker_inputs(mode, admission, unknown_minute, widened, positions, ticker):
    """Validate the ticker-mode inputs; legacy mode refuses any of them when non-empty."""
    if mode not in ("legacy", "ticker"):
        raise AccountRiskRefused("invalid risk classification mode", code="input_invalid")
    if mode == "legacy":
        if admission or unknown_minute or widened:
            raise AccountRiskRefused("ticker-mode inputs refused in legacy mode", code="input_invalid")
        return {}, frozenset()
    if type(widened) is not bool:
        raise AccountRiskRefused("invalid widened flag", code="input_invalid")
    unknown = frozenset(unknown_minute or ())
    if any(not isinstance(market, str) or not market for market in unknown):
        raise AccountRiskRefused("invalid unknown-minute ticker", code="input_invalid")
    if unknown & set(positions):
        raise AccountRiskRefused("unknown-minute ticker also has a position minute", code="input_invalid")
    checked = {}
    for key, cost in (admission or {}).items():
        if not isinstance(key, tuple) or len(key) != 2 or not isinstance(key[0], str) or not key[0]:
            raise AccountRiskRefused("invalid admission key", code="input_invalid")
        market, minute = key
        if minute is None:
            if market not in unknown:
                raise AccountRiskRefused("invalid admission key", code="input_invalid")
        elif type(minute) is not int or minute < 0 or market in unknown:
            raise AccountRiskRefused("invalid admission key", code="input_invalid")
        checked[key] = _cents(cost)
    if ticker in unknown:
        raise AccountRiskRefused("market settlement time unavailable", code="settlement_minute_unavailable")
    return checked, unknown


class AccountRiskLedger:
    def __init__(self, path=None, *, account_id="replay"):
        if not isinstance(account_id, str) or not account_id:
            raise AccountRiskRefused("account identity required", code="input_invalid")
        self.account_id = account_id
        self.path = Path(path) if path is not None else None
        self._memory = None
        if self.path is None:
            self._memory = sqlite3.connect(":memory:", isolation_level=None)

    @contextmanager
    def _transaction(self):
        # A nested _transaction on this instance in this thread refuses input_invalid before touching
        # the connection (whose ROLLBACK would end the outer one) and marks the outer one so it rolls
        # back too, even when the nested refusal is swallowed.
        active = self.__dict__.setdefault("_transaction_threads", {})
        thread = threading.get_ident()
        if thread in active:
            active[thread] = True
            raise AccountRiskRefused("risk ledger transaction re-entered", code="input_invalid")
        active[thread] = False
        try:
            with self._transaction_body(active, thread) as state:
                yield state
        finally:
            del active[thread]

    @contextmanager
    def _transaction_body(self, active, thread):
        if self.path is not None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        db = self._memory or sqlite3.connect(str(self.path), timeout=2, isolation_level=None)
        stats = self.__dict__.setdefault("tx_stats", {
            "n": 0, "elided": 0, "wait_ns": 0, "hold_ns": 0, "max_wait_ns": 0})
        acquired_ns = None
        try:
            db.execute("PRAGMA synchronous=FULL")
            stats["n"] += 1
            started_ns = _perf_counter_ns()
            try:
                db.execute("BEGIN IMMEDIATE")
            finally:
                waited_ns = _perf_counter_ns()
                wait_ns = waited_ns - started_ns
                stats["wait_ns"] += wait_ns
                stats["max_wait_ns"] = max(stats["max_wait_ns"], wait_ns)
            acquired_ns = waited_ns
            if db.execute("SELECT 1 FROM sqlite_master WHERE name='risk_format'").fetchone():
                raise AccountRiskRefused("body writer refuses rows ledger", code="ledger_format_rows")
            db.execute("CREATE TABLE IF NOT EXISTS account_risk (id INTEGER PRIMARY KEY, body TEXT NOT NULL)")
            row = db.execute("SELECT body FROM account_risk WHERE id=1").fetchone()
            self._body_bytes = len(row[0]) if row else 0
            state = json.loads(row[0]) if row else self._empty_state()
            if state.get("version") not in (1, 2) or state.get("account_id") != self.account_id:
                raise AccountRiskRefused("risk ledger identity/schema mismatch", code="ledger_identity")
            stored_revision = state["revision"]
            if type(stored_revision) is not int:
                raise AccountRiskRefused("risk ledger revision not an integer", code="ledger_corrupt")
            # No marker: one membership test, no event walk and no extra I/O on the hot path.
            if _RESTORE_MARKER in state:
                _audit_restore(state)
            archived = None
            if state["version"] == 2:
                archived = _ArchiveEntries(state["entries"], db, _archive_meta(state))
                state["entries"] = archived
            yield state
            if active[thread]:
                raise AccountRiskRefused("risk ledger transaction re-entered", code="input_invalid")
            payload = json.dumps(state, separators=(",", ":"), allow_nan=False)
            if archived is not None and (payload != row[0] or archived.changed()):
                archived.flush()
                rows, _ = _archive_prepare(state)
                _archive_insert(db, rows)
                # An archive-only edit invalidates observations just like a hot-body edit.
                if state["revision"] <= stored_revision:
                    state["revision"] = stored_revision + 1
                payload = _archive_json(state)
            if archived is not None:
                # Snapshot views include this transaction's imports, promotions and maintenance atomically.
                for hot, ticker, result in archived.views:
                    result.update(json.loads(_archive_json(_archive_view(db, state, hot=hot, ticker=ticker))))
            if row is not None and payload == row[0]:
                db.execute("ROLLBACK")
                stats["elided"] += 1
            else:
                # Every changed body advances revision so expected_revision rejects stale observations.
                if type(state["revision"]) is not int:
                    raise AccountRiskRefused("risk ledger revision not an integer", code="ledger_corrupt")
                if row is not None and state["revision"] <= stored_revision:
                    state["revision"] = stored_revision + 1
                    payload = json.dumps(state, separators=(",", ":"), allow_nan=False)
                db.execute("INSERT OR REPLACE INTO account_risk VALUES (1, ?)", (payload,))
                db.execute("COMMIT")
            self._body_bytes = len(payload)
        except (sqlite3.Error, ValueError, KeyError, TypeError) as exc:
            if db.in_transaction:
                db.execute("ROLLBACK")
            raise AccountRiskRefused("risk ledger unavailable or corrupt", code="ledger_corrupt") from exc
        except BaseException:
            if db.in_transaction:
                db.execute("ROLLBACK")
            raise
        finally:
            if acquired_ns is not None:
                stats["hold_ns"] += _perf_counter_ns() - acquired_ns
            if self._memory is None:
                db.close()

    def _empty_state(self):
        return {
            "version": 1, "account_id": self.account_id, "revision": 0,
            "day": None, "day_open_cents": 0, "high_water_cents": 0,
            "equity_cents": 0, "entries": {}, "events": {}, "fault": None}

    def snapshot(self, *, hot=False, ticker=None):
        with self._transaction() as state:
            if state["version"] == 2:
                entries = state["entries"]
                # Fill the detached export after maintenance, before this transaction commits.
                exported = {}
                entries.views.append((hot, ticker, exported))
            else:
                exported = None
        if exported is not None:
            return exported
        return json.loads(json.dumps(state))

    def _decode(self, body):
        """Parse one read-only body with the same identity check the writer applies."""
        if body is None:
            return self._empty_state()
        try:
            state = json.loads(body)
        except ValueError as exc:
            raise AccountRiskRefused("risk ledger unavailable or corrupt", code="ledger_corrupt") from exc
        if not isinstance(state, dict) or state.get("version") not in (1, 2) or state.get("account_id") != self.account_id:
            raise AccountRiskRefused("risk ledger identity/schema mismatch", code="ledger_identity")
        return state

    def read_snapshot(self, *, hot=False, ticker=None):
        """Read-only snapshot: mode=ro, deferred, never mkdir/CREATE/write, so no fsync.

        None when the file is missing. A hot journal after a writer crash surfaces as
        sqlite3.OperationalError and falls back ONCE to snapshot(), which recovers it.
        """
        if self.path is None:
            return self.snapshot(hot=True, ticker=ticker) if hot else self.snapshot()
        if not self.path.exists():
            return None
        try:
            body = _read_snapshot_body_ro(self.path, hot=hot, ticker=ticker)
        except sqlite3.OperationalError:
            return self.snapshot(hot=True, ticker=ticker) if hot else self.snapshot()
        except sqlite3.Error as exc:
            raise AccountRiskRefused("risk ledger unavailable or corrupt", code="ledger_corrupt") from exc
        return self._decode(body)

    @staticmethod
    def _basis(state, equity, now_ns, *, client_id=None, cash_cents=None, open_cost_cents=None, record=True):
        """The non-widened basis write (reserve, release). O(1) unless the observation jumps.

        Refuses venue_read_skew, writing nothing, an equity above bound * 3/2 where bound is the
        largest of the stored day open, equity and high water (EQUITY_JUMP_*): the same bound on
        the same UTC day, where transfer() has already moved the day open and high water by any
        deposit, and on a day rollover, where the transfers dated the new day (which moved no
        base) are added to it. That read is a shallow copy and runs only past the plain bound.
        Exempt: the first basis write (nothing observed yet, bound 0) and a body no writer has
        committed (revision 0), which take this observation as their baseline. A raise of the
        high water on an opened basis records high_water_raised when record is set (reserve()
        clears it for a provenance-free legacy call, which writes the frozen writer's body).
        """
        day = _utc_day(now_ns)
        if state["day"] is not None and day < state["day"]:
            raise AccountRiskRefused("risk clock moved backwards", code="clock_backwards")
        rollover = day != state["day"]
        bound = max(state["day_open_cents"], state["equity_cents"], state["high_water_cents"])
        opened = bound > 0 and state["revision"] != 0
        if opened and equity > bound * EQUITY_JUMP_NUM // EQUITY_JUMP_DEN:
            if rollover:
                bound += max(0, _day_transfers(dict(state), now_ns // _DAY_NS, -1)[0])
            if equity > bound * EQUITY_JUMP_NUM // EQUITY_JUMP_DEN:
                raise AccountRiskRefused(f"equity observation implausible: {equity}c vs bound {bound}c",
                                         code="venue_read_skew")
        if rollover:
            state["day"], state["day_open_cents"] = day, equity
        high = state["high_water_cents"]
        if equity > high and opened and record and type(now_ns) is int and 0 <= now_ns <= _NS_MAX:
            state[_RAISED] = {
                "at_ns": now_ns, "from_cents": high, "to_cents": equity, "equity_cents": equity,
                "client_id": client_id[:_RAISED_TEXT_MAX] if isinstance(client_id, str) else None,
                "cash_cents": cash_cents, "open_cost_cents": open_cost_cents}
        state["high_water_cents"] = max(high, equity)
        state["equity_cents"] = equity

    @staticmethod
    def _scratch_basis(state, equity, now_ns):
        """Widened observations persist no basis and never open a day (v3.1 A1).

        The persisted day must already be today, and only non-widened writers (or the
        day-start write) ever set it; otherwise the entry is refused day_baseline_unknown.
        An equity above the same-day plausibility bound of _basis (EQUITY_JUMP_*; transfer()
        has already folded today's transfers into the day open and high water) is refused
        venue_read_skew, so a spike never reads a zero drawdown against itself or sizes an
        entry. Exempt as in _basis: bound 0 or revision 0. Returns (day_open, high_water) for
        this one decision.
        """
        day = _utc_day(now_ns)
        if state["day"] is not None and day < state["day"]:
            raise AccountRiskRefused("risk clock moved backwards", code="clock_backwards")
        if day != state["day"]:
            raise AccountRiskRefused("account day baseline unknown for a widened observation",
                                     code="day_baseline_unknown")
        bound = max(state["day_open_cents"], state["equity_cents"], state["high_water_cents"])
        if bound > 0 and state["revision"] != 0 and equity > bound * EQUITY_JUMP_NUM // EQUITY_JUMP_DEN:
            raise AccountRiskRefused(f"equity observation implausible: {equity}c vs bound {bound}c",
                                     code="venue_read_skew")
        return state["day_open_cents"], max(state["high_water_cents"], equity)

    @staticmethod
    def _marked_basis(state, observed_ns, now_ns, widened, marked_cents):
        """(today's marked day start or None, fallback reason or None). At most two field writes.

        The marked term may only tighten a correct reading of the day. It is used only when
        this observation's venue timestamp falls on today's UTC day and no transfer recorded
        for today postdates it; otherwise the paid term decides alone and the reason is
        returned: marked_stale (the observation, or the recorded start, names another UTC day)
        or marked_unreconciled (a recorded cash movement is not yet in this observation).
        Write-once per UTC day: the first non-widened mark on today's UTC day (so on or after
        00:00Z) is persisted with that timestamp, restated in the current cash basis by every
        transfer recorded for today that it predates (transfer() moves a start already
        installed the same way). A widened observation persists no basis (v3.1 A1) and reads
        an existing start only. A record from a later UTC day is never overwritten.
        Days are integer ns // _DAY_NS. O(1) plus O(events appended since the stamp by a writer
        that does not maintain it) on every reservation after the install: _catch_up applies
        those events by transfer()'s rule, then the day's transfers are read from the one stored
        record (_MARKED_TRANSFERS, written with the start and moved by transfer()), trusted only
        while the index stamp is current. The install, and the one rebuild of a record a
        pre-fix-c start lacks, read today's k transfers by key through the transfer index
        (_day_transfers: O(k) lookups, never a walk of the events; one full pass per ledger
        lifetime builds the index).
        """
        day = now_ns // _DAY_NS
        if observed_ns // _DAY_NS != day:
            return None, "marked_stale"
        # A function of the events, never of this observation, so a widened one runs it too (v3.1 A1).
        _catch_up(state)
        opened = _marked_day_open(state, day)
        if opened is None:
            if widened:
                return None, None
            recorded = state.get(_MARKED_NS)
            if type(recorded) is int and 0 <= recorded <= _NS_MAX and recorded // _DAY_NS > day:
                return None, "marked_stale"
            total, latest, pending = _day_transfers(state, day, observed_ns)
            opened = min(2**53 - 1, max(0, marked_cents + pending))
            state[_MARKED_CENTS], state[_MARKED_NS] = opened, observed_ns
            state[_MARKED_TRANSFERS] = [total, latest]
        else:
            record = _marked_transfers(state)
            index = _index_shaped(state)
            if record is None or index is None or index[2] != len(state["events"]):
                # A start a pre-fix-c writer installed carries no record, and a record is trusted
                # only with a current index: the first reservation rebuilds it and stores it with
                # the start in this transaction, so every later one reads it. The record (and the
                # index) are a function of the events and the start's day, never of this
                # observation, so a widened observation stores them too; it still persists no
                # basis (v3.1 A1).
                record = list(_day_transfers(state, day, observed_ns)[:2])
                state[_MARKED_TRANSFERS] = record
            latest = record[1]
        if latest > observed_ns:
            # A transfer recorded for today postdates this observation: not yet in its cash.
            return None, "marked_unreconciled"
        return opened, None

    def reserve(self, client_id, ticker, settlement_minute, requested_cents, *,
                cash_cents, open_cost_cents, policy=DEFAULT_POLICY, now_ns=None,
                positions=None, expected_revision=None, resize=False, brake_trim=False,
                side=None, count=None, price_cents=None, prepared=False, holder=None,
                journal_digest=None, authority_generation=None,
                mode="legacy", admission=None, unknown_minute=None, widened=False,
                marked_cents=None, marked_ns=None, headroom=None, retried=None,
                probe=None, account_policy=None, drawdown_policy=None):
        """Reserve before send. Live callers use a fresh, revision-bound venue read.

        positions maps ticker to (settlement minute, fee-inclusive open cost).
        max(venue, durable filled cost) avoids counting a known fill twice. Pending
        sends are additional, even if a venue read may already include their fill.
        Callers can opt into a smaller reservation with resize=True.

        Owner probes with a usable account_policy and no headroom use drawdown_policy's
        numeric fractions in [0, 1], capped at the probe maxima then clamped by hard_maxima(),
        for new admission; brake room still uses the caller policy. None or malformed policies
        retain caller thresholds.
        Only DRAWDOWN_POLICY_UNAVAILABLE refuses drawdown_stop for failed live discovery.
        Headroom and legacy paper calls retain caller terms.

        side and count add the compact provenance record p to the entry (both modes).
        mode="ticker" takes classify_tickers' admission, unknown_minute and widened;
        admission raises exposure only (never equity or the basis), and a widened
        observation persists no basis. Legacy mode refuses those inputs and decides
        as blob 4bb2f23 did apart from the probe budget and incumbent slice below. Explicit
        probes without a usable account_policy refuse. Legacy probes without an account
        fraction retain the original arithmetic. Every outcome is summarized in self.last_reserve.

        probe and account_policy (RC2, v3) carve a probe slice out of each daily-loss term
        (paid and marked): reserve = min(PROBE_LOSS_RESERVE_CENTS, floor(PROBE_LOSS_RESERVE_SHARE
        * floor(term base * f))), where the term base is day_open (paid) or the marked start and
        f is account_policy's daily_loss_fraction clamped by hard_maxima(): the ACCOUNT base
        policy (the incumbent book's), never a probe engine's own. account_policy None, or a
        malformed one, makes the reserve 0 and last_reserve["probe_reserve_reason"] names why.
        With probe=True this instead refuses daily_loss with probe_ceiling_bound: an unknown
        ceiling never means no ceiling. Incumbents and probe=None callers keep today's behaviour.
        probe True or False is the caller's classification; None derives it from the id
        (PROBE_CLIENT_PREFIX). A probe reservation persists "pr": 1 on its entry (additive; old
        readers ignore it). probe_at_risk sums the not-closed probe entries' cost and
        probe_realized_loss_today the net "pl" of entries whose "pd" is this reservation's UTC
        day, floored at 0 after summing losses and gains (release() records them), in the one
        pass over the entries. An INCUMBENT term subtracts
        max(0, reserve - probe_at_risk - probe_realized_loss_today): the part of the slice
        probes may still use. With a usable fraction and no headroom, a PROBE's paid term is
        reserve - probe_at_risk - probe_realized_loss_today, even when reserve is zero; its
        marked term is ignored. Headroom-bearing probes retain min(today's term, that ceiling)
        for both paid and marked terms, with today's term unchanged when its reserve is zero.
        A probe's
        realized loss also reduces the shared day_loss like any other loss. Refusal codes are
        unchanged (daily_loss). Entries without "pr" (legacy imports, pre-RC2) count as incumbent
        unless their id starts PROBE_CLIENT_PREFIX, which only enlarges the protected slice.
        last_reserve carries probe, probe_reserve_cents (the paid term's subtraction for an
        incumbent, 0 for a probe), probe_reserve_marked_cents, probe_at_risk_cents,
        probe_realized_loss_today_cents, probe_reserve_bound (an incumbent refused or trimmed
        that the same request with the slice 0 admits in full) and probe_ceiling_bound (the
        own-budget term is selected, or a legacy/headroom ceiling alone trims or refuses).
        Probe calls also carry paid_room_cents (diagnostic account room) and probe_budget_cents.

        marked_cents and marked_ns (X2b, D5a) are this observation's marked portfolio
        (marked_portfolio_cents: cash plus venue marks) and its venue timestamp. The first
        non-widened one on or after 00:00Z is persisted write-once as the day's marked start,
        and the account breaker term becomes the minimum of the paid daily-loss term and the
        marked one (net loss since the marked start against the same fraction of it). No
        mark (marked_cents None, with or without marked_ns), no marked start for today, a mark
        from another UTC day, or a mark that predates a transfer recorded for today keeps the
        paid term alone: never a refusal. last_reserve["marked_reason"] names the fallback
        (marked_missing, marked_stale, marked_unreconciled); marked_stale and
        marked_unreconciled are also journaled once per UTC day as events[reason + ":" + day].

        headroom (T2-v4 R2) is a (market_cents, window_cents, total_cents) tuple of non-negative
        ints (bool refused); anything else, a callable included, refuses input_invalid before the
        transaction opens, so no caller code ever runs inside it. The caller (R3, the t2cal host
        gate) computes the tuple from read_snapshot() outside the transaction and must pass
        expected_revision=<that snapshot's revision>: headroom with expected_revision None refuses
        input_invalid, and a stale revision refuses revision_conflict and writes nothing.
        Contract: a headroom reservation admits only when a plain caller could still
        reserve the full stated capacity afterwards on the same ticker and settlement minute. The
        market term adds market_cents to the ticker's cost, the window term adds window_cents to the
        minute's cost, the daily-loss terms (paid and marked) add total_cents to the amount at risk,
        the cash term subtracts total_cents, and an active drawdown brake reserves twice the market
        and window headroom (the brake halves a later caller's room). Room below the requested
        amount refuses whole with t2cal_headroom and writes nothing: never a trim, whatever resize
        says. headroom=None
        leaves the transaction, its result and the ledger body exactly as without the argument.

        retried (RC1) changes only the refusal journal, never the decision: None journals every
        refusal as before. False marks a first attempt its caller retries once on revision_conflict:
        that conflict's row is deferred onto the exception (journal_deferred_refusal writes it if
        the retry does not run), so a conflict the retry recovers is never journaled as a refusal.
        True marks that retry: its revision_conflict row carries "retried": true. Every other
        refusal code is journaled exactly as with None.
        """
        stats = {"code": None, "binding": None, "admission_consumption_cents": 0,
                 "widened": widened is True, "entries": None, "legacy_entries": None,
                 "body_bytes": None, "revision": None, "marked_room_cents": None,
                 "marked_loss_cents": None, "marked_reason": None,
                 "probe": None, "probe_reserve_cents": 0, "probe_reserve_marked_cents": 0,
                 "probe_at_risk_cents": None, "probe_realized_loss_today_cents": None,
                 "probe_reserve_bound": False, "probe_ceiling_bound": False,
                 "probe_reserve_reason": None}
        try:
            admitted = self._reserve(stats, client_id, ticker, settlement_minute, requested_cents,
                                     cash_cents=cash_cents, open_cost_cents=open_cost_cents,
                                     policy=policy, now_ns=now_ns, positions=positions,
                                     expected_revision=expected_revision, resize=resize, brake_trim=brake_trim,
                                     provenance=(side, count, price_cents, holder, journal_digest,
                                                 authority_generation),
                                     prepared=prepared, mode=mode, admission=admission,
                                     unknown_minute=unknown_minute, widened=widened,
                                     marked=(marked_cents, marked_ns), headroom=headroom,
                                     probe=probe, account_policy=account_policy, drawdown_policy=drawdown_policy)
        except AccountRiskRefused as exc:
            stats["code"] = exc.code
            if exc.code == "revision_conflict" and retried is False:
                exc.journal_deferred = (self, client_id, ticker, requested_cents, stats["revision"])
            else:
                journal_refusal(self, exc.code, client_id, ticker, requested_cents, revision=stats["revision"],
                                retried=True if exc.code == "revision_conflict" and retried is True
                                else None, detail=exc.detail)  # never raises (C13 fix g)
            raise
        else:
            # C13 fix j: the positive record on the real path; after this writer's first reserve of each
            # UTC day the journal's fast path makes it a no-syscall no-op. Never raises, never changes the result.
            journal_heartbeat(self, stats["revision"])
            return admitted
        finally:
            stats["body_bytes"] = getattr(self, "_body_bytes", None)
            self.last_reserve = stats

    def _reserve(self, stats, client_id, ticker, settlement_minute, requested_cents, *,
                 cash_cents, open_cost_cents, policy, now_ns, positions, expected_revision,
                 resize, brake_trim, provenance, prepared, mode, admission, unknown_minute, widened, marked,
                 headroom=None, probe=None, account_policy=None, drawdown_policy=None):
        for value in (requested_cents, cash_cents, open_cost_cents):
            _cents(value)
        headroom = _headroom_inputs(headroom, expected_revision)
        if marked[0] is None and marked[1] is not None:
            stats["marked_reason"] = "marked_missing"
        marked = _marked_inputs(*marked)
        if not requested_cents or not isinstance(client_id, str) or not client_id:
            raise AccountRiskRefused("invalid risk reservation", code="input_invalid")
        if probe is not None and type(probe) is not bool:
            raise AccountRiskRefused("invalid probe classification", code="input_invalid")
        # RC2: the caller's classification, else the id's prefix (every pre-RC2 caller).
        is_probe = client_id.startswith(PROBE_CLIENT_PREFIX) if probe is None else probe
        stats["probe"] = is_probe
        fraction, stats["probe_reserve_reason"] = _reserve_fraction(account_policy)
        if probe is True and fraction is None:
            stats["binding"] = "daily loss"
            stats["probe_ceiling_bound"] = True
            raise AccountRiskRefused("probe ceiling unavailable: " + stats["probe_reserve_reason"],
                                     code="daily_loss", detail={
                                         "binding_term": "probe_ceiling_unavailable",
                                         "binding_request_cents": requested_cents})
        if not isinstance(ticker, str) or not ticker or type(settlement_minute) is not int or settlement_minute < 0:
            raise AccountRiskRefused("market settlement minute required", code="input_invalid")
        now_ns = time.time_ns() if now_ns is None else now_ns
        positions = positions or {}
        provenance = _provenance_inputs(*provenance)
        admission, unknown = _ticker_inputs(mode, admission, unknown_minute, widened, positions, ticker)
        with self._transaction() as state:
            if expected_revision is not None and state["revision"] != expected_revision:
                raise AccountRiskRefused("account changed during risk read", code="revision_conflict")
            if client_id in state["entries"]:
                raise AccountRiskRefused("risk client id already reserved", code="duplicate_client_id")
            if state["fault"]:
                raise AccountRiskRefused(state["fault"], code="ledger_fault")
            equity = cash_cents + open_cost_cents
            if widened:
                day_open, high = self._scratch_basis(state, equity, now_ns)
            else:
                self._basis(state, equity, now_ns, client_id=client_id, cash_cents=cash_cents,
                            open_cost_cents=open_cost_cents, record=provenance is not None or mode != "legacy")
                day_open, high = state["day_open_cents"], state["high_water_cents"]
            marked_open = None
            if marked is not None:
                marked_open, reason = self._marked_basis(state, marked[1], now_ns, widened, marked[0])
                if reason is not None:
                    stats["marked_reason"] = reason
                    # Journal the fallback once per UTC day: the first observation's instants.
                    journal = reason + ":" + _utc_day(now_ns)
                    if journal not in state["events"]:
                        _append_event(state, journal, [marked[1], now_ns])
            filled, pending = {}, {}
            legacy_entries = state.get(_ARCHIVE, {}).get("legacy_count", 0)
            # RC2: probe exposure and today's probe realized loss, in this one pass (no second walk).
            today = _utc_day(now_ns)
            probe_at_risk = probe_realized = 0
            for cid, entry in state["entries"].items():
                if not _v2(entry):
                    legacy_entries += 1
                if entry.get("pd") == today:
                    loss = entry.get("pl")
                    if type(loss) is int and -_CENTS_MAX <= loss <= _CENTS_MAX:
                        probe_realized += loss
                if entry["state"] == "closed":
                    continue
                tag = entry.get("pr")  # _probe_entry, inlined on the hot path
                if (tag == 1) if tag is not None else cid.startswith(PROBE_CLIENT_PREFIX):
                    probe_at_risk += entry["cost_cents"]
                target = pending if entry["state"] == "reserved" else filled
                if entry["ticker"] in unknown:
                    # In memory only: an unknown minute is never written back (old readers need ints).
                    key = (entry["ticker"], None)
                else:
                    minute = positions.get(entry["ticker"], (entry["minute"], 0))[0]
                    if type(minute) is not int or minute < 0:
                        raise AccountRiskRefused("open exposure settlement minute requires reconciliation",
                                                 code="settlement_minute_reconcile")
                    if entry["minute"] >= 0 and minute != entry["minute"]:
                        raise AccountRiskRefused("position settlement minute changed",
                                                 code="settlement_minute_reconcile")
                    entry["minute"] = minute
                    key = (entry["ticker"], minute)
                target[key] = target.get(key, 0) + entry["cost_cents"]
            probe_realized = max(0, probe_realized)
            for market, (minute, cost) in positions.items():
                _cents(cost)
                if type(minute) is not int or minute < 0:
                    raise AccountRiskRefused("position settlement minute required", code="input_invalid")
                key = (market, minute)
                filled[key] = max(filled.get(key, 0), cost)
            exposure = dict(filled)
            consumption = 0
            for key, cost in admission.items():
                # Admission is a charge only: max(ledger, venue cost, admission), never valuation.
                if cost > exposure.get(key, 0):
                    consumption += cost - exposure.get(key, 0)
                    exposure[key] = cost
            for key, cost in pending.items():
                exposure[key] = exposure.get(key, 0) + cost
            market_cost = sum(cost for (market, _), cost in exposure.items() if market == ticker)
            # An unknown-minute key (minute None) counts toward every window.
            window_cost = sum(cost for (_, minute), cost in exposure.items()
                              if minute == settlement_minute or minute is None)
            # T2-v4 R2: the parent's stated capacity, bound to this revision above; zeros when unset.
            head_market, head_window, head_total = headroom if headroom is not None else (0, 0, 0)
            cluster_room = entry_risk_room(equity, market_cost + head_market, window_cost + head_window, policy)
            day_loss = max(0, day_open - equity)
            at_risk = sum(exposure.values())
            loss_fraction = min(policy.daily_loss_fraction, hard_maxima().get("daily_loss_fraction", 1.0))
            paid_room = int(day_open * loss_fraction) - day_loss - at_risk - head_total
            cash_room = cash_cents - sum(pending.values()) - policy.cash_floor_cents - head_total
            marked_room = None
            if marked_open is not None:
                # D5a: net loss since the marked day start (realized plus open mark), against the
                # same fraction of that start; open and pending exposure stay at risk as in the
                # paid term.
                marked_loss = max(0, marked_open - marked[0])
                marked_room = int(marked_open * loss_fraction) - marked_loss - at_risk - head_total
                stats["marked_room_cents"], stats["marked_loss_cents"] = marked_room, marked_loss
            drawdown_fractions = (policy.drawdown_brake_fraction, policy.drawdown_stop_fraction)
            if is_probe and fraction is not None and headroom is None:
                if drawdown_policy is DRAWDOWN_POLICY_UNAVAILABLE:
                    stats["binding"] = "drawdown stop"
                    raise AccountRiskRefused("probe drawdown policy unavailable", code="drawdown_stop",
                                             detail={"binding_term": "drawdown_policy_unavailable",
                                                     "binding_request_cents": requested_cents})
                adopted_fractions = _drawdown_fractions(drawdown_policy)
                if adopted_fractions is not None:
                    drawdown_fractions = (min(adopted_fractions[0], PROBE_DRAWDOWN_BRAKE_MAX),
                                          min(adopted_fractions[1], PROBE_DRAWDOWN_STOP_MAX))
            brake_fraction = min(drawdown_fractions[0], hard_maxima().get("drawdown_brake_fraction", 1.0))
            stop_fraction = min(drawdown_fractions[1], hard_maxima().get("drawdown_stop_fraction", 1.0))
            if is_probe:
                stats["probe_drawdown_fractions"] = [brake_fraction, stop_fraction]
            brake_room = None
            if high and (high - equity) / high >= brake_fraction:
                brake_room = entry_risk_room(equity, market_cost, window_cost, policy) // 2
                if headroom is not None:
                    # A later plain caller's brake room is half of what this reservation leaves, so it
                    # keeps its full capacity only when twice the market and window headroom survive.
                    brake_room = min(brake_room, entry_risk_room(
                        equity, market_cost + 2 * head_market, window_cost + 2 * head_window, policy))
            # Observed drawdown stops new admission; it does not cap existing exposure's later losses.
            stop = high and (high - equity) / high >= stop_fraction
            # RC2: each daily-loss term's probe slice from its own base and the account fraction;
            # integer cents and Decimal only (_probe_reserve), never float.
            paid_reserve = _probe_reserve(day_open, fraction)
            marked_reserve = _probe_reserve(marked_open, fraction) if marked_room is not None else 0
            probe_used = probe_at_risk + probe_realized
            paid_cut = marked_cut = 0
            if is_probe:
                # Legacy/headroom ceiling arithmetic: never above today's term, and a term
                # with no reserve stays today's. The own-budget path below replaces these terms.
                if paid_reserve:
                    paid_cut = max(0, paid_room - (paid_reserve - probe_used))
                if marked_reserve:
                    marked_cut = max(0, marked_room - (marked_reserve - probe_used))
            else:
                # An incumbent may not use the part of the slice probes can still use; a probe's
                # own exposure already sits in at_risk, so it is never counted twice.
                paid_cut = max(0, paid_reserve - probe_used)
                marked_cut = max(0, marked_reserve - probe_used)
            own_budget = is_probe and fraction is not None and headroom is None
            # At every probe admission U + admitted_cost <= S: U includes open and pending
            # probe exposure (including yesterday's) plus max(0, net realized loss today).
            # A shrinking base with S < U refuses further probes; nothing is force-closed.
            # Incumbents retain the account term less the unused slice, so total daily loss
            # is bounded by the account term as seen by incumbents plus S.
            # restore()/legacy import retain supplied tags: untagged non-lp- entries count
            # as incumbents. Fresh reservations, retry/reversal legs and probe adopts are tagged.
            paid_term = paid_reserve - probe_used if own_budget else paid_room - paid_cut
            marked_term = None if own_budget or marked_room is None else marked_room - marked_cut
            room, binding = _binding_room(cluster_room, paid_term, cash_room,
                                          marked_term,
                                          brake_room, stop)
            # Bound only when the slice alone refuses or trims: the same request with no cut admits in full.
            cut_bound = bool(paid_cut or marked_cut) and room < requested_cents and requested_cents <= (
                _binding_room(cluster_room, paid_room, cash_room, marked_room, brake_room, stop)[0])
            stats.update(probe_reserve_cents=0 if is_probe else paid_cut,
                         probe_reserve_marked_cents=0 if is_probe else marked_cut,
                         probe_at_risk_cents=probe_at_risk, probe_realized_loss_today_cents=probe_realized,
                         probe_reserve_bound=cut_bound and not is_probe,
                         probe_ceiling_bound=(binding == "daily loss" if own_budget else cut_bound and is_probe))
            if is_probe:
                stats.update(paid_room_cents=paid_room, probe_budget_cents=paid_reserve)
            if binding == "per-order/cluster":
                # entry_risk_room = max(0, min(a, b)); the tie goes to the ticker cap.
                market_cap, window_cap = entry_risk_caps(equity, policy)
                code = "ticker_cap" if market_cap - market_cost <= window_cap - window_cost else "window"
            else:
                code = _BINDING_CODES[binding]
            allowed = max(0, min(requested_cents, room))
            if headroom is not None and allowed < requested_cents:
                # Whole or nothing, whatever resize says; raised inside the transaction so it writes nothing.
                stats.update(binding=binding, admission_consumption_cents=consumption,
                             entries=len(state["entries"]) + state.get(_ARCHIVE, {}).get("count", 0), legacy_entries=legacy_entries,
                             revision=state["revision"])
                raise AccountRiskRefused(
                    "t2cal headroom: " + binding + f" room={room}c requested={requested_cents}c"
                    f" headroom={head_market},{head_window},{head_total}c", code="t2cal_headroom")
            refused = allowed < requested_cents and not (resize or (brake_trim and binding == "drawdown brake"))
            if refused:
                allowed = 0
            if allowed:
                entry = {
                    "ticker": ticker, "minute": settlement_minute, "cost_cents": allowed,
                    "reserved_cents": allowed, "state": "reserved", "equity_cents": equity}
                if provenance is not None:
                    entry["p"] = _provenance(
                        provenance, admitted_count(provenance[1], requested_cents, allowed, prepared=prepared),
                        now_ns)
                else:
                    legacy_entries += 1
                if is_probe:
                    entry["pr"] = 1  # RC2: additive; old readers check only the core fields
                elif client_id.startswith(PROBE_CLIENT_PREFIX):
                    entry["pr"] = 0  # an explicit incumbent classification outranks the prefix
                state["entries"][client_id] = entry
            state["revision"] += 1
            stats.update(binding=binding, admission_consumption_cents=consumption,
                         entries=len(state["entries"]) + state.get(_ARCHIVE, {}).get("count", 0), legacy_entries=legacy_entries,
                         revision=state["revision"])
        if refused:
            detail = None
            if code in ("daily_loss", "ticker_cap", "drawdown_brake", "drawdown_stop"):
                term = code
                if binding in ("daily loss", "marked daily loss"):
                    cut = paid_cut if binding == "daily loss" else marked_cut
                    term = ("probe_ceiling" if is_probe else "probe_slice") if cut > 0 else (
                        "account_paid" if binding == "daily loss" else "account_marked")
                    if own_budget and binding == "daily loss":
                        term = "probe_ceiling"
                detail = {"binding_term": term, "binding_room_cents": room,
                          "binding_request_cents": requested_cents}
            raise AccountRiskRefused("account market/window/loss risk cap: " + binding +
                                     f" room={room}c requested={requested_cents}c", code=code,
                                     detail=detail)
        return allowed

    def resolve(self, client_id, cost_cents, *, count=None, exact=True):
        """A terminal IOC reply replaces the reserve with its actual filled cost."""
        _cents(cost_cents)
        with self._transaction() as state:
            entry = state["entries"][client_id]
            if entry["state"] != "reserved":
                if entry["cost_cents"] == cost_cents:
                    return
                raise AccountRiskRefused("conflicting risk resolution", code="invariant")
            if cost_cents > entry["reserved_cents"]:
                state["fault"] = "venue fill exceeded risk reservation"
            entry["cost_cents"] = cost_cents
            entry["state"] = "open" if cost_cents else "closed"
            entry["exact"] = bool(exact)
            if count is not None:
                quantity = Decimal(str(count))
                if not quantity.is_finite() or quantity < 0:
                    raise AccountRiskRefused("invalid risk quantity", code="input_invalid")
                entry["count"] = str(quantity)
            state["revision"] += 1

    def adopt(self, client_id, ticker, cost_cents, count, settlement_minute, *, probe=None):
        """Import an existing fill-basis ticket, never re-reserve or reopen an id."""
        _cents(cost_cents)
        quantity = Decimal(str(count))
        if not quantity.is_finite() or quantity <= 0:
            raise AccountRiskRefused("invalid adopted risk quantity", code="input_invalid")
        with self._transaction() as state:
            if client_id in state["entries"]:
                return
            state["entries"][client_id] = {
                "ticker": ticker, "minute": settlement_minute, "cost_cents": cost_cents,
                "reserved_cents": cost_cents, "state": "open", "count": str(quantity),
                "exact": True, "equity_cents": None}
            if probe is True:
                state["entries"][client_id]["pr"] = 1
            state["revision"] += 1

    def release(self, client_id, event_id, cost_cents, *, equity_cents=None, now_ns=None, count=None,
                probe_loss_cents=None):
        """Idempotent cost release after a confirmed exit/settlement, including losses.

        RC2 v3: releasing a probe entry's cost also records its realized loss ("pl" for the
        release's UTC day "pd", _record_probe_loss) with the same event, so a replay records
        nothing twice. probe_loss_cents is the caller's signed loss (negative for a net gain);
        None or malformed counts the whole released cost (conservative). Other entries ignore it.
        """
        _cents(cost_cents)
        with self._transaction() as state:
            event = [client_id, cost_cents]
            if event_id in state["events"]:
                if state["events"][event_id] != event:
                    raise AccountRiskRefused("conflicting risk release", code="invariant")
                return
            entry = state["entries"].get(client_id)
            if entry is None:
                return  # Pre-ledger holdings remain covered by the venue snapshot.
            if entry["state"] == "closed":
                _append_event(state, event_id, event)
                return  # Another confirmed settlement producer already released it.
            if entry["state"] == "reserved" or cost_cents > entry["cost_cents"]:
                raise AccountRiskRefused("unresolved risk release", code="invariant")
            entry["cost_cents"] -= cost_cents
            remaining = Decimal(0)
            if count is not None and "count" in entry:
                remaining = Decimal(entry["count"]) - Decimal(str(count))
                if not remaining.is_finite() or remaining < 0:
                    raise AccountRiskRefused("invalid risk quantity release", code="input_invalid")
                entry["count"] = str(remaining)
            # A known probe remainder still has P&L to release after cost rounds to zero.
            # Cost-only releases retain their full-settlement closure semantics.
            if not entry["cost_cents"] and not (_probe_entry(client_id, entry) and remaining > 0):
                entry["state"] = "closed"
                entry["count"] = "0"
            # A fractional exit can realize P&L even when its allocated cost rounds to 0c.
            if (cost_cents or type(probe_loss_cents) is int) and _probe_entry(client_id, entry):
                _record_probe_loss(entry, cost_cents, probe_loss_cents,
                                   time.time_ns() if now_ns is None else now_ns)
            _append_event(state, event_id, event)
            if equity_cents is not None:
                self._basis(state, _cents(equity_cents), time.time_ns() if now_ns is None else now_ns,
                            client_id=client_id)
            state["revision"] += 1

    def transfer(self, event_id, amount_cents, *, at_ns):
        """A deposit (amount > 0) or withdrawal (amount < 0): a cash movement, never P&L.

        Idempotent by event id (events["transfer:" + id] = [amount, at_ns]; a different
        replay refuses invariant). It moves today's day-start bases by its amount, floored
        at 0: the paid basis (and the high water with it) when its day is the movement's UTC
        day, and the marked start
        when that start was observed strictly before the movement (a start at or after it
        already contains it). A movement on a day whose basis has not opened moves nothing,
        because the day's first observation will include it; a marked start installed later
        from an observation that predates the movement is restated by it at install
        (_marked_basis), and until a mark postdates it the paid term decides. The caller
        posts a movement once it is seen after the paid basis opened; the paid basis carries
        no open instant. A movement on the marked start's UTC day also moves that day's
        transfer record (sum and latest instant) in O(1); days are integer ns // _DAY_NS.
        """
        if not isinstance(event_id, str) or not event_id:
            raise AccountRiskRefused("invalid transfer id", code="input_invalid")
        if type(amount_cents) is not int or abs(amount_cents) > 2**53 - 1:
            raise AccountRiskRefused("invalid transfer amount", code="input_invalid")
        if type(at_ns) is not int or not 0 <= at_ns <= _NS_MAX:
            raise AccountRiskRefused("invalid transfer time", code="input_invalid")
        with self._transaction() as state:
            # Transfers a non-maintaining writer appended first, so this one moves a complete index.
            _catch_up(state)
            key, event = _TRANSFER_PREFIX + event_id, [amount_cents, at_ns]
            if key in state["events"]:
                if state["events"][key] != event:
                    raise AccountRiskRefused("conflicting transfer", code="invariant")
                return
            if state["day"] == _utc_day(at_ns):
                state["day_open_cents"] = min(2**53 - 1, max(0, state["day_open_cents"] + amount_cents))
                # The drawdown basis moves with it, so a withdrawal never reads as a drawdown
                # and a deposit never hides one.
                state["high_water_cents"] = min(2**53 - 1, max(0, state["high_water_cents"] + amount_cents))
            # The marked start, its day record and the index move in O(1) (_apply_transfer); an
            # absent or malformed record or index stays so, and the next install or rebuild builds
            # it from the events, this one included.
            _apply_transfer(state, key, amount_cents, at_ns)
            _append_event(state, key, event)
            state["revision"] += 1

    def finish_reversal(self, order_id, old_id, new_id, old_cost, new_cost, *, old_count=0, new_count=0):
        """Transfer a confirmed physical IOC to its netted ticket identities."""
        _cents(old_cost)
        _cents(new_cost)
        with self._transaction() as state:
            event_id = "reversal:" + order_id
            event = [old_id, new_id, old_cost, new_cost]
            if event_id in state["events"]:
                if state["events"][event_id] != event:
                    raise AccountRiskRefused("conflicting reversal risk split", code="invariant")
                return
            physical = state["entries"].get(order_id)
            if physical is None:
                if not new_cost:
                    return  # Admission refused before the physical order was sent.
                raise AccountRiskRefused("reversal risk reservation missing", code="invariant")
            old = state["entries"].get(old_id)
            if old is not None:
                if old["state"] == "reserved" or old_cost > old["cost_cents"]:
                    raise AccountRiskRefused("invalid old reversal exposure", code="invariant")
                if old_cost < old["cost_cents"] and _probe_entry(old_id, old):
                    _record_probe_loss(old, old["cost_cents"] - old_cost, None, time.time_ns())
                old["cost_cents"], old["state"] = old_cost, "open" if old_cost else "closed"
                old["count"] = str(old_count)
            if new_cost > physical["reserved_cents"] or new_id in state["entries"]:
                raise AccountRiskRefused("invalid new reversal exposure", code="invariant")
            if new_cost:
                ticket = dict(physical, cost_cents=new_cost, state="open",
                              count=str(new_count), exact=True)
                if _v2(physical):
                    # New code names the derivation; a v2 ticket without p.d is UNKNOWN, never native.
                    ticket["p"] = _ticket_provenance(physical["p"], order_id)
                state["entries"][new_id] = ticket
            physical["cost_cents"], physical["state"] = 0, "closed"
            _append_event(state, event_id, event)
            state["revision"] += 1

    def split_entry(self, wire_client_id, legs):
        """COMBINE-S1: one combined IOC's resolved entry becomes its legs' entries, in ONE transaction.

        legs: [(client_id, count, cost_cents)], one of them the wire id itself (the anchor keeps its
        own share under it). Every leg entry carries its count and the wire's own exactness, so the
        per-ticker exact-count check (kalshi_live _reserve_entry_risk) holds on the next entry: the legs' counts
        and costs sum exactly to the wire's. Refuses (invariant, nothing written) an unresolved or
        missing wire entry, sums that differ from it, or a leg id already present. A replay of the
        same split is a no-op; a different one refuses invariant."""
        rows = []
        for leg in legs:
            client_id, count, cost = leg
            if not isinstance(client_id, str) or not client_id:
                raise AccountRiskRefused("invalid combined leg id", code="input_invalid")
            try:
                quantity = Decimal(str(count))
            except (InvalidOperation, ValueError) as exc:
                raise AccountRiskRefused("invalid combined leg count", code="input_invalid") from exc
            if not quantity.is_finite() or quantity < 0:
                raise AccountRiskRefused("invalid combined leg count", code="input_invalid")
            rows.append((client_id, quantity, _cents(cost)))
        ids = [row[0] for row in rows]
        if wire_client_id not in ids or len(set(ids)) != len(ids):
            raise AccountRiskRefused("combined legs must name the wire id once each", code="input_invalid")
        with self._transaction() as state:
            entries = state["entries"]
            wire = entries.get(wire_client_id)
            if wire is None or wire["state"] == "reserved":
                raise AccountRiskRefused("combined wire entry missing or unresolved", code="invariant")
            split = [[cid, str(quantity), cost] for cid, quantity, cost in rows]
            if wire.get("combined_split") is not None:
                if wire["combined_split"] != split:
                    raise AccountRiskRefused("conflicting combined split", code="invariant")
                return
            total_cost = sum(row[2] for row in rows)
            total_count = sum((row[1] for row in rows), Decimal(0))
            if wire["cost_cents"] != total_cost or ("count" in wire and Decimal(wire["count"]) != total_count):
                raise AccountRiskRefused("combined split does not sum to the wire entry", code="invariant")
            if any(cid != wire_client_id and cid in entries for cid in ids):
                raise AccountRiskRefused("combined leg id already present", code="invariant")
            base = {key: value for key, value in wire.items() if key not in ("p", "combined_split", "pl", "pd")}
            # An inexact wire (a reply without exact venue cost) splits into inexact legs, so the
            # next entry on the ticker still meets today's ticker_reconciliation_required gate.
            exact = bool(wire.get("exact"))
            for cid, quantity, cost in rows:
                if cid == wire_client_id:
                    continue
                leg = dict(base, cost_cents=cost, reserved_cents=cost,
                           state="open" if cost or quantity else "closed",
                           count=str(quantity), exact=exact, combined=wire_client_id)
                if _v2(wire):
                    leg["p"] = _ticket_provenance(wire["p"], wire_client_id)
                entries[cid] = leg
            anchor = next(row for row in rows if row[0] == wire_client_id)
            wire.update(cost_cents=anchor[2], state="open" if anchor[2] or anchor[1] else "closed",
                        count=str(anchor[1]), exact=exact, combined_split=split)
            state["revision"] += 1


class VerifiedAccountRiskLedger(AccountRiskLedger):
    """Share risk by the principal verified by the authenticated dashboard response.

    Binding is lazy so unavailable entry identity cannot prevent an exit.
    All lanes use one root and principal-derived filename, even after key rotation.
    """

    def __init__(self, root, identity_path, *, legacy_paths=()):
        self.root = Path(root)
        self.identity_path = Path(identity_path)
        self.legacy_paths = tuple(Path(path) for path in legacy_paths)
        self._bound = False
        self._connections = {}
        self._connection_pid = os.getpid()
        self._store_pin_local = threading.local()

    def _store_class(self):
        pinned = getattr(self._store_pin_local, "store", None)
        if pinned is not None:
            return pinned
        self.principal
        selected = self.__dict__.get("_selected_store")
        if selected is None:
            format_name = _rows_module().ledger_format(self.path)
            if format_name == "missing":
                format_name = os.environ.get("LEAFHFT_LEDGER_NEW_FORMAT", "body")
                if format_name not in ("body", "rows"):
                    raise AccountRiskRefused("invalid new ledger format", code="input_invalid")
            if format_name not in ("body", "rows"):
                # Body does its own busy wait and format check, refusing rows with ledger_format_rows.
                return AccountRiskLedger
            selected = _rows_module().RowAccountRiskLedger if format_name == "rows" else AccountRiskLedger
            self._selected_store = selected
        return selected

    @contextmanager
    def _store_pin(self):
        pinned = getattr(self._store_pin_local, "store", None)
        if pinned is not None:
            yield pinned
            return
        store = self._store_class()
        self._store_pin_local.store = store
        try:
            yield store
        finally:
            del self._store_pin_local.store

    @contextmanager
    def _transaction_body(self, active, thread):
        with self._store_pin() as store:
            with store._transaction_body(self, active, thread) as state:
                yield state

    def _reserve(self, *args, **kwargs):
        with self._store_pin() as store:
            return store._reserve(self, *args, **kwargs)

    def snapshot(self, *, hot=False, ticker=None):
        with self._store_pin() as store:
            return store.snapshot(self, hot=hot, ticker=ticker)

    def _connection(self):
        return _rows_module().RowAccountRiskLedger._connection(self)

    @staticmethod
    def _admission_rows(state, positions, unknown, now_ns):
        return _rows_module().RowAccountRiskLedger._admission_rows(state, positions, unknown, now_ns)

    def close(self):
        for record in self._connections.values():
            record["db"].close()
        self._connections.clear()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    @property
    def principal(self):
        from ..engines import load_dashboard_account_identity
        from ..attribution import account_digest
        try:
            identity = load_dashboard_account_identity(self.identity_path)
            if identity.subaccount_number != 0:
                raise AccountRiskRefused("unsupported execution subaccount", code="ledger_identity")
            principal = json.dumps(["kalshi", identity.account_id, identity.subaccount_number],
                                   separators=(",", ":"))
        except (OSError, ValueError) as exc:
            raise AccountRiskRefused("verified account principal unavailable", code="ledger_identity") from exc
        if self._bound and self.account_id != principal:
            raise AccountRiskRefused("verified execution principal changed", code="ledger_identity")
        if not self._bound:
            super().__init__(self.root / (account_digest(principal) + ".sqlite3"),
                             account_id=principal)
            self._bound = True
        return self.account_id

    @contextmanager
    def _transaction(self):
        self.principal
        with super()._transaction() as state:
            # Events a non-maintaining writer appended (a frozen import included) come first, so
            # the import below moves a complete index, record and start.
            _catch_up(state)
            for path in self.legacy_paths:
                if path == self.path or not path.exists():
                    continue
                # Carry old lane reservations and loss baselines forward once.
                # A still-running old writer cannot silently fork account risk.
                db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
                try:
                    row = db.execute("SELECT body FROM account_risk WHERE id=1").fetchone()
                finally:
                    db.close()
                if row is None:
                    raise AccountRiskRefused("legacy risk state is empty", code="ledger_identity")
                digest = hashlib.sha256(row[0].encode()).hexdigest()
                key = str(path.resolve())
                imported = state.setdefault("legacy_imports", {})
                if key in imported:
                    if imported[key] != digest:
                        raise AccountRiskRefused("legacy risk writer changed after migration",
                                                 code="ledger_identity")
                    continue
                legacy = json.loads(row[0])
                if legacy.get("version") != 1:
                    raise AccountRiskRefused("legacy risk schema unavailable", code="ledger_identity")
                for cid, entry in legacy["entries"].items():
                    _cents(entry["cost_cents"])
                    if cid in state["entries"] and state["entries"][cid] != entry:
                        raise AccountRiskRefused("legacy risk entry conflicts with principal ledger",
                                                 code="ledger_identity")
                    state["entries"][cid] = entry
                for event, value in legacy["events"].items():
                    if event in state["events"]:
                        if state["events"][event] != value:
                            raise AccountRiskRefused("legacy risk release conflicts with principal ledger",
                                                     code="ledger_identity")
                        continue
                    if event.startswith(_TRANSFER_PREFIX):
                        # A movement transfer() never counted: it moves the marked start, its day
                        # record and the index by transfer()'s marked rule, in O(1). A malformed
                        # one is skipped by every count (index, full pass, catch-up).
                        moved = _transfer_value(value)
                        if moved is not None:
                            _apply_transfer(state, event, moved[0], moved[1])
                    _append_event(state, event, value)
                state["high_water_cents"] = max(state["high_water_cents"], _cents(legacy["high_water_cents"]))
                if legacy["day"] is not None:
                    if state["day"] is None or legacy["day"] > state["day"]:
                        state["day"] = legacy["day"]
                        state["day_open_cents"] = _cents(legacy["day_open_cents"])
                    elif legacy["day"] == state["day"]:
                        state["day_open_cents"] = max(state["day_open_cents"], _cents(legacy["day_open_cents"]))
                state["fault"] = state["fault"] or legacy["fault"]
                imported[key] = digest
                state["revision"] += 1
            yield state

    def _legacy_pending(self, state):
        """True when any legacy file is not imported, or changed since its recorded digest."""
        imported = (state or {}).get("legacy_imports", {})
        for path in self.legacy_paths:
            if path == self.path or not path.exists():
                continue
            try:
                body = _read_body_ro(path)
            except sqlite3.Error:
                return True
            if body is None or imported.get(str(path.resolve())) != hashlib.sha256(body.encode()).hexdigest():
                return True
        return False

    def read_snapshot(self, *, hot=False, ticker=None):
        """Principal-bound read-only snapshot; one snapshot() fallback on a pending or
        changed legacy import (which snapshot() imports or refuses) or a hot journal."""
        self.principal
        with self._store_pin() as store:
            if store is not AccountRiskLedger:
                state = store.read_snapshot(self, hot=hot, ticker=ticker)
                return self.snapshot(hot=hot, ticker=ticker) if self._legacy_pending(state) else state
            if not self.path.exists():
                return (self.snapshot(hot=True, ticker=ticker) if hot else self.snapshot()) if self._legacy_pending(None) else None
            try:
                state = self._decode(_read_snapshot_body_ro(self.path, hot=hot, ticker=ticker))
            except sqlite3.OperationalError:
                return self.snapshot(hot=True, ticker=ticker) if hot else self.snapshot()
            except sqlite3.Error as exc:
                raise AccountRiskRefused("risk ledger unavailable or corrupt", code="ledger_corrupt") from exc
            return (self.snapshot(hot=True, ticker=ticker) if hot else self.snapshot()) if self._legacy_pending(state) else state


def _connect_ro(path):
    return sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True, timeout=2,
                           isolation_level=None)


def _rows_module():
    # One registered lazy edge avoids a cycle with the shared economic transitions.
    import leafhft.broker.account_risk_rows as account_risk_rows
    return account_risk_rows


def _read_body_ro(path):
    """One deferred read-only transaction: no mkdir, CREATE or write. None when no row."""
    db = _connect_ro(path)
    try:
        db.execute("BEGIN")
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='risk_format'").fetchone():
            raise AccountRiskRefused("body reader refuses rows ledger", code="ledger_format_rows")
        row = db.execute("SELECT body FROM account_risk WHERE id=1").fetchone()
        db.execute("COMMIT")
    finally:
        db.close()
    return None if row is None else row[0]


def _read_snapshot_body_ro(path, *, hot=False, ticker=None):
    # Keep the original positional read hook and raw bytes for every version-1 reader.
    for _ in range(8):
        body = _read_body_ro(path)
        try:
            state = json.loads(body)
        except (ValueError, TypeError, RecursionError):
            return body
        if type(state) is not dict or state.get("version") != 2:
            return body
        merged = _read_archive_body(_connect_ro(path), complete=True, hot=hot,
                                    ticker=ticker, expected_body=body)
        if merged is not None:
            return merged
    raise sqlite3.OperationalError("risk ledger changed during archive read")


def _read_archive_body_ro(path, *, complete=False, hot=False, ticker=None):
    """Read the raw migration body or a consistent complete/hot archive view."""
    return _read_archive_body(_connect_ro(path), complete=complete, hot=hot, ticker=ticker)


def _read_archive_body(db, *, complete=False, hot=False, ticker=None, expected_body=None):
    """Consume and close the caller's connection without opening an unbounded connection."""
    try:
        db.execute("BEGIN")
        row = db.execute("SELECT body FROM account_risk WHERE id=1").fetchone()
        # Exact body equality also catches bookkeeping changes without merging different views.
        if expected_body is not None and (row is None or row[0] != expected_body):
            return None
        if complete and row is not None:
            try:
                state = json.loads(row[0])
            except (ValueError, TypeError, RecursionError):
                state = None  # Preserve version-1 readers' established malformed-body diagnostics.
            if type(state) is dict and state.get("version") == 2:
                try:
                    row = (_archive_json(_archive_view(db, state, hot=hot, ticker=ticker)),)
                except (ValueError, TypeError, KeyError, RecursionError) as exc:
                    raise _archive_error() from exc
        db.execute("COMMIT")
    finally:
        db.close()
    return None if row is None else row[0]


_LEDGER_INT_FIELDS = ("revision", "day_open_cents", "high_water_cents", "equity_cents")
_ENTRY_STATES = frozenset({"reserved", "open", "closed"})
# X2c: the domains writers can store. Every cents value passes _cents (0..2**53-1); the paid basis
# fields hold cash_cents + open_cost_cents (_basis), the sum of two _cents values.
_CENTS_MAX = 2**53 - 1
_BASIS_MAX = 2 * _CENTS_MAX
_BASIS_FIELDS = ("day_open_cents", "high_water_cents", "equity_cents")
# Event keys with their own layout, in dispatch order; every other key is a release event.
_REVERSAL_PREFIX = "reversal:"
_EVENT_PREFIXES = (_TRANSFER_PREFIX, _REVERSAL_PREFIX, "marked_stale:", "marked_unreconciled:")


def _prefixed_event_ok(key, value):
    """True when a transfer, reversal or marked-journal event list matches its writer's layout.

    O(1), never raises: type(...) is tests and chained comparisons only, never str() of an int.
    transfer (transfer()): [amount int, |amount| <= 2**53-1, at_ns int 0.._NS_MAX].
    reversal (finish_reversal()): [old_id str, new_id str, old_cost cents, new_cost cents].
    marked_stale: / marked_unreconciled: journal (_reserve): [marked_ns int 0.._NS_MAX, now_ns int].
    """
    if key.startswith(_TRANSFER_PREFIX):
        return (len(value) == 2 and type(value[0]) is int and -_CENTS_MAX <= value[0] <= _CENTS_MAX
                and type(value[1]) is int and 0 <= value[1] <= _NS_MAX)
    if key.startswith(_REVERSAL_PREFIX):
        return (len(value) == 4 and type(value[0]) is str and type(value[1]) is str
                and type(value[2]) is int and 0 <= value[2] <= _CENTS_MAX
                and type(value[3]) is int and 0 <= value[3] <= _CENTS_MAX)
    return (len(value) == 2 and type(value[0]) is int and 0 <= value[0] <= _NS_MAX
            and type(value[1]) is int)


def _raised_ok(value):
    """True when a high_water_raised record matches _basis' layout. O(1), never raises.

    Exactly _RAISED_KEYS: at_ns int 0.._NS_MAX; from, to and equity cents int 0.._BASIS_MAX;
    client_id None or text of at most 128 characters; cash and open cost None or cents.
    """
    if type(value) is not dict or value.keys() != _RAISED_KEYS:
        return False
    if type(value["at_ns"]) is not int or not 0 <= value["at_ns"] <= _NS_MAX:
        return False
    for field in ("from_cents", "to_cents", "equity_cents"):
        if type(value[field]) is not int or not 0 <= value[field] <= _BASIS_MAX:
            return False
    client_id = value["client_id"]
    if client_id is not None and (type(client_id) is not str or len(client_id) > _RAISED_TEXT_MAX):
        return False
    return all(value[field] is None or (type(value[field]) is int and 0 <= value[field] <= _CENTS_MAX)
               for field in ("cash_cents", "open_cost_cents"))


def _int_text(value):
    """An int as at most 20 characters, without str() of an unbounded int (fails closed on size)."""
    if -10**19 < value < 10**19:
        return str(value)
    return "-(20+ digits)" if value < 0 else "(20+ digits)"


def _ledger_structure_error(state):
    """Why a decoded version-1 body is not a ledger the writers can make, else None.

    Type and writer-domain checks, one pass over entries and one over events: O(E + events +
    imports), never raises, comparisons only on ints (never str() of an unbounded one); the
    transfer index check (the transfer keys of its first seen events) shares the events pass.
    Mirrors every field the writers read with [] (revision, day, basis cents, entries, events,
    fault, each entry's ticker, minute, cost, reserved cents and state) and legacy_imports.
    Money fields must lie in the ranges writers produce: basis cents 0..2*(2**53-1), entry and
    marked cents 0..2**53-1. Each event must match its key's writer layout (_prefixed_event_ok;
    any other key is a release, [client_id str, cents]). revision stays a type-only check.
    """
    if _RESTORE_MARKER in state:
        marker = state[_RESTORE_MARKER]
        if type(marker) is not str or not 1 <= len(marker) <= 200:
            return f"{_RESTORE_MARKER} not text of 1..200 characters"
    for field in _LEDGER_INT_FIELDS:
        if type(state.get(field)) is not int:
            return f"{field} missing or not an integer"
    for field in _BASIS_FIELDS:
        if not 0 <= state[field] <= _BASIS_MAX:
            return f"{field} out of range"
    if "day" not in state or not (state["day"] is None or isinstance(state["day"], str)):
        return "day missing or not text"
    if "fault" not in state or not (state["fault"] is None or isinstance(state["fault"], str)):
        return "fault missing or not text"
    for field in (_MARKED_CENTS, _MARKED_NS):
        # Optional (X2b): absent on every body a frozen or pre-X2b writer made.
        if field in state and type(state[field]) is not int:
            return f"{field} not an integer"
    if _MARKED_CENTS in state and not 0 <= state[_MARKED_CENTS] <= _CENTS_MAX:
        return f"{_MARKED_CENTS} out of range"
    if _MARKED_TRANSFERS in state and _marked_transfers(state) is None:
        return f"{_MARKED_TRANSFERS} not [sum, latest ns]"
    index = _transfer_index(state)
    if _TRANSFER_INDEX in state and index is None:
        return f"{_TRANSFER_INDEX} not [newest transfer day, transfer keys, events seen]"
    if _RAISED in state and not _raised_ok(state[_RAISED]):
        return f"{_RAISED} not the high water provenance record"
    entries, events = state.get("entries"), state.get("events")
    if type(entries) is not dict:
        return "entries missing or not an object"
    if not isinstance(events, dict):
        return "events missing or not an object"
    for cid, entry in entries.items():
        if type(entry) is not dict:
            return f"entry {cid[:64]} malformed"
        cost, reserved = entry.get("cost_cents"), entry.get("reserved_cents")
        if (not isinstance(entry.get("ticker"), str)
                or not isinstance(entry.get("state"), str) or entry.get("state") not in _ENTRY_STATES
                or type(entry.get("minute")) is not int
                or type(cost) is not int or not 0 <= cost <= _CENTS_MAX
                or type(reserved) is not int or not 0 <= reserved <= _CENTS_MAX):
            return f"entry {cid[:64]} malformed"
    if index is not None and index[2] > len(events):
        return f"{_TRANSFER_INDEX} has seen more events than the ledger holds"
    top, keys = -1, []  # _day_transfers' full-pass rule over the first seen events, in body order
    for position, (event_id, value) in enumerate(events.items()):
        if type(value) is not list:
            return f"event {event_id[:64]} malformed"
        if not event_id.startswith(_EVENT_PREFIXES):
            # release(): [client_id, cost cents]; one prefix test and no call for the common key.
            if (len(value) != 2 or type(value[0]) is not str or type(value[1]) is not int
                    or not 0 <= value[1] <= _CENTS_MAX):
                return f"event {event_id[:64]} malformed"
        elif not _prefixed_event_ok(event_id, value):
            return f"event {event_id[:64]} malformed"
        elif index is not None and position < index[2] and event_id.startswith(_TRANSFER_PREFIX):
            at_day = value[1] // _DAY_NS  # a well-formed transfer: at_ns is an int in 0.._NS_MAX
            if at_day > top:
                top, keys = at_day, [event_id]
            elif at_day == top:
                keys.append(event_id)
    if index is not None and [top, keys] != [index[0], index[1]]:
        return f"{_TRANSFER_INDEX} is not the transfer keys of its first {index[2]} events"
    imported = state.get("legacy_imports", {})
    if type(imported) is not dict or any(not isinstance(value, str) for value in imported.values()):
        return "legacy_imports not an object of digests"
    return None


def restore_snapshot(path, body, *, account_id, note):
    """Replace the complete state document atomically; every writer must be stopped first.

    Validate and serialize before opening SQLite, so an invalid snapshot never creates a file.
    The first current-writer transaction audits the marker and recounts the derived fields.
    Returns the SHA-256 hex digest of the exact UTF-8 payload stored in account_risk.id=1.
    """
    if Path(path).exists():
        probe = None
        try:
            probe = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro",
                                    uri=True, timeout=0.1)
            budget = 1000

            def bounded():
                nonlocal budget
                budget -= 1
                return int(budget <= 0)

            probe.set_progress_handler(bounded, 100)
            if probe.execute("SELECT 1 FROM sqlite_master WHERE type='table' "
                             "AND name='risk_format' LIMIT 1").fetchone():
                raise AccountRiskRefused("body restore refuses rows ledger", code="ledger_format_rows")
        except (sqlite3.Error, OSError) as exc:
            raise AccountRiskRefused("risk ledger restore unavailable", code="ledger_corrupt") from exc
        finally:
            if probe is not None:
                probe.close()
    try:
        state = json.loads(body)
    except (ValueError, TypeError, RecursionError) as exc:
        raise AccountRiskRefused("restore body is not JSON", code="ledger_corrupt") from exc
    if type(state) is not dict:
        raise AccountRiskRefused("restore body is not an object", code="ledger_corrupt")
    if type(state.get("version")) is not int or state["version"] != 1:
        raise AccountRiskRefused("restore version must be the integer 1", code="ledger_identity")
    if (type(state.get("account_id")) is not str or not state["account_id"]
            or state["account_id"] != account_id):
        raise AccountRiskRefused("restore account identity mismatch", code="ledger_identity")
    reason = _ledger_structure_error(state)
    if reason is not None:
        raise AccountRiskRefused(reason, code="ledger_corrupt")
    if type(note) is not str or not 1 <= len(note) <= 200:
        raise AccountRiskRefused("restore_marker note must be text of 1..200 characters",
                                 code="input_invalid")
    state[_RESTORE_MARKER] = note
    try:
        payload = json.dumps(state, separators=(",", ":"), allow_nan=False)
        digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    except (ValueError, TypeError, RecursionError) as exc:
        raise AccountRiskRefused("restore body cannot be serialized", code="ledger_corrupt") from exc
    path = Path(path)
    db = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(str(path), timeout=2, isolation_level=None)
        db.execute("PRAGMA synchronous=FULL")
        db.execute("BEGIN EXCLUSIVE")
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='risk_format'").fetchone():
            raise AccountRiskRefused("body restore refuses rows ledger", code="ledger_format_rows")
        db.execute("CREATE TABLE IF NOT EXISTS account_risk (id INTEGER PRIMARY KEY, body TEXT NOT NULL)")
        row = db.execute("SELECT body FROM account_risk WHERE id=1").fetchone()
        # A complete restore replaces both stores in the same write transaction.
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='account_risk_archive'").fetchone():
            db.execute("DELETE FROM account_risk_archive")
        if row is not None and payload == row[0]:
            db.execute("ROLLBACK")
        else:
            if row is not None:
                try:
                    stored_state = json.loads(row[0])
                except (ValueError, TypeError, RecursionError):
                    stored_state = None
                stored_revision = stored_state.get("revision") if type(stored_state) is dict else None
                if type(stored_revision) is int and state["revision"] <= stored_revision:
                    state["revision"] = stored_revision + 1
                    payload = json.dumps(state, separators=(",", ":"), allow_nan=False)
                    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
            db.execute("INSERT OR REPLACE INTO account_risk VALUES (1, ?)", (payload,))
            db.execute("COMMIT")
    except (sqlite3.Error, OSError) as exc:
        if db is not None and db.in_transaction:
            db.execute("ROLLBACK")
        raise AccountRiskRefused("risk ledger restore unavailable", code="ledger_corrupt") from exc
    except BaseException:
        if db is not None and db.in_transaction:
            db.execute("ROLLBACK")
        raise
    finally:
        if db is not None:
            db.close()
    return digest


def read_ledger(path, expected_account_id=None, *, legacy_paths=(), hot=False, ticker=None):
    """Root auditor read: mode=ro only, never snapshot(), never raises on ledger content.

    status: ok | missing | empty | unreadable | corrupt | identity_mismatch; reason
    names why a body is corrupt. legacy_import: none | current | pending | changed |
    unreadable; only ok with none or current is healthy, so a pending or changed
    import is never healthy, and a body missing required structure is corrupt.

    missing: no file. empty: no body row. unreadable: a locked or hot database. corrupt: not
    a database, not JSON, not a JSON object, a version that is not the integer 1 (true and
    1.0 are refused), an account_id that is missing or not non-empty text, or a version-1
    body a writer could not have made (_ledger_structure_error). identity_mismatch: only a
    well-formed version-1 object whose non-empty text account_id differs from a given
    expected_account_id. Any JSON-decodable body returns a dict: comparisons only on ints.
    """
    path = Path(path)
    result = {"status": "missing", "state": None, "legacy_import": "none", "healthy": False,
              "reason": None}
    if not path.exists():
        return result
    rows = _rows_module()
    if rows.ledger_format(path) == "rows":
        return rows.read_rows_ledger(path, expected_account_id, legacy_paths=legacy_paths,
                                     hot=hot, ticker=ticker)
    try:
        for _ in range(8):
            body = _read_body_ro(path)
            try:
                preliminary = json.loads(body)
            except (ValueError, TypeError, RecursionError):
                break
            if type(preliminary) is not dict or preliminary.get("version") != 2:
                break
            # Reports rebind both the body hook and this connection factory to bound I/O.
            merged = _read_archive_body(_connect_ro(path), complete=True, hot=hot,
                                        ticker=ticker, expected_body=body)
            if merged is not None:
                body = merged
                break
        else:
            raise sqlite3.OperationalError("risk ledger changed during archive read")
    except AccountRiskRefused as exc:
        if getattr(exc, "code", None) == "ledger_format_rows":
            return rows.read_rows_ledger(path, expected_account_id, legacy_paths=legacy_paths,
                                         hot=hot, ticker=ticker)
        result.update(status="corrupt", reason=str(exc))
        return result
    except sqlite3.OperationalError:
        result["status"] = "unreadable"
        return result
    except sqlite3.Error:
        result["status"] = "corrupt"
        return result
    if body is None:
        result["status"] = "empty"
        return result
    try:
        state = json.loads(body)
    except (ValueError, TypeError, RecursionError):
        result.update(status="corrupt", reason="body is not JSON")
        return result
    if type(state) is not dict:
        result.update(status="corrupt", reason="body is not an object")
        return result
    version = state.get("version")
    if type(version) is not int:
        result.update(status="corrupt", reason="version missing or not an integer")
        return result
    if version not in (1, 2):
        result.update(status="corrupt", reason=f"unsupported version {_int_text(version)}")
        return result
    account_id = state.get("account_id")
    if type(account_id) is not str or not account_id:
        result.update(status="corrupt", reason="account_id missing or not text")
        return result
    if expected_account_id is not None and account_id != expected_account_id:
        result["status"] = "identity_mismatch"
        return result
    reason = _ledger_structure_error(state)
    if reason is not None:
        result.update(status="corrupt", reason=reason)
        return result
    imported = state.get("legacy_imports", {})
    verdicts = set()
    candidates = {str(Path(p).resolve()) for p in legacy_paths if Path(p).resolve() != path.resolve()}
    for key in sorted(candidates | set(imported)):
        legacy = Path(key)
        try:
            if not legacy.exists():
                continue
            legacy_body = _read_body_ro(legacy)
        except (sqlite3.Error, OSError, ValueError):
            verdicts.add("unreadable")
            continue
        if legacy_body is not None and not isinstance(legacy_body, str):
            verdicts.add("unreadable")
            continue
        if key not in imported:
            verdicts.add("pending")
        elif legacy_body is None or hashlib.sha256(legacy_body.encode()).hexdigest() != imported[key]:
            verdicts.add("changed")
        else:
            verdicts.add("current")
    for verdict in ("changed", "unreadable", "pending", "current"):
        if verdict in verdicts:
            result["legacy_import"] = verdict
            break
    result.update(status="ok", state=state,
                  healthy=result["legacy_import"] in ("none", "current"))
    return result


# Ticker classes in evaluation order. V is valuation (reaches open_cost_cents and so
# equity); A is an admission charge only (reaches the exposure caps, never equity).
TICKER_CLASSES = ("flat", "ledger_only", "opposed", "exact", "legacy_side_unknown",
                  "in_flight", "foreign", "shortfall", "inexact", "legacy_unmatched")
_NON_WIDENED = frozenset({"exact", "legacy_side_unknown"})
_NEEDS_VALUE = frozenset({"opposed", "foreign", "inexact", "legacy_unmatched"})
_REQUESTED_REFUSALS = {
    "opposed": "ticker_reconciliation_required",
    "legacy_side_unknown": "ticker_reconciliation_required",
    "inexact": "ticker_reconciliation_required",
    "legacy_unmatched": "ticker_reconciliation_required",
    "foreign": "ticker_foreign_exposure",
    "shortfall": "ticker_position_shortfall",
}


@dataclass(frozen=True)
class TickerClassification:
    classes: dict             # ticker -> class, for the requested ticker and every held or ledger-open one
    refusal: tuple | None     # (code, message) refusing this reservation, else None
    positions: dict           # ticker -> (minute, paid) for held tickers with a known minute
    open_cost_cents: int      # sum of V; admission never reaches it
    admission: dict           # (ticker, minute or None) -> A cents
    unknown_minute: frozenset
    widened: bool             # some held ticker fails E0, or a minute is unknown
    foreign_open: tuple       # at most FOREIGN_OPEN_MAX foreign tickers
    legacy_side_unknown_exact: int

    def raise_for_refusal(self):
        if self.refusal is not None:
            raise AccountRiskRefused(self.refusal[1], code=self.refusal[0])

    def reserve_kwargs(self):
        """The reserve() keywords that carry this observation in ticker mode."""
        return {"mode": "ticker", "positions": dict(self.positions),
                "open_cost_cents": self.open_cost_cents, "admission": dict(self.admission),
                "unknown_minute": self.unknown_minute, "widened": self.widened}


_ZERO = Decimal(0)


def _decimal_of(value):
    """Decimal(str(value)) without the str round trip for text, the common wire shape."""
    return Decimal(value if type(value) is str else str(value))


def _venue_index(venue_rows, residual):
    venue = {}
    for row in venue_rows:
        if type(row) is not dict and not isinstance(row, Mapping):
            raise AccountRiskRefused("invalid account position", code="venue_malformed")
        market = row.get("ticker")
        try:
            quantity = _decimal_of(row.get("position_fp", row.get("position")))
        except (InvalidOperation, ValueError) as exc:
            raise AccountRiskRefused("invalid account position", code="venue_malformed") from exc
        if not isinstance(market, str) or not market or not quantity.is_finite():
            raise AccountRiskRefused("invalid account position", code="venue_malformed")
        if market in venue:
            raise AccountRiskRefused("duplicate account position", code="venue_malformed")
        value = row.get("market_exposure")
        if not residual or type(value) is not int or not 0 <= value <= 2**53 - 1:
            value = None
        venue[market] = (quantity, value)
    return venue


def _exact_count(entry):
    """The open entry's count as a Decimal when it is exact, else None (inexact or malformed)."""
    if not entry.get("exact") or "count" not in entry:
        return None
    try:
        quantity = _decimal_of(entry["count"])
    except (InvalidOperation, ValueError):
        return None
    return quantity if quantity.is_finite() and quantity >= 0 else None


def classify_tickers(entries, venue_rows, *, requested, now_ns, worst_cents, minutes,
                     journal_sides=None, residual_valuation=None):
    """Pure per-ticker classification: one indexed pass over entries and one over venue rows.

    O(P + E + T) with T = |venue tickers + ledger-open tickers + requested| <= P + E + 1:
    tickers are walked in index insertion order, never sorted. Only the bounded report is
    ordered: foreign_open is the FOREIGN_OPEN_MAX smallest foreign tickers (heapq,
    O(T log FOREIGN_OPEN_MAX)) and the value refusal names min(), so every output equals
    the sorted walk's. No I/O and no strategy import (worst_cents W and minutes are passed in).
    Signed venue quantity: positive YES, negative NO (F1). journal_sides maps a legacy
    client id to its SENT side; a legacy entry without one keeps an UNKNOWN side, so
    count equality alone never makes a ticker exact (v3.1 Q6). In-flight reservations
    are never an asset (v3.1 A2): their reserved cost is admission only.
    """
    residual = RESIDUAL_VALUATION_ENABLED if residual_valuation is None else bool(residual_valuation)
    if type(worst_cents) is not int or worst_cents <= 0 or type(now_ns) is not int:
        raise AccountRiskRefused("invalid classification input", code="input_invalid")
    if not isinstance(requested, str) or not requested:
        raise AccountRiskRefused("invalid classification input", code="input_invalid")
    journal_sides = journal_sides or {}
    # One pass over entries. Closed entries cost one dict read each; every open entry's
    # side, exact count (one Decimal parse) and minute validity are parsed ONCE into a
    # typed record (side, count|None, cost entry, minute_bad), indexed by ticker.
    opened_by, covering_by = {}, {}
    for cid, entry in entries.items():
        state = entry.get("state")
        if state == "open":
            p = entry.get("p")
            known = p.get("s") if type(p) is dict and p.get("v") == 2 else _side_code(journal_sides.get(cid))
            minute = entry.get("minute")
            record = (known if known == "y" or known == "n" else None, _exact_count(entry), entry,
                      type(minute) is not int or minute < 0)
            bucket = opened_by.get(entry["ticker"])
            if bucket is None:
                opened_by[entry["ticker"]] = [record]
            else:
                bucket.append(record)
        elif state == "reserved":
            p = entry.get("p")
            if type(p) is dict and p.get("v") == 2:
                bucket = covering_by.get(entry["ticker"])
                if bucket is None:
                    covering_by[entry["ticker"]] = [entry]
                else:
                    bucket.append(entry)
    venue = _venue_index(venue_rows, residual)
    # Insertion-ordered union (a dict, not a set, so the walk is deterministic); no sort.
    tickers = dict.fromkeys(venue)
    tickers.update(dict.fromkeys(opened_by))
    tickers[requested] = None
    classes, positions, admission = {}, {}, {}
    unknown, foreign, value_missing = set(), [], []
    open_cost, side_unknown_exact, widened = 0, 0, False
    absent = (_ZERO, None)
    for market in tickers:
        quantity, value = venue.get(market, absent)
        opened = opened_by.get(market, ())
        if not quantity:
            if not opened:
                classes[market] = "flat"
                continue
            classes[market] = "ledger_only"
            for record in opened:
                if record[3]:
                    unknown.add(market)
                    break
            continue
        side = "y" if quantity > 0 else "n"
        magnitude = abs(quantity)
        minute = minutes.get(market)
        known_minute = type(minute) is int and minute >= 0
        if not known_minute:
            unknown.add(market)
        is_opposed, side_unknown, exact_entries, held, paid = False, False, True, _ZERO, 0
        for known, count, entry, _ in opened:
            if known is None:
                side_unknown = True
            elif known != side:
                is_opposed = True
            if count is None:
                exact_entries = False
            else:
                held += count
            paid += entry["cost_cents"]
        charge = None
        if is_opposed:
            cls = "opposed"
        elif exact_entries and opened and held == magnitude:
            cls = "legacy_side_unknown" if side_unknown else "exact"
            valuation = paid
            if not known_minute:
                charge = paid
        elif exact_entries and held < magnitude:
            cover_count, cover_cents = _ZERO, 0
            for entry in covering_by.get(market, ()):
                p = entry["p"]
                age = now_ns - p["t"] if type(p.get("t")) is int else -1
                if p.get("s") != side or not 0 <= age < COVER_WINDOW_NS:
                    continue
                try:
                    reserved_count = _decimal_of(p["n"])
                except (KeyError, InvalidOperation, ValueError):
                    continue
                if reserved_count.is_finite() and reserved_count > 0:
                    cover_count += reserved_count
                    cover_cents += entry["reserved_cents"]
            uncovered = magnitude - held
            covered = min(uncovered, cover_count)
            residual_count = uncovered - covered
            charge = paid + max(0, _ceil(covered * worst_cents) - cover_cents)
            if residual_count:
                cls = "foreign"
                charge += _ceil(residual_count * worst_cents)
                valuation = None if value is None else paid + _floor(Decimal(value) * residual_count / magnitude)
            else:
                cls = "in_flight"
                valuation = paid
        elif exact_entries and held > magnitude:
            cls = "shortfall"
            valuation = _floor(Decimal(paid) * magnitude / held)
            charge = _ceil(magnitude * worst_cents)
        else:
            cls = "inexact" if not exact_entries else "legacy_unmatched"
        if cls in ("opposed", "inexact", "legacy_unmatched"):
            valuation = value
            charge = _ceil(magnitude * worst_cents)
        classes[market] = cls
        if cls == "legacy_side_unknown":
            side_unknown_exact += 1
        if cls not in _NON_WIDENED:
            widened = True
        if cls == "foreign":
            foreign.append(market)
        if valuation is None:
            value_missing.append(market)
        else:
            open_cost += valuation
        if known_minute:
            positions[market] = (minute, paid)
        if charge is not None:
            admission[(market, minute if known_minute else None)] = charge
    widened = widened or bool(unknown)
    refusal = None
    requested_class = classes[requested]
    requested_minute = minutes.get(requested, 0)
    if requested in unknown or type(requested_minute) is not int or requested_minute < 0:
        refusal = ("settlement_minute_unavailable", "market settlement time unavailable")
    elif requested_class in _REQUESTED_REFUSALS:
        quantity = venue.get(requested, absent)[0]
        refusal = (_REQUESTED_REFUSALS[requested_class],
                   f"ticker {requested_class} requires reconciliation: {requested[:64]} "
                   f"venue={quantity.normalize():f} entries={len(opened_by.get(requested, ()))}")
    elif value_missing:
        refusal = ("foreign_value_unavailable",
                   f"venue market value unavailable: {min(value_missing)[:64]} tickers={len(value_missing)}")
    return TickerClassification(
        classes=classes, refusal=refusal, positions=positions, open_cost_cents=open_cost,
        admission=admission, unknown_minute=frozenset(unknown), widened=widened,
        foreign_open=tuple(heapq.nsmallest(FOREIGN_OPEN_MAX, foreign)),
        legacy_side_unknown_exact=side_unknown_exact)
