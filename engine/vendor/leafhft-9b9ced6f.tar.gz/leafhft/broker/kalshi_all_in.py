"""KalshiAllInOnce: a shared, locked, single-fire claim so the FIRST qualifying 90-94c leg
across all fourteen book processes may buy with the entire free balance exactly once, then
disarm permanently. Reuses the exclusive-lock discipline of ProfitPool (kalshi_pool.py): one
JSON document guarded by a dedicated `<path>.lock` file, so no two books can ever race the same
claim.

`spent` is TERMINAL: no code path in this module ever returns it to `armed`. A MISSING file is
the virgin, armed state (deleting the file is the operator's deliberate re-arm act, named in the
spec). A file that EXISTS but cannot be parsed (empty, oversized, malformed JSON, or a shape the
validator rejects) fails CLOSED, treated as not armed, so a corrupted record can never resurrect
a spent shot or a stale claim.
"""
from __future__ import annotations

import os
import re
import time
from decimal import Decimal
from pathlib import Path
from typing import Any

import orjson

from leafhft.broker.kalshi_pool import _FileLock

MAX_DOC_BYTES = 65536
MAX_KEY_LEN = 64
MAX_REASON_LEN = 256
MAX_INT_CENTS = 100_000_000
MAX_COUNT = 100_000_000
CLAIM_TTL_MS = 60_000
DOC_VERSION = 1


def _encode_count(count: int | float | Decimal) -> int | str:
    """Validate the exact hundredth grid and return its version-1 representation."""
    if isinstance(count, bool) or not isinstance(count, (int, float, Decimal)):
        raise ValueError("count invalid")
    value = Decimal(str(count)) if isinstance(count, float) else Decimal(count)
    if not value.is_finite() or not 0 < value <= MAX_COUNT:
        raise ValueError("count invalid")
    _, digits, exponent = value.as_tuple()
    # Inspect digits instead of doing arithmetic that could round in a Decimal context.
    if exponent < -2 and any(digits[exponent + 2:]):
        raise ValueError("count invalid")
    if value == value.to_integral_value():
        return int(value)
    return format(value, ".2f")


def _validate_claim(claim: Any) -> bool:
    if not isinstance(claim, dict):
        return False
    book_id = claim.get("book_id")
    ticker = claim.get("ticker")
    at_ms = claim.get("at_ms")
    if not isinstance(book_id, str) or not 0 < len(book_id) <= MAX_KEY_LEN:
        return False
    if not isinstance(ticker, str) or not 0 < len(ticker) <= MAX_KEY_LEN:
        return False
    if type(at_ms) is not int or at_ms < 0:
        return False
    return True


def _validate_spent(spent: Any) -> bool:
    if not isinstance(spent, dict):
        return False
    book_id = spent.get("book_id")
    ticker = spent.get("ticker")
    count = spent.get("count")
    cost_cents = spent.get("cost_cents")
    at_ms = spent.get("at_ms")
    if not isinstance(book_id, str) or not 0 < len(book_id) <= MAX_KEY_LEN:
        return False
    if not isinstance(ticker, str) or not 0 < len(ticker) <= MAX_KEY_LEN:
        return False
    if isinstance(count, str):
        if re.fullmatch(r"(?:0|[1-9][0-9]*)\.[0-9]{2}", count) is None or count.endswith(".00"):
            return False
        count = Decimal(count)
    elif type(count) is not int:
        return False
    try:
        _encode_count(count)
    except ValueError:
        return False
    if type(cost_cents) is not int or not 0 <= cost_cents <= MAX_INT_CENTS:
        return False
    if type(at_ms) is not int or at_ms < 0:
        return False
    return True


def _validate_doc(doc: Any) -> dict[str, Any] | None:
    if not isinstance(doc, dict):
        return None
    if doc.get("version") != DOC_VERSION:
        return None
    state = doc.get("state")
    claim = doc.get("claim")
    spent = doc.get("spent")
    if state == "armed":
        if claim is not None or spent is not None:
            return None
    elif state == "claimed":
        if not _validate_claim(claim):
            return None
        if spent is not None:
            return None
    elif state == "spent":
        if not _validate_spent(spent):
            return None
        if claim is not None and not _validate_claim(claim):
            return None
    else:
        return None
    return {"version": DOC_VERSION, "state": state, "claim": claim, "spent": spent}


class KalshiAllInOnce:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._lock_path = Path(str(self.path) + ".lock")

    def _load(self) -> dict[str, Any] | None:
        """Missing file: the virgin armed state. A file that exists but cannot be parsed
        returns None, the fail-closed signal every public method treats as not armed."""
        try:
            exists = self.path.exists()
        except OSError:
            return None
        if not exists:
            return {"version": DOC_VERSION, "state": "armed", "claim": None, "spent": None}
        try:
            data = self.path.read_bytes()
        except OSError:
            return None
        if not data or len(data) > MAX_DOC_BYTES:
            return None
        try:
            raw = orjson.loads(data)
        except Exception:
            return None
        return _validate_doc(raw)

    def _write(self, doc: dict[str, Any]) -> None:
        payload = orjson.dumps(doc)
        if len(payload) > MAX_DOC_BYTES:
            raise ValueError("all-in document would exceed MAX_DOC_BYTES")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + f".tmp{os.getpid()}")
        tmp.write_bytes(payload)
        os.replace(tmp, self.path)

    @staticmethod
    def _validate_book_ticker(book_id: str, ticker: str) -> None:
        if not isinstance(book_id, str) or not 0 < len(book_id) <= MAX_KEY_LEN:
            raise ValueError("book_id invalid")
        if not isinstance(ticker, str) or not 0 < len(ticker) <= MAX_KEY_LEN:
            raise ValueError("ticker invalid")

    def claim(self, book_id: str, ticker: str, now_ms: int | None = None) -> bool:
        """The ONLY way to fire. True exactly once per file lifetime, ever, unless a fresh
        claim expires (TTL) with no settle_spent, in which case it becomes stealable again."""
        self._validate_book_ticker(book_id, ticker)
        now_ms = int(time.time() * 1000) if now_ms is None else now_ms
        if type(now_ms) is not int or now_ms < 0:
            raise ValueError("now_ms invalid")
        with _FileLock(self._lock_path):
            doc = self._load()
            if doc is None:
                return False
            if doc["state"] == "spent":
                return False
            if doc["state"] == "claimed":
                claim = doc["claim"]
                if claim is None or (now_ms - claim["at_ms"]) <= CLAIM_TTL_MS:
                    return False  # fresh claim: not stealable
            self._write({
                "version": DOC_VERSION,
                "state": "claimed",
                "claim": {"book_id": book_id, "ticker": ticker, "at_ms": now_ms},
                "spent": None,
            })
            return True

    def settle_spent(self, book_id: str, ticker: str, count: int | float | Decimal, cost_cents: int,
                     now_ms: int | None = None) -> bool:
        """Only the CURRENT claim holder may spend. Writes `spent` (terminal) atomically under
        the same lock: a crash after this call cannot lose the terminal state to a competitor."""
        self._validate_book_ticker(book_id, ticker)
        stored_count = _encode_count(count)
        if type(cost_cents) is not int or not 0 <= cost_cents <= MAX_INT_CENTS:
            raise ValueError("cost_cents invalid")
        now_ms = int(time.time() * 1000) if now_ms is None else now_ms
        if type(now_ms) is not int or now_ms < 0:
            raise ValueError("now_ms invalid")
        with _FileLock(self._lock_path):
            doc = self._load()
            if doc is None or doc["state"] != "claimed":
                return False
            claim = doc["claim"]
            if claim is None or claim["book_id"] != book_id or claim["ticker"] != ticker:
                return False
            self._write({
                "version": DOC_VERSION,
                "state": "spent",
                "claim": claim,
                "spent": {
                    "book_id": book_id, "ticker": ticker, "count": stored_count,
                    "cost_cents": cost_cents, "at_ms": now_ms,
                },
            })
            return True

    def release(self, book_id: str, reason: str, now_ms: int | None = None) -> bool:
        """A no-fill or an error returns the shot to `armed` so it survives, but only the
        current holder may release; a non-holder's call is refused and the claim stays intact."""
        if not isinstance(book_id, str) or not 0 < len(book_id) <= MAX_KEY_LEN:
            raise ValueError("book_id invalid")
        if not isinstance(reason, str) or not 0 < len(reason) <= MAX_REASON_LEN:
            raise ValueError("reason invalid")
        with _FileLock(self._lock_path):
            doc = self._load()
            if doc is None or doc["state"] != "claimed":
                return False
            claim = doc["claim"]
            if claim is None or claim["book_id"] != book_id:
                return False
            self._write({"version": DOC_VERSION, "state": "armed", "claim": None, "spent": None})
            return True

    def snapshot(self) -> dict[str, Any]:
        doc = self._load()
        if doc is None:
            return {"state": "unreadable", "claim": None, "spent": None}
        return {"state": doc["state"], "claim": doc["claim"], "spent": doc["spent"]}


def compute_all_in_count(free_cash_cents: int, price_cents: int, fee_cents: int) -> int:
    """Pure sizing core (spec ordering step 4): the largest whole number of contracts the
    entire free balance affords at price_cents plus a per-contract fee_cents. Deliberately
    bypasses every fractional sizing knob; it does NOT bypass the venue balance itself, which is
    exactly what free_cash_cents already is."""
    if type(free_cash_cents) is not int or not 0 <= free_cash_cents <= MAX_INT_CENTS:
        raise ValueError("free_cash_cents invalid")
    if type(price_cents) is not int or not 0 < price_cents <= 99:
        raise ValueError("price_cents invalid")
    if type(fee_cents) is not int or not 0 <= fee_cents <= MAX_INT_CENTS:
        raise ValueError("fee_cents invalid")
    return free_cash_cents // (price_cents + fee_cents)
