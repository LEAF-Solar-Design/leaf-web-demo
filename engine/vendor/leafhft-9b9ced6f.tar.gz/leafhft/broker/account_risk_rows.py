"""Row-format account ledger and format-aware principal-bound live writer.

Economic transitions are shared with the body writer; the transaction owns row
and aggregate changes together. Amount aggregates use decimal TEXT so SQLite's
signed 64-bit SUM cannot silently narrow Python's exact integer arithmetic.
"""
from collections.abc import MutableMapping
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import threading

from . import account_risk as risk


# Admission enforces its own deadlines elsewhere; contention may wait briefly,
# but must never block a ledger transaction indefinitely.
BUSY_TIMEOUT_S = 5


ROWS_POISON_BODY = (
    "LEAFHFT-ROWS-V1: This ledger is rows format and must be opened by code at or "
    "after the rows cutover, or converted back with to-body first."
)


_ROW_TABLES = ("risk_format", "risk_account", "risk_entry", "risk_event", "risk_legacy",
               "risk_bucket", "risk_ticker", "risk_minute", "risk_loss", "account_risk_archive")


def _ledger_format(db):
    tables = {row[0] for row in db.execute(
        "SELECT name FROM sqlite_master WHERE type='table' LIMIT 64")}
    if "risk_format" in tables:
        marker = db.execute("SELECT id,substr(value,1,16),length(CAST(value AS BLOB)) "
                            "FROM risk_format LIMIT 2").fetchall()
        if marker == [(1, "rows-v1", 7)] and set(_ROW_TABLES) <= tables:
            for table, columns in (("risk_account", "id,metadata_json,counters,schema_epoch,revision"),
                                   ("risk_entry", "client_id,sequence,hot_order,body_json"),
                                   ("risk_event", "event_id,sequence,body_json"),
                                   ("risk_legacy", "path,digest"),
                                   ("risk_bucket", "ticker,minute,filled,pending,active_count"),
                                   ("risk_ticker", "ticker,filled,pending,active_count,min_minute,max_minute"),
                                   ("risk_minute", "minute,filled,pending,active_count"),
                                   ("risk_loss", "day,net_pl"),
                                   ("account_risk_archive", "kind,id,body,sequence,day")):
                db.execute(f"SELECT {columns} FROM {table} LIMIT 0")
            return "rows"
        return "unknown"
    if "account_risk" in tables:
        db.execute("SELECT id,body FROM account_risk LIMIT 0")
        return "body"
    return "unknown"


def ledger_format(path):
    """Bounded, read-only format probe; never creates an absent ledger."""
    db = None
    try:
        path = Path(path)
        if not path.exists():
            return "missing"
        db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=0.1)
        budget = 1000

        def bounded():
            nonlocal budget
            budget -= 1
            return int(budget <= 0)

        db.set_progress_handler(bounded, 100)
        db.execute("BEGIN")
        return _ledger_format(db)
    except (sqlite3.Error, OSError, ValueError):
        return "unknown"
    finally:
        if db is not None:
            db.close()


def _json(value):
    return json.dumps(value, separators=(",", ":"), allow_nan=False)


def _corrupt():
    return risk.AccountRiskRefused("risk ledger unavailable or corrupt", code="ledger_corrupt")


def _format(db, *, create=False):
    tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "risk_format" in tables:
        if db.execute("SELECT value FROM risk_format").fetchall() != [("rows-v1",)]:
            raise _corrupt()
        return
    if tables or not create:
        raise risk.AccountRiskRefused("risk ledger identity/schema mismatch", code="ledger_identity")
    for statement in (
        "CREATE TABLE risk_format(id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL)",
        "INSERT INTO risk_format VALUES(1,'rows-v1')",
        "CREATE TABLE account_risk (id INTEGER PRIMARY KEY, body TEXT NOT NULL)",
        f"INSERT INTO account_risk VALUES(1,'{ROWS_POISON_BODY}')",
        *(f"CREATE TRIGGER account_risk_no_{operation.lower()} "
          f"BEFORE {operation} ON account_risk BEGIN "
          "SELECT RAISE(ABORT, 'leafhft ledger is rows-v1; run to-body before using older code'); END"
          for operation in ("INSERT", "UPDATE", "DELETE")),
        "CREATE TABLE risk_account(id INTEGER PRIMARY KEY CHECK(id=1), schema_epoch INTEGER, "
        "revision INTEGER, day TEXT, day_open TEXT, equity TEXT, high_water TEXT, "
        "marked_basis TEXT, fault TEXT, metadata_json TEXT NOT NULL, counters TEXT NOT NULL)",
        "CREATE TABLE risk_entry(client_id TEXT PRIMARY KEY, sequence INTEGER UNIQUE, "
        "hot_order INTEGER UNIQUE, ticker TEXT, minute INTEGER, state TEXT, cost TEXT, reserved TEXT, "
        "probe INTEGER, pd TEXT, pl TEXT, closed_day TEXT, body_bytes INTEGER, body_json TEXT NOT NULL)",
        "CREATE INDEX risk_entry_active ON risk_entry(ticker,minute,state)",
        "CREATE INDEX risk_entry_live ON risk_entry(ticker,minute) WHERE state!='closed'",
        "CREATE INDEX risk_entry_archive ON risk_entry(hot_order,closed_day) WHERE state='closed'",
        "CREATE TABLE risk_event(event_id TEXT PRIMARY KEY, sequence INTEGER UNIQUE, "
        "body_json TEXT NOT NULL, transfer_ns INTEGER, transfer_amount TEXT)",
        "CREATE INDEX risk_event_transfer ON risk_event(transfer_ns,event_id)",
        "CREATE TABLE risk_legacy(path TEXT PRIMARY KEY, digest TEXT NOT NULL)",
        "CREATE TABLE risk_bucket(ticker TEXT, minute INTEGER, filled TEXT, pending TEXT, "
        "active_count INTEGER, PRIMARY KEY(ticker,minute))",
        "CREATE TABLE risk_ticker(ticker TEXT PRIMARY KEY, filled TEXT, pending TEXT, "
        "active_count INTEGER, min_minute INTEGER, max_minute INTEGER)",
        "CREATE TABLE risk_minute(minute INTEGER PRIMARY KEY, filled TEXT, pending TEXT, active_count INTEGER)",
        "CREATE TABLE risk_loss(day TEXT PRIMARY KEY, net_pl TEXT NOT NULL)",
    ):
        db.execute(statement)
    risk._archive_create(db)


def _counters():
    return dict(entries=0, events=0, legacy=0, filled=0, pending=0, probe=0, active=0,
                next_entry=0, next_hot=0, next_event=0, archived=0, archive_legacy=0,
                entry_chars=0, event_chars=0, order_chars=0, closed_chars=0, closed_count=0,
                logical_bytes=0, has_imports=False)


def _entry_chars(counters, cid, body, sequence, closed_day, sign):
    key = len(_json(cid)) + 1
    counters["entry_chars"] += sign * (key + len(body))
    counters["order_chars"] += sign * (key + len(str(sequence)))
    if closed_day is not None:
        counters["closed_chars"] += sign * (key + len(_json(closed_day)))
        counters["closed_count"] += sign


def _object_chars(parts, count):
    return 2 + parts + max(0, count - 1)


def _body_chars(state, counters):
    # Exact legacy JSON character count, without reconstructing retained entries.
    result = len(_json(_metadata(state)))
    for name, chars, count in (("entries", counters["entry_chars"], counters["entries"]),
                               ("events", counters["event_chars"], counters["events"])):
        result += 1 + len(_json(name)) + 1 + _object_chars(chars, count)
    if "legacy_imports" in state:
        result += 1 + len(_json("legacy_imports")) + 1 + len(_json(state["legacy_imports"]))
    if state["version"] == 2:
        meta = dict(count=counters["archived"], legacy_count=counters["archive_legacy"],
                    next=counters["next_entry"], order={}, closed={})
        length = len(_json(meta))
        length += _object_chars(counters["order_chars"], counters["entries"]) - 2
        length += _object_chars(counters["closed_chars"], counters["closed_count"]) - 2
        result += 1 + len(_json(risk._ARCHIVE)) + 1 + length
    return result


class _Rows(MutableMapping):
    """Transaction-local keyed cache. Iteration deliberately exports hot rows only."""

    def __init__(self, db, counters, *, events=False):
        self.db, self.counters, self.events = db, counters, events
        self.cache, self.original, self.info = {}, {}, {}
        self.views = []
        self.table = "risk_event" if events else "risk_entry"
        self.key = "event_id" if events else "client_id"

    def __getitem__(self, key):
        if key in self.cache:
            return self.cache[key]
        if self.events:
            row = self.db.execute("SELECT body_json,sequence FROM risk_event WHERE event_id=?", (key,)).fetchone()
        else:
            row = self.db.execute("SELECT body_json,sequence,hot_order,closed_day FROM risk_entry "
                                  "WHERE client_id=?", (key,)).fetchone()
        cold = False
        if row is None and not self.events:
            archived = self.db.execute("SELECT body,sequence,day FROM account_risk_archive "
                                       "WHERE kind='entry' AND id=?", (key,)).fetchone()
            if archived:
                row = (archived[0], archived[1], None, archived[2])
                cold = True
        if row is None:
            raise KeyError(key)
        self.cache[key] = json.loads(row[0])
        self.original[key] = row[0]
        self.info[key] = (row[1:], cold)
        return self.cache[key]

    def __setitem__(self, key, value):
        if key not in self.cache:
            try:
                self[key]
            except KeyError:
                self.original[key] = None
                counter = "next_event" if self.events else "next_entry"
                sequence = self.counters[counter]
                self.counters[counter] += 1
                if self.events:
                    info = (sequence,)
                else:
                    info = (sequence, self.counters["next_hot"], None)
                    self.counters["next_hot"] += 1
                self.info[key] = (info, False)
        self.cache[key] = value

    def __delitem__(self, key):
        raise TypeError("ledger entries and events are append-only")

    def __iter__(self):
        order = "sequence" if self.events else "hot_order"
        seen = set()
        for (key,) in self.db.execute(f"SELECT {self.key} FROM {self.table} ORDER BY {order}"):
            seen.add(key)
            yield key
        for key in self.cache:
            if key not in seen and self.original[key] is None:
                yield key

    def __reversed__(self):
        return reversed(list(self))

    def __len__(self):
        return self.counters["events" if self.events else "entries"] + sum(
            body is None for body in self.original.values())

    def changed(self):
        return any(_json(value) != self.original[key] for key, value in self.cache.items())


def _adjust(db, table, keys, delta):
    names, values = zip(*keys.items())
    where = " AND ".join(name + "=?" for name in names)
    row = db.execute(f"SELECT filled,pending,active_count FROM {table} WHERE {where}", values).fetchone()
    totals = [int(value) for value in row] if row else [0, 0, 0]
    totals = [a + b for a, b in zip(totals, delta)]
    if totals[2] == 0:
        if totals[:2] != [0, 0]:
            raise _corrupt()
        db.execute(f"DELETE FROM {table} WHERE {where}", values)
    else:
        columns = ",".join(names) + ",filled,pending,active_count"
        marks = ",".join("?" for _ in range(len(names) + 3))
        db.execute(f"INSERT OR REPLACE INTO {table}({columns}) VALUES({marks})",
                   (*values, str(totals[0]), str(totals[1]), totals[2]))


def _contribute(db, counters, cid, entry, sign):
    counters["entries"] += sign
    counters["legacy"] += sign * int(not risk._v2(entry))
    loss = entry.get("pl")
    day = entry.get("pd")
    if type(day) is str and type(loss) is int and -risk._CENTS_MAX <= loss <= risk._CENTS_MAX:
        row = db.execute("SELECT net_pl FROM risk_loss WHERE day=?", (day,)).fetchone()
        total = (int(row[0]) if row else 0) + sign * loss
        db.execute("INSERT OR REPLACE INTO risk_loss VALUES(?,?)", (day, str(total)))
    if entry["state"] == "closed":
        return
    counters["active"] += sign
    cost = entry["cost_cents"]
    pending = cost if entry["state"] == "reserved" else 0
    filled = cost - pending
    counters["filled"] += sign * filled
    counters["pending"] += sign * pending
    counters["probe"] += sign * cost * int(risk._probe_entry(cid, entry))
    delta = (sign * filled, sign * pending, sign)
    _adjust(db, "risk_bucket", dict(ticker=entry["ticker"], minute=entry["minute"]), delta)
    _adjust(db, "risk_ticker", dict(ticker=entry["ticker"]), delta)
    _adjust(db, "risk_minute", dict(minute=entry["minute"]), delta)


def _flush_entries(entries, version):
    db, counters = entries.db, entries.counters
    today = risk._utc_day(risk.time.time_ns())
    changed = False
    tickers = set()
    for cid, entry in entries.cache.items():
        payload = _json(entry)
        original = entries.original[cid]
        if payload == original:
            continue
        changed = True
        (sequence, hot_order, closed_day), cold = entries.info[cid]
        old = json.loads(original) if original is not None else None
        size = len(payload.encode("utf-8"))
        pd = entry.get("pd")
        if cold:
            promote = (entry["state"] != "closed" or size > risk.ARCHIVE_ENTRY_MAX_BYTES
                       or (pd is not None and (type(pd) is not str or pd >= today)))
            if not promote:
                db.execute("UPDATE account_risk_archive SET body=? WHERE kind='entry' AND id=?", (payload, cid))
                counters["archive_legacy"] += int(not risk._v2(entry)) - int(not risk._v2(old))
                continue
            db.execute("DELETE FROM account_risk_archive WHERE kind='entry' AND id=?", (cid,))
            counters["archived"] -= 1
            counters["archive_legacy"] -= int(not risk._v2(old))
            hot_order = counters["next_hot"]
            counters["next_hot"] += 1
        elif old is not None:
            _entry_chars(counters, cid, original, sequence, closed_day, -1)
            _contribute(db, counters, cid, old, -1)
            tickers.add(old["ticker"])
        if version == 2:
            closed_day = (closed_day or today) if entry["state"] == "closed" else None
        _entry_chars(counters, cid, payload, sequence, closed_day, 1)
        _contribute(db, counters, cid, entry, 1)
        tickers.add(entry["ticker"])
        db.execute("INSERT OR REPLACE INTO risk_entry VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (cid, sequence, hot_order, entry["ticker"], entry["minute"], entry["state"],
                    str(entry["cost_cents"]), str(entry["reserved_cents"]), int(risk._probe_entry(cid, entry)),
                    pd, _json(entry.get("pl")), closed_day, size, payload))
    for ticker in tickers:
        bounds = tuple(db.execute("SELECT minute FROM risk_entry WHERE ticker=? AND state!='closed' "
                                  f"ORDER BY minute {order} LIMIT 1", (ticker,)).fetchone()
                       for order in ("ASC", "DESC"))
        bounds = tuple(row[0] if row else None for row in bounds)
        db.execute("UPDATE risk_ticker SET min_minute=?,max_minute=? WHERE ticker=?", (*bounds, ticker))
    return changed


def _archive(db, counters):
    """Indexed hot insertion order retains the body's byte-fitting batch rule.

    Full-export sequence survives promotion; promoted entries append to hot order,
    just as dict insertion does in the current writer. Legacy hashing is untouched.
    """
    today = risk._utc_day(risk.time.time_ns())
    rows = db.execute("SELECT client_id,body_json,sequence,closed_day,body_bytes FROM risk_entry "
                      "INDEXED BY risk_entry_archive WHERE state='closed' AND closed_day<? "
                      "AND body_bytes<=? ORDER BY hot_order", (today, risk.ARCHIVE_ENTRY_MAX_BYTES))
    selected, size = [], 0
    for cid, body, sequence, day, length in rows:
        if len(selected) >= risk.ARCHIVE_BATCH_ENTRIES:
            break
        entry = json.loads(body)
        pd = entry.get("pd")
        if pd is not None and (type(pd) is not str or pd >= today):
            continue
        if size + length > risk.ARCHIVE_BATCH_BYTES:
            continue
        selected.append(("entry", cid, body, sequence, day))
        size += length
    risk._archive_insert(db, selected)
    for _, cid, body, sequence, day in selected:
        entry = json.loads(body)
        _entry_chars(counters, cid, body, sequence, day, -1)
        _contribute(db, counters, cid, entry, -1)
        counters["archived"] += 1
        counters["archive_legacy"] += int(not risk._v2(entry))
        db.execute("DELETE FROM risk_entry WHERE client_id=?", (cid,))


def _metadata(state):
    return {key: value for key, value in state.items()
            if key not in ("entries", "events", "legacy_imports", risk._ARCHIVE)}


def _load(db, empty=None):
    row = db.execute("SELECT metadata_json,counters,schema_epoch FROM risk_account WHERE id=1").fetchone()
    if row is None:
        if empty is None:
            return None
        state, counters = empty, _counters()
    else:
        if row[2] != 1:
            raise _corrupt()
        state, counters = json.loads(row[0]), json.loads(row[1])
    state["entries"] = _Rows(db, counters)
    state["events"] = _Rows(db, counters, events=True)
    imports = dict(db.execute("SELECT path,digest FROM risk_legacy"))
    if imports or counters["has_imports"]:
        state["legacy_imports"] = imports
    if state["version"] == 2:
        state[risk._ARCHIVE] = dict(count=counters["archived"], legacy_count=counters["archive_legacy"])
    return state, counters, row


def _export(db, state, counters, *, hot=False, ticker=None):
    result = _metadata(state)
    if "legacy_imports" in state:
        result["legacy_imports"] = state["legacy_imports"]
    result["events"] = dict(state["events"])
    if state["version"] != 2 or hot:
        result["entries"] = dict(state["entries"])
        if state["version"] == 2:
            result["archive"] = dict(entries=counters["archived"], legacy_entries=counters["archive_legacy"])
            if ticker is not None:
                result["archive"]["ticker_exists"] = db.execute(
                    "SELECT 1 FROM account_risk_archive WHERE kind='entry' "
                    "AND json_extract(body,'$.ticker')=? LIMIT 1", (ticker,)).fetchone() is not None
    else:
        rows = db.execute("SELECT client_id,body_json,sequence FROM risk_entry UNION ALL "
                          "SELECT id,body,sequence FROM account_risk_archive WHERE kind='entry' ORDER BY 3").fetchall()
        if len(rows) != counters["entries"] + counters["archived"]:
            raise _corrupt()
        result["entries"] = {cid: json.loads(body) for cid, body, _ in rows}
        result["version"] = 1
    return json.loads(_json(result))


class RowAccountRiskLedger(risk.AccountRiskLedger):
    """Same account authority and public transitions, with row-backed transactions."""

    def __init__(self, path=None, *, account_id="replay"):
        if not isinstance(account_id, str) or not account_id:
            raise risk.AccountRiskRefused("account identity required", code="input_invalid")
        self.account_id = account_id
        self.path = Path(path) if path is not None else None
        self._memory = None
        self._connections = {}
        self._connection_pid = os.getpid()

    def close(self):
        for record in self._connections.values():
            record["db"].close()
        self._connections.clear()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def _connection(self):
        pid = os.getpid()
        if pid != self._connection_pid:
            self.close()
            self._connection_pid = pid
        key = (pid, threading.current_thread())
        identity = None
        if self.path is not None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            try:
                stat = self.path.stat()
                identity = (stat.st_dev, stat.st_ino)
            except FileNotFoundError:
                pass
        record = self._connections.get(key)
        if record is not None and record["identity"] != identity:
            record["db"].close()
            del self._connections[key]
            record = None
        if record is None:
            for attempt in range(3):
                if self.path is not None:
                    try:
                        stat = self.path.stat()
                        identity = (stat.st_dev, stat.st_ino)
                    except FileNotFoundError:
                        identity = None
                db = sqlite3.connect(str(self.path) if self.path is not None else ":memory:",
                                     timeout=BUSY_TIMEOUT_S, isolation_level=None,
                                     check_same_thread=False)
                try:
                    # Inspect an existing format before changing its journal mode.
                    tables = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' LIMIT 1").fetchone()
                    if tables:
                        _format(db)
                    db.execute("PRAGMA journal_mode=WAL")
                    db.execute("PRAGMA synchronous=FULL")
                    confirmed_identity = None
                    if self.path is not None:
                        try:
                            stat = self.path.stat()
                            confirmed_identity = (stat.st_dev, stat.st_ino)
                        except FileNotFoundError:
                            pass
                    if ((identity is not None and identity != confirmed_identity)
                            or (self.path is not None and confirmed_identity is None)):
                        db.close()
                        continue
                    record = dict(db=db, identity=confirmed_identity)
                    self._connections[key] = record
                    break
                except BaseException:
                    db.close()
                    raise
            else:
                raise _corrupt()
        return record

    @contextmanager
    def _transaction_body(self, active, thread):
        db = None
        stats = self.__dict__.setdefault("tx_stats", dict(n=0, elided=0, wait_ns=0, hold_ns=0, max_wait_ns=0))
        acquired = None
        try:
            record = self._connection()
            db = record["db"]
            stats["n"] += 1
            started = risk._perf_counter_ns()
            try:
                db.execute("BEGIN IMMEDIATE")
            finally:
                waited = risk._perf_counter_ns()
                elapsed = waited - started
                stats["wait_ns"] += elapsed
                stats["max_wait_ns"] = max(stats["max_wait_ns"], elapsed)
            acquired = waited
            _format(db, create=True)
            state, counters, stored = _load(db, self._empty_state())
            self._body_bytes = counters["logical_bytes"]
            if (type(state.get("version")) is not int or state["version"] not in (1, 2)
                    or state.get("account_id") != self.account_id):
                raise risk.AccountRiskRefused("risk ledger identity/schema mismatch", code="ledger_identity")
            revision = state["revision"]
            if type(revision) is not int:
                raise risk.AccountRiskRefused("risk ledger revision not an integer", code="ledger_corrupt")
            before = _json(_metadata(state))
            old_imports = _json(state.get("legacy_imports", {}))
            if risk._RESTORE_MARKER in state:
                audited = _export(db, state, counters)
                risk._audit_restore(audited)
                for field in (risk._RESTORE_MARKER, risk._TRANSFER_INDEX, risk._MARKED_TRANSFERS,
                              risk._MARKED_CENTS, risk._MARKED_NS):
                    if field in audited:
                        state[field] = audited[field]
                    else:
                        state.pop(field, None)
            yield state
            if active[thread]:
                raise risk.AccountRiskRefused("risk ledger transaction re-entered", code="input_invalid")
            entries, events = state["entries"], state["events"]
            changed = (stored is None or before != _json(_metadata(state)) or entries.changed()
                       or events.changed() or old_imports != _json(state.get("legacy_imports", {})))
            if changed:
                _flush_entries(entries, state["version"])
                for key, event in events.cache.items():
                    payload = _json(event)
                    if payload == events.original[key]:
                        continue
                    moved = risk._transfer_value(event) if key.startswith(risk._TRANSFER_PREFIX) else None
                    db.execute("INSERT OR REPLACE INTO risk_event VALUES(?,?,?,?,?)",
                               (key, events.info[key][0][0], payload,
                                moved[1] if moved else None, str(moved[0]) if moved else None))
                    counters["events"] += int(events.original[key] is None)
                    if events.original[key] is None:
                        counters["event_chars"] += len(_json(key)) + 1 + len(payload)
                    else:
                        counters["event_chars"] += len(payload) - len(events.original[key])
                if state["version"] == 2:
                    today = risk._utc_day(risk.time.time_ns())
                    for (cid,) in db.execute("SELECT client_id FROM risk_entry "
                                             "WHERE state='closed' AND closed_day IS NULL"):
                        counters["closed_chars"] += len(_json(cid)) + 1 + len(_json(today))
                        counters["closed_count"] += 1
                    db.execute("UPDATE risk_entry SET closed_day=? WHERE state='closed' AND closed_day IS NULL",
                               (today,))
                    _archive(db, counters)
                if stored is not None and state["revision"] <= revision:
                    state["revision"] = revision + 1
                if type(state["revision"]) is not int:
                    raise risk.AccountRiskRefused("risk ledger revision not an integer", code="ledger_corrupt")
                for path, digest in state.get("legacy_imports", {}).items():
                    db.execute("INSERT OR REPLACE INTO risk_legacy VALUES(?,?)", (path, digest))
                counters["has_imports"] = "legacy_imports" in state
                payload = _json(_metadata(state))
                counters["logical_bytes"] = _body_chars(state, counters)
                db.execute("INSERT OR REPLACE INTO risk_account VALUES(1,?,?,?,?,?,?,?,?,?,?)",
                           (1, state["revision"], state["day"], str(state["day_open_cents"]),
                            str(state["equity_cents"]), str(state["high_water_cents"]),
                            _json([state.get(risk._MARKED_CENTS), state.get(risk._MARKED_NS)]),
                            state["fault"], payload, _json(counters)))
            # Reopen caches after writes: snapshot views include archive maintenance.
            fresh, counts, _ = _load(db)
            for hot, ticker, view in entries.views:
                view.update(_export(db, fresh, counts, hot=hot, ticker=ticker))
            db.execute("COMMIT" if changed else "ROLLBACK")
            self._body_bytes = counters["logical_bytes"]
            if not changed:
                stats["elided"] += 1
        except (sqlite3.Error, ValueError, KeyError, TypeError) as exc:
            if db is not None and db.in_transaction:
                db.execute("ROLLBACK")
            raise _corrupt() from exc
        except BaseException:
            if db is not None and db.in_transaction:
                db.execute("ROLLBACK")
            raise
        finally:
            if acquired is not None:
                stats["hold_ns"] += risk._perf_counter_ns() - acquired

    def snapshot(self, *, hot=False, ticker=None):
        result = {}
        with self._transaction() as state:
            state["entries"].views.append((hot, ticker, result))
        return result

    def read_snapshot(self, *, hot=False, ticker=None):
        if self.path is None:
            return self.snapshot(hot=hot, ticker=ticker)
        if not self.path.exists():
            return None
        db = None
        try:
            db = risk._connect_ro(self.path)
            db.execute("BEGIN")
            _format(db)
            loaded = _load(db)
            if loaded is None:
                return self._empty_state()
            state, counters, _ = loaded
            if type(state.get("version")) is not int or state["version"] not in (1, 2) or state.get("account_id") != self.account_id:
                raise risk.AccountRiskRefused("risk ledger identity/schema mismatch", code="ledger_identity")
            return _export(db, state, counters, hot=hot, ticker=ticker)
        except sqlite3.OperationalError:
            if db is not None:
                db.close()
                db = None
            return self.snapshot(hot=hot, ticker=ticker)
        except (sqlite3.Error, ValueError, KeyError, TypeError) as exc:
            raise _corrupt() from exc
        finally:
            if db is not None:
                db.close()

    def enable_archive(self):
        """The dark harness's explicit equivalent of compaction's v2 conversion."""
        with self._transaction() as state:
            state["version"] = 2

    @staticmethod
    def _admission_rows(state, positions, unknown, now_ns):
        entries = state["entries"]
        db, counters = entries.db, entries.counters
        filled, pending = {}, {}
        active = 0
        failures = []
        # Work is proportional to active buckets, never retained closed history.
        # The eager unknown-minute repair additionally costs O(R) row writes.
        for ticker, stored_minute, f, p, count in db.execute(
                "SELECT ticker,minute,filled,pending,active_count FROM risk_bucket"):
            if count <= 0:
                raise _corrupt()
            active += count
            if ticker in unknown:
                minute = None
            else:
                minute = positions.get(ticker, (stored_minute, 0))[0]
                if type(minute) is not int or minute < 0:
                    message = "open exposure settlement minute requires reconciliation"
                elif stored_minute >= 0 and minute != stored_minute:
                    message = "position settlement minute changed"
                else:
                    message = None
                if message is not None:
                    first = db.execute("SELECT MIN(hot_order) FROM risk_entry WHERE ticker=? "
                                       "AND minute=? AND state!='closed'", (ticker, stored_minute)).fetchone()[0]
                    failures.append((first, message))
                    continue
                if stored_minute < 0:
                    for (cid,) in db.execute("SELECT client_id FROM risk_entry WHERE ticker=? "
                                             "AND minute=? AND state!='closed' ORDER BY hot_order",
                                             (ticker, stored_minute)):
                        entries[cid]["minute"] = minute
            key = (ticker, minute)
            filled[key] = filled.get(key, 0) + int(f)
            pending[key] = pending.get(key, 0) + int(p)
        if failures:
            raise risk.AccountRiskRefused(min(failures)[1], code="settlement_minute_reconcile")
        if (sum(filled.values()) != counters["filled"] or sum(pending.values()) != counters["pending"]
                or active != counters["active"]):
            raise _corrupt()
        loss = db.execute("SELECT net_pl FROM risk_loss WHERE day=?", (risk._utc_day(now_ns),)).fetchone()
        return (filled, pending, counters["legacy"] + counters["archive_legacy"],
                counters["probe"], max(0, int(loss[0]) if loss else 0))

    def _reserve(self, stats, client_id, ticker, settlement_minute, requested_cents, *,
                 cash_cents, open_cost_cents, policy, now_ns, positions, expected_revision,
                 resize, brake_trim, provenance, prepared, mode, admission, unknown_minute, widened, marked,
                 headroom=None, probe=None, account_policy=None, drawdown_policy=None):
        for value in (requested_cents, cash_cents, open_cost_cents):
            risk._cents(value)
        headroom = risk._headroom_inputs(headroom, expected_revision)
        if marked[0] is None and marked[1] is not None:
            stats["marked_reason"] = "marked_missing"
        marked = risk._marked_inputs(*marked)
        if not requested_cents or not isinstance(client_id, str) or not client_id:
            raise risk.AccountRiskRefused("invalid risk reservation", code="input_invalid")
        if probe is not None and type(probe) is not bool:
            raise risk.AccountRiskRefused("invalid probe classification", code="input_invalid")
        # RC2: the caller's classification, else the id's prefix (every pre-RC2 caller).
        is_probe = client_id.startswith(risk.PROBE_CLIENT_PREFIX) if probe is None else probe
        stats["probe"] = is_probe
        fraction, stats["probe_reserve_reason"] = risk._reserve_fraction(account_policy)
        if probe is True and fraction is None:
            stats["binding"] = "daily loss"
            stats["probe_ceiling_bound"] = True
            raise risk.AccountRiskRefused("probe ceiling unavailable: " + stats["probe_reserve_reason"],
                                     code="daily_loss", detail={
                                         "binding_term": "probe_ceiling_unavailable",
                                         "binding_request_cents": requested_cents})
        if not isinstance(ticker, str) or not ticker or type(settlement_minute) is not int or settlement_minute < 0:
            raise risk.AccountRiskRefused("market settlement minute required", code="input_invalid")
        now_ns = risk.time.time_ns() if now_ns is None else now_ns
        positions = positions or {}
        provenance = risk._provenance_inputs(*provenance)
        admission, unknown = risk._ticker_inputs(mode, admission, unknown_minute, widened, positions, ticker)
        with self._transaction() as state:
            if expected_revision is not None and state["revision"] != expected_revision:
                raise risk.AccountRiskRefused("account changed during risk read", code="revision_conflict")
            if client_id in state["entries"]:
                raise risk.AccountRiskRefused("risk client id already reserved", code="duplicate_client_id")
            if state["fault"]:
                raise risk.AccountRiskRefused(state["fault"], code="ledger_fault")
            equity = cash_cents + open_cost_cents
            if widened:
                day_open, high = self._scratch_basis(state, equity, now_ns)
            else:
                self._basis(state, equity, now_ns, client_id=client_id, cash_cents=cash_cents,
                            open_cost_cents=open_cost_cents, record=provenance is not None or mode != "legacy")
                day_open, high = state["day_open_cents"], state["high_water_cents"]
            marked_open = None
            if marked is not None:
                marked_open, reason = self._marked_basis(state, marked[1], now_ns, widened, marked[0])
                if reason is not None:
                    stats["marked_reason"] = reason
                    # Journal the fallback once per UTC day: the first observation's instants.
                    journal = reason + ":" + risk._utc_day(now_ns)
                    if journal not in state["events"]:
                        risk._append_event(state, journal, [marked[1], now_ns])
            filled, pending, legacy_entries, probe_at_risk, probe_realized = self._admission_rows(
                state, positions, unknown, now_ns)
            for market, (minute, cost) in positions.items():
                risk._cents(cost)
                if type(minute) is not int or minute < 0:
                    raise risk.AccountRiskRefused("position settlement minute required", code="input_invalid")
                key = (market, minute)
                filled[key] = max(filled.get(key, 0), cost)
            exposure = dict(filled)
            consumption = 0
            for key, cost in admission.items():
                # Admission is a charge only: max(ledger, venue cost, admission), never valuation.
                if cost > exposure.get(key, 0):
                    consumption += cost - exposure.get(key, 0)
                    exposure[key] = cost
            for key, cost in pending.items():
                exposure[key] = exposure.get(key, 0) + cost
            market_cost = sum(cost for (market, _), cost in exposure.items() if market == ticker)
            # An unknown-minute key (minute None) counts toward every window.
            window_cost = sum(cost for (_, minute), cost in exposure.items()
                              if minute == settlement_minute or minute is None)
            # T2-v4 R2: the parent's stated capacity, bound to this revision above; zeros when unset.
            head_market, head_window, head_total = headroom if headroom is not None else (0, 0, 0)
            cluster_room = risk.entry_risk_room(equity, market_cost + head_market, window_cost + head_window, policy)
            day_loss = max(0, day_open - equity)
            at_risk = sum(exposure.values())
            loss_fraction = min(policy.daily_loss_fraction, risk.hard_maxima().get("daily_loss_fraction", 1.0))
            paid_room = int(day_open * loss_fraction) - day_loss - at_risk - head_total
            cash_room = cash_cents - sum(pending.values()) - policy.cash_floor_cents - head_total
            marked_room = None
            if marked_open is not None:
                # D5a: net loss since the marked day start (realized plus open mark), against the
                # same fraction of that start; open and pending exposure stay at risk as in the
                # paid term.
                marked_loss = max(0, marked_open - marked[0])
                marked_room = int(marked_open * loss_fraction) - marked_loss - at_risk - head_total
                stats["marked_room_cents"], stats["marked_loss_cents"] = marked_room, marked_loss
            drawdown_fractions = (policy.drawdown_brake_fraction, policy.drawdown_stop_fraction)
            if is_probe and fraction is not None and headroom is None:
                if drawdown_policy is risk.DRAWDOWN_POLICY_UNAVAILABLE:
                    stats["binding"] = "drawdown stop"
                    raise risk.AccountRiskRefused("probe drawdown policy unavailable", code="drawdown_stop",
                                             detail={"binding_term": "drawdown_policy_unavailable",
                                                     "binding_request_cents": requested_cents})
                adopted_fractions = risk._drawdown_fractions(drawdown_policy)
                if adopted_fractions is not None:
                    drawdown_fractions = (min(adopted_fractions[0], risk.PROBE_DRAWDOWN_BRAKE_MAX),
                                          min(adopted_fractions[1], risk.PROBE_DRAWDOWN_STOP_MAX))
            brake_fraction = min(drawdown_fractions[0], risk.hard_maxima().get("drawdown_brake_fraction", 1.0))
            stop_fraction = min(drawdown_fractions[1], risk.hard_maxima().get("drawdown_stop_fraction", 1.0))
            if is_probe:
                stats["probe_drawdown_fractions"] = [brake_fraction, stop_fraction]
            brake_room = None
            if high and (high - equity) / high >= brake_fraction:
                brake_room = risk.entry_risk_room(equity, market_cost, window_cost, policy) // 2
                if headroom is not None:
                    # A later plain caller's brake room is half of what this reservation leaves, so it
                    # keeps its full capacity only when twice the market and window headroom survive.
                    brake_room = min(brake_room, risk.entry_risk_room(
                        equity, market_cost + 2 * head_market, window_cost + 2 * head_window, policy))
            # Observed drawdown stops new admission; it does not cap existing exposure's later losses.
            stop = high and (high - equity) / high >= stop_fraction
            # RC2: each daily-loss term's probe slice from its own base and the account fraction;
            # integer cents and Decimal only (risk._probe_reserve), never float.
            paid_reserve = risk._probe_reserve(day_open, fraction)
            marked_reserve = risk._probe_reserve(marked_open, fraction) if marked_room is not None else 0
            probe_used = probe_at_risk + probe_realized
            paid_cut = marked_cut = 0
            if is_probe:
                # Legacy/headroom ceiling arithmetic: never above today's term, and a term
                # with no reserve stays today's. The own-budget path below replaces these terms.
                if paid_reserve:
                    paid_cut = max(0, paid_room - (paid_reserve - probe_used))
                if marked_reserve:
                    marked_cut = max(0, marked_room - (marked_reserve - probe_used))
            else:
                # An incumbent may not use the part of the slice probes can still use; a probe's
                # own exposure already sits in at_risk, so it is never counted twice.
                paid_cut = max(0, paid_reserve - probe_used)
                marked_cut = max(0, marked_reserve - probe_used)
            own_budget = is_probe and fraction is not None and headroom is None
            # At every probe admission U + admitted_cost <= S: U includes open and pending
            # probe exposure (including yesterday's) plus max(0, net realized loss today).
            # A shrinking base with S < U refuses further probes; nothing is force-closed.
            # Incumbents retain the account term less the unused slice, so total daily loss
            # is bounded by the account term as seen by incumbents plus S.
            # restore()/legacy import retain supplied tags: untagged non-lp- entries count
            # as incumbents. Fresh reservations, retry/reversal legs and probe adopts are tagged.
            paid_term = paid_reserve - probe_used if own_budget else paid_room - paid_cut
            marked_term = None if own_budget or marked_room is None else marked_room - marked_cut
            room, binding = risk._binding_room(cluster_room, paid_term, cash_room,
                                          marked_term,
                                          brake_room, stop)
            # Bound only when the slice alone refuses or trims: the same request with no cut admits in full.
            cut_bound = bool(paid_cut or marked_cut) and room < requested_cents and requested_cents <= (
                risk._binding_room(cluster_room, paid_room, cash_room, marked_room, brake_room, stop)[0])
            stats.update(probe_reserve_cents=0 if is_probe else paid_cut,
                         probe_reserve_marked_cents=0 if is_probe else marked_cut,
                         probe_at_risk_cents=probe_at_risk, probe_realized_loss_today_cents=probe_realized,
                         probe_reserve_bound=cut_bound and not is_probe,
                         probe_ceiling_bound=(binding == "daily loss" if own_budget else cut_bound and is_probe))
            if is_probe:
                stats.update(paid_room_cents=paid_room, probe_budget_cents=paid_reserve)
            if binding == "per-order/cluster":
                # risk.entry_risk_room = max(0, min(a, b)); the tie goes to the ticker cap.
                market_cap, window_cap = risk.entry_risk_caps(equity, policy)
                code = "ticker_cap" if market_cap - market_cost <= window_cap - window_cost else "window"
            else:
                code = risk._BINDING_CODES[binding]
            allowed = max(0, min(requested_cents, room))
            if headroom is not None and allowed < requested_cents:
                # Whole or nothing, whatever resize says; raised inside the transaction so it writes nothing.
                stats.update(binding=binding, admission_consumption_cents=consumption,
                             entries=len(state["entries"]) + state.get(risk._ARCHIVE, {}).get("count", 0), legacy_entries=legacy_entries,
                             revision=state["revision"])
                raise risk.AccountRiskRefused(
                    "t2cal headroom: " + binding + f" room={room}c requested={requested_cents}c"
                    f" headroom={head_market},{head_window},{head_total}c", code="t2cal_headroom")
            refused = allowed < requested_cents and not (resize or (brake_trim and binding == "drawdown brake"))
            if refused:
                allowed = 0
            if allowed:
                entry = {
                    "ticker": ticker, "minute": settlement_minute, "cost_cents": allowed,
                    "reserved_cents": allowed, "state": "reserved", "equity_cents": equity}
                if provenance is not None:
                    entry["p"] = risk._provenance(
                        provenance, risk.admitted_count(provenance[1], requested_cents, allowed, prepared=prepared),
                        now_ns)
                else:
                    legacy_entries += 1
                if is_probe:
                    entry["pr"] = 1  # RC2: additive; old readers check only the core fields
                elif client_id.startswith(risk.PROBE_CLIENT_PREFIX):
                    entry["pr"] = 0  # an explicit incumbent classification outranks the prefix
                state["entries"][client_id] = entry
            state["revision"] += 1
            stats.update(binding=binding, admission_consumption_cents=consumption,
                         entries=len(state["entries"]) + state.get(risk._ARCHIVE, {}).get("count", 0), legacy_entries=legacy_entries,
                         revision=state["revision"])
        if refused:
            detail = None
            if code in ("daily_loss", "ticker_cap", "drawdown_brake", "drawdown_stop"):
                term = code
                if binding in ("daily loss", "marked daily loss"):
                    cut = paid_cut if binding == "daily loss" else marked_cut
                    term = ("probe_ceiling" if is_probe else "probe_slice") if cut > 0 else (
                        "account_paid" if binding == "daily loss" else "account_marked")
                    if own_budget and binding == "daily loss":
                        term = "probe_ceiling"
                detail = {"binding_term": term, "binding_room_cents": room,
                          "binding_request_cents": requested_cents}
            raise risk.AccountRiskRefused("account market/window/loss risk cap: " + binding +
                                     f" room={room}c requested={requested_cents}c", code=code,
                                     detail=detail)
        return allowed


class FormatAwareVerifiedAccountRiskLedger(risk.VerifiedAccountRiskLedger):
    """Compatibility name for the format-aware principal-bound writer."""


def _verify_restored_rows(db):
    """Recompute materialized totals from entry bodies before accepting a backup."""
    _format(db)
    loaded = _load(db)
    if loaded is None:
        raise _corrupt()
    state, counters, _ = loaded
    if (type(state.get("version")) is not int or state["version"] not in (1, 2)
            or type(state.get("account_id")) is not str or not state["account_id"]):
        raise _corrupt()
    exported = _export(db, state, counters)
    if (exported.get("version") != 1 or not exported.get("account_id")
            or risk._ledger_structure_error(exported) is not None):
        raise _corrupt()
    scratch = sqlite3.connect(":memory:")
    try:
        _format(scratch, create=True)
        computed = _counters()
        bounds = {}
        for row in db.execute("SELECT * FROM risk_entry"):
            (cid, sequence, hot_order, ticker, minute, status, cost, reserved,
             probe, pd, pl, closed_day, size, body) = row
            entry = json.loads(body)
            if ((ticker, minute, status, cost, reserved, probe, pd, pl, size) !=
                    (entry["ticker"], entry["minute"], entry["state"], str(entry["cost_cents"]),
                     str(entry["reserved_cents"]), int(risk._probe_entry(cid, entry)),
                     entry.get("pd"), _json(entry.get("pl")), len(body.encode("utf-8")))
                    or type(sequence) is not int or not 0 <= sequence < counters["next_entry"]
                    or type(hot_order) is not int or not 0 <= hot_order < counters["next_hot"]):
                raise _corrupt()
            _contribute(scratch, computed, cid, entry, 1)
            _entry_chars(computed, cid, body, sequence, closed_day, 1)
            if status != "closed":
                low, high = bounds.get(ticker, (minute, minute))
                bounds[ticker] = (min(low, minute), max(high, minute))
        for ticker, (low, high) in bounds.items():
            scratch.execute("UPDATE risk_ticker SET min_minute=?,max_minute=? WHERE ticker=?",
                            (low, high, ticker))
        for table in ("risk_bucket", "risk_ticker", "risk_minute", "risk_loss"):
            actual = set(db.execute(f"SELECT * FROM {table}"))
            expected = set(scratch.execute(f"SELECT * FROM {table}"))
            if table == "risk_loss":
                actual = {row for row in actual if int(row[1])}
                expected = {row for row in expected if int(row[1])}
            if actual != expected:
                raise _corrupt()
        for key, sequence, body, at_ns, amount in db.execute("SELECT * FROM risk_event"):
            event = json.loads(body)
            moved = risk._transfer_value(event) if key.startswith(risk._TRANSFER_PREFIX) else None
            if ((at_ns, amount) != (moved[1] if moved else None, str(moved[0]) if moved else None)
                    or type(sequence) is not int or not 0 <= sequence < counters["next_event"]):
                raise _corrupt()
            computed["events"] += 1
            computed["event_chars"] += len(_json(key)) + 1 + len(body)
        for kind, cid, body, sequence, day in db.execute("SELECT * FROM account_risk_archive"):
            if (kind != "entry" or type(sequence) is not int
                    or not 0 <= sequence < counters["next_entry"]):
                raise _corrupt()
            computed["archived"] += 1
            computed["archive_legacy"] += int(not risk._v2(json.loads(body)))
        if len(exported["entries"]) != computed["entries"] + computed["archived"]:
            raise _corrupt()
        for name in ("entries", "events", "legacy", "filled", "pending", "probe", "active",
                     "archived", "archive_legacy", "entry_chars", "event_chars", "order_chars",
                     "closed_chars", "closed_count"):
            if type(counters[name]) is not int or counters[name] != computed[name]:
                raise _corrupt()
        if counters["logical_bytes"] != _body_chars(state, counters):
            raise _corrupt()
        mirrored = db.execute("SELECT schema_epoch,revision,day,day_open,equity,high_water,"
                              "marked_basis,fault FROM risk_account WHERE id=1").fetchone()
        if mirrored != (1, state["revision"], state["day"], str(state["day_open_cents"]),
                        str(state["equity_cents"]), str(state["high_water_cents"]),
                        _json([state.get(risk._MARKED_CENTS), state.get(risk._MARKED_NS)]), state["fault"]):
            raise _corrupt()
    finally:
        scratch.close()


def restore_rows_ledger(backup_path, dest_path, *, account_id, note):
    """Restore a stopped account ledger with a fresh revision and writer audit marker."""
    if type(account_id) is not str or not account_id:
        raise risk.AccountRiskRefused("account identity required", code="input_invalid")
    if type(note) is not str or not 1 <= len(note) <= 200:
        raise risk.AccountRiskRefused("restore_marker note must be text of 1..200 characters",
                                      code="input_invalid")
    backup_path, dest_path = Path(backup_path), Path(dest_path)
    if backup_path.resolve() == dest_path.resolve():
        raise risk.AccountRiskRefused("restore source equals destination", code="input_invalid")
    for path in (backup_path, dest_path):
        if ledger_format(path) == "body":
            raise risk.AccountRiskRefused("rows restore refuses body ledger", code="ledger_format_body")
    source = dest = None
    try:
        source = sqlite3.connect(backup_path.resolve().as_uri() + "?mode=rw", uri=True,
                                 timeout=2, isolation_level=None)
        source.execute("BEGIN EXCLUSIVE")
        version = _load(source)[0].get("version")
        if type(version) is not int or version not in (1, 2):
            raise risk.AccountRiskRefused("restore account identity mismatch", code="ledger_identity")
        _verify_restored_rows(source)
        source_state, _, _ = _load(source)
        if source_state["account_id"] != account_id:
            raise risk.AccountRiskRefused("restore account identity mismatch", code="ledger_identity")
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        existing = dest_path.exists()
        dest = sqlite3.connect(str(dest_path), timeout=0, isolation_level=None)
        dest.execute("PRAGMA synchronous=FULL")
        try:
            dest.execute("BEGIN EXCLUSIVE")
        except sqlite3.OperationalError as exc:
            raise risk.AccountRiskRefused("risk ledger restore lock unavailable",
                                          code="ledger_corrupt") from exc
        if _ledger_format(dest) == "body":
            raise risk.AccountRiskRefused("rows restore refuses body ledger", code="ledger_format_body")
        _format(dest, create=True)
        current = _load(dest)
        if ((existing and current is None)
                or (current is not None and current[0].get("account_id") != account_id)):
            raise risk.AccountRiskRefused("restore account identity mismatch", code="ledger_identity")
        revision = current[0]["revision"] if current is not None else 0
        if type(revision) is not int or revision < 0:
            raise _corrupt()
        for table in _ROW_TABLES:
            dest.execute(f"DELETE FROM {table}")
            cursor = source.execute(f"SELECT * FROM {table}")
            marks = ",".join("?" for _ in cursor.description)
            while batch := cursor.fetchmany(128):
                dest.executemany(f"INSERT INTO {table} VALUES({marks})", batch)
        state, counters, _ = _load(dest)
        state["revision"] = max(revision, source_state["revision"]) + 1
        state[risk._RESTORE_MARKER] = note
        counters["logical_bytes"] = _body_chars(state, counters)
        dest.execute("UPDATE risk_account SET revision=?,metadata_json=?,counters=? WHERE id=1",
                     (state["revision"], _json(_metadata(state)), _json(counters)))
        _verify_restored_rows(dest)
        dest.execute("COMMIT")
    except (sqlite3.Error, OSError, ValueError, KeyError, TypeError, RecursionError) as exc:
        raise _corrupt() from exc
    finally:
        if dest is not None:
            if dest.in_transaction:
                dest.execute("ROLLBACK")
            dest.close()
        if source is not None:
            source.close()


def _export_bounds(db, max_bytes, max_entries):
    """Check stored character lengths before JSON; do not trust cached counters."""
    if max_bytes is not None:
        row = db.execute("SELECT length(CAST(counters AS BLOB)) FROM risk_account WHERE id=1").fetchone()
        if row is not None and row[0] > max(4096, max_bytes):
            raise ValueError("ledger counters bound exceeded")
    size = count = 0
    for table, columns in (("risk_account", "metadata_json"),
                           ("risk_entry", "client_id,body_json"),
                           ("risk_event", "event_id,body_json"),
                           ("risk_legacy", "path,digest"),
                           ("account_risk_archive", "id,body")):
        lengths = "+".join(f"length({column})" for column in columns.split(","))
        n, length = db.execute(f"SELECT count(*),coalesce(sum({lengths}),0) FROM {table}").fetchone()
        size += length
        if table in ("risk_entry", "account_risk_archive"):
            count += n
        if (max_bytes is not None and size > max_bytes
                or max_entries is not None and count > max_entries):
            raise ValueError("ledger export bound exceeded")


def read_rows_ledger(path, expected_account_id=None, *, legacy_paths=(), hot=False, ticker=None,
                     max_bytes=None, max_entries=None):
    """Read one row-store snapshot, with the body auditor's statuses and precedence.

    max_bytes retains its API name but bounds JSON characters, like the body auditor.
    """
    path = Path(path)
    result = {"status": "missing", "state": None, "legacy_import": "none", "healthy": False,
              "reason": None}
    if not path.exists():
        return result
    db = None
    try:
        db = risk._connect_ro(path)
        db.execute("BEGIN")
        _format(db)
        if max_bytes is not None or max_entries is not None:
            deadline = risk.time.monotonic() + 2
            db.set_progress_handler(lambda: int(risk.time.monotonic() >= deadline), 1000)
            _export_bounds(db, max_bytes, max_entries)
        loaded = _load(db)
        body = None if loaded is None else _json(_export(
            db, loaded[0], loaded[1], hot=hot, ticker=ticker))
        if body is not None and max_bytes is not None and len(body) > max_bytes:
            raise ValueError("ledger export bound exceeded")
    except risk.AccountRiskRefused as exc:
        result.update(status="corrupt", reason=str(exc))
        return result
    except sqlite3.OperationalError:
        result["status"] = "unreadable"
        return result
    except (sqlite3.Error, ValueError, KeyError, TypeError, RecursionError):
        result["status"] = "corrupt"
        return result
    finally:
        if db is not None:
            db.close()
    if body is None:
        result["status"] = "empty"
        return result
    try:
        state = json.loads(body)
    except (ValueError, TypeError, RecursionError):
        result.update(status="corrupt", reason="body is not JSON")
        return result
    if type(state) is not dict:
        result.update(status="corrupt", reason="body is not an object")
        return result
    version = state.get("version")
    if type(version) is not int:
        result.update(status="corrupt", reason="version missing or not an integer")
        return result
    if version not in (1, 2):
        result.update(status="corrupt", reason=f"unsupported version {risk._int_text(version)}")
        return result
    account_id = state.get("account_id")
    if type(account_id) is not str or not account_id:
        result.update(status="corrupt", reason="account_id missing or not text")
        return result
    if expected_account_id is not None and account_id != expected_account_id:
        result["status"] = "identity_mismatch"
        return result
    reason = risk._ledger_structure_error(state)
    if reason is not None:
        result.update(status="corrupt", reason=reason)
        return result
    imported = state.get("legacy_imports", {})
    verdicts = set()
    candidates = {str(Path(p).resolve()) for p in legacy_paths if Path(p).resolve() != path.resolve()}
    for key in sorted(candidates | set(imported)):
        legacy = Path(key)
        try:
            if not legacy.exists():
                continue
            legacy_body = risk._read_body_ro(legacy)
        except (sqlite3.Error, OSError, ValueError):
            verdicts.add("unreadable")
            continue
        if legacy_body is not None and not isinstance(legacy_body, str):
            verdicts.add("unreadable")
            continue
        if key not in imported:
            verdicts.add("pending")
        elif legacy_body is None or hashlib.sha256(legacy_body.encode()).hexdigest() != imported[key]:
            verdicts.add("changed")
        else:
            verdicts.add("current")
    for verdict in ("changed", "unreadable", "pending", "current"):
        if verdict in verdicts:
            result["legacy_import"] = verdict
            break
    result.update(status="ok", state=state,
                  healthy=result["legacy_import"] in ("none", "current"))
    return result
