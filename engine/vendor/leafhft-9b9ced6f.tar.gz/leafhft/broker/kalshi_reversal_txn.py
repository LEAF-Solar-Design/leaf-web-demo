"""H2a2: the cashout-first (reversal_execution_mode 2) two-leg reversal transaction.

States: EXIT_PENDING -> EXIT_PARTIAL -> HEDGE_PENDING -> HEDGE_SUBMITTED -> COMPLETE, with the
terminals FLAT_NO_HEDGE (the original is flat, no hedge filled), UNKNOWN_EXIT and UNKNOWN_HEDGE,
plus EXIT_INCOMPLETE (the exit leg ended with original quantity still held, so no hedge was ever
sent and the remainder stays an ordinary ticket).

Contract:
- The exit leg is the caller's reduce-only KalshiBook.exit() with a PREDETERMINED lx- client id
  derived from the transaction id and the attempt number, so a restart finds it on the venue by id.
  At most MAX_EXIT_ATTEMPTS ids exist per transaction, and each is sent at most once.
- No hedge is sent while any original quantity remains.
- The hedge leg r' <= r goes through the caller's COMPLETE normal entry pipeline (the
  authority-wrapped book.buy with every runner gate). This module never holds a venue client:
  every send and every venue read is a function the caller passes in.
- Write-ahead: every transition is one fsync'd JSON line in a bounded journal, written BEFORE the
  send it authorizes. A journal write that fails before a send refuses that send.
- An UNKNOWN_* terminal, and any transaction still in flight, holds its market: blocked_markets()
  names it and begin() refuses it until reconcile() (UNKNOWN_*) or resume() (in flight)
  identifies the legs from venue truth, or an operator releases an UNKNOWN_* through
  clear_unknown() with an existing, parseable receipt file naming the transaction and the
  operator's decision AND an approval id that resolves in the root-only approvals store and is
  consumed there (CLEARED); anything short refuses clear_unauthorized. The hold is the
  journal's, so it survives restarts and turns. reconcile() and clear_unknown() never send.
- Every order the transaction submits (each exit attempt and the hedge, with its one zero-fill
  retry) carries a VENUE-SIDE expiry, expiration_ts = submit time + ORDER_TTL_S (unix seconds),
  journaled write-ahead in the row that authorizes the send: the venue neither accepts nor
  rests the order after it. On the wire it is a good-till-time LIMIT order, never an IOC:
  time_in_force good_till_canceled plus expiration_time, the only combination Kalshi's Create
  Order (V2) documents for an expiring order (IOC with an expiry is rejected; the quoted
  semantics sit beside kalshi_live._order_body). Such an order may rest until its expiry; a
  send whose reply still shows contracts remaining is UNKNOWN and is settled from order status.
- Restart (resume) rebuilds both legs from venue ORDER STATUS by predetermined client id AND venue
  fills plus the journal, never from memory. A leg is known only when every id it could have sent
  is positively resolved by its status (a terminal IOC with nothing remaining) and its fills sum
  to exactly that status's fill count. An empty or lagging fills page is no information, never
  zero: the in-flight exit lands in UNKNOWN_EXIT, and no further exit id is allocated until the
  last one resolves as not (fully) filled. An unreadable venue is not a zero either: resume
  raises and leaves the state untouched.
- "No such order" is NOT final while the order could still be accepted late. It becomes a
  confirmed zero only when ALL hold: (a) the venue says not found by id, (b) that reply's VENUE
  timestamp (venue_ts, from the venue's response, never the local clock) is past the id's
  journaled expiration_ts plus EXPIRY_SKEW_S, and (c) the fills read after it carries no fill
  for the id. A position read never establishes non-execution (a flat position after
  settlement looks exactly like a never-filled order); fills by client id are the only evidence
  of a fill count. Anything short keeps the leg UNKNOWN (original_may_still_execute): no
  replacement exit id is allocated, no hedge reservation is released and every send on the
  market is refused. The same rule guards both legs, in resume() and reconcile(). It never
  applies to a leg whose primary id is fully resolved (terminal status, nothing remaining, and
  fills by that client id equal to the leg's whole count): that is checked first, so an unused
  retry id needs no venue timestamp. KalshiLive's not-found reply carries none (the venue's
  order listing has no server time), so without a full primary fill a not-found id stays
  UNKNOWN until the venue resolves it or the operator's approval-gated clear, never a timer.
- Budget: the hedge is claimed through ReversalBudget.claim_hedge, which counts it only after the
  exit leg is COMPLETE (or PARTIAL) with the freed cash known. The claim is the caller's buy
  pipeline MAXIMUM debit for the count (max_debit: price buffer and fees included). Its ceiling
  is min(budget caps, the freed cash the journal records for the exit leg, free cash): above
  either cash figure the hedge is refused here, and the budget refuses above the freed cash too.
- Latency: every row carries exit_leg_ns and hedge_leg_ns (monotonic send durations) so H2a3 can
  measure mode 2's cost on the tape before any live enablement.

C13 boundary (a documented precondition, not enforced here): lifecycle-managed exits are skipped
by cli.py, and H2a3 wires this mode into cli.py. Every entry point takes the mode and the caller's
send functions as parameters; modes None and 1 never reach this module.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import os
import re
import secrets
import time
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Awaitable, Callable

import orjson

from ..policy import REVERSAL_MODE_CASHOUT_FIRST
from .kalshi_book import KalshiBookError
from .kalshi_live import _fill_level_basis, _fixed_count
from .kalshi_reversal_budget import Filled, ReversalBudget

EXIT_PENDING = "EXIT_PENDING"
EXIT_PARTIAL = "EXIT_PARTIAL"
HEDGE_PENDING = "HEDGE_PENDING"
HEDGE_SUBMITTED = "HEDGE_SUBMITTED"
COMPLETE = "COMPLETE"
FLAT_NO_HEDGE = "FLAT_NO_HEDGE"
EXIT_INCOMPLETE = "EXIT_INCOMPLETE"
UNKNOWN_EXIT = "UNKNOWN_EXIT"
UNKNOWN_HEDGE = "UNKNOWN_HEDGE"
CLEARED = "CLEARED"  # an operator released an UNKNOWN_* hold by receipted command; asserts no venue fact
STATES = frozenset({EXIT_PENDING, EXIT_PARTIAL, HEDGE_PENDING, HEDGE_SUBMITTED, COMPLETE,
                    FLAT_NO_HEDGE, EXIT_INCOMPLETE, UNKNOWN_EXIT, UNKNOWN_HEDGE, CLEARED})
TERMINAL_STATES = frozenset({COMPLETE, FLAT_NO_HEDGE, EXIT_INCOMPLETE, UNKNOWN_EXIT, UNKNOWN_HEDGE,
                             CLEARED})
UNKNOWN_STATES = frozenset({UNKNOWN_EXIT, UNKNOWN_HEDGE})
# Legal transitions. The exit states repeat (one row per authorized exit attempt or resume); an
# UNKNOWN_* terminal leaves only through reconcile() or clear_unknown(), neither of which sends.
_TRANSITIONS = {
    EXIT_PENDING: frozenset({EXIT_PENDING, EXIT_PARTIAL, HEDGE_PENDING, EXIT_INCOMPLETE, UNKNOWN_EXIT}),
    EXIT_PARTIAL: frozenset({EXIT_PARTIAL, HEDGE_PENDING, EXIT_INCOMPLETE, UNKNOWN_EXIT}),
    HEDGE_PENDING: frozenset({HEDGE_SUBMITTED, FLAT_NO_HEDGE, UNKNOWN_HEDGE}),
    # HEDGE_PENDING again: a hedge refused before its send (nothing reached the venue) stays pending.
    HEDGE_SUBMITTED: frozenset({COMPLETE, FLAT_NO_HEDGE, UNKNOWN_HEDGE, HEDGE_PENDING}),
    UNKNOWN_EXIT: frozenset({FLAT_NO_HEDGE, EXIT_INCOMPLETE, CLEARED}),
    UNKNOWN_HEDGE: frozenset({COMPLETE, FLAT_NO_HEDGE, CLEARED}),
}
# Terminal IOC statuses: with nothing remaining, the order's fill count is final.
_TERMINAL_ORDER_STATUSES = frozenset({"canceled", "cancelled", "executed", "filled"})

MAX_JOURNAL_BYTES = 1024 * 1024
BEGIN_HEADROOM_BYTES = 64 * 1024  # a begun transaction always has room to journal its finish
MAX_ROW_BYTES = 4096
MAX_EXIT_ATTEMPTS = 3
MAX_CONTRACTS = 100_000
MAX_FILL_ROWS = 10_000  # KalshiLive.fills_all's own bound
MAX_TEXT = 200
# Venue-side expiry: every order this module submits carries expiration_ts = submit + ORDER_TTL_S
# (unix seconds; sent as good_till_canceled + expiration_time, so Kalshi neither accepts nor
# rests it after that). A not-found id is a confirmed
# zero only once a VENUE timestamp is past expiration_ts + EXPIRY_SKEW_S, the allowance for the
# venue timestamp's whole-second granularity and the gap between the response clock and the
# matching engine's expiry check.
ORDER_TTL_S = 10
EXPIRY_SKEW_S = 5
MAX_EXPIRY_READS = 4  # status + fills reads per leg while waiting out an expiry
MAX_EXPIRY_WAIT_S = ORDER_TTL_S + EXPIRY_SKEW_S + 1  # the most one resume/reconcile waits
MAX_VENUE_TS = 1 << 40
ORIGINAL_MAY_STILL_EXECUTE = "original_may_still_execute"
MAX_RECEIPT_BYTES = 64 * 1024  # an operator clear receipt is read bounded, never whole
CLEAR_DECISION = "clear"  # the receipt's decision field that authorizes clear_unknown()
# The approval clear_unknown() consumes: engine_ops' approval digest over kind, engine_id (the
# transaction id), account (this constant), symbols ([the market]) and sizing (the decision).
CLEAR_APPROVAL_KIND = "reversal_clear"
CLEAR_APPROVAL_ACCOUNT = "kalshi-reversal"
CLEAR_UNAUTHORIZED = "clear_unauthorized"
_TXN_ID = re.compile(r"rt2-[0-9a-f]{24}")

SendExit = Callable[..., Awaitable[Any]]
SendBuy = Callable[..., Awaitable[Any]]
ReadFills = Callable[[], Awaitable[Any]]
# Order status by client id (KalshiLive reply shape). A "no such order" reply must carry the
# venue's own response time as venue_ts (int unix seconds); without it, not-found is no information.
ReadOrder = Callable[[str], Awaitable[Any]]
MaxDebit = Callable[[int, int, int], int]  # (price, count, fee) -> the buy pipeline's max debit


class ReversalJournalError(RuntimeError):
    """The durable journal is unreadable, full or unwritable. Fails closed: nothing is sent."""


class ReversalVenueUnreadable(RuntimeError):
    """The venue fill read failed. Unreadable is not zero: the transaction state is untouched."""


class AmbiguousFills(ValueError):
    """Venue or book fill evidence that could be read two ways."""


class HedgeSendStarted(RuntimeError):
    """H2a3 fix h: raised by the hedge send boundary for an exception of a refusal class (a
    KalshiBookError) that arrived AFTER the client's send state machine recorded SENT. Never a
    KalshiBookError, so _hedge_step records UNKNOWN_HEDGE: once SENT the order may be live, and
    the send state overrides every exception class. The message keeps the original class name."""

    def __init__(self, exc: BaseException) -> None:
        super().__init__(f"send started before {type(exc).__name__}: {exc}"[:400])


class ReversalClearUnauthorized(KalshiBookError):
    """clear_unknown() without an approval that resolves, binds this clear and is consumed now."""

    code = CLEAR_UNAUTHORIZED

    def __init__(self, detail: str) -> None:
        super().__init__(f"{CLEAR_UNAUTHORIZED}: {detail}"[:400])


def new_transaction_id() -> str:
    return "rt2-" + secrets.token_hex(12)


def exit_client_id(txn_id: str, attempt: int) -> str:
    """The predetermined reduce-only id of exit attempt `attempt`: the lx- shape KalshiLive sends
    reduce-only, derived so a restart can name every id this transaction could have sent."""
    if not isinstance(txn_id, str) or not _TXN_ID.fullmatch(txn_id):
        raise ValueError("transaction id invalid")
    if type(attempt) is not int or not 0 <= attempt < MAX_EXIT_ATTEMPTS:
        raise ValueError("exit attempt out of bounds")
    return "lx-" + hashlib.sha256(f"{txn_id}:exit:{attempt}".encode()).hexdigest()[:21]


def hedge_client_ids(txn_id: str) -> tuple[str, str]:
    """The hedge's entry id and KalshiBook._buy's one zero-fill retry id for it."""
    if not isinstance(txn_id, str) or not _TXN_ID.fullmatch(txn_id):
        raise ValueError("transaction id invalid")
    hedge_id = "lh-" + hashlib.sha256(f"{txn_id}:hedge".encode()).hexdigest()[:24]
    return hedge_id, "lb-r1-" + hashlib.sha256(hedge_id.encode()).hexdigest()[:24]


def _cents(value: Decimal) -> int:
    return int(value.quantize(Decimal(1), rounding=ROUND_HALF_UP))


def _text(value: Any) -> str:
    return (value if isinstance(value, str) else str(value))[:MAX_TEXT]


def leg_fills(rows: Any, client_ids, bought_side_yes: bool,
              limit: Decimal) -> tuple[Decimal, Decimal | None]:
    """Sum venue fills whose client_order_id is one of client_ids: (count, debit in cents
    including fees, or None when any matching fill lacks a price). Raises AmbiguousFills on a
    malformed row, a conflicting duplicate fill identity or more than `limit` contracts.
    One pass, bounded by MAX_FILL_ROWS."""
    if not isinstance(rows, list) or len(rows) > MAX_FILL_ROWS:
        raise AmbiguousFills("venue fill page malformed or unbounded")
    ids = frozenset(client_ids)
    seen: dict[str, dict] = {}
    count = Decimal(0)
    debit: Decimal | None = Decimal(0)
    for row in rows:
        if not isinstance(row, dict):
            raise AmbiguousFills("venue fill row malformed")
        if row.get("client_order_id") not in ids:
            continue
        identity = row.get("fill_id", row.get("trade_id"))
        if not isinstance(identity, str) or not identity:
            raise AmbiguousFills("venue fill lacks an identity")
        if identity in seen:
            if seen[identity] != row:
                raise AmbiguousFills("conflicting venue fill identity")
            continue
        seen[identity] = row
        quantity = _fixed_count(str(row.get("count_fp", row.get("count"))))
        if quantity is None or quantity <= 0:
            raise AmbiguousFills("venue fill count malformed")
        count += quantity
        if debit is not None:
            try:
                price, fee = _fill_level_basis(row, bought_side_yes)
                debit += price * quantity + fee
            except Exception:
                debit = None  # a count without its price: the cash is unknown, not zero
    if count > limit:
        raise AmbiguousFills("venue fills exceed the leg's quantity")
    return count, debit


def is_not_found(reply: Any) -> bool:
    """The venue's "no such order" answer with no fill count. Not a zero by itself: an order
    still in flight is not found until the venue accepts it."""
    return (isinstance(reply, dict) and not reply.get("error") and reply.get("not_found") is True
            and _fixed_count(str(reply.get("fill_count", 0))) == 0)


def venue_timestamp(reply: Any) -> int | None:
    """The venue's own response time on an order-status reply (venue_ts, int unix seconds), or
    None when absent or malformed. Never the local clock."""
    value = reply.get("venue_ts") if isinstance(reply, dict) else None
    return value if type(value) is int and 0 < value < MAX_VENUE_TS else None


def order_disposition(reply: Any, client_id: str, limit: Decimal, *,
                      absence_confirmed: bool = False) -> Decimal | None:
    """The final filled count of client_id when the venue's order-status reply POSITIVELY
    resolves it: a terminal IOC status for this id with nothing remaining, or "no such order"
    (zero) ONLY when absence_confirmed says the caller proved the absence (a venue timestamp
    past the id's venue-side expiry plus skew, and no fill). None for anything else (resting,
    pending, an unconfirmed not-found, an error, another id, a malformed count, more than
    `limit`): no information, never zero."""
    if not isinstance(reply, dict) or reply.get("error"):
        return None
    if reply.get("not_found") is True:
        return Decimal(0) if absence_confirmed and is_not_found(reply) else None
    if reply.get("client_order_id", client_id) != client_id:
        return None
    if reply.get("status") not in _TERMINAL_ORDER_STATUSES:
        return None
    filled = _fixed_count(str(reply.get("fill_count")))
    remaining = _fixed_count(str(reply.get("remaining_count")))
    if filled is None or remaining != 0 or filled > limit:
        return None
    return filled


def resolved_leg(rows: Any, statuses: dict[str, Any], client_ids, bought_side_yes: bool,
                 limit: Decimal, confirmed_absent=frozenset()) -> tuple[Decimal, Decimal | None]:
    """A leg's venue truth only when order status AND fills agree for every id it could have
    sent: each id positively resolved by its status (a not-found id only when it is in
    confirmed_absent), and its fills summing to exactly that status's fill count, so a confirmed
    absent id with any fill still raises. Raises AmbiguousFills otherwise, so a fills page that
    is empty or behind the status is no information, never a zero. Bounded: one pass per id plus
    one over all."""
    ids = tuple(client_ids)
    leg_fills(rows, ids, bought_side_yes, limit)  # cross-id duplicate identities and the total
    count, debit = Decimal(0), Decimal(0)
    for cid in ids:
        final = order_disposition(statuses.get(cid), cid, limit,
                                  absence_confirmed=cid in confirmed_absent)
        if final is None:
            if is_not_found(statuses.get(cid)):
                raise AmbiguousFills(f"order {cid} not found; absence not confirmed")
            raise AmbiguousFills(f"order {cid} not positively resolved by the venue")
        filled, cost = leg_fills(rows, (cid,), bought_side_yes, limit)
        if filled != final:
            raise AmbiguousFills(f"order {cid}: fills {filled} disagree with its status {final}")
        count += filled
        debit = None if debit is None or cost is None else debit + cost
    return count, debit


def _plan_count_hundredths(value: Any, name: str) -> int:
    """Validate a count and return exact hundredths without Decimal context arithmetic."""
    if type(value) is int:
        if 1 <= value <= MAX_CONTRACTS:
            return value * 100
    elif isinstance(value, Decimal) and value.is_finite():
        sign, digits, exponent = value.as_tuple()
        if (not sign and exponent >= -2
                and len(digits) + exponent <= len(str(MAX_CONTRACTS))):
            coefficient = 0
            for digit in digits:
                coefficient = coefficient * 10 + digit
            hundredths = coefficient * 10 ** (exponent + 2)
            if 1 <= hundredths <= MAX_CONTRACTS * 100:
                return hundredths
    raise ValueError(f"{name} out of bounds")


@dataclass(frozen=True, slots=True)
class CashoutFirstPlan:
    """One mode-2 transaction's fixed inputs, validated before any journal row exists.
    side_yes is the HELD side; both legs buy the other side.
    exit_count and hedge_count: int or decimal.Decimal on the 0.01 grid, 0.01..MAX_CONTRACTS
    Decimal counts retain their exact value and scale (at most two decimal places).
    Construction accepts Decimals; production intent and execution admission remain int-only."""
    ticket_client_id: str
    ticker: str
    side_yes: bool
    exit_count: int | Decimal
    hedge_count: int | Decimal
    exit_price_cents: int
    exit_fee_per_contract_cents: int
    hedge_price_cents: int
    hedge_fee_per_contract_cents: int
    cluster_id: int
    close_ns: int
    reason: str = ""

    def __post_init__(self) -> None:
        for name in ("ticket_client_id", "ticker"):
            value = getattr(self, name)
            if not isinstance(value, str) or not 0 < len(value) <= 64:
                raise ValueError(f"{name} invalid")
        if type(self.side_yes) is not bool:
            raise ValueError("side_yes must be a bool")
        counts = [_plan_count_hundredths(getattr(self, name), name)
                  for name in ("exit_count", "hedge_count")]
        if sum(counts) > MAX_CONTRACTS * 100:
            raise ValueError("exit_count + hedge_count out of bounds")
        for name in ("exit_price_cents", "hedge_price_cents"):
            value = getattr(self, name)
            if type(value) is not int or not 1 <= value <= 99:
                raise ValueError(f"{name} out of bounds")
        for name in ("exit_fee_per_contract_cents", "hedge_fee_per_contract_cents",
                     "cluster_id", "close_ns"):
            value = getattr(self, name)
            if type(value) is not int or value < 0:
                raise ValueError(f"{name} must be a nonnegative int")
        if not isinstance(self.reason, str):
            raise ValueError("reason must be text")


def plan_from_intent(intent: Any, *, exit_fee_per_contract_cents: int,
                     hedge_fee_per_contract_cents: int) -> CashoutFirstPlan:
    """The plan for a KalshiCashoutFirstIntent (kalshi_edge, mode 2). Duck-typed so the broker
    layer never imports the strategy. Admission stays int-only until Decimal execution exists."""
    request = getattr(intent, "cashout", None)
    if request is None:
        raise ValueError("not a cashout-first intent")
    for name, value in (("exit_count", intent.count), ("hedge_count", request.count)):
        if type(value) is not int:
            raise ValueError(f"{name} out of bounds")
    return CashoutFirstPlan(intent.client_id, intent.ticker, intent.side_yes, intent.count,
                            request.count, intent.price_cents, exit_fee_per_contract_cents,
                            intent.hedge_price_cents, hedge_fee_per_contract_cents,
                            intent.cluster_id, request.close_ns, intent.reason)


class ReversalJournal:
    """Append-only, fsync'd, bounded JSON-lines journal: one row per transition, each row the
    transaction's full snapshot, so the last row per transaction id is its durable state."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def size(self) -> int:
        try:
            return self.path.stat().st_size
        except FileNotFoundError:
            return 0
        except OSError as exc:
            raise ReversalJournalError("reversal journal unreadable") from exc

    def append(self, row: dict[str, Any]) -> None:
        try:
            payload = orjson.dumps(row) + b"\n"
        except TypeError as exc:
            raise ReversalJournalError("reversal journal row not serializable") from exc
        if len(payload) > MAX_ROW_BYTES:
            raise ReversalJournalError("reversal journal row exceeds its bound")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(self.path, os.O_RDWR | os.O_CREAT | getattr(os, "O_BINARY", 0), 0o600)
            try:
                size = os.lseek(fd, 0, os.SEEK_END)
                if size:
                    start = max(0, size - MAX_ROW_BYTES)
                    os.lseek(fd, start, os.SEEK_SET)
                    tail = os.read(fd, size - start)
                    if not tail.endswith(b"\n"):
                        # A crash tore the final row before its fsync returned, so no send
                        # followed it (write-ahead). Cut back to the last complete row.
                        cut = tail.rfind(b"\n")
                        if cut < 0 and start > 0:
                            raise ReversalJournalError("torn journal row exceeds the row bound")
                        size = start + cut + 1
                        os.ftruncate(fd, size)
                if size + len(payload) > MAX_JOURNAL_BYTES:
                    raise ReversalJournalError("reversal journal full")
                os.lseek(fd, size, os.SEEK_SET)
                view = memoryview(payload)
                while view:
                    written = os.write(fd, view)
                    if written <= 0:
                        raise ReversalJournalError("reversal journal short write")
                    view = view[written:]
                os.fsync(fd)
            finally:
                os.close(fd)
        except OSError as exc:
            raise ReversalJournalError("reversal journal write failed") from exc

    def rows(self) -> list[dict[str, Any]]:
        """Every complete row, validated in order. A torn final row (never acknowledged) is
        ignored; any other malformed row, sequence gap or illegal transition fails closed."""
        try:
            with self.path.open("rb") as fh:
                payload = fh.read(MAX_JOURNAL_BYTES + 1)
        except FileNotFoundError:
            return []
        except OSError as exc:
            raise ReversalJournalError("reversal journal unreadable") from exc
        if len(payload) > MAX_JOURNAL_BYTES:
            raise ReversalJournalError("reversal journal exceeds its bound")
        lines = payload.split(b"\n")
        lines.pop()  # b"" after the final newline, or a torn row that was never acknowledged
        rows: list[dict[str, Any]] = []
        last: dict[str, dict[str, Any]] = {}
        for line in lines:
            try:
                row = orjson.loads(line)
            except orjson.JSONDecodeError as exc:
                raise ReversalJournalError("malformed reversal journal row") from exc
            if (not isinstance(row, dict) or row.get("v") != 1
                    or not isinstance(row.get("txn"), str) or not _TXN_ID.fullmatch(row["txn"])
                    or row.get("state") not in STATES
                    or type(row.get("seq")) is not int):
                raise ReversalJournalError("invalid reversal journal row")
            prior = last.get(row["txn"])
            if prior is None:
                if row["seq"] != 0 or row["state"] != EXIT_PENDING:
                    raise ReversalJournalError("reversal journal transaction lacks its begin row")
            elif row["seq"] != prior["seq"] + 1 or row["state"] not in _TRANSITIONS.get(prior["state"], ()):
                raise ReversalJournalError("reversal journal sequence or transition invalid")
            last[row["txn"]] = row
            rows.append(row)
        return rows

    def load(self) -> dict[str, dict[str, Any]]:
        """Transaction id -> its last (durable) row."""
        return {row["txn"]: row for row in self.rows()}

    def history(self, txn_id: str) -> list[dict[str, Any]]:
        return [row for row in self.rows() if row["txn"] == txn_id]


class ReversalTransactions:
    """Runs and recovers mode-2 transactions over one durable journal. Holds no venue client."""

    def __init__(self, journal: ReversalJournal | str | Path, *,
                 budget: ReversalBudget | None = None,
                 clock_ns: Callable[[], int] = time.time_ns,
                 timer_ns: Callable[[], int] = time.perf_counter_ns,
                 sleep: Callable[[float], Awaitable[Any]] = asyncio.sleep,
                 max_expiry_wait_s: int = MAX_EXPIRY_WAIT_S,
                 approvals_dir: str | Path | None = None) -> None:
        """clock_ns is wall time: it stamps rows and sets each order's venue-side expiry (the
        venue enforces it in its own time). timer_ns is monotonic: it times the legs. sleep(s)
        waits out a not-found order's venue expiry, at most max_expiry_wait_s per read of a leg.
        approvals_dir is the approval store clear_unknown() consumes from; None is engine_ops'
        root-only default."""
        if type(max_expiry_wait_s) is not int or not 0 <= max_expiry_wait_s <= MAX_EXPIRY_WAIT_S:
            raise ValueError(f"max_expiry_wait_s must be int seconds in 0..{MAX_EXPIRY_WAIT_S}")
        self.journal = journal if isinstance(journal, ReversalJournal) else ReversalJournal(journal)
        self.budget = budget
        self._clock_ns = clock_ns
        self._timer_ns = timer_ns
        self._sleep = sleep
        self.max_expiry_wait_s = max_expiry_wait_s
        self.approvals_dir = None if approvals_dir is None else str(approvals_dir)
        self._last: dict[str, dict[str, Any]] = {}

    def _expiry(self) -> int:
        """The venue-side expiry for an order about to be authorized: unix seconds."""
        return self._clock_ns() // 1_000_000_000 + ORDER_TTL_S

    def refresh(self) -> dict[str, dict[str, Any]]:
        self._last = self.journal.load()
        return self._last

    def state(self, txn_id: str) -> dict[str, Any] | None:
        row = self._last.get(txn_id)
        return None if row is None else dict(row)

    def blocked_markets(self) -> dict[str, str]:
        """ticker -> transaction id for every market a transaction still holds: in flight (a
        restart must resume it) or UNKNOWN_* (until reconcile). No send belongs there."""
        return {row["ticker"]: txn for txn, row in self._last.items()
                if row["state"] not in TERMINAL_STATES or row["state"] in UNKNOWN_STATES}

    def refuses_send(self, ticker: str) -> bool:
        return ticker in self.blocked_markets()

    def pending(self) -> list[str]:
        return [txn for txn, row in self._last.items() if row["state"] not in TERMINAL_STATES]

    @staticmethod
    def _require_mode(mode: Any) -> None:
        if mode != REVERSAL_MODE_CASHOUT_FIRST or type(mode) is not int:
            raise KalshiBookError("the two-leg reversal transaction runs only in reversal_execution_mode 2")

    async def begin(self, mode: int, plan: CashoutFirstPlan, *, send_exit: SendExit,
                    send_buy: SendBuy, max_debit: MaxDebit,
                    free_cash: Callable[[], int] | None = None,
                    link_hedge_row: Callable[[str, str], Any] | None = None,
                    now_ns: int | None = None) -> dict[str, Any]:
        """Journal EXIT_PENDING, then drive the transaction to a terminal. Refuses before any row
        when the mode is not 2, the plan is invalid, or the market is held by another.
        max_debit is send_buy's own worst-case debit (KalshiBook.max_buy_debit_cents for
        KalshiBook.buy): the hedge claims it, so no pipeline price buffer escapes the caps."""
        self._require_mode(mode)
        if not isinstance(plan, CashoutFirstPlan):
            raise KalshiBookError("a CashoutFirstPlan is required")
        # Decimal construction does not authorize the integer-only executor, even for 1.00.
        if type(plan.exit_count) is not int or type(plan.hedge_count) is not int:
            raise KalshiBookError("Decimal plan execution is not supported")
        self.refresh()
        holder = self.blocked_markets().get(plan.ticker)
        if holder is not None:
            raise KalshiBookError(f"market held by reversal transaction {holder} "
                                  f"({self._last[holder]['state']})")
        if self.journal.size() > MAX_JOURNAL_BYTES - BEGIN_HEADROOM_BYTES:
            raise ReversalJournalError("reversal journal full: no new transaction")
        txn = new_transaction_id()
        row = {"v": 1, "txn": txn, "seq": 0, "state": EXIT_PENDING, "event": "begin",
               "ts_ns": self._clock_ns(), "mode": REVERSAL_MODE_CASHOUT_FIRST,
               "ticket_client_id": plan.ticket_client_id, "ticker": plan.ticker,
               "side_yes": plan.side_yes, "q": str(plan.exit_count), "r": str(plan.hedge_count),
               "exit_price_cents": plan.exit_price_cents,
               "exit_fee_per_contract_cents": plan.exit_fee_per_contract_cents,
               "hedge_price_cents": plan.hedge_price_cents,
               "hedge_fee_per_contract_cents": plan.hedge_fee_per_contract_cents,
               "cluster_id": plan.cluster_id, "close_ns": plan.close_ns,
               "reason": plan.reason[:300], "exit_attempts": 1,
               "exit_expirations": [self._expiry()], "hedge_expiration_ts": None, "exited": "0",
               "freed_cash_cents": 0, "hedge_id": hedge_client_ids(txn)[0], "hedge_count": None,
               "hedge_filled": None, "hedge_cost_cents": None, "budget_token": None,
               "exit_leg_ns": 0, "hedge_leg_ns": None, "note": ""}
        self.journal.append(row)
        self._last[txn] = row
        return await self._drive(row, send_exit, send_buy, max_debit, free_cash, link_hedge_row,
                                 now_ns)

    async def resume(self, txn_id: str, mode: int, *, read_fills: ReadFills,
                     read_order: ReadOrder, send_exit: SendExit, send_buy: SendBuy,
                     max_debit: MaxDebit, free_cash: Callable[[], int] | None = None,
                     link_hedge_row: Callable[[str, str], Any] | None = None,
                     now_ns: int | None = None) -> dict[str, Any]:
        """Rebuild an in-flight transaction from the journal plus venue order status AND fills by
        predetermined client id, and finish it. A terminal transaction is returned unchanged; an
        UNKNOWN_* one waits for reconcile() or clear_unknown(). Never resends an id the journal
        authorized, and allocates the next exit id only after every authorized one is positively
        resolved on the venue; anything short of that lands in UNKNOWN_EXIT with no send. A
        not-found id counts as unsent only once a venue timestamp is past its venue-side expiry
        plus skew and no fill carries it (original_may_still_execute otherwise)."""
        self._require_mode(mode)
        self.refresh()
        row = self._last.get(txn_id)
        if row is None:
            raise KalshiBookError("no such reversal transaction")
        if row["state"] in TERMINAL_STATES:
            return dict(row)
        side = not row["side_yes"]
        if row["state"] in (EXIT_PENDING, EXIT_PARTIAL):
            q = Decimal(row["q"])
            try:
                count, freed = await self._exit_venue(row, read_order, read_fills)
            except AmbiguousFills as exc:
                # The last authorized exit may be live, in flight or filled on the venue: hold the
                # market and send nothing until the venue resolves it (reconcile) or an operator
                # clears it.
                return dict(self._transition(row, UNKNOWN_EXIT, "exit not resolved by the venue",
                                             note=exc))
            resumed = EXIT_PARTIAL if count > 0 else EXIT_PENDING
            more = count < q
            if more and row["exit_attempts"] >= MAX_EXIT_ATTEMPTS:
                row = self._transition(row, resumed, "resumed from venue and journal",
                                       exited=str(count), freed_cash_cents=freed)
                return dict(self._transition(row, EXIT_INCOMPLETE, "exit attempts exhausted"))
            # Every authorized id is final on the venue, so the remainder is venue truth.
            # Write-ahead: that truth, the NEXT attempt's id and its expiry are durable before it
            # is sent.
            row = self._transition(row, resumed, "resumed from venue and journal",
                                   exited=str(count), freed_cash_cents=freed,
                                   **self._next_attempt(row, more))
            return await self._drive(row, send_exit, send_buy, max_debit, free_cash,
                                     link_hedge_row, now_ns)
        hedge_ids = hedge_client_ids(txn_id)
        if row["state"] == HEDGE_PENDING:
            # HEDGE_SUBMITTED precedes every hedge send, so the venue must show nothing here.
            fills = await self._read(read_fills)
            try:
                count, _ = leg_fills(fills, hedge_ids, side, Decimal(row["r"]))
                if count:
                    raise AmbiguousFills("hedge fills exist without a submitted row")
            except AmbiguousFills as exc:
                return dict(self._transition(row, UNKNOWN_HEDGE, "ambiguous hedge fill read", note=exc))
            return await self._drive(row, send_exit, send_buy, max_debit, free_cash,
                                     link_hedge_row, now_ns)
        # HEDGE_SUBMITTED: the hedge may have been sent. Venue truth decides; never resend.
        try:
            fills, statuses, absent = await self._hedge_venue(row, read_order, read_fills)
            return dict(self._settle_hedge_from_venue(row, fills, statuses, absent,
                                                      link_hedge_row, "resumed"))
        except AmbiguousFills as exc:
            self._release(row["budget_token"], "UNKNOWN")
            return dict(self._transition(row, UNKNOWN_HEDGE, "resumed: hedge not resolved by the venue",
                                         note=exc))

    async def reconcile(self, txn_id: str, *, read_fills: ReadFills, read_order: ReadOrder,
                        link_hedge_row: Callable[[str, str], Any] | None = None) -> dict[str, Any]:
        """Identify an UNKNOWN_* leg from venue order status AND fills and release the market.
        Never sends: a reconciled UNKNOWN_EXIT ends FLAT_NO_HEDGE (the original is flat on the
        venue) or EXIT_INCOMPLETE. Anything short of every id positively resolved with its fills
        present (an empty or lagging page, a live order, fewer fills than the journal, a
        not-found id whose venue-side expiry has not passed in venue time) leaves the state
        UNKNOWN and every reservation held."""
        self.refresh()
        row = self._last.get(txn_id)
        if row is None:
            raise KalshiBookError("no such reversal transaction")
        if row["state"] not in UNKNOWN_STATES:
            return dict(row)
        if row["state"] == UNKNOWN_EXIT:
            q = Decimal(row["q"])
            try:
                count, freed = await self._exit_venue(row, read_order, read_fills)
            except AmbiguousFills:
                return dict(row)
            state = FLAT_NO_HEDGE if count == q else EXIT_INCOMPLETE
            return dict(self._transition(row, state, "reconciled from venue", exited=str(count),
                                         freed_cash_cents=freed))
        try:
            fills, statuses, absent = await self._hedge_venue(row, read_order, read_fills)
            return dict(self._settle_hedge_from_venue(row, fills, statuses, absent,
                                                      link_hedge_row, "reconciled"))
        except AmbiguousFills:
            return dict(row)

    def clear_unknown(self, txn_id: str, *, operator: str, receipt: str,
                      approval: str | None = None, now: Any = None) -> dict[str, Any]:
        """The operator's approved, receipted release of an UNKNOWN_* hold that venue truth has
        not resolved: journals CLEARED with who cleared it, the receipt path and its sha256, and
        the approval it consumed. The receipt must be an existing JSON object file (at most
        MAX_RECEIPT_BYTES) whose transaction_id is this transaction and whose decision is
        CLEAR_DECISION; an operator field, when present, must name the same operator. The
        approval (the clear command's --approval id) must resolve in the root-only approvals
        store through engine_ops' own resolver, bind kind reversal_clear, this transaction, its
        market and the decision, be unexpired and unconsumed, and is consumed exactly once before
        the CLEARED row: anything short refuses clear_unauthorized (ReversalClearUnauthorized),
        so a self-authored receipt alone never clears. Never sends and never touches the budget,
        so a hedge reservation stays held until its own release or settlement. Refuses anything
        but an UNKNOWN_* transaction. now is engine_ops' clock (tz-aware datetime) for tests."""
        for name, value in (("operator", operator), ("receipt", receipt)):
            if not isinstance(value, str) or not value.strip() or len(value) > MAX_TEXT:
                raise KalshiBookError(f"clear_unknown needs a {name} (1..{MAX_TEXT} chars)")
        self.refresh()
        row = self._last.get(txn_id)
        if row is None:
            raise KalshiBookError("no such reversal transaction")
        if row["state"] not in UNKNOWN_STATES:
            raise KalshiBookError(f"only an UNKNOWN_* transaction is cleared ({row['state']})")
        digest = self._validated_receipt(receipt, txn_id, operator)
        approval_id = self._consume_clear_approval(approval, row, now)
        return dict(self._transition(row, CLEARED, "operator cleared", note=receipt,
                                     cleared_by=operator, cleared_from=row["state"],
                                     clear_receipt=receipt, clear_receipt_sha256=digest,
                                     clear_approval=approval_id))

    def _consume_clear_approval(self, approval: Any, row: dict[str, Any], now: Any) -> str:
        """Resolve, check and consume the clear's approval through engine_ops' Ops resolver (the
        one the engine verbs use: the store chain check, the guarded bounded read, the digest,
        the expiry and the exclusive consumed marker), never a copy of it. The consuming request
        id is unique per call, so an approval is spent once even if the journal is rolled back.
        Raises ReversalClearUnauthorized on anything short; nothing is journaled then."""
        if not isinstance(approval, str) or not approval.strip() or len(approval) > MAX_TEXT:
            raise ReversalClearUnauthorized("an approval id (--approval) is required")
        from .. import engine_ops  # lazy: the broker layer loads the approval resolver only here

        try:
            ops = engine_ops.Ops(argparse.Namespace(
                engines_dir=engine_ops.DEFAULT_ENGINES_DIR, bindings=None,
                registry_dir=engine_ops.DEFAULT_REGISTRY_DIR, approvals_dir=self.approvals_dir,
                manifests_dir=engine_ops.DEFAULT_MANIFESTS_DIR,
                evidence_dir=engine_ops.DEFAULT_EVIDENCE_DIR, trials_dir=engine_ops.TRIALS_DIR,
                lanes_root=engine_ops.DEFAULT_LANES_ROOT,
                owner_overrides=engine_ops.DEFAULT_OWNER_OVERRIDES,
                owner_runs=engine_ops.DEFAULT_OWNER_RUNS, lifecycle_dir=None, json=False), now)
            doc = ops.load_approval(approval)
            request_id = f"reversal-clear:{row['txn']}:{secrets.token_hex(8)}"
            problem = ops.approval_problem(doc, kind=CLEAR_APPROVAL_KIND, engine_id=row["txn"],
                                           account=CLEAR_APPROVAL_ACCOUNT, symbols=[row["ticker"]],
                                           sizing=CLEAR_DECISION, request_id=request_id)
            if problem is not None:
                raise ReversalClearUnauthorized(problem)
            ops.consume_approval(approval, request_id)
        except engine_ops.Refused as exc:
            raise ReversalClearUnauthorized(f"{exc.code}: {exc.detail}") from None
        except OSError as exc:
            raise ReversalClearUnauthorized(f"approval store unusable: {type(exc).__name__}") from None
        return approval

    @staticmethod
    def _validated_receipt(receipt: str, txn_id: str, operator: str) -> str:
        """The sha256 of an existing, parseable receipt naming txn_id and the clear decision.
        Raises KalshiBookError otherwise. Bounded read: MAX_RECEIPT_BYTES + 1 at most."""
        try:
            with Path(receipt).open("rb") as fh:
                payload = fh.read(MAX_RECEIPT_BYTES + 1)
        except OSError as exc:
            raise KalshiBookError(f"clear receipt unreadable or missing: {type(exc).__name__}") from exc
        if not payload or len(payload) > MAX_RECEIPT_BYTES:
            raise KalshiBookError("clear receipt empty or over its bound")
        try:
            doc = orjson.loads(payload)
        except orjson.JSONDecodeError as exc:
            raise KalshiBookError("clear receipt is not parseable JSON") from exc
        if not isinstance(doc, dict):
            raise KalshiBookError("clear receipt is not a JSON object")
        if doc.get("transaction_id") != txn_id:
            raise KalshiBookError("clear receipt names another transaction")
        if doc.get("decision") != CLEAR_DECISION:
            raise KalshiBookError(f"clear receipt decision is not {CLEAR_DECISION!r}")
        if "operator" in doc and doc["operator"] != operator:
            raise KalshiBookError("clear receipt names another operator")
        return hashlib.sha256(payload).hexdigest()

    @staticmethod
    async def _read(read_fills: ReadFills) -> Any:
        try:
            return await read_fills()
        except Exception as exc:
            raise ReversalVenueUnreadable(f"venue fill read failed: {type(exc).__name__}") from exc

    @staticmethod
    async def _read_orders(read_order: ReadOrder, client_ids) -> dict[str, Any]:
        """Order status for each id (at most MAX_EXIT_ATTEMPTS or two). A failed read is not a
        zero: it raises and leaves the transaction untouched."""
        statuses: dict[str, Any] = {}
        for cid in client_ids:
            try:
                statuses[cid] = await read_order(cid)
            except Exception as exc:
                raise ReversalVenueUnreadable(
                    f"venue order status read failed: {type(exc).__name__}") from exc
        return statuses

    async def _read_leg(self, ids, expiries: dict[str, int | None], read_order: ReadOrder,
                        read_fills: ReadFills, exhausted_by=None):
        """(fills, statuses, confirmed_absent) for one leg: status first, then fills, so a fill
        the status already counts is read after it. A not-found id is confirmed absent only when
        the venue itself shows the original can no longer execute: its not-found reply's venue
        timestamp is past the id's journaled expiration_ts + EXPIRY_SKEW_S. The caller's
        resolved_leg then requires that no fill carries it (fills by client id are the only fill
        evidence; no position read is ever taken). Short of that it sleeps out the venue expiry,
        at most max_expiry_wait_s in total, and re-reads; still short (or an id with no journaled
        expiry, or a not-found reply without a venue timestamp) raises AmbiguousFills
        original_may_still_execute for the caller's UNKNOWN_*. An id this process believes it
        never sent gets no exemption: only venue evidence confirms its absence. The one venue
        exemption is exhausted_by (primary id, leg limit, bought side), checked on every read
        BEFORE any timestamp rule on the other ids: when the primary id's terminal status AND its
        fills by client id both show the whole leg filled, the leg has no remainder any retry
        could carry, so the fills settle it with no venue timestamp and no wait (a retry that was
        never sent has none to give; a flat position proves nothing and is never read). A retry
        id that did fill still fails resolved_leg, because its fills must equal zero. Bounded:
        MAX_EXPIRY_READS status passes and fill reads."""
        waited = 0.0
        for read in range(MAX_EXPIRY_READS):
            statuses = await self._read_orders(read_order, ids)
            fills = await self._read(read_fills)
            absent = frozenset(cid for cid in ids if is_not_found(statuses[cid]))
            if exhausted_by is not None and self._leg_exhausted(statuses, fills, *exhausted_by):
                return fills, statuses, absent  # the predetermined id filled the whole leg
            need = 0
            for cid in absent:
                expiry = expiries.get(cid)
                if expiry is None:
                    raise AmbiguousFills(f"{ORIGINAL_MAY_STILL_EXECUTE}: order {cid} not found "
                                         "and its venue-side expiry is not journaled")
                venue_ts = venue_timestamp(statuses[cid])
                if venue_ts is None:
                    raise AmbiguousFills(f"{ORIGINAL_MAY_STILL_EXECUTE}: order {cid} not found "
                                         "without a venue timestamp")
                need = max(need, expiry + EXPIRY_SKEW_S + 1 - venue_ts)
            if need <= 0:
                return fills, statuses, absent  # found, or provably past its venue expiry
            left = self.max_expiry_wait_s - waited
            if left <= 0 or read == MAX_EXPIRY_READS - 1:
                break
            step = min(need, left)
            await self._sleep(step)
            waited += step
        raise AmbiguousFills(f"{ORIGINAL_MAY_STILL_EXECUTE}: order not found before its venue-side "
                             f"expiry plus {EXPIRY_SKEW_S} s passed in venue time")

    @staticmethod
    def _leg_exhausted(statuses, fills, primary: str, limit: Decimal, bought_side_yes: bool) -> bool:
        """True only when the venue positively shows `primary` filled the leg's full `limit`: a
        terminal status with nothing remaining AND fills by that client id summing to the same
        count. Raises AmbiguousFills on a malformed page (the caller keeps UNKNOWN)."""
        final = order_disposition(statuses.get(primary), primary, limit)
        if final is None or final <= 0 or final != limit:
            return False
        filled, _ = leg_fills(fills, (primary,), bought_side_yes, limit)
        return filled == final

    @staticmethod
    def _expiry_of(value: Any) -> int | None:
        return value if type(value) is int and 0 < value < MAX_VENUE_TS else None

    async def _exit_venue(self, row, read_order, read_fills) -> tuple[Decimal, int]:
        """(exited count, freed cash) for the exit leg from the venue under the expiry rule;
        each attempt's id is bound to the expiry its authorizing row journaled."""
        ids = [exit_client_id(row["txn"], a) for a in range(row["exit_attempts"])]
        journaled = row.get("exit_expirations")
        journaled = journaled if isinstance(journaled, list) else []
        expiries = {cid: self._expiry_of(journaled[a]) if a < len(journaled) else None
                    for a, cid in enumerate(ids)}
        fills, statuses, absent = await self._read_leg(ids, expiries, read_order, read_fills)
        return self._exit_truth(row, fills, statuses, ids, absent)

    async def _hedge_venue(self, row, read_order, read_fills):
        """(fills, statuses, confirmed_absent) for the hedge leg under the expiry rule; the hedge
        id and book.buy's one retry id share the expiry the HEDGE_SUBMITTED row journaled. A
        not-found retry id is confirmed absent only past that expiry in venue time, unless the
        venue shows the hedge id itself filled the whole leg (terminal status and fills by client
        id agree), which leaves no remainder for the retry: the local belief that it was never
        sent is not evidence, a full fill of the predetermined id is."""
        expiry = self._expiry_of(row.get("hedge_expiration_ts"))
        hedge_ids = hedge_client_ids(row["txn"])
        limit = Decimal(row["hedge_count"] if row["hedge_count"] is not None else row["r"])
        return await self._read_leg(hedge_ids, dict.fromkeys(hedge_ids, expiry), read_order,
                                    read_fills,
                                    exhausted_by=(hedge_ids[0], limit, not row["side_yes"]))

    def _next_attempt(self, row: dict[str, Any], more: bool) -> dict[str, Any]:
        """Write-ahead fields that authorize the next exit id: its attempt count and its
        venue-side expiry. Empty when no further attempt is authorized."""
        if not more:
            return {}
        attempts = row["exit_attempts"]
        journaled = row.get("exit_expirations")
        journaled = list(journaled)[:attempts] if isinstance(journaled, list) else []
        journaled += [None] * (attempts - len(journaled))  # index = attempt; None never confirms
        return {"exit_attempts": attempts + 1, "exit_expirations": journaled + [self._expiry()]}

    @staticmethod
    def _exit_truth(row, fills, statuses, ids, confirmed_absent=frozenset()) -> tuple[Decimal, int]:
        """(exited count, freed cash) for the exit leg from venue status and fills, or raises
        AmbiguousFills. The journal's own count is a floor: the venue never shows less."""
        q, journaled = Decimal(row["q"]), Decimal(row["exited"])
        count, debit = resolved_leg(fills, statuses, ids, not row["side_yes"], q, confirmed_absent)
        if count < journaled:
            raise AmbiguousFills("venue shows fewer exit fills than the journal")
        if count == journaled:
            return count, row["freed_cash_cents"]
        if debit is None:
            raise AmbiguousFills("exit fills lack prices; freed cash unknown")
        return count, _cents(count * 100 - debit)

    def _settle_hedge_from_venue(self, row, fills, statuses, confirmed_absent, link_hedge_row,
                                 event):
        """Settle the hedge from venue truth, or raise AmbiguousFills before any transition or
        release: the caller keeps the reservation (UNKNOWN) and the hold."""
        limit = Decimal(row["hedge_count"] if row["hedge_count"] is not None else row["r"])
        hedge_ids = hedge_client_ids(row["txn"])
        count, debit = resolved_leg(fills, statuses, hedge_ids, not row["side_yes"], limit,
                                    confirmed_absent)
        if count and debit is None:
            raise AmbiguousFills("hedge fills lack prices; hedge cost unknown")
        if not count:
            # Both ids final on the venue with no fill (a terminal status, or not found past its
            # venue-side expiry with no fill by client id): a confirmed zero, not an empty page.
            self._release(row["budget_token"], "rejected")
            return self._transition(row, FLAT_NO_HEDGE, f"{event}: venue shows no hedge fill",
                                    hedge_filled="0")
        cost = _cents(debit)
        self._release(row["budget_token"], Filled(cost))
        row = self._transition(row, COMPLETE, f"{event}: hedge filled on the venue",
                               hedge_filled=str(count), hedge_cost_cents=cost)
        self._link(link_hedge_row, row)
        return row

    async def _drive(self, row, send_exit, send_buy, max_debit, free_cash, link_hedge_row, now_ns):
        # Bounded: every exit step consumes one of MAX_EXIT_ATTEMPTS ids or ends the exit leg.
        while row["state"] in (EXIT_PENDING, EXIT_PARTIAL):
            row = await self._exit_step(row, send_exit, now_ns)
        if row["state"] == HEDGE_PENDING:
            row = await self._hedge_step(row, send_buy, max_debit, free_cash, link_hedge_row,
                                         now_ns)
        return dict(row)

    @staticmethod
    def _max_debit(max_debit, price, count, fee) -> int:
        """The caller's buy pipeline maximum debit for `count`, validated: whole cents and never
        below count * (price + fee), which would understate the claim."""
        debit = max_debit(price, count, fee)
        if type(debit) is not int or debit < count * (price + fee):
            raise ValueError("max debit understates count * (price + fee) or is not int cents")
        return debit

    async def _exit_step(self, row, send_exit, now_ns):
        q, exited = Decimal(row["q"]), Decimal(row["exited"])
        remaining = q - exited
        if remaining <= 0:
            return self._transition(row, HEDGE_PENDING, "exit leg complete")
        if remaining != remaining.to_integral_value():
            return self._transition(row, EXIT_INCOMPLETE, "fractional residue cannot exit whole")
        attempt = row["exit_attempts"] - 1
        xid = exit_client_id(row["txn"], attempt)
        journaled = row.get("exit_expirations")
        expiry = self._expiry_of(journaled[attempt]) if (
            isinstance(journaled, list) and attempt < len(journaled)) else None
        if expiry is None:
            # Nothing is sent without a journaled venue-side expiry: absence could never be proven.
            return self._transition(row, EXIT_INCOMPLETE, "exit expiry not journaled")
        started = self._timer_ns()
        try:
            result = await send_exit(row["ticket_client_id"], row["exit_price_cents"], int(remaining),
                                     row["exit_fee_per_contract_cents"], row["reason"], now_ns,
                                     exit_client_id=xid, transaction_id=row["txn"],
                                     expiration_ts=expiry)
        except KalshiBookError as exc:
            # KalshiBook.exit raises this only before the venue is touched: nothing was sent.
            return self._transition(row, EXIT_INCOMPLETE, "exit refused before send",
                                    exit_leg_ns=row["exit_leg_ns"] + self._timer_ns() - started,
                                    note=f"{type(exc).__name__}: {exc}")
        except Exception as exc:
            return self._transition(row, UNKNOWN_EXIT, "exit outcome unknown",
                                    exit_leg_ns=row["exit_leg_ns"] + self._timer_ns() - started,
                                    note=f"{type(exc).__name__}: {exc}")
        elapsed = row["exit_leg_ns"] + self._timer_ns() - started
        try:
            if result is None:
                filled, proceeds = Decimal(0), 0
            else:
                filled = _fixed_count(str(result.get("count"))) if isinstance(result, dict) else None
                proceeds = result.get("proceeds_cents") if isinstance(result, dict) else None
                if filled is None or filled > remaining or type(proceeds) is not int:
                    raise AmbiguousFills("exit fill row malformed or over the remaining count")
        except AmbiguousFills as exc:
            return self._transition(row, UNKNOWN_EXIT, "ambiguous exit fill", exit_leg_ns=elapsed,
                                    note=exc)
        exited += filled
        changes = {"exited": str(exited), "freed_cash_cents": row["freed_cash_cents"] + proceeds,
                   "exit_leg_ns": elapsed}
        if exited == q:
            return self._transition(row, HEDGE_PENDING, "exit leg complete", **changes)
        if filled == 0:
            return self._transition(row, EXIT_INCOMPLETE, "exit zero fill", **changes)
        if row["exit_attempts"] >= MAX_EXIT_ATTEMPTS:
            row = self._transition(row, EXIT_PARTIAL, "exit leg partial", **changes)
            return self._transition(row, EXIT_INCOMPLETE, "exit attempts exhausted")
        # Write-ahead: the partial fill, the NEXT attempt's id and its expiry are durable before
        # it is sent.
        return self._transition(row, EXIT_PARTIAL, "exit leg partial",
                                **self._next_attempt(row, True), **changes)

    async def _hedge_step(self, row, send_buy, max_debit, free_cash, link_hedge_row, now_ns):
        r = int(row["r"])
        price, fee = row["hedge_price_cents"], row["hedge_fee_per_contract_cents"]
        hedge_id = hedge_client_ids(row["txn"])[0]
        # A hedge refused before its send stays HEDGE_PENDING holding its budget claim; the retry
        # reuses that claim (a second claim on the market would refuse already_reversed), and
        # every end short of a send releases it.
        held = row.get("budget_token")

        def flat(event, note=""):
            self._release(held, "rejected")
            return self._transition(row, FLAT_NO_HEDGE, event, note=note)

        try:
            per_contract = self._max_debit(max_debit, price, 1, fee)
        except Exception as exc:
            return flat("hedge max debit unreadable", f"{type(exc).__name__}: {exc}")
        count = r
        if held is not None:
            try:
                count = min(r, int(row["hedge_count"]))  # a retry never outgrows its retained claim
            except (KeyError, TypeError, ValueError) as exc:
                return flat("hedge retry count unreadable", f"{type(exc).__name__}: {exc}")
        free = None
        if free_cash is not None:
            try:
                free = free_cash()
                if type(free) is not int:
                    raise TypeError("free cash must be int cents")
            except Exception as exc:
                return flat("free cash unreadable", f"{type(exc).__name__}: {exc}")
            count = min(count, max(0, free) // per_contract)
        if count < 1:
            return flat("hedge unaffordable")
        freed = row["freed_cash_cents"]  # the exit leg's proceeds as the journal records them
        cash = max(0, free if free is not None else freed)
        try:
            worst = self._max_debit(max_debit, price, count, fee)
        except Exception as exc:
            return flat("hedge max debit unreadable", f"{type(exc).__name__}: {exc}")
        # The ceiling is min(caps, freed cash, free cash); the budget enforces the caps and
        # the freed cash again. The buffered figure, not the plan price, is what the send can debit.
        if worst > cash:
            return flat("hedge max debit exceeds free cash", f"{worst} > {cash}")
        if worst > freed:
            return flat("hedge max debit exceeds freed cash", f"{worst} > {freed}")
        token = held
        if held is not None:
            # The retained claim bounds the retry: it may never debit more than was claimed.
            claimed = row.get("hedge_max_debit_cents")
            if type(claimed) is not int or worst > claimed:
                return flat("hedge max debit exceeds the retained claim", f"{worst} > {claimed}")
        elif self.budget is not None:
            try:
                claim = self.budget.claim_hedge(
                    row["ticker"], row["close_ns"], hedge_id, exit_leg="COMPLETE",
                    freed_cash_cents=freed, count=count, price_cents=price,
                    fee_per_contract_cents=fee, free_cash_cents=cash, max_debit_cents=worst)
            except Exception as exc:
                claim = exc
            if not isinstance(claim, str):
                reason = getattr(getattr(claim, "reason", None), "value", None) or type(claim).__name__
                return self._transition(row, FLAT_NO_HEDGE, "hedge budget refused", note=reason)
            token = claim
        try:
            # Write-ahead: the venue-side expiry is durable before the hedge (or its retry) is sent.
            row = self._transition(row, HEDGE_SUBMITTED, "hedge submitted", hedge_count=str(count),
                                   budget_token=token, hedge_max_debit_cents=worst,
                                   hedge_expiration_ts=self._expiry())
        except BaseException:
            if held is None:
                self._release(token, "rejected")  # the row that authorizes the send never landed
            raise
        started = self._timer_ns()
        try:
            ticket = await send_buy(row["ticker"], not row["side_yes"], price, count, fee,
                                    row["cluster_id"], hedge_id, now_ns, row["reason"],
                                    expiration_ts=row["hedge_expiration_ts"])
        except KalshiBookError as exc:
            # KalshiBook.buy (and the runner's guarded send) raises this only before the venue is
            # touched: nothing was sent (fix h: the guarded send re-raises one that follows SENT as
            # HedgeSendStarted, which lands below as UNKNOWN_HEDGE). The H2a2 contract keeps the
            # hedge HEDGE_PENDING with the refusal recorded, the market held and the claim kept: a
            # later clean turn retries it under the same id (resume).
            refusals = row.get("hedge_refusals")
            return self._transition(row, HEDGE_PENDING, "hedge refused before send",
                                    hedge_leg_ns=self._timer_ns() - started,
                                    hedge_refusals=(refusals if type(refusals) is int else 0) + 1,
                                    note=f"{type(exc).__name__}: {exc}")
        except Exception as exc:
            self._release(token, "UNKNOWN")
            return self._transition(row, UNKNOWN_HEDGE, "hedge outcome unknown",
                                    hedge_leg_ns=self._timer_ns() - started,
                                    note=f"{type(exc).__name__}: {exc}")
        elapsed = self._timer_ns() - started
        if ticket is None:
            self._release(token, "rejected")
            return self._transition(row, FLAT_NO_HEDGE, "hedge zero fill", hedge_filled="0",
                                    hedge_leg_ns=elapsed)
        filled = _fixed_count(str(getattr(ticket, "count", None)))
        cost = getattr(ticket, "cost_cents", None)
        if filled is None or filled <= 0 or filled > count or type(cost) is not int or cost < 0:
            self._release(token, "UNKNOWN")
            return self._transition(row, UNKNOWN_HEDGE, "ambiguous hedge fill", hedge_leg_ns=elapsed)
        self._release(token, Filled(cost))
        row = self._transition(row, COMPLETE, "hedge filled", hedge_filled=str(filled),
                               hedge_cost_cents=cost, hedge_leg_ns=elapsed)
        self._link(link_hedge_row, row)
        return row

    @staticmethod
    def _link(link_hedge_row, row) -> None:
        if link_hedge_row is None:
            return
        try:
            link_hedge_row(row["hedge_id"], row["txn"])
        except Exception:
            pass  # the journal is the transaction's record; the linked row is a view of it

    def _release(self, token: str | None, outcome: Any) -> None:
        if token is None or self.budget is None:
            return
        try:
            self.budget.release(token, outcome)
        except Exception:
            pass  # a failed release keeps the reservation, which is the conservative side

    def _transition(self, row: dict[str, Any], state: str, event: str, *, note: Any = "",
                    **changes: Any) -> dict[str, Any]:
        if state not in _TRANSITIONS.get(row["state"], frozenset()):
            raise ReversalJournalError(f"illegal reversal transition {row['state']} -> {state}")
        new = {**row, **changes, "seq": row["seq"] + 1, "state": state, "event": _text(event),
               "ts_ns": self._clock_ns(), "note": _text(note)}
        self.journal.append(new)
        self._last[new["txn"]] = new
        return new
