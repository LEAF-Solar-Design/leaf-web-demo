"""Durable account ceiling shared by every Kashbot book process.

The root-owned approval supplies the binding. Missing state is created only by
the supervisor; children can never recreate it. Used bindings are never reset.
Amounts are integer cents. Unresolved sends do not age out of turnover.
"""
from __future__ import annotations

from contextlib import contextmanager
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import time

from .live_gate import LiveGateClosed

ORDER_CAP = 20_000
STAKE_CENTS = 7_000
TURNOVER_CAP_CENTS = 20 * STAKE_CENTS
WINDOW_NS = 86_400 * 1_000_000_000
MAX_BYTES = 16 * 1024 * 1024
MAX_NS = 2**63 - 1


class AccountBudgetRefused(LiveGateClosed):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def approval_binding(config, generation):
    from ..account_lane_agent import canonical_symbols, identifier
    identifier(generation)
    document = {"version": 1, "lane_id": identifier(config["lane_id"]),
                "tenant_id": identifier(config["tenant_id"]), "venue": "kalshi", "subaccount": 0,
                "generation": generation, "authority_generation": config["lane_id"],
                "fingerprint": config["fingerprint"], "dry_run_id": config["dry_run_id"],
                "symbols": list(canonical_symbols()), "per_book_stake_cents": 500,
                "aggregate_stake_cents": STAKE_CENTS, "order_cap": ORDER_CAP,
                "turnover_cap_cents": TURNOVER_CAP_CENTS, "window_ns": WINDOW_NS,
                "limits_profile": "kalshi-experiment"}
    if "account_sizing" in config:
        sizing = sizing_from_cash(config["account_sizing"]["free_cash_cents"])
        if canonical(sizing) != canonical(config["account_sizing"]):
            raise AccountBudgetRefused("invalid account sizing")
        document.update(sizing)
        document["version"] = 2
    return {"generation": generation, "digest": hashlib.sha256(canonical(document)).hexdigest()}


def sizing_from_cash(free_cash_cents):
    from ..account_lane_agent import canonical_symbols
    cash = _integer(free_cash_cents, MAX_NS // 20)
    stake = min(cash // 5, 50_000)
    if stake < 1:
        raise AccountBudgetRefused("insufficient account free cash")
    aggregate = min(cash, stake * len(canonical_symbols()))
    return {"free_cash_cents": cash, "per_book_stake_cents": stake,
            "aggregate_stake_cents": aggregate, "turnover_cap_cents": 20 * aggregate}


def _integer(value, maximum=MAX_NS):
    if type(value) is not int or not 0 <= value <= maximum:
        raise AccountBudgetRefused("invalid account budget value")
    return value


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise AccountBudgetRefused("duplicate account budget field")
        result[key] = value
    return result


class AccountLiveBudget:
    def __init__(self, path, *, lane_id, generation, digest, owner=None, sizing=None):
        from ..account_lane_agent import LanePaths, identifier
        self.path = Path(path)
        self.lane_id = identifier(lane_id)
        self.generation = identifier(generation)
        if not isinstance(digest, str) or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
            raise AccountBudgetRefused("invalid account budget digest")
        self.digest = digest
        self.sizing = None
        if sizing is not None:
            expected = sizing_from_cash(sizing["free_cash_cents"])
            if canonical(sizing) != canonical(expected):
                raise AccountBudgetRefused("invalid account sizing")
            self.sizing = expected
        self.turnover_cap = TURNOVER_CAP_CENTS if sizing is None else self.sizing["turnover_cap_cents"]
        self.owner = os.geteuid() if os.name == "posix" else None
        if owner is not None and os.name == "posix":
            if (type(owner) is not int or owner < 0
                    or (os.geteuid() != 0 and owner != os.geteuid())):
                raise AccountBudgetRefused("invalid account budget owner")
            self.owner = owner
        if self.path != LanePaths(lane_id).state / "account-live-budget.json":
            raise AccountBudgetRefused("noncanonical account budget path")

    def _header(self):
        header = {"version": 1, "lane_id": self.lane_id, "generation": self.generation,
                "digest": self.digest, "order_cap": ORDER_CAP,
                "aggregate_stake_cents": STAKE_CENTS, "turnover_cap_cents": TURNOVER_CAP_CENTS}
        if self.sizing is not None:
            header.update(self.sizing)
            header["version"] = 2
        return header

    def _safe_file(self, fd):
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > MAX_BYTES
                or (os.name == "posix" and
                    (info.st_uid != self.owner or stat.S_IMODE(info.st_mode) != 0o600))):
            raise AccountBudgetRefused("unsafe account budget file")

    @contextmanager
    def _locked(self):
        from ..account_lane_agent import private_parent, safe_path
        safe_path(self.path)
        if os.name == "posix":
            for directory in self.path.parents:
                info = directory.stat()
                if info.st_uid not in (0, self.owner) or (
                        stat.S_IMODE(info.st_mode) & 0o022 and not info.st_mode & stat.S_ISVTX):
                    raise AccountBudgetRefused("unsafe account budget ancestor")
        with private_parent(self.path) as parent:
            info = os.fstat(parent) if parent is not None else self.path.parent.stat()
            if (not stat.S_ISDIR(info.st_mode) or (os.name == "posix" and
                    (info.st_uid != self.owner or stat.S_IMODE(info.st_mode) != 0o700))):
                raise AccountBudgetRefused("unsafe account budget directory")
            lock = self.path.with_suffix(".lock")
            safe_path(lock)
            flags = os.O_RDWR | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
            try:
                fd = os.open(lock.name if parent is not None else lock,
                             flags | os.O_CREAT | os.O_EXCL, 0o600, dir_fd=parent)
            except FileExistsError:
                fd = os.open(lock.name if parent is not None else lock, flags, dir_fd=parent)
            else:
                if os.name == "posix" and self.owner != os.geteuid():
                    try:
                        os.fchown(fd, self.owner, -1)
                    except BaseException:
                        os.close(fd)
                        raise
            try:
                self._safe_file(fd)
                if os.name == "posix":
                    import fcntl
                    fcntl.flock(fd, fcntl.LOCK_EX)
                else:
                    import msvcrt
                    deadline = time.monotonic() + 30.0
                    while True:
                        if time.monotonic() >= deadline:
                            raise AccountBudgetRefused("account budget lock timed out")
                        try:
                            # Use nonblocking attempts so the CRT's internal retries
                            # cannot run beyond our contention deadline.
                            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                            break
                        except OSError as exc:
                            if exc.errno not in (13, 33, 36, errno.EACCES, errno.EDEADLK):
                                raise
                            remaining = deadline - time.monotonic()
                            if remaining <= 0:
                                raise AccountBudgetRefused("account budget lock timed out") from exc
                            time.sleep(min(0.01, remaining))
                # A substituted lock must never create a second serialization domain.
                current = os.stat(lock.name if parent is not None else lock,
                                  dir_fd=parent, follow_symlinks=False)
                if (current.st_dev, current.st_ino) != (os.fstat(fd).st_dev, os.fstat(fd).st_ino):
                    raise AccountBudgetRefused("account budget lock replaced")
                yield parent
            finally:
                os.close(fd)

    def _read(self, parent, *, prior_binding=False):
        fd = os.open(self.path.name if parent is not None else self.path,
                     os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0),
                     dir_fd=parent)
        with os.fdopen(fd, "rb") as stream:
            self._safe_file(stream.fileno())
            data = stream.read(MAX_BYTES + 1)
        if len(data) > MAX_BYTES:
            raise AccountBudgetRefused("account budget too large")
        try:
            value = json.loads(data, object_pairs_hook=_pairs)
            if prior_binding:
                if type(value) is not dict:
                    raise AccountBudgetRefused("corrupt account budget")
                previous = AccountLiveBudget(self.path, lane_id=self.lane_id,
                    generation=value["generation"], digest=value["digest"], owner=self.owner,
                    sizing=({key: value[key] for key in ("free_cash_cents", "per_book_stake_cents",
                        "aggregate_stake_cents", "turnover_cap_cents")} if value.get("version") == 2 else None))
                previous._validate(value)
            else:
                self._validate(value)
            return value
        except (ValueError, TypeError, KeyError, RecursionError):
            raise AccountBudgetRefused("corrupt account budget") from None

    def _validate(self, value):
        header = self._header()
        if (type(value) is not dict or set(value) != set(header) | {"total_claims", "total_fills", "clock_ns", "claims"}
                or any(type(value[k]) is not type(v) or value[k] != v for k, v in header.items())):
            raise AccountBudgetRefused("account budget binding mismatch")
        _integer(value["clock_ns"])
        _integer(value["total_claims"], ORDER_CAP)
        _integer(value["total_fills"], ORDER_CAP)
        claims = value["claims"]
        if type(claims) is not dict or len(claims) != value["total_claims"]:
            raise AccountBudgetRefused("invalid account claims")
        fills = 0
        for cid, row in claims.items():
            if not isinstance(cid, str) or not 0 < len(cid) <= 36 or type(row) is not dict or set(row) != {
                    "request_digest", "reserved_cents", "filled_cents", "claimed_ns", "resolved_ns"}:
                raise AccountBudgetRefused("invalid account claim")
            if not isinstance(row["request_digest"], str) or re.fullmatch(r"[0-9a-f]{64}", row["request_digest"]) is None:
                raise AccountBudgetRefused("invalid account claim digest")
            _integer(row["reserved_cents"], self.turnover_cap)
            _integer(row["claimed_ns"], value["clock_ns"])
            if row["filled_cents"] is None:
                if row["resolved_ns"] is not None:
                    raise AccountBudgetRefused("invalid unresolved claim")
            else:
                _integer(row["filled_cents"], row["reserved_cents"])
                _integer(row["resolved_ns"], value["clock_ns"])
                if row["resolved_ns"] < row["claimed_ns"]:
                    raise AccountBudgetRefused("invalid claim clock")
                fills += row["filled_cents"] > 0
        if fills != value["total_fills"]:
            raise AccountBudgetRefused("invalid fill total")
        if self._turnover(value, value["clock_ns"]) > self.turnover_cap:
            raise AccountBudgetRefused("invalid account turnover")

    def _write(self, parent, value):
        self._validate(value)
        data = canonical(value)
        if len(data) > MAX_BYTES:
            raise AccountBudgetRefused("account budget too large")
        name = ".account-budget-" + secrets.token_hex(16)
        target = name if parent is not None else self.path.parent / name
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                     0o600, dir_fd=parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                if os.name == "posix" and self.owner != os.geteuid():
                    os.fchown(stream.fileno(), self.owner, -1)
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(target, self.path.name if parent is not None else self.path,
                       src_dir_fd=parent, dst_dir_fd=parent)
            if parent is not None:
                os.fsync(parent)
        finally:
            try:
                os.unlink(target, dir_fd=parent)
            except FileNotFoundError:
                pass

    def rebind_unused(self):
        """Adopt an existing, valid, untouched ledger under its serialization lock."""
        with self._locked() as parent:
            value = self._read(parent, prior_binding=True)
            if (value["total_claims"] != 0 or value["total_fills"] != 0
                    or value["clock_ns"] != 0 or value["claims"] != {}):
                raise AccountBudgetRefused("account budget already used")
            value.update(self._header())
            self._write(parent, value)
            return value

    def rollover(self):
        """Carry every resolved claim into a new approval without resetting clocks or spend."""
        with self._locked() as parent:
            value = self._read(parent, prior_binding=True)
            if any(row["filled_cents"] is None for row in value["claims"].values()):
                raise AccountBudgetRefused("unresolved account claims prevent rollover")
            value.update(self._header())
            self._write(parent, value)
            return value

    def initialize(self):
        with self._locked() as parent:
            try:
                return self._read(parent)
            except FileNotFoundError:
                # A deleted or lost state file must not replenish an approval.
                # Publish the marker first; a crash in initialization fails closed.
                marker = self.path.with_suffix(".initialized")
                try:
                    fd = os.open(marker.name if parent is not None else marker,
                                 os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                                 0o600, dir_fd=parent)
                except FileExistsError:
                    raise AccountBudgetRefused("account budget state missing after initialization") from None
                with os.fdopen(fd, "wb") as stream:
                    stream.write(canonical(self._header()))
                    stream.flush()
                    os.fsync(stream.fileno())
                if parent is not None:
                    os.fsync(parent)
                value = {**self._header(), "total_claims": 0, "total_fills": 0, "clock_ns": 0, "claims": {}}
                self._write(parent, value)
                return value

    @staticmethod
    def _turnover(value, now):
        return sum(row["reserved_cents"] if row["filled_cents"] is None else
                   row["filled_cents"] if row["resolved_ns"] >= now - WINDOW_NS else 0
                   for row in value["claims"].values())

    def claim(self, client_id, buy_notional_cents, request, *, now_ns=None):
        if not isinstance(client_id, str) or not 0 < len(client_id) <= 36:
            raise AccountBudgetRefused("invalid account client id")
        _integer(buy_notional_cents, self.turnover_cap)
        digest = hashlib.sha256(canonical(request)).hexdigest()
        with self._locked() as parent:
            value = self._read(parent)
            now = _integer(time.time_ns() if now_ns is None else now_ns)
            if now < value["clock_ns"]:
                raise AccountBudgetRefused("account budget clock moved backwards")
            if client_id in value["claims"]:
                raise AccountBudgetRefused("account client id already claimed")
            if value["total_claims"] >= ORDER_CAP or self._turnover(value, now) + buy_notional_cents > self.turnover_cap:
                raise AccountBudgetRefused("account live budget exhausted")
            value["claims"][client_id] = {"request_digest": digest, "reserved_cents": buy_notional_cents,
                "filled_cents": None, "claimed_ns": now, "resolved_ns": None}
            value["total_claims"] += 1
            value["clock_ns"] = now
            self._write(parent, value)

    def resolve(self, client_id, filled_buy_cents, *, now_ns=None):
        _integer(filled_buy_cents, MAX_NS)
        with self._locked() as parent:
            value = self._read(parent)
            row = value["claims"].get(client_id)
            if row is None or filled_buy_cents > row["reserved_cents"]:
                raise AccountBudgetRefused("account resolution mismatch")
            if row["filled_cents"] is not None:
                if row["filled_cents"] != filled_buy_cents:
                    raise AccountBudgetRefused("conflicting account resolution")
                return False
            now = max(value["clock_ns"], _integer(time.time_ns() if now_ns is None else now_ns))
            row.update(filled_cents=filled_buy_cents, resolved_ns=now)
            value["clock_ns"] = now
            value["total_fills"] += filled_buy_cents > 0
            self._write(parent, value)
            return True

    def reconcile(self, client_id, filled_buy_cents, *, now_ns=None):
        """Called only after the caller has established authoritative final venue state."""
        return self.resolve(client_id, filled_buy_cents, now_ns=now_ns)

    def snapshot(self, *, now_ns=None):
        with self._locked() as parent:
            value = self._read(parent)
            now = max(value["clock_ns"], _integer(time.time_ns() if now_ns is None else now_ns))
            return {**value, "buy_turnover_cents": self._turnover(value, now),
                    "unresolved_reservations": {cid: row["reserved_cents"] for cid, row in value["claims"].items()
                                                if row["filled_cents"] is None}}
