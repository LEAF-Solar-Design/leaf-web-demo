"""Polymarket US adapter for the KalshiBook client surface (prep slice 2).

Facts verified 2026-09-10 in https://docs.polymarket.us/api-reference/introduction
and https://docs.polymarket.us/api-reference/authentication: retail REST is
https://api.polymarket.us; public REST is https://gateway.polymarket.us. WebSockets
are wss://api.polymarket.us/v1/ws/markets (books/trades) and /v1/ws/private
(orders/positions/balances). X-PM-Access-Key identifies the key; X-PM-Timestamp
is milliseconds within 30 seconds of server time; X-PM-Signature is base64 of
Ed25519 signing timestamp + method + path. Keys require iOS KYC and the developer
portal. The caller reads raw Ed25519 seed bytes from the file named by
POLYMARKET_US_KEY_FILE, never argv. Signing uses the existing cryptography dependency.

https://docs.polymarket.us/api-reference/orders/create-order documents POST
/v1/orders: marketSlug, type ORDER_TYPE_LIMIT or ORDER_TYPE_MARKET, USD price
value 0.01..0.99, numeric quantity, tif TIME_IN_FORCE_DAY, GOOD_TILL_CANCEL,
GOOD_TILL_DATE, IMMEDIATE_OR_CANCEL or FILL_OR_KILL (all TIME_IN_FORCE_ prefixed).
Use intent ORDER_INTENT_BUY_LONG/SELL_LONG/BUY_SHORT/SELL_SHORT, or outcomeSide
OUTCOME_SIDE_YES/NO with action ORDER_ACTION_BUY/SELL. Automated orders set
manualOrderIndicator MANUAL_ORDER_INDICATOR_AUTOMATIC. slippageTolerance and
goodTillTime are optional. Cancel paths are POST /v1/order/{orderId}/cancel,
/v1/orders/open/cancel and /v1/orders/batched/cancel (up to 20). ORDER_STATE_
states are PENDING_NEW, NEW, PENDING_REPLACE, PENDING_CANCEL, PENDING_RISK,
PARTIALLY_FILLED, FILLED, CANCELED, REPLACED, REJECTED and EXPIRED.
https://docs.polymarket.us/api-reference/rate-limits publishes 20 requests/s/key.

https://docs.polymarket.us/fees (effective 2026-07-01): taker dollars are
0.06 * C * p * (1-p); maker rebate coefficient is -0.0125, with banker's
rounding to cents per fill. At 10c/50c/90c taker cost is 0.54c/1.50c/0.54c
per contract. https://docs.polymarket.us/faqs/general-faqs describes Thursday
2-6 AM ET maintenance, prior cancellation of open orders and API HTTP 503.

Read mappings: /api-reference/markets/get-market-by-slug,
/api-reference/markets/get-market-settlement, /api-reference/account/get-account-balances,
/api-reference/portfolio/get-user-positions and /api-reference/orders/get-order
under https://docs.polymarket.us. Settlement prices other than binary 0/1 stay
unknown, never a synthetic void. Crypto slug shape, contract settlement method,
data source and displayed depth remain unknown until listing (depth assumed
available from get-market-book).

The injected fetch(method, path, body) replaces HTTP completely. Default HTTP
requires auth and a durable journal directory. Client ids are local ownership
keys, not undocumented venue idempotency fields. The requested single retry on
5xx/timeout can duplicate a create when the first response was lost; retried
creates therefore always remain UNKNOWN, even on a successful second response.
Venue idempotency must be resolved before live activation. Submissions without a venue id are
retained for operator reconciliation, never matched by ticker alone.

nothing in this module is exercised against the venue until a crypto contract lists and the operator has an API key
"""
from __future__ import annotations

import asyncio
import base64
import os
import time
from collections import deque
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from pathlib import Path
from typing import Any, Awaitable, Callable
from urllib.parse import quote

import aiohttp
import orjson
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

REST_URL = "https://api.polymarket.us"
PUBLIC_URL = "https://gateway.polymarket.us"
KEY_FILE_ENV = "POLYMARKET_US_KEY_FILE"
MAX_BODY_BYTES = 256 * 1024
MAX_JOURNAL_BYTES = 1024 * 1024
MAX_OWNED = 2_000
TIMEOUT_S = 10.0
TERMINAL = {"FILLED", "PARTIAL", "GONE", "CANCELED"}
Fetch = Callable[[str, str, dict | None], Awaitable[tuple[int, Any]]]


class VenueError(RuntimeError):
    def __init__(self, http: int = 0, message: str = "venue request failed") -> None:
        self.http = http
        super().__init__(f"polymarket US http {http}: {message}")


class VenueMaintenance(VenueError):
    """A 503 refusal; KalshiBook releases the reservation on this exception."""


class RateLimitExceeded(VenueError):
    """Local per-key request budget exhausted, before transmission."""


class PolymarketUSAuth:
    def __init__(self, key_id: str, private_key_bytes: bytes) -> None:
        if not isinstance(key_id, str) or not key_id or any(c in key_id for c in "\r\n"):
            raise ValueError("invalid access key id")
        try:
            self._key = Ed25519PrivateKey.from_private_bytes(private_key_bytes)
        except Exception:
            raise ValueError("invalid Ed25519 private key") from None
        self._key_id = key_id

    def __repr__(self) -> str:
        return "PolymarketUSAuth(<redacted>)"

    def headers(self, method: str, path: str, now_ms: int) -> dict[str, str]:
        if type(now_ms) is not int or now_ms < 0 or method not in {"GET", "POST"}:
            raise ValueError("invalid signing input")
        if not isinstance(path, str) or not path.startswith("/"):
            raise ValueError("invalid signing path")
        try:
            signature = base64.b64encode(self._key.sign(f"{now_ms}{method}{path}".encode())).decode("ascii")
        except Exception:
            raise ValueError("Ed25519 signing failed") from None
        return {"X-PM-Access-Key": self._key_id, "X-PM-Timestamp": str(now_ms),
                "X-PM-Signature": signature}


class TokenBucket:
    """20-token burst, 20/s refill, plus a strict rolling one-second ceiling.

    Share one bucket between clients that share an API key.
    """
    def __init__(self, clock: Callable[[], float] = time.monotonic) -> None:
        self.clock = clock
        self.tokens = 20.0
        self.updated = clock()
        self._requests: deque[float] = deque()

    def take(self) -> None:
        now = self.clock()
        self.tokens = min(20.0, self.tokens + max(0.0, now - self.updated) * 20)
        self.updated = now
        while self._requests and now - self._requests[0] >= 1:
            self._requests.popleft()
        if self.tokens < 1 or len(self._requests) >= 20:
            raise RateLimitExceeded(429, "local request limit")
        self.tokens -= 1
        self._requests.append(now)


def _identifier(value: Any) -> str:
    if not isinstance(value, str) or not 0 < len(value) <= 256:
        raise ValueError("invalid identifier")
    return value


def _number(value: Any) -> Decimal:
    if type(value) not in (int, float, str) or len(str(value)) > 40:
        raise ValueError("invalid number")
    try:
        number = Decimal(str(value))
    except InvalidOperation:
        raise ValueError("invalid number") from None
    if not number.is_finite() or number < 0:
        raise ValueError("invalid number")
    return number


def _count(value: Any) -> int:
    number = _number(value)
    if number != number.to_integral_value() or number > 100_000:
        raise ValueError("invalid whole count")
    return int(number)


def _parse_order(reply: Any, count: int, expected_id: str | None = None) -> dict:
    try:
        if not isinstance(reply, dict):
            raise ValueError()
        if "executions" in reply:
            oid = _identifier(reply.get("id"))
            executions = reply["executions"]
            if not isinstance(executions, list) or not 0 < len(executions) <= 1000:
                raise ValueError()
            snapshots = [execution["order"] for execution in executions]
        else:
            snapshots = [reply.get("order", reply)]
            oid = _identifier(snapshots[0].get("id"))
        if expected_id is not None and oid != expected_id:
            raise ValueError()
        previous = 0
        for order in snapshots:
            if not isinstance(order, dict) or order.get("id") != oid:
                raise ValueError()
            filled = _count(order.get("cumQuantity"))
            remaining = _count(order.get("leavesQuantity"))
            if _count(order.get("quantity")) != count or not previous <= filled <= count:
                raise ValueError()
            if filled + remaining > count:
                raise ValueError()
            previous = filled
        state = order.get("state")
        allowed = {"ORDER_STATE_" + s for s in ("FILLED", "PARTIALLY_FILLED", "CANCELED", "REJECTED", "EXPIRED")}
        if state not in allowed or remaining != 0:
            raise ValueError()
        if state == "ORDER_STATE_FILLED" and filled != count:
            raise ValueError()
        if state == "ORDER_STATE_PARTIALLY_FILLED" and not 0 < filled < count:
            raise ValueError()
        if state == "ORDER_STATE_REJECTED" and filled:
            raise ValueError()
        return {"order_id": oid, "fill_count": filled, "remaining_count": remaining, "status": state}
    except (ValueError, TypeError, KeyError, AttributeError):
        raise VenueError(200, "malformed order reply") from None


class PolymarketUSLive:
    def __init__(self, fetch: Fetch | None = None, *, auth: PolymarketUSAuth | None = None,
                 journal_dir: str | Path | None = None, bucket: TokenBucket | None = None) -> None:
        if fetch is None and (auth is None or journal_dir is None):
            raise ValueError("HTTP requires auth and journal_dir")
        self.auth = auth
        self._fetch = fetch
        self._session: aiohttp.ClientSession | None = None
        self.bucket = bucket if bucket is not None else TokenBucket()
        self._lock = asyncio.Lock()
        self._records: dict[str, dict] = {}
        self._owned: dict[str, str] = {}
        self._journal_failed = False
        self.shutdown_result: dict | None = None
        self.journal_path = Path(journal_dir) / "polymarket-us-orders.jsonl" if journal_dir is not None else None
        if self.journal_path is not None:
            self.load_journal()

    def __repr__(self) -> str:
        return "PolymarketUSLive()"

    @property
    def unresolved(self) -> list[str]:
        return [cid for cid, state in self._owned.items() if state not in TERMINAL]

    def load_journal(self) -> None:
        try:
            with self.journal_path.open("rb") as stream:
                data = stream.read(MAX_JOURNAL_BYTES + 1)
        except FileNotFoundError:
            return
        if len(data) > MAX_JOURNAL_BYTES or (data and not data.endswith(b"\n")):
            raise RuntimeError("invalid order journal size or incomplete row")
        records = {}
        try:
            for line in data.splitlines():
                row = orjson.loads(line)
                cid = _identifier(row["client_id"])
                _identifier(row["ticker"])
                if row["state"] not in TERMINAL | {"SENT", "UNKNOWN"}:
                    raise ValueError()
                if type(row["side_yes"]) is not bool or type(row["price_cents"]) is not int or not 1 <= row["price_cents"] <= 99:
                    raise ValueError()
                if not 0 < _count(row["count"]) or _count(row["fill_count"]) > row["count"]:
                    raise ValueError()
                if row["venue_order_id"] is not None:
                    _identifier(row["venue_order_id"])
                records[cid] = row
                if len(records) > MAX_OWNED:
                    raise ValueError()
        except (ValueError, KeyError, TypeError):
            raise RuntimeError("malformed order journal") from None
        self._records = records
        self._owned = {cid: row["state"] for cid, row in records.items()}

    def _transition(self, cid: str, state: str, **updates: Any) -> None:
        row = dict(self._records[cid], **updates)
        row.update(client_id=cid, state=state, ts_ns=time.time_ns())
        if self.journal_path is not None:
            try:
                self.journal_path.parent.mkdir(parents=True, exist_ok=True)
                payload = orjson.dumps(row) + b"\n"
                size = self.journal_path.stat().st_size if self.journal_path.exists() else 0
                if size + len(payload) > MAX_JOURNAL_BYTES:
                    raise OSError("journal capacity reached")
                with self.journal_path.open("ab") as stream:
                    stream.write(payload)
                    stream.flush()
                    os.fsync(stream.fileno())
            except OSError:
                self._journal_failed = True
                self._owned[cid] = "UNKNOWN"
                raise RuntimeError("order journal write failed") from None
        self._records[cid] = row
        self._owned[cid] = state

    async def __aenter__(self) -> PolymarketUSLive:
        if self._fetch is None and self._session is None:
            self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=TIMEOUT_S))
        return self

    async def __aexit__(self, *exc: Any) -> None:
        try:
            self.shutdown_result = await self.cancel_owned()
        finally:
            if self._session is not None:
                await self._session.close()
                self._session = None

    async def _http(self, method: str, path: str, body: dict | None) -> tuple[int, Any]:
        if self._session is None:
            raise RuntimeError("client not entered")
        public = path.startswith(("/v1/market/", "/v1/markets/"))
        headers = {} if public or path == "/v1/health" else self.auth.headers(method, path.split("?", 1)[0], time.time_ns() // 1_000_000)
        base = PUBLIC_URL if public else REST_URL
        async with self._session.request(method, base + path, json=body, headers=headers,
                                         allow_redirects=False) as response:
            # Error bodies may be HTML. Their HTTP status still controls maintenance/retry.
            if response.status >= 500:
                return response.status, {}
            payload = bytearray()
            async for chunk in response.content.iter_chunked(65536):
                payload.extend(chunk)
                if len(payload) > MAX_BODY_BYTES:
                    raise VenueError(response.status, "response body too large")
            try:
                return response.status, orjson.loads(payload) if payload else {}
            except ValueError:
                raise VenueError(response.status, "invalid JSON") from None

    async def _request(self, method: str, path: str, body: dict | None = None) -> Any:
        if body is not None and len(orjson.dumps(body)) > MAX_BODY_BYTES:
            raise ValueError("request body too large")
        for attempt in range(2):
            ambiguous_create = attempt == 1 and method == "POST" and path == "/v1/orders"
            try:
                self.bucket.take()
            except RateLimitExceeded:
                if ambiguous_create:
                    raise VenueError(0, "create outcome unknown after retry limit") from None
                raise
            try:
                async with asyncio.timeout(TIMEOUT_S):
                    status, reply = await (self._fetch or self._http)(method, path, body)
            except TimeoutError:
                if attempt == 0:
                    continue
                raise VenueError(0, "request timed out") from None
            if ambiguous_create:
                # A second response cannot prove whether the first create also executed.
                # Do not let even a second-attempt 503 retire the first SENT record.
                raise VenueError(status, "create outcome unknown after retry")
            if status == 503:
                raise VenueMaintenance(503, "venue maintenance")
            if 500 <= status <= 599 and attempt == 0:
                continue
            if not 200 <= status < 300:
                raise VenueError(status)
            try:
                if len(orjson.dumps(reply)) > MAX_BODY_BYTES:
                    raise VenueError(status, "response body too large")
            except (TypeError, RecursionError):
                raise VenueError(status, "invalid JSON reply") from None
            if not isinstance(reply, dict):
                raise VenueError(status, "expected response object")
            return reply
        raise AssertionError("unreachable")

    async def place_ioc_buy(self, ticker: str, side_yes: bool, price_cents: int, count: int,
                            client_id: str) -> dict:
        _identifier(ticker)
        _identifier(client_id)
        if type(side_yes) is not bool or type(price_cents) is not int or not 1 <= price_cents <= 99:
            raise ValueError("invalid side or price")
        if type(count) is not int or not 1 <= count <= 100_000:
            raise ValueError("invalid count")
        body = {"marketSlug": ticker, "type": "ORDER_TYPE_LIMIT",
                "price": {"value": f"{price_cents / 100:.2f}", "currency": "USD"},
                "quantity": count, "tif": "TIME_IN_FORCE_IMMEDIATE_OR_CANCEL",
                "outcomeSide": "OUTCOME_SIDE_YES" if side_yes else "OUTCOME_SIDE_NO",
                "action": "ORDER_ACTION_BUY", "manualOrderIndicator": "MANUAL_ORDER_INDICATOR_AUTOMATIC"}
        async with self._lock:
            if self._journal_failed or self.unresolved:
                raise RuntimeError("resolve order journal before submitting")
            if client_id in self._owned or len(self._owned) >= MAX_OWNED:
                raise ValueError("client id already owned or owned table full")
            self._records[client_id] = {"ticker": ticker, "side_yes": side_yes,
                "price_cents": price_cents, "count": count, "fill_count": 0, "venue_order_id": None}
            self._transition(client_id, "SENT")
            try:
                raw = await self._request("POST", "/v1/orders", body)
                if isinstance(raw.get("id"), str):
                    self._transition(client_id, "SENT", venue_order_id=_identifier(raw["id"]))
                reply = _parse_order(raw, count)
            except (VenueMaintenance, RateLimitExceeded):
                self._transition(client_id, "GONE")
                raise
            except BaseException:
                self._transition(client_id, "UNKNOWN")
                raise
            filled = reply["fill_count"]
            self._transition(client_id, "FILLED" if filled == count else "PARTIAL" if filled else "GONE",
                             fill_count=filled, venue_order_id=reply["order_id"])
            return reply

    async def reconcile(self) -> list[str]:
        async with self._lock:
            for cid in list(self.unresolved):
                record = self._records[cid]
                oid = record.get("venue_order_id")
                if oid is None:
                    continue
                try:
                    raw = await self._request("GET", "/v1/order/" + quote(oid, safe=""))
                    reply = _parse_order(raw, record["count"], oid)
                    filled = reply["fill_count"]
                    self._transition(cid, "FILLED" if filled == record["count"] else "PARTIAL" if filled else "GONE",
                                     fill_count=filled)
                except Exception:
                    self._transition(cid, "UNKNOWN")
            return self.unresolved

    async def cancel_owned(self) -> dict:
        cancelled, failed = [], []
        async with self._lock:
            for cid in list(self.unresolved):
                oid = self._records[cid].get("venue_order_id")
                if oid is None:
                    continue
                try:
                    await self._request("POST", "/v1/order/" + quote(oid, safe="") + "/cancel", {})
                    cancelled.append(cid)
                except Exception:
                    failed.append(cid)
        unresolved = await self.reconcile()
        result = {"cancelled": cancelled, "failed": failed, "unresolved": unresolved,
                  "clean": not failed and not unresolved}
        self.shutdown_result = result
        return result

    async def balance(self) -> int:
        reply = await self._request("GET", "/v1/account/balances")
        try:
            rows = reply["balances"]
            if not isinstance(rows, list) or not all(isinstance(row, dict) for row in rows):
                raise ValueError()
            usd = [row for row in rows if row.get("currency") == "USD"]
            if len(usd) != 1:
                raise ValueError()
            # Buying power is spendable collateral; currentBalance can include reservations.
            dollars = _number(usd[0]["buyingPower"])
            return int((dollars * 100).to_integral_value(rounding=ROUND_DOWN))
        except (ValueError, TypeError, KeyError):
            raise VenueError(200, "malformed USD balance") from None

    async def exchange_status(self) -> dict:
        """Maintenance pauses both books; other failures retain the driver's last state."""
        self.bucket.take()
        async with asyncio.timeout(TIMEOUT_S):
            status, reply = await (self._fetch or self._http)("GET", "/v1/health", None)
        if status == 503:
            active = False
        elif status == 200 and isinstance(reply, dict):
            active = reply.get("status") == "ok"
        else:
            raise VenueError(status, "health request failed")
        return {"exchange_active": active, "trading_active": active, "estimated_resume": None}

    async def balance_cents(self) -> int:
        return await self.balance()

    async def positions(self) -> list[dict]:
        reply = await self._request("GET", "/v1/portfolio/positions")
        rows = reply.get("positions")
        if not isinstance(rows, dict) or len(rows) > MAX_OWNED or reply.get("eof") is not True:
            raise VenueError(200, "malformed or incomplete positions")
        if not all(isinstance(row, dict) for row in rows.values()):
            raise VenueError(200, "malformed positions")
        return [dict(row, marketSlug=slug) for slug, row in rows.items()]

    async def market(self, ticker: str) -> dict:
        slug = quote(_identifier(ticker), safe="")
        reply = await self._request("GET", "/v1/market/slug/" + slug)
        market = reply.get("market")
        if not isinstance(market, dict) or market.get("slug") != ticker:
            raise VenueError(200, "malformed market")
        raw = await self._request("GET", f"/v1/markets/{slug}/settlement")
        if raw.get("slug") != ticker:
            raise VenueError(200, "settlement slug mismatch")
        close_ms = None
        if market.get("endDate"):
            try:
                close = datetime.fromisoformat(market["endDate"].replace("Z", "+00:00"))
                if close.tzinfo is None:
                    raise ValueError()
                close_ms = int(close.timestamp() * 1000)
            except (ValueError, TypeError, AttributeError, OverflowError):
                raise VenueError(200, "malformed market close time") from None
        result = None
        if market.get("closed") is True and raw.get("settlement") is not None:
            try:
                price = _number(raw["settlement"])
            except ValueError:
                raise VenueError(200, "malformed settlement price") from None
            result = "yes" if price == 1 else "no" if price == 0 else None
        return dict(market, settlement=raw.get("settlement"), raw_settlement=raw,
                    result=result, settled=result is not None, close_time_ms=close_ms,
                    status="settled" if result is not None else "unsettled")
