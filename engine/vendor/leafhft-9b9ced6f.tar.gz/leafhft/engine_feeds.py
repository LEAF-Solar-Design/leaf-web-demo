"""The FEEDS table: every data feed an engine manifest may name, and whether it is live here.

Today the only live feeds are the Kalshi order books, one per SYMBOL_MAP symbol. A manifest that
names a feed outside this table is invalid; a feed that is only recorded (the FEED path, plan F1,
is deferred) keeps an engine out of live trading. Importing this module is pure data, no I/O.

FEEDS is a literal written by scripts/gen_book_inventory.py from the book library
(leafhft/library/kalshi_v2, itself described from SYMBOL_MAP); tests/test_books_inventory.py
fails when regenerating would change a byte. `scan_library` reads the library only when called
(B-STD B3): a bad manifest there is reported by its path and never breaks an import.
"""
from __future__ import annotations

import os
import stat
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

LIVE_PROVISIONED = "live_provisioned"
RECORDED_ONLY = "recorded_only"
FEED_STATUSES = frozenset({LIVE_PROVISIONED, RECORDED_ONLY})
KALSHI_BOOK_KIND = "kalshi_book"


@dataclass(frozen=True)
class Feed:
    id: str
    kind: str
    status: str
    description: str

    def __post_init__(self):
        if self.status not in FEED_STATUSES:
            raise ValueError(f"feed {self.id}: status must be one of {sorted(FEED_STATUSES)}")


def kalshi_book_feed_id(symbol: str) -> str:
    return f"kalshi-book:{symbol}"


# BEGIN GENERATED FEEDS: scripts/gen_book_inventory.py writes this block; do not edit by hand.
FEEDS: Mapping[str, Feed] = MappingProxyType({
    "kalshi-book:BNB-15M": Feed(
        "kalshi-book:BNB-15M", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXBNB15M, settled on BNBUSD_RTI."),
    "kalshi-book:BNB-1H": Feed(
        "kalshi-book:BNB-1H", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXBNBD, settled on BNBUSD_RTI."),
    "kalshi-book:BTC-15M": Feed(
        "kalshi-book:BTC-15M", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXBTC15M, settled on BRTI."),
    "kalshi-book:BTC-1H": Feed(
        "kalshi-book:BTC-1H", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXBTCD, settled on BRTI."),
    "kalshi-book:DOGE-15M": Feed(
        "kalshi-book:DOGE-15M", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXDOGE15M, settled on DOGEUSD_RTI."),
    "kalshi-book:ETH-15M": Feed(
        "kalshi-book:ETH-15M", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXETH15M, settled on ETHUSD_RTI."),
    "kalshi-book:ETH-1H": Feed(
        "kalshi-book:ETH-1H", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXETHD, settled on ETHUSD_RTI."),
    "kalshi-book:HYPE-15M": Feed(
        "kalshi-book:HYPE-15M", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXHYPE15M, settled on HYPEUSD_RTI."),
    "kalshi-book:HYPE-1H": Feed(
        "kalshi-book:HYPE-1H", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXHYPED, settled on HYPEUSD_RTI."),
    "kalshi-book:NEAR-15M": Feed(
        "kalshi-book:NEAR-15M", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXNEAR15M, settled on NEARUSD_RTI."),
    "kalshi-book:SOL-15M": Feed(
        "kalshi-book:SOL-15M", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXSOL15M, settled on SOLUSD_RTI."),
    "kalshi-book:XRP-15M": Feed(
        "kalshi-book:XRP-15M", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXXRP15M, settled on XRPUSD_RTI."),
    "kalshi-book:XRP-1H": Feed(
        "kalshi-book:XRP-1H", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXXRPD, settled on XRPUSD_RTI."),
    "kalshi-book:ZEC-15M": Feed(
        "kalshi-book:ZEC-15M", KALSHI_BOOK_KIND, LIVE_PROVISIONED,
        "Kalshi order book and trades for series KXZEC15M, settled on ZECUSD_RTI."),
})
# END GENERATED FEEDS


def book_feeds(symbols) -> list[str]:
    """The live book feed ids for the given symbols, in the order given."""
    return [kalshi_book_feed_id(symbol) for symbol in symbols]


def _manifest_feeds(manifest):
    inputs = getattr(manifest, "inputs", None)
    if inputs is None and isinstance(manifest, Mapping):
        inputs = manifest.get("inputs")
    if not isinstance(inputs, Mapping):
        raise TypeError("feeds_live_provisioned: expected an EngineManifest or a manifest mapping")
    feeds = inputs.get("feeds")
    if not isinstance(feeds, (list, tuple)):
        raise TypeError("feeds_live_provisioned: inputs.feeds must be a list")
    return feeds


def feeds_live_provisioned(manifest) -> list[str]:
    """Return the feed ids that are NOT live here, in manifest order; empty means allowed.

    Unknown ids and recorded_only feeds are both returned. A malformed manifest raises rather
    than returning an empty (allowing) list, so a caller can never fail open.
    """
    offending = []
    for feed_id in _manifest_feeds(manifest):
        if isinstance(feed_id, Mapping) and isinstance(feed_id.get("feed_id"), str):
            feed_id = feed_id["feed_id"]
        feed = FEEDS.get(feed_id) if isinstance(feed_id, str) else None
        if feed is None or feed.status != LIVE_PROVISIONED:
            shown = feed_id if isinstance(feed_id, str) else repr(feed_id)
            if shown not in offending:
                offending.append(shown)
    return offending


class FeedPinUnavailable(ValueError):
    """A feed has no verified library pin in the effective lock."""


def live_feed_pins(feed_ids, *, root=None) -> dict[str, str]:
    """Read and verify each requested book manifest against one lock snapshot."""
    from .books import pins

    requested = list(feed_ids)
    if not requested:
        return {}
    try:
        lock = pins.load_lock(root)
        effective = pins.effective_pins(lock)
    except (pins.PinError, OSError) as exc:
        raise FeedPinUnavailable(f"{requested[0]}: {getattr(exc, 'code', 'missing')}: {exc}") from None
    scan = scan_library(None if root is None else Path(root) / "leafhft" / "library")
    entries = {entry.manifest.book_id: entry for entry in scan.entries}
    result = {}
    for feed_id in requested:
        entry = entries.get(feed_id)
        if entry is None:
            raise FeedPinUnavailable(f"{feed_id}: missing: no library manifest") from None
        path = "leafhft/library/" + entry.path
        try:
            pins.resolve_path(path, root, pins=lock)
        except (pins.PinError, OSError) as exc:
            raise FeedPinUnavailable(f"{feed_id}: {getattr(exc, 'code', 'missing')}: {exc}") from None
        result[feed_id] = "sha256:" + effective[path].sha256
    return result


# ---------------------------------------------------------------- the book library (read on call only)

LIBRARY_DIR = Path(__file__).resolve().parent / "library"
LIBRARY_MANIFEST = "manifest.json"
# The approved data file names (books/pins.py APPROVED_LIBRARY_FILES is the gate's copy).
LIBRARY_DATA_FILES = frozenset({"manifest.json", "fees.json", "grid.json", "tape.jsonl"})
MAX_LIBRARY_NODES = 1024
MAX_ACTIVATION_DEPTH = 32
# A library manifest describes a book; it never switches a unit on or names a binding (B-STD
# amendment 7). Any of these keys, at any depth and in any letter case, refuses the manifest.
ACTIVATION_KEYS = frozenset({"unit", "units", "service", "services", "timer", "timers", "systemd",
                             "enable", "enabled", "binding", "bindings", "lane", "lanes", "live",
                             "engine", "engines"})
_ACTIVATION_SUFFIXES = (".service", ".timer", ".socket", "bindings.json", "enabled.txt")


@dataclass(frozen=True)
class LibraryEntry:
    path: str  # library-relative POSIX path, e.g. "kalshi_v2/BTC-15M/manifest.json"
    manifest: object  # books.manifest.BookManifest


@dataclass(frozen=True)
class LibraryProblem:
    path: str  # library-relative POSIX path of the bad file or directory
    code: str
    detail: str


@dataclass(frozen=True)
class LibraryScan:
    entries: tuple  # LibraryEntry, sorted by path
    problems: tuple  # LibraryProblem, in scan order

    @property
    def manifests(self) -> tuple:
        return tuple(entry.manifest for entry in self.entries)


def activation_refusal(doc, depth: int = 0) -> str | None:
    """Why a parsed manifest document tries to activate something, or None. Bounded depth."""
    if depth > MAX_ACTIVATION_DEPTH:
        return "nesting too deep"
    if isinstance(doc, dict):
        for key, value in doc.items():
            if isinstance(key, str) and key.lower() in ACTIVATION_KEYS:
                return f"key {key[:32]!r} names a unit or a binding"
            found = activation_refusal(value, depth + 1)
            if found:
                return found
    elif isinstance(doc, list):
        for value in doc:
            found = activation_refusal(value, depth + 1)
            if found:
                return found
    elif isinstance(doc, str) and doc.lower().endswith(_ACTIVATION_SUFFIXES):
        return f"value {doc[:64]!r} names a unit or a binding"
    return None


def _names(path: Path) -> list[str]:
    with os.scandir(path) as listing:
        return sorted(entry.name for entry in listing)


def _read_manifest_bytes(path: Path, limit: int) -> bytes:
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0))
    with os.fdopen(fd, "rb") as handle:
        return handle.read(limit + 1)


def scan_library(root=None) -> LibraryScan:
    """Every <integration>/<book>/manifest.json under the library, decoded strictly.

    Reads only when called, never at import. A bad file never raises: it lands in `problems` with
    its library-relative path and a code, and every other manifest still loads. Symlinks, special
    files, unapproved names, a manifest that names a unit or a binding, a book directory that
    disagrees with its manifest's symbol and a duplicate book id are all problems. Bounded to
    MAX_LIBRARY_NODES directory entries.
    """
    from .books.manifest import (
        MAX_MANIFEST_BYTES, ManifestInvalid, StrictJsonError, decode_manifest, strict_json_loads,
    )

    base = Path(LIBRARY_DIR if root is None else root)
    entries, problems, seen = [], [], {}
    budget = [MAX_LIBRARY_NODES]

    def problem(rel, code, detail):
        problems.append(LibraryProblem(rel, code, detail))

    def listing(path, rel):
        try:
            names = _names(path)
        except OSError as exc:
            problem(rel, "unreadable", type(exc).__name__)
            return []
        budget[0] -= len(names)
        if budget[0] < 0:
            problem(rel, "too_many", f"the library holds more than {MAX_LIBRARY_NODES} entries")
            return []
        return names

    def is_dir(path, rel):
        try:
            mode = os.lstat(path).st_mode
        except OSError as exc:
            problem(rel, "unreadable", type(exc).__name__)
            return False
        if not stat.S_ISDIR(mode):
            problem(rel, "not_a_directory", "the library holds <integration>/<book>/ directories only")
            return False
        return True

    if not base.is_dir():
        return LibraryScan((), ())
    for integration in listing(base, "."):
        if budget[0] < 0 or not is_dir(base / integration, integration):
            continue
        for book in listing(base / integration, integration):
            book_rel = f"{integration}/{book}"
            if budget[0] < 0 or not is_dir(base / integration / book, book_rel):
                continue
            names = listing(base / integration / book, book_rel)
            if budget[0] >= 0 and LIBRARY_MANIFEST not in names:
                problem(book_rel, "manifest_missing", f"no {LIBRARY_MANIFEST}")
            for name in names:
                rel = f"{book_rel}/{name}"
                path = base / integration / book / name
                if name not in LIBRARY_DATA_FILES:
                    problem(rel, "unapproved_file", f"allowed names: {sorted(LIBRARY_DATA_FILES)}")
                    continue
                try:
                    regular = stat.S_ISREG(os.lstat(path).st_mode)
                except OSError as exc:
                    problem(rel, "unreadable", type(exc).__name__)
                    continue
                if not regular:
                    problem(rel, "not_regular", "a symlink or special file")
                    continue
                if name != LIBRARY_MANIFEST:
                    continue
                try:
                    raw = _read_manifest_bytes(path, MAX_MANIFEST_BYTES)
                except OSError as exc:
                    problem(rel, "unreadable", type(exc).__name__)
                    continue
                if len(raw) > MAX_MANIFEST_BYTES:
                    problem(rel, "oversize", f"more than {MAX_MANIFEST_BYTES} bytes")
                    continue
                try:
                    refusal = activation_refusal(strict_json_loads(raw))
                except StrictJsonError as exc:
                    problem(rel, exc.code, exc.detail)
                    continue
                if refusal:
                    problem(rel, "activation_refused", refusal)
                    continue
                try:
                    manifest = decode_manifest(raw)
                except ManifestInvalid as exc:
                    problem(rel, exc.code, exc.detail)
                    continue
                if manifest.symbol != book:
                    problem(rel, "book_dir_mismatch", f"symbol {manifest.symbol} lives in {integration}/{manifest.symbol}/")
                    continue
                if manifest.book_id in seen:
                    problem(rel, "duplicate_book", f"{manifest.book_id} is already {seen[manifest.book_id]}")
                    continue
                seen[manifest.book_id] = rel
                entries.append(LibraryEntry(rel, manifest))
    return LibraryScan(tuple(sorted(entries, key=lambda entry: entry.path)), tuple(problems))
