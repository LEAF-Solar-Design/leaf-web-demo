"""The engine loop: feed -> book -> broker fills -> strategy -> risk -> broker -> ledger.

process_event() is the whole hot path and is synchronous; the async driver only pulls from the
feed queue. Budget: p99 under 1 ms per event on this host unloaded (network adds 200 to 1100 ms).
The receipt records p50/p99/max so a regression shows.

Shutdown never invents execution: resting orders are canceled (cancel latency applied), residual
inventory is reported at mid AND at liquidation value (bid, taker fee, slippage), and the receipt
carries cash and buy-and-hold baselines next to the strategy's equity. Any exception in the live
loop still reaches _shutdown, so cancellation and the receipt are guaranteed.
An explicit paper residual policy may submit one IOC after a risk kill.
"""
from __future__ import annotations

import asyncio
import json
from collections import deque
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Iterable

import numpy as np

from .book import Book
from .build import build_identity
from .broker.base import Broker
from .clock import iso, mono_ns, now_ns
from .config import EngineConfig
from .feeds.base import Feed
from .feeds.recorder import Recorder, iter_file
from .ledger import Ledger, LedgerFailed
from .risk import RiskManager
from .strategy.base import Strategy
from .types import QUOTE_UNIT, Fill, Intent, Liquidity, MalformedInput, Quote, Side, TimeInForce, Trade, bps_of, notional_q

LAT_RING = 65_536
MARKOUT_HORIZONS_NS = ((1, 1_000_000_000), (5, 5_000_000_000), (30, 30_000_000_000))
MAX_PENDING_MARKOUTS = 20_000
LIVE_IDLE_TIMEOUT_S = 300.0  # floor for a live-mode idle timeout: the feeds' own heartbeat is 120 s
LIVE_MAX_FEED_RECONNECTS = 3  # risk already stops quoting and cancels resting orders at stale_feed_ms


def _git_sha() -> str:
    """Receipt identity hook kept patchable for the driver tests."""
    return build_identity()["git_sha"]


class Markouts:
    """Signed post-fill drift at 1/5/30 s, two ways: versus the fill price (what we actually earned
    or lost on the position after the fill) and versus the mid at fill time (pure adverse drift,
    spread excluded). Split by maker/taker. Positive means the market moved our way."""

    __slots__ = ("pending", "sum_fill", "sum_mid", "n", "dropped")

    def __init__(self) -> None:
        self.pending = {h: deque() for h, _ in MARKOUT_HORIZONS_NS}
        self.sum_fill: dict[tuple[int, int], float] = {}
        self.sum_mid: dict[tuple[int, int], float] = {}
        self.n: dict[tuple[int, int], int] = {}
        self.dropped = 0

    def add(self, f: Fill, mid_at_fill_i: int) -> None:
        for h, ns in MARKOUT_HORIZONS_NS:
            dq = self.pending[h]
            if len(dq) >= MAX_PENDING_MARKOUTS:
                dq.popleft()
                self.dropped += 1
            dq.append((f.ts_ns + ns, f.price_i, mid_at_fill_i, f.side.sign, f.order_id, int(f.liquidity)))

    def settle(self, now_ns: int, mid_i: int, ledger: Ledger | None) -> None:
        if mid_i <= 0:
            return
        for h, _ in MARKOUT_HORIZONS_NS:
            dq = self.pending[h]
            while dq and dq[0][0] <= now_ns:
                _, px, mid0, sign, oid, liq = dq.popleft()
                vs_fill = sign * bps_of(mid_i - px, px)
                vs_mid = sign * bps_of(mid_i - mid0, mid0) if mid0 > 0 else 0.0
                k = (h, liq)
                self.sum_fill[k] = self.sum_fill.get(k, 0.0) + vs_fill
                self.sum_mid[k] = self.sum_mid.get(k, 0.0) + vs_mid
                self.n[k] = self.n.get(k, 0) + 1
                if ledger is not None:
                    ledger.append(now_ns, "markout", {"h_s": h, "liq": liq, "vs_fill_bps": round(vs_fill, 4), "vs_mid_bps": round(vs_mid, 4), "order_id": oid})

    def summary(self) -> dict:
        out: dict = {}
        for h, _ in MARKOUT_HORIZONS_NS:
            row: dict = {}
            for liq, name in ((int(Liquidity.MAKER), "maker"), (int(Liquidity.TAKER), "taker")):
                n = self.n.get((h, liq), 0)
                row[name] = {
                    "n": n,
                    "vs_fill_bps": (self.sum_fill[(h, liq)] / n) if n else None,
                    "vs_mid_bps": (self.sum_mid[(h, liq)] / n) if n else None,
                }
            out[f"{h}s"] = row
        out["pending"] = sum(len(d) for d in self.pending.values())
        out["dropped"] = self.dropped
        return out


@dataclass(slots=True)
class Metrics:
    events: int = 0
    quotes: int = 0
    trades: int = 0
    intents: int = 0
    orders: int = 0
    cancels: int = 0
    fills: int = 0
    risk_rejects: int = 0
    stale_cancels: int = 0
    feed_reconnects: int = 0
    lat: np.ndarray = field(default_factory=lambda: np.zeros(LAT_RING, dtype=np.int64))
    lat_n: int = 0
    lat_head: int = 0
    lat_max: int = 0

    def note_lat(self, ns: int) -> None:
        self.lat[self.lat_head] = ns
        self.lat_head = (self.lat_head + 1) % LAT_RING
        self.lat_n = min(LAT_RING, self.lat_n + 1)
        if ns > self.lat_max:
            self.lat_max = ns

    def lat_pct(self) -> dict[str, float]:
        if self.lat_n == 0:
            return {"p50_us": 0.0, "p99_us": 0.0, "max_us": 0.0}
        a = self.lat[: self.lat_n]
        return {"p50_us": float(np.percentile(a, 50)) / 1e3, "p99_us": float(np.percentile(a, 99)) / 1e3, "max_us": self.lat_max / 1e3}


class Engine:
    def __init__(
        self,
        cfg: EngineConfig,
        strategy: Strategy,
        broker: Broker,
        risk: RiskManager,
        ledger: Ledger,
        run_dir: str | Path,
        recorder: Recorder | None = None,
        clock: Callable[[], int] | None = None,
    ) -> None:
        self.cfg = cfg
        self.strategy = strategy
        self.broker = broker
        self.risk = risk
        self.ledger = ledger
        self.run_dir = Path(run_dir)
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.recorder = recorder
        self.book = Book(cfg.venue, cfg.symbol)
        self.m = Metrics()
        self.markouts = Markouts()
        self.malformed_events = 0
        self._clock = clock or now_ns
        self._event_time_mode = clock is not None
        self._now = 0
        self._next_mark_ns = 0
        self._start_ns = 0
        self._deadline_ns = 0
        self.stop_reason = ""
        self.exception = ""
        self.equity_start_q = cfg.starting_cash_q
        self.equity_q = cfg.starting_cash_q
        self.equity_peak_q = cfg.starting_cash_q
        self.equity_min_q = cfg.starting_cash_q
        self.equity_exec_q = cfg.starting_cash_q
        self.equity_exec_min_q = cfg.starting_cash_q
        self._residual_handled = False
        self._residual_action = "none"
        self.first_mid_i = 0
        self.goal_hit_ns = 0
        self.unexecuted_stop_intents = 0
        self.ledger_error = ""

    # ---- hot path -------------------------------------------------------
    def process_event(self, ev: Quote | Trade) -> None:
        t0 = mono_ns()
        now = ev.ts_recv_ns if self._event_time_mode else self._clock()
        self._now = now
        self.m.events += 1
        if self.recorder is not None:
            self.recorder.write(ev)
        try:
            if isinstance(ev, Quote):
                self.m.quotes += 1
                admitted = self.book.on_quote(ev)
                fills = self.broker.on_quote(ev, now) if admitted else []
                if admitted:
                    if self.first_mid_i == 0:
                        self.first_mid_i = ev.mid_i
                    self.markouts.settle(now, ev.mid_i, self.ledger)
            else:
                self.m.trades += 1
                admitted = self.book.on_trade(ev)
                fills = self.broker.on_trade(ev, now) if admitted else []
        except MalformedInput:
            self.malformed_events += 1
            self.m.note_lat(mono_ns() - t0)
            return
        if fills:
            self._on_fills(fills, now)
        view = self.broker.view()
        if self.risk.killed:
            intents, cancels = [], []
        else:
            intents, cancels = self.strategy.on_event(self.book, view, now)
        cancels_before = self.m.cancels
        if cancels:
            for c in cancels:
                if self.broker.cancel(c.order_id, now):
                    self.m.cancels += 1
                    self._ledger(now, "cancel", {"order_id": c.order_id, "reason": c.reason})
            view = self.broker.view()
        switched = getattr(self.strategy, "switched", None)
        if switched:
            self._ledger(now, "block", {"label": switched, "cancels": self.m.cancels - cancels_before})
            self.strategy.switched = None
        if intents:
            mid = self.book.mid_i()
            age_ms = self.book.stale_ns(now) // 1_000_000
            for it in intents:
                self.m.intents += 1
                open_notional = self.broker.open_notional_q()
                pending = self.broker.pending_i(it.side)
                v = self.risk.check(it, mid, view.pos_i, view.open_count, open_notional, age_ms, now, pending)
                if not v.ok:
                    self.m.risk_rejects += 1
                    self._ledger(now, "reject", {"reason": v.reason, "side": int(it.side), "size_i": it.size_i, "price_i": it.price_i})
                    continue
                o = self.broker.submit(it, self.strategy.name, now)
                self.m.orders += 1
                self.risk.on_order(now)
                self.ledger.order(now, o, self.book.mid_i())
                view = self.broker.view()  # refreshed so the next intent in the batch sees this one
        if now >= self._next_mark_ns:
            self._mark(now)
        self.m.note_lat(mono_ns() - t0)

    def _ledger(self, now: int, kind: str, body: dict) -> None:
        self.ledger.append(now, kind, body)

    def _on_fills(self, fills: list[Fill], now: int) -> None:
        mid = self.book.mid_i()
        for f in fills:
            self.m.fills += 1
            self.risk.on_fill(now)
            self.ledger.fill(f)
            self.markouts.add(f, mid)
        self._mark(now, persist=False)  # equity, drawdown and kill checks per fill; the ledger row waits for the timer

    def _mark(self, now: int, persist: bool = True) -> None:
        mid = self.book.mid_i()
        if mid <= 0:
            return
        self.equity_q = self.broker.equity_q(mid)
        self.equity_exec_q = self.broker.liquidation_q()
        self.equity_exec_min_q = min(self.equity_exec_min_q, self.equity_exec_q)
        self.equity_peak_q = max(self.equity_peak_q, self.equity_q)
        self.equity_min_q = min(self.equity_min_q, self.equity_q)
        self.risk.on_mark(min(self.equity_q, self.equity_exec_q), persist=persist)
        v = self.broker.view()
        watch = self.risk.poll(now, self.book.stale_ns(now) // 1_000_000, persist=persist)
        if watch == "stale" and v.open_count:
            n = self.broker.cancel_all(now)
            self.m.stale_cancels += n
            self._ledger(now, "stale-cancel", {"orders": n, "age_ms": self.book.stale_ns(now) // 1_000_000})
        if persist:
            self.ledger.mark(now, self.equity_q, v.cash_q, v.pos_i, mid, {"open": v.open_count, "fees_q": v.fees_paid_q, "exec_q": self.equity_exec_q})
            self.ledger.flush()  # timed durability: at most mark_interval_ms of buffered rows at risk; never on the fill path
            self._next_mark_ns = now + self.cfg.mark_interval_ms * 1_000_000
        if self.equity_q >= self.cfg.goal_q and self.goal_hit_ns == 0:
            self.goal_hit_ns = now
            self.stop_reason = "goal reached"
        if self.risk.killed:
            n = self.broker.cancel_all(now)  # latched kill: pull every resting order, then stop
            self.m.cancels += n
            if not self.stop_reason:
                self.stop_reason = "risk kill: " + self.risk.kill_reason
            if persist:
                self._handle_residual(now)

    def _handle_residual(self, now: int) -> None:
        """Report killed inventory once; paper IOC obeys latency, depth and freshness rules."""
        if self._residual_handled:
            return
        self._residual_handled = True  # settling fills may re-enter _mark
        policy = self.cfg.residual_policy
        can_liquidate = policy == "liquidate" and self.cfg.mode in ("paper", "replay")
        latency_ns = self.cfg.paper.latency_ms * 1_000_000
        if can_liquidate:
            # Wait for cancel effects before selling inventory reserved by resting sells.
            now += latency_ns
            fills = self.broker.settle(now)
            if fills:
                self._on_fills(fills, now)
        v = self.broker.view()
        if v.pos_i == 0:
            self._residual_handled = False  # a pending arrival may fill before a hold cancel settles
            return
        self._residual_action = "hold"
        self._ledger(now, "residual", {
            "pos_i": v.pos_i, "mid_i": self.book.mid_i(),
            "exec_q": self.broker.liquidation_q(), "policy": policy,
        })
        if can_liquidate:
            intent = Intent(Side.SELL if v.pos_i > 0 else Side.BUY, 0, abs(v.pos_i), TimeInForce.IOC, "risk residual liquidation")
            order = self.broker.submit(intent, self.strategy.name, now)
            self.m.orders += 1
            self.risk.on_order(now)
            self.ledger.order(now, order, self.book.mid_i())
            settled_ns = now + latency_ns
            fills = self.broker.settle(settled_ns)
            if fills:
                self._on_fills(fills, settled_ns)
            remaining = self.broker.view().pos_i
            self._residual_action = "filled" if remaining == 0 else "partial_fill" if order.filled_i else "unfilled"
            self._ledger(settled_ns, "residual-outcome", {
                "order_id": order.id, "pos_i": remaining, "filled_i": order.filled_i,
                "status": int(order.status), "reason": order.reason, "action": self._residual_action,
            })
        self.ledger.flush()

    def _should_stop(self, now: int) -> bool:
        if self.stop_reason:
            return True
        if self._deadline_ns and now >= self._deadline_ns:
            self.stop_reason = "run_seconds elapsed"
            return True
        if self.cfg.max_ticks and self.m.events >= self.cfg.max_ticks:
            self.stop_reason = "max_ticks"
            return True
        return False

    # ---- drivers --------------------------------------------------------
    async def run_live(self, feed: Feed) -> dict:
        self._start_ns = self._clock()
        self._deadline_ns = self._start_ns + self.cfg.run_seconds * 1_000_000_000 if self.cfg.run_seconds else 0
        await feed.start()
        fs: dict = {}
        heartbeat = asyncio.create_task(self._heartbeat(feed), name="leafhft-heartbeat")
        reference = reference_task = None
        try:
            if self.cfg.reference_venue:
                from .feeds.base import make_feed

                if not callable(getattr(self.strategy, "on_reference", None)):
                    raise ValueError("reference feed has no strategy consumer")
                reference = make_feed(self.cfg.reference_venue, self.cfg.symbol)
                await reference.start()
                reference_task = asyncio.create_task(self._reference_events(reference, feed), name="leafhft-reference")
            base_idle_s = max(60.0, self.cfg.risk.stale_feed_ms / 1000 * 4)
            idle_timeout_s = max(LIVE_IDLE_TIMEOUT_S, self.cfg.risk.stale_feed_ms / 1000 * 4) if self.cfg.mode == "live" else base_idle_s
            can_reconnect = self.cfg.mode == "live" and callable(getattr(feed, "reconnect", None))
            stopped = False
            while not stopped:
                try:
                    async for ev in feed.events(idle_timeout_s=idle_timeout_s):
                        self.process_event(ev)
                        if self._should_stop(self._clock()):
                            stopped = True
                            break
                    else:
                        stopped = True  # events() returned normally: feed.stop() was called elsewhere
                except TimeoutError as e:
                    if can_reconnect and self.m.feed_reconnects < LIVE_MAX_FEED_RECONNECTS:
                        self.m.feed_reconnects += 1
                        self._ledger(self._clock(), "feed-reconnect", {"attempt": self.m.feed_reconnects, "reason": str(e)})
                        await feed.reconnect()
                    else:
                        self.stop_reason = f"feed idle: {e}"
                        stopped = True
        except Exception as e:  # noqa: BLE001 - shutdown must run whatever happened
            self.exception = f"{type(e).__name__}: {e}"[:300]
            self.stop_reason = "exception: " + self.exception
        finally:
            heartbeat.cancel()
            if reference_task is not None:
                reference_task.cancel()
                await asyncio.gather(reference_task, return_exceptions=True)
            if reference is not None:
                await reference.stop()
            try:
                await feed.stop()
            finally:
                fs = asdict(feed.stats)
                if hasattr(feed, "quality"):
                    fs["quality"] = feed.quality()
                if reference is not None:
                    fs["reference"] = asdict(reference.stats)
        return self._shutdown(fs)

    async def _reference_events(self, reference: Feed, primary: Feed) -> None:
        try:
            async for ev in reference.events():
                if isinstance(ev, Quote):
                    self.strategy.on_reference(ev)
                    self._reference_protection(self._clock())
        except asyncio.CancelledError:
            raise
        except Exception as e:
            self.exception = f"reference: {type(e).__name__}: {e}"[:300]
            self.stop_reason = "exception: " + self.exception
        if not self.stop_reason:
            self.stop_reason = "reference feed stopped"
        await primary.stop()

    def _reference_protection(self, now: int) -> None:
        hook = getattr(self.strategy, "on_timer", None)
        if hook is None or self.risk.killed:
            return
        for c in hook(self.book, self.broker.view(), now):
            if self.broker.cancel(c.order_id, now):
                self.m.cancels += 1
                self._ledger(now, "cancel", {"order_id": c.order_id, "reason": c.reason})

    async def _heartbeat(self, feed: Feed) -> None:
        """Timer-driven marks and stop checks: a live run marks equity at mark_interval_ms even when the
        feed is quieter than that (Binance.US REST delivers about 2 events a second), and the deadline,
        the KILL file and stale-feed detection (all polled in _mark) fire on this cadence instead of on
        the next message, so a dead feed cannot hold the kill switch hostage. Same loop as
        process_event, so no concurrent mutation. Stopping the feed ends run_live's event loop."""
        period = max(0.05, self.cfg.mark_interval_ms / 1000.0)
        if self.cfg.reference_venue:
            period = min(period, 0.25)
        while True:
            await asyncio.sleep(period)
            now = self._clock()
            if self.cfg.reference_venue:
                self._reference_protection(now)
            if not self.stop_reason and self.book.mid_i() > 0 and now >= self._next_mark_ns:
                self._mark(now)
            if self._should_stop(now):
                await feed.stop()
                return

    def run_replay(self, events: Iterable[Quote | Trade]) -> dict:
        first = True
        try:
            for ev in events:
                if first:
                    self._start_ns = ev.ts_recv_ns
                    self._deadline_ns = self._start_ns + self.cfg.run_seconds * 1_000_000_000 if self.cfg.run_seconds else 0
                    first = False
                self.process_event(ev)
                if self._should_stop(ev.ts_recv_ns):
                    break
        except Exception as e:  # noqa: BLE001
            self.exception = f"{type(e).__name__}: {e}"[:300]
            self.stop_reason = "exception: " + self.exception
        return self._shutdown({"skipped_lines": getattr(iter_file, "skipped", 0)})

    def _shutdown(self, feed_stats: dict) -> dict:
        now = self._now if self._event_time_mode else self._clock()
        latency_ns = self.cfg.paper.latency_ms * 1_000_000
        try:
            intents, cancels = self.strategy.on_stop(self.book, self.broker.view(), now)
            self.unexecuted_stop_intents = len(intents)  # never executed: shutdown invents no fills
            for c in cancels:
                if self.broker.cancel(c.order_id, now):
                    self.m.cancels += 1
            self.m.cancels += self.broker.cancel_all(now)
            fills = self.broker.settle(now + latency_ns)  # cancel effects; arrivals against a stale book are rejected
            if fills:
                self._on_fills(fills, now + latency_ns)
            self._mark(now + latency_ns)
        except LedgerFailed as e:
            self.ledger_error = str(e)
        if self.recorder is not None:
            self.recorder.close()
        ok, rows = False, 0
        try:
            self.ledger.flush()
            ok, rows = self.ledger.verify()
        except LedgerFailed as e:
            self.ledger_error = self.ledger_error or str(e)
        receipt = self.receipt(feed_stats, ok, rows)
        (self.run_dir / "receipt.json").write_text(json.dumps(receipt, indent=2, default=str), encoding="utf-8")
        try:
            self.ledger.close()
        except LedgerFailed:
            pass
        return receipt

    # ---- receipt --------------------------------------------------------
    def receipt(self, feed_stats: dict, ledger_ok: bool, ledger_rows: int) -> dict:
        v = self.broker.view()
        bs = getattr(self.broker, "snapshot", lambda: {})()
        mid = self.book.mid_i()
        pnl_q = self.equity_q - self.equity_start_q
        liq_q = self.broker.liquidation_q()
        bah_q = (self.equity_start_q * mid // self.first_mid_i) if self.first_mid_i else self.equity_start_q
        return {
            "schema": "leafhft.receipt.v2",
            "config_digest": self.cfg.digest(),
            "config": {
                "venue": self.cfg.venue,
                "symbol": self.cfg.symbol,
                "strategy": self.cfg.strategy,
                "mode": self.cfg.mode,
                "strategy_params": self.strategy.params,
                "paper": asdict(self.cfg.paper),
                "risk_limits": asdict(self.cfg.risk),
            },
            "git_sha": _git_sha(),
            "started": iso(self._start_ns) if self._start_ns else "",
            "ended": iso(self._now) if self._now else "",
            "stop_reason": self.stop_reason,
            "exception": self.exception,
            "equity_start_usd": self.equity_start_q / QUOTE_UNIT,
            "equity_end_usd": self.equity_q / QUOTE_UNIT,
            "equity_liquidation_usd": liq_q / QUOTE_UNIT,
            "liquidation_cost_usd": (self.equity_q - liq_q) / QUOTE_UNIT,
            "baseline_cash_usd": self.equity_start_q / QUOTE_UNIT,
            "baseline_buy_and_hold_usd": bah_q / QUOTE_UNIT,
            "equity_peak_usd": self.equity_peak_q / QUOTE_UNIT,
            "equity_min_usd": self.equity_min_q / QUOTE_UNIT,
            "equity_exec_min_usd": self.equity_exec_min_q / QUOTE_UNIT,
            "pnl_usd": pnl_q / QUOTE_UNIT,
            "pnl_bps": 0.0 if self.equity_start_q == 0 else 10_000.0 * pnl_q / self.equity_start_q,
            "goal_usd": self.cfg.goal_q / QUOTE_UNIT,
            "goal_reached": self.goal_hit_ns != 0,
            "fees_usd": v.fees_paid_q / QUOTE_UNIT,
            "slip_usd": bs.get("slip_paid_q", 0) / QUOTE_UNIT,
            "residual_position_i": v.pos_i,
            "residual": {"pos_i": v.pos_i, "policy": self.cfg.residual_policy, "action": self._residual_action},
            "residual_value_mid_usd": notional_q(mid, v.pos_i) / QUOTE_UNIT,
            "cash_usd": v.cash_q / QUOTE_UNIT,
            "unexecuted_stop_intents": self.unexecuted_stop_intents,
            "feed_reconnects": self.m.feed_reconnects,
            "counts": {
                "events": self.m.events,
                "quotes": self.m.quotes,
                "trades": self.m.trades,
                "intents": self.m.intents,
                "orders": self.m.orders,
                "cancels": self.m.cancels,
                "stale_cancels": self.m.stale_cancels,
                "fills": self.m.fills,
                "risk_rejects": self.m.risk_rejects,
                "maker_fills": bs.get("maker_fills", 0),
                "taker_fills": bs.get("taker_fills", 0),
                "broker_rejects": bs.get("rejected_total", 0),
            },
            "fill_rules": bs.get("fill_rules", {}),
            "latency": self.m.lat_pct(),
            "markouts": self.markouts.summary(),
            "malformed_events": self.malformed_events,
            "dropped_seq": self.book.dropped_seq,
            "risk": self.risk.snapshot(),
            "strategy_state": self.strategy.state(),
            "feed": {k: val for k, val in feed_stats.items() if k != "errors"},
            "feed_errors": feed_stats.get("errors", [])[:10],
            "ledger": {"path": str(self.ledger.path), "rows": ledger_rows, "chain_ok": ledger_ok, "error": self.ledger_error},
            "book": {"mid_usd": mid / QUOTE_UNIT, "first_mid_usd": self.first_mid_i / QUOTE_UNIT, "avg_spread_bps": self.book.avg_spread_bps(), "vol_bps": self.book.vol_bps()},
        }
