"""Standalone contracts for coordinated entry; this module never places orders.

Prices are integer cents, depth/capacity are whole contracts, and timestamps are
Unix nanoseconds. Readiness is advisory, not trading permission. Callers must
check freshness and account risk again before execution. Persist an intent with
AuthorityJournal.record before sending it. Retransmit that same intent on retry.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import socket
from contextlib import contextmanager
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import ClassVar, Mapping

MAX_PAYLOAD_BYTES = 8192
MAX_ACCOUNTS = 256
MAX_INTEGER = (1 << 63) - 1
SIGNAL_TTL_NS = 150_000_000
_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}\Z")


class ContractError(ValueError):
    """A malformed contract, payload, or journal must not authorize entry."""


def _integer(value: object, name: str, minimum: int = 0,
             maximum: int = MAX_INTEGER) -> None:
    if type(value) is not int or not minimum <= value <= maximum:
        raise ContractError(f"invalid {name}")


def _identifier(value: object, name: str) -> None:
    if type(value) is not str or _IDENTIFIER.fullmatch(value) is None:
        raise ContractError(f"invalid {name}")


def _digest(value: object, name: str) -> None:
    if type(value) is not str or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise ContractError(f"invalid {name}")


def allocation_digest(allocation: tuple[tuple[str, int], ...]) -> str:
    """Hash the canonical, sorted, complete account-to-quantity allocation."""
    if type(allocation) is not tuple or len(allocation) > MAX_ACCOUNTS:
        raise ContractError("invalid allocation")
    previous = None
    for entry in allocation:
        if type(entry) is not tuple or len(entry) != 2:
            raise ContractError("invalid allocation entry")
        account_id, quantity = entry
        _identifier(account_id, "account_id")
        _integer(quantity, "quantity")
        if previous is not None and account_id <= previous:
            raise ContractError("allocation must have unique sorted account IDs")
        previous = account_id
    raw = json.dumps(allocation, separators=(",", ":")).encode("ascii")
    return hashlib.sha256(raw).hexdigest()


class _Contract:
    SCHEMA: ClassVar[str]

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: object):
        expected = {field.name for field in fields(cls)}
        if type(value) is not dict or set(value) != expected:
            raise ContractError(f"{cls.__name__} requires exactly {sorted(expected)}")
        return cls(**value)


@dataclass(frozen=True)
class SignalIntentV1(_Contract):
    """An immutable market decision, identified independently of each account."""

    SCHEMA: ClassVar[str] = "leafhft.signal-intent.v1"
    signal_id: str
    sequence: int
    market: str
    side_yes: bool
    price_cents: int
    depth_contracts: int
    created_ns: int
    expires_ns: int
    engine_id: str
    engine_digest: str
    policy_digest: str
    configuration_digest: str
    canonical_quote_id: str
    deployment_generation: int
    authority_epoch: str
    allocation: tuple[tuple[str, int], ...]
    allocation_digest: str
    schema: str = SCHEMA

    def __post_init__(self) -> None:
        if type(self.schema) is not str or self.schema != self.SCHEMA:
            raise ContractError("unsupported signal schema")
        _identifier(self.signal_id, "signal_id")
        _identifier(self.market, "market")
        _integer(self.sequence, "sequence", 1)
        if type(self.side_yes) is not bool:
            raise ContractError("invalid side_yes")
        _integer(self.price_cents, "price_cents", 1, 99)
        _integer(self.depth_contracts, "depth_contracts")
        _integer(self.created_ns, "created_ns")
        _integer(self.expires_ns, "expires_ns", self.created_ns + 1)
        if self.expires_ns - self.created_ns != SIGNAL_TTL_NS:
            raise ContractError("signal deadline must be exactly 150ms")
        for name in ("engine_id", "canonical_quote_id", "authority_epoch"):
            _identifier(getattr(self, name), name)
        for name in ("engine_digest", "policy_digest", "configuration_digest",
                     "allocation_digest"):
            _digest(getattr(self, name), name)
        _integer(self.deployment_generation, "deployment_generation", 1)
        if allocation_digest(self.allocation) != self.allocation_digest:
            raise ContractError("allocation digest mismatch")
        if sum(quantity for _, quantity in self.allocation) > self.depth_contracts // 2:
            raise ContractError("allocation exceeds half depth")

    def to_dict(self) -> dict:
        value = super().to_dict()
        value["allocation"] = [list(entry) for entry in self.allocation]
        return value

    @classmethod
    def from_dict(cls, value: object):
        if type(value) is dict and type(value.get("allocation")) is list:
            entries = value["allocation"]
            if any(type(entry) is not list for entry in entries):
                raise ContractError("invalid allocation wire shape")
            value = value | {"allocation": tuple(tuple(entry) for entry in entries)}
        else:
            raise ContractError("allocation must be a JSON array")
        return super().from_dict(value)

    def for_account(self, account_id: str) -> RecipientIntentV1:
        return RecipientIntentV1(self, account_id)

    def is_fresh(self, now_ns: int) -> bool:
        _integer(now_ns, "now_ns")
        return self.created_ns <= now_ns < self.expires_ns


@dataclass(frozen=True)
class AccountReadinessV1(_Contract):
    """An account's capacity for one market during a bounded time interval."""

    SCHEMA: ClassVar[str] = "leafhft.account-readiness.v1"
    account_id: str
    market: str
    capacity_contracts: int
    ready: bool
    observed_ns: int
    expires_ns: int
    enabled_engine_ids: tuple[str, ...]
    per_book_stake_cents: int
    killed: bool
    configuration_digest: str
    deployment_generation: int
    schema: str = SCHEMA

    def __post_init__(self) -> None:
        if type(self.schema) is not str or self.schema != self.SCHEMA:
            raise ContractError("unsupported readiness schema")
        _identifier(self.account_id, "account_id")
        _identifier(self.market, "market")
        _integer(self.capacity_contracts, "capacity_contracts")
        if type(self.ready) is not bool:
            raise ContractError("invalid ready")
        _integer(self.observed_ns, "observed_ns")
        _integer(self.expires_ns, "expires_ns", self.observed_ns + 1)
        if type(self.killed) is not bool:
            raise ContractError("invalid killed")
        _integer(self.per_book_stake_cents, "per_book_stake_cents", 1)
        _integer(self.deployment_generation, "deployment_generation", 1)
        _digest(self.configuration_digest, "configuration_digest")
        if (type(self.enabled_engine_ids) is not tuple
                or len(self.enabled_engine_ids) > MAX_ACCOUNTS):
            raise ContractError("invalid enabled_engine_ids")
        for engine in self.enabled_engine_ids:
            _identifier(engine, "engine_id")
        if tuple(sorted(set(self.enabled_engine_ids))) != self.enabled_engine_ids:
            raise ContractError("enabled engines must be unique and sorted")

    def to_dict(self) -> dict:
        value = super().to_dict()
        value["enabled_engine_ids"] = list(self.enabled_engine_ids)
        return value

    @classmethod
    def from_dict(cls, value: object):
        if type(value) is not dict or type(value.get("enabled_engine_ids")) is not list:
            raise ContractError("enabled engines must be a JSON array")
        return super().from_dict(value | {
            "enabled_engine_ids": tuple(value["enabled_engine_ids"])})

    def is_fresh(self, now_ns: int) -> bool:
        _integer(now_ns, "now_ns")
        return self.ready and not self.killed and self.observed_ns <= now_ns < self.expires_ns


@dataclass(frozen=True)
class RecipientIntentV1:
    """Immutable view of one recipient in the durable shared decision.

    Quantity is derived, so a recipient cannot override the shared allocation.
    The shared intent is the wire and journal representation.
    """

    intent: SignalIntentV1
    account_id: str

    def __post_init__(self) -> None:
        if type(self.intent) is not SignalIntentV1:
            raise ContractError("invalid shared intent")
        _identifier(self.account_id, "account_id")
        if self.account_id not in dict(self.intent.allocation):
            raise ContractError("recipient absent from allocation")

    @property
    def quantity(self) -> int:
        return dict(self.intent.allocation)[self.account_id]


def allocate_depth(depth_contracts: int, capacities: Mapping[str, int],
                   per_book_stake_cents: Mapping[str, int]) -> dict[str, int]:
    """Minimum-one barrier followed by capped weighted Hamilton rounds.

    Exact integer remainders break ties by ascending account ID. Each round
    either exhausts the budget or saturates an account, bounding runtime by
    the account count, independent of the number of contracts.
    """
    _integer(depth_contracts, "depth_contracts")
    if not isinstance(capacities, Mapping) or len(capacities) > MAX_ACCOUNTS:
        raise ContractError("invalid capacities")
    for account_id, capacity in capacities.items():
        _identifier(account_id, "account_id")
        _integer(capacity, "capacity_contracts")
    if (not isinstance(per_book_stake_cents, Mapping)
            or set(per_book_stake_cents) != set(capacities)):
        raise ContractError("weights must cover exactly the capacity accounts")
    for weight in per_book_stake_cents.values():
        _integer(weight, "per_book_stake_cents", 1)
    result = dict.fromkeys(sorted(capacities), 0)
    budget = min(depth_contracts // 2, sum(capacities.values()))
    active = [key for key in result if capacities[key] > 0]
    if budget < len(active):
        return result
    for key in active:
        result[key] = 1
    budget -= len(active)
    active = [key for key in active if result[key] < capacities[key]]
    while budget and active:
        total_weight = sum(per_book_stake_cents[key] for key in active)
        shares = {key: divmod(budget * per_book_stake_cents[key], total_weight)
                  for key in active}
        grants = {key: shares[key][0] for key in active}
        remainder = budget - sum(grants.values())
        ranked = sorted(active, key=lambda key: (-shares[key][1], key))
        for key in ranked[:remainder]:
            grants[key] += 1
        for key in active:
            grant = min(grants[key], capacities[key] - result[key])
            result[key] += grant
            budget -= grant
        active = [key for key in active if result[key] < capacities[key]]
    return result


def allocate_ready(intent: SignalIntentV1, accounts: list[AccountReadinessV1],
                   now_ns: int) -> dict[str, int]:
    """Exclude stale, unready, and other-market accounts; reject duplicate IDs."""
    if type(intent) is not SignalIntentV1:
        raise ContractError("invalid intent")
    if type(accounts) is not list or len(accounts) > MAX_ACCOUNTS:
        raise ContractError("invalid accounts")
    fresh = intent.is_fresh(now_ns)
    capacities = {}
    weights = {}
    for account in accounts:
        if type(account) is not AccountReadinessV1 or account.account_id in capacities:
            raise ContractError("invalid or duplicate account")
        capacities[account.account_id] = (
            account.capacity_contracts
            if fresh and account.market == intent.market and account.is_fresh(now_ns)
            and intent.engine_id in account.enabled_engine_ids
            and account.configuration_digest == intent.configuration_digest
            and account.deployment_generation == intent.deployment_generation
            else 0
        )
        weights[account.account_id] = account.per_book_stake_cents
    return allocate_depth(intent.depth_contracts, capacities, weights)


def account_client_id(signal_id: str, account_id: str) -> str:
    """Stable 35-character owned-order ID for an account, including retries.

    Signal IDs must be globally unique within the deployment. Price, quantity,
    clocks, and process IDs deliberately do not create a new retry identity.
    """
    _identifier(signal_id, "signal_id")
    _identifier(account_id, "account_id")
    identity = json.dumps(["coordinated-entry-v1", signal_id, account_id],
                          separators=(",", ":")).encode("ascii")
    return "lh-" + hashlib.sha256(identity).hexdigest()[:32]


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ContractError("duplicate JSON key")
        result[key] = value
    return result


def _reject_constant(value: str) -> None:
    raise ContractError("non-finite JSON number")


def encode_payload(message: SignalIntentV1 | AccountReadinessV1) -> bytes:
    if type(message) not in (SignalIntentV1, AccountReadinessV1):
        raise ContractError("unsupported message type")
    # Revalidate rather than trusting callers who bypass frozen dataclasses.
    value = type(message).from_dict(message.to_dict()).to_dict()
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"),
                     allow_nan=False).encode("utf-8")
    if not 0 < len(raw) <= MAX_PAYLOAD_BYTES:
        raise ContractError("payload exceeds datagram bound")
    return raw


def decode_payload(raw: bytes) -> SignalIntentV1 | AccountReadinessV1:
    if type(raw) is not bytes or not 0 < len(raw) <= MAX_PAYLOAD_BYTES:
        raise ContractError("invalid payload size or type")
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_reject_constant)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ContractError("invalid JSON payload") from exc
    if type(value) is not dict:
        raise ContractError("payload must be an object")
    schema = value.get("schema")
    if schema == SignalIntentV1.SCHEMA:
        return SignalIntentV1.from_dict(value)
    if schema == AccountReadinessV1.SCHEMA:
        return AccountReadinessV1.from_dict(value)
    raise ContractError("unsupported payload schema")


def _timeout(timeout_s: float) -> None:
    if (type(timeout_s) not in (int, float) or not math.isfinite(timeout_s)
            or not 0 < timeout_s <= 5):
        raise ContractError("timeout must be finite and in (0, 5] seconds")


def _socket_path(path: str | Path) -> str:
    path = os.fspath(path)
    if (type(path) is not str or not path or "\0" in path
            or len(os.fsencode(path)) > 103):
        raise ContractError("invalid Unix socket path")
    return path


def bind_datagram(path: str | Path, timeout_s: float = 0.1) -> socket.socket:
    """Bind a new Unix datagram endpoint. Never unlink an existing endpoint.

    The caller owns the returned socket and its filesystem path. Socket support
    and OS errors propagate; there is no TCP or in-process fallback.
    """
    _timeout(timeout_s)
    path = _socket_path(path)
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    try:
        sock.settimeout(timeout_s)
        sock.bind(path)
    except BaseException:
        sock.close()
        raise
    return sock


def send_datagram(path: str | Path, message: SignalIntentV1 | AccountReadinessV1,
                  timeout_s: float = 0.1) -> None:
    raw = encode_payload(message)
    _timeout(timeout_s)
    path = _socket_path(path)
    with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as sock:
        sock.settimeout(timeout_s)
        if sock.sendto(raw, path) != len(raw):
            raise OSError("incomplete datagram send")


def receive_datagram(sock: socket.socket, timeout_s: float = 0.1):
    """Reject truncated/oversized packets, including a valid JSON prefix."""
    _timeout(timeout_s)
    if not hasattr(socket, "AF_UNIX") or sock.family != socket.AF_UNIX or sock.getsockopt(
            socket.SOL_SOCKET, socket.SO_TYPE) != socket.SOCK_DGRAM:
        raise ContractError("expected Unix datagram socket")
    previous = sock.gettimeout()
    try:
        sock.settimeout(timeout_s)
        raw = sock.recv(MAX_PAYLOAD_BYTES + 1)
        return decode_payload(raw)
    finally:
        sock.settimeout(previous)


@contextmanager
def _locked(file):
    """Serialize cooperating journal readers/writers across processes."""
    file.seek(0)
    if os.name == "nt":
        import msvcrt

        msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
        try:
            yield
        finally:
            file.seek(0)
            msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
    else:
        import fcntl

        fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            fcntl.flock(file.fileno(), fcntl.LOCK_UN)


class AuthorityJournal:
    """Fsynced append-only intents; corruption is fatal, never silently reset.

    The parent directory must already exist. Cooperating instances lock the
    journal and reload before each write, so a stale instance cannot reuse a
    sequence. Partial writes halt recovery for operator reconciliation. No
    truncation or repair is attempted. A successful record is durable before
    its sequence becomes available to the caller for publication.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._signals: dict[str, SignalIntentV1] = {}
        self._last: dict[str, SignalIntentV1] = {}
        self._sequence = 0
        # Creating at construction also makes subsequent missing-file errors
        # fatal, rather than resetting authority after accidental deletion.
        with self.path.open("a+b") as file, _locked(file):
            self._restore(file)
            file.flush()
            os.fsync(file.fileno())
            self._sync_directory()

    @property
    def sequence(self) -> int:
        return self._sequence

    @property
    def next_sequence(self) -> int:
        return self._sequence + 1

    @property
    def last_signal_by_market(self) -> dict[str, SignalIntentV1]:
        return self._last.copy()

    def _sync_directory(self) -> None:
        # Windows has no portable directory-fsync API. File fsync still uses
        # the platform's durable flush. POSIX also persists the directory entry.
        if os.name != "nt":
            fd = os.open(self.path.parent, os.O_RDONLY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)

    def _restore(self, file) -> None:
        signals = {}
        last = {}
        sequence = 0
        file.seek(0)
        while raw := file.readline(MAX_PAYLOAD_BYTES + 2):
            if not raw.endswith(b"\n"):
                raise ContractError("incomplete or oversized journal record")
            intent = decode_payload(raw[:-1])
            if type(intent) is not SignalIntentV1:
                raise ContractError("journal record is not a signal")
            if intent.sequence != sequence + 1 or intent.signal_id in signals:
                raise ContractError("journal sequence or signal identity conflict")
            sequence = intent.sequence
            signals[intent.signal_id] = intent
            last[intent.market] = intent
        self._signals, self._last, self._sequence = signals, last, sequence

    def record(self, intent: SignalIntentV1) -> SignalIntentV1:
        if type(intent) is not SignalIntentV1:
            raise ContractError("journal requires a signal")
        raw = encode_payload(intent) + b"\n"
        with self.path.open("r+b") as file, _locked(file):
            self._restore(file)
            existing = self._signals.get(intent.signal_id)
            if existing is not None:
                if existing != intent:
                    raise ContractError("signal ID reused with different content")
                # Also flush on retry after an earlier uncertain fsync result.
                file.flush()
                os.fsync(file.fileno())
                self._sync_directory()
                return existing
            if intent.sequence != self.next_sequence:
                raise ContractError("signal sequence must be the next sequence")
            file.seek(0, os.SEEK_END)
            if file.write(raw) != len(raw):
                raise OSError("incomplete journal write")
            file.flush()
            os.fsync(file.fileno())
            self._sync_directory()
            self._signals[intent.signal_id] = intent
            self._last[intent.market] = intent
            self._sequence = intent.sequence
            return intent
