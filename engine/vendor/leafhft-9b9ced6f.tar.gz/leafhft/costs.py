"""Whole-cent cost adapter for the R6 scorer, paper host and lane sizing.

For dollar price P and contract count C, the model fee is m*C*P*(1-P)
dollars. ``order_fee_cents`` applies ceil(100*m*C*P*(1-P)) once to the
whole order, not separately to its fills. The taker multiplier comes from
settlement; the separate maker multiplier defaults to that incumbent's zero.

https://docs.kalshi.com/getting_started/fee_rounding describes an accumulator
shared across an order's fills, including maker/taker transitions. The current
rules round the model fee up to six dollar decimals, then align the signed
balance change to the member's precision and rebate accumulated overpayment.
Thus this whole-cent model fee is not a reconstruction of a fractional fill's
venue fee. Pass reported total fees to entry/exit accounting when available.

https://docs.kalshi.com/getting_started/orderbook_responses supplies fixed-point
dollar prices and quantities as strings, and derives asks from complementary
bids. Convert those dollars to Decimal cents before using this adapter.

Prices accept int or Decimal cents strictly between 0 and 100 on a 0.1c grid;
positive counts accept int or Decimal on a 0.01-contract grid. Monetary totals
and reported fees are integer cents. Numeric floats and bools are refused;
only the explicit ``maker`` switch accepts bool. Trailing zeroes do not change
grid precision. Book notional uses ROUND_HALF_UP; lane reserves use CEILING.
"""
from __future__ import annotations

from decimal import Decimal, ROUND_CEILING, ROUND_HALF_UP, localcontext

from .strategy.settlement import DEFAULT_TAKER_MULTIPLIER as _TAKER_MULTIPLIER
from .venue_facts import PER_ORDER_CEIL, VenueFactError, exact_fee_cents


# Convert the incumbent's configuration once; public numeric inputs stay exact.
DEFAULT_TAKER_MULTIPLIER = Decimal(str(_TAKER_MULTIPLIER))
DEFAULT_MAKER_MULTIPLIER = Decimal("0")


class CostError(ValueError):
    """An input is outside the adapter's exact numeric domain."""


def _decimal(value, name: str) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (int, Decimal)):
        raise CostError(f"{name} must be an int or Decimal")
    result = Decimal(value)
    if not result.is_finite():
        raise CostError(f"{name} must be finite")
    return result


def _on_grid(value: Decimal, places: int) -> bool:
    _, digits, exponent = value.as_tuple()
    extra = -exponent - places
    return extra <= 0 or not any(digits[-extra:])


def _price(value) -> Decimal:
    result = _decimal(value, "price_cents")
    if not 0 < result < 100 or not _on_grid(result, 1):
        raise CostError("price_cents must be in (0, 100) with at most 1 dp")
    return result


def _count(value) -> Decimal:
    result = _decimal(value, "count")
    if result <= 0 or not _on_grid(result, 2):
        raise CostError("count must be positive with at most 2 dp")
    return result


def _cents(value, name: str, *, signed: bool = False) -> int:
    if type(value) is not int or (not signed and value < 0):
        raise CostError(f"{name} must be {'a signed' if signed else 'a nonnegative'} int")
    return value


def _precision(*values: Decimal) -> int:
    # Enough digits for exact sums/products, independent of the caller's context.
    return 16 + sum(len(v.as_tuple().digits) + abs(v.as_tuple().exponent) for v in values)


def contract_fee_cents(price_cents, *, multiplier=DEFAULT_TAKER_MULTIPLIER,
                       maker=False, maker_multiplier=DEFAULT_MAKER_MULTIPLIER) -> int:
    """Ceiling of the one-contract model fee, matching settlement's fee tier."""
    return order_fee_cents(price_cents, 1, multiplier=multiplier, maker=maker,
                           maker_multiplier=maker_multiplier)


def order_fee_cents(price_cents, count, *, multiplier=DEFAULT_TAKER_MULTIPLIER,
                    maker=False, maker_multiplier=DEFAULT_MAKER_MULTIPLIER) -> int:
    """Round the model fee up once for the complete order's quantity (venue_facts per_order_ceil).

    Fails closed with CostError on any operand beyond 40 coefficient digits or with an exponent
    outside [-40, 40] (the venue_facts exact bound); before B13 such a value returned an
    arbitrarily large exact result, an unbounded allocation.
    """
    price, quantity = _price(price_cents), _count(count)
    taker = _decimal(multiplier, "multiplier")
    maker_rate = _decimal(maker_multiplier, "maker_multiplier")
    if type(maker) is not bool or taker < 0 or maker_rate < 0:
        raise CostError("maker must be bool and multipliers must be nonnegative")
    rate = maker_rate if maker else taker
    try:
        return exact_fee_cents(PER_ORDER_CEIL, price, quantity, rate)
    except VenueFactError as exc:
        raise CostError(str(exc)) from None


def worst_case_debit_cents(price_cents, count) -> int:
    """Dark Horse reserve: ceil(count * (ask + ceil(one-contract fee)))."""
    price, quantity = _price(price_cents), _count(count)
    fee = Decimal(contract_fee_cents(price))
    with localcontext() as ctx:
        ctx.prec = _precision(price, quantity, fee)
        return int(((price + fee) * quantity).to_integral_value(rounding=ROUND_CEILING))


def _notional_cents(price_cents, count) -> int:
    price, quantity = _price(price_cents), _count(count)
    with localcontext() as ctx:
        ctx.prec = _precision(price, quantity)
        return int((price * quantity).to_integral_value(rounding=ROUND_HALF_UP))


def entry_cost_cents(price_cents, count, fee_cents) -> int:
    """Book-rounded fill notional plus the supplied total fee (not a unit fee).

    This also matches the book's integer-intent fallback. Its Decimal-intent
    fallback separately ceilings notional and fee and can reserve more cents.
    """
    return _notional_cents(price_cents, count) + _cents(fee_cents, "fee_cents")


def exit_proceeds_cents(exit_price_cents, count, fee_cents) -> int:
    """Book-rounded gross sale proceeds less the supplied total fee, possibly negative."""
    return _notional_cents(exit_price_cents, count) - _cents(fee_cents, "fee_cents")


def episode_net_cents(entry_cost, exit_proceeds_total, settle_payout) -> int:
    """Net cents = all exit proceeds + remaining settlement payout - entry cost."""
    return (_cents(exit_proceeds_total, "exit_proceeds_total", signed=True)
            + _cents(settle_payout, "settle_payout") - _cents(entry_cost, "entry_cost"))


def fee_tier_boundary_cents() -> Decimal:
    """Upper root of m*p*(100-p)/100 = 1, to 50 significant Decimal digits.

    The irrational boundary lies between 82.7c and 82.8c with the default
    taker rate. An ask at 82.7c has a 2c fee but its rounded-up 83c limit has
    a 1c fee. Fee decisions use exact arithmetic, never this diagnostic root.
    """
    with localcontext() as ctx:
        ctx.prec = 50
        return Decimal(50) * (1 + (1 - Decimal(4) / (100 * DEFAULT_TAKER_MULTIPLIER)).sqrt())


def fee_for_rounded_limit(ask, limit) -> int:
    """Retain the larger of the quoted-ask and rounded-limit fee tiers."""
    return max(contract_fee_cents(ask), contract_fee_cents(limit))
