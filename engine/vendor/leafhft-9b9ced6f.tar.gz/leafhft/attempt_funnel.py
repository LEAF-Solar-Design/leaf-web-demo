"""Bounded, read-only attempt evidence, independent of trading and controls.

Unknown book/account-risk refusals use risk_blocked/other; other unknown
evidence stays unexplained/unmapped:<slug> so missing instrumentation is visible.
No journal, cursor, policy or trading file is written by this exporter.
"""
from __future__ import annotations

from bisect import bisect_left
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import re
import stat
import time
import urllib.error
import urllib.request

import orjson

MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_READ_BYTES = 8 * 1024 * 1024
MAX_BODY = 250 * 1024
EXPORT_DEADLINE_S = 3.0
ENDPOINT = "/api/leafhft/ingest/attempt-funnel"
_forbidden = False
_log = logging.getLogger(__name__)
STAGES = ("halted", "risk_blocked", "conflict", "too_late", "unexplained",
          "send_error", "zero_fill", "partial", "filled")
REASON_STAGE = {}
for _stage, _reasons in {
    "halted": "venue_paused lifecycle_entries_halted_or_size_below_one lifecycle_unavailable kill run_stopped kill_file_or_halt_active latched engine_disabled assignment_drift",
    "risk_blocked": "cash floor cash_floor below_cash_floor insufficient_cash_including_fee cumulative_loss_cap drawdown_stop daily_loss per_order_loss_cap exceeds_per_order_loss_cap exceeds_max_open_tickets exceeds_cluster_exposure_cap exceeds_cumulative_experiment_loss_cap ticker_cap window t2cal_headroom intent_limit ticker_limit cash_unreconciled stale_cash all_in_buffered_or_consumed reversal_market_held breaker_engine breaker_account registry_gate pilot_refused limit_refused limit_price_refused revision_conflict",
    "conflict": "engine_disagreement engine_position_exists ticker_owned ticker_pending ticker_unknown ticker_conflict incumbent_undecided duplicate_client_id ticket_engine_open ticket_opposite_side cohort_local_entry_suppressed shared_client_busy exposure_ledger_busy",
    "too_late": "market_closed proposal_expired late_send late_dispatch deadline_guard coordinated_signal_expired settlement_window_unavailable stale_quote_at_send",
    "send_error": "order_state_unknown journal_failure submission_refused",
    "zero_fill": "ioc_no_fill ioc_retry_no_fill",
    "partial": "ioc_partial", "filled": "ioc_filled",
    "unexplained": "no_reason_recorded decision_row_only",
}.items():
    REASON_STAGE.update(dict.fromkeys(_reasons.split(), _stage))
from .broker.account_risk import REFUSAL_CODES
for _reason in REFUSAL_CODES:
    REASON_STAGE.setdefault(_reason, "risk_blocked")
PREFIX_STAGE = {"lifecycle_": "halted", "drawdown_": "risk_blocked",
                "max_": "risk_blocked", "rate_budget_": "risk_blocked",
                "exposure_": "risk_blocked", "count_": "risk_blocked",
                "venue_read_": "risk_blocked", "http_": "send_error"}
REASON_STAGE.update({prefix + "*": stage for prefix, stage in PREFIX_STAGE.items()})
REASON_STAGE.update({"coordinated_*": "conflict", "authority:*": "conflict"})


def slug(text):
    return re.sub(r"[^a-z0-9_:.-]", "_", str(text).lower())[:64] or "other"


def classify_reason(text, *, source):
    """Use book/KalshiBookError or account-risk sources for generic risk refusals."""
    reason = slug(text.strip() if isinstance(text, str) else text)
    if reason.startswith("authority:"):
        stage, inner = classify_reason(reason[10:], source="authority")
        if stage == "unexplained":
            return "conflict", "authority:other"
        return stage, ("authority:" + inner)[:64]
    if reason in REASON_STAGE:
        return REASON_STAGE[reason], reason
    if reason.startswith("coordinated_"):
        return ("too_late" if "expired" in reason or "late" in reason else "conflict"), reason
    for prefix, stage in PREFIX_STAGE.items():
        if reason.startswith(prefix):
            return stage, reason
    if source in ("book", "KalshiBookError", "account", "account_risk") or source in REFUSAL_CODES:
        return "risk_blocked", "other"
    return "unexplained", ("unmapped:" + reason)[:64]


def _number(value):
    if type(value) not in (int, float, str):
        return None
    try:
        value = float(value)
        return value if math.isfinite(value) and value >= 0 else None
    except (ValueError, OverflowError):
        return None


def _object(value):
    return value if isinstance(value, dict) else {}


def _encode(value):
    try:
        return orjson.dumps(value)
    except TypeError:
        # Summed valid journal counters can exceed orjson's 64-bit integer range.
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _iso(seconds):
    return datetime.fromtimestamp(seconds, timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _wall(row):
    ns = _number(row.get("wall_time_ns"))
    if ns is not None:
        return ns / 1e9
    for key in ("decided_at", "timestamp", "ts"):
        value = row.get(key)
        if isinstance(value, str):
            try:
                stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
                if stamp.tzinfo is not None:
                    return stamp.timestamp()
            except (ValueError, OverflowError):
                pass
    return None


def _tail(path, budget, coverage, *, journal=True):
    limit = min(MAX_FILE_BYTES, budget[0])
    if limit <= 0:
        return []
    try:
        if not stat.S_ISREG(path.stat().st_mode):
            return []
        with path.open("rb") as stream:
            size = os.fstat(stream.fileno()).st_size
            offset = max(0, size - limit)
            stream.seek(offset)
            raw = stream.read(limit)
        budget[0] -= len(raw)
        if offset:
            coverage["tail_truncated"] = True
            raw = raw.partition(b"\n")[2]
        if not journal:
            try:
                return [_object(orjson.loads(raw))] if not offset else []
            except (ValueError, TypeError):
                return []
        rows = []
        # Ignore an incomplete trailing write.
        for line in raw[:raw.rfind(b"\n") + 1].splitlines():
            if len(line) > 65536:
                continue
            try:
                row = orjson.loads(line)
                if isinstance(row, dict):
                    rows.append(row)
            except (ValueError, TypeError):
                pass
        return rows
    except OSError:
        return []


def _identity(row):
    attribution = _object(row.get("attribution"))
    did = attribution.get("decision_id")
    return did if isinstance(did, str) and did and did != "unknown" else None


def _text(value, limit, default):
    if not isinstance(value, str) or not value or "\x00" in value:
        return default
    return value[:limit].encode("utf-8", "replace").decode("utf-8")


def _metrics(row):
    result = {key: _number(row.get(key)) for key in
              ("quote_age_ms", "decision_to_submit_ms", "submit_to_ack_ms")}
    for metric, end, start in (("decision_to_submit_ms", "submit_ns", "decide_end_ns"),
                               ("submit_to_ack_ms", "ack_ns", "submit_ns")):
        # These stamps are monotonic only when present together in the decision row.
        if type(row.get(end)) is int and type(row.get(start)) is int:
            result[metric] = _number((row[end] - row[start]) / 1e6)
        elif result[metric] is None:
            result[metric] = _number(_object(row.get("latency")).get(metric))
    return result


def _outcome(decision, facts):
    choices = []
    filled = _number(decision.get("filled_count"))
    requested = _number(decision.get("requested_count", decision.get("count")))
    if filled is not None and filled > 0:
        choices.append(("filled" if requested is not None and filled >= requested else "partial",
                        "ioc_filled" if requested is not None and filled >= requested else "ioc_partial"))
    elif filled == 0 and _number(decision.get("ack_ns")) is not None:
        choices.append(("zero_fill", "ioc_no_fill"))
    retry_zero = False
    for kind, row in facts:
        fill = _number(row.get("fill_count", row.get("filled_count")))
        state, result = row.get("state"), row.get("result")
        note = row.get("note")
        place_failed = isinstance(note, str) and note.startswith("place failed:")
        order_count = _number(row.get("count", row.get("requested_count")))
        if state == "FILLED" or result == "filled" or fill is not None and fill > 0 and order_count is not None and fill >= order_count:
            choices.append(("filled", "ioc_filled"))
        elif state == "PARTIAL" or result == "partial" or fill is not None and fill > 0:
            choices.append(("partial", "ioc_partial"))
        elif result == "zero" or state == "GONE" and fill == 0 and row.get("sent_ts_ns") is not None and not place_failed:
            choices.append(("zero_fill", "ioc_no_fill"))
            retry_zero |= str(row.get("client_id", "")).startswith("lb-r1-")
        if isinstance(note, str):
            match = re.search(r"place failed: http=(\d{3})(?:\s+code=([a-zA-Z0-9_.-]+))?", note)
            if match:
                choices.append(("send_error", slug("http_" + match[1] + ("_" + match[2] if match[2] else ""))))
        if state == "UNKNOWN":
            choices.append(("send_error", "order_state_unknown"))
        if result == "late_send":
            choices.append(("too_late", "late_send"))
        refusal_class = row.get("refusal_class")
        if not isinstance(refusal_class, str):
            refusal_class = None
        reason = refusal_class or row.get("refuse_reason")
        if not reason and (kind == "attribution" and row.get("stage") in ("rejected", "rejected_or_unknown") or result == "refused"):
            reason = row.get("reason") or row.get("error")
        if isinstance(reason, str) and reason:
            source = "account_risk" if refusal_class in REFUSAL_CODES else "book" if kind == "decision" or kind == "darkhorse" and result == "refused" else kind
            choices.append(classify_reason(reason, source=source))
    if retry_zero:
        choices.append(("zero_fill", "ioc_retry_no_fill"))
    if not choices:
        return "unexplained", "decision_row_only" if decision.get("client_id") else "no_reason_recorded"
    rank = {"filled": 6, "partial": 5, "zero_fill": 4, "send_error": 3, "unexplained": 0}
    return max(choices, key=lambda pair: (rank.get(pair[0], 2), pair[1] == "ioc_retry_no_fill"))


def build_attempt_funnel(run_dirs, *, now_s, bucket_s=300, window_s=86400, max_read_bytes=MAX_READ_BYTES):
    """Recompute complete buckets from bounded journal tails without side effects."""
    if type(bucket_s) is not int or not 60 <= bucket_s <= 3600:
        raise ValueError("bucket_s")
    coverage = dict(runs_read=0, decision_rows_dropped=0, tail_truncated=False,
                    stale_quote_evals=None, stale_index_evals=None, evals_in_window=None)
    block = dict(schema="leaf.attempt-funnel.v1", generated_at=_iso(now_s), bucket_s=bucket_s,
                 coverage=coverage, cells=[], latency=[], traces=[])
    budget = [max(0, min(MAX_READ_BYTES, int(max_read_bytes)))]
    cells, histograms, traces = Counter(), {}, []
    seen = set()
    for directory in run_dirs:
        if budget[0] <= 0:
            break
        directory = Path(directory)
        if not directory.is_dir():
            continue
        coverage["runs_read"] += 1
        decisions = _tail(directory / "kalshi-decisions.jsonl", budget, coverage)
        attribution = _tail(directory / "decision-attribution.jsonl", budget, coverage)
        orders = _tail(directory / "live-orders.jsonl", budget, coverage)
        darkhorse = _tail(directory / "kalshi-darkhorse-sends.jsonl", budget, coverage)
        statuses = _tail(directory / "kalshi-edge-status.json", budget, coverage, journal=False)
        if statuses:
            status = statuses[0]
            dropped = _object(status.get("decision_journal")).get("dropped", 0)
            if type(dropped) is int and dropped >= 0:
                coverage["decision_rows_dropped"] += dropped
            for target, key in (("stale_quote_evals", "skipped_stale_quote"),
                                ("stale_index_evals", "skipped_stale_index"),
                                ("evals_in_window", "in_window_evaluations")):
                value = _object(status.get("stats")).get(key)
                if type(value) is int and value >= 0:
                    coverage[target] = (coverage[target] or 0) + value
        walls = [w for row in decisions if (w := _wall(row)) is not None and 0 <= w <= now_s]
        leading = math.ceil(min(walls) / bucket_s) * bucket_s if walls else None
        attempts, clients, facts = {}, {}, {}
        for kind, rows in (("decision", decisions), ("attribution", attribution)):
            for row in rows:
                did = _identity(row)
                if did is None:
                    continue
                facts.setdefault(did, []).append((kind, row))
                cid = row.get("client_id")
                if isinstance(cid, str):
                    clients[cid] = did
                if kind == "decision" and row.get("gate") == "passed" or kind == "attribution" and row.get("stage") == "proposal":
                    if kind == "decision" or did not in attempts:
                        attempts[did] = row
        latest = {}
        for row in orders:
            cid = row.get("client_id")
            if isinstance(cid, str):
                latest[cid] = row
                did = _identity(row)
                if did:
                    clients[cid] = did
        for kind, rows in (("order", latest.values()), ("darkhorse", darkhorse)):
            for row in rows:
                did = _identity(row)
                cid = row.get("client_id")
                if not did and isinstance(cid, str):
                    did = clients.get(cid)
                if did:
                    facts.setdefault(did, []).append((kind, row))
        for did, decision in attempts.items():
            try:
                if did in seen:
                    continue
                if _wall(decision) is None:
                    representative = next((r for kind, r in facts.get(did, [])
                                           if kind == "decision" and _wall(r) is not None), None)
                    if representative is not None:
                        decision = representative
                wall = _wall(decision)
                if wall is None:
                    # Some proposals only have nested evidence; without a wall stamp
                    # they cannot truthfully contribute a time bucket.
                    continue
                bucket = math.floor(wall / bucket_s) * bucket_s
                if leading is not None and bucket < leading or bucket < now_s - window_s or wall > now_s:
                    continue
                stage, reason = _outcome(decision, facts.get(did, []))
                attr = _object(decision.get("attribution"))
                market, sizing = _object(attr.get("market_inputs")), _object(attr.get("sizing_inputs"))
                run_id = _text(directory.name, 128, "unknown")
                engine = _text(attr.get("engine_id"), 128, "unknown")
                stamp = _iso(bucket)
                seen.add(did)
                cells[(run_id, engine, stamp, stage, reason)] += 1
                metrics = _metrics(decision)
                for metric, value in metrics.items():
                    if value is not None:
                        hist = histograms.setdefault((run_id, engine, stamp, metric), [0] * 11)
                        hist[bisect_left((5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000), value)] += 1
                side = decision.get("side", market.get("side"))
                if side not in ("yes", "no"):
                    side_yes = decision.get("side_yes", market.get("side_yes"))
                    side = "yes" if side_yes is True else "no" if side_yes is False else None
                ticker = decision.get("ticker", market.get("ticker"))
                if side and isinstance(ticker, str) and ticker and "\x00" not in ticker:
                    fills = [_number(r.get("fill_count", r.get("filled_count"))) for _, r in facts.get(did, [])]
                    order_fills = [_number(r.get("fill_count")) for kind, r in facts.get(did, []) if kind == "order"]
                    if any(value is not None for value in order_fills):
                        fills.append(_number(sum(value for value in order_fills if value is not None)))
                    price = _number(decision.get("price_cents", market.get("price_cents")))
                    traces.append(dict(decision_key=hashlib.sha256(did.encode()).hexdigest()[:16],
                        run_id=run_id, engine_id=engine, ticker=_text(ticker, 64, "unknown"), side=side,
                        price_cents=int(price) if price is not None and price.is_integer() else None,
                        count=_number(decision.get("requested_count", sizing.get("requested_count"))),
                        decided_at=_iso(wall), **metrics, stage=stage, reason=reason,
                        filled_count=max((v for v in fills if v is not None), default=None)))
            except (ValueError, TypeError, OverflowError, OSError):
                continue
    block["cells"] = [dict(run_id=k[0], engine_id=k[1], bucket_start=k[2], stage=k[3], reason=k[4], count=min(v, 1000000))
                      for k, v in sorted(cells.items(), key=lambda item: item[0][2], reverse=True)[:2000]]
    block["latency"] = [dict(run_id=k[0], engine_id=k[1], bucket_start=k[2], metric=k[3], hist=v)
                        for k, v in sorted(histograms.items(), key=lambda item: item[0][2], reverse=True)[:1000]]
    block["traces"] = sorted(traces, key=lambda row: row["decided_at"], reverse=True)[:50]
    # Binary search complete bucket suffixes, avoiding quadratic re-encoding.
    if len(_encode(block)) > MAX_BODY:
        buckets = sorted({row["bucket_start"] for key in ("cells", "latency") for row in block[key]})
        original = {key: block[key] for key in ("cells", "latency", "traces")}
        low, high = 0, len(buckets)
        while low < high:
            middle = (low + high) // 2
            cutoff = buckets[middle]
            for key in ("cells", "latency"):
                block[key] = [row for row in original[key] if row["bucket_start"] >= cutoff]
            block["traces"] = [row for row in original["traces"] if row["decided_at"] >= cutoff]
            if len(_encode(block)) > MAX_BODY:
                low = middle + 1
            else:
                high = middle
        cutoff = buckets[low] if low < len(buckets) else None
        for key in ("cells", "latency"):
            block[key] = [row for row in original[key] if cutoff and row["bucket_start"] >= cutoff]
        block["traces"] = [row for row in original["traces"] if cutoff and row["decided_at"] >= cutoff]
    return block


def send_owner_attempt_funnel(runs_dir, url, token_env, *, deadline):
    global _forbidden
    try:
        if time.monotonic() >= deadline:
            return {"state": "deadline"}
        if _forbidden:
            return {"state": "disabled"}
        token = os.environ.get(token_env, "")
        if not token:
            return {"state": "disabled"}
        cutoff = time.time() - 48 * 3600
        directories = []
        for path in Path(runs_dir).iterdir():
            if time.monotonic() >= deadline:
                return {"state": "deadline"}
            try:
                if path.is_dir() and path.stat().st_mtime >= cutoff:
                    directories.append((path.stat().st_mtime, path))
            except OSError:
                continue
        block = build_attempt_funnel([p for _, p in sorted(directories, key=lambda item: item[0], reverse=True)[:8]], now_s=time.time())
        if not block["cells"]:
            return {"state": "empty"}
        block["account_id"] = "owner"
        request = urllib.request.Request(url.rstrip("/") + ENDPOINT, data=_encode(block), method="POST",
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + token,
                     "User-Agent": "leafhft-order-latency/1"})
        timeout = min(3.0, deadline - time.monotonic())
        if timeout <= 0:
            return {"state": "deadline"}
        with urllib.request.urlopen(request, timeout=timeout) as response:
            if response.status == 403:
                _forbidden = True
                _log.error("attempt funnel configuration: HTTP 403; export disabled until restart")
            if not 200 <= response.status < 300:
                return {"state": "failed", "http_status": response.status}
        return {"state": "accepted"}
    except Exception as exc:
        if isinstance(exc, urllib.error.HTTPError) and exc.code == 403:
            _forbidden = True
            _log.error("attempt funnel configuration: HTTP 403; export disabled until restart")
        else:
            _log.warning("attempt funnel export failed: %s", type(exc).__name__)
        return {"state": "failed"}


def send_lane_attempt_funnel(lane_id, run_dirs, push, deadline, redirect_handler):
    try:
        from .push import ACCOUNT_LANE_POST_TIMEOUT_S, _read_before_deadline
        if time.monotonic() >= deadline:
            return {"state": "deadline"}
        block = build_attempt_funnel(run_dirs, now_s=time.time())
        if not block["cells"]:
            return {"state": "failed", "reason": "no_complete_buckets"}
        data = _encode({"attempt_funnel": block})
        if len(data) > 256 * 1024:
            return {"state": "oversize"}
        request = urllib.request.Request(push["url"], data=data, method="POST",
            headers={"Content-Type": "application/json", "Accept": "application/json",
                     "Authorization": "Bearer " + push["token"], "User-Agent": "KashbotRunner/1.0",
                     "X-Kashbot-Route": "telemetry"})
        timeout = min(ACCOUNT_LANE_POST_TIMEOUT_S, deadline - time.monotonic())
        if timeout <= 0:
            return {"state": "deadline"}
        with urllib.request.build_opener(redirect_handler).open(request, timeout=timeout) as response:
            if not 200 <= getattr(response, "status", 200) < 300:
                return {"state": "failed"}
            reply = orjson.loads(_read_before_deadline(response, 65537, deadline))
        if (type(reply) is not dict or set(reply) != {"success", "accepted", "runner_account", "control"}
                or reply.get("success") is not True or reply.get("accepted") is not True
                or type(reply.get("runner_account")) is not dict or reply["runner_account"].get("verified") is not True
                or type(reply.get("control")) is not dict or set(reply["control"]) != {"pending"}):
            return {"state": "failed"}
        return {"state": "accepted"}
    except Exception:
        return {"state": "failed"}
