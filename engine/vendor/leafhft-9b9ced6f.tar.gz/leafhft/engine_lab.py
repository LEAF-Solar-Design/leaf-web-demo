"""Read-only engine-lab v3 projection of registered research and its evidence.

Callers pass TrialStore/LaneRegistry instances (or their directories), current
Darkhorse snapshot envelopes, and immutable report references of the form
{report_path, report_hash}. Candidate discovery is data driven. This module
never arms a lane, writes an engine, or treats simulated returns as live P&L.
Replay, paper and shadow evidence is offline tuning (simulated), never a
verdict: only a passing report with `live_fill` provenance offers an engine
(docs/ENGINES.md, "Evidence and the verdict").
"""
from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import re

from .lanes import LaneRegistry
from .lanes.document import cold_digest
from .trials import TrialStore

SCHEMA_VERSION = 3
NOT_REPORTED = "not_reported"
PROVENANCES = frozenset({"replay", "paper", "shadow", "live_fill"})
# The one provenance that may promote. Everything else is offline tuning (simulated).
PROMOTING_PROVENANCE = "live_fill"
OFFLINE_TUNING_REASON = "offline tuning (simulated): {provenance} evidence; promotion needs live_fill evidence"
MAX_REPORT_BYTES = 32 * 1024 * 1024
MAX_REPORTS = 256
MAX_SNAPSHOTS = 64
MAX_TRIAL_IDS = 64
MAX_RESEARCH_DEPTH = 6  # Consumer 30173fdb, research(), TS 72-73.
# _metrics extracts population (report + population: 2 containers) or a primary
# grid row (report + grid array + row: 3). Its index_rows branch creates only
# scalar metrics. Include the research root here because the JSON scan counts
# open containers, while TS 72-86 starts research(row.metrics) at depth 0 (TS 150).
MAX_REPORT_WRAPPER_DEPTH = 3
# This is only a recursion guard. A floor leaves boundary violations for the
# consumer mirror; the ceiling stays well below Python's recursion limit.
MAX_ENTRY_DEPTH = min(200, max(64, MAX_RESEARCH_DEPTH + MAX_REPORT_WRAPPER_DEPTH))
# Keep these in step with ops-dashboard's leafhft-engine-lab.ts validator.
PRIVATE_FIELD = re.compile(
    r"(?:account|balance|equity|buying.?power|credential|password|secret|token|"
    r"private.?key|public.?key|api.?key|access.?key|control|budget|free.?cash|"
    r"authorization|cookie|path|^enabled$|^default_enabled$|^start_live$|^stop_live$)", re.I)
# ECMAScript WhiteSpace and LineTerminator; keep word classes ASCII below.
JS_WHITESPACE = r"\t\n\v\f\r \u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff"
OMISSION_PREFIX = "Research metric fields or candidates omitted: "
PRIVATE_TEXT = re.compile(
    rf"(?:-----BEGIN|\bBearer[{JS_WHITESPACE}]|\bkashbot_[A-Za-z0-9_-]+|\b(?:api[_ -]?key|"
    r"access[_ -]?key|private[_ -]?key|public[_ -]?key|keys?|secrets?|passwords?|"
    r"credentials?|balances?|token_hash|access[_ -]?token|refresh[_ -]?token|"
    r"account[_ -]?(?:id|number|balance|telemetry|activity|budget)|free[_ -]?cash|"
    r"balance[_ -]?cents)\b)", re.I | re.ASCII)
PRIVATE_PATH = re.compile(
    rf"(?:[a-z]:[\\/]|\\\\|(?:^|[{JS_WHITESPACE}])[/~][\\/\w.]|(?:^|[\\/{JS_WHITESPACE}])\.\.(?:[\\/]|$)|"
    rf"\bfile:|(?:^|[\\/{JS_WHITESPACE}])(?:\.env(?:\.[\w-]+)?|\.ssh|\.aws|id_rsa|id_ed25519)"
    rf"(?:[\\/{JS_WHITESPACE}]|$)|\.(?:pem|key|p12|pfx)(?:\b|$))", re.I | re.ASCII)


def _text(value):
    """Redact display text without changing the evidence used for promotion."""
    if isinstance(value, str) and (PRIVATE_TEXT.search(value) or PRIVATE_PATH.search(value)):
        return "redacted"
    return value


class EngineLabValidationError(ValueError):
    """A consumer rule failed; messages contain rule names, never input values."""


_INPUT_REFUSALS = {
    "immutable report hash or size mismatch": "Report hash or size mismatch",
    "report registration or candidate mismatch": "Report registration or candidate mismatch",
}


def _input_reason(cause):
    """The one reason builder: a known refusal kind keeps its text, all else is generic."""
    return _INPUT_REFUSALS.get(str(cause), "Report input unavailable or invalid")


class EngineLabInputError(EngineLabValidationError):
    """One failed local file, identified locally without exposing its contents."""

    def __init__(self, path, cause):
        self.path = Path(path)
        self.reason = _input_reason(cause)
        super().__init__(f"{self.path.name}: {type(cause).__name__}")


def _check_depth(value, *, json_bytes=False, json_text=False):
    """Linear recursion-safety preflight, not the consumer's research-depth rule.

    validate_engine_lab measures extracted metrics from the consumer's root.
    Parsing still checks JSON syntax after the decoded report scan.
    """
    if json_bytes:
        # Match json.loads(bytes): scan characters, never UTF-16/32 code bytes.
        value = value.decode(json.detect_encoding(value), errors="surrogatepass")
    if json_bytes or json_text:
        depth, quoted, escaped = 0, False, False
        for char in value:
            if quoted:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    quoted = False
            elif char == '"':
                quoted = True
            elif char in "[{":
                depth += 1
                if depth > MAX_ENTRY_DEPTH:
                    raise EngineLabValidationError("entry recursion depth")
            elif char in "]}":
                depth -= 1
        return
    pending = [(value, 0)]
    while pending:
        item, depth = pending.pop()
        if depth > MAX_ENTRY_DEPTH:
            raise EngineLabValidationError("entry recursion depth")
        if isinstance(item, Mapping):
            pending.extend((child, depth + 1) for child in item.values())
        elif isinstance(item, (list, tuple)):
            pending.extend((child, depth + 1) for child in item)


def validate_engine_lab(value, *, kind="block", now=None, seen=None, candidate_id=None):
    """Mirror ops-dashboard leafhft-engine-lab.ts at 30173fdb, lines 13-199.

    Entry modes use the SAME rules as the block validator. Return normalized
    values for consumer equality/duplicate checks; callers may retain wire text.
    Missing properties are distinct from JSON null, as in JavaScript.
    """
    absent = object()
    whitespace = "\t\n\v\f\r \u00a0\u1680" + "".join(map(chr, range(0x2000, 0x200b))) + "\u2028\u2029\u202f\u205f\u3000\ufeff"

    def require(condition, rule):
        if not condition:
            raise EngineLabValidationError(rule)

    def obj(item, fields):  # TS 13-18
        require(type(item) is dict, "object type")
        require(item.keys() <= set(fields.split()), "object fields")
        return item

    def length(item):
        return len(item.encode("utf-16-le", errors="surrogatepass")) // 2

    def text(item, maximum):  # TS 28-31
        require(type(item) is str, "text type")
        require(bool(item.strip(whitespace)), "text empty after trim")
        require(length(item) <= maximum, "text length")
        require(not PRIVATE_TEXT.search(item) and not PRIVATE_PATH.search(item), "private text")
        require(not re.search(r"[\x00-\x08\x0b-\x1f\x7f]", item), "text control character")
        return item.strip(whitespace)

    def identity(item, *, private=True):  # TS 24-26
        require(type(item) is str and re.fullmatch(r"[a-z0-9][a-z0-9-]{0,63}", item)
                and (not private or not PRIVATE_TEXT.search(item)), "engine identity")
        return item

    def stamp(item):  # TS 33-40, Date.parse truncates fractional milliseconds
        require(type(item) is str and length(item) <= 40, "timestamp type or length")
        require(re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:\.[0-9]{1,9})?(?:Z|[+-](?:[01][0-9]|2[0-3]):[0-5][0-9])", item), "timestamp format")
        year, month, day = map(int, item[:10].split("-"))
        # A 400-year shift permits JS year zero and offset crossings at year 9999.
        shifted_year = year % 400 + 2000
        try:
            base = datetime(shifted_year, month, day, int(item[11:13]),
                            int(item[14:16]), int(item[17:19]), tzinfo=timezone.utc)
        except ValueError:
            raise EngineLabValidationError("timestamp calendar date") from None
        fraction = re.search(r"\.([0-9]+)", item)
        millis = int((fraction.group(1) + "000")[:3]) if fraction else 0
        offset = 0 if item.endswith("Z") else (int(item[-5:-3]) * 60 + int(item[-2:])) * (1 if item[-6] == "+" else -1)
        epoch_ms = (int(base.timestamp()) * 1000 + (year - shifted_year) // 400 * 146097 * 86400000
                    + millis - offset * 60000)
        utc = base + timedelta(milliseconds=millis, minutes=-offset)
        utc_year = utc.year + year - shifted_year
        year_text = f"{utc_year:04d}" if 0 <= utc_year <= 9999 else f"{utc_year:+07d}"
        iso = (f"{year_text}-{utc.month:02d}-{utc.day:02d}T{utc.hour:02d}:"
               f"{utc.minute:02d}:{utc.second:02d}.{utc.microsecond // 1000:03d}Z")
        return iso, epoch_ms

    def number(item):
        if type(item) not in (int, float):
            return False
        try:
            return math.isfinite(float(item))
        except OverflowError:
            return False

    def array(item, maximum):  # TS 49-51
        require(type(item) is list and len(item) <= maximum, "array type or count")
        return item

    def provenance(item):  # TS 53-55
        require(type(item) is str and item in (*PROVENANCES, NOT_REPORTED), "provenance")
        return item

    def source_stamp(item):  # TS 57-61
        if item == NOT_REPORTED:
            return item
        if number(item) and float(item).is_integer() and 0 < float(item) <= 1e20:
            return float(item)
        return stamp(item)[0]

    def digest(item):  # TS 63-65
        require(type(item) is str and (item == NOT_REPORTED or re.fullmatch(r"[a-f0-9]{64}", item)), "hash")
        return item

    def profit(item):  # TS 67-70
        require(item == NOT_REPORTED or number(item), "profit type or finite number")
        return float(item) if number(item) else item

    def field(item):  # TS 82-84
        require(type(item) is str and re.fullmatch(r"[a-zA-Z0-9_.-]{1,80}", item)
                and not PRIVATE_FIELD.search(item)
                and item not in ("__proto__", "constructor", "prototype"), "research field")
        text(item, 80)
        return item

    def research(item, depth=0):  # TS 72-86
        require(depth <= MAX_RESEARCH_DEPTH, "research depth")
        if type(item) is str:
            return text(item, 2000)
        if type(item) is bool:
            return item
        if type(item) in (int, float):
            return profit(item)
        if type(item) is list:
            return [research(child, depth + 1) for child in array(item, 128)]
        require(type(item) is dict, "research object type")
        require(len(item) <= 64, "research field count")
        return {field(key): research(child, depth + 1) for key, child in item.items()}

    def origin_profit(row):  # TS 145-147, 179-181
        origin = provenance(row.get("provenance", absent))
        amount = profit(row.get("live_profit_cents", absent))
        require(amount == NOT_REPORTED or origin == "live_fill", "profit requires live_fill")
        return origin, amount

    def evidence(item):  # TS 140-152
        row = obj(item, "candidate_id kind source_timestamp provenance source source_hash status reason metrics live_profit_cents verdict")
        require(row.get("kind") in ("trial_registration", "lane_registration", "darkhorse_snapshot", "report"), "evidence kind")
        require(row.get("status") in ("reported", "held"), "evidence status")
        origin, amount = origin_profit(row)
        result = {"candidate_id": identity(row.get("candidate_id")), "kind": row["kind"],
                  "source_timestamp": source_stamp(row.get("source_timestamp", absent)),
                  "provenance": origin, "source": text(row.get("source"), 1024),
                  "source_hash": digest(row.get("source_hash")), "status": row["status"],
                  "reason": text(row.get("reason"), 2000), "metrics": research(row.get("metrics")),
                  "live_profit_cents": amount}
        if "verdict" in row:
            result["verdict"] = text(row["verdict"], 80)
        return result

    def candidate(item):  # TS 166-190; cross-candidate uniqueness is below
        row = obj(item, "id engine_id name enabled shadow_only reason engine promotion_verdict live_profit_cents evidence source_timestamp provenance trial_ids registered_mode")
        engine_id = identity(row.get("engine_id"))
        require(row.get("id") == engine_id and row.get("enabled") is False
                and type(row.get("shadow_only")) is bool, "candidate identity or flags")
        descriptor = row.get("engine", absent)
        if descriptor is not None:
            obj(descriptor, "engine_id enabled default_enabled evidence_hash")
            require(descriptor.get("engine_id") == engine_id and descriptor.get("enabled") is False
                    and descriptor.get("default_enabled") is False, "engine descriptor identity or flags")
            digest(descriptor.get("evidence_hash"))
        rows = [evidence(child) for child in array(row.get("evidence"), 256)]
        require(all(child["candidate_id"] == engine_id for child in rows), "evidence candidate identity")
        origin, amount = origin_profit(row)
        result = {**row, "name": text(row.get("name"), 128), "reason": text(row.get("reason"), 2000),
                  "promotion_verdict": text(row.get("promotion_verdict"), 80), "evidence": rows,
                  "provenance": origin, "live_profit_cents": amount,
                  "source_timestamp": source_stamp(row.get("source_timestamp", absent))}
        if "trial_ids" in row:
            ids = [text(child, 128) for child in array(row["trial_ids"], 64)]
            require(len(set(ids)) == len(ids), "duplicate trial identities")
            result["trial_ids"] = ids
        if "registered_mode" in row:
            require(row["registered_mode"] in ("paper", "live", "shadow"), "registered mode")
        return result

    def candidate_rows(items):  # TS 165, 169
        rows = [candidate(row) for row in array(items, 64)]
        require(len({row["id"] for row in rows}) == len(rows), "duplicate candidates")
        return rows

    def evidence_rows(items):  # TS 192-194
        rows = [evidence(row) for row in array(items, 256)]
        identities = [tuple(row[key] for key in (
            "candidate_id", "kind", "source", "source_hash", "source_timestamp")) for row in rows]
        require(len(set(identities)) == len(identities), "duplicate evidence")
        return rows

    def stringify(item):
        # JSON.stringify uses binary64 numbers, compact separators, UTF-8 text,
        # and escapes lone surrogates (TS 159). Python's default JSON differs.
        if type(item) is str:
            paired = item.encode("utf-16-le", errors="surrogatepass").decode("utf-16-le", errors="surrogatepass")
            encoded = json.dumps(paired, ensure_ascii=False)
            return "".join(f"\\u{ord(char):04x}" if 0xd800 <= ord(char) <= 0xdfff else char for char in encoded)
        if item is None:
            return "null"
        if type(item) is bool:
            return "true" if item else "false"
        if type(item) in (int, float):
            if not number(item):
                return "null"
            n = float(item)
            if n == 0:
                return "0"
            raw = repr(n).lower()
            if 1e-6 <= abs(n) < 1e21:
                if "e" in raw:
                    from decimal import Decimal
                    raw = format(Decimal(raw), "f")
                return raw[:-2] if raw.endswith(".0") else raw
            mantissa, exponent = raw.split("e")
            mantissa = mantissa.removesuffix(".0")
            return mantissa + "e" + ("+" if int(exponent) >= 0 else "-") + str(abs(int(exponent)))
        if type(item) is list:
            return "[" + ",".join(map(stringify, item)) + "]"
        require(type(item) is dict and all(type(key) is str for key in item), "JSON object type")
        indices = sorted((key for key in item if re.fullmatch(r"0|[1-9][0-9]*", key)
                          and len(key) <= 10 and int(key) < 4294967295), key=int)
        keys = indices + [key for key in item if key not in indices]
        return "{" + ",".join(stringify(key) + ":" + stringify(item[key]) for key in keys) + "}"

    if kind == "engine_id":
        return identity(value)
    if kind == "registration_id":
        # Construction retains identity until emission; it never renames an ID.
        return identity(value, private=False)
    if kind == "field":
        return field(value)
    if kind == "problem":
        return text(value, 2000)
    if kind == "evidence":
        row = evidence(value)
        require(candidate_id is None or row["candidate_id"] == candidate_id, "evidence candidate identity")
        identity_key = tuple(row[key] for key in ("candidate_id", "kind", "source", "source_hash", "source_timestamp"))
        if seen is not None:
            require(identity_key not in seen, "duplicate evidence")
            seen.add(identity_key)
        return row
    if kind == "candidate":
        row = candidate(value)
        if seen is not None:
            require(row["id"] not in seen, "duplicate candidates")
            seen.add(row["id"])
        return row
    if kind == "candidates":
        return candidate_rows(value)
    if kind == "evidence_rows":
        return evidence_rows(value)
    if kind == "input_views":
        # TS 194-195: compare the consumer's normalized evidence, not raw text.
        # Identical input views may contain bad entries to be omitted together.
        left, right = value
        # Compare raw views iteratively: discarded entries may be arbitrarily
        # deep, and must never re-enter the recursive serializer here.
        pending = [(left, right)]
        equal = True
        while pending:
            first, second = pending.pop()
            if first is second:
                continue
            if type(first) is dict and type(second) is dict:
                if list(first) != list(second):
                    equal = False
                    break
                pending.extend((first[key], second[key]) for key in first)
            elif type(first) is list and type(second) is list:
                if len(first) != len(second):
                    equal = False
                    break
                pending.extend(zip(first, second))
            elif type(first) in (dict, list) or type(second) in (dict, list):
                equal = False
                break
            elif stringify(first) != stringify(second):
                equal = False
                break
        if equal:
            return value
        require(stringify([evidence(row) for row in left]) == stringify([evidence(row) for row in right]),
                "flat evidence mismatch")
        return value
    require(kind == "block", "validator kind")
    require(len(stringify(value).encode("utf-8")) <= 64 * 1024, "block byte limit")  # TS 5, 158-160
    body = obj(value, "schema_version generated_at candidates evidence problems missing_value live_profit_cents")
    require(type(body.get("schema_version")) in (int, float) and body["schema_version"] == 3
            and body.get("missing_value") == NOT_REPORTED
            and body.get("live_profit_cents", NOT_REPORTED) == NOT_REPORTED, "block schema or missing sentinel")  # TS 162-163
    candidates = candidate_rows(body.get("candidates"))
    rows = evidence_rows(body.get("evidence"))
    require(stringify([row for item in candidates for row in item["evidence"]]) == stringify(rows), "flat evidence mismatch")  # TS 195
    generated, generated_ms = stamp(body.get("generated_at"))
    current = datetime.now(timezone.utc).timestamp() if now is None else now
    require(generated_ms <= current * 1000 + 60000, "generated_at in future")  # TS 196-197
    problems = [text(row, 2000) for row in array(body.get("problems"), 64)]  # TS 199
    return {**body, "generated_at": generated, "candidates": candidates, "evidence": rows,
            "problems": problems, "live_profit_cents": NOT_REPORTED}


def _promotion_refusal(candidate):
    """Walk every report item; the first whose provenance is not live_fill refuses by name.

    An absent provenance (not_reported) refuses too. Returns None only when every
    report item is live_fill. Registration, lane and snapshot rows carry no verdict.
    """
    for row in candidate["evidence"]:
        if row["kind"] == "report" and row["provenance"] != PROMOTING_PROVENANCE:
            if row["provenance"] == NOT_REPORTED:
                return "provenance not_reported; promotion needs live_fill evidence"
            return OFFLINE_TUNING_REASON.format(provenance=row["provenance"])
    return None


def _stamp(value):
    if type(value) is int and value > 0:
        return value
    if isinstance(value, str) and value != NOT_REPORTED:
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is not None:
                return dt.astimezone(timezone.utc).isoformat()
        except ValueError:
            pass
    return NOT_REPORTED


def _order(value):
    stamp = _stamp(value)
    if type(stamp) is int:
        return stamp
    if stamp == NOT_REPORTED:
        return -1
    return int(datetime.fromisoformat(stamp).timestamp() * 1_000_000_000)


def _number(value):
    if type(value) is int or (type(value) is float and math.isfinite(value)):
        return value
    return NOT_REPORTED


def _present(value, redactions=None):
    _check_depth(value)
    return _present_value(value, redactions)


def _present_value(value, redactions):
    if value is None:
        return NOT_REPORTED
    if isinstance(value, Mapping):
        result = {}
        for key, item in value.items():
            try:
                validate_engine_lab(key, kind="field")
            except EngineLabValidationError:
                if redactions is not None:
                    redactions[0] += 1
                continue
            result[key] = _present_value(item, redactions)
        return result
    if isinstance(value, (list, tuple)):
        return [_present_value(item, redactions) for item in value]
    if type(value) is float and not math.isfinite(value):
        return NOT_REPORTED
    return _text(value)


def _candidate(candidates, engine_id):
    validate_engine_lab(engine_id, kind="registration_id")
    if engine_id not in candidates:
        candidates[engine_id] = {
            "id": engine_id, "engine_id": engine_id,
            "name": _text(engine_id.replace("-", " ").title()),
            "enabled": False, "shadow_only": True,
            "reason": "promotion verdict not_reported", "engine": None,
            "promotion_verdict": NOT_REPORTED,
            "live_profit_cents": NOT_REPORTED, "evidence": [],
        }
    return candidates[engine_id]


def _evidence(candidate, kind, *, timestamp=None, provenance=None, source=None,
              metrics=None, reason=None, digest=None, redactions=None):
    row = {"candidate_id": candidate["id"], "kind": kind,
           "source_timestamp": _stamp(timestamp),
           "provenance": provenance if provenance in PROVENANCES else NOT_REPORTED,
           "source": _text(source or NOT_REPORTED), "source_hash": digest or NOT_REPORTED,
           "status": "reported" if reason is None else "held",
           "reason": _text(reason or NOT_REPORTED),
           "metrics": _present(metrics, redactions),
           "live_profit_cents": NOT_REPORTED}
    candidate["evidence"].append(row)
    return row


def _provenance(registration=None, report=None):
    report = report or {}
    declared = report.get("provenance")
    source = report.get("source")
    if report.get("schema") == "dip-recovery-replay-v1":
        return "replay"
    if report.get("scorer_id") == "r12-relay-divergence-daily":
        return "paper"
    if declared in {"replay", "paper", "shadow"}:
        return declared
    if source == "shadow":
        return "shadow"
    if registration is not None:
        execution = registration.execution
        if execution.get("source") == "shadow":
            return "shadow"
        if execution["mode"] == "paper":
            return "replay" if execution.get("source") == "paper_replay" else "paper"
        # A live registration alone does not turn an arbitrary attachment into
        # fill evidence. Only the ledger scorer supplies this population.
        if (execution["mode"] == "live"
                and str(report.get("scorer_id", "")).startswith("kalshi_engine_verdict/")):
            return "live_fill"
    return NOT_REPORTED


def _json_pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate report field: " + key)
        result[key] = value
    return result


def _finite_float(value):
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("nonfinite report number")
    return number


def _load_json(path, *, limit=MAX_REPORT_BYTES, expected_hash=None, canonical=None,
               lines=False, line_limit=None, max_lines=None, with_bytes=False):
    """The Engine Lab file reader: bounded bytes, decoded depth scan, then parse.

    All read/decode/parse failures, including recursion and allocation failures,
    carry the filename so callers count each failed file once and keep siblings.
    Canonical producers still authenticate the original bytes, not decoded text.
    """
    try:
        with Path(path).open("rb") as stream:
            data = stream.read(limit + 1)
        if len(data) > limit:
            raise ValueError("research input limit")
        if expected_hash is not None and (
                type(expected_hash) is not str or not re.fullmatch(r"[a-f0-9]{64}", expected_hash)
                or hashlib.sha256(data).hexdigest() != expected_hash):
            raise ValueError("immutable report hash or size mismatch")
        text = data.decode(json.detect_encoding(data), errors="surrogatepass")
        # JSONL separates on LF only; Unicode line separators can occur in strings.
        parts = text.split("\n") if lines else []
        documents = ([part + "\n" for part in parts[:-1]]
                     + ([parts[-1]] if parts[-1] else [])) if lines else [text]
        if lines and len(documents) > max_lines:
            raise ValueError("research event count")
        values = []
        for document in documents:
            if lines and (not document.endswith("\n") or len(document.encode("utf-8")) > line_limit):
                raise ValueError("research event line too long or incomplete")
            _check_depth(document, json_text=True)
            value = json.loads(document, object_pairs_hook=_json_pairs,
                               parse_float=_finite_float, parse_constant=_finite_float)
            if type(value) is not dict:
                raise ValueError("research document must be an object")
            values.append(value)
        result = values if lines else values[0]
        if canonical is not None and canonical(result) != data:
            raise ValueError("noncanonical research JSON")
        return (result, data) if with_bytes else result
    except Exception as exc:
        raise EngineLabInputError(path, exc) from None


class _LabTrials(TrialStore):
    """Read-only TrialStore adapter retaining its receipt and identity checks."""

    def _report(self, reference, record):
        """Load one referenced file independently of its trial's registration."""
        return _report(reference)

    def _record(self, path):
        from . import trials

        def document(name, limit, **kwargs):
            file = path / name
            trials._safe_stat(file)
            return _load_json(file, limit=limit, **kwargs)

        raw, data = document("registration.json", trials.MAX_REGISTRATION_BYTES, with_bytes=True)
        if raw.get("provenance") == "prospective" and raw.get("transcribed_from", False) is None:
            raw.pop("transcribed_from")
        reg = trials.Registration.from_mapping(raw)
        if reg.trial_id != path.name:
            raise trials.TrialError("tampered: registration trial_id does not match directory")
        digest = trials.registration_hash(reg)
        if hashlib.sha256(data).hexdigest() != digest:
            raise trials.TrialError("tampered: registration bytes are not canonical")
        rows = document("events.jsonl", trials.MAX_EVENT_BYTES * trials.MAX_EVENTS,
                        lines=True, line_limit=trials.MAX_EVENT_BYTES, max_lines=trials.MAX_EVENTS)
        for row in rows:
            trials._event(row)
        registered = [row for row in rows if row["kind"] == "registered"]
        if (len(registered) != 1 or not rows or rows[0] != registered[0]
                or registered[0]["registration_hash"] != digest
                or registered[0]["at"] != reg.registered_at):
            raise trials.TrialError("tampered: registered event does not match registration")
        activation = None
        if trials._safe_stat(path / "activation.json", missing=True) is not None:
            activation = trials.Activation.from_mapping(document("activation.json", trials.MAX_ACTIVATION_BYTES))
            if activation.trial_id != reg.trial_id or activation.registration_hash != digest:
                raise trials.TrialError("tampered: activation registration hash or trial_id mismatch")
        activated = [row for row in rows if row["kind"] == "activated"]
        expected = [] if activation is None else [{
            "kind": "activated", "at": activation.activated_at,
            "registration_hash": digest, "population_start_ns": activation.population_start_ns}]
        if activated != expected:
            raise trials.TrialError("tampered: activated event does not match activation")
        closed = None
        if trials._safe_stat(path / "closed.json", missing=True) is not None:
            closed = trials._closed(document("closed.json", trials.MAX_EVENT_BYTES))
            if activation is None and closed["verdict"] != "ABANDONED":
                raise trials.TrialError("tampered: unactivated trial is closed")
        closing = [row for row in rows if row["kind"] == "closed"]
        expected = [] if closed is None else [{
            "kind": "closed", "at": closed["closed_at"],
            "verdict": closed["verdict"], "evidence_hash": closed["evidence_hash"]}]
        if closing != expected:
            raise trials.TrialError("tampered: closed event does not match closure")
        if activated and closing and rows.index(activated[0]) > rows.index(closing[0]):
            raise trials.TrialError("tampered: activation follows closure")
        return trials.TrialRecord(reg, digest, activation, closed, len(rows)), rows


class _LabLanes(LaneRegistry):
    """Parse each lane once, including unavailable implementations' declarations."""

    def list(self):
        from .lanes.document import MAX_DOCUMENT_BYTES, _document_from_mapping
        from .lanes.registry import MAX_LIVE, LaneRegistryError

        self.problems, self.raw_documents, self.input_failures = [], {}, {}
        try:
            paths = self._paths()
        except (OSError, LaneRegistryError) as exc:
            self.problems.append("lanes: " + type(exc).__name__)
            return []
        for path in paths:
            try:
                self.raw_documents[path] = _load_json(path, limit=MAX_DOCUMENT_BYTES)
            except EngineLabInputError as exc:
                self.input_failures[exc.path] = str(exc)
        if sum(raw.get("mode") == "live" for raw in self.raw_documents.values()) > MAX_LIVE:
            self.problems.append(str(LaneRegistryError(f"registry exceeds {MAX_LIVE} live lane documents")))
            self.raw_documents = {}
            return []
        documents = []
        for path, raw in self.raw_documents.items():
            try:
                documents.append(_document_from_mapping(path, raw))
            except Exception as exc:
                self.problems.append(f"{path.name}: {type(exc).__name__}")
        return documents


def _report(reference):
    if type(reference["report_hash"]) is not str or not re.fullmatch(r"[a-f0-9]{64}", reference["report_hash"]):
        raise ValueError("immutable report hash is required")
    return _load_json(reference["report_path"], expected_hash=reference["report_hash"])


def _metrics(report):
    population = report.get("population")
    if isinstance(population, dict):
        return population
    grid = report.get("grid")
    primary = next((row for row in (grid if isinstance(grid, list) else [])
                    if isinstance(row, dict) and row.get("label") == "primary"), None)
    if primary is not None:
        return primary
    if "index_rows" in report:
        return {"index_rows": _number(report.get("index_rows")),
                "settled_markets": len(report["settled_markets"])
                if isinstance(report.get("settled_markets"), dict) else NOT_REPORTED}
    return NOT_REPORTED


def _hold_reason(report):
    diagnostics = report.get("diagnostics", {})
    if report.get("complete") is False or report.get("truncated"):
        return "incomplete report"
    if isinstance(diagnostics, dict) and any(diagnostics.get(key) for key in (
            "truncated", "malformed", "invalid_rows", "attribution_conflict", "decision_truncated")):
        return "incomplete or invalid evidence"
    verdict = report.get("verdict", NOT_REPORTED)
    if verdict not in {"SUCCESS", "SCREEN_PASS"}:
        return str(report.get("rule") or verdict)
    if not str(report.get("scorer_id", "")).startswith("kalshi_engine_verdict/"):
        return "promotion scorer not_reported"
    if not isinstance(report.get("population"), dict) or not report["population"]:
        return "population not_reported"
    return None


def _valid_population(report):
    diagnostics = report.get("diagnostics", {})
    return (isinstance(report.get("population"), dict) and isinstance(diagnostics, dict)
            and report.get("complete") is not False and not report.get("truncated")
            and not any(diagnostics.get(key) for key in (
                "truncated", "malformed", "invalid_rows", "attribution_conflict")))


def build_engine_lab(trial_store=None, lane_registry=None, darkhorse_snapshots=(), reports=(), *,
                     now=None, trials_dir=None, lanes_dir=None):
    """Build v3 evidence without mutating the underlying research stores.

    Missing values are explicit, including timestamps absent from an older
    producer. Report references require hashes, never trust a mutable filename.
    A passing existing scorer report offers a disabled engine descriptor only,
    and only when its provenance is live_fill; a replay, paper or shadow pass is
    offline tuning (simulated) and stays shadow_only with no engine.
    """
    if trial_store is None and trials_dir is not None:
        trial_store = _LabTrials(trials_dir)
    elif trial_store is not None and not isinstance(trial_store, TrialStore):
        trial_store = _LabTrials(trial_store)
    elif trial_store is not None and type(trial_store)._record is TrialStore._record:
        # Custom in-memory stores may override get/events without opening files.
        if type(trial_store).get is TrialStore.get:
            trial_store = _LabTrials(trial_store.dir_path)
    if lane_registry is None and lanes_dir is not None:
        lane_registry = _LabLanes(lanes_dir)
    elif lane_registry is not None and not isinstance(lane_registry, LaneRegistry):
        lane_registry = _LabLanes(lane_registry)
    elif lane_registry is not None and getattr(lane_registry.list, "__func__", None) is LaneRegistry.list:
        reader = _LabLanes(lane_registry.dir_path)
        reader._paths = lane_registry._paths
        lane_registry = reader
    candidates, problems, pending, records = {}, [], [], {}
    input_failures = {}  # Local filenames identify omissions; only totals cross the wire.
    redactions = [0]
    gold = _candidate(candidates, "kalshi-gold-paper")
    gold["registered_mode"] = "paper"
    gold["reason"] = "collecting paper outcomes"
    if trial_store is not None:
        try:
            trial_ids = trial_store.list()
        except (OSError, ValueError) as exc:
            trial_ids = []
            problems.append("trials: " + str(exc))
        for trial_id in trial_ids:
            try:
                record = trial_store.get(trial_id)
                records[trial_id] = record
                reg = record.registration
                candidate = _candidate(candidates, reg.candidate["engine_id"])
                candidate.setdefault("trial_ids", []).append(trial_id)
                # Newest registration first, then descending id for equal stamps.
                # Bound the projection as it is built, not just at serialization.
                candidate["trial_ids"].sort(key=lambda item: (
                    _order(records[item].registration.registered_at), item), reverse=True)
                del candidate["trial_ids"][MAX_TRIAL_IDS:]
                _evidence(candidate, "trial_registration", timestamp=reg.registered_at,
                          redactions=redactions,
                          provenance=_provenance(reg), source="TrialStore/" + trial_id,
                          digest=record.hash, metrics={"trial_hash": record.hash,
                              "mode": reg.execution["mode"], "hypothesis": reg.hypothesis["cell"]})
                events = [event for event in trial_store.events(trial_id)
                          if event["kind"] in {"report", "read", "superseded_report"}]
                superseded = {event["supersedes_hash"] for event in events
                              if event["kind"] == "superseded_report"}
                events = [event for event in events if event["report_hash"] not in superseded]
                if len(events) > MAX_REPORTS:
                    problems.append(trial_id + ": report history limited to latest 256 receipts")
                for event in sorted(events, key=lambda e: _order(e["at"]))[-MAX_REPORTS:]:
                    pending.append((candidate, event, record))
                if record.closed:
                    pending.append((candidate, {"report_path": record.closed["report_path"],
                        "report_hash": record.closed["evidence_hash"], "at": record.closed["closed_at"]}, record))
            except EngineLabInputError as exc:
                input_failures[exc.path] = str(exc)
            except EngineLabValidationError:
                redactions[0] += 1
            except (OSError, ValueError, KeyError, TypeError) as exc:
                problems.append(trial_id + ": " + str(exc))
            except Exception:
                redactions[0] += 1

    if lane_registry is not None:
        for document in lane_registry.list():
            try:
                candidate = _candidate(candidates, document.id)
                candidate["registered_mode"] = document.mode
                path = lane_registry.path_for(document.id)
                _evidence(candidate, "lane_registration",
                          redactions=redactions,
                          timestamp=datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(),
                          provenance="paper" if document.mode == "paper" else None,
                          source="LaneRegistry/" + document.id, digest=cold_digest(document),
                          metrics={"entry": document.to_mapping()["entry"], "mode": document.mode,
                                   "timestamp_basis": "registration_file_mtime"})
            except Exception:
                redactions[0] += 1
        problems.extend(lane_registry.problems)
        input_failures.update(getattr(lane_registry, "input_failures", {}))
        # Unavailable code does not erase a registered candidate from the lab.
        try:
            raw_documents = getattr(lane_registry, "raw_documents", None)
            paths = raw_documents if raw_documents is not None else lane_registry._paths()
            for path in paths:
                if path.stem in candidates:
                    continue
                try:
                    from .lanes.document import MAX_DOCUMENT_BYTES

                    raw = (raw_documents[path] if raw_documents is not None
                           else _load_json(path, limit=MAX_DOCUMENT_BYTES))
                    if raw.get("id") != path.stem:
                        continue
                    candidate = _candidate(candidates, path.stem)
                    _evidence(candidate, "lane_registration", source="LaneRegistry/" + candidate["id"],
                              provenance="paper" if raw.get("mode") == "paper" else None,
                              reason="lane implementation or document unavailable")
                except EngineLabInputError as exc:
                    input_failures[exc.path] = str(exc)
                except Exception:
                    redactions[0] += 1
        except Exception as exc:
            problems.append("lanes: " + str(exc))

    if isinstance(darkhorse_snapshots, Mapping):
        darkhorse_snapshots = [darkhorse_snapshots]
    for index, envelope in enumerate(darkhorse_snapshots):
        if index >= MAX_SNAPSHOTS:
            problems.append("Darkhorse snapshots limited to 64")
            break
        try:
            candidate = _candidate(candidates, envelope.get("engine_id", "darkhorse"))
            snapshot = envelope.get("snapshot", envelope)
            _evidence(candidate, "darkhorse_snapshot", timestamp=envelope.get("source_timestamp"),
                      redactions=redactions,
                      provenance="shadow", source=envelope.get("source", "Darkhorse.snapshot"),
                      metrics={key: snapshot.get(key, NOT_REPORTED) for key in (
                          "stats", "markets", "late_ms", "due_ms", "score_max", "last_score",
                          "index_rows", "quote_rows", "lifecycle_rows")})
        except EngineLabValidationError:
            redactions[0] += 1
        except (ValueError, TypeError, AttributeError) as exc:
            problems.append("Darkhorse: " + str(exc))
        except Exception:
            redactions[0] += 1

    for index, reference in enumerate(reports):
        if index >= MAX_REPORTS:
            problems.append("external report references limited to 256")
            break
        try:
            report = _report(reference)
            record = records.get(report.get("trial_id"))
            engine_id = (record.registration.candidate["engine_id"] if record else
                         report.get("engine_id", reference.get("engine_id")))
            pending.append((_candidate(candidates, engine_id), reference, record))
        except EngineLabInputError as exc:
            input_failures[exc.path] = str(exc)
        except EngineLabValidationError:
            redactions[0] += 1
        except (OSError, ValueError, KeyError, TypeError) as exc:
            problems.append("report: " + str(exc))
        except Exception:
            redactions[0] += 1

    latest, latest_order, seen = {}, {}, set()
    for candidate, reference, record in pending:
        evidence_count = len(candidate["evidence"])
        try:
            identity = (candidate["id"], reference["report_hash"])
            report, reason, valid = {}, None, False
            provenance = _provenance(record.registration) if record else NOT_REPORTED
            stamp = reference.get("at")
            try:
                report = (trial_store._report(reference, record)
                          if record is not None and isinstance(trial_store, _LabTrials)
                          else _report(reference))
                if record and (report.get("registration_hash") != record.hash
                               or report.get("trial_id", record.registration.trial_id) != record.registration.trial_id
                               or report.get("engine_id", candidate["id"]) != candidate["id"]):
                    raise EngineLabInputError(reference["report_path"],
                                              ValueError("report registration or candidate mismatch"))
                # Each filename must pass its own read and binding checks,
                # even when a valid sibling has already supplied this hash.
                if identity in seen:
                    continue
                provenance = _provenance(record.registration if record else None, report)
                stamp = report.get("source_timestamp", report.get("data_cutoff", report.get("until_ns", stamp)))
                reason = _hold_reason(report)
                if _stamp(stamp) == NOT_REPORTED:
                    reason = "source timestamp not_reported"
                if provenance == NOT_REPORTED:
                    reason = "provenance not_reported"
                if record is None:
                    reason = reason or "registered trial not_reported"
                elif record.activation is None:
                    reason = "trial not activated"
                elif record.closed and record.closed["verdict"] not in {"SUCCESS", "SCREEN_PASS"}:
                    reason = "trial closed: " + record.closed["verdict"]
                valid = (record is not None and _stamp(stamp) != NOT_REPORTED
                         and provenance != NOT_REPORTED
                         and _valid_population(report))
            except EngineLabValidationError:
                raise
            except OSError:
                reason = "Report unreadable"
            except (ValueError, KeyError, TypeError) as exc:
                reason = str(exc)
            row = _evidence(candidate, "report", timestamp=stamp, provenance=provenance,
                            redactions=redactions,
                            source="ImmutableReport/" + reference["report_hash"], digest=reference["report_hash"],
                            metrics=_metrics(report), reason=reason)
            row["verdict"] = _text(report.get("verdict", NOT_REPORTED))
            # Only authenticated ledger-scorer populations can report live profit.
            if valid and provenance == "live_fill":
                population = report.get("population", {})
                row["live_profit_cents"] = _number(population.get("net_cents"))
            validate_engine_lab(row, kind="evidence", candidate_id=candidate["id"])
            order = _order(reference.get("at", row["source_timestamp"]))
            seen.add(identity)
            if candidate["id"] not in latest or order >= latest_order[candidate["id"]]:
                latest[candidate["id"]] = row
                latest_order[candidate["id"]] = order
        except EngineLabInputError as exc:
            del candidate["evidence"][evidence_count:]
            input_failures[exc.path] = str(exc)
            candidate["reason"] = exc.reason
        except Exception:
            # Parse, sanitize and validate form one entry transaction.
            del candidate["evidence"][evidence_count:]
            redactions[0] += 1

    for engine_id, candidate in candidates.items():
        row = latest.get(engine_id)
        if row is not None:
            candidate["promotion_verdict"] = row["verdict"]
            candidate["reason"] = row["reason"]
            candidate["live_profit_cents"] = row["live_profit_cents"]
            refusal = _promotion_refusal(candidate)
            if row["status"] == "reported" and refusal is not None:
                candidate["reason"] = refusal
            elif row["status"] == "reported":
                candidate["shadow_only"] = False
                candidate["reason"] = "promotion passed; engine disabled by default"
                candidate["engine"] = {"engine_id": engine_id, "enabled": False,
                                       "default_enabled": False, "evidence_hash": row["source_hash"]}
        candidate["source_timestamp"] = (row["source_timestamp"] if row else NOT_REPORTED)
        candidate["provenance"] = row["provenance"] if row else NOT_REPORTED
    # Gold remains a paper candidate even before its first canonical summary.
    gold.update(enabled=False, shadow_only=True, provenance="paper", engine=None,
                promotion_verdict=NOT_REPORTED, live_profit_cents=NOT_REPORTED,
                reason="collecting paper outcomes")
    # Engine IDs are identities: omit refused candidates rather than renaming
    # them. Filter before flattening evidence so no orphan rows reach the wire.
    rows = []
    for key in sorted(candidates):
        try:
            validate_engine_lab(key, kind="engine_id")
        except EngineLabValidationError:
            redactions[0] += 1
            continue
        rows.append(candidates[key])
    redactions[0] += len(input_failures)
    if redactions[0]:
        # The schema has no counter field; its existing problems list accepts text.
        problems.append(f"{OMISSION_PREFIX}{redactions[0]}")
    return {"schema_version": SCHEMA_VERSION,
            "generated_at": _stamp(now or datetime.now(timezone.utc).isoformat()),
            "candidates": rows, "evidence": [row for c in rows for row in c["evidence"]],
            "live_profit_cents": NOT_REPORTED,
            "problems": [_text(problem) for problem in problems], "missing_value": NOT_REPORTED}


build = build_engine_lab
