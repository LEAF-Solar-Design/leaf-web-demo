"""EngineManifest v1: the sidecar that says what an engine is, why it exists and what it asks for.

The manifest sits beside the engine JSON at `<manifests_dir>/<engine_id>.json` and is never a
second executable authority: the policy JSON stays authoritative for policy engines, and every
risk figure here is a REQUEST the host can only lower (the host takes the minimum). Contract:
plan D2, contracts/C4.md.

Hardening contract: every reader is bounded (16 KiB), strict (unknown key, duplicate key, JSON
float, NaN, bad decimal and missing thesis all refuse with a named `ManifestInvalid.code`) and
fails closed. `to_lane_document` is pure, performs no I/O, and its output loads through
`leafhft.lanes.document._document_from_mapping`.
"""
from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping
from dataclasses import dataclass, fields
from decimal import ROUND_DOWN, Decimal
from pathlib import Path

from .broker.kalshi_authority import LaneCaps
from .broker.kalshi_book import KalshiLimits
from .engine_feeds import FEEDS, book_feeds, feeds_live_provisioned
from .feeds.kalshi import SYMBOL_MAP
from .lanes.base import MAX_HISTORY, _decimal, _freeze, _plain, canonical_json
from .policy import HARD_MAXIMA

MANIFEST_SCHEMA = 1
MANIFEST_SCHEMA_V2 = 2
MANIFEST_SCHEMAS = frozenset({1, 2})
LANE_API_VERSIONS = frozenset({1})
MAX_MANIFEST_BYTES = 16384
ENGINE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")
ORIGINS = frozenset({"legacy_import", "tune", "foundry", "marathon", "operator"})
EVIDENCE_KINDS = frozenset({"waiver", "backtest", "replay", "trial", "receipt", "review"})
LANE_MODES = frozenset({"paper", "shadow", "live"})

POLICY_KERNEL_ID = "kalshi_edge"
# kernel_id -> (entry module, entry attr). The policy kernel is C2's adapter; lane kernels are the
# allow-listed code lanes. Resolution and allow-listing stay with lanes/registry.py.
KERNEL_ENTRIES = {
    POLICY_KERNEL_ID: ("leafhft.lanes.kalshi_edge_entry", "KalshiEdgeEntry"),
    "darkhorse": ("leafhft.lanes.darkhorse", "DarkHorseEntry"),
    "dip_recovery": ("leafhft.lanes.dip_recovery", "DipRecoveryEntry"),
    "ladder_select": ("leafhft.lanes.ladder_select", "LadderSelectEntry"),
}
LANE_KERNEL_IDS = frozenset(KERNEL_ENTRIES) - {POLICY_KERNEL_ID}

# Host defaults for to_lane_document when the caller supplies no limits: the probe envelope
# (wave-A.md PROBE_LIMITS; C7b recomputes max_cumulative_loss_cents from the engine breaker).
DEFAULT_LANE_LIMITS = KalshiLimits(max_loss_per_order_cents=105, max_cluster_exposure_cents=210,
                                   max_cumulative_loss_cents=210, max_open_tickets=8)
DEFAULT_FRESHNESS = {"max_event_gap_ns": 5_000_000_000, "max_index_age_ns": 2_500_000_000}

_TOP_KEYS = ("schema", "identity", "provenance", "thesis", "kernel", "inputs", "hot_keys",
             "risk_request", "evidence", "digest")
_THESIS_KEYS = ("summary", "novelty", "kill_criterion", "expected_edge_cents")
_LIMIT_FIELDS = tuple(f.name for f in fields(KalshiLimits) if f.name != "risk_policy")
_CAP_FIELDS = tuple(f.name for f in fields(LaneCaps))
_HEX64 = re.compile(r"[0-9a-f]{64}")
_CODE_SHA = re.compile(r"[0-9a-f]{7,64}")
_NAME = re.compile(r"[a-z_][a-z0-9_]{0,63}")
_MAX_TEXT = 500
_MAX_PARAMS = 32
_MAX_PARAM_BYTES = 4096
_MAX_HOT_KEYS = 16
_MAX_EVIDENCE = 32
_MAX_MODELS = 4

# Every ManifestInvalid.code this module raises; the reason table sentence is "manifest_invalid"
# except for feeds_not_live, which has its own sentence.
MANIFEST_INVALID_CODES = frozenset({
    "unreadable", "oversize", "json_invalid", "duplicate_key", "unknown_key", "missing_key",
    "bad_decimal", "schema_invalid", "filename_mismatch", "digest_mismatch", "engine_id_invalid",
    "identity_invalid", "provenance_invalid", "thesis_missing", "thesis_invalid",
    "kernel_invalid", "kernel_unknown", "symbols_invalid", "feed_unknown", "feeds_invalid",
    "history_rows_invalid", "models_invalid", "hot_keys_invalid", "fraction_above_maximum",
    "risk_request_invalid", "evidence_invalid", "evidence_missing", "waiver_missing",
    "legacy_engine_invalid", "lane_request_invalid", "hot_value_missing", "feeds_not_live",
    "contract_invalid", "feed_unpinned", "kernel_pin_mismatch",
    "feed_pin_unavailable", "feed_pin_mismatch",
})


class ManifestInvalid(ValueError):
    """A manifest (or a lane request built from one) is refused; `code` names the rule."""

    def __init__(self, code: str, detail: str = ""):
        self.code = code
        self.detail = detail
        self.reason = "feeds_not_live" if code == "feeds_not_live" else "manifest_invalid"
        super().__init__(f"manifest_invalid: {code}" + (f": {detail}" if detail else ""))


@dataclass(frozen=True)
class EngineManifest:
    schema: int
    identity: Mapping
    provenance: Mapping
    thesis: Mapping
    kernel: Mapping
    inputs: Mapping
    hot_keys: tuple
    risk_request: Mapping
    evidence: tuple
    digest: str

    @property
    def engine_id(self) -> str:
        return self.identity["engine_id"]

    def to_mapping(self) -> dict:
        return {name: _plain(getattr(self, name)) for name in _TOP_KEYS}


# ---------------------------------------------------------------- parsing (bounded, strict)

def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ManifestInvalid("duplicate_key", key)
        result[key] = value
    return result


def _refuse_float(value):
    raise ManifestInvalid("bad_decimal", f"JSON number {value} must be a decimal string")


def _parse(payload: bytes):
    if len(payload) > MAX_MANIFEST_BYTES:
        raise ManifestInvalid("oversize", f"exceeds {MAX_MANIFEST_BYTES} bytes")
    try:
        return json.loads(payload.decode("utf-8"), object_pairs_hook=_pairs,
                          parse_float=_refuse_float, parse_constant=_refuse_float)
    except ManifestInvalid:
        raise
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ManifestInvalid("json_invalid", str(exc)[:200]) from exc


def _read(path) -> object:
    try:
        with Path(path).open("rb") as stream:
            payload = stream.read(MAX_MANIFEST_BYTES + 1)
    except OSError as exc:
        raise ManifestInvalid("unreadable", f"{path}: {exc}") from exc
    return _parse(payload)


# ---------------------------------------------------------------- field validators

def _object(value, keys, name):
    if not isinstance(value, Mapping):
        raise ManifestInvalid("schema_invalid", f"{name}: expected an object")
    unknown = sorted(set(value) - set(keys))
    if unknown:
        raise ManifestInvalid("unknown_key", f"{name}: {unknown}")
    missing = sorted(set(keys) - set(value))
    if missing:
        raise ManifestInvalid("missing_key", f"{name}: {missing}")
    return value


def _text(value, code, name, maximum=_MAX_TEXT, minimum=1):
    if (type(value) is not str or not minimum <= len(value) <= maximum
            or (value and not value.isprintable())):
        raise ManifestInvalid(code, f"{name}: expected {minimum}..{maximum} printable characters")
    return value


def _int(value, code, name, minimum, maximum):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ManifestInvalid(code, f"{name}: expected an integer in {minimum}..{maximum}")
    return value


def _dec(value, name, minimum, maximum) -> Decimal:
    try:
        return _decimal(value, name, Decimal(minimum), Decimal(maximum), string_only=True)
    except ValueError as exc:
        raise ManifestInvalid("bad_decimal", str(exc)) from exc


def _engine_id(value, code="engine_id_invalid", name="identity.engine_id"):
    if type(value) is not str or not ENGINE_ID_RE.fullmatch(value):
        raise ManifestInvalid(code, f"{name}: must match {ENGINE_ID_RE.pattern}")
    return value


def _list(value, code, name, maximum, minimum=0):
    if type(value) is not list or not minimum <= len(value) <= maximum:
        raise ManifestInvalid(code, f"{name}: expected a list of {minimum}..{maximum} items")
    return value


def _check_identity(identity):
    _object(identity, ("engine_id", "version", "parent"), "identity")
    _engine_id(identity["engine_id"])
    _int(identity["version"], "identity_invalid", "identity.version", 1, 10**6)
    parent = identity["parent"]
    if parent is not None:
        _engine_id(parent, "identity_invalid", "identity.parent")
        if parent == identity["engine_id"]:
            raise ManifestInvalid("identity_invalid", "identity.parent: an engine is not its own parent")


def _check_provenance(provenance):
    _object(provenance, ("origin", "source_ref", "code_sha"), "provenance")
    if provenance["origin"] not in ORIGINS:
        raise ManifestInvalid("provenance_invalid", f"provenance.origin: one of {sorted(ORIGINS)}")
    _text(provenance["source_ref"], "provenance_invalid", "provenance.source_ref", 256)
    code_sha = provenance["code_sha"]
    if code_sha is not None and (type(code_sha) is not str or not _CODE_SHA.fullmatch(code_sha)):
        raise ManifestInvalid("provenance_invalid", "provenance.code_sha: 7..64 lowercase hex or null")


def _check_thesis(thesis):
    if not isinstance(thesis, Mapping):
        raise ManifestInvalid("thesis_missing", "thesis: expected an object")
    unknown = sorted(set(thesis) - set(_THESIS_KEYS))
    if unknown:
        raise ManifestInvalid("unknown_key", f"thesis: {unknown}")
    for key in _THESIS_KEYS:
        value = thesis.get(key)
        if type(value) is not str or not value.strip():
            raise ManifestInvalid("thesis_missing", f"thesis.{key}: required and non-empty")
    for key in _THESIS_KEYS[:3]:
        _text(thesis[key], "thesis_invalid", "thesis." + key)
    _dec(thesis["expected_edge_cents"], "thesis.expected_edge_cents", "0", "99.99")


def _check_params(params):
    if not isinstance(params, Mapping) or len(params) > _MAX_PARAMS:
        raise ManifestInvalid("kernel_invalid", f"kernel.params: object of at most {_MAX_PARAMS} keys")
    for key, value in params.items():
        if type(key) is not str or not _NAME.fullmatch(key):
            raise ManifestInvalid("kernel_invalid", f"kernel.params: invalid key {key!r}")
        if type(value) is float:
            _refuse_float(value)
        if type(value) is str:
            _text(value, "kernel_invalid", "kernel.params." + key, 4096, 0)
        elif type(value) is int:
            _int(value, "kernel_invalid", "kernel.params." + key, -10**12, 10**12)
        elif type(value) is not bool:
            raise ManifestInvalid("kernel_invalid", f"kernel.params.{key}: str, int or bool only")
    try:
        size = len(canonical_json(params))
    except ValueError as exc:
        raise ManifestInvalid("kernel_invalid", "kernel.params: not canonical JSON") from exc
    if size > _MAX_PARAM_BYTES:
        raise ManifestInvalid("kernel_invalid", f"kernel.params: exceeds {_MAX_PARAM_BYTES} bytes")


def _check_kernel(kernel, schema=MANIFEST_SCHEMA):
    if not isinstance(kernel, Mapping) or kernel.get("kind") not in ("policy", "lane"):
        raise ManifestInvalid("kernel_invalid", "kernel.kind: policy or lane")
    extra = ("contract",) if schema == MANIFEST_SCHEMA_V2 else ()
    if extra:
        from .lanes import flags

        if "contract" not in kernel:
            raise ManifestInvalid("missing_key", "kernel.contract")
        contract = kernel["contract"]
        if (not isinstance(contract, Mapping) or set(contract) != {"lane_api", "signal"}
                or type(contract["lane_api"]) is not int
                or contract["lane_api"] not in LANE_API_VERSIONS
                or (contract["signal"] is not None and (
                    type(contract["signal"]) is not int
                    or contract["signal"] != flags.FLAG_CONTRACT_VERSION))):
            raise ManifestInvalid("contract_invalid", "kernel.contract")
    if kernel["kind"] == "policy":
        _object(kernel, ("kind", "kernel_id", "policy_engine_id", "policy_digest") + extra, "kernel")
        if kernel["kernel_id"] != POLICY_KERNEL_ID:
            raise ManifestInvalid("kernel_invalid", f"kernel.kernel_id: policy kernels are {POLICY_KERNEL_ID}")
        _engine_id(kernel["policy_engine_id"], "kernel_invalid", "kernel.policy_engine_id")
        if type(kernel["policy_digest"]) is not str or not _HEX64.fullmatch(kernel["policy_digest"]):
            raise ManifestInvalid("kernel_invalid", "kernel.policy_digest: 64 lowercase hex")
        return
    _object(kernel, ("kind", "kernel_id", "module_sha256", "params") + extra, "kernel")
    if type(kernel["kernel_id"]) is not str or kernel["kernel_id"] not in LANE_KERNEL_IDS:
        raise ManifestInvalid("kernel_unknown", f"kernel.kernel_id: one of {sorted(LANE_KERNEL_IDS)}")
    if type(kernel["module_sha256"]) is not str or not _HEX64.fullmatch(kernel["module_sha256"]):
        raise ManifestInvalid("kernel_invalid", "kernel.module_sha256: 64 lowercase hex")
    _check_params(kernel["params"])
    if schema == MANIFEST_SCHEMA_V2:
        from .lanes import kernels

        pin = kernels.pin_for_module(KERNEL_ENTRIES[kernel["kernel_id"]][0])
        if pin is None or kernel["module_sha256"] != pin.sha256:
            raise ManifestInvalid("kernel_pin_mismatch", kernel["kernel_id"])


def _check_models(models):
    _list(models, "models_invalid", "inputs.models", _MAX_MODELS)
    seen = set()
    for model in models:
        if not isinstance(model, Mapping) or set(model) != {"path", "sha256"}:
            raise ManifestInvalid("models_invalid", "inputs.models item: exactly path and sha256")
        path = model["path"]
        # The same lexical rule as the lane document; model bytes are never read here.
        if (type(path) is not str or not 1 <= len(path) <= 4096 or "\x00" in path
                or not Path(path).is_absolute()):
            raise ManifestInvalid("models_invalid", "inputs.models.path: absolute path expected")
        if path in seen:
            raise ManifestInvalid("models_invalid", "inputs.models: duplicate path")
        seen.add(path)
        if type(model["sha256"]) is not str or not re.fullmatch(r"[0-9a-fA-F]{64}", model["sha256"]):
            raise ManifestInvalid("models_invalid", "inputs.models.sha256: 64 hex characters")


def _check_inputs(inputs, schema=MANIFEST_SCHEMA):
    _object(inputs, ("symbols", "feeds", "history_rows", "models"), "inputs")
    symbols = _list(inputs["symbols"], "symbols_invalid", "inputs.symbols", len(SYMBOL_MAP), 1)
    if (any(type(symbol) is not str or symbol not in SYMBOL_MAP for symbol in symbols)
            or len(set(symbols)) != len(symbols)):
        raise ManifestInvalid("symbols_invalid", "inputs.symbols: distinct SYMBOL_MAP symbols")
    feeds = _list(inputs["feeds"], "feeds_invalid", "inputs.feeds", len(FEEDS) + 16,
                  1 if schema == MANIFEST_SCHEMA_V2 else 0)
    if schema == MANIFEST_SCHEMA_V2:
        ids = []
        for item in feeds:
            if not isinstance(item, Mapping) or set(item) != {"feed_id", "pin_digest"}:
                raise ManifestInvalid("feeds_invalid", "inputs.feeds: exactly feed_id and pin_digest")
            feed = item["feed_id"]
            if type(feed) is not str or feed not in FEEDS:
                raise ManifestInvalid("feed_unknown", repr(feed))
            if item["pin_digest"] == "unpinned":
                raise ManifestInvalid("feed_unpinned", feed)
            if (type(item["pin_digest"]) is not str
                    or not re.fullmatch(r"sha256:[0-9a-f]{64}", item["pin_digest"])):
                raise ManifestInvalid("feeds_invalid", feed)
            ids.append(feed)
        feeds = ids
    for feed in feeds:
        if type(feed) is not str:
            raise ManifestInvalid("feeds_invalid", "inputs.feeds: strings only")
        if feed not in FEEDS:
            raise ManifestInvalid("feed_unknown", f"inputs.feeds: {feed[:64]!r} is not in the FEEDS table")
    if len(set(feeds)) != len(feeds):
        raise ManifestInvalid("feeds_invalid", "inputs.feeds: duplicate feed")
    _int(inputs["history_rows"], "history_rows_invalid", "inputs.history_rows", 0, MAX_HISTORY)
    _check_models(inputs["models"])


def _check_hot_keys(hot_keys, kernel):
    _list(hot_keys, "hot_keys_invalid", "hot_keys", _MAX_HOT_KEYS)
    if (any(type(key) is not str or not _NAME.fullmatch(key) for key in hot_keys)
            or len(set(hot_keys)) != len(hot_keys)):
        raise ManifestInvalid("hot_keys_invalid", "hot_keys: distinct lowercase names")
    if kernel["kind"] == "policy" and hot_keys:
        raise ManifestInvalid("hot_keys_invalid", "hot_keys: the policy kernel has no hot keys")


def _check_risk_request(request):
    _object(request, ("fractions", "caps", "limits"), "risk_request")
    fractions, caps, limits = request["fractions"], request["caps"], request["limits"]
    for name, value, allowed in (("fractions", fractions, HARD_MAXIMA),
                                 ("caps", caps, _CAP_FIELDS), ("limits", limits, _LIMIT_FIELDS)):
        if not isinstance(value, Mapping):
            raise ManifestInvalid("risk_request_invalid", f"risk_request.{name}: expected an object")
        unknown = sorted(set(value) - set(allowed))
        if unknown:
            raise ManifestInvalid("unknown_key", f"risk_request.{name}: {unknown}")
    for key, value in fractions.items():
        number = _dec(value, "risk_request.fractions." + key, "0", "1")
        if number > Decimal(repr(HARD_MAXIMA[key])):
            raise ManifestInvalid("fraction_above_maximum",
                                  f"risk_request.fractions.{key}: {value} exceeds {HARD_MAXIMA[key]}")
    for key, value in caps.items():
        low, high = {"daily_loss_bp": (0, 5000), "loss_window_hours": (1, 168)}.get(key, (0, 10**7))
        _int(value, "risk_request_invalid", "risk_request.caps." + key, low, high)
    for key, value in limits.items():
        low, high = (1, 1000) if key == "max_open_tickets" else (0 if key == "cash_floor_cents" else 1, 10**7)
        _int(value, "risk_request_invalid", "risk_request.limits." + key, low, high)


def _check_evidence(evidence, origin):
    _list(evidence, "evidence_invalid", "evidence", _MAX_EVIDENCE)
    for item in evidence:
        if not isinstance(item, Mapping) or set(item) != {"kind", "ref", "detail"}:
            raise ManifestInvalid("evidence_invalid", "evidence item: exactly kind, ref and detail")
        if item["kind"] not in EVIDENCE_KINDS:
            raise ManifestInvalid("evidence_invalid", f"evidence.kind: one of {sorted(EVIDENCE_KINDS)}")
        _text(item["ref"], "evidence_invalid", "evidence.ref", 256)
        _text(item["detail"], "evidence_invalid", "evidence.detail", _MAX_TEXT, 0)
    if not evidence:
        raise ManifestInvalid("evidence_missing", "evidence: at least one item (legacy imports carry a waiver)")
    if origin == "legacy_import" and not any(
            item["kind"] == "waiver" and item["detail"].strip() for item in evidence):
        raise ManifestInvalid("waiver_missing", "evidence: a legacy import needs a waiver with a reason")


def _body_digest(body: Mapping) -> str:
    return hashlib.sha256(canonical_json({key: body[key] for key in body if key != "digest"})).hexdigest()


def manifest_from_mapping(raw, *, expected_engine_id: str | None = None) -> EngineManifest:
    """Validate a parsed manifest and verify its digest; the only constructor of EngineManifest."""
    if not isinstance(raw, Mapping):
        raise ManifestInvalid("schema_invalid", "manifest: expected an object")
    unknown = sorted(set(raw) - set(_TOP_KEYS))
    if unknown:
        raise ManifestInvalid("unknown_key", f"manifest: {unknown}")
    if "thesis" not in raw:
        raise ManifestInvalid("thesis_missing", "thesis: required")
    _object(raw, _TOP_KEYS, "manifest")
    if type(raw["schema"]) is not int or raw["schema"] not in MANIFEST_SCHEMAS:
        raise ManifestInvalid("schema_invalid", f"schema: expected {MANIFEST_SCHEMA}")
    _check_identity(raw["identity"])
    if expected_engine_id is not None and raw["identity"]["engine_id"] != expected_engine_id:
        raise ManifestInvalid("filename_mismatch", "identity.engine_id does not match the file name")
    _check_provenance(raw["provenance"])
    _check_thesis(raw["thesis"])
    _check_kernel(raw["kernel"], raw["schema"])
    _check_inputs(raw["inputs"], raw["schema"])
    _check_hot_keys(raw["hot_keys"], raw["kernel"])
    _check_risk_request(raw["risk_request"])
    _check_evidence(raw["evidence"], raw["provenance"]["origin"])
    if type(raw["digest"]) is not str or not _HEX64.fullmatch(raw["digest"]):
        raise ManifestInvalid("digest_mismatch", "digest: 64 lowercase hex")
    try:
        body_size = len(canonical_json(raw))
        computed = _body_digest(raw)
    except ValueError as exc:
        raise ManifestInvalid("schema_invalid", "manifest: not canonical JSON") from exc
    if body_size > MAX_MANIFEST_BYTES:
        raise ManifestInvalid("oversize", f"exceeds {MAX_MANIFEST_BYTES} bytes")
    if computed != raw["digest"]:
        raise ManifestInvalid("digest_mismatch", "digest does not match the manifest body")
    frozen = {key: _freeze(raw[key]) for key in _TOP_KEYS}
    return EngineManifest(**frozen)


def build_manifest(body: Mapping) -> EngineManifest:
    """Stamp the digest on a body (any existing digest is replaced) and validate it strictly."""
    if not isinstance(body, Mapping):
        raise ManifestInvalid("schema_invalid", "manifest: expected an object")
    unsigned = {key: value for key, value in body.items() if key != "digest"}
    try:
        # Round trip through canonical bytes so Python-built bodies meet the file reader's rules.
        raw = _parse(canonical_json(unsigned))
    except ValueError as exc:
        if isinstance(exc, ManifestInvalid):
            raise
        raise ManifestInvalid("schema_invalid", str(exc)) from exc
    if isinstance(raw, dict):
        try:
            raw["digest"] = _body_digest(raw)
        except (ValueError, TypeError) as exc:
            raise ManifestInvalid("schema_invalid", "manifest: not canonical JSON") from exc
    return manifest_from_mapping(raw)


def manifest_bytes(manifest: EngineManifest) -> bytes:
    """Canonical file bytes for a validated manifest."""
    return canonical_json(manifest.to_mapping(), MAX_MANIFEST_BYTES)


def load_manifest(path) -> EngineManifest:
    """Read at most 16385 bytes from `<manifests_dir>/<engine_id>.json` and validate strictly."""
    return manifest_from_mapping(_read(path), expected_engine_id=Path(path).stem)


def manifest_digest(manifest) -> str:
    """sha256 of the canonical manifest without its digest; binds lifecycle, receipts and trials."""
    body = manifest.to_mapping() if isinstance(manifest, EngineManifest) else _plain(manifest)
    return _body_digest(body)


def feed_ids(manifest) -> list[str]:
    """Declared feed ids in manifest order, for either schema."""
    body = manifest.to_mapping() if isinstance(manifest, EngineManifest) else manifest
    return [item["feed_id"] if body["schema"] == MANIFEST_SCHEMA_V2 else item
            for item in body["inputs"]["feeds"]]


def feed_pins(manifest) -> dict[str, str]:
    """Declared feed pins; schema 1 has none."""
    body = manifest.to_mapping() if isinstance(manifest, EngineManifest) else manifest
    return ({item["feed_id"]: item["pin_digest"] for item in body["inputs"]["feeds"]}
            if body["schema"] == MANIFEST_SCHEMA_V2 else {})


def identity_digest(manifest) -> str:
    """sha256{kernel_id, params, policy_digest}: equal for clones under another id or account."""
    kernel = manifest.kernel if isinstance(manifest, EngineManifest) else manifest["kernel"]
    payload = {"kernel_id": kernel["kernel_id"], "params": _plain(kernel.get("params", {})),
               "policy_digest": kernel.get("policy_digest")}
    return hashlib.sha256(canonical_json(payload)).hexdigest()


# ---------------------------------------------------------------- legacy import

def _one_line(value: str, maximum: int = _MAX_TEXT) -> str:
    return " ".join("".join(ch if ch.isprintable() else " " for ch in value).split())[:maximum]


def _cents(value: float, places: str = "0.01") -> str:
    return str(Decimal(repr(float(value))).quantize(Decimal(places), rounding=ROUND_DOWN))


def import_legacy(engine_json_path, *, waiver_reason: str, symbols=None) -> EngineManifest:
    """Wrap an existing engine JSON (read through engines.EngineRegistry) as origin legacy_import.

    The engine had no thesis or evidence when it was built, so the manifest carries a waiver with
    the given reason. `symbols` defaults to every SYMBOL_MAP symbol; the registry narrows it.
    """
    from .engines import EngineError, EngineRegistry
    from .policy import policy_digest

    if type(waiver_reason) is not str or not _one_line(waiver_reason):
        raise ManifestInvalid("waiver_missing", "waiver_reason: required and non-empty")
    path = Path(engine_json_path)
    try:
        engine = EngineRegistry(path.parent).get(path.stem)
    except EngineError as exc:
        raise ManifestInvalid("legacy_engine_invalid", str(exc)[:300]) from exc
    policy = engine.policy
    chosen = sorted(SYMBOL_MAP) if symbols is None else list(symbols)
    body = {
        "schema": MANIFEST_SCHEMA,
        "identity": {"engine_id": engine.engine_id, "version": engine.version,
                     "parent": engine.parent_engine_id},
        "provenance": {"origin": "legacy_import", "source_ref": f"engines/{path.name}@v{engine.version}",
                       "code_sha": None},
        "thesis": {
            "summary": _one_line(engine.description) or _one_line(engine.name),
            "novelty": "Imported from the legacy engine catalog; novelty was not recorded before manifests existed.",
            "kill_criterion": "Three daily loss breaker trips in seven UTC days halt the engine for review.",
            "expected_edge_cents": _cents(policy.edge_threshold_cents),
        },
        "kernel": {"kind": "policy", "kernel_id": POLICY_KERNEL_ID,
                   "policy_engine_id": engine.engine_id, "policy_digest": policy_digest(policy)},
        "inputs": {"symbols": chosen, "feeds": book_feeds(chosen), "history_rows": 0, "models": []},
        "hot_keys": [],
        "risk_request": {
            "fractions": {key: _cents(min(getattr(policy, key), maximum))
                          for key, maximum in HARD_MAXIMA.items()},
            "caps": {}, "limits": {},
        },
        "evidence": [{"kind": "waiver", "ref": "legacy_import", "detail": _one_line(waiver_reason)}],
    }
    return build_manifest(body)


# ---------------------------------------------------------------- lane document generation

def cid_prefix(engine_id: str) -> str:
    """`lh-<sha6(engine_id)>-`, the lane document's client id prefix."""
    return f"lh-{hashlib.sha256(_engine_id(engine_id).encode('utf-8')).hexdigest()[:6]}-"


def _host_caps(caps) -> dict:
    if caps is None:
        return {}
    if isinstance(caps, LaneCaps):
        return {f.name: getattr(caps, f.name) for f in fields(LaneCaps)}
    if isinstance(caps, Mapping) and set(caps) <= set(_CAP_FIELDS):
        return dict(caps)
    raise ManifestInvalid("lane_request_invalid", "caps: LaneCaps, a LaneCaps mapping, or None")


def _minimum(*values):
    present = [value for value in values if value is not None]
    return min(present) if present else None


def to_lane_document(manifest: EngineManifest, mode: str, symbols, caps, pilot, *,
                     limits: KalshiLimits | None = None, hot: Mapping | None = None,
                     live_pins: Mapping[str, str] | None = None) -> dict:
    """Pure: build the values-only lane document for this engine; no I/O, no host authority.

    Lane id = engine_id. Caps and limits are the elementwise minimum of the host's values and the
    manifest's requests (cash floor: the maximum), so a manifest can only tighten. Hot values start
    disarmed: `armed` defaults to False and every other hot key must be supplied in `hot`. The lane
    document carries no symbol list; `symbols` is checked against the manifest so no document is
    produced for a symbol the engine did not declare. A live document needs every feed live.
    """
    if not isinstance(manifest, EngineManifest):
        raise ManifestInvalid("lane_request_invalid", "manifest: expected an EngineManifest")
    engine_id = manifest.engine_id
    if manifest.schema == MANIFEST_SCHEMA_V2:
        for feed, digest in feed_pins(manifest).items():
            if not isinstance(live_pins, Mapping) or feed not in live_pins:
                raise ManifestInvalid("feed_pin_unavailable", feed)
            if live_pins[feed] != digest:
                raise ManifestInvalid("feed_pin_mismatch", feed)
    if type(mode) is not str or mode not in LANE_MODES:
        raise ManifestInvalid("lane_request_invalid", f"mode: one of {sorted(LANE_MODES)}")
    if isinstance(symbols, str):
        raise ManifestInvalid("symbols_invalid", "symbols: expected a list, not a string")
    chosen = list(symbols)
    declared = set(manifest.inputs["symbols"])
    if not chosen or len(set(chosen)) != len(chosen) or not set(chosen) <= declared:
        raise ManifestInvalid("symbols_invalid", "symbols: distinct symbols the manifest declares")
    if mode != "live" and pilot is not None:
        raise ManifestInvalid("lane_request_invalid", f"{mode} lanes require pilot=None")
    if mode == "live":
        not_live = feeds_live_provisioned(manifest)
        if not_live:
            raise ManifestInvalid("feeds_not_live", ", ".join(not_live))

    host = _host_caps(caps)
    requested = manifest.risk_request["caps"]
    merged_caps = {}
    for name in _CAP_FIELDS:
        value = _minimum(host.get(name), requested.get(name))
        if value is not None:
            merged_caps[name] = value

    base = DEFAULT_LANE_LIMITS if limits is None else limits
    if not isinstance(base, KalshiLimits):
        raise ManifestInvalid("lane_request_invalid", "limits: expected KalshiLimits")
    asked = manifest.risk_request["limits"]
    merged_limits = {}
    for name in _LIMIT_FIELDS:
        if name == "cash_floor_cents":
            merged_limits[name] = max(getattr(base, name), asked.get(name, 0))
        else:
            merged_limits[name] = _minimum(getattr(base, name), asked.get(name))
    try:
        KalshiLimits(**merged_limits)
    except (TypeError, ValueError) as exc:
        raise ManifestInvalid("risk_request_invalid", f"limits: {exc}") from exc

    supplied = {} if hot is None else dict(hot)
    hot_keys = tuple(manifest.hot_keys)
    if not set(supplied) <= set(hot_keys):
        raise ManifestInvalid("hot_keys_invalid", f"hot: keys outside hot_keys {sorted(set(supplied) - set(hot_keys))}")
    hot_values = {}
    for key in hot_keys:
        if key in supplied:
            value = supplied[key]
        elif key == "armed":
            value = False
        else:
            raise ManifestInvalid("hot_value_missing", f"hot.{key}: no initial value supplied")
        if key == "armed" and type(value) is not bool:
            raise ManifestInvalid("hot_keys_invalid", "hot.armed: must be a bool")
        if type(value) not in (bool, int, str):
            raise ManifestInvalid("hot_keys_invalid", f"hot.{key}: bool, int or decimal string only")
        hot_values[key] = value

    kernel = manifest.kernel
    module, attr = KERNEL_ENTRIES[kernel["kernel_id"]]
    if kernel["kind"] == "policy":
        params = {"policy_engine_id": kernel["policy_engine_id"], "policy_digest": kernel["policy_digest"]}
    else:
        params = _plain(kernel["params"])

    document = {
        "version": manifest.schema,
        "id": engine_id,
        "mode": mode,
        "entry": {"module": module, "attr": attr, "params": params},
        "hot": hot_values,
        "caps": merged_caps,
        "limits": merged_limits,
        "pilot": None if pilot is None else _plain(pilot),
        "paths": {"ledger_name": f"kalshi-lane-{engine_id}-tickets.jsonl",
                  "journal_dir_name": engine_id, "cid_prefix": cid_prefix(engine_id)},
        "freshness": dict(DEFAULT_FRESHNESS),
        "models": [dict(model) for model in manifest.inputs["models"]],
    }
    if manifest.schema == MANIFEST_SCHEMA_V2:
        from .lanes import flags, kernels

        pin = kernels.pin_for_module(module)
        if pin is None:
            raise ManifestInvalid("kernel_pin_mismatch", module)
        document["pins"] = {
            "flag": flags.flag_pin() if kernel["contract"]["signal"] is not None else None,
            "feeds": _plain(manifest.inputs["feeds"]),
            "kernel_sha256": pin.sha256,
        }
    return document
