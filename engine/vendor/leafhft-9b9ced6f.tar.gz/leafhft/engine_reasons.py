"""Plain sentences for every engine refusal, lifecycle and integrity reason code.

Codes are the machine contract (wave-A.md "Reason codes"); the sentence is what a person reads
on the dashboard or the phone. One sentence per code, ending with a period, no dashes and no
fixed dollar amounts: every loss limit is a percentage of the day start portfolio (plan D5a).
`text()` never raises, so a renderer can pass any value it was handed.
"""
from __future__ import annotations

_REASONS = {
    # executor.REFUSAL_CODES (C5a), in contract order.
    "engine_disagreement": "Another engine already holds the opposite side of this market, so this entry was skipped.",
    "engine_position_exists": "This engine already has a position in this market, so it will not add a second one.",
    "ticker_owned": "Another lane already owns this market, so this engine stayed out.",
    "ticker_pending": "An order from another process is still waiting on this market, so this entry was held back.",
    "ticker_unknown": "An order from another process on this market has an unknown outcome, so this entry was held back.",
    "incumbent_undecided": "The main engine on this book has not made its call on this market yet, so the probe waited.",
    "probe_code_collision": "Two probe engines on this host share the same short code, so the second one was not started.",
    "lifecycle": "The engine's lifecycle state does not allow new entries right now.",
    "breaker_engine": "This engine reached its daily loss limit, so new entries are paused until midnight UTC.",
    "breaker_account": "The account reached its daily loss limit, so new entries are paused until midnight UTC.",
    "registry_gate": "The engine registry does not assign this engine to this account and symbol, so it cannot trade here.",
    "exposure_authority": "This account is not the one allowed to hold exposure for this Kalshi member, so the entry was refused.",
    "cash": "There is not enough free cash to cover this order.",
    "floor": "This order would take cash below the protected floor, so it was refused.",
    "exposure_ledger_busy": "The exposure ledger was busy for a moment, so this one entry was skipped and the engine keeps running.",
    # Lifecycle states (C0 canary.py).
    "lifecycle_suspended": "New entries are paused until midnight UTC after a daily loss limit was reached.",
    "lifecycle_halted": "The engine is halted and takes no new entries until an operator reviews it.",
    "lifecycle_retired": "The engine is retired and will not trade again.",
    "lifecycle_not_entry_state": "The engine is in a state that does not place new entries.",
    # Integrity halts (C0 canary.py).
    "risk_invariant": "A risk check found numbers that do not add up, so the engine was halted for review.",
    "attribution_gap": "A trade could not be tied back to the engine that made it, so the engine was halted for review.",
    "data_integrity_failure": "The engine's records failed an integrity check, so it was halted for review.",
    "policy_changed": "The engine's settings changed while it was running, so it was halted until they are approved again.",
    "account_attribution_gap": "An account trade could not be tied back to any engine, so the engine was halted for review.",
    "kill_criterion": "The engine hit its loss limit three times in seven days, so it was halted for review.",
    "day_start_unknown": "The day's starting portfolio value is not known yet, so new entries wait until it is recorded.",
    # Kernel, manifest and registry refusals (C2, C4, C1).
    "policy_feature_refused": "This engine uses a setting that probe trading does not allow, so it was refused.",
    "manifest_invalid": "The engine's manifest failed validation, so the engine cannot be loaded.",
    "feeds_not_live": "The engine needs a data feed that is not live on this host yet.",
    "identity_clone": "This engine is a copy of an engine that already exists under another name, so it was refused.",
    "engine_assigned_elsewhere": "This engine is already assigned to a different account.",
    "domain_not_exposure_authority": "This account cannot hold exposure for its Kalshi member, so probes and graduated engines are not allowed on it.",
}

REASONS: dict[str, str] = _REASONS

# Build path codes (plan Part II B10, slice M0), keyed to RAISE SITES. Kept apart from _REASONS so
# C4's table stays exactly the engine refusal contract; text() reads both tables. Each code carries
# the sentence a person reads and the one `next` action. docs/ENGINE-BUILD-THREAT-MODEL.md holds the
# threat model and a raise site table that must equal BUILD_RAISE_SITES (tests/test_engine_reasons.py).

# The classes the build queue persists as `failure_class` on a failed item (B10); every class has a
# `build.failure_class_<class>` code below.
BUILD_FAILURE_CLASSES: tuple[str, ...] = (
    "budget", "timeout", "credential", "oracle", "conform", "seal_mismatch", "promotion",
    "infrastructure", "lease_lost", "status_unreadable",
)

_BUILD = {
    # Admission, consent and control (ops-dashboard BuildRecord, slices A2, M1, M4).
    "build.owner_only": (
        "Only the owner account can start or approve an engine build, so this request was refused.",
        "Send the idea as a build request and the owner approves it on the web dashboard."),
    "build.kernel_path_unavailable": (
        "Code builds are not open yet, so only dial variants of an existing engine can be built right now.",
        "Ask for a dial variant of an existing engine, or wait until code builds open."),
    "build.quota_exhausted": (
        "This account has used its build allowance for the day or the month, so no new build can start.",
        "Wait for the allowance to reset or ask the owner to raise it."),
    "build.envelope_exhausted": (
        "The project's total build budget is used up or paused, so no new build can start.",
        "Ask the operator to review the project budget before any new build."),
    "build.card_digest_mismatch": (
        "The build details changed after the confirm card was shown, so the approval was refused.",
        "Open the build again and approve the card that is shown now."),
    "build.card_expired": (
        "The confirm card expired before it was approved, so the approval was refused.",
        "Open the build again to get a fresh confirm card and approve that one."),
    "build.duplicate_submission": (
        "This conversation already submitted a build, so a second one was not started.",
        "Check the status of the build that is already running."),
    "build.dispatcher_token_missing": (
        "The build dispatcher has no valid access token, so no build can advance.",
        "The operator sets the dispatcher token and restarts the dispatcher."),
    "build.cancel_requested": (
        "A stop was requested, so the build ends after its current round and spend continues until then.",
        "Check the build status to see when the round ended and what it spent."),
    # Queue failure classes (the persisted failure_class, slices M3a, M3b, M4, M6).
    "build.failure_class_budget": (
        "The build reached its spending cap, so it was stopped.",
        "Review what it produced before approving a new build with a larger cap."),
    "build.failure_class_timeout": (
        "The build ran past its time limit, so it was stopped.",
        "Retry with a smaller idea or ask the owner for a longer limit."),
    "build.failure_class_credential": (
        "The build could not get access to the model service, so it stopped without doing any work.",
        "The operator checks the build's model access and requeues it."),
    "build.failure_class_oracle": (
        "The engine the build produced failed its replay tests, so nothing was promoted.",
        "Read the test report and submit a revised idea."),
    "build.failure_class_conform": (
        "The engine the build produced did not meet the engine standard, so nothing was promoted.",
        "Read the conformance report and submit a revised idea."),
    "build.failure_class_seal_mismatch": (
        "The build's results could not be tied to this request, so they were discarded.",
        "The operator reviews the build record before any retry."),
    "build.failure_class_promotion": (
        "The engine passed its tests but its pull request could not be opened.",
        "The operator retries the promotion from the sealed record."),
    "build.failure_class_infrastructure": (
        "The build service failed before the build finished, so no result was recorded.",
        "Retry the build once the service is healthy again."),
    "build.failure_class_lease_lost": (
        "The worker lost its hold on this build, so it stopped to avoid running twice.",
        "The dispatcher requeues the build from its last saved point."),
    "build.failure_class_status_unreadable": (
        "The build's status could not be read for too long, so the operator was notified.",
        "The operator checks the build and can release its reservation."),
}

BUILD_REASONS: dict[str, str] = {code: pair[0] for code, pair in _BUILD.items()}
BUILD_NEXT: dict[str, str] = {code: pair[1] for code, pair in _BUILD.items()}

# (site, repo, path, call site, code, slice). One row per place a build refusal or failure is raised;
# the future files land in the named slice. Mirrored row for row by the raise site table in the doc.
BUILD_RAISE_SITES: tuple[tuple[str, str, str, str, str, str], ...] = (
    ("assistant.engine_tool", "ops-dashboard", "src/lib/services/kashbot-assistant.ts",
     "engine tool execute() when the server stamped input.role is not owner", "build.owner_only", "A2"),
    ("admin.builds", "ops-dashboard", "src/app/api/kashbot/admin/builds/route.ts",
     "admin build route execute() for a beta admin", "build.owner_only", "M1"),
    ("builds.admit.kernel", "ops-dashboard", "src/lib/services/kashbot-engine-builds.ts",
     "admitBuild() for tier KERNEL before M3a, M3b, M4 and M6 are live", "build.kernel_path_unavailable", "M1"),
    ("builds.admit.quota", "ops-dashboard", "src/lib/services/kashbot-engine-builds.ts",
     "admitBuild() under FOR UPDATE on the charged tenant's kashbot_build_quotas row", "build.quota_exhausted", "M1"),
    ("builds.admit.envelope", "ops-dashboard", "src/lib/services/kashbot-engine-builds.ts",
     "admitBuild() under FOR UPDATE on the kashbot_build_envelope row", "build.envelope_exhausted", "M1"),
    ("builds.propose.duplicate", "ops-dashboard", "src/lib/services/kashbot-engine-builds.ts",
     "proposeBuild() for a second submission from one assistant job", "build.duplicate_submission", "M1"),
    ("builds.dispatcher.token", "ops-dashboard", "src/lib/services/kashbot-engine-builds.ts",
     "requireDispatcherToken() with the token unset or shorter than 32 characters", "build.dispatcher_token_missing", "M1"),
    ("builds.approve.digest", "ops-dashboard", "src/app/api/leafhft/mobile/builds/[id]/approve/route.ts",
     "POST approve whose card_digest differs from the server recomputed digest", "build.card_digest_mismatch", "M1"),
    ("builds.approve.expired", "ops-dashboard", "src/app/api/leafhft/mobile/builds/[id]/approve/route.ts",
     "POST approve after the card's expires_at", "build.card_expired", "M1"),
    ("builds.cancel", "ops-dashboard", "src/app/api/leafhft/mobile/builds/[id]/cancel/route.ts",
     "POST cancel that fences the lease", "build.cancel_requested", "M1"),
    ("dispatcher.tick.token", "ops-dashboard", "src/app/api/kashbot/admin/builds/tick/route.ts",
     "tick execute() with the dispatcher token unset or shorter than 32 characters",
     "build.dispatcher_token_missing", "M4"),
    ("exec.budget", "leaf-hft", "scripts/engine_build/exec.sh",
     "StopBuild from the token metric alarm or the spend cap", "build.failure_class_budget", "M3a"),
    ("exec.timeout", "leaf-hft", "scripts/engine_build/exec.sh",
     "the build timeout derived from the measured model cost per minute", "build.failure_class_timeout", "M3a"),
    ("exec.credential", "leaf-hft", "scripts/engine_build/exec.sh",
     "the per build STS session or InvokeModel is refused", "build.failure_class_credential", "M3a"),
    ("judge_run.oracle", "leaf-hft", "scripts/engine_build/judge_run.py",
     "the base owned replay tests fail on the candidate", "build.failure_class_oracle", "M3a"),
    ("judge_run.conform", "leaf-hft", "scripts/engine_build/judge_run.py",
     "the candidate fails engine conformance", "build.failure_class_conform", "M3a"),
    ("judge_seal.request_id", "leaf-hft", "scripts/engine_build/judge_seal.py",
     "BatchGetBuilds shows a judge-run REQUEST_ID that differs from the key", "build.failure_class_seal_mismatch", "M3b"),
    ("promote.pr_open", "leaf-hft", "scripts/engine_build/promote.py",
     "the promotion marker cannot reach PR_OPEN", "build.failure_class_promotion", "M6"),
    ("dispatcher.tick.infrastructure", "ops-dashboard", "src/app/api/kashbot/admin/builds/tick/route.ts",
     "a CodeBuild phase ends FAILED or FAULT outside every other class", "build.failure_class_infrastructure", "M4"),
    ("dispatcher.tick.lease", "ops-dashboard", "src/app/api/kashbot/admin/builds/tick/route.ts",
     "renew is refused by the fencing token", "build.failure_class_lease_lost", "M4"),
    ("dispatcher.tick.unreadable", "ops-dashboard", "src/app/api/kashbot/admin/builds/tick/route.ts",
     "build status stays unreadable past the bounded window", "build.failure_class_status_unreadable", "M4"),
)

# Flag reason codes (B-STD B4, B-D6, B-D7, B-D10), after C4 and M0. A flag's reason is one of these or
# a _REASONS code (the opposite side reads `engine_disagreement`); `passed` is the only green reason.
# Kept apart from _REASONS because C4's table is the engine refusal contract that
# tests/test_engine_manifest.py asserts set-equal; text() reads this table too, so it is one vocabulary.
_FLAG = {
    "passed": "The engine's checks all passed on fresh data, so this flag is green.",
    "no_flag": "The engine gave no flag for this market in this window, so it reads red.",
    "stale_input": "The quote or index data behind this flag is too old or missing, so it reads red.",
    "window_closed": "This market's window has already closed, so the flag reads red.",
    "feed_gap": "The data feed had a gap, so this engine's flags stay red until a clean turn completes.",
    "kernel_error": "The engine hit an error while it was evaluating, so its flags stay red until a clean turn completes.",
    "engine_room": "The engine has no room left for another position in this market, so the flag reads red.",
    "engine_refire": "The engine fired on this market too recently to fire again, so the flag reads red.",
    "engine_declined": "The engine looked at this market and chose not to enter, so the flag reads red.",
    "latency_budget": "The engine took longer than its time budget to decide, so its flags read red and entries pause for a minute.",
}

FLAG_REASONS: dict[str, str] = _FLAG


# Research verdict codes (plan Part II B8 and B10, slice M5), after M5-verdict-consumer. The research
# fleet's verdict consumer (scripts/kalshi_research_verdict.py) refuses a result with one of these,
# and its REASON_CODES must equal this table (tests/test_engine_reasons.py). Kept apart from _REASONS
# and _BUILD so C4's table and the build path contract stay exact; text() and build_next() read it.
_RESEARCH = {
    "research.job_missing": (
        "The research job was not found in the fleet's job table, so there is no result to use.",
        "Check the job id and submit the research job again if it was never queued."),
    "research.not_completed": (
        "The research job did not finish, so its result cannot be used.",
        "Check the job's state and resubmit it if it failed or was cancelled."),
    "research.row_invalid": (
        "The research job's record is malformed or points outside its own results folder, so it was refused.",
        "The operator inspects the job record before any retry."),
    "research.result_unreadable": (
        "The research result file could not be read within its size limit, so it was refused.",
        "Retry the read once, then the operator checks the result file."),
    "research.result_invalid": (
        "The research result file does not match the expected format, so it was refused.",
        "The operator reviews the worker that wrote the result before any retry."),
    "research.identity_mismatch": (
        "The research result does not belong to this job, so it was refused.",
        "The operator compares the result with the job record before any retry."),
    "research.not_accepted": (
        "The research job ran but did not pass its acceptance check, so its result cannot be used.",
        "Read the job's report and submit a revised variant."),
    "research.sandbox_not_uid": (
        "The research job did not run inside the separate user sandbox, so its result cannot be trusted.",
        "Run the job again on a fleet that runs research code as its own separate user."),
    "research.sandbox_invalid": (
        "The research result names an invalid sandbox user, so it was refused.",
        "The operator checks the fleet's sandbox settings before any retry."),
    "research.sandbox_user_mismatch": (
        "The research job ran as a different sandbox user than the one expected, so it was refused.",
        "The operator checks which sandbox user the fleet is configured to use."),
}

RESEARCH_REASONS: dict[str, str] = {code: pair[0] for code, pair in _RESEARCH.items()}
RESEARCH_NEXT: dict[str, str] = {code: pair[1] for code, pair in _RESEARCH.items()}

# (site, repo, path, call site, code, slice). One row per refusal in the consumer; mirrored row for
# row by the research site table in docs/ENGINE-BUILD-THREAT-MODEL.md.
RESEARCH_RAISE_SITES: tuple[tuple[str, str, str, str, str, str], ...] = (
    ("verdict.read.missing", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "read_verdict() when the job table has no row for the job id", "research.job_missing", "M5"),
    ("verdict.read.state", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "read_verdict() for a row whose state is not pending, running or completed", "research.not_completed", "M5"),
    ("verdict.row.state", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "_check_row() for a row whose state is not completed", "research.not_completed", "M5"),
    ("verdict.read.row", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "read_verdict() for a row that is not an object or whose job_key differs from the job id",
     "research.row_invalid", "M5"),
    ("verdict.row.fields", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "_check_row() for a missing field or a result or archive key outside the job's results prefix",
     "research.row_invalid", "M5"),
    ("verdict.read.result", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "read_verdict() when the bounded get-object or the JSON read of result.json fails",
     "research.result_unreadable", "M5"),
    ("verdict.check.schema", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "check_result() for a result whose keys or field types differ from schema v1", "research.result_invalid", "M5"),
    ("verdict.check.identity", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "check_result() for a job id, token, spec digest, archive key or archive digest that differs from the row",
     "research.identity_mismatch", "M5"),
    ("verdict.check.acceptance", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "check_result() for a nonzero exit code, a failed acceptance or an incomplete run", "research.not_accepted", "M5"),
    ("verdict.check.sandbox_mode", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "check_result() for a sandbox whose mode is not uid", "research.sandbox_not_uid", "M5"),
    ("verdict.check.sandbox_shape", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "check_result() for a uid sandbox with extra keys, a bad user name or a uid that is not a positive integer",
     "research.sandbox_invalid", "M5"),
    ("verdict.check.sandbox_user", "leaf-hft", "scripts/kalshi_research_verdict.py",
     "check_result() when expected_user is set and the sandbox user differs", "research.sandbox_user_mismatch", "M5"),
)


def build_next(code) -> str:
    """Return the `next` action for a build or research code; any other input yields a fixed sentence, never an error."""
    try:
        action = (BUILD_NEXT.get(code) or RESEARCH_NEXT.get(code)) if isinstance(code, str) else None
    except Exception:  # unhashable str subclass or similar; never raise to a renderer
        action = None
    return action if action is not None else "No next step is recorded for this reason code."


def text(code) -> str:
    """Return the sentence for a code; any other input yields the unknown sentence, never an error."""
    try:
        sentence = ((_REASONS.get(code) or BUILD_REASONS.get(code) or _FLAG.get(code)
                     or RESEARCH_REASONS.get(code)) if isinstance(code, str) else None)
    except Exception:  # unhashable str subclass or similar; never raise to a renderer
        sentence = None
    if sentence is not None:
        return sentence
    try:
        shown = code if isinstance(code, str) else repr(code)
    except Exception:
        shown = "<unprintable>"
    return f"Unknown reason code: {shown[:128]}"
