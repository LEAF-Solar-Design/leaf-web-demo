"""Book manifests: one strict, canonical description per book (B-STD slice B2, mandate 18).

Pure data: no I/O, no venue client, standard library only at import. A book id is
`kalshi-book:<symbol>`, today's feed id, and never carries a version (B-D1); the integration
family and its pinned version ride on the manifest, which is what a connection records. The
fourteen legacy Kalshi books are DESCRIBED from SYMBOL_MAP by `legacy_manifests()`, never
re-plumbed (B-D2): nothing in the money process reads this module.

The decoder fails closed. Unknown keys, duplicate keys, floats (every decimal is a string),
out-of-range values and documents over MAX_MANIFEST_BYTES are refused with a stable code from
REFUSAL_CODES. `manifest_digest` is sha256 over the canonical JSON (sorted keys, no whitespace,
ASCII), so equal manifests digest equally in every process whatever its hash seed.

Fee models (amendment 11): `per_order_ceil` rounds the model fee up once for the whole order
(costs.order_fee_cents); `per_contract_ceil` rounds the one-contract fee up first
(settlement.fee_per_contract) and then ceil(quantity x that fee) for fractional quantities.
`model_fee_cents` is the exact Decimal reference for both; reported venue fees still win for
actual fills.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from decimal import ROUND_CEILING, Decimal, localcontext
from typing import Any

SCHEMA = 1
MAX_MANIFEST_BYTES = 16 * 1024
MAX_FEEDS = 16
MAX_TICK_BANDS = 32
MIN_FLAG_QUOTE_AGE_MS = 1
# Far below the 60 s max_quote_age_ms, which is never a flag bound (B-D7).
MAX_FLAG_QUOTE_AGE_MS = 30_000
BOOK_ID_PREFIX = "kalshi-book:"
DOMAINS = frozenset({"kalshi"})
PER_ORDER_CEIL = "per_order_ceil"
PER_CONTRACT_CEIL = "per_contract_ceil"
FEE_MODELS = (PER_ORDER_CEIL, PER_CONTRACT_CEIL)
# The hop names of B-STD section 3; every budget is a hypothesis until B1b measures it.
LATENCY_HOPS = frozenset({
    "loop_lag", "receive_to_dequeue", "incumbent_compute", "tap_emit", "index_relay",
    "trade_relay", "quote_state_age", "tap_to_observer", "signal_step", "flag_to_admit",
    "admit_to_ack", "e2e", "publish_lag",
})
# A feed with no pin yet. B3 owns pins.lock.json; execution admission refuses an unpinned feed.
UNPINNED = "unpinned"

REFUSAL_CODES = (
    "bad_type", "oversize", "not_json", "duplicate_key", "float_refused", "unknown_key",
    "missing_key", "schema_unsupported", "bad_string", "bad_decimal", "bad_length",
    "book_id_mismatch", "domain_unknown", "feed_invalid", "fee_model_unknown",
    "tick_grid_invalid", "age_out_of_range", "slo_invalid",
)

_SYMBOL = re.compile(r"[A-Z0-9]{1,12}(?:-[A-Z0-9]{1,8}){0,2}")
_DOMAIN = re.compile(r"[a-z0-9-]{1,16}")
_SERIES = re.compile(r"[A-Z0-9]{1,32}")
_INDEX_ID = re.compile(r"[A-Za-z0-9_./-]{1,64}")
_FEED_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,31}:[A-Z0-9][A-Z0-9-]{0,31}")
_PIN = re.compile(r"sha256:[0-9a-f]{64}|" + UNPINNED)
_INTEGRATION_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,31}")
_FAMILY = re.compile(r"[a-z0-9][a-z0-9-]{0,15}")
_VERSION = re.compile(r"[0-9]{1,6}(?:\.[0-9]{1,6}){0,2}")
# Canonical decimal strings only: no sign, no leading zeros, no trailing fractional zeros, so a
# value has exactly one spelling and the digest cannot drift on "0.07" versus "0.070".
_DECIMAL = re.compile(r"(?:0|[1-9][0-9]{0,8})(?:\.[0-9]{0,5}[1-9])?")

_TOP_KEYS = ("book_id", "domain", "fee_model", "feeds", "flag_quote_age_ms", "index_id",
             "integration", "latency_slo_ms", "schema", "series", "symbol", "tick_grid")


class ManifestInvalid(ValueError):
    """A manifest refusal; `code` is one of REFUSAL_CODES."""

    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


class StrictJsonError(ValueError):
    """Strict JSON refusal shared by the manifest decoder and the tape codec."""

    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


def _pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise StrictJsonError("duplicate_key", f"duplicate key {key[:64]!r}")
        out[key] = value
    return out


def _refuse_float(text):
    raise StrictJsonError("float_refused", "numbers are integers; decimals travel as strings")


def _refuse_constant(text):
    raise StrictJsonError("float_refused", f"{text} is not a JSON number")


def strict_json_loads(raw: bytes) -> Any:
    """Parse already size-bounded UTF-8 JSON; duplicate keys, floats and NaN fail closed."""
    try:
        text = bytes(raw).decode("utf-8")
    except UnicodeDecodeError:
        raise StrictJsonError("not_json", "not UTF-8") from None
    try:
        return json.loads(text, object_pairs_hook=_pairs, parse_float=_refuse_float,
                          parse_constant=_refuse_constant)
    except StrictJsonError:
        raise
    except (ValueError, RecursionError) as exc:
        raise StrictJsonError("not_json", type(exc).__name__) from None


def canonical_json(value: Any) -> bytes:
    """The one canonical form: sorted keys, no whitespace, ASCII only, no NaN."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode("ascii")


# ---------------------------------------------------------------- fee models

def _exact(value, name: str) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (int, Decimal)):
        raise ValueError(f"{name} must be an int or Decimal")
    result = Decimal(value)
    if not result.is_finite():
        raise ValueError(f"{name} must be finite")
    sign, digits, exponent = result.as_tuple()
    if len(digits) > 18 or exponent < -8:
        raise ValueError(f"{name} exceeds 18 digits or 8 decimal places")
    return result


def model_fee_cents(model: str, price_cents, quantity, rate) -> int:
    """Exact whole-cent model fee for one order; fails closed on a bad model or input.

    per_order_ceil:    ceil(rate * q * p * (100 - p) / 100), rounded once per order.
    per_contract_ceil: ceil(q * ceil(rate * p * (100 - p) / 100)).
    """
    price, count, fee_rate = _exact(price_cents, "price_cents"), _exact(quantity, "quantity"), _exact(rate, "rate")
    if not 0 < price < 100 or count <= 0 or fee_rate < 0:
        raise ValueError("price_cents must be in (0, 100), quantity positive, rate nonnegative")
    with localcontext() as ctx:
        ctx.prec = 100  # three 18-digit factors and a quantity stay exact
        unit = fee_rate * price * (Decimal(100) - price) / Decimal(100)
        if model == PER_ORDER_CEIL:
            total = unit * count
        elif model == PER_CONTRACT_CEIL:
            total = unit.to_integral_value(rounding=ROUND_CEILING) * count
        else:
            raise ValueError(f"unknown fee model {model!r}")
        return int(total.to_integral_value(rounding=ROUND_CEILING))


# ---------------------------------------------------------------- the manifest

@dataclass(frozen=True, slots=True)
class Integration:
    id: str
    family: str
    version: str


@dataclass(frozen=True, slots=True)
class FeedPin:
    feed_id: str
    pin_digest: str


@dataclass(frozen=True, slots=True)
class FeeModel:
    name: str
    rate: str

    def fee_cents(self, price_cents, quantity) -> int:
        return model_fee_cents(self.name, price_cents, quantity, Decimal(self.rate))


@dataclass(frozen=True, slots=True)
class TickBand:
    lo: str
    hi: str
    tick: str

    def contains(self, price: Decimal) -> bool:
        lo, hi, tick = Decimal(self.lo), Decimal(self.hi), Decimal(self.tick)
        return lo <= price <= hi and (price - lo) % tick == 0


@dataclass(frozen=True, slots=True)
class BookManifest:
    """Built only by `manifest_from_dict` / `decode_manifest`; `encode_manifest` re-checks."""

    schema: int
    book_id: str
    domain: str
    symbol: str
    series: str
    index_id: str
    integration: Integration
    feeds: tuple[FeedPin, ...]
    fee_model: FeeModel
    tick_grid: tuple[TickBand, ...]
    flag_quote_age_ms: int
    latency_slo_ms: tuple[tuple[str, str], ...]

    def on_grid(self, price_cents) -> bool:
        """True when the price sits on this book's tick grid."""
        if isinstance(price_cents, bool) or not isinstance(price_cents, (int, Decimal)):
            raise TypeError("price_cents must be an int or Decimal")
        price = Decimal(price_cents)
        return price.is_finite() and any(band.contains(price) for band in self.tick_grid)

    def to_dict(self) -> dict:
        return {
            "book_id": self.book_id,
            "domain": self.domain,
            "fee_model": {"name": self.fee_model.name, "rate": self.fee_model.rate},
            "feeds": [{"feed_id": f.feed_id, "pin_digest": f.pin_digest} for f in self.feeds],
            "flag_quote_age_ms": self.flag_quote_age_ms,
            "index_id": self.index_id,
            "integration": {"family": self.integration.family, "id": self.integration.id,
                            "version": self.integration.version},
            "latency_slo_ms": {hop: value for hop, value in self.latency_slo_ms},
            "schema": self.schema,
            "series": self.series,
            "symbol": self.symbol,
            "tick_grid": [{"hi": b.hi, "lo": b.lo, "tick": b.tick} for b in self.tick_grid],
        }


def _keys(value, where: str, required) -> dict:
    if type(value) is not dict:
        raise ManifestInvalid("bad_type", f"{where}: expected an object")
    unknown = set(value) - set(required)
    if unknown:
        raise ManifestInvalid("unknown_key", f"{where}: unknown key {sorted(unknown)[0][:64]!r}")
    missing = set(required) - set(value)
    if missing:
        raise ManifestInvalid("missing_key", f"{where}: missing key {sorted(missing)[0]!r}")
    return value


def _int(value, where: str) -> int:
    if type(value) is not int:
        raise ManifestInvalid("bad_type", f"{where}: expected an integer")
    return value


def _text(value, where: str, pattern: re.Pattern, code: str = "bad_string") -> str:
    if type(value) is not str:
        raise ManifestInvalid("bad_type", f"{where}: expected a string")
    if not pattern.fullmatch(value):
        raise ManifestInvalid(code, f"{where}: {value[:64]!r} is not allowed")
    return value


def _decimal(value, where: str) -> Decimal:
    if type(value) is not str:
        raise ManifestInvalid("bad_type", f"{where}: expected a decimal string")
    if not _DECIMAL.fullmatch(value):
        raise ManifestInvalid("bad_decimal", f"{where}: {value[:32]!r} is not a canonical decimal string")
    return Decimal(value)


def _list(value, where: str, lo: int, hi: int) -> list:
    if type(value) is not list:
        raise ManifestInvalid("bad_type", f"{where}: expected a list")
    if not lo <= len(value) <= hi:
        raise ManifestInvalid("bad_length", f"{where}: {len(value)} entries, allowed {lo} to {hi}")
    return value


def manifest_from_dict(doc) -> BookManifest:
    """Validate a parsed manifest document; every refusal carries a REFUSAL_CODES code."""
    _keys(doc, "manifest", _TOP_KEYS)
    schema = _int(doc["schema"], "schema")
    if schema != SCHEMA:
        raise ManifestInvalid("schema_unsupported", f"schema {schema} is not {SCHEMA}")
    domain = _text(doc["domain"], "domain", _DOMAIN)
    if domain not in DOMAINS:
        raise ManifestInvalid("domain_unknown", f"domain {domain!r} is not one of {sorted(DOMAINS)}")
    symbol = _text(doc["symbol"], "symbol", _SYMBOL)
    book_id = doc["book_id"]
    if type(book_id) is not str:
        raise ManifestInvalid("bad_type", "book_id: expected a string")
    if book_id != BOOK_ID_PREFIX + symbol:
        raise ManifestInvalid("book_id_mismatch", f"book_id must be {BOOK_ID_PREFIX + symbol!r}")
    series = _text(doc["series"], "series", _SERIES)
    index_id = _text(doc["index_id"], "index_id", _INDEX_ID)

    raw = _keys(doc["integration"], "integration", ("family", "id", "version"))
    integration = Integration(_text(raw["id"], "integration.id", _INTEGRATION_ID),
                              _text(raw["family"], "integration.family", _FAMILY),
                              _text(raw["version"], "integration.version", _VERSION))

    feeds = []
    for n, item in enumerate(_list(doc["feeds"], "feeds", 1, MAX_FEEDS)):
        item = _keys(item, f"feeds[{n}]", ("feed_id", "pin_digest"))
        feeds.append(FeedPin(_text(item["feed_id"], f"feeds[{n}].feed_id", _FEED_ID, "feed_invalid"),
                             _text(item["pin_digest"], f"feeds[{n}].pin_digest", _PIN, "feed_invalid")))
    feed_ids = [f.feed_id for f in feeds]
    if len(set(feed_ids)) != len(feed_ids):
        raise ManifestInvalid("feed_invalid", "feeds: duplicate feed_id")
    if book_id not in feed_ids:
        raise ManifestInvalid("feed_invalid", f"feeds: the book's own feed {book_id!r} is missing")

    raw = _keys(doc["fee_model"], "fee_model", ("name", "rate"))
    name = raw["name"]
    if type(name) is not str:
        raise ManifestInvalid("bad_type", "fee_model.name: expected a string")
    if name not in FEE_MODELS:
        raise ManifestInvalid("fee_model_unknown", f"fee_model.name {name[:64]!r} is not one of {list(FEE_MODELS)}")
    if not 0 <= _decimal(raw["rate"], "fee_model.rate") <= 1:
        raise ManifestInvalid("bad_decimal", "fee_model.rate must be in [0, 1]")
    fee_model = FeeModel(name, raw["rate"])

    bands = []
    previous_hi = None
    for n, item in enumerate(_list(doc["tick_grid"], "tick_grid", 1, MAX_TICK_BANDS)):
        item = _keys(item, f"tick_grid[{n}]", ("hi", "lo", "tick"))
        lo = _decimal(item["lo"], f"tick_grid[{n}].lo")
        hi = _decimal(item["hi"], f"tick_grid[{n}].hi")
        tick = _decimal(item["tick"], f"tick_grid[{n}].tick")
        if not (0 < lo <= hi < 100 and tick > 0 and (hi - lo) % tick == 0):
            raise ManifestInvalid("tick_grid_invalid", f"tick_grid[{n}]: need 0 < lo <= hi < 100 and hi - lo a whole number of ticks")
        if previous_hi is not None and lo <= previous_hi:
            raise ManifestInvalid("tick_grid_invalid", f"tick_grid[{n}]: bands must ascend without overlap")
        previous_hi = hi
        bands.append(TickBand(item["lo"], item["hi"], item["tick"]))

    age = doc["flag_quote_age_ms"]
    if type(age) is not int:
        raise ManifestInvalid("bad_type", "flag_quote_age_ms: expected an integer")
    if not MIN_FLAG_QUOTE_AGE_MS <= age <= MAX_FLAG_QUOTE_AGE_MS:
        raise ManifestInvalid("age_out_of_range", f"flag_quote_age_ms must be {MIN_FLAG_QUOTE_AGE_MS} to {MAX_FLAG_QUOTE_AGE_MS}")

    slos = doc["latency_slo_ms"]
    if type(slos) is not dict:
        raise ManifestInvalid("bad_type", "latency_slo_ms: expected an object")
    if any(type(hop) is not str for hop in slos):
        raise ManifestInvalid("slo_invalid", "latency_slo_ms: hop names are strings")
    for hop in sorted(slos):
        if hop not in LATENCY_HOPS:
            raise ManifestInvalid("slo_invalid", f"latency_slo_ms: unknown hop {hop[:64]!r}")
        if _decimal(slos[hop], f"latency_slo_ms.{hop}") <= 0:
            raise ManifestInvalid("slo_invalid", f"latency_slo_ms.{hop}: a budget must be positive")

    return BookManifest(
        schema=schema, book_id=book_id, domain=domain, symbol=symbol, series=series,
        index_id=index_id, integration=integration, feeds=tuple(feeds), fee_model=fee_model,
        tick_grid=tuple(bands), flag_quote_age_ms=age,
        latency_slo_ms=tuple((hop, slos[hop]) for hop in sorted(slos)))


def decode_manifest(raw) -> BookManifest:
    """Strict decoder: bytes or str of at most MAX_MANIFEST_BYTES; fails closed with a code."""
    if isinstance(raw, str):
        raw = raw.encode("utf-8")
    if not isinstance(raw, (bytes, bytearray)):
        raise ManifestInvalid("bad_type", "manifest must be bytes or str")
    if len(raw) > MAX_MANIFEST_BYTES:
        raise ManifestInvalid("oversize", f"{len(raw)} bytes > {MAX_MANIFEST_BYTES}")
    try:
        doc = strict_json_loads(raw)
    except StrictJsonError as exc:
        raise ManifestInvalid(exc.code, exc.detail) from None
    return manifest_from_dict(doc)


def encode_manifest(manifest: BookManifest) -> bytes:
    """Canonical bytes; refuses a manifest the decoder would not have produced."""
    if not isinstance(manifest, BookManifest):
        raise TypeError("encode_manifest expects a BookManifest")
    doc = manifest.to_dict()
    if manifest_from_dict(doc) != manifest:
        raise ManifestInvalid("bad_type", "manifest was not built by the decoder")
    body = canonical_json(doc)
    if len(body) > MAX_MANIFEST_BYTES:
        raise ManifestInvalid("oversize", f"{len(body)} bytes > {MAX_MANIFEST_BYTES}")
    return body


def manifest_digest(manifest: BookManifest) -> str:
    """sha256 over the canonical JSON, as `sha256:<64 hex>`."""
    return "sha256:" + hashlib.sha256(encode_manifest(manifest)).hexdigest()


# ---------------------------------------------------------------- the fourteen legacy books

LEGACY_INTEGRATION_ID = "kalshi-v2"
LEGACY_INTEGRATION_VERSION = "1"
LEGACY_FEE_MODEL = PER_CONTRACT_CEIL  # kalshi_edge prices entries with settlement.fee_per_contract
LEGACY_FLAG_QUOTE_AGE_MS = 5_000  # guessed; B1b's baseline receipt replaces it with a measurement
LEGACY_TICK_GRID = ({"hi": "99", "lo": "1", "tick": "1"},)  # whole cents 1..99, probe_runner's range
LEGACY_LATENCY_SLO_MS = {"e2e": "150", "receive_to_dequeue": "5"}  # B-STD section 3, modeled and guessed
_LEGACY_FAMILIES = (("-15M", "15m"), ("-1H", "1h"))


def _canonical_decimal(value: Decimal) -> str:
    text = format(value.normalize(), "f")
    if not _DECIMAL.fullmatch(text):
        raise ValueError(f"{value!r} has no canonical decimal spelling")
    return text


def legacy_manifests(symbol_map=None, taker_rate=None) -> tuple[BookManifest, ...]:
    """Describe the legacy Kalshi books from SYMBOL_MAP, sorted by symbol. Reads, never writes.

    The venue modules are imported lazily, here only, so importing this module stays pure.
    """
    if symbol_map is None:
        from ..feeds.kalshi import SYMBOL_MAP as symbol_map
    if taker_rate is None:
        from ..strategy.settlement import DEFAULT_TAKER_MULTIPLIER as taker_rate
    if isinstance(taker_rate, bool) or not isinstance(taker_rate, (int, float, Decimal)):
        raise TypeError("taker_rate must be a number")
    rate = _canonical_decimal(Decimal(str(taker_rate)))
    out = []
    for symbol in sorted(symbol_map):
        series, index_id = symbol_map[symbol]
        family = next((name for suffix, name in _LEGACY_FAMILIES if symbol.endswith(suffix)), None)
        if family is None:
            raise ValueError(f"legacy symbol {symbol!r} is neither a 15M series nor a 1H ladder")
        book_id = BOOK_ID_PREFIX + symbol
        out.append(manifest_from_dict({
            "book_id": book_id,
            "domain": "kalshi",
            "fee_model": {"name": LEGACY_FEE_MODEL, "rate": rate},
            "feeds": [{"feed_id": book_id, "pin_digest": UNPINNED}],
            "flag_quote_age_ms": LEGACY_FLAG_QUOTE_AGE_MS,
            "index_id": index_id,
            "integration": {"family": family, "id": LEGACY_INTEGRATION_ID,
                            "version": LEGACY_INTEGRATION_VERSION},
            "latency_slo_ms": dict(LEGACY_LATENCY_SLO_MS),
            "schema": SCHEMA,
            "series": series,
            "symbol": symbol,
            "tick_grid": [dict(band) for band in LEGACY_TICK_GRID],
        }))
    return tuple(out)


def legacy_golden_text(symbol_map=None, taker_rate=None) -> str:
    """The generator's output: one canonical manifest per line, sorted by symbol."""
    return "".join(encode_manifest(m).decode("ascii") + "\n"
                   for m in legacy_manifests(symbol_map, taker_rate))
