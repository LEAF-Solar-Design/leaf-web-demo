"""HopMeter: per-hop latency over preallocated rings and 1 s x 60 time buckets (B-STD B7, B-D9;
B-STD-amendments v2 item 9).

Every hop declares ONE clock, its two endpoints, its missing-data rule and the I/O it includes.
A hop's value is always `end - start` read on that one clock: epoch_ns (time.time_ns, the receive
clock of frame.CLOCK_DOMAIN) or perf_counter_ns (a same-process duration), never mixed. A missing
sample is null (record_missing, published as a count and as null percentiles), never zero. Every
budget is a hypothesis: guessed until B1b measures it on the target execution path.

| hop | clock | start -> end | missing | I/O included | budget (basis) |
|---|---|---|---|---|---|
| loop_lag | perf_counter_ns | scheduled wakeup deadline -> perf_counter_ns read first in the woken callback | a wakeup that never fires is null, recorded missing by the next wakeup | none direct; includes every GC pause and blocking call another callback made on the loop | 20 ms (modeled max(20 ms, baseline p99 + 10 ms); guessed until B1b measures it) |
| receive_to_dequeue | epoch_ns | ts_recv (feed receive stamp, after the 100 ms quote throttle) -> time.time_ns at loop dequeue | an event without ts_recv is null | loop queue wait only; excludes network and the throttle | 5 ms p99 (guessed until B1b measures it) |
| incumbent_compute | perf_counter_ns | before the incumbent evaluate -> after it returns (hot_path_ms) | a turn with no evaluation is null | whatever the incumbent runs inline; no new I/O | none new (recorded; guessed until B1b measures it) |
| tap_emit | perf_counter_ns | before Tap.emit -> after it returns | an un-opted book records nothing (null) | none: one clock read and a ring write | 2 us p99 on runner-class hardware (guessed until B1b measures it) |
| index_relay | epoch_ns | venue index timestamp -> ts_recv of that message | a message without a venue timestamp is null | venue publish, network, websocket read; skew-inclusive | 250 ms (skew-inclusive; guessed until B1b measures it) |
| trade_relay | epoch_ns | venue trade timestamp -> ts_recv of that message | a message without a venue timestamp is null | venue publish, network, websocket read; skew-inclusive | 250 ms (skew-inclusive; guessed until B1b measures it) |
| quote_state_age | epoch_ns | ts_arrival (retained across identical snapshots) -> ts_recv | a quote without ts_arrival is null | none; informational, excluded from health | none (informational only; guessed until B1b measures it) |
| tap_to_observer | epoch_ns | tap stamp in the book process -> time.time_ns at observer decode | an event a full ring dropped is null (Tap dropped counter) | ring wait, drainer poll, local socket write and observer read; one host clock, two processes | 20 ms p99 (guessed until B1b measures it) |
| signal_step | perf_counter_ns | before one engine's signal() -> after it returns, per engine per turn | an engine skipped this turn is null | none expected; kernel code only | turn_total / engines (modeled; guessed until B1b measures it) |
| flag_to_admit | perf_counter_ns | flag turns green -> admission decision | a green flag with no admission decision is null | read-only cash, floor and breaker prechecks; excludes ledger.reserve I/O (20 to 49 ms measured) | 2 ms p99 (guessed until B1b measures it) |
| admit_to_ack | perf_counter_ns | admission of one client order id -> venue ack received | no ack (timeout or unknown outcome) is null | order POST round trip: TLS, network, venue matching | from the baseline receipt (guessed until B1b measures it) |
| e2e | epoch_ns | ts_recv of the triggering input -> time.time_ns just before the order send | an intent never sent is null | everything in-process between receive and send; excludes network to the venue | 150 ms p99 (modeled; guessed until B1b measures it) |
| publish_lag | epoch_ns | status at_ms (as ns) -> push accepted | a push that fails is null | status serialisation, write and push upload | 90 s (push cadence; guessed until B1b measures it) |

Contract, record path (record, record_missing and the helpers they call): no container growth, no
object retention and no blocking on the record path; CPython integer boxing is bounded. Every
container is preallocated at construction and only ever index-assigned; the only objects stored
are ints, one per fixed slot, so boxed ints are bounded by the slot count. No I/O, no lock, no
await, no clock read: the caller passes its own monotonic reading (`mono_ns`, time.monotonic_ns)
for time bucketing. Bad input fails closed into a counter, never an exception into the caller.

Windows are 60 one-second buckets per hop. Each bucket carries a log-linear value histogram
(16 sub-buckets per power of two, relative width at most 1/16) plus n, missing and max; a rolling
window histogram is kept in step, so a snapshot walks one histogram per hop. Percentiles are
nearest-rank over the window and exact to within one bucket width; max is exact. Values above
MAX_TRACKABLE_NS land in the top bucket and are counted as overflow.

Pure: standard library only, no I/O, no clock reads, no threads. Nothing wires it yet (B8).
"""
from __future__ import annotations

from types import MappingProxyType
from typing import NamedTuple

EPOCH_NS = "epoch_ns"
PERF_NS = "perf_counter_ns"
CLOCKS = (EPOCH_NS, PERF_NS)
UNMEASURED = "guessed until B1b measures it"

WINDOW_SLOTS = 60
SLOT_NS = 1_000_000_000
SUB_BITS = 4
_SUB = 1 << SUB_BITS
MAX_TRACKABLE_NS = (1 << 37) - 1  # about 137 s; publish_lag's 90 s budget fits
NBUCKETS = (((MAX_TRACKABLE_NS.bit_length() - SUB_BITS - 1) << SUB_BITS)
            + (MAX_TRACKABLE_NS >> (MAX_TRACKABLE_NS.bit_length() - SUB_BITS - 1)) + 1)
RING_CAPACITY = 1024
MIN_RING = 16
MAX_RING = 1 << 16
QUANTILES = (("p50", 500), ("p90", 900), ("p95", 950), ("p99", 990))  # per mille, nearest rank
_NEVER = -(1 << 62)


class HopSpec(NamedTuple):
    """One row of the B-D9 hop table: one clock, two endpoints, a missing rule, the I/O it includes."""

    name: str
    clock: str
    start: str
    end: str
    missing: str
    io: str
    budget_ns: int | None
    basis: str


HOPS: tuple[HopSpec, ...] = (
    HopSpec("loop_lag", PERF_NS, "scheduled wakeup deadline",
            "perf_counter_ns read first in the woken callback",
            "a wakeup that never fires is null, recorded missing by the next wakeup",
            "none direct; includes every GC pause and blocking call another callback made on the loop",
            20_000_000, "modeled max(20 ms, baseline p99 + 10 ms); " + UNMEASURED),
    HopSpec("receive_to_dequeue", EPOCH_NS,
            "ts_recv (feed receive stamp, after the 100 ms quote throttle)",
            "time.time_ns at loop dequeue", "an event without ts_recv is null",
            "loop queue wait only; excludes network and the throttle",
            5_000_000, "p99; " + UNMEASURED),
    HopSpec("incumbent_compute", PERF_NS, "before the incumbent evaluate",
            "after it returns (hot_path_ms)", "a turn with no evaluation is null",
            "whatever the incumbent runs inline; no new I/O",
            None, "recorded, no new budget; " + UNMEASURED),
    HopSpec("tap_emit", PERF_NS, "before Tap.emit", "after it returns",
            "an un-opted book records nothing (null)", "none: one clock read and a ring write",
            2_000, "p99 on runner-class hardware; " + UNMEASURED),
    HopSpec("index_relay", EPOCH_NS, "venue index timestamp", "ts_recv of that message",
            "a message without a venue timestamp is null",
            "venue publish, network, websocket read; skew-inclusive (a negative value is counted, "
            "never histogrammed)",
            250_000_000, "skew-inclusive; " + UNMEASURED),
    HopSpec("trade_relay", EPOCH_NS, "venue trade timestamp", "ts_recv of that message",
            "a message without a venue timestamp is null",
            "venue publish, network, websocket read; skew-inclusive (a negative value is counted, "
            "never histogrammed)",
            250_000_000, "skew-inclusive; " + UNMEASURED),
    HopSpec("quote_state_age", EPOCH_NS, "ts_arrival (retained across identical snapshots)",
            "ts_recv", "a quote without ts_arrival is null",
            "none; informational, excluded from health",
            None, "informational only; " + UNMEASURED),
    HopSpec("tap_to_observer", EPOCH_NS, "tap stamp in the book process",
            "time.time_ns at observer decode",
            "an event a full ring dropped is null (Tap dropped counter)",
            "ring wait, drainer poll, local socket write and observer read; one host clock, "
            "two processes",
            20_000_000, "p99; " + UNMEASURED),
    HopSpec("signal_step", PERF_NS, "before one engine's signal(), per engine per turn",
            "after it returns", "an engine skipped this turn is null",
            "none expected; kernel code only",
            None, "modeled turn_total / engines, resolved per turn; " + UNMEASURED),
    HopSpec("flag_to_admit", PERF_NS, "flag turns green", "admission decision",
            "a green flag with no admission decision is null",
            "read-only cash, floor and breaker prechecks; excludes ledger.reserve I/O "
            "(20 to 49 ms measured)",
            2_000_000, "p99; " + UNMEASURED),
    HopSpec("admit_to_ack", PERF_NS, "admission of one client order id", "venue ack received",
            "no ack (timeout or unknown outcome) is null",
            "order POST round trip: TLS, network, venue matching",
            None, "from the baseline receipt; " + UNMEASURED),
    HopSpec("e2e", EPOCH_NS, "ts_recv of the triggering input",
            "time.time_ns just before the order send", "an intent never sent is null",
            "everything in-process between receive and send; excludes network to the venue",
            150_000_000, "p99, modeled; " + UNMEASURED),
    HopSpec("publish_lag", EPOCH_NS, "status at_ms (as ns)", "push accepted",
            "a push that fails is null", "status serialisation, write and push upload",
            90_000_000_000, "push cadence; " + UNMEASURED),
)
HOP_NAMES = tuple(h.name for h in HOPS)
HOP_INDEX = MappingProxyType({h.name: i for i, h in enumerate(HOPS)})
_NHOPS = len(HOPS)


def bucket_index(value_ns: int) -> int:
    """Histogram bucket of a non-negative duration; values above MAX_TRACKABLE_NS take the top bucket."""
    v = MAX_TRACKABLE_NS if value_ns > MAX_TRACKABLE_NS else value_ns
    if v < _SUB:
        return v
    e = v.bit_length() - SUB_BITS - 1
    return (e << SUB_BITS) + (v >> e)


def _bounds_of(b: int) -> tuple[int, int]:
    if b < _SUB:
        return b, b + 1
    e = (b >> SUB_BITS) - 1
    m = b - (e << SUB_BITS)
    return m << e, (m + 1) << e


def bucket_bounds(value_ns: int) -> tuple[int, int]:
    """[lo, hi) of the bucket holding value_ns: the percentile error bound at that value."""
    return _bounds_of(bucket_index(value_ns))


class HopMeter:
    """Latency per B-D9 hop. The record path allocates no container, retains no object beyond its
    fixed int slots, and performs no I/O, lock, await or clock read; bad input fails closed into
    the `rejected` counter."""

    __slots__ = (
        "_ring", "_ring_cap", "_ring_mask", "_ring_pos",
        "_slot_sec", "_slot_n", "_slot_missing", "_slot_max", "_slot_blo", "_slot_bhi", "_slot_hist",
        "_win_hist", "_win_n", "_win_missing",
        "_total", "_missing_total", "_negative", "_late", "_overflow", "_rejected",
    )

    def __init__(self, ring_capacity: int = RING_CAPACITY):
        if (type(ring_capacity) is not int or not MIN_RING <= ring_capacity <= MAX_RING
                or ring_capacity & (ring_capacity - 1)):
            raise ValueError(f"ring_capacity must be a power of two in [{MIN_RING}, {MAX_RING}]")
        slots = _NHOPS * WINDOW_SLOTS
        self._ring = [0] * (_NHOPS * ring_capacity)
        self._ring_cap = ring_capacity
        self._ring_mask = ring_capacity - 1
        self._ring_pos = [0] * _NHOPS
        self._slot_sec = [_NEVER] * slots
        self._slot_n = [0] * slots
        self._slot_missing = [0] * slots
        self._slot_max = [-1] * slots
        self._slot_blo = [NBUCKETS] * slots
        self._slot_bhi = [-1] * slots
        self._slot_hist = [0] * (slots * NBUCKETS)
        self._win_hist = [0] * (_NHOPS * NBUCKETS)
        self._win_n = [0] * _NHOPS
        self._win_missing = [0] * _NHOPS
        self._total = [0] * _NHOPS
        self._missing_total = [0] * _NHOPS
        self._negative = [0] * _NHOPS
        self._late = [0] * _NHOPS
        self._overflow = [0] * _NHOPS
        self._rejected = 0

    # -- record path: index assignment into preallocated lists only --------------------------

    def record(self, hop: int, value_ns: int, mono_ns: int) -> None:
        """One sample of `hop` (an index from HOP_INDEX), `value_ns` = end - start on the hop's
        declared clock, bucketed at the caller's monotonic reading `mono_ns`. Never raises."""
        if (type(hop) is not int or type(value_ns) is not int or type(mono_ns) is not int
                or hop < 0 or hop >= _NHOPS):
            self._rejected += 1
            return
        if value_ns < 0:
            self._negative[hop] += 1
            return
        si = self._slot(hop, mono_ns)
        if si < 0:
            self._late[hop] += 1
            return
        if value_ns > MAX_TRACKABLE_NS:
            self._overflow[hop] += 1
            v = MAX_TRACKABLE_NS
        else:
            v = value_ns
        if v < _SUB:
            b = v
        else:
            e = v.bit_length() - SUB_BITS - 1
            b = (e << SUB_BITS) + (v >> e)
        self._slot_hist[si * NBUCKETS + b] += 1
        self._win_hist[hop * NBUCKETS + b] += 1
        self._slot_n[si] += 1
        self._win_n[hop] += 1
        self._total[hop] += 1
        if value_ns > self._slot_max[si]:
            self._slot_max[si] = value_ns
        if b < self._slot_blo[si]:
            self._slot_blo[si] = b
        if b > self._slot_bhi[si]:
            self._slot_bhi[si] = b
        p = self._ring_pos[hop]
        self._ring[hop * self._ring_cap + p] = value_ns
        self._ring_pos[hop] = (p + 1) & self._ring_mask

    def record_missing(self, hop: int, mono_ns: int) -> None:
        """A sample that should exist and does not: counted as missing, never recorded as zero."""
        if type(hop) is not int or type(mono_ns) is not int or hop < 0 or hop >= _NHOPS:
            self._rejected += 1
            return
        si = self._slot(hop, mono_ns)
        if si < 0:
            self._late[hop] += 1
            return
        self._slot_missing[si] += 1
        self._win_missing[hop] += 1
        self._missing_total[hop] += 1

    def _slot(self, hop: int, mono_ns: int) -> int:
        """The slot index for this second, rotated in place; -1 when the second is older than the
        slot's current occupant (a late sample)."""
        sec = mono_ns // SLOT_NS
        si = hop * WINDOW_SLOTS + sec % WINDOW_SLOTS
        cur = self._slot_sec[si]
        if cur == sec:
            return si
        if sec < cur:
            return -1
        if self._slot_n[si] or self._slot_missing[si]:
            self._clear_slot(hop, si)
        self._slot_sec[si] = sec
        return si

    def _clear_slot(self, hop: int, si: int) -> None:
        """Subtract one slot from the window and zero it; walks only the slot's occupied bucket span."""
        sh = self._slot_hist
        wh = self._win_hist
        base = si * NBUCKETS
        wbase = hop * NBUCKETS
        for b in range(self._slot_blo[si], self._slot_bhi[si] + 1):
            c = sh[base + b]
            if c:
                wh[wbase + b] -= c
                sh[base + b] = 0
        self._win_n[hop] -= self._slot_n[si]
        self._win_missing[hop] -= self._slot_missing[si]
        self._slot_n[si] = 0
        self._slot_missing[si] = 0
        self._slot_max[si] = -1
        self._slot_blo[si] = NBUCKETS
        self._slot_bhi[si] = -1

    # -- read path: allocates freely, runs once per second -----------------------------------

    def snapshot(self, mono_ns: int) -> dict:
        """The 60 s window ending at `mono_ns`, per hop: n, p50, p90, p95, p99, max (null when
        n is 0, never zero), missing, and the lifetime negative, late and overflow counters."""
        if type(mono_ns) is not int:
            raise TypeError("mono_ns must be an int (time.monotonic_ns)")
        floor = mono_ns // SLOT_NS - WINDOW_SLOTS + 1
        hops = {}
        for hop, spec in enumerate(HOPS):
            wmax = -1
            for s in range(WINDOW_SLOTS):
                si = hop * WINDOW_SLOTS + s
                if self._slot_sec[si] < floor:
                    if self._slot_n[si] or self._slot_missing[si]:
                        self._clear_slot(hop, si)
                elif self._slot_max[si] > wmax:
                    wmax = self._slot_max[si]
            n = self._win_n[hop]
            row = {"n": n, "clock": spec.clock}
            row.update(self._percentiles(hop, n, wmax))
            row["max"] = wmax if n else None
            row["missing"] = self._win_missing[hop]
            row["total"] = self._total[hop]
            row["missing_total"] = self._missing_total[hop]
            row["negative"] = self._negative[hop]
            row["late"] = self._late[hop]
            row["overflow"] = self._overflow[hop]
            row["budget_ns"] = spec.budget_ns
            hops[spec.name] = row
        return {"window_s": WINDOW_SLOTS, "rejected": self._rejected, "hops": hops}

    def _percentiles(self, hop: int, n: int, wmax: int) -> dict:
        out = {name: None for name, _ in QUANTILES}
        if n <= 0:
            return out
        targets = [(name, (q * n + 999) // 1000 - 1) for name, q in QUANTILES]
        wh = self._win_hist
        base = hop * NBUCKETS
        cum = 0
        ti = 0
        for b in range(NBUCKETS):
            c = wh[base + b]
            if not c:
                continue
            cum += c
            while ti < len(targets) and targets[ti][1] < cum:
                hi = _bounds_of(b)[1]
                out[targets[ti][0]] = hi - 1 if hi - 1 < wmax else wmax
                ti += 1
            if ti == len(targets):
                break
        return out

    def recent(self, hop: int) -> list[int]:
        """The ring's retained samples for `hop`, oldest first (at most the ring capacity)."""
        cap = self._ring_cap
        filled = min(self._total[hop], cap)
        pos = self._ring_pos[hop]
        base = hop * cap
        return [self._ring[base + ((pos - filled + k) & self._ring_mask)] for k in range(filled)]
