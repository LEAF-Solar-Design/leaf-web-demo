"""Pure book contracts (B-STD slice B2, mandate 18): manifests, frames and flags, the tape codec.

Standard library plus leafhft.engine_reasons only: importing this package constructs no client,
opens no socket and reads no file, and nothing in the money process imports it yet.
"""
from __future__ import annotations

from .frame import (
    CLOCK_DOMAIN,
    ClockDomainError,
    FlagHold,
    FlagRecord,
    Frame,
    FrameInvalid,
    evaluate_flag,
)
from .manifest import (
    BookManifest,
    ManifestInvalid,
    decode_manifest,
    encode_manifest,
    legacy_manifests,
    manifest_digest,
)
from .tape import ReplayClock, TapeError, decode_row, encode_row, replay, replay_receipt

__all__ = [
    "CLOCK_DOMAIN", "BookManifest", "ClockDomainError", "FlagHold", "FlagRecord", "Frame",
    "FrameInvalid", "ManifestInvalid", "ReplayClock", "TapeError", "decode_manifest",
    "decode_row", "encode_manifest", "encode_row", "evaluate_flag", "legacy_manifests",
    "manifest_digest", "replay", "replay_receipt",
]
