"""The pin lock and the pre-install data gate (B-STD slice B3; B-D12, amendments 7 and 10).

One pin shape for every exact-bytes dependency: `Pin(path, sha256, kind)`, the data twin of C10's
`KernelPin(module, attr, sha256, modes)`. The digest is sha256 over the LF-normalized bytes (CRLF
becomes LF), which is exactly the committed git blob, so one pin holds on a Windows autocrlf
checkout and on the Linux runner, the same rule leafhft/lanes/kernels.py applies to code.
`kernel_pins()` projects KERNELS into this shape so one resolver checks both.

pins.lock.json (repository root) is append-only, one canonical entry per line so an append never
edits a line:

    {"schema":1,"pins":[
    {"kind":"book_manifest","path":"leafhft/library/kalshi_v2/BNB-15M/manifest.json","sha256":"..."},
    null]}

The trailing null closes the array, so every entry line keeps its comma and a new pin is inserted
just above it. The lock is a log: a later entry for a path supersedes an earlier one, a path never
changes kind, and nothing is ever removed or rewritten. `resolve_pin` reads the exact bytes once,
bounded, refuses a symlink, a non-regular file or a path escape, and refuses any digest mismatch.

Append-only is proven over RAW BYTES (`check_append_only`): the base lock before its footer line is
an exact byte prefix of the candidate, so a line-ending flip or a reorder is a finding even where
the parsed entries agree.

The pre-install gate that CI trusts is NOT this file: `.codebuild/ci.sh` carries a self-contained
stdlib-only copy of the lock and data-only checks inline, reading git objects only, so the first
gating pull request gates itself and a later candidate cannot rewrite the helper before the gate
runs. `ci_gate` below is the in-process twin (it adds the manifest validator) for local runs and
the tests; it imports the standard library only. Either refuses (exit 2) (a) a
pins.lock.json that is not an append-only extension of the base's, and (b) any changed path under
leafhft/library/ that is not a bounded, regular, non-executable data file at an approved path.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import stat
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

LOCK_NAME = "pins.lock.json"
LOCK_HEADER = '{"schema":1,"pins":['
LOCK_FOOTER = "null]}"
MAX_LOCK_BYTES = 1 << 20
MAX_LOCK_PINS = 4096
MAX_PIN_BYTES = 8 << 20
MAX_PATH_CHARS = 255
GIT_TIMEOUT_S = 120

KIND_BOOK_MANIFEST = "book_manifest"
KIND_KERNEL = "kernel"
PIN_KINDS = frozenset({KIND_BOOK_MANIFEST, "book_fees", "book_grid", "book_tape", KIND_KERNEL})
PIN_ERROR_CODES = frozenset({"lock_invalid", "lock_not_append_only", "unpinned", "pin_mismatch",
                             "too_large", "path_escape", "not_regular", "missing", "git_failed"})

# The library holds data only. Approved file names and their byte bounds (guessed bounds: a
# manifest is capped at books.manifest.MAX_MANIFEST_BYTES; a tape at 8 MiB until B14 sizes one).
LIBRARY_ROOT = "leafhft/library"
APPROVED_LIBRARY_FILES = MappingProxyType({
    "manifest.json": 16 * 1024,
    "fees.json": 64 * 1024,
    "grid.json": 64 * 1024,
    "tape.jsonl": 8 << 20,
})
LIBRARY_FILE_KINDS = MappingProxyType({
    "manifest.json": KIND_BOOK_MANIFEST, "fees.json": "book_fees", "grid.json": "book_grid",
    "tape.jsonl": "book_tape",
})
# leafhft/library/<integration>/<book>/<approved name>, nothing deeper and nothing shallower.
LIBRARY_FILE_RE = re.compile(r"leafhft/library/([a-z0-9][a-z0-9_-]{0,31})/([A-Za-z0-9][A-Za-z0-9-]{0,31})/"
                             r"(manifest\.json|fees\.json|grid\.json|tape\.jsonl)")
REGULAR_FILE_MODE = "100644"

_SHA256 = re.compile(r"[0-9a-f]{64}")
# Every component starts with a letter, digit or underscore, so "." and ".." cannot occur.
_PATH = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}(?:/[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}){0,11}")
_REV = re.compile(r"[A-Za-z0-9][A-Za-z0-9_./^~-]{0,127}")


class PinError(ValueError):
    """A pin or lock refusal; `code` is one of PIN_ERROR_CODES."""

    def __init__(self, code: str, detail: str):
        if code not in PIN_ERROR_CODES:
            raise ValueError(f"unknown pin error code {code!r}")
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


@dataclass(frozen=True, slots=True)
class Pin:
    """One exact-bytes dependency: a repository-relative POSIX path, its LF-normalized sha256 and
    what it is. Validated on construction; fails closed on anything malformed."""

    path: str
    sha256: str
    kind: str

    def __post_init__(self):
        if type(self.path) is not str or len(self.path) > MAX_PATH_CHARS or not _PATH.fullmatch(self.path):
            raise PinError("lock_invalid", f"pin path {str(self.path)[:80]!r} is not a relative POSIX path")
        if type(self.sha256) is not str or not _SHA256.fullmatch(self.sha256):
            raise PinError("lock_invalid", f"{self.path}: sha256 must be 64 lowercase hex characters")
        if type(self.kind) is not str or self.kind not in PIN_KINDS:
            raise PinError("lock_invalid", f"{self.path}: kind {str(self.kind)[:32]!r} is not one of {sorted(PIN_KINDS)}")

    def line(self) -> str:
        """The one canonical lock line for this pin (sorted keys, no whitespace, ASCII)."""
        return json.dumps({"kind": self.kind, "path": self.path, "sha256": self.sha256},
                          sort_keys=True, separators=(",", ":"), ensure_ascii=True) + ","


def lf_bytes(raw: bytes) -> bytes:
    """CRLF to LF: the committed-blob form every pin digests."""
    return bytes(raw).replace(b"\r\n", b"\n")


def lf_digest(raw: bytes) -> str:
    return hashlib.sha256(lf_bytes(raw)).hexdigest()


def repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


# ---------------------------------------------------------------- strict JSON (stdlib only)

def _pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"duplicate key {key[:64]!r}")
        out[key] = value
    return out


def _refuse_number(text):
    raise ValueError(f"{text[:32]} is not an integer")


def strict_json(text: str):
    """json.loads with duplicate keys, floats, NaN and Infinity refused."""
    return json.loads(text, object_pairs_hook=_pairs, parse_float=_refuse_number,
                      parse_constant=_refuse_number)


# ---------------------------------------------------------------- the lock

def _lock_text(raw) -> str:
    if isinstance(raw, str):
        raw = raw.encode("utf-8")
    if not isinstance(raw, (bytes, bytearray)):
        raise PinError("lock_invalid", "the lock must be bytes or str")
    if len(raw) > MAX_LOCK_BYTES:
        raise PinError("lock_invalid", f"{len(raw)} bytes > {MAX_LOCK_BYTES}")
    try:
        return lf_bytes(raw).decode("ascii")
    except UnicodeDecodeError:
        raise PinError("lock_invalid", "the lock is ASCII only") from None


def parse_lock(raw) -> tuple[Pin, ...]:
    """Every entry of a lock, in file order. Fails closed on any deviation from the canonical
    layout: header line, one canonical entry per line, the null footer, a final newline."""
    text = _lock_text(raw)
    if not text.endswith("\n"):
        raise PinError("lock_invalid", "the lock must end with a newline")
    lines = text[:-1].split("\n")
    if len(lines) < 2 or lines[0] != LOCK_HEADER or lines[-1] != LOCK_FOOTER:
        raise PinError("lock_invalid", f"the lock must open with {LOCK_HEADER} and close with {LOCK_FOOTER}")
    entries = lines[1:-1]
    if len(entries) > MAX_LOCK_PINS:
        raise PinError("lock_invalid", f"{len(entries)} entries > {MAX_LOCK_PINS}")
    pins = []
    kinds: dict[str, str] = {}
    for number, line in enumerate(entries, start=2):
        if not line.endswith(","):
            raise PinError("lock_invalid", f"line {number}: an entry line ends with a comma")
        try:
            doc = strict_json(line[:-1])
        except ValueError as exc:
            raise PinError("lock_invalid", f"line {number}: {exc}") from None
        if type(doc) is not dict or set(doc) != {"kind", "path", "sha256"}:
            raise PinError("lock_invalid", f"line {number}: an entry has exactly kind, path and sha256")
        pin = Pin(doc["path"], doc["sha256"], doc["kind"])
        if pin.line() != line:
            raise PinError("lock_invalid", f"line {number}: not in canonical form")
        if kinds.setdefault(pin.path, pin.kind) != pin.kind:
            raise PinError("lock_invalid", f"line {number}: {pin.path} changes kind")
        pins.append(pin)
    return tuple(pins)


def render_lock(pins) -> str:
    """The canonical lock text for `pins`, in the order given."""
    pins = tuple(pins)
    text = "\n".join([LOCK_HEADER, *(pin.line() for pin in pins), LOCK_FOOTER]) + "\n"
    parse_lock(text)
    return text


def effective_pins(pins) -> dict[str, Pin]:
    """path -> the LAST entry for that path (the lock is a log; a later entry supersedes)."""
    out: dict[str, Pin] = {}
    for pin in pins:
        out[pin.path] = pin
    return out


def _lock_bytes(raw) -> bytes:
    """The exact bytes of a lock as given (str is UTF-8 encoded); never line-ending normalized."""
    if isinstance(raw, str):
        raw = raw.encode("utf-8")
    if not isinstance(raw, (bytes, bytearray)):
        raise PinError("lock_invalid", "the lock must be bytes or str")
    return bytes(raw)


def first_difference(a: bytes, b: bytes) -> int:
    """The first byte offset at which `a` and `b` differ (the shorter length when one is a prefix
    of the other). Binary search over zero-copy memoryview slices: O(n log n) C compares, no copy."""
    left, right = memoryview(a), memoryview(b)
    lo, hi = 0, min(len(a), len(b))
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if left[:mid] == right[:mid]:
            lo = mid
        else:
            hi = mid - 1
    return lo


def check_append_only(base_raw, head_raw) -> tuple[Pin, ...]:
    """The pins `head` appends to `base`, proven over RAW BYTES, never a normalized form: the base
    lock with its footer line removed is an exact byte prefix of the head, the head closes with the
    base's exact footer bytes, and everything between is complete lines in the base's line ending.
    Any changed existing byte, line-ending flip, reorder or removal is
    PinError(lock_not_append_only) naming the first differing byte offset. Both locks must also
    parse. `base_raw` None means the base has no lock yet."""
    head_pins = parse_lock(head_raw)
    if base_raw is None:
        return head_pins
    base_pins = parse_lock(base_raw)
    base, head = _lock_bytes(base_raw), _lock_bytes(head_raw)
    body_end = base.rfind(b"\n", 0, len(base) - 1) + 1  # start of the footer line
    body, footer = base[:body_end], base[body_end:]
    newline = b"\r\n" if footer.endswith(b"\r\n") else b"\n"
    ending = "CRLF" if newline == b"\r\n" else "LF"
    if not head.startswith(body):
        raise PinError("lock_not_append_only", f"byte {first_difference(body, head)}: an existing byte was "
                                               "changed, removed or reordered (the base lock is not a byte prefix)")
    tail = len(head) - len(footer)
    if tail < len(body) or not head.endswith(footer):
        offset = len(body) if tail < len(body) else tail + first_difference(footer, head[tail:])
        raise PinError("lock_not_append_only", f"byte {offset}: the footer line is not the base's exact bytes")
    lines = head[len(body):tail].split(newline)
    offset = len(body)
    for line in lines[:-1]:
        if b"\r" in line or b"\n" in line:
            raise PinError("lock_not_append_only", f"byte {offset}: an appended line does not end in the "
                                                   f"base's {ending} line ending")
        offset += len(line) + len(newline)
    if lines[-1]:
        raise PinError("lock_not_append_only", f"byte {offset}: the appended bytes are not complete lines")
    if head_pins[:len(base_pins)] != base_pins:  # implied by the byte prefix; kept as the invariant
        raise PinError("lock_not_append_only", "an existing entry was changed or moved")
    return head_pins[len(base_pins):]


def append_pins(lock_raw, new_pins) -> str:
    """`lock_raw` with `new_pins` appended above the footer, as canonical LF text. The append-only
    proof runs over the committed-blob (LF) form of `lock_raw`, the bytes the pre-install gate
    compares, so a CRLF working-tree copy on a Windows autocrlf checkout still appends."""
    text = render_lock(parse_lock(lock_raw) + tuple(new_pins))
    check_append_only(lf_bytes(_lock_bytes(lock_raw)), text)
    return text


def load_lock(root=None) -> tuple[Pin, ...]:
    path = Path(root or repo_root()) / LOCK_NAME
    with open(path, "rb") as handle:
        raw = handle.read(MAX_LOCK_BYTES + 1)
    return parse_lock(raw)


# ---------------------------------------------------------------- resolution

def _open_flags() -> int:
    return os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)


def read_pinned_bytes(root, path: str, limit: int = MAX_PIN_BYTES) -> bytes:
    """The raw bytes of repository-relative `path` under `root`: no symlink anywhere below root,
    a regular file, at most `limit` bytes, read once."""
    if type(path) is not str or not _PATH.fullmatch(path):
        raise PinError("path_escape", f"{str(path)[:80]!r} is not a relative POSIX path")
    base = Path(root).resolve()
    current = base
    for part in path.split("/"):
        current = current / part
        try:
            info = os.lstat(current)
        except FileNotFoundError:
            raise PinError("missing", f"{path}: not found") from None
        if stat.S_ISLNK(info.st_mode):
            raise PinError("path_escape", f"{path}: {current.name} is a symlink")
    if not stat.S_ISREG(info.st_mode):
        raise PinError("not_regular", f"{path}: not a regular file")
    if not current.resolve().is_relative_to(base):
        raise PinError("path_escape", f"{path}: resolves outside the root")
    fd = os.open(current, _open_flags())
    with os.fdopen(fd, "rb") as handle:
        if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
            raise PinError("not_regular", f"{path}: not a regular file")
        raw = handle.read(limit + 1)
    if len(raw) > limit:
        raise PinError("too_large", f"{path}: more than {limit} bytes")
    return raw


def resolve_pin(pin: Pin, root=None) -> bytes:
    """The LF-normalized bytes of `pin.path`, read once, when their sha256 is the pin; the caller
    uses THESE bytes, never the file again. Any mismatch is PinError(pin_mismatch)."""
    if not isinstance(pin, Pin):
        raise TypeError("resolve_pin expects a Pin")
    data = lf_bytes(read_pinned_bytes(root or repo_root(), pin.path))
    digest = hashlib.sha256(data).hexdigest()
    if digest != pin.sha256:
        raise PinError("pin_mismatch", f"{pin.path}: pinned {pin.sha256}, file {digest} (LF-normalized)")
    return data


def resolve_path(path: str, root=None, pins=None) -> bytes:
    """Resolve `path` through its effective lock entry; an unlisted path is refused (unpinned)."""
    table = effective_pins(load_lock(root) if pins is None else pins)
    pin = table.get(path)
    if pin is None:
        raise PinError("unpinned", f"{path}: no entry in {LOCK_NAME}")
    return resolve_pin(pin, root)


def kernel_pins() -> tuple[Pin, ...]:
    """C10's KERNELS (and EXTRA_PINS) in the shared Pin shape, sorted by path. Imported lazily:
    the standalone gate never calls this."""
    from ..lanes import kernels

    root = repo_root()
    out = [Pin(kernels.module_path(pin.module).resolve().relative_to(root).as_posix(), pin.sha256, KIND_KERNEL)
           for pin in kernels.pins().values()]
    return tuple(sorted(out, key=lambda pin: pin.path))


# ---------------------------------------------------------------- the pre-install data gate

def touches_library(path: str) -> bool:
    """True for the library root or anything below it, whatever the letter case, so a
    case-folding filesystem cannot smuggle a file past the gate."""
    folded = path.replace("\\", "/").lower()
    return folded == LIBRARY_ROOT or folded.startswith(LIBRARY_ROOT + "/")


def library_kind(path: str) -> str | None:
    match = LIBRARY_FILE_RE.fullmatch(path)
    return LIBRARY_FILE_KINDS[match.group(3)] if match else None


def _git(root, *args, timeout=GIT_TIMEOUT_S) -> tuple[int, bytes]:
    try:
        done = subprocess.run(["git", "-C", str(root), *args], capture_output=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise PinError("git_failed", f"git {args[0]}: {type(exc).__name__}") from None
    return done.returncode, done.stdout


def _git_ok(root, *args) -> bytes:
    code, out = _git(root, *args)
    if code != 0:
        raise PinError("git_failed", f"git {' '.join(args[:2])} exited {code}")
    return out


def _rev(rev: str) -> str:
    if type(rev) is not str or not _REV.fullmatch(rev):
        raise PinError("git_failed", f"revision {str(rev)[:64]!r} is not allowed")
    return rev


def git_blob(root, rev: str, path: str, limit: int) -> bytes | None:
    """The blob at `rev:path`, or None when absent; bounded before it is read."""
    spec = f"{_rev(rev)}:{path}"
    code, _ = _git(root, "cat-file", "-e", spec)
    if code != 0:
        return None
    size = int(_git_ok(root, "cat-file", "-s", spec).strip() or b"-1")
    if not 0 <= size <= limit:
        raise PinError("too_large", f"{path} at {rev}: {size} bytes > {limit}")
    return _git_ok(root, "cat-file", "blob", spec)


def changed_entries(root, base: str, head: str) -> list[tuple[str, str, str, str]]:
    """(status, new mode, new blob, path) for every path that differs between base and head."""
    raw = _git_ok(root, "diff", "--raw", "-z", "--no-abbrev", "--no-renames", "--no-ext-diff",
                  "--no-textconv", _rev(base), _rev(head), "--")
    tokens = raw.split(b"\0")
    if tokens and tokens[-1] == b"":
        tokens.pop()
    if len(tokens) % 2:
        raise PinError("git_failed", "unexpected git diff --raw output")
    out = []
    for meta, path in zip(tokens[0::2], tokens[1::2]):
        fields = meta.decode("ascii", "replace").lstrip(":").split(" ")
        if len(fields) != 5:
            raise PinError("git_failed", "unexpected git diff --raw record")
        _old_mode, new_mode, _old_blob, new_blob, status = fields
        out.append((status[:1], new_mode, new_blob, path.decode("utf-8", "surrogateescape")))
    return out


def _load_validator(module_path):
    """The base-owned books.manifest module, loaded from the given file (a git show of origin/main)."""
    spec = importlib.util.spec_from_file_location("leafhft_base_book_manifest", module_path)
    if spec is None or spec.loader is None:
        raise PinError("git_failed", f"cannot load the manifest validator from {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _data_problem(path: str, blob: bytes, validator) -> str | None:
    """Content check with base-owned code: strict UTF-8 JSON, and a manifest must decode."""
    match = LIBRARY_FILE_RE.fullmatch(path)
    name = match.group(3)
    try:
        text = blob.decode("utf-8")
    except UnicodeDecodeError:
        return "not UTF-8"
    try:
        if name == "tape.jsonl":
            for number, line in enumerate(text.split("\n"), start=1):
                if line and type(strict_json(line)) is not dict:
                    return f"line {number} is not a JSON object"
        elif type(strict_json(text)) is not dict:
            return "not a JSON object"
    except (ValueError, RecursionError) as exc:
        return f"not strict JSON ({type(exc).__name__}: {str(exc)[:80]})"
    if name == "manifest.json" and validator is not None:
        try:
            manifest = validator.decode_manifest(blob)
        except ValueError as exc:
            return f"manifest refused ({str(exc)[:120]})"
        if manifest.symbol != match.group(2):
            return f"manifest symbol {manifest.symbol} does not match its directory {match.group(2)}"
    return None


def data_only_violations(root, base: str, head: str, validator=None) -> list[str]:
    """Every changed path under leafhft/library/ must be a regular, non-executable file at an
    approved path, within its byte bound, and valid data. Deletions are allowed: nothing runs."""
    problems = []
    for status, mode, blob_id, path in changed_entries(root, base, head):
        if not touches_library(path):
            continue
        if status == "D":
            continue
        if mode != REGULAR_FILE_MODE:
            label = {"100755": "executable", "120000": "a symlink", "160000": "a submodule"}.get(mode, f"mode {mode}")
            problems.append(f"{path}: {label}; the library takes regular non-executable files only")
            continue
        match = LIBRARY_FILE_RE.fullmatch(path)
        if match is None:
            problems.append(f"{path}: not an approved path (leafhft/library/<integration>/<book>/"
                            f"{{{', '.join(APPROVED_LIBRARY_FILES)}}})")
            continue
        blob = git_blob(root, head, path, APPROVED_LIBRARY_FILES[match.group(3)])
        if blob is None:
            problems.append(f"{path}: blob missing at {head}")
            continue
        problem = _data_problem(path, blob, validator)
        if problem:
            problems.append(f"{path}: {problem}")
    return problems


def lock_violations(root, base: str, head: str) -> tuple[list[str], int]:
    """([problem], appended pin count) for pins.lock.json between base and head."""
    base_lock = git_blob(root, base, LOCK_NAME, MAX_LOCK_BYTES)
    head_lock = git_blob(root, head, LOCK_NAME, MAX_LOCK_BYTES)
    if head_lock is None:
        return ([f"{LOCK_NAME}: removed"] if base_lock is not None else []), 0
    try:
        return [], len(check_append_only(base_lock, head_lock))
    except PinError as exc:
        return [f"{LOCK_NAME}: {exc}"], 0


def ci_gate(root, base: str, head: str = "HEAD", manifest_module=None) -> list[str]:
    """Both pre-install checks; an empty list means the candidate may be installed."""
    validator = _load_validator(manifest_module) if manifest_module else None
    problems, _ = lock_violations(root, base, head)
    return problems + data_only_violations(root, base, head, validator)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="pins", description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    gate = sub.add_parser("ci-gate", help="the pre-install lock and data-only gate; exit 2 on any violation")
    gate.add_argument("--root", default=".")
    gate.add_argument("--base", required=True)
    gate.add_argument("--head", default="HEAD")
    gate.add_argument("--manifest-module", default=None)
    verify = sub.add_parser("verify", help="every effective pin in the lock resolves")
    verify.add_argument("--root", default=".")
    args = parser.parse_args(argv)
    try:
        if args.command == "ci-gate":
            problems = ci_gate(args.root, args.base, args.head, args.manifest_module)
        else:
            problems = []
            for pin in effective_pins(load_lock(args.root)).values():
                try:
                    resolve_pin(pin, args.root)
                except PinError as exc:
                    problems.append(str(exc))
    except (PinError, OSError, ValueError) as exc:
        print(f"pins {args.command}: refused, {exc}", file=sys.stderr)
        return 2
    for problem in problems:
        print(f"pins {args.command}: {problem}", file=sys.stderr)
    if problems:
        return 2
    print(f"pins {args.command}: ok")
    return 0


if __name__ == "__main__":
    sys.exit(main())
