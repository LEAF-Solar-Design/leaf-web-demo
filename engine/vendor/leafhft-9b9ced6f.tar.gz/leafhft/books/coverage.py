"""Offline tape observations for B14, never a claim of uninterrupted market coverage.

Run ``python -m leafhft.books.coverage report|conformance --manifest MANIFEST
--tape PART [--tape TAIL ...] --from-ns START --to-ns END``. The receive-time
observation window is half-open. Report mode emits one JSON line suitable for
coverage.jsonl; conformance mode emits the separate coverage.json document.
Only explicitly supplied regular files are read. Inputs must remain unchanged
through both the decoding pass and the final streaming digest check.
"""
from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import stat
import sys

from .frame import MAX_EPOCH_NS, MIN_EPOCH_NS
from .manifest import (
    MAX_MANIFEST_BYTES, BookManifest, ManifestInvalid, canonical_json,
    decode_manifest, manifest_digest,
)
from .tape import MAX_LINE_BYTES, ROW_KINDS, TapeError, decode_row

MAX_INPUT_FILES = 1_000
MAX_INPUT_BYTES = 1 << 30
MAX_DECODED_ROWS = 10_000_000
READ_CHUNK = 1 << 20
REPORT_SCHEMA = "leafhft.books.coverage.v1"
RECEIVE_FIELDS = {
    "q": "tr", "x": "tr", "i": "local_ns", "i5": "local_ns",
    "l": "local_ns", "f": "at_ns", "r": "eval_ns", "o": "local_ns",
}


class CoverageRefused(ValueError):
    """No success document is available for these inputs."""

    def __init__(self, code: str, detail: str):
        self.code = code
        self.detail = detail
        super().__init__(f"{code}: {detail}")


def _identity(st):
    return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def _snapshot(path):
    st = path.lstat()
    if not stat.S_ISREG(st.st_mode):
        raise CoverageRefused("input_unreadable", f"not a regular file: {path}")
    return _identity(st)


def _check(path, before, stream=None, stream_before=None):
    if _snapshot(path) != before:
        raise CoverageRefused("input_changed", f"input changed: {path}")
    if stream is not None:
        current = _identity(os.fstat(stream.fileno()))
        # Windows lstat and fstat can give ctime different meanings. Compare
        # that field only within the same API, retaining the shared identity.
        if current[:4] != before[:4] or (
            stream_before is not None and current != stream_before
        ):
            raise CoverageRefused("input_changed", f"input changed: {path}")
        return current


def _verify_source(path, before, expected):
    """Rehash bounded input, including same-size edits that restore the mtime."""
    _check(path, before)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        stream_before = _check(path, before, stream)
        remaining = before[2]
        while remaining:
            chunk = stream.read(min(READ_CHUNK, remaining))
            if not chunk:
                raise CoverageRefused("input_changed", f"input truncated: {path}")
            digest.update(chunk)
            remaining -= len(chunk)
        if stream.read(1):
            raise CoverageRefused("input_changed", f"input grew: {path}")
        _check(path, before, stream, stream_before)
    if digest.hexdigest() != expected:
        raise CoverageRefused("input_changed", f"input digest changed: {path}")
    return stream_before


def _validate_identity(row, manifest):
    if "book_id" in row and row["book_id"] != manifest.book_id:
        raise CoverageRefused("book_mismatch", "row book_id differs from manifest")
    ticker = row.get("ticker", row.get("s"))
    if ticker is not None and not ticker.startswith(manifest.series + "-"):
        raise CoverageRefused("book_mismatch", "row ticker differs from manifest series")
    if "index_id" in row and row["index_id"] != manifest.index_id:
        raise CoverageRefused("book_mismatch", "row index_id differs from manifest")
    if "v" in row and row["v"] != manifest.domain:
        raise CoverageRefused("book_mismatch", "row venue differs from manifest domain")


def coverage(manifest: BookManifest, tape_paths, *, from_ns: int, to_ns: int,
             mode: str = "report") -> dict:
    """Observe supplied tape parts once each; raise CoverageRefused on any refusal.

    All rows, including those outside the window, must decode and match the book.
    Counts and timestamp extrema describe observed rows only, not a market's
    lifetime, settlement, missing events, or continuity. An empty observation
    window has no observed row. The upper bound may be MAX_EPOCH_NS + 1 so the
    codec's last valid timestamp can be included in a half-open window.
    """
    if mode not in ("report", "conformance"):
        raise CoverageRefused("mode_invalid", "mode must be report or conformance")
    if (type(from_ns) is not int or type(to_ns) is not int
            or not MIN_EPOCH_NS <= from_ns < to_ns <= MAX_EPOCH_NS + 1):
        raise CoverageRefused("window_invalid", "require receive epoch ns: from_ns < to_ns")
    try:
        digest = manifest_digest(manifest)  # revalidates even a hand-built BookManifest
    except (ManifestInvalid, TypeError, ValueError, AttributeError) as exc:
        raise CoverageRefused("manifest_invalid", str(exc)) from None
    try:
        return _coverage(manifest, digest, tape_paths, from_ns, to_ns, mode)
    except TapeError as exc:
        raise CoverageRefused("tape_invalid", str(exc)) from None
    except OSError as exc:
        raise CoverageRefused("input_unreadable", str(exc)) from None


def _coverage(manifest, digest, tape_paths, from_ns, to_ns, mode):
    if isinstance(tape_paths, (str, bytes, os.PathLike)):
        raise CoverageRefused("input_invalid", "tape_paths must be an iterable of paths")
    try:
        tape_paths = iter(tape_paths)
    except TypeError:
        raise CoverageRefused("input_invalid", "tape_paths must be an iterable of paths") from None
    sources, names, identities = [], set(), set()
    total_bytes = 0
    for item in tape_paths:
        if len(sources) >= MAX_INPUT_FILES:
            raise CoverageRefused("limit", f"more than {MAX_INPUT_FILES} input files")
        try:
            supplied = os.fsdecode(os.fspath(item))
        except TypeError:
            raise CoverageRefused("input_invalid", "each tape path must be a filesystem path") from None
        if "\0" in supplied:
            raise CoverageRefused("input_invalid", "tape paths must not contain NUL bytes")
        # Resolve symlinks before collapsing '..': lexical normalization can
        # otherwise select a different file from the one the caller supplied.
        path = Path(os.path.realpath(supplied, strict=True))
        before = _snapshot(path)
        name = os.path.normcase(str(path))
        identity = before[:2]
        if name in names or identity in identities:
            raise CoverageRefused("duplicate_source", f"duplicate source file: {path}")
        names.add(name)
        identities.add(identity)
        total_bytes += before[2]
        if total_bytes > MAX_INPUT_BYTES:
            raise CoverageRefused("limit", f"inputs exceed {MAX_INPUT_BYTES} bytes")
        sources.append((path, before))
    if not sources:
        raise CoverageRefused("input_invalid", "at least one explicit tape path is required")

    # Import only on the conformance path; these are the consumer's actual bounds.
    if mode == "conformance":
        from .conform import MAX_COVERAGE_BYTES, MAX_DECLARED_GAPS, parse_coverage

    counts = dict.fromkeys(ROW_KINDS, 0)
    first = last = None
    rows = read_bytes = 0
    gaps, evidence = set(), []
    for path, before in sources:
        sha = hashlib.sha256()
        size = source_rows = 0
        _check(path, before)
        with path.open("rb") as stream:
            stream_before = _check(path, before, stream)
            while True:
                line = stream.readline(MAX_LINE_BYTES + 2)
                if not line:
                    break
                size += len(line)
                read_bytes += len(line)
                if size > before[2]:
                    raise CoverageRefused("input_changed", f"input grew: {path}")
                if read_bytes > MAX_INPUT_BYTES or rows >= MAX_DECODED_ROWS:
                    raise CoverageRefused("limit", "input byte or decoded row limit exceeded")
                row = decode_row(line)
                _validate_identity(row, manifest)
                sha.update(line)
                rows += 1
                source_rows += 1
                at = row[RECEIVE_FIELDS[row["t"]]]
                if from_ns <= at < to_ns:
                    counts[row["t"]] += 1
                    first = at if first is None else min(first, at)
                    last = at if last is None else max(last, at)
                    if mode == "conformance" and row["t"] == "f" and row["gap"]:
                        gaps.add(at)
                        if len(gaps) > MAX_DECLARED_GAPS:
                            raise CoverageRefused("limit", "too many declared gaps")
            _check(path, before, stream, stream_before)
        if size != before[2]:
            raise CoverageRefused("input_changed", f"input truncated: {path}")
        evidence.append({"path": str(path), "sha256": sha.hexdigest(), "bytes": size,
                         "decoded_rows": source_rows})

    verified = [_verify_source(path, before, source["sha256"])
                for (path, before), source in zip(sources, evidence)]

    if mode == "conformance":
        doc = {"schema": 1, "manifest_digest": digest,
               "gaps": [{"from_ns": at, "to_ns": at} for at in sorted(gaps)]}
        raw = canonical_json(doc) + b"\n"
        if len(raw) > MAX_COVERAGE_BYTES:
            raise CoverageRefused("limit", "conformance document exceeds byte limit")
        parse_coverage(raw, manifest)
    else:
        doc = {"schema": REPORT_SCHEMA, "manifest_digest": digest, "book_id": manifest.book_id,
               "window": {"from_ns": from_ns, "to_ns": to_ns}, "clock_domain": "epoch_ns",
               "sources": evidence,
               "observed": [] if first is None else [
                   {"rows": counts, "first_receive_ns": first, "last_receive_ns": last}]}
    # A later part's rehash may race an edit to an earlier part. On Windows
    # lstat's creation time cannot detect it; compare fstat to its own baseline.
    for (path, before), stream_before in zip(sources, verified):
        with path.open("rb") as stream:
            _check(path, before, stream, stream_before)
    return doc


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("report", "conformance"))
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--tape", required=True, action="append", type=Path)
    parser.add_argument("--from-ns", required=True, type=int)
    parser.add_argument("--to-ns", required=True, type=int)
    args = parser.parse_args(argv)
    try:
        before = _snapshot(args.manifest)
        if before[2] > MAX_MANIFEST_BYTES:
            raise CoverageRefused("manifest_invalid", "manifest exceeds byte limit")
        with args.manifest.open("rb") as stream:
            stream_before = _check(args.manifest, before, stream)
            raw = stream.read(MAX_MANIFEST_BYTES + 1)
            _check(args.manifest, before, stream, stream_before)
        manifest = decode_manifest(raw)
        doc = coverage(manifest, args.tape, from_ns=args.from_ns, to_ns=args.to_ns, mode=args.mode)
        _verify_source(args.manifest, before, hashlib.sha256(raw).hexdigest())
    except (CoverageRefused, ManifestInvalid, OSError) as exc:
        # No partial success document reaches stdout.
        print(canonical_json({"refused": {"code": getattr(exc, "code", "input_unreadable"),
                                           "detail": str(exc)}}).decode("ascii"), file=sys.stderr)
        return 2
    print(canonical_json(doc).decode("ascii"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
