"""`python -m leafhft.books conform|replay ...`: the book conformance command (B-STD B6).

Exit 0 conforms, 2 refused, 3 no verdict; one JSON object on stdout and never a traceback there,
even when the conformance module itself fails to import.
"""
from __future__ import annotations

import json
import sys


def _run() -> int:
    try:
        from .conform import main
    except Exception as exc:  # noqa: BLE001 - the exit-3 contract holds before main exists
        sys.stderr.write(f"books conform: internal: import failed: {type(exc).__name__}: {str(exc)[:500]}\n")
        sys.stdout.write(json.dumps({"error": {"code": "internal", "detail": type(exc).__name__}},
                                    sort_keys=True, separators=(",", ":")) + "\n")
        sys.stdout.flush()
        return 3
    return main()


if __name__ == "__main__":
    raise SystemExit(_run())
