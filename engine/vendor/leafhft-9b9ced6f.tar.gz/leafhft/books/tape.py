"""The book tape codec and a deterministic replay (B-STD B2, B-D13).

One JSON object per line. Encoding is canonical (sorted keys, no whitespace, ASCII) and bounded
at MAX_LINE_BYTES; decoding is strict: oversize lines, duplicate keys, floats, unknown kinds,
unknown keys and missing keys are refused with a TapeError code from TAPE_REFUSAL_CODES.

Row kinds (`t`):
  q   quote       the Recorder's shape (feeds/recorder.py)
  x   trade       the Recorder's shape
  i   index       cli.py's KalshiRecorder shape, the only index row that is a freshness input
  i5  fast index  recorder-only predictor, never a freshness input
  l   lifecycle   market status transition
  f   flag input  one kernel evaluation of one ticker in one turn (gate, gap, error, need)
  r   receipt     the FlagRecord the host derived from an `f` row
  o   outcome     a market's settlement result (yes, no or unknown), never a freshness input
Every receive-side `*_ns` stamp (q.tr, q.ta, x.tr, i.local_ns, i5.local_ns, l.local_ns, f.at_ns,
r.eval_ns, o.local_ns) is epoch ns on the receive clock, frame.CLOCK_DOMAIN; a perf_counter_ns
reading there is refused as `clock_domain`.

Optional q.tv is Kalshi's orderbook_delta ts_ms converted to ns for the last book-changing
delta, never local time. Consumers that do not know it must ignore it; replay still uses q.tr.

`replay(rows, clock)` is a pure function of the rows and a ReplayClock: it reads no wall or
monotonic clock and iterates only in tape order, so two processes with different PYTHONHASHSEED
values produce byte-equal receipts. Pure: no I/O; callers hand in bytes and take bytes back.
"""
from __future__ import annotations

import dataclasses
import re
from collections.abc import Iterable, Iterator, Mapping

from .frame import (
    MAX_DELTA_NS,
    MAX_EPOCH_NS,
    MIN_EPOCH_NS,
    ClockDomainError,
    FlagHold,
    FlagRecord,
    Frame,
    FrameInvalid,
    evaluate_flag,
)
from .manifest import BookManifest, StrictJsonError, canonical_json, legacy_manifests, strict_json_loads

MAX_LINE_BYTES = 4096  # the Recorder's line bound
MAX_TAPE_ROWS = 1_000_000
MAX_TRACKED_KEYS = 4096  # distinct tickers or index ids one replay may track
ROW_KINDS = ("q", "x", "i", "i5", "l", "f", "r", "o")
TAPE_REFUSAL_CODES = (
    "oversize", "not_json", "duplicate_key", "float_refused", "bad_type", "unknown_kind",
    "unknown_key", "missing_key", "bad_value", "clock_domain", "book_unknown", "too_many_keys",
)


class TapeError(ValueError):
    """A tape refusal; `code` is one of TAPE_REFUSAL_CODES."""

    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


# ---------------------------------------------------------------- field validators

def _int(lo: int, hi: int):
    def check(value, where):
        if type(value) is not int:
            raise TapeError("bad_type", f"{where} must be an int")
        if not lo <= value <= hi:
            raise TapeError("bad_value", f"{where} out of range [{lo}, {hi}]")
    return check


def _epoch(value, where):
    if type(value) is not int:
        raise TapeError("bad_type", f"{where} must be an int")
    if not MIN_EPOCH_NS <= value <= MAX_EPOCH_NS:
        raise TapeError("clock_domain", f"{where}={value} is not epoch ns on the receive clock")


def _text(pattern: str):
    compiled = re.compile(pattern)

    def check(value, where):
        if type(value) is not str:
            raise TapeError("bad_type", f"{where} must be a string")
        if not compiled.fullmatch(value):
            raise TapeError("bad_value", f"{where}: {value[:64]!r} is not allowed")
    return check


def _bool(value, where):
    if type(value) is not bool:
        raise TapeError("bad_type", f"{where} must be a bool")


def _choice(*choices):
    def check(value, where):
        if not any(type(value) is type(c) and value == c for c in choices):
            raise TapeError("bad_value", f"{where} must be one of {list(choices)}")
    return check


def _optional(inner):
    def check(value, where):
        if value is not None:
            inner(value, where)
    return check


_U62 = _int(0, 2**62)
_U64 = _int(0, 2**64 - 1)
_VENUE_TS = _int(0, MAX_EPOCH_NS)  # the venue's own stamp: another clock, recorded as-is
_MS = _int(0, MAX_EPOCH_NS // 1_000_000)
_CLOSE_MS = _int(MIN_EPOCH_NS // 1_000_000, MAX_EPOCH_NS // 1_000_000)
_NAME = _text(r"[\x21-\x7e]{1,64}")
_GATE = _optional(_text(r"[a-z0-9_]{1,64}"))
_INDEX = {"index_id": _NAME, "value_i": _U64, "source_ts_ms": _MS, "received_at_ms": _MS,
          "local_ns": _epoch}

# kind -> (required fields, optional fields); `t` is implied.
SCHEMAS: Mapping[str, tuple[dict, dict]] = {
    "q": ({"v": _NAME, "s": _NAME, "b": _U62, "bs": _U62, "a": _U62, "as": _U62,
           "te": _VENUE_TS, "tr": _epoch, "n": _U62},
          {"ta": _epoch, "tv": _VENUE_TS}),
    "x": ({"v": _NAME, "s": _NAME, "p": _U62, "z": _U62, "d": _choice(1, -1),
           "te": _VENUE_TS, "tr": _epoch, "n": _U62},
          {"id": _text(r"[\x20-\x7e]{1,128}")}),
    "i": (dict(_INDEX),
          {"avg60_value_i": _U64, "avg60_window_size": _U64, "avg60_window_start_ms": _U64}),
    "i5": (dict(_INDEX), {}),
    "l": ({"ticker": _NAME, "status": _text(r"[\x21-\x7e]{1,32}"), "close_time_ms": _MS,
           "expiration_time_ms": _MS, "strike_i": _U64, "local_ns": _epoch},
          {"strike_type": _text(r"[\x20-\x7e]{0,32}"), "open_time_ms": _MS}),
    "f": ({"book_id": _NAME, "ticker": _NAME, "close_ms": _CLOSE_MS, "gate": _GATE,
           "turn": _U62, "sequence": _U62, "at_ns": _epoch, "gap": _bool, "error": _bool,
           "need_ms": _optional(_int(1, 3_600_000))},
          {}),
    "r": ({"book_id": _NAME, "ticker": _NAME, "window_id": _text(r"[1-9][0-9]{0,15}"),
           "colour": _choice("green", "red"), "reason": _text(r"[a-z0-9_]{1,64}"),
           "is_final": _bool, "gate": _GATE, "turn": _U62, "sequence": _U62, "eval_ns": _epoch},
          {}),
    "o": ({"ticker": _NAME, "close_ms": _CLOSE_MS, "strike_i": _U64,
           "outcome": _choice("yes", "no", "unknown"), "local_ns": _epoch},
          {"strike_type": _text(r"[\x20-\x7e]{0,32}")}),
}
_FLAG_FIELDS = tuple(f.name for f in dataclasses.fields(FlagRecord))


# ---------------------------------------------------------------- codec

def validate_row(row) -> dict:
    """Return row when it is a well-formed tape row of a known kind; TapeError otherwise."""
    if type(row) is not dict:
        raise TapeError("bad_type", "a tape row is a JSON object")
    kind = row.get("t")
    if type(kind) is not str or kind not in SCHEMAS:
        raise TapeError("unknown_kind", f"row kind {str(kind)[:16]!r} is not one of {list(ROW_KINDS)}")
    required, optional = SCHEMAS[kind]
    keys = set(row)
    keys.discard("t")
    unknown = keys - required.keys() - optional.keys()
    if unknown:
        raise TapeError("unknown_key", f"{kind}: unknown key {sorted(map(str, unknown))[0][:64]!r}")
    missing = required.keys() - keys
    if missing:
        raise TapeError("missing_key", f"{kind}: missing key {sorted(missing)[0]!r}")
    for key, check in required.items():
        check(row[key], f"{kind}.{key}")
    for key, check in optional.items():
        if key in row:
            check(row[key], f"{kind}.{key}")
    if kind == "q" and "ta" in row and row["ta"] > row["tr"]:
        raise TapeError("bad_value", "q.ta must not exceed q.tr")
    if kind == "o" and row["local_ns"] < row["close_ms"] * 1_000_000:
        raise TapeError("bad_value", "o.local_ns is before close_ms: an outcome is never known before "
                                     "its market closes")
    if kind == "r":
        flag_from_row(row)
    return row


def encode_row(row) -> bytes:
    """Canonical bytes for one row, without the newline."""
    line = canonical_json(validate_row(row))
    if len(line) > MAX_LINE_BYTES:
        raise TapeError("oversize", f"{len(line)} bytes > {MAX_LINE_BYTES}")
    return line


def decode_row(line) -> dict:
    """Strictly decode one line (bytes or str, one trailing newline allowed)."""
    if isinstance(line, str):
        line = line.encode("utf-8")
    if not isinstance(line, (bytes, bytearray)):
        raise TapeError("bad_type", "a tape line is bytes or str")
    if line.endswith(b"\n"):
        line = line[:-1]
    if len(line) > MAX_LINE_BYTES:
        raise TapeError("oversize", f"{len(line)} bytes > {MAX_LINE_BYTES}")
    try:
        row = strict_json_loads(line)
    except StrictJsonError as exc:
        raise TapeError(exc.code, exc.detail) from None
    return validate_row(row)


def encode_tape(rows: Iterable) -> bytes:
    """Canonical tape bytes: one encoded row per line, each ending in a newline."""
    out = []
    for n, row in enumerate(rows):
        if n >= MAX_TAPE_ROWS:
            raise TapeError("oversize", f"more than {MAX_TAPE_ROWS} rows")
        out.append(encode_row(row) + b"\n")
    return b"".join(out)


def iter_tape(blob, max_rows: int = MAX_TAPE_ROWS) -> Iterator[dict]:
    """Decode tape bytes row by row; a blank line anywhere but the end is refused."""
    if not isinstance(blob, (bytes, bytearray)):
        raise TapeError("bad_type", "a tape is bytes")
    if type(max_rows) is not int or not 0 < max_rows <= MAX_TAPE_ROWS:
        raise ValueError(f"max_rows must be an int in (0, {MAX_TAPE_ROWS}]")
    if len(blob) > max_rows * (MAX_LINE_BYTES + 1):
        raise TapeError("oversize", f"tape exceeds {max_rows} rows of {MAX_LINE_BYTES} bytes")
    return _iter_lines(bytes(blob), max_rows)


def _iter_lines(blob: bytes, max_rows: int) -> Iterator[dict]:
    start = n = 0
    while start < len(blob):
        end = blob.find(b"\n", start)
        end = len(blob) if end < 0 else end
        if end == start:
            raise TapeError("bad_value", f"blank line at byte {start}")
        n += 1
        if n > max_rows:
            raise TapeError("oversize", f"more than {max_rows} rows")
        yield decode_row(blob[start:end])
        start = end + 1


def flag_row(record: FlagRecord) -> dict:
    """The `r` receipt row for a FlagRecord."""
    if not isinstance(record, FlagRecord):
        raise TypeError("flag_row expects a FlagRecord")
    row = {"t": "r"}
    for name in _FLAG_FIELDS:
        row[name] = getattr(record, name)
    return row


def flag_from_row(row) -> FlagRecord:
    """The FlagRecord an `r` row describes; its vocabulary is checked, not just its shape."""
    try:
        return FlagRecord(**{name: row[name] for name in _FLAG_FIELDS})
    except KeyError as exc:
        raise TapeError("missing_key", f"r: missing key {exc.args[0]!r}") from None
    except (FrameInvalid, ClockDomainError) as exc:
        raise TapeError("bad_value", f"r: {exc}") from None


# ---------------------------------------------------------------- replay

@dataclasses.dataclass(frozen=True, slots=True)
class ReplayClock:
    """The only clock replay reads: a flag row evaluates at its own at_ns plus lag_ns."""

    lag_ns: int = 0

    def __post_init__(self):
        if type(self.lag_ns) is not int or not 0 <= self.lag_ns <= MAX_DELTA_NS:
            raise ValueError(f"lag_ns must be an int in [0, {MAX_DELTA_NS}]")

    def at(self, at_ns: int) -> int:
        return at_ns + self.lag_ns


def _book_table(manifests) -> dict[str, BookManifest]:
    if manifests is None:
        return {m.book_id: m for m in legacy_manifests()}
    if not isinstance(manifests, Mapping):
        raise TypeError("manifests must be a mapping of book_id to BookManifest")
    table = {}
    for book_id, manifest in manifests.items():
        if not isinstance(manifest, BookManifest) or manifest.book_id != book_id:
            raise TypeError("manifests must map each book_id to its own BookManifest")
        table[book_id] = manifest
    return table


def _track(table: dict, key: str, value: int) -> None:
    if key not in table and len(table) >= MAX_TRACKED_KEYS:
        raise TapeError("too_many_keys", f"more than {MAX_TRACKED_KEYS} distinct keys")
    table[key] = value


def replay(rows: Iterable, clock: ReplayClock, *, manifests: Mapping | None = None) -> Iterator[Frame]:
    """Yield one Frame, its flag attached, per `f` row, in tape order. No wall clock inside.

    Quote rows set the ticker's quote receive time, `i` rows the index receive time; the book's
    manifest names its index. Rows may be decoded dicts or raw lines. One FlagHold per book.
    """
    if not isinstance(clock, ReplayClock):
        raise TypeError("replay needs a ReplayClock; any other callable could read the wall clock")
    return _replay(rows, clock, _book_table(manifests))


def _replay(rows, clock: ReplayClock, books: dict[str, BookManifest]) -> Iterator[Frame]:
    quote_recv: dict[str, int] = {}
    index_recv: dict[str, int] = {}
    holds: dict[str, FlagHold] = {}
    for n, raw in enumerate(rows):
        if n >= MAX_TAPE_ROWS:
            raise TapeError("oversize", f"more than {MAX_TAPE_ROWS} rows")
        row = decode_row(raw) if isinstance(raw, (bytes, bytearray, str)) else validate_row(raw)
        kind = row["t"]
        if kind == "q":
            _track(quote_recv, row["s"], row["tr"])
        elif kind == "i":
            _track(index_recv, row["index_id"], row["local_ns"])
        elif kind == "f":
            manifest = books.get(row["book_id"])
            if manifest is None:
                raise TapeError("book_unknown", f"no manifest for book {row['book_id']!r}")
            hold = holds.get(manifest.book_id)
            if hold is None:
                hold = holds[manifest.book_id] = FlagHold()
            frame = Frame(book_id=manifest.book_id, ticker=row["ticker"], close_ms=row["close_ms"],
                          now_ns=clock.at(row["at_ns"]), quote_recv_ns=quote_recv.get(row["ticker"]),
                          index_recv_ns=index_recv.get(manifest.index_id), gate=row["gate"],
                          turn=row["turn"], sequence=row["sequence"], gap=row["gap"],
                          error=row["error"])
            flag = evaluate_flag(frame, manifest, hold=hold, kernel_need_ms=row["need_ms"])
            yield dataclasses.replace(frame, flag=flag)


def replay_receipt(rows: Iterable, clock: ReplayClock, *, manifests: Mapping | None = None) -> bytes:
    """The canonical `r` rows of a replay: byte-equal for equal tape and clock in any process."""
    return encode_tape(flag_row(frame.flag) for frame in replay(rows, clock, manifests=manifests))
