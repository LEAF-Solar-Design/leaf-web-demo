"""Tap: one stamp per event and a non-blocking write into a bounded ring, drained to a local
socket by a drainer thread (B-STD B7; B-D4, B-D9 hop tap_emit and tap_to_observer).

Contract, emit (the book's event loop): with no consumer attached, emit returns before reading
the clock, so an un-opted book pays one attribute test and makes zero syscalls; no ring exists
until the first attach. Attached, emit is one clock read (epoch ns, the tap_to_observer start
stamp), four index assignments into preallocated lists and one index bump: no I/O, no lock, no
await, no container growth. A full ring DROPS the event and counts it (`dropped`); emit never
blocks and never raises into the caller.

Contract, drainer (its own daemon thread): polls the ring every `poll_s`, encodes a bounded batch
as `book_tap.v1` lines and hands it to the sink. Every sink or encode failure is counted
(`sink_errors`, `sink_dropped`, `malformed`, `drain_errors`) and swallowed: the drainer never
raises into the caller, and a stalled sink only fills the ring, which then drops.

Single producer (the thread that calls emit, attach and detach), single consumer (the drainer).
Each ring index is written by exactly one side, which is safe under the GIL of the default CPython
build; a free-threaded build is out of contract.

Wire `book_tap.v1`: one line per event, `<stamp_ns>\\t<kind>\\t<key>\\t<value>\\n`, ASCII, where kind
matches [a-z0-9_]{1,16}, key matches [A-Za-z0-9_.:/-]{1,64} and value is a signed 64-bit int.

Sinks: UnixSocketSink (the runner) and NamedPipeSink (the Windows dev host) behind
open_local_sink; tests use an in-process fake. Nothing wires the tap yet (B8 owns cli.py).
"""
from __future__ import annotations

import os
import re
import socket
import threading
import time
from typing import NamedTuple

WIRE = "book_tap.v1"
DEFAULT_CAPACITY = 4096
MIN_CAPACITY = 16
MAX_CAPACITY = 1 << 20
DEFAULT_POLL_S = 0.002
DEFAULT_JOIN_TIMEOUT_S = 2.0
MAX_LINE = 128
_INT64 = 1 << 63

_KIND = re.compile(r"[a-z0-9_]{1,16}")
_KEY = re.compile(r"[A-Za-z0-9_.:/-]{1,64}")


class TapError(ValueError):
    """A refused tap configuration, a second attach, or a malformed wire line."""


class TapEvent(NamedTuple):
    stamp_ns: int
    kind: str
    key: str
    value: int


def encode_event(stamp_ns: object, kind: object, key: object, value: object) -> bytes | None:
    """One `book_tap.v1` line, or None when any field is malformed (fails closed, never raises)."""
    if type(stamp_ns) is not int or not 0 <= stamp_ns < _INT64:
        return None
    if type(value) is not int or not -_INT64 <= value < _INT64:
        return None
    if type(kind) is not str or _KIND.fullmatch(kind) is None:
        return None
    if type(key) is not str or _KEY.fullmatch(key) is None:
        return None
    return b"%d\t%s\t%s\t%d\n" % (stamp_ns, kind.encode("ascii"), key.encode("ascii"), value)


def decode_event(line: bytes) -> TapEvent:
    """Strict inverse of encode_event; raises TapError on anything else."""
    if type(line) is not bytes or len(line) > MAX_LINE or not line.endswith(b"\n"):
        raise TapError("malformed_line: not one bounded newline-terminated line")
    try:
        text = line[:-1].decode("ascii")
    except UnicodeDecodeError as exc:
        raise TapError("malformed_line: not ascii") from exc
    parts = text.split("\t")
    if len(parts) != 4:
        raise TapError("malformed_line: expected four fields")
    stamp_s, kind, key, value_s = parts
    if not re.fullmatch(r"[0-9]{1,19}", stamp_s) or not re.fullmatch(r"-?[0-9]{1,19}", value_s):
        raise TapError("malformed_line: bad integer field")
    stamp, value = int(stamp_s), int(value_s)
    if encode_event(stamp, kind, key, value) != line:
        raise TapError("malformed_line: not canonical")
    return TapEvent(stamp, kind, key, value)


class Tap:
    """Bounded SPSC ring from the book loop to a local sink. emit never blocks, never raises, and
    is a no-op without a consumer."""

    __slots__ = (
        "_sink", "_clock", "_cap", "_mask", "_poll_s", "_batch", "_join_s",
        "_stamps", "_kinds", "_keys", "_values", "_head", "_tail",
        "_dropped", "_sent", "_sink_errors", "_sink_dropped", "_malformed", "_drain_errors",
        "_thread", "_stop",
    )

    def __init__(self, capacity: int = DEFAULT_CAPACITY, *, clock=time.time_ns,
                 poll_s: float = DEFAULT_POLL_S, batch: int | None = None,
                 join_timeout_s: float = DEFAULT_JOIN_TIMEOUT_S):
        if (type(capacity) is not int or not MIN_CAPACITY <= capacity <= MAX_CAPACITY
                or capacity & (capacity - 1)):
            raise TapError(f"capacity must be a power of two in [{MIN_CAPACITY}, {MAX_CAPACITY}]")
        if batch is None:  # default: 512 events per send, clamped to a small ring
            batch = min(512, capacity)
        if not callable(clock):
            raise TapError("clock must be callable")
        if type(poll_s) not in (int, float) or not 0 < poll_s <= 1:
            raise TapError("poll_s must be in (0, 1]")
        if type(batch) is not int or not 1 <= batch <= capacity:
            raise TapError("batch must be in [1, capacity]")
        if type(join_timeout_s) not in (int, float) or not 0 < join_timeout_s <= 60:
            raise TapError("join_timeout_s must be in (0, 60]")
        self._sink = None
        self._clock = clock
        self._cap = capacity
        self._mask = capacity - 1
        self._poll_s = float(poll_s)
        self._batch = batch
        self._join_s = float(join_timeout_s)
        self._stamps = None
        self._kinds = None
        self._keys = None
        self._values = None
        self._head = 0
        self._tail = 0
        self._dropped = 0
        self._sent = 0
        self._sink_errors = 0
        self._sink_dropped = 0
        self._malformed = 0
        self._drain_errors = 0
        self._thread = None
        self._stop = None

    # -- the caller's path -------------------------------------------------------------------

    def emit(self, kind: str, key: str, value: int) -> bool:
        """Stamp one event and queue it. False when no consumer is attached (no clock read, no
        syscall) or the ring is full (dropped and counted). No I/O, lock, await or growth."""
        if self._sink is None:
            return False
        h = self._head
        if h - self._tail >= self._cap:
            self._dropped += 1
            return False
        i = h & self._mask
        self._stamps[i] = self._clock()
        self._kinds[i] = kind
        self._keys[i] = key
        self._values[i] = value
        self._head = h + 1
        return True

    @property
    def attached(self) -> bool:
        return self._sink is not None

    @property
    def dropped(self) -> int:
        return self._dropped

    def attach(self, sink) -> None:
        """Allocate the ring (first time only), start the drainer, then publish the sink so emit
        begins writing only once a consumer exists. Called from the producer's thread."""
        if self._sink is not None:
            raise TapError("already_attached")
        if self._thread is not None and self._thread.is_alive():
            raise TapError("previous_drainer_alive: a stalled sink never returned; refusing a second consumer")
        write = getattr(sink, "write", None)
        if not callable(write):
            raise TapError("sink must have a callable write(bytes)")
        if self._stamps is None:
            self._stamps = [0] * self._cap
            self._kinds = [None] * self._cap
            self._keys = [None] * self._cap
            self._values = [None] * self._cap
        self._head = 0
        self._tail = 0
        stop = threading.Event()
        thread = threading.Thread(target=self._drain_loop, args=(sink, stop),
                                  name="leafhft-tap-drainer", daemon=True)
        self._stop = stop
        self._thread = thread
        thread.start()
        self._sink = sink

    def detach(self) -> bool:
        """Stop emitting, let the drainer flush and close the sink. True when the drainer exited
        within the join timeout; False leaves a stalled daemon drainer that blocks re-attach."""
        if self._sink is None:
            return self._thread is None or not self._thread.is_alive()
        self._sink = None
        self._stop.set()
        self._thread.join(self._join_s)
        return not self._thread.is_alive()

    def stats(self) -> dict:
        return {
            "wire": WIRE, "attached": self._sink is not None, "capacity": self._cap,
            "emitted": self._head, "pending": self._head - self._tail, "dropped": self._dropped,
            "sent": self._sent, "sink_errors": self._sink_errors, "sink_dropped": self._sink_dropped,
            "malformed": self._malformed, "drain_errors": self._drain_errors,
        }

    # -- the drainer thread ------------------------------------------------------------------

    def _drain_loop(self, sink, stop: threading.Event) -> None:
        try:
            while True:
                stopping = stop.wait(self._poll_s)
                try:
                    while self._drain_batch(sink):
                        pass
                except Exception:
                    self._drain_errors += 1
                if stopping:
                    break
        except Exception:
            self._drain_errors += 1
        finally:
            try:
                close = getattr(sink, "close", None)
                if callable(close):
                    close()
            except Exception:
                self._sink_errors += 1

    def _drain_batch(self, sink) -> bool:
        """Encode and send at most one batch; True when a full batch went and more may wait."""
        t = self._tail
        n = self._head - t
        if n <= 0:
            return False
        if n > self._batch:
            n = self._batch
        mask = self._mask
        stamps, kinds, keys, values = self._stamps, self._kinds, self._keys, self._values
        parts = []
        for j in range(t, t + n):
            i = j & mask
            line = encode_event(stamps[i], kinds[i], keys[i], values[i])
            kinds[i] = None
            keys[i] = None
            values[i] = None
            if line is None:
                self._malformed += 1
            else:
                parts.append(line)
        self._tail = t + n
        if parts:
            try:
                sink.write(b"".join(parts))
                self._sent += len(parts)
            except Exception:
                self._sink_errors += 1
                self._sink_dropped += len(parts)
        return n == self._batch


class UnixSocketSink:
    """Stream to a local Unix socket (the runner). Blocking I/O, drainer thread only, bounded by a timeout."""

    def __init__(self, path: str, timeout_s: float = 1.0):
        family = getattr(socket, "AF_UNIX", None)
        if family is None:
            raise TapError("AF_UNIX is unavailable on this host")
        sock = socket.socket(family, socket.SOCK_STREAM)
        try:
            sock.settimeout(timeout_s)
            sock.connect(path)
        except Exception:
            sock.close()
            raise
        self._sock = sock

    def write(self, data: bytes) -> None:
        self._sock.sendall(data)

    def close(self) -> None:
        self._sock.close()


class NamedPipeSink:
    """Write to a Windows named pipe (the dev host), e.g. \\\\.\\pipe\\leafhft-tap. Drainer thread only."""

    def __init__(self, path: str):
        self._fh = open(path, "wb", buffering=0)

    def write(self, data: bytes) -> None:
        self._fh.write(data)

    def close(self) -> None:
        self._fh.close()


def open_local_sink(address: str):
    """The platform's local transport: a named pipe on Windows, a Unix socket elsewhere."""
    if type(address) is not str or not address or len(address) > 256:
        raise TapError("address must be a non-empty path of at most 256 characters")
    if os.name == "nt":
        return NamedPipeSink(address)
    return UnixSocketSink(address)
