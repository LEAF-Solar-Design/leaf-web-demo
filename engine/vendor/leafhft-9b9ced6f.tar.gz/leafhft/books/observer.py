"""SH4 live-data observation core. The process wrapper owns transport and persistence.

Call on_event for a decoded book event, then turn with the current epoch clock.
None is an explicit feed-gap notification. No lifecycle status implies a result.
The adapter and FlagHost allocate temporary records; retained telemetry is bounded.
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import replace
from types import SimpleNamespace

from leafhft.books.latency import HOP_INDEX, HopMeter
from leafhft.books.manifest import BookManifest, legacy_manifests, manifest_from_dict
from leafhft.engines import EngineRegistry
from leafhft.feeds.base import IndexTick, Lifecycle
from leafhft.lanes.base import DecisionFrame
from leafhft.lanes.flags import (
    FLAG_CONTRACT_VERSION, GREEN, MAX_FLAGS, FlagHost, MarketStamp, epoch_stamp,
    flag_contract_sha12, inputs_as_of_ns,
)
from leafhft.lanes.kalshi_edge_entry import KalshiEdgeSignal, STALE_NS
from leafhft.policy import policy_digest
from leafhft.strategy.settlement import fee_per_contract
from leafhft.types import Quote

MAX_ENGINES = 16
MAX_BOOKS = 15
CAPACITY = 4096
_SIGNAL_STEP = HOP_INDEX["signal_step"]
_CLOSED = frozenset(("closed", "settled", "determined", "finalized"))


class _ReceiveRing:
    def __init__(self):
        self.values = [0] * CAPACITY
        self.n = self.pos = self.missing = 0

    def record(self, recv_ns, computed_ns):
        if (epoch_stamp(recv_ns) is None or epoch_stamp(computed_ns) is None
                or recv_ns > computed_ns):
            self.missing += 1
            return
        self.values[self.pos] = computed_ns - recv_ns
        self.pos = (self.pos + 1) % CAPACITY
        self.n += 1

    def snapshot(self):
        n = min(self.n, CAPACITY)
        ordered = sorted(self.values[:n])
        return {"n": n, "missing": self.missing,
                "p50": ordered[(n * 50 + 99) // 100 - 1] if n else None,
                "p90": ordered[(n * 90 + 99) // 100 - 1] if n else None,
                "p99": ordered[(n * 99 + 99) // 100 - 1] if n else None,
                "max": ordered[-1] if n else None}


class _Engine:
    def __init__(self, engine_id):
        self.engine_id = engine_id
        self.pairs = []
        self.pending = deque(maxlen=CAPACITY)
        self.admissions = deque(maxlen=CAPACITY)
        self.dropped = 0
        self.counterfactual_dropped = 0
        self.meter = HopMeter()
        self.receive = _ReceiveRing()

    def emit(self, row):
        if len(self.pending) == CAPACITY:
            self.dropped += 1
        self.pending.append(row)


class _Pair:
    def __init__(self, engine, manifest, engines_dir, digest):
        self.engine = engine
        self.manifest = manifest
        self.kernel = KalshiEdgeSignal({"policy_engine_id": engine.engine_id,
                                       "policy_digest": digest})
        self.kernel.initialize(SimpleNamespace(
            engines_dir=engines_dir, symbol=manifest.symbol,
            family=manifest.integration.family, series=(manifest.series,),
            balance_cents=10_000))
        self.host = FlagHost(self.kernel, book_id=manifest.book_id,
                             engine_id=engine.engine_id,
                             manifest_flag_quote_age_ms=manifest.flag_quote_age_ms,
                             kernel_need_ms=STALE_NS // 1_000_000)
        self.windows = {}
        self.symbols = set()
        self.first_ns = self.last_ns = None
        self.windows_evaluated = 0
        self.kernel_ns = None
        self.recv_ns = None

    def window(self, window_id):
        result = self.windows.get(window_id)
        if result is None:
            # Match the signal adapter's four retained windows.
            if len(self.windows) == 4:
                del self.windows[next(iter(self.windows))]
            result = self.windows[window_id] = {}
            self.windows_evaluated += 1
        return result


class _Book:
    def __init__(self, manifest):
        self.manifest = manifest
        self.pairs = []
        self.markets = {}
        self.index_recv_ns = None
        self.sequence = 0
        self.stamps = {}
        self.frames = []


class Observer:
    """One signal and flag host per engine/book, with no execution capability.

    books accepts manifests, manifest dictionaries, or legacy symbols/book ids.
    turn drains bounded pending rows; status returns detached read-only data.
    """

    def __init__(self, watch, *, books, engines_dir,
                 clock_ns=time.time_ns, mono_ns=time.monotonic_ns):
        self._clock_ns = clock_ns
        self._mono_ns = mono_ns
        self._engines_dir = engines_dir
        self._engines = {}
        self._books = {}
        self._refused = deque(maxlen=128)
        self._pin = flag_contract_sha12()
        legacy = None
        for value in books:
            if len(self._books) == MAX_BOOKS:
                raise ValueError("at most 15 books")
            if isinstance(value, BookManifest):
                manifest = manifest_from_dict(value.to_dict())
            elif isinstance(value, dict):
                manifest = manifest_from_dict(value)
            elif isinstance(value, str):
                if legacy is None:
                    legacy = {m.symbol: m for m in legacy_manifests()}
                symbol = value.removeprefix("kalshi-book:")
                if symbol not in legacy:
                    raise ValueError("unknown book")
                manifest = legacy[symbol]
            else:
                raise ValueError("invalid book")
            if manifest.symbol in self._books:
                raise ValueError("duplicate book")
            self._books[manifest.symbol] = _Book(manifest)
        for engine_id in watch:
            self.watch(engine_id)

    def watch(self, engine_id):
        """Add only this engine; a refusal leaves every existing kernel intact."""
        reason = None
        if type(engine_id) is not str:
            reason = "invalid_engine_id"
        elif engine_id in self._engines:
            reason = "duplicate_engine"
        elif len(self._engines) >= MAX_ENGINES:
            reason = "engine_limit"
        else:
            try:
                catalog = EngineRegistry(self._engines_dir).get(engine_id)
                if catalog.policy.reversal_mult != 0:
                    reason = "reversal_engine"
                else:
                    engine = _Engine(engine_id)
                    digest = policy_digest(catalog.policy)
                    for book in self._books.values():
                        engine.pairs.append(_Pair(engine, book.manifest, self._engines_dir, digest))
            except (ValueError, OSError, TypeError) as exc:
                reason = "invalid_or_unknown_engine:" + type(exc).__name__
        if reason is not None:
            self._refused.append({"engine_id": engine_id if type(engine_id) is str else None,
                                  "reason": reason})
            return False
        self._engines[engine_id] = engine
        for pair in engine.pairs:
            self._books[pair.manifest.symbol].pairs.append(pair)
        return True

    def unwatch(self, engine_id):
        engine = self._engines.pop(engine_id, None)
        if engine is None:
            return False
        for pair in engine.pairs:
            self._books[pair.manifest.symbol].pairs.remove(pair)
        return True

    def on_event(self, symbol, ev, recv_ns):
        book = self._books.get(symbol.removeprefix("kalshi-book:"))
        if book is None:
            return
        now_ns = recv_ns if epoch_stamp(recv_ns) is not None else self._clock_ns()
        gap = ev is None or getattr(ev, "gap", False) is True
        # The caller's receive stamp is authoritative, including when replayed late.
        if isinstance(ev, IndexTick):
            if ev.index_id != book.manifest.index_id:
                return
            book.index_recv_ns = recv_ns
            if epoch_stamp(recv_ns) is not None and ev.local_ns != recv_ns:
                ev = replace(ev, local_ns=recv_ns)
        elif isinstance(ev, Lifecycle):
            close = ev.close_time_ms or ev.expiration_time_ms
            if close > 0:
                market = book.markets.get(ev.ticker)
                if market is None or market[0] != close:
                    if len(book.markets) >= 64:
                        del book.markets[next(iter(book.markets))]
                    # window, strike, quote receipt, closed
                    market = book.markets[ev.ticker] = [close, ev.strike_i, None, False]
                market[1] = ev.strike_i
                market[3] = ev.status in _CLOSED
        elif isinstance(ev, Quote):
            market = book.markets.get(ev.symbol)
            if market is not None:
                market[2] = recv_ns
            if epoch_stamp(recv_ns) is not None and ev.ts_recv_ns != recv_ns:
                ev = replace(ev, ts_recv_ns=recv_ns)
        book.sequence += 1
        # Frames are book-owned and shared across engines. The adapter reads its
        # own feed state, so quote/index payload copies are unnecessary here.
        frames = book.frames
        frames.clear()
        for ticker, market in book.markets.items():
            if market[3] or market[0] * 1_000_000 <= now_ns:
                continue
            frames.append(DecisionFrame(
                opportunity_id=f"{book.sequence}:{ticker}"[:96], now_ns=now_ns,
                cutoff_ns=now_ns, close_ms=market[0], ticker=ticker,
                symbol=book.manifest.symbol, strike_i=market[1],
                side_candidates=(True, False), quote=None, index=None, history=(),
                positions=(), reserved_cents=0, sequence=book.sequence, gap=gap))
        for pair in book.pairs:
            pair.recv_ns = recv_ns
            if pair.first_ns is None:
                pair.first_ns = recv_ns
            pair.last_ns = recv_ns
            started = self._mono_ns()
            error = False
            try:
                if not gap:
                    try:
                        pair.kernel.on_event(ev, now_ns)
                    except Exception:
                        error = True
                for frame in frames:
                    window = pair.window(frame.close_ms)
                    state = window.get(frame.ticker)
                    if state is None:
                        if len(window) >= MAX_FLAGS:
                            error = True
                            continue
                        # previous colour, admitted, last intent price
                        state = window[frame.ticker] = [None, False, None]
                        pair.symbols.add(frame.ticker)
                    state[2] = None
                    for _at, intent in pair.kernel._entry.pending:
                        if intent.ticker == frame.ticker:
                            state[2] = intent.price_cents
                    pair.host.observe(frame)
                    if pair.host.hold.reason == "kernel_error":
                        error = True
            except Exception:
                error = True
            ended = self._mono_ns()
            pair.kernel_ns = ended - started
            pair.engine.meter.record(_SIGNAL_STEP, pair.kernel_ns, ended)
            # A later frame in this event must not clear an earlier frame's fault.
            if error or gap:
                pair.host.hold.turn(gap=gap, error=error)

    def turn(self, now_ns):
        rows = []
        # Freshness inputs belong to the book, not the engine. Build each
        # window's map once per turn and share it across all its FlagHosts.
        for book in self._books.values():
            for market in book.stamps.values():
                market.clear()
            for ticker, tracked in book.markets.items():
                market = book.stamps.get(tracked[0])
                if market is None:
                    market = book.stamps[tracked[0]] = {}
                market[ticker] = MarketStamp(tracked[2], book.index_recv_ns)
            for window_id in tuple(book.stamps):
                if not book.stamps[window_id]:
                    del book.stamps[window_id]
        for engine in self._engines.values():
            for pair in engine.pairs:
                book = self._books[pair.manifest.symbol]
                for window_id, states in pair.windows.items():
                    market = book.stamps.get(window_id)
                    if market is None:
                        # A corrected or evicted market still has a retained
                        # snapshot; missing receipts must fail freshness.
                        market = {ticker: MarketStamp(None, book.index_recv_ns)
                                  for ticker in states}
                    # The required adapter sorts tickers inside its flags();
                    # observer traversal itself preserves enrollment order.
                    for flag in pair.host.flags(window_id, now_ns, market):
                        state = states.get(flag.ticker)
                        if state is None or state[0] == flag.colour:
                            continue
                        state[0] = flag.colour
                        stamp = market.get(flag.ticker)
                        if stamp is None:
                            stamp = MarketStamp(None, book.index_recv_ns)
                        row = {"schema": "FlagV1", "contract_version": FLAG_CONTRACT_VERSION,
                               "flag_contract_sha12": self._pin, "engine_id": engine.engine_id,
                               "book_id": pair.manifest.book_id,
                               "feed_id": pair.manifest.feeds[0].feed_id, "ticker": flag.ticker,
                               "window_id": window_id, "color": flag.colour, "reason": flag.reason,
                               "side_yes": flag.side_yes,
                               "limit_price_cents": state[2] if flag.colour == GREEN else None,
                               "inputs_as_of_ns": inputs_as_of_ns(stamp.quote_recv_ns, stamp.index_recv_ns),
                               "computed_ns": now_ns, "kernel_ns": pair.kernel_ns,
                               "kind": "flag", "source": "live"}
                        engine.emit(row)
                        engine.receive.record(pair.recv_ns, now_ns)
                        if flag.colour == GREEN and not state[1]:
                            state[1] = True
                            admission = dict(row, kind="would_admit",
                                             counterfactual={"state": "unsettled", "pnl_cents": None})
                            engine.emit(admission)
                            if len(engine.admissions) == CAPACITY:
                                engine.counterfactual_dropped += 1
                            engine.admissions.append(dict(
                                admission, counterfactual=dict(admission["counterfactual"])))
            rows.extend(engine.pending)
            engine.pending.clear()
        return rows

    def on_settlement(self, ticker, result_yes: bool, at_ns):
        """Score only an explicit market result, once per admission, for count one."""
        if type(result_yes) is not bool or epoch_stamp(at_ns) is None:
            raise ValueError("settlement requires a boolean result and an epoch stamp")
        for engine in self._engines.values():
            for row in engine.admissions:
                score = row["counterfactual"]
                if (row["ticker"] != ticker or score["state"] != "unsettled"
                        or at_ns < row["window_id"] * 1_000_000):
                    continue
                price = row["limit_price_cents"]
                if price is None:
                    continue
                fee = fee_per_contract(price)
                score.update(state="settled", result_yes=result_yes, at_ns=at_ns,
                             fee_cents=fee,
                             pnl_cents=(100 if row["side_yes"] == result_yes else 0) - price - fee)

    def status(self):
        rows = []
        now = self._mono_ns()
        for engine in self._engines.values():
            hop = engine.meter.snapshot(now)["hops"]["signal_step"]
            signal = {key: hop[key] for key in ("n", "p50", "p90", "p99", "max", "missing")}
            receive = engine.receive.snapshot()
            for pair in engine.pairs:
                admissions = [dict(row, counterfactual=dict(row["counterfactual"]))
                              for row in engine.admissions if row["book_id"] == pair.manifest.book_id]
                rows.append({"engine_id": engine.engine_id, "book_id": pair.manifest.book_id,
                             "source": "live", "signal_step": dict(signal),
                             "receive_to_flag": dict(receive), "dropped": engine.dropped,
                             "opportunity_set": {"symbols_seen": len(pair.symbols),
                                                 "first_event_ns": pair.first_ns,
                                                 "last_event_ns": pair.last_ns,
                                                 "windows_evaluated": pair.windows_evaluated},
                             "counterfactual": {"rows": admissions,
                                                "dropped": engine.counterfactual_dropped}})
        return {"watch": {"active": list(self._engines),
                          "refused": [dict(row) for row in self._refused]}, "rows": rows}


if __name__ == "__main__":
    from leafhft.books.replay_observer import main

    raise SystemExit(main())
