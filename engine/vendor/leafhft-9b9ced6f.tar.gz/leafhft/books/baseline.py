"""Offline recorded wakeup-lag evidence for the books Watch/execution prerequisite.

Identity is a recorded producer claim, not deployment attestation. Headroom only
describes these rolling windows against the caller's limit, never live authority.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import tempfile


CAPTURE_LIMIT = 16 * 1024 * 1024
RECEIPT_LIMIT = 65_536
MAX_DURATION_US = (2**63 - 1) // 1000
CAPTURE_SCHEMA = "leafhft.books.baseline.capture.v1"
RECEIPT_SCHEMA = "leafhft.books.baseline.v1"
_DURATIONS = ("p50_us", "p95_us", "p99_us", "max_us")
_METRICS = ("samples", "gaps", *_DURATIONS)
_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


def _integer(value, low, high=None, code="invalid_integer"):
    if type(value) is not int or value < low or (high is not None and value > high):
        raise ValueError(code)
    return value


def _symbol(book_id):
    if type(book_id) is not str or re.fullmatch(r"kalshi-book:[A-Z0-9]{1,16}-(15M|1H)", book_id) is None:
        raise ValueError("invalid_book")
    return book_id.split(":", 1)[1]


def _timestamp(value, *, milliseconds=False):
    if type(value) is not str:
        raise ValueError("invalid_timestamp")
    match = re.fullmatch(
        r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}"
        r"(?:\.([0-9]+))?(?:Z|[+-][0-9]{2}:[0-9]{2})", value
    )
    if match is None:
        raise ValueError("invalid_timestamp")
    fraction = match.group(1) or ""
    if any(char != "0" for char in fraction[3 if milliseconds else 6:]):
        raise ValueError("timestamp_precision")
    try:
        instant = datetime.fromisoformat(value.replace("Z", "+00:00"))
        delta = instant.astimezone(timezone.utc) - _EPOCH
    except (ValueError, OverflowError):
        raise ValueError("invalid_timestamp") from None
    micros = (delta.days * 86400 + delta.seconds) * 1_000_000 + delta.microseconds
    return micros // 1000 if milliseconds else micros


def _microseconds(value):
    if type(value) not in (int, Decimal):
        raise ValueError("invalid_duration")
    value = Decimal(value)
    if not value.is_finite() or value < 0 or value > Decimal("9223372036854.775"):
        raise ValueError("invalid_duration")
    if not value:
        return 0
    # Work on decimal digits, without the ambient Decimal context rounding them.
    _, digits, exponent = value.as_tuple()
    digits = list(digits)
    while digits[-1] == 0:
        digits.pop()
        exponent += 1
    exponent += 3
    if exponent < 0:
        raise ValueError("duration_precision")
    return int("".join(map(str, digits))) * 10**exponent


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("invalid_json")
        result[key] = value
    return result


def _constant(_value):
    raise ValueError("invalid_json")


def _window(at_ms, block):
    if block is None:
        return {"at_ms": at_ms, **dict.fromkeys(_METRICS)}
    if type(block) is not dict:
        raise ValueError("invalid_meter")
    _integer(block.get("schema"), 1, 1, "invalid_meter")
    _integer(block.get("window_s"), 60, 60, "invalid_meter")
    samples = _integer(block.get("samples"), 100, 4096, "invalid_meter")
    gaps = _integer(block.get("gaps"), 0, samples, "invalid_meter")
    values = [_microseconds(block.get(key.replace("_us", "_ms"))) for key in _DURATIONS]
    if values != sorted(values):
        raise ValueError("invalid_quantiles")
    return {"at_ms": at_ms, "samples": samples, "gaps": gaps, **dict(zip(_DURATIONS, values))}


def _assemble(book_id, source, limit, windows, events_delta):
    first, last = windows[0]["at_ms"], windows[-1]["at_ms"]
    reasons = []
    if len(windows) < 2 or last - first < 60_000:
        reasons.append("insufficient_span")
    if any(b["at_ms"] - a["at_ms"] > 60_000 for a, b in zip(windows, windows[1:])):
        reasons.append("capture_gap")
    if events_delta == 0:
        reasons.append("no_events")
    measured = [window for window in windows if window["samples"] is not None]
    complete = len(measured) == len(windows)
    if not complete:
        reasons.append("loop_lag_missing")
    if any(window["gaps"] for window in measured):
        reasons.append("loop_lag_gaps")
    if any(window["p99_us"] > limit for window in measured):
        reasons.append("p99_over_limit")
    return {
        "schema": RECEIPT_SCHEMA, "book_id": book_id, "source": source,
        "policy": {"max_p99_us": limit, "basis": "explicit_offline_limit_not_live_authority"},
        "observation": {"first_at_ms": first, "last_at_ms": last, "span_ms": last - first,
                        "status_count": len(windows), "events_delta": events_delta,
                        "aggregation": "max_window_p99", "clock": "perf_counter_ns", "window_s": 60},
        "windows": windows,
        "wakeup_lag_p99_us": max(w["p99_us"] for w in measured) if complete else None,
        "headroom": not reasons, "reasons": sorted(reasons),
    }


def _json_bytes(value):
    def check(item):
        if type(item) is dict:
            for key, child in item.items():
                if type(key) is not str:
                    raise ValueError("invalid_receipt")
                check(child)
        elif type(item) is list:
            for child in item:
                check(child)
        elif item is not None and type(item) not in (str, int, bool):
            raise ValueError("invalid_receipt")

    try:
        check(value)
        data = (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                           allow_nan=False) + "\n").encode("ascii")
    except (TypeError, ValueError, RecursionError):
        raise ValueError("invalid_receipt") from None
    if len(data) > RECEIPT_LIMIT:
        raise ValueError("receipt_too_large")
    return data


def build_baseline_receipt(capture_bytes: bytes, *, book_id: str, max_p99_us: int) -> dict:
    """Validate saved live statuses and summarize their maximum window p99."""
    symbol = _symbol(book_id)
    limit = _integer(max_p99_us, 1, 20_000, "invalid_policy")
    if type(capture_bytes) is not bytes:
        raise ValueError("invalid_capture")
    if len(capture_bytes) > CAPTURE_LIMIT:
        raise ValueError("capture_too_large")
    try:
        capture = json.loads(capture_bytes.decode("utf-8"), object_pairs_hook=_pairs,
                             parse_float=Decimal, parse_constant=_constant)
    except (ValueError, InvalidOperation, OverflowError, RecursionError):
        raise ValueError("invalid_json") from None
    if (type(capture) is not dict or set(capture) != {"schema", "book_id", "statuses"}
            or capture["schema"] != CAPTURE_SCHEMA):
        raise ValueError("invalid_capture")
    if capture["book_id"] != book_id:
        raise ValueError("book_mismatch")
    statuses = capture["statuses"]
    if type(statuses) is not list or not 1 <= len(statuses) <= 128:
        raise ValueError("invalid_status_count")
    windows, counters, identity = [], [], None
    for status in statuses:
        if type(status) is not dict or type(status.get("build")) is not dict:
            raise ValueError("invalid_status")
        build = status["build"]
        sha = build.get("git_sha")
        if (type(sha) is not str or re.fullmatch(r"[0-9a-f]{40}", sha) is None
                or build.get("dirty") is not False
                or build.get("unit") != f"leafhft-live@kalshi-{symbol}.service"):
            raise ValueError("invalid_identity")
        pid = _integer(build.get("pid"), 1, code="invalid_identity")
        started = _timestamp(build.get("started_at"))
        current = (sha, build["unit"], pid, started)
        if identity is not None and current != identity:
            raise ValueError("identity_changed")
        identity = current
        at_ms = _timestamp(status.get("generated_at"), milliseconds=True)
        if at_ms * 1000 < started:
            raise ValueError("observation_before_start")
        if windows and at_ms <= windows[-1]["at_ms"]:
            raise ValueError("timestamp_order")
        events = _integer(status.get("events_seen"), 0, code="invalid_events")
        if counters and events < counters[-1]:
            raise ValueError("events_order")
        counters.append(events)
        windows.append(_window(at_ms, status.get("loop_lag")))
    source = {"capture_sha256": hashlib.sha256(capture_bytes).hexdigest(),
              "producer_git_sha": identity[0], "unit": identity[1], "pid": identity[2],
              "started_at_us": identity[3], "metric": "status.loop_lag"}
    receipt = _assemble(book_id, source, limit, windows, counters[-1] - counters[0])
    _json_bytes(receipt)
    return receipt


def _validated_bytes(receipt):
    """Recheck the public writer's argument before it can create a file."""
    data = _json_bytes(receipt)
    try:
        symbol = _symbol(receipt["book_id"])
        source = receipt["source"]
        if (set(source) != {"capture_sha256", "producer_git_sha", "unit", "pid", "started_at_us", "metric"}
                or re.fullmatch(r"[0-9a-f]{64}", source["capture_sha256"]) is None
                or re.fullmatch(r"[0-9a-f]{40}", source["producer_git_sha"]) is None
                or source["unit"] != f"leafhft-live@kalshi-{symbol}.service"
                or source["metric"] != "status.loop_lag"
                or type(source["started_at_us"]) is not int):
            raise ValueError("invalid_receipt")
        _integer(source["pid"], 1)
        limit = _integer(receipt["policy"]["max_p99_us"], 1, 20_000)
        windows = receipt["windows"]
        if type(windows) is not list or not 1 <= len(windows) <= 128:
            raise ValueError("invalid_receipt")
        previous = None
        for window in windows:
            if set(window) != {"at_ms", *_METRICS} or type(window["at_ms"]) is not int:
                raise ValueError("invalid_receipt")
            at_ms = window["at_ms"]
            if at_ms * 1000 < source["started_at_us"] or (previous is not None and at_ms <= previous):
                raise ValueError("invalid_receipt")
            previous = at_ms
            if window["samples"] is None:
                if any(window[key] is not None for key in _METRICS):
                    raise ValueError("invalid_receipt")
            else:
                samples = _integer(window["samples"], 100, 4096)
                _integer(window["gaps"], 0, samples)
                values = [_integer(window[key], 0, MAX_DURATION_US) for key in _DURATIONS]
                if values != sorted(values):
                    raise ValueError("invalid_receipt")
        delta = _integer(receipt["observation"]["events_delta"], 0)
        if len(windows) == 1 and delta != 0:
            raise ValueError("invalid_receipt")
        expected = _assemble(receipt["book_id"], source, limit, windows, delta)
        if data != _json_bytes(expected):
            raise ValueError("invalid_receipt")
    except (KeyError, TypeError, ValueError):
        raise ValueError("invalid_receipt") from None
    return data


def _local_path(path):
    try:
        path = Path(os.path.abspath(path))
        # Check parents too: a plain final name under a junction is still redirected.
        for component in (*reversed(path.parents), path):
            try:
                info = component.lstat()
            except FileNotFoundError:
                continue
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise ValueError("unsafe_path")
    except (TypeError, ValueError):
        raise ValueError("unsafe_path") from None
    return path


def _read_capture(path):
    try:
        path = _local_path(path)
        if not stat.S_ISREG(path.lstat().st_mode):
            raise ValueError("read_refused")
        flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
        with os.fdopen(os.open(path, flags), "rb") as stream:
            if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                raise ValueError("read_refused")
            return stream.read(CAPTURE_LIMIT + 1)
    except OSError:
        raise ValueError("read_refused") from None


def write_baseline_receipt(receipt: dict, output_dir) -> Path:
    """Stage validated bytes, then exclusively create the explicit destination.

No existing destination is overwritten. A failed copy removes only the partial
destination created by this call. No default runner directory is supplied.
"""
    data = _validated_bytes(receipt)
    staged = None
    created = False
    destination = None
    try:
        directory = _local_path(output_dir)
        directory.mkdir(parents=True, exist_ok=True)
        destination = _local_path(directory / (_symbol(receipt["book_id"]) + ".json"))
        fd, name = tempfile.mkstemp(prefix=".baseline-", suffix=".tmp", dir=directory)
        staged = Path(name)
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        with staged.open("rb") as source:
            with destination.open("xb") as target:
                created = True
                shutil.copyfileobj(source, target)
                target.flush()
                os.fsync(target.fileno())
        return destination
    except (OSError, ValueError):
        if created:
            destination.unlink()
        raise ValueError("write_refused") from None
    finally:
        if staged is not None:
            staged.unlink()


class _Parser(argparse.ArgumentParser):
    def error(self, _message):
        raise ValueError("usage")


def main(argv=None) -> int:
    parser = _Parser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--book", required=True)
    parser.add_argument("--capture", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--max-p99-us", required=True, type=int)
    try:
        args = parser.parse_args(argv)
        symbol = _symbol(args.book)
        _integer(args.max_p99_us, 1, 20_000, "invalid_policy")
        capture_path = _local_path(args.capture)
        output = _local_path(Path(args.output_dir) / (symbol + ".json"))
        if capture_path == output or (output.exists() and os.path.samefile(capture_path, output)):
            raise ValueError("input_output_alias")
        receipt = build_baseline_receipt(_read_capture(capture_path), book_id=args.book,
                                         max_p99_us=args.max_p99_us)
        destination = write_baseline_receipt(receipt, args.output_dir)
    except ValueError as error:
        print(json.dumps({"error": str(error)}, separators=(",", ":")))
        return 2
    except OSError:
        print('{"error":"io_refused"}')
        return 2
    print(json.dumps({"book_id": receipt["book_id"], "headroom": receipt["headroom"],
                      "reasons": receipt["reasons"], "output": destination.name},
                     sort_keys=True, separators=(",", ":")))
    return 0 if receipt["headroom"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
