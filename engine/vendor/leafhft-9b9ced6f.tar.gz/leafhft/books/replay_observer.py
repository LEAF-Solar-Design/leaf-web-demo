"""B10 local replay Watch receipts. No live transport or execution entry point.

The Ops caller serializes sidecar updates. This reader owns only its validated
per-book output directory; SH4's live Watch protocol and state are independent.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import re
import stat
import tempfile
import time
from collections import OrderedDict
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

from leafhft import engine_conform as conform
from leafhft.books.latency import HOP_INDEX, HopMeter
from leafhft.books.manifest import legacy_manifests
from leafhft.engine_manifest import ENGINE_ID_RE, load_manifest, manifest_digest
from leafhft.lanes.base import DecisionFrame
from leafhft.lanes.flags import GREEN, RED, MAX_FLAGS, FlagHost, MarketStamp
from leafhft.lanes.kalshi_edge_entry import KalshiEdgeSignal, STALE_NS

SIGNAL_KERNELS = {"kalshi_edge": KalshiEdgeSignal}
WATCH_SCHEMA = "leafhft.books.watches.v1"
ACK_SCHEMA = "leafhft.books.observer.ack.v1"
STATUS_SCHEMA = "leafhft.books.observer.v1"
MAX_WATCH_ROWS = 256
MAX_JSON_BYTES = 65_536
MAX_HOSTS = 16
MAX_SCAN = 512
MAX_FLIPS_BYTES = 1 << 20
MAX_RETAINED = 4 * MAX_FLAGS
MAX_COUNTER = (1 << 63) - 1
DEFAULT_BASELINE = "/var/lib/leafhft/books/baseline"
DEFAULT_STATE = "/var/lib/leafhft/observe-replay"
_REQUEST = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
_ACCOUNT = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}")
_HASH = re.compile(r"[0-9a-f]{64}")
_REASON = re.compile(r"[a-z][a-z0-9_]{0,63}")
_WATCH_KEYS = {"request_id", "engine_id", "book_id", "enabled", "account_id", "requested_at"}
_ACK_KEYS = {"request_id", "engine_id", "enabled", "state", "reason", "at"}
LOG = logging.getLogger(__name__)


class ReplayRefused(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"),
                       ensure_ascii=True, allow_nan=False) + "\n").encode("utf-8")


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate key")
        result[key] = value
    return result


def _not_number(value):
    raise ValueError("non-integer number")


def strict_read(path):
    """A missing file is distinct from an unreadable or invalid one."""
    with Path(path).open("rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError("not a regular file")
        data = stream.read(MAX_JSON_BYTES + 1)
    if len(data) > MAX_JSON_BYTES:
        raise ValueError("oversize")
    return json.loads(data.decode("utf-8", errors="strict"), object_pairs_hook=_pairs,
                      parse_float=_not_number, parse_constant=_not_number), data


def _matches(pattern, value):
    return type(value) is str and pattern.fullmatch(value) is not None


def _timestamp(value):
    if type(value) is not str or not 0 < len(value) <= 64:
        return False
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed.tzinfo is not None and parsed.utcoffset() is not None
    except (ValueError, OverflowError):
        return False


def books():
    return {book.book_id: book for book in legacy_manifests()}


def validate_watches(value):
    if (type(value) is not dict or set(value) != {"schema", "rows"}
            or value["schema"] != WATCH_SCHEMA or type(value["rows"]) is not list
            or len(value["rows"]) > MAX_WATCH_ROWS):
        raise ReplayRefused("watches_invalid")
    allowed, seen = books(), set()
    for row in value["rows"]:
        if (type(row) is not dict or set(row) != _WATCH_KEYS
                or not _matches(_REQUEST, row["request_id"])
                or not _matches(ENGINE_ID_RE, row["engine_id"])
                or type(row["book_id"]) is not str or row["book_id"] not in allowed
                or type(row["enabled"]) is not bool
                or (row["account_id"] is not None and not _matches(_ACCOUNT, row["account_id"]))
                or not _timestamp(row["requested_at"])):
            raise ReplayRefused("watches_invalid")
        pair = row["engine_id"], row["book_id"]
        if pair in seen:
            raise ReplayRefused("watches_invalid")
        seen.add(pair)
    if len(canonical(value)) > MAX_JSON_BYTES:
        raise ReplayRefused("watches_invalid")
    return value


def read_watches(registry_dir):
    path = Path(registry_dir) / "watches.json"
    try:
        value, data = strict_read(path)
    except FileNotFoundError:
        if os.path.lexists(path):
            raise ReplayRefused("watches_invalid") from None
        value = {"schema": WATCH_SCHEMA, "rows": []}
        data = canonical(value)
    except (OSError, ValueError, RecursionError):
        raise ReplayRefused("watches_invalid") from None
    validate_watches(value)
    return value, hashlib.sha256(data).hexdigest()


def _atomic(path, data, check=lambda path: None):
    check(path)
    descriptor, name = tempfile.mkstemp(prefix=".b10-", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            check(temporary)
            os.chmod(temporary, 0o644)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        check(temporary)
        check(path)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            check(temporary)
            temporary.unlink()


def write_watches(registry_dir, value):
    """Caller must hold the Ops lock. Never replace invalid existing state."""
    read_watches(registry_dir)
    validate_watches(value)
    _atomic(Path(registry_dir) / "watches.json", canonical(value))


def baseline_problem(directory, book_id):
    book = books().get(book_id)
    if book is None:
        return "book_unknown"
    try:
        value, _ = strict_read(Path(directory) / (book.symbol + ".json"))
    except (OSError, ValueError, RecursionError):
        return "baseline_absent"
    if (type(value) is not dict or value.get("schema") != "leafhft.books.baseline.v1"
            or value.get("book_id") != book_id):
        return "baseline_absent"
    return None if value.get("headroom") is True else "baseline_no_headroom"


def read_ack(path):
    value, _ = strict_read(path)
    if (type(value) is not dict or set(value) != {"schema", "book_id", "sidecar_sha256", "rows"}
            or value["schema"] != ACK_SCHEMA or type(value["book_id"]) is not str
            or value["book_id"] not in books() or not _matches(_HASH, value["sidecar_sha256"])
            or type(value["rows"]) is not list or len(value["rows"]) > MAX_WATCH_ROWS):
        raise ValueError("invalid acknowledgement")
    seen = set()
    for row in value["rows"]:
        if (type(row) is not dict or set(row) != _ACK_KEYS
                or not _matches(_REQUEST, row["request_id"])
                or not _matches(ENGINE_ID_RE, row["engine_id"])
                or type(row["enabled"]) is not bool or type(row["state"]) is not str
                or row["state"] not in ("applied", "rejected") or not _timestamp(row["at"])
                or (row["state"] == "applied" and row["reason"] is not None)
                or (row["state"] == "rejected" and not _matches(_REASON, row["reason"]))
                or row["engine_id"] in seen):
            raise ValueError("invalid acknowledgement row")
        seen.add(row["engine_id"])
    return value


def watch_status(registry_dir, state_dir, engine_id=None, book_id=None):
    watches, digest = read_watches(registry_dir)
    acks, result = {}, []
    for row in watches["rows"]:
        if (engine_id is not None and row["engine_id"] != engine_id
                or book_id is not None and row["book_id"] != book_id):
            continue
        bid = row["book_id"]
        if bid not in acks:
            path = Path(state_dir) / books()[bid].symbol / "ack.json"
            try:
                acks[bid] = read_ack(path)
            except FileNotFoundError:
                acks[bid] = False if os.path.lexists(path) else None
            except (OSError, ValueError, RecursionError):
                acks[bid] = False
        ack = acks[bid]
        current = dict(row, source="replay", state="unreported" if ack is False else "requested")
        if ack and ack["book_id"] == bid and ack["sidecar_sha256"] == digest:
            for applied in ack["rows"]:
                if (all(applied[key] == row[key] for key in ("engine_id", "request_id", "enabled"))
                        and applied["at"] == row["requested_at"]):
                    current.update(state=applied["state"], reason=applied["reason"])
                    break
        result.append(current)
    return {"source": "replay", "rows": sorted(result, key=lambda row: (row["book_id"], row["engine_id"]))}


def signal_spec(manifest, engines_dir, symbol):
    kernel_id = manifest.kernel["kernel_id"]
    if kernel_id not in SIGNAL_KERNELS:
        raise ReplayRefused("kernel_not_signal")
    if symbol not in manifest.inputs["symbols"]:
        raise ReplayRefused("watch_symbol_mismatch")
    resolved = conform.resolve_manifest_kernel(manifest)
    spec = conform.spec_for(manifest, resolved, engines_dir)
    spec = replace(spec, entry_cls=SIGNAL_KERNELS[kernel_id], symbols=(symbol,))
    return spec, (manifest_digest(manifest), resolved.sha256)


def _redirect(path):
    return path.is_symlink() or getattr(path, "is_junction", lambda: False)()


class Output:
    """All mutation targets are direct children of this checked, stable book directory."""
    def __init__(self, state_dir, symbol):
        self.root = Path(state_dir).absolute()
        self.root_resolved = self.root.resolve()
        self.directory = self.root / symbol
        self.resolved = self.directory.resolve()
        forbidden = Path("/var/lib/leafhft/observe").resolve()
        if (self.root_resolved.is_relative_to(forbidden) or self.resolved.is_relative_to(forbidden)
                or self.resolved != self.root_resolved / symbol or _redirect(self.directory)):
            raise ReplayRefused("state_dir_unsafe")
        self._directory_check()
        self.directory.mkdir(parents=True, exist_ok=True)
        self._directory_check()
        for name in ("ack.json", "status.json", "flips.jsonl", "flips.jsonl.1"):
            self.check(self.directory / name)

    def _directory_check(self):
        if (self.root.resolve() != self.root_resolved or self.directory.resolve() != self.resolved
                or _redirect(self.directory)):
            raise ReplayRefused("state_dir_unsafe")

    def check(self, path):
        self._directory_check()
        if (path.parent != self.directory or _redirect(path)
                or path.resolve() != self.resolved / path.name):
            raise ReplayRefused("state_dir_unsafe")

    def write(self, name, value):
        _atomic(self.directory / name, canonical(value), self.check)

    def flip(self, value):
        path, backup = self.directory / "flips.jsonl", self.directory / "flips.jsonl.1"
        data = canonical(value)
        self.check(path)
        self.check(backup)
        if path.exists() and path.stat().st_size + len(data) > MAX_FLIPS_BYTES:
            self.check(path)
            self.check(backup)
            os.replace(path, backup)
        self.check(path)
        flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(path, flags, 0o644)
        with os.fdopen(descriptor, "ab") as stream:
            self.check(path)
            stream.write(data)


def newest_tape(runs, symbol):
    candidates = []
    try:
        with os.scandir(runs) as entries:
            for index, entry in enumerate(entries):
                if index >= MAX_SCAN:
                    raise ReplayRefused("tape_scan_limit")
                if not entry.name.endswith("record-kalshi-" + symbol) or not entry.is_dir(follow_symlinks=False):
                    continue
                path = Path(entry.path)
                summary, tape = path / "record-summary.json", path / "ticks.jsonl"
                if summary.is_file() and tape.is_file():
                    candidates.append((summary.stat().st_mtime_ns, entry.name, tape))
    except FileNotFoundError:
        return None
    except OSError:
        raise ReplayRefused("tape_unreadable") from None
    return max(candidates)[2] if candidates else None


class ReplayHost(conform.OfflineHost):
    def __init__(self, spec, tape_name, book, consume, meter):
        super().__init__(spec, tape_name, sample=False)
        self.book, self.consume, self.meter = book, consume, meter
        self.flag_hosts = {}

    def create(self, symbol, restored_state):
        kernel = super().create(symbol, restored_state)
        # Policy lookup keeps its pinned policy identity. Flags use the watched manifest identity.
        kernel.engine_id = self.spec.engine_id
        self.flag_hosts[symbol] = FlagHost(
            kernel, book_id=self.book.book_id, engine_id=self.spec.engine_id,
            manifest_flag_quote_age_ms=self.book.flag_quote_age_ms,
            kernel_need_ms=STALE_NS // 1_000_000)
        return kernel

    def _evaluate(self, kernel, symbol, market, line, record):
        ticker = market["ticker"]
        frame_id = f"{self.tape}#{line}:{ticker}"
        frame = DecisionFrame(
            opportunity_id=frame_id[:96], now_ns=self.now_ns, cutoff_ns=self.now_ns,
            close_ms=market["close_ms"], ticker=ticker, symbol=symbol, strike_i=market["strike_i"],
            side_candidates=(True, False), quote=self.quotes.get(ticker),
            index=self.index.get(conform.SYMBOL_MAP[symbol][1]), history=(), positions=(),
            reserved_cents=0, sequence=self.sequence, gap=False)
        host = self.flag_hosts[symbol]
        start = time.monotonic_ns()
        try:
            self._call(frame_id, host.observe, frame)
            stamps = {ticker: MarketStamp((frame.quote or {}).get("at_ns"), (frame.index or {}).get("at_ns"))}
            flags = self._call(frame_id, host.flags, frame.close_ms, self.now_ns, stamps)
            if record:
                self.frames += 1
                for flag in flags:
                    if flag.ticker == ticker:
                        self.consume(flag, line)
        finally:
            end = time.monotonic_ns()
            self.meter.record(HOP_INDEX["signal_step"], end - start, end)


class _Session:
    def __init__(self, spec, key, book, output):
        self.spec, self.key, self.book, self.output = spec, key, book, output
        self.meter = HopMeter()
        self.last_hash = None
        self.tape_hash = None
        self.flags = OrderedDict()
        self.counts = {"frames": 0, "green": 0, "red": 0, "last": None}

    def consume(self, flag, line):
        self.counts["frames"] = min(MAX_COUNTER, self.counts["frames"] + 1)
        colour = "green" if flag.colour == GREEN else "red"
        self.counts[colour] = min(MAX_COUNTER, self.counts[colour] + 1)
        row = {"engine_id": self.spec.engine_id, "book_id": self.book.book_id,
               "ticker": flag.ticker, "window_id": flag.window_id, "colour": flag.colour,
               "reason": flag.reason, "evaluated_at_ns": flag.evaluated_at_ns,
               "source": "replay", "tape_sha256": self.tape_hash, "line": line}
        self._retain(row)

    def _retain(self, row):
        key = row["ticker"], row["window_id"]
        previous = self.flags.get(key)
        if previous is None or previous["colour"] != row["colour"]:
            self.output.flip(row)
        self.flags[key] = row
        self.flags.move_to_end(key)
        if len(self.flags) > MAX_RETAINED:
            self.flags.popitem(last=False)
        self.counts["last"] = {key: row[key] for key in ("ticker", "window_id", "colour", "reason")}

    def fault(self):
        for row in list(self.flags.values()):
            self._retain(dict(row, colour=RED, reason="feed_gap"))
        self.last_hash = None

    def replay(self, tape):
        if self.last_hash == tape.sha256:
            return
        self.tape_hash = tape.sha256
        host = ReplayHost(self.spec, tape.name, self.book, self.consume, self.meter)
        for item in tape.items:
            host.step(item)
        self.last_hash = tape.sha256


class ReplayObserver:
    def __init__(self, symbol, *, registry_dir, manifests_dir, engines_dir, runs,
                 state_dir=DEFAULT_STATE, tape=None):
        allowed = {book.symbol: book for book in legacy_manifests()}
        if type(symbol) is not str or symbol not in allowed:
            raise ReplayRefused("book_unknown")
        self.book = allowed[symbol]
        self.output = Output(state_dir, symbol)
        self.registry_dir, self.manifests_dir = Path(registry_dir), Path(manifests_dir)
        self.engines_dir, self.runs = Path(engines_dir), Path(runs)
        self.tape = None if tape is None else Path(tape)
        self.hosts = {}

    def tick(self):
        problems, decisions, retained = [], [], {}
        try:
            watches, digest = read_watches(self.registry_dir)
        except ReplayRefused:
            watches, digest = {"rows": []}, "0" * 64
            problems.append("watches_invalid")
        for row in sorted(watches["rows"], key=lambda row: row["engine_id"]):
            if row["book_id"] != self.book.book_id:
                continue
            decision = {key: row[key] for key in ("request_id", "engine_id", "enabled")}
            decision.update(state="applied", reason=None, at=row["requested_at"])
            if row["enabled"]:
                try:
                    path = self.manifests_dir / (row["engine_id"] + ".json")
                    if not path.exists():
                        raise ReplayRefused("manifest_missing")
                    manifest = load_manifest(path)
                    spec, pins = signal_spec(manifest, self.engines_dir, self.book.symbol)
                    if len(retained) >= MAX_HOSTS:
                        raise ReplayRefused("observer_full")
                    key = (row["request_id"], row["engine_id"], pins)
                    current = self.hosts.get(row["engine_id"])
                    retained[row["engine_id"]] = (current if current and current.key == key else
                                                  _Session(spec, key, self.book, self.output))
                except (OSError, ValueError, conform.ConformRefused) as exc:
                    decision.update(state="rejected", reason=getattr(exc, "code", "manifest_invalid"))
            decisions.append(decision)
        self.hosts = retained
        tape_info = None
        try:
            path = self.tape if self.tape is not None else newest_tape(self.runs, self.book.symbol)
            if path is None or not path.is_file():
                raise ReplayRefused("tape_missing")
            try:
                corpus = conform.load_corpus(path)
            except (OSError, ValueError, conform.ConformRefused):
                raise ReplayRefused("tape_invalid") from None
            tape = corpus.tapes[0]
            tape_info = {"run": path.parent.name, "sha256": tape.sha256, "rows": tape.rows}
            for decision in decisions:
                engine_id = decision["engine_id"]
                session = self.hosts.get(engine_id)
                if session is None:
                    continue
                try:
                    session.replay(tape)
                except (ValueError, conform.ConformRefused) as exc:
                    session.fault()
                    decision.update(state="rejected", reason=getattr(exc, "code", "kernel_error"))
                    del self.hosts[engine_id]
        except ReplayRefused as exc:
            problems.append(exc.code)
            for session in self.hosts.values():
                session.fault()
        # A corrupt sidecar cannot be acknowledged as an applied generation.
        self.output.write("ack.json", {"schema": ACK_SCHEMA, "book_id": self.book.book_id,
                                       "sidecar_sha256": digest, "rows": decisions})
        now = time.monotonic_ns()
        status = {"schema": STATUS_SCHEMA, "book_id": self.book.book_id, "source": "replay",
                  "tape": tape_info, "problems": problems,
                  "engines": {eid: dict(session.counts) for eid, session in sorted(self.hosts.items())},
                  "hops": {eid: session.meter.snapshot(now) for eid, session in sorted(self.hosts.items())},
                  "at": datetime.now(timezone.utc).isoformat()}
        self.output.write("status.json", status)
        return status


def _interval(value):
    try:
        number = int(value)
    except (ValueError, TypeError):
        raise argparse.ArgumentTypeError("interval must be an integer from 5 through 600") from None
    if not 5 <= number <= 600:
        raise argparse.ArgumentTypeError("interval must be from 5 through 600")
    return number


def main(argv=None):
    parser = argparse.ArgumentParser(description="Replay-only local book observation")
    parser.add_argument("--book", required=True)
    parser.add_argument("--registry-dir", default="/var/lib/leafhft/engine-registry")
    parser.add_argument("--manifests-dir", default="/etc/leafhft/engine-manifests")
    parser.add_argument("--engines-dir", default="/etc/leafhft/engines")
    parser.add_argument("--runs", required=True)
    parser.add_argument("--state-dir", default=DEFAULT_STATE)
    parser.add_argument("--tape")
    parser.add_argument("--interval-s", type=_interval, default=30)
    parser.add_argument("--once", action="store_true")
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return 0 if exc.code == 0 else 2
    try:
        observer = ReplayObserver(args.book, registry_dir=args.registry_dir,
                                  manifests_dir=args.manifests_dir, engines_dir=args.engines_dir,
                                  runs=args.runs, state_dir=args.state_dir, tape=args.tape)
    except ReplayRefused as exc:
        LOG.error("replay startup refused: %s", exc.code)
        return 2
    except Exception:
        LOG.exception("replay startup failed")
        return 3
    while True:
        try:
            observer.tick()
        except MemoryError:
            LOG.exception("replay memory exhausted")
            return 3
        except ReplayRefused as exc:
            if exc.code == "state_dir_unsafe":
                LOG.error("replay output refused: %s", exc.code)
                return 2
            LOG.exception("replay tick refused")
        except Exception:
            LOG.exception("replay tick failed")
            if args.once:
                return 3
        if args.once:
            return 0
        time.sleep(args.interval_s)
