"""BookTapHost: the book process's side of the B-STD tap (B8; B-D4, B-D9, B-STD section 4).

Constructed only for a book whose symbol is listed in <etc>/kalshi-book-taps: live-run.sh then
passes --book-tap <address>, a CLI argument outside EngineConfig and the config digest. An
unlisted book never imports this module, so its argv, config.json, config digest, intents and
status JSON are byte-identical to before (tests/test_books_host_golden.py).

Contract, on_event and loop_lag (the book's event loop): at most five HopMeter record calls, at
most one Tap.emit and at most three clock reads (monotonic_ns for bucketing, two perf_counter_ns
around the emit while a consumer is attached); no I/O, lock, await or container growth; never
raises into the caller (a failure counts in `errors`). on_event runs after the incumbent's
evaluate and its hot_path measurement, so it never changes an intent, but it runs before that
event's intents are dispatched: its whole cost (on_event ns/event) sits on the send path.

Contract, ensure_attached: the socket connect runs off the loop (asyncio.to_thread), bounded by
UnixSocketSink's 1 s timeout; with no consumer listening the tap stays detached, emit stays a
no-op, and the caller retries at most once per 30 s status tick. A consumer that goes away after
attach is counted in the tap's sink_errors and is not re-attached within the run.

Status: status_block() is the top-level `book_hops` key of kalshi-edge-status.json in the shape
B9's push reads ({"schema": 1, "at_ms", "health", "integration": {"id", "version"}, "window_s",
"rejected", "hops"}); tap_block() is the sibling `book_tap` key. Neither ever goes under "book",
which is the cash block.
"""
from __future__ import annotations

import asyncio
import time

from ..feeds.base import IndexTick, Lifecycle
from ..types import Quote, Trade
from .latency import HOP_INDEX, HopMeter
from .manifest import LEGACY_INTEGRATION_ID, LEGACY_INTEGRATION_VERSION
from .tap import Tap, TapError, open_local_sink

BOOK_HOPS_SCHEMA = 1
LAG_PERIOD_NS = 50_000_000  # the dedicated wakeup for a book with no darkhorse timer
MAX_ADDRESS = 256
HEALTH_OK = "ok"
HEALTH_DEGRADED = "degraded"
HEALTH_STALE = "stale"  # no event dequeued in the 60 s window
_HEALTH_HOPS = ("receive_to_dequeue", "loop_lag")

_LOOP_LAG = HOP_INDEX["loop_lag"]
_R2D = HOP_INDEX["receive_to_dequeue"]
_COMPUTE = HOP_INDEX["incumbent_compute"]
_TAP_EMIT = HOP_INDEX["tap_emit"]
_INDEX_RELAY = HOP_INDEX["index_relay"]
_TRADE_RELAY = HOP_INDEX["trade_relay"]
_QUOTE_AGE = HOP_INDEX["quote_state_age"]


def health_of(snapshot: dict) -> str:
    """stale when no event was dequeued in the window; degraded when receive_to_dequeue or loop_lag
    has samples and its p99 exceeds its budget; ok otherwise. Never "down" (B9 accepts it; no
    producer here emits it)."""
    hops = snapshot["hops"]
    if hops["receive_to_dequeue"]["n"] == 0:
        return HEALTH_STALE
    for name in _HEALTH_HOPS:
        row = hops[name]
        budget = row["budget_ns"]
        if row["n"] and budget is not None and row["p99"] is not None and row["p99"] > budget:
            return HEALTH_DEGRADED
    return HEALTH_OK


class BookTapHost:
    """One opted-in book's HopMeter and Tap. Hot path: on_event and loop_lag only."""

    __slots__ = ("address", "meter", "tap", "errors", "attach_attempts", "attach_failures")

    def __init__(self, address: str, *, tap: Tap | None = None, meter: HopMeter | None = None):
        if type(address) is not str or not address or len(address) > MAX_ADDRESS:
            raise TapError(f"book tap address must be a non-empty path of at most {MAX_ADDRESS} characters")
        self.address = address
        self.meter = meter if meter is not None else HopMeter()
        self.tap = tap if tap is not None else Tap()
        self.errors = 0
        self.attach_attempts = 0
        self.attach_failures = 0

    # -- the book's event loop -----------------------------------------------------------------

    def on_event(self, ev, now_ns: int, compute_ns: int) -> None:
        """One dequeued event: now_ns is the loop's epoch reading at dequeue, compute_ns the
        incumbent's evaluate duration (the hot_path_ms sample). Never raises."""
        try:
            mono = time.monotonic_ns()
            meter = self.meter
            meter.record(_COMPUTE, compute_ns, mono)
            kind = type(ev)
            if kind is Quote:
                recv = ev.ts_recv_ns
                tag, key = "quote", ev.symbol
                if ev.ts_arrival_ns is None:
                    meter.record_missing(_QUOTE_AGE, mono)
                else:
                    meter.record(_QUOTE_AGE, recv - ev.ts_arrival_ns, mono)
            elif kind is IndexTick:
                recv = ev.received_at_ms * 1_000_000
                tag, key = "index", ev.index_id
                meter.record(_INDEX_RELAY, (ev.received_at_ms - ev.source_ts_ms) * 1_000_000, mono)
            elif kind is Trade:
                recv = ev.ts_recv_ns
                tag, key = "trade", ev.symbol
                meter.record(_TRADE_RELAY, recv - ev.ts_exch_ns, mono)
            elif kind is Lifecycle:
                recv = ev.ts_recv_ns
                tag, key = "lifecycle", ev.ticker
            else:
                recv = None
                tag, key = "other", "-"
            if type(recv) is int:
                meter.record(_R2D, now_ns - recv, mono)
            else:
                meter.record_missing(_R2D, mono)
            tap = self.tap
            if tap.attached:
                started = time.perf_counter_ns()
                tap.emit(tag, key, recv if type(recv) is int else 0)
                meter.record(_TAP_EMIT, time.perf_counter_ns() - started, mono)
        except Exception:
            self.errors += 1

    def loop_lag(self, lateness_ns: int) -> None:
        """One scheduled wakeup's lateness (perf_counter_ns). Never raises."""
        try:
            self.meter.record(_LOOP_LAG, lateness_ns, time.monotonic_ns())
        except Exception:
            self.errors += 1

    async def lag_timer(self) -> None:
        """A 50 ms wakeup that records loop_lag only, for a book with no darkhorse timer."""
        while True:
            due = time.perf_counter_ns() + LAG_PERIOD_NS
            await asyncio.sleep(LAG_PERIOD_NS / 1_000_000_000)
            self.loop_lag(time.perf_counter_ns() - due)

    # -- the status tick (every 30 s) ------------------------------------------------------------

    async def ensure_attached(self) -> bool:
        """Attach the tap to the local consumer when detached. The connect runs off the loop."""
        if self.tap.attached:
            return True
        self.attach_attempts += 1
        try:
            sink = await asyncio.to_thread(open_local_sink, self.address)
        except Exception:
            self.attach_failures += 1
            return False
        try:
            self.tap.attach(sink)
        except Exception:
            self.attach_failures += 1
            try:
                sink.close()
            except Exception:
                pass
            return False
        return True

    def status_block(self, at_ms: int, mono_ns: int) -> dict:
        """The `book_hops` status key (the shape B9's push reads)."""
        snapshot = self.meter.snapshot(mono_ns)
        return {"schema": BOOK_HOPS_SCHEMA, "at_ms": at_ms, "health": health_of(snapshot),
                "integration": {"id": LEGACY_INTEGRATION_ID, "version": LEGACY_INTEGRATION_VERSION},
                **snapshot}

    def tap_block(self) -> dict:
        """The `book_tap` status key: Tap.stats plus the attach and error counters."""
        return {"address": self.address, "attach_attempts": self.attach_attempts,
                "attach_failures": self.attach_failures, "errors": self.errors, **self.tap.stats()}

    def close(self) -> bool:
        """Detach at shutdown (joins the drainer up to its timeout; call off the loop)."""
        return self.tap.detach()
