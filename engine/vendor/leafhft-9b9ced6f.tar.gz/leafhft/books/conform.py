"""Book conformance: one manifest, one tape, two hash seeds, one receipt (B-STD B6, B-D13;
amendments v2 items 4 and 11). Extends C11's engine_conform pattern to books.

`python -m leafhft.books conform --manifest M --tape T [--coverage C] [--out receipt.json]`

1. The manifest is decoded strictly (B2's schema, books/manifest.py) and its fee model is checked
   against B13's venue facts for the same venue: the model name must be a venue model, the rate
   the venue taker rate, and every (price on the manifest's tick grid, quantity) cell must agree
   with venue_facts.fee_cents exactly. Any difference is `fee_model_mismatch`.
2. The tape is refused above MAX_TAPE_BYTES (`tape_too_large`) before a byte of it is parsed, and
   its sha256 is taken by a bounded streaming read.
3. The tape is replayed through the pure frame codec (books/tape.py) TWICE, each in its own
   interpreter with a different PYTHONHASHSEED, concurrently, under one shared CHILD_TIMEOUT_S
   deadline. While replaying, each child audits the declared hop order on the receive clock
   (HOP_ORDER, frame.CLOCK_DOMAIN) and refuses `hop_order` on the first frame whose stamps run
   backwards, and refuses `gap_row` on an `f` row with gap=true outside the declared coverage.
   The two outputs must be byte-equal after normalize_receipt, and two refusals must be equal,
   or the verdict is `nondeterministic`.
4. The receipt binds manifest_digest, tape_sha256, the codec and flag host module digests, the
   hop order, the replay clock and the hash seeds. Flag colour in it is a pure function of the
   tape plus the replay clock: the child reads no wall or monotonic clock.

Coverage: B2's manifest schema carries no coverage field, so a manifest declares no gaps by
itself. Declared gaps ride in an optional coverage document bound to the manifest by its digest
({"schema": 1, "manifest_digest": "sha256:...", "gaps": [{"from_ns": a, "to_ns": b}, ...]},
epoch ns on the receive clock, ascending and disjoint). B14 becomes its producer.

Exit codes: 0 conforms (the receipt on stdout, and in --out when given); 2 refused (one JSON
object `{"refused": {code, detail, row}}` on stdout, code from REFUSAL_CODES); 3 could not reach
a verdict (`{"error": {code, detail}}`, code from FAILURE_CODES: a child timeout or crash, a bad
command line, an internal error). Never a traceback on stdout.
"""
from __future__ import annotations

import argparse
import bisect
import hashlib
import os
import re
import subprocess
import sys
import time
from collections.abc import Iterator, Mapping
from decimal import Decimal
from pathlib import Path

from .. import venue_facts
from . import frame as _frame_module
from . import tape as _tape_module
from .frame import CLOCK_DOMAIN, GREEN, MAX_DELTA_NS, ClockDomainError, FrameInvalid, epoch_ns
from .manifest import (
    MAX_MANIFEST_BYTES,
    BookManifest,
    ManifestInvalid,
    StrictJsonError,
    canonical_json,
    decode_manifest,
    manifest_digest,
    strict_json_loads,
)
from .tape import (
    MAX_LINE_BYTES,
    MAX_TRACKED_KEYS,
    ROW_KINDS,
    ReplayClock,
    TapeError,
    encode_row,
    flag_row,
    replay,
    validate_row,
)

CONFORM_SCHEMA = "leafhft.books.conform.v1"
REPLAY_SCHEMA = "leafhft.books.conform.replay.v1"
CODEC_VERSION = "1"  # the tape row schema of books/tape.py; the module sha256 pins the code itself
COVERAGE_SCHEMA = 1
LABEL = "offline book conformance, not a verdict"
HASH_SEEDS = ("1", "2718")
MAX_TAPE_BYTES = 256 << 20
MAX_COVERAGE_BYTES = 64 << 10
MAX_DECLARED_GAPS = 1024
MAX_WINDOWS = 65_536  # distinct (ticker, window) pairs one replay may count
MAX_CHILD_OUTPUT = 1 << 20
CHILD_TIMEOUT_S = 300.0
MAX_TIMEOUT_S = 3600.0
READ_CHUNK = 1 << 20
EXIT_OK = 0
EXIT_REFUSED = 2
EXIT_FAILED = 3
VOLATILE_KEYS = frozenset({"at"})
# Fee parity quantities: whole counts plus one fractional count, where the two models differ most.
FEE_PARITY_QUANTITIES = (1, 5, 20, 100, Decimal("2.5"))

# The declared hop order on the receive clock (frame.CLOCK_DOMAIN): each pair is (earlier, later)
# and a frame whose stamps run the other way is refused `hop_order`. The quote and index receive
# stamps a frame reads are the latest `q` row for its ticker and the latest `i` row for its
# manifest's index; `f.at_ns` never runs backwards in tape order.
HOP_ORDER = (
    ("q.ta", "q.tr"),
    ("q.tr", "f.at_ns"),
    ("i.local_ns", "f.at_ns"),
    ("f.at_ns", "next f.at_ns"),
)

REFUSAL_CODES = frozenset({
    "hop_order", "gap_row", "fee_model_mismatch", "tape_too_large", "manifest_invalid",
    "coverage_invalid", "tape_invalid", "input_unreadable", "input_changed", "nondeterministic",
})
FAILURE_CODES = frozenset({"replay_timeout", "replay_failed", "usage", "internal"})

_PACKAGE_ROOT = Path(__file__).resolve().parents[2]
_SEED = re.compile(r"[0-9]{1,10}")
# The venue facts module for each manifest domain (manifest.DOMAINS).
VENUE_FACTS = {"kalshi": venue_facts}


class ConformRefused(Exception):
    """The input does not conform (exit 2); `code` is one of REFUSAL_CODES, `row` the 1-based
    tape line when one row is to blame."""

    def __init__(self, code: str, detail: str = "", row: int | None = None):
        if code not in REFUSAL_CODES:
            raise ValueError(f"unknown refusal code {code!r}")
        self.code = code
        self.detail = str(detail)[:1000]
        self.row = row
        where = f" at row {row}" if row is not None else ""
        super().__init__(f"{code}{where}: {self.detail}")

    def to_dict(self) -> dict:
        return {"code": self.code, "detail": self.detail, "row": self.row}


class ConformFailed(Exception):
    """No verdict could be reached (exit 3); `code` is one of FAILURE_CODES."""

    def __init__(self, code: str, detail: str = ""):
        if code not in FAILURE_CODES:
            raise ValueError(f"unknown failure code {code!r}")
        self.code = code
        self.detail = str(detail)[:1000]
        super().__init__(f"{code}: {self.detail}")

    def to_dict(self) -> dict:
        return {"code": self.code, "detail": self.detail}


def _strip(value):
    if isinstance(value, Mapping):
        return {key: _strip(item) for key, item in value.items() if key not in VOLATILE_KEYS}
    if isinstance(value, (list, tuple)):
        return [_strip(item) for item in value]
    return value


def normalize_receipt(receipt: Mapping) -> bytes:
    """Canonical bytes of a receipt or replay section without its wall-clock fields
    (VOLATILE_KEYS at any depth): equal for equal inputs in any process and hash seed."""
    return canonical_json(_strip(receipt))


# ---------------------------------------------------------------- bounded input reads

def _read_bounded(path, limit: int, code: str, what: str) -> bytes:
    """At most `limit` bytes of a file; a larger file is refused with `code`."""
    try:
        with open(path, "rb") as handle:
            data = handle.read(limit + 1)
    except OSError as exc:
        raise ConformRefused("input_unreadable", f"{what}: {type(exc).__name__}: {exc.strerror or exc}") from None
    if len(data) > limit:
        raise ConformRefused(code, f"{what} exceeds {limit} bytes")
    return data


def load_manifest(path) -> BookManifest:
    """The book manifest at `path`, strictly decoded; `manifest_invalid` otherwise."""
    raw = _read_bounded(path, MAX_MANIFEST_BYTES, "manifest_invalid", "manifest")
    try:
        return decode_manifest(raw)
    except ManifestInvalid as exc:
        raise ConformRefused("manifest_invalid", f"{exc.code}: {exc.detail}") from None


def parse_coverage(raw: bytes, manifest: BookManifest) -> tuple[tuple[int, int], ...]:
    """Declared gap intervals [from_ns, to_ns] for this manifest; `coverage_invalid` otherwise."""
    if len(raw) > MAX_COVERAGE_BYTES:
        raise ConformRefused("coverage_invalid", f"coverage exceeds {MAX_COVERAGE_BYTES} bytes")
    try:
        doc = strict_json_loads(raw)
    except StrictJsonError as exc:
        raise ConformRefused("coverage_invalid", f"{exc.code}: {exc.detail}") from None
    if type(doc) is not dict or set(doc) != {"schema", "manifest_digest", "gaps"}:
        raise ConformRefused("coverage_invalid", "coverage is an object with exactly schema, manifest_digest, gaps")
    if type(doc["schema"]) is not int or doc["schema"] != COVERAGE_SCHEMA:
        raise ConformRefused("coverage_invalid", f"coverage schema must be {COVERAGE_SCHEMA}")
    if doc["manifest_digest"] != manifest_digest(manifest):
        raise ConformRefused("coverage_invalid", "coverage is bound to another manifest")
    gaps = doc["gaps"]
    if type(gaps) is not list or len(gaps) > MAX_DECLARED_GAPS:
        raise ConformRefused("coverage_invalid", f"gaps is a list of at most {MAX_DECLARED_GAPS}")
    out, previous = [], None
    for n, gap in enumerate(gaps):
        if type(gap) is not dict or set(gap) != {"from_ns", "to_ns"}:
            raise ConformRefused("coverage_invalid", f"gaps[{n}] is an object with exactly from_ns, to_ns")
        try:
            lo, hi = epoch_ns(gap["from_ns"], f"gaps[{n}].from_ns"), epoch_ns(gap["to_ns"], f"gaps[{n}].to_ns")
        except ClockDomainError as exc:
            raise ConformRefused("coverage_invalid", str(exc)) from None
        if lo > hi or (previous is not None and lo <= previous):
            raise ConformRefused("coverage_invalid", f"gaps[{n}]: gaps ascend, disjoint, from_ns <= to_ns")
        previous = hi
        out.append((lo, hi))
    return tuple(out)


def load_coverage(path, manifest: BookManifest) -> tuple[tuple[int, int], ...]:
    if path is None:
        return ()
    return parse_coverage(_read_bounded(path, MAX_COVERAGE_BYTES, "coverage_invalid", "coverage"), manifest)


def tape_digest(path) -> tuple[str, int]:
    """(sha256 hex, size) of the tape by a bounded streaming read; `tape_too_large` above
    MAX_TAPE_BYTES, checked on the file size before any byte is read and again while reading."""
    try:
        size = os.stat(path).st_size
    except OSError as exc:
        raise ConformRefused("input_unreadable", f"tape: {type(exc).__name__}: {exc.strerror or exc}") from None
    if size > MAX_TAPE_BYTES:
        raise ConformRefused("tape_too_large", f"tape is {size} bytes > {MAX_TAPE_BYTES}")
    digest, total = hashlib.sha256(), 0
    try:
        with open(path, "rb") as handle:
            while True:
                chunk = handle.read(READ_CHUNK)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_TAPE_BYTES:
                    raise ConformRefused("tape_too_large", f"tape grew past {MAX_TAPE_BYTES} bytes")
                digest.update(chunk)
    except OSError as exc:
        raise ConformRefused("input_unreadable", f"tape: {type(exc).__name__}: {exc.strerror or exc}") from None
    return digest.hexdigest(), total


# ---------------------------------------------------------------- fee model against venue facts

def check_fee_model(manifest: BookManifest) -> dict:
    """The manifest's fee model against B13's venue facts for the same venue; returns the
    report, or refuses `fee_model_mismatch`. Bounded: bands sit in (0, 100) without overlap on
    the venue's price precision, so at most about a thousand prices are checked."""
    facts = VENUE_FACTS.get(manifest.domain)
    if facts is None:
        raise ConformRefused("fee_model_mismatch", f"no venue facts for domain {manifest.domain!r}")
    name = manifest.fee_model.name
    if name not in facts.FEE_MODELS:
        raise ConformRefused("fee_model_mismatch", f"fee model {name!r} is not one of the venue's {list(facts.FEE_MODELS)}")
    rate_fact = facts.VENUE["taker_rate"]
    rate = Decimal(manifest.fee_model.rate)
    if rate != rate_fact.value:
        raise ConformRefused("fee_model_mismatch",
                             f"fee rate {manifest.fee_model.rate} is not the venue taker rate {rate_fact.value} "
                             f"({rate_fact.source}, recorded {rate_fact.recorded})")
    precision = facts.VENUE["price_precision_cents"].value
    cells = 0
    for band in manifest.tick_grid:
        lo, hi, tick = Decimal(band.lo), Decimal(band.hi), Decimal(band.tick)
        if lo % precision or tick % precision:
            raise ConformRefused("fee_model_mismatch",
                                 f"tick band {band.lo}..{band.hi} step {band.tick} is finer than the venue "
                                 f"price precision {precision}c, where the venue fee model is undefined")
        price = lo
        while price <= hi:
            for quantity in FEE_PARITY_QUANTITIES:
                try:
                    book_fee = manifest.fee_model.fee_cents(price, quantity)
                    venue_fee = facts.fee_cents(name, price, quantity, rate=rate_fact.value)
                except (ValueError, ArithmeticError) as exc:
                    raise ConformRefused("fee_model_mismatch", f"price {price}c x {quantity}: {exc}") from None
                if book_fee != venue_fee:
                    raise ConformRefused("fee_model_mismatch",
                                         f"price {price}c x {quantity}: manifest {book_fee}c, venue {venue_fee}c")
                cells += 1
            price += tick
    return {"venue": manifest.domain, "name": name, "rate": manifest.fee_model.rate,
            "venue_rate": str(rate_fact.value), "source": rate_fact.source,
            "recorded": rate_fact.recorded, "cells": cells}


# ---------------------------------------------------------------- the child: audit and replay

def _tape_lines(handle, digest, size: list) -> Iterator[tuple[int, bytes]]:
    """(1-based line number, body) per tape line; bounded per line and in total."""
    n = 0
    while True:
        line = handle.readline(MAX_LINE_BYTES + 2)
        if not line:
            return
        n += 1
        size[0] += len(line)
        if size[0] > MAX_TAPE_BYTES:
            raise ConformRefused("tape_too_large", f"tape grew past {MAX_TAPE_BYTES} bytes", n)
        digest.update(line)
        body = line[:-1] if line.endswith(b"\n") else line
        if len(body) > MAX_LINE_BYTES:
            raise ConformRefused("tape_invalid", f"oversize: line exceeds {MAX_LINE_BYTES} bytes", n)
        if not body:
            raise ConformRefused("tape_invalid", "bad_value: blank line", n)
        yield n, body


class _TapeAudit:
    """Decodes rows, checks HOP_ORDER and the declared gaps, and counts rows, all in tape order.
    Tracking is bounded exactly as replay's (MAX_TRACKED_KEYS tickers)."""

    def __init__(self, manifest: BookManifest, gaps: tuple[tuple[int, int], ...]):
        self.manifest = manifest
        self.gaps = gaps
        self._gap_starts = [lo for lo, _hi in gaps]
        self.row = 0
        self.counts = dict.fromkeys(ROW_KINDS, 0)
        self._quote_tr: dict[str, int] = {}
        self._index_ns: int | None = None
        self._last_at: int | None = None

    def covered(self, at_ns: int) -> bool:
        k = bisect.bisect_right(self._gap_starts, at_ns) - 1
        return k >= 0 and self.gaps[k][0] <= at_ns <= self.gaps[k][1]

    def rows(self, lines) -> Iterator[dict]:
        for n, body in lines:
            self.row = n
            try:
                row = strict_json_loads(body)
            except StrictJsonError as exc:
                raise ConformRefused("tape_invalid", f"{exc.code}: {exc.detail}", n) from None
            if (type(row) is dict and row.get("t") == "q" and type(row.get("ta")) is int
                    and type(row.get("tr")) is int and row["ta"] > row["tr"]):
                raise ConformRefused("hop_order", f"q.ta {row['ta']} is after q.tr {row['tr']}", n)
            try:
                validate_row(row)
            except TapeError as exc:
                raise ConformRefused("tape_invalid", f"{exc.code}: {exc.detail}", n) from None
            self._observe(n, row)
            yield row

    def _observe(self, n: int, row: dict) -> None:
        kind = row["t"]
        self.counts[kind] += 1
        if kind == "q":
            ticker = row["s"]
            if ticker not in self._quote_tr and len(self._quote_tr) >= MAX_TRACKED_KEYS:
                raise ConformRefused("tape_invalid", f"too_many_keys: more than {MAX_TRACKED_KEYS} tickers", n)
            self._quote_tr[ticker] = row["tr"]
        elif kind == "i":
            if row["index_id"] == self.manifest.index_id:
                self._index_ns = row["local_ns"]
        elif kind == "f":
            at = row["at_ns"]
            quote = self._quote_tr.get(row["ticker"])
            if quote is not None and quote > at:
                raise ConformRefused("hop_order", f"q.tr {quote} is after f.at_ns {at}", n)
            if self._index_ns is not None and self._index_ns > at:
                raise ConformRefused("hop_order", f"i.local_ns {self._index_ns} is after f.at_ns {at}", n)
            if self._last_at is not None and at < self._last_at:
                raise ConformRefused("hop_order", f"f.at_ns {at} runs back from {self._last_at}", n)
            self._last_at = at
            if row["gap"] and not self.covered(at):
                raise ConformRefused("gap_row", f"a gap at f.at_ns {at} is not declared in the manifest's coverage", n)


def replay_section(manifest_path, tape_path, *, coverage_path=None, lag_ns: int = 0) -> dict:
    """The replay section one child emits: a pure function of the manifest, tape, coverage and
    replay clock. Reads no wall or monotonic clock; iterates only in tape order."""
    manifest = load_manifest(manifest_path)
    gaps = load_coverage(coverage_path, manifest)
    clock = ReplayClock(lag_ns)
    audit = _TapeAudit(manifest, gaps)
    digest, size = hashlib.sha256(), [0]
    flags = hashlib.sha256()
    green = red = 0
    by_reason: dict[str, int] = {}
    windows: dict[tuple[str, str], int] = {}
    try:
        with open(tape_path, "rb") as handle:
            rows = audit.rows(_tape_lines(handle, digest, size))
            for frame in replay(rows, clock, manifests={manifest.book_id: manifest}):
                flag = frame.flag
                flags.update(encode_row(flag_row(flag)) + b"\n")
                by_reason[flag.reason] = by_reason.get(flag.reason, 0) + 1
                if flag.colour == GREEN:
                    green += 1
                    key = (flag.ticker, flag.window_id)
                    if key not in windows and len(windows) >= MAX_WINDOWS:
                        raise ConformRefused("tape_invalid", f"too_many_keys: more than {MAX_WINDOWS} green windows",
                                             audit.row)
                    windows[key] = windows.get(key, 0) + 1
                else:
                    red += 1
    except OSError as exc:
        raise ConformRefused("input_unreadable", f"tape: {type(exc).__name__}: {exc.strerror or exc}") from None
    except TapeError as exc:
        raise ConformRefused("tape_invalid", f"{exc.code}: {exc.detail}", audit.row) from None
    except (FrameInvalid, ClockDomainError) as exc:
        raise ConformRefused("tape_invalid", str(exc), audit.row) from None
    return {
        "schema": REPLAY_SCHEMA,
        "book_id": manifest.book_id,
        "manifest_digest": manifest_digest(manifest),
        "tape_sha256": digest.hexdigest(),
        "tape_bytes": size[0],
        "clock_domain": CLOCK_DOMAIN,
        "replay_clock": {"lag_ns": clock.lag_ns},
        "hop_order": [list(pair) for pair in HOP_ORDER],
        "declared_gaps": len(gaps),
        "rows": dict(audit.counts),
        "frames": green + red,
        "flags": {"green": green, "red": red, "by_reason": by_reason, "sha256": flags.hexdigest()},
        # Amendment 4: what one-send-per-window removes. The tape carries flags, not fills, so
        # fills and economics removed are not measured here (null), never reported as zero.
        "one_send_per_window": {
            "green_flags": green,
            "windows_with_green": len(windows),
            "refires_removed": green - len(windows),
            "fills_removed": None,
            "economics_removed": None,
        },
    }


# ---------------------------------------------------------------- the parent: two seeds

def _check_seeds(hash_seeds) -> tuple[str, ...]:
    seeds = tuple(hash_seeds)
    if (len(seeds) < 2 or len(set(seeds)) != len(seeds)
            or any(type(s) is not str or not _SEED.fullmatch(s) for s in seeds)):
        raise ValueError("hash_seeds: at least two distinct decimal PYTHONHASHSEED values")
    return seeds


def _check_timeout(timeout_s) -> float:
    if isinstance(timeout_s, bool) or not isinstance(timeout_s, (int, float)) or not 0 < timeout_s <= MAX_TIMEOUT_S:
        raise ValueError(f"timeout_s must be a number in (0, {MAX_TIMEOUT_S}]")
    return float(timeout_s)


def _check_lag(lag_ns) -> int:
    if type(lag_ns) is not int or not 0 <= lag_ns <= MAX_DELTA_NS:
        raise ValueError(f"lag_ns must be an int in [0, {MAX_DELTA_NS}]")
    return lag_ns


def child_command(manifest_path, tape_path, *, coverage_path=None, lag_ns: int = 0) -> list[str]:
    command = [sys.executable, "-m", "leafhft.books", "replay", "--manifest", str(Path(manifest_path).resolve()),
               "--tape", str(Path(tape_path).resolve()), "--lag-ns", str(_check_lag(lag_ns))]
    if coverage_path is not None:
        command += ["--coverage", str(Path(coverage_path).resolve())]
    return command


def _child_env(seed: str) -> dict:
    env = dict(os.environ)
    env["PYTHONHASHSEED"] = seed
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONPATH"] = os.pathsep.join(filter(None, (str(_PACKAGE_ROOT), env.get("PYTHONPATH"))))
    return env


def run_children(command: list[str], hash_seeds, timeout_s: float = CHILD_TIMEOUT_S) -> list[tuple[int, bytes, bytes]]:
    """Run `command` once per seed, concurrently, under one shared deadline; every child still
    alive when this returns or raises is killed. Returns (returncode, stdout, stderr) per seed.
    Seeds need not be distinct here, so the same seed can be replayed twice."""
    seeds = tuple(hash_seeds)
    if not seeds or any(type(s) is not str or not _SEED.fullmatch(s) for s in seeds):
        raise ValueError("hash_seeds: decimal PYTHONHASHSEED values")
    timeout = _check_timeout(timeout_s)
    procs, results = [], []
    try:
        for seed in seeds:
            procs.append(subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE, env=_child_env(seed), cwd=str(_PACKAGE_ROOT)))
        deadline = time.monotonic() + timeout
        for proc in procs:
            out, err = proc.communicate(timeout=max(0.001, deadline - time.monotonic()))
            results.append((proc.returncode, out, err))
    except subprocess.TimeoutExpired:
        raise ConformFailed("replay_timeout", f"a replay child exceeded {timeout} s") from None
    except OSError as exc:
        raise ConformFailed("replay_failed", f"could not start a replay child: {exc}") from None
    finally:
        for proc in procs:
            if proc.poll() is None:
                proc.kill()
                proc.wait()
    return results


def compare_replays(hash_seeds, results) -> dict:
    """The determinism verdict over one (returncode, stdout, stderr) per seed: every child must
    replay, or refuse identically, and the outputs must be byte-equal after normalize_receipt.
    Returns the first child's section."""
    seeds = tuple(hash_seeds)
    if len(seeds) < 2 or len(results) != len(seeds):
        raise ValueError("compare_replays: one result per hash seed, at least two")
    documents = []
    for seed, (code, out, err) in zip(seeds, results):
        if code not in (EXIT_OK, EXIT_REFUSED) or len(out) > MAX_CHILD_OUTPUT:
            tail = err.decode("utf-8", "replace")[-800:]
            raise ConformFailed("replay_failed", f"seed {seed}: exit {code}: {tail}")
        try:
            doc = strict_json_loads(out)
        except StrictJsonError as exc:
            raise ConformFailed("replay_failed", f"seed {seed}: unreadable output: {exc}") from None
        if type(doc) is not dict:
            raise ConformFailed("replay_failed", f"seed {seed}: output is not an object")
        documents.append((code, doc))
    refusals = [doc.get("refused") for code, doc in documents if code == EXIT_REFUSED]
    if refusals:
        if len(refusals) != len(documents) or any(item != refusals[0] for item in refusals):
            raise ConformRefused("nondeterministic", f"hash seeds {list(seeds)}: the children disagree on refusal")
        refused = refusals[0]
        if (type(refused) is not dict or refused.get("code") not in REFUSAL_CODES
                or (refused.get("row") is not None and type(refused.get("row")) is not int)):
            raise ConformFailed("replay_failed", "a replay child refused with an unknown shape or code")
        raise ConformRefused(refused["code"], refused.get("detail", ""), refused.get("row"))
    normalized = [normalize_receipt(doc) for _code, doc in documents]
    for seed, body in zip(seeds[1:], normalized[1:]):
        if body != normalized[0]:
            offset = next((n for n, (a, b) in enumerate(zip(body, normalized[0])) if a != b),
                          min(len(body), len(normalized[0])))
            raise ConformRefused("nondeterministic",
                                 f"seed {seed} differs from seed {seeds[0]} at byte {offset} after normalize_receipt")
    return documents[0][1]


def _module_identity(module, **extra) -> dict:
    source = Path(module.__file__).read_bytes()
    return {"module": module.__name__, **extra, "sha256": hashlib.sha256(source).hexdigest()}


def conform(manifest_path, tape_path, *, coverage_path=None, lag_ns: int = 0, hash_seeds=HASH_SEEDS,
            timeout_s: float = CHILD_TIMEOUT_S) -> dict:
    """The conformance receipt for one book manifest and one tape; ConformRefused (exit 2) or
    ConformFailed (exit 3) otherwise. Cheap refusals come first, before any child starts."""
    seeds = _check_seeds(hash_seeds)
    timeout = _check_timeout(timeout_s)
    lag_ns = _check_lag(lag_ns)
    manifest = load_manifest(manifest_path)
    digest = manifest_digest(manifest)
    fee_report = check_fee_model(manifest)
    coverage_raw = None
    if coverage_path is not None:
        coverage_raw = _read_bounded(coverage_path, MAX_COVERAGE_BYTES, "coverage_invalid", "coverage")
        parse_coverage(coverage_raw, manifest)
    tape_sha, tape_bytes = tape_digest(tape_path)
    command = child_command(manifest_path, tape_path, coverage_path=coverage_path, lag_ns=lag_ns)
    section = compare_replays(seeds, run_children(command, seeds, timeout))
    if section.get("manifest_digest") != digest or section.get("tape_sha256") != tape_sha:
        raise ConformRefused("input_changed", "the manifest or tape changed while it was replayed")
    return {
        "schema": CONFORM_SCHEMA,
        "label": LABEL,
        "book_id": manifest.book_id,
        "manifest_digest": digest,
        "tape_sha256": tape_sha,
        "tape_bytes": tape_bytes,
        "codec": _module_identity(_tape_module, version=CODEC_VERSION),
        "flag_host": _module_identity(_frame_module),
        "clock_domain": CLOCK_DOMAIN,
        "hop_order": [list(pair) for pair in HOP_ORDER],
        "hash_seeds": list(seeds),
        "fee_model": fee_report,
        "coverage": {"declared_gaps": section.get("declared_gaps"),
                     "sha256": None if coverage_raw is None else hashlib.sha256(coverage_raw).hexdigest()},
        "replay": section,
        "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }


# ---------------------------------------------------------------- command line

class _UsageError(Exception):
    pass


class _Parser(argparse.ArgumentParser):
    """argparse's own exit 2 would read as a refusal; a bad command line is exit 3 `usage`."""

    def error(self, message):
        raise _UsageError(message)


def _timeout_arg(text: str) -> float:
    try:
        return _check_timeout(float(text))
    except ValueError:
        raise argparse.ArgumentTypeError(f"a number of seconds in (0, {MAX_TIMEOUT_S}]") from None


def _lag_arg(text: str) -> int:
    try:
        return _check_lag(int(text))
    except ValueError:
        raise argparse.ArgumentTypeError(f"an int in [0, {MAX_DELTA_NS}]") from None


def _parser() -> argparse.ArgumentParser:
    parser = _Parser(prog="python -m leafhft.books", description="Book conformance (B6).")
    verbs = parser.add_subparsers(dest="verb", required=True, parser_class=_Parser)
    for name in ("conform", "replay"):
        verb = verbs.add_parser(name)
        verb.add_argument("--manifest", required=True)
        verb.add_argument("--tape", required=True)
        verb.add_argument("--coverage", default=None, help="declared gaps bound to the manifest digest")
        verb.add_argument("--lag-ns", type=_lag_arg, default=0, help="replay clock lag")
        if name == "conform":
            verb.add_argument("--out", default=None)
            verb.add_argument("--timeout-s", type=_timeout_arg, default=CHILD_TIMEOUT_S,
                              help="shared deadline for the replay children")
    return parser


def _emit(doc: dict, code: int) -> int:
    sys.stdout.write(canonical_json(doc).decode("ascii") + "\n")
    sys.stdout.flush()
    return code


def _write_atomic(path: Path, data: bytes) -> None:
    tmp = path.with_name(f"{path.name}.tmp{os.getpid()}")
    try:
        with open(tmp, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def main(argv=None) -> int:
    """0 conforms, 2 refused, 3 no verdict; exactly one JSON object on stdout, never a traceback."""
    try:
        try:
            args = _parser().parse_args(argv)
        except _UsageError as exc:
            raise ConformFailed("usage", str(exc)) from None
        if args.verb == "replay":
            return _emit(replay_section(args.manifest, args.tape, coverage_path=args.coverage,
                                        lag_ns=args.lag_ns), EXIT_OK)
        receipt = conform(args.manifest, args.tape, coverage_path=args.coverage, lag_ns=args.lag_ns,
                          timeout_s=args.timeout_s)
        body = canonical_json(receipt) + b"\n"
        if args.out is not None:
            _write_atomic(Path(args.out), body)
        return _emit(receipt, EXIT_OK)
    except ConformRefused as exc:
        return _emit({"refused": exc.to_dict()}, EXIT_REFUSED)
    except ConformFailed as exc:
        sys.stderr.write(f"books conform: {exc}\n")
        return _emit({"error": exc.to_dict()}, EXIT_FAILED)
    except Exception as exc:  # noqa: BLE001 - the exit-3 contract: never a traceback on stdout
        sys.stderr.write(f"books conform: internal: {type(exc).__name__}: {str(exc)[:500]}\n")
        return _emit({"error": {"code": "internal", "detail": type(exc).__name__}}, EXIT_FAILED)
