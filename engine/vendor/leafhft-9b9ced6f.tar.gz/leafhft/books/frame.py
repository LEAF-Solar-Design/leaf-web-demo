"""Frames and flags: one declared clock domain and the red-only skip gates (B-STD B2; B-D6,
B-D7, B-D8; amendment 5).

Every timestamp on a Frame is integer epoch nanoseconds from the RECEIVE clock (clock.now_ns),
the declared clock domain CLOCK_DOMAIN. perf_counter_ns readings are durations only: they ride
in `deltas_ns`, never in a timestamp slot. The two ranges cannot overlap (a timestamp before
2020-01-01 or a duration of an hour or more is refused), so mixing them fails closed at
construction, and so does a stamp later than the frame's own `now_ns`.

Freshness is per ticker: `inputs_as_of_ns` is the older of the quote and index receive times,
and the green bound is the stricter of the manifest's `flag_quote_age_ms` and the kernel's
declared need (never the 60 s max_quote_age_ms, never eval_at_ms). Only the kernel gate
`passed` can be green; `skip_market_full` reads red `engine_room` and `skip_refire_gap` reads
red `engine_refire`. A gap or a kernel event error holds every flag of that kernel red until one
whole turn completes clean. A flag carries `window_id`, the market's close_ms as a string.

Pure: no I/O and no clock reads. A flag reason is an engine_reasons code, FLAG_REASONS (slice B4)
or REASONS; there is no second vocabulary (B-D10).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from types import MappingProxyType

from .. import engine_reasons
from .manifest import BookManifest

CLOCK_DOMAIN = "epoch_ns"  # the flag host's spelling (lanes/flags.py CLOCK_DOMAIN)
# #454's spelling, still passed by existing callers; normalized to CLOCK_DOMAIN at Frame construction.
CLOCK_DOMAIN_ALIASES = MappingProxyType({"epoch_ns.recv": CLOCK_DOMAIN})
MIN_EPOCH_NS = 1_577_836_800 * 10**9  # 2020-01-01T00:00:00Z
# 2100-01-01T00:00:00Z, INCLUSIVE as #454 and types.MAX_TS_NS accept it (tests/test_types.py pins
# MAX_TS_NS + 1 as the first refused stamp); same value as the flag host's EPOCH_NS_CEILING.
MAX_EPOCH_NS = 4_102_444_800 * 10**9
MAX_DELTA_NS = 3_600 * 10**9  # an hour; any perf_counter_ns delta is far shorter
MAX_DELTAS = 16
MAX_COUNT = 2**62
NS_PER_MS = 1_000_000

GREEN = "green"
RED = "red"
COLOURS = (GREEN, RED)
GREEN_GATE = "passed"
RED_GATE_REASONS = MappingProxyType({"skip_market_full": "engine_room", "skip_refire_gap": "engine_refire"})
FLAG_REASON_CODES = frozenset(engine_reasons.FLAG_REASONS)  # B4's table, never a second vocabulary

_NAME = re.compile(r"[A-Za-z0-9_.:/-]{1,64}")
_GATE = re.compile(r"[a-z0-9_]{1,64}")
_DELTA_NAME = re.compile(r"[a-z0-9_]{1,32}")
_WINDOW_ID = re.compile(r"[1-9][0-9]{0,15}")


class ClockDomainError(ValueError):
    """A timestamp outside the declared clock domain, a future stamp, or a duration in a stamp slot."""

    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}: {detail}")
        self.code = code


class FrameInvalid(ValueError):
    """A malformed frame or flag record."""

    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}: {detail}")
        self.code = code


def epoch_ns(value, where: str) -> int:
    """Return value when it is epoch ns on the receive clock; ClockDomainError otherwise."""
    if type(value) is not int:
        raise ClockDomainError("not_epoch_ns", f"{where} must be an int")
    if not MIN_EPOCH_NS <= value <= MAX_EPOCH_NS:
        raise ClockDomainError("not_epoch_ns", f"{where}={value} is not epoch ns on the receive clock "
                                               "(a perf_counter_ns reading is a duration, never a timestamp)")
    return value


def _name(value, where: str) -> None:
    if type(value) is not str or not _NAME.fullmatch(value):
        raise FrameInvalid("bad_name", f"{where} must match {_NAME.pattern}")


def _count(value, where: str) -> None:
    if type(value) is not int or not 0 <= value <= MAX_COUNT:
        raise FrameInvalid("bad_count", f"{where} must be an int in [0, 2**62]")


def _gate(value, where: str) -> None:
    if value is not None and (type(value) is not str or not _GATE.fullmatch(value)):
        raise FrameInvalid("bad_gate", f"{where} must be None or match {_GATE.pattern}")


def _close_ms(value) -> None:
    if type(value) is not int:
        raise ClockDomainError("not_epoch_ns", "close_ms must be an int")
    epoch_ns(value * NS_PER_MS, "close_ms")


@dataclass(frozen=True, slots=True)
class FlagRecord:
    """The host's flag for one ticker in one window: red or green, and why."""

    book_id: str
    ticker: str
    window_id: str
    colour: str
    reason: str
    is_final: bool
    gate: str | None
    turn: int
    sequence: int
    eval_ns: int

    def __post_init__(self):
        _name(self.book_id, "book_id")
        _name(self.ticker, "ticker")
        if type(self.window_id) is not str or not _WINDOW_ID.fullmatch(self.window_id):
            raise FrameInvalid("bad_window", "window_id is the market close_ms as a decimal string")
        if self.colour not in COLOURS:
            raise FrameInvalid("bad_colour", f"colour must be one of {COLOURS}")
        if type(self.reason) is not str or (self.reason not in FLAG_REASON_CODES
                                            and self.reason not in engine_reasons.REASONS):
            raise FrameInvalid("bad_reason", "reason must be a flag or engine_reasons code")
        if (self.colour == GREEN) != (self.reason == GREEN_GATE):
            raise FrameInvalid("green_requires_passed", "only reason 'passed' is green, and 'passed' is never red")
        if type(self.is_final) is not bool:
            raise FrameInvalid("bad_type", "is_final must be a bool")
        _gate(self.gate, "gate")
        _count(self.turn, "turn")
        _count(self.sequence, "sequence")
        epoch_ns(self.eval_ns, "eval_ns")


@dataclass(frozen=True, slots=True)
class Frame:
    """One kernel evaluation of one ticker, every stamp in CLOCK_DOMAIN."""

    book_id: str
    ticker: str
    close_ms: int
    now_ns: int
    quote_recv_ns: int | None
    index_recv_ns: int | None
    gate: str | None
    turn: int
    sequence: int
    gap: bool = False
    error: bool = False
    deltas_ns: tuple[tuple[str, int], ...] = ()
    clock_domain: str = CLOCK_DOMAIN
    flag: FlagRecord | None = None

    def __post_init__(self):
        if type(self.clock_domain) is str and self.clock_domain in CLOCK_DOMAIN_ALIASES:
            object.__setattr__(self, "clock_domain", CLOCK_DOMAIN_ALIASES[self.clock_domain])
        if self.clock_domain != CLOCK_DOMAIN:
            raise ClockDomainError("clock_domain_mismatch", f"frames declare {CLOCK_DOMAIN!r} only")
        _name(self.book_id, "book_id")
        _name(self.ticker, "ticker")
        now = epoch_ns(self.now_ns, "now_ns")
        for where in ("quote_recv_ns", "index_recv_ns"):
            stamp = getattr(self, where)
            if stamp is not None and epoch_ns(stamp, where) > now:
                raise ClockDomainError("future_stamp", f"{where} is later than now_ns")
        _close_ms(self.close_ms)
        _gate(self.gate, "gate")
        _count(self.turn, "turn")
        _count(self.sequence, "sequence")
        if type(self.gap) is not bool or type(self.error) is not bool:
            raise FrameInvalid("bad_type", "gap and error must be bools")
        if type(self.deltas_ns) is not tuple or len(self.deltas_ns) > MAX_DELTAS:
            raise FrameInvalid("bad_deltas", f"deltas_ns must be a tuple of at most {MAX_DELTAS} pairs")
        seen = set()
        for pair in self.deltas_ns:
            if type(pair) is not tuple or len(pair) != 2:
                raise FrameInvalid("bad_deltas", "each delta is a (name, ns) pair")
            name, value = pair
            if type(name) is not str or not _DELTA_NAME.fullmatch(name) or name in seen:
                raise FrameInvalid("bad_deltas", "delta names are unique and match [a-z0-9_]{1,32}")
            seen.add(name)
            if type(value) is not int:
                raise FrameInvalid("bad_deltas", f"delta {name} must be an int")
            if value >= MIN_EPOCH_NS:
                raise ClockDomainError("epoch_in_delta", f"delta {name} holds an epoch timestamp, not a duration")
            if not 0 <= value <= MAX_DELTA_NS:
                raise ClockDomainError("delta_out_of_range", f"delta {name} must be in [0, {MAX_DELTA_NS}] ns")
        if self.flag is not None:
            flag = self.flag
            if (not isinstance(flag, FlagRecord) or flag.book_id != self.book_id
                    or flag.ticker != self.ticker or flag.window_id != self.window_id
                    or flag.turn != self.turn or flag.sequence != self.sequence
                    or flag.eval_ns != self.now_ns):
                raise FrameInvalid("flag_mismatch", "a frame's flag must describe that frame")

    @property
    def window_id(self) -> str:
        return str(self.close_ms)

    @property
    def close_ns(self) -> int:
        return self.close_ms * NS_PER_MS

    @property
    def inputs_as_of_ns(self) -> int | None:
        """The older of the quote and index receive times; None when either is missing."""
        if self.quote_recv_ns is None or self.index_recv_ns is None:
            return None
        return min(self.quote_recv_ns, self.index_recv_ns)

    @property
    def is_final(self) -> bool:
        """True once the receive clock has reached the window's close."""
        return self.now_ns >= self.close_ns


def freshness_bound_ms(manifest_age_ms: int, kernel_need_ms: int | None = None) -> int:
    """The stricter of the manifest's flag_quote_age_ms and the kernel's declared need."""
    if type(manifest_age_ms) is not int or manifest_age_ms <= 0:
        raise ValueError("manifest_age_ms must be a positive int")
    if kernel_need_ms is None:
        return manifest_age_ms
    if type(kernel_need_ms) is not int or kernel_need_ms <= 0:
        raise ValueError("kernel_need_ms must be None or a positive int")
    return min(manifest_age_ms, kernel_need_ms)


def is_fresh(frame: Frame, bound_ms: int) -> bool:
    """Both inputs present and the older one at most bound_ms old at frame.now_ns (inclusive)."""
    as_of = frame.inputs_as_of_ns
    return as_of is not None and frame.now_ns - as_of <= bound_ms * NS_PER_MS


def classify_gate(gate: str | None) -> tuple[str, str]:
    """Colour and reason from the kernel's evaluation state alone, before freshness and holds."""
    if gate is None:
        return RED, "no_flag"
    if gate == GREEN_GATE:
        return GREEN, GREEN_GATE
    reason = RED_GATE_REASONS.get(gate)
    return RED, reason if reason is not None else "engine_declined"


class FlagHold:
    """Per kernel: a gap or a kernel error holds every flag red until one whole turn completes clean.

    The turn that carried the gap is red, the first clean turn after it is red while the state is
    rebuilt, and the next turn is judged normally. Turns never regress.
    """

    __slots__ = ("reason", "_dirty_turn", "_clean_turn", "_last_turn")

    def __init__(self):
        self.reason: str | None = None
        self._dirty_turn = -1
        self._clean_turn: int | None = None
        self._last_turn = -1

    def observe(self, turn: int, *, gap: bool, error: bool) -> str | None:
        """Return the holding reason for a flag in this turn, or None when it is not held."""
        _count(turn, "turn")
        if turn < self._last_turn:
            raise FrameInvalid("turn_regressed", f"turn {turn} after turn {self._last_turn}")
        self._last_turn = turn
        if gap or error:
            self.reason = "feed_gap" if gap else "kernel_error"
            self._dirty_turn, self._clean_turn = turn, None
            return self.reason
        if self.reason is None:
            return None
        if turn == self._dirty_turn:
            return self.reason
        if self._clean_turn is None:
            self._clean_turn = turn
            return self.reason
        if turn == self._clean_turn:
            return self.reason
        self.reason, self._clean_turn = None, None
        return None


def evaluate_flag(frame: Frame, manifest: BookManifest, *, hold: FlagHold,
                  kernel_need_ms: int | None = None) -> FlagRecord:
    """The host's flag for one frame: a pure function of the frame, the manifest and the hold."""
    if not isinstance(frame, Frame):
        raise TypeError("evaluate_flag expects a Frame")
    if not isinstance(manifest, BookManifest):
        raise TypeError("evaluate_flag expects a BookManifest")
    if not isinstance(hold, FlagHold):
        raise TypeError("evaluate_flag expects a FlagHold")
    if frame.book_id != manifest.book_id:
        raise FrameInvalid("book_mismatch", f"frame book {frame.book_id!r} is not {manifest.book_id!r}")
    bound_ms = freshness_bound_ms(manifest.flag_quote_age_ms, kernel_need_ms)
    held = hold.observe(frame.turn, gap=frame.gap, error=frame.error)
    colour, reason = classify_gate(frame.gate)
    if held is not None:
        colour, reason = RED, held
    elif colour == GREEN:
        if frame.is_final:
            colour, reason = RED, "window_closed"
        elif not is_fresh(frame, bound_ms):
            colour, reason = RED, "stale_input"
    return FlagRecord(book_id=frame.book_id, ticker=frame.ticker, window_id=frame.window_id,
                      colour=colour, reason=reason, is_final=frame.is_final, gate=frame.gate,
                      turn=frame.turn, sequence=frame.sequence, eval_ns=frame.now_ns)
