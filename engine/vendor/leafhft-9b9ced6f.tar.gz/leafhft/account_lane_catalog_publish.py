"""Detached C14-B catalog artifacts. Publication grants no execution authority.

This library seam has no automatic caller or live consumer. Callers must supply
an existing trusted output root and explicitly opt in on each invocation.
"""
from __future__ import annotations

from contextlib import contextmanager
import ctypes
import errno
import hashlib
import os
from pathlib import Path
import secrets
import stat

from . import ENGINE_CATALOG_CAPACITY
from . import account_lane_catalog_audit as audit
from . import account_lane_agent as agent
from . import account_lane_provision as provision
from .engine_registry import MAX_ASSIGNMENTS

SCHEMA = "leafhft.account-lane-catalog-publication.v1"
_POSIX = os.name == "posix"
_LOCK = ".catalog-publication-lock"
_ASSIGNMENT_MAX = min(ENGINE_CATALOG_CAPACITY, MAX_ASSIGNMENTS)


def _metadata(path):
    return path.lstat()


def _object_id(info):
    return info.st_dev, info.st_ino


def _trusted(info, *, directory, mode=None):
    """Separate trust from byte equality; metadata can be supplied by test hosts."""
    kind = stat.S_ISDIR if directory else stat.S_ISREG
    if (not kind(info.st_mode)
            or getattr(info, "st_file_attributes", 0) & 0x400
            or (not directory and info.st_nlink != 1)):
        raise audit._Unavailable("destination_unsafe")
    if _POSIX:
        permissions = stat.S_IMODE(info.st_mode)
        if (info.st_uid != 0
                or (mode is not None and permissions != mode)
                or (mode is None and (permissions & 0o022 or permissions & 0o111 != 0o111))):
            raise audit._Unavailable("destination_unsafe")


def _directory(path, mode):
    info = _metadata(path)
    _trusted(info, directory=True, mode=mode)
    return _object_id(info)


def _output_root(value):
    try:
        spelling = os.fspath(value).replace("\\", "/")
        if spelling.startswith("//"):
            raise audit._Unavailable("destination_unsafe")
        if any(part.endswith((" ", ".")) for part in spelling.split("/")):
            raise audit._Unavailable("destination_unsafe")
        root = Path(value)
        if not root.is_absolute() or ".." in root.parts:
            raise audit._Unavailable("destination_unsafe")
        # Reject alternate data streams and ambiguous Windows component spelling
        # even when a POSIX test host would accept it as an ordinary filename.
        for part in root.parts[1:]:
            if any(char in part for char in ':<>"|?*') or part.endswith((" ", ".")):
                raise audit._Unavailable("destination_unsafe")
        resolved_root = os.path.normcase(os.path.realpath(root))
        for protected in (provision.ENGINE_SOURCE, provision.REGISTRY_DIR,
                          agent.STATE_ROOT, agent.CONFIG_ROOT, agent.PROJECTION_ROOT,
                          agent.RUN_ROOT, agent.AGENT_ROOT):
            resolved_protected = os.path.normcase(os.path.realpath(protected))
            try:
                common = os.path.commonpath((resolved_root, resolved_protected))
            except ValueError:
                # Paths on different Windows drives cannot overlap.
                continue
            if common in (resolved_root, resolved_protected):
                raise audit._Unavailable("destination_overlap")
        identity = _directory(root, 0o755)
        for parent in root.parents:
            _directory(parent, None)
        return root, identity
    except (TypeError, ValueError):
        raise audit._Unavailable("destination_unsafe") from None


def _exists(path):
    try:
        _metadata(path)
        return True
    except FileNotFoundError:
        return False


def _same_object(path, identity):
    try:
        return _object_id(_metadata(path)) == identity
    except FileNotFoundError:
        return False


@contextmanager
def _exclusive(root):
    """All cooperating publishers hold this lock through the directory rename.

    Never reclaim an existing lock: a competing or interrupted invocation yields
    a static contention refusal. Only the invocation that made it may remove it.
    """
    lock = root / _LOCK
    try:
        lock.mkdir(mode=0o700)
    except FileExistsError:
        raise audit._Unavailable("publication_contended") from None
    identity = _object_id(_metadata(lock))
    try:
        _directory(lock, 0o700)
        yield
    finally:
        if _same_object(lock, identity):
            lock.rmdir()


def _receipt(lane_id, capture):
    view = capture.projection[0]
    return {"schema": SCHEMA, "lane_id": lane_id, "domain": view["domain"],
            "projection_generation": capture.projection[3][0],
            "projection_digest": capture.projection[3][1], "exit_only": view["exit_only"],
            "assigned_engine_ids": sorted(capture.sources),
            "byte_digests": {eid: hashlib.sha256(data[0]).hexdigest()
                             for eid, data in sorted(capture.sources.items())}}


def _validate_artifact(path, receipt_bytes, sources, *, staging=False):
    """Require the entire immutable tree, not just an expected subset of files."""
    mode = 0o700 if staging else 0o555
    before = _directory(path, mode)
    if {entry.name for entry in path.iterdir()} != {"engines", "receipt.json"}:
        raise audit._Unavailable("destination_conflict")
    engines = path / "engines"
    engine_identity = _directory(engines, 0o555)
    if {entry.name for entry in engines.iterdir()} != {eid + ".json" for eid in sources}:
        raise audit._Unavailable("destination_conflict")
    expected = {path / "receipt.json": receipt_bytes,
                **{engines / (eid + ".json"): data[0] for eid, data in sources.items()}}
    for file, data in expected.items():
        info = _metadata(file)
        _trusted(info, directory=False, mode=0o444)
        actual, _ = audit._read(file, len(data), "destination")
        if actual != data:
            raise audit._Unavailable("destination_conflict")
        after = _metadata(file)
        _trusted(after, directory=False, mode=0o444)
        if audit._identity(info) != audit._identity(after):
            raise audit._Unavailable("destination_changed")
    if before != _directory(path, mode) or engine_identity != _directory(engines, 0o555):
        raise audit._Unavailable("destination_changed")


def _rename_no_replace(source, destination):
    # Windows rename already refuses any existing destination. POSIX rename can
    # replace an empty directory, so use the platform's atomic exclusive variant.
    if os.name != "posix":
        os.rename(source, destination)
        return
    libc = ctypes.CDLL(None, use_errno=True)
    if hasattr(libc, "renameat2"):
        rename = libc.renameat2
        rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int,
                           ctypes.c_char_p, ctypes.c_uint]
        rename.restype = ctypes.c_int
        result = rename(-100, os.fsencode(source), -100, os.fsencode(destination), 1)
    elif hasattr(libc, "renamex_np"):
        rename = libc.renamex_np
        rename.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_uint]
        rename.restype = ctypes.c_int
        result = rename(os.fsencode(source), os.fsencode(destination), 4)
    else:
        raise audit._Unavailable("publication_atomic_rename_unavailable")
    if result:
        code = ctypes.get_errno()
        if code == errno.EEXIST:
            raise FileExistsError(code, "publication destination exists")
        raise OSError(code, "publication rename failed")


def _write_file(path, data, owned):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL
                 | getattr(os, "O_NOFOLLOW", 0), 0o600)
    with os.fdopen(fd, "wb") as stream:
        owned[path] = _object_id(_metadata(path))
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    path.chmod(0o444)


def _cleanup(stage, directories, files):
    """Clean only recorded objects belonging to this invocation, never walk a tree."""
    if stage not in directories or not _same_object(stage, directories[stage]):
        return
    for path, identity in directories.items():
        if _same_object(path, identity):
            path.chmod(0o700)
    for path, identity in files.items():
        if (_same_object(path.parent, directories[path.parent])
                and _same_object(path, identity)):
            path.chmod(0o600)
            path.unlink()
    for path, identity in reversed(tuple(directories.items())):
        if _same_object(path, identity):
            try:
                path.rmdir()
            except OSError:
                # Unexpected children belong to someone else. Never recurse.
                pass


def _revalidate(paths, capture):
    audit._revalidate_sources(capture)
    audit._revalidate_projection(paths, capture)


def _check_assignment_bound(paths):
    """Count bounded input before projection validation or manifest reads."""
    try:
        path = agent.registry_projection_path(paths)
        data, _ = audit._read(path, audit.MAX_REGISTRY_BYTES, "projection")
    except agent.LaneRefused:
        raise audit._Unavailable("projection_unsafe") from None
    except audit._Unavailable as exc:
        if str(exc) == "projection_missing":
            raise audit._Unavailable("projection_absent") from None
        raise
    try:
        doc = audit.strict_loads(data, audit.MAX_REGISTRY_BYTES)
    except (audit.RegistryError, ValueError, RecursionError):
        raise audit._Unavailable("projection_invalid") from None
    if (type(doc) is dict and type(doc.get("assignments")) is dict
            and len(doc["assignments"]) > _ASSIGNMENT_MAX):
        raise audit._Unavailable("source_oversized")


def publish_lane_catalog(lane_id, output_root, *, enabled=False):
    """Publish captured assignments as a detached snapshot, with integration OFF."""
    report = {"schema": SCHEMA, "status": "disabled", "refusal_codes": [],
              "snapshot_id": None, "receipt": None}
    if enabled is not True:
        return report
    report["status"] = "unavailable"
    try:
        try:
            lane_id = agent.identifier(lane_id)
        except agent.LaneRefused:
            raise audit._Unavailable("invalid_lane_id") from None
        root, root_identity = _output_root(output_root)
        paths = agent.LanePaths(lane_id)
        # At catalog capacity 1024 and registry limit 1024, captured manifests
        # total at most 8,388,608 bytes (8 MiB; _ASSIGNMENT_MAX * audit.MANIFEST_MAX).
        # Each manifest read is at most 8,193 bytes including overflow detection;
        # the projection count read is at most 1,048,577 bytes including overflow.
        _check_assignment_bound(paths)
        # Recheck the accepted count if the projection changed after the precheck.
        capture = audit._capture_assigned(paths, assignment_limit=_ASSIGNMENT_MAX)
        receipt = _receipt(lane_id, capture)
        receipt_bytes = agent.canonical(receipt)
        snapshot_id = hashlib.sha256(receipt_bytes).hexdigest()
        final = root / snapshot_id
        with _exclusive(root):
            if _output_root(root)[1] != root_identity:
                raise audit._Unavailable("destination_changed")
            if _exists(final):
                _validate_artifact(final, receipt_bytes, capture.sources)
                _revalidate(paths, capture)
                if _output_root(root)[1] != root_identity:
                    raise audit._Unavailable("destination_changed")
                status = "unchanged"
            else:
                stage = root / (".catalog-stage-" + secrets.token_hex(16))
                directories, files = {}, {}
                try:
                    stage.mkdir(mode=0o700)
                    directories[stage] = _object_id(_metadata(stage))
                    _directory(stage, 0o700)
                    engines = stage / "engines"
                    engines.mkdir(mode=0o700)
                    directories[engines] = _object_id(_metadata(engines))
                    _directory(engines, 0o700)
                    for eid, captured in capture.sources.items():
                        _write_file(engines / (eid + ".json"), captured[0], files)
                    _write_file(stage / "receipt.json", receipt_bytes, files)
                    engines.chmod(0o555)
                    _validate_artifact(stage, receipt_bytes, capture.sources, staging=True)
                    _revalidate(paths, capture)
                    if _output_root(root)[1] != root_identity:
                        raise audit._Unavailable("destination_changed")
                    # Under the lock, no cooperating publisher can win between
                    # this check and rename. Still preserve an externally supplied
                    # destination, even an empty directory, without replacing it.
                    if _exists(final):
                        _validate_artifact(final, receipt_bytes, capture.sources)
                        status = "unchanged"
                    else:
                        stage.chmod(0o555)
                        _directory(stage, 0o555)
                        try:
                            _rename_no_replace(stage, final)
                            status = "published"
                        except FileExistsError:
                            _validate_artifact(final, receipt_bytes, capture.sources)
                            status = "unchanged"
                finally:
                    _cleanup(stage, directories, files)
        report.update(status=status, snapshot_id=snapshot_id, receipt=receipt)
    except audit._Unavailable as exc:
        report["refusal_codes"] = [str(exc)]
    except agent.LaneRefused:
        report["refusal_codes"] = ["destination_unsafe"]
    except (OSError, ValueError, audit.EngineError):
        report["refusal_codes"] = ["publication_unreadable"]
    return report
