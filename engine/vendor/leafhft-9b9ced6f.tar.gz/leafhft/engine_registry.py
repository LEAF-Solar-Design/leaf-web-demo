"""The standing engine registry: one engine, one account, by shape (plan D4, D5a, VII.4).

`/var/lib/leafhft/engine-registry/assignments.json` is keyed by engine_id, so an engine can be
assigned to at most one account without any runtime check at all. The same generation-chained
document carries the D5a loss breakers and the VII.4 exposure authority (member_key per account,
exit_only in the projection, authority and transfer state per member), so neither needs a
migration of a chained file later.

Writers hold `kalshi_pool._FileLock` on `<dir>/.lock` for one load-decide-write cycle, append one
`journal.jsonl` row per generation BEFORE the atomic replace, and re-decode what they are about to
write, so a writer can never save a file the reader refuses. Every commit then writes the same bytes
to `projection.json` (0444), the file the books read; `RegistryStore.project()` rewrites it for
recovery. The publication marker `publication.json` (0444, {generation, digest, state}) brackets
each commit: "publishing" before the registry replace, "published" after the projection, so a crash
or a failed write between them leaves a marker the books' reader refuses (`publication_incomplete`)
until `RegistryStore.load()` or `project()` completes the publication. Readers on the entry hot path
use `RegistryProjection`: one `os.stat` per file per call and a re-parse only when (mtime, inode,
size) changes; an absent or invalid file fails closed (`assignment_allows` False, `exit_only` None).

Every numeric field is a DECIMAL STRING. The strict decoder refuses any JSON number, duplicate
keys, unknown keys, and more than 1024 assignments; `digest` is sha256 over canonical JSON of the
document without `digest`, and `previous_digest` chains each generation to the one before it.

X1c (found live 2026-09-24 07:24Z): an account's registry key ("owner", a lane id) is not the id a
book hands the gate. A book passes the verified account id its dashboard identity file names
(cli._kalshi_probe_account_id), so schema v2 gives every account `book_account_id`, that exact
string or null, and the gate admits the caller by the assignment's account key OR that account's
book id. A document stays v1 (the C1 shape pre-X1c readers decode) until the first book id is
stamped, and a v2 document never goes back; the decoder reads both.
"""
from __future__ import annotations

import functools
import hashlib
import json
import os
import re
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from .broker.kalshi_pool import _FileLock

SCHEMA = "leafhft.engine_registry.v1"
# X1c: v1 plus `book_account_id` on every account; written once any account carries one.
SCHEMA_V2 = "leafhft.engine_registry.v2"
REGISTRY_SCHEMAS = (SCHEMA, SCHEMA_V2)
# C14-A: the per-domain VIEW a tenant lane receives, never the whole registry.
PROJECTION_SCHEMA = "leafhft.engine_registry.projection.v1"
# X1c: the view plus its account's `book_account_id`; written only when that id is known.
PROJECTION_SCHEMA_V2 = "leafhft.engine_registry.projection.v2"
PUSH_SCHEMA = "leafhft.engine_registry.push.v1"
AUDIT_SCHEMA = "leafhft.engine_registry.audit.v1"
SOURCES_SCHEMA_KEYS = frozenset({"accounts"})
REGISTRY_FILE = "assignments.json"
# C1c: what the books read (live-run.sh --engine-registry): the committed registry bytes, 0444.
PROJECTION_FILE = "projection.json"
PROJECTION_MODE = 0o444
# C6d fix b: the marker beside the projection that says whether the last commit finished publishing.
PUBLICATION_FILE = "publication.json"
PUBLISHING = "publishing"
PUBLISHED = "published"
PUBLICATION_KEYS = frozenset({"generation", "digest", "state"})
MAX_PUBLICATION_BYTES = 512
JOURNAL_FILE = "journal.jsonl"
AUDIT_FILE = "audit.json"
LOCK_FILE = ".lock"

MAX_ASSIGNMENTS = 1024
MAX_ACCOUNTS = 32
MAX_ROLE_POINTS = 256
# All validator bounds together: 2,400,781 canonical bytes (worst_case_document test).
# Next power of two >= 1.25 times that size, including v2 UTF-8 ids and role history.
# test_worst_case_strict_decode_and_validation_budget in tests/test_engine_registry.py
# bounds strict_loads + validate_document to 2 s;
# measured 0.076413 s for strict_loads + validate_document of the 2,400,781-byte worst case on Evans-Dekstop (Windows AMD64, Python 3.13.5), 2026-09-27
MAX_REGISTRY_BYTES = 4 * 1024 * 1024
MAX_BINDINGS_BYTES = 4096
MAX_SOURCES_BYTES = 64 * 1024
MAX_PUSH_BYTES = 64 * 1024
MAX_DASHBOARD_REGISTRY_BYTES = 262_144
MAX_DASHBOARD_ASSIGNMENTS = 512
MAX_JOURNAL_ROW_BYTES = 4096
MAX_AUDIT_FINDINGS = 256
JOURNAL_SHOWN = 64
JOURNAL_ROTATE_BYTES = 4 * 1024 * 1024
# load()'s widest walk back through tentative rows; the read itself is capped by the two files' size.
MAX_JOURNAL_WALK = 2 * 8 ** 5
MAX_GENERATION = 999_999_999
MAX_LABEL = 48
# cli._kalshi_probe_account_id passes 1..128 characters; engines.account_id refuses control chars.
MAX_BOOK_ACCOUNT_ID = 128
LOCK_TIMEOUT_S = 5.0

DEFAULT_BREAKER_PCT = 50
MIN_BREAKER_PCT = 1
MAX_BREAKER_PCT = 100
DEFAULT_MAX_CONCURRENT_PROBES = 4
MAX_CONCURRENT_PROBES = 1024

LEGACY_OWNER_DOMAIN = "legacy-owner"
ROLES = ("probe", "graduated", "legacy")
OPENING_ROLES = frozenset({"probe", "graduated"})
ACCOUNT_KINDS = ("owner", "tenant")
TRANSFER_STEPS = ("draining", "reconciling", "flat_proven")
DOMAIN_AUTHORITY = "authority"
DOMAIN_EXIT_ONLY = "exit_only"
PROBE_LIFECYCLE_STATES = frozenset({"probe", "probe_sized"})
BREAKER_SCOPES = ("account", "engine")

# Plan D4 violation classes, then the VII.4 exposure classes.
AUDIT_CLASSES = ("bound_unassigned", "bound_to_other_account", "dormant_conflict", "identity_clone",
                 "probe_without_lifecycle", "lifecycle_probe_without_assignment",
                 "bound_outside_symbols", "exposure_two_domains_opening",
                 "exposure_generation_unknown")
# X1 (contracts/X2X3.md 2.1 items 6-7): a dormant owner-engine copy on an exit_only domain of an
# operational member is kept and reported, never a conflict; an observe member's findings on its
# exit_only domains are prefixed `observed_`. Neither counts as a violation.
DORMANT_ON_EXIT_ONLY = "dormant_on_exit_only"
OBSERVED_PREFIX = "observed_"


def is_informational(cls: str) -> bool:
    return cls == DORMANT_ON_EXIT_ONLY or cls.startswith(OBSERVED_PREFIX)

_ENGINE_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,31}")
_KEY_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}")
_REF_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}")
_LANE_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,63}")
_DOMAIN = re.compile(r"legacy-owner|account-lane:[a-z0-9][a-z0-9-]{0,63}")
_ACTION = re.compile(r"[a-z][a-z0-9_.-]{0,31}")
_HEX64 = re.compile(r"[0-9a-f]{64}")
_DECIMAL = re.compile(r"0|[1-9][0-9]{0,8}")
_STAMP = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
# Public names of the key and domain shapes, the same compiled objects the decoder uses, so a
# caller that validates before a read (engine_ops' exposure verbs) holds no restated copy to drift.
KEY_ID_RE = _KEY_ID
DOMAIN_RE = _DOMAIN

_TOP_KEYS = frozenset({"schema", "generation", "previous_digest", "accounts", "assignments",
                       "loss_breakers", "exposure", "max_concurrent_probes",
                       "roles_by_generation", "digest"})
_ACCOUNT_KEYS = frozenset({"kind", "lane_id", "label", "member_key", "domain", "exit_only"})
BOOK_ACCOUNT_ID = "book_account_id"
_ACCOUNT_KEYS_V2 = _ACCOUNT_KEYS | {BOOK_ACCOUNT_ID}
_ASSIGNMENT_KEYS = frozenset({"account_id", "domain", "role", "symbols", "identity_digest",
                              "manifest_digest", "since", "request_id", "approval_id",
                              "previous_bindings"})
_BREAKER_KEYS = frozenset({"default_pct", "accounts", "engines"})
_EXPOSURE_KEYS = frozenset({"members"})
_MEMBER_KEYS = frozenset({"authority_domain", "transfer"})
_TRANSFER_KEYS = frozenset({"draining_from", "started_at", "step"})
_SOURCE_KEYS = frozenset({"account_id", "kind", "lane_id", "label", "member_key", "domain",
                          "bindings"})
_VIEW_KEYS = frozenset({"schema", "generation", "domain", "account_id", "role", "exit_only",
                        "assignments", "roles_by_generation", "digest"})
_VIEW_KEYS_V2 = _VIEW_KEYS | {BOOK_ACCOUNT_ID}
_VIEW_ASSIGNMENT_KEYS = frozenset({"role", "symbols", "since"})
# The reader's refusal of a projection older than the last generation it accepted.
PROJECTION_REPLAYED = "projection_replayed"
# The reader's refusal of a projection whose publication marker does not say it finished.
PUBLICATION_INCOMPLETE = "publication_incomplete"


class RegistryError(ValueError):
    """A refusal or an invalid document. `code` is the stable machine reason; `detail` carries a
    structured report where one exists (init refusals)."""

    def __init__(self, code: str, message: str = "", detail: Any = None) -> None:
        super().__init__(f"{code}: {message}" if message else code)
        self.code = code
        self.detail = detail


@functools.lru_cache(maxsize=1)
def symbols() -> tuple[str, ...]:
    """The live Kalshi symbols, in SYMBOL_MAP order (the push block's mask order)."""
    from .feeds.kalshi import SYMBOL_MAP

    return tuple(SYMBOL_MAP)


@functools.lru_cache(maxsize=1)
def _symbol_set() -> frozenset[str]:
    return frozenset(symbols())


# ---------------------------------------------------------------- strict JSON and canonical form

def _pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise RegistryError("duplicate_key", repr(key))
        out[key] = value
    return out


def _no_number(text: str) -> Any:
    raise RegistryError("non_decimal_string_number",
                        f"JSON number {text!r}; registry numbers are decimal strings")


def strict_loads(data: bytes, limit: int) -> Any:
    """Decode bounded UTF-8 JSON; refuses duplicate keys and every JSON number."""
    if len(data) > limit:
        raise RegistryError("too_large", f"{len(data)} bytes exceeds {limit}")
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs, parse_int=_no_number,
                          parse_float=_no_number, parse_constant=_no_number)
    except RegistryError:
        raise
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise RegistryError("invalid_json", str(exc)) from exc


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


def document_digest(doc: Mapping[str, Any]) -> str:
    """sha256 over canonical JSON of the document without its own `digest` field."""
    return hashlib.sha256(canonical_bytes({k: v for k, v in doc.items() if k != "digest"})).hexdigest()


def _read_bounded(path: Path, limit: int) -> bytes:
    """Read at most `limit` bytes; FileNotFoundError propagates so callers can mean 'absent'."""
    with open(path, "rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise RegistryError("too_large", f"{path} exceeds {limit} bytes")
    return data


def _utc_stamp(now: datetime | None = None) -> str:
    now = datetime.now(timezone.utc) if now is None else now
    if not isinstance(now, datetime) or now.tzinfo is None:
        raise RegistryError("invalid_time", "a timezone-aware datetime is required")
    return now.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


utc_stamp = _utc_stamp  # public name: the registry's fixed-width UTC stamp, naive time refuses


# ---------------------------------------------------------------- field validators (fail closed)

def _exact(value: Any, keys: frozenset[str], where: str) -> dict[str, Any]:
    if type(value) is not dict:
        raise RegistryError("invalid_type", f"{where}: expected an object")
    extra = set(value) - keys
    if extra:
        raise RegistryError("unknown_key", f"{where}: {sorted(extra)}")
    missing = keys - set(value)
    if missing:
        raise RegistryError("missing_key", f"{where}: {sorted(missing)}")
    return value


def _object(value: Any, where: str) -> dict[str, Any]:
    if type(value) is not dict:
        raise RegistryError("invalid_type", f"{where}: expected an object")
    return value


def _match(pattern: re.Pattern[str], value: Any, where: str, *, nullable: bool = False) -> Any:
    if value is None and nullable:
        return None
    if type(value) is not str or pattern.fullmatch(value) is None:
        raise RegistryError("invalid_value", f"{where}: {value!r}")
    return value


def _decimal(value: Any, where: str, low: int, high: int) -> int:
    if type(value) is not str or _DECIMAL.fullmatch(value) is None:
        raise RegistryError("non_decimal_string_number", f"{where}: {value!r}")
    number = int(value)
    if not low <= number <= high:
        raise RegistryError("out_of_range", f"{where}: {number} outside {low}..{high}")
    return number


def _stamp(value: Any, where: str) -> str:
    if type(value) is not str or _STAMP.fullmatch(value) is None:
        raise RegistryError("invalid_value", f"{where}: {value!r}")
    try:
        datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError as exc:
        raise RegistryError("invalid_value", f"{where}: {value!r}") from exc
    return value


def _label(value: Any, where: str) -> str:
    if type(value) is not str or not 1 <= len(value) <= MAX_LABEL or not value.isprintable():
        raise RegistryError("invalid_value", f"{where}: 1..{MAX_LABEL} printable characters")
    return value


def valid_book_account_id(value: Any) -> bool:
    """A string a book can pass the gate: 1..128 printable characters (the identity file's
    account_id, which may be a JSON list such as a lane's provisional ["kashbot-<lane>","kalshi",0])."""
    return type(value) is str and 1 <= len(value) <= MAX_BOOK_ACCOUNT_ID and value.isprintable()


def _book_id(value: Any, where: str) -> str | None:
    if value is not None and not valid_book_account_id(value):
        raise RegistryError("invalid_value", f"{where}: null or 1..{MAX_BOOK_ACCOUNT_ID} printable characters")
    return value


def book_account_conflicts(accounts: Mapping[str, Any]) -> list[str]:
    """Account keys whose book_account_id names ANOTHER account's key, or is shared with an account
    of another member. Two domains of one member (one venue account) may share a book id; the
    gate still checks the assignment's domain, so sharing never widens what a caller may open."""
    by_id: dict[str, list[str]] = {}
    for aid, account in accounts.items():
        book = account.get(BOOK_ACCOUNT_ID)
        if book is not None:
            by_id.setdefault(book, []).append(aid)
    bad: set[str] = set()
    for book, aids in by_id.items():
        if (book in accounts and aids != [book]) or len({accounts[aid]["member_key"] for aid in aids}) > 1:
            bad.update(aids)
    return sorted(bad)


def _symbol_list(value: Any, where: str) -> list[str]:
    known = _symbol_set()
    if (type(value) is not list or not 1 <= len(value) <= len(known)
            or any(type(item) is not str or item not in known for item in value)
            or any(a >= b for a, b in zip(value, value[1:]))):
        raise RegistryError("invalid_symbols", f"{where}: a sorted unique list of known symbols")
    return value


def normalize_symbols(value: Iterable[str]) -> list[str]:
    if isinstance(value, (str, bytes)):
        raise RegistryError("invalid_symbols", "symbols must be a list, not one string")
    items = list(value)
    known = _symbol_set()
    if not items or len(set(items)) != len(items) or any(item not in known for item in items):
        raise RegistryError("invalid_symbols", f"unknown, duplicate or empty symbols {items!r}")
    return sorted(items)


def derive_roles(accounts: Mapping[str, Any], members: Mapping[str, Any]) -> dict[str, str]:
    """Each domain's exposure role: authority for its member's authority_domain, else exit_only."""
    return {account["domain"]: (DOMAIN_AUTHORITY
                                if members[account["member_key"]]["authority_domain"] == account["domain"]
                                else DOMAIN_EXIT_ONLY)
            for account in accounts.values()}


def _role_point(points: Mapping[str, Any], generation: int) -> str | None:
    """Key of the latest role change point at or before `generation` (points are change points)."""
    best = -1
    for key in points:
        value = int(key)
        if best < value <= generation:
            best = value
    return None if best < 0 else str(best)


def validate_document(doc: Any) -> dict[str, Any]:
    """Structural, referential and digest validation of one registry generation; raises on any
    defect so a reader never acts on a partially understood document."""
    _exact(doc, _TOP_KEYS, "registry")
    if doc["schema"] not in REGISTRY_SCHEMAS:
        raise RegistryError("unknown_schema", repr(doc["schema"]))
    account_keys = _ACCOUNT_KEYS_V2 if doc["schema"] == SCHEMA_V2 else _ACCOUNT_KEYS
    generation = _decimal(doc["generation"], "generation", 1, MAX_GENERATION)
    if generation == 1:
        if doc["previous_digest"] is not None:
            raise RegistryError("chain_invalid", "generation 1 carries no previous_digest")
    else:
        _match(_HEX64, doc["previous_digest"], "previous_digest")

    accounts = _object(doc["accounts"], "accounts")
    if not 1 <= len(accounts) <= MAX_ACCOUNTS:
        raise RegistryError("too_many_accounts", f"1..{MAX_ACCOUNTS} accounts")
    domains: dict[str, str] = {}
    for aid, account in accounts.items():
        _match(_KEY_ID, aid, "accounts key")
        where = f"accounts.{aid}"
        _exact(account, account_keys, where)
        _book_id(account.get(BOOK_ACCOUNT_ID), f"{where}.{BOOK_ACCOUNT_ID}")
        if account["kind"] not in ACCOUNT_KINDS:
            raise RegistryError("invalid_value", f"{where}.kind: {account['kind']!r}")
        _match(_LANE_ID, account["lane_id"], f"{where}.lane_id", nullable=True)
        _label(account["label"], f"{where}.label")
        _match(_KEY_ID, account["member_key"], f"{where}.member_key")
        _match(_DOMAIN, account["domain"], f"{where}.domain")
        if type(account["exit_only"]) is not bool:
            raise RegistryError("invalid_value", f"{where}.exit_only: must be a bool")
        if account["domain"] in domains:
            raise RegistryError("domain_reused", f"{account['domain']} on {domains[account['domain']]} and {aid}")
        domains[account["domain"]] = aid
    conflicts = book_account_conflicts(accounts)
    if conflicts:
        raise RegistryError("book_account_id_reused", ", ".join(conflicts))

    members = _object(_exact(doc["exposure"], _EXPOSURE_KEYS, "exposure")["members"], "exposure.members")
    referenced = {account["member_key"] for account in accounts.values()}
    if set(members) != referenced:
        raise RegistryError("member_mismatch", f"members {sorted(members)} != accounts' {sorted(referenced)}")
    for key, member in members.items():
        where = f"exposure.members.{key}"
        _exact(member, _MEMBER_KEYS, where)
        authority = _match(_DOMAIN, member["authority_domain"], f"{where}.authority_domain", nullable=True)
        if authority is not None and (authority not in domains
                                      or accounts[domains[authority]]["member_key"] != key):
            raise RegistryError("authority_domain_unknown", f"{where}: {authority}")
        transfer = member["transfer"]
        if transfer is not None:
            _exact(transfer, _TRANSFER_KEYS, f"{where}.transfer")
            _match(_DOMAIN, transfer["draining_from"], f"{where}.transfer.draining_from")
            _stamp(transfer["started_at"], f"{where}.transfer.started_at")
            if transfer["step"] not in TRANSFER_STEPS:
                raise RegistryError("invalid_value", f"{where}.transfer.step: {transfer['step']!r}")
    roles = derive_roles(accounts, members)
    for aid, account in accounts.items():
        if account["exit_only"] is not (roles[account["domain"]] == DOMAIN_EXIT_ONLY):
            raise RegistryError("exit_only_mismatch", f"accounts.{aid}.exit_only disagrees with authority")

    assignments = _object(doc["assignments"], "assignments")
    if len(assignments) > MAX_ASSIGNMENTS:
        raise RegistryError("too_many_assignments", f"{len(assignments)} > {MAX_ASSIGNMENTS}")
    known = _symbol_set()
    for eid, assignment in assignments.items():
        _match(_ENGINE_ID, eid, "assignments key")
        where = f"assignments.{eid}"
        _exact(assignment, _ASSIGNMENT_KEYS, where)
        account = accounts.get(assignment["account_id"])
        if account is None:
            raise RegistryError("unknown_account", f"{where}.account_id: {assignment['account_id']!r}")
        if assignment["domain"] != account["domain"]:
            raise RegistryError("domain_mismatch", f"{where}.domain != its account's domain")
        if assignment["role"] not in ROLES:
            raise RegistryError("invalid_value", f"{where}.role: {assignment['role']!r}")
        _symbol_list(assignment["symbols"], f"{where}.symbols")
        _match(_HEX64, assignment["identity_digest"], f"{where}.identity_digest", nullable=True)
        _match(_HEX64, assignment["manifest_digest"], f"{where}.manifest_digest", nullable=True)
        _stamp(assignment["since"], f"{where}.since")
        _match(_REF_ID, assignment["request_id"], f"{where}.request_id", nullable=True)
        _match(_REF_ID, assignment["approval_id"], f"{where}.approval_id", nullable=True)
        previous = assignment["previous_bindings"]
        if previous is not None:
            _object(previous, f"{where}.previous_bindings")
            for symbol, engine_id in previous.items():
                if symbol not in known:
                    raise RegistryError("invalid_symbols", f"{where}.previous_bindings: {symbol!r}")
                _match(_ENGINE_ID, engine_id, f"{where}.previous_bindings.{symbol}", nullable=True)

    breakers = _exact(doc["loss_breakers"], _BREAKER_KEYS, "loss_breakers")
    _decimal(breakers["default_pct"], "loss_breakers.default_pct", MIN_BREAKER_PCT, MAX_BREAKER_PCT)
    for aid, pct in _object(breakers["accounts"], "loss_breakers.accounts").items():
        if aid not in accounts:
            raise RegistryError("unknown_account", f"loss_breakers.accounts.{aid}")
        _decimal(pct, f"loss_breakers.accounts.{aid}", MIN_BREAKER_PCT, MAX_BREAKER_PCT)
    for eid, pct in _object(breakers["engines"], "loss_breakers.engines").items():
        if eid not in assignments:
            raise RegistryError("unknown_engine", f"loss_breakers.engines.{eid}")
        if pct is not None:
            _decimal(pct, f"loss_breakers.engines.{eid}", MIN_BREAKER_PCT, MAX_BREAKER_PCT)
    _decimal(doc["max_concurrent_probes"], "max_concurrent_probes", 0, MAX_CONCURRENT_PROBES)

    points = _object(doc["roles_by_generation"], "roles_by_generation")
    if not 1 <= len(points) <= MAX_ROLE_POINTS:
        raise RegistryError("invalid_value", f"roles_by_generation: 1..{MAX_ROLE_POINTS} points")
    for key, mapping in points.items():
        _decimal(key, "roles_by_generation key", 1, generation)
        _object(mapping, f"roles_by_generation.{key}")
        if not 1 <= len(mapping) <= MAX_ACCOUNTS:
            raise RegistryError("invalid_value", f"roles_by_generation.{key}: 1..{MAX_ACCOUNTS} domains")
        for domain, role in mapping.items():
            _match(_DOMAIN, domain, f"roles_by_generation.{key} domain")
            if role not in (DOMAIN_AUTHORITY, DOMAIN_EXIT_ONLY):
                raise RegistryError("invalid_value", f"roles_by_generation.{key}.{domain}: {role!r}")
    current = _role_point(points, generation)
    if current is None or points[current] != roles:
        raise RegistryError("roles_mismatch", "roles_by_generation disagrees with the current authority")

    _match(_HEX64, doc["digest"], "digest")
    if doc["digest"] != document_digest(doc):
        raise RegistryError("digest_mismatch", "digest does not match the document")
    return doc


# ---------------------------------------------------------------- one validated generation

class Registry:
    """One validated registry generation. Treat as immutable; writes go through RegistryStore."""

    __slots__ = ("doc", "_points", "_canonical", "_exit_only", "_member")

    def __init__(self, doc: dict[str, Any]) -> None:
        self.doc = doc
        self._points = sorted(int(key) for key in doc["roles_by_generation"])
        # X1c fix b: {account key or book_account_id: account key} and {same ids: exit_only}, built
        # once per document so a lookup by either id is one dict get. A book id two domains of one
        # member share maps to None in both: it names no single account (validate_document refuses a
        # book id that is another account's key, so a book id never shadows an account key).
        # X1c fix c: {same ids: member_key}. A book id shared by two domains of one member keeps
        # that member_key (book_account_conflicts refuses a book id spanning members).
        canonical: dict[str, str | None] = {aid: aid for aid in doc["accounts"]}
        exit_only: dict[str, bool | None] = {aid: account["exit_only"] for aid, account in doc["accounts"].items()}
        member: dict[str, str] = {aid: account["member_key"] for aid, account in doc["accounts"].items()}
        for aid, account in doc["accounts"].items():
            book = account.get(BOOK_ACCOUNT_ID)
            if book is None or book == aid:
                continue
            member[book] = account["member_key"]
            if book in canonical:
                canonical[book] = None
                if exit_only[book] is not account["exit_only"]:
                    exit_only[book] = None
            else:
                canonical[book], exit_only[book] = aid, account["exit_only"]
        self._canonical, self._exit_only, self._member = canonical, exit_only, member

    @classmethod
    def from_bytes(cls, data: bytes) -> "Registry":
        return cls(validate_document(strict_loads(data, MAX_REGISTRY_BYTES)))

    @classmethod
    def from_document(cls, doc: Mapping[str, Any]) -> "Registry":
        """Round-trips through bytes so an in-memory document meets the same strict decoder."""
        return cls.from_bytes(canonical_bytes(doc))

    def to_bytes(self) -> bytes:
        return canonical_bytes(self.doc)

    def copy_document(self) -> dict[str, Any]:
        return json.loads(self.to_bytes())

    @property
    def generation(self) -> int:
        return int(self.doc["generation"])

    @property
    def digest(self) -> str:
        return self.doc["digest"]

    @property
    def accounts(self) -> Mapping[str, Any]:
        return self.doc["accounts"]

    @property
    def assignments(self) -> Mapping[str, Any]:
        return self.doc["assignments"]

    def roles_at(self, generation: int) -> Mapping[str, str] | None:
        """Each domain's role at `generation`, or None when that generation is unknown (in the
        future, or older than the oldest retained change point)."""
        if type(generation) is not int or not 1 <= generation <= self.generation:
            return None
        best = None
        for point in self._points:
            if point > generation:
                break
            best = point
        return None if best is None else self.doc["roles_by_generation"][str(best)]

    def canonical_account(self, account_or_book_id: str) -> str:
        """The account key for an account key or an account's book_account_id (the id a book passes:
        cli._ProbeHost._loss_breakers, cli._ProbeRegistryGate). One dict get. Raises RegistryError
        unknown_account for an unknown id, and for a book id shared by two domains of one member,
        which names no single account (fails closed)."""
        key = self._canonical.get(account_or_book_id) if type(account_or_book_id) is str else None
        if key is None:
            raise RegistryError("unknown_account", repr(account_or_book_id))
        return key

    def account(self, account_or_book_id: str) -> Mapping[str, Any]:
        """The account record by account key or book id (canonical_account); raises unknown_account."""
        return self.accounts[self.canonical_account(account_or_book_id)]

    def exit_only(self, account_id: str) -> bool | None:
        """By account key or book id: one dict get; None when unknown, or when the accounts sharing
        a book id disagree (fails closed)."""
        return self._exit_only.get(account_id) if type(account_id) is str else None

    def member_key(self, account_or_book_id: str) -> str | None:
        """The member_key of an account key or an account's book_account_id (the day start keying
        check, cli._probe_day_start_account). One dict get. Fails closed: None on unknown."""
        return self._member.get(account_or_book_id) if type(account_or_book_id) is str else None

    def effective_pct(self, account_id: str, engine_id: str | None = None) -> tuple[int, bool]:
        """D5a breaker percentage: (engine pct, False) when the engine is set individually, else
        (account pct or the registry default, True), the second item meaning 'inherited'.
        `account_id` is the account key or its book_account_id (X1c fix b: the probe host passes the
        book id); an unknown id raises unknown_account."""
        account_id = self.canonical_account(account_id)
        breakers = self.doc["loss_breakers"]
        if engine_id is not None:
            engine_pct = breakers["engines"].get(engine_id)
            if engine_pct is not None:
                return int(engine_pct), False
        account_pct = breakers["accounts"].get(account_id)
        return int(account_pct if account_pct is not None else breakers["default_pct"]), True

    def push_block(self) -> dict[str, Any]:
        """Legacy grouped dashboard block, limited to 64 KiB canonical JSON, not MAX_ASSIGNMENTS.
        No production caller uses this format; telemetry uses RegistryProjection.push_block.
        Assignments are grouped under their account and symbols use a `symbol_order` bitmask.
        Larger registries can raise push_block_too_large; this is not the registry file cap."""
        order = symbols()
        bit = {symbol: 1 << index for index, symbol in enumerate(order)}
        breakers = self.doc["loss_breakers"]
        accounts: dict[str, Any] = {}
        for aid, account in self.accounts.items():
            accounts[aid] = {"kind": account["kind"], "label": account["label"],
                             "member_key": account["member_key"], "domain": account["domain"],
                             "exit_only": account["exit_only"],
                             "breaker_pct": self.effective_pct(aid)[0], "engines": {}}
        for eid, assignment in self.assignments.items():
            explicit = breakers["engines"].get(eid)
            accounts[assignment["account_id"]]["engines"][eid] = {
                "role": assignment["role"],
                "symbols_mask": sum(bit[symbol] for symbol in assignment["symbols"]),
                "since": assignment["since"],
                "breaker_pct": None if explicit is None else int(explicit)}
        members = {key: {"authority_domain": member["authority_domain"],
                         "transfer_step": None if member["transfer"] is None else member["transfer"]["step"]}
                   for key, member in self.doc["exposure"]["members"].items()}
        block = {"schema": PUSH_SCHEMA, "generation": self.generation, "digest": self.digest,
                 "symbol_order": list(order), "default_breaker_pct": int(breakers["default_pct"]),
                 "max_concurrent_probes": int(self.doc["max_concurrent_probes"]),
                 "assignment_count": len(self.assignments), "members": members,
                 "accounts": accounts}
        size = len(canonical_bytes(block))
        if size > MAX_PUSH_BYTES:
            raise RegistryError("push_block_too_large", f"{size} > {MAX_PUSH_BYTES} bytes")
        return block


# ---------------------------------------------------------------- per-domain projection view (C14-A)

def projection_for(registry: Registry, domain: str) -> dict[str, Any]:
    """The filtered view one domain's lane receives: schema, generation, the domain's own account id,
    role and exit_only, its assignments (role, symbols, since), its role at each change point, and a
    digest over the view. Never a member_key, a member, a breaker or any other domain's data.
    Raises RegistryError `unknown_domain` when the registry holds no account in `domain`."""
    _match(_DOMAIN, domain, "domain")
    owners = [aid for aid, account in registry.accounts.items() if account["domain"] == domain]
    if not owners:
        raise RegistryError("unknown_domain", domain)
    exit_only = registry.accounts[owners[0]]["exit_only"]
    book = registry.accounts[owners[0]].get(BOOK_ACCOUNT_ID)
    view = {"schema": PROJECTION_SCHEMA if book is None else PROJECTION_SCHEMA_V2,
            "generation": str(registry.generation), "domain": domain,
            "account_id": owners[0], "role": DOMAIN_EXIT_ONLY if exit_only else DOMAIN_AUTHORITY,
            "exit_only": exit_only,
            "assignments": {eid: {"role": a["role"], "symbols": list(a["symbols"]), "since": a["since"]}
                            for eid, a in registry.assignments.items() if a["domain"] == domain},
            "roles_by_generation": {key: roles[domain]
                                    for key, roles in registry.doc["roles_by_generation"].items()
                                    if domain in roles}}
    if book is not None:
        view[BOOK_ACCOUNT_ID] = book
    view["digest"] = document_digest(view)
    return validate_projection(view)


def projection_bytes(registry: Registry, domain: str) -> bytes:
    """Canonical bytes of `projection_for(registry, domain)`: what the provisioner writes."""
    return canonical_bytes(projection_for(registry, domain))


def validate_projection(doc: Any) -> dict[str, Any]:
    """Strict validation of one projection view; raises on any defect (the reader fails closed)."""
    if type(doc) is dict and doc.get("schema") == PROJECTION_SCHEMA_V2:
        _exact(doc, _VIEW_KEYS_V2, "projection")
        if not valid_book_account_id(doc[BOOK_ACCOUNT_ID]):
            raise RegistryError("invalid_value", f"projection.{BOOK_ACCOUNT_ID}")
    else:
        _exact(doc, _VIEW_KEYS, "projection")
        if doc["schema"] != PROJECTION_SCHEMA:
            raise RegistryError("unknown_schema", repr(doc["schema"]))
    generation = _decimal(doc["generation"], "projection.generation", 1, MAX_GENERATION)
    _match(_DOMAIN, doc["domain"], "projection.domain")
    _match(_KEY_ID, doc["account_id"], "projection.account_id")
    if doc["role"] not in (DOMAIN_AUTHORITY, DOMAIN_EXIT_ONLY) or type(doc["exit_only"]) is not bool:
        raise RegistryError("invalid_value", "projection.role / exit_only")
    if doc["exit_only"] is not (doc["role"] == DOMAIN_EXIT_ONLY):
        raise RegistryError("exit_only_mismatch", "projection.exit_only disagrees with its role")
    assignments = _object(doc["assignments"], "projection.assignments")
    if len(assignments) > MAX_ASSIGNMENTS:
        raise RegistryError("too_many_assignments", f"{len(assignments)} > {MAX_ASSIGNMENTS}")
    for eid, assignment in assignments.items():
        _match(_ENGINE_ID, eid, "projection.assignments key")
        where = f"projection.assignments.{eid}"
        _exact(assignment, _VIEW_ASSIGNMENT_KEYS, where)
        if assignment["role"] not in ROLES:
            raise RegistryError("invalid_value", f"{where}.role: {assignment['role']!r}")
        _symbol_list(assignment["symbols"], f"{where}.symbols")
        _stamp(assignment["since"], f"{where}.since")
    points = _object(doc["roles_by_generation"], "projection.roles_by_generation")
    if not 1 <= len(points) <= MAX_ROLE_POINTS:
        raise RegistryError("invalid_value", f"projection.roles_by_generation: 1..{MAX_ROLE_POINTS} points")
    for key, role in points.items():
        _decimal(key, "projection.roles_by_generation key", 1, generation)
        if role not in (DOMAIN_AUTHORITY, DOMAIN_EXIT_ONLY):
            raise RegistryError("invalid_value", f"projection.roles_by_generation.{key}: {role!r}")
    current = _role_point(points, generation)
    if current is None or points[current] != doc["role"]:
        raise RegistryError("roles_mismatch", "projection.roles_by_generation disagrees with its role")
    _match(_HEX64, doc["digest"], "projection.digest")
    if doc["digest"] != document_digest(doc):
        raise RegistryError("digest_mismatch", "projection digest does not match the view")
    return doc


# ---------------------------------------------------------------- pure mutations (doc in place)

def check_assign(doc: Mapping[str, Any], engine_id: str, account_id: str, role: str,
                 symbol_list: Iterable[str], identity_digest: str | None = None) -> list[str]:
    """Refuse an assignment that breaks uniqueness by shape or exposure authority; returns the
    normalized symbol list. Codes: engine_assigned_elsewhere, identity_clone,
    domain_not_exposure_authority, domain_exit_only, concurrent_probes_exceeded, registry_full."""
    _match(_ENGINE_ID, engine_id, "engine_id")
    if role not in ROLES:
        raise RegistryError("invalid_role", repr(role))
    account = doc["accounts"].get(account_id)
    if account is None:
        raise RegistryError("unknown_account", repr(account_id))
    wanted = normalize_symbols(symbol_list)
    assignments = doc["assignments"]
    current = assignments.get(engine_id)
    if current is not None and current["account_id"] != account_id:
        raise RegistryError("engine_assigned_elsewhere",
                            f"{engine_id} is assigned to {current['account_id']}")
    member = doc["exposure"]["members"][account["member_key"]]
    if role in OPENING_ROLES and member["authority_domain"] != account["domain"]:
        raise RegistryError("domain_not_exposure_authority",
                            f"{account['domain']} is not member {account['member_key']}'s authority")
    if account["exit_only"]:
        raise RegistryError("domain_exit_only", f"{account['domain']} is exit-only")
    if identity_digest is not None:
        _match(_HEX64, identity_digest, "identity_digest")
        wanted_set = frozenset(wanted)
        for other_id, other in assignments.items():
            if (other_id != engine_id and other["identity_digest"] == identity_digest
                    and not wanted_set.isdisjoint(other["symbols"])):
                raise RegistryError("identity_clone",
                                    f"{engine_id} has the identity of {other_id} on a shared symbol")
    if current is None and len(assignments) >= MAX_ASSIGNMENTS:
        raise RegistryError("registry_full", f"{MAX_ASSIGNMENTS} assignments")
    if role == "probe" and (current is None or current["role"] != "probe"):
        probes = sum(1 for other in assignments.values() if other["role"] == "probe")
        if probes >= int(doc["max_concurrent_probes"]):
            raise RegistryError("concurrent_probes_exceeded", f"{probes} probes already assigned")
    return wanted


def apply_assign(doc: dict[str, Any], engine_id: str, account_id: str, role: str,
                 symbol_list: Iterable[str], *, since: str, identity_digest: str | None = None,
                 manifest_digest: str | None = None, request_id: str | None = None,
                 approval_id: str | None = None,
                 previous_bindings: Mapping[str, str | None] | None = None) -> bool:
    """Assign in place; returns False when the identical assignment already stands (idempotent)."""
    wanted = check_assign(doc, engine_id, account_id, role, symbol_list, identity_digest)
    entry = {"account_id": account_id, "domain": doc["accounts"][account_id]["domain"],
             "role": role, "symbols": wanted, "identity_digest": identity_digest,
             "manifest_digest": manifest_digest, "since": since, "request_id": request_id,
             "approval_id": approval_id,
             "previous_bindings": None if previous_bindings is None else dict(previous_bindings)}
    current = doc["assignments"].get(engine_id)
    if current is not None and {**current, "since": since} == entry:
        return False
    doc["assignments"][engine_id] = entry
    return True


def apply_release(doc: dict[str, Any], engine_id: str) -> bool:
    if engine_id not in doc["assignments"]:
        raise RegistryError("not_assigned", repr(engine_id))
    del doc["assignments"][engine_id]
    doc["loss_breakers"]["engines"].pop(engine_id, None)
    return True


def apply_book_account_ids(doc: dict[str, Any], ids: Mapping[str, str | None]) -> dict[str, str]:
    """Stamp each account's book_account_id from `ids` (account key -> id) in place. A None or
    missing id keeps what the account already carries (an unreadable identity never erases a
    stamped id). An invalid id, one naming another account's key, or one shared across members is
    NOT stamped: the account keeps its previous id and the returned {account: problem} names it,
    so a commit never writes a document the decoder refuses. Returns {} when every id applied."""
    accounts = doc["accounts"]
    problems: dict[str, str] = {}
    for aid, value in ids.items():
        if aid not in accounts or value is None:
            continue
        if not valid_book_account_id(value):
            problems[aid] = "book_account_id_invalid"
            continue
        had, previous = BOOK_ACCOUNT_ID in accounts[aid], accounts[aid].get(BOOK_ACCOUNT_ID)
        accounts[aid][BOOK_ACCOUNT_ID] = value
        if aid in book_account_conflicts(accounts):
            problems[aid] = "book_account_id_reused"
            if had:
                accounts[aid][BOOK_ACCOUNT_ID] = previous
            else:
                del accounts[aid][BOOK_ACCOUNT_ID]
    return problems


def normalize_schema(doc: dict[str, Any], current_schema: str | None = None) -> None:
    """v2 (every account carries book_account_id, null where unknown) once any account has one or
    the document or its predecessor already is v2; otherwise the C1 v1 shape, with no null field."""
    accounts = doc["accounts"]
    v2 = (doc.get("schema") == SCHEMA_V2 or current_schema == SCHEMA_V2
          or any(account.get(BOOK_ACCOUNT_ID) is not None for account in accounts.values()))
    doc["schema"] = SCHEMA_V2 if v2 else SCHEMA
    for account in accounts.values():
        if v2:
            account.setdefault(BOOK_ACCOUNT_ID, None)
        else:
            account.pop(BOOK_ACCOUNT_ID, None)


def apply_set_max_concurrent_probes(doc: dict[str, Any], n: int) -> bool:
    """Set the probe limit within the registry, family and current assignment bounds."""
    from leafhft import probe_bar

    if type(n) is not int or not 1 <= n <= MAX_CONCURRENT_PROBES:
        raise RegistryError("max_probes_out_of_range", f"expected 1..{MAX_CONCURRENT_PROBES}")
    if n > probe_bar.MAX_FAMILY:
        raise RegistryError("probe_family_bound", f"maximum family size is {probe_bar.MAX_FAMILY}")
    probes = sum(assignment["role"] == "probe" for assignment in doc["assignments"].values())
    if n < probes:
        raise RegistryError("probes_above_new_max", f"{probes} probes already assigned")
    value = str(n)
    if doc["max_concurrent_probes"] == value:
        return False
    doc["max_concurrent_probes"] = value
    return True


def apply_set_breaker(doc: dict[str, Any], scope: str, target_id: str, pct: int | None) -> bool:
    """Set one D5a breaker, clamped to 1..100; None returns it to inheriting. Refuses a scope or
    an id the registry does not know."""
    if scope not in BREAKER_SCOPES:
        raise RegistryError("unknown_scope", repr(scope))
    known = doc["accounts"] if scope == "account" else doc["assignments"]
    if target_id not in known:
        raise RegistryError("unknown_breaker_target", f"{scope} {target_id!r}")
    table = doc["loss_breakers"]["accounts" if scope == "account" else "engines"]
    if pct is None:
        return table.pop(target_id, None) is not None
    if type(pct) is not int:
        raise RegistryError("invalid_pct", repr(pct))
    value = str(max(MIN_BREAKER_PCT, min(MAX_BREAKER_PCT, pct)))
    if table.get(target_id) == value:
        return False
    table[target_id] = value
    return True


# ---------------------------------------------------------------- bindings (read-only view)

@dataclass(frozen=True)
class BindingsView:
    default: str | None
    symbols: Mapping[str, str]
    disabled: frozenset[str]


def read_bindings(path: Path | str) -> BindingsView:
    """Strict read of a bindings file ({default, symbols, disabled?}); an absent file is empty,
    matching engines.Bindings.load, without requiring the engine catalog to be present."""
    path = Path(path)
    try:
        data = _read_bounded(path, MAX_BINDINGS_BYTES)
    except FileNotFoundError:
        return BindingsView(None, {}, frozenset())
    except OSError as exc:
        raise RegistryError("bindings_unreadable", f"{path}: {exc}") from exc
    raw = strict_loads(data, MAX_BINDINGS_BYTES)
    if (type(raw) is not dict or set(raw) not in ({"default", "symbols"}, {"default", "symbols", "disabled"})
            or type(raw["symbols"]) is not dict):
        raise RegistryError("invalid_bindings", f"{path}: expected default, symbols, optional disabled")
    known = _symbol_set()
    _match(_ENGINE_ID, raw["default"], f"{path}: default", nullable=True)
    for symbol, engine_id in raw["symbols"].items():
        if symbol not in known:
            raise RegistryError("invalid_bindings", f"{path}: unknown symbol {symbol!r}")
        _match(_ENGINE_ID, engine_id, f"{path}: symbols.{symbol}")
    disabled = raw.get("disabled", [])
    if (type(disabled) is not list or len(set(disabled)) != len(disabled)
            or any(type(symbol) is not str or symbol not in known for symbol in disabled)):
        raise RegistryError("invalid_bindings", f"{path}: disabled must be a unique symbol list")
    return BindingsView(raw["default"], dict(raw["symbols"]), frozenset(disabled))


def expand_bindings(view: BindingsView) -> tuple[dict[str, str], frozenset[str]]:
    """(active {symbol: engine_id} across the 14 symbols minus disabled, dormant engine ids that
    the file names but that run on no enabled symbol)."""
    active: dict[str, str] = {}
    for symbol in symbols():
        if symbol in view.disabled:
            continue
        engine_id = view.symbols.get(symbol, view.default)
        if engine_id is not None:
            active[symbol] = engine_id
    referenced = set(view.symbols.values())
    if view.default is not None:
        referenced.add(view.default)
    return active, frozenset(referenced - set(active.values()))


@dataclass(frozen=True)
class AccountSource:
    """One execution domain's bindings, as registry init and the audit read them."""
    account_id: str
    kind: str
    domain: str
    member_key: str
    bindings_path: Path
    lane_id: str | None = None
    label: str = ""

    def record(self) -> dict[str, Any]:
        _match(_KEY_ID, self.account_id, "account_id")
        if self.kind not in ACCOUNT_KINDS:
            raise RegistryError("invalid_value", f"{self.account_id}.kind: {self.kind!r}")
        return {"kind": self.kind, "lane_id": _match(_LANE_ID, self.lane_id, "lane_id", nullable=True),
                "label": _label(self.label or self.account_id, "label"),
                "member_key": _match(_KEY_ID, self.member_key, "member_key"),
                "domain": _match(_DOMAIN, self.domain, "domain"), "exit_only": True}


def load_sources(path: Path | str) -> list[AccountSource]:
    """Read an accounts file {"accounts": [{account_id, kind, lane_id, label, member_key, domain,
    bindings}]}; `bindings` is relative to the file's directory."""
    path = Path(path)
    raw = strict_loads(_read_bounded(path, MAX_SOURCES_BYTES), MAX_SOURCES_BYTES)
    rows = _exact(raw, SOURCES_SCHEMA_KEYS, str(path))["accounts"]
    if type(rows) is not list or not 1 <= len(rows) <= MAX_ACCOUNTS:
        raise RegistryError("invalid_sources", f"{path}: 1..{MAX_ACCOUNTS} accounts")
    sources = []
    for row in rows:
        _exact(row, _SOURCE_KEYS, f"{path}: account")
        if type(row["bindings"]) is not str or not row["bindings"]:
            raise RegistryError("invalid_sources", f"{path}: bindings must be a relative path")
        sources.append(AccountSource(row["account_id"], row["kind"], row["domain"], row["member_key"],
                                     path.parent / row["bindings"], row["lane_id"], row["label"]))
    return sources


# ---------------------------------------------------------------- the writer

class RegistryStore:
    """The only writer. One `_FileLock` on `<dir>/.lock` per load-decide-write cycle; one journal
    row per generation, appended before the atomic replace."""

    def __init__(self, directory: Path | str, *, lock_timeout_s: float = LOCK_TIMEOUT_S,
                 roles_dir: Path | str | None = None, roles_owner: int | None = 0,
                 book_account_ids: Callable[[Mapping[str, Any]], Mapping[str, str | None]] | None = None) -> None:
        self.directory = Path(directory)
        self.path = self.directory / REGISTRY_FILE
        self.projection_path = self.directory / PROJECTION_FILE
        self.publication_path = self.directory / PUBLICATION_FILE
        self.journal_path = self.directory / JOURNAL_FILE
        self.audit_path = self.directory / AUDIT_FILE
        self.lock_path = self.directory / LOCK_FILE
        self.lock_timeout_s = lock_timeout_s
        # With a roles dir, every commit lowers role files before the replace and raises after it
        # (exposure_authority.CommitPlan); None leaves the role files to `exposure project`, and once
        # a projection is active an authority-changing commit then refuses `roles_dir_required`.
        self.roles_dir = None if roles_dir is None else Path(roles_dir)
        self.roles_owner = roles_owner
        # X1c: accounts -> {account key: book id or None}, asked once per commit (engine_ops derives
        # it from the books' identity files). None carries every stamped id forward unchanged.
        self.book_account_ids = book_account_ids
        self.book_problems: dict[str, str] = {}
        self.interim: dict[str, str] = {}  # what the last project() recognised and rewrote
        self._held = False  # True while this store holds its lock (load()'s repair re-enters it)

    @contextmanager
    def _lock(self):
        """The registry lock for one load-decide-write cycle. Re-entrant within this store only, so
        load()'s publication repair runs under a lock the caller already holds."""
        if self._held:
            yield None
            return
        with _FileLock(self.lock_path, self.lock_timeout_s) as lock:
            self._held = True
            try:
                yield lock
            finally:
                self._held = False

    def load(self, *, complete_publication: bool = True) -> Registry | None:
        """The current generation, verified against the journal chain; None when never written.
        Completes an interrupted publication before it returns (`_complete_publication`), unless
        the caller (project(), under the lock) publishes itself."""
        try:
            data = _read_bounded(self.path, MAX_REGISTRY_BYTES)
        except FileNotFoundError:
            rows = self._journal_rows(JOURNAL_SHOWN)
            # A crash between the journal append and the replace of the very first generation
            # leaves unapplied init rows (a retry never reuses a tentative generation, so each
            # retried init chains to the one before); anything else means the file went missing.
            if rows and not _abandoned_inits(rows):
                raise RegistryError("registry_missing", f"{self.path} is gone but the journal is not")
            return None
        except OSError as exc:
            raise RegistryError("registry_unreadable", str(exc)) from exc
        registry = Registry.from_bytes(data)
        self._verify_journal_anchor(registry)
        if complete_publication and not publication_matches(self.publication_path, registry.generation,
                                                             registry.digest):
            self._complete_publication(registry, data)
        return registry

    def _complete_publication(self, registry: Registry, data: bytes) -> None:
        """Rewrite projection.json from the registry just loaded and mark it published, under the
        lock (re-read there: a writer may have moved on). A caller that cannot take the lock or
        write the files (not root, or a writer busy past the timeout) leaves the marker as it is,
        so the books keep refusing `publication_incomplete` until a root load or `registry project`
        completes it: fail closed, never a stale projection admitted."""
        try:
            if self._held:
                write_projection(self.directory, data)
                write_publication(self.directory, registry.generation, registry.digest, PUBLISHED)
            else:
                with self._lock():
                    self.load()  # under the lock this lands in the branch above
        except OSError:  # TimeoutError included
            return

    def _verify_journal_anchor(self, registry: Registry) -> None:
        """The file must be a journaled generation (the anchor). Rows after it may only be tentative
        writes that never reached the file (A7: a failed or crashed replace), any number in a row:
        each chains to the committed digest with a strictly higher generation, so none can match a
        committed registry. Reads 2 rows in the common case, widening 8x per miss; the walk stops at
        the first row that is neither, and the journal's two bounded files bound the widest read."""
        wanted = (registry.doc["generation"], registry.digest)
        limit = 2
        while True:
            rows = self._journal_rows(limit)
            if not rows:
                raise RegistryError("journal_missing", f"{self.journal_path} has no rows")
            ceiling = None
            for row in reversed(rows):
                if (row.get("generation"), row.get("digest")) == wanted:
                    return
                generation = row.get("generation")
                if (row.get("previous_digest") != registry.digest or type(generation) is not str
                        or _DECIMAL.fullmatch(generation) is None or int(generation) <= registry.generation
                        or (ceiling is not None and int(generation) >= ceiling)):
                    raise RegistryError("journal_mismatch", "the registry file does not match the journal chain")
                ceiling = int(generation)
            if len(rows) < limit or limit >= MAX_JOURNAL_WALK:
                raise RegistryError("journal_mismatch", "no journal row names the registry file's generation")
            limit *= 8

    def mutate(self, action: str, change: Callable[[dict[str, Any]], bool], *,
               request_id: str | None = None, actor: str | None = None,
               now: datetime | None = None, expect: tuple[int, str] | None = None) -> Registry:
        """Apply `change` to a copy of the current document under the lock and commit the next
        generation; `change` returns False for a no-op, which writes nothing. `expect` is the
        (generation, digest) the caller decided on: a mismatch refuses `registry_changed` (CAS)."""
        with self._lock():
            current = self.load()
            if current is None:
                raise RegistryError("registry_absent", "run registry init first")
            if expect is not None and (current.generation, current.digest) != tuple(expect):
                raise RegistryError("registry_changed",
                                    f"expected generation {expect[0]}, found {current.generation}")
            doc = current.copy_document()
            if not change(doc):
                return current
            return self._commit(current, doc, action, request_id=request_id, actor=actor, now=now)

    def assign(self, engine_id: str, account_id: str, role: str, symbol_list: Iterable[str], *,
               identity_digest: str | None = None, manifest_digest: str | None = None,
               request_id: str | None = None, approval_id: str | None = None,
               previous_bindings: Mapping[str, str | None] | None = None, actor: str | None = None,
               now: datetime | None = None) -> Registry:
        since = _utc_stamp(now)
        return self.mutate("assign", lambda doc: apply_assign(
            doc, engine_id, account_id, role, symbol_list, since=since,
            identity_digest=identity_digest, manifest_digest=manifest_digest,
            request_id=request_id, approval_id=approval_id, previous_bindings=previous_bindings),
            request_id=request_id, actor=actor, now=now)

    def release(self, engine_id: str, *, request_id: str | None = None, actor: str | None = None,
                now: datetime | None = None) -> Registry:
        return self.mutate("release", lambda doc: apply_release(doc, engine_id),
                           request_id=request_id, actor=actor, now=now)

    def set_max_concurrent_probes(self, n: int, *, request_id: str | None = None,
                                  actor: str | None = None, now: datetime | None = None) -> Registry:
        return self.mutate("probes.max_set", lambda doc: apply_set_max_concurrent_probes(doc, n),
                           request_id=request_id, actor=actor, now=now)

    def set_breaker(self, scope: str, target_id: str, pct: int | None, *,
                    request_id: str | None = None, actor: str | None = None,
                    now: datetime | None = None) -> Registry:
        return self.mutate("breaker.set", lambda doc: apply_set_breaker(doc, scope, target_id, pct),
                           request_id=request_id, actor=actor, now=now)

    def _commit(self, current: Registry | None, doc: dict[str, Any], action: str, *,
                request_id: str | None, actor: str | None, now: datetime | None,
                book_ids: Mapping[str, str | None] | None = None) -> Registry:
        """Seal and write the next generation. Caller holds the lock. `book_ids` (else the store's
        provider) stamps book_account_id; the schema is normalized v1/v2 before the seal."""
        _match(_ACTION, action, "action")
        _match(_REF_ID, request_id, "request_id", nullable=True)
        _match(_REF_ID, actor, "actor", nullable=True)
        generation = 1 if current is None else current.generation + 1
        previous_digest = None if current is None else current.digest
        tail = self._journal_rows(1)
        # X2X3 v3.1 A7: a journaled-but-unapplied generation is never reused, so a role file, a
        # history row or a reservation stamp that saw the tentative generation can never name a
        # different document. The retry takes the number above the highest journaled one (the
        # tail: every allocation is above it), however many attempts failed in a row; an
        # abandoned init chains to it.
        if tail:
            journaled = _decimal(tail[-1].get("generation"), "journal generation", 1, MAX_GENERATION)
            if current is None:
                generation = journaled + 1
                previous_digest = _match(_HEX64, tail[-1].get("digest"), "journal digest")
            elif journaled >= generation:
                generation = journaled + 1
        if generation > MAX_GENERATION:
            raise RegistryError("generation_exhausted", str(generation))
        members = doc["exposure"]["members"]
        for account in doc["accounts"].values():
            account["exit_only"] = members[account["member_key"]]["authority_domain"] != account["domain"]
        if book_ids is None and self.book_account_ids is not None:
            book_ids = self.book_account_ids(doc["accounts"])
        if book_ids is not None:
            self.book_problems.update(apply_book_account_ids(doc, book_ids))
        normalize_schema(doc, None if current is None else current.doc["schema"])
        doc["generation"] = str(generation)
        doc["previous_digest"] = previous_digest
        # roles_by_generation keeps CHANGE POINTS: the role at g is the latest point <= g, so the
        # document stays bounded however many generations pass without an authority change.
        points = {} if current is None else dict(doc["roles_by_generation"])
        roles = derive_roles(doc["accounts"], members)
        latest = _role_point(points, generation)
        if latest is None or points[latest] != roles:
            points[str(generation)] = roles
        while len(points) > MAX_ROLE_POINTS:
            del points[min(points, key=int)]
        doc["roles_by_generation"] = points
        doc["digest"] = document_digest(doc)
        data = canonical_bytes(doc)
        registry = Registry.from_bytes(data)
        from . import exposure_authority  # imports this module; bound lazily to avoid the cycle

        plan = exposure_authority.CommitPlan(self, current, registry, action=action, request_id=request_id)
        self._append_journal({"action": action, "actor": actor, "at": _utc_stamp(now),
                              "digest": registry.digest, "generation": str(generation),
                              "previous_digest": doc["previous_digest"], "request_id": request_id})
        # C6d fix b: the marker says "publishing" before anything the books read can move, so from
        # here until the flip below the reader refuses publication_incomplete (fails closed) and a
        # crash anywhere in between is completed by the next load() or `project()`.
        write_publication(self.directory, generation, registry.digest, PUBLISHING)
        plan.before_replace()  # history role rows and role LOWERINGS, before the replace
        _atomic_write(self.path, data)
        # The books' copy follows the registry and precedes the raises, so no authority opens
        # before the book-facing view carries this generation; a failure here stops the commit
        # exactly where a crash would, and `project()` recovers it.
        write_projection(self.directory, data)
        write_publication(self.directory, generation, registry.digest, PUBLISHED)
        plan.after_replace()  # the commit row, the marker and the raises, after it
        return registry

    def project(self, *, actor: str | None = None, now: datetime | None = None) -> Registry:
        """Recovery: rewrite projection.json from the committed registry file under the lock, then
        mark it published. Refuses (RegistryError) when the file is absent, unreadable, invalid or
        off the journal chain, leaving the previous projection and marker in place.

        X1c: when the book ids this store derives (plus any an interim hand-patched projection
        names, `recognise_interim`) differ from what the registry carries, it commits ONE generation
        (`project.book-ids`) instead, which writes the projection with the ids and its published
        marker in the same publication. `self.interim` names what was recognised; the interim
        file itself is replaced by the canonical bytes either way."""
        with self._lock():
            # Read before load(): an incomplete publication makes load() overwrite projection.json.
            try:
                interim_bytes: bytes | None = _read_bounded(self.projection_path, MAX_REGISTRY_BYTES)
            except (OSError, RegistryError):
                interim_bytes = None
            # The same refusals the books' writers meet; this call publishes below, exactly once.
            registry = self.load(complete_publication=False)
            if registry is None:
                raise RegistryError("registry_absent", "run registry init first")
            try:
                data = _read_bounded(self.path, MAX_REGISTRY_BYTES)
            except OSError as exc:
                raise RegistryError("registry_unreadable", str(exc)) from exc
            if Registry.from_bytes(data).digest != registry.digest:  # replaced outside the lock
                raise RegistryError("registry_changed", f"{self.path} changed while it was projected")
            self.interim = recognise_interim(interim_bytes, registry)
            wanted = dict(self.book_account_ids(registry.accounts)) if self.book_account_ids is not None else {}
            for aid, hint in self.interim.items():
                if wanted.get(aid) is None:
                    wanted[aid] = hint  # the id the operator verified live, when no identity file says
            doc = registry.copy_document()
            self.book_problems.update(apply_book_account_ids(doc, wanted))
            normalize_schema(doc, registry.doc["schema"])
            if doc != registry.doc:
                return self._commit(registry, doc, "project.book-ids", request_id=None, actor=actor, now=now,
                                    book_ids=wanted)
            write_projection(self.directory, data)
            write_publication(self.directory, registry.generation, registry.digest, PUBLISHED)
            return registry

    # journal ---------------------------------------------------------------------------------

    def _append_journal(self, row: Mapping[str, Any]) -> None:
        line = canonical_bytes(row) + b"\n"
        if len(line) > MAX_JOURNAL_ROW_BYTES:
            raise RegistryError("journal_row_too_large", str(len(line)))
        try:
            if self.journal_path.stat().st_size > JOURNAL_ROTATE_BYTES:
                os.replace(self.journal_path, self.journal_path.with_name(JOURNAL_FILE + ".1"))
        except FileNotFoundError:
            pass
        flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_BINARY", 0)
        fd = os.open(self.journal_path, flags, 0o644)
        try:
            os.write(fd, line)
            os.fsync(fd)
        finally:
            os.close(fd)

    def _journal_rows(self, limit: int) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for path in (self.journal_path, self.journal_path.with_name(JOURNAL_FILE + ".1")):
            need = limit - len(rows)
            if need <= 0:
                break
            rows = _tail_rows(path, need) + rows
        return rows

    def journal_tail(self, limit: int = JOURNAL_SHOWN) -> list[dict[str, Any]]:
        return self._journal_rows(max(0, min(limit, JOURNAL_SHOWN)))

    def write_audit(self, registry: Registry, findings: list[dict[str, Any]], *,
                    now: datetime | None = None) -> dict[str, Any]:
        """audit.json for scripts/leafhft_alert.py to read (bounded, atomic)."""
        informational = sum(1 for finding in findings if is_informational(finding["class"]))
        report = {"schema": AUDIT_SCHEMA, "at": _utc_stamp(now), "generation": str(registry.generation),
                  "digest": registry.digest, "violations": str(len(findings) - informational),
                  "informational": str(informational),
                  "classes": sorted({finding["class"] for finding in findings}),
                  "findings": findings[:MAX_AUDIT_FINDINGS],
                  "truncated": len(findings) > MAX_AUDIT_FINDINGS}
        self.directory.mkdir(parents=True, exist_ok=True)
        _atomic_write(self.audit_path, canonical_bytes(report))
        return report


def _tail_rows(path: Path, limit: int) -> list[dict[str, Any]]:
    try:
        with open(path, "rb") as stream:
            size = stream.seek(0, os.SEEK_END)
            start = max(0, size - limit * MAX_JOURNAL_ROW_BYTES)
            stream.seek(start)
            data = stream.read()
    except FileNotFoundError:
        return []
    lines = data.split(b"\n")
    if start > 0:
        lines = lines[1:]
    rows = []
    for line in [line for line in lines if line][-limit:]:
        try:
            row = json.loads(line.decode("utf-8"))
        except (UnicodeError, ValueError) as exc:
            raise RegistryError("journal_corrupt", f"{path}: {exc}") from exc
        if type(row) is not dict:
            raise RegistryError("journal_corrupt", f"{path}: row is not an object")
        rows.append(row)
    return rows


def _abandoned_inits(rows: list[dict[str, Any]]) -> bool:
    """True when the whole journal is init rows that never reached the file: generation 1 with no
    previous digest, each retry the next generation chained to the one before (A7)."""
    if not rows or len(rows) >= JOURNAL_SHOWN:
        return False
    previous, expected = None, 1
    for row in rows:
        if (row.get("action") != "init" or row.get("generation") != str(expected)
                or row.get("previous_digest") != previous):
            return False
        previous, expected = row.get("digest"), expected + 1
    return True


def _atomic_write(path: Path, data: bytes, mode: int = 0o644) -> None:
    fd, temporary = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if os.name == "posix":
            os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
    if os.name == "posix":
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)


def write_projection(directory: Path | str, data: bytes) -> Path:
    """`<directory>/projection.json`: the committed registry bytes themselves (same schema, same
    digest), so `RegistryProjection` reads the generation the registry carries. Atomic (temp,
    fsync, replace, directory fsync) and 0444 on POSIX; a failed write leaves the previous
    projection. The caller holds the registry lock and passes bytes that already decoded."""
    path = Path(directory) / PROJECTION_FILE
    _atomic_write(path, data, mode=PROJECTION_MODE)
    return path


def publication_bytes(generation: int, digest: str, state: str) -> bytes:
    """The marker document {generation, digest, state}, canonical and bounded; refuses bad input."""
    if state not in (PUBLISHING, PUBLISHED):
        raise RegistryError("invalid_value", f"publication state {state!r}")
    if type(generation) is not int or not 1 <= generation <= MAX_GENERATION:
        raise RegistryError("invalid_value", f"publication generation {generation!r}")
    _match(_HEX64, digest, "publication digest")
    return canonical_bytes({"generation": str(generation), "digest": digest, "state": state})


def write_publication(directory: Path | str, generation: int, digest: str, state: str) -> Path:
    """`<directory>/publication.json`, atomic and 0444 on POSIX. The caller holds the registry lock."""
    path = Path(directory) / PUBLICATION_FILE
    _atomic_write(path, publication_bytes(generation, digest, state), mode=PROJECTION_MODE)
    return path


def read_publication(path: Path | str) -> tuple[int, str, str]:
    """(generation, digest, state) of a marker; OSError when unreadable, RegistryError when it is
    not exactly {generation, digest, state} with a decimal generation, a sha256 and a known state."""
    raw = strict_loads(_read_bounded(Path(path), MAX_PUBLICATION_BYTES), MAX_PUBLICATION_BYTES)
    _exact(raw, PUBLICATION_KEYS, "publication")
    if raw["state"] not in (PUBLISHING, PUBLISHED):
        raise RegistryError("invalid_publication", f"state {raw['state']!r}")
    generation = _decimal(raw["generation"], "publication generation", 1, MAX_GENERATION)
    return generation, _match(_HEX64, raw["digest"], "publication digest"), raw["state"]


def publication_matches(path: Path | str, generation: int, digest: str) -> bool:
    """True only when the marker reads published for exactly this generation and digest; a missing,
    unreadable or invalid marker is False (fails closed)."""
    try:
        return read_publication(path) == (generation, digest, PUBLISHED)
    except (OSError, RegistryError):
        return False


def recognise_interim(data: bytes | None, registry: Registry) -> dict[str, str]:
    """{registry account key: renamed key} when `data` is the interim hand-patched projection of
    2026-09-24 (an account key renamed to the id its book passes, the assignments following it),
    else {}. A renamed key is matched to exactly one registry account with the same kind, lane_id,
    member_key and domain, must be a valid book id, and every assignment naming it must be that
    account's engine in the registry. Never raises: anything else is simply not the interim shape."""
    if not data:
        return {}
    try:
        doc = strict_loads(data, MAX_REGISTRY_BYTES)
    except RegistryError:
        return {}
    if (type(doc) is not dict or doc.get("schema") not in REGISTRY_SCHEMAS
            or type(doc.get("accounts")) is not dict or type(doc.get("assignments")) is not dict
            or len(doc["accounts"]) > MAX_ACCOUNTS or len(doc["assignments"]) > MAX_ASSIGNMENTS):
        return {}
    accounts, known = doc["accounts"], registry.accounts
    renamed = [key for key in accounts if key not in known]
    missing = [aid for aid in known if aid not in accounts]
    if not renamed or len(renamed) != len(missing):
        return {}
    fields = ("kind", "lane_id", "member_key", "domain")
    hints: dict[str, str] = {}
    for aid in missing:
        matches = [key for key in renamed if type(accounts[key]) is dict
                   and all(accounts[key].get(name) == known[aid][name] for name in fields)]
        if len(matches) != 1 or not valid_book_account_id(matches[0]):
            return {}
        hints[aid] = matches[0]
    if len(set(hints.values())) != len(hints):
        return {}
    original = {key: aid for aid, key in hints.items()}
    for engine_id, assignment in doc["assignments"].items():
        holder = assignment.get("account_id") if type(assignment) is dict else None
        if (type(holder) is str and holder in original
                and registry.assignments.get(engine_id, {}).get("account_id") != original[holder]):
            return {}
    return hints


# ---------------------------------------------------------------- registry init from bindings

def init_from_bindings(registry_dir: Path | str, sources: Iterable[AccountSource], *,
                       authorities: Mapping[str, str] | None = None,
                       identity_digests: Mapping[str, str] | None = None, dry_run: bool = True,
                       now: datetime | None = None, request_id: str | None = None,
                       actor: str | None = None, enforcement: Mapping[str, str] | None = None,
                       conformance_receipts: Iterable[Path | str] = (),
                       provisioned_lanes: Iterable[str] | None = None,
                       roles_dir: Path | str | None = None, roles_owner: int | None = 0,
                       book_account_ids: Mapping[str, str | None] | None = None) -> dict[str, Any]:
    """Build generation 1 from the owner bindings and every lane's bindings, one legacy
    assignment per active engine. `dry_run=False` refuses while any conflict remains or while a
    member has two domains and no authority_domain; the grandfather approval names the snapshot
    of the byte-identical status quo, never an operator quote.

    X1 (contracts/X2X3.md 2.1 item 6): enablement is read only through the bindings `disabled`
    set. `enforcement` maps member -> operational|observe (absent: operational). Every exit_only
    domain of an operational member needs a fresh conformant X5 receipt among
    `conformance_receipts` to apply (else `exit_only_domain_open`); its dormant owner-engine copies
    are `dormant_on_exit_only` (informational, kept). An observe member's claims on its exit_only
    domains are `observed_claims`: no conflict, no assignment. `provisioned_lanes` (the account
    agent's binding registry) must all be enumerated by the sources (else `lane_not_enumerated`).
    Applying writes the sidecar first, then commits; with `roles_dir` the role files are lowered
    before the replace (init counts as a lowering) and the marker and raises follow it.

    X1c: `book_account_ids` (account -> the id its book passes, None when unknown) is stamped on
    each account; the report carries `book_account_ids` beside the account keys and any
    `book_account_problems` (an id refused by `apply_book_account_ids` is left null)."""
    from . import exposure_authority  # imports this module; bound lazily to avoid the cycle

    sources = list(sources)
    authorities = dict(authorities or {})
    identity_digests = dict(identity_digests or {})
    if not 1 <= len(sources) <= MAX_ACCOUNTS:
        raise RegistryError("invalid_sources", f"1..{MAX_ACCOUNTS} accounts")
    accounts: dict[str, dict[str, Any]] = {}
    views: dict[str, BindingsView] = {}
    for source in sources:
        if source.account_id in accounts:
            raise RegistryError("invalid_sources", f"duplicate account {source.account_id}")
        record = source.record()
        if any(other["domain"] == record["domain"] for other in accounts.values()):
            raise RegistryError("domain_reused", record["domain"])
        accounts[source.account_id] = record
        views[source.account_id] = read_bindings(source.bindings_path)
    book_problems = apply_book_account_ids({"accounts": accounts}, dict(book_account_ids or {}))
    if isinstance(provisioned_lanes, (str, bytes)):
        raise RegistryError("invalid_sources", "provisioned_lanes must be a collection of lane ids")
    if provisioned_lanes is not None:
        enumerated = {record["lane_id"] for record in accounts.values() if record["lane_id"] is not None}
        missing = sorted(set(provisioned_lanes) - enumerated)
        if missing:
            # An omitted provisioned lane would read `unregistered` and fail closed at its next start.
            raise RegistryError("lane_not_enumerated", ", ".join(missing), detail={"lanes": missing})
    snapshot = hashlib.sha256(canonical_bytes({
        aid: {"default": view.default, "symbols": dict(view.symbols), "disabled": sorted(view.disabled)}
        for aid, view in views.items()})).hexdigest()

    domains_by_member: dict[str, list[str]] = {}
    for record in accounts.values():
        domains_by_member.setdefault(record["member_key"], []).append(record["domain"])
    members: dict[str, dict[str, Any]] = {}
    without_authority = []
    for member_key, domains in domains_by_member.items():
        authority = authorities.get(member_key)
        if authority is not None and authority not in domains:
            raise RegistryError("authority_domain_unknown", f"{member_key}: {authority}")
        if authority is None and len(domains) == 1:
            authority = domains[0]  # one domain on the member: grandfathered as its own authority
        if authority is None:
            without_authority.append(member_key)
        members[member_key] = {"authority_domain": authority, "transfer": None}
    for record in accounts.values():
        record["exit_only"] = members[record["member_key"]]["authority_domain"] != record["domain"]
    modes = {key: exposure_authority.OPERATIONAL for key in members}
    for key, mode in dict(enforcement or {}).items():
        if key not in members or mode not in exposure_authority.ENFORCEMENTS:
            raise RegistryError("invalid_enforcement", f"{key}: {mode!r}")
        modes[key] = mode

    def observed(record: Mapping[str, Any]) -> bool:
        return record["exit_only"] and modes[record["member_key"]] == exposure_authority.OBSERVE

    conflicts: list[dict[str, Any]] = []
    informational: list[dict[str, Any]] = []
    observed_claims: list[dict[str, Any]] = []
    claims: dict[str, dict[str, list[str]]] = {}
    dormant_by_account: dict[str, frozenset[str]] = {}
    for aid, view in views.items():
        active, dormant = expand_bindings(view)
        if observed(accounts[aid]):
            # An observe member's exit_only domain keeps opening: record, never assign or conflict.
            grouped: dict[str, list[str]] = {}
            for symbol, engine_id in active.items():
                grouped.setdefault(engine_id, []).append(symbol)
            for engine_id in sorted(grouped):
                observed_claims.append(_finding("observed_claim", account_id=aid, engine_id=engine_id,
                                                symbols=grouped[engine_id], detail=accounts[aid]["domain"]))
            for engine_id in sorted(dormant):
                observed_claims.append(_finding("observed_dormant", account_id=aid, engine_id=engine_id,
                                                detail=accounts[aid]["domain"]))
            continue
        dormant_by_account[aid] = dormant
        for symbol, engine_id in active.items():
            claims.setdefault(engine_id, {}).setdefault(aid, []).append(symbol)
    since = _utc_stamp(now)
    approval_id = f"grandfather-snapshot-{snapshot}"
    init_request = request_id or f"registry-init-{snapshot[:12]}"
    assignments: dict[str, dict[str, Any]] = {}
    for engine_id in sorted(claims):
        owners = list(claims[engine_id])  # source order: the first active claimant holds it
        holder = owners[0]
        for other in owners[1:]:
            conflicts.append(_finding("bound_to_other_account", account_id=other, engine_id=engine_id,
                                      symbols=claims[engine_id][other],
                                      detail=f"also active on {holder}"))
        record = accounts[holder]
        # An exit-only domain with active bindings is a conflict once its member's authority is
        # known; a member still missing its authority is reported as that instead.
        if record["exit_only"] and members[record["member_key"]]["authority_domain"] is not None:
            conflicts.append(_finding("exit_only_domain_bound", account_id=holder, engine_id=engine_id,
                                      symbols=claims[engine_id][holder],
                                      detail=f"{record['domain']} is exit-only"))
        identity = identity_digests.get(engine_id)
        _match(_HEX64, identity, f"identity_digests.{engine_id}", nullable=True)
        assignments[engine_id] = {"account_id": holder, "domain": record["domain"], "role": "legacy",
                                  "symbols": sorted(claims[engine_id][holder]),
                                  "identity_digest": identity, "manifest_digest": None,
                                  "since": since, "request_id": init_request,
                                  "approval_id": approval_id, "previous_bindings": None}
    for aid, dormant in dormant_by_account.items():
        record = accounts[aid]
        # Kept, not cleared: `{default: null}` would put every lane book into a watcher error.
        kept = record["exit_only"] and members[record["member_key"]]["authority_domain"] is not None
        for engine_id in sorted(dormant):
            holder = assignments.get(engine_id, {}).get("account_id")
            if holder is not None and holder != aid:
                (informational if kept else conflicts).append(_finding(
                    DORMANT_ON_EXIT_ONLY if kept else "dormant_conflict", account_id=aid,
                    engine_id=engine_id, detail=f"dormant copy of an engine active on {holder}"))
    conflicts.extend(_identity_clones(assignments))
    conflicts.sort(key=_finding_key)
    informational.sort(key=_finding_key)
    observed_claims.sort(key=_finding_key)
    receipts_required = sorted(record["domain"] for record in accounts.values()
                               if record["exit_only"] and modes[record["member_key"]] == exposure_authority.OPERATIONAL)

    refusals = []
    if conflicts:
        refusals.append("init_conflicts")
    if without_authority:
        refusals.append("member_without_authority")
    report: dict[str, Any] = {
        "applied": False, "generation": None, "digest": None, "snapshot_digest": snapshot,
        "accounts": {aid: dict(record) for aid, record in accounts.items()},
        "assignments": {eid: {"account_id": a["account_id"], "role": a["role"], "symbols": list(a["symbols"])}
                        for eid, a in assignments.items()},
        "authorities": {key: member["authority_domain"] for key, member in members.items()},
        "enforcement": dict(sorted(modes.items())),
        "conflicts": conflicts, "informational": informational, "observed_claims": observed_claims,
        "members_without_authority": sorted(without_authority),
        "receipts_required": receipts_required, "refusals": refusals,
        "book_account_ids": {aid: record.get(BOOK_ACCOUNT_ID) for aid, record in accounts.items()},
        "book_account_problems": book_problems}
    if dry_run:
        return report
    if refusals:
        raise RegistryError("init_refused", ", ".join(refusals), detail=report)
    receipt_problems: dict[str, list[str]] = {}
    receipt_paths = list(conformance_receipts)
    for domain in receipts_required:
        problems = [exposure_authority.check_conformance_receipt(path, domain, now=now) for path in receipt_paths]
        if None not in problems:
            receipt_problems[domain] = [problem for problem in problems if problem] or ["receipt_missing"]
    if receipt_problems:
        raise RegistryError("exit_only_domain_open",
                            "; ".join(f"{domain}: {', '.join(reasons)}"
                                      for domain, reasons in receipt_problems.items()),
                            detail=dict(report, receipt_problems=receipt_problems))
    doc = {"schema": SCHEMA, "generation": "1", "previous_digest": None, "accounts": accounts,
           "assignments": assignments,
           "loss_breakers": {"default_pct": str(DEFAULT_BREAKER_PCT), "accounts": {}, "engines": {}},
           "exposure": {"members": members},
           "max_concurrent_probes": str(DEFAULT_MAX_CONCURRENT_PROBES),
           "roles_by_generation": {}, "digest": ""}
    store = RegistryStore(registry_dir, roles_dir=roles_dir, roles_owner=roles_owner)
    with store._lock():
        if store.load() is not None:
            raise RegistryError("registry_exists", str(store.path))
        # The sidecar first, so the commit's lowering pass already reads each member's enforcement.
        state = exposure_authority.empty_state()
        state["members"] = {key: {"enforcement": mode, "transfer": None, "attested_foreign": []}
                            for key, mode in sorted(modes.items())}
        exposure_authority.write_state(store.directory, state)
        registry = store._commit(None, doc, "init", request_id=init_request, actor=actor, now=now)
    report.update(applied=True, generation=registry.generation, digest=registry.digest)
    return report


# ---------------------------------------------------------------- the audit

def _finding(cls: str, *, account_id: str | None = None, engine_id: str | None = None,
             symbols: Iterable[str] = (), detail: str = "") -> dict[str, Any]:
    return {"class": cls, "account_id": account_id, "engine_id": engine_id,
            "symbols": sorted(symbols), "detail": detail}


def _finding_key(finding: Mapping[str, Any]) -> tuple[str, str, str, str]:
    return (finding["class"], finding["account_id"] or "", finding["engine_id"] or "", finding["detail"])


def _identity_clones(assignments: Mapping[str, Any]) -> list[dict[str, Any]]:
    by_identity: dict[str, list[str]] = {}
    for engine_id, assignment in assignments.items():
        if assignment["identity_digest"] is not None:
            by_identity.setdefault(assignment["identity_digest"], []).append(engine_id)
    findings = []
    for identity, engine_ids in by_identity.items():
        engine_ids.sort()
        for index, first in enumerate(engine_ids):
            for second in engine_ids[index + 1:]:
                shared = set(assignments[first]["symbols"]) & set(assignments[second]["symbols"])
                if shared:
                    findings.append(_finding("identity_clone", account_id=assignments[second]["account_id"],
                                             engine_id=second, symbols=shared,
                                             detail=f"same identity as {first} ({identity[:12]})"))
    return findings


def audit(registry: Registry, bindings: Mapping[str, BindingsView], *,
          lifecycle_states: Mapping[str, str] | None = None,
          reservations: Iterable[Mapping[str, Any]] = (),
          enforcement: Mapping[str, str] | None = None) -> list[dict[str, Any]]:
    """Every D4 violation class plus the VII.4 exposure classes; [] when clean.

    `bindings` maps account_id -> its bindings view (each file's default expanded across the 14
    symbols minus disabled). `lifecycle_states` maps engine_id -> CanaryStore state.
    `reservations` are ledger entries {domain, authority_generation}; an entry with no stamp
    predates the registry and proves nothing either way, so it is skipped. `enforcement` maps
    member -> operational|observe (the sidecar; absent: operational). On an exit_only domain a
    dormant copy is `dormant_on_exit_only` for an operational member, and every finding of an
    observe member is `observed_<class>`; both are informational (`is_informational`)."""
    assignments = registry.assignments
    modes = dict(enforcement or {})
    accounts = registry.accounts
    observed_domains = frozenset(account["domain"] for account in accounts.values()
                                 if account["exit_only"] and modes.get(account["member_key"]) == "observe")

    def exposure_class(cls: str, account_id: str | None) -> str:
        account = accounts.get(account_id) if account_id is not None else None
        if account is not None and account["domain"] in observed_domains:
            return OBSERVED_PREFIX + cls
        if cls == "dormant_conflict" and account is not None and account["exit_only"]:
            return DORMANT_ON_EXIT_ONLY
        return cls

    findings: list[dict[str, Any]] = []
    for account_id, view in bindings.items():
        active, dormant = expand_bindings(view)
        grouped: dict[tuple[str, str], list[str]] = {}
        for symbol, engine_id in active.items():
            assignment = assignments.get(engine_id)
            if assignment is None:
                cls = "bound_unassigned"
            elif assignment["account_id"] != account_id:
                cls = "bound_to_other_account"
            elif symbol not in assignment["symbols"]:
                cls = "bound_outside_symbols"
            else:
                continue
            grouped.setdefault((cls, engine_id), []).append(symbol)
        for (cls, engine_id), bound in grouped.items():
            holder = assignments.get(engine_id, {}).get("account_id")
            findings.append(_finding(exposure_class(cls, account_id), account_id=account_id,
                                     engine_id=engine_id, symbols=bound,
                                     detail="" if holder is None else f"assigned to {holder}"))
        for engine_id in dormant:
            holder = assignments.get(engine_id, {}).get("account_id")
            if holder is not None and holder != account_id:
                findings.append(_finding(exposure_class("dormant_conflict", account_id), account_id=account_id,
                                         engine_id=engine_id,
                                         detail=f"dormant copy of an engine assigned to {holder}"))
    findings.extend(_identity_clones(assignments))

    states = dict(lifecycle_states or {})
    for engine_id, assignment in assignments.items():
        if assignment["role"] == "probe" and states.get(engine_id) not in PROBE_LIFECYCLE_STATES:
            findings.append(_finding("probe_without_lifecycle", account_id=assignment["account_id"],
                                     engine_id=engine_id, detail=f"lifecycle {states.get(engine_id)!r}"))
    for engine_id, state in states.items():
        if state in PROBE_LIFECYCLE_STATES and assignments.get(engine_id, {}).get("role") != "probe":
            findings.append(_finding("lifecycle_probe_without_assignment", engine_id=engine_id,
                                     detail=f"lifecycle {state!r} with no probe assignment"))

    for reservation in reservations:
        domain = reservation.get("domain")
        stamp = reservation.get("authority_generation")
        if stamp is None:
            continue
        generation = stamp if type(stamp) is int else (
            int(stamp) if type(stamp) is str and _DECIMAL.fullmatch(stamp) else None)
        roles = None if generation is None else registry.roles_at(generation)
        client = reservation.get("client_id")
        detail = f"client {client}" if type(client) is str else ""
        if roles is None:
            findings.append(_finding("exposure_generation_unknown", detail=f"{domain} at {stamp!r} {detail}".strip()))
        elif roles.get(domain) != DOMAIN_AUTHORITY:
            # A domain absent from the generation's roles never held authority there either.
            findings.append(_finding(OBSERVED_PREFIX + "exposure_two_domains_opening"
                                     if domain in observed_domains else "exposure_two_domains_opening",
                                     detail=f"{domain} opened at generation {generation} as "
                                            f"{roles.get(domain, 'unregistered')} {detail}".strip()))
    findings.sort(key=_finding_key)
    return findings


def audit_sources(registry: Registry, sources: Iterable[AccountSource], **kwargs: Any) -> list[dict[str, Any]]:
    return audit(registry, {source.account_id: read_bindings(source.bindings_path) for source in sources},
                 **kwargs)


# ---------------------------------------------------------------- hot-path reader

class RegistryProjection:
    """Entry-path gate: one os.stat per call, a re-parse only when (mtime, inode, size) changes.
    Absent or invalid file -> assignment_allows False and exit_only None (fails closed). Reads the
    whole registry document or a C14-A per-domain view (`projection_for`). With `min_generation`
    set, the reader is monotonic: a file whose generation is below the highest it accepted (or the
    floor it was given) fails closed with error `projection_replayed` and is never applied.

    C6d fix b: a whole-registry document read from a file named projection.json (what the books
    read, written by every commit) is admitted only while `publication.json` beside it reads
    published for the same generation and digest; otherwise error `publication_incomplete`. The
    marker is stat-cached with the projection, keyed on both files' (mtime, inode, size), so the
    cached path is one os.stat per file. Per-domain views and other file names carry no marker.

    X1c: the caller's account id matches an assignment by the account key OR that account's
    book_account_id (the id the book passes). X1c fix b: each cached assignment carries its
    account's book id, so admission is one dict get plus the comparisons; exit_only keeps ONE map
    over account keys, domains and book ids (that precedence), so it is one dict get."""

    __slots__ = ("path", "_marker", "_key", "_allow", "_exit_only",
                 "generation", "digest", "error", "parses", "floor", "_push_floor")

    def __init__(self, path: Path | str, *, min_generation: int | None = None) -> None:
        self.path = os.fspath(path)
        self._marker = (os.path.join(os.path.dirname(self.path), PUBLICATION_FILE)
                        if os.path.basename(self.path) == PROJECTION_FILE else None)
        self._key: tuple | None = None
        # engine id -> (account key, symbols, opening allowed, domain, account's book id or None)
        self._allow: dict[str, tuple[str, frozenset[str], bool, str, str | None]] | None = None
        self._exit_only: dict[str, bool | None] = {}
        self.generation: int | None = None
        self.digest: str | None = None
        self.error: str | None = "not loaded"
        self.parses = 0
        if min_generation is not None and (type(min_generation) is not int or min_generation < 0):
            raise RegistryError("invalid_value", "min_generation: a non-negative int")
        self.floor = min_generation
        self._push_floor = min_generation

    def push_block(self) -> dict[str, Any] | None:
        """Whole-registry telemetry, push-only; never on the entry path."""
        try:
            # Re-read independently: telemetry never changes the entry cache, errors or floor.
            doc = validate_document(strict_loads(
                _read_bounded(Path(self.path), MAX_REGISTRY_BYTES), MAX_REGISTRY_BYTES))
            generation, digest = int(doc["generation"]), doc["digest"]
            if self._marker is not None and not publication_matches(self._marker, generation, digest):
                return None
            floors = [floor for floor in (self.floor, self._push_floor) if floor is not None]
            if floors and generation < max(floors):
                return None
            if len(doc["assignments"]) > MAX_DASHBOARD_ASSIGNMENTS:
                return None
            assignments = []
            for engine_id, assignment in sorted(doc["assignments"].items()):
                # This is the registry key, not a dashboard id. engine_pnl resolves it from
                # trusted identity files and removes book_account_id before transmission.
                row = {"engine_id": engine_id, "account_id": assignment["account_id"]}
                book = doc["accounts"][assignment["account_id"]].get(BOOK_ACCOUNT_ID)
                if book is not None:
                    row[BOOK_ACCOUNT_ID] = book
                for name, pattern in (("role", r"[a-z][a-z0-9_]{0,31}"),
                                      ("domain", r"[A-Za-z0-9._:-]{1,128}")):
                    value = assignment.get(name)
                    if isinstance(value, str) and re.fullmatch(pattern, value):
                        row[name] = value
                assignments.append(row)
            block = {"generation": generation, "digest": digest, "assignments": assignments}
            if re.fullmatch(r"[A-Za-z0-9._:/-]{1,64}", doc["schema"]):
                block["schema"] = doc["schema"]
            # Current whole-registry schemas have no timestamp; never invent one from a file stat.
            updated = doc.get("updated_at")
            if isinstance(updated, str) and len(updated) <= 40:
                try:
                    datetime.fromisoformat(updated.replace("Z", "+00:00"))
                except ValueError:
                    pass
                else:
                    block["updated_at"] = updated
            if len(canonical_bytes(block)) > MAX_DASHBOARD_REGISTRY_BYTES:
                return None
            if floors:
                self._push_floor = generation
            return block
        except Exception:
            return None

    def _refresh(self) -> bool:
        try:
            stat = os.stat(self.path)
        except OSError:
            self._key = None
            self._fail("absent")
            return False
        key: tuple = (stat.st_mtime_ns, stat.st_ino, stat.st_size)
        if self._marker is not None:
            try:
                marker = os.stat(self._marker)
                key = (key, (marker.st_mtime_ns, marker.st_ino, marker.st_size))
            except OSError:
                key = (key, None)
        if key == self._key:
            return self._allow is not None
        self._key = key
        self.parses += 1
        marker_required = False
        try:
            doc = strict_loads(_read_bounded(Path(self.path), MAX_REGISTRY_BYTES), MAX_REGISTRY_BYTES)
            if type(doc) is dict and doc.get("schema") in (PROJECTION_SCHEMA, PROJECTION_SCHEMA_V2):
                view = validate_projection(doc)
                generation, digest = int(view["generation"]), view["digest"]
                book = view.get(BOOK_ACCOUNT_ID)
                by_id: Mapping[str, bool | None] = {} if book is None else {book: view["exit_only"]}
                by_account = {view["account_id"]: view["exit_only"]}
                by_domain = {view["domain"]: view["exit_only"]}
                allow = {engine_id: (view["account_id"], frozenset(a["symbols"]), not view["exit_only"],
                                     view["domain"], book)
                         for engine_id, a in view["assignments"].items()}
            else:
                registry = Registry(validate_document(doc))
                generation, digest = registry.generation, registry.digest
                marker_required = self._marker is not None
                accounts = registry.accounts
                by_id = registry._exit_only  # account keys and book ids, built once per document
                by_account = {aid: account["exit_only"] for aid, account in accounts.items()}
                by_domain = {account["domain"]: account["exit_only"] for account in accounts.values()}
                allow = {engine_id: (a["account_id"], frozenset(a["symbols"]),
                                     not accounts[a["account_id"]]["exit_only"], a["domain"],
                                     accounts[a["account_id"]].get(BOOK_ACCOUNT_ID))
                         for engine_id, a in registry.assignments.items()}
            # One map, precedence account key > domain > book id (the order the lookups ran before).
            exit_only = {**by_id, **by_domain, **by_account}
        except (OSError, RegistryError) as exc:
            self._fail(str(exc) or type(exc).__name__)
            return False
        if marker_required and not publication_matches(self._marker, generation, digest):
            # A commit (or its crash) between "publishing" and "published": never admit either side.
            self._fail(PUBLICATION_INCOMPLETE)
            return False
        if self.floor is not None:
            if generation < self.floor:
                # A restored older copy is never applied, however valid its bytes.
                self._fail(PROJECTION_REPLAYED)
                return False
            self.floor = generation
        self._allow, self._exit_only = allow, exit_only
        self.generation, self.digest, self.error = generation, digest, None
        return True

    def _fail(self, reason: str) -> None:
        self._allow, self._exit_only = None, {}
        self.generation = self.digest = None
        self.error = reason

    def assignment_allows(self, engine_id: str, account_id: str, *where: str, domain: str | None = None,
                          symbol: str | None = None) -> bool:
        """True only when engine_id is assigned to account_id on symbol, in `domain`, and that
        domain holds exposure authority. Two call shapes: (engine_id, account_id, symbol) and
        wave-A's (engine_id, account_id, domain, symbol), which probe_runner makes (X2X3 v3.1 Q7);
        `domain` None means legacy-owner. Any other shape never admits. `account_id` is the
        assignment's account key or that account's book_account_id (X1c). The cached path is one
        stat per file (projection, and its publication marker when it carries one), one dict get
        and the comparisons (the entry carries its account's book id), never a parse."""
        if len(where) == 2 and domain is None and symbol is None:
            domain, symbol = where
        elif len(where) == 1 and symbol is None:
            symbol = where[0]
        elif len(where) == 1 and domain is None:
            domain = where[0]
        elif where:
            return False
        if not self._refresh():
            return False
        entry = self._allow.get(engine_id)
        return (entry is not None and entry[2]
                and (entry[0] == account_id or (entry[4] is not None and entry[4] == account_id))
                and symbol in entry[1] and entry[3] == (LEGACY_OWNER_DOMAIN if domain is None else domain))

    def exit_only(self, account_or_domain: str) -> bool | None:
        """Exit-only by account id, by domain (probe_runner asks by domain), or by book id (the
        book's own gate asks by the id it passes): one dict get. None when unknown, or when the
        accounts sharing a book id disagree (fails closed)."""
        if not self._refresh():
            return None
        return self._exit_only.get(account_or_domain) if type(account_or_domain) is str else None


BREAKERS_VIEW_SCHEMA = "leafhft.engine_registry.breakers.v1"
BREAKERS_VIEW_FILE = "breakers.json"
_BREAKERS_VIEW_KEYS = frozenset({"schema", "generation", "domain", "account_id",
                                 "account_pct", "engines", "digest"})


def validate_breakers_view(doc: Any) -> dict[str, Any]:
    """Validate the isolated breaker document, including its canonical digest."""
    keys = _BREAKERS_VIEW_KEYS
    if type(doc) is dict and BOOK_ACCOUNT_ID in doc:
        keys = keys | {BOOK_ACCOUNT_ID}
    _exact(doc, keys, "breakers")
    if doc["schema"] != BREAKERS_VIEW_SCHEMA:
        raise RegistryError("unknown_schema", repr(doc["schema"]))
    _decimal(doc["generation"], "breakers.generation", 1, MAX_GENERATION)
    _match(_DOMAIN, doc["domain"], "breakers.domain")
    _match(_KEY_ID, doc["account_id"], "breakers.account_id")
    if BOOK_ACCOUNT_ID in doc and not valid_book_account_id(doc[BOOK_ACCOUNT_ID]):
        raise RegistryError("invalid_value", "breakers.book_account_id")
    _decimal(doc["account_pct"], "breakers.account_pct", MIN_BREAKER_PCT, MAX_BREAKER_PCT)
    engines = _object(doc["engines"], "breakers.engines")
    if len(engines) > MAX_ASSIGNMENTS:
        raise RegistryError("too_many_assignments", "breakers.engines")
    for eid, pct in engines.items():
        _match(_ENGINE_ID, eid, "breakers.engines key")
        if pct is not None:
            _decimal(pct, "breakers.engines." + eid, MIN_BREAKER_PCT, MAX_BREAKER_PCT)
    _match(_HEX64, doc["digest"], "breakers.digest")
    if doc["digest"] != document_digest(doc):
        raise RegistryError("digest_mismatch", "breakers")
    return doc


def breakers_view_for(registry: Registry, domain: str) -> dict[str, Any]:
    """Only this domain's account percentage and assigned engines' overrides."""
    projection = projection_for(registry, domain)
    aid = projection["account_id"]
    view = {"schema": BREAKERS_VIEW_SCHEMA, "generation": projection["generation"],
            "domain": domain, "account_id": aid,
            "account_pct": str(registry.effective_pct(aid)[0]),
            "engines": {eid: registry.doc["loss_breakers"]["engines"].get(eid)
                        for eid in projection["assignments"]}}
    if BOOK_ACCOUNT_ID in projection:
        view[BOOK_ACCOUNT_ID] = projection[BOOK_ACCOUNT_ID]
    view["digest"] = document_digest(view)
    return validate_breakers_view(view)


def breakers_view_bytes(registry: Registry, domain: str) -> bytes:
    return canonical_bytes(breakers_view_for(registry, domain))


def assignment_allows(projection: RegistryProjection, engine_id: str, account_id: str, symbol: str, *,
                      domain: str | None = None) -> bool:
    return projection.assignment_allows(engine_id, account_id, symbol, domain=domain)
