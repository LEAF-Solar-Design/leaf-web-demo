"""Gold's paper execution boundary, independent of fleet and portfolio changes.

Transport supplies accepted batches and fenced publication. This module owns
source admission, checkpoint recovery, event consumption and result creation.
The digest covers whole files, including package initialization dependencies.
"""
from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path
import tempfile
import time

from .checkpoint_files import restore, snapshot
from .gold_paper_live import KIND, GoldPaperLive, validate_generation


GOLD_SOURCE_CLOSURE = (
    'leafhft/__init__.py',
    'leafhft/book.py',
    'leafhft/broker/__init__.py',
    'leafhft/broker/base.py',
    'leafhft/broker/paper.py',
    'leafhft/checkpoint_files.py',
    'leafhft/config.py',
    'leafhft/costs.py',
    'leafhft/fees.py',
    'leafhft/gold_artifacts.py',
    'leafhft/gold_calendar.py',
    'leafhft/gold_paper_live.py',
    'leafhft/gold_runner.py',
    'leafhft/paper_results.py',
    'leafhft/strategy/__init__.py',
    'leafhft/strategy/base.py',
    'leafhft/strategy/kalshi_gold.py',
    'leafhft/strategy/settlement.py',
    'leafhft/types.py',
    'leafhft/venue_facts.py',
)
assert GOLD_SOURCE_CLOSURE == tuple(sorted(set(GOLD_SOURCE_CLOSURE)))


class WorkerSourceMismatch(ValueError):
    """This worker runs another source; the generation itself is not stalled."""


def gold_source_sha256():
    """Hash Gold's reviewed execution closure, never the whole shadow fleet."""
    root = Path(__file__).resolve().parents[1]
    digest = hashlib.sha256()
    for relative in GOLD_SOURCE_CLOSURE:
        path = root / relative
        if any(part.is_symlink() for part in (path, *path.parents) if part != root):
            raise ValueError('source links forbidden')
        if not path.is_file():
            raise ValueError('source file missing: ' + relative)
        name = relative.encode()
        data = path.read_bytes()
        digest.update(len(name).to_bytes(8, 'big'))
        digest.update(name)
        digest.update(len(data).to_bytes(8, 'big'))
        digest.update(data)
    return digest.hexdigest()


async def work_once(control, generation, frozen, row, out_dir, *,
                    next_batch, should_stop=lambda: False):
    """Evaluate one accepted batch under the caller's lease."""
    if frozen['source_sha256'] != gold_source_sha256():
        raise WorkerSourceMismatch('worker source mismatch')
    validate_generation(frozen)
    batch = next_batch(control, row['cursor'])
    if not batch:
        return False
    previous = control.read(row['head']) if row['head'] else None
    if previous and (previous['generation'] != generation or previous['cursor'] != row['cursor']
                     or previous['source_sha256'] != frozen['source_sha256']):
        raise ValueError('checkpoint binding mismatch')
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=out_dir) as directory:
        destination = Path(directory) / 'host'
        if previous:
            restore(destination, previous['files'])
        instance = GoldPaperLive(destination, generation, frozen['source_sha256'])
        source_seconds = previous['source_seconds'] if previous else None
        next_renewal = 0.0
        for event in batch['events']:
            if should_stop():
                return False
            now = time.monotonic()
            if now >= next_renewal:
                control.renew(row)
                next_renewal = now + 30
            await asyncio.wait_for(instance.consume(event), timeout=30)
            instance.processed += 1
            stamp = event.get('t_recv_ns')
            if type(stamp) is int and stamp > 0:
                # Lag follows all accepted stream rows without replacing source time.
                source_seconds = (stamp / 1e9 if source_seconds is None
                                  else max(source_seconds, stamp / 1e9))
        if should_stop():
            return False
        instance.checkpoint()
        instance.views()
        control.renew(row)
        result = dict(generation=generation, cursor=batch['cursor'], paper=True,
                      source_sha256=frozen['source_sha256'],
                      source_seconds=source_seconds if source_seconds is not None else 0,
                      files=snapshot(instance.out), kind=KIND)
        control.accept(row, result, batch['cursor'])
    return True
