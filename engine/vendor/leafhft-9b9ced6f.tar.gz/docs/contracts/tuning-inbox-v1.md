# Tuning inbox v1

Status: C0 wire freeze for `tuning-inbox-20260929`, based on
`C:/tmp/tuning-inbox-plan-v1.1.md`. This is a contract for the subsequent slices,
not a claim that their routes or money-path code already exist.

## Authority and scope

The producer proposes, the dashboard stores and transports, the non-root runner
plans, and the root runner alone verifies presence and mints through engine_ops.
Only `verb=accept` authorizes placement. The operator's reviewed, pinned iPhone
Secure Enclave P-256 credential signs for both owner and tenant accounts. Tenant
devices may read their own accounts but cannot authorize them. No browser key,
WebAuthn, Telegram hold, signed reject, or dashboard-minted approval exists in v1.
The existing tg1 channel and legacy approval-request tables remain unchanged.

Accept covers init, try, mint for every eligible card, probe/bind, the exact
owner restart steps, and probe-activate. Retire and kill lists are display-only,
labelled **not run by Accept**. Existing money checks, including `_wave_check`,
probe_failures, max_concurrent_probes, HARD_MAXIMA and the R3 envelope, still run.
Tenant planning remains disabled until the owner drill; `e6216739` is always
excluded, before insertion, planning or execution.

## Encoding and identifiers

All clocks are integer UTC Unix milliseconds unless a unit explicitly says
seconds. JSON numbers must be integers in `[-9007199254740991,9007199254740991]`;
booleans are not integers. Fractions, exponents, NaN and Infinity are refused.
Sizing and money use decimal strings, never JSON floats. Reject duplicate JSON
keys, unknown fields in closed objects, malformed UTF-8 and embedded NULs.

Canonical plan JSON is `json.dumps(doc, sort_keys=True, separators=(",", ":"),
ensure_ascii=True, allow_nan=False).encode("ascii")`, with no BOM or trailing
newline. Restrict plan strings and keys to printable ASCII; this makes ordering
and escaping identical across Python, TypeScript and Swift. Hash the **exact
decoded bytes**, never a client's reserialization. SHA-256 values are 64 lower
hex characters, code_sha is 40 lower hex characters, nonce is 32 lower hex
characters (16 random bytes), UUIDs are canonical lowercase hyphenated strings.
Base64 is standard padded RFC 4648, no whitespace, verified by decode/re-encode.

`account` is eight lowercase hex digits; a root-owned runner mapping supplies
`registry_account` (`owner` or the tenant registry key). Never infer this mapping
from a request. `cycle_kind` is `owner_daily`, `owner_starve`, or `tenant_planned`.
`cycle_id` matches `^ap-\d{8}(-h\d{2})?$`; its date/hour must be valid UTC and
within 36 hours of the server clock (date-only means midnight). generated_at_ms
must also be within 36 hours of receipt. runner_host is 1..64 characters matching
`[A-Za-z0-9][A-Za-z0-9.-]*`. Engine ids, card and step request ids match
`[A-Za-z0-9][A-Za-z0-9._:-]{0,127}`. The wave is a positive monotonic integer per
account, never reused for a different proposal. UUID request_id is the HTTP
idempotency key; it is distinct from engine_ops card/step request ids.

C0 decision: encoding, identifier syntax, cycle-kind spellings, and the limits
below resolve details left open by the frozen plan.

## States, actors and transitions

Open states are `proposed`, `planning`, `ready`, `accepted`, `executing`,
`waiting_window`, `held`. Terminal states are `executed`, `rejected`,
`superseded`, `revoked`, `expired`, `plan_refused`, `failed`. No terminal row is
reopened. Each transition is one conditional UPDATE on `(id, version, state)`
with its request-journal result in the same statement; increment version once.
Every CAS additionally checks server-derived runner_host and, for claimed work,
lease id, lease epoch and lease expiry. Old workers cannot report or mutate a
new lease. Same HTTP request_id and same body hash replays the stored response;
a changed body is `409 idempotency_conflict`, before incrementing any counters.

| From | To | Actor and condition |
| --- | --- | --- |
| absent | proposed | can_propose producer; new eligible cycle |
| absent | superseded | producer's late/equal-time different cycle; stale_cycle |
| proposed | planning | matching planner claim_plan; flags enabled |
| planning | ready | leased planner post_plan, verified frozen bundle |
| planning | proposed | planner refusal or expired lease, attempts 1 or 2 |
| planning | plan_refused | server on third failed planning attempt |
| ready | ready | advisory signature refusal; attempt/event only |
| ready | accepted | operator mobile signed accept, advisory pre-check passes |
| proposed/planning/ready | rejected | operator's unsigned reject plus confirm token |
| accepted | executing | matching executor claim_exec; authority reverified locally |
| executing | executing | executor step receipt or heartbeat, same lease |
| executing | waiting_window | executor's restart guard refuses current window |
| waiting_window | executing | executor claim_exec in a later permitted gap |
| accepted/executing/waiting_window | held | executor sees OFF, HOLD, CONTAINMENT or unreadable guard inputs |
| held | accepted/waiting_window | executor after guard clears, using persisted resume_state |
| executing | executed | executor post_result after all steps settled successfully |
| accepted/executing/waiting_window/held | failed | executor irrecoverable refusal, unknown outcome exhausted, lost bundle, or third lapsed executor lease |
| any open | superseded | server receives strictly newer generated_at_ms in same (account, cycle_kind) |
| any open | revoked | server on account switch off or explicit admin revoke |
| any open | expired | server read/claim at proposal age >= 7 days |
| planning/ready/accepted/executing/waiting_window/held | proposed | server on plan expiry or code_sha change, plan_seq incremented |
| any open | failed | admin force_fail with nonempty reason |

Before replacing an executing plan, fence its lease, reconcile in-flight work,
and revoke unconsumed dv1 approvals. Completed receipts remain immutable and the
next planner observes live state. An unresolved outcome fails as
timeout_unreconciled instead of blindly replaying under a new plan. Revocation
and supersession never undo completed placements. They fence further steps and
require cleanup. A process cannot interrupt an already-issued external action;
it records its eventual receipt and performs no next action under the old lease.

Supersession is scoped only to (account, cycle_kind); at most one open row exists
in that scope. Equal generated_at_ms does not supersede. A newer identical grid
carries the planning content forward, but not its authority: create a new child
plan bound to the new proposal/cycle and a fresh nonce, rehash, discard old
decisions, and require a new accept. Preserve original frozen_at_ms/expiry; if
expired, or code/host/gates changed, replan instead. C0 decision: carry-forward
never transfers a signature to a different proposal or extends its lifetime.

Plans are append-only with UNIQUE(proposal_id, plan_seq), starting at 1. Replan
allocates plan_seq+1; old evidence cannot match it. Decisions (max 3 attempts per
plan_seq), events and request journal are append-only. A bad signature is
non-terminal refused_signature. C0 decision: after the third decision attempt,
ready remains readable but further attempts get decision_attempts_exhausted;
reject, revoke or expiry/replan still work. Idempotent retries cost no attempt.

## Clocks, retention and scheduling

| Clock | Rule |
| --- | --- |
| Proposal lifetime | created_at_ms + 604800000; checked on every read and claim |
| Plan lifetime | expires_at_ms = frozen_at_ms + 86400000; expire at equality |
| First evidence binding | -60000 <= runner_now_ms - issued_at_ms <= 7260000 (2 h + 60 s) |
| Resume | ledger binding, nonce, plan/code/host and expiry checked; do not age-check issued_at again |
| Planner interval | 60000 ms; runner_sync stale when age > 180000 ms or missing |
| Executor interval | 15000 ms |
| Planning lease | 180000 ms, renewed every <= 30000 ms |
| Executor lease | 90000 ms, renewed every <= 15000 ms; fence before side effects |
| Lease failures | third lapsed executor lease fails bundle_lost if copy missing, otherwise lease_abandoned |
| Confirm request | expires at min(created_at_ms + 300000, plan.expires_at_ms) |
| Browser status poll | every 5000 ms, stop at confirm expiry |
| Restart gap | inclusive seconds 60..420 of each 900 s epoch cycle; at most one unit per gap |
| Restart blackout | 23:35Z inclusive to 00:25Z exclusive; no inbox override |
| Waiting-window notice | notify once after > 1800000 ms waiting; no failed-lease charge while parked |
| Gate freshness | R1/R3 <= 86400000 ms, R2 <= 604800000 ms and matching code_sha; future gates refused |
| Retention | after > 30 days terminal, null raw grid/plan/assertion/receipt payloads, retaining digests and metadata |

C0 decision: lease lengths, renewal periods, future-signature tolerance and
boundary inclusivity above are normative. A heartbeat cannot revive an expired
lease. Lease loss returns work to its claimable state twice, preserving journal;
waiting_window and held have no running lease. Every read performs expiry
maintenance first, including producer status reads. Payload-null retention is
the only exception to UPDATE/DELETE refusal on append-only child tables.

## Routes, authentication and bounds

All limits are bytes, not characters; KiB = 1024. Bound the body while reading
and before JSON/base64 parsing. Oversize is 413 payload_too_large. All responses
are private/no-store. GET has no body. POST requires application/json and a
closed object. Lists default to 20, max 50, with opaque cursor pagination;
list summaries omit raw plan/grid/assertion bytes. A single-id read returns the
exact plan_b64 and plan_sha256. Planner reads may be up to 512 KiB; executor
responses are <= 64 KiB (claims reference its local bundle, not inline plans).

Auth helper names marked **new** are required D3 interfaces, not existing code.

| Route / methods / ops | Auth | Request bound and behavior |
| --- | --- | --- |
| `/api/leafhft/tuning/proposals` POST | authenticateAutopilotPushPrincipal plus persisted can_propose and account allowlist | 192 KiB JSON; decoded grid <= 128 KiB; <=48 accepted publishes/account/UTC day |
| same, GET | same principal, own allowlisted accounts only | 0; max 50 summaries |
| `/api/leafhft/tuning/runner` POST claim_plan, post_plan, heartbeat | **new** authenticateTuningPrincipal, role=planner, registered host | claim/heartbeat 4 KiB; post_plan 384 KiB, decoded plan <=256 KiB |
| same, POST claim_exec, step, post_result, heartbeat | authenticateTuningPrincipal, role=executor, registered host | claim/heartbeat 4 KiB; step/result 64 KiB |
| `/api/kashbot/admin/tuning-inbox` GET | browser admin helpers below | 0; list or id read |
| same, POST reject_confirm, revoke, force_fail, account_switch | browser admin helpers below | 4 KiB; reason 1..300 printable characters on force_fail/revoke |
| `/api/kashbot/admin/tuning-inbox/[id]/confirm-request` POST | browser admin helpers below | 4 KiB; proposal_id, plan_seq, plan_sha256, request_id |
| `/api/kashbot/admin/tuning-inbox/[id]/decision` POST | browser admin helpers below | 4 KiB; unsigned reject only; any accept assertion refused |
| `/api/kashbot/admin/tuning-inbox/principals` GET/POST/DELETE | browser admin helpers below | GET 0; POST/DELETE 4 KiB; hash/host/role registration or revocation |
| `/api/leafhft/mobile/tuning-inbox` GET | verifyLeafhftMobileAuth + SQL deviceControlsAccount | 0; max 50 summaries or id read; outside scope 404 |
| same, POST reject_confirm | mobile auth plus operator-only check below | 4 KiB; unsigned confirm token issuance |
| `/api/leafhft/mobile/tuning-inbox/[id]/decision` POST | mobile auth plus operator-only check below | 16 KiB; decoded assertion <=8 KiB; accept or confirmed unsigned reject |

Browser admin helpers mean `withKashbotBrowserSession(..., {admin: true})`,
`getKashbotBrowserSession`, `requireKashbotEngineAdmin`, an explicitly present
Origin header AND `isKashbotBrowserOriginAllowed(request, true)`. The origin
helper alone accepts absent Origin, so the route must check presence itself.
Mobile decisions and reject-confirm require the static owner bearer token OR
a non-monitor device whose tenant equals configured LEAFHFT_OPERATOR_TENANT_ID;
unset refuses device authority. A browser-session fallback never authorizes a
mobile decision. Operator account reads still pass the account-scope check.
No other tenant device can accept, even with a purported valid signature.

Runner auth hashes its bearer token and matches a non-revoked tuning principal.
Ingest tokens, including legacy ones, get 403; missing tuning configuration gets
503 runner_unconfigured. Role/host mismatch is 403. runner_host in a body is
ignored: derive from registered principal and account mapping, check every CAS.
Planner and executor tokens are distinct, generated on-runner, stored 0600 in
their separate StateDirectories, never `/run/leafhft/ingest.env`. Principals POST
accepts exactly request_id, token_hash (SHA-256), host, role; never token value.
DELETE accepts request_id, token_hash, reason. GET exposes no token values.

New middleware exemptions are exactly these four entries, never a prefix:

1. EXACT `/api/leafhft/tuning/proposals`
2. EXACT `/api/leafhft/tuning/runner`
3. EXACT `/api/leafhft/mobile/tuning-inbox`
4. Pattern `^/api/leafhft/mobile/tuning-inbox/[^/]+/decision$`

C0 decision: mobile reject_confirm uses the existing list path, allowing unsigned
native rejection without a fifth middleware exemption. D3 must extend the auth
helper's exact POST permission for these two mobile inbox paths; its current
POST_PATHS only includes `/api/leafhft/mobile/control`.

### Request and result shapes

Producer POST fields are request_id, account, cycle_id, cycle_kind,
generated_at_ms, grid_b64, grid_sha256, grid_sig_b64, retire. grid signature is
Ed25519 (below). Retire is at most 36 unique engine ids and is display-only.
Same (account, cycle_id) and same immutable content returns 200 with the same id;
changed grid/content gets 409 already_exists. First insert returns 201. A valid
late cycle is delivered as superseded/stale_cycle. Grid digest mismatch is
400 grid_sha_mismatch; excluded account and allowlist violations are 403.

Runner bodies have op and UUID request_id. Claims add account; at most one row
per account per call. Leased ops add proposal_id, plan_seq, version, lease_id.
post_plan has outcome=ready with plan_b64 and plan_sha256, or outcome=refused
with code and detail (<=300 ASCII chars). step adds step_id, status
(`started`, `completed`, `outcome_unknown`), receipt (bounded JSON) and
receipt_sha256 of its canonical bytes. post_result adds state, code, receipts
(step_id and receipt_sha256 references, not duplicate unbounded payloads).
heartbeat reports code_sha, credential_fingerprints and producer_key_fingerprint;
leased heartbeat additionally carries lease fields. Claims return lease_id,
version, lease_expires_at_ms and plan/grid references; only claim_plan may
include producer bytes. Post-plan success records the planner's local bundle
reference for executor pickup. Do not send a 256 KiB bundle via a 64 KiB exec response.

Admin ops include op, request_id and version; proposal ops add proposal_id;
account_switch adds account and enabled boolean. Reject confirmation issues a
random single-use token bound to actor, proposal, plan_seq and version, expiry
min(now+5 min, plan expiry if any). Decision reject fields are request_id,
proposal_id, plan_seq, version, verb=reject, confirm_token; no signature fields.
Accept POST fields are request_id, proposal_id, plan_seq, version, verb=accept,
assertion_b64 (base64 of the assertion JSON below). URL id must match body id.

Confirm-request is permitted only for ready and fresh runner_sync: otherwise
409 runner_stale for stale sync/expired plan. At most one pending request and
three requests per plan_seq. Identical retry returns the same confirm request;
changed request_id body is 409. Reply includes confirm_request_id, expires_at_ms,
status=waiting. Push category tuning_confirm_request only opens the item. The
phone fetches and hashes exact bytes before Face ID; push arrival is no authority.
Status becomes confirmed only on accepted decision, or expired on its deadline
or invalidated plan. candidate_ready is deduped by (account, grid_sha256).

Responses use `{success:true, code, ...}` or `{success:false, code}` without
reflecting secrets. Stale version/lease/state gets 409 state_conflict;
unconfigured service gets 503; disabled global flag gets 409 inbox_disabled;
account off gets 409 account_disabled. Rate limits get 429 rate_limited.
C0 decision: method/op payloads, response spellings and bounds in this section
are the D1/D3 interfaces. Authenticated retries precede quota charging.

## Plan v1: closed schema and step grammar

Required top-level fields (no additional fields):

| Fields | Type / rule |
| --- | --- |
| schema | literal `leafhft.tuning-plan.v1` |
| proposal_id, account, registry_account, cycle_id, cycle_kind, generated_at_ms | identities above, matching proposal and root mapping |
| plan_seq, wave | positive safe integers |
| runner_host, code_sha, grid_sha256, runner_nonce | fixed identities and hashes above |
| frozen_at_ms, expires_at_ms | safe nonnegative integers, exactly 24 h apart |
| engines | 1..36 distinct placement engines; schema below |
| manifests | 1..36 distinct eligible placement cards; schema below |
| steps | 1..252 ordered steps; schema below |
| gates | exactly three full owner-live-gate.v1 receipt objects R1/R2/R3, or [] with gate_waiver |
| gate_waiver | null or closed {waiver_id, cap_total}; only separately operator-authorized configuration |
| n_max_total | integer 0..256; gate/waiver cap enforced, never widened by plan |
| deferred | at most 36 closed {engine_id, reason} rows, display-only |
| retire | at most 36 unique engine ids, display-only |

Engine fields: id, parent, set (ASCII policy-key map to string/int/bool), symbols
(nonempty sorted distinct SYMBOL_MAP keys), sizing (canonical positive decimal
string), summary, novelty (each <=300 printable ASCII), request_ids (closed
{probe, activate}), activation (null or closed {bytes, sha256}). Activation bytes
are base64 of the exact engine activation document, <=64 KiB, bound by sha256;
never accept a producer-supplied activation filesystem path. Activation is
required if probe-activate is present. Existing completed init/try/probe steps
may be omitted only with live-state reconciliation before mint/activation.

Manifest fields are exactly request_id, bytes, sha256. `bytes` is base64 of the
**exact manifest bytes**, <=64 KiB decoded, and sha256 hashes those bytes. Parse
as a closed {items} object; each item is {kind:"probe", engine, account, symbols,
sizing}. Every planned engine occurs in exactly one card with identical scope
and sizing; account is registry_account. Cover every eligible card. No renewal,
retire or kill item is legal. max_cards=36 and max_engines=36 are independent
limits; exceeding either or total canonical plan size 256 KiB refuses the whole
bundle as plan_too_large. Do not silently truncate or defer due to Telegram's
hour/day scheduling. Retain the card request ids from generation's unique wave.

Every step has exactly step_id, op, argv, plus the fields shown below. step_id is
`s001`..`s252` matching array order. E is a plan engine id, R is a listed card
request_id, P/A are that engine's probe/activate request ids, S is its comma-joined
symbols, U is its mapped owner unit. `EO` expands to the literal first three argv
elements `["python3","-m","leafhft.engine_ops"]`. The displayed arguments are
individual strings; no shell, interpolation, environment assignment or extra flags.

| op / extra fields | Exact argv |
| --- | --- |
| init / engine_id | EO + ["manifest","init",E,"--parent",parent,"--symbols",S,"--summary",summary,"--novelty",novelty] + sorted ["--set","key=value"] pairs |
| try / engine_id | EO + ["try",E] |
| mint / request_id | EO + ["approve","--kind","wave","--manifest","@manifest:"+R,"--request-id",R,"--presence-decision","@decision","--presence-plan","@plan"] |
| probe / engine_id, request_id, card_request_id | EO + ["probe",E,"--symbols",S,"--approval","@approval:"+R+":"+E,"--bind","--request-id",P] |
| restart / symbol, unit, config_digest, ack_sentence | ["python3","deploy/runner/rearm.py","--apply",U] |
| probe-activate / engine_id, request_id | EO + ["probe-activate",E,"--activation","@activation:"+E,"--request-id",A] |

All engine/card/request metadata must equal the argv scope. `set` values render
as their literal string, decimal integer or lowercase true/false. Symbol maps
to exactly `leafhft-live@kalshi-<lowercase symbol with '-' retained>.service`;
unit must equal the reviewed SYMBOL_MAP-derived allowlist and the signed value.
Restart is a compound executor operation, not an arbitrary subprocess dispatch.
Its argv denotes the final re-arm action; the guarded stop/start/evidence
choreography below is mandatory. Tenants have zero restart steps. Owners have
exactly one per distinct placed symbol. init and try have no --request-id.
All placeholders are literal tokens resolved only to root-owned copied bundle
files or the named mint's journaled approval id. No other @ token or path is legal.

Order is all required init, all required try, mint for each card, all probe --bind,
all owner restarts, then all required probe-activate. C0 decision: this phase
ordering and token grammar are closed; no retire/kill, arbitrary command, service
wildcard, or raw systemctl step can be signed into authority.

Restart config_digest is lowercase SHA-256; ack_sentence must match exactly:

```text
I authorize live trading with config <64 lower hex>[ under policy bounds <12 lower hex>] and a stake of at most $<digits>.<two digits>
```

The brackets describe an optional segment and are not literal bytes. No final
period or newline belongs to ack_sentence. Its config digest must equal the
step's config_digest. Freeze the entire latest-startup sentence including stake
and any policy-bounds suffix; never synthesize it from a guessed stake. The rail
writes that exact sentence followed by one LF to LIVE-ACK.

## Decision bytes and cryptography

Assertion JSON has exactly kind, credential_id, decision, signature_b64. kind
is **se-p256 only**. credential_id is lowercase SHA-256 of DER SPKI, matching a
reviewed runner pin. Decision object has exactly verb, proposal_id, plan_seq,
plan_sha256, runner_nonce, account, issued_at_ms. The ASCII message is the
following lines in this order, each ending with LF, including the final line:

```text
leafhft.tuning-decision.v1
verb=accept
proposal_id=<uuid>
plan_seq=<base-10 integer>
plan_sha256=<64 lower hex>
runner_nonce=<32 lower hex>
account=<8 lower hex>
issued_at_ms=<base-10 integer>
```

Integers have no leading zero, sign or exponent. The verb field is serialized
literally before checking policy; anything other than accept returns
verb_not_allowed and cannot mint. There are no signed reject fixtures. The
non_accept_verb negative changes the verb to `cancel` without granting authority.

Signature is ECDSA P-256 over SHA-256(message), ASN.1 DER SEQUENCE(r,s), base64.
Use message-signing APIs (Python ECDSA(SHA256), Apple
ecdsaSignatureMessageX962SHA256), not a second hash of an already hashed message.
Accept valid low or high s; production Secure Enclave signatures need not be
deterministic. Fixture generation uses RFC6979 deterministic signing. An SPKI
must identify secp256r1, not another curve. A fingerprint supplied by the client
does not install trust. Empty reviewed pins return presence_unconfigured.

Verifier order: bounded strict parsing/kind -> pins configured and credential
match -> verb -> exact plan hash and proposal/seq/account/host/code binding ->
nonce -> plan expiry -> first-bind issued_at -> ECDSA signature. Reasons are
invalid_assertion, unsupported_kind, presence_unconfigured, credential_unknown,
verb_not_allowed, plan_sha_mismatch, evidence_scope, nonce_mismatch,
plan_expired, issued_at_stale, issued_at_future, refused_signature respectively.
Same-message signature verification with a wrong key returns refused_signature;
an unknown credential id returns credential_unknown. D2's result is advisory;
H1/H2 repeat the authoritative verification inside the root approve verb.

Evidence SHA-256 hashes the canonical assertion JSON bytes, including signature.
The root-only evidence ledger binds once to (proposal_id, plan_sha256) and the
listed card request ids. Every card mints at most once; another listed card may
mint with the same evidence, an unlisted id returns evidence_scope. Resume
requires the existing binding and unexpired plan, not a fresh Face ID signature
or a renewed issued_at. Replanning requires a new signature. dv1- approvals
carry grade presence-device-v1, credential_id and plan/evidence digests.

## Producer grid signature bytes

Grid transport is Ed25519, separate from the se-p256 decision kind. Verify its
signature before parsing the decoded grid; empty pinned producer key returns
grid_unsigned. grid_sha256 is SHA-256 of the exact decoded grid bytes, including
any whitespace. Sign the following ASCII lines with one final LF:

```text
leafhft.tuning-grid.v1
account=<8 lower hex>
cycle_id=<cycle id>
cycle_kind=<cycle kind>
generated_at_ms=<base-10 integer>
grid_sha256=<64 lower hex>
```

Ed25519 signs these message bytes directly (not SHA-256 of the message).
grid_sig_b64 is base64 of the 64-byte signature. The producer public key is 32
raw bytes pinned in runner code, its reporting fingerprint is SHA-256(raw key).
Recompute the grid hash first: mismatch is grid_sha_mismatch, otherwise bad
signature is grid_signature_invalid. H4 verifies again and matches every plan
engine's id, parent, set and symbols against the signed grid. Default pick30
must never add unsigned engines. Retire display metadata grants no authority.

## Execution, kill switches and result codes

Before claim, mint and every step, fail closed on missing/unreadable status or
lease, disabled TUNING_INBOX_ENABLED, disabled account, OFF or CONTAINMENT.
Existing/unstatable `/var/lib/leafhft-tuning/OFF` or
`/var/lib/leafhft/CONTAINMENT`, any affected HOLD, or a missing/unreadable
`/root/leafhft-cliff` directory parks as held. A missing marker in a readable
directory is clear. Recheck between steps and immediately before each stop and
mint. Global disable pauses claims/decisions and holds existing execution;
account switch off revokes open rows. Clearing a local hold resumes the persisted
phase only after evidence/expiry/digest/lease checks. Never remove HOLD or
CONTAINMENT, lift a money guard, or extend evidence to finish a plan.

The executor uses its own O_NOFOLLOW, regular, root-owned, mode-checked plan
copy under `/var/lib/leafhft-tuning` (0700); missing is plan_not_local. Verify its
hash and all copied manifests/activations. Every mutating verb runs as root.
Steps fsync started/completed/outcome-unknown receipts before progressing. Init
and try reconcile by state; request-id steps follow MAX_REPLAYS=3, then
timeout_unreconciled with one notify. A pending(...) tenant lease note fails.
Manual root resolve journals a settlement rather than deleting a step.

For each signed restart: persist and enforce the one-unit-per-gap slot, arm
LEAFHFT_REARM_WINDOW_GUARD=1 with no override, check the fresh clock immediately
before initial stop, stop and wait <=30 s for inactive/failed, start, poll the
positional `rearm.py --plan U` every 3 s within the rail's bounded refusal wait.
Reject command errors/non-gate failures. Pin the new gate-closed refusal's digest
and entire sentence to the signed values, recheck guards, then call apply_plan
with its window guard. Revalidate through the rail immediately before its stop
and after journal read. Drift is plan_stale; window refusal is waiting_window,
not failure. Journal subphases so a crash does not allocate another gap or mint
again. probe-activate requires ActiveEnterTimestamp after bind and fresh ack:
LEAFHFT_AUTHZ_V2=1 uses retained ack + arm record, otherwise consumed ack receipt.

All subprocesses and HTTP calls have timeouts. Failed or invalidated plans revoke
unconsumed dv1 approvals; no completed placement is implicitly rolled back.
Persistent FYI outbox uses capped backoff; notify on failed, plan_stale,
presence_refused, lapsed lease, and >30 min waiting_window.

| Terminal state | Result codes |
| --- | --- |
| executed | executed |
| rejected | operator_rejected |
| superseded | newer_cycle, stale_cycle |
| revoked | account_disabled, operator_revoked |
| expired | max_await_expired |
| plan_refused | planning_attempts_exhausted; last_reason includes plan_too_large, grid_unsigned, grid_sha_mismatch, grid_signature_invalid, gate_refused, startup_evidence_missing, input_unreadable, tenant_disabled |
| failed | presence_refused, plan_stale, plan_not_local, bundle_lost, lease_abandoned, step_grammar, grid_scope, mint_refused_after_init, timeout_unreconciled, tenant_lease_pending, restart_failed, step_failed, admin_force_failed |

Terminal result includes state, code, completed step ids, receipt hashes, created
ids (especially mint_refused_after_init), revoked approval ids and optional
last_reason. Non-terminal status codes are ready, accepted, refused_signature,
decision_attempts_exhausted, held, waiting_window, plan_expired, code_changed and
lease_lapsed. A presence_refused result includes the precise verifier reason;
advisory signature refusal alone never terminally fails a ready proposal.
C0 decision: result codes and wrapper/detail distinction above are frozen.

## Source anchors and rollout obligations

These leaf-hft references were read in this task checkout:

- `leafhft/owner_live_plan.py:510-554`: Telegram card packing/scheduling and
  distinct per-card request ids; `:968-1005`: init/try without request id,
  approve/probe argv, owner-symbol restarts and activation arguments;
  `:1022-1028`: per-card manifest bytes and bounds.
- `leafhft/engine_ops.py:5566-5567`: 64 items and 64 KiB manifest bound;
  `leafhft/engine_controls.py:99`: MAX_REPLAYS=3.
- `leafhft/engine_ops.py:5540-5543` and `:6835-6860`: tg1's in-verb presence
  channel and frozen record; H2 must preserve it while adding the device channel.
- `leafhft/owner_live_plan.py:53`, `:274-283`, `:1130-1131` and `:1210`:
  default pick30 merge can add or override grid rows; H3 supplies an empty list.
- `leafhft/owner_live_plan.py:657-674` and `:1161-1164`: gate loads and degraded
  planning; unattended H3 must refuse instead of relying on that degradation.
- `leafhft/owner_live_rate.py:216` and `:253`,
  `scripts/bench_owner_live.py:322` and `:419`, and
  `leafhft/owner_live_envelope.py:156` and `:211`: R1/R2/R3 receipt producers.
- `deploy/runner/units/leafhft-exposure-step.service:22` and
  `leafhft/engine_ops.py:463-472`, `:489-500`: writable parent directories are
  required for sibling temporary files and atomic replacement.
- `leafhft/engine_ops.py:3684-3693`: probe-activate reads an activation document;
  C0 pins its copied bytes rather than trusting a planner-supplied path.
- `leafhft/feeds/kalshi.py:101`: SYMBOL_MAP allowlist.
- `leafhft/cli.py:2184`: startup config digest and exact ack sentence.
- `deploy/runner/rearm.py:22-26`: sentence grammar; `:30-37`: gap and blackout;
  `:63-69`: HOLD location and missing-path behavior; `:112-122`: guard defaults
  off; `:136-147` and `:173`: matching gate refusal and ten-minute journal;
  `:189-209`: validation/stop/drift; `:210-227`: exact fsynced ack write.
- `deploy/runner/rollout.sh:708-762`: guarded stop/start, refusal polling and
  positional-unit re-arm. `leafhft/broker/live_gate.py:330-335`: authz-v2 receipt
  distinction. `leafhft/owner_live_gate.py:13` and `:70-75`: gate freshness.

Auth anchors were separately read in the frozen companion checkout
`C:/tmp/wt-od-inbox-bf110eca` (they are not files in this leaf-hft checkout):

- `src/lib/services/leafhft-autopilot-push.ts:19-29`: existing hashed push
  principal; can_propose is a new scope, not currently enforced there.
- `src/lib/api/leafhft-mobile-auth.ts:13-25`: current method restriction;
  `:55-64`: browser fallback that must not grant decision authority.
- `src/app/api/kashbot/admin/engine-approval-requests/route.ts:13-14` and
  `:37-39`: admin helpers (the plan's :36 points at a blank line).
- `src/lib/api/kashbot-aws-auth.ts:12-25`: strict configured origin comparison,
  including the absent-Origin caveat.

The frozen plan's `.gitignore:4` citation is stale in this checkout: that line
is `.pytest_cache/`, and this file has no `program/*` entry. C0's durable artifact
is this tracked doc; any program pointer belongs to the planner, outside C0.

H3 requires root-owned protected configuration and a fresh complete R1/R2/R3 GO
set from H8, invokes generation with an empty --pick30 and unique wave, and uses
systemd-journal group access for latest-startup evidence without a ten-minute
limit. H8 reruns real producers; withdraw old publication before refresh, publish
only a complete validated set, never timestamp old success. R1/R3 run daily;
R2 reruns on SHA change or within 24 h of seven-day expiry, during the settlement
blackout with Nice=19 and CPU quota. An incomplete refresh prevents planning.

H6 installs timers disabled, grants the executor writable parent directories
for atomic replacements and read-only HOLD visibility, and supplies alerting.
E0 requires reviewed pins, operator-approved release, migration/API deployment,
hash-only principal registration, on-runner permissions/sandbox proof, recorded
authz mode and successful H8 refresh before enabling. Empty pins refuse presence,
empty grid key refuses grids, and TUNING_INBOX_ENABLED gates both claims and
decisions. No fixture key below is a deployable trust root.

## Golden fixture interface

`tests/fixtures/tuning_inbox_v1/vectors.json` is the byte-for-byte fixture copied
by D2 and H7; consumers compare the whole file SHA-256. It contains four distinct
signed accept decisions (two owner, two tenant), four exact plan documents and
their bytes/hashes, signed Ed25519 grids, public test keys, and explicit negative
inputs with expected result codes and expected cryptographic validity. Decision
case `kind` is always se-p256; Ed25519 appears only in the separate grids section.

Each decision carries assertion, decision_ascii, decision_sha256, evidence_sha256,
plan_id, trusted_key_id, now_ms, signature_valid and expected. Negative cases are
complete inputs, not instructions to mutate a hidden base. `wrong_key` verifies
against another test pin; `wrong_plan_sha` and `wrong_nonce` retain the original
signature over changed message bytes; `stale_issued_at` retains a valid signature
but advances the first-bind clock. `non_accept_verb` is refused before crypto.
`mutated_grid_byte` retains the original digest/signature over changed grid bytes;
`mutated_grid_rehashed` also recomputes the advertised digest, proving signature
failure rather than only digest mismatch. Tests recompute every stored digest,
regenerate deterministic signatures from clearly test-only private material and
check both policy outcomes and mathematical signature validity for negatives.
