# Tuning inbox v2

Status: L3a wire reference for `engine-unify-20261003`. Draft 3 resolutions,
round 3 residuals and the attempt-2 planner decision on R3-2 are binding.
This is a contract for subsequent slices, not a claim that the producer,
writer, readers or runtime already implement it. Money-path review precedes
activation.

## Authority and scope

L3 owns this contract, the pure reference, golden vectors, non-root freeze
producer in tuning_plan.py, both presence-verifier branches, both readers,
device capability, publication gate, notifications and widget links. L2 owns
the authenticated change API, root engine_ops deploy writer, signature
verification, consumption journal and atomic generation write. P3 book
processes emit apply receipts. The L2 API creates the proposal and hands
change_sha256 to L3b ingestion. No dummy manifests or v1 card ids represent v2.

The producer proposes, the operator reviews and signs with the pinned Secure
Enclave P-256 credential, and the writer applies. Only Accept authorizes
application. Signing this plan never substitutes for the separate account
envelope boot ack. Freeze, writer apply and boot ack use the same envelope
digest, but are separate authorizations.

V2 is owner-only. Tenant ingestion, freeze and writer apply refuse
tenant_v2_deferred until P5 binds device mandates. The trusted root account
mapping determines ownership: registry_account=owner in untrusted bytes
does not establish authority. The offline reference checks this assertion,
not the mapping. Decoding never grants execution authority.

## Encoding and identifiers

All clocks are integer UTC Unix milliseconds. JSON numbers in the outer
plan are integers in [-9007199254740991,9007199254740991]; booleans are not
integers. Refuse fractions, exponents, NaN, Infinity, duplicate keys, unknown
closed fields, malformed UTF-8, BOM, embedded NUL and non-printable ASCII
strings or keys. Bound nesting to 64 levels. Decimal quantities use strings.

Canonical JSON is
`json.dumps(doc, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode("ascii")`,
without BOM or trailing newline. Hash exact received plan bytes for the
presence decision, never the client's reserialization. Formatting and
object-key order may vary on input; arrays have the normative order below.
Envelope and after-state digests explicitly hash canonical bytes instead.

SHA-256 is 64 lowercase hex, code_sha is 40 lowercase hex, runner_nonce is
32 lowercase hex. UUIDs are lowercase hyphenated 8-4-4-4-12 hex. account is
eight lowercase hex. runner_host matches [A-Za-z0-9][A-Za-z0-9.-]{0,63}.
Engine ids match [A-Za-z0-9][A-Za-z0-9._:-]{0,127}; creates have at most 32
characters. Policy override keys match [A-Za-z_][A-Za-z0-9_]{0,127}.
Base64 is standard padded RFC 4648, without whitespace, verified by
decode/re-encode. Book ids are exactly BTC-15M, ETH-15M, BTC-1H, ETH-1H,
BNB-15M, DOGE-15M, HYPE-15M, NEAR-15M, SOL-15M, XRP-15M, ZEC-15M, BNB-1H,
HYPE-1H, XRP-1H (leafhft/deployments_derive.py:27-30).
Leverage is an integer in {1,5,20,50,100,250}, never a string.

Nonnegative decimal strings match (0|[1-9][0-9]*)(\.[0-9]{1,6})?, at most
24 characters. No signs, exponents or leading zeroes. Trailing fractional
zeroes are allowed and remain digest-significant. Fractions are in [0,1].
Every money value marked cents is a nonnegative safe integer.

Bound raw input before JSON parsing: at most 256 KiB. Canonical plan bytes
are also at most 256 KiB. Refuse plan_too_large rather than truncate. An
embedded policy is at most 64 KiB decoded; bound its encoded length before
base64 decoding. Baseline has at most 14 books and 1024 rows; controls at
most 15; items at most 64 total; catalog at most 1088; effects and tuner
evidence at most 1088; migration rows and policies at most 1024 each.
These bounds intersect: 1024 baseline rows need not fit with their effects
under the byte bound. The maximum-size golden plan is exactly 262144
canonical bytes. No promise exists that every count limit is simultaneously
attainable.

## Plan v2: closed schema

Every field below is required; no additional fields:

| Fields | Type / rule |
| --- | --- |
| schema | literal leafhft.tuning-plan.v2 |
| proposal_id, account, registry_account | identities above; registry_account must be owner |
| plan_seq | positive safe integer, beginning at 1 |
| runner_host, code_sha, runner_nonce | identities above |
| frozen_at_ms, expires_at_ms | nonnegative safe integers; exactly 86400000 ms apart |
| cycle_kind | deployment_change or migration |
| cycle_id | dc- plus 16 lower hex for change; mg- plus 16 lower hex for migration |
| change_sha256 | digest of exact stored authenticated change request bytes |
| origin | operator or tuner, equal to authenticated request origin |
| kind | change for deployment_change; migration for migration |
| expected_generation | nonnegative safe integer |
| resulting_generation | expected_generation + 1, still a safe integer |
| baseline | closed inventory below |
| controls | array, controls below |
| items | array, creates then deploys below |
| catalog | sorted digest evidence below |
| envelope | closed {version,digest,document}; version integer 1 |
| sizing_basis | closed {free_balance_cents,day_open_cents,observed_at_ms}; nonnegative safe integers; frozen_at_ms - 900000 <= observed_at_ms <= frozen_at_ms, else sizing_basis_stale |
| migration | null for change, closed migration object otherwise |
| effects | complete recomputed sorted list, including neutral rows |
| tuner_evidence | array of closed evidence references below; [] for operator |

At least one control, item or migration row is required. No raise and no
sizing_law means approval_not_required: L2 applies those changes directly.
generated_at_ms is proposal-only metadata, not signed in v2. V1 grid, wave,
manifest, card and step fields are not accepted.

L3a decision: catalog and tuner_evidence are required evidence extensions;
migration policies and windows use the exact shapes below. They make local
referential checks unambiguous without pretending the signed producer's
claims are independent evidence of the actual catalog or request.

## Baseline, controls and items

Baseline is closed {paused,books,rows}. paused is boolean. books is sorted
by book, unique, with closed {book,book_off} entries and boolean book_off.
rows is sorted by (book,engine), unique, with closed
{book,engine,engine_policy_digest,leverage,on} entries; on is boolean.
Every row's book appears in books. Every row's engine appears in catalog
with the same digest.

Scope includes exactly the books named by controls, deploys or migration.
An account control instead requires every book and row of the account,
including empty books and off rows. The producer and locked writer compare
the deployments document projection at expected_generation exactly;
difference refuses baseline_mismatch. A reader cannot prove completeness
against an external document. Include book_off and paused even when no
transition changes them.

Catalog entries are closed {engine,engine_policy_digest}, sorted and unique
by engine. Include exactly the existing engines referenced by baseline,
deploys or create parents. This is a projection of the whole trusted catalog,
not the whole catalog. A new create id must be absent from the WHOLE catalog,
checked independently by producer and writer. Locally it must be absent from
the projection and other creates. Deploying an existing engine on a new book
uses its catalog digest. Every occurrence of an existing engine is immutable.

| Control fields | Type / rule |
| --- | --- |
| kind | control |
| scope | account or book |
| book | null for account, scoped book id for book |
| field | paused for account, book_off for book; no other pairing |
| from, to | booleans; from equals baseline |

Controls sort by (scope,book or "",field), unique on that key.

| Create fields | Type / rule |
| --- | --- |
| kind | create |
| engine | globally new engine id, at most 32 characters |
| parent, parent_policy_digest | existing catalog id and its exact digest |
| policy_bytes, policy_digest | base64 exact resolved JSON policy bytes and SHA-256 of those bytes |
| set | policy-key map to string/int/bool; no null or nested values |
| summary | 1..300 printable ASCII characters |

Creates sort by engine and precede all deploys. The producer and writer
resolve parent plus set themselves and compare the resulting exact bytes;
a difference refuses create_policy_mismatch. Local digest validity cannot
prove parentage. Policy documents are objects whose full field semantics
are owned by the policy resolver. The reader preserves their exact bytes;
for sizing it reads decimal strings or plain JSON fractional number tokens
as exact decimal strings, never Python floats. Outer-plan fractional JSON
numbers remain forbidden. per_order_fraction and daily_loss_fraction in
the sizing view are decimal strings; omitted fields use defaults below.
stake_ceiling_usd is a decimal string or integer dollar amount giving exact
integer cents. fixed_count must be absent, null or zero for cells.
The local reference validates these sizing fields, not the entire runtime
policy vocabulary. Unknown policy settings confer no execution authority.

| Deploy fields | Type / rule |
| --- | --- |
| kind | deploy |
| book, engine | scoped book and created or catalog engine |
| engine_policy_digest | create digest for new engine; catalog digest otherwise |
| from | null iff absent in baseline; otherwise closed {leverage,on} equal to baseline |
| to | closed {leverage,on}; legal integer leverage and boolean on |

Deploys sort by (book,engine), unique on that key. A digest change on an
existing engine refuses immutable_engine, even when off. Dangling references
refuse; create parents must be existing catalog engines, not another create.
Migration permits only deploys of its existing baseline rows, never creates
or newly added rows.

The producer and writer both re-derive controls, creates and deploys from
authenticated change request bytes and compare origin and change_sha256.
Any difference refuses change_mismatch. This external authorization check
is mandatory; decode_plan_v2(data) has no trusted request input and cannot
perform it.

Tuner origin is a producer DEFAULT, not a universal 1x schema cap. Its
default creates engines at 1x on named books. For each tuner raise whose
final leverage exceeds 1, including paused, book-off and switched-off rows,
tuner_evidence contains exactly one closed
{book,engine,leverage,receipt_sha256} reference, sorted by (book,engine,leverage).
No unused references are allowed; the digest names the exact justification
receipt bytes retained with the authenticated request. Producer and writer
must authenticate and bind that receipt to this engine, book and step.
The phone labels tuner raises distinctly. Every raise requires rendered
review and Face ID. The receipt resolver remains assigned below.

## Effects and readback state

Compute over the union of baseline rows and rows added by deploys. Apply
all independent controls and deploys to copies. entering is
row exists AND on AND NOT paused AND NOT book_off. Order of object keys,
formatting and traversal of independent transitions cannot change effects.

Use this precedence:

1. raises if leverage increases, the row is new, the row deploys a created
   engine, its engine digest changes, or entering changes false to true.
   These tests apply regardless of entering state, including paused,
   book-off and switched-off rows. A changed existing policy digest still
   refuses immutable_engine before effects computation.
2. Otherwise sizing_law for every migration row, including off or lowered
   rows and unchanged leverage.
3. Otherwise lowers if entering changes true to false or leverage decreases.
4. Otherwise neutral.

Every create item also has its own raises effect, even without a deployment.
Its book is the empty string (a policy-level sentinel, never a book id),
before is null, and after is closed {engine_policy_digest}, equal to the
create's policy_digest. This approves the new policy itself with Face ID.
Create effects need no tuner receipt of their own; every deployed raises
row above 1x does, including deployments that remain off.

Effects sort by (book,engine), with exactly {book,engine,effect,before,after};
create effects precede deployment-row effects.
Ordinary before/after state is closed {entering,leverage,on,paused,book_off}.
All but leverage are booleans. For an absent before row, leverage=null,
on=false and entering=false; paused/book_off retain baseline values.
Present states have legal integer leverage. There is no row deletion item.

| Transition | Effect |
| --- | --- |
| leverage increases while paused, book-off or switched off | raises |
| pause or turn off and raise leverage in the same plan | raises |
| new row, including an off row | raises |
| create item, and each row deploying it even off | raises |
| entering changes false to true | raises |
| existing engine digest changes | immutable_engine refusal |
| migration row without a raise | sizing_law |
| entering changes true to false or leverage decreases, without a raise or migration | lowers |
| otherwise | neutral |

The review screen shows the leverage change and the final entering state
separately. For a 1x to 250x raise on an off row, it reads "raises 1x to 250x
while off; it trades at 250x when turned on". Such a plan still requires
rendered review and Face ID; pausing in the same plan cannot waive approval.

Migration before extends the five state fields with exactly
{sizing_law:"legacy",today_contracts,today_cents_at_median_fill,
window_start_ms,window_end_ms}. Migration after extends them with exactly
{sizing_law:"cells-v3",new_S_cents,new_per_entry_cap_cents}. Values equal the
migration evidence. This overrides D3-9's five-field shape only for migration.
The desired_digest is SHA-256 of the canonical after object alone; row and
account identity are separately bound by the receipt. Thus migration
readback proves law, S and cap changed, not merely leverage/on.

Every reader and writer recomputes the complete effects list and refuses
effects_mismatch on any difference, including missing neutral rows, unknown
fields or bool/int substitutions. compute_effects validates plan structure
and references but deliberately ignores claimed effects. decode_plan_v2
also compares effects and enforces that approval is needed.

## Migration and sizing evidence

One owner book per migration. Required closed fields:

| Fields | Type / rule |
| --- | --- |
| book | the only baseline book |
| law_from, law_to | legacy, cells-v3 respectively |
| rows | sorted by engine, unique, exactly baseline engines one-to-one |
| policies | sorted by engine, unique, exactly migration engines; closed {engine,policy_bytes,policy_digest}, matching catalog |
| source_digest | SHA-256 of P1 derived.json source |
| generation | expected_generation; P1 evidence generation |
| small_rows_today_slice_cents | floor(min(5000, 0.30 * 0.15 * day_open_cents)) |
| small_rows_sum_S_cents | sum new_S_cents over small rows |
| small_rows_exceed_slice | boolean, exactly small_rows_sum_S_cents > small_rows_today_slice_cents; recomputed by decoder |
| book_sum_S_cents | sum new_S_cents over all rows |
| rounding | literal ceil_to_cent; order-price convention, does not change allocation floors |

Each row is closed:

| Fields | Type / rule |
| --- | --- |
| engine | baseline engine |
| leverage_before, leverage_after | baseline leverage and final leverage after deploys |
| today_contracts | nonnegative decimal string, at most six places |
| today_cents_at_median_fill | nonnegative integer cents measured by P1 |
| window_start_ms, window_end_ms | nonnegative safe integers; start < end <= frozen_at_ms |
| new_S_cents, new_per_entry_cap_cents | recomputed nonnegative safe integer cents |
| role | probe or other; P1 roles other than probe normalize to other |
| small | boolean, exactly role == probe |

P1 decides small membership from the actual shared slice, not the producer.
Producer and writer check source_digest, generation, roles, windows and
measurements against frozen P1 evidence. The signed values let offline
readers recompute arithmetic, not independently authenticate P1. Show every
row, both sums and the envelope in dollars. The first migrated book also
shows the F6 values being signed.

Under ratified F5, the operator signs per-cell budgets that may exceed
today's shared probe slice; the comparison is not a refusal or allocation
clamp. If small_rows_exceed_slice is true, the review screen prominently
shows "these engines together get more than today's shared probe budget".
The [account envelope](#account-envelope) bounds the total at runtime under
F6 and the P3 enforcement obligation below; legacy risk-room reductions
are evidenced at leafhft/strategy/kalshi_edge.py:1240-1246. This is not a
claim that the new envelope intersections are already deployed.

### Allocation and per-entry upper bound

The normative functions are new_S_cents(resolved_policy,envelope,leverage,
sizing_basis) and max_entry_cents(resolved_policy,envelope,new_S_cents,
sizing_basis). Let B = sizing_basis.free_balance_cents, the ratified
allocation basis, not day_open_cents. Use exact Decimal arithmetic from
decimal strings, never float; floor only where written:

The balance observation must be at most 15 minutes old at freeze:
frozen_at_ms - 900000 <= observed_at_ms <= frozen_at_ms. Older or future
observations refuse sizing_basis_stale.

```text
new_S_cents =
  floor(min(resolved_policy.daily_loss_fraction, envelope.daily_loss_fraction)
        * leverage / 250 * B)

max_entry_cents(resolved_policy, envelope, new_S_cents, sizing_basis) =
  max(0, min(floor(B * resolved_policy.per_order_fraction),
             floor(B * envelope.per_order_fraction),
             resolved_policy.stake_ceiling_usd * 100,
             envelope.per_book_stake_cents,
             new_S_cents))
```

The stake_ceiling_usd term is exact integer cents and is omitted when the
field is absent; do not insert the runtime stake default. Missing policy
per_order_fraction uses "0.10" (leafhft/policy.py:318); missing policy
daily_loss_fraction uses "0.15" (leafhft/policy.py:320). Zero inputs yield
zero; no one-cent minimum. The reference fixes its own Decimal precision
so a caller's rounding/precision cannot alter authorization arithmetic.

This figure is displayed as **at most, at the signed balance B**, not an
attainable quote-dependent prediction. It scales with balance and is not
a runtime clamp: a balance that grows after signing can yield a larger
per-entry amount. At the same balance, conviction, Kelly, price and
remaining risk room usually reduce the amount further.
Cells have fixed_count unset. Buys round UP to whole cents under FILL-2:
that applies to order prices, not to these caps. The quantity law and
rounding are defined here once; Python, TypeScript and Swift share the
golden arithmetic vectors.

Source and integration evidence for each clamp:

| Term / further reduction | Source |
| --- | --- |
| policy per-order fraction and stake ceiling | leafhft/policy.py:155-167; final max(0,min(...)) at :167 |
| regime per-order bound | leafhft/policy.py:164-166; leafhft/strategy/kalshi_edge.py:864 and :1682-1687 |
| stake dollars and authorized stake reduction | leafhft/strategy/kalshi_edge.py:868-874 |
| envelope per-order and per-book bounds | cells-v3 ratified planner formula above; P3 must intersect runtime caps with these exact terms |
| cell new_S_cents bound | cells-v3 ratified planner formula above; P3 must intersect runtime cap with S |
| conviction, size_scale, favourite and target-win | leafhft/policy.py:159-163, before the final minimum |
| Kelly only lowers cap | leafhft/strategy/kalshi_edge.py:1673-1678 |
| spent market room | leafhft/strategy/kalshi_edge.py:1694 |
| buffered fee-inclusive cost, whole-count floor | leafhft/strategy/kalshi_edge.py:1704-1709 and :1723 |
| reversal quantity reduction and final debit | leafhft/strategy/kalshi_edge.py:1724-1740 |
| daily loss, cash floor, drawdown room | leafhft/strategy/kalshi_edge.py:1240-1246 |

There is no current-code line implementing the new envelope/S intersections:
they are P3 runtime obligations, not a claim about legacy deployment.
Do not import entry_size_cap into this pure reference: its hard_maxima
reads process environment. The signed upper bound omits additional
quote-dependent reductions; it does not remove them from execution.

## Account envelope

The exact document is closed:

| Fields | Type / rule |
| --- | --- |
| schema | leafhft.account-envelope.v1 |
| daily_loss_fraction, per_order_fraction, cluster_fraction | decimal fraction strings in [0,1], at most six places |
| drawdown_brake_fraction, drawdown_stop_fraction | same; brake <= stop |
| cash_floor_cents, per_book_stake_cents | nonnegative safe integer cents |
| reversal_max_open_cents, reversal_budget_cents | nonnegative safe integer cents |

envelope_digest hashes canonical document bytes with SHA-256. envelope
version is integer 1. Writer checks the authorized envelope and never
silently widens it to match the plan. Decimal spellings remain part of the
signed document; "0.1" and "0.10" can have distinct digests.

## Decision bytes and consumption

The exact eight-line decision message is unchanged. Each line ends with LF,
including the last:

```text
leafhft.tuning-decision.v1
verb=accept
proposal_id=<uuid>
plan_seq=<base-10 integer>
plan_sha256=<64 lower hex>
runner_nonce=<32 lower hex>
account=<8 lower hex>
issued_at_ms=<base-10 integer>
```

Retain v1 assertion, signature, credential and runner-pin rules and the
rendered-review gate before Accept. Changed plan hash, sequence or nonce
requires fresh presence evidence. Keep v1 decoding through rollback.
From the first v2-aware release, the root v1 executor tuning_execute.py
must refuse any v2 schema fail closed (L3e); the two executors never both act.

The L3 non-root producer claims a v2 proposal, receives change_sha256 and
authenticated change request bytes instead of a grid, resolves state,
checks the request binding and posts the frozen plan. Both producer and
writer enforce the external checks above. The v2 verifier returns closed
{proposal_id,plan_seq,plan_sha256,account,expected_generation,resulting_generation}.
L3a decision: approval_id is SHA-256 of this object's canonical bytes.
The writer consumes once, journals before recovery, and re-reads its own
journal by approval_id. A replay of the same committed operation is a no-op
returning the same resulting_generation. V1 card consumption is unchanged.

## Capability, publication and old clients

The authenticated /api/leafhft/mobile/push-token body gains integer
plan_contract_max in 1..2, absent means 1. The authenticated
/api/leafhft/mobile/capabilities route carries the same field for devices
which denied notifications. Persist per device. The approving device is
the existing designated operator confirmation device.

Re-send capability on every launch and capability change. Re-pair or a
lower reported build number resets capability to 1. Gate at freeze, ready,
each push dispatch and detail read. Filter lists and details BEFORE
pagination and serialization. Devices below 2 receive no v2 plan bytes:
show an old-reader-compatible fixed placeholder, "update the app to review
this change". The static owner-token branch never receives v2 rows.
Incompatible publication also alarms.

Deploy additive server support with producer flag off, then browser and
TestFlight dual readers; observe the approving phone advertising 2.
Merge the runner verifier through a daily cut. Prove freeze, review,
Face ID, writer verification and atomic apply plus old-device refusal
before activation. Before P3, proofs stop at writer apply. The first P3
migration supplies live readback. Change publication waits for P3 or the
phone shows "applied, waiting for the book to confirm" until receipts exist.
Notifications/widget activation follows the end-to-end gate.

## States and apply receipt

A receipt is closed {account,book,engine,desired_digest,applied_generation,
approval_id,observed_at_ms}. Identities follow this contract; digests are
lowercase SHA-256; generation/time are nonnegative safe integers.
P3 emits through leafhft-push.service like control acks. Store by approval
AND row; one receipt cannot cover an entire multirow approval.

Receipts are required for EVERY row whose effective state changes,
including lowers, indirect control changes and migration law changes.
Policy-level create effects have no book-process receipt; the writer
confirms creation, and any deployment requires its own row receipt.
Compare canonical before/after states, not merely the effect label;
unchanged baseline rows need none. Match account, book, engine, approval,
desired_digest and applied_generation=resulting_generation.

| State / display | Condition |
| --- | --- |
| approved, waiting | decision accepted; writer not yet committed |
| applying | writer wrote resulting_generation; complete matching readback absent |
| live | every changed row has matching after-state digest/generation receipt observed within five minutes |
| failed | writer refusal or apply failure |
| superseded | later generation changed an affected row before complete readback; never show live |

Poll the existing detail route; never say "Placed" for v2. The observation
clock/window adapter remains assigned below. Migration supersession scopes
(account,cycle_kind,book); change scopes (account,cycle_kind). L3b migrates
the unique index accordingly.

Ready notifications use durable jobs keyed by account, proposal, sequence,
hash and device, enqueued with ready. Journal before APNs; recheck state,
identity, expiry and capability on every attempt. Shared caps: 3 per plan,
6 per account/hour. Notification authenticationRequired/foreground actions
and widget URLs open review only, never accept. Widget target includes
expires_at_ms; expired proposals leave the count. Live Activity exists
only while pending and refreshes on every state change (L3f).

## Refusals and reference API

PlanV2Error exposes code and a message containing only that code.
decode_plan_v2(bytes) returns a dict or refuses. Pure functions perform
no I/O, clock reads, catalog lookup, signature verification or consumption.

| Decoder code | Condition |
| --- | --- |
| plan_too_large | byte or collection/policy bound exceeded |
| invalid_json | invalid JSON/UTF-8, duplicate key, forbidden number token or non-bytes input |
| invalid_plan | closed shape, scalar type/range, ASCII, ordering, identifier or cross-field grammar invalid |
| tenant_v2_deferred | registry_account is not owner |
| baseline_mismatch | control/deploy from mismatch or local touched-book projection mismatch |
| duplicate_transition | duplicate sorted inventory, control, create, deploy, migration or evidence key |
| dangling_reference | missing or unused catalog entry, missing book, engine or policy reference |
| immutable_engine | existing/parent/catalog/create-deploy digest mismatch or create id already in catalog |
| create_policy_mismatch | malformed base64/policy, hash mismatch or invalid cell sizing fields; also used externally for failed parent resolution |
| envelope_mismatch | canonical envelope digest mismatch |
| sizing_basis_stale | balance observation older than 15 minutes at freeze or later than freeze |
| migration_mismatch | migration inventory, generation, leverage, small membership, windows, arithmetic, sums or small_rows_exceed_slice disagree |
| effects_mismatch | claimed effects differ from full recomputation |
| approval_not_required | no raises and no sizing_law after all other checks |
| tuner_evidence_required | missing, extra or wrong-step tuner receipt reference |

Refusal order is pre-parse raw bound, strict JSON/tree, canonical bound,
top-level/identity/generation, sizing basis, envelope, baseline and catalog,
controls, items, migration, scope, tuner evidence, effects and approval need.
Within a collection, inspect wire order; validate each row before checking
the array's duplicates/order. Malformed oversized policy text is rejected
by its encoded bound before base64 parsing. Golden refusal vectors isolate
one condition rather than relying on ordering among unrelated faults.

External-only change_mismatch means authenticated request hash/origin or
re-derived operations differ. baseline_mismatch additionally covers locked
generation/inventory, and create_policy_mismatch additionally covers parent
resolution. Those external checks have no trusted inputs in this decoder;
a self-contained negative decode vector cannot prove they were performed.
The golden file covers every DECODER code in REFUSAL_CODES. L2/L3b must
add external refusal vectors at their authenticated boundary.

The golden file has schema leafhft.tuning-plan-v2.vectors.v1, vectors with
{name,plan_b64,expect:{ok,effects|code}}, and sizing_vectors with
{name,resolved_policy,envelope,sizing_basis,leverage,expect:{new_S_cents,
max_entry_cents}}. Shared arithmetic vectors exercise each minimum term
winning, defaults, floors and zero. Copy the fixture verbatim to the other
implementations; do not regenerate expected values from the implementation
being tested.

## Open items

1. **L2 / L3 freeze producer:** authenticate whole-catalog novelty and
   catalog projection, exact parent-plus-set resolution, request-to-plan
   binding and locked generation projection. Freeze the authenticated
   change-request transport schema; decoder success proves none of these.
2. **P1 / L2:** adapt derived.json to measured today_contracts,
   today_cents_at_median_fill, source digest, generation, roles and windows.
   leafhft/deployments_derive.py:379-392 supplies role/generation and an
   equity sizing proxy, not all these measurements. Supply actual free
   balance B; never silently substitute that equity proxy.
3. **P3:** enforce the signed envelope and S intersections in the live cell
   law with fixed_count unset; prove runtime debits do not exceed the bound
   recomputed at the runtime balance (the signed-balance figure is no clamp),
   including FILL-2 price rounding, fees, buffers and reversal paths.
4. **L2 / L3b:** freeze the authenticated receipt resolver for tuner
   justification and retention; receipt_sha256 is only a reference. Do not
   allow unauthenticated producer-invented justification.
5. **L3b / P3:** freeze receipt observation window anchor, clock and equality
   semantics plus supersession fencing. L3c/L3d must preserve applied-waiting
   wording until this and first-book readback are proven.
6. **L3b / L3c / L3d / L3e:** implement dual readers/verifiers, copy the
   fixtures and record their whole-file digest; prove old-client placeholder
   compatibility and the v1 executor schema refusal before activation.
