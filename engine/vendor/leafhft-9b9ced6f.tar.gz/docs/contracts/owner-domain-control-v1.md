### owner-domain-control v1 (FROZEN 2026-09-30, program kashbot-owner-merge-20260930)

Every slice M1..M9 builds against this text. A change needs a v2 from the planner; builders never edit it
except M1, which copies it verbatim to leaf-hft `docs/contracts/owner-domain-control-v1.md`.

## Purpose

The operator's Kashbot app lane e6216739 is parked (exposure role exit_only, zero assignments). The app must
show and control the `legacy-owner` execution domain (member_key `owner`, 14 `leafhft-live@kalshi-*` books)
instead. Pause stops new entries on every owner book; resume clears only that pause. Exits, settlements and
reduce_only orders always continue. The exposure registry, engine assignments, lifecycles, sizing, book
disables and breakers are never changed by this feature. Beta tenants (4383ed19, 5a1e869a, b8f87279) are
byte-for-byte unaffected.

## 1. Control kinds (leafhft_control_requests rows)

Added to `leafhft.engine_controls.KINDS`. `domain.resume` is NOT in `APPROVAL_KINDS`: its authority is the
device presence decision in `value.presence` (section 4), verified on the runner.

- `domain.pause` value: `{"domain":"legacy-owner","member_key":"owner","reason":"operator_pause","request_id":"<uuid>","requested_by":"device:<device uuid>"}`
- `domain.resume` value: `{"domain":"legacy-owner","member_key":"owner","expect_generation":<int>=0>,"request_id":"<uuid>","requested_by":"device:<device uuid>","presence":{"assertion":"<string, <=8 KiB>","plan":"<string, <=16 KiB>"}}`

Row fields: `venue='kalshi'`, `target_host=<owner registry holder host>`, `scope_kind='account'`,
`scope_account_id=<v_owner_account>` (the existing `'["<holder host>","kalshi",0]'` owner account form),
`engine_id=NULL`, `kind`, `value` as JSON text. Neon trigger (ops-dashboard migration, M5): a device may insert
a `domain.*` row only when a `kashbot_owner_lanes` row exists for the device's bound lane, `scope_account_id`
equals the owner account, and `value.domain='legacy-owner'`; every other device gets the existing refusal.
Audit action `control.request`, device-attributed, as today. At most one pending `domain.*` row per
(venue, scope_account_id): a unique partial index `WHERE state='requested' AND kind LIKE 'domain.%'`.

`engine_controls.validate`: `domain` fullmatch `[a-z0-9][a-z0-9:-]{0,63}` and equal to the applying process's
`_control_exposure_domain()`; `member_key` equal to `owner`; `reason` fullmatch the existing `_REASON`;
`request_id` a UUID; `expect_generation` a non-negative int; `presence.assertion` and `presence.plan` strings
within the bounds; unknown keys rejected. `argv()`:
- pause: `["domain","pause","--domain",d,"--member-key","owner","--reason",r,"--request-id",rid,"--requested-by",who]`
- resume: `["domain","resume","--domain",d,"--member-key","owner","--expect-generation",str(n),"--request-id",rid,"--requested-by",who,"--presence-assertion-file",<tmp>,"--presence-plan-file",<tmp>]`
  (the rail writes the two presence strings to 0600 temp files it deletes after the call; they never enter argv).
Exposure rule: pause applies in an `exit_only` or `authority` domain; resume is refused (`Rejected("domain_not_authority")`)
unless the domain's role reads `authority`. Unknown outcome stays pending (existing C12 rule). The ack note carries
`applied_sha=<runner git sha>` and `generation=<n>`.

## 2. Pause record (runner)

Path: `<engine_ops.DEFAULT_REGISTRY_DIR>/domain-pause/<slug>.json`, slug = domain with `:` replaced by `_`
(so `/var/lib/leafhft/engine-registry/domain-pause/legacy-owner.json`). Written only by `engine_ops domain`
under the engine-ops lock, temp file + fsync + rename, mode 0644, directory 0755, readable by every book user.
Never deleted. Strict decode: exactly these keys, no floats, no duplicate keys, <= 4 KiB.

```json
{"schema":1,"member_key":"owner","domain":"legacy-owner","generation":3,"state":"paused",
 "reason":"operator_pause","request_id":"<uuid>","requested_by":"device:<uuid>",
 "paused_at":"<iso8601Z>","resumed_at":null,"resume_nonce":"<32 hex>",
 "evidence_sha256":null,"previous_digest":"<64 hex>|null","digest":"<64 hex>"}
```

- `digest` = sha256 hex of the canonical JSON (sorted keys, compact separators) of the record without `digest`.
- `generation` starts at 1 on the first write and increments by 1 on every write.
- pause: if the stored record is `paused` with the same `request_id` it is a replay no-op (exit 0, same generation);
  otherwise write `state:"paused"`, new generation, fresh `resume_nonce` (16 random bytes, hex), `resumed_at:null`,
  `evidence_sha256:null`.
- resume: refuse `generation_stale` unless stored `generation == expect_generation` and `state == "paused"`;
  verify presence (section 4) bound to that generation and `resume_nonce`; then write `state:"resumed"`,
  generation+1, `resumed_at`, `evidence_sha256`, `resume_nonce:null`. A replay of the same request_id after
  success is a no-op. Resume never touches engine halts, breakers, venue pause, book disables or assignments.
- `engine_ops domain show --domain D` prints the record (or `{"state":"absent"}`) as JSON, exit 0.

## 3. Entry fence (broker)

In `leafhft/broker/kalshi_live.py` `_exposure_fence`, before the existing role read: read the pause record for
the client's execution domain through a module-level cache keyed on (st_mtime_ns, st_ino, st_size), one
`os.stat` per call, re-parse only on change.
- file absent -> admit (byte-identical to today's behaviour);
- `state == "paused"` -> raise `AccountRiskRefused(code="domain_paused")`;
- `state == "resumed"` -> admit;
- unreadable or malformed -> raise `AccountRiskRefused(code="domain_pause_unreadable")`.
Both existing call sites (`_reserve_entry_risk` before venue reads, and the non-reduce_only send boundary) get
it for free; reduce_only sends never reach the fence. Every KalshiLive constructor (incumbent, cohosted probes,
darkhorse, lanes/live_runner.py) passes through these two sites.

Status: each book's runtime status payload (the file the owner telemetry push already publishes) gains
`"domain_pause":{"generation":<int|null>,"state":"paused|resumed|absent|unreadable"}` read through the same cache,
so the API can prove every book observed the current generation.

## 4. Resume authority (device presence)

The phone signs a presence decision with its pinned Secure Enclave key using the existing se-p256 decision
format verified by `leafhft.tuning_presence` (read that module's contract, docs/contracts/tuning-inbox-v1.md).
The signed plan for this feature is a new plan kind `domain-resume-v1`, defined in `leafhft/owner_domain_control.py`:

```json
{"kind":"domain-resume-v1","domain":"legacy-owner","member_key":"owner","expect_generation":3,
 "resume_nonce":"<32 hex from the pause record>","request_id":"<uuid>","host":"<holder host>",
 "frozen_at":"<iso8601Z>","expires_at":"<frozen_at + 10 min>"}
```

`engine_ops domain resume` verifies the assertion against this plan with tuning_presence's verifier primitives
(pinned credential from tuning_trust, signature, nonce equality with the stored `resume_nonce`, plan expiry by the
runner clock, bind-once evidence ledger in the root-only approvals store). Any refusal leaves the record paused and
exits non-zero with the named reason. No API-minted approval and no approvals_dir file is needed. The phone gets
`resume_nonce` and `generation` from the status object (section 5).

## 5. Status API `execution` object (ops-dashboard `/api/kashbot/status`)

Added only when the authenticated device's bound lane has a `kashbot_owner_lanes` row. Every existing field
(`lane`, `tenant`, `request`, `automatedTrading`, ...) stays unchanged and truthful about the parked lane.

```json
"execution":{"schema":1,"domain":"legacy-owner","member_key":"owner","host":"<holder host>",
 "observed_at":"<iso8601Z, max producer heartbeat>","summary":"running|halted|degraded|unavailable",
 "pause":{"state":"paused|resumed|absent","generation":3,"paused_at":null,"resumed_at":null,
          "requested_by":null,"request_id":null,"resume_nonce":null},
 "pending_request":null,
 "counts":{"expected":14,"running":14,"entry_enabled":14,"halted":0,"missing":0},
 "books":[{"book_id":"btc-15m","run_id":"...","heartbeat_at":"<iso>","fresh":true,
           "observed_pause_generation":3,"entry_enabled":true,"blockers":[]}],
 "loss_breaker":{},
 "capabilities":{"owner_domain_control":true,"pause":true,"resume":false,"resume_requires_presence":true}}
```

`pending_request`, when a `domain.*` row is unacked: `{"id":"<row id>","kind":"domain.pause|domain.resume","state":"requested|applied|rejected","note":"","requested_at":"<iso>"}`.
`blockers` vocabulary: `operator_pause`, `venue_paused`, `book_halted`, `kill`, `breaker`, `exit_only`, `stale`, `generation_lag`.
Rules: `unavailable` iff the owner mapping or holder host is missing; `running` iff all expected books are fresh
(existing leafhft-monitor/defs.ts thresholds), every `observed_pause_generation` equals `pause.generation`
(null equals null for `absent`) and every `entry_enabled` is true; `halted` iff all fresh and every book's blockers
contain `operator_pause` at the current generation; otherwise `degraded`. `capabilities.pause` is true unless state
is paused; `capabilities.resume` is true iff `pause.state == "paused"`. `resume_nonce` is exposed only here, only to
the owner device. Expected books = 14 (btc,eth,sol,xrp,doge,bnb,hype,near,zec 15m; btc,eth,xrp,bnb,hype 1h).

## 6. API behaviour for an owner-lane device (`/api/kashbot/runner`)

Branch before `kashbot_request_runner`. For an owner-lane device: `pause` -> insert one `domain.pause` row, 202 with
the row id; `start_live` -> requires `presence:{assertion,plan}` in the body and a current `expect_generation`,
inserts one `domain.resume` row, 202; missing presence -> 409 `presence_required`; `start_dry_run`, `revoke` and any
lane enrollment action -> 409 `owner_lane_parked`. A second request while one `domain.*` row is pending -> 409
`request_pending`. Tenant devices take the unchanged existing path.

## 7. Parked lane guard (runner account lane agent)

A lane id listed in `/etc/leafhft-account-agent/owner-lanes.json` (`{"schema":1,"lanes":["e6216739-a5c2-4a10-9457-c2b52a96288a"]}`,
root-owned 0644; absent file = empty list) refuses `start`, `activate`, `enroll` and restore-to-live work with
`owner_lane_parked` on the direct, queued (sync cursor) and restore paths, and never starts
`leafhft-account@<lane>`. Pause and stop work on it still apply.

## 8. Phone (iOS)

Reads `execution.capabilities.owner_domain_control === true`; absent or false keeps today's lane UI. When true:
Account shows `summary` and counts; Pause enabled iff `capabilities.pause`; Start enabled iff `capabilities.resume`
and runs the presence flow (sign `domain-resume-v1` with the Secure Enclave key, POST with presence); readback
deadline 120 s with "Pausing" / "Resuming" while `pending_request` is non-null; no dry-run, revoke, engine or book
toggles, or Risky Batman tab. The owner engine halt and probe board stay.
