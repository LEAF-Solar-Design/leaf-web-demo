# Tenant offboarding

This is the ordered, receipted procedure Leaf Automation runs when a Kashbot tenant leaves. It releases every
engine assignment, stops and masks the tenant's lane, revokes the Kalshi credential without any value crossing a
context window, unpairs the tenant's device from both mobile allowlists, removes the lane's projection from the
root-owned tree, hands the tenant an export of their money, and keeps only what retention requires. Every step
writes a receipt and names its rollback.

Status: design. No `offboard` verb exists in today's code. Each step below is composed from verbs and files that
do exist, cited as `path:line` against `origin/main` at the time of writing. Where a step depends on something
that lives outside this repository (the ops-dashboard tenancy tables, the Vercel environment, the AWS task
secret, App Store Connect), the doc says so and marks the name UNVERIFIED rather than inventing it.

Section 3 now includes a partial offline checkpoint for one account and one UTC day. It does not complete
offboarding, prove settlement finality, or authorize account exit.

## Terms

The **tenant id** and the **lane id** are both UUIDs. A tenant owns exactly one lane; the provisioner refuses a
duplicate tenant or lane (`leafhft/account_lane_provision.py:125-138`). The **account id** is the engine
registry's name for the tenant's Kalshi account, and each registry assignment carries one
(`leafhft/engine_ops.py:1301` reads it, `leafhft/engine_ops.py:1324` reports it as `released_from`).

A live tenant lane lives in three root-owned trees (`leafhft/account_lane_agent.py:38-41`):

| Tree | Holds | Cited |
| --- | --- | --- |
| `/etc/leafhft-accounts/<lane>` | runner token, enrollment key, credential, config, approval | `leafhft/account_lane_agent.py:185-187`, `leafhft/account_lane_provision.py:225-246` |
| `/var/lib/leafhft-accounts/<lane>` | books, ledgers, KILL file, engine catalog projection | `leafhft/account_lane_agent.py:189-191`, `leafhft/account_lane_provision.py:241-243`, `leafhft/account_lane_provision.py:299-341` |
| `/run/leafhft-accounts/<lane>` | runtime scratch | `leafhft/account_lane_agent.py:193-195` |

The lane runs as the system user `leafacct-<20 hex>` derived from the lane id
(`leafhft/account_lane_agent.py:58-60`). Its units are `leafhft-account@<lane>.service`
(`leafhft/account_lane_agent.py:197-199`), and the `leafhft-account-sync@<lane>.timer` and
`leafhft-account-push@<lane>.timer` pair the provisioner enables (`leafhft/account_lane_provision.py:680-686`).

A dry-run tenant runs under the separate tenancy tree `/etc/leafhft-tenants`, `/var/lib/leafhft-tenants` and
`/run/leafhft-tenants` (`deploy/runner/tmpfiles.d/leafhft-tenants.conf:2-4`), as user `leafhft-<tenant>`
(`deploy/runner/units/leafhft-tenant@.service:8`). That path never holds a Kalshi key: `tenant-run.sh` refuses any
environment name that looks like a private key, a Kalshi key path or a live ack (`deploy/runner/tenant-run.sh:18-22`).

## Receipts

Every step writes one JSON receipt into a root-only directory, `/var/lib/leafhft-offboarding/<tenant>/` (mode
0700, proposed; nothing creates it today). A receipt carries: `step`, `tenant_id`, `lane_id`, `account_id`,
`started_at`, `finished_at`, the exact command run, its exit code, the sha256 of every artifact it produced or
removed, and the rollback tuple for that step. A receipt never carries a secret value, a token, a PEM, or a
signed URL; the credential appears only as its fingerprint, which is already a sha256 of the public key
(`leafhft/account_lane_agent.py:1100`). A step that fails writes a failure receipt and the procedure stops there;
the next run resumes at the first step without a success receipt.

engine_ops already writes its own receipts for step 1, under `<evidence-dir>/<engine_id>/receipts/<utc>-<verb>.json`
with the journal row in `<registry-dir>/engine-ops-journal.jsonl` (`leafhft/engine_ops.py:10-17`), defaulting to
`/var/lib/leafhft/engine-evidence` and `/var/lib/leafhft/engine-registry` (`leafhft/engine_ops.py:71`,
`leafhft/engine_ops.py:74`). The offboarding receipt for step 1 records those receipt hashes rather than copying
them.

## 1. Release every engine assignment

Break before make: the tenant's account loses every engine before anything else changes, so the entry gate closes
first. The registry projection that every book reads on its entry path fails closed when an assignment is absent
(`leafhft/engine_registry.py:1272-1274`).

1. List the account's assignments: `python -m leafhft.engine_ops registry show --json` prints the generation, the
   digest and the whole document (`leafhft/engine_ops.py:1101`, verb at `leafhft/engine_ops.py:2968`). Keep every
   engine id whose assignment names this account id.
2. For each engine id, run `python -m leafhft.engine_ops release <engine_id> --request-id offboard-<tenant>-<engine_id>`
   (`leafhft/engine_ops.py:2999-3002`). Release needs no approval. It snapshots the assignment into the request
   record before writing (`leafhft/engine_ops.py:1300-1305`), removes it from the registry
   (`leafhft/engine_ops.py:1320-1323`), and reports the new `registry_generation`
   (`leafhft/engine_ops.py:1324-1326`). Each release commits a new generation, one above the current or above
   the highest journaled one (`leafhft/engine_registry.py:786-789`, `leafhft/engine_registry.py:803-817`).
3. If a probe bound the engine's symbols, add `--restore-bindings` so the bindings file returns to its pre-probe
   bytes; release refuses `bindings_changed_since_probe` when someone edited it since
   (`leafhft/engine_ops.py:1307-1319`).
4. A crash mid-list is safe. Rerunning a completed release's request id replays its receipt and writes nothing
   (`leafhft/engine_ops.py:1015-1016`). A release that crashed after writing a step is never resumed: its rerun
   refuses `transaction_interrupted` and writes nothing (`leafhft/engine_ops.py:1023-1025`). Finish it with
   `python -m leafhft.engine_ops repair offboard-<tenant>-<engine_id> --finish` (`leafhft/engine_ops.py:2989-3026`),
   which runs only the remaining release steps. A release is never rolled back, because that would re-authorize
   the engine without an approval.

Today's `release` takes one engine id and has no `--account` flag (`leafhft/engine_ops.py:2999-3002`). The spec
names `engine_ops release --account <aid>`; that flag is a proposed addition that would loop the same `perform`
per assignment under one lock. Until it exists, the list in item 1 is the loop.

Done when `registry show --json` lists no assignment for the account id and `registry audit` exits 0.

Rollback: re-assign with
`python -m leafhft.engine_ops assign <engine_id> --account <aid> --symbols <list> --approval <file> --request-id <id>`
(`leafhft/engine_ops.py:2991-2997`). Assign requires a fresh approval, by design: offboarding is undone
deliberately, never by a replay.

## 2. Stop the lane and wait for flat

Send the lane the dashboard `stop` command. The root agent writes `KILL` into the lane state, removes the
activation document, stops `leafhft-account@<lane>.service`, disables it at boot, and rewrites `approval.json`
to `approved: false` (`leafhft/account_lane_agent.py:1063-1077`). Every book loop checks `KILL` and exits
(`leafhft/account_lane_agent.py:747`, `leafhft/account_lane_agent.py:783`).

Open positions are left to settle rather than flattened into a wide book. Wait until the account shows no open
position and no unsettled market, then record the final balance in the receipt. A market's settlement can lag
its close, so the wait is on the venue's settlement rows, not on the clock.

Rollback: delete `KILL`, write the approval back through the normal enroll and activate path
(`leafhft/account_lane_agent.py:1078-1079`); a stop never deletes state, so nothing is lost.

## 3. The tenant's export

Build the export before the credential is revoked. The economics reader takes venue day statements from disk
(`scripts/kalshi_daily_read.py:685`), and the last day's statement has to be captured while the tenant's key still
validates (inferred: this repository does not show which process fetches the statements).

The complete offboarding export must cover every day the tenant traded. The current command supplies only
one account-day, from an explicit statement and an immutable registry snapshot:

```text
python scripts/kalshi_account_export.py --account <account-id> --day 2026-09-17 --statement <statement.json> --registry-snapshot <registry.json> --output <new-checkpoint.zip>
```

Both inputs are read once. Their captured bytes are hashed and validated before publication. The statement
must name an account that resolves to the requested account in the validated registry. There are no live-path
defaults, network calls, credential reads, or ledger discovery. The output path must not exist. Invalid input
returns code 2 with a bounded diagnostic that does not quote input contents.
Publication writes and syncs an exclusive temporary file in the destination directory, then creates the
destination with a no-clobber hard link. A destination published by another writer is left intact.

The deterministic ZIP has exactly four members: `statement.json`, `economics.json`, `authority.json`, and
`manifest.json`. The manifest records the two input hashes and each other member's SHA-256. It states that
this is a partial offline checkpoint, settlement finality and exit readiness are unverified, and hashes grant
no authority. An empty position list or balanced statement does not prove exit readiness.

The checkpoint retains these statement fields and the current assignment versions:

| Content | Source | Cited |
| --- | --- | --- |
| trades (fills) with cash per fill | venue day statement `fills` | `scripts/kalshi_daily_read.py:637`, `scripts/kalshi_daily_read.py:685` |
| fees | statement `fee_cents`, counted once | `scripts/kalshi_daily_read.py:639`, `scripts/kalshi_daily_read.py:664` |
| settlements | statement `settlements` | `scripts/kalshi_daily_read.py:638` |
| cash movements (deposits and withdrawals) | statement `transfers` | `scripts/kalshi_daily_read.py:645-647` |
| opening and closing balances, reconciliation | the economics model | `scripts/kalshi_daily_read.py:629-641` |
| engine versions | current selected-account assignments, with identity and manifest digests | `leafhft/engine_registry.py:425-448` |

The exporter uses the existing account economics model (`scripts/kalshi_daily_read.py:870-904`). Deposits and
withdrawals stay separate from trading P&L, and unexplained cash remains a reconciliation residual. Missing
balances or positions stay unknown. Every declared ledger lane is unavailable and compute cost is null.
Supplied rows outside the UTC day remain in the statement but are excluded and counted by the model.

Statement fields use explicit document and row allowlists. The authority member records the selected account,
its current assignments and version digests, its member's authority and transfer state, its domain's retained
role history, and the source registry generation and digest. It omits labels, unrelated accounts and members,
previous bindings, request and approval references, and arbitrary metadata. No credential or approval document
is read or copied. The registry snapshot is evidence of captured state, not permission to restore authority.
Every retained role-history change point is included. A null role records that the selected domain was absent
at that point, so an earlier role cannot carry forward through an absence.

Deferred work includes multi-day export, historical engine versions and assignment receipts, account-scoped
ledger attribution, settlement-completeness evidence, durable incident checkpoints, unknown-order recovery
without duplicate submission, lost-runner, phone and credential recovery, and account UI integration.
This command does not repair state, release assignments, cancel orders, flatten positions, revoke credentials,
unpair devices, remove projections, delete retained data, or authorize exit. Those steps need separate bounded
implementation and authority.

Delivery goes through a channel the operator chooses for that tenant; the receipt records the archive's sha256
and the delivery time, never a download link.

Rollback: none needed; the export is additive. A wrong export is regenerated at a new path and the receipt
records both hashes. Existing outputs are never overwritten. A failed write removes only its own temporary file.

## 4. Revoke the Kalshi credential

The key belongs to the tenant. The authoritative revocation is the tenant deleting the API key in their own
Kalshi account; Leaf Automation cannot do that for them and asks them to, in writing, with the date recorded in
the receipt.

On the Leaf Automation side there are two rails, and a value crosses neither:

1. **Lane file rail (tenant lanes).** Enrollment decrypts the envelope on the host and writes
   `/etc/leafhft-accounts/<lane>/credential.json` (`leafhft/account_lane_agent.py:1085-1086`,
   `leafhft/account_lane_agent.py:1102`). Root removes it with `shred -u` without reading it. Root then removes
   the lane's entry from the shared fingerprint registry `/var/lib/leafhft-account-agent/fingerprints.json`
   (`leafhft/account_lane_agent.py:1090-1101`), by fingerprint, editing the JSON under the agent lock
   (`leafhft/account_lane_agent.py:1209`). Leaving it would make a later re-enrollment of the same key refuse
   `credential already bound` (`leafhft/account_lane_agent.py:1096-1097`). The lane's `runner-token` and
   `enrollment-private.pem` (`leafhft/account_lane_provision.py:227-240`) are shredded the same way, and the
   dashboard side revokes the token hash it registered (`leafhft/account_lane_provision.py:164`).
2. **Secrets Manager rail (a tenant on the owner's secret path).** The host reads the secret id from a pointer
   file, never the value: `/etc/leafhft/kalshi-secret-id` for the event venue and
   `/etc/leafhft/kalshi-perps-secret-id` for perps (`scripts/populate_runner_secrets.py:386-395`). The
   revocation is
   `aws secretsmanager delete-secret --secret-id "$(cat /etc/leafhft/kalshi-secret-id)" --recovery-window-in-days 30`,
   run as root on the runner under the instance role; the pointer file is then
   removed and `/run/leafhft/kalshi.env` with it. Only the id is read. Nobody runs `get-secret-value` during
   offboarding; that call exists only inside the root unit loader (`scripts/populate_runner_secrets.py:228-231`).

The dashboard's stored credential envelope (the ciphertext it relayed at enrollment) is deleted with the tenancy
rows in step 5. The table name lives in ops-dashboard: UNVERIFIED from this repository.

Rollback: the tenant creates a new key and re-enrolls through the app, which is the only path that writes a
credential (`leafhft/account_lane_agent.py:1082-1107`). The Secrets Manager rail restores within the recovery
window with `aws secretsmanager restore-secret --secret-id <id>`. A shredded file is never restored.

## 5. Unpair the device and edit both allowlists

The app binds a device through `/api/kashbot/bind/challenge` and `/api/kashbot/bind`
(`ios/LeafHFT/Net/DashboardClient.swift:76-83`) and keeps its dashboard token in the Keychain
(`ios/LeafHFT/Net/DashboardClient.swift:44-50`). It already has a runner revoke action
(`ios/LeafHFT/Net/DashboardClient.swift:107-109`).

In order:

1. Ask the tenant to run the in-app revoke, if they still have the phone; that is the clean path. Either way the
   server side below is authoritative.
2. Delete the tenant's rows from the ops-dashboard tenancy tables: the device binding, the lane assignment that
   provisioning discovers, and the stored credential envelope. Discovery must stop listing the lane before step 7,
   because the provisioner recreates a journal and re-prepares any discovered lane that has no local directory
   (`leafhft/account_lane_provision.py:762-777`). Table names: UNVERIFIED from this repository.
3. Remove the device from the mobile allowlist in the ops-dashboard Vercel environment and redeploy.
4. Remove the same device from the mobile allowlist in the AWS task secret and restart the task so it rereads it.
   Both copies are edited in the same window: a device left in either one can still authenticate there.

The variable and secret names for items 3 and 4 live in ops-dashboard and the AWS side, not in leaf-hft:
UNVERIFIED here. Read them from those sources before running this step.

Rollback: re-add the device id to both allowlists, redeploy, and have the tenant bind again through the challenge
flow; the old binding row is not resurrected.

## 6. Edit the beta allowlist

Remove the tenant from the external TestFlight group in App Store Connect. The external group is the one that
holds beta tenants with real-money controls, so a departed tenant left there keeps receiving builds. This is an
App Store Connect action with no code in this repository.

Rollback: re-invite the tester to the same group.

## 7. Stop, disable and mask the lane units

Order matters here, and the trap is real. The provisioner re-enables every lane named in `bindings.json` on every
pass (`leafhft/account_lane_provision.py:814-817`) with `systemctl enable --now` and `check=True`
(`leafhft/account_lane_provision.py:680-686`). A masked unit that still has a binding makes that call fail, and
the failure refuses provisioning for every tenant on the host (`leafhft/account_lane_provision.py:852-856`).

1. Stop `leafhft-account-provision.timer` and `leafhft-account-agent.timer` for the edit window.
2. Remove the lane from `/etc/leafhft-accounts/bindings.json` and delete its journal
   `/etc/leafhft-accounts/<lane>.provision.json` (`leafhft/account_lane_provision.py:168-169`). With step 5 done,
   discovery no longer returns it, so no reassignment refusal fires (`leafhft/account_lane_provision.py:756-760`).
3. Stop, disable and mask `leafhft-account@<lane>.service`, `leafhft-account-sync@<lane>.timer` and
   `leafhft-account-push@<lane>.timer`, and remove the drop-in directories under `/etc/systemd/system`
   (`leafhft/account_lane_agent.py:914-916`), then `systemctl daemon-reload`. The agent's own systemctl wrapper
   refuses `mask` by design (`leafhft/account_lane_agent.py:844-848`), so this is a root action on the host.
4. For a dry-run tenant, remove `/etc/leafhft-tenants/<tenant>/config.env`; the unit is conditioned on it and
   becomes a no-op (`deploy/runner/units/leafhft-tenant@.service:4`), then mask `leafhft-tenant@<tenant>.service`
   and `leafhft-push@<tenant>.service`.
5. Restart both timers. Keep `leafhft-account-agent.timer` running: it serves every other tenant.

Rollback: unmask the units, restore `bindings.json` and the journal from the copies the receipt hashed, restart
the timers. Provisioning then re-enables the lane itself.

## 8. Remove the projection under the root-owned tree

The lane holds a projection of the engine catalog that the provisioner copies in as root, 0444 files in a 0555
directory (`leafhft/account_lane_provision.py:315-341`), plus the lane-owned `engine-bindings.json`,
`engine-account-overrides.json` and `dashboard-account-identity.json` (`leafhft/account_lane_provision.py:343-360`).
The exposure authority keeps its own root tree at `/var/lib/leafhft-exposure` with role files and
`exposure-projection.json`, and reads each lane's ledger from `/var/lib/leafhft-accounts/<lane>/account-risk`
(`leafhft/exposure_authority.py:59-67`).

1. Archive `/var/lib/leafhft-accounts/<lane>` into the retention store (step 9) and record its sha256.
2. Remove the engine catalog projection and the three lane files.
3. Run `python -m leafhft.engine_ops registry audit`; the released account must show no orphan role or ledger
   reference. There is no verb today that removes an account from `/etc/leafhft/engine-registry-accounts.json`
   (`leafhft/engine_ops.py:70`); until one exists the account stays listed with zero assignments, and
   `registry init --provisioned-lane` will refuse it as `unknown_lane` only if it is also removed from the
   accounts file (`leafhft/engine_ops.py:2963-2965`).
4. Remove the lane state, config and runtime directories, the activation files under
   `/var/lib/leafhft-accounts/activations` (`leafhft/account_lane_agent.py:441-443`,
   `leafhft/account_lane_agent.py:503-507`), the live ledger exporter's tree `/var/lib/leafhft-account-live/<lane>`
   (the `StateDirectory` of `deploy/runner/units/leafhft-account-live-ledger@.service:12-14`, holding staged copies
   of the lane's config and ticket ledgers plus `state/ledger.sqlite3`, `leafhft/account_live_ledger.py:196`),
   and the lane user `leafacct-<20 hex>`. Nobody disables `leafhft-account-live-ledger@<lane>.timer` by hand: once
   step 7.2 removed the binding and the journal, the provisioner's next pass disables and stops it itself
   (`leafhft/account_lane_provision.py:739-745`). Confirm `systemctl is-enabled` reads `disabled` before removing
   the exporter's tree, so a running export cannot recreate it. For a dry-run tenant remove
   `/var/lib/leafhft-tenants/<tenant>`, which systemd preserves on stop
   (`deploy/runner/units/leafhft-tenant@.service:15-17`), and the user `leafhft-<tenant>`.

Rollback: restore the directory from the step 9 archive by its hash and recreate the user; the next provision pass
rewrites the catalog projection.

## 9. Neon retention

Neon holds the ops-dashboard side: tenancy rows and the telemetry each lane pushes to
`/api/kashbot/runner/work` (`leafhft/account_lane_provision.py:27-30`, `deploy/runner/tenant-run.sh:83-86`). This
repository has no Neon client, so the table names are UNVERIFIED here.

Proposed policy, for the operator to ratify:

| Kept | How long | Why |
| --- | --- | --- |
| financial rows: fills, fees, settlements, cash movements, balances | 7 years | tax and dispute evidence, the same rows the tenant's export carries |
| engine versions and assignment history | 7 years | explains every trade the financial rows record |
| lane telemetry and activity | 90 days | incident review, then deleted |
| device bindings, tokens, token hashes, credential envelopes | deleted in step 5 | no purpose after the tenant leaves |

The host archive from step 8 follows the financial row: kept, root-only, never committed, then deleted when its
Neon twin expires. A deletion at expiry writes its own receipt.

Rollback: a retention change is forward only; restoring deleted rows is not possible, which is why deletion waits
for the period to lapse.

## 10. Close the offboarding receipt

Write the closing receipt: the list of step receipts and their hashes, the final registry generation, the export
hash, the date the tenant confirmed deleting their Kalshi key, and the retention expiry date. Offboarding is done
only when every step from 1 to 9 has a success receipt.

## Rollback summary

| Step | Rollback |
| --- | --- |
| 1 release | `engine_ops assign` with a fresh approval |
| 2 stop | delete KILL, re-approve through enroll and activate |
| 3 export | regenerate; additive |
| 4 credential | tenant re-enrolls a new key; Secrets Manager restore within the window |
| 5 device and allowlists | re-add to both allowlists, rebind |
| 6 beta allowlist | re-invite |
| 7 units | unmask, restore bindings and journal |
| 8 projection | restore from the archive by hash |
| 9 retention | forward only |
