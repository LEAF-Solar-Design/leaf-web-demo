# Tenant profit pool

Kashbot tenant account lanes can share a profit pool across their books on their
own account. It is off by default. The owner pool and other lanes are separate.

Root sets `/etc/leafhft-accounts/<lane UUID>/profit-pool.json`, owned by root with
mode `0600`, in the existing root-owned lane config directory. The lane user must
not be able to write or replace that file or its parent. Do not add this setting
to `config.json`, which the root agent rewrites during account activation.

The file must contain exactly these fields:

```json
{"schema_version":1,"deposit_cents":12000,"extra_ceiling_cents":500}
```

Use the lane's verified open cash that day for `deposit_cents`. Only profit above
that deposit funds the pool. Set `extra_ceiling_cents` to one base position, the
lane's per-order cap in cents. The numbers above are examples, not defaults.
Both amounts must be integers no greater than `100000000`. Deposit must be
positive; the extra ceiling may be zero. Booleans, strings, floats, unknown keys,
missing fields, and any schema version other than integer `1` refuse the book.

The unit loads this separate root input as the private `profit-pool` systemd
credential. `SetCredential=profit-pool:off` supplies the default when the optional
`LoadCredential` source is absent, so an unset pool does not prevent unit startup.
The agent uses the same private-copy checks as its other credentials. It never
reads the masked `/etc/leafhft` or `/etc/leafhft-accounts` trees from the lane.
The literal credential value `off` disables the pool. Other non-object values,
including JSON `null` and JSON `"off"`, refuse the book. Read or permission errors
are not treated as an absent setting.

The unit picks up a change at its next start. The runner deploy executor restarts
lane units only in its post-install round. Never restart a tenant lane by hand
from the box. After a restart the operator re-arms it with
`kashbot_admin_restore` and `start_live` from the dashboard. A deployment alone
does not prove the unit has picked up this credential; check its start time.

The agent derives `/var/lib/leafhft-accounts/<lane UUID>/kalshi-pool.json` and
passes it in canonical inline JSON via `--params`. It writes no params file.
The JSON contains only `profit_pool` with `deposit_cents`, `extra_ceiling_cents`,
and `path`. Keys are sorted and no spaces are added. The same params enter the
live acknowledgement digest. The CLI rejects duplicate or unsolicited params;
the runtime validator requires the exact derived bytes. Symlinks and junction
ancestors are refused, and the resolved pool path must remain in the lane root.
The unit retains its existing filesystem masks and lane-only write paths.

To revert, root deletes `profit-pool.json`. At the next start the default `off`
credential restores the original arguments with no `profit_pool` block. This
does not erase the lane's pool state or alter another lane. Use the same deploy
and dashboard re-arm procedure; do not restart it by hand.
