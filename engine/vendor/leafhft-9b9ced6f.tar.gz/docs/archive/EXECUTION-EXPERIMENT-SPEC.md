# Kashbot HFT account execution experiment

> Archived 2026-09-24 from the repository root to docs/archive/ (plan abstract-pondering-magpie, Part IV lane 18). Kept as a historical record; the index is docs/archive/README.md.

Parent: Kashbot HFT runs one engine policy for distinct, consenting Kalshi members. Kalshi permits one account per person. This feature must never create or coordinate duplicate accounts, hide activity, or evade venue surveillance.

## Goal

Add a disabled-by-default, auditable experiment layer for new entry orders. It may only reduce an engine's requested size and add a short client-side delay. It never changes price, direction, market, exits, manual or emergency actions, all-in legs, shadow orders, Dark Horse, or recovered orders.

## Frozen design

1. A bounded JSON spec at `EngineConfig.execution_experiment_path` selects eligible engine ids and weighted variants.
2. Each variant has `size_bps_min`, `size_bps_max`, and `delay_ms_max`. Size bounds are 1000 through 10000 bps. Delay is 0 through 5 ms. A variant can never increase size or accelerate an order.
3. The assignment unit is a verified dashboard account id plus engine id. Hash the experiment id, allocation salt, account id, and engine id to select one fixed variant. Do not use a Kalshi API key or subaccount key.
4. Per-order size and delay draws are deterministic hashes of the frozen assignment plus ticker, cluster id, decision wall clock, and requested count. Emit a short cohort digest, never the raw account id, into order telemetry.
5. If the spec is absent, invalid, disabled, the engine is ineligible, no verified account identity exists, or `/var/lib/leafhft/EXPERIMENT_OFF` exists, preserve baseline order behavior.
6. Apply the size draw after any profit-pool addition, then run all current cash and book caps. Existing caps remain authoritative.
7. Delay only entry intents. If the delay would enter the deadline guard, use zero delay and record the reason. Schedule delayed submissions in background tasks so market-data processing does not sleep. Hold the pending decision row until the task submits or aborts.
8. Immediately before a delayed submission, re-check KILL, experiment-off, venue pause, drawdown/cap halt, and the captured account-engine assignment. Abort and write the decision refusal if any check fails.
9. Audit fields in the decision row and ticket reason: experiment id, spec digest, variant, cohort digest, original count, applied count, size bps, intended delay ms, actual delay ms, and deadline/skip reason.
10. The live learning report parses the audit tokens and adds `by_experiment_variant`. Account identity is never a feature. It may be used outside the model only as a cluster/block for analysis.
11. The spec is loaded at startup and hot-read on change. A malformed hot update disables the experiment and reports the error. No live config write is part of this change.

## Core schema

```json
{
  "schema_version": 1,
  "enabled": false,
  "experiment_id": "exp-account-execution-v1",
  "allocation_salt": "64 lowercase hex characters",
  "eligible_engine_ids": ["default"],
  "deadline_guard_ms": 1000,
  "variants": [
    {"id": "control", "weight_bps": 5000, "size_bps_min": 10000, "size_bps_max": 10000, "delay_ms_max": 0},
    {"id": "explore", "weight_bps": 5000, "size_bps_min": 7000, "size_bps_max": 10000, "delay_ms_max": 5}
  ]
}
```

Variant weights must total 10000. Ids use lowercase letters, digits, and hyphens. The entire file is at most 16384 bytes with duplicate-key rejection.

## Acceptance

- Absent, disabled, invalid, or killed experiment returns the baseline count with zero delay.
- Same account-engine pair always receives the same variant.
- Different per-order keys produce deterministic bounded draws.
- Applied count is between 1 and the post-pool requested count.
- Intended delay never exceeds 5 ms and becomes zero inside the deadline guard.
- No raw account id appears in audit output.
- Delayed entry does not block a second coroutine and aborts on KILL or assignment drift.
- The learning report groups settled outcomes by experiment and variant.
- Existing cash and policy book checks remain green.

## Verification

`python -m pytest tests/test_execution_experiment.py tests/test_kalshi_live_learn.py tests/test_cli_kalshi_sizing.py tests/test_account_engine_controls.py tests/test_runner_units.py -q`

## Release boundary

Commit, push, PR, required AWS CodeBuild, and merge are in scope. Production runner deployment and enabling any experiment are separate production promotions and need the operator's fresh approval for the exact merged source and spec.
