# leafhft stage 2: real money, and a system that gets better as it runs

> Archived 2026-09-24 from the repository root to docs/archive/ (plan abstract-pondering-magpie, Part IV lane 18). Kept as a historical record; the index is docs/archive/README.md.

Status: v1, 2026-09-05, after consult round 3 (astra = gpt-6-astra, Kimi = kimi-critic; both full
answers at C:/tmp/askall-leafhft-r3/). Nothing in this file authorizes spending. Every dollar that enters,
including a cloud runner, is a named exception under the operator's standing authority and needs a fresh yes
at the moment it happens (astra A1: infrastructure spend is the FIRST spending decision, not S2C). The
plan's job is to make each yes cheap to give, cheap to withdraw, and impossible to give by accident.

Where the two seats disagreed, the plan takes the more skeptical reading and names the other.

## 0. Frozen facts from stage 1 (REPORT.md, receipts under runs/), corrected by the consult

- No positive net edge measured anywhere. The latest 30-minute Binance.US session (receipt-020651) is
  +0.05 bps at mid but -1.08 bps at liquidation ($99.989); of its 3 fills one is the maker's taker seed
  (astra A1). Its maker markouts vs mid were positive at 1 s and 5 s on two fills, which establishes
  nothing (n = 2). Stage-1 markouts across venues and strategies were negative at every horizon.
- Fees decide the venue: Coinbase 60/120 bps (modeled at the worse published tier; the account page is
  behind login), Kraken 40/80, Binance.US 0 maker and 1 or 2 bps taker (the April blog says 2, the fee
  page says 1; carry 2 until the account's own commission is read). Neither seat could verify any
  maker-rebate venue reachable by a $100 US retail account; the plan does not assume one.
- Flow is the binding constraint on Binance.US: about 1 print per 20 minutes in quiet windows, roughly
  2.4 prints a minute at the daily average. Today's market-making session made 22 maker fills in its
  first 10 minutes; the 30-minute receipt averaged 4 maker fills an hour. Both are real; the variance is
  the point.
- Tenfold in 30 days is 7.98% a day compounded; in 90 days it is 2.59% a day (astra). Required net edge:
  23 bps per round trip over 1,000 trips, 2.3 over 10,000, 0.23 over 100,000. Deposits do not count.
- Feed: the Binance.US WebSocket is blocked from this host; REST polling at 2 Hz (162 ms mean, 7 gaps in
  30 minutes). Coinbase and Kraken WebSockets work from here (4,058 and 531 prints per 20 minutes).
- Odds of $1000 in 30 days per the seats after stage 1: astra 0.001%, Kimi 0.005%. Through the CLI: 0%.
- Ready pieces: fixed-point engine (p99 under 1 ms), evidence-only fill model, latching risk manager with
  250 ms kill and stale polls (heartbeat-driven since today), hash-chained ledger, signals layer, two live
  surfaces, and a signed Binance.US client bound to a one-shot live authorization. The live DRIVER does
  not exist: cmd_live arms the gate and returns 4 (Kimi, cli.py:198-203).
- Execution capacity for stage 2: the gpt-6-astra executor rail is at its usage limit until 2026-09-12
  (fleet notice 12:57Z). Pair records until then run degraded on sonnet-builder with the substitution
  named, and the adversarial reads go to the disclosed fallback critic. Astra remains the consult seat.

## 1. What "really good" means, in numbers

At $100 the plausible edge is cents a day; the platform is good when it measures itself well enough to know
whether to scale. Frozen metrics, computed by the engine, rendered on both surfaces, never hand-edited:

| Metric | Stage-1 value | Target that unlocks the next step |
| --- | --- | --- |
| Net liquidation return per fixed 30-minute block, lower 95% bound, dependence-aware | negative | > 0 on a pre-registered future window, all registered regimes seen |
| Fill-model calibration by cohort (quote distance, side, rest duration) with intervals | unknown (no live) | live fill rate inside the paper model's interval per cohort; headline error under 20% |
| Post-fill markout 5 s vs mid, maker (diagnostic, not the reward) | negative | non-negative on >= 300 fills, reported with intervals |
| Max drawdown on the sleeve | n/a | < 5% rolling 7 days |
| Kill latency: KILL or limit breach to every resting order cancelled ON THE VENUE | 250 ms poll, unexercised | < 2 s measured on a real resting order, 3 times |
| Feed completeness | 7 gaps / 30 min REST | WebSocket; zero UNDETECTED or unreconciled gaps in 24 h (astra: not "never disconnects") |
| Experiment ledger | none | every change has a registered row whose registered_ts precedes its data window |

## 2. The ladder: gates that the next stage cannot skip

S2A Research platform. Money at risk $0; the cloud runner is a spend and needs its own yes first.
- Before hosting: prove the Binance.US WebSocket works from the candidate region (a moved host is not a
  proof, astra). Measure RTT from us-east-1 and us-west-2, pick the lower.
- Record continuous L2 + trades from Binance.US, Coinbase and Kraken for >= 14 days, hash-chained.
- Pre-register BEFORE the evaluation data exists (both seats): the candidate count, the search protocol,
  the evaluation grid, the statistical method (purged and embargoed walk-forward, deflated Sharpe or PBO
  against that frozen budget), the execution assumptions, and the sample-size rationale.
- The separating experiment (astra A3 + Kimi A3): the same frozen quote decisions replayed on contiguous
  future data under three execution conditions (optimistic bounds, conservative queue-and-latency,
  conservative plus actual fees) and on two venues (Binance.US and Coinbase) with equal capital. Report
  gross spread capture, adverse drift, fees, inventory return and liquidation cost separately. Failure
  under optimistic execution rejects the candidate on this sample; success only under optimistic fills
  names execution as the unresolved dependency; Binance.US positive while Coinbase's fees erase it names
  fees. None of it proves no edge exists anywhere.
- Exit gate: one frozen configuration whose net liquidation return has a positive lower 95% bound on the
  held-out weeks, surviving haircut 0/1/2/5 with the blocking cost bound tied to measured execution
  uncertainty, not a universal 5 bps. If nothing passes: "no supported edge among the registered candidates,
  venues and windows tested", $0 of trading exposure spent, stage 2 ends.

S2B Learning paper. Money at risk $0.
- Bounded adaptation over a small grid (section 3), rewarded on liquidation equity per block on WS-recorded
  replay with the queue model, never on live-polled REST (Kimi: a bandit rewarded by the fill model it is
  meant to validate optimizes a simulation of itself).
- Exit gate: one challenger frozen from past data beats the frozen S2A incumbent on the same next 14
  complete UTC days by a pre-set margin at a pre-set alpha, looks weekly not nightly, positive net return
  and positive paired-improvement lower bounds by a pre-registered dependence-aware method. A validated
  frozen strategy may proceed to S2B.5 without adaptation having beaten it (astra).

S2B.5 Live dress rehearsal (new, blocking; Kimi's missing gate, astra's certification step). Money at
risk $0, then the venue's minimum size under its own fresh yes.
- Fault-injected contract tests of the live broker; Binance.US test-order validation; then, separately
  approved, a minimum-size live certification: place a real resting order, cancel it through the venue's
  path with measured latency, force an UNKNOWN state and reconcile it by client id, restart mid-run and
  prove ownership and risk state survive, KILL mid-run. Neither seat could verify that Binance.US offers a
  matching-engine test environment, so this is the only place the plumbing is proven.

S2C Live micro. Money at risk $100, a fresh yes that names the limits.
- Purpose: buy calibration data, not return. Maker-only enforced at the submission boundary, not by
  strategy intent; the maker's taker seed disabled (astra, mm.py:64). One symbol. The existing conservative
  box stays until the operator changes it explicitly (astra, config.py:28): $25 inventory, $10 per order,
  $2 daily loss, 2 open orders, price band, stale-quote cancel. Daily loss is measured against the venue
  account balance at start of day, not per-process marks (Kimi), and persists across restarts. Trade-only
  API key, withdrawals disabled, IP allowlist to the runner. No automatic restart after a kill.
- The stake cap in live_gate.py:31 becomes an operator-signed bound inside the ack sentence; the code is
  never edited to raise it (Kimi).
- Learning target: the fill-probability and time-to-fill models re-fit on live outcomes including censored
  no-fills and cancel races (astra); calibration reported by cohort with intervals.
- Exit gate: >= 300 live maker fills, calibration inside the intervals per cohort, kill path exercised on the
  venue 3 times, zero unknown or unreconciled orders, no risk breach, positive net lower bound after real
  fees. If the flow cannot deliver 300 fills in 6 weeks, that is the finding (Kimi: the fill-count gate,
  not the economics, is the binding constraint at measured flow).

S2D Ramp. Each step is its own fresh yes; evidence at a size qualifies only the next step.
- 100 -> 300 -> 1,000 -> 3,000 after 300 fills at the new size with the lower bound still positive and
  drawdown under 5%. Demotion halts or restricts; it never moves money, replenishes the sleeve or opens
  another session (astra). Adaptation freezes 24 h after any latch.
- Honest expectation (astra's arithmetic): 1 bps net on 50 round trips a day earns $0.05 at $10 a trip and
  $0.50 at $100 a trip; capital does not set turnover. $100 -> $1000 is a capital decision by the operator
  after evidence, never a compounding promise. Strategy earnings and contributions are reported apart, with
  infrastructure cost in the profitability line.

## 3. How it learns, and what keeps each mechanism honest

Ranked by information per dollar of exposure (Kimi A2, astra A2):
1. Execution learning (S2B.5/S2C): the only output that cannot be had for free. Fit fill probability and
   time to fill on live outcomes; keep a calibrated estimate AND separate conservative stress bounds (astra:
   a lower fill probability is not automatically conservative, missed exits raise losses).
2. Offline pre-registered loop (S2A onward): nearly free, and the thing that keeps the rest honest.
3. Bounded adaptation (S2B onward): half theater until rewarded on replay with the queue model or on live
   fills. Frozen spec below.
4. Regime gating: cheap and safe. Unknown regime or invalid feed means NO NEW EXPOSURE, not "fall back to
   the incumbent" unless the incumbent was validated for that regime (astra A7).
5. Self-audit: plumbing, not learning; ledgers and calibration rendered on both surfaces, daily digest on
   the notify rail with a dedupe key.

Frozen bandit spec (astra's, adopted; Kimi's 32-arm grid is the expansion once evidence exists):
- Reward: 10,000 x change in liquidation equity / fixed $100, per non-overlapping 30-minute block, net of
  all modeled fees and execution costs, idle and no-fill blocks included, inventory carried across blocks,
  terminal liquidation charged. Markouts at 5 s and 30 s recorded as diagnostics only.
- Prior: normal per arm, mean -0.1 bps, sd 1 bps (an engineering prior, not knowledge); day-clustered
  updates; observation variance floor 25 bps^2; fills are never counted as independent observations.
- Grid: 8 maker arms, half-spread {0.25, 0.5} bps x skew {0, 2} bps x minimum rest {5, 15} s; order size
  $5 (subject to the venue floor), inventory target $10, seed_frac 0, position cap $25. Frozen incumbent
  and cash as controls.
- Bounds: at most 20% of eligible blocks explore; the arm is a config, never an intent; every intent still
  passes RiskManager.check. The learner cannot touch limits, fees, fill rules, credentials, authorization
  or venue.
- Promotion: one challenger from past data, artifact and schedule frozen, compared with the incumbent on
  the same next 14 complete UTC days; positive net return and positive paired-improvement lower bounds by
  the pre-registered method; extend the window when information is insufficient without changing the
  hypothesis. Demotion: immediate halt on integrity or risk failure; scheduled daily sequential
  deterioration rule reverts to the incumbent or cash.
- Pre-registration row (hash-chained like ledger.py; a result whose registered_ts follows its data
  window is rejected at promote time): experiment_id, created_at, hypothesis, incumbent_digest,
  candidate_digest, code_digest, venue_symbol, fee_snapshot, data_cutoff, train_window, purge_embargo,
  evaluation_window, regime_definition, grid, reward, prior, bounds, allocation_probability, seed,
  fill_model_version, latency_model, primary_metric, dependence_method, multiplicity_rule,
  minimum_information, promotion_rule, demotion_rule, approval_reference_if_live; results appended, never
  overwritten.

## 4. Aggression: what "more happening" can and cannot mean

The operator's ask (2026-09-05): "more aggressive, not enough is happening fast enough". Both seats: more
paper activity is information about execution and accounting, never evidence of more opportunity, and the
simulator's evidence rules are never relaxed to satisfy a fill counter.

What was done today, and what it showed:
- Taker configurations on Binance.US (take-profit 2 and 5 bps) and Coinbase (3 bps) were refused by the
  engine as fee-dead by construction (round-trip costs 8, 6 and 244 bps). The platform declined to burn
  simulated fees for activity. Relaunched with an 8 bps take-profit on the tier-0 schedule; ETH-USD market
  making at the touch added; Coinbase and Kraken WebSocket market making at 0.25 bps half-spread added as
  Kimi's "more expensive thermometer": tens of fills an hour at fees that guarantee a loss, so the operator
  reads the activity as a fee gauge, not as progress.

What comes next (paper only):
- Astra's execution probe as a NEW strategy (not a parameter): Binance.US BTC-USD, alternating $5
  marketable IOC buys and sells, one outstanding order, $10 inventory cap, 350 ms delay, 2 bps fee and
  2 bps slippage per side, one order every 6 to 60 s for 600 to 60 fills an hour as targets, sells only from
  confirmed inventory, loss stop live, early termination reported rather than extended. Cost of activity
  made visible: $0.12 to $1.20 an hour before spread and price.
- Kimi's data aggression: replay sweeps over Coinbase and Kraken WS recordings (the 100x flow) with
  half-spreads 0.1 to 0.5 bps, queue model on, 4 to 8 parallel configurations per recording through
  scripts/sweep.py.
- Only the Binance.US leg can ever justify real money: aggressive QUOTING (rest at the touch, re-quote on
  0.05 bps moves, size at the venue floor) to maximize real maker fills per day, because the S2C gate is a
  fill count. It qualifies only through the unchanged S2B gate. Aggression changes how fast we learn, never
  what we require.

## 5. Real-money controls that do not bend

- API key: trade-only, withdrawals disabled at the venue, IP allowlist to the runner, stored in the secrets
  store, resolved in-process. Rotation on any exposure.
- Engine limits: the existing conservative profile is the S2C box; one named limits profile referenced by
  both the plan and the code so the config digest binds what ships (Kimi).
- Venue-side proof before the first live order: S2B.5 in full.
- Money movement: deposits and every ramp step are operator actions; the platform never moves fiat and
  never re-arms itself after a kill.
- Reporting: every live session leaves a receipt with the fresh-yes reference, the limits in force, the
  calibration report and the list of any unresolved orders; a clean terminal receipt is refused while an
  order is unresolved (astra, binanceus_live.py:115).

## 6. Defects before any real order (union of both seats' lists; file:line as given)

- cli.py:194 consumes the one-shot authorization before reporting the driver is unavailable; run every
  non-mutating readiness check first.
- cli.py:198-203 the live driver does not exist; build it mirroring cmd_paper's wiring with the live broker
  and a replay-tested integration test.
- engine.py:216 assumes a synchronous broker; add durable pending orders, asynchronous execution-report
  ingestion (open orders + myTrades polling at <= 1 s or the user stream), and authoritative portfolio
  reconciliation before any submission after a restart.
- (missing) nothing seeds engine state from the venue; call account() at start, refuse on mismatch beyond
  dust, measure daily loss as the account delta.
- binanceus_live.py:130 and :128-131 non-200 responses collapse into RuntimeError; parse {code, msg}
  structurally; treat 5xx and malformed 200s as UNKNOWN until reconciled (Binance.US documents that 5xx may
  mean the order executed).
- binanceus_live.py:103 ownership and unresolved states live in memory only; persist intent before
  transmission, reconcile before restart can submit.
- binanceus_live.py:137 unresolved-state check and placement are not serialized.
- binanceus_live.py:174 cancel error -2011 becomes GONE without settling fills; query order and trade
  history first.
- binanceus_live.py:115 shutdown discards failed cancellations; persist and surface them, refuse a clean
  receipt.
- binanceus_live.py:55 hard-coded precision; load tick, step, minimum notional and trading status from
  exchangeInfo at arm time and validate the final order.
- live_gate.py:59-65 the boundary enforces only per-order notional; add maker-only, aggregate
  reservations, buy-side spend, portfolio limits and a cumulative order budget (defense in depth).
- live_gate.py:31 the $100 stake cap must be the operator-signed bound in the ack digest.
- mm.py:64 the maker seeds with a 50%-equity taker order; disable, acquire inventory post-only.
- risk.py:59 kill state and daily start equity reset on process construction; persist the risk epoch.
- engine.py:241/259 risk marks at mid and cancellation leaves inventory exposed; add executable-value
  accounting and an explicitly pre-approved residual-position response.
- (missing) the pre-registered experiment ledger; implement as a second hash-chained ledger on ledger.py's
  envelope.
- (missing) a 24/7 runner with a working WebSocket is a hard prerequisite of S2C, not an infra nicety.

## 7. Infra

- One small cloud runner near the venue (region by measured RTT and a proven WebSocket), supervisor for
  recorder + engine + pusher, disk for recordings, nightly backup of ledgers and recordings, the dashboard
  as the read surface, the notify rail for alerts. Estimate under $40 a month; it is a spend and gets its
  own yes. The local host keeps research and the local UI.

## 8. Budget and odds

Operator approval 2026-09-05: $500 total project budget (BUDGET.md is the ledger against it; the deposit to an
exchange keeps its own yes). The cloud runner is therefore authorized once the WebSocket proof passes.


| Item | Money at risk | Wall clock |
| --- | --- | --- |
| S2A research | $0 trading; runner ~$40/mo (fresh yes) | 2 to 3 weeks after 14 days of data |
| S2B learning paper | $0 | overlaps S2A, +1 week |
| S2B.5 dress rehearsal | $0, then venue minimum size (fresh yes) | 1 week |
| S2C live micro | $100 sleeve, existing $2 daily stop | 3 to 6 weeks, flow-bound |
| S2D ramp | 300 -> 3,000 by steps, each a fresh yes | evidence-bound |

Odds as planning judgments, not calibrated forecasts (both seats said so):

| Gate | astra | Kimi |
| --- | --- | --- |
| S2A positive-edge exit | 5 to 20% | 15 to 25% |
| S2B adaptive beats frozen (conditional) | 10 to 30% | 40 to 60% |
| S2C full exit (conditional on entry) | 10 to 30% | 20 to 30% |
| S2D one step (conditional) | 20 to 50% | about 30% |
| $100 -> $1000 by trading within 90 days of S2C | under 0.1% | under 0.5% (5 to 10% only as an operator capital decision) |

The single assumption that moves everything: whether Binance.US BTC-USD flow during S2C looks like the
quiet window (1 print per 20 minutes) or the daily average (2.4 a minute). Every measurement so far says
the edge is at or below zero; the plan is built so that finding costs $0 and is reported as such.

## 8b. First S2A-style readout (2026-09-05, 20-minute samples, items 3 and 4 landed)

`scripts/decompose.py` (pair record s2-decompose, astra) replayed the frozen maker (half-spread 0.1, 0.25,
0.5 bps, seed off) on the three 2026-09-04 venue recordings and today's 60-minute Coinbase session under
optimistic (touch fills, 0 latency, 0 fees), conservative (queue, 350 ms, 2 bps haircut, 0 fees) and
conservative-with-fees execution. Readout, every venue: "rejected under optimistic execution on this sample".
Coinbase optimistic: 430 zero-fee fills, +2.4 bps gross spread capture, 5 s drift -0.08 bps, yet equity
-10.7 bps and net liquidation -11.7 bps; Kraken 34 fills, -8.6 bps; Binance.US 1 fill. The loss is inventory
drift over the holding period, not fees and not the fill model: the maker gets filled on the side the market
is leaving. Report: reports/decompose-20260905T1509Z.md. These are 20-minute samples; S2A's 14-day recording
is what turns this into a decision. Calibration (`leafhft/calibration.py`, record s2-calibration) is computed
for all 16 finished runs; its distance cohorts are empty until order rows carry the mid at placement, which
slice C adds.

## 8c. Aggression session results and a defect they surfaced (2026-09-05, 09:27 to 10:34 CT)

Six paper sessions ran at once. The two taker configurations that cleared the cost gate did little: BTC
momentum on the tier-0 schedule at an 8 bps take-profit made 8 fills on 6 orders in its hour; ETH
mean-reversion 6 fills on 86 orders. Market making at the touch: BTC 25 fills on 182 orders, +1.1 bps at mid
and -1.2 bps at liquidation against buy-and-hold +7.5 bps; ETH 5 fills on 501 orders. The thermometers did
what Kimi said they would: Coinbase market making made 1 fill on 236 orders and paid $0.60 in fees (-61 bps
at mid, -122 bps at liquidation); Kraken 1 fill on 93 orders, $0.40 in fees (-41 bps). The execution probe
(item 2, live at 10:20 CT) fills every order at one every 6 s, 526 fills an hour, and cost $0.10 in its
first six minutes, which is the price of activity astra estimated ($0.12 to $1.20 an hour).

Defect: three of the six sessions (BTC, Coinbase and Kraken market making) did not reach their deadline;
each died with "LedgerFailed: head sidecar write failed: PermissionError". The ledger renames its truncation
checkpoint into place on every flush, and on Windows a rename fails when any other process holds the target
open for that instant (a reader, Defender scanning the fresh file). The fail-closed latch is right; turning a
transient sharing violation into a dead session is not. Fix: bounded retry with backoff in the sidecar write
(pair record s2-ledger-sidecar-retry). A live session would have been killed by the same fault, which is
exactly why S2B.5 exists.

## 8d. Runner region and the WebSocket proof (2026-09-05 12:20 CT)

Two throwaway EC2 probes (Ubuntu 24.04, t3.micro, identity-gated under the leaf-admin SSO role, self-stopping,
terminated afterwards, cost cents) launched fine in us-east-1 (production VPC private subnet) and us-west-2
(default VPC) but their serial console logs came back empty, so no numbers. Read-only checks show the
us-east-1 private subnet routes 0.0.0.0/0 through an available NAT gateway and the existing github-runner in
that subnet is SSM-managed and Online, so egress and SSM both work there. Region decision: us-east-1, the only
region with the Leaf VPC (a second region would need a whole VPC, out of the $40/mo line). The WebSocket proof
moves onto the runner itself: after the Terraform apply, `scripts/probe_venue_ws.py` runs on the instance via
SSM Run Command and its JSON is recorded here before the 14-day recording starts. Meanwhile the local host
proved the leafhft WebSocket transport works today (60 s, 76 messages, 0 REST polls), so the earlier "blocked"
finding was transient; the runner buys uptime and latency (local REST p50 452 ms), not access.

## 8e. The runner is live (2026-09-05 14:05 CT)

Operator approved a $500 total project budget at 11:5x CT; the first spend is the cloud runner (about $40 a month,
BUDGET.md). Terraform root `terraform/environments/shared/leafhft-runner` in leaf-automation-aws-terraform (PRs
#1476 root, #1477 multi-platform lock, #1478 endpoint admission and secret shells; applies 33983570429 and
33985793406, 11 resources, all create-only). EC2 i-041d199cb2da5d73d, Ubuntu 24.04 t3.small, production VPC
us-east-1a private subnet, egress 443 and 9443 only, SSM only, IMDSv2, encrypted root; a read-only deploy key
for the private repo LEAF-Solar-Design/leaf-hft over ssh.github.com:443; two Secrets Manager shells populated by
file. Three lessons cost about an hour and are in memory: a Windows-generated lock file fails Linux CI's readonly
init; Terraform must not manage secret versions because the read-only plan role cannot read values; the VPC's
Secrets Manager interface endpoint is an allowlist and every new workload needs its own standalone ingress rule.

Recording started 14:02 CT: leafhft-record@binanceus, @coinbase, @kraken active (24-hour files, restart on end),
pusher and signals timers active. The WebSocket proof from the runner itself: connect 508.2 ms,
4 book updates in 60 s (msgs_per_s 0.07, max gap 47.5 s, the venue's
own quiet rate at 14:04 CT), REST /time p50 456.9 ms, p90 470.3 ms, min 159.2 ms over
30 calls. The local host measured p50 452 ms at 12:00 CT. Conclusion: no latency edge from us-east-1
against Binance.US; the runner buys uptime and 14 continuous days, not speed. S2A's exit gate is unchanged.

## 8f. Runner recording, first hour (2026-09-05, 14:23 CT)

The first recorders died on quiet venues: Binance.US delivered nothing for 60 s five times in five minutes
(the venue's bookTicker is bursty, 9 quotes in one 45 s window and 68 in a 12 s window measured from the
runner) and the record command's consumer-side idle timeout of 60 s raised, so five fragments and no summary.
Fix on main 6fd1a8e (pair record s2-record-resilience, gpt-6-astra, 428 tests): Feed.reconnect() keeps queued
events, `record --idle-s` (default 900 s, 30 to 86400) counts the quiet period and reconnects up to
`--max-reconnects` (default 96) inside the same run, and record-summary.json lands on every exit path with a
stop_reason. Deployed over SSM at 14:23 CT (code b395525 to 6fd1a8e, three recorders restarted); at 14:42 CT all
three were on one run each: Coinbase 2500 rows in 3 min, Kraken 70 KB, Binance.US 79 KB after its first 500-row
flush. Receipts: C:/tmp/leafhft-tf-runner-receipts/deploy-20260905T1923Z.log and the venue-diag, ssm-*.log files.

Refuted on the way (kept so nobody re-chases them): the raw two-stream Binance.US WebSocket URL works from the
runner (68 messages in 12 s; the combined /stream form returned nothing), the feed class run standalone as the
service user emits within a second with zero malformed, and REST time endpoints for all three venues answer 200.
The zero-byte files were the recorder's 500-row write buffer on a sparse venue, not a dead feed.

One residual closed the same afternoon on the operator's "do it": leaf-automation-aws-terraform PR #1481 (1411c87c,
haiku-medium PASS, merge queue) sets `start_paper_maker` true and runs leafhft-paper.service over REST (the engine's
2 s stale guard and 60 s idle timeout cannot live on Binance.US's bursty WebSocket). The apply replaced the instance:
i-041d199cb2da5d73d terminated, i-0aea5f579a4d9622a up at 15:27 CT on main 1eb00c9 with all six units active, the
three recorders and the paper run restarted 15:29 CT, so the 14-day window now ends 2026-09-19 15:29 CT. A manual
replacement apply needs create_only=false, expected_resource_actions `aws_instance.runner=delete,create` and the
acknowledgement `destroy:807034087062:leafhft-runner-shared`, or the plan-safety step refuses the destroy. The Binance.US watchdog (heartbeat 20 s) reconnects on every quiet gap longer than 20 s, which is cheap
but noisy; raising the WebSocket heartbeat for that venue or keying it on ping/pong is a one-line follow-up.

## 8g. S2A frozen and registered; runner units in the repo; four paper books (2026-09-05, 15:30 to 17:20 CT)

Consult round 4 (consults/round4-*.txt) refused to register the draft until the analysis was executable and covered
by the same code digest: astra "do not register", kimi "register with these edits". Both sets of edits are in
experiments/PREREG-S2A.md: order_frac 0.05 (the code default 0.25 requested $25 quotes the conservative box
rejects, so the draft described a strategy the code could not run), decompose.py moved to RiskLimits.conservative(),
the bootstrap named exactly (circular whole-UTC-day blocks, 10,000 resamples, seed 20260905, identical indices,
inverted-CDF quantile), the optimistic screen on the point estimate, coverage-only extension, regimes descriptive,
fees isolated by paired re-accounting of the same fills at Coinbase's schedule instead of a second venue, MDE 1.2
bps per block declared with ICC 0.2. scripts/s2a_bounds.py (record s2a-bounds, astra, 462 then 466 tests) carries
replay, bounds and register; smoke on the local recording: about 1250 events/s per cell (the 14-day readout runs in
a process pool; budget four hours).

Registered 2026-09-05 22:01:32Z, code digest 42edf5f, ledger experiments/s2a.sqlite head
ee5d031b5aec5f23aacc8e2facee4e2e9167e8cdc5890ebc3dd3aeb70e13286a, rows in experiments/s2a/rows:
exp-db8a94e09bfb (0.25 bps), exp-1ee506cfdf5c (0.5), exp-bf2a0975fcad (1.0), exp-85b01ea07bab (2.0). Evaluation
window 2026-09-06 00:00Z to 2026-09-19 00:00Z, 13 complete UTC days; nothing recorded before it is inspected. The
decision runs once at the close with `python scripts/s2a_bounds.py bounds` on the runner's Binance.US recording.

Runner: units moved into deploy/runner (record runner-units, astra, main f6b3df8): record@ and paper@ templates,
enabled.txt, idempotent root install-units.sh, paper-run.sh with the S2A frozen parameters; one REST maker (0.25)
and three WebSocket makers (0.5, 1.0, 2.0 with `paper --stale-ms 120000`, because one REST poller already uses
about 840 of the 1200/min weight budget). Installed on i-0aea5f579a4d9622a at 16:55 CT without touching the
recorders; the hand-added paper unit retired itself. Terraform PR #1483 makes the bootstrap install from the repo
(one more replacement; critic RED on a dead variable, fixed as 1fcf152). Defect found on the way: four units
starting in one second shared a run directory (two engines, one ledger); quarantined on the box, fixed as
run-dir-unique (astra, main 1ebfda5). Binance.US heartbeat 20 s to 120 s landed earlier (50b42a0).

## 8h. S2C readout 1: hold; the venue's 19-month USD suspension; round 6 (2026-09-05 19:00 to 20:40 CT)

Built and landed tonight, each a pair record: scripts/klines_fetch.py (Binance.US 4h and 1m history since
2019-09-17 to local CSV, paced, resumable, manifest-hashed; three corrections for the venue's short genesis and
maintenance candles, which are kept and listed as irregular), scripts/conviction_backtest.py with the committed
research manifest (astra; a stripped-def correction by the planner after the sandbox defect blocked the executor;
manifest --check reworked so the freezing commit need not know its own sha; short candles accepted; the 4h history
split into contiguous segments at gaps with per-segment indicator warm-up). Data on disk (gitignored): 4h 11,749
rows, 1m 2,817,760 rows, 2019-09-17 to 2026-09-06. The harness scans 2.83 M rows in 37 s.

Readout 1 (reports/s2c, code a263350, manifest dbdfec85, data sha256 in episodes-summary.json): the frozen family
fired 45 times in seven years, 0.45 test trades a month against the round-5 planning assumption of 2 to 8; 19 valid
test episodes; p 0.325 with lower bound 0.167; payoff 2.07 with lower bound 0.68; break-even hit rate after costs
0.596; mean net -4.7 bps at 8 bps round trip, -10.7 at 14; lag-1 autocorrelation 0.15; every fold 0 to 8
calibration episodes against the 100 floor. Decision under the frozen rules: hold. The sizing law bets $0 at every
bankroll, which is the loop refusing to size a signal that has not earned it.

Coverage, settled: astra's 15,274 scheduled 4h slots against 11,749 bars is one gap, 2023-07-14 00:00Z to
2025-02-19 12:00Z in both series, Binance.US's suspension of USD trading after the June 2023 SEC action until USD
pairs returned in early 2025. The fetcher recorded it; nothing was lost. The history is two regimes: 46 months to
mid-2023 and 19 months of a thinner post-return market, which is the market the paper books quote today (the bursty
bookTicker in 8f). Folds 5 and 6 of the walk-forward fall inside the suspension and carry 0 episodes.

Round 6 (consults/round6-astra.txt, round6-kimi.txt): astra EXTEND (coverage audit and harness corrections first,
0 new families, $0 allocation), kimi NEXT FAMILY (F2 on 1h bars with K counted). Both name the same defects: the
sizing table's 0E+27, a fabricated p 0.5 on empty folds, hardcoded quantiles, provenance overwritten by the
reporting commit, effective versus calendar test months, an unasserted purge, run-on hold reasons. Resolution in
order: (1) record s2c-harness-r6 lands the corrections plus the multiplicity plumbing (family_index,
parent_manifest_sha256, K_running, quantile alpha/K) and declares the suspension as an exclusion window; (2) F2 as
kimi specified it, registered before any run past the development cutoff: long-only spot on 1h bars built
deterministically from the 1m file, signal close above the 24-bar high AND ATR(14) <= 0.9 x ATR(168), no volume
or SMA filter, entry next open, trail highest completed close minus 2 x ATR(14) at 1m resolution with
gap-through at min(stop, open), 72 h time stop, 72 h cooldown, one position, 8/14 bps, same folds, embargo,
bootstrap and seed, K_running 2 (quantile 0.025), minimum calibration per fold lowered to 60 with the reason
recorded (cooldown-bounded 1h signal frequency), minimum test episodes 200; expected 5 to 8 trades a month on
kimi's basis (0.4% of 4h bars fired with four conditions; two conditions on 70,000 1h bars, cooldown-capped).
What would make it snooping, fixed now: choosing any F2 parameter from family 1's per-episode outcomes; only the
aggregate firing rate and the fold floors were used. If F2 holds with floors met and no edge, that is the
evidence-based stop for directional research on this venue.

Visible learning, both seats: the four paper books' fill calibration (Wilson intervals per distance bucket, already
pushed) is the operator-facing learning signal for the next two weeks, independent of the directional question
and feeding S2B. Kimi's numbers: near-touch buckets converge in week 1, tight enough (half-width under 0.10 at
n 100) to refit the paper fill model honestly in week 2; astra's caution: requotes share market events, so daily
variation is reported and 1,000 correlated orders are never presented as 1,000 trials. An evidence panel on the
dashboard (intervals narrowing over time, the S2A countdown, the S2C readout) is the next surface to build.

## 8i. S2C readout 2: family 2 holds; directional research on this venue stops on evidence (2026-09-05 21:20 CT)

Family 2 (record s2c-family2, astra; kimi's round-6 specification adopted verbatim; manifest 1b52094d, parent 29131934,
K_running 2, quantile 0.025; 1h bars built deterministically from the 1m file; breakout above the 24-bar high under
ATR(14) <= 0.9 x ATR(168); trail 2 x ATR(14); 72 h stop and cooldown; 8/14 bps; calibration floor pre-lowered to 60
with the reason recorded). Readout (reports/s2c-f2, code 02deb62): 249 firings in seven years, 1.86 test trades a
month against kimi's 5 to 8; 78 valid test episodes over 23 effective months; hit probability 0.2975 with lower
bound 0.199; payoff 2.11 with lower bound 1.10; break-even hit rate after costs 0.475, promotion threshold 0.525;
mean net -6.0 bps at 8 bps round trip, -12.0 at 14; every fold below the 60-calibration floor; lag-1 -0.19.
Decision under the frozen rules: hold. The hit rate sits below break-even with the sample to say so, which is
worse than a shortfall of data.

Both seats fixed the consequence before the run (8h): a second hold with no edge is the evidence-based stop for
directional research on this venue. K = 2 is spent and stays spent; a third family here would be a search. The
S2C deliverable stands as specified: a validated-or-refuted conviction instrument (refuted, twice, pre-registered),
and a sizing law over settled profits that correctly bets $0 with no measured edge. The compounding loop is built
and refuses to bet; that refusal is the product.

What the loop learns from here, in order: (1) the S2A decision on 2026-09-19 (four registered maker candidates,
one replay); (2) the four paper books' fill calibration, the visible learning signal for the next two weeks (Wilson
intervals per distance bucket tightening; near-touch buckets converge in week 1), feeding S2B's paper fill model;
(3) S2B's challenger, including the operator's confidence-scaled sizing, against whatever S2A promotes. A different
venue or instrument class for the conviction leg would be a new hypothesis space with its own registration; nothing
in this venue's seven years supports one now, and the post-2025 Binance.US USD market is the thin one.

Housekeeping landed tonight: run directories are collision-proof (1ebfda5), the Binance.US watchdog stopped churning
(50b42a0), the pusher reads /run/leafhft/ingest.env (344db98), the third runner instance i-0fd5604126e28b196
bootstraps its units from the repo (Terraform #1483), four paper books push every five minutes; leaf-hft main 529
tests. Eleven pair records today executed on gpt-6-astra; the fallbacks (sonnet-builder for the Terraform units
change and the first kline fetcher attempt, planner edits for the plan sections, the stripped-def repair, the push
path, the receipts) are named in their receipts.

## 8j. Live dress rehearsal: from the operator's yes to a running book on Binance.US (2026-09-06, 00:15 to 10:15 CT)

Operator, 00:15 CT: "quit with the paper trading, lets do real trading with like $1 ... that way we learn real lessons
and dont have to relearn once we finally switch over." The venue's floor set the stake: BTCUSD minimum lot 0.00001 BTC
(about $0.80), minimum notional $1, so the smallest legal order is two lots (about $1.60) and the stake is $5.00.
The account was created by the operator that morning, funded $9.60 by card, and given a trade-only key locked to
the runner's egress IP 34.203.65.145 (he later enabled API withdrawals too, by his own choice; the book never
withdraws). The key value crossed no terminal: a masked prompt wrote it to a private file, the file went into a
Secrets Manager shell by file handle and was deleted, and a root oneshot on the runner loads it into a 0600
runtime file the live unit reads.

What the build added (records live-rehearsal-3, live-error-message, live-public-exchangeinfo, live-soft-2010,
live-adopt-inventory; two on the sonnet fallback while every codex refresh token had expired fleet-wide, disclosed in
their receipts): LIVE_DRIVER_AVAILABLE on with every other gate intact (LEAFHFT_LIVE=1, the hand-written
authorization sentence naming the config digest, both credential variables, the s2c limits, the $100 ceiling);
`live --stake-usd` and `--ack-dir`; maker sizing that clears the venue floor at micro stakes; a probe order 50 bps
off the touch, cancelled, as the first act of every run; the live units and launcher in deploy/runner; the paper
books off. The gate consumes one authorization per armed run (it renames the ack file with a nonce), so every
restart is a human decision; today's runs consumed seven.

Lessons the venue taught, each fixed on main the same hour:
1. The first armed run was refused before any order: HTTP 400 code -1104, "read 1 parameter but was sent 4". Our
   exchange-info (filters) request was signed; it is a public endpoint that takes only the symbol (0c5bac3).
2. The run recorded only "VenueError" and hid the reason; now the receipt carries the venue's http status, code
   and message, and an account line prints canTrade, permissions and the USD and BTC balances before the driver
   starts (7ee6d13).
3. The first session with money placed a post-only probe bid at $79,304.40 (accepted, cancelled), quoted, and filled a
   resting bid for 0.00002 BTC at $79,755.77, fee zero, the first real trade (run 20260906-144107, 14:41Z). It then
   died on a single -2010 "insufficient balance" when a replacement bid went out before the cancelled bid's dollars
   were released. A -2010 on place is now a soft reject: resync balances, skip the side for one cycle, abort only
   after three in a row or on any other refusal (5df0805).
4. The next start was refused by our own gate: "existing base inventory requires explicit permission", because the
   account now held the lot we had bought and the CLI never exposed LiveBroker's permission. `live --adopt-inventory`
   exposes it, prints and records the adopted amount, and the launcher carries it under the operator's directive to
   keep the book running over its own fills (5dee892).
5. The first continuous session ended itself after six minutes: "buy turnover exceeds 20x authorized stake" after 83
   placements and one fill. The per-authorization budget charged every placement as turnover, but a maker that requotes
   every four seconds places about $2 of bids per requote and fills almost none of them, so a $100 turnover budget
   held about six minutes of quoting. The budget now charges executed notional (placements reserve, cancels release,
   resting reservations still count against the cap), the placement cap is 20,000 per authorization with a churn
   halt at 2,000 placements and zero fills, and adopted inventory enters start equity so pnl_usd measures only the run
   (the earlier receipt had shown +1.59 for a run that did nothing but own the lot it started with) (458a431).
6. The first long session ended after two hours at 17:22Z, right after its second fill: the per-run order journal
   reached its 4 MiB cap and the gate refused the next order. The cap was sized for a short session and the sync
   loop journaled every venue reply, changed or not: 11,897 ACKED rows for 1,255 orders. Two more caps would have
   ended a 24-hour run near hour 16 (10,000 owned orders in memory; a broker sync that walked every order ever
   placed on every call). Now only changes are journaled, the journal rotates at 3 MiB with a crash-safe compaction
   snapshot of the open orders (rotated files kept for audit, 256 rotations max, the limit checked before any file
   operation), finished orders leave memory, and the broker syncs only live orders (4739f18). The installer's dry
   run, the refused-start cleanup and this fix each came from watching the real box, not from a test.
7. A cancel that discovers a fill. Run 20260906-200049 (two hours on the journal fix, seven maker fills, +$0.008)
   halted at 21:21Z: the venue filled a bid while our cancel was in flight, the client settled it as FILLED from
   myTrades, and the broker's sync saw an execution it had not booked and took the fail-closed branch. The cancel
   path now pulls myTrades and books the fill before syncing, and a filled order needs no cancel acknowledgement;
   the unaccounted-execution halt stays as the backstop (d003d3f).
8. Starting below the stake. That run netted a buy, so the re-arm found $2.41 free USD against the $5 stake floor.
   The stake is a ceiling on exposure, not a floor on cash: with inventory adopted the book now starts on its actual
   free cash (floor: the venue's $1 minimum order), and a buy or sell beyond a free balance is a local rejected order
   for one cycle instead of a fatal gate closure (1849eb3).
9. The phantom drawdown. The first start on that code died at its first mark, "drawdown 2125 bps", because start
   equity was the stake plus inventory while the marks used the real cash. Start equity is now min(start cash,
   stake) plus adopted inventory, the same basis the marks use; the CLI clamps trading cash to the stake, so only a
   shortfall shifts it (bf5a80a).
Smaller ones: a checkout on the runner dropped the launcher's executable bit (systemd status 203; the bit is now stored
in git, cbb549d); the installer's retire loop misses template instances (task 23); a refused start still creates an
empty run directory every 30 seconds (cosmetic, queued).

State at 17:30 CT: leafhft-live@binanceus-mm active on main bf5a80a, run 20260906-222515-live-binanceus-mm, started
on $2.41 cash with 0.00009 BTC adopted (equity $9.59 at the first mark, P&L zero there), two maker sells in its first
minute. Twelve authorizations were consumed today; every record ran on the sonnet fallback with astra down. Nine
venue lessons in one day, each found by the real box and fixed on main within the hour, is the point of the $5
rehearsal: the switch to real size when an edge is proven is a stake change and a fresh authorization, not a
rebuild. The dashboard's /leafhft page was reworked the same evening (ops-dashboard #372): the hero axis fits the
data, a latency card, bounded client state, live-aware copy.

## 8k. Round 9: "bigger returns exponentially faster", the mandate, and its revision (2026-09-06, 17:40 to 19:30 CT)

Operator: "work with astra on developing a fast-paced improvement plan for generating bigger returns exponentially
faster." Both seats (consults: gpt-6-astra at C:/tmp/askall-r9/out-codex-astra.txt, kimi critic beside it) refuted
the premise the same way: at $5 to $500, spot only, the daily result is filled notional times net edge per filled
dollar; a stable 0.1% a day compounds to 1.4% in 14 days; nothing measured yet says the edge is above zero. Astra's
sensitivity, not a forecast: 96 fills a day at $1.60 to $3.20 and an assumed 0.25 to 1 bp net edge is $0.004 to
$0.031 a day; a negative edge loses at the same scale. The levers that move the rate by multiples are capital,
fills per day and edge per fill; compounding cadence is noise. Two facts the seats surfaced and the code confirmed:
the maker is bid-only whenever inventory falls under two lots (mm.py zeroes the ask below the $1 minimum), which
halves fills and biases every markout sample; and quote size and inventory target are fractions of marked equity, so
a deposit would silently rescale the strategy against an unchanged $10 order cap. Astra's funding test (an
anytime-valid supermartingale: per-block liquidation return capped at 1%, product at or above 100, 12 operating days,
150 fills, positive net liquidation P&L, drift attributed separately) is the scoreboard; the critic's hourly-blocked
bootstrap bound prints beside it as a diagnostic.

Asked which gate should govern deposits and whether to buy BTC drift on purpose, the operator answered "as much
budget as you need" and "we dont care about this money, move as riskily as you want" (18:20 CT); the plan became the
aggressive track (C:/Users/ehaug/.claude/plans/vivid-seeking-stream.md): a $500 deposit, an allocation ramp, a risk
profile scaled to the stake, a declared 70% BTC core, paired mm-versus-anchor blocks on real money. At 19:30 CT he
revised it: "just leave the amount i have in there, once you've proven success i'll add more." So the capital
lines are parked and proof is the scoreboard on live fills at the current size, positive on execution rather than
drift. Records opened tonight (all waiting on the fleet's executor cap at 19:20 CT): live-two-sided (re-seed two
lots below two lots), live-aggressive-profile (RiskLimits.aggressive scaled to the stake, $500 ceiling, stake and
profile read from /etc/leafhft files; lands as code, the runner stays on s2c), fill-tape (per-fill markouts at 10,
30, 120 s from the ledger marks, resting age and cancels from the journal, execution vs drift attribution; reads
nothing embargoed) and live-postonly-cross (lesson 10: Binance's -2010 also means "would immediately match" for a
post-only order; three fast-market crosses in a row hit the balance abort and ended the 26-fill run at 23:19Z).
Next: the scoreboard script, the paired blocks, the stake raised to the cash already in the account ($9 under the
s2c box), and uptime. The runner's Binance.US recording stays untouched until 2026-09-19 00:00Z.

Goal ceiling (2026-09-06 19:45 CT). Operator: "/goal continue working until you can drive 1% increase every 10min
interval, or determine we need a significant change to reach these goals." Determination, from the Binance.US 1-minute
history since the USD relisting (81,085 non-overlapping 10-minute windows over 563 days) and today's live fills:
the absolute 10-minute BTC move averages 11.7 bps (median 5.2, p90 31, p99 79); only 0.46% of windows move 1% at all.
A long-only spot trader with PERFECT foresight of every 10-minute move, paying the 4 bp taker round trip, averages
4.8 bps per interval (0.048%), twenty-one times short of 1%. The maker at this account (2.2 fills per 10 minutes on
the 26-fill run, $3.20 quotes on $9.60, 0.5 to 2 bp capture) earns 0.004% to 0.014% per interval, 70 to 280 times
short. One percent per 10 minutes compounds to 319% a day; the venue offers this account no leverage, and leverage
against a p99 tail of 79 bps would be liquidated inside a week. Verdict: the goal is unreachable by two orders of
magnitude with any instrument this account can hold, and by one order of magnitude even with perfect foresight; it
needs a significant change of target, not of code. The reachable unit is basis points per day of execution P&L on
the scoreboard (astra's anytime-valid test), with capital added on proof; the plan above pursues that.

## S2C. The compounding loop (operator's goal, 2026-09-05 17:05 CT), designed with both seats in round 5

Operator's words: "steadily work toward some modest profits, then leverage those profits on a very large position
we're somewhat confident in and has a huge potential upside, and continue that in a loop." Round 5 (consults/
round5-astra.txt, round5-kimi.txt) agreed on the shape and refuted two parts of the framing; the plan keeps the
refutations.

Grind mode is the S2A incumbent, or cash if nothing promotes; cash is a reported result, not a failure. What
"modest profits" can mean on $100 at maker fee zero, stated without decoration: at the measured flow (about 4
maker fills an hour, $5 quotes) a validated +1 bp net per round trip earns $0.02 to $0.05 a day. The grind's
product is the incumbent's evidence and a sleeve that ends each week above $100, not income; the runner's roughly
$40 a month dwarfs it.

Conviction mode is one frozen family, no parameter search (K = 1): long-only volatility-compression breakout on
completed 4h Binance.US BTC/USD candles (ATR20/ATR120 <= 0.75, close above the 20-bar high, volume >= 1.5x the
20-bar median, close above SMA200), taker entry at the next open, stop 2x ATR20 trailed on completed closes, 72 h
time stop, one position, 72 h flat after any exit, exits resolved on 1m candles, 8 bps round trip modeled (14 bps
stress). Validated walk-forward on public kline history since 2019 (not the S2A recording): folds of 24 months
development, 12 calibration, 6 test, advancing 6, purge and 72 h embargo; probability p = (w + 0.5) / (n + 1) with
a 7-day block-bootstrap lower bound p_L, payoff ratio b with b_L; needs >= 200 valid test episodes over >= 24
months and 100 calibration episodes per fold, else hold. Planning assumption, unverified: 2 to 8 eligible
episodes a month, which is why the history has to be years long. Illustrative economics to test, not measured:
300 bp winners and 100 bp losers become +292/-108 after costs, payoff 2.7, break-even hit rate 27%; at 35% wins
the expectancy is 32 bps of traded notional.

Sizing law, the part that turns "leverage the profits" into a loop instead of a blow-up: bets draw only from
settled profits P (the $100 base is never bettable; astra notes strict protection of the base means the grind
itself must earn P first), f = 0.25 x max(0, p_L - (1 - p_L) / b_L), stop-loss dollars R = min(f P, 0.02 P,
$0.50), notional N = min(R / stop fraction, 0.05 P, $10), daily cap min(0.05 P, $1), no recycling of the day's
winnings, 72 h cooldown, three consecutive losses suspend the mode. Ruin of the base is zero by construction;
P_n >= 0.95^n P_0 without replenishment. The number the operator will hate: the first conviction bet needs roughly
$15 of accumulated grind profit to clear the venue's $1 minimum with margin, and at the measured grind rate that
is many months away, so inside this stage the "very large position" is a $1 to $5 bet and most weeks there is
none. "Leverage" here means concentrating profits; the venue offers this account no margin or futures and the
base rule forbids it anyway.

Refutations kept: (a) the loop cannot compound from $100 of grind profit in any reasonable window; S2C's
deliverable is a validated conviction instrument plus a sizing law that fires when profits exist, and any
capital contribution is a separate fresh yes, never loop profit; (b) no funding or basis play exists on this
venue; (c) no reinforcement learning, no extra dashboards, no automatic live promotion.

Build order (each a pair record, both seats' text as the spec): scripts/klines_fetch.py (4h and 1m history to
local CSV under a frozen data contract, resumable, manifest-hashed; record s2c-klines-fetch); scripts/
conviction_backtest.py with a committed research manifest checked before any run (record s2c-conviction-backtest);
then the fetch and the walk-forward on the workstation, a plain-prose readout, and, only if the family promotes,
14 days of shadow on the runner beside the four paper makers (signals to the hash-chained ledger, paper
execution) before any paper-live use; live remains behind S2B.5 and S2C's own yes.

## 9. Next actions, in order (each a pair record; all executed on gpt-6-astra so far, none degraded)

1. DONE (s2-experiment-ledger, leafhft/experiments.py): pre-registration ledger and the row schema.
2. DONE (s2-probe-strategy): execution probe strategy, live as a paper session since 10:20 CT.
3. DONE (s2-decompose): scripts/decompose.py; first readout in 8b.
4. DONE (s2-calibration, s2-calibration-fix, s2-push-calibration; dashboard ops-dashboard #318 merged 534bbf54,
   deployment 6283291380): leafhft/calibration.py, the Calibration card on both surfaces, calibration pushed with every run.
5. DONE: slice A live broker, slice B gate boundary (readiness before the ack, stake in the ack, maker-only boundary),
   slice C risk persistence + executable value + order mid_i, slice D maker-only default, the sidecar retry, and slice E
   the live driver, wired end to end on a fake client and still refused by LIVE_DRIVER_AVAILABLE=False. leaf-hft main
   3694b1d, 395 tests. Every record executed on gpt-6-astra except s2-calibration-fix (sonnet fallback, disclosed).
6. DONE: runner recording (8e, 8f); S2A frozen and registered (8g), window 2026-09-06 to 2026-09-19 00:00Z, decision
   once at the close with scripts/s2a_bounds.py bounds. Four paper books live on the runner from deploy/runner.
7. IN FLIGHT: S2C (records s2c-klines-fetch, s2c-conviction-backtest), then the walk-forward readout; Terraform #1483
   replacement. NEXT after 09-19: S2A decision, S2B challenger (confidence-scaled sizing) against the incumbent; S2B.5 and
   any real money each behind their own yes.
