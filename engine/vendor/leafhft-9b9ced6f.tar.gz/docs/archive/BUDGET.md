# leafhft project budget ledger

> Archived 2026-09-24 from the repository root to docs/archive/ (plan abstract-pondering-magpie, Part IV lane 18). Kept as a historical record; the index is docs/archive/README.md.

Approved by the operator 2026-09-05 11:5x CT in session 8ef085a7: "approved at $500 total project budget".
Scope as understood: one envelope for the whole leafhft project (infrastructure and the live sleeve). Each
line below is a commitment against it; the moment money is deposited to an exchange still gets its own yes
(it needs the operator's account). Nothing here is spent until its row says "committed".

| Item | Planned | Committed | Spent to date | Note |
| --- | ---: | ---: | ---: | --- |
| Cloud runner for S2A (14-day recording + 24/7 engine) | $120 (3 months) | $40/mo committed 2026-09-05 | $0 so far (billing accrues hourly) | EC2 i-041d199cb2da5d73d, t3.small on-demand us-east-1 (~$15.2/mo) + 40 GB gp3 (~$3.20/mo) + NAT data (~$0.045/GB, a few MB/day) + two Secrets Manager secrets (~$0.80/mo); Terraform shared/leafhft-runner, PRs #1476 and #1477, apply run 2 on main cb1a3d43; stop = terraform destroy via the apply workflow |
| Live sleeve S2C | $100 | $0 | $0 | after S2B.5, own yes at deposit |
| Ramp reserve (S2D first step 100 -> 300) | $200 | $0 | $0 | evidence-gated, own yes |
| Contingency (data egress, snapshots, venue minimums) | $80 | $0 | $0 | |
| Total | $500 | ~$40/mo (runner) | $0 | envelope $500; next re-read from the AWS bill on 2026-10-01 |

Rules: a row moves to "committed" only when the resource exists and its cost is recorded with a receipt
path; monthly infra cost is re-read from the provider's bill, never estimated twice; if cumulative spend
reaches $400 the plan pauses for a fresh yes on the remaining $100.
