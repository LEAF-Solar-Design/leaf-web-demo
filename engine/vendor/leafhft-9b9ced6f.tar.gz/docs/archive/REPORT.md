# leafhft: $100 to $1000 by high-frequency crypto trading. The platform, the runs, the arithmetic.

> Archived 2026-09-24 from the repository root to docs/archive/ (plan abstract-pondering-magpie, Part IV lane 18). Kept as a historical record; the index is docs/archive/README.md.

Built and run 2026-09-04 22:30 to 2026-09-05 00:30 Central in one session, with the astra consult seat
(gpt-6-astra, read-only) as design partner and adversarial reviewer across two rounds, Kimi and Haiku as the
disagreement signal. Source: `D:/GitHub/leaf-hft`, git sha in each `receipt.json`. Consult transcripts:
`C:/tmp/askall-leafhft-r1/` and `C:/tmp/askall-leafhft-r2/`.

## Verdict first

The honest claim is narrower than the mandate and worth more than a fake win: a hardened paper-trading
harness that survived two adversarial reviews, measured live markets honestly enough to say no, and refused
real money without a fresh human yes.

Every short live-data paper session lost money. The best was Binance.US market making at -$0.16 on $100 over
13.8 minutes, with $24.66 still marked as BTC inventory and its fills unvalidated (that is astra's own
one-line summary of the evidence, quoted). The corrected fill model, rerun after round 2 for 45 minutes
across three Binance.US sessions, produced exactly one maker fill, marked out at -4.7 bps against mid, and
P&L of -$0.04, -$0.03 and $0.00 against cash at $0.00 and buy-and-hold at -$0.03. There is no evidence of
positive net edge anywhere in this work, and on the one venue whose fees allow a maker to exist there is
almost no flow to fill one.

* Required net edge to compound $100 into $1000: 23 bps per round trip over 1,000 trips, 2.3 bps over
  10,000, 0.23 bps over 100,000. Tenfold in 30 days is 7.98% compounded daily.
* Fee death (round trips until fees alone burn 99% of the stake, zero price movement): Coinbase 190
  taker/taker and 381 maker/maker; Kraken 286 and 573; Binance.US 11,511 taker/taker and never for
  maker/maker at 0% maker.
* Post-fill markouts were negative at every horizon on every strategy and venue. On the best configuration
  the sample is 10 fills, which has no power to resolve a 1 bp effect; the sign is the finding, not the size.
* Probability of $1000 in 30 days: astra 0.01% after round 1, 0.001% after seeing the data; Kimi under 1%,
  then 0.005%; Haiku 3% on a compounding error (it divided 900 bps by the per-trip edge instead of
  compounding), which is the three-seat disagreement signal working as intended. Through the shipped CLI the
  probability is exactly 0%: the live driver is deliberately unwired.

Recommendation, agreed by both reviewing seats and by me: fund $0, leave the live gate unarmed. Spending money
is a named exception in the operator's standing authority and this report does not exercise it.

## What was built

| Module | What it does, and what it does not claim |
| --- | --- |
| `leafhft/types.py` | Fixed-point Python ints for price/size/cash (exact at BTC scale, no int64). Every field validated: ints not bools, enums not raw ints, sub-scale precision and negatives rejected, no silent rounding. |
| `leafhft/book.py` | L1 book, bounded trade tape, anchored rolling sums (variance verified against two-pass numpy at $79.6k mids). Venue/symbol identity enforced, strictly increasing seq, separate quote and trade clocks, NEVER sentinel before the first quote. |
| `leafhft/feeds/` | Coinbase Advanced Trade WS (ticker, market_trades, heartbeats), Kraken WS v2 (ticker, trade), Binance.US WS with REST fallback (book every 0.5 s, prints every 1 s, under 10% of the weight budget, trade-id gap counter). Bounded queue that drops the oldest event, capped backoff, heartbeat watchdog, every message size-capped and schema-checked. A dropped event is counted, and a paper fill during a gap is not trustworthy. |
| `leafhft/broker/paper.py` | Orders and cancels both arrive after 350 ms. Takers fill only against displayed depth (zero depth, zero fill; one assumed extra level for a market remainder; the rest canceled). Post-only that would cross is rejected; a non-marketable IOC is canceled. Resting orders fill only on print evidence stamped after arrival: trade-through capped by print size, same-price sided prints through a queue whose position is known only after our price has been the touch. A crossed snapshot is ambiguous and fills nothing unless `snapshot_fills` is on. Buys reserve notional plus fee plus haircut and are re-checked at fill. Every fill is attributed to its rule in the receipt. Residual optimism named in the module docstring: cancellations ahead of us are not modeled, hidden liquidity is ignored, and missed prints on a polled feed hide both fills we would have had and volume that would have depleted our queue. |
| `leafhft/risk.py` | Latching kill: drawdown, daily loss, kill file (polled on a 250 ms budget from the mark path, not only when a strategy speaks). Order and position caps that count pending same-side orders as filled, open-order cap, orders and fills per minute, price band, stale-quote block that also cancels resting orders. |
| `leafhft/ledger.py` | SQLite, WAL, hash chain over a versioned envelope {ts, kind, body}; verified on open; tail truncation detected by a sidecar checkpoint; failed state latches; buffer capped. This is integrity evidence (nobody edited the record), not proof the economics are right. |
| `leafhft/strategy/` | `mm` post-only maker around the microprice with inventory skew; `momentum` taker scalper; `meanrev` maker entry and exit. Each receives its round-trip cost from the CLI (a caller cannot understate it) and abstains below it: the maker widens to cost/2 plus 0.25 bps, momentum refuses to enter when its take-profit cannot clear two taker legs, mean reversion raises its profit floor. |
| `leafhft/engine.py` | The loop. Hot path p50 in the tens of microseconds, p99 868 us unloaded (budget 1 ms), 1 to 7 ms with four sessions and a consult sharing the host. Markouts at 1/5/30 s per fill, versus the fill price and versus the mid at fill time, maker and taker separately. Shutdown cancels (with latency), invents no flatten fill, reports residual inventory at mid and at liquidation value, and writes the receipt even if the loop raised. |
| `leafhft/broker/live_gate.py` | Fails closed unless LEAFHFT_LIVE=1, an ack file containing "I authorize live trading with config <sha256>", venue credentials in env, and stake at most $100. Arming consumes the ack (renamed with a nonce): one hand-written yes, one run, time-boxed, with astra's conservative limits ($10 order, $25 inventory, $2 daily loss, 5% drawdown) attached to the authorization. |
| `leafhft/broker/binanceus_live.py` | HMAC-signed REST client that cannot be constructed without a LiveAuthorization and re-checks expiry and per-order notional on every place(). Timeouts leave the order UNKNOWN and block further placement until resolved by client id. Shutdown cancels only the client ids this run placed. Unexercised against the venue: no credentials exist; signing, parameters and the authorization boundary are unit-tested. |
| `leafhft/sim/goal.py` | Required edge, trips needed, fee-death table, vectorized Monte Carlo with first-passage. |

77 pytest cases pass on this host (`python -m pytest tests -q`). Astra's review was static: it could not
run the tests or open the ledgers (its shell helper is broken fleet-wide), so "reviewed" means read, not rerun.

## Fee facts that decided the venue (verified 2026-09-05)

| Venue | Maker | Taker | Source and caveat |
| --- | --- | --- | --- |
| Coinbase Advanced Trade, under $1K 30-day volume | 0.60% | 1.20% | search snippets conflict (one says 0.40/0.60 under $10K); the fee page returned 403; modeled at the worse tier; astra: verify the account's own schedule before any live use |
| Kraken Pro tier 1, under $2.5K | 0.40% | 0.80% | kraken.com/features/fee-schedule |
| Binance.US, every Advanced pair since 2026-04-22 | 0.00% | 0.02% | blog.binance.us/zero-fee-trading; Tier 0 pairs (BTC/USD per secondary sources) 0.00/0.01; modeled at the worse 0.02 |

Binance.US is the only venue where a maker strategy is not fee-dead by construction. Its WebSocket is blocked
from this host (TCP connects in 0.23 s, the upgrade never completes under two client libraries), so the engine
polls REST: book every 0.5 s (2 Hz nominal), prints every 1 s. Measured over one 15-minute session: 2,638
polls, mean 151 ms per poll, 1 cadence gap. At 1 Hz on prints the venue is not an HFT venue; intervening
prints are missed, so maker fills there are inferred from price crossing our level, never observed.

## Live paper sessions (real feeds, paper fills)

Set 1 (2026-09-04 22:59 to 23:13 Central, 13.8 minutes each, ended by a shutdown bug, reconstructed from the
ledger, chain verified). Fill rules of that build: snapshot crossing filled the full order, trade-through filled
the full order, cancels were instant. Treat every maker figure here as an upper bound.

| Venue / strategy | Fills (maker/taker) | P&L | Fees | Haircut | Residual BTC at mid | Markout vs fill 1 s / 5 s / 30 s (bps) |
| --- | --- | --- | --- | --- | --- | --- |
| Binance.US mm, half-spread 0.25 bps | 10 (9/1) | -$0.156 | $0.010 | $0.067 | $24.66 | -1.04 / -1.31 / -1.52 |
| Coinbase mm, half-spread 0.25 bps | 41 (40/1) | -$6.607 | $6.226 | $0.281 | $23.97 | -0.50 / -0.67 / -0.61 |
| Coinbase momentum, entry 3 / tp 6 / sl 4 bps | 5 (0/5) | -$4.579 | $4.507 | 0 | 0 | -2.00 / -2.00 / -1.84 |

Set 2 (23:14 to 23:29 Central, 15 minutes, receipts written, same fill rules as set 1 plus the abstention
floor). With a 1 bp haircut the maker's floor is 1.25 bps, so it quoted $10 from mid and never filled:

| Venue / strategy | Fills | P&L | Fees | Orders | Note |
| --- | --- | --- | --- | --- | --- |
| Binance.US mm | 1 (seed) | +$0.001 | $0.010 | 65 | abstained; the cent is BTC drift on the $50 seed |
| Binance.US meanrev | 0 | $0.000 | 0 | 1 | one bid rested, never reached |
| Coinbase mm | 1 (seed) | -$0.590 | $0.600 | 67 | abstained; the seed's 120 bps taker fee is the loss |
| Coinbase momentum | 6 (0/6) | -$4.595 | $4.507 | 4 | flagged fee-dead at start; that build still traded, this one abstains |

Set 3 (23:33 to 23:52 Central, corrected fill model after astra round 2, git ebfa678, Binance.US only,
15 minutes each, REST feed 2,641 to 2,644 polls per session at 151 to 152 ms mean and 475 ms max, zero
cadence gaps, zero trade-id gaps). Every fill's rule is in the receipt:

| Strategy | Fills (maker/taker) | P&L | Fees | Residual BTC at mid | Equity at liquidation | Buy-and-hold | Maker markout 30 s (bps, vs fill / vs mid) | Orders / cancels / post-only rejections |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| mm, haircut 0, resting 5 s | 2 (1/1) | -$0.039 | $0.010 | $24.66 | $99.951 | $99.971 | -4.66 / -4.71 (n = 1, a trade-through fill) | 81 / 61 / 18 |
| mm, haircut 1, resting 5 s | 1 (0/1) | -$0.034 | $0.010 | $49.31 | $99.945 | $99.971 | none (abstained at the 1.25 bps floor) | 65 / 64 / 0 |
| meanrev, haircut 0 | 0 | $0.000 | 0 | 0 | $100.000 | $99.949 | none (3 bids joined the touch, 3 withdrawn) | 3 / 3 / 0 |

The single maker fill of the night under evidence-only accounting came from a print through our bid, and
the market kept falling for 30 s afterwards: adverse selection of 4.7 bps on a quote 0.25 bps from mid. One
fill is an anecdote, not a statistic; its sign matches every other markout measured tonight.

Baselines for every row above: cash stays $100.00; buy-and-hold of $100 in BTC over the same window is in
each receipt as `baseline_buy_and_hold_usd`. Equity is marked at mid; `equity_liquidation_usd` is what selling
the residual BTC at the bid with taker fee and slippage would leave, and is the number to compare to cash.

## Replay sweep (20-minute recordings, all three venues)

Recordings 2026-09-04 22:52 to 23:12 Central: Coinbase 8,097 events, Binance.US 2,320, Kraken 901.
Grid: {mm at half-spread 0.1/0.25/0.5/1/2 bps, meanrev, momentum} x haircut {0, 1, 2, 5} bps x fill model
{queue, touch}.

Sweep 1 (`runs/sweep/summary.md`, old fill rules, 147 runs): 0 positive P&L rows. Binance.US mm
-$0.131 to -$0.082 with 1 to 15 fills and 30 s markouts averaging -2.0 bps; Coinbase meanrev -$8 to -$10 in
20 minutes (fee death); every maker on Coinbase and Kraken abstained and lost only its seed fee.

Sweep 2 (`runs/sweep2/summary.md`, corrected fill rules, maker still re-quoting on every $0.02 move, 147
runs): 0 positive rows, and the maker on Binance.US got zero maker fills at every half-spread and haircut.
Its only fill was the seed (taker, $0.0099 fee); the -$0.082 is BTC drift on that $50 seed. Fill-rule
attribution across the venue: 40 taker, 0 trade-through, 0 queue, 0 snapshot. The 1 to 15 maker fills per
run in sweep 1 were therefore artifacts of the snapshot rule, exactly as astra's C3 said. Coinbase and
Kraken makers abstained; Coinbase mean reversion entered once and could never clear its 122 bps exit floor.

Sweep 3 (`runs/sweep3/summary.md`, corrected fill rules and a maker that rests quotes 5 s and re-quotes on
0.05 bps moves, so it can actually hold queue position, 147 runs): 0 positive rows, and still zero maker
fills on Binance.US at every half-spread and haircut. The venue's own recording explains why:

| Recording, 20 min | Quote updates | Prints | Volume | $ per minute | Median print |
| --- | --- | --- | --- | --- | --- |
| Binance.US BTC/USD | 2,319 | 1 | 0.0001 BTC ($10) | $0.50 | 0.00012 BTC |
| Coinbase BTC-USD | 4,039 | 4,058 | 21.5 BTC ($1.71M) | $85,701 | 0.00002 BTC |
| Kraken BTC/USD | 370 | 531 | 4.13 BTC ($329K) | $16,444 | 0.00046 BTC |

Confirmed from the venue at 23:50 Central: Binance.US BTC/USD 24-hour volume 18.39 BTC ($1.47M) in 3,518
prints, 2.4 a minute, and its last 20 prints spanned 153 minutes; Coinbase printed 6,103 BTC the same day
(332 times more). The displayed queue at the Binance.US touch was 0.025 BTC, about $2,000 ahead of any $25
order that joins it, and the flow to work through that queue arrives at $0.50 a minute in a quiet window and
about $1,000 a minute on the daily average. The zero-fee venue is a near-empty venue. Turnover of thousands
of round trips a day, the only path the Monte Carlo found, is impossible there by orders of magnitude, and on
the venues with flow the fees are fatal. The other maker fills in sweep 3 (8 trade-through and 4 queue on
Kraken, 8 trade-through on Coinbase) all belong to mean reversion entries that never reached their exit floor.

## What astra said, and what changed because of it

Round 1: pick Binance.US post-only market making as an experiment, 0.01% odds, 18 defects across
types/book/ledger (variance cancellation at BTC magnitude, ignored sequence numbers, timestamp and kind
outside the hash preimage, rounding instead of rejecting). All fixed before the live runs. Its build order was
followed and its refuse list honored: no live submission, no leverage workaround, no cross-venue arbitrage, no
ML, no dashboard, no Numba rewrite.

Round 2 (after reading the code and the set-1 ledgers): the fill model was "not conservative by construction"
and it named why: snapshot crossing manufactured full fills, trade-through ignored print size, zero displayed
depth filled everything, cancels were instant, cash was not re-checked at fill, the kill file was polled only
when a strategy emitted, shutdown synthesized a flatten fill against a stale quote, and the signed client could
place orders on credentials alone. Every one of those is fixed in the current source (commit message
"astra round-2 fixes"); the fill-rule attribution counters in each receipt show which rule produced each fill.
Astra also rejected the framing of this report (see the next section) and cut its probability to 0.001%.

## What "every Leaf system" actually meant here, and what it did not

Used: the askall consult driver across three model families (astra, Kimi, Haiku) twice; the secrets store,
to prove no exchange keys exist; the web tools for fee verification; the learnings ledger (L415, L416) and the
memory system; the fleet dialogue bus for context. That is a bounded test of one new trading prototype, not a
test of Leaf's systems. The CAD pipeline, the walk infrastructure, the AWS services, and every other live
session were untouched, and none of them could supply the one missing thing: a measured, positive net edge
after fees. "Ultimate" would also imply the platform passed; its central finding is negative, which is the
correct output of an honest instrument.

## The surface: local UI, dashboard page, signals (added 2026-09-05, operator's ask)

Designed on a Claude Design canvas in the ops-dashboard's own system (Geist, its dark and light
tokens, 12 px cards) from this run's real data: https://claude.ai/code/artifact/b09cc5e7-a764-40fa-abb1-76469aea651d.
Two surfaces render it: `python -m leafhft ui --port 8811` (loopback only, live follow by ledger
row, KILL button) and the ops dashboard page `/leafhft` (Analytics group), fed by
`scripts/push_runs.py`. Chart hues were validated with the dataviz palette checker on both surfaces;
equity is shown against cash and buy-and-hold on every view, fills carry their rule, markouts are
measured against fill and against mid.

Signals (`python -m leafhft signals`) add context per run and are labeled as context, not permission
to trade: regime (realized volatility, move, spread from 1 s bars), pattern (lag-1 autocorrelation,
variance ratio, AR(1) half-life, descriptive only), a walk-forward logistic model on book features
predicting the mid 30 s ahead, and the public Fear and Greed index (73, "Greed", 2026-09-05). The
model is scored on later time blocks only, and its p-value counts one independent trial per horizon
(the first version counted every overlapping second and reported p = 0.0006 on a random walk; a test
now guards that). On the Coinbase recording it hits 55.9% of 717 labels (24 effective trials, p 0.56)
for an implied 0.06 bps per trade before costs; on the Binance.US runs it is at or below coin-flip.
Against a required 2.3 to 23 bps per trip, that is the same answer as the fills: nothing to compound.

Refresh cadence (operator's ask, 2026-09-05 02:00 CT): the engine marks equity every 250 ms from a
heartbeat, not only when a message arrives, because the Binance.US REST feed delivers about two
events a second and event-driven marks topped out at 2 per second. Measured on session
20260905-020651: 3.75 marks per second over a 4 s window. The local UI polls ledger deltas every
250 ms while a run is live and follows a new session on its own; the dashboard page polls once a
second while live and the pusher ships deltas every 2 s. The same heartbeat runs the deadline, the
KILL file and the stale-feed poll, so a dead feed can no longer hold the kill switch until the idle
timeout: `feed.stop()` wakes its consumer with a queue sentinel, and a test proves KILL on a silent
feed lands in under 3 s (session 20260905-015709 was stopped this way: "risk kill: kill file present").

Dashboard state (2026-09-05 02:50 CT): the redesigned page shipped in ops-dashboard PR #312, squash-merged
as c13ddad3 (deployment 6278617350), which also fixed the sidebar entry #308 missed (the sidebar reads
`src/lib/config/surfaces.ts`, not `navigation.ts`) and added the signals column; every run here was
pushed to it with signals after the deploy. The production alias had been pinned to the #311 build by a settled rollback in the ARLO lane (GitHub reported success while the alias never moved); on the operator's word it was promoted at 08:5x CT (`vercel promote dpl_HeTBYbWuQwd9ZnEZARYMDaAtggvb`), the alias resolves to c13ddad3, and all 16 runs were pushed again so the signals landed.

Stage-2 build state (2026-09-05 11:40 CT): PLAN-STAGE2.md section 9 items 1 to 5 are done on main (3694b1d, 395
tests): experiment ledger, execution probe, decomposition, calibration on both surfaces (ops-dashboard #318,
534bbf54), and the live-path hardening slices A to E including the wired but flag-refused live driver. No money
has moved; the live gate has never opened. The fee lesson of the day: the probe and the Coinbase and Kraken
thermometers paid $1.49 of the $1.65 in simulated fees, by design; the Binance.US maker paid one cent per
session (its taker seed, now off by default). Only zero-fee maker configurations run on the surfaces now.

## How to run it

```
cd D:/GitHub/leaf-hft
python -m pytest tests -q
python -m leafhft goal
python -m leafhft paper --venue binanceus --symbol BTC-USD --strategy mm --seconds 900 --transport rest --haircut-bps 0
python scripts/sweep.py --recordings runs/<run>/ticks.jsonl --out runs/sweep
python scripts/ledger_summary.py runs/<run>/ledger.sqlite
python -m leafhft verify --ledger runs/<run>/ledger.sqlite
```

The Monte Carlo in `python -m leafhft goal` is an assumed-edge illustration with full-equity sizing and a 50%
ruin threshold, not a forecast and not the conservative $2-loss control. The one scenario that reaches $1000
assumes 60% wins at +-6 bps, 2,000 round trips a day, zero fees, for 30 days; the platform's own rate limits
forbid that turnover and its measurements show the opposite sign on the edge.

## Stage 2 (planned 2026-09-05, nothing funded)

The next stage is planned in `PLAN-STAGE2.md` with astra and Kimi (consult round 3, transcripts under
`consults/`): a four-stage ladder (research platform, learning paper, live dress rehearsal, $100 live micro,
then a ramp) where every dollar, including a cloud runner, is a separate fresh yes; a bandit rewarded on
liquidation equity per 30-minute block inside a frozen risk box; pre-registration before any evaluation data
exists; and an aggression section that keeps "more happening" separate from "more edge" (today's taker
configurations were refused by the engine as fee-dead; WebSocket market making on Coinbase and Kraken runs as
a fee thermometer). Both seats put $100 to $1000 by trading alone under 0.5%.

The runner's first hour (2026-09-05 afternoon CT) exposed one real defect and one false alarm. Real: the record
command died when a venue went quiet for 60 s, which Binance.US does routinely; main 6fd1a8e (pair record
s2-record-resilience, 428 tests) reconnects inside the run instead and writes a summary on every exit. False: the
zero-byte tick files were the recorder's 500-row buffer on a sparse venue, refuted by running the feed class and
the record command by hand on the box. All three venues have been recording continuously since 14:23 CT.

S2A is registered (2026-09-05 22:01Z, `experiments/s2a.sqlite`, four Binance.US maker candidates, window 2026-09-06 to
2026-09-19 00:00Z, analysis frozen in `scripts/s2a_bounds.py` under the same code digest) after both consult seats
refused a draft whose risk box the code did not run. The runner carries four paper books from `deploy/runner`. The
operator's compounding-loop goal became stage S2C: a validated directional instrument on years of kline history and a
quarter-Kelly law over profits only; both seats state that the loop cannot compound from $100 of grind profit in any
reasonable window, so the first conviction bet is a $1 to $5 bet many months out unless capital is contributed.

The S2C instrument ran its first pre-registered evaluation on seven years of Binance.US history (reports/s2c): the
frozen compression-breakout family fired 45 times, 19 valid test episodes, hit rate 0.325 (lower bound 0.167), payoff
2.07, mean net -4.7 bps after costs, decision hold, first bet $0 at every bankroll. The history carries the venue's
19-month USD-trading suspension (2023-07 to 2025-02); the post-return market is the thin one quoted today. A second
family on 1h bars runs next with the multiplicity budget counted; if it also holds, directional research on this venue
stops on evidence and the fill-calibration lane becomes the loop's learning product.

Family 2 (1h breakout under compression, K counted) also holds: 249 firings, 78 valid test episodes, hit rate 0.30
(lower bound 0.20) against a break-even of 0.475 after costs, mean net -6.0 bps. Directional research on this venue
stops on evidence; the sizing law bets $0; the loop's learning product is the maker's fill calibration and the S2A
decision on 2026-09-19.

Real trading began 2026-09-06 at a $5 stake on a card-funded Binance.US account: the live gate opened on a hand-written
authorization, a probe order was accepted and cancelled, and the maker filled real buys at $79,755.77 and $79,581.49 for
0.00002 and 0.00003 BTC at zero fee. Four venue lessons were fixed the same hour (an unsigned public endpoint, the
venue's reason in the receipt, transient insufficient-balance refusals handled, explicit adoption of the account's own
inventory). The book runs continuously on the runner with exposure bounded by the stake and the risk box; the point is
calibration and a proven live path, not returns, until the maker's edge is decided on 2026-09-19.

## What would change the answer

Astra's list, adopted as the acceptance bar: a frozen strategy evaluated on unseen, contiguous data across
several market regimes; complete trade and depth sequencing (a working WebSocket, not 1 Hz polling); a
positive lower 95% confidence bound on net liquidation returns with dependence-aware sampling; results that
survive the execution stresses (haircut 0/1/2/5, queue model, cancel latency); and verified cancellation,
unknown-order recovery and authorization boundaries exercised against the venue's test environment. Thousands
of correlated fills alone would not suffice. If that evidence ever appears, the gate, the conservative limits
and the signed client are ready; the decision to fund remains the operator's fresh yes.
