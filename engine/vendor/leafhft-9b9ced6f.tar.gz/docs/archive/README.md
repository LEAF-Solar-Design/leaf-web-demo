# Archive

Documents that shaped leafhft's first two stages and are no longer its working surface. They moved here from the repository root on 2026-09-24 (plan abstract-pondering-magpie, Part IV lane 18), so the root keeps only live entry points. Each file keeps its full text; the one edit is a banner line under its title. `git log --follow docs/archive/<file>` shows the history from before the move.

| File | What it is | Last change before the move |
| --- | --- | --- |
| [REPORT.md](REPORT.md) | Stage 1 report: the $100 to $1000 platform, the runs, and the fee arithmetic that rules out the tenfold goal. | d555394, 2026-09-06 |
| [PLAN-STAGE2.md](PLAN-STAGE2.md) | Stage 2 plan after consult round 3: the ladder from research platform to live micro sleeve, its targets and open questions. | f70d182, 2026-09-06 |
| [BUDGET.md](BUDGET.md) | The $500 project budget ledger approved 2026-09-05 and the commitments made against it. | b395525, 2026-09-05 |
| [EXECUTION-EXPERIMENT-SPEC.md](EXECUTION-EXPERIMENT-SPEC.md) | Frozen design of the account execution experiment layer: size and delay variants, assignment, audit fields. | 160c137, 2026-09-18 |

## Old references

Some files still cite these documents by their old root names; read each such name as this folder.

- `leafhft/fees.py` and `leafhft/sim/goal.py` cite REPORT.md.
- `leafhft/config.py` and `scripts/probe_venue_ws.py` cite PLAN-STAGE2.md.
- `experiments/PREREG-S2A.md` and the consult transcripts under `consults/` cite PLAN-STAGE2.md and REPORT.md.
