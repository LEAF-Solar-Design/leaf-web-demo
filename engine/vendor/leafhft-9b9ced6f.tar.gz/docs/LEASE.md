# The authorization lease for leafhft live books

Status: design, awaiting the operator's yes (lane L5, artifact L5-D). Nothing in this document is
built or deployed. The final section states the exact decision requested.

The lease replaces two things at once: the daily `--seconds 86400` expiry that every live book is
started with, and the attended re-arm that follows it, in which someone reads each of fourteen
journals, writes fourteen sentences and restarts fourteen units. The lease is one durable,
operator-signed authorization per book that survives restarts, renews without a restart, and can
be revoked from outside the process within a stated bound. It changes who has to be awake, not what
the book is allowed to risk: every stake, policy, cap and gate in force today stays in force.

## Today's behaviour, cited

Every claim here was read from the tree at origin/main (16f1f23) on 2026-09-23.

- The wrapper starts every book with a fixed one day run. `--seconds 86400` is passed for the
  Binance.US maker (deploy/runner/live-run.sh:129), Polymarket US (deploy/runner/live-run.sh:170),
  Kalshi books with a policy file (deploy/runner/live-run.sh:198), Kalshi books without one
  (deploy/runner/live-run.sh:201) and the perps sleeve (deploy/runner/live-run.sh:288). The Kalshi
  sizing branch that reads the policy ceiling is deploy/runner/live-run.sh:185-198.
- The authorization expires with the run. `assert_armed` sets the expiry to `run_seconds` plus
  `AUTH_GRACE_S` (leafhft/broker/live_gate.py:338-345, grace of 900 s at
  leafhft/broker/live_gate.py:38). `LiveAuthorization.check` raises "authorization expired"
  (leafhft/broker/live_gate.py:142-144), and the Kalshi client calls it at construction and on the
  send path (leafhft/broker/kalshi_live.py:683, leafhft/broker/kalshi_live.py:1791).
- The Kalshi loop stops itself at the same deadline: `deadline = time.monotonic() +
  cfg.run_seconds` with stop reason "seconds elapsed" (leafhft/kalshi_live_runtime.py:4467-4468).
- A trap for anyone who tries to lift the limit by passing zero seconds: the loop then has no
  deadline (leafhft/kalshi_live_runtime.py:4467), but the authorization falls back to `(cfg.run_seconds or 3600)`
  (leafhft/broker/live_gate.py:338), so the book would lose its authorization after 75 minutes.
  The lease must own the expiry; it can never be derived from `run_seconds`.
- The ack is one shot by default. Arming renames it with a nonce (leafhft/broker/live_gate.py:333-337),
  and the shared original is claimed the same way (leafhft/cli.py:834-842). With
  `LEAFHFT_AUTHZ_V2=1` the ack is instead kept for 7 days and 64 starts
  (leafhft/broker/live_gate.py:39-40, leafhft/broker/live_gate.py:273-320,
  leafhft/cli.py:823-832), recorded in `arms.jsonl`; V2 ships off (deploy/runner/AUTHORIZATION.md:3-5).
- The unit restarts only on failure: `Restart=on-failure`, `RestartPreventExitStatus=4` and
  `RestartSec=30` (deploy/runner/units/leafhft-live@.service:19-21). Exit status 4 is how the
  wrapper already says "stay down": a bad lane binding (deploy/runner/live-run.sh:241) and the
  exposure prestart refusal (deploy/runner/live-run.sh:286) both use it. Inferred, not yet checked
  against a journal: a clean exit at the 86400 s deadline is not a failure, so systemd does not
  restart it and the book stays down until someone starts it.
- Re-arm is attended. `rearm.py` parses the latest startup's "LIVE GATE CLOSED" refusal and its
  printed sentence (deploy/runner/rearm.py:24-52), then per unit stops it, rechecks the refusal,
  writes the sentence atomically as mode 0640 and starts it (deploy/runner/rearm.py:83-129). Its
  sentence grammar is deploy/runner/rearm.py:17-21. `rollout.sh` serializes deploy and rearm one
  settlement gap per book (deploy/runner/rollout.sh:26) across the fourteen Kalshi units
  (deploy/runner/rollout.sh:59-60).

## What the lease is

A lease is a small JSON document, at most 8 KiB, one per book, at
`/etc/leafhft/leases/<unit instance>.lease.json` (for BTC-15M, `kalshi-btc-15m.lease.json`), root
owned, mode 0640, group leafhft. It binds, and the book refuses it unless every binding matches the
process that reads it:

- Book: venue and symbol (`kalshi`, `BTC-15M`) and the unit instance name.
- Engine: the engine binding id and digest the book resolves at start from
  `kalshi-engine-bindings.json` (deploy/runner/live-run.sh:206-210), or the literal `incumbent`
  when none is bound.
- Policy digest: the config digest `cfg.digest()` and the policy bounds digest, the same two values
  the current ack sentence carries (leafhft/broker/live_gate.py:175-180). The digest already
  covers sizing, risk, routing, strategy parameters, policy bounds and engine selection
  (deploy/runner/AUTHORIZATION.md:7-10).
- Stake ceiling: in cents, and it must equal the policy ceiling the wrapper derives
  (deploy/runner/live-run.sh:187-197) and stay inside the venue ceiling
  (leafhft/broker/live_gate.py:62). A mismatch is a refusal, exactly as readiness refuses today
  (leafhft/broker/live_gate.py:257-260).
- Code sha: the 40 hex build sha the wrapper exports as `LEAFHFT_BUILD_SHA`, with
  `LEAFHFT_BUILD_DIRTY=0` required (deploy/runner/live-run.sh:308-319). A dirty tree never holds a
  lease.
- Validity: `lease_id` (random 128 bit hex), `issued_at` and `not_after` in UTC. `not_after` is at
  most 7 days after `issued_at`, the same ceiling V2 uses (leafhft/broker/live_gate.py:39).
  `max_starts` is at most 64 per lease, the V2 bound (leafhft/broker/live_gate.py:40).
- The sentence: the exact current ack sentence for this config, so the operator still reads and
  approves a human sentence, followed by "under lease <lease_id> until <not_after>".
- Signature: an Ed25519 detached signature over the canonical bytes (sorted keys, no whitespace)
  made with a key the operator holds off the runner. The runner holds only the public key, at
  `/etc/leafhft/lease-signer.pub`. A session, a prompt or a bug on the runner cannot mint a lease.

Renewal without a restart: the book rereads its lease file on the policy watcher's cadence and at
most every 30 s. A new lease whose bindings (book, engine, digests, stake, code sha) are byte equal
to the running one and whose `not_after` is later is adopted in place: the process swaps the expiry
it enforces and appends a renewal receipt. A lease that changes any binding is refused in place and
the running lease keeps governing until its own `not_after`; changing a binding is a restart, as it
is today. This needs one code change the doc names so the build lane cannot miss it:
`LiveAuthorization` is a frozen dataclass with a fixed `expires_ns`
(leafhft/broker/live_gate.py:128-144), so the lease path gives it an expiry holder the watcher can
advance and never shorten except through revocation.

## Revocation checks

Two independent paths, both polled, both fail closed.

- Revocation list: `/etc/leafhft/lease-revocations.json`, root owned, at most 64 KiB, carrying a
  monotonic `generation` and a list of revoked `lease_id` values plus an optional `all_before`
  timestamp. The book polls it every 5 s. A lease id on the list, or an `issued_at` before
  `all_before`, revokes. The file must exist (deploy installs it empty); missing, oversize,
  malformed or a generation that goes backwards counts as unreadable, and three consecutive
  unreadable polls (15 s) are treated as a revocation of new entries.
- Kill file: the existing `KILL` file in the run directory, polled every 250 ms by the risk
  manager (leafhft/risk.py:20, leafhft/risk.py:202-210) and by the Kalshi loop
  (leafhft/kalshi_live_runtime.py:4137, leafhft/kalshi_live_runtime.py:5131). The lease does not replace it and adds nothing to
  it. KILL remains the instant stop.

Refusal semantics on a revocation: the book stops opening immediately (no new entry intent passes),
cancels resting entry orders, keeps settlement polling and risk reducing exits exactly as the daily
cap latch does today ("without stopping settlements or risk-reducing exits",
leafhft/kalshi_live_runtime.py:2515), writes a revocation receipt, and once every open ticket has settled or 30
minutes have passed, exits with status 4 so systemd keeps it down
(deploy/runner/units/leafhft-live@.service:20). A revoked book is restarted only by a new lease.

## Position recovery across a restart

A restart under a valid lease needs no ack and no human. Recovery keeps today's order: venue truth
first, the journal second.

1. The venue first. `client.reconcile()` runs before anything else (leafhft/kalshi_live_runtime.py:4173) and reads
   every owned order back from Kalshi (leafhft/broker/kalshi_live.py:2000-2063), including its fill
   count and fill basis; an absence is accepted only with a valid send timestamp and after the
   monotonic grace (leafhft/broker/kalshi_live.py:2014-2027). Balance and positions are then read
   from the venue (leafhft/kalshi_live_runtime.py:4174-4178).
2. The journal second. `kalshi-tickets.jsonl` supplies settled, void, adopted and exited client ids
   (leafhft/kalshi_live_runtime.py:4218-4241), and `KalshiBook.recover` rebuilds open tickets from the reconciled
   journal minus those ids (leafhft/broker/kalshi_book.py:1191-1227). Today's realized P&L comes
   from `prior_realized_today_cents` (leafhft/broker/kalshi_book.py:200, leafhft/kalshi_live_runtime.py:4243-4249).
3. The exposure prestart still runs in the wrapper before the process starts
   (deploy/runner/live-run.sh:284-286), and the day open basis is read back from the shared file
   (leafhft/kalshi_live_runtime.py:4193-4195).

The lease adds one rule: if the lease is expired or revoked at start while the reconciled book holds
open tickets, the book starts in exit only mode instead of refusing outright, so recovered tickets
still settle and book, then exits 4 as in the revocation path. With no open tickets it refuses and
exits 4. A restart consumes one of the lease's `max_starts`, counted in `arms.jsonl` under a lock
with an fsync before arming, reusing the V2 journal code (leafhft/broker/live_gate.py:284-316).

## Day rollover on one book

Today a book's day boundary is wherever its 86400 s run happens to end, plus the in-loop checks
below. Under a lease one process spans many UTC days, so the 00:00Z rules must be explicit.

Resets at 00:00Z (already implemented in the running loop, kept as is):

- The daily loss cap. `_kalshi_refresh_cap_halt` detects the new UTC date, recomputes prior realized
  P&L for the new day, and clears the cap halt if the cap is no longer reached
  (leafhft/kalshi_live_runtime.py:2514-2543).
- The day open equity basis. `kalshi_equity_day_open` keeps today's basis and persists a fresh one
  when a new UTC day starts (leafhft/kalshi_live_runtime.py:256-279); the loop calls it on every balance refresh
  (leafhft/kalshi_live_runtime.py:4725-4728), and `kalshi_shard_refresh` recomputes the drawdown state and size
  scale from it (leafhft/kalshi_live_runtime.py:230-247).

Carries across 00:00Z:

- The exposure ledger: open tickets, reserved cash and resting orders stay exactly as they are.
- Breakers other than the daily cap: KILL, a latched stale feed and a book halt carry until their
  own clear condition, never a date.
- The buy turnover bound is a rolling 24 h window (leafhft/broker/live_gate.py:45,
  leafhft/broker/live_gate.py:102-125), so it neither resets nor accumulates at midnight.
- Counters: `LiveBudget.orders_total` is lifetime per authorization and refuses at 20,000 orders
  (leafhft/broker/live_gate.py:37, leafhft/broker/live_gate.py:158-159), and the churn rule refuses
  after 2,000 orders with no fill (leafhft/broker/live_gate.py:160-161). Those limits were sized
  for one day. Under a lease the order budget resets at 00:00Z and at each adopted renewal, never
  on restart, so a seven day lease cannot starve on day three and a restart loop cannot reset it.
  Status counters stay process lifetime; the daily read keys on the UTC date already.

Each rollover appends one receipt: the date, prior realized cents, whether the cap cleared, the day
open basis and the lease id in force.

## Blackout and gap rules the lease keeps

The lease loosens none of these.

- Release blackout: the gold lane still refuses windows that meet a release event or leave calendar
  coverage (leafhft/gold_artifacts.py:212-218).
- Settlement gaps: a restart, deploy or first lease activation happens only in a settlement gap, one
  book at a time (deploy/runner/rollout.sh:26, deploy/runner/AUTHORIZATION.md:41-45). A renewal is
  adopted in place and needs no gap; activation and rollback do.
- Feed gaps: the stale feed watchdog (leafhft/risk.py:211-213) and the lane freshness bounds on
  event gap and index age (leafhft/lanes/document.py:185-187) still halt quoting.
- Exposure conformance: an exit only legacy owner still blocks a fresh opening producer
  (deploy/runner/live-run.sh:284-286).

## Failure modes

- Clock skew. The book refuses a lease whose `issued_at` is more than 120 s in its future. Expiry is
  enforced on both clocks: at load it records the monotonic time and the wall time left, and the
  lease ends at whichever comes first, the same monotonic guard the reconcile grace uses
  (leafhft/broker/kalshi_live.py:2021-2027). A wall clock stepped backwards cannot extend a lease.
  There is no grace after `not_after`, unlike `AUTH_GRACE_S` today.
- A lease revoked mid position. Entries stop, exits and settlements continue, the book exits 4 when
  flat or after 30 minutes, as in the revocation section. Kalshi binary contracts settle at close
  on their own, so no forced flatten order is sent.
- A lease that outlives its code sha. The running process keeps its lease, because the code it runs
  is the code the lease names. After a deploy the next start sees a different `LEAFHFT_BUILD_SHA`,
  refuses and exits 4 with a receipt naming both shas. Today a deploy already strands books by
  rotating the config digest under a one shot ack; the lease makes that loud and deliberate:
  `rollout.sh` must refuse to restart a leased book when no successor lease for the target sha is
  present, so a deploy never takes a book down silently.
- Unreadable lease, bad signature, wrong public key, oversize file: refuse at start and exit 4; in a
  running book, keep the current lease and count the failure, never adopt.
- `max_starts` exhausted: refuse and exit 4; a crash loop cannot trade forever on one signature.
- Signer key lost or exposed: revoke with `all_before` set to now, then issue new leases under a new
  public key.

## Rollback to today's behaviour

Leasing is opt in per book through a new file, `/etc/leafhft/lease-books`, one unit instance per line,
read by the wrapper exactly like `kalshi-probe-hosts` (deploy/runner/live-run.sh:263-280). A book not
listed gets today's byte identical argv, including `--seconds 86400`
(deploy/runner/live-run.sh:198). To roll a book back: in a settlement gap remove its line, write its
ack with `rearm.py --apply` using the sentence it prints (deploy/runner/rearm.py:132-155), and it runs
under the one day expiry and one shot ack again. The lease files, revocation list and receipts stay
on disk as evidence. V2 is untouched by either direction.

## Receipts

All receipts are append only JSON lines, fsynced, under
`/var/lib/leafhft/lease-receipts/<unit instance>/<UTC date>.jsonl`, each file capped at 1 MiB with
refusal rather than truncation past the cap.

- arm: lease id, sha256 of the lease bytes, code sha, config digest, starts used and left.
- renew: old and new `not_after`, lease id, sha256 of the new bytes.
- refuse: the exact binding that failed, at start or at adoption.
- revoke: which path fired (list generation, `all_before` or KILL), open tickets at that moment,
  exit time and exit status.
- rollover: as in the day rollover section.

The arm row also lands in `arms.jsonl` beside the lease, as V2 does today, so one journal counts
every start across leases.

## Migration on BTC-15M first and the acceptance for widening

One book first: `leafhft-live@kalshi-btc-15m.service`. It has the deepest fill history and a 15
minute settlement cadence, so a gap comes every quarter hour and a revoked position clears fast.

Sequence: build and merge the lease code with `lease-books` empty (no book changes); sign one BTC-15M
lease for the running code sha with a 7 day `not_after`; in a settlement gap list the book, stop it,
start it, read back the arm receipt.

Acceptance for widening, all observed on the live box, none inferred:

1. Seven consecutive UTC days on the lease with no ack written and no human re-arm.
2. At least two 00:00Z rollovers with rollover receipts, and the cap and day open values matching
   the daily read for those dates.
3. One deliberate restart in a settlement gap that comes back armed from the lease alone, with the
   position recovered and reconcile showing zero UNKNOWN or UNRECONCILABLE orders.
4. One renewal adopted in place, with no restart and a renew receipt.
5. One revocation drill: entries stop within 5 s, open tickets settle, exit 4, no systemd restart.
6. One deploy that moves the code sha, with the successor lease in place and `rollout.sh` refusing
   a restart without it.
7. Realized P&L for BTC-15M on those days within normal variance of its own prior two weeks, so the
   lease changed nothing economic.

Widening after that: BTC-1H and ETH-15M together, then the remaining eleven Kalshi books, each step
one settlement gap per book under `rollout.sh`. Binance.US, Polymarket US and the perps sleeve stay on
today's expiry until a separate yes.

## Operator decision requested

Reply with one line. The recommended answer is the first.

"Yes L5-D: build the authorization lease as written in docs/LEASE.md, signing key held on my machine
only, 7 day maximum lease, 5 s revocation poll, BTC-15M first under its current policy ceiling, and
widen only after all seven acceptance items are observed; record this yes for Leaf Automation under
Operator authorization in deploy/runner/AUTHORIZATION.md."

Or name the section to change (binding, revocation, recovery, rollover, failure modes, rollback,
receipts, migration) and the value you want instead.
