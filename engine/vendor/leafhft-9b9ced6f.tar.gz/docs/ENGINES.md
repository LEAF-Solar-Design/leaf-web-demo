# Kashbot engines

How an engine is made, tested, probed with real money at one contract, judged, and shown. This file is
the standard every surface builds to: the CLI, the ops dashboard, the iOS app and the assistant. Every
rule that names a number cites the constant in code that holds it, as `module.CONSTANT`.

## Make an engine in three commands

```
# 1. A variant of an existing engine: writes the catalog policy and the manifest.
python -m leafhft.engine_ops manifest init my-variant --template variant --parent <parent-id> \
    --set edge_threshold_cents=6 --summary "One sentence thesis." --novelty "What differs from the parent."
# 2. Test it offline: manifest, kernel pin, parity replay over the pinned corpus. Exit 0 means probe-ready.
python -m leafhft.engine_ops try my-variant
# 3. Probe it live at one contract under a signed, single-use approval.
python -m leafhft.engine_ops probe my-variant --symbols BTC-15M --approval <approval-id> --request-id <uuid>
```

`--set` takes any policy dial in `policy.POLICY_BOUNDS`; values outside those bounds are refused.
`try` prints one card (proposals on the corpus, overlap with the parent, descriptive replay P&L labelled
"offline, not a verdict", evaluate p99, receipt hash) and writes the conform record that `probe` checks.
`engine_ops approve` mints the approval `probe` consumes. `engine_ops status my-variant` then shows
where the engine stands and the next step in one sentence.

## Vocabulary

- **Book**: market data plus one execution slot for one (account, symbol) pair.
- **Kernel**: the code that turns data into signals. A policy kernel is `engine_manifest.POLICY_KERNEL_ID`
  (`kalshi_edge`); a lane kernel is a `LaneEntry` class pinned by the sha256 of its module bytes. One kernel
  backs many engines.
- **Engine**: a kernel plus its parameters, declared inputs and thesis. Named by `engine_id`
  (`engine_manifest.ENGINE_ID_RE`, at most 32 characters) and versioned by its `manifest_digest`.
- **Assignment**: an engine bound to exactly one account and execution domain, with its symbols and a role
  from `engine_registry.ROLES` (probe, graduated, legacy). One account holds many engines; an engine is
  never assigned to two accounts.
- **Executor**: the one process per (account, symbol) that turns engine proposals into orders under the
  account authority, the book and the lifecycle. It hosts at most `executor.MAX_PROBES_PER_BOOK` (40)
  probe engines beside the incumbent, and the incumbent always decides first.

## The manifest (EngineManifest v1)

One file per engine under `/etc/leafhft/engine-manifests/<engine_id>.json`, schema
`engine_manifest.MANIFEST_SCHEMA` (1), at most `engine_manifest.MAX_MANIFEST_BYTES` (16384) bytes,
canonical JSON, decimals as strings, floats refused. It is a sidecar for thesis, provenance and evidence;
the policy JSON stays the executable authority for variants. Sections, all required:

| Section | Fields |
|---|---|
| `identity` | `engine_id`, `version` (1 or more), `parent` (an engine id or null) |
| `provenance` | `origin` from `engine_manifest.ORIGINS`, `source_ref`, `code_sha` (7 to 64 hex or null) |
| `thesis` | `summary`, `novelty`, `kill_criterion`, `expected_edge_cents` (0 to 99.99); none may be empty |
| `kernel` | policy: `kind`, `kernel_id`, `policy_engine_id`, `policy_digest`; lane: `kind`, `kernel_id`, `module_sha256`, `params` |
| `inputs` | `symbols` (from `SYMBOL_MAP`), `feeds` (from `engine_feeds.FEEDS`), `history_rows` (0 to `lanes.base.MAX_HISTORY`, 600), `models` |
| `hot_keys` | lane kernels only, at most 16 names |
| `risk_request` | `fractions` (each at or below `policy.HARD_MAXIMA`), `caps` (LaneCaps fields), `limits` (KalshiLimits fields); requests only, the host takes the minimum |
| `evidence` | at least one item, kind from `engine_manifest.EVIDENCE_KINDS`; a legacy import carries a waiver with a reason |
| `digest` | sha256 of the canonical body |

Two digests come out of it. `manifest_digest` binds the lifecycle, receipts and trials.
`identity_digest` hashes the kernel, parameters and policy digest, so the same logic under a new name is
refused as a clone.

## Kernels and the policy adapter

Only reviewed bytes ever run. `kernels.KERNELS` maps a kernel id to a `kernels.KernelPin`: the entry
module, its entry class, the sha256 of the module's LF-normalized source, and the modes it may run in.
Every kernel enters with `kernels.OFFLINE` (paper, shadow and replay only); a kernel that runs live carries
`kernels.OFFLINE_LIVE`. Adding live to a pin is its own reviewed PR, and `tests/test_lane_kernels.py` fails
any diff that adds it without a `D7-Approval: <id>` commit trailer. The table holds at most
`kernels.MAX_PINS` (64) pins.

`kernels.resolve_kernel` reads the module once, at most `kernels.MAX_KERNEL_BYTES` (1048576) bytes,
normalizes CRLF to LF, checks the digest against the pin and executes exactly those bytes, so a later edit
on disk never runs. A mismatch, an unlisted id or a mode the pin does not carry is refused by name
(`kernels.KERNEL_ERROR_CODES`). A foundry kernel reaches this repo only as a `kernels.EXTRA_PINS` row in its
own reviewed PR, pinned offline, with an id and module that may not collide with `kernels.KERNELS`.

Two ids name the policy path, and they are different things. `engine_manifest.POLICY_KERNEL_ID`
(`kalshi_edge`) is the kernel id a policy engine's manifest declares. `kalshi-edge-entry` is the lane pin
in `kernels.KERNELS` whose entry class, `kalshi_edge_entry.KalshiEdgeEntry`, lets that policy meet the
kernel contract through the lane executor seam. Its params are `policy_engine_id` and `policy_digest`. It
proposes entries only; execution and exits stay with the host. It refuses a policy with `reversal_mult`
above zero, a policy with `all_in_once_armed` set, a policy whose digest differs from `policy_digest`, and a
disabled engine, each as a named refusal.

## The registry

One file, `engine_registry.REGISTRY_FILE` under `/var/lib/leafhft/engine-registry/`
(`engine_ops.DEFAULT_REGISTRY_DIR`), keyed by `engine_id`. Because the key is the engine, an engine is
assigned to at most one account by the file's shape, with no runtime check. It holds at most
`engine_registry.MAX_ASSIGNMENTS` (1024) assignments, writes every number as a decimal string, is decoded
strictly (JSON numbers, duplicate keys and unknown keys refused), and chains each generation to the one
before it by `previous_digest`. The only writer is `python -m leafhft.engine_ops`; the dashboard writes
control requests, never the registry.

- **Domain.** An assignment binds an engine to an execution domain, not just a Kalshi member: either
  `engine_registry.LEGACY_OWNER_DOMAIN` or `account-lane:<lane id>`. A domain marked
  `engine_registry.DOMAIN_EXIT_ONLY` settles and exits but never opens. That is why the owner's own account
  lane (the same Kalshi member, a different ledger) never runs an engine assigned to legacy-owner.
- **Role.** One of `engine_registry.ROLES`.
- **Probes.** At most `engine_registry.DEFAULT_MAX_CONCURRENT_PROBES` (4) probes at once by default.
- **Breakers.** The D5a percentages live in the same file, with the default
  `engine_registry.DEFAULT_BREAKER_PCT` (50) percent.
- **Audit.** `engine_ops registry audit` reports every class in `engine_registry.AUDIT_CLASSES` and exits 2
  when it finds one.
- **The send boundary.** Before an order leaves, the runner asks `engine_registry.assignment_allows`
  through an `engine_registry.RegistryProjection`: one stat per call, a re-parse only when the file
  changes, and an absent or invalid file fails closed.
- **The dashboard mirror.** The pushed registry block is at most `engine_registry.MAX_PUSH_BYTES` (65536)
  bytes.

## Lifecycle

States live in the lifecycle store, `canary.STATES`. New engines use probe, probe_sized, halted, graduated
and retired; shadow and canary are legacy states that stay readable and are never entered again. The states
that place entries are `canary.ENTRY_STATES`.

1. **Draft, tested.** `manifest init` writes the manifest; `try` proves it replays one for one. Offline
   replay and tuning are tuning only, never a verdict.
2. **Probe.** One contract (`canary.PROBE_CONTRACTS`) on the owner account, under a signed approval with an
   expiry. The default window is `probe_bar.WINDOW_DAYS` (14) days with a terminal read
   `probe_bar.TERMINAL_READ_DAYS` (7) days later.
3. **Operational qualification.** The first 20 attributed fills (the default minimum fill count of
   `probe_bar.OperationalQualification`) prove attribution, accounting and settlement before any
   profitability read.
4. **Probe sized.** The ladder `probe_bar.LADDER` (1, 2, 5 contracts), one approval per rung.
5. **Judge.** The verdict is a pre-registered live trial scored from live fills (below).
6. **Graduated.** After the graduation gate and an operator yes, sized within `policy.HARD_MAXIMA`.
7. **Halted.** Integrity stops only (`canary.INTEGRITY_CODES`). Re-entry needs a new signed approval.
8. **Retired.** Terminal. On FAILURE, EXPIRED, or the kill criterion.

A disabled engine keeps settling; a halted probe keeps settling; only retired is terminal.

### The loss breaker (D5a)

One rule shape everywhere: a UTC-day loss limit expressed as a percentage of the account's portfolio value
at the start of the UTC day (cash plus the venue mark of open positions).

- The default is `breaker.DEFAULT_PCT` (50 percent); a setting is clamped to `breaker.MIN_PCT` through
  `breaker.MAX_PCT` (1 to 100).
- Two scopes, `engine_registry.BREAKER_SCOPES`. The **account** breaker measures the account's net loss
  since the day start across every engine on it, incumbents included. The **engine** breaker measures one
  engine's attributed loss against the same day-start value; it inherits the account percentage until
  someone sets it on its own.
- A trip **suspends** new entries until 00:00Z, reported as `breaker_account` or `breaker_engine`.
  Settlement and exits continue. A trip is never a halt.
- Three trips in `canary.KILL_WINDOW_DAYS` (7) days (`canary.KILL_TRIPS`, 3) is the kill criterion
  (`kill_criterion`), and that one does halt.
- An unknown day-start value means no entries (`breaker.DAY_START_UNKNOWN`, reported as
  `day_start_unknown`), shown as "Not reported".
- The breaker can only add a stop. A tighter `policy.HARD_MAXIMA` term still applies where it is tighter,
  and the surfaces always name whichever limit binds.
- The runner evaluates the rule in one place per account, `breaker.breaker_room`, called from the
  pre-trade reservation.
- The account numerator is the account's net portfolio loss since the day start, realized plus open mark
  to market, across the whole account. It is never the sum of the losing engines.
- The engine numerator is that engine's attributed realized loss plus its open mark to market.
- Foreign or unknown venue quantity is valued at the venue mark and counts as admission consumption only,
  never as breaker loss. An account suspension whose binding term is foreign consumption is reported under
  the canary suspend code foreign_exposure (one of `canary.SUSPEND_CODES`) and never counts toward any
  engine's three-trip kill criterion. That code is not in `engine_reasons.REASONS` yet; canary words it
  itself.
- A deposit or a withdrawal moves the day-start basis by its amount, because it is a cash movement, not
  profit or loss.
- The UTC midnight reset clears the day's loss count, and it never erases unresolved exposure.
- "A one-contract probe never trips at 50 percent" is a modeled expectation, not an invariant. Repeated
  losses accumulate within the day, and the meter shows them.

### The reversal transaction's venue orders (H2a2, mode 2)

Every order the cashout-first reversal transaction sends (each reduce-only exit attempt and the hedge, with
its one retry) is a good-till-time limit order, never an IOC: `time_in_force` `good_till_canceled` plus
`expiration_time` = submit time + `kalshi_reversal_txn.ORDER_TTL_S` (unix seconds), the only combination
Kalshi's Create Order (V2) documents for an expiring order
(<https://docs.kalshi.com/api-reference/orders/create-order-v2>: "To place an expiring order, set
`time_in_force` to `good_till_canceled` and provide this `expiration_time`", and "The `immediate_or_cancel`
time-in-force value cannot be combined with `expiration_time`"). The venue enforces the expiry, so such an
order may rest for a few seconds; a send whose reply still shows contracts remaining is UNKNOWN and is
settled from order status. Kalshi's order listing carries no server time, so a "no such order" answer is
never a confirmed zero on its own. A leg settles only when every id it could have sent is positively resolved
by order status and fills by client id, or when its primary id alone filled the whole leg (then an unused
retry id needs no timestamp). Anything short stays UNKNOWN, holding its market and its cash reservation,
until the venue resolves it or the operator clears it through the approval-gated clear command, never on a
timer.

## Evidence and the verdict

Replay, paper and shadow results are **offline tuning (simulated)**. They help pick parameters. They are
never a verdict and never promote an engine. `engine_lab.PROMOTING_PROVENANCE` is `live_fill`: the Engine
Lab offers an engine descriptor (still disabled) only from a passing report whose provenance is `live_fill`,
meaning a live trial scored by the ledger scorer. The gate walks every report item for the candidate: the
first one that is not `live_fill` refuses, and a passing candidate stays `shadow_only` with the reason
`engine_lab.OFFLINE_TUNING_REASON` naming that provenance (paper, replay or shadow). A report with no
provenance refuses too. `tests/test_lab.py` and `tests/test_push_engine_lab.py` prove a paper, replay or
shadow provenance can never promote, even beside live items.

The probe bar is frozen at probe start in `probe_bar.py`: quantity-weighted cents per contract after fees
(`probe_bar.METRIC`), paired calendar-block bootstrap with `probe_bar.RESAMPLES` (20000) resamples,
alpha `probe_bar.FAMILY_ALPHA` (0.05) divided across open probe trials, a count gate of
`probe_bar.COUNT_GATE_MARKETS` (100) markets and `probe_bar.MIN_BLOCKS` (4) blocks. Success is a one-sided
lower bound above `probe_bar.SUCCESS_LOWER_ABOVE_CENTS` (0); failure is a mean below
`probe_bar.FAILURE_MEAN_BELOW_CENTS` (-2 cents). Too little evidence is INCONCLUSIVE, never a kill.

The graduation gate adds `probe_bar.GRAD_MIN_TICKETS` (200) filled tickets, `probe_bar.GRAD_MIN_MARKETS`
(100) settled markets, `probe_bar.GRAD_MIN_DAYS` (10) complete UTC days, a maximum drawdown of
`probe_bar.GRAD_MAX_DRAWDOWN_CENTS` (2500 cents), at most `probe_bar.GRAD_MAX_BREAKER_SUSPENSIONS` (2)
breaker suspensions and `probe_bar.GRAD_MAX_INTEGRITY_STOPS` (0) integrity stops in the last
`probe_bar.GRAD_LOOKBACK` (7 days).

## Building an engine: tune, build, feed

Three paths make an engine. Every tuning tool below is offline tuning (simulated) and is never the verdict.

| Path | What changes | Tuning tools (never the verdict) | Gate before a probe |
|---|---|---|---|
| TUNE | policy JSON only, written by `engine_ops manifest init --template variant` | `scripts/kalshi_research.py` (walk forward) and `leafhft/shadow_continuous.py` | `engine_ops manifest freeze`, then `engine_ops try` |
| BUILD | a code kernel module, its test and a draft manifest | conformance over the pinned corpus | an operator promotion PR adds the `kernels.KernelPin`, then deploy, then conformance by the deployed code |
| FEED | a reviewed pair task adds a recorder and an `engine_feeds.FEEDS` row with status `engine_feeds.RECORDED_ONLY` | the tapes it accumulates | executor provisioning flips the row to `engine_feeds.LIVE_PROVISIONED` |

The FEED path is deferred (plan row F1). Until a feed is provisioned, `engine_feeds.feeds_live_provisioned`
returns every declared feed that is unknown or not live, and `probe` refuses such an engine by name.
Conformance runs `engine_conform.conform` over the pinned corpus `tests/fixtures/tapes/kalshi-mini-v1.jsonl`
twice, once under each seed in `engine_conform.HASH_SEEDS`, requires byte-equal receipts, labels its output
`engine_conform.LABEL`, and flags a near clone whose Jaccard overlap with a peer is above nine tenths
(`engine_conform.NEAR_CLONE`).

## What conformance proves and what it does not

`engine_conform.conform` proves that a kernel is pinned, deterministic across two hash seeds, bounded,
round trips its checkpoint and is new. Its two guards are hygiene checks. They are not a sandbox.

- The static guard (`engine_conform.static_guard`) refuses process, network, file and dynamic import
  modules, live clients and credential tokens in every kernel. A candidate kernel, meaning any source that is
  not a `KERNELS` entry's exact pinned bytes (a foundry lane or an `EXTRA_PINS` row included), is also
  refused every reflection name in `REFLECTION_NAMES` (`__globals__`, `__closure__`, `__self__`,
  `f_globals`, `_getframe` and the rest), the introspection modules in `CANDIDATE_DENIED_MODULES` (`gc`,
  `ctypes`, `inspect`, `dis`, `types`, `importlib`, `builtins`, directly or through `__import__`) and the
  guard's own private names. A pinned kernel keeps the base rule set because its pin is the control: the
  pinned Darkhorse kernel rebinds a function through `__globals__`, `__closure__` and `types`.
- The capability guard (`engine_conform.install_capability_guard`) runs in each replay child. It refuses a
  kernel that reaches for the file system, a process, the network, the environment, a thread or a frame by
  ordinary means, even when the kernel catches the refusal. Every shim is a bound method of a `__slots__`
  gate under an empty globals namespace, the table of originals leaves the module namespace once the child is
  armed, and `gc`, `inspect` and `dis` leave `sys.modules`. The receipt field `capability_guard` means
  "armed (hygiene)". The wire value does not change.

CPython reflection is unbounded. `__globals__`, `__closure__`, `gc.get_referrers`, `object.__subclasses__`
and `ctypes` can reach any object in the process, so no in process shim can make an original unreachable to
arbitrary kernel code. The capability guard therefore fails a kernel that reaches for I/O by ordinary means
and is a first line of defense in depth. It is not the security boundary.

The security boundary for kernel code is the operator's promotion PR plus the pinned bytes loader. A
`KernelPin` is added only by a reviewed PR, and adding `live` to it is a second reviewed PR (plan D3 and B7).
`kernels._PinnedLoader` then executes exactly the hashed bytes, so a later edit on disk never runs. A
conform receipt is evidence for that review. It never replaces it.

## Operator tooling

`python -m leafhft.engine_ops` is the one writer of engine assignment, probe and breaker state. Its exit
codes are the machine contract: `engine_ops.EXIT_OK` (0) for success, `engine_ops.EXIT_REFUSED` (2) for a
refusal with a named code, and `engine_ops.EXIT_INTERNAL` (3) for an internal error.

Every mutating verb in the legacy engine workflow (`registry init --apply`, `assign`, `release`, `probe`, `probe-activate`, `halt`,
`probe-size`, `graduate`, `retire`, `breaker set`, `exposure transfer`, `exposure quarantine`,
`exposure register`, `domain pause`, `domain resume`, `watch`) carries a `--request-id`, so a rerun of the same id completes the earlier write and never
duplicates it. It takes the engine_ops lock, then the registry lock, then the canary lock, always in that
order for the stores it uses. Replay-only `watch` uses only the engine_ops lock and never opens the
registry or canary for mutation. It appends a journal row, writes one receipt under the evidence directory
(`engine_ops.DEFAULT_EVIDENCE_DIR`) and prints `hot: engine <verb> applied; receipt <sha12>`.

Every risk-increasing verb in that workflow needs `--approval <id>`: a signed, single-use approval, never a free-text
reference. It resolves in the root-only store `engine_ops.DEFAULT_APPROVALS_DIR`, binds the verb's
arguments by digest and is consumed on use. `engine_ops approve` mints one from an operator's Telegram
reply, and kashbot-api mints one from an operator presence assertion.

The five `deploy` verbs are root-only and manage a separate document authority under
`/etc/leafhft-deployments`, with its writer lock and transaction records under
`/var/lib/leafhft-deployments`. This writer is dark behind `/etc/leafhft-deployments/ENABLED`:
`deploy apply` and `deploy settle` refuse while it is absent, and `deploy recover` leaves pending
transactions untouched. `deploy init` and read-only `deploy inspect` remain available. No live book
reads this document before P3; a committed transaction does not confirm live application.

`probe` checks the preconditions in `engine_ops.PROBE_PRECONDITIONS`, each a named refusal: the engine is
not assigned elsewhere, its identity is unique, concurrent probes are below the maximum, no owner policy
override exists, every feed is live provisioned, the manifest is conformed or waived, the lifecycle state
allows a probe, the domain is the exposure authority, the approval is valid, and the book is flat.

| Verb | What it does | Approval |
|---|---|---|
| `approve` | mints, lists, revokes or cancels probe approvals from one operator Telegram reply | none; it is the minting path |
| `assign` | binds an engine to one account and domain | signed approval |
| `breaker set` | sets an account or engine breaker percentage | signed approval only when the percentage rises |
| `breaker show` | prints the D5a loss breakers | none |
| `conform` | runs `engine_conform.conform` over `--corpus` for a policy or lane kernel and writes the conform record `probe` checks | none |
| `deploy init` | creates the empty generation-zero owner document for `--account`; identical initialization is idempotent | root only |
| `deploy apply` | test CLI applies a signed v2 plan from one root-private transaction input directory; the executor calls the Python API | root only; signed deployment decision |
| `deploy recover` | recovers at most 64 transactions per pass, recognizes prior commits and quarantines corrupt records; stops under containment | root only; retains the original approval |
| `deploy inspect` | lists transaction ids and states without mutation; accepts `--json` | root only |
| `deploy settle` | resolves a needs_operator transaction with `--finalize` or `--abandon` and a required `--reason`; abandonment keeps the approval spent | root only; finalization requires commit or ancestor evidence |
| `domain pause` | stops new entries across the domain; exits and settlements continue | none |
| `domain resume` | clears only the domain pause at the expected generation and nonce | device presence |
| `domain show` | prints the domain pause record, or absent, as JSON | none |
| `exposure quarantine` | sets the member's authority to null and every domain of the member exit_only | none |
| `exposure register` | adds one account: exit_only under `--member`, or a new member with `--attest` | signed approval (`--attest`) only for a new member |
| `exposure transfer` | prepares an authority transfer that the X4 step advances | signed approval |
| `graduate` | graduates a probe whose current verdict is GRADUATE_ELIGIBLE | signed approval |
| `halt` | stops new entries now; open contracts settle | none |
| `judge` | reads every probe's verdict (`--write` records it); exit 2 on a failed read or a KILL | none |
| `manifest freeze` | freezes an engine's manifest | none |
| `manifest import-legacy` | wraps catalog engines in manifests with a waiver | none |
| `manifest init` | writes a testable variant and its manifest in one command | none |
| `manifest show` | prints a manifest | none |
| `manifest validate` | validates a manifest | none |
| `probe` | starts a one-contract live probe | signed approval |
| `probe-activate` | activates the probe's trial | none |
| `probe-size` | moves a probe one rung up the 1, 2, 5 contract ladder | signed approval |
| `registry audit` | reports every violation class; exit 2 when any is found | none |
| `registry init` | builds generation 1 from every account's bindings (`--dry-run` or `--apply`) | none |
| `registry project` | rewrites the projection the books read from the current registry; recovery only | none |
| `registry show` | prints the current generation | none |
| `release` | removes an assignment | none |
| `repair` | reports an interrupted probe or release; `--finish` or `--rollback` settles it (C6e) | none |
| `repair-staging` | checks every owner probe's staging directory; dry run by default, `--apply --request-id <id>` creates missing directories owned by the book user as root; exit 0 on success, 1 for wrong ownership, unsafe paths, a missing user or a non-root caller | none |
| `retire` | retires an engine for good; retired is terminal | none |
| `status` | prints the status object | none |
| `try` | validates, pins and replays; exit 0 means probe-ready | none |
| `watch` | requests replay-only observation with `--book`, `--on` or `--off`, and required `--request-id` | none |
| `watch-status` | reads request-bound replay acknowledgements, optionally filtered by engine and `--book` | none |

Every verb in this table is registered in `engine_ops.build_parser`, and the doc test fails when a
registered verb is missing from the table.

`watch <engine_id> --book kalshi-book:<SYMBOL> --on --request-id <id>` requires a matching
baseline receipt with headroom. `--off` does not read a baseline. `--account` resolves an account
key or unique lane alias; tenants may watch only exact engine IDs in their domain projection.
Watch stores local requests in `<registry-dir>/watches.json`. `watch-status` reports `requested`
until the replay observer acknowledges that exact request and sidecar digest, then `applied` or
`rejected`. Unreadable acknowledgements report `unreported`.

`python -m leafhft.books.observer --book <SYMBOL> --runs <DIR>` reads completed recorded tapes
through the offline replay host. Its receipts and colour changes are marked `source: replay` and
live under `/var/lib/leafhft/observe-replay/<SYMBOL>/`. They grant no execution or live readiness.
SH4's separate live Watch, `watch-applied.json`, observer service and `/var/lib/leafhft/observe`
state retain their own protocol. The replay template `leafhft-observe@.service` is disabled and
absent from enabled lists. Combined and runner roles can select non-account templates; tenant
installation selects account-family or explicitly wanted sources. B10 does not install or start it.

## The status object

`python -m leafhft.engine_ops status <engine_id> --json` is the one shape (`engine_ops.engine_status`). The
runner pushes it, the dashboard and the phone render it, the assistant reads it. Unknown values are null,
never zero.

```
{engine_id, name, version, manifest_digest,
 kernel{kind, kernel_id}, inputs[], markets[],
 owner{kind operator|tenant, lane_id},
 assignment{account_id, domain, role, since} | null,
 enabled{global, per_account{}},
 lifecycle{state, entries_enabled, entries_suspended_until, stop_reasons[{code, text}],
           probe_started_at, expires_at,
           breaker{engine_pct, inherited, account_pct, engine_loss_cents, engine_limit_cents,
                   account_loss_cents, account_limit_cents, day_start_marked_cents}},
 evidence{conform_receipt, trial_id, verdict{state, read_kind, next_read_at, population}},
 pending_requests[{kind, state, requested_at}],
 next_step{code, text}}
```

`next_step` comes from one function, `engine_ops.next_step`, and its text is always the sentence for that
code in `engine_reasons.REASONS`. Every refusal, stop and suspension reason uses that same table, except
the two canary codes foreign_exposure and account_eligibility_expired, which canary still words itself: the
runner emits the code and the sentence, and no surface writes its own wording.

The book's own status file (`kalshi-edge-status.json`, not this object) carries `loop_lag`
`{schema, window_s, samples, p50_ms, p95_ms, p99_ms, max_ms, gaps}` from `leafhft.loop_lag`, null under 100
samples. It measures how late the 50 ms timer turn wakes against its intended period, inclusive of asyncio's
timer registration, in the perf_counter clock domain. Its `record()` hot path grows no container, retains no
object and never does I/O, takes a lock or awaits; it is not allocation-free, because CPython boxes the
integers it counts, and that boxing is bounded. Its cost is asserted as the per-call p99 over a same-thread
reference, a ratio, never as wall-clock nanoseconds.

## Controls

Three facts stay separate and are never merged into one switch:

- **Owner**: who may change the engine (the operator, or the tenant whose lane holds the assignment).
- **Assignment**: which account and domain executes it. Exactly one.
- **Toggle**: enabled per account (the existing engine configure `enabled` field), plus the lifecycle's
  `entries_enabled` for probes.

One action vocabulary across the CLI, dashboard, iOS and the assistant:

| Action | What it does | Approval |
|---|---|---|
| Enable | turn an engine on for an account | none (per-account toggle) |
| Disable | turn it off; open positions still settle | none |
| Assign | bind an engine to one account (`engine_ops assign`) | signed approval |
| Release | remove an assignment (`engine_ops release`) | none |
| Probe | start a one-contract live probe (`engine_ops probe`) | signed approval |
| Halt | stop new entries now (`engine_ops halt`); open contracts settle normally | none |
| Resume | probe again after a halt, with a new authorization | signed approval |
| Graduate | move a qualified probe to graduated sizing | signed approval |
| Retire | end the engine for good | none |
| Set breaker | set the account or engine percentage (`engine_ops breaker set`) | signed approval only when the percentage rises |

Every action carries a client request id, is idempotent, and shows as requested, then applied or rejected,
on every surface. A rejection shows the reason table's sentence.

Who may do what:

- The operator may do everything.
- A tenant may Enable, Disable and Halt only engines assigned to its own lane, and may set its own account
  breaker within its regime's clamp.
- Devices never Assign, Graduate or Retire.
- The assistant only proposes through a confirm card and never writes a control itself.
- Every risk-increasing action carries a signed, single-use approval, consumed on use.

## Rendering standard

The same words and colours in both apps.

- **Lifecycle chip**: draft slate, tested blue, probing amber, live green, suspended amber with the reset
  time, halted red with its reasons, retired muted. Colour is never the only signal; the chip always carries
  its word.
- **Account chip** beside every engine: the account it is assigned to, "Unassigned", or a red
  "Bound on 2 accounts" when the registry audit finds a conflict.
- **Breaker meter text** names the limit that binds, for example
  "-$12.40 of $1,250.00 (50% of $2,500.00) · UTC day". The meter reads the runner's numbers and never
  recomputes them.
- **Per-contract P&L always with n**: a per-contract figure is never shown without its sample count.
- **Freshness** comes from the row's `received_at`, shown on every number that can go stale. Missing values
  read "Not reported", never zero.
- The probe day is the UTC day, always labelled as such, with its reset time printed in Central time.

## Surfaces

The house rules hold on every surface: one rule per number, null is never shown as zero, colour is never
the only signal, and page times are in Central time. The probe day is the UTC day, always labelled, with its
reset time printed in Central time, and it is never mixed with the page's Central "today".

- **Engine Catalog**: every engine with its lifecycle chip, account chip, kernel and version.
- **Probe Board**: every live probe with its trial read and breaker meters. The account breaker meter comes
  from the runner's `loss_breakers` block and is never recomputed.
- **Engine detail**: one engine's status object, evidence, receipts and next step.
- **Markets**: the books an engine trades and what it holds in each.
- **Accounts**: each account with its assigned engines and its breaker.

Every surface that showed paper as a verdict is relabelled "Offline tuning (simulated)" or retired, and the
Engine Lab's promote action reads "Nominate for probe". The assistant reads the Engine Catalog and the Probe
Board and never writes a control row.

## Decision map

The letters are the decisions of the Kashbot engine plan; each maps to the sections of this file that carry
it.

| Decision | Sections |
|---|---|
| D1 | Vocabulary |
| D2 | The manifest (EngineManifest v1) |
| D3 | Kernels and the policy adapter |
| D4 | The registry |
| D5 | Lifecycle; Evidence and the verdict |
| D5a | The loss breaker (D5a) |
| D6 | Building an engine: tune, build, feed; What conformance proves and what it does not |
| D7 | Operator tooling |
| D8 | Surfaces; Rendering standard |
| D9 | Make an engine in three commands; The status object; Controls |
