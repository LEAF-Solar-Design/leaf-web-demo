# Offline first-probe reconciliation

This is the export-reconciliation slice of Kashbot `magpie-20260923`,
GAP-PROBE-ACCEPT. It joins the declared three-engine cohort to W1 watch exports,
C6/C6c approval exports and probe ticket exports. It does not collect evidence,
consume approvals, register a timer, deploy, change admission or authorize trades.

`evidence_ready` means the declared exports reconcile. It is not full oracle
acceptance. Every receipt keeps `oracle_state: incomplete` and these limitations:

* `signed_approval_verifier_deferred`: no signed-approval verifier is integrated.
* `disabled_baseline_proof_deferred`: W1 cannot attest that probes stayed disabled
  throughout the baseline. A caller-authored boolean is not such proof.
* `deployed_source_unverified`: W1 copies a SHA claim. It does not independently
  establish the executable that produced each book status.
* `counter_continuity_unverified`: monotonic sampled counters do not prove that
  a process did not restart between samples.

The runner owner retains baseline collection, bindings, approval execution,
deployment, restarts, rearming and the actual watch. Widening, Stage B, external
promotion and dashboard/phone comparison remain separate gates. This report
grants no execution, deployment, widening, credential or spending authority.

## Invocation and publication

Copy the evidence into a local export directory first. Do not point this tool at
a live runner or credential store. Supply paths relative to that export root;
there is no recursive discovery. Create the output directory separately.

```text
python -m scripts.probe_accept --export-root C:/tmp/probe-export --manifest manifest.json --receipts-dir C:/tmp/probe-receipts
```

The CLI reads only the named manifest and its declared files. It writes one
`probe-acceptance-<sha256>.json` through
`approve_presence.publish_exclusive(..., keep_existing=False)`. The digest covers
the complete deterministically serialized receipt. An identical rerun reuses the
same bytes, even after approvals expire. A collision never overwrites a file.
There is no latest pointer, overwrite switch or replacement W1 verdict.

Exit codes:

| Code | Meaning |
| --- | --- |
| 0 | A receipt with `reconciliation_state: evidence_ready` was published or reused. |
| 1 | An `incomplete` or `refused` evidence receipt was published or reused. |
| 2 | Invalid invocation, unsafe boundary or failed publication. |

`incomplete` names missing or unreadable evidence and coverage gaps. `refused`
names contradictory scope, conflicting observations, future evidence or adverse
observations. Both retain available evidence and null affected metrics. Neither
state changes any live control. The unchanged `probe_watch.judge` result is
embedded as `watch_verdict`; its nested `accept` value is only W1's verdict.

`build_report(manifest_bytes, evidence_by_relative_path, now=aware_datetime)` is
a deterministic computation over the supplied bytes. Values in the evidence
mapping are exact file bytes or `None` for an unreadable source.
`main(..., clock=callable)` provides clock injection. No generation timestamp
enters the receipt, so historical reruns remain stable. The cold-import residual
for validated approval exports is described below.

## Ingestion shape gate

`SHAPES` in `scripts/probe_accept.py` is the single accepted-shape table for the
manifest, baseline, ticks, book executor views, completed operations and their
arguments/results, approvals, presence sidecars, consumer markers, ticket kinds
and nested attribution. Every record passes `shape_issues` before reconciliation
uses its fields. Required members must exist. Objects, lists, strings, booleans
and integers are distinct types. Symbols must be lists of unique nonempty
strings. Event counters must be nonnegative integers; booleans never count as integers.
Actual ticket quantities use JSON numbers. Sealed requested
quantities use the producer's decimal-string format. Neither admits booleans,
negative quantities or nonfinite quantities.

Optional unused measurements, such as request rates and entry-suspension times,
may be null where the producer emits null. Required evidence cannot use null as
a clean zero. Optional extension members, including `economics`, are validated as
bounded JSON and then discarded at ingestion. They do not affect acceptance.
Attribution seals are checked over the original fields before projection, so
discarding an unused input cannot hide a broken seal. An unsupported signature
is retained only as a presence marker and keeps signed counts unknown.
All ticket records, including non-buy records,
reject unsupported schema fields before kind-based exclusion. The ticket dispatch
table accepts `buy`, `adopt`, `exit`, `settle`, `void` and `unsettled`, with each
kind's required producer fields checked before exclusion. Settlement exports use
the `SettlementPoller._ledger_row` shape. An unrecognized kind, including the
nonproducer spelling `settlement` or an unsupported `reversal` export, produces
`unsupported_ticket_kind` and an unknown record. Signature exports have no supported verification
shape and cannot establish a signed approval count.

A rejected record produces `invalid_record_shape` and field-specific reasons.
It never enters the joins, W1 judge or metric calculations. Rejected W1 records
null the dependent window totals and W1 verdict. Rejected ticket records retain
their unknown/exclusion counts, while valid buys still contribute to the
observed subset. Any finding prevents `evidence_ready`.

Repeated facts must agree across all representations. A contradiction produces
a named reason and null dependent metrics, even when the remaining observations
still meet the cadence threshold. Missing identity mappings likewise produce
null affected counts, never a definitive zero.

The shape table names its producer locations. Presence cards require
`text_sha256`, an SHA-256 string emitted by `engine_ops`, rather than a boolean
or a caller assertion. Persisted buy and adoption rows require the settlement
minute added by `SettlementPoller._append_row`. Persisted reduce-only exits include
`entry_reason` when `exit_reason` is present; ordinary exits omit it
(`kalshi_book.py:1816-1821`). Fill-basis buys/exits also require `intent_price_cents`.
Conditional transaction and reduce-only fields must appear together. Fields
that the producer genuinely omits on some branches stay optional; the tool does
not invent evidence to fill them. Nullable request measurements stay distinct
from missing fields.

Executor engine IDs, manifest engine IDs and binding symbols, and notification
classes must be unique within their containing list. A repeated identity is
`ambiguous_record_identity`, even if one row would hide a counter decrease.
Conflicting exported approval/operation identities and ticket identities remain
errors. Identical tick and ticket exports can still be deduplicated. Non-buy
ticket conflicts are checked before those records are excluded from entry counts.

The clock check precedes ticket-kind dispatch. It checks event timestamps on
every record, including adoption, exit, opening and settlement timestamps, and
presence card/reply dates. It uses integer nanoseconds for ticket times, so an
out-of-range future value cannot overflow a date conversion or disappear behind
the non-buy branch. Expiries and deadlines are not event times.

Producer-derived facts must agree: normalized operation expiry with approval
expiry; the operation's copied engine, account, symbols and binding with its
scope; the presence delay with the card/reply dates; W1 probe and request-demand
summaries with executor views; venue-429 totals with request demand; notification
keys with SHA/class; and ticket settlement minute with sealed attribution.
Persisted reduce-only exits must also retain the writer's true flags and copy
`exit_reason` into `reason`. Transaction legs must match the buy or exit branch.
These checks supplement the existing journal, disturbance, latch and allowance
checks. Contradictions produce named reasons and null dependent metrics. The
unexported registry/trial records still limit independent verification of a
result's registry generation and trial ID.

The entire ingestion pass finishes before approval reconciliation imports
`engine_ops`. If any export fails ingestion, approval reconciliation is deferred
with `approval_validation_unavailable` and null approval counts. This deliberately
avoids importing runner dependencies to reconcile a partially validated set.
Manifest validation and timestamp parsing use only the standard library.

Known Windows stdlib residual: valid exports require the existing
`engine_ops.approval_digest` helper. Its first import can pull in `aiohttp` and
call `platform.system`, which may run `ver` on a cold Windows interpreter. This
slice cannot remove that transitive import without changing an unowned producer
module or copying its digest implementation. It does not patch or suppress the
call. Importing this tool and rejecting malformed shapes do not need that
module. No report path invokes a trading handler, network request, credential
read or notification. The cold-builder regression uses a fresh interpreter and
fails on process or network calls while rejecting malformed exports; it does
not patch `platform.system` or rely on pytest's cached runner imports.

## Manifest schema

The manifest is strict JSON with schema
`leafhft.probe-acceptance.manifest.v1`. The following example abbreviates the
192 tick paths only in prose; an actual manifest must enumerate each path.

```json
{
  "schema": "leafhft.probe-acceptance.manifest.v1",
  "program": "magpie-20260923",
  "source_sha": "daf140344683337d7c97759c34fd315c6683d444",
  "registry_account_key": "owner",
  "execution_account_digest": "<64 lowercase hex characters>",
  "baseline": {"start": "2026-09-22T12:00:00Z", "end": "2026-09-23T12:00:00Z"},
  "watch": {"start": "2026-09-23T12:00:00Z", "end": "2026-09-25T12:00:00Z"},
  "required_book_units": [
    "leafhft-live@kalshi-btc-15m.service",
    "leafhft-live@kalshi-btc-1h.service"
  ],
  "engines": [
    {"engine_id": "probe-a", "policy_digest": "<expected policy digest>", "binding": "cohost",
     "bindings": [{"symbol": "BTC-15M", "unit": "leafhft-live@kalshi-btc-15m.service", "market_series": "KXBTC15M"}]},
    {"engine_id": "probe-b", "policy_digest": "<expected policy digest>", "binding": "cohost",
     "bindings": [{"symbol": "BTC-1H", "unit": "leafhft-live@kalshi-btc-1h.service", "market_series": "KXBTCD"}]},
    {"engine_id": "probe-c", "policy_digest": "<expected policy digest>", "binding": "cohost",
     "bindings": [{"symbol": "BTC-15M", "unit": "leafhft-live@kalshi-btc-15m.service", "market_series": "KXBTC15M"}]}
  ],
  "c6c_exception_reference": "<existing exception reference, if supplied>",
  "sources": {
    "baseline": "baseline-daf140344683.json",
    "ticks": [],
    "approvals": [],
    "presence": [],
    "consumptions": [],
    "operations": [],
    "tickets": [],
    "signatures": []
  }
}
```

Replace placeholders with evidence-derived identities and enumerate the source
files. Empty required groups produce incomplete evidence. `signatures` is
optional and reserved for supplied signature exports: no supplied signature
format is verified by this slice, so its presence makes the signed count unknown.
The optional C6c exception reference is preserved verbatim as evidence; it does
not mint, renew or expand authority.

Keep these identities separate:

* `registry_account_key` is the C6 registry account used by the probe operation.
* `execution_account_digest` identifies the actual execution principal sealed in
  ticket attribution, using `leafhft.attribution.account_digest`.
* Each binding names the book unit, symbol and market series. These are declared
  mappings, not identities inferred from the observed tickets. The symbol and
  unit must agree. Supply the series from that book's actual producer binding.
* `policy_digest` is each engine's expected policy identity from the declared
  deployment. Never copy the digest from a ticket to make that ticket qualify.
* Optional `engines[].fixed_count` declares the expected count as a finite decimal
  string on the `0.01` grid, from `"0.01"` through `"1.00"`, inclusive. Absence
  means `"1.00"`. Explicit zero, null, booleans, JSON numbers, nonfinite values,
  off-grid values and out-of-range values fail with `invalid_fixed_count`.
  The expected count is never inferred from tickets.

`fixed_count` is a caller-declared reconciliation expectation. The reader receives
no policy document. Matching `policy_digest` declarations and ticket seals do not
independently prove that a count belongs to that policy. Approval sizing remains
`"1"`, with its existing digest and scope checks. The count declaration grants no
fractional execution authority. Policy publication, approval-format changes,
producer integration, signed probes and live fractional probes remain with their
owners and applicable operator authorization.

Missing account or policy mappings are named unresolved criteria. A missing
execution-account digest nulls entry counts for every engine in both windows.
A missing policy digest nulls those counts for that engine only, including the
observed-subset count, because its tickets cannot be attributed to the policy.
Exactly three
distinct string engine IDs are required; other types are invalid invocations.
The manifest source SHA must be a string of exactly 40 lowercase hexadecimal
characters. Numeric SHA values are invalid invocations and return exit code 2.
Every engine gets baseline and watch rows,
even when it never appears in W1's observations.

## Time, coverage and shared metrics

The declared baseline is `[start,end)` and at least 24 hours. The watch starts
immediately at baseline end and lasts at least 48 hours. Baseline `since`, `at`
and `window_s` must agree with these declarations. Tick observations use
`(watch_start,watch_end]`; ticket entries use `[watch_start,watch_end)`, with exact
integer nanosecond comparisons. `watch_start == baseline.at`. Evidence in the
future relative to the injected clock cannot establish readiness.
Both declared windows are limited to 14 days. A window end more than one day
after the injected clock is rejected. These bounds run during manifest validation,
before parsing exports or materializing coverage interval IDs. An invalid window
raises a named `Invalid` error and the CLI returns 2 without publishing a receipt.
Ends within the one-day bound still cannot establish readiness while in the future.

W1's journal producer uses inclusive collection bounds. These exports cannot
resolve events exactly on a journal boundary; this report preserves W1's
aggregate counts and does not claim an independent event-level baseline proof.

Ticks are sorted and deduplicated by baseline identity and timestamp. Identical
parsed observations count once; conflicts refuse reconciliation. Out-of-window
ticks are excluded. Every valid in-window observation is examined for adverse
evidence, including extra observations within an already covered cadence slot.

Coverage uses W1's 900-second cadence and 75% threshold. Each right-closed
cadence interval contributes at most once. Required book components must be
readable with integer `0 <= age_s <= 1800`. An observation must reach the exact
watch end. Missing components cannot contribute clean coverage. Dense ticks at
the end of the watch cannot substitute for observations across the watch.
The expected interval set comes from the declared watch bounds, independently
of the listed tick files. `missing_intervals` lists uncovered zero-based slots.
`coverage_complete` means at least 75% of these intervals are covered and a valid
observation reaches the watch end. A 48-hour watch needs 144 of 192 intervals.
Missing slots remain listed, but do not create a coverage finding within this
allowance. Falling below the threshold, missing the end observation, or supplying
unreadable, malformed or conflicting observations nulls watch totals and latch
conclusions. This is sampled coverage, not proof of continuous observation.

Shared rows preserve book scope for disturbance and engines-lane latches, and
class/unit scope for journal counters. The aggregate journal scope is explicitly
`journal:all_exported_books`; the exports do not establish per-account or
per-engine causation for this aggregate. Engine rows reference shared metric
IDs; they never divide or copy shared counts into per-engine causal counts.

W1 journal unit maps are sparse. An absent unit in a readable complete journal
map means no matching refusal was counted. An absent book status, unreadable
journal, missing class counter or skipped journal line is a gap, not zero.
Stale-snapshot allowances use `ceil(baseline_count * elapsed / window_s)`;
deltas use `max(0, observed - allowance)`. Supplied derivatives must agree.

Repeated process-cumulative snapshots are never summed. Rows retain initial,
final, sampled maximum and sampled delta. Decreases or missing components make
the affected window delta null. These are sampled deltas only: the exported W1
schema lacks process identity, so continuity remains a full-oracle limitation.
Every observed cumulative counter is checked across chronological ticks, including
executor-engine and aggregate-probe fills and refusals, journal counts by class,
unit and market, journal source counts, disturbance, latch events and request
read/write/error counters. Client counts, rates, ages and derived allowances or
deltas are not cumulative counters. Decreases record one `counter_reset` per
counter key, retaining the first reset's scope and timestamp plus `first_tick`,
`last_tick` and `reset_count`. Repeated decreases extend that summary rather than
adding one finding per tick. A reset invalidates coverage even
when the remaining slots exceed 75%, and dependent watch totals become null.
Disappearing observed components retain named gaps; later observations are still
compared with the last known counter so a gap cannot hide a reset.
Each missing counter component produces one `counter_component_missing` finding
with `first_tick`, `last_tick` and `missing_tick_count`. Separate gaps for that
component share the finding. Tracking visits present keys and closes trailing
gaps once, so sparse keys do not multiply findings or retained memory by the
number of later ticks. Regressions cover 8,000 disappearing market keys and
2,000 refusal keys, and 4,000 market keys resetting 96 times each, with bounds on
report bytes and incremental memory.
Disturbance totals must equal the exported book counters. The supplied incumbent
and lane-refusal deltas must equal the increase over the baseline totals.
Contradictions produce `counters_disagree` and null affected disturbance totals;
raw sampled values remain available as evidence.
Journal class totals must equal the sum across all exported units. Market counts
may be smaller, because some journal messages contain no ticker, but cannot
exceed their class total. Contradictions null the affected journal class metrics.
The latch-unit list must equal the books whose flag is true or whose event count
grew over baseline. The aggregate latch delta must equal that list's length.
Contradictions null the dependent watch latch conclusions and counter deltas.
Observed incumbent refusals, positive disturbance changes, stale-snapshot
excesses and engines-lane latch evidence prevent evidence-ready reconciliation.
Nested engine and probe refusal counters must be non-negative integers. Malformed
counters or timestamps, including UTC conversion overflow, produce named gaps
and null affected window totals.

Optional canonical-status fields, including `economics`, are accepted but do
not determine probe acceptance. Existing W1 verdict behavior is not changed.

## Approval and entry joins

Approval documents use the existing C6 document shape (no schema field).
Consumption markers likewise use their existing schema-less shape. Presence
sidecars use `leafhft.engine_ops.presence.v1`; completed operation receipts use
`leafhft.engine_ops.receipt.v1` with `verb: probe`.

Approval ID and payload digest join document to sidecar. The sidecar request ID
is the approval-card request. A marker's request ID is the consuming operation
and must equal the completed receipt's request ID; it need not equal the card
request. The receipt subject, result account/engine/symbols/binding, approval
argument and code SHA must agree with the declared cohort and approval scope.
The consuming operation's `args.code_sha` must match the manifest SHA. A presence
card's `code_sha` is an unbound checkout claim from the card producer and need not
match the consuming operation. The exported nonce and every reply token must be
valid six-character Crockford nonces. A missing nonce cannot match a reply.
The reply sender and chat must both equal the approving operator identity.
The probe contract supplies sizing `"1"`; the operation does not have a sizing
argument. `approval_digest` is recomputed from that actual scope.

Expiry is checked at recorded consumption, including the minimum probe window
unless `oq_only` applies. Card, consumption and completion times are retained
separately, including whether consumption was in the baseline, watch or outside
both. Each approval counts once. Conflicting consumers or scopes are errors.
Each declared engine needs a reconciled consumed identity-grade probe approval.
Any failed approval, sidecar, consumer or operation join makes the identity
approval total and engine approval counts null, rather than reporting a known
zero or a partial total as complete. Successfully matched rows remain available
when all inputs passed ingestion and a later semantic join failed.

Presence sidecars that share one card `message_id` or one reply `update_id` are
one batch. The producer copies the card, reply, card request ID, bot, operator,
host, code SHA and prompt timing into every sidecar of a batch and mints a
distinct nonce per row (`leafhft/engine_ops.py` about :5218 and :5383-5396). A
copied field that differs inside a batch is `presence_batch_contradiction`; a
nonce on two sidecars is `presence_nonce_reused`. Both refuse reconciliation and
no approval of that batch is matched.
Approvals in one batch also share the mint moment embedded in their IDs and
one expiry. A mismatch is `approval_batch_time_contradiction`.

Completed probe steps are `registry`, `lifecycle`, `trial`, the binding step,
and `approval`, in that order. The producer may insert `overrides` after
`trial`. The binding step is `probe_bindings` for cohost and `bindings` for
displace. Receipt time equals consumption time unless the result contains the
producer's `repaired` record. This record is retained and shape-checked.
`args.displace` is absent or true; an explicit false is a contradiction.

Matched `tg1-` exports are identity-grade only. Three such known records yield
three identity approvals and zero signed approvals. A payload hash or
`signed: true` never proves a signature. Unreadable or unsupported signature
evidence makes the signed count null. Export reconciliation cannot re-attest
Telegram presence or replace the deferred signature verifier.
This includes signature evidence on a document missing its approval ID; losing
the join identity cannot turn an unsupported signature into a known zero.

Tickets must be the actual probe ticket JSONL exports. Only `kind: buy` records
can qualify. `attribution_or_unknown` checks the sealed attribution. Account,
engine and expected policy must match the manifest. Ticket ticker and side must
agree with attribution and the declared market-series binding. Both actual
filled `count` and sealed `sizing_inputs.requested_count` must equal the engine's
declared expected count, using exact Decimal equality. Fractional fills are not
combined; a requested-two/filled-one partial does not
qualify. W1 lifetime fill counts, adoption rows and settlements are not entries.

`count` is a JSON number, as `_count_number` writes it (`kalshi_live.py` :781):
an integer token for whole contracts, a decimal number token for hundredths. Strings such as `"1"`,
`" 1 "`, `"1e0"` and `"01"`, and a float with a whole value, are
`invalid_ticket_count`. A buy's `opened_ns` is required and, on the probe lane,
equals `ts_ns` because one `now_ns` reaches both `KalshiBook.buy` and
`record_buy` (`kalshi_live_runtime.py` about :4497 and :4515). For a one-contract
buy the price fields follow `KalshiBook.buy` (`kalshi_book.py` about :1330-1358):
with fill basis, `cost_cents == price_cents + fee_cents` and `intent_price_cents`
equals the attribution's limit price; with intent basis the unlaned
`record_buy` writes `price_cents == cost_cents == limit + fee`, while a laned
incumbent book keeps `price_cents == limit`. Probe buys cannot carry `lane`.
Intent basis never carries
`intent_price_cents`. A mismatch is `derived_field_contradiction`. A watch
entry's settlement minute (equal to the attribution cluster minute) must lie in
`[watch_start, watch_end + 1 day]`, else `settlement_minute_outside_watch`.

Fractional fill-basis buys require `cost_cents >= fee_cents`. Their displayed
price is `(cost_cents - fee_cents) / count`, rounded half up to an integer cent.
Their `intent_price_cents` still equals the sealed market price. Fractional
intent-basis buys retain the producer's rounded estimates:
`cost_cents - fee_cents == ceil(sealed_limit_price * count)`. Unlaned intent rows
display `floor(cost_cents / count)`; laned incumbent rows display the sealed
limit price. Cohort probe rows remain unlaned. The `price_basis` discriminator
keeps intent estimates separate from fill-basis exported accounting.

For fractional fill-basis buys and settlement-kind rows, exported cost, fee,
payout and PnL may be JSON number tokens with up to four decimal places in cents,
equivalent to six decimal places in dollars. Integer cents remain supported.
PnL may be negative; cost, fee and payout may not. Strings and booleans are not
money. Whole-count monetary fields, intent estimates, timestamps, event counters
and displayed prices retain their integer-only requirements. Actual counts and
supported money fields are parsed directly from raw JSON tokens into Decimal
before any float conversion. Thus `0.0100000000000000001` is an invalid count
and `0.0168000000000000001` is invalid money, even if a float would hide the
excess precision. Money errors are named `invalid_ticket_money`.

Settlement rows must copy their linked buy's exact cost and fee. A winning
settlement pays `100 * count` cents; a losing settlement pays zero. Voids refund
cost. PnL equals payout minus cost, except that unsettled payout and PnL remain
zero. Settlement display price retains the producer's `floor(cost / count)`
rule, which includes fees and can differ from the buy display price.

The supplied fee is used without a whole-cent fee model. For example, a
fill-basis count of `0.01`, displayed price `40`, fee `0.0168` and total cost
`0.4168` reconcile with a winning payout of `1` and PnL of `0.5832` cents.
The precise-money fixtures define a new reader contract, not proof that current
producers emit those tokens. The current broker rounds fractional accounting
and accepts venue overrides only as integer cents. This reader cannot recover
precision already lost upstream. Export consistency does not authenticate a
venue fee or detect every coordinated alteration of all its exported copies.
Missing evidence stays missing and never becomes a modeled fee or cost.

Exact working numbers do not enter the report's JSON representation. Numeric
attribution extensions retain their existing JSON float representation for seal
verification. Duplicate-key, nonfinite, depth, byte and record limits still apply.

Settle, void, unsettled, exit and adoption rows are compared with every buy that
shares their `client_id`. Ticker, side, attribution, reason and `opened_ns` are copied
from the buy's ticket (`kalshi_book.py` about :1507-1512 and :1835-1856), so any
difference is `ticket_cross_record_contradiction`. Exits reduce the ticket; the
sum of exit counts may not exceed the buy, each settlement-kind row must carry
the remainder for non-probe tickets. A probe buy cannot have an exit or adoption
row at all. A contradicted buy is an
unknown record: it never counts and entry totals become null.
An exit with a producer-form probe client ID, or cohort probe attribution on
the execution account, is refused even when its buy is absent from the export.
An unlinked adoption of a probe's own recovered intent remains valid.

An entry qualifies only when its engine has a reconciled approval whose
consumption marker and completed probe receipt both precede the entry's `ts_ns`
and whose expiry follows it; otherwise `entry_before_approval_consumption`
refuses reconciliation. When approval reconciliation is unknown, every entry
total is null with `entry_authority_unknown`; the observed subset remains.

Every declared engine must appear in each W1 tick as `role: probe` on each of
its bound book units, in a lifecycle state `probe` or `probe_sized`
(`canary.py` :63), with `entries_suspended_until` absent or not after watch
start. Reasons are `cohort_engine_not_observed`, `cohort_engine_role_mismatch`,
`cohort_engine_wrong_unit` and `cohort_probe_latched_or_suspended`. Missing or
mismatched rows refuse when a buy or a probe receipt claims that engine traded,
and are incomplete otherwise. A probe row whose engine is outside the cohort is
`undeclared_probe_engine`.

Buy records deduplicate across all files by `(account_digest, client_id)`.
Identical parsed records count once. Conflicts under that identity refuse
reconciliation and do not count. Excluded and unknown records retain named
counts. Baseline entries are reported separately and never satisfy watch fills.
Any cohort probe buy or approval consumption within the declared disabled
baseline is a contradiction, even if watch entries and approvals are complete.
If buy identity is unknown or conflicting, or a buy has a malformed quantity or
timestamp, the complete entry total is null with a named reason;
`observed_one_contract_entries` retains only the known qualifying subset.
`one_contract_entries` and `observed_one_contract_entries` are legacy field
names. They now count qualifying entries at `expected_count`, a canonical
two-decimal string on each engine metric row. These totals remain integer event
counts, never sums of contract quantities. Existing `not_one_contract_entry`
and `one_contract_entry_missing` diagnostics likewise retain their legacy names.
Null, boolean, nonnumeric, negative and nonfinite quantities are unknown evidence,
not ordinary partial-fill exclusions. A timestamp must be a non-negative integer.
Missing or malformed ticket kinds produce `invalid_ticket_kind`, an unknown
record and null entry totals. They cannot be classified as `not_buy`. Malformed
ticker and side fields likewise produce named unknown records.

## Parsing and filesystem limits

Limits are 8,192 declared source files, 4 MiB per file, 64 MiB total including
the manifest, 256 KiB per JSONL line and 64 nested JSON levels. Records are
bounded at 100,000 per source (`jsonl_record_limit`, a named source failure) and
200,000 in total (`record_count_limit`, an invalid invocation). Both bounds are
computed from raw line counts before any line is parsed or retained, so retained
state contains declared fields rather than decoded copies of unused extensions.
One regression shares a roughly 3.8 MiB input among 15 declared duplicate ticks
and bounds incremental `tracemalloc` peak memory below four times that buffer.
Duplicate JSON
keys, unsupported producer schemas, nonfinite numbers and booleans used as
counts cannot establish clean evidence. Input hashes cover the exact bytes
parsed, not a normalized reserialization. An unreadable input has a null hash.
`input_hashes.manifest` holds the manifest hash. `input_hashes.sources` maps each
relative source path to its hash, so a source named `manifest` or `sources` cannot
overwrite another input's identity.

Source paths must be relative to the explicit local export root. Both the export
root and the existing receipt directory have their complete directory chains
checked. UNC/device paths, alternate streams, symlinks, Windows reparse points
and nonregular source files are rejected. Existing output destinations must be
regular files. Output basenames are internally derived from content. Publication
uses the existing atomic exclusive helper. The tool runs on a single-tenant
operator host over exports written by this repository's own tooling. Another
local principal swapping a checked source or receipt directory for a symlink or
junction between check and use is outside this threat model. The pre-use checks
remain required; they do not bind later I/O against such a concurrent swap.

## Verification handoff

The pair planner runs the amended verification command from the dedicated
worktree. The executor does not execute tests. Report test execution separately
from collection and identify platform skips, including systems where symlink
creation is unavailable.

```powershell
python -B -m pytest tests/test_probe_accept.py tests/test_probe_watch.py tests/test_probe_widen.py tests/test_engine_ops.py tests/test_engine_ops_approve.py tests/test_probe_runner.py tests/test_kalshi_book.py tests/test_push_engine_rollup.py tests/test_kalshi_shadow_continuous.py -q -p no:cacheprovider -p no:xonsh --capture=sys --basetemp="C:/tmp/wt-w2-probe-accept-tmp/pt-$PID"
```

The new fixtures reuse W1 status fixtures and real attribution/approval digest
helpers. The regressions cover historical expiry, request namespaces, cumulative
counters, cadence coverage, fill identity and quantity, malformed evidence,
filesystem containment, create-only replay and external-action spies. No sibling
assertions or live producer paths are changed.
The named shape regressions include object-valued symbols, boolean journal
counts and string-valued executor engine lists. Coverage exercises exactly 75%
and one interval below it. The conflicting-consumer case includes two real
operation receipts, so replacing conflict detection with last-record-wins
indexing cannot satisfy that assertion.

The producer mutation matrix starts from a complete, evidence-ready export set
with populated sparse maps, nullable records, notification rows and every
supported ticket kind, including emitted lane and transaction fields. It removes
every required field, tries each wrong JSON
type independently, and inserts conflicting identities into each list of
records. Producer-optional fields get type checks when present; removal is
tested when their producer discriminator requires them. Removing a truly
optional field is not fabricated into a failure. Each concrete fixture field
must have a shape-table declaration, so removing a declaration cannot silently
shrink the matrix. Same-type expiry contradictions and future adoption times are
also matrix cases, as are a buy `opened_ns`, cost or intent price that breaks its
producer relation, settlement and adoption rows that disagree with their buy,
and a presence batch with a differing host or a reused nonce. The producer
fixture's exit and adoption belong to a recovered incumbent ticket. Its void
and unsettled rows have separate identities from the settled buy. Separate
regressions reproduce the hidden executor decrease
and check unknown dependent counts. The original counter-reset regression now
sets the producer-derived venue-429 total in its positive setup; all of its
assertions remain intact.

## Derived-field reconciliation

`DERIVATIONS`, next to `SHAPES`, inventories the repeated and computed fields,
the producer file and line for each relationship, and the diagnostic each check
must emit. `test_derivation_matrix` covers every inventory row with a same-type
contradiction, a green control, and the row's named reason. Adding an inventory
row without a mutation fails the matrix inventory assertion. Shape rejection
alone cannot satisfy a different derivation's diagnostic.

Approval IDs use `tg1-<UTC moment>-<engine>-<lowercase nonce>`. The embedded
engine and nonce must agree with the approval and sidecar. The moment cannot
follow the card, reply or consumption. Expiry must be that moment plus the
producer's probe duration and an integral claim interval of 1 through 24 hours.
Sidecars with any shared prompt request, card message or reply update are one
batch. Their copied prompt fields agree and their reply tokens correspond
exactly to exported approval nonces. An unexplained token, missing join or
second approval set for the same cohort engine makes approval counts unknown.

Probe buys use `lp-<code>-<20 lowercase hex digits>` client IDs, where `code`
equals the first four lowercase hex digits of SHA256 of the attributed engine ID.
The match is case-sensitive. An adoption with cohort probe attribution on the
execution account must also use that engine's exact client partition, as
`adopt_own` scans only its own prefix.
Their decision ID must equal the producer hash over the client ID, account,
engine, policy, ticker, side, price, requested count and cluster minute.
Two distinct cohort probe buys on the execution account cannot share a decision
ID. These two decision checks do not apply to excluded incumbent or other-account
buys: a strategy can seal a dict deterministic key instead of a client ID.
A probe buy's reason is
`probe ` followed by its engine ID and equals its attribution reason. Matching
settlement rows copy their buy's cost and fees, derive price by integer division,
and follow its timestamp. A yes/no result determines a settlement payout; voids
refund cost. Realized PnL is payout minus cost, while unsettled observations
carry zero payout and zero PnL. Distinct settle and void rows cannot both be
terminal for one ticket. Identical re-exported rows still deduplicate. Missing
terminal rows do not invent a settlement: this report reconciles entry evidence,
not proof that every open ticket has already settled.
Unsettled observations cannot precede `opened_ns` plus the producer's default
3,600-second reporting delay or follow a terminal settle/void row for that ticket.

The market series must match the declared symbol. Settlement and attribution
close minutes must agree and cannot precede the buy's minute. The source drops
sub-minute precision when it writes `close_ms // 60000`; exports do not include
the venue market response. This report therefore cannot independently recover
the exact market close from a ticker or claim that it verified that response.

W1 cannot show an enabled cohort probe or a fill increase before its enabling
operation receipt. Each sampled fill-counter increase needs at least that many
distinct attributed buy rows on the same engine and book in the observation
interval. This includes fractional fills as events; only a fill matching the
declared and sealed requested count qualifies as an entry. Repeated cumulative
counters consume no extra buys. A
watch buy also needs a fill-counter increase in its interval; an extra buy with
an unchanged counter is `buy_without_fill_counter`. A
first sample after an in-watch enabling receipt starts from zero; an enabling
receipt predating the watch does not supply an invented lifetime-counter base.
