# Tenant owner risk regime

Kashbot account lanes stay guarded by default. After the runner deploy and the
operator's yes for one lane, a deploy executor can promote that lane's risk-size
caps. Lane identity, credentials, routing, exposure, loss breakers, halts and the
kill path retain their account-lane controls. POLICY_BOUNDS still apply.

Install the following exact text in BOTH files, replacing `<lane-id>` with the
approved lane ID:

- `/etc/systemd/system/leafhft-account@<lane-id>.service.d/owner-regime.conf`
- `/etc/systemd/system/leafhft-account-push@<lane-id>.service.d/owner-regime.conf`

```ini
[Service]
Environment=LEAFHFT_ACCOUNT_RISK_REGIME=owner
```

Both directories and files must be root-owned. Set each file to mode 0644. The
tenant lane user must never be able to write its unit or drop-ins. Only the exact
value `owner` is accepted. No other value promotes a lane, and the host setting
`LEAFHFT_RISK_REGIME` cannot promote it. These instructions are documentation
only; the installer never installs promotion settings.

Run `systemctl daemon-reload`. The deploy executor restarts the two lane units
in its post-install steps. The consumed one-shot LIVE-ACK then holds the lane
until the operator runs `kashbot_admin_restore` and
`start_live` from the dashboard. Never re-arm a tenant lane from the box or use
an ad hoc box restart to recover it. The dashboard re-arm is required after the
deployment restart.

To revert, delete both drop-ins, run `systemctl daemon-reload`, and use the same
deploy-executor restart and dashboard re-arm sequence. Without the drop-ins,
both the trading and push processes return to the guarded account regime.
