# Kashbot Live wire contract v1 (frozen by the planner, 2026-09-29)

This contract is shared by the iOS app (R1 to R3) and the ops-dashboard push sender (R4). The iOS side commits it verbatim as `docs/kashbot-live-activity.md` in leaf-hft. The golden vector is `ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/kashbot-live-golden.json`. Any change bumps `v`.

## ActivityAttributes: `KashbotLiveAttributes`

- Static JSON is `{"v":1}`.
- It has one stored property, `v: Int`, set to 1.

## ContentState: `KashbotLiveAttributes.ContentState`

- The type is Codable and Hashable.
- JSON keys are exactly the Swift property names. There is no key strategy, and neither side uses snake_case.
- Every time is integer epoch seconds. Every money value is integer cents. No floats and no ISO dates appear anywhere.

| key | type | meaning |
|---|---|---|
| `v` | Int | Always 1. |
| `asOf` | Int | Epoch seconds when the numbers were read. |
| `totalCents` | Int | Full portfolio value: Kalshi balance `portfolio_value` plus cash, i.e. `AccountBalance.accountValue`. |
| `todayCents` | Int | Sum of ledger P/L for settlements whose `at` falls in the current America/New_York calendar day. 0 when there are none. |
| `openCount` | Int | Number of open positions, which can be more than `rows.count`. |
| `rows` | [Row] | At most 3. Sorted by exposure descending, then by ticker ascending. |
| `ledger` | [Entry] | At most 4. Newest first by `at`, then by ticker ascending. |

### Row

| key | type | meaning |
|---|---|---|
| `ticker` | String | Truncated to 40 characters. |
| `label` | String? | The market's `yes_sub_title`, truncated to 32 characters. Omitted when unknown. |
| `side` | String | `"yes"` or `"no"`. |
| `milli` | Int | Absolute contracts x 1000, rounded half away from zero (for example 0.25 becomes 250). |
| `winCents` | Int? | Profit if right, defined below. Omitted when exposure is missing. |
| `oddsPct` | Int? | Market odds of the held side, 1 to 99, defined below. Omitted when there is no quote or the market is not open. |
| `state` | String | `"open"`, `"won"` or `"lost"`. `won` and `lost` apply only when the market has a `result` and the position is not yet settled. |

### Entry

| key | type | meaning |
|---|---|---|
| `ticker` | String | Truncated to 40 characters. |
| `pnlCents` | Int | Cash P/L. |
| `pnlBps` | Int? | P/L as a fraction of cost, in basis points, truncated toward zero. Omitted when cost is 0. |
| `at` | Int | Epoch seconds of `settled_time`. |

## Formulas (Decimal math throughout; convert to cents only at the end)

- **Contracts `c`:** `abs(position_fp)`. Side is `yes` when `position_fp` is greater than 0, `no` when it is less than 0. Positions with 0 are dropped.
- **Exposure `e`:** `market_exposure_dollars`.
- **Fees `f`:** `fees_paid_dollars`, or 0 when absent.
- **winCents:** `floor((c x 1.00 - e - f) x 100)` (floor toward negative infinity). It is NOT clamped to 0.
- **Odds:**
  - Let `b = yes_bid_dollars` and `a = yes_ask_dollars` from `GET /trade-api/v2/markets?tickers=...`.
  - If `b > 0` and `a < 1` and `a >= b` and `a - b <= 0.10`, then `p = (a + b) / 2`.
  - Otherwise, if `last_price_dollars > 0`, then `p = last`.
  - Otherwise there is no odds value.
  - For side `no`, `p = 1 - p`.
  - `oddsPct = clamp(round_half_even(p x 100), 1, 99)`, only while the market `status` is `"active"` or `"open"`.
- **Ledger:**
  - `cost = yes_total_cost_dollars + no_total_cost_dollars`.
  - `pnlCents = revenue - round(cost x 100) - round(fee_cost x 100)`, where `revenue` is already cents and round is half away from zero.
  - `pnlBps = trunc(pnlCents x 10000 / costCents)` when `costCents` is greater than 0.
  - Drop rows where both costCents and revenue are 0.
- **Material change** (drives the buzz; `isMaterialChange(from old: ContentState?) -> Bool`), true when any of these holds:
  - `old` is nil;
  - the multiset of (`ticker`, `side`, `milli`) over `rows` differs;
  - `openCount` differs;
  - `ledger.first` differs by (`ticker`, `at`);
  - any row's `state` differs for the same ticker.

  Odds, `winCents`, `totalCents` and `asOf` changes alone are NOT material.

## Size

- The encoded ContentState plus attributes must stay under 4096 bytes in the worst case: 3 rows with 40 character tickers and 32 character labels, 4 ledger entries, and Int.max style values. Tests prove it.

## App group snapshot (iOS only)

- Key `kashbot.live-board.v1` in `group.com.evan.leafhft` holds the `KashbotBoardSnapshot` JSON, which has two fields:
  - `state`: the ContentState;
  - `ledger`: [Entry], at most 20, newest first.
- The snapshot expires after 24 h, like the portfolio snapshot.

## Push (R3 uploads, R4 sends)

- The app POSTs `/api/leafhft/mobile/live-activity-token` with the dashboard bearer auth used by push-token.
- The body is `{"kind":"update"|"start","token":"<hex>","activityId":"<id or null>"}`.
- R4 sends APNs pushes with:
  - `apns-push-type: liveactivity`
  - topic `com.evan.leafhft.push-type.liveactivity`
  - payload `aps.event` of `update`, `start` or `end`, plus `aps.timestamp`, `aps.content-state` (the ContentState above), `aps.stale-date` (`asOf + 180`) and `aps.attributes-type` `"KashbotLiveAttributes"` with `aps.attributes` `{"v":1}` on start.
- An `aps.alert` is added only when `isMaterialChange` is true, and always on a start.
- Priority 5 for a non-material update, at most once per 60 s per token. Priority 10 for a material update or a start.

## App settings keys (standard UserDefaults, app target only; R2 writes the UI, R3 reads them)

- `kashbot.live.enabled` Bool, default true: show the Live Activity. False ends any running activity and stops token upload.
- `kashbot.live.buzzOnOdds` Bool, default false: also treat a held side's oddsPct crossing 50 (either direction) as material.

## v1 additive: live P/L

# Kashbot Live wire contract v1, additive change "live P/L" (frozen by the planner, 2026-09-30)

This change is additive. `v` stays 1, every existing key keeps its meaning, and an old payload still decodes.

## New Row key

| key | type | meaning |
|---|---|---|
| `pnlCents` | Int? | Live (mark-to-market) P/L of the open position in cents. Omitted when there is no mark. |

**Formula.** Decimal math throughout, converted to cents only at the end.

- `c` = abs(position count), `e` = exposure (cost basis), `f` = fees (0 when absent).
- **Mark `m`** (dollars per contract, held side, unrounded):
  - if yes_bid > 0 and yes_ask < 1 and ask >= bid and ask - bid <= 0.10, then m_yes = (bid + ask) / 2;
  - otherwise, if last_price > 0, then m_yes = last;
  - otherwise there is no mark and `pnlCents` is omitted.
- The held side's mark is m = m_yes for YES and 1 - m_yes for NO.
- When the row `state` is `won`, m = 1. When it is `lost`, m = 0. These apply even without a quote.
- `pnlCents = floor((c x m - e - f) x 100)`, floored toward negative infinity.

These are the same quote rules as `oddsPct`, but unrounded and unclamped.

**Material change.** Unchanged: a `pnlCents` change alone is NOT material (no buzz).

**Golden vector.** It is regenerated to include `pnlCents` on rows with a mark, and omits the key on the row without one. The iOS fixture `ios/Packages/LeafHFTCore/Tests/LeafHFTCoreTests/Fixtures/kashbot-live-golden.json` is authoritative. ops-dashboard copies it byte for byte.

## Presentation (iOS only, operator ask)

The operator said: "too much unnecessary data, just the symbol and P/L history is enough, highlighting open positions and their P/L as live as possible in a larger/dynamic way". The board shows only:

1. **A small header:** the leaf glyph plus "KASHBOT", and the portfolio total at 15 pt semibold white (kept from the original ask "show full portfolio size").
2. **Open positions, the hero.** Up to 3 rows, each showing:
   - the SYMBOL at 17 pt semibold white;
   - the live P/L at 26 pt bold rounded, in leaf or loss by sign, with a ▲ or ▼ glyph, `.monospacedDigit()`, `.contentTransition(.numericText(value:))`, and `.animation(.default, value:)` keyed on the value, so updates roll.

   With exactly 1 open position, a hero layout shows the symbol at 20 pt and the P/L at 40 pt. With no mark, the row shows "--" in slate. The row `state` `won` or `lost` shows as a 13 pt heavy tag after the symbol.
3. **History:** the last 4 settled results, each as SYMBOL (13 pt, slate) plus cash P/L (15 pt semibold, leaf or loss).

Everything else is removed: side, size, odds and bars, to-win, percentages and the today chip.

**SYMBOL.** A pure function `KashbotSymbol.short(ticker:)` returns the series, the part before the first "-". If two DISPLAYED rows (or history entries) share a series, each gets " " plus the ticker's last "-" segment appended. It is truncated to 12 characters.

## Refresh cadence ("as live as possible")

- **iOS, app in the foreground:** a separate markets-only loop every 10 s. It makes one batched public `.markets(tickers:)` call for the open tickers, rebuilds the board from the last positions, settlements and balance, and applies it. The non-material Live Activity throttle drops from 15 s to 10 s. The existing 60 s full Kalshi poll is unchanged.
- **Server** (ops-dashboard kashbot-live-push):
  - the priority-5 non-material interval drops from 60 s to 20 s;
  - the per-host refresh coalescer interval drops from 60 s to 20 s;
  - the public markets cache drops from 30 s to 10 s.

  Everything else is unchanged: material updates at priority 10 with an alert, and the 4 h start cap.
