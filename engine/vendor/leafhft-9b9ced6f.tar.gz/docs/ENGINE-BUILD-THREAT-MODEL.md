# Engine build threat model (plan abstract-pondering-magpie, Part II B11, slice M0)

This is the written threat model for the rebuilt engine build path: an idea from a phone, the web
or the assistant becomes one BuildRequest and one BuildRecord (B1), runs on the five project native
CodeBuild rail in `shared/leafhft-engine-build` (B4, slice M2), and ends as a sealed record, a
pinned kernel pull request, or a named failure. It states who the principals are, which AWS
permission each one can exercise, how logs, evidence and money are controlled, and what is still
exposed. The reason codes every refusal and failure on this path carries live in
`leafhft/engine_reasons.py` (`BUILD_REASONS`, `BUILD_NEXT`, `BUILD_RAISE_SITES`), and the raise
site table at the end of this file must equal `BUILD_RAISE_SITES` row for row
(`tests/test_engine_reasons.py` checks it).

Status: design contract. The rail, the BuildRecord and the dispatcher land in slices M1 to M6;
until M3a, M3b, M4 and M6 are live every KERNEL request is refused with
`build.kernel_path_unavailable`.

## The host threat model this rests on (plan Part VII preamble, measured 2026-09-23)

On the operator's desktop every agent runs as the operator's OS user. A DPAPI user scope key
decrypts for any same user process, the default AWS profile is the `AdministratorAccess` SSO role
on account 807034087062, the logged in Chrome (Auth0 session) is drivable through the browser
tools, the production Neon `DATABASE_URL` is readable from the ops-dashboard `.env.local`, and the
plugged in iPhone is drivable through WebDriverAgent. So an approval keyed to IDENTITY (a cookie, a
role session, a repo commit, a free text authorization reference) is agent satisfiable.

Consequences for this path:

1. Every risk increasing build action (a build approve, a `promote` start by the admin principal,
   a `live` KernelPin, a raise of any build quota or of the project envelope) is bound to USER
   PRESENCE: a WebAuthn assertion with `userVerification=required` on the dashboard, a Secure
   Enclave `.biometryCurrentSet` signature on the phone, or a KMS Sign allowed only for an MFA
   fresh role session (`aws:MultiFactorAuthPresent`, `MultiFactorAuthAge < 300`) that is never
   cached as the host default profile. The token is signed server side, single use, bound to the
   payload digest and verified by the consumer.
2. Cancel, stop, a quota LOWERING and a reservation release stay unsigned because they only
   reduce risk.
3. The `operator` column of the permission matrix is `yes` everywhere, and that column is also
   what any agent on the host can do. The rail does not defend against the host; it defends
   against tenants, the assistant model and the exec agent.

## Principals

| Principal | Who or what it is | Trust |
|---|---|---|
| tenant | A beta user on a paired phone or on the web, authenticated by device pairing and Auth0. Creates and reads BuildRecords through the API only. | Untrusted input; never holds AWS credentials. |
| assistant model | The model behind a Kashbot assistant turn. May propose a build through a tool; its panels and tool output are model authored and are never consent. | Untrusted; the server stamps `input.role` from the claim so the model cannot forge it (A2). |
| exec agent | The model driven coding agent inside the `exec` project. Writes the candidate kernel and its evidence. | Hostile by assumption: prompt injectable through the brief and the corpus. |
| judge-run | The `judge-run` project. Runs candidate conformance and base owned tests as a separate uid. | Runs hostile code, so it holds ZERO credentials; its output is a build artifact only. |
| judge-seal | The `judge-seal` project. Never runs candidate code; sole writer of `record.json`. | Trusted; verifies `BatchGetBuilds(judge-run).environment.REQUEST_ID == key`. |
| kashbot-api | The Fargate API service behind the phone and the web. | Its task role keeps no AWS permissions (production INFRASTRUCTURE.md:529). |
| dispatcher | The dedicated dispatcher identity (tick token of at least 32 characters, no CRON_SECRET fallback, plus its own IAM identity). The only principal that advances a BuildRecord, writes `request.json`, settles spend and cancels. | Trusted; created as a class 3 authority change with a fresh yes. |
| admin | The dashboard admin principal (`isAdminEmail`; beta admins are refused on admin build routes). Approves tenant builds and may start `promote` with a presence bound signature. | Trusted human action, but agent reachable through the host (see above), hence presence binding. |
| operator | The human holding `AdministratorAccess` on 807034087062 and the terraform apply rail. | Full authority; shares that authority with every agent on the host. |

## Every AWS permission of the five project rail, mapped to who can exercise it

Cells read `yes` (the principal holds it directly), `no` (it cannot exercise it by any path on the
rail), or `scoped` (it can cause the action only under the Condition column, through the Holder).
`source`, `exec`, `judge-run`, `judge-seal` and `promote` are the five CodeBuild projects; the role
names are the M2 terraform root's.

<!-- permission-matrix:begin -->
| Permission | Holder | Condition | tenant | assistant model | exec agent | judge-run | judge-seal | kashbot-api | dispatcher | admin | operator |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `s3:PutObject` on `engine-builds/v1/<request_id>/request.json` | dispatcher identity | only after admission commits in Neon; `s3:if-none-match=*` required | no | no | no | no | no | scoped | yes | no | yes |
| start of `source` through the fixed parameter EventBridge rule and Lambda (`codebuild:StartBuild` on `source`) | start Lambda role | fires only on a new `request.json`; no buildspec, environment or source override is reachable | scoped | no | no | no | no | scoped | scoped | scoped | yes |
| `codebuild:StartBuild` with any override (buildspec, environment variables, source version, image, service role) | no rail role | granted to no rail role and to no API identity | no | no | no | no | no | no | no | no | yes |
| `codebuild:StartBuild` on `exec`, `judge-run`, `judge-seal` (chain step) | chain Lambda role | on the previous project's SUCCEEDED state change for the same REQUEST_ID | no | no | no | no | no | no | no | no | yes |
| `codebuild:StartBuild` on `promote` | chain Lambda role | only from a sealed `record.json` or an admin presence bound signature | no | no | no | no | scoped | no | no | scoped | yes |
| `codebuild:StopBuild` on any rail project | StopBuild Lambda role and dispatcher identity | token metric alarm, a cancel on the tenant's own build, or the unreadable window release | scoped | no | no | no | no | no | yes | scoped | yes |
| `bedrock:InvokeModel`, `bedrock:InvokeModelWithResponseStream`, `bedrock:Converse`, `bedrock:ConverseStream` on the dedicated application inference profile | per build exec STS session | session policy allows only these actions on that one profile; denied when the Budgets action fires | no | no | scoped | no | no | no | no | no | yes |
| `sts:AssumeRole` into the per build exec session | exec project role | the trusted wrapper mints it before the agent starts; 169.254.169.254 is blocked for the agent process | no | no | no | no | no | no | no | no | yes |
| `s3:PutObject` under `engine-builds/v1/<request_id>/<nonce>/` | exec project role | `s3:if-none-match=*` required by IAM; key carries the server minted 128 bit nonce and `$CODEBUILD_BUILD_ID` | no | no | scoped | no | no | no | no | no | yes |
| `s3:GetObject` on `engine-builds/v1/*` evidence | judge-seal, promote and dispatcher roles | read only; exec reads only its own claim and bundle keys | no | no | scoped | no | yes | no | scoped | no | yes |
| `s3:PutObject` on `engine-builds/v1/<request_id>/record.json` | judge-seal role | sole writer; `s3:if-none-match=*` | no | no | no | no | yes | no | no | no | yes |
| `s3:ListBucket` on the evidence bucket | no rail role | never granted to exec, so keys are not discoverable | no | no | no | no | no | no | no | no | yes |
| `codebuild:BatchGetBuilds` on the rail projects | judge-seal role and dispatcher identity | judge-seal reads the judge-run REQUEST_ID; dispatcher reads status for its own requests | no | no | no | no | yes | no | scoped | no | yes |
| `kms:GenerateDataKey`, `kms:Decrypt` on the evidence bucket key | every rail role through S3 | `kms:ViaService` limited to S3 in us-east-1 | no | no | scoped | no | scoped | no | scoped | no | yes |
| `logs:CreateLogStream`, `logs:PutLogEvents` on the exec log group | exec project role | output passes the redaction filter first; 14 day retention; KMS | no | no | scoped | no | no | no | no | no | yes |
| `logs:GetLogEvents`, `logs:FilterLogEvents` on exec logs and Bedrock invocation logs | no rail role | read by the operator only | no | no | no | no | no | no | no | no | yes |
| Bedrock model invocation logging configuration | account setting | delivered to a KMS encrypted destination; only the account admin role can change it | no | no | no | no | no | no | no | no | yes |
| `secretsmanager:GetSecretValue` on the GitHub App private key | promote project role | read inside `promote` only; the App is ruleset scoped to `engine-build/*` refs | no | no | no | no | no | no | no | no | yes |
| `s3:GetObject` on the pinned Kalshi corpus and pinned code bundles | source project role | pinned by digest, read only; exec and judge-run see the hydrated copy, never the bucket | no | no | no | no | no | no | no | no | yes |
| `s3:PutObject` on the Kalshi corpus prefix | lane 11 recorder job role | new dataset versions only, conditional put, never an overwrite | no | no | no | no | no | no | no | no | yes |
| Budgets action attaching the Bedrock deny policy to the exec role | Budgets execution role | fires at the budget threshold | no | no | no | no | no | no | no | no | yes |
| `lambda:InvokeFunction` on the StopBuild Lambda | CloudWatch alarm on the inference profile token metrics | near real time spend stop | no | no | no | no | no | no | no | no | yes |
| `iam:*`, `codebuild:UpdateProject` and any apply of `shared/leafhft-engine-build` | terraform apply role | through the apply rail with the card's yes | no | no | no | no | no | no | no | no | yes |
<!-- permission-matrix:end -->

## Isolation of the exec project (B4, B5)

1. Bedrock only through the dedicated application inference profile; its quota is isolated so a
   runaway exec cannot starve other Bedrock users.
2. No internet. The S3 gateway endpoint policy is pinned to this account and this bucket, and a
   Route 53 DNS firewall blocks every other name.
3. No IMDS reachable role credentials in the agent process: a container or microVM with
   169.254.169.254 blocked, and the per build STS session policy allowing only InvokeModel* on the
   one profile.
4. One project role is shared by every build, so per request IAM scoping is impossible. Separation
   between builds comes from the server minted nonce in every key, `s3:if-none-match=*` on every
   exec write, no `s3:ListBucket`, and per attempt claim keys (`claim-<attempt>.json`).
5. Candidate authored tests never enter the repo. judge-run runs base owned tests as a separate uid
   with zero credentials; judge-seal never runs candidate code.

## Logs, evidence and attribution

**Exec logs.** The exec wrapper passes agent output through a redaction filter before it reaches
CloudWatch: credential shaped values (AWS access key ids, STS session tokens, bearer tokens, PEM
blocks and 32 plus character base64 runs) are replaced by a class label. The exec log group keeps
14 days, is KMS encrypted, and is readable by the operator only.

**Evidence bucket.** `engine-builds/v1/<request_id>/` is encrypted with a customer managed KMS
key (leaf-dev-ops SKILL.md:211), bucket keys on, public access blocked, TLS only. Every exec key
sits under the nonce and the build id, and `record.json` has exactly one writer.

**Bedrock invocation logging.** Enabled for the account, delivered to a KMS encrypted destination
with the same 14 day retention, so every model call a build made can be tied to the profile and
reviewed. It holds the tenant's brief and the model's output, so it is operator readable only.

**Attribution receipt.** For every request the dispatcher writes
`engine-builds/v1/<request_id>/attribution.json` with a conditional put, schema
`leaf.engine-build-attribution.v1`: `request_id`, `requested_by` (the Auth0 subject),
`device_id` (the paired device, or `web`), `tenant_id`, `charged_tenant_id`, `approver`,
`approval_id`, `card_digest`, `nonce`, the CodeBuild build id of every project run (`run_id` is
the `source` build id; the chain ids follow), the inference profile ARN, `reserved_usd`,
`metered_usd` and `settled_usd`. Every BuildRecord state change and every spend figure resolves to
one person, one device and one tenant through this file.

**Pinned Kalshi corpus.** The replay corpus (Part IV lane 11: one closed Kalshi tape with
timestamps, gaps, market metadata, outcomes and provenance) lives in S3 under a versioned prefix,
is referenced by digest in the build request, is hydrated only by `source`, and is never writable
by any build project. A corpus the exec agent could edit would let it grade its own work.

## Money controls (B3, B6)

1. **Admission in the database.** Admission takes `SELECT ... FOR UPDATE` on the CHARGED tenant's
   `kashbot_build_quotas` row (the owner when the operator approves a tenant build) AND on the
   single `kashbot_build_envelope` row (the project envelope) in one transaction, in a fixed lock
   order, so two concurrent approvals cannot both reserve the same remaining capacity under READ
   COMMITTED. Caps are a per tenant month cap and a per day kickoff cap, and the remaining room is
   `min(month_cap, envelope_remaining minus margin)` against the ratified project envelope (500 USD
   total, pause at 400 USD). A refusal is `build.quota_exhausted` or `build.envelope_exhausted`.
2. **Reservation and settlement.** The reservation is the full cap until metered spend is known.
   Settlement is `max(reserved, metered Bedrock cost)`, never the exec's own report.
3. **The dispatcher token.** Mandatory, at least 32 characters, no CRON_SECRET fallback; unset
   answers 503 `build.dispatcher_token_missing`. A DB advisory lock keeps ticks mutually exclusive
   across Fargate tasks.
4. **The Budgets deny.** When the AWS Budgets action fires it attaches a deny of
   `bedrock:InvokeModel`, `bedrock:InvokeModelWithResponseStream` and `bedrock:Converse*` to the
   exec role.
5. **The token metric StopBuild alarm.** A CloudWatch alarm on the inference profile's token
   metrics invokes a Lambda that issues `StopBuild` in near real time; the build fails with
   `build.failure_class_budget`.
6. **Timeout.** Derived from a MEASURED model cost per minute at this account's tokens per minute
   quota, recorded before any build runs; a hit is `build.failure_class_timeout`.
7. **No redrive multiplication.** A budget failure is terminal for the attempt; it never requeues
   with a fresh cap.

## Residual risks (stated, not closed)

1. **Budgets lags 8 to 12 hours.** The Budgets deny is a backstop only; the token metric alarm is
   the real time stop, and spend continues for one alarm period plus the StopBuild latency.
2. **The exec role is shared by every build.** A Budgets deny stops every build at once, and a
   flaw in the nonce or conditional put scheme is a cross build flaw; IAM cannot scope per request.
3. **The host is the operator.** Any agent on the desktop holds `AdministratorAccess`; presence
   binding covers risk increasing approvals, but not a raw API call made with the admin role.
4. **Settlement lags metering.** Metered Bedrock cost arrives after the fact; until it does the
   reservation holds the full cap, and a bounded unreadable window notifies the operator
   (`build.failure_class_status_unreadable`) rather than guessing.
5. **Cancel is not instant.** A cancel fences the lease; the worker sees it at its next renew, so
   spend continues until the current round ends (`build.cancel_requested` says so).
6. **Redaction is pattern based.** A secret in an unrecognised shape can reach the exec log group;
   retention and operator only reads bound the exposure.
7. **Model provided code is hostile.** judge-run's separate uid and zero credentials are the
   boundary; the static AST import guard is linting, never a boundary.

## Raise sites

Every place a build refusal or failure is raised, with the code it must carry. The files land in
the named slice; `tests/test_engine_reasons.py` asserts this table equals `BUILD_RAISE_SITES`,
that every code has a plain sentence and a `next` action, and, for each leaf-hft file that exists,
that the file contains its code.

<!-- raise-sites:begin -->
| Site | Repo | Path | Call site | Code | Slice |
|---|---|---|---|---|---|
| `assistant.engine_tool` | ops-dashboard | `src/lib/services/kashbot-assistant.ts` | engine tool execute() when the server stamped input.role is not owner | `build.owner_only` | A2 |
| `admin.builds` | ops-dashboard | `src/app/api/kashbot/admin/builds/route.ts` | admin build route execute() for a beta admin | `build.owner_only` | M1 |
| `builds.admit.kernel` | ops-dashboard | `src/lib/services/kashbot-engine-builds.ts` | admitBuild() for tier KERNEL before M3a, M3b, M4 and M6 are live | `build.kernel_path_unavailable` | M1 |
| `builds.admit.quota` | ops-dashboard | `src/lib/services/kashbot-engine-builds.ts` | admitBuild() under FOR UPDATE on the charged tenant's kashbot_build_quotas row | `build.quota_exhausted` | M1 |
| `builds.admit.envelope` | ops-dashboard | `src/lib/services/kashbot-engine-builds.ts` | admitBuild() under FOR UPDATE on the kashbot_build_envelope row | `build.envelope_exhausted` | M1 |
| `builds.propose.duplicate` | ops-dashboard | `src/lib/services/kashbot-engine-builds.ts` | proposeBuild() for a second submission from one assistant job | `build.duplicate_submission` | M1 |
| `builds.dispatcher.token` | ops-dashboard | `src/lib/services/kashbot-engine-builds.ts` | requireDispatcherToken() with the token unset or shorter than 32 characters | `build.dispatcher_token_missing` | M1 |
| `builds.approve.digest` | ops-dashboard | `src/app/api/leafhft/mobile/builds/[id]/approve/route.ts` | POST approve whose card_digest differs from the server recomputed digest | `build.card_digest_mismatch` | M1 |
| `builds.approve.expired` | ops-dashboard | `src/app/api/leafhft/mobile/builds/[id]/approve/route.ts` | POST approve after the card's expires_at | `build.card_expired` | M1 |
| `builds.cancel` | ops-dashboard | `src/app/api/leafhft/mobile/builds/[id]/cancel/route.ts` | POST cancel that fences the lease | `build.cancel_requested` | M1 |
| `dispatcher.tick.token` | ops-dashboard | `src/app/api/kashbot/admin/builds/tick/route.ts` | tick execute() with the dispatcher token unset or shorter than 32 characters | `build.dispatcher_token_missing` | M4 |
| `exec.budget` | leaf-hft | `scripts/engine_build/exec.sh` | StopBuild from the token metric alarm or the spend cap | `build.failure_class_budget` | M3a |
| `exec.timeout` | leaf-hft | `scripts/engine_build/exec.sh` | the build timeout derived from the measured model cost per minute | `build.failure_class_timeout` | M3a |
| `exec.credential` | leaf-hft | `scripts/engine_build/exec.sh` | the per build STS session or InvokeModel is refused | `build.failure_class_credential` | M3a |
| `judge_run.oracle` | leaf-hft | `scripts/engine_build/judge_run.py` | the base owned replay tests fail on the candidate | `build.failure_class_oracle` | M3a |
| `judge_run.conform` | leaf-hft | `scripts/engine_build/judge_run.py` | the candidate fails engine conformance | `build.failure_class_conform` | M3a |
| `judge_seal.request_id` | leaf-hft | `scripts/engine_build/judge_seal.py` | BatchGetBuilds shows a judge-run REQUEST_ID that differs from the key | `build.failure_class_seal_mismatch` | M3b |
| `promote.pr_open` | leaf-hft | `scripts/engine_build/promote.py` | the promotion marker cannot reach PR_OPEN | `build.failure_class_promotion` | M6 |
| `dispatcher.tick.infrastructure` | ops-dashboard | `src/app/api/kashbot/admin/builds/tick/route.ts` | a CodeBuild phase ends FAILED or FAULT outside every other class | `build.failure_class_infrastructure` | M4 |
| `dispatcher.tick.lease` | ops-dashboard | `src/app/api/kashbot/admin/builds/tick/route.ts` | renew is refused by the fencing token | `build.failure_class_lease_lost` | M4 |
| `dispatcher.tick.unreadable` | ops-dashboard | `src/app/api/kashbot/admin/builds/tick/route.ts` | build status stays unreadable past the bounded window | `build.failure_class_status_unreadable` | M4 |
<!-- raise-sites:end -->

The queue's failure classes (`BUILD_FAILURE_CLASSES`) are budget, timeout, credential, oracle,
conform, seal_mismatch, promotion, infrastructure, lease_lost and status_unreadable; each maps to
`build.failure_class_<class>`. M3a, M3b, M4 and M6 persist exactly these values as the queue
item's `failure_class`, and a new class lands here first with its sentence and `next` action.

## Research verdict codes (plan Part II B8 and B10, slice M5)

The research fleet's verdict consumer (`scripts/kalshi_research_verdict.py`, slice
M5-verdict-consumer) refuses every result that is missing, malformed, mismatched, not accepted or
not produced under the uid sandbox, and each refusal carries one `research.*` code. The sentence a
person reads and the one `next` action live in `leafhft/engine_reasons.py` (`RESEARCH_REASONS`,
`RESEARCH_NEXT`, `RESEARCH_RAISE_SITES`), kept apart from the build codes so `BUILD_REASONS` stays
exactly the build path contract. `tests/test_engine_reasons.py` asserts this table equals
`RESEARCH_RAISE_SITES`, that the codes equal the consumer's `REASON_CODES`, and that the consumer
file names every code.

<!-- research-sites:begin -->
| Site | Repo | Path | Call site | Code | Slice |
|---|---|---|---|---|---|
| `verdict.read.missing` | leaf-hft | `scripts/kalshi_research_verdict.py` | read_verdict() when the job table has no row for the job id | `research.job_missing` | M5 |
| `verdict.read.state` | leaf-hft | `scripts/kalshi_research_verdict.py` | read_verdict() for a row whose state is not pending, running or completed | `research.not_completed` | M5 |
| `verdict.row.state` | leaf-hft | `scripts/kalshi_research_verdict.py` | _check_row() for a row whose state is not completed | `research.not_completed` | M5 |
| `verdict.read.row` | leaf-hft | `scripts/kalshi_research_verdict.py` | read_verdict() for a row that is not an object or whose job_key differs from the job id | `research.row_invalid` | M5 |
| `verdict.row.fields` | leaf-hft | `scripts/kalshi_research_verdict.py` | _check_row() for a missing field or a result or archive key outside the job's results prefix | `research.row_invalid` | M5 |
| `verdict.read.result` | leaf-hft | `scripts/kalshi_research_verdict.py` | read_verdict() when the bounded get-object or the JSON read of result.json fails | `research.result_unreadable` | M5 |
| `verdict.check.schema` | leaf-hft | `scripts/kalshi_research_verdict.py` | check_result() for a result whose keys or field types differ from schema v1 | `research.result_invalid` | M5 |
| `verdict.check.identity` | leaf-hft | `scripts/kalshi_research_verdict.py` | check_result() for a job id, token, spec digest, archive key or archive digest that differs from the row | `research.identity_mismatch` | M5 |
| `verdict.check.acceptance` | leaf-hft | `scripts/kalshi_research_verdict.py` | check_result() for a nonzero exit code, a failed acceptance or an incomplete run | `research.not_accepted` | M5 |
| `verdict.check.sandbox_mode` | leaf-hft | `scripts/kalshi_research_verdict.py` | check_result() for a sandbox whose mode is not uid | `research.sandbox_not_uid` | M5 |
| `verdict.check.sandbox_shape` | leaf-hft | `scripts/kalshi_research_verdict.py` | check_result() for a uid sandbox with extra keys, a bad user name or a uid that is not a positive integer | `research.sandbox_invalid` | M5 |
| `verdict.check.sandbox_user` | leaf-hft | `scripts/kalshi_research_verdict.py` | check_result() when expected_user is set and the sandbox user differs | `research.sandbox_user_mismatch` | M5 |
<!-- research-sites:end -->
