# Tenant host move baseline

Part IV lane 7 uses this L7a reader to freeze the before-numbers for moving
tester supervisors to their own host. It reads run evidence only. It does not
change units, account state, credentials, orders, or lane settings.

Run as root on the runner because tester state directories are mode 0700.
The script uses only the Python standard library and works with the system
Python or `/opt/leafhft/.venv/bin/python`.

Before the move, freeze a receipt under the program receipts directory. Replace
`<program-receipts-dir>` and each `<lane-uuid>` with the actual directory and the
four distinct tester lane UUIDs. Keep the same lane names for the after capture.
The output directory must already exist.

```sh
sudo /opt/leafhft/.venv/bin/python scripts/tenant_host_baseline.py capture \
  --lane owner=/var/lib/leafhft/runs \
  --lane tester-1=/var/lib/leafhft-accounts/<lane-uuid>/runs \
  --lane tester-2=/var/lib/leafhft-accounts/<lane-uuid>/runs \
  --lane tester-3=/var/lib/leafhft-accounts/<lane-uuid>/runs \
  --lane tester-4=/var/lib/leafhft-accounts/<lane-uuid>/runs \
  --hours 30 --out <program-receipts-dir>/tenant-host-before.json
```

The default window is 30 hours, ending at the current UTC time. `--now` accepts
an ISO timestamp with a timezone for a reproducible window. Endpoints are
inclusive. Capture after the move with a comparable observation window and a
new output path, for example `tenant-host-after.json`. Capture the tester lanes
on the tenant host; capture the owner separately on its host if needed. Compare
matches lane names and emits null deltas for any lane absent on either side.

```sh
python scripts/tenant_host_baseline.py compare \
  --before <program-receipts-dir>/tenant-host-before.json \
  --after <program-receipts-dir>/tenant-host-after.json
```

Move acceptance reads tester quote age p50 and buy counts from `compare`.
The output also includes quote age p90 and total buy contracts. Each metric
has `before`, `after`, and `delta` (after minus before). This tool supplies
evidence and invents no pass or fail threshold. The live move and its acceptance
remain the operator-owned L7d step.

## Reading the receipt

- Quote ages come from decision rows, with nearest-rank p50, p90, p99 and max.
  Status snapshots supply a separate last-quote-age summary.
- Buys count only in-window `kind == "buy"` ticket rows. Contract counts sum
  int-coercible `count` values; invalid counts contribute zero. The engine split
  counts buy rows by string `engine_id`, falling back to `unknown`.
- `no_runs_root` means the root is missing or unreadable. `no_ledger` means no
  decisions or tickets file could be read. Both report null buys and contracts.
- `no_rows_in_window` means ledgers were read but had no timestamped rows in
  the window. This reports zero buys. `last_row_ns` includes out-of-window rows
  so a stopped lane can be distinguished from one that is quiet.
- `ok` means at least one timestamped ledger row was in the window, even if it
  was not a buy or lacked a valid quote age. Status alone does not establish
  ledger coverage. `quote_age_missing`, `bad_lines`, and `read_errors` expose
  incomplete evidence.

Only immediate child run directories are read. Symlink children are skipped.
The root is also a candidate if it directly holds evidence files. At most 256
candidates total are read, newest by directory mtime, with path order breaking
ties. `run_dirs_skipped` includes symlink children and candidates beyond the cap.
Evidence-file symlinks and nonregular files are not read.

Each ledger is limited to 64 MiB and each status snapshot to 1 MiB. A cut file
sets `truncated`; an incomplete JSON line is counted as bad. At most 500000 quote
samples per lane are retained in read order; further valid samples set
`samples_capped`. Producer-side ledger limits and these reader bounds mean this
is observed evidence, not a claim of exhaustive account history. Check the
coverage fields before interpreting a zero or a percentile.

`inputs` lists paths, byte counts, and SHA-256 hashes over exactly the bytes
read, sorted by path. The receipt digest is SHA-256 over its JSON without the
`digest` field, using sorted keys and separators `(',', ':')`. It detects receipt
changes, not authenticity. Capture is a sequential read of live files, not an
atomic snapshot across the host.

The only write is the requested receipt, created exclusively with mode 0600
and fsynced. Existing outputs are never overwritten. Exit codes are 0 for
success, 2 for usage or malformed/unreadable receipt input, and 3 for an existing
capture output. Refusals give one reason line on stderr. Compare verifies both
v1 schemas and digests before emitting its JSON object.
