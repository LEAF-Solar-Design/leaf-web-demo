# Gold live runner

LG4 adds the Gold launcher to the leaf-hft runner. The installer copies
`deploy/runner/units/leafhft-gold-live.service`, but `enabled.txt` has no Gold
line. This slice does not deploy, enable, start, acknowledge, or arm Gold.

The unit calls `deploy/runner/gold-live-run.sh`. It accepts the runner role or
an absent role file, rejects account lanes, and sets the owner risk regime.
Stake comes from `/etc/leafhft/kalshi-gold-stake`, with a default of `5.00` and
a range of `1.00` to `50.00`. `LEAFHFT_ETC` relocates that configuration root.
The exposure prestart checks `legacy-owner` for `GOLD-15M`; refusal exits 4.
The process writes runs under `/var/lib/leafhft/gold-runs`.

Gold uses its own unit and entry point. The fourteen-book matchers do not see
it. `live-run.sh` and `DIGEST_PROOF_FILES` are unchanged. A Gold-specific
status check is needed after any later authorized start.

## Gold on an account lane

For Zach's lane `5a1e869a-f3e1-4e80-a9b2-5f1c0208a0d9`, the owner unit `leafhft-gold-live.service`
stays disabled. One engine must never run on two Kalshi accounts. The lane
book (record `magpie-S7E-GOLD-LANE`) runs
`leafhft.gold_live_main.run_lane` under the lane's credential and shared
account budget. Its dials are `GOLD_LIVE_DIALS_V1`.

The opt-in is root-owned `/etc/leafhft-accounts/<lane>/gold.json`, delivered
to the lane as systemd credential `gold` (default `off`). Its exact keys are
`schema` (`leafhft.gold-lane-opt-in.v1`), `lane_id` (the bound lane),
`stake_usd` (a JSON string of positive whole cents from `"0.01"` to `"50.00"`),
and `fixed_count` (a JSON string from `"0.01"` to `"1.00"` in hundredths).
The `gold-exclusive` root pre-step refuses the whole lane unit when this
lane and another lane both opt in. Presence counts even for a symlinked lane
directory, symlinked opt-in, or invalid opt-in file; the pre-step does not
read its contents. Only an opted-in lane checks the owner unit with
`systemctl is-active leafhft-gold-live.service`. It admits only `inactive`
or `failed` stdout; every other state, error, or timeout after five seconds
refuses. A lane without an opt-in skips the owner-unit check.

Gold starts as one extra child after all 14 books are ready and the activation
receipt exists and exactly matches the lane's activated live receipt. The
child checks that receipt again before changing its environment or creating
directories and refuses if it is missing or mismatched. The supervisor waits
for a missing receipt; a mismatching receipt refuses Gold for this supervisor
run. A Gold failure never stops the books, and Gold stays
down until the next supervisor run.
Its separate `gold-status.json` lives in the lane state directory; the
14-book status, readiness and renewal rules remain unchanged. A status write
failure records one refusal and disables further Gold status writes without
stopping the books. Gold's exited state is written once.

The arm is root-published at
`/var/lib/leafhft-projections/<lane>/gold-entry-arm.json`, read by
`leafhft.gold_live.load_account_arm`, and uses these exact keys:

| Key | Required value |
| --- | --- |
| `schema` | `leafhft.gold-entry-arm.v2` |
| `series` | `KXGOLD15M` |
| `symbol` | `GOLD-15M` |
| `build_sha` | Exact running build, 40 lowercase hex characters |
| `risk_regime` | `account` |
| `lane_id` | Bound account lane UUID, the form `account_lane_agent.UUID` and `account-run.sh` require (`5a1e869a-f3e1-4e80-a9b2-5f1c0208a0d9` for Zach) |
| `issued_at_ms` | Integer Unix milliseconds, no more than 60 seconds ahead |
| `expires_at_ms` | Integer milliseconds after issue and after now |
| `fixed_count` | JSON string from `"0.01"` to `"1.00"` |
| `approval_id` | 1 to 128 letters, digits, underscores, or hyphens |

TTL must be at most 86,400,000 ms (24 hours). Use canonical JSON: sorted
keys, compact separators, ASCII escapes, and no trailing newline. The arm
must satisfy the reader's ownership, permissions, regular-file and size
checks; unknown or duplicate keys are refused. The lane id, build and
unexpired arm must match the running lane, with
`LEAFHFT_RISK_REGIME=account` and `LEAFHFT_ACCOUNT_LANE_ID` bound to it.

The remaining operator decisions for lane go-live are the lane-book merge,
a runner flip naming the exact SHA, the pin-flip PR with a
`Gold-Entry-Approval:` trailer, the lane's `LIVE-ACK`, Zach's written consent,
and the account-bound arm document. Keep their receipts together. The
owner-path decisions below do not authorize this lane path.

Before the owner launcher runs, `leafhft-gold-live.service` runs the root
condition `ExecCondition=+/bin/bash /opt/leafhft/deploy/runner/gold-owner-fence.sh`.
The fence refuses with exit 1 and names the lane directory if any
`/etc/leafhft-accounts/*/gold.json` opt-in exists, so systemd skips the start
with no restart. The owner unit sets `LEAFHFT_GOLD_OWNER_FENCE=v1`; the
launcher exits 4 without it.
Presence of the lane opt-in is enough to refuse, even before the
lane is running or armed; removing it is not proof that lane trading has
stopped.

## Later operator decisions

Each step below needs its own explicit yes and the named artifact. Completion
of one step does not grant the next. Existing account and book holds remain
in force.

1. **Runner deploy.** Approve the exact source commit and runner deployment
   through the existing runner release path. Keep the deployment receipt,
   installed unit, and disabled state as evidence. Do not start Gold as a
   side effect of installing it. Preserve the incumbent books and their holds.

2. **Enablement PR.** Approve a PR that adds the literal line
   `leafhft-gold-live.service` to `deploy/runner/enabled.txt` and changes
   `tests/test_gold_live_launcher.py::test_gold_live_is_not_enabled` in the
   same PR. This is a separate decision from the inert runner deploy.

3. **Evidence file.** Approve building evidence with
   `scripts/gold_evidence_replay.py` and placing the output at
   `/etc/leafhft/gold-live-evidence.json`. That producer is absent from this
   checkout and must ship before this step can run. Do not hand-build a
   substitute. Record the replay bundle, cursors, gap count, source and
   artifact hashes, and output SHA-256. The output must pass the
   `leafhft.gold-live-evidence.v1` reader: canonical JSON, at most 1 MiB,
   correct source and artifact pins, and age at most 24 hours.

4. **Cell gate.** Approve the evidence-backed cell admission only when
   resolved >= 200, a tier has n >= 50 over at least 5 distinct days with a
   positive edge, and the selected cell has n >= 20 and n_eff >= 20. Keep
   the tier and cell report with the evidence digest. An aggregate count
   alone does not qualify a cell or grant an order.

5. **Process acknowledgement.** Approve the Gold config digest and stake.
   Write the exact sentence produced by `ack_sentence(cfg)` to
   `/var/lib/leafhft/gold-live-ack/LIVE-ACK-<first 12 of config digest>.txt`:
   `I authorize live trading with config <full config digest> and a stake of at most $<stake to two decimals>`.
   Use the Gold configuration, not an incumbent book's digest. The process
   also needs `LEAFHFT_LIVE=1` and valid venue credentials through the unit's
   existing environment files. The shared live gate consumes the ack by
   default; its existing authorization mode governs any reuse. An ack does
   not replace the entry pin or arm document.

6. **Code-pin PR.** Done: `leafhft/gold_live.py::GOLD_LIVE_ENTRY_PIN` is
   `enabled` on main by the `Gold-Entry-Approval:` commit of 2026-09-30.
   Bind the approval to the candidate build, evidence, account, and ticket
   limit. Deploy that exact reviewed build before creating its arm document.

7. **Arm document.** Approve and place a root-owned regular file at
   `/etc/leafhft/gold-entry-arm.json`. It must not be a symlink or writable
   by group or others, and must be at most 4096 bytes. Its exact keys are:

   | Key | Required value |
   | --- | --- |
   | `schema` | `leafhft.gold-entry-arm.v1` |
   | `series` | `KXGOLD15M` |
   | `symbol` | `GOLD-15M` |
   | `build_sha` | Exact running clean build, 40 lowercase hex characters |
   | `risk_regime` | `owner` |
   | `issued_at_ms` | Integer Unix milliseconds, no more than 60 seconds ahead |
   | `expires_at_ms` | Integer milliseconds after issue and after now |
   | `max_ticket_cents` | Integer from 1 to 500 |
   | `evidence_sha256` | SHA-256 of the approved evidence bytes, 64 lowercase hex characters |
   | `approval_id` | 1 to 128 letters, digits, underscores, or hyphens |

   TTL is at most 86,400,000 ms (24 hours). Unknown or duplicate keys are
   refused. A dirty build, expired document, disabled pin, or mismatched
   build or evidence leaves entry closed. The reader checks file changes
   every five seconds and expiry on each call. Keep the document digest and
   operator approval with the build receipt. Renewal needs a new decision.

8. **Zach's account.** Obtain Zach's consent and a separate build before any
   binding to account lane `5a1e869a-f3e1-4e80-a9b2-5f1c0208a0d9`. Retain the consent and account-bound build
   receipt. This owner-only launcher refuses account lanes and is not that
   binding mechanism.

9. **Shared account-risk arithmetic.** Approve a budget record against the
   shared `engines` authority lane. Gold may have at most one open ticket,
   costing at most `max_ticket_cents`, including fees and the sizing buffer.
   Gold draws from the same remaining account allowance as other engines;
   its stake is not a second pool. Record incumbent commitments, remaining
   lane allowance, the Gold cap, and resulting reservation. Require
   incumbent commitments plus the Gold reservation to fit the shared lane
   ceiling and available cash. A tighter shared limit wins. No admission
   count, ack, or arm document overrides this arithmetic.

## Known limits

The head retains only the last 64 unresolved positions. Within the expiry
window, a mismatched retirement that ages off this list appears as
`retired_unsettled` in the head report, while replay retains its reason and
counts it as `R=-1`. At the bound, `gold_evidence_report.py` adds a `limits`
field to its JSON and prints a `limits` line on stderr with the head's UTC
day and the bound. Every successful report also prints the bound in its
stderr footer. The planned fix is to raise the bound or carry the retirement
reason in the head.

## Recovery after a later authorized start

Check the exact Gold unit, build identity, current evidence and arm digests,
and `/var/lib/leafhft/gold-runs` for the changed behavior. Do not infer Gold
health from the fourteen-book deploy check or use their rearm path for Gold.
For a refusal, preserve the journal and correct only the failed prerequisite
within its approval. Do not manufacture an ack or renew an arm to clear it.
For rollback, use the approved prior build and preserve the account's open
positions and risk ledger. Disarming blocks new entry; it does not prove
that an existing position is closed.
