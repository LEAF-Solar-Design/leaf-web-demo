# Kalshi run archive: context for an agent with no history here

This document travels with `scripts/kalshi_archive_index.py` and its generated
`archive-index.json` / `archive-index.md`. Every line below cost a prior session real time
to learn. Read this before touching the archive; it states what the artifacts are, what is
already confirmed, and what has already been refuted so you do not pay to rediscover it.

## WHERE THINGS ARE

- Runs root `/var/lib/leafhft/runs`, one directory per process run, named
  `YYYYMMDD-HHMMSS-<kind>-<venue>-<symbol>`. About 649 dirs, 98 with Kalshi ledgers, 140 with
  tapes, roughly 7.4 GB as of 2026-09-10.
- `kalshi-tickets.jsonl` is the ledger: rows of kind `buy`, `settle`, `exit`, `adopt`, `void`.
- `ticks.jsonl` is the recorder tape: index observations, quotes, lifecycle.
- `kalshi-edge-status.json` is a 30-second snapshot of a book's live state.
- Labelled datasets are under `datasets/` as `ds-<SYMBOL>.jsonl.gz`. The glob an analysis
  script needs is `datasets/ds-*.jsonl.gz`, NOT `ds-*.jsonl.gz` at the runs root.

## SCHEMA TRAPS, all observed

- The SAME ledger row appears in more than one run dir after a recovery. De-duplicate on
  `(kind, client_id, exit_client_id, ts_ns, settled_ns, count, price_cents)` before counting
  anything, or every total is inflated.
- ADOPTED settle rows carry EMPTY reason fields, so a loss that settled at a restart cannot be
  classified from the ledger alone.
- Many settle rows carry no `settled_ns`, so they cannot be ordered in time. Do not assume a
  ledger tail is chronological.
- A `buy` row's `cost_cents` INCLUDES the fee; `fee_cents` is already inside it, not an addition. `price_cents = cost_cents // count` is fee-inclusive.
  Recover the raw quoted ask with `kalshi_book._raw_price_from_buy_row_price_cents` or the reason string. Assuming cost excludes the fee mis-measures every ticket.
- Dataset rows now carry every integer `k` from 1 to 59 inside the settlement window plus unchanged pre-window offsets.
  `datasets-oldgrid/` holds the OLD sparse grid (`k` only 0, 15, 30, 40, 45, 50, 55) for rollback; do not use it for analysis.
  `ds-BTC-1H` and `ds-ETH-1H` have `truncated=True` in their manifests after hitting a per-symbol time budget: valid but partial; say so when using them.
- Live and replay compute `k` from DIFFERENT SOURCES. `leafhft/strategy/kalshi_edge.py:795` sets `state.venue_k = ev.avg60_window_size`;
  entry (869) and exit (639) use `k = state.venue_k if state.venue_k is not None else len(state.window_obs)`, with `sum_k` from the same source.
  The venue's settlement-window size is authoritative for Kalshi's 60-second average. Replay (`scripts/kalshi_dataset.py`) uses
  `k = bisect.bisect_right(bucket_local_ns, cutoff_ns)`, counting observations WE received. Counts usually agree (96.4% mean completeness over 740 settled windows), but diverge during reconnects.
  Until PR #16 (541cce3) is deployed to the runner, `venue_k` is absent from tape. Pre-deploy tape is permanently un-reconcilable: no replay can reproduce a live admission decision.
- A dataset shard can be TRUNCATED if its build timed out; `gzip` raises EOFError part way.
  Tolerate it per shard and report the partial count rather than aborting the run.

## WHAT IS CONFIRMED

- The in-contract exit rule pays. Across every exit ever made, 12 of 14 were right in
  hindsight and all 14 cleared the rule's own bar; holding instead would have turned a $37.02
  realized loss into $86.64, so the rule is worth about $49.62. Nine of eleven exited tickets
  would have settled at ZERO.
- The k floor of 10 is correctly placed: below it the venue prices better than our model
  (Brier 0.0391 against 0.0372), above it we price better (0.0107 against 0.0117).
- Price bands differ enormously. On 331 simulated tickets under the live rules: 50-69c earns
  +11.36c per ticket at a Kelly fraction of 0.32, while 80-89c earns +0.25c at a Kelly fraction
  of 0.02, and 90-94c is the one high band that pays.

## WHAT IS ALREADY REFUTED, do not rebuild these

- A sparse-index variance guard. Replayed over every tape: no variant was positive, and the
  symbol it was designed for (XRP) is not sparse, at 46 to 51 index moves a minute.
- A minimum hold time before the exit rule may fire. Every hold-off value scored worse than
  firing immediately; 45 s destroyed the rule.
- Buying the cheap out-of-the-money side early. Measured on 7,127 settled markets: every price
  bucket underpays its fee-adjusted break-even, and 85 percent of markets have no cheap-side
  quote five minutes out.
- Blending our probability toward the venue mid. It improves Brier but does not improve trading
  profit, because the disagreement IS the signal. Note the caveat that made the first reading
  too strong: lowering the blend weight while holding the edge bar fixed ALSO raises the
  required raw disagreement, so compare at matched ticket counts.

## THE MEASUREMENT THAT MATTERS MOST

- Our model is well calibrated in aggregate and badly overconfident on the trades the rule
  actually selects: it claims 0.9491 and delivers 0.8338 across 331 tickets, an eleven point
  gap that appears only under selection. This is the optimizer's curse and it is why the exit
  rule has been rescuing so many entries.

## OPERATIONAL TRAPS

- `leafhft policy set` serializes the FULL policy schema of the checked-out code. If the running
  books are older, they fail closed on unknown keys and freeze on their previous policy while
  the CLI still prints success. Verify by reading `policy.digest` and `policy.error` off every
  book, never by trusting the CLI's own line.
- A book's status `params` block is a FIXED field list and does NOT carry new policy keys, so it
  cannot be used to probe which build a book is running. Use the process start time and the run
  dir instead.

## THE FRONTEND BASELINE

- The dashboard may show P&L from a baseline moment rather than from the first deposit. That is
  a DISPLAY choice only. The database keeps every row, and
  `GET /api/leafhft/kalshi/account?scope=all` returns the complete history. Learning and
  win-rate statistics use full history, never the baseline.

## Using the generated index

`python scripts/kalshi_archive_index.py --runs-root /var/lib/leafhft/runs` writes
`archive-index.json` and `archive-index.md`. Per run directory it records the parsed kind,
venue, symbol and start time, which artifacts exist, row counts, byte sizes, and first/last
timestamps where cheaply available; a directory whose name does not parse is listed under
`skipped` with the reason, never silently dropped. Totals cover run and artifact counts,
ledger rows by kind (deduplicated across the whole archive), the date span, and the dataset
shards under `datasets/` with their row counts. The tool streams every artifact under a byte
and line cap, never loading a tape or ledger whole into memory, and two runs over the same
archive produce byte-identical output.
