# Public book feed: deployment and recovery

Book is the data we read; engine is how we transform; execution is the
threshold/policy for acceptance based on engine outputs. `bookd` publishes public
Kalshi data over a host-local UNIX socket. It holds no lane authority and performs
no order execution. Starting a publisher does not switch a trading consumer.

## F-key decision and credential boundary

The operator chose **K2**, then **yes, create the read-only key**. Use a separate
Kalshi read-only API key in AWS Secrets Manager `leafhft/kalshi-marketdata-readonly`,
with exactly `{key_id, private_key_pem}`. Key creation and venue permission checks
are provisioning work; the presence of this code does not prove either happened.
Grant the host role read access to this secret. Do not reuse a trading key.

Provision the non-secret selector as root:

```sh
sudo install -d -m 0700 -o root -g root /etc/leafhft-bookd
printf '%s\n' leafhft/kalshi-marketdata-readonly | sudo tee /etc/leafhft-bookd/kalshi-secret-id >/dev/null
sudo chown root:root /etc/leafhft-bookd/kalshi-secret-id
sudo chmod 0600 /etc/leafhft-bookd/kalshi-secret-id
```

`leafhft-bookd-secrets.service` runs as root after bootstrap, invoking
`populate_runner_secrets.py --load-bookd-env`. It fetches and validates the secret
without printing values or provider errors. Its runtime directory is root:root
0700 and `/run/leafhft-bookd-secrets/kalshi.env` is root:root 0600. A missing or
malformed secret fails the oneshot and blocks the dependent publishers. It never
writes `LEAFHFT_LIVE`.

Each publisher has both `Requires=` and `After=` on that oneshot. This ordering is
essential: systemd reads a `LoadCredential` source **before** `ExecStartPre`.
The publisher receives only `kalshi` in `$CREDENTIALS_DIRECTORY`, reads the two
quoted names in-process, and passes them directly to `KalshiFeed`. It neither
sources a shell env file nor exports the values to `os.environ`. Missing names,
unreadable files or a `LEAFHFT_LIVE` entry refuse startup with one reason line.
There is no fallback to `/run/leafhft/kalshi.env`, `/etc/leafhft`, or tenant keys.

The oneshot remains active after success; restarting one publisher does not fetch
a new key. For key rotation, first move all consumers to direct and verify that
move, then stop publishers, restart the secrets oneshot, and start publishers
one symbol at a time. Restarting a required secrets unit can stop its consumers;
do not use it as an incidental credential refresh during trading.

## Installation and host scope

`install-units.sh` installs `sysusers.d/leafhft-bookd.conf` and runs
`systemd-sysusers` before starting publishers. The user has no login shell and no
trading-group membership. Each instance owns `/run/leafhft-bookd/SYMBOL` (0755),
publishes `book.sock` (explicit chmod 0666) and `health.json` (0644), and has no
`ReadWritePaths` grant. `UMask=0000` preserves socket accessibility; directory
ownership prevents consumers from replacing the endpoint. systemd supplies a
private credential copy. Core dumps are disabled.

Fifteen instances are listed only in `enabled.txt`: BTC/ETH/BNB/HYPE/XRP at 15M
and 1H, plus DOGE/NEAR/SOL/ZEC/GOLD at 15M. The secrets unit is dependency-started,
not separately enabled, and the installer preserves it while any instance is
wanted. The unit resolves the installed checkout SHA before exec so the hello
and health records identify the running build. `Type=notify`, `WatchdogSec=5`,
`Restart=always`, `RestartSec=1`, `RestartSteps=6`, `RestartMaxDelaySec=60` and
`StartLimitIntervalSec=0` provide process recovery with repeated failures backing
off from 1 s toward 60 s, without a start-rate limit.
READY and watchdog notifications prove process liveness, not upstream freshness.

`HOST-ROLES.md` names **L7d follow-up: tenant-host bookd listing**. Sockets do not
cross hosts. The tenant list, identity installation, read-only key provisioning
and monitoring must be extended together before any tenant-host lane can switch.
The current installer refuses bookd names in `enabled-tenant.txt`.

## S0 to S3 gates

Keep evidence for each gate: exact SHA, host role, symbol, UTC interval, unit
state, hello/health samples, consumer comparison and rollback result. No gate is
satisfied merely by a green systemd state.

- **S0 — configuration and isolation.** Enable BTC-15M first through
  `enabled.txt` and the installer, after the read-only key is stored and the
  BE-B7 WS ceiling soak passes. Keep the other fourteen instances commented.
  A hand-started publisher blocks the owner flip kit and is not allowed.
  Review the money gate and run the unit,
  credential and publisher/consumer verification for the selected SHA. Run
  `bash /opt/leafhft/deploy/runner/install-units.sh --check`. Verify the read-only
  key's venue permissions and root-owned selector. Confirm the dedicated user,
  credential modes, socket permissions, bootstrap ordering and missing-secret
  refusal. Installation after the enable PR starts the configured instances,
  so use the approved deployment window. Do not flip a lane during installation.
- **S1 — publisher only.** BTC-15M, ETH-15M, BNB-15M, DOGE-15M, HYPE-15M, NEAR-15M, SOL-15M, XRP-15M and ZEC-15M are on; no lane reads them. Keep
  every consumer direct. Enable the remaining symbols one at a time through
  the installer after BTC-15M passes this gate. For each symbol, inspect
  hello identity and fresh health; exercise reconnect, sequence-gap/resnapshot,
  restart/epoch change and slow-client rejection. Observe a complete market
  rotation. Require matching series/index/venue, a connected upstream and ready
  books before proceeding. Record baseline reconnect/gap/drop counts and resource
  use. Foreign-series lifecycle events are dropped and counted as
  `foreign_lifecycle_dropped` in `health.json`. Foreign-series trades are dropped
  and counted as `foreign_trade_dropped` in `health.json`.
  The comparator requires a quote price envelope match within 500 ms at
  0.97 or better, no disagreement run longer than 2 s, and a median socket/tape
  size ratio within 5 percent (with at least 20 positive-side samples); index and
  recorded lifecycle fields must be equal within 250 ms, with no missing ticker
  or missing 5 Hz index feed. S1 passes on five consecutive 60 s windows, at
  least one of them in US market hours. No new trading exposure is needed for
  this gate.
- **S2 — one lane.** BE-B2's consumer and per-lane transport selector must be
  deployed first. Compare its reconstructed stream against direct data, then
  flip one approved lane on one symbol. Require snapshot completion, contiguous
  sequence handling, freshness refusal and reconnect recovery. Confirm transport
  changes leave the signed trading configuration, stake, policy, approval and
  authority unchanged. Exercise that lane's direct rollback before expansion.
  The lane hook loads the selector as the systemd credential `book-source`; it
  takes effect at the lane's next start. A selector that does not parse stops
  that lane's books from starting; fix it with `lane_select`, which never writes
  a malformed selector.
- **S3 — fleet.** Expand one lane and one symbol at a time, with the same evidence
  and a healthy observation window between changes. Confirm expected publisher
  count, observed clients, fresh heartbeats and lane readiness on every host.
  Any unexplained gap/drop increase, stale data, wrong identity or authority
  change stops expansion and invokes rollback. Tenant hosts also require L7d.

BE-B3 provides the publisher deployment. As root, select a lane's desired source
with `python -m leafhft.bookd.lane_select set --lane <lane> --symbol <symbol> --source shared`;
use `python -m leafhft.bookd.lane_select list` to show desired against effective,
and `python -m leafhft.bookd.lane_select clear --lane <lane> --symbol <symbol>`
to select direct. The lane hook (BE-B4b) must be deployed before a selector has
any effect. The choice takes effect at the lane's next start (daily renewal)
and never changes a running book; S2/S3 remain blocked until the hook is deployed.

## Per-lane flip and one-symbol upgrade

With BE-B2 and the lane hook (BE-B4b) deployed, read back the trading digest and
run `python -m leafhft.bookd.lane_select list --lane <lane>` for desired against
effective. As root, run `python -m leafhft.bookd.lane_select set --lane <lane> --symbol <symbol> --source shared`.
The choice takes effect at the lane's next start (daily renewal), never changes
a running book, and has no effect before BE-B4b is deployed. After that start,
read back effective source, digest and snapshot readiness. Do not mint an ack,
extend authority, change limits or restart the whole trading fleet for this
selection; a changed trading digest fails the gate. Reverse the selection with
`python -m leafhft.bookd.lane_select clear --lane <lane> --symbol <symbol>` and
check `list` after the next start. The consumer must refuse stale/incomplete
data rather than silently falling back.

For a publisher upgrade, deploy the reviewed code through the existing deployment
procedure, then restart just one publisher and inspect its new SHA/epoch:

```sh
sudo systemctl restart leafhft-bookd@BTC-15M.service
systemctl show leafhft-bookd@BTC-15M.service -p ActiveState -p SubState -p Result -p NRestarts
cat /run/leafhft-bookd/BTC-15M/health.json
journalctl -u leafhft-bookd@BTC-15M.service --since '5 minutes ago' --no-pager
```

Require the consumers to resnapshot and recover readiness on the new epoch.
Check `build_sha`, `updated_at_ns`, `upstream_connected`, `upstream_age_ms`,
`seq_gaps`, `resnapshots`, `reconnects` and `dropped` against S1. Repeat for the
next symbol only after acceptance. Avoid wildcard restarts of publishers.

## Global rollback order

1. **Flip all affected lanes to direct first**, using the reviewed per-lane
   selector, and read back every lane. Preserve trading configuration and
   authority. Include lanes on each host; do not rely on the owner's wanted set
   to enumerate dynamically managed tenant lanes.
2. **Restart affected lanes second**, one at a time through their existing
   lifecycle procedure if needed to activate the direct selection. Confirm
   direct data, unchanged risk bounds and execution health. A bare restart is
   not a re-arm. If a lane requires a new approval, leave it stopped pending that
   approval; never fabricate authority to complete rollback.
3. **Remove bookd last**, only after no lane depends on a stream: remove its
   active wanted lines through a reviewed deployment, then disable/stop each
   instance, and finally stop the secrets oneshot. Do not remove sockets or
   credentials beneath running consumers. Never revert trading configs merely
   to revert a data transport.

## Fleet re-arm and alarm response

For owner live units that actually report the one-shot ack gate closed, the
existing fleet re-arm commands are:

```sh
sudo /opt/leafhft/.venv/bin/python /opt/leafhft/deploy/runner/rearm.py --plan
# After reviewing the plan and obtaining the existing trading authorization:
sudo env LEAFHFT_REARM_WINDOW_GUARD=1 /opt/leafhft/.venv/bin/python /opt/leafhft/deploy/runner/rearm.py --apply
```

Prefer explicit unit names after `--plan` and `--apply` for a scoped incident.
The tool preserves HOLD and containment refusals and enforces the guarded
settlement window. These commands handle owner `leafhft-live@` units only;
tenant lanes use their account control agent and signed approval flow. Do not
restart or re-arm a tenant/Gold lane without its owner. Publisher restarts and
transport-only flips themselves do not require fleet re-arm.

For failed-unit, watchdog or book-freshness alarms, collect these public facts:

```sh
systemctl --failed --no-pager
systemctl status leafhft-bookd-secrets.service leafhft-bookd@BTC-15M.service --no-pager
systemctl show leafhft-bookd@BTC-15M.service -p ActiveState -p SubState -p Result -p NRestarts
journalctl -u leafhft-bookd-secrets.service -u leafhft-bookd@BTC-15M.service --since '10 minutes ago' --no-pager
stat -c '%U %G %a %n' /run/leafhft-bookd/BTC-15M /run/leafhft-bookd/BTC-15M/book.sock
cat /run/leafhft-bookd/BTC-15M/health.json
```

Do not print credential files. A failed secrets unit needs root-path, IAM or
read-only-key repair; there is no trading-env fallback. A healthy process with
stale upstream data still requires consumer refusal and, if not promptly
recoverable, the rollback above. Capture before/after health and lane readiness
with the alarm receipt. Do not silence an alarm merely by resetting failed state.
Static wanted-set health includes only enabled instances; publisher freshness,
consumer progress and tenant-host coverage must be proven at S1-S3, not inferred
from that inventory. This runbook does not claim a deployed alarm or rollout receipt.
