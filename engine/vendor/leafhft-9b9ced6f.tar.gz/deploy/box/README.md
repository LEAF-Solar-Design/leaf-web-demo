# Box jobs

R12 is the daily paper observation job for V191a Rollout 0, lane 7. It compares
V186 candidate B (the 5 Hz relay mean) with the two live parent policies on
matched tape frames. It does not call a venue, alter bindings, or restart a trader.

## Install the relay observation job

Use the existing checkout and Python environment at `/opt/dh/src`. Before enabling
the timer, place these frozen EngineRegistry documents in `/opt/dh/engines`:
`15m-late-k30-9094.json`, `hourly-k12-all.json`, and `5hz-mean-b.json`.
The candidate document must set `policy.mean_fast_index` to `1`. Its raw bytes
provide the activation's 12-hex policy digest. Registration also records the full
hash of all three documents; later reads refuse document changes. Keep the Git
metadata readable: initial registration requires the checkout's real HEAD SHA.

Run these install commands by hand on the box after the R9 mirror is configured:

```sh
sudo install -d -o ubuntu -g ubuntu /opt/dh/trials /opt/dh/out/relay
sudo install -m 0644 deploy/box/units/leafhft-relay-divergence.service /etc/systemd/system/
sudo install -m 0644 deploy/box/units/leafhft-relay-divergence.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now leafhft-relay-divergence.timer
```

The timer runs at 04:30 UTC, after the scheduled R9 tape mirror. The tape at
`/opt/dh/tape` is read-only. The first invocation registers and activates the
prospective trial at the current UTC time, records descriptive empty paper books,
and records an empty-window note without calling replay. The next day's run
makes the first report. No historical tape enters the prospective population.

## Read the daily evidence

The fixed trial ID is the first 32 hex characters of
`sha256("R12:relay-divergence:5hz-mean-B")`. Registration and activation live under
`/opt/dh/trials/<trial_id>/`. Each daily JSON is written to both that trial's
`reports/` directory and `/opt/dh/out/relay/<trial_id>/`, named
`YYYYMMDDTHHMMZ-<sha12>.json`. The report event records the full SHA-256 of those
same bytes. Completed UTC days are skipped on retry; older reports are never
rewritten. An incomplete replay is refused before a report is published.

Read `results["250"]["pooled"]` (or `15M` and `1H`) for A/B tickets, `decisions`
for changed admissions, and `paired` for `sum_D`, `mean_D`, and `ci95`. The daily
read uses 10,000 bootstrap draws and is marked `read_kind: daily_observation`.
These exploratory intervals and the replay's screen fields are not terminal
trial verdicts. The registration retains the 30-day window, seven-day grace,
100,000 resamples, and 0.01 alpha for the terminal look.

At day 37, use the separate verdict command with the trial's scoring inputs:

```sh
/opt/dh/src/.venv/bin/python /opt/dh/src/scripts/kalshi_engine_verdict.py \
  --trial /opt/dh/trials/<trial_id> --runs-root /opt/dh/tape \
  --paper-root <paper-ledger-root> --decisions-root <decision-ledger-root> \
  --out /opt/dh/out/relay/<trial_id>/terminal.json \
  --md /opt/dh/out/relay/<trial_id>/terminal.md
```

The daily replay JSON does not create paper or decision ledgers for that scorer.
Supply its required evidence at the terminal look; daily observations alone do
not establish a terminal result. Inspect job errors with
`journalctl -u leafhft-relay-divergence.service`. To stop future reads, disable
the timer and retain the trial directory.
