# Research runner units

These units run three research recorders and one live rehearsal maker. Terraform's
first-boot bootstrap calls this same installer after preparing the clone,
virtualenv, service user and secrets. Terraform integration is a separate change.

Update an existing runner:

```bash
sudo bash /opt/leafhft/deploy/runner/deploy.sh <target-sha> [--restart-unchanged] [--force-degraded]
```

If the checkout lacks executable bits, invoke `sudo bash deploy/runner/install-units.sh`
once. The installer sets both scripts executable. Use
`bash deploy/runner/install-units.sh --check` for validation without root or systemd.
Installation copies changed unit files, reloads systemd, retires enabled leafhft
units absent from enabled.txt, then enables and starts the listed units. With
`LEAFHFT_INSTALL_LIVE_ONLY` set it starts only the named `leafhft-live@` instances
and only enables the others (see "Subset rollout" under the deploy verb).
It never changes bootstrap units. Already running services are not restarted;
use deploy.sh for code updates and its rearm.py guidance for books left on old code.

`leafhft-notify-feed.timer` runs the message forwarder every minute, independently
of Telegram delivery. It sends scrubbed `notify-log.jsonl` rows to the ops dashboard's
`/api/leafhft/ingest/messages` route and saves progress in
`/var/lib/leafhft/notify-feed-cursor.json`. The service reads its dashboard token from
`/run/leafhft/ingest.env`; a dashboard outage leaves the cursor ready for a retry.

## Shipping a feature dark and taking it live (features.json)

A feature that merges switched off must add its row to `features.json` in the
same PR. Name its owner, PRs, trading-path effect, shadow/live stage, activation
authority, and when changes apply. Declare its switches, preconditions,
activation and rollback steps, and optional checks that prove it is in effect.
Base configuration switch points belong in `not_features` with a specific reason;
the CI gate rejects undeclared switches. It scans systemd ConditionPathExists,
every $etc/<name> reference in live-run.sh and gold-live-run.sh, optional policy
keys, and Python switch-path literals. Run-time-built paths belong in
SWITCHES_THE_SCAN_CANNOT_SEE in tests/test_runner_features.py with their source
file and construction fragment; the gate checks that each fragment still exists.

Run `python3 deploy/runner/feature_check.py` on the runner for observed state and
readiness, or add `--json` for structured output and `--feature ID` to select a row.
Exit codes: 0 means all selected features without manual switches are on;
3 means at least one such feature is off, partial, or unknown; 4 means the
registry is invalid or unreadable; 5 means usage. Manual-switch features are
still printed but do not affect the exit code. The manual boolean identifies
them; text readiness is yes, no, or manual. Readiness requires no manual switch,
no unreadable switch or precondition, passing preconditions, and a state other
than on. Kill-switch rows require operator authority and manual stop removal.
Policy dials count only engines in the owner and probe bindings; all_bound
requires every bound engine to match, with at least one bound engine.
Manual or unreadable checks cannot prove a feature is on. This checker is
read-only and never executes activation or rollback steps.

The runner seat activates through `scripts/release-train/feature_rail.py` in
claude-config, following the row's authority and preconditions; operator rows
require the operator's words. Book restarts and lane starts remain distinct.

## Guarded code deploy

`deploy.sh` is the code deploy entry point. It reads the running SHA from
`leafhft deployed --json` and requires a full target SHA between that commit and
`origin/main`. Multiple live SHAs refuse deployment. No live SHA, or any live
row with missing, null or blank SHA metadata, requires `--force-degraded`.
Without it, deployment refuses before checkout. With it, deployment still
requires the exact target to be on `origin/main`, installs that target, records
`running_sha: null` and `digest_may_move: 1`, and leaves all live units on old
code. `--force-degraded` never permits restarts, even with `--restart-unchanged`.
Malformed nonempty SHAs and multiple known live SHAs still refuse deployment.

The digest proof requires byte identity of `deploy/runner/live-run.sh`,
`leafhft/cli.py`, `leafhft/config.py`, `leafhft/policy.py` and `leafhft/types.py`
between running and target commits. This set is closed over the hashed authorized
fields: config defines them and imports only types, types and policy import only
stdlib, cli maps inputs and defaults, and live-run supplies argument values.
Engine paths and bindings are plain strings, so engines.py does not feed the digest.
A new package import into config.py or any new module feeding an authorized field
must extend `DIGEST_PROOF_FILES` in deploy.sh.

The deploy never changes policy or engine files under `/etc/leafhft`,
runs the live launcher, or writes an ack. A changed proof file permits the code
deploy but refuses restarts, even with `LEAFHFT_ALLOW_ACK_CHANGE=1`.

Only `--restart-unchanged` with that proof and the unit's
`LEAFHFT_AUTHZ_V2=1` permits a restart of a previously live unit. Restarts run
one at a time with a 20-second settle and active/live checks. The first failed
recovery stops the sequence. Other books use
`python3 /opt/leafhft/deploy/runner/rearm.py --plan`, then `--apply`, after the
operator restarts them to obtain their own journal refusals.

The installer plan must contain no unrefused retirement. One JSON receipt lands
in `/var/lib/leafhft/deploy-receipts/<utc>-<sha12>.json`, including the proof,
restart lists, installer plan and final deployed verdict. The final verdict
sets the exit code; `stage` and `stage_exit` record any deploy refusal or error.

Only the live binanceus-mm maker uses REST. All paper labels use WebSocket:
025, 050, 100 and 200 have 0.25, 0.5, 1.0 and 2.0 bp half-spreads.
Their paper-only stale limit is 120000 ms because bookTicker can stay quiet
for over 20 seconds. All use the frozen parameters in experiments/PREREG-S2A.md.
The override is saved under risk.stale_feed_ms in config.json; live is unchanged.

To add a book, add its fixed label and parameters to paper-run.sh, add the label
to the installer's validation table and add its instance to enabled.txt. Keep
the single REST maker budget. To retire a book, remove its enabled.txt line and
run the installer. The old enabled instance is stopped and disabled.

## Tier 0 symbol screen

Five paper books run continuously on binanceus over WebSocket to measure fill
rate and markouts before any symbol other than BTC goes live: `eth` (ETH-USD),
`sol` (SOL-USD), `bnb` (BNB-USD), `ada` (ADA-USD) and `sui` (SUI-USD), each at
the 050 half-spread (0.5 bp) and the same frozen params as the BTC paper labels
(vol_mult 1.5, order_frac 0.05, seed_frac 0, cost_rt_bps 0, min_edge_bps 0.25,
stale-ms 120000). The BTC numeric labels (025/050/100/200) remain valid
paper-run.sh inputs but stay out of enabled.txt: the live book owns BTC.

The number to clear before a pair moves toward live rehearsal: at least 15
fills a day for two consecutive days.

Push runs every five minutes to https://ops-dashboard-seven.vercel.app using
/run/leafhft/ingest.env, which bootstrap must supply. Signals run daily through
/usr/local/bin/leafhft-signals, the finished-run helper supplied by bootstrap.
The service sandbox, journal output and bootstrap ordering match the Terraform
reference; push and signals remain oneshot services.

Every ten minutes (three minutes after boot, then every ten) `leafhft-tape.timer`
runs `deploy/runner/tape-run.sh` under a non-blocking flock so overlapping ticks
skip instead of stacking. It writes `fill-tape.json` for the 20 newest `*-live-*`
run directories under `/var/lib/leafhft/runs` that hold a `ledger.sqlite`
(skipping a directory whose tape is already newer than its ledger and has a
receipt, and any recorder directory even if its name matched), then
`scoreboard.json` over the whole runs root, copied into the newest live run
directory. Each script call is bounded by `timeout 120`; a failed script is
logged and does not stop the tick or fail the unit. `reader.run_detail` exposes
both files as `tape` (rows trimmed to the last 200) and `scoreboard`, None when
absent.

## Live dress rehearsal

Fund a few dollars on Binance.US. Create a spot-trading-only API key with no
withdrawal permission, restricted to runner IP 34.203.65.145. Save the key and
secret in a private JSON file with fields `key` and `secret`, each at least 16
characters. Pass its path, never its contents, to:

```text
python scripts/populate_runner_secrets.py --secret-id <name-or-arn> --file <private-json-path>
```

The identity gate and private temporary file remain mandatory. A successful
upload removes both the temporary file and the source file. The operator writes
the secret name to `/etc/leafhft/live-secret-id`. The root oneshot fetches it into
`/run/leafhft/binanceus.env`, root-owned mode 0600, without printing credentials.
Missing or malformed input fails the unit. Systemd reads that file before starting
the live process as leafhft. Restart the secrets unit after rotating the secret.

Before installing, set `deploy/runner/live-run.sh` executable (`chmod 0755`). The
existing installer restores executable bits only for its older scripts. The
manifest retires all paper instances and enables the live secrets unit and book.

1. Run the live label to obtain its readiness printout, config digest and exact
   authorization sentence. Without an ack it refuses trading. The stake defaults
   to $5 and `--stake-usd` replaces `--cash`, which the live CLI refuses.
   `live-run.sh` reads the stake from `/etc/leafhft/live-stake` (a single decimal
   like `100.00`, default `5.00` when absent) and the limits profile from
   `/etc/leafhft/live-profile` (`s2c` or `aggressive`, default `s2c` when absent),
   printing `stake=<v> profile=<p> alternate=<a> transport=<t>` to the journal
   before exec. Either the stake or profile file with unparseable content
   stops the unit before it starts. `/etc/leafhft/live-alternate` (absent or
   empty for none, or `anchor_mm`; anything else stops the unit) makes the mm
   maker and the Coinbase-anchored maker alternate in fixed four-hour blocks
   on the live book: when set, the launcher adds `--alternate anchor_mm
   --reference-venue coinbase --block-minutes 240`. Each block switch cancels
   every open order first; the ledger and the receipt's
   `strategy_state.blocks` record every switch, and the config digest (so the
   ack sentence) changes with either file, requiring a fresh authorization.
   `/etc/leafhft/live-transport` (absent or empty for `rest`, or `ws`;
   anything else stops the unit) selects the feed the live book quotes from,
   passed as `--transport <v>`. It is a feed argument, not an `EngineConfig`
   field, so unlike stake, profile and alternate it does not change the
   config digest or require a fresh ack.
2. The planner writes `LIVE-ACK-<digest12>.txt` by hand under
   `/var/lib/leafhft/live-ack`, with the exact printed sentence, and records the
   operator's authorization beside it in `AUTHORIZATION.md`. Make this directory
   writable by leafhft so it can consume the ack. The run copies only a matching
   ack into its fresh timestamped live run directory, then atomically consumes the
   shared original before arming. This preserves the existing one-ack, one-run
   gate. A restart requires another explicit ack, even with an unchanged digest.
   A config change requires a new digest and sentence. The run never authors an ack.
3. Start `leafhft-live@binanceus-mm.service`. The default `--probe-order` attempts
   one LIMIT_MAKER buy 50 bps below the bid during the first hour. It uses the same
   risk and authorization gates as normal quotes and requests cancellation
   immediately, before any normal quote. The order and cancellation are recorded
   in `live-orders.jsonl`; the ledger records successful probe completion. A failed
   or over-10-second cancellation stops quoting and requires reconciliation. A
   fill cannot be called canceled until its execution has been reconciled.
   If the start is refused for locked balances, run `live-reconcile --cancel`,
   then re-arm.
4. Normal maker quoting follows. At micro stakes the maker targets at least two
   lots while respecting available cash, inventory and the fetched notional floor.
   At $1 and an $80,000 BTC price it abstains and prints `stake below venue minimum`
   at most once per minute. No extra account cash is allocated to the strategy.

Every other gate remains: `LEAFHFT_LIVE=1`, both credentials, Binance.US only,
a limits profile of s2c or aggressive, and a stake at most $500. The authorization
enforces maker-only orders, 20,000 orders per authorization, 20x stake buy
turnover, and the profile's own aggregate cap (s2c: $10 order / $25 position
fixed; aggressive: 10% of stake per order, 80% of stake in aggregate, both
scaling with the stake). The normal account loss, stale-feed and kill checks
also apply to the probe. For an immediate stop, create `KILL` inside the active
run directory and run `systemctl stop leafhft-live@binanceus-mm.service`.
Inspect its receipt, journal and reconciliation files before authorizing another
run. An unclean receipt is not a successful rehearsal.

## Kalshi ticket book (day-3 experiment)

`leafhft-record-kalshi@.service` (enabled as `leafhft-record-kalshi@BTC-15M.service`) records the
Kalshi WebSocket, which needs the same signed handshake as a live order even for market data.
`leafhft-live-secrets.service` (`--load-runner-env`) now writes both env files in one run: the
existing `/run/leafhft/binanceus.env` from `/etc/leafhft/live-secret-id`, and, only when
`/etc/leafhft/kalshi-secret-id` exists, `/run/leafhft/kalshi.env` (root-owned mode 0600) from
that second secret, shaped `{key_id, private_key_pem}`. The PEM's real newlines are escaped to
literal `\n` in the env file; `LEAFHFT_KALSHI_PRIVATE_KEY_PEM` is unescaped client-side (same
convention as `leafhft/feeds/kalshi.py`). Populate it the same way as the Binance.US secret:

```text
python scripts/populate_runner_secrets.py --secret-id <name-or-arn> --file <private-json-path>
```

with the JSON file holding `key_id` and `private_key_pem`. Both the record and the live units
require `leafhft-live-secrets.service` (`Requires=`/`After=`) so a missing or malformed secret
stops them before they start, never with credentials logged.

`deploy/runner/live-run.sh` gains label `kalshi-btc-15m`, reading `/etc/leafhft/kalshi-stake`
(a decimal like `100.00`, default `5.00`) and `/etc/leafhft/kalshi-profile` (`kalshi-experiment`
or `kalshi-week2`, default `kalshi-experiment`), independent of the Binance.US `live-stake` and
`live-profile` files. It runs `leafhft live --venue kalshi --symbol BTC-15M --strategy kalshi_edge
--stake-usd <v> --limits-profile <p>`, same ack-and-arm gate as the Binance.US book: a fresh ack
sentence at `/var/lib/leafhft/live-ack/LIVE-ACK-<digest12>.txt` is required for every stake or
profile change. The experiment caps ($1 per order, $3 per cluster, $5 cumulative, 3 open tickets)
live in `KalshiLimits.experiment()`; `kalshi-week2` widens to $5/$10/$100/10. `KILL` in the active
run directory stops new orders while any open ticket rides to settlement, same as the Binance.US
book. `leafhft kalshi-reconcile --venue kalshi` lists open tickets and balance; `--cancel` cancels
resting orders (IOC tickets should never leave one); `--settle` reads each open ticket's market
result and prints the settlement it would book, without mutating the run's ledger.

### Kalshi policy file

The hot-reloadable sizing and threshold values a policy-driven Kalshi book runs under live at
`/etc/leafhft/kalshi-policy.json`, installed from `deploy/runner/kalshi-policy.default.json` when
absent (the launcher itself never creates it). Inspect or change it with
`leafhft policy show|validate|set key=value... [--path P] [--dry-run]`, which loads, validates
against `KalshiPolicy`'s bounds, and writes atomically, so a bad pair leaves the file untouched.
Every book's `PolicyWatcher` picks up a valid write within 5 s except a `stake_ceiling_usd`
change, which the `set` command flags with a `re-ack` line because it requires a fresh
authorization sentence like any other stake change.

## Kalshi BTCPERP sleeve

`deploy/runner/live-run.sh` gains label `kalshi-perp-btc`, reading `/etc/leafhft/kalshi-perp-stake`
(a decimal like `20.00`, default `20.00`, at most two digits before the point). It runs
`leafhft live --venue kalshi-perp --symbol BTC-PERP --strategy perp_breakout --stake-usd <v>
--limits-profile <p>`, the same ack-and-arm gate as the other Kalshi book: a fresh ack
sentence at `/var/lib/leafhft/live-ack/LIVE-ACK-<digest12>.txt` is required for every stake or
profile change, and the config digest names the collateral, the profile and the strategy params
together (the ack sentence's dollar figure is the sleeve's collateral, not a separate cap).
`kalshi-sleeve` or `kalshi-sleeve-fast` are the only limits profiles this venue accepts; live
requires a stake of at most $25 (`KALSHI_PERP_LIVE_MAX_STAKE_Q`, leaf_hft/broker/live_gate.py),
well inside the $500 mandate, because 5x leverage multiplies the venue's own risk on top of it.

Cadence is a second, operator-selected sleeve profile, not a code change. `/etc/leafhft/kalshi-perp-profile`
(`kalshi-sleeve` or `kalshi-sleeve-fast`, default `kalshi-sleeve` when absent) picks
`PerpSleeveParams.sleeve()` (the frozen day-1 sleeve, 24 h time stop, 30-minute cooldown) or
`PerpSleeveParams.sleeve_fast()` (2026-09-07 sweep pick: same $20/5x/1%/1.5% sleeve, 30-minute
time stop, 15-minute cooldown); every other number is unchanged between the two.
`/etc/leafhft/kalshi-perp-params` (a JSON object of `perp_breakout` strategy params, at most 512
bytes, one line, absent or empty means the strategy's own frozen defaults) is passed through as
`--params` only when set. Both values print on the `kalshi_perp_profile=<p> kalshi_perp_params=<j>`
fields of the launcher's stderr line before exec. Run `leafhft perp-replay <kalshi record dir>
--profile <p> --params <j>` with the same two values to reproduce exactly the config a live run
would arm under, before authorizing it.

The perps exchange signs with its own key, separate from the event exchange's: the first live
margin order (2026-09-07 14:30Z) got HTTP 500 under the event credential, and the reference SDK
(TexasCoding/kalshi-python-sdk) documents "separate API keys issued for the perps exchange". The
operator writes the second secret's name to `/etc/leafhft/kalshi-perps-secret-id`.
`leafhft-live-secrets.service` (`--load-runner-env`) loads it too, only when that id file exists,
into `/run/leafhft/kalshi-perps.env` (root-owned mode 0600), shaped `{key_id, private_key_pem}`
exactly like the event Kalshi secret, with the PEM escaped the same way. Populate it the same way:

```text
python scripts/populate_runner_secrets.py --secret-id <name-or-arn> --file <private-json-path>
```

The name is `leafhft-runner-kalshi-perps-key`. `deploy/runner/units/leafhft-live@.service` adds
`EnvironmentFile=-/run/leafhft/kalshi-perps.env` (optional, after the event Kalshi line), so a
runner without the perps secret starts unaffected; `live_gate.CRED_ENV["kalshi-perp"]` requires
`LEAFHFT_KALSHI_PERPS_KEY_ID`/`LEAFHFT_KALSHI_PERPS_PRIVATE_KEY_PEM` and refuses to arm without them.

`KalshiPerp` (leafhft/broker/kalshi_perp.py) signs against the margin API
(`https://external-api.kalshi.com/trade-api/v2/margin`) with this perps-only RSA-PSS credential and
journals every order the same way as `KalshiLive`. `PerpSleeve` sizes
`collateral x leverage` at the mark into whole 0.0001 BTC contracts, keeps one position at a
time, rests a reduce-only protective stop at 1% adverse when the venue accepts a resting order
and re-checks the mark on every tick as the backstop, ratchets a 1.5% trailing stop only on
completed one-minute bars, applies a 24 h time stop, allows one entry attempt per hour with a
30-minute cooldown after any stop, and closes the sleeve for the window (refusing new entries)
the moment its cumulative realized-plus-unrealized P&L reaches -$20 or the venue reports a
liquidation. `perp_breakout` (leafhft/strategy/perp_breakout.py) is entries-only: on 1-minute
BRTI index bars (reused from the BTC-15M event feed's index stream, since BRTI is venue-wide and
kalshi-perp has no separate feed), it goes long on a close above the 20-bar high and short on a
close below the 20-bar low, only when the 20-bar range sits below 0.75x the 120-bar median range.
Before any order, run `leafhft perp-replay <kalshi record dir>` (a `ticks.jsonl` recorded by
`leafhft record --venue kalshi`) to see the frozen rule's attempts, stops, wins and cumulative
P&L on that recorded day; it places nothing.

## Ramping the stake

The three-day ramp ($100, $250, $500) is an operator-set file change, never a
code edit. Each step is a fresh authorization because the config digest changes
with the stake:

1. Write the new stake to `/etc/leafhft/live-stake` (and, the first time the
   aggressive limits are wanted, `aggressive` to `/etc/leafhft/live-profile`).
2. Run the live label once to print the new config digest and ack sentence,
   then write `LIVE-ACK-<digest12>.txt` under `/var/lib/leafhft/live-ack` with
   that exact sentence, as in step 2 of the dress rehearsal above.
3. Restart `leafhft-live@binanceus-mm.service` so the running unit picks up the
   new stake, profile and ack; an already-running unit never re-reads these
   files on its own.

## Probes on a book

Probe engines ride beside the incumbent only on the books listed in
`/etc/leafhft/kalshi-probe-hosts`, one symbol per line (for example `BTC-15M` and
`BTC-1H`). For a listed symbol, and only when `/etc/leafhft/probe-bindings.json`
exists, `live-run.sh` appends `--probe-bindings /etc/leafhft/probe-bindings.json
--lifecycle-dir /var/lib/leafhft/engine-lifecycle --engine-registry
/var/lib/leafhft/engine-registry/projection.json`. An unlisted book, or any book
when the hosts file is absent, gets a byte-identical argv to the one before probes.
`live-run.sh` only checks that the bindings file exists; its JSON is validated
inside the process, where a bad file switches probes off and never stops the
incumbent. `probe-bindings.example.json` shows the schema.

### Binding a probe (co-host, never displace by default)

`engine_ops probe <engine> --symbols <SYM> --approval <id> --bind` co-hosts the
probe beside the incumbent: it adds the engine to
`/etc/leafhft/probe-bindings.json` (global flag `--probe-bindings`, same schema
as the example) under the engine_ops lock, atomically, and refuses
`max_per_book_exceeded` when the book already hosts `max_per_book` probes. It
never writes `/etc/leafhft/kalshi-engine-bindings.json`. `engine_ops release`
takes the engine back out of `probe-bindings.json` and leaves every other probe
bound. The order is fixed, and `probe --bind` refuses `probe_hosts_missing` when
step 1 is not done, because a probe bound onto a book that does not host probes
never runs:

1. Hosts file: add the symbol to `/etc/leafhft/kalshi-probe-hosts` (the file
   beside `--probe-bindings`).
2. Bind: run `engine_ops probe ... --bind`.
3. Same-digest restart: restart that one book so `live-run.sh` appends the probe
   flags, then re-arm it with `rearm.py --plan <unit>` and `--apply <unit>`.

Displacing the incumbent is a separate flag, `--displace`, and never the first
probe. It rewrites the main bindings file only when the approval card showed
`displaces: <engine>` naming the engine now bound on those symbols (refused
`displace_not_on_card` otherwise); it does not need the hosts file.
`release --restore-bindings` puts a displaced binding back byte for byte; after a
co-hosted probe it has nothing to restore and only the probe entry is removed.

A crashed probe or release is never resumed (C6e). Rerunning the same
`--request-id` after it wrote a step, or while a step was in flight, refuses
`transaction_interrupted`, writes nothing, and names the completed steps, the
in-flight step and the three repair commands below. A `started` request that
wrote nothing outside its request directory is evaluated afresh under the same
id. Every other verb (assign, halt, probe-size, graduate, retire,
probe-activate, approve, registry init, breaker set, and the exposure transfer,
quarantine and register verbs) still completes its earlier write when rerun with
the same id. `registry audit` lists an interrupted probe or release as
`request_incomplete`, and its detail names `engine_ops repair <request-id>`.

Settle it with `engine_ops repair`, which runs under the same engine_ops lock:

1. Report: `engine_ops repair <request-id>` (add `--json` for the JSON) is read
   only and exits 0. It prints the steps, the in-flight step, the captured
   assignment, the registry's current holder, `generation_holds`,
   `approval_consumed`, `finishable` and `rollback_plan` (what a rollback would
   take back and what it would leave).
2. Finish: `engine_ops repair <request-id> --finish` records a probe that is
   already fully written (every step through `approval` done, or `approval` in
   flight with the consumption marker naming this request) and writes nothing to
   the registry, the bindings, the lifecycle or the overrides. It refuses
   `repair_finish_incomplete` when a step is missing and `repair_superseded` when
   the registry moved to another generation. For a release it runs the remaining
   steps, each only while the registry holds the captured generation; a step that
   meets another generation leaves it and records `release_superseded`.
3. Rollback: `engine_ops repair <request-id> --rollback` undoes a probe. It ends
   `rolled_back` (exit 0); or `superseded` with `rollback_superseded` (exit 2,
   nothing undone) when the registry no longer holds the generation it wrote; or
   stays `started` and refuses `repair_incomplete` when an undo failed, and the
   same command retries it. A consumed approval stays consumed, so a new probe
   needs a new approval. A release is never rolled back
   (`repair_rollback_not_allowed`), because that would re-authorize the engine
   without an approval; finish it instead.

Every finish or rollback that acts writes a `repair` receipt (what it undid, what
it left, any errors) and a `repaired` journal row. The same action repeated after
it settled replays that receipt and writes nothing. Repair refuses
`request_not_found`, `request_not_interrupted` (nothing to settle) and
`repair_not_supported` (any verb but probe and release; rerun that verb's same
`--request-id` instead).

A rollback, in process after a failure or through `repair --rollback`, restores
only the entries this request wrote. A file goes back to its snapshot byte for
byte only while it is still exactly this request's own write. Otherwise the main
bindings file (`--displace`) gets back only the symbols still bound to this
engine, the probe bindings file loses only this request's own entries, and a
lifecycle or overrides file someone changed since stands (listed as `left` in the
repair receipt), so a halt written after the crash is never erased. Every
bindings write starts from the file's current bytes, so a probe bound by another
request in the meantime stays bound.

The rule behind every repair and every rollback: a probe or release transaction
captures, at its first step, the assignment generation it acts on (engine,
account, request id, since stamp, and the registry generation). Every later step,
`repair` and every rollback re-read the registry under the lock and go on only
while it still holds that generation for the engine. If the world moved (a
release, or a release and a reprobe under another request id), a rollback undoes
nothing and records `rollback_superseded`; the newer state stands. The request
ends `superseded`, `registry audit` names the partial transaction
(`rollback_superseded at <step> by <request>`; records written before C6e may
show `resume_superseded` or `resume refused <code>`), and its id is retired: a
rerun refuses the same code, so continue under a new `--request-id` once the
engine's state is what you want.

book_flat applies to displacement, not to co-hosting. A co-host never touches the
incumbent, so open tickets on the book do not refuse `approve --item` or
`probe --bind` (both BTC-1H cards on 2026-09-24 were refused `book_flat` while the
book was flat). Only an item approved with `approve --displace <engine>`, which
the approve request digest covers and the card record stores, runs the flat
proof at approve and at `probe --displace`; a co-host approval can never displace.
The proof never counts an exit order (kind `exit`, or an `lx-` client id) as an
open ticket.

Every write to either bindings file keeps the file's mode and owner (a new file
gets 0644 and its directory's owner), set before the atomic replace, and refuses
`bindings_owner_unpreserved` rather than leave a file the books cannot read. The
books run as `leafhft`; the 2026-09-24 05:24Z probe rewrote the main file as root
0600, which the book could not read, and restoring 0644 hot-swapped the book to
the probe engine at full sizing.

The tmpfiles entry `units/leafhft-lifecycle-dir.conf` (installed by
`install-units.sh` as `/etc/tmpfiles.d/leafhft-lifecycle-dir.conf`) creates
`/var/lib/leafhft/engine-lifecycle` (0750, leafhft) and
`/var/lib/leafhft/engine-registry` (0755 root) at boot. `projection.json` and
`publication.json` are 0444 root because engine_ops writes them that way, and no
tmpfiles row touches them: a `z` row on `projection.json` walks from leafhft-owned
`/var/lib/leafhft` into root-owned `engine-registry`, which systemd-tmpfiles refuses
as an unsafe path transition with exit 73, stopping `install-units.sh` before any
unit starts. The live unit's existing `ReadWritePaths=/var/lib/leafhft` already covers
the lifecycle dir; do not widen it.

The books read two paths and engine_ops is the only writer of both. The registry
projection `/var/lib/leafhft/engine-registry/projection.json` is rewritten, 0444
and atomically, by every registry commit (init, assign, release, probe, breaker
set), as the same bytes as `assignments.json`, so the book's gate reads the
generation the registry carries; `engine_ops registry project` rewrites it from
the current registry for recovery and refuses when the registry is invalid. Each
commit brackets the write with `publication.json` (0444): `publishing` before the
registry moves, `published` after the projection, and the book's reader refuses
every engine (`publication_incomplete`) while the marker does not read published
for the projection's generation and digest, so a crash mid-commit never leaves a
released engine authorized. The next root registry load, or `registry project`,
completes an interrupted publication. The
lifecycle dir `/var/lib/leafhft/engine-lifecycle` is engine_ops' default
`--lifecycle-dir`; engine_ops writes every record there as the directory's owner
(`leafhft`, umask 0o022, then 0644), so no book ever meets a root 0600 record, and
the hand-over after each verb only checks for a root entry left behind. The
pre-C0 `/etc/leafhft/engines/lifecycle` is never written again; only
`engine_ops status` reads it, and warns `lifecycle_dir_legacy` for a record that
sits there and not in the new dir. Do not hand-copy either file: the 2026-09-24
first probe needed a copied projection (05:59Z) and a copied lifecycle record
(05:53Z), and a copy goes stale at the next generation.

`deploy/runner/live-run.sh` is a digest-proof file (`DIGEST_PROOF_FILES` in
deploy.sh), so the deploy that carries this change refuses `--restart-unchanged`
and leaves every book on old code. Only the two BTC books re-ack:
`leafhft-live@kalshi-btc-15m.service` and `leafhft-live@kalshi-btc-1h.service`
are restarted with probes and take a fresh ack. The other twelve Kalshi books are
not restarted and need no re-ack; their argv is byte-identical, pinned by the
golden argv test in `tests/test_runner_units.py`.

### Rollback tuple

- Previous sha: record the running sha from `leafhft deployed --json` before the
  deploy; that sha is the code rollback target for `deploy.sh`.
- Argv restore: remove the symbol from `/etc/leafhft/kalshi-probe-hosts` and
  restart that one unit. Its argv returns byte-identical to the pre-probe argv
  and needs no code change.
- Re-arm: after any restart, run
  `python3 /opt/leafhft/deploy/runner/rearm.py --plan <unit>`, then
  `--apply <unit>`, so the restarted book is re-acked; an ack is one-shot and a
  bare `systemctl restart` re-arms nothing.

### Blackout and expiry cliff

Never restart a book inside the 23:35-00:25Z blackout or across the daily
03:0x-03:3xZ expiry cliff. Start the rollout far enough ahead that the restart,
settle and re-ack all finish outside both windows.

### Read holds first

Read holds first: the fleet board and `/var/lib/leafhft/CONTAINMENT`, in a
separate command from any mutation. A live hold or a CONTAINMENT marker stops the
rollout.

### Owner ack

Message the books' owner lane and wait for the ack before touching a live unit.
No ack, no rollout.

### Rollout order

1. `deploy.sh <target sha>`: installs the code and leaves every book on old code
   (live-run.sh moved, so restarts are refused).
2. `deploy_check.py`: confirm every book is still live and fresh.
3. `rollout.sh <target sha> --units leafhft-live@kalshi-btc-15m.service,leafhft-live@kalshi-btc-1h.service`:
   restarts only the two BTC books, one settlement gap per book (never
   `--no-rearm`, which needs all fourteen units).
4. Re-ack: rollout.sh runs `rearm.py --plan <unit>` then `--apply <unit>` for
   each of the two BTC books; confirm both are re-acked and live before closing
   the rollout.

### Approving a probe from the phone (interim, identity grade)

A probe needs a single-use approval (plan D7). Until the kashbot-api signer lands (RT5), the runner mints an identity-grade approval, id prefix `tg1-`, after the operator answers one Telegram card. Run it over SSM as root: `cd /opt/leafhft && /opt/leafhft/.venv/bin/python -m leafhft.engine_ops approve --account <account> --item <engine>=BTC-15M --item <engine>=BTC-1H --request-id approve-<yyyymmddThhmm>`. The runner reads the bot token from the secret `leafhft/approvals-telegram` in memory. The token never goes in argv, an environment file or a log. The runner sends one card to the operator's private chat with the approvals bot. Each line shows the book, the engine, 1 contract, the engine it displaces, the breakers, the expiry and a six-character nonce. It then waits 10 minutes. Reply to that card with the nonces to approve, or NO. The runner accepts only the operator's pinned Telegram user id, in his private chat, replying to an unedited card. It then writes one approval per nonce under `/var/lib/leafhft-approvals` (root, 0700; probe refuses any store whose path is not root-owned), writes a receipt under `engine-evidence/<engine>/receipts`, and prints the exact probe command. Claim each approval within the claim window (default 2 h) or it lapses. Revoke an unused approval with `approve --revoke <approval_id> --request-id revoke-<approval_id>`. After a probe has consumed it, use `engine_ops halt <engine>`. `approve --list` shows every approval with its grade and flags any approval with no presence record. One card is open per store at a time: a second `approve` while a card is open is refused (`presence_busy` while the first run holds the presence lock, `presence_pending_other` while the earlier card's window is still open), so answer or cancel the open card first. `approve --cancel <request_id>` voids an open card for good: every record change is a compare-and-swap under the engine_ops lock, so a reply, a card send or a mint that races the cancel finds the record voided and stops without minting; a card already in flight gets a `VOID` follow-up. The secret fetch runs the aws cli with an allowlisted environment (PATH, LANG, the region variables; both AWS config files set to /dev/null), so only the instance role can answer; an `AWS_PROFILE`, static key, session token, credentials file, container or web-identity variable in the calling shell is dropped. Every file read from the store is opened without following a symlink and must be a regular file owned by root (or the running user), not group or other writable; anything else refuses `store_corrupt` (probe reports it as `approval_valid`). The store path itself may contain no symlink and must resolve to itself. Limits: root on this host, or anyone driving the operator's Telegram, can forge a `tg1-` approval. Keep Telegram signed in on the phone only, with a cloud password and a Face ID passcode lock.

### Assigning an engine to a tenant account from the phone (C6f, identity grade)

`engine_ops assign` needs a single-use approval of kind `assign`. Until RT5 lands, `approve --kind assign` mints one from one Telegram card. It widens the identity-grade exception from probes to one tenant assignment per card, only on the operator's tap. The card controls are the probe card's: one open card per store (`presence.lock`), the 3 per hour and 6 per day limits shared with probe cards, the 600 s reply window, the reply bound to the nonce, the operator's user id and the card's message id, and single use. The runbook, run over SSM as root in `/opt/leafhft` with `/opt/leafhft/.venv/bin/python -m leafhft.engine_ops`:

1. Unbind from the old account first. If `status` shows the engine assigned to another account, `release <engine> --request-id release-<engine>-<yyyymmdd>`. If another account's bindings file still runs the engine on any enabled symbol, take it off those books there. The card is refused before it is sent while either holds (`not_assigned_elsewhere`, or `bound_elsewhere`, which uses the same default-and-disabled expansion as `registry audit`).
2. Mint: `approve --kind assign --account <lane id or owner> --item <engine>=BTC-1H,ETH-1H,... [--role legacy] --request-id assign-approve-<yyyymmddThhmm>`. Exactly one `--item`; `--displace` is refused. The account must be a registered account (its key, or the lane id of exactly one account) and must not be exit-only; `unknown_account` and `account_exit_only` refuse before a card. The card names the engine, the account and its label and domain, every symbol, the role, and says in plain words that it assigns a real-money engine to that account. Reply to it with the nonce, or NO. At mint the same checks run again under the engine_ops lock; an engine that moved in the meantime is declined and nothing is minted. The approval's digest covers kind `assign`, the engine, the account key, the symbols and the role, and it expires after `--claim-hours` (default 2 h).
3. Assign: run the exact `assign <engine> --account <account key> --symbols ... --role legacy --approval <tg1-id> --request-id assign-<engine>-<tg1-id>` line the mint printed, for example `--request-id assign-probe-a-tg1-20260924T120000Z-probe-a-002f1b`. The request id carries the full approval id, with no hash and no truncation, so it is unique exactly when the approval id is (timestamp, engine, nonce): two assign approvals for one engine on the same day print two request ids and the second command is not refused `request_id_reused`. The id is at most 100 characters and passes the request id check unchanged; it is derived at print time and nothing new is signed. It consumes the approval once; a second request with the same approval refuses `approval_valid`.
4. The lane user enables the books: the tenant binds the engine on that account's books and turns them on through the account lane's own flow. Nothing in this runbook binds or starts a book.

Revoke an unused assign approval with `approve --revoke <tg1-id> --request-id revoke-<tg1-id>`, exactly as for a probe approval. A probe command refuses an assign approval (`approval kind 'assign' is not 'probe'`), and a probe `approve` without `--kind` behaves exactly as before.

## Deploy verb (deploy.py)

`deploy.py` is the one deploy and re-arm verb. It chooses between deploy.sh and
rollout.sh so nobody picks by hand, and it runs nothing it has not printed first.
Check out the target on the box first (`git -C /opt/leafhft checkout --detach <sha>`),
then run it as root with the venv interpreter, which can import `leafhft`:

    /opt/leafhft/.venv/bin/python /opt/leafhft/deploy/runner/deploy.py <40-hex sha> \
      --approved-by <handle> [--approval-ref <operator receipt id>] \
      [--units leafhft-live@kalshi-btc-15m.service,leafhft-live@kalshi-btc-1h.service] \
      [--dry-run] [--window-override "<reason>"]

Decision. It diffs the running sha against the target over `DIGEST_PROOF_FILES`,
read from deploy.sh itself, for the named units (default: every live unit).

- Digest unchanged: `deploy.sh <sha> --restart-unchanged`. deploy.sh restarts
  exactly the live fleet, so `--units` must name every live unit or be omitted.
- Digest may move (a proof file changed, or a named unit reports no running sha):
  `deploy.sh <sha>` (no restarts), then `rollout.sh <sha> --units <named>`, which
  restarts and re-acks one book per settlement gap. rollout.sh runs its own
  no-restart deploy.sh pass first; that second pass is idempotent.

Subset rollout. When `--units` names fewer units than `leafhft deployed --json`
reports (the two BTC books, say), the other books must come out exactly as they
went in:

- Before any mutation the verb captures each unselected unit's identity (its full
  sha when live, `-` when not live) and its `systemctl is-active` state, and
  records both in the receipt (`predecessors`, `unselected_active_before`).
- Both commands run with `LEAFHFT_INSTALL_LIVE_ONLY=<selected instances>`, for
  example `kalshi-btc-15m,kalshi-btc-1h`. Under it install-units.sh enables every
  other wanted `leafhft-live@` instance without `--now`, so an inactive or failed
  book outside the selection never starts. Unset or empty, the installer starts
  every wanted unit exactly as before. rollout.sh exports the same variable itself
  for any `--units` subset.
- After deploy.sh the verb re-reads the active states and fails, before rollout.sh
  restarts anything, if any unselected state changed.
- rollout.sh gets `--expect-unselected unit=<sha>|-,...`. It captures the same
  identities itself before mutation (kept in its state file for `--resume`),
  refuses when they disagree with the caller's read, and verifies at the end with
  `rollout_verify_subset`: selected units live on the target, unselected units as
  captured, no other unit live, and the collector verdict those identities imply
  (DRIFTED for a two-sha fleet). It prints and records `IN_SYNC_SUBSET` naming
  both sets. Fourteen selected units keep the original fourteen-row IN_SYNC check.
- After rollout.sh the verb re-reads `leafhft deployed --json` and fails unless
  every unit matches that expectation (`deployed_after` in the receipt).

Clock. The time checks read the clock after the preflight reads, never before
them, and again immediately before each command (receipt `boundaries`). Before
rollout.sh the check covers its remaining projection. On a subset, the gap and
blackout guard runs on a fresh clock after every read and receipt write,
immediately before each `systemctl stop`, so no I/O sits between the last check
and the stop. rollout.sh runs it after the book's precheck and its
`prechecked`/`restart_started` checkpoints. `rearm.py --apply`, which stops and
starts the book a second time, runs it itself after its journal read, because
rollout.sh sets `LEAFHFT_REARM_WINDOW_GUARD=1` and passes the override as
`LEAFHFT_REARM_WINDOW_OVERRIDE`. The rules live once, in rearm.py
(`window_refusal`); the verb imports them and rollout.sh's
`rollout_boundary_refusal` mirrors them. A refused guard never issues the stop
and leaves the unit untouched. rearm.py exits 3 outside the gap and 4 inside the
blackout. At the first boundary, outside the gap the book drops its
`restart_started` (`restart_held` instead) and waits for the next gap, and inside
the 23:35-00:25Z blackout it stops between books. At the re-arm boundary, outside the gap it holds the re-arm for the next
gap (at most one 900 s cycle, recorded as the unit's `rearm_held` timestamp and
the state's `rearm_held` note), then re-reads the plan and applies again. Inside
the blackout it stops with that book started but gate-closed, so it trades
nothing, and `--resume` redoes the book. Either stop names the boundary in the
receipt `error`, which the verb copies into its own `failure`.
`--window-override` is passed through to rollout.sh and lifts only the blackout
stop. A fourteen-unit rollout skips both re-checks and keeps the pre-L16a
command sequence byte for byte; the verb's admission projection is its time
guard.

Resume. `rollout.sh --resume` on a subset re-reads `leafhft deployed --json`
and compares every unselected unit with the identity saved before the first
mutation. Any difference refuses the resume with `predecessor_drift` naming the
unit, saved and found shas. A moved unselected book means another lane touched
the fleet, and the operator decides.

Refusals. Each one prints `REFUSED: <reason>` and exits 2 with nothing run and no
receipt written:

- `/var/lib/leafhft/CONTAINMENT` exists or cannot be stat'ed. No flag lifts this.
- `leafhft deployed --json` fails, times out, exits 3, or returns malformed rows.
- The sha is not the checked-out head of `/opt/leafhft`.
- The live fleet is drifted or reports no sha. deploy.sh would need
  `--force-degraded`, and this verb never passes that flag.
- The digest proof (`git diff`) is unavailable.
- Restart-unchanged only: a named unit's ack has used `LEAFHFT_ACK_MAX_STARTS`
  starts in `arms.jsonl`, or its config digest is unreadable.
- Time: from now to the projected end, the run would touch the 23:35-00:25Z
  blackout or the 02:30-03:30Z pre-cliff window. It also refuses when now is
  outside the [60, 420] s gap of the 900 s settlement cycle. The projection is an
  estimate: 600 s per deploy.sh pass plus 900 s per rollout book, or 30 s per
  restart-unchanged unit. `--window-override "<reason>"` lifts only these time
  refusals and records the reason and the overridden refusals in the receipt.

Receipt. Before the first command runs, the verb writes
`/var/lib/leafhft/deploy-receipts/<utc>-<sha12>.json` (schema
`leafhft.deploy-wrapper.v1`). After each command it rewrites the receipt
atomically. The receipt holds the sha, units, path, digest_may_move, moved files,
commands, exit codes, child receipt paths, started_at, ended_at, approved_by,
approval_ref, the window override and the outcome. After deploy.sh, the verb reads
deploy.sh's own receipt. It stops before rollout.sh unless deploy.sh finished and
proved the digest the verb expected. `--dry-run` prints the decision and the
commands, runs nothing, and writes no receipt.

Ack start limit. The source of truth is `LEAFHFT_ACK_MAX_STARTS` in
`leafhft/broker/live_gate.py`, the number the gate enforces. deploy.py imports it
and does not copy it. It also imports `ACK_DIR` from rearm.py, because rearm.py
has no start limit of its own. rollout.sh's `>= 48` check is a stricter margin
kept inside that script. Fold it into the same constant when rollout.sh is next
edited.
## Account lane registry projections (C14-A, phase A)

Every provisioning tick, `leafhft-account-provision.service` (root) registers each bound lane
the engine registry does not know as an exit-only domain, then publishes the lane's own view of
the registry to `/var/lib/leafhft-projections/<lane>/engine-registry/projection.json` and its
replay floor to `/var/lib/leafhft-projections/<lane>/floor.json`. Both files are root-owned 0444
in root-owned 0755 directories, outside every lane root. Only the provisioner writes the floor and
never lowers it; the lane only reads it and refuses any projection below it
(`projection_replayed`), and refuses a projection whose floor is missing
(`projection_floor_missing`). The unit creates `/var/lib/leafhft-projections` in its
`ExecStartPre` and lists it in `ReadWritePaths`, because `ProtectSystem=strict` leaves `/var`
read-only. Registration writes the registry itself (its `.lock`, journal, `assignments.json`,
exposure state and history) and publishes roles under `/var/lib/leafhft-exposure`, so the unit
also lists exactly `/var/lib/leafhft/engine-registry` and `/var/lib/leafhft-exposure` there, never
their parents; without them a new lane is `register_refused` with EROFS and never gets a
projection. Both are optional (`-`) entries: the installer's tmpfiles create them, and a host
without them reports `register_refused` rather than failing the whole unit. The agent re-reads the
projection's bytes on every check, so an older copy put back with the same size, inode and
timestamp is still `projection_replayed`.

If one lane's registration is refused twice in a tick, nothing from that tick's registry snapshot
is published to any lane; the next tick reloads. A lane's timers start only once its projection
and floor are published. To start lanes report-only without a projection, the operator creates
`/etc/leafhft-accounts/REGISTRY_REPORT_ONLY` (root) and removes it once projections publish. The
unit discards stderr, so run `/opt/leafhft/.venv/bin/python -m leafhft.account_lane_provision`
as root by hand to read why a lane's timers were refused.

An enabling control row (`book.configure` or `engine.configure` with entries on) must pass the
registry's entry authority first, then every check push's original applier makes (exposure role,
book validation, the gated-engine restriction). Two paths still bypass registry authority until
phase B: direct writes to a lane's `engine-bindings.json` (lane-writable 0600, because push's
in-process book lowering writes it as the lane user), and the owner CLI's `leafhft engine set`.
Both move with the phase B catalog filter.

## Stage B: executor mode, one book at a time (C16d)

Stage B moves one book's incumbent onto the executor adapter, proves it for 24 h with zero parity
divergence and zero probe disturbance, and only then moves the next book. `stage_b.py` makes that
rule mechanical and fails closed: it keeps the flip set in `/etc/leafhft/kalshi-executor-hosts`
(one symbol per line), judges each 24 h window from the book's own status, and refuses a flip that
the evidence does not support. It restarts nothing and re-acks nothing; it prints those commands.
It writes only under `/var/lib/leafhft/stage-b` (ledger, ticks, receipts) and the hosts file. Run
every verb as root on the runner:

    /opt/leafhft/.venv/bin/python /opt/leafhft/deploy/runner/stage_b.py <verb> ...

Exit codes: 0 done or accept, 1 verdict refused, 2 refused or bad input (the refusal code is on
stderr and in a receipt under `/var/lib/leafhft/stage-b/receipts`), 3 insufficient evidence.
`stage_b.py status` (read only) shows the hosts set, open windows, the last verdict per book and
which book may flip next. BTC-15M is the first book.

### Dormant storage capacity

W1-STAGEB supplies dormant storage support only. `EngineRegistry` and `CanaryStore`
default to 64 records. An explicit constructor `capacity=256` supports bounded storage;
256 is not a supported concurrent live-engine claim. No runtime caller opts in, and
this slice adds no environment variable, CLI option, or persisted capacity field.
Reopen expanded stores with the same capacity. Default readers refuse overflow without
truncating or deleting records, so rollback must account for any later storage expansion.

The C15 parity mirror and the program contracts `C16a.md`, `C16b.md`, `C16c.md`, and
`C16d2-readme.md` still govern integration and activation. C16c's deferred incumbent
adapter integration must be reconciled separately.
Later source work must coordinate runtime capacity wiring, client partitions, ticket capacity,
and per-book probes. The independent limits remain 16 risk-book slots, 64 ticket engines,
and four probes per book. Account override documents still cap each account at 64 engines;
their capacity and related control consumers also need a later slice.

This storage change does not deploy, enable executor mode, bind an engine, activate a mirror,
restart a book, or activate capacity. Later operator-gated activation must coordinate all
consumers, preserve rollback compatibility, and complete the mirror window and one-book
acceptance sequence below before widening. Storage tests do not satisfy those live gates.

### Preconditions

- C16c is merged and deployed with the executor flag off on every book.
- The book runs the C15 parity mirror (`--parity-mirror`), so its `kalshi-edge-status.json`
  carries the `parity_mirror` block.
- live-run.sh reads two files in `/etc/leafhft`, one symbol per line (C16d2-live, #542, merged
  at 5d6450b). A book listed in `kalshi-parity-mirror-hosts` starts with `--parity-mirror`; a book
  listed in `kalshi-executor-hosts` starts with `--parity-mirror --executor-mode`, because executor
  mode always brings the mirror (C16c refuses `--executor-mode` alone), and `--parity-mirror`
  appears once when a book is in both. `stage_b.py` is the only writer of both files: flip and
  unflip write `kalshi-executor-hosts`, mirror and unmirror (C16d2-mirror-verb, #557, merged at
  87e6864) write `kalshi-parity-mirror-hosts`; do not hand edit either. A line matches after all
  whitespace is stripped, exactly and case included (`btc-15m` does not list BTC-15M). A symlink, a
  directory, a file the `leafhft` user cannot read, more than 64 lines or a line of 256 characters
  or more makes that file unusable: the book's journal carries
  `kalshi stage b: <path> unusable; it adds no flag` and that file adds no flag. An unlisted book
  keeps a byte-identical argv. Both flags enter the book's config digest, so adding a book to
  either file, or removing it, needs that book's restart and re-ack. The hunk reaches the runner
  only with a code deploy that carries 5d6450b, and the mirror verb only with one that carries
  87e6864; check `leafhft deployed --json` first. Until then both files are inert, a flip changes
  no argv, and every flipped verdict refuses `executor_mode_unconfirmed`, which is the intended
  fail closed state.
- Turn the mirror on before the mirror window (runner train, operator's yes, holds read first, see
  Holds and owner ack): `stage_b.py mirror --symbol <book> --sha <running sha> --request-id <id>`
  adds exactly one line to `/etc/leafhft/kalshi-parity-mirror-hosts`, keeping the file's mode and
  owner. It refuses, in order, `containment`, `bad_symbol`, `bad_sha`, `bad_request_id`,
  `already_mirrored` and `already_flipped` (executor mode already runs the mirror). Then run
  `stage_b.py restart-plan --symbol <book> --sha <running sha>` and the one one-unit rollout.sh
  command it prints, which carries `--txn stage-b-<book>-mirror-<compact UTC>` and restarts and
  re-acks that one book; only after that, run the printed `stage_b.py arm --phase mirror` (step 1
  of Mirror window). Take the mirror off with
  `stage_b.py unmirror --symbol <book> --sha <sha> --request-id <id> --reason <text>`: it refuses
  `bad_input`, `not_mirrored` and `still_flipped` (unflip first, executor mode keeps the mirror
  on), is never blocked by containment, closes the book's open mirror window, and its restart
  runs the same way under `--txn stage-b-<book>-unmirror-<compact UTC>`.

### Mirror window

1. `stage_b.py arm --symbol BTC-15M --phase mirror --sha <running sha> --request-id <id>` opens a
   window at now. The book must not be in the hosts file. arm reads the book's running sha and
   config digest from its own files: the newest run of the book whose status is at most 180 s old,
   its status `build.git_sha` and `build.dirty`, and its config.json `build.git_sha` and `digest`.
   It refuses `identity_unreadable` when there is no such run, a field is missing, the build is
   dirty or the two shas differ, and `identity_sha_mismatch` when the book does not run `--sha`.
   `--sha` is only an assertion; the window stores the observed sha, config digest and run.
2. Let the ticks run for 24 h (next section).
3. `stage_b.py verdict --symbol BTC-15M --phase mirror` accepts only when every tick read a live
   status and a running mirror with zero divergence in every class, nothing invalidated or dropped,
   frames rising in every run, no status older than 180 s, no restart gap over 300 s, the same sha
   and config digest the window was armed on in every line, and `executor_mode` never true.
   Coverage is counted in 900 s intervals: at least 75 percent of the window's intervals hold a
   readable line, and never more than 2 intervals are missed in a row. `--hours` cannot go below
   24.

### Flip one book

1. `stage_b.py flip --symbol BTC-15M --sha <sha> --request-id <id>`. It refuses, in order,
   `containment`, `bad_symbol`, `already_flipped`, `mirror_not_accepted`, `mirror_sha_mismatch`
   (the accepted mirror window ran another sha) and `stage_b_in_progress` (a flipped book has no
   accepted flipped verdict yet). On success it adds exactly one line to `kalshi-executor-hosts`,
   keeping the file's mode and owner, and prints the next commands.
2. Run `stage_b.py restart-plan --symbol BTC-15M --sha <sha>` (read only), then run the one
   `rollout.sh <sha> --txn <tag> --units leafhft-live@kalshi-btc-15m.service --expect-unselected ...`
   command it prints. restart-plan refuses `containment`, `deploy_unavailable`, `restart_refused`,
   `head_mismatch`, `unit_unknown`, `fleet_not_on_sha`, `restart_window`, `no_stage_b_step` (no
   flip or rollback of the book in the ledger), `step_pending` (rerun the flip or unflip with its
   `--request-id` first) and `step_sha_mismatch`. rollout.sh waits for
   the settlement gap, restarts that one book and re-acks it with `LEAFHFT_REARM_WINDOW_GUARD=1`.
   Do not use deploy.py for a same-sha flip: the hosts file is not a digest-proof file, so
   deploy.py takes its restart-unchanged path, which restarts the whole live fleet and cannot
   re-ack a book whose config digest the flip moved.
3. Only when the rollout stopped with the gate closed, re-ack by hand:
   `python3 /opt/leafhft/deploy/runner/rearm.py --plan <unit>`, then the printed
   `LEAFHFT_REARM_WINDOW_GUARD=1 python3 /opt/leafhft/deploy/runner/rearm.py --apply <unit>`. A
   `--plan` that shows no plan means nothing is left to apply. An ack is one-shot, so a restart
   without the re-ack leaves the book stranded.
4. `stage_b.py arm --symbol BTC-15M --phase flipped --sha <sha> --request-id <id>-arm` opens the
   flipped window.

A repeated `--request-id` replays the recorded result and writes nothing; the same id on another
verb, book, sha or phase refuses `request_id_reused`.

Every flip and every rollback is its own rollout transaction. rollout.sh keys its state file on the
sha, so without a tag the second book on one sha would meet the first book's finished state
(`state already exists`, and `--resume` then refuses or skips the verified unit). restart-plan
therefore prints `--txn stage-b-<book>-<flip|rollback>-<step start, compact UTC>`, for example
`--txn stage-b-btc-15m-flip-20260925T120100Z`, and rollout.sh keeps that transaction in
`/var/lib/leafhft/rollout-state/<sha12>-<tag>.json`. The tag is derived from the book's flip (or
newest rollback) in the ledger, never typed: the next book, and a rollback of a flipped book, start
clean, and a re-print of the same step prints the same tag, so its printed `--resume` form resumes
that transaction and nothing else. The flip and unflip receipts, the flipped window and its
acceptance receipt all carry the tag. A tag outside `[A-Za-z0-9._-]{1,64}` makes rollout.sh fail;
without `--txn` rollout.sh behaves exactly as before. When a tagged run fails, the
`Remaining command:` line it prints carries the same `--txn <tag>`, so its `--resume` reopens that
transaction and never the sha-only state; an untagged run prints the line unchanged.

### Ticks

Ticks run from a transient timer, four times an hour, clear of the quarter-hour settlements:

    systemd-run --unit leafhft-stage-b-tick --on-calendar '*-*-* *:07,22,37,52:00 UTC' /opt/leafhft/.venv/bin/python /opt/leafhft/deploy/runner/stage_b.py tick

Each tick appends one line per run of each armed book (newest 128 run dirs, status files capped at
1 MiB) to `/var/lib/leafhft/stage-b/ticks-<window>.jsonl`. An unreadable status is recorded as
null, never zero, and a null fails the verdict. A book's counters reset at every restart, so the
window is judged run by run, never from one read at hour 24. No unit file ships yet: a durable
`leafhft-stage-b.{service,timer}` pair moves the unit count pinned by `test_units_and_hardening` and
touches install-units.sh, both in flight on PR #455 (C13). Until that merges, re-create the
transient timer after a runner reboot and check it with `systemctl list-timers leafhft-stage-b-tick*`.

A run dir the scan cannot classify is an unknown candidate, never skipped: a config with no or a
null `venue` (or a venue leafhft does not know), a `mode` that is not `paper`, `replay` or `live`,
a status or config file whose stat or read fails twice (a permission error, say), a run-named entry
whose directory type cannot be read, or a dir with no run file.
Only readable proof excludes a run dir: another venue, a known other mode, another book's symbol,
or a status and a config both older than the window. Any timestamp inside the window keeps a
candidate: an old status beside a config written since arm is still in the window. A candidate is
never excluded before it is fully resolved: its classification and every timestamp are read, a
failed read is retried once, and only then does the one exclusion check run. Every resolved field
is a tagged value, `Resolved(value)` or `Unavailable(reason)`, never a bare null: a file counts as
absent only when both reads and an `lstat` agree it is gone, so a stat or config read that fails
twice on a file that exists is `Unavailable`, which keeps the candidate unknown and inside every
window. The scan filters nothing before resolve: every entry under the runs root is resolved, and an
entry whose name is not a run name, or that is proven not a directory, is excluded only on that
resolved fact. An unknown
candidate writes a null line marked `unknown` with its reason into every window it may belong to,
and while one lies in a window the verdict is `unavailable` (exit 4), never accept, unless harm
was read beside it: a divergence, a disturbance or any other rule but `unreadable` refuses the
window whatever unknown candidate or short window sits beside it (precedence refused >
unavailable > insufficient > accept). Resolution is per tick: a candidate unavailable on one tick
and read on a later one is judged on what that later tick read. A status that reads but whose timestamp cannot be read (after one re-read) is the same: an
`unknown` line with no coverage credit, never an `ok` one. Fix the run dir (its permissions or its
config), then `arm` a new window: the unknown line stays in the old window's ticks.

### Verdict and the next book

After 24 h, `stage_b.py verdict --symbol BTC-15M --phase flipped` exits 0 (accept), 1 (refused,
naming every failing rule: `unreadable`, `stale_status`, `mirror_not_running`,
`mirror_invalidated`, `mirror_idle`, `divergence`, `run_gap`, `identity_unverified` (a line with
an unreadable sha or config digest, or a dirty build), `identity_changed` (a line on another sha
or config digest than the window was armed on), `executor_mode_unconfirmed`, `disturbance`) or 3
(insufficient, naming `young` when the window is younger than 24 h, `coverage` when under 75
percent of its 900 s intervals hold a readable line, and `coverage_gap` when more than 2 intervals
in a row hold none) or 4 (unavailable: an unknown candidate lies in the window, see Ticks). A
flipped window also refuses on any incumbent, lane or stale snapshot
refusal caused by a probe; revision retries are recorded, not judged. The acceptance receipt,
`receipts/verdict-<window>.json`, names the book, the sha, the config digest and the window bounds
(start, end, first and last tick). It is written once; a verdict rerun after a failed ledger save
adopts it instead of judging again. The next book's flip is refused `stage_b_in_progress` until
this book has an accepted flipped verdict on the sha it was flipped on. A refused window stays
refused: fix the cause, then `arm` a new window (or `unflip`).

### Rollback tuple

- Previous sha: record the running sha from `leafhft deployed --json` before any code deploy; that
  sha is the code rollback target.
- Flip set: `stage_b.py unflip --symbol BTC-15M --sha <sha> --request-id <id> --reason "<why>"`
  removes the book from `kalshi-executor-hosts` and closes its open flipped window. unflip is never
  blocked by containment; it refuses only `bad_symbol` and `not_flipped`.
- Restart that one unit: `stage_b.py restart-plan --symbol BTC-15M --sha <sha>` after the unflip,
  then the one rollout.sh command it prints, which carries the rollback's own `--txn`. Use the printed `rearm.py --plan <unit>` and guarded `--apply
  <unit>` only when the rollout stopped with the gate closed.

### Holds and owner ack

Read holds first: the fleet board and `/var/lib/leafhft/CONTAINMENT`, in a separate command from
any mutation. flip refuses while the containment marker exists. The flip, the restart and the
re-ack belong to the runner train with the operator's yes; message the runner train and wait for
its ack before touching a live unit. restart-plan projects the 23:35-00:25Z blackout and the
02:30-03:30Z pre-cliff through deploy.py's windows, and rollout.sh and rearm.py re-check the gap
and the blackout immediately before each stop.

## Owner-lane parking marker (owner-domain-control v1 section 7)

Run as root to park the owner lane:

```sh
install -d -m 0755 -o root -g root /etc/leafhft-account-agent
marker_tmp=$(mktemp)
printf '%s\n' '{"schema":1,"lanes":["e6216739-a5c2-4a10-9457-c2b52a96288a"]}' > "$marker_tmp"
install -m 0644 -o root -g root "$marker_tmp" /etc/leafhft-account-agent/owner-lanes.json
rm -- "$marker_tmp"
```

The root agent stops, disables and deactivates parked lanes every pass. To unpark:

```sh
rm -f -- /etc/leafhft-account-agent/owner-lanes.json
```

An invalid marker makes root keep enforcing the last-known-good set and page
`owner_lanes_invalid`; tenant units ignore invalid markers. Inspect
`/var/lib/leafhft-account-agent/owner-lanes-refusal.json` for the alarm,
`/var/lib/leafhft-account-agent/owner-lanes-lkg.json` for the enforced set, and
`/var/lib/leafhft-account-agent/refusals/<lane>.json` for a lane refusal.
Provisioning does not create or repair this marker directory.

Unparking does not restart a lane. The dashboard must issue a new start: a refused
cursor stays terminal for its revision.

## Whole-host view (deploy_check.py --host)

Run as root: `python deploy/runner/deploy_check.py --host` (add `--json` for one object).
Reads owner `leafhft deployed --json`, active account units, lane `status.json`, child start
times, rollout/deploy receipt filenames, and Gold arms under `/var/lib/leafhft-projections`.
The target defaults to `/opt/leafhft` HEAD; override with `--target SHA40`. Evidence paths can
be set with `--accounts-dir`, repeatable `--receipt-dir`, and `--gold-arms-dir`.
Tenant and child shas are derived from start times relative to HEAD-move receipts, not recorded
build identities. Expected renewal is the lane unit start plus 24 hours, also derived.
`IN_SYNC` exits 0; `CONVERGING` exits 3 and names lagging lanes/children or Gold arms;
`DRIFTED` exits 1 for owner drift; `UNREADABLE` exits 4 for any missing/unreadable required
evidence, including an unknown HEAD-move time. Unreadable evidence takes precedence.
This command only reports: it never restarts lanes or changes an arm.
Known limits: child shas are inferred from receipt times, and book processes not listed in a lane's status.json are not seen.
