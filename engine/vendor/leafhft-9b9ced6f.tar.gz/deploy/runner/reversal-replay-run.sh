#!/bin/sh
# Measurement only: GET venue data and write datasets, never change a book.
set -eu

runs_root="${LEAFHFT_RUNS:-/var/lib/leafhft/runs}"
py="${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}"
scripts_dir="${LEAFHFT_SCRIPTS:-/opt/leafhft/scripts}"
datasets="$runs_root/datasets"
mkdir -p "$datasets"
work=$(mktemp -d "$datasets/.reversal-replay.XXXXXX")

finish() {
    code=$?
    trap - 0
    set +e
    "$py" - "$datasets" "$work" "$code" <<'PY'
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

datasets, work = map(Path, sys.argv[1:3])
entry = dict(utc=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
             exit_code=int(sys.argv[3]), n_exits=None, n_resolved=None,
             verdict=None, refusal_counts=None)
try:
    report = json.loads((work / "replay.json").read_text(encoding="utf-8"))
    primary = report["C"]["verdict_table"]["1:800"]
    entry.update(n_exits=report["A"]["n_exits"], n_resolved=report["A"]["n_resolved"],
                 verdict=primary["verdict"], refusal_counts=primary["refusal_counts"])
except (OSError, ValueError, KeyError, TypeError):
    pass
with (datasets / "reversal-replay-prospective.log").open("a", encoding="utf-8") as log:
    log.write(json.dumps(entry, separators=(",", ":")) + "\n")
PY
    rm -rf -- "$work"
    exit "$code"
}
trap finish 0
trap 'exit 143' TERM
trap 'exit 130' INT

# Share this lock with manually dispatched analysis; never overlap this replay.
exec 9>"$datasets/reversal-replay.lock"
flock -n 9 || exit 75

# Bound refresh and replay together; leave time for the exit receipt and cleanup.
timeout -k 10 1500 "$py" - "$runs_root" "$scripts_dir" "$work" "${1:-}" <<'PY'
import json
import os
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlencode

from leafhft.kalshi_account import _make_default_fetch, REST_URL

runs, scripts, work = map(Path, sys.argv[1:4])
datasets = runs / "datasets"


def cents(value):
    if type(value) is not int or value < 0:
        raise ValueError("cash must be nonnegative integer cents")
    return value


try:
    snapshot = datasets / "TRIAL-START-SNAPSHOT.json"
    if snapshot.exists():
        # The snapshot records venue free cash, never portfolio value or book stakes.
        start = cents(json.loads(snapshot.read_text(encoding="utf-8"))["balance_cents"])
    else:
        start = cents(int(sys.argv[4]))
    fetch = _make_default_fetch(os.environ["LEAFHFT_KALSHI_KEY_ID"],
                                os.environ["LEAFHFT_KALSHI_PRIVATE_KEY_PEM"], REST_URL)
    rows, seen, cursor = [], set(), None
    for _ in range(400):
        params = {"limit": 200}
        if cursor:
            params["cursor"] = cursor
        page = fetch("/portfolio/settlements?" + urlencode(params))
        if not isinstance(page, dict) or not isinstance(page.get("settlements"), list):
            raise ValueError("malformed settlements page")
        rows.extend(page["settlements"])
        cursor = page.get("cursor")
        if not cursor:
            break
        if not isinstance(cursor, str) or cursor in seen:
            raise ValueError("invalid or repeated settlements cursor")
        seen.add(cursor)
    else:
        raise ValueError("settlements page cap reached")
    end = cents(fetch("/portfolio/balance")["balance"])
    dump = work / "settlements.json"
    dump.write_text(json.dumps(rows, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(dump, datasets / "settlements-dump.json")
except (ValueError, KeyError, TypeError, OSError):
    print("reversal-replay: refresh or freeze cash unavailable", file=sys.stderr)
    raise SystemExit(4)

code = subprocess.call([
    sys.executable, str(scripts / "kalshi_reversal_replay.py"),
    "--runs-root", str(runs), "--settlements-json", str(datasets / "settlements-dump.json"),
    "--since", "2026-09-13T17:25:00Z", "--frozen-at", "2026-09-13T17:25:00Z",
    "--start-cash-cents", str(start), "--end-cash-cents", str(end),
    "--latency-ms", "0,800,1000", "--multipliers", "0,0.5,1,2",
    "--max-extra-cents", "100", "--max-open-cents", "200", "--budget-cents", "200",
    "--floor-cents", "1000", "--seed", "20260913", "--bootstrap", "10000",
    "--out", str(work / "replay.json"), "--markdown", str(work / "replay.md"),
])
if code == 0:
    # Keep the per-run JSON for the exit receipt; publish each complete file atomically.
    for source, suffix in (("replay.json", "json"), ("replay.md", "md")):
        staged = work / ("publish." + suffix)
        staged.write_bytes((work / source).read_bytes())
        os.replace(staged, datasets / ("reversal-replay-prospective." + suffix))
raise SystemExit(code if code >= 0 else 128 - code)
PY
