"""Read-only runtime evidence after a deploy or restart (stdlib only; --exposure alone imports the
launch path's own role reader, so the report and the prestart can never disagree about a role file)."""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import fnmatch
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time


DEFAULT_PATTERN = "leafhft live --venue kalshi"
DEFAULT_UNITS_GLOB = "leafhft-live@kalshi-*"
ENABLED_FILE = Path(__file__).with_name("enabled.txt")
MAX_RUN_DIRS = 4096  # Same cap as leafhft.cli._live_policy_readers; no leafhft import.

# --exposure (X5, contracts/X2X3.md section 6): a read-only report run before rollout.sh. Paths mirror
# leafhft.exposure_authority; a role file is judged ONLY by leafhft.exposure_conformance.read_role, the
# reader every prestart calls (never a copy of its validator), imported on first --exposure use.
ROLES_DIR = Path("/var/lib/leafhft-exposure/roles")
REGISTRY_FILE = Path("/var/lib/leafhft/engine-registry/assignments.json")
PYTHON = "/opt/leafhft/.venv/bin/python"
ROLE_MARKER = "_registry.json"
ACCOUNT_UNITS_GLOB = "leafhft-account@*.service"
MAX_ROLE_BYTES = 4096
MAX_REGISTRY_BYTES = 4 * 1024 * 1024  # Tracks leafhft.engine_registry.MAX_REGISTRY_BYTES; no leafhft import.
MAX_ACCOUNT_UNITS = 64
MAX_CHECK_BYTES = 256 * 1024
_LANE_UNIT = re.compile(r"leafhft-account@([a-z0-9][a-z0-9-]{0,63})\.service")
_DOMAIN = re.compile(r"legacy-owner|account-lane:[a-z0-9][a-z0-9-]{0,63}")
CHECK_VERDICTS = {0: "conformant", 3: "unreadable", 4: "not_conformant"}

ACCOUNTS_DIR = Path("/var/lib/leafhft-accounts")
RECEIPT_DIRS = (Path("/var/lib/leafhft/rollout-receipts"), Path("/var/lib/leafhft/deploy-receipts"))
# leafhft/account_lane_agent.py:52,1543: PROJECTION_ROOT / lane_id / "gold-entry-arm.json".
GOLD_ARMS_DIR = Path("/var/lib/leafhft-projections")
MAX_HOST_CHILDREN = 64
_SHA40 = re.compile(r"[0-9a-f]{40}")
_RECEIPT = re.compile(r"(\d{8}T\d{6}(?:\.\d{1,6})?Z)-([0-9a-f]{12})\.json")


def run_command(argv: list[str]) -> tuple[int, str]:
    completed = subprocess.run(argv, capture_output=True, text=True, timeout=10, check=False)
    return completed.returncode, completed.stdout


def _enabled_units(path: Path, pattern: str) -> tuple[list[str], list[str]]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except FileNotFoundError:
        return [], [f"enabled instances file missing: {path}"]
    units = []
    for line in lines:
        name = line.partition("#")[0].strip()
        if name and fnmatch.fnmatchcase(name, pattern) and name not in units:
            units.append(name)
    return units, [] if units else [f"no enabled instances match {pattern}"]


def _fresh_status_files(runs: Path, fresh_s: float, now: float) -> list[str]:
    fresh = []
    count = 0
    try:
        with os.scandir(runs) as entries:
            for entry in entries:
                if not entry.is_dir():
                    continue
                count += 1
                if count > MAX_RUN_DIRS:
                    raise ValueError(f"run directory cap ({MAX_RUN_DIRS}) exceeded under {runs}")
                status = Path(entry.path) / "kalshi-edge-status.json"
                try:
                    if status.is_file() and now - status.stat().st_mtime <= fresh_s:
                        fresh.append(entry.name)
                except FileNotFoundError:
                    continue
    except FileNotFoundError:
        pass
    return sorted(fresh)


def check(runs: Path, *, units_glob: str = DEFAULT_UNITS_GLOB,
          expected: int | None = None, fresh_s: float = 180.0,
          max_restarts: int = 3, pgrep_pattern: str = DEFAULT_PATTERN,
          enabled_file: Path = ENABLED_FILE, run=run_command, now=time.time) -> dict:
    """Return counts, per-unit observations, failures, and the intended exit code.

    run(argv) is the only command boundary; callers can inject canned responses.
    Expected overrides the count, while enabled.txt still names the units to inspect.
    """
    result = {"expected": expected if expected is not None else 0, "observed": 0,
              "active": 0, "activating": 0, "loops": 0, "fresh": 0,
              "units": [], "fresh_files": [], "warnings": [], "reasons": [],
              "exit_code": 4}
    try:
        if expected is not None and (type(expected) is not int or expected < 0):
            raise ValueError("expected must be a nonnegative integer")
        if not math.isfinite(fresh_s) or fresh_s < 0 or max_restarts < 0:
            raise ValueError("fresh_s and max_restarts must be nonnegative")
        units, warnings = _enabled_units(Path(enabled_file), units_glob)
        result["warnings"] = warnings
        result["expected"] = len(units) if expected is None else expected
        rc, stdout = run(["pgrep", "-fc", pgrep_pattern])
        if rc not in (0, 1):
            raise RuntimeError(f"pgrep failed (exit {rc})")
        observed = int(stdout.strip() or ("0" if rc == 1 else ""))
        if observed < 0 or (rc == 1 and observed != 0):
            raise ValueError("invalid pgrep count")
        result["observed"] = observed
        for unit in units:
            rc, stdout = run(["systemctl", "is-active", unit])
            state = stdout.strip()
            if rc not in (0, 3, 4) or not state or (state == "active" and rc != 0):
                raise RuntimeError(f"is-active failed for {unit} (exit {rc})")
            rc, stdout = run(["systemctl", "show", "-p", "NRestarts", "--value", unit])
            if rc != 0:
                raise RuntimeError(f"NRestarts unavailable for {unit} (exit {rc})")
            restarts = int(stdout.strip())
            if restarts < 0:
                raise ValueError(f"invalid NRestarts for {unit}")
            result["units"].append({"name": unit, "state": state, "restarts": restarts})
            result["active"] += int(state == "active")
            result["activating"] += int(state == "activating")
            result["loops"] += int(restarts > max_restarts)
        result["fresh_files"] = _fresh_status_files(Path(runs), fresh_s, now())
        result["fresh"] = len(result["fresh_files"])
        expected = result["expected"]
        reasons = result["reasons"]
        if observed != expected:
            reasons.append(f"process count {observed}/{expected}")
        if observed == 0 and expected > 0:
            reasons.append("zero processes")
        if result["active"] != expected:
            reasons.append(f"active units {result['active']}/{expected}")
        if result["activating"]:
            reasons.append(f"activating units: {result['activating']}")
        if result["loops"]:
            reasons.append(f"restart loops: {result['loops']}")
        if result["fresh"] == 0:
            reasons.append("zero fresh status files")
        elif expected > 0 and result["fresh"] != expected:
            reasons.append(f"fresh status files {result['fresh']}/{expected}")
        result["exit_code"] = 1 if reasons else 0
    except Exception as exc:
        result["reasons"].append(f"internal error: {type(exc).__name__}: {exc}")
    result["evidence"] = (
        f"IMPACT-EVIDENCE deploy-check:processes:{result['observed']}/{result['expected']}:"
        f"active={result['active']}:fresh={result['fresh']}:loops={result['loops']}")
    return result


def _read_json(path: Path, limit: int):
    """(value, None), (None, "absent") or (None, error kind); bounded, duplicate keys refused."""
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError(f"duplicate key {key!r}")
            out[key] = value
        return out

    try:
        with open(path, "rb") as stream:
            data = stream.read(limit + 1)
    except FileNotFoundError:
        return None, "absent"
    except OSError as exc:
        return None, type(exc).__name__
    if len(data) > limit:
        return None, "oversize"
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=pairs), None
    except (ValueError, UnicodeError, RecursionError) as exc:
        return None, type(exc).__name__


def unit_domain(unit: str) -> str:
    """leafhft-account@<uuid>.service is account-lane:<uuid>; every leafhft-live@kalshi-* book,
    the perp included, is legacy-owner."""
    match = _LANE_UNIT.fullmatch(unit)
    return f"account-lane:{match.group(1)}" if match else "legacy-owner"


def _launch_reader():
    """leafhft.exposure_conformance.read_role, the exact call every prestart makes. An import or
    reader failure propagates, so the report fails closed (exit 4) rather than judging a role itself."""
    try:
        from leafhft.exposure_conformance import read_role
    except ImportError:
        root = str(Path(__file__).resolve().parents[2])
        if root not in sys.path:
            sys.path.insert(0, root)
        from leafhft.exposure_conformance import read_role
    return read_role


def _projection(roles_dir: Path, domain: str, now_s: float, read_role) -> dict:
    """One domain's projected role as the launch reader sees it, with the file's age: valid only when
    that reader returns the record, missing when it says absent or unregistered, else unreadable.
    `reader` is the reader's own state, printed as the reason."""
    out = {"projection": "missing", "reader": "absent", "role": None, "enforcement": None,
           "generation": None, "age_s": None}
    path = Path(roles_dir) / (domain.replace(":", "_") + ".json")
    try:
        out["age_s"] = round(max(0.0, now_s - os.stat(path).st_mtime), 1)
    except OSError:
        pass  # the reader reports a missing or unstat-able file itself
    view = read_role(domain, roles_dir)
    if view is None:
        return out
    out["reader"] = view.state
    if view.state == "record":
        out.update(projection="valid", role=view.role, enforcement=view.enforcement,
                   generation=view.generation)
    elif view.state != "unregistered":
        out["projection"] = "unreadable"
    return out


def _marker(roles_dir: Path, now_s: float) -> dict:
    path = Path(roles_dir) / ROLE_MARKER
    value, error = _read_json(path, MAX_ROLE_BYTES)
    if error == "absent":
        return {"state": "absent", "generation": None, "age_s": None}
    if error is not None or type(value) is not dict or type(value.get("generation")) is not int:
        return {"state": "unreadable", "generation": None, "age_s": None}
    try:
        age = round(max(0.0, now_s - os.stat(path).st_mtime), 1)
    except OSError:
        age = None
    return {"state": "present", "generation": value["generation"], "age_s": age}


def _registered_domains(registry: Path) -> list[str] | None:
    """Every domain the registry names, [] when it does not exist, None when unreadable."""
    value, error = _read_json(Path(registry), MAX_REGISTRY_BYTES)
    if error == "absent":
        return []
    accounts = value.get("accounts") if error is None and type(value) is dict else None
    if type(accounts) is not dict:
        return None
    domains = []
    for account in accounts.values():
        domain = account.get("domain") if type(account) is dict else None
        if type(domain) is not str or _DOMAIN.fullmatch(domain) is None:
            return None
        if domain not in domains:
            domains.append(domain)
    return sorted(domains)


def _account_units(run) -> list[str]:
    """Every leafhft-account@ instance systemd knows, loaded or not yet started."""
    rc, stdout = run(["systemctl", "list-units", "--all", "--plain", "--no-legend", "--type=service",
                      ACCOUNT_UNITS_GLOB])
    if rc != 0:
        raise RuntimeError(f"list-units failed for {ACCOUNT_UNITS_GLOB} (exit {rc})")
    units = []
    for line in stdout.splitlines():
        for token in line.split()[:2]:  # a leading status glyph may precede the name
            if _LANE_UNIT.fullmatch(token):
                if token not in units:
                    units.append(token)
                break
    if len(units) > MAX_ACCOUNT_UNITS:
        raise ValueError(f"more than {MAX_ACCOUNT_UNITS} account units")
    return units


def _domain_check(domain: str, python: str, run) -> dict:
    """X5 `check` (configured producers) for one domain; reported, never a refusal here."""
    row = {"domain": domain, "exit": None, "verdict": "error", "role": None, "on": None}
    try:
        rc, stdout = run([python, "-m", "leafhft.exposure_conformance", "check", "--domain", domain, "--json"])
    except (OSError, subprocess.SubprocessError) as exc:
        row["detail"] = type(exc).__name__
        return row
    row["exit"] = rc
    row["verdict"] = CHECK_VERDICTS.get(rc, "error")
    try:
        data = json.loads(stdout[:MAX_CHECK_BYTES]) if stdout.strip() else None
    except ValueError:
        data = None
    if type(data) is dict and type(data.get("role")) is dict and type(data.get("producers")) is list:
        row["role"] = f"{data['role'].get('state')}/{data['role'].get('role')}"
        row["on"] = sum(1 for item in data["producers"] if type(item) is dict and item.get("on") is not False)
    return row


def exposure(*, units_glob: str = DEFAULT_UNITS_GLOB, enabled_file: Path = ENABLED_FILE,
             roles_dir: Path = ROLES_DIR, registry: Path = REGISTRY_FILE, python: str = PYTHON,
             run=run_command, now=time.time) -> dict:
    """Every enabled book's domain, role, projection presence and age, plus `check` for every
    registered domain (lanes included). Exit 1 only when the projection is present and an enabled
    book's domain lacks a valid role file; with no projection at all the books keep
    foreign_exposure_mode=refuse (until C14-B) and the report degrades instead of refusing.
    Every role file is judged by the launch reader itself (`_launch_reader`). The report is a
    snapshot like the prestart: a role that moves after it is caught by the X4 audit and step."""
    result = {"mode": "exposure", "projection": None, "marker": None, "foreign_exposure_mode": None,
              "books": [], "domains": [], "warnings": [], "reasons": [], "exit_code": 4}
    try:
        now_s = now()
        units, warnings = _enabled_units(Path(enabled_file), units_glob)
        result["warnings"] = warnings
        lanes = _account_units(run)
        registered = _registered_domains(Path(registry))
        if registered is None:
            result["warnings"].append(f"registry unreadable: {registry}")
            registered = []
        for domain in registered:
            if domain != "legacy-owner":
                unit = f"leafhft-account@{domain.split(':', 1)[1]}.service"
                if unit not in lanes:
                    lanes.append(unit)
        marker = _marker(Path(roles_dir), now_s)
        result["marker"] = marker
        read_role = _launch_reader()
        for unit in units + lanes:
            domain = unit_domain(unit)
            result["books"].append({"unit": unit, "domain": domain,
                                    **_projection(Path(roles_dir), domain, now_s, read_role)})
        books = result["books"]
        if marker["state"] == "absent" and all(book["projection"] == "missing" for book in books):
            result["projection"] = "absent"
            result["foreign_exposure_mode"] = "refuse"
            result["warnings"].append("projection absent: books keep foreign_exposure_mode=refuse until C14-B")
            if registered:
                result["warnings"].append("registry present without a projection (X4 E7 alarms)")
        else:
            result["projection"] = "present" if marker["state"] == "present" else marker["state"]
            if marker["state"] != "present":
                result["reasons"].append(f"projection marker {marker['state']}")
            for book in books:
                if book["projection"] != "valid":
                    result["reasons"].append(
                        f"{book['unit']}: {book['domain']} has no valid projection "
                        f"({book['projection']}, launch reader: {book['reader']})")
        for domain in sorted(set(registered) | {book["domain"] for book in books}):
            result["domains"].append(_domain_check(domain, python, run))
        result["exit_code"] = 1 if result["reasons"] else 0
    except Exception as exc:
        result["reasons"].append(f"internal error: {type(exc).__name__}: {exc}")
    missing = sum(1 for book in result["books"] if book["projection"] != "valid")
    result["evidence"] = (
        f"IMPACT-EVIDENCE deploy-check:exposure:books={len(result['books'])}:"
        f"projection={result['projection']}:missing={missing}:domains={len(result['domains'])}")
    return result


def _print_exposure(result: dict) -> None:
    marker = result["marker"] or {}
    print(f"deploy check exposure: projection={result['projection']} "
          f"marker_generation={marker.get('generation')} marker_age_s={marker.get('age_s')} "
          f"books={len(result['books'])} foreign_exposure_mode={result['foreign_exposure_mode'] or '-'}")
    for book in result["books"]:
        print(f"deploy check exposure: book {book['unit']} domain={book['domain']} role={book['role']} "
              f"enforcement={book['enforcement']} projection={book['projection']} age_s={book['age_s']} "
              f"reader={book['reader']}")
    for row in result["domains"]:
        print(f"deploy check exposure: domain {row['domain']} check={row['verdict']} exit={row['exit']} "
              f"role={row['role']} producers_on={row['on']}")
    print(result["evidence"])
    for warning in result["warnings"]:
        print(f"deploy check: WARNING {warning}")
    if result["exit_code"]:
        print("deploy check: FAIL " + "; ".join(result["reasons"]))


def _host_stamp(raw: str) -> datetime:
    """Receipt stamps, UTC systemd timestamps, or C-locale ps lstart (forced UTC)."""
    for fmt in ("%Y%m%dT%H%M%S.%fZ", "%Y%m%dT%H%M%SZ",
                "%a %Y-%m-%d %H:%M:%S UTC", "%a %b %d %H:%M:%S %Y"):
        try:
            return datetime.strptime(raw.strip(), fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    raise ValueError(f"invalid UTC timestamp: {raw!r}")


def _host_receipts(directories) -> list[tuple[datetime, str, str]]:
    receipts = []
    for directory in directories:
        names = []
        try:
            with os.scandir(directory) as entries:
                for count, entry in enumerate(entries, 1):
                    if count > MAX_RUN_DIRS:
                        raise ValueError(f"receipt bound ({MAX_RUN_DIRS}) exceeded: {directory}")
                    if entry.is_file(follow_symlinks=False):
                        names.append(entry.name)
        except FileNotFoundError:
            continue
        for name in sorted(names, reverse=True):
            match = _RECEIPT.fullmatch(name)
            if match:
                receipts.append((_host_stamp(match[1]), match[2], match[1]))
    return sorted(receipts, reverse=True)


def _host_gold(directory: Path, lane_ids: list[str], target: str, now_s: float) -> dict:
    """Include arms for inactive lanes too; never read tenant-owned gold.json as an arm."""
    identifiers = set(lane_ids)
    try:
        with os.scandir(directory) as entries:
            for count, entry in enumerate(entries, 1):
                if count > MAX_ACCOUNT_UNITS:
                    raise ValueError(f"Gold lane directory bound ({MAX_ACCOUNT_UNITS}) exceeded")
                if _LANE_UNIT.fullmatch(f"leafhft-account@{entry.name}.service"):
                    identifiers.add(entry.name)
    except FileNotFoundError:
        pass
    if len(identifiers) > MAX_ACCOUNT_UNITS:
        raise ValueError(f"Gold lane bound ({MAX_ACCOUNT_UNITS}) exceeded")
    arms = []
    for lane in sorted(identifiers):
        value, error = _read_json(directory / lane / "gold-entry-arm.json", MAX_ROLE_BYTES)
        if error == "absent":
            continue
        row = {"lane_id": lane, "state": "unreadable", "build_sha": None, "expires_at_ms": None}
        arms.append(row)
        if (error or type(value) is not dict or value.get("schema") != "leafhft.gold-entry-arm.v2"
                or value.get("lane_id") != lane or type(value.get("build_sha")) is not str
                or not _SHA40.fullmatch(value["build_sha"])
                or type(value.get("expires_at_ms")) is not int):
            row["reason"] = f"Gold {lane}: {error or 'invalid arm fields'}"
            continue
        row.update(build_sha=value["build_sha"], expires_at_ms=value["expires_at_ms"])
        row["state"] = ("expired" if now_s * 1000 >= value["expires_at_ms"] else
                        "on_target" if value["build_sha"] == target else "lagging")
    states = {arm["state"] for arm in arms}
    state = next((s for s in ("unreadable", "expired", "lagging", "on_target") if s in states), "none")
    return {"state": state, "arms": arms}


def host(*, target: str | None = None, accounts_dir: Path = ACCOUNTS_DIR,
         receipt_dirs=RECEIPT_DIRS, gold_arms_dir: Path = GOLD_ARMS_DIR,
         run=run_command, now=time.time) -> dict:
    """Read-only host snapshot. Tenant build identities are start-time inferences, not attestations."""
    result = {"verdict": "UNREADABLE", "target": target, "head_moved_at": None,
              "owner": {"state": "unreadable", "rows": []}, "lanes": [],
              "gold": {"state": "unreadable", "arms": []}, "unreadable": [], "exit_code": 4}
    errors = result["unreadable"]

    def bounded_run(argv):
        rc, stdout = run(argv)
        if len(stdout.encode("utf-8")) > MAX_CHECK_BYTES:
            raise ValueError(f"command output bound ({MAX_CHECK_BYTES}) exceeded: {argv[0]}")
        return rc, stdout

    def read_command(argv, accepted_codes=(0,)):
        rc, stdout = bounded_run(argv)
        if rc not in accepted_codes:
            raise ValueError(f"{argv[0]} failed (exit {rc})")
        return stdout.strip()

    try:
        if target is None:
            target = read_command(["git", "-C", "/opt/leafhft", "rev-parse", "HEAD"])
        if type(target) is not str or not _SHA40.fullmatch(target):
            raise ValueError("target must be a lowercase SHA40")
        result["target"] = target
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        errors.append(f"target: {exc}")
        return result
    try:
        # deployed emits its report for IN_SYNC (0), DRIFTED (1), and DEGRADED (2).
        owner = json.loads(read_command(
            ["/opt/leafhft/.venv/bin/leafhft", "deployed", "--json"], accepted_codes=(0, 1, 2)))
        if (type(owner) is not dict or type(owner.get("rows")) is not list
                or type(owner.get("verdict")) is not str):
            raise ValueError("invalid owner document")
        rows = owner["rows"]
        for row in rows:
            if (type(row) is not dict or type(row.get("unit")) is not str
                    or type(row.get("live")) is not bool
                    or (row["live"] and (type(row.get("git_sha")) is not str
                                         or not _SHA40.fullmatch(row["git_sha"])))):
                raise ValueError("invalid owner row")
        result["owner"]["rows"] = rows
        if any(row["live"] and row["git_sha"] != target for row in rows):
            result["owner"]["state"] = "drifted"
        elif owner["verdict"] == "IN_SYNC":
            result["owner"]["state"] = "on_target"
        else:
            raise ValueError(f"owner verdict {owner['verdict']}")
    except (OSError, ValueError, RecursionError, subprocess.SubprocessError) as exc:
        errors.append(f"owner: {exc}")
    receipts = []
    moved = None
    try:
        receipts = _host_receipts(receipt_dirs)
        match = next((r for r in receipts if r[1] == target[:12]), None)
        if match:
            moved, _, result["head_moved_at"] = match
        else:
            errors.append("head_move_unknown")
    except (OSError, ValueError) as exc:
        errors.append(f"head_move_unknown: {exc}")
    units = []
    try:
        units = _account_units(bounded_run)
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as exc:
        errors.append(f"account unit bound/read: {exc}")
    for unit in units:
        lane_id = _LANE_UNIT.fullmatch(unit)[1]
        lane = {"unit": unit, "lane_id": lane_id, "state": "unreadable", "children": [],
                "expected_renewal": None, "derived": True}
        try:
            rc, active = bounded_run(["systemctl", "is-active", unit])
            if rc in (3, 4) and active.strip() == "failed":
                lane.update(state="failed", reason="lane unit failed")
                result["lanes"].append(lane)
                continue
            if rc in (3, 4) and active.strip() in ("inactive", "unknown"):
                continue
            if rc != 0 or active.strip() != "active":
                raise ValueError(f"unit state unavailable: {active.strip()}")
            result["lanes"].append(lane)
            stamp = read_command(["env", "LC_ALL=C", "TZ=UTC", "systemctl", "show", "-p",
                                  "ActiveEnterTimestamp", "--value", unit])
            entered = _host_stamp(stamp)
            if moved is not None:
                lane["expected_renewal"] = (entered + timedelta(hours=24)).isoformat()
            value, error = _read_json(Path(accounts_dir) / lane_id / "status.json", MAX_CHECK_BYTES)
            if error or type(value) is not dict or type(value.get("book_pids")) is not dict:
                raise ValueError(f"status.json: {error or 'invalid book_pids'}")
            pids = value["book_pids"]
            if len(pids) > MAX_HOST_CHILDREN:
                raise ValueError(f"child bound ({MAX_HOST_CHILDREN}) exceeded")
            for symbol, pid in pids.items():
                child = {"symbol": symbol, "pid": pid, "state": "unreadable", "started_at": None,
                         "git_sha": "unknown", "derived": True}
                lane["children"].append(child)
                try:
                    if type(pid) is not int or pid <= 0:
                        raise ValueError("invalid child pid")
                    rc, stamp = bounded_run(["env", "LC_ALL=C", "TZ=UTC", "ps", "-o", "lstart=", "-p", str(pid)])
                    if rc == 1 and not stamp.strip():
                        child["state"] = "gone"
                        continue
                    if rc != 0:
                        raise ValueError(f"ps failed (exit {rc})")
                    started = _host_stamp(stamp)
                    child["started_at"] = started.isoformat()
                    if moved is not None:
                        child["state"] = "on_target" if started >= moved else "lagging"
                        child["git_sha"] = (target[:12] if started >= moved else
                                            next((r[1] for r in receipts if r[0] < started), "unknown"))
                except (OSError, ValueError, subprocess.SubprocessError) as exc:
                    child["reason"] = str(exc)
                    errors.append(f"{lane_id}/{symbol}: {exc}")
            states = {child["state"] for child in lane["children"]}
            if moved is None or "unreadable" in states:
                lane["reason"] = "head_move_unknown" if moved is None else "unreadable child"
            elif entered < moved:
                lane.update(state="lagging", reason="lane process predates head move")
            elif "on_target" in states and "lagging" in states:
                lane["state"] = "mixed"
            elif states & {"lagging", "gone"}:
                lane["state"] = "lagging"
            else:
                lane["state"] = "on_target"
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            if lane not in result["lanes"]:
                result["lanes"].append(lane)
            lane["reason"] = str(exc)
            errors.append(f"{lane_id}: {exc}")
    try:
        result["gold"] = _host_gold(Path(gold_arms_dir), [_LANE_UNIT.fullmatch(u)[1] for u in units],
                                    target, now())
        errors.extend(arm["reason"] for arm in result["gold"]["arms"] if arm["state"] == "unreadable")
    except (OSError, ValueError) as exc:
        errors.append(f"Gold: {exc}")
    if errors:
        verdict, code = "UNREADABLE", 4
    elif result["owner"]["state"] == "drifted":
        verdict, code = "DRIFTED", 1
    elif (any(lane["state"] in ("lagging", "mixed", "failed") for lane in result["lanes"])
          or result["gold"]["state"] in ("lagging", "expired")):
        verdict, code = "CONVERGING", 3
    else:
        verdict, code = "IN_SYNC", 0
    result.update(verdict=verdict, exit_code=code)
    return result


def _print_host(result: dict) -> None:
    print(f"host: {result['verdict']} target {(result['target'] or 'unknown')[:12]}")
    for row in result["owner"]["rows"]:
        print(f"owner: {row['unit']} live={row['live']} sha={row.get('git_sha')} {result['owner']['state']}")
    for lane in result["lanes"]:
        print(f"lane: {lane['lane_id']} {lane['state']} derived "
              f"renewal={lane['expected_renewal']} derived {lane.get('reason', '')}")
        for child in lane["children"]:
            print(f"child: {lane['lane_id']}/{child['symbol']} pid={child['pid']} "
                  f"{child['state']} derived sha={child['git_sha']} derived {child.get('reason', '')}")
    print(f"gold: {result['gold']['state']}")
    for arm in result["gold"]["arms"]:
        print(f"gold: {arm['lane_id']} {arm['state']} build_sha={arm['build_sha']} "
              f"target={result['target']} expires_at_ms={arm['expires_at_ms']}")
    for reason in result["unreadable"]:
        print(f"unreadable: {reason}")


def _target_sha(raw: str) -> str:
    if not _SHA40.fullmatch(raw):
        raise argparse.ArgumentTypeError("must be a lowercase SHA40")
    return raw


def _nonnegative_int(raw: str) -> int:
    value = int(raw)
    if value < 0:
        raise argparse.ArgumentTypeError("must be nonnegative")
    return value


def _nonnegative_float(raw: str) -> float:
    value = float(raw)
    if not math.isfinite(value) or value < 0:
        raise argparse.ArgumentTypeError("must be finite and nonnegative")
    return value


def main(argv=None, *, run=run_command, now=time.time) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path)
    parser.add_argument("--units-glob", default=DEFAULT_UNITS_GLOB)
    parser.add_argument("--expected", type=_nonnegative_int)
    parser.add_argument("--fresh-s", type=_nonnegative_float, default=180.0)
    parser.add_argument("--max-restarts", type=_nonnegative_int, default=3)
    parser.add_argument("--pgrep-pattern", default=DEFAULT_PATTERN)
    parser.add_argument("--enabled-file", type=Path, default=ENABLED_FILE)
    parser.add_argument("--json", action="store_true")
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--host", action="store_true", help="report the whole runner host")
    modes.add_argument("--exposure", action="store_true",
                        help="report every enabled book's exposure role and projection instead")
    parser.add_argument("--roles-dir", type=Path, default=ROLES_DIR)
    parser.add_argument("--registry", type=Path, default=REGISTRY_FILE)
    parser.add_argument("--python", default=PYTHON)
    parser.add_argument("--target", type=_target_sha)
    parser.add_argument("--accounts-dir", type=Path, default=ACCOUNTS_DIR)
    parser.add_argument("--receipt-dir", type=Path, action="append")
    parser.add_argument("--gold-arms-dir", type=Path, default=GOLD_ARMS_DIR)
    args = parser.parse_args(argv)
    options = vars(args).copy()
    json_output = options.pop("json")
    exposure_mode = options.pop("exposure")
    host_mode = options.pop("host")
    host_options = {key: options.pop(key) for key in ("target", "accounts_dir", "gold_arms_dir")}
    host_options["receipt_dirs"] = options.pop("receipt_dir") or RECEIPT_DIRS
    exposure_options = {key: options.pop(key) for key in ("roles_dir", "registry", "python")}
    if host_mode:
        result = host(**host_options, run=run, now=now)
        if json_output:
            print(json.dumps(result, sort_keys=True))
        else:
            _print_host(result)
        return result["exit_code"]
    if exposure_mode:
        result = exposure(units_glob=args.units_glob, enabled_file=args.enabled_file,
                          **exposure_options, run=run, now=now)
        if json_output:
            print(json.dumps(result, sort_keys=True))
        else:
            _print_exposure(result)
        return result["exit_code"]
    if args.runs is None:
        parser.error("--runs is required unless --exposure is given")
    result = check(**options, run=run, now=now)
    if json_output:
        print(json.dumps(result, sort_keys=True))
    else:
        print("deploy check: " + " ".join(f"{key}={result[key]}" for key in
              ("expected", "observed", "active", "activating", "loops", "fresh")))
        print(result["evidence"])
        for warning in result["warnings"]:
            print(f"deploy check: WARNING {warning}")
        if result["exit_code"]:
            print("deploy check: FAIL " + "; ".join(result["reasons"]))
    return result["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
