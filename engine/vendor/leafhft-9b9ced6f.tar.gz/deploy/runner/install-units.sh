#!/bin/bash
set -euo pipefail

fail() { echo "$*" >&2; exit 2; }
mode=""
case "$#:$*" in
  0:) ;;
  1:--check) mode=check ;;
  1:--plan) mode=plan ;;
  *) fail 'Usage: install-units.sh [--check|--plan]' ;;
esac
if [[ -z "$mode" && $EUID -ne 0 ]]; then
  fail 'install-units.sh must run as root'
fi
base=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
valid_name() { [[ "$1" =~ ^leafhft-[A-Za-z0-9_@.-]+\.(service|timer)$ ]]; }
book_hold_marker() {
  local LC_ALL=C
  [[ -z $1 || $1 == *[[:space:][:cntrl:]]* ]] && return 1
  [[ "$1" =~ ^leafhft-live@kalshi-([a-z0-9]+)-([a-z0-9]+)\.service$ ]] || return 1
  printf 'HOLD-%s-%s\n' "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}"
}
book_held() {
  local marker status
  marker=$(book_hold_marker "$1") || return 1
  # stat without -L also holds dangling symlinks. Only ENOENT clears a hold;
  # permission or other lookup errors must not turn a paused book back on.
  if status=$(LC_ALL=C stat -- "${LEAFHFT_HOLD_DIR:-/root/leafhft-cliff}/$marker" 2>&1); then
    return 0
  fi
  [[ "$status" != *": No such file or directory" ]]
}
bootstrap() { [[ "$1" == leafhft-bootstrap* ]]; }
# Risk research units have an independent lifecycle outside this installer.
risk_managed() { [[ "$1" == leafhft-risk-* ]]; }
# The probe watch is installed disabled; only the C8 runbook enables it, and a rerun never retires it.
probe_watch_managed() { [[ "$1" == leafhft-probe-watch.service || "$1" == leafhft-probe-watch.timer ]]; }
account_managed() { [[ "$1" == leafhft-account@* || "$1" == leafhft-account-push@* || "$1" == leafhft-account-sync@* || "$1" == leafhft-account-live-ledger@* || "$1" == leafhft-account-agent.* || "$1" == leafhft-account-provision.* || "$1" == leafhft-account-deposits.* ]]; }
# The registry audit rides with the units, not enabled.txt: its root oneshot only reads the
# registry and writes audit.json, so the installer enables its timer whenever the file is present.
registry_audit_timer=leafhft-engine-registry-audit.timer
registry_audit_managed() { [[ "$1" == leafhft-engine-registry-audit.service || "$1" == "$registry_audit_timer" ]]; }
# The bookd loader is dependency-started, never an enabled line. Retiring it
# while an instance is wanted would stop every Requires= consumer on a rerun.
bookd_secrets_required() {
  [[ "$1" == leafhft-bookd-secrets.service ]] || return 1
  local unit
  for unit in "${units[@]}"; do
    [[ "$unit" != leafhft-bookd@*.service ]] || return 0
  done
  return 1
}
# The engine judge is allowed in enabled.txt only as its timer: enabling the root service itself
# would rerun the judge (trial activation, the scorer) on every install.
judge_service() { [[ "$1" == leafhft-engine-judge.service ]]; }
bare_template() {
  [[ "$1" == *@* ]] || return 1
  local rest=${1#*@}
  local instance=${rest%.*}
  [[ -z "$instance" ]]
}
timer_wanted() {
  [[ "$1" == *.service ]] || return 1
  local timer="${1%.service}.timer"
  [[ -n "${wanted[$timer]+yes}" ]]
}
# Host role (L7c, HOST-ROLES.md): one root-owned line in /etc/leafhft-host-role, runner or tenant.
# Absent is combined, today's behaviour exactly. Anything else fails closed before any mutation;
# no environment variable sets the role, and one that tries is refused.
role_invalid() { fail "Invalid host role file: $*"; }
read_host_role() {
  local LC_ALL=C role_file=${LEAFHFT_HOST_ROLE_FILE:-/etc/leafhft-host-role}
  local role_stat="" role_uid="" role_mode="" role_size="" role_raw=""
  [[ -z "${LEAFHFT_HOST_ROLE+set}" ]] || role_invalid 'LEAFHFT_HOST_ROLE is not read; write /etc/leafhft-host-role'
  if [[ ! -e "$role_file" && ! -L "$role_file" ]]; then
    role=combined
    return 0
  fi
  [[ ! -L "$role_file" ]] || role_invalid "$role_file is a symlink"
  [[ -f "$role_file" ]] || role_invalid "$role_file is not a regular file"
  role_stat=$(stat -c '%u %a %s' -- "$role_file") || role_invalid "$role_file cannot be read"
  read -r role_uid role_mode role_size <<< "$role_stat" || true
  [[ "$role_uid" =~ ^[0-9]+$ && "$role_mode" =~ ^[0-7]+$ && "$role_size" =~ ^[0-9]+$ ]] \
    || role_invalid "$role_file cannot be read"
  (( (8#$role_mode & 8#022) == 0 )) || role_invalid "$role_file is group- or other-writable"
  if [[ $EUID -eq 0 && "$role_uid" != 0 ]]; then
    role_invalid "$role_file is not owned by root"
  fi
  (( role_size <= 64 )) || role_invalid "$role_file is too large"
  IFS= read -r -d '' role_raw < "$role_file" || true
  (( ${#role_raw} == role_size )) || role_invalid "$role_file holds a NUL byte or changed while read"
  role_raw=${role_raw%$'\n'}
  role_raw=${role_raw%$'\r'}
  case "$role_raw" in
    runner|tenant) role=$role_raw ;;
    '') role_invalid "$role_file is empty" ;;
    *) role_invalid "$role_file must hold exactly one line, runner or tenant" ;;
  esac
}
role=""
read_host_role
[[ -r "$base/enabled.txt" && -f "$base/paper-run.sh" ]] || fail 'Missing runner files'
bash -n "$base/paper-run.sh" || fail 'Invalid paper script'
bash -n "$base/shadow-lane-host-run.sh" || fail 'Invalid shadow lane host script'
bash -n "$base/flag-observe-run.sh" || fail 'Invalid flag observe script'
[[ -f "$base/shadow-continuous-worker.sh" && ! -L "$base/shadow-continuous-worker.sh" ]] || fail 'Missing continuous paper worker script'
bash -n "$base/shadow-continuous-worker.sh" || fail 'Invalid continuous paper worker script'
shopt -s nullglob
# The probe lifecycle tmpfiles entry rides beside the units but is not a unit.
lifecycle_tmpfiles="$base/units/leafhft-lifecycle-dir.conf"
files=("$base"/units/*)
units_only=()
for file in "${files[@]}"; do
  [[ "$file" == "$lifecycle_tmpfiles" ]] || units_only+=("$file")
done
files=("${units_only[@]}")
[[ ${#files[@]} -gt 0 ]] || fail 'No unit files'
for file in "${files[@]}"; do
  name=${file##*/}
  valid_name "$name" && ! bootstrap "$name" || fail "Invalid unit file: $name"
  # The root venue snapshot (network, the Kalshi key) reserves its prefix to exactly its two units.
  [[ "$name" != leafhft-venue-snapshot* || "$name" == leafhft-venue-snapshot.service || "$name" == leafhft-venue-snapshot.timer ]] || fail "Reserved unit prefix: $name"
  [[ -f "$file" && ! -L "$file" && -s "$file" ]] || fail "Invalid unit file: $name"
  grep -qx '\[Unit\]' "$file" || fail "Missing Unit section: $name"
  if [[ "$name" == *.service ]]; then section=Service; else section=Timer; fi
  grep -qx "\[$section\]" "$file" || fail "Missing $section section: $name"
done
declare -A wanted=()
units=()
while IFS= read -r line || [[ -n "$line" ]]; do
  line=${line%$'\r'}
  [[ -z "$line" || "$line" == \#* ]] && continue
  valid_name "$line" && ! bootstrap "$line" || fail "Invalid enabled unit: $line"
  ! account_managed "$line" || fail 'Account units require the account control agent'
  ! probe_watch_managed "$line" || fail 'Probe watch is enabled by the C8 runbook only'
  ! judge_service "$line" || fail 'The engine judge is enabled through leafhft-engine-judge.timer only'
  [[ -z "${wanted[$line]+yes}" ]] || fail "Duplicate enabled unit: $line"
  source=$line
  if [[ "$line" == *@* ]]; then
    instance=${line#*@}; instance=${instance%.*}
    [[ -n "$instance" && "$instance" != *@* ]] || fail "Invalid instance: $line"
    source="${line%%@*}@.${line##*.}"
  fi
  [[ -f "$base/units/$source" ]] || fail "Missing unit for: $line"
  if [[ "$line" == leafhft-paper@* ]]; then
    case "$instance" in 025|050|100|200|eth|sol|bnb|ada|sui) ;; *) fail "Unknown paper label: $instance" ;; esac
  fi
  wanted[$line]=1
  units+=("$line")
done < "$base/enabled.txt"
[[ ${#units[@]} -gt 0 ]] || fail 'Empty enabled list'
# Tenant list (L7c): validated in every role whenever it exists, so --check rejects a bad list; it
# is the wanted set on the tenant host only. Runner units (enabled.txt wanted or drained lines, and
# every book, secrets loader, paper and recorder name) are refused: no live book starts there.
tenant_enabled="$base/enabled-tenant.txt"
declare -A runner_named=()
for name in "${units[@]}"; do runner_named[$name]=1; done
drained_re='^# (leafhft-[A-Za-z0-9_@.-]+\.(service|timer)) \(drained'
while IFS= read -r line || [[ -n "$line" ]]; do
  line=${line%$'\r'}
  if [[ "$line" =~ $drained_re ]]; then
    runner_named[${BASH_REMATCH[1]}]=1
  fi
done < "$base/enabled.txt"
runner_unit() {
  [[ -n "${runner_named[$1]+yes}" || "$1" == leafhft-live@* || "$1" == leafhft-live-secrets* \
    || "$1" == leafhft-paper@* || "$1" == leafhft-record* || "$1" == leafhft-bookd* || "$1" == leafhft-hot@* ]]
}
declare -A tenant_wanted=()
tenant_units=()
if [[ "$role" == tenant || -e "$tenant_enabled" || -L "$tenant_enabled" ]]; then
  [[ -f "$tenant_enabled" && -r "$tenant_enabled" ]] || fail 'Missing tenant enabled list'
  while IFS= read -r line || [[ -n "$line" ]]; do
    line=${line%$'\r'}
    [[ -z "$line" || "$line" == \#* ]] && continue
    valid_name "$line" && ! bootstrap "$line" || fail "Invalid enabled unit: $line"
    ! account_managed "$line" || fail 'Account units require the account control agent'
    ! probe_watch_managed "$line" || fail 'Probe watch is enabled by the C8 runbook only'
    ! judge_service "$line" || fail 'The engine judge is enabled through leafhft-engine-judge.timer only'
    ! runner_unit "$line" || fail "Runner unit on the tenant host: $line"
    [[ -z "${tenant_wanted[$line]+yes}" ]] || fail "Duplicate enabled unit: $line"
    source=$line
    if [[ "$line" == *@* ]]; then
      instance=${line#*@}; instance=${instance%.*}
      [[ -n "$instance" && "$instance" != *@* ]] || fail "Invalid instance: $line"
      source="${line%%@*}@.${line##*.}"
    fi
    [[ -f "$base/units/$source" ]] || fail "Missing unit for: $line"
    tenant_wanted[$line]=1
    tenant_units+=("$line")
  done < "$tenant_enabled"
fi
# The role's installed file set, built once: the apply loop, the plan loop and both counts use it.
# runner skips the account family (it installs on the tenant host only); tenant installs that family
# plus each wanted line's source unit and, for a timer, its same-stem service.
install_files=()
not_installed=()
declare -A tenant_sources=()
if [[ "$role" == tenant ]]; then
  wanted=()
  for name in ${tenant_units[@]+"${tenant_units[@]}"}; do
    wanted[$name]=1
    source=$name
    [[ "$name" != *@* ]] || source="${name%%@*}@.${name##*.}"
    tenant_sources[$source]=1
    if [[ "$source" == *.timer && -f "$base/units/${source%.timer}.service" ]]; then
      tenant_sources[${source%.timer}.service]=1
    fi
  done
  units=(${tenant_units[@]+"${tenant_units[@]}"})
fi
for file in "${files[@]}"; do
  name=${file##*/}
  case "$role" in
    combined) install_files+=("$file") ;;
    runner)
      if account_managed "$name"; then not_installed+=("$name"); else install_files+=("$file"); fi ;;
    tenant)
      if account_managed "$name" || [[ -n "${tenant_sources[$name]+yes}" ]]; then install_files+=("$file"); fi ;;
  esac
done
# Subset deploy (deploy.py and rollout.sh --units): LEAFHFT_INSTALL_LIVE_ONLY names, comma
# separated, the leafhft-live@ instances this run may start. Every other wanted leafhft-live@
# instance is enabled WITHOUT --now, so an inactive or failed book outside the selection keeps
# its lifecycle state. Unset or empty is the full path: every wanted unit is enabled and started.
declare -A live_only=()
live_subset=0
if [[ -n "${LEAFHFT_INSTALL_LIVE_ONLY:-}" ]]; then
  live_subset=1
  IFS=, read -r -a live_only_list <<< "$LEAFHFT_INSTALL_LIVE_ONLY"
  for instance in "${live_only_list[@]}"; do
    [[ "$instance" =~ ^[A-Za-z0-9_-]+$ ]] || fail "Invalid LEAFHFT_INSTALL_LIVE_ONLY instance: $instance"
    [[ -z "${live_only[$instance]+yes}" ]] || fail "Duplicate LEAFHFT_INSTALL_LIVE_ONLY instance: $instance"
    [[ -n "${wanted[leafhft-live@$instance.service]+yes}" ]] \
      || fail "LEAFHFT_INSTALL_LIVE_ONLY names an instance not in enabled.txt: $instance"
    live_only[$instance]=1
  done
fi
# False only for a wanted leafhft-live@ instance outside a LEAFHFT_INSTALL_LIVE_ONLY subset.
start_now() {
  [[ $live_subset -eq 1 && "$1" == leafhft-live@*.service ]] || return 0
  local instance=${1#leafhft-live@}
  instance=${instance%.service}
  [[ -n "${live_only[$instance]+yes}" ]]
}
held=0
tmpfiles="$base/tmpfiles.d/leafhft.conf"
[[ -r "$tmpfiles" ]] || fail 'Missing tmpfiles configuration'
awk '
  { sub(/\r$/, "") }
  /^[[:space:]]*(#|$)/ { next }
  {
    if (NF != 6 || $1 != "d" || $6 != "-") bad=1
    if ($5 != "leafhft") bad=1
    else if ($2 == "/etc/leafhft" || $2 == "/etc/leafhft/engines") {
      if ($3 != "0775" || $4 != "root") bad=1
    } else if ($2 == "/var/lib/leafhft/account-shadow") {
      if ($3 != "0750" || $4 != "leafhft") bad=1
    } else bad=1
    seen[$2]++
  }
  END {
        exit (bad || seen["/etc/leafhft"] != 1 || seen["/etc/leafhft/engines"] != 1 ||
              seen["/var/lib/leafhft/account-shadow"] != 1) }
' "$tmpfiles" || fail 'Invalid tmpfiles configuration'
# Deployment trees have their own exact allowlist, independent of the main tmpfiles rows.
# Optional for runner copies without deployments; when present every row must occur once.
deployments_tmpfiles="$base/tmpfiles.d/leafhft-deployments.conf"
if [[ -e "$deployments_tmpfiles" ]]; then
  [[ -f "$deployments_tmpfiles" && ! -L "$deployments_tmpfiles" && -r "$deployments_tmpfiles" ]] \
    || fail 'Invalid deployments tmpfiles configuration'
  awk '
    BEGIN {
      deployments["/etc/leafhft-deployments"]="0755"
      deployments["/etc/leafhft-deployments/catalog"]="0755"
      deployments["/var/lib/leafhft-deployments"]="0700"
      deployments["/var/lib/leafhft-deployments/tx"]="0700"
      deployments["/var/lib/leafhft-deployments/consumed"]="0700"
      deployments["/var/lib/leafhft-deployments/requests"]="0700"
      deployments["/var/lib/leafhft-deployments/pending"]="0700"
      deployments["/var/lib/leafhft-deployments/quarantine"]="0700"
    }
    { sub(/\r$/, "") }
    /^[[:space:]]*(#|$)/ { next }
    {
      if (NF != 6 || $1 != "d" || $6 != "-" || !($2 in deployments) ||
          $3 != deployments[$2] || $4 != "root" || $5 != "root") bad=1
      seen[$2]++
    }
    END {
      for (path in deployments) if (seen[path] != 1) bad=1
      exit bad
    }
  ' "$deployments_tmpfiles" || fail 'Invalid deployments tmpfiles configuration'
fi
# Optional so a runner copy without probes still installs; when present it must be exact.
if [[ -e "$lifecycle_tmpfiles" ]]; then
  [[ -f "$lifecycle_tmpfiles" && ! -L "$lifecycle_tmpfiles" && -r "$lifecycle_tmpfiles" ]] \
    || fail 'Invalid lifecycle tmpfiles configuration'
  awk '
    { sub(/\r$/, "") }
    /^[[:space:]]*(#|$)/ { next }
    {
      key = $1 " " $2 " " $3 " " $4 " " $5 " " $6
      if (NF != 6 || !(key in want)) bad=1
      seen[key]++
    }
    BEGIN {
      want["d /var/lib/leafhft/engine-lifecycle 0750 leafhft leafhft -"]
      want["d /var/lib/leafhft/engine-registry 0755 root root -"]
    }
    END {
      for (k in want) if (seen[k] != 1) bad=1
      exit bad
    }
  ' "$lifecycle_tmpfiles" || fail 'Invalid lifecycle tmpfiles configuration'
fi
# X4 (contracts/X2X3.md 2.4, v3.1 A8): the exposure role directories the projector checks (root 0755)
# and the book prestart refusal spool, in their own file. Optional so a runner copy without X4 still
# installs; when present it must hold exactly these three rows, each once.
exposure_tmpfiles="$base/tmpfiles.d/leafhft-exposure.conf"
if [[ -e "$exposure_tmpfiles" ]]; then
  [[ -f "$exposure_tmpfiles" && ! -L "$exposure_tmpfiles" && -r "$exposure_tmpfiles" ]] \
    || fail 'Invalid exposure tmpfiles configuration'
  awk '
    BEGIN {
      want["d /var/lib/leafhft-exposure 0755 root root -"]
      want["d /var/lib/leafhft-exposure/roles 0755 root root -"]
      want["d /var/lib/leafhft/exposure-refusals 0750 leafhft leafhft -"]
    }
    { sub(/\r$/, "") }
    /^[[:space:]]*(#|$)/ { next }
    {
      key = $1 " " $2 " " $3 " " $4 " " $5 " " $6
      if (NF != 6 || !(key in want)) bad=1
      seen[key]++
    }
    END {
      for (k in want) if (seen[k] != 1) bad=1
      exit bad
    }
  ' "$exposure_tmpfiles" || fail 'Invalid exposure tmpfiles configuration'
fi
# Tuning units are installed through install_files like H8's gate refresher, but only
# enabled.txt can start them. E0 adds their timers after provisioning and sandbox proof.
tuning_tmpfiles="$base/tmpfiles.d/leafhft-tuning.conf"
[[ -f "$tuning_tmpfiles" && ! -L "$tuning_tmpfiles" && -r "$tuning_tmpfiles" ]] \
  || fail 'Invalid tuning tmpfiles configuration'
awk '
  BEGIN {
    want["d /etc/leafhft-tuning 0750 root leafhft -"]
    want["d /var/lib/leafhft-tuning 0700 root root -"]
    want["d /var/lib/leafhft-tuning-inputs 0750 root leafhft -"]
  }
  { sub(/\r$/, "") }
  /^[[:space:]]*(#|$)/ { next }
  {
    key = $1 " " $2 " " $3 " " $4 " " $5 " " $6
    if (NF != 6 || !(key in want)) bad=1
    seen[key]++
  }
  END {
    for (k in want) if (seen[k] != 1) bad=1
    exit bad
  }
' "$tuning_tmpfiles" || fail 'Invalid tuning tmpfiles configuration'
bookd_sysusers="$base/sysusers.d/leafhft-bookd.conf"
if [[ "$role" != tenant && -f "$base/units/leafhft-bookd@.service" ]]; then
  [[ -f "$bookd_sysusers" && ! -L "$bookd_sysusers" && -r "$bookd_sysusers" ]] \
    || fail 'Missing bookd sysusers configuration'
  [[ -f "$base/units/leafhft-bookd-secrets.service" ]] || fail 'Missing bookd secrets unit'
fi
if [[ "$mode" == check ]]; then
  echo "Validated ${#install_files[@]} files and ${#units[@]} enabled units"
  exit 0
fi
if [[ "$role" != combined ]]; then
  echo "host role: $role"
fi
for name in ${not_installed[@]+"${not_installed[@]}"}; do
  echo "not installing $name: account units install on the tenant host only"
done

# Query the enabled and running-or-failed unit sets before any mutation and
# fail closed on either query so a broken systemctl never retires blindly.
enabled_units=$(systemctl list-unit-files --state=enabled --no-legend --no-pager 'leafhft-*') \
  || fail 'systemctl list-unit-files query failed'
running_units=$(systemctl list-units --all --plain --no-legend --no-pager 'leafhft-*') \
  || fail 'systemctl list-units query failed'
declare -A retire=()
declare -A was_enabled=()
while read -r name state rest; do
  [[ "$name" == leafhft-* ]] || continue
  bootstrap "$name" && continue
  account_managed "$name" && continue
  risk_managed "$name" && continue
  probe_watch_managed "$name" && continue
  registry_audit_managed "$name" && continue
  bookd_secrets_required "$name" && continue
  bare_template "$name" && continue
  was_enabled[$name]=1
  [[ -z "${wanted[$name]+yes}" ]] || continue
  timer_wanted "$name" && continue
  retire[$name]=1
done <<< "$enabled_units"
while read -r name load active sub; do
  [[ "$name" == leafhft-* ]] || continue
  bootstrap "$name" && continue
  account_managed "$name" && continue
  risk_managed "$name" && continue
  probe_watch_managed "$name" && continue
  registry_audit_managed "$name" && continue
  bookd_secrets_required "$name" && continue
  bare_template "$name" && continue
  [[ -z "${wanted[$name]+yes}" ]] || continue
  timer_wanted "$name" && continue
  retire[$name]=1
done <<< "$running_units"

# A stale wanted set must never retire a book reported live by the runner.
declare -A live=()
live_count=0
live_error=""
py=${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}
if ! resolved_py=$(command -v -- "$py") || [[ ! -f "$resolved_py" || ! -x "$resolved_py" ]]; then
  live_error='live probe unreadable (interpreter unavailable)'
elif live_units=$(timeout 10 "$resolved_py" -m leafhft deployed --live-units); then
  while IFS= read -r name; do
    name=${name%$'\r'}
    [[ -n "$name" ]] || continue
    if ! valid_name "$name"; then
      live_error='live probe unreadable (invalid unit output)'
      break
    fi
    if [[ -z "${live[$name]+yes}" ]]; then
      live_count=$((live_count + 1))
      live[$name]=1
    fi
  done <<< "$live_units"
else
  live_status=$?
  live_error="live probe unreadable (exit $live_status; timeout is 124)"
fi
if [[ -n "$live_error" ]]; then
  echo 'live probe unreadable: refusing every retirement'
else
  echo "live probe: $live_count live units"
fi
can_retire() {
  if [[ -n "$live_error" ]]; then
    echo "refused to retire $1: $live_error"
    return 1
  fi
  if [[ -n "${live[$1]+yes}" ]]; then
    echo "refused to retire $1: live"
    return 1
  fi
  return 0
}

secrets_enable_only=0
if [[ $live_count -gt 0 && -n "${wanted[leafhft-live-secrets.service]+yes}" ]]; then
  secrets_state=$(systemctl show -p ActiveState,ExecMainStatus leafhft-live-secrets.service)
  secrets_state=${secrets_state//$'\r'/}
  if [[ $'\n'"$secrets_state"$'\n' == *$'\nActiveState=inactive\n'* && $'\n'"$secrets_state"$'\n' == *$'\nExecMainStatus=0\n'* ]]; then
    secrets_enable_only=1
  fi
fi

if [[ "$mode" == plan ]]; then
  change=0
  for file in ${install_files[@]+"${install_files[@]}"}; do
    target="/etc/systemd/system/${file##*/}"
    if ! cmp -s -- "$file" "$target"; then
      echo "would change ${file##*/}"
      change=$((change + 1))
    fi
  done
  planned_retire=0
  for name in "${!retire[@]}"; do
    if refusal=$(can_retire "$name"); then
      echo "would retire $name"
      planned_retire=$((planned_retire + 1))
    else
      echo "$refusal"
    fi
  done
  echo 'would install tmpfiles configuration and create /etc/leafhft/engines'
  if [[ "$role" != tenant && -f "$base/units/leafhft-bookd@.service" ]]; then
    echo 'would install bookd sysusers configuration and create leafhft-bookd'
  fi
  if [[ -e "$lifecycle_tmpfiles" ]]; then
    echo 'would install lifecycle tmpfiles and create /var/lib/leafhft/engine-lifecycle and /var/lib/leafhft/engine-registry'
  fi
  if [[ -e "$exposure_tmpfiles" ]]; then
    echo 'would install exposure tmpfiles and create /var/lib/leafhft-exposure/roles (root 0755) and /var/lib/leafhft/exposure-refusals'
  fi
  if [[ -e "$deployments_tmpfiles" ]]; then
    echo 'would install deployments tmpfiles and create /etc/leafhft-deployments (root 0755) and /var/lib/leafhft-deployments (root 0700) and their subdirectories'
  fi
  echo 'would install tuning tmpfiles and create /etc/leafhft-tuning (root:leafhft 0750) and /var/lib/leafhft-tuning (root 0700) and /var/lib/leafhft-tuning-inputs (root:leafhft 0750)'
  for name in "${units[@]}"; do
    if book_held "$name"; then
      echo "held, not started: $name" >&2
      held=$((held + 1))
    elif [[ "$name" == leafhft-live-secrets.service && $secrets_enable_only -eq 1 ]]; then
      echo "would enable (not start) $name"
    elif ! start_now "$name"; then
      echo "would enable (not start) $name: outside LEAFHFT_INSTALL_LIVE_ONLY"
      held=$((held + 1))
    else
      echo "would start $name"
    fi
  done
  if [[ "$role" != tenant && -f "$base/units/$registry_audit_timer" ]]; then
    echo "would start $registry_audit_timer"
  fi
  echo "plan: change $change, retire $planned_retire, start $(( ${#units[@]} - held ))"
  exit 0
fi

changed=0
for file in ${install_files[@]+"${install_files[@]}"}; do
  target="/etc/systemd/system/${file##*/}"
  if ! cmp -s -- "$file" "$target"; then
    install -m 0644 -- "$file" "$target"
    echo "Changed ${file##*/}"
    changed=$((changed + 1))
  else
    chmod 0644 -- "$target"
  fi
done
# Git checkouts on Windows may lose executable bits.
chmod 0755 -- "$base/paper-run.sh" "$base/install-units.sh"
systemctl daemon-reload
if [[ "$role" != tenant && -f "$base/units/leafhft-bookd@.service" ]]; then
  install -D -m 0644 -- "$bookd_sysusers" /etc/sysusers.d/leafhft-bookd.conf
  systemd-sysusers /etc/sysusers.d/leafhft-bookd.conf
fi
install -m 0644 -- "$tmpfiles" /etc/tmpfiles.d/leafhft.conf
systemd-tmpfiles --create /etc/tmpfiles.d/leafhft.conf
if [[ -e "$lifecycle_tmpfiles" ]]; then
  install -m 0644 -- "$lifecycle_tmpfiles" /etc/tmpfiles.d/leafhft-lifecycle-dir.conf
  systemd-tmpfiles --create /etc/tmpfiles.d/leafhft-lifecycle-dir.conf
fi
if [[ -e "$exposure_tmpfiles" ]]; then
  install -m 0644 -- "$exposure_tmpfiles" /etc/tmpfiles.d/leafhft-exposure.conf
  systemd-tmpfiles --create /etc/tmpfiles.d/leafhft-exposure.conf
fi
if [[ -e "$deployments_tmpfiles" ]]; then
  install -m 0644 -- "$deployments_tmpfiles" /etc/tmpfiles.d/leafhft-deployments.conf
  systemd-tmpfiles --create /etc/tmpfiles.d/leafhft-deployments.conf
fi
install -m 0644 -- "$tuning_tmpfiles" /etc/tmpfiles.d/leafhft-tuning.conf
systemd-tmpfiles --create /etc/tmpfiles.d/leafhft-tuning.conf
retired=0
for name in "${!retire[@]}"; do
  can_retire "$name" || continue
  systemctl stop "$name"
  if [[ -n "${was_enabled[$name]+yes}" ]]; then
    systemctl disable "$name"
  fi
  retired=$((retired + 1))
done
for name in "${units[@]}"; do
  if book_held "$name"; then
    echo "held, not started: $name" >&2
    systemctl stop "$name"
    systemctl disable "$name"
    held=$((held + 1))
  elif [[ "$name" == leafhft-live-secrets.service && $secrets_enable_only -eq 1 ]]; then
    systemctl enable "$name"
    echo "not restarting secrets loader while $live_count live units run"
  elif ! start_now "$name"; then
    systemctl enable "$name"
    echo "enabled (not started) $name: outside LEAFHFT_INSTALL_LIVE_ONLY"
    held=$((held + 1))
  else
    systemctl enable --now --no-block "$name"
  fi
done
if [[ "$role" != tenant && -f "$base/units/$registry_audit_timer" ]]; then
  systemctl enable --now --no-block "$registry_audit_timer"
fi
echo "installed ${#install_files[@]}, changed $changed, started $(( ${#units[@]} - held )), retired $retired"
