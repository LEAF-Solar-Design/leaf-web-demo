#!/bin/bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo 'Usage: paper-run.sh <025|050|100|200|eth|sol|bnb|ada|sui>' >&2
  exit 2
fi
case "$1" in
  025) symbol=BTC-USD; half_spread=0.25; transport=(--transport ws --stale-ms 120000) ;;
  050) symbol=BTC-USD; half_spread=0.5; transport=(--transport ws --stale-ms 120000) ;;
  100) symbol=BTC-USD; half_spread=1.0; transport=(--transport ws --stale-ms 120000) ;;
  200) symbol=BTC-USD; half_spread=2.0; transport=(--transport ws --stale-ms 120000) ;;
  eth) symbol=ETH-USD; half_spread=0.5; transport=(--transport ws --stale-ms 120000) ;;
  sol) symbol=SOL-USD; half_spread=0.5; transport=(--transport ws --stale-ms 120000) ;;
  bnb) symbol=BNB-USD; half_spread=0.5; transport=(--transport ws --stale-ms 120000) ;;
  ada) symbol=ADA-USD; half_spread=0.5; transport=(--transport ws --stale-ms 120000) ;;
  sui) symbol=SUI-USD; half_spread=0.5; transport=(--transport ws --stale-ms 120000) ;;
  *) echo "Unknown paper label: $1" >&2; exit 2 ;;
esac

exec /opt/leafhft/.venv/bin/python -m leafhft paper \
  --venue binanceus --symbol "$symbol" --strategy mm --seconds 86400 \
  "${transport[@]}" \
  --params "{\"half_spread_bps\": $half_spread, \"vol_mult\": 1.5, \"order_frac\": 0.05, \"seed_frac\": 0, \"cost_rt_bps\": 0, \"min_edge_bps\": 0.25}" \
  --runs /var/lib/leafhft/runs
