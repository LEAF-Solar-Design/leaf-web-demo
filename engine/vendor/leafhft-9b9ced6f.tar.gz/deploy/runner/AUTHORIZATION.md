# Durable authorization for LeafHFT live books

S5 of deploy truth changes the authorization digest and adds an opt-in restart
model. V2 ships off. Do not set `LEAFHFT_AUTHZ_V2=1` on the runner before the
operator records authorization below.

One exact sentence authorizes one economic config digest and one venue/symbol.
The digest includes order sizing, risk, routing, strategy parameters, policy
bounds and engine selection. Observation, scheduling and paper-fill settings
are excluded. Narrowing the digest rotates existing acknowledgments once,
even with V2 off. Empty engine selections remain omitted from the digest.

With `LEAFHFT_AUTHZ_V2=1`, an acknowledgment remains intact across starts.
The default `LEAFHFT_ACK_TTL_S` module constant is 604800 seconds (7 days),
measured from the original ack's mtime. `LEAFHFT_ACK_MAX_STARTS` is 64 starts
per digest. These are code constants, not environment overrides. Each start
still passes all existing readiness, stake and policy-bound checks. Each run
retains its existing runtime and order limits.

`arms.jsonl` beside the shared ack records unit, venue, symbol, digest, nonce,
timestamp and cumulative starts under a lock, with an append and fsync before
arming. The run-directory copy preserves the shared ack's mtime. Reading the
journal uses only its last 64 KiB. If an old digest has fallen outside that
window, arming refuses because its count cannot be established. Rewriting an
ack does not reset its digest's start count. Renewal after the count limit or
loss of bounded history needs an explicit operator decision about that history;
the rearm tool never deletes it or resets counts.

Use `python deploy/runner/rearm.py --plan` to list recent gate refusals from
each unit's own journal. Add full unit names to limit the operation. `--apply`
stops each selected unit, confirms it stopped, checks its refusal again, writes
the exact sentence atomically as mode 0640 owned by leafhft:leafhft, starts it,
and reads back active state. It replaces the runner-only
`/opt/leafhft-tools/rearm-stranded-books.py`. It does not grant operator approval
or enable V2. Active state alone does not prove a full day of healthy trading.

Rollback: unset `LEAFHFT_AUTHZ_V2`. The next arm consumes the shared original
and renames the run ack with a nonce again. Existing running authorizations
are unaffected. The narrowed digest remains in effect.

Deployment order: fetch with V2 unset and no restarts. At a window gap, stop
binanceus-mm, write its new acknowledgment, and start it. With recorded
authorization, observe a full day under V2 including one deliberate restart.
Only then, with the operator's recorded yes and engines-lane coordination,
rearm the fourteen Kalshi books using their own printed sentences.

## Operator authorization

PENDING: the operator's own words, date and the numbers go here
