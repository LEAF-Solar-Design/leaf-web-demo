"""Read-only evidence for the combined Magpie runner deployment.

Usage: python deploy/runner/post_deploy_report.py --sha <40-lowercase-hex> \
    --since <aware-ISO-time> --until <aware-ISO-time> --receipt <exact-path> \
    --unit leafhft-push.service [--lane <account-lane>]

Only the explicit receipt, account evidence and bounded journal/deployed reads
are collected. Approval presence is not authority. Process identity is a current
snapshot, not historical journal lineage. Local push completion and journal
counts do not establish dashboard delivery. Absent natural scenarios remain
unobserved. Complete means collection completeness, never permission to trade,
deploy, rearm or release. This module writes only sanitized JSON to stdout.
"""

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import errno
import json
import os
from pathlib import Path
import re
import stat
import subprocess


SCHEMA = "leafhft.post-deploy-report.v1"
RECEIPT_SCHEMA = "leafhft.deploy-wrapper.v1"
MAX_OUTPUT = 1024 * 1024
MAX_LANE_FILE = 64 * 1024
UNIT = re.compile(r"leafhft-[A-Za-z0-9@_.-]+\.service")
LANE = re.compile(r"[a-z0-9][a-z0-9-]{0,63}")
SHA = re.compile(r"[0-9a-f]{40}")
STAGES = {"validate", "build", "post", "response", "apply", "complete"}


class _EvidenceError(Exception):
    """A fixed, safe error code, never an underlying exception message."""


def _utc_now():
    return datetime.now(timezone.utc)


def _time(value):
    if isinstance(value, str):
        value = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if not isinstance(value, datetime) or value.utcoffset() is None:
        raise ValueError("invalid_arguments")
    return value.astimezone(timezone.utc)


def _iso(value):
    return value.isoformat()


def _matches(pattern, value):
    return isinstance(value, str) and pattern.fullmatch(value) is not None


def _selections(value, pattern, maximum, required=False):
    if not isinstance(value, (list, tuple)):
        raise ValueError("invalid_arguments")
    if any(not _matches(pattern, item) for item in value):
        raise ValueError("invalid_arguments")
    result = sorted(set(value))
    if len(result) > maximum or (required and not result):
        raise ValueError("invalid_arguments")
    return result


def _arguments(args, now):
    """Finish all validation before touching a file or invoking a command."""
    try:
        collected = _time(now() if callable(now) else now)
        since, until = _time(args.since), _time(args.until)
        if not _matches(SHA, args.sha):
            raise ValueError
        if not since < until <= collected or (until - since).total_seconds() > 86400:
            raise ValueError
        units = _selections(args.unit, UNIT, 32, required=True)
        lane_values = getattr(args, "lane", None)
        lanes = _selections([] if lane_values is None else lane_values, LANE, 16)
        paths = {}
        for key, default in (
            ("receipt", None),
            ("account_root", "/var/lib/leafhft-accounts"),
            ("runs_root", "/var/lib/leafhft/runs"),
            ("python", "/opt/leafhft/.venv/bin/python"),
        ):
            value = os.fspath(getattr(args, key, default))
            if not isinstance(value, str) or not value or "\x00" in value:
                raise ValueError
            paths[key] = value
        return collected, since, until, units, lanes, paths
    except (AttributeError, TypeError, ValueError, OverflowError):
        raise ValueError("invalid_arguments") from None


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise _EvidenceError("duplicate_keys")
        result[key] = value
    return result


def _constant(value):
    raise _EvidenceError("invalid_json")


def _object(data):
    try:
        result = json.loads(data, object_pairs_hook=_pairs, parse_constant=_constant)
    except (ValueError, UnicodeError, RecursionError):
        raise _EvidenceError("invalid_json") from None
    if not isinstance(result, dict):
        raise _EvidenceError("invalid_fields")
    return result


def _is_link(info):
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0) & 0x400
    )


def _path_stat(path, directory_fd=None):
    if directory_fd is None:
        return os.lstat(path)
    return os.stat(path, dir_fd=directory_fd, follow_symlinks=False)


def _os_error(exc):
    if isinstance(exc, FileNotFoundError):
        return "missing"
    if exc.errno == errno.ELOOP:
        return "symlink"
    return "inaccessible"


def _read_object(path, limit, directory_fd=None):
    descriptor = None
    try:
        before = _path_stat(path, directory_fd)
        if _is_link(before):
            raise _EvidenceError("symlink")
        if not stat.S_ISREG(before.st_mode):
            raise _EvidenceError("invalid_file")
        flags = os.O_RDONLY | getattr(os, "O_BINARY", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
        options = {} if directory_fd is None else {"dir_fd": directory_fd}
        descriptor = os.open(path, flags, **options)
        after = os.fstat(descriptor)
        if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
            raise _EvidenceError("changed_during_read")
        if not stat.S_ISREG(after.st_mode):
            raise _EvidenceError("invalid_file")
        with os.fdopen(descriptor, "rb") as stream:
            descriptor = None
            data = stream.read(limit + 1)
        if len(data) > limit:
            raise _EvidenceError("oversize")
        return _object(data.decode("utf-8"))
    except UnicodeError:
        raise _EvidenceError("invalid_json") from None
    except OSError as exc:
        raise _EvidenceError(_os_error(exc)) from None
    finally:
        if descriptor is not None:
            os.close(descriptor)


@contextmanager
def _lane_directory(path):
    """Pin the lane directory on POSIX; reject links/reparse points elsewhere."""
    descriptor = None
    try:
        before = _path_stat(path)
        if _is_link(before):
            raise _EvidenceError("symlink")
        if not stat.S_ISDIR(before.st_mode):
            raise _EvidenceError("invalid_directory")
        if os.open in os.supports_dir_fd and hasattr(os, "O_NOFOLLOW"):
            descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            after = os.fstat(descriptor)
            if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
                raise _EvidenceError("changed_during_read")

        def evidence_path(name):
            if descriptor is not None:
                return name, descriptor
            after = _path_stat(path)
            if _is_link(after):
                raise _EvidenceError("symlink")
            if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
                raise _EvidenceError("changed_during_read")
            return path / name, None

        yield evidence_path
    except OSError as exc:
        raise _EvidenceError(_os_error(exc)) from None
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _issue(issues, scope, code, **selection):
    issues.append({"scope": scope, "code": code, **selection})


def _receipt(path, sha, since, issues):
    approval = {
        "approved_by_present": False,
        "approval_ref_present": False,
        "authority_verified": False,
    }
    try:
        data = _read_object(path, MAX_OUTPUT)
    except _EvidenceError as exc:
        _issue(issues, "deployment", "receipt_" + str(exc))
        return None, approval, []
    result = {
        "schema": None, "sha": None, "units": [], "started_at": None,
        "ended_at": None, "outcome": None,
    }
    if data.get("schema") == RECEIPT_SCHEMA:
        result["schema"] = RECEIPT_SCHEMA
    else:
        _issue(issues, "deployment", "receipt_schema_mismatch")
    if _matches(SHA, data.get("sha")):
        result["sha"] = data["sha"]
    if result["sha"] != sha:
        _issue(issues, "deployment", "receipt_sha_mismatch")
    units = data.get("units")
    if (isinstance(units, list) and units
            and all(_matches(UNIT, unit) for unit in units)
            and len(set(units)) == len(units)):
        result["units"] = sorted(units)
    else:
        _issue(issues, "deployment", "receipt_invalid_units")
    outcome = data.get("outcome")
    if isinstance(outcome, str) and outcome in {"running", "failed", "succeeded"}:
        result["outcome"] = outcome
    if result["outcome"] != "succeeded":
        _issue(issues, "deployment", "receipt_not_succeeded")
    try:
        if not all(isinstance(data.get(key), str) for key in ("started_at", "ended_at")):
            raise ValueError
        started, ended = _time(data["started_at"]), _time(data["ended_at"])
        result["started_at"], result["ended_at"] = _iso(started), _iso(ended)
        if not started <= ended <= since:
            _issue(issues, "deployment", "receipt_window_mismatch")
    except (ValueError, TypeError, OverflowError):
        _issue(issues, "deployment", "receipt_invalid_time")
    for key in ("approved_by", "approval_ref"):
        value = data.get(key)
        approval[key + "_present"] = isinstance(value, str) and bool(value.strip())
        if value is not None and not isinstance(value, str):
            _issue(issues, "deployment", "receipt_invalid_approval")
    if not approval["approved_by_present"] or not approval["approval_ref_present"]:
        _issue(issues, "deployment", "approval_missing")
    return result, approval, result["units"]


def _command(run, argv):
    try:
        response = run(
            argv, shell=False, timeout=10, check=False,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
    except subprocess.TimeoutExpired:
        raise _EvidenceError("timeout") from None
    except (OSError, subprocess.SubprocessError):
        raise _EvidenceError("command_failed") from None
    output = response.stdout
    try:
        if isinstance(output, str):
            if len(output) > MAX_OUTPUT or len(output.encode("utf-8")) > MAX_OUTPUT:
                raise _EvidenceError("oversize")
        elif isinstance(output, bytes):
            if len(output) > MAX_OUTPUT:
                raise _EvidenceError("oversize")
            output = output.decode("utf-8")
        else:
            raise _EvidenceError("invalid_output")
    except UnicodeError:
        raise _EvidenceError("invalid_output") from None
    return response.returncode, output


def _source(run, paths, selected, sha, collected, issues):
    result = {"matched": False, "rows": []}
    try:
        code, output = _command(run, [
            paths["python"], "-m", "leafhft", "deployed",
            "--runs-root", paths["runs_root"], "--json",
        ])
        if type(code) is not int or code not in (0, 1, 2):
            raise _EvidenceError("unreadable")
        data = _object(output)
        if (not isinstance(data.get("rows"), list)
                or data.get("verdict") not in ("IN_SYNC", "DRIFTED", "DEGRADED")
                or type(data.get("exit_code")) is not int
                or data["exit_code"] != code
                or not isinstance(data.get("errors"), list)
                or any(not isinstance(row, dict) for row in data["rows"])):
            raise _EvidenceError("invalid_output")
    except _EvidenceError as exc:
        _issue(issues, "source", "deployed_" + str(exc))
        return result
    first_issue = len(issues)
    for unit in selected:
        rows = [row for row in data["rows"] if row.get("unit") == unit]
        if len(rows) != 1:
            _issue(issues, "source", "source_missing" if not rows else "source_duplicate", unit=unit)
            continue
        row = rows[0]
        clean = {"unit": unit, "git_sha": None, "dirty": None, "live": None, "generated_at": None}
        if _matches(SHA, row.get("git_sha")):
            clean["git_sha"] = row["git_sha"]
        for key in ("dirty", "live"):
            if type(row.get(key)) is bool:
                clean[key] = row[key]
        for valid, error in (
            (clean["git_sha"] == sha, "source_sha_mismatch"),
            (clean["dirty"] is False, "source_dirty"),
            (clean["live"] is True, "source_not_live"),
        ):
            if not valid:
                _issue(issues, "source", error, unit=unit)
        try:
            if not isinstance(row.get("generated_at"), str):
                raise ValueError
            generated = _time(row["generated_at"])
            clean["generated_at"] = _iso(generated)
            age = (collected - generated).total_seconds()
            if age < 0:
                _issue(issues, "source", "source_future", unit=unit)
            elif age >= 60:
                _issue(issues, "source", "source_stale", unit=unit)
        except (ValueError, TypeError, OverflowError):
            _issue(issues, "source", "source_invalid_time", unit=unit)
        result["rows"].append(clean)
    result["matched"] = bool(selected) and len(issues) == first_issue
    return result


def _event_kind(message):
    if (message.startswith(("push books: scan failed:", "push books: POST failed:"))
            or re.fullmatch(r"push books [^\s:]+: .+", message)):
        return "books_errors"
    if re.fullmatch(r"push control: pending row -?[0-9]+ malformed, ignored", message):
        return "malformed_rows"
    if re.fullmatch(r"push control: id=\S+[^\r\n]* -> rejected unsupported_kind:[^\r\n]*", message):
        return "unsupported_kind_rejections"
    return "other_events"


def _micros(value):
    delta = value - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return (delta.days * 86400 + delta.seconds) * 1000000 + delta.microseconds


def _journal(run, unit, since, until, issues):
    result = {
        "unit": unit, "complete": False, "observation": "unobserved",
        "interval_coverage": "not_established", "input_rows": 0,
        "observed_events": 0, "excluded_other_unit": 0,
        "excluded_out_of_window": 0, "books_errors": 0,
        "malformed_rows": 0, "unsupported_kind_rejections": 0, "other_events": 0,
    }
    first_issue = len(issues)
    try:
        code, output = _command(run, [
            "journalctl", "--unit", unit, "--since", _iso(since),
            "--until", _iso(until), "--output=json", "--no-pager", "--lines=1001",
        ])
    except _EvidenceError as exc:
        _issue(issues, "journal", "journal_" + str(exc), unit=unit)
        return result
    if type(code) is not int or code != 0:
        _issue(issues, "journal", "journal_nonzero", unit=unit)
    lines = output.splitlines()
    result["input_rows"] = len(lines)
    if len(lines) >= 1001:
        _issue(issues, "journal", "journal_truncated", unit=unit)
    lower, upper = _micros(since), _micros(until)
    malformed = False
    for line in lines[:1001]:
        try:
            row = _object(line)
            timestamp = row.get("__REALTIME_TIMESTAMP")
            if (not isinstance(row.get("_SYSTEMD_UNIT"), str)
                    or not isinstance(row.get("MESSAGE"), str)
                    or not isinstance(timestamp, str)
                    or not re.fullmatch(r"[0-9]{1,20}", timestamp)):
                raise _EvidenceError("invalid_fields")
            if row["_SYSTEMD_UNIT"] != unit:
                result["excluded_other_unit"] += 1
            elif not lower <= int(timestamp) <= upper:
                result["excluded_out_of_window"] += 1
            else:
                result["observed_events"] += 1
                result[_event_kind(row["MESSAGE"])] += 1
        except _EvidenceError:
            malformed = True
    if malformed:
        _issue(issues, "journal", "journal_malformed", unit=unit)
    result["complete"] = len(issues) == first_issue
    if result["observed_events"]:
        result["observation"] = "observed"
    return result


def _lane(lane, root, since, until, collected, issues):
    result = {
        "lane": lane, "status": None, "push_status": None, "kill_present": None,
        "state": "unreadable", "down_reason": None, "push_in_window": False,
        "completed_push": "unobserved", "dashboard_lane_status": "unobserved",
        "lane_source_binding": "not_available_in_status", "complete": False,
    }
    first_issue = len(issues)
    try:
        with _lane_directory(Path(root) / lane) as evidence_path:
            for name, key in (("status.json", "status"), ("push-status.json", "push_status")):
                try:
                    path, directory_fd = evidence_path(name)
                    data = _read_object(path, MAX_LANE_FILE, directory_fd)
                    updated = data.get("updated_at")
                    if type(updated) is not int or updated < 0:
                        raise _EvidenceError("invalid_fields")
                    if updated > collected.timestamp():
                        raise _EvidenceError("future")
                    if key == "status":
                        if (data.get("mode") not in ("live", "dry_run")
                                or type(data.get("running_books")) is not int
                                or not 0 <= data["running_books"] <= 14):
                            raise _EvidenceError("invalid_fields")
                        result[key] = {"mode": data["mode"], "running_books": data["running_books"], "updated_at": updated}
                    else:
                        if (not isinstance(data.get("stage"), str)
                                or data["stage"] not in STAGES
                                or type(data.get("success")) is not bool):
                            raise _EvidenceError("invalid_fields")
                        result[key] = {"stage": data["stage"], "success": data["success"], "updated_at": updated}
                except _EvidenceError as exc:
                    _issue(issues, "lane", key + "_" + str(exc), lane=lane)
            try:
                path, directory_fd = evidence_path("KILL")
                info = _path_stat(path, directory_fd)
                if _is_link(info):
                    raise _EvidenceError("symlink")
                result["kill_present"] = True
            except FileNotFoundError:
                result["kill_present"] = False
            except OSError as exc:
                _issue(issues, "lane", "kill_" + _os_error(exc), lane=lane)
            except _EvidenceError as exc:
                _issue(issues, "lane", "kill_" + str(exc), lane=lane)
    except _EvidenceError as exc:
        _issue(issues, "lane", "lane_" + str(exc), lane=lane)
    status = result["status"]
    if status is not None:
        if collected.timestamp() - status["updated_at"] <= 120:
            result["state"] = "fresh"
        else:
            result["state"] = "down"
            if result["kill_present"] is True:
                result["down_reason"] = "stopped"
            elif result["kill_present"] is False:
                result["down_reason"] = "exited" if status["running_books"] == 0 else "unresponsive"
    push = result["push_status"]
    if push is not None:
        result["push_in_window"] = since.timestamp() <= push["updated_at"] <= until.timestamp()
        if result["push_in_window"] and push["stage"] == "complete" and push["success"]:
            result["completed_push"] = "observed"
    result["complete"] = len(issues) == first_issue
    return result


def collect_post_deploy_report(args, *, run=None, now=None) -> dict:
    """Collect partial evidence; invalid arguments raise ValueError before I/O."""
    collected, since, until, units, lanes, paths = _arguments(
        args, _utc_now if now is None else now,
    )
    run = subprocess.run if run is None else run
    issues = []
    deployment, approval, selected = _receipt(paths["receipt"], args.sha, since, issues)
    source = _source(run, paths, selected, args.sha, collected, issues)
    journals = [_journal(run, unit, since, until, issues) for unit in units]
    accounts = [_lane(lane, paths["account_root"], since, until, collected, issues) for lane in lanes]
    issues = sorted(
        {json.dumps(issue, sort_keys=True): issue for issue in issues}.values(),
        key=lambda issue: (issue["scope"], issue.get("unit", ""), issue.get("lane", ""), issue["code"]),
    )
    return {
        "schema": SCHEMA, "target_sha": args.sha,
        "window": {"since": _iso(since), "until": _iso(until)},
        "collected_at": _iso(collected), "deployment": deployment, "approval": approval,
        "selected_process_source": source, "source_binding": "selected_process_snapshot",
        "historical_source_verified": False, "journals": journals, "lanes": accounts,
        "slice_observations": {
            "B9": {"books_errors": sum(j["books_errors"] for j in journals),
                   "dashboard_ingest": "unobserved", "book_hops_positive": "unobserved"},
            "C-ackunknown": {"unsupported_kind_rejection": "observed" if any(
                j["unsupported_kind_rejections"] for j in journals
            ) else "unobserved", "malformed_rows": sum(j["malformed_rows"] for j in journals)},
            "KM7": {"account_evidence": "observed" if any(
                lane["status"] is not None for lane in accounts
            ) else "unobserved", "completed_push": "observed" if any(
                lane["completed_push"] == "observed" for lane in accounts
            ) else "unobserved", "dashboard_lane_status": "unobserved"},
        },
        "issues": issues, "complete": not issues,
    }


class _Parser(argparse.ArgumentParser):
    def error(self, message):
        raise ValueError("invalid_arguments")


def post_deploy_main(argv=None) -> int:
    parser = _Parser(description=__doc__, allow_abbrev=False)
    for name in ("sha", "since", "until", "receipt"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--unit", action="append", required=True)
    parser.add_argument("--lane", action="append", default=[])
    parser.add_argument("--account-root", default="/var/lib/leafhft-accounts")
    parser.add_argument("--runs-root", default="/var/lib/leafhft/runs")
    parser.add_argument("--python", default="/opt/leafhft/.venv/bin/python")
    try:
        report = collect_post_deploy_report(parser.parse_args(argv))
    except ValueError:
        print(json.dumps({"schema": SCHEMA, "complete": False, "issues": [
            {"scope": "arguments", "code": "invalid_arguments"},
        ]}, sort_keys=True))
        return 2
    print(json.dumps(report, sort_keys=True))
    return 0 if report["complete"] else 1


if __name__ == "__main__":
    raise SystemExit(post_deploy_main())
