#!/usr/bin/env python3
"""Read-only runner feature inventory; activation steps are data, never executed."""

import argparse
import fnmatch
import json
import math
import re
import shlex
import subprocess
import sys
from pathlib import Path, PurePosixPath


SCHEMA = "leafhft.runner-features.v1"
MAX_REGISTRY = 256 * 1024
MAX_POLICY = 1024 * 1024
PATH_ROOTS = ("/etc/leafhft/", "/etc/leafhft-bookd/", "/etc/leafhft-accounts/",
              "/var/lib/leafhft-tuning/", "/var/lib/leafhft/")
UNIT = re.compile(r"leafhft-[A-Za-z0-9@._-]+\.(service|timer)\Z")
# A trailing star also matches the unit suffix (the live-book selector uses this).
UNIT_GLOB = re.compile(r"leafhft-(?:[A-Za-z0-9@._*\-]+\.(?:service|timer)|[A-Za-z0-9@._*\-]*\*)\Z")
ID = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*\Z")


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def string(value, maximum=None, empty=False):
    return (isinstance(value, str) and "\0" not in value
            and (empty or bool(value.strip()))
            and (maximum is None or len(value) <= maximum))


def valid_path(value):
    return (string(value) and value.startswith(PATH_ROOTS)
            and ".." not in value.split("/") and "\\" not in value
            and PurePosixPath(value).is_absolute())


def fields(obj, required, optional=()):
    require(type(obj) is dict, "expected an object")
    require(set(required) <= obj.keys() <= set(required) | set(optional),
            "missing or unexpected fields: " + repr(obj))


def validate_check(check, precondition=False):
    require(type(check) is dict, "check must be an object")
    kind = check.get("kind")
    shapes = {
        "file_content": ("path", "content"), "file_present": ("path",),
        "file_absent": ("path",), "unit_active": ("unit",),
        "policy_dial": ("key", "value", "min_engines"),
        "proc_arg": ("unit_globs", "arg"), "manual": ("note",),
    }
    if precondition:
        shapes["feature_on"] = ("id",)
    require(isinstance(kind, str) and kind in shapes, "unknown check kind")
    fields(check, ("kind",) + shapes[kind], ("all_bound",) if kind == "policy_dial" else ())
    if "path" in check:
        require(valid_path(check["path"]), "invalid check path")
    if "content" in check:
        require(string(check["content"], empty=True), "invalid file content")
    if "unit" in check:
        require(string(check["unit"]) and UNIT.fullmatch(check["unit"]), "invalid unit")
    if kind == "proc_arg":
        require(type(check["unit_globs"]) is list and 1 <= len(check["unit_globs"]) <= 4
                and all(string(g) and UNIT_GLOB.fullmatch(g) for g in check["unit_globs"]),
                "invalid unit globs")
        require(string(check["arg"]) and bool(shlex.split(check["arg"])), "invalid argument")
    if kind == "policy_dial":
        require(type(check.get("all_bound", False)) is bool, "invalid all_bound")
        require(string(check["key"]), "invalid policy key")
        value = check["value"]
        require(value is None or type(value) in (str, bool, int, float), "invalid policy value")
        require(not isinstance(value, float) or math.isfinite(value), "nonfinite policy value")
        require(type(check["min_engines"]) is int and 1 <= check["min_engines"] <= 4096,
                "invalid min_engines")
    if "note" in check:
        require(string(check["note"]), "invalid manual note")
    if kind == "feature_on":
        require(string(check["id"], 48) and ID.fullmatch(check["id"]), "invalid feature reference")


def validate_step(step):
    require(type(step) is dict, "step must be an object")
    shapes = {"write_file": ("path", "content", "mode"), "remove_file": ("path",),
              "start_unit": ("unit",), "stop_unit": ("unit",),
              "restart_books": (), "manual": ("note",)}
    kind = step.get("kind")
    require(isinstance(kind, str) and kind in shapes, "unknown step kind")
    fields(step, ("kind",) + shapes[kind])
    if "path" in step:
        require(valid_path(step["path"]), "invalid step path")
    if "unit" in step:
        require(string(step["unit"]) and UNIT.fullmatch(step["unit"]), "invalid step unit")
    if kind == "write_file":
        require(step["mode"] == "0644" and string(step["content"], empty=True),
                "invalid write_file content or mode")
    if kind == "manual":
        require(string(step["note"]), "invalid manual step")


def validate_registry(registry):
    fields(registry, ("schema", "features", "not_features"))
    require(registry["schema"] == SCHEMA, "invalid registry schema")
    rows = registry["features"]
    require(type(rows) is list and len(rows) <= 256, "feature cap exceeded or invalid list")
    ids = set()
    for row in rows:
        fields(row, ("id", "title", "owner", "prs", "summary", "stage", "authority",
                     "applies", "switches", "preconditions", "activate", "rollback"), ("verify",))
        require(string(row["id"], 48) and ID.fullmatch(row["id"]), "invalid feature id")
        require(row["id"] not in ids, "duplicate feature id")
        ids.add(row["id"])
        for key, cap in (("title", 80), ("owner", 48), ("summary", 240)):
            require(string(row[key], cap), "invalid " + key)
        require(type(row["prs"]) is list and all(type(p) is int for p in row["prs"]), "invalid prs")
        for key, choices in (("stage", ("shadow", "live")), ("authority", ("seat", "operator")),
                             ("applies", ("immediate", "book_restart", "lane_start", "unit_start"))):
            require(row[key] in choices, "invalid " + key)
        for key, low, high in (("switches", 1, 16), ("preconditions", 0, 16), ("verify", 0, 4),
                               ("activate", 1, 8), ("rollback", 1, 8)):
            values = row.get(key, [])
            require(type(values) is list and low <= len(values) <= high, "invalid " + key)
            for value in values:
                if key in ("activate", "rollback"):
                    validate_step(value)
                else:
                    validate_check(value, key == "preconditions")
    for row in rows:
        stops = {c["path"] for c in row["switches"] if c["kind"] == "file_absent"}
        if stops:
            require(row["authority"] == "operator", "kill-switch requires operator authority")
            require(not any(s["kind"] == "remove_file" and s["path"] in stops
                            for s in row["activate"]), "kill-switch removal must be manual")
        for check in row["preconditions"]:
            if check["kind"] == "feature_on":
                require(check["id"] in ids, "unknown feature_on id: " + check["id"])
    require(type(registry["not_features"]) is list, "invalid not_features")
    names = set()
    for row in registry["not_features"]:
        fields(row, ("name", "reason"))
        require(string(row["name"]) and string(row["reason"]), "invalid exemption")
        require(row["name"] not in names, "duplicate exemption")
        names.add(row["name"])
    return registry


def unique_object(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, "duplicate JSON key: " + key)
        obj[key] = value
    return obj


def read_json(path, limit):
    with path.open("rb") as stream:
        data = stream.read(limit + 1)
    require(len(data) <= limit, str(path) + " exceeds size limit")
    return json.loads(data, object_pairs_hook=unique_object,
                      parse_constant=lambda value: require(False, "nonfinite JSON: " + value))


def load_registry(path):
    return validate_registry(read_json(Path(path), MAX_REGISTRY))


def run(argv, timeout):
    return subprocess.run(argv, timeout=timeout, capture_output=True, text=True, check=False)


class Checker:
    def __init__(self, root="/", run=run):
        self.root = Path(root)
        self.run = run
        self.unreadable = []

    def path(self, absolute):
        return self.root.joinpath(*PurePosixPath(absolute).parts[1:])

    def command(self, argv, allow_inactive=False):
        result = self.run(argv, timeout=10)
        if result.returncode and not (allow_inactive and result.returncode == 3):
            raise ValueError("command failed: " + " ".join(argv))
        return result.stdout.strip()

    def check(self, check, states=None):
        result = dict(check)
        try:
            status, fact = self.evaluate(check, states or {})
        except (OSError, ValueError, UnicodeError, subprocess.SubprocessError, RecursionError) as exc:
            status, fact = "unreadable", str(exc)[:240]
        result.update(status=status, fact=fact)
        if status == "unreadable":
            self.unreadable.append(fact)
        return result

    def evaluate(self, check, states):
        kind = check["kind"]
        if kind == "manual":
            return "unreadable", "manual: " + check["note"]
        if kind == "feature_on":
            state = states[check["id"]]
            return ("pass" if state == "on" else "unreadable" if state == "unknown" else "fail"), state
        if kind.startswith("file_"):
            path = self.path(check["path"])
            try:
                path.stat()
                exists = True
            except FileNotFoundError:
                exists = False
            if kind == "file_content":
                passed = exists and "".join(path.read_text(encoding="utf-8").split()) == "".join(check["content"].split())
            else:
                passed = exists if kind == "file_present" else not exists
            return ("pass" if passed else "fail"), check["path"] + (" matches" if passed else " does not match")
        if kind == "unit_active":
            active = self.command(["systemctl", "is-active", check["unit"]], allow_inactive=True)
            return ("pass" if active == "active" else "fail"), active or "no active state"
        if kind == "policy_dial":
            return self.policy(check)
        if kind == "proc_arg":
            return self.processes(check)
        raise ValueError("unsupported check")

    def policy(self, check):
        count = skipped = 0
        engines = set()
        for filename, probes in (("kalshi-engine-bindings.json", False), ("probe-bindings.json", True)):
            bindings = read_json(self.path("/etc/leafhft/" + filename), MAX_POLICY)
            require(type(bindings) is dict and type(bindings.get("symbols")) is dict,
                    "invalid bindings: " + filename)
            for value in bindings["symbols"].values():
                ids = value if probes else [value]
                require(type(ids) is list, "invalid bindings engines: " + filename)
                for engine in ids:
                    require(string(engine) and re.fullmatch(r"[A-Za-z0-9_-]+", engine),
                            "invalid bound engine id")
                    engines.add(engine)
        files = [self.path("/etc/leafhft/engines/" + e + ".json") for e in sorted(engines)]
        skipped = max(0, len(files) - 4096)
        for path in files[:4096]:
            try:
                policy = read_json(path, MAX_POLICY)
                pending = [policy]
                found = False
                while pending:
                    obj = pending.pop()
                    if isinstance(obj, dict):
                        value = obj.get(check["key"])
                        if value is not None and (check["value"] is None or
                                (value == check["value"] and isinstance(value, bool) == isinstance(check["value"], bool))):
                            found = True
                        pending.extend(obj.values())
                    elif isinstance(obj, list):
                        pending.extend(obj)
                count += found
            except (OSError, ValueError, UnicodeError, RecursionError) as exc:
                skipped += 1
                self.unreadable.append(str(path) + ": " + str(exc)[:160])
        fact = f"{count} of {len(engines)} bound engines"
        if skipped:
            self.unreadable.append(fact)
        passed = (count == len(engines) and count >= 1 if check.get("all_bound", False)
                  else count >= check["min_engines"])
        return ("pass" if passed else "unreadable" if skipped else "fail"), fact

    def processes(self, check):
        output = self.command(["systemctl", "list-units", "--state=active", "--no-legend",
                               "--plain", "--no-pager", *check["unit_globs"]])
        units = list(dict.fromkeys(line.split()[0] for line in output.splitlines() if line.strip()))
        require(len(units) <= 256, "unit glob exceeds 256 units")
        require(all(UNIT.fullmatch(u) and any(fnmatch.fnmatchcase(u, g) for g in check["unit_globs"]) for u in units),
                "unexpected unit in systemctl output")
        if not units:
            return "fail", "no active units"
        wanted = shlex.split(check["arg"])
        failures = unreadable = 0
        for unit in units:
            try:
                pid = self.command(["systemctl", "show", unit, "--property=MainPID", "--value"])
                require(pid.isascii() and pid.isdigit() and int(pid) > 0, "invalid MainPID for " + unit)
                args = self.path("/proc/" + pid + "/cmdline").read_bytes().decode("utf-8").split("\0")
                failures += not any(args[i:i + len(wanted)] == wanted for i in range(len(args)))
            except (OSError, ValueError, UnicodeError, subprocess.SubprocessError) as exc:
                unreadable += 1
                self.unreadable.append(unit + ": " + str(exc)[:160])
        return ("fail" if failures else "unreadable" if unreadable else "pass"), (
            f"{len(units)} active units; {failures} missing argument; {unreadable} unreadable")


def feature_state(switches):
    statuses = {s["status"] for s in switches}
    if "fail" in statuses:
        return "partial" if "pass" in statuses else "off"
    return "unknown" if "unreadable" in statuses else "on"


def report(registry, root="/", run=run):
    validate_registry(registry)
    checker = Checker(root, run)
    rows = [{**row, "switches": [checker.check(c) for c in row["switches"]]}
            for row in registry["features"]]
    states = {row["id"]: feature_state(row["switches"]) for row in rows}
    for row in rows:
        row["state"] = states[row["id"]]
        row["preconditions"] = [checker.check(c, states) for c in row["preconditions"]]
        row["manual"] = any(c["kind"] == "manual" for c in row["switches"])
        row["ready"] = (row["state"] != "on" and not row["manual"]
                        and not any(c["status"] == "unreadable" for c in row["switches"])
                        and all(c["status"] == "pass" for c in row["preconditions"]))
        if "verify" in row:
            row["verify"] = [checker.check(c) for c in row["verify"]]
    repo = str(Path(__file__).resolve().parents[2])
    try:
        head = checker.command(["git", "-C", repo, "-c", "safe.directory=" + repo, "rev-parse", "HEAD"]) or None
    except (OSError, ValueError, subprocess.SubprocessError):
        head = None
    return {"schema": "leafhft.runner-feature-state.v1", "head": head, "features": rows,
            "counts": {state: sum(r["state"] == state for r in rows)
                       for state in ("on", "partial", "off", "unknown")},
            "unreadable": checker.unreadable}


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(5, message + "\n")


def main(argv=None, run=run):
    parser = Parser(description=__doc__)
    parser.add_argument("--registry", default=str(Path(__file__).with_name("features.json")))
    parser.add_argument("--root", default="/")
    parser.add_argument("--feature")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    try:
        registry = load_registry(args.registry)
    except (OSError, ValueError, UnicodeError, RecursionError) as exc:
        print("invalid registry: " + str(exc), file=sys.stderr)
        return 4
    if args.feature and args.feature not in {r["id"] for r in registry["features"]}:
        parser.error("unknown feature: " + args.feature)
    result = report(registry, args.root, run)
    if args.feature:
        result["features"] = [r for r in result["features"] if r["id"] == args.feature]
        result["counts"] = {s: sum(r["state"] == s for r in result["features"]) for s in result["counts"]}
    if args.json:
        print(json.dumps(result))
    else:
        counts = result["counts"]
        print("features: " + ", ".join(f"{counts[s]} {s}" for s in counts))
        for row in result["features"]:
            ready = "manual" if row["manual"] else "yes" if row["ready"] else "no"
            print(f"{row['id']}: {row['state']} stage={row['stage']} applies={row['applies']} ready={ready}")
            for check in row["switches"]:
                print(f"  {check['kind']}: {check['status']} {check['fact']}")
    return 0 if all(r["state"] == "on" for r in result["features"] if not r["manual"]) else 3


if __name__ == "__main__":
    sys.exit(main())
