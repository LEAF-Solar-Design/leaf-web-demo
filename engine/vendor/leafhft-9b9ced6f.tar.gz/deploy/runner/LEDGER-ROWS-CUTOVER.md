# Offline account-ledger rows cutover

This procedure needs the operator's explicit yes and the seat's approved restart
kit. Shipping this code does not authorize a live cutover. Run it only inside the
approved restart gap, with all 14 owner book processes stopped together. Do not
use a rolling restart. Stop any additional process or automation that can write
this principal's ledger, including automatic restart/re-arm jobs, for the whole
operation. Preserve the existing containment and re-arm gates in the seat kit.

`VerifiedAccountRiskLedger.live` reads the existing format. New files default to
body; `LEAFHFT_LEDGER_NEW_FORMAT=rows` changes only creation. Leave this variable
unset for this cutover. Body-only writers at or after this release refuse rows
with `ledger_format_rows`. Older code refuses every rows file's poisoned
legacy slot with `ledger_corrupt`. Deploy the compatible revision everywhere
before converting.

## Prepare and stop

Use the deployed Python environment from the checked-out compatible revision.
Set `SRC` to the verified principal-derived `.sqlite3` path from the seat kit, not
the legacy lane ledger. Confirm its account identity and the complete writer
inventory before beginning. The commands below run on the Linux runner as the
seat; service commands require the seat's normal privileges.

```bash
set -euo pipefail
export SRC=/var/lib/leafhft/account-risk/PRINCIPAL_DIGEST.sqlite3
TS=$(date -u +%Y%m%dT%H%M%SZ)
export DST="${SRC}.rows-${TS}"
source deploy/runner/book-inventory.generated.env
UNITS=()
for symbol in "${KALSHI_SYMBOLS[@]}"; do
  UNITS+=("leafhft-live@kalshi-${symbol,,}.service")
done
test "${#UNITS[@]}" -eq 14
# After the seat kit confirms the restart gap and pauses restart automation:
systemctl stop "${UNITS[@]}"
for unit in "${UNITS[@]}"; do
  test "$(systemctl show --property=ActiveState --value "$unit")" = inactive
  test "$(systemctl show --property=MainPID --value "$unit")" = 0
done
```

Reconcile this list against the kit's inventory: a second lane sharing the
principal must also be stopped. `BEGIN EXCLUSIVE` within two seconds is an active
transaction fence, not proof that an idle writer process has exited. A refusal
means stop and investigate; never bypass the lock or copy around it.

Checkpoint only after all writers and auxiliary connections have stopped. Keep
SQLite sidecars with their database until this succeeds; never discard a WAL.

```bash
python - <<'PY'
import os, sqlite3
from pathlib import Path
path = Path(os.environ['SRC']).resolve()
db = sqlite3.connect(path.as_uri() + '?mode=rw', uri=True, timeout=2, isolation_level=None)
try:
    assert db.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0] == 0
    db.execute('BEGIN EXCLUSIVE')
    db.execute('ROLLBACK')
finally:
    db.close()
wal = Path(str(path) + '-wal')
assert not wal.exists() or wal.stat().st_size == 0
PY
python -m leafhft.broker.account_risk_migrate to-rows "$SRC" "$DST"
```

The converter requires an unused sibling destination, never deletes SRC, fsyncs
DST, compares canonical full and hot export bytes and entry/event order, reopens
the durable output, and writes `DST.receipt.json`. A failed conversion may leave
an unused destination; do not rename it into service. Preserve it for diagnosis
and choose a fresh destination on retry. No successful receipt means no cutover.

## Verify receipt, rename, start, read back

Compare both formats while still stopped. Receipt digests are SHA-256 of
canonical public JSON exports, not SQLite page bytes. Counts include full
entries, hot entries, events and archived entries. The revision must not change
during conversion. Inspect the receipt's principal, paths and timestamps against
the kit before proceeding.

Prepare shell associative arrays `UNIT_CHECKOUT` and `UNIT_PYTHON`, keyed by
every unit in `UNITS`, from the seat's complete writer inventory. Verify each
unit's deployed checkout, working directory, venv and import environment against
`systemctl cat "$unit"`, its drop-ins and its launch script. The stock owner
unit uses `/opt/leafhft` and `/opt/leafhft/.venv/bin/python`; do not assume those
paths for an overridden unit or another lane. For example, start with
`declare -A UNIT_CHECKOUT UNIT_PYTHON`, then set
`UNIT_CHECKOUT[leafhft-live@kalshi-btc-15m.service]=/opt/leafhft` and
`UNIT_PYTHON[leafhft-live@kalshi-btc-15m.service]=/opt/leafhft/.venv/bin/python`,
and fill the remaining units from the inventory. Match any unit-specific import
environment when running its check. Keep deployment and venv updates paused
through start. The loop below checks every unit, including units sharing a
checkout. A missing mapping or failed capability assertion stops the procedure;
keep all writers stopped until it is resolved.

```bash
python - <<'PY'
import hashlib, json, os
from pathlib import Path
from leafhft.broker.account_risk import read_ledger
from leafhft.broker.account_risk_migrate import export_bytes
src, dst = Path(os.environ['SRC']), Path(os.environ['DST'])
r = json.loads(Path(str(dst) + '.receipt.json').read_text())
assert r['schema'] == 'leafhft-ledger-conversion-v1'
assert r['source'] == str(src.resolve()) and r['destination'] == str(dst.absolute())
assert r['source_digests'] == r['destination_digests']
for path, side in ((src, 'source'), (dst, 'destination')):
    for hot, view in ((False, 'full'), (True, 'hot')):
        result = read_ledger(path, r['account_id'], hot=hot)
        assert result['status'] == 'ok' and result['healthy'], result
        state = result['state']
        assert state['revision'] == r['revision']
        assert hashlib.sha256(export_bytes(state)).hexdigest() == r[side + '_digests'][view]
        assert len(state['entries']) == r['hot_entry_count' if hot else 'entry_count']
        assert len(state['events']) == r['event_count']
        if hot:
            assert state.get('archive', {}).get('entries', 0) == r['archive_count']
print(json.dumps(r, indent=2))
PY
for unit in "${UNITS[@]}"; do
  checkout="${UNIT_CHECKOUT[$unit]:?missing deployed checkout for unit}"
  unit_python="${UNIT_PYTHON[$unit]:?missing deployed venv Python for unit}"
  test "${checkout:0:1}" = /
  test "${unit_python:0:1}" = /
  test -x "$unit_python"
  (cd -- "$checkout" && "$unit_python" -c 'import leafhft.broker.account_risk; assert "rows-v1" in leafhft.broker.account_risk.LEDGER_FORMATS; print(leafhft.broker.account_risk.__file__)') || { echo "Rows code check failed: $unit" >&2; exit 1; }
done
chown --reference="$SRC" "$DST"
chmod --reference="$SRC" "$DST"
test ! -e "${SRC}.body-backup-${TS}"
mv --no-clobber -- "$SRC" "${SRC}.body-backup-${TS}"
test ! -e "$SRC"
mv --no-clobber -- "$DST" "$SRC"
test ! -e "$DST"
python -c 'import sys; from leafhft.broker.account_risk_rows import ledger_format; assert ledger_format(sys.argv[1]) == "rows"' "$SRC"
sync -f "$(dirname "$SRC")"
systemctl start "${UNITS[@]}"
```

Use the kit's normal containment/readiness and re-arm readbacks for every book.
Then audit the principal ledger through `read_ledger(SRC, expected_account_id)`:
require `status=ok`, `healthy=true`, the receipt's account identity, format `rows`
and revision at least the receipt revision. Confirm fresh book status and no
new ledger refusal signals. Retain the body backup and receipt with the kit.
If either rename fails, keep everything stopped and reconcile the named files
before any start. Re-enable paused automation only after successful readback.

## Rollback after rows has accepted writes

Any code rollback to a release before the rows cutover requires `to-body` FIRST,
using the compatible release's converter before installing the older code. A
missed `to-body` now fails closed: every rows file carries the poisoned legacy
slot, whether converted or created by live code under
`LEAFHFT_LEDGER_NEW_FORMAT=rows`. Older code refuses any of these files with
`ledger_corrupt` rather than trading on an empty ledger.

Obtain the operator's yes for rollback and repeat the same all-writers stop and
checkpoint steps in an approved gap. Do not put the old body backup back into
service: it omits trades accepted after cutover. Set a fresh sibling destination:

```bash
TS=$(date -u +%Y%m%dT%H%M%SZ)
export DST="${SRC}.body-${TS}"
python -m leafhft.broker.account_risk_migrate to-body "$SRC" "$DST"
```

Run the identical receipt-verification block above. `to-body` reads the latest
rows state, preserves archive state and revision, and refuses a body SRC. Copy
owner/mode as above; rename SRC to `${SRC}.rows-backup-${TS}`, rename DST into
SRC, require `test ! -e "$DST"` and verify `ledger_format(SRC) == "body"`
with the compatible Python, then sync the directory. Only then install the
older release if needed. The forward rows-capability loop applies to a rows
start; a pre-cutover release may start only after the body conversion and swap
have been verified. Start all books through the seat kit, read back
`status=ok`, `healthy=true`, format `body`, the same principal and a revision at
least the rollback receipt's revision. Keep both backups and both receipts.
