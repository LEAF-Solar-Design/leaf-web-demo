#!/usr/bin/env bash
# Trusted relay materializes accepted paper summaries for the existing pusher.
set -euo pipefail
umask 077
: "${SHADOW_BUCKET:?set SHADOW_BUCKET}"
: "${SHADOW_TABLE:?set SHADOW_TABLE}"
: "${SHADOW_FLEET:?set SHADOW_FLEET}"
: "${SHADOW_RELAY_DIR:?set SHADOW_RELAY_DIR}"
: "${AWS_REGION:?set AWS_REGION}"
# Destinations are part of the runner isolation contract, not caller options.
[[ "$SHADOW_RELAY_DIR" == /var/lib/leafhft/shadow/accepted ]] || exit 2
for argument in "$@"; do
  case "$argument" in
    --out*|--paper*) echo 'relay destinations are fixed' >&2; exit 2 ;;
  esac
done
exec "${PYTHON:-python3}" -m scripts.kalshi_shadow_aws relay \
  --region "$AWS_REGION" --bucket "$SHADOW_BUCKET" --table "$SHADOW_TABLE" \
  --fleet "$SHADOW_FLEET" \
  --out-dir /var/lib/leafhft/shadow/accepted \
  --paper-results-dir /var/lib/leafhft/paper-results "$@"
