#!/bin/bash
# Offline native lane accounts. Inputs are host-owned, outputs are shadow-only.
set -euo pipefail
py="${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}"
scripts_dir="${LEAFHFT_SCRIPTS:-/opt/leafhft/scripts}"
shadow="${LEAFHFT_SHADOW_DIR:-/var/lib/leafhft/shadow}"
engines="${LEAFHFT_ENGINES_DIR:-/etc/leafhft/engines}"
lanes="${LEAFHFT_LANES_DIR:-/etc/leafhft/lanes}"
darkhorse="${LEAFHFT_DARKHORSE_CONFIG:-/etc/leafhft/darkhorse.json}"
results="${LEAFHFT_SHADOW_RESULTS_DIR:-$shadow/results}"
exec "$py" "$scripts_dir/kalshi_shadow_lane_host.py" \
  --spool-dir "$shadow" --engines-dir "$engines" --lanes-dir "$lanes" \
  --darkhorse-config "$darkhorse" --manifest "$shadow/lane-manifest.json" \
  --out-dir "$results/lane-cohort" --managed --follow
