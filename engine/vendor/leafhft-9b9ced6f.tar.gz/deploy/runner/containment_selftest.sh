#!/usr/bin/env bash
# Exercise the real runner preflight in a disposable tree, never a rollout.
set -euo pipefail

fail() {
  printf 'containment selftest: FAIL (%s)\n' "$*" >&2
  exit 1
}
trap 'fail "local setup failed at line $LINENO"' ERR

[[ $# -eq 0 ]] || fail 'usage: bash deploy/runner/containment_selftest.sh'
runner_dir=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
source_file=$runner_dir/rollout.sh
[[ -f "$source_file" && -r "$source_file" ]] || fail 'sibling rollout.sh is missing or unreadable'

marker_anchor='ROLLOUT_CONTAINMENT=/var/lib/leafhft/CONTAINMENT'
root_anchor="[[ \$EUID -eq 0 ]] || fail 'rollout.sh must run as root'"
preflight_anchor='containment=$(rollout_containment_refusal "$ROLLOUT_CONTAINMENT") || fail "$containment"'
marker_count=0; root_count=0; preflight_count=0
marker_line=0; root_line=0; preflight_line=0
source_lines=()
# Normalize checkout CRLF to shell LF without changing the logical source lines.
# Validate and copy the same snapshot, including anchors beyond the copied prefix.
while IFS= read -r line || [[ -n "$line" ]]; do
  line=${line%$'\r'}
  source_lines+=("$line")
  case "$line" in
    "$marker_anchor") marker_count=$((marker_count + 1)); marker_line=${#source_lines[@]} ;;
    "$root_anchor") root_count=$((root_count + 1)); root_line=${#source_lines[@]} ;;
    "$preflight_anchor") preflight_count=$((preflight_count + 1)); preflight_line=${#source_lines[@]} ;;
  esac
done < "$source_file"
[[ $marker_count -eq 1 ]] || fail "marker assignment anchor count=$marker_count, expected 1"
[[ $root_count -eq 1 ]] || fail "root check anchor count=$root_count, expected 1"
[[ $preflight_count -eq 1 ]] || fail "preflight anchor count=$preflight_count, expected 1"
[[ $marker_line -lt $preflight_line && $root_line -lt $preflight_line ]] || fail 'anchors are outside the preflight prefix'

scratch_parent=$(CDPATH= cd -- "${TMPDIR:-/tmp}" && pwd -P)
scratch_prefix=${scratch_parent%/}/containment-selftest.
scratch=''
cleanup() {
  local result=$? leaf
  trap - EXIT INT TERM ERR
  # Only the single directory returned by our mktemp call is eligible for removal.
  leaf=${scratch#"$scratch_prefix"}
  if [[ -n "$scratch" && "$scratch" == "$scratch_prefix"* && -n "$leaf" && "$leaf" != */* && -d "$scratch" && ! -L "$scratch" ]]; then
    if ! rm -rf -- "$scratch"; then
      printf 'containment selftest: FAIL (scratch cleanup failed)\n' >&2
      exit 1
    fi
  fi
  if [[ $result -eq 0 ]]; then
    printf 'containment selftest: PASS (isolated preflight, exit=2)\n'
  fi
  exit "$result"
}
umask 077
scratch=$(mktemp -d -- "${scratch_prefix}XXXXXXXXXX") || fail 'cannot create private scratch directory'
trap cleanup EXIT
trap 'fail "interrupted"' INT TERM
scratch_leaf=${scratch#"$scratch_prefix"}
[[ -n "$scratch" && "$scratch" == "$scratch_prefix"* && -n "$scratch_leaf" && "$scratch_leaf" != */* && -d "$scratch" && ! -L "$scratch" ]] || fail 'invalid scratch directory'

mkdir -p -- "$scratch/deploy/runner"
marker=$scratch/CONTAINMENT
printf '' > "$marker"
copy=$scratch/deploy/runner/rollout.sh
{
  for ((index=0; index<preflight_line; index++)); do
    line=${source_lines[index]}
    case "$line" in
      "$marker_anchor") printf 'ROLLOUT_CONTAINMENT=%q\n' "$marker" ;;
      "$root_anchor") printf ':\n' ;;
      *) printf '%s\n' "$line" ;;
    esac
  done
  printf 'exit 97\n'
} > "$copy"

if syntax_output=$("$BASH" -n "$copy" 2>&1); then
  :
else
  fail "copied preflight syntax rejected: ${syntax_output:0:600}"
fi
if output=$(REARM_REFUSAL_WAIT_S=90 "$BASH" "$copy" 0000000000000000000000000000000000000000 --dry-run 2>&1); then
  child_status=0
else
  child_status=$?
fi
expected="CONTAINMENT: $marker exists; no override lifts it"
matched=0
while IFS= read -r line || [[ -n "$line" ]]; do
  if [[ "$line" == "$expected" ]]; then matched=1; fi
done <<< "$output"
[[ $child_status -eq 2 && $matched -eq 1 ]] || fail "isolated preflight exit=$child_status, expected containment refusal and exit=2; output: ${output:0:600}"
exit 0
