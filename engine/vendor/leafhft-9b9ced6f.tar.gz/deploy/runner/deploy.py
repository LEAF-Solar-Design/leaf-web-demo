#!/usr/bin/env python3
"""leafhft deploy <sha>: the one deploy and re-arm verb over deploy.sh and rollout.sh.

Contract (fails closed, pre-deploy refusals exit 2; partial_deploy_refused exits 5
when a registry check refuses after a command ran):
  * decision: digest_may_move for the named units (deploy.sh:142-158 proof files, read from
    deploy.sh itself). Unchanged digest runs `deploy.sh <sha> --restart-unchanged`, which restarts
    exactly the live fleet (deploy.sh:201-231), so --units must name every live unit or be
    omitted. A moving digest runs `deploy.sh <sha>` (no restarts), then
    `rollout.sh <sha> --units <named>`, which stops, starts and re-acks one book per gap.
  * refuses under /var/lib/leafhft/CONTAINMENT (never overridable), on an unreadable
    `leafhft deployed --json`, on a sha that is not the checked-out head of /opt/leafhft, on a
    drifted or sha-less live fleet, on an unprovable digest, and (restart-unchanged only) when a
    unit's ack has used its LEAFHFT_ACK_MAX_STARTS starts.
  * refuses every target whose own registry decoder or store cannot read the live registry;
    no override permits a rollback that could silently replace tighter loss breakers.
    The writers' lock covers only each compatibility check, never a deploy or rollout command.
    A registry change between the last boundary recheck and the next command start is caught
    at the next boundary, and an older reader facing a registry past its limits refuses probes
    at registry_gate.
  * refuses, unless --window-override records a reason, when now..projected end touches the
    23:35-00:25Z blackout or the 02:30-03:30Z pre-cliff window, or when now sits outside the
    [60, 420] s settlement gap of the 900 s cycle. The clock is read AFTER the preflight reads
    and again immediately before every command; on a subset the gap and the blackout are
    re-checked on a fresh clock after every read and receipt write, immediately before each stop:
    by rollout.sh before its own stop, and by rearm.py's apply path before the re-arm's stop
    (--window-override is passed through to both). Fourteen units keep the pre-L16a rollout.sh
    sequence byte for byte, so the projection checked here is their only time guard.
  * a subset rollout (--units short of every deployed unit) captures each unselected unit's
    identity (its sha when live, '-' when not) and `systemctl is-active` state before any
    mutation, passes the identities to rollout.sh as --expect-unselected, runs both commands with
    LEAFHFT_INSTALL_LIVE_ONLY=<selected instances> so install-units.sh starts no unselected book,
    fails before rollout.sh when an unselected active state moved during install, and re-reads
    `leafhft deployed --json` afterwards to hold every unit to its expected identity.
  * prints every command before running it; writes the SHA-stamped receipt
    /var/lib/leafhft/deploy-receipts/<utc>-<sha12>.json before the first command and rewrites it
    atomically after each; --dry-run prints the decision and commands and writes nothing.
"""
from __future__ import annotations

import argparse
from collections import deque
from contextlib import contextmanager, ExitStack
import datetime as dt
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile
import tempfile
import threading
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from leafhft.broker.live_gate import LEAFHFT_ACK_MAX_STARTS as ACK_MAX_STARTS  # noqa: E402


def _load_rearm():
    # Loaded by path so deploy/runner never lands on sys.path (a bare `deploy` module there
    # would shadow the repo's deploy/ namespace for every later import).
    spec = importlib.util.spec_from_file_location("leafhft_runner_rearm", HERE / "rearm.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_REARM = _load_rearm()
ACK_DIR = _REARM.ACK_DIR  # the one ack directory rearm.py writes and the gate reads
ARMS_JOURNAL = ACK_DIR / "arms.jsonl"
REPO = Path("/opt/leafhft")
DEPLOY_SH = HERE / "deploy.sh"
CONTAINMENT = Path("/var/lib/leafhft/CONTAINMENT")
LIVE_REGISTRY = Path("/var/lib/leafhft/engine-registry/assignments.json")
REGISTRY_CHECK_TIMEOUT_S = 30
REGISTRY_LOCK_TIMEOUT_S = 5.0
MAX_REGISTRY_CHECK_OUTPUT_BYTES = 64 * 1024
MAX_REGISTRY_PACKAGE_BYTES = 64 * 1024 * 1024
MAX_REGISTRY_PACKAGE_FILES = 4096
RECEIPT_DIR = Path("/var/lib/leafhft/deploy-receipts")
SCHEMA = "leafhft.deploy-wrapper.v1"

RESTART_UNCHANGED = "restart-unchanged"
ROLLOUT = "rollout"
DAY_S = 86_400
# (name, start, end) in seconds after 00:00Z; the blackout runs past midnight.
# The blackout and the gap are rearm.py's, whose guard runs immediately before a re-arm stop.
WINDOWS = (
    ("23:35-00:25Z blackout", _REARM.BLACKOUT_START_S, DAY_S + _REARM.BLACKOUT_END_S),
    ("02:30-03:30Z pre-cliff", 2 * 3600 + 30 * 60, 3 * 3600 + 30 * 60),
)
GAP_CYCLE_S = _REARM.GAP_CYCLE_S
GAP_MIN_S, GAP_MAX_S = _REARM.GAP_MIN_S, _REARM.GAP_MAX_S
# Projection bounds (estimates, not measurements): one deploy.sh pass, one settlement cycle per
# rollout book, one restart plus deploy.sh's 20 s settle per restart-unchanged unit.
DEPLOY_ESTIMATE_S = 600
ROLLOUT_UNIT_ESTIMATE_S = GAP_CYCLE_S
RESTART_UNIT_ESTIMATE_S = 30

UNIT = re.compile(r"leafhft-live@[A-Za-z0-9_-]+\.service")
ACTIVE_STATE = re.compile(r"[a-z-]{1,32}")
INSTALL_SUBSET_ENV = "LEAFHFT_INSTALL_LIVE_ONLY"  # install-units.sh starts only these instances
SHA = re.compile(r"[0-9a-f]{40}")
DIGEST = re.compile(r"[0-9a-f]{64}")
HANDLE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.@-]{0,63}")
REFERENCE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:@/-]{0,127}")
MAX_UNITS = 64
MAX_REASON_CHARS = 300
MAX_JSON_BYTES = 1024 * 1024
ARMS_READ_BYTES = 64 * 1024  # the live gate reads the same bounded tail (live_gate._record_arm)
TAIL_LINES = 200
TAIL_LINE_CHARS = 4096
READ_TIMEOUT_S = 60


class Refused(Exception):
    """A named refusal; exit 2 before commands, 5 for a mid-deploy registry refusal."""


def _now() -> float:
    return time.time()


def _iso(epoch: float) -> str:
    return dt.datetime.fromtimestamp(epoch, dt.timezone.utc).isoformat().replace("+00:00", "Z")


def _read(argv: list[str], timeout: float) -> tuple[int, str]:
    """One read-only command, time bounded; stdout is capped (a cut JSON fails to parse)."""
    env = dict(os.environ)
    env["PATH"] = (REPO / ".venv/bin").as_posix() + os.pathsep + env.get("PATH", "")
    completed = subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                               env=env, check=False)
    return completed.returncode, completed.stdout[:MAX_JSON_BYTES]


def _execute(argv: list[str], environment: dict[str, str] | None = None) -> tuple[int, list[str]]:
    """Run one mutating command in REPO, streaming output and keeping a bounded tail.

    `environment` adds to the inherited environment (the subset install variable); empty inherits
    it unchanged. No wall-clock kill: killing rollout.sh mid-book strands a stopped book, and both
    children bound every step themselves (deploy.sh timeouts, rollout.sh's 1200 s window cap).
    """
    env = {**os.environ, **environment} if environment else None
    tail: deque[str] = deque(maxlen=TAIL_LINES)
    with subprocess.Popen(argv, cwd=REPO, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          text=True, errors="replace") as proc:
        for line in proc.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()
            tail.append(line.rstrip("\r\n")[:TAIL_LINE_CHARS])
        code = proc.wait()
    return code, list(tail)


def check_containment() -> None:
    try:
        os.lstat(CONTAINMENT)
    except FileNotFoundError:
        return
    except OSError as exc:
        raise Refused(f"CONTAINMENT marker unreadable ({type(exc).__name__}); treated as contained")
    raise Refused(f"CONTAINMENT: {CONTAINMENT.as_posix()} exists; no override lifts it")


# The target package is imported only in this child, never into the deploy process. Store.load
# can repair publication, so even its read check runs against a private snapshot, not live files.
_REGISTRY_CHECK = r'''
import importlib.machinery
import json
from pathlib import Path
import sys

try:
    package, live, snapshot = map(Path, sys.argv[1:])
    # -I ignores PYTHONPATH. Admit only the private target package explicitly.
    sys.path.insert(0, str(package))
    # -I still loads site-packages, including editable-install import hooks. Resolve every
    # leafhft import from the archive and refuse missing siblings before those hooks run.
    class TargetPackageFinder:
        def find_spec(self, fullname, path=None, target=None):
            if fullname == "leafhft" or fullname.startswith("leafhft."):
                parent = package.joinpath(*fullname.split(".")[:-1])
                spec = importlib.machinery.PathFinder.find_spec(fullname, [str(parent)])
                if spec is None:
                    raise ModuleNotFoundError(fullname)
                return spec
            return None
    sys.meta_path.insert(0, TargetPackageFinder())
    for name in list(sys.modules):
        if name == "leafhft" or name.startswith("leafhft."):
            del sys.modules[name]
    from leafhft import engine_registry as registry
    cap = registry.MAX_REGISTRY_BYTES
    if type(cap) is not int or cap <= 0:
        raise ValueError("invalid target byte cap")
    with live.open("rb") as stream:
        data = stream.read(cap + 1)
    registry.validate_document(registry.strict_loads(data, cap))
    snapshot.mkdir()
    (snapshot / registry.REGISTRY_FILE).write_bytes(data)
    # A journal may exceed its rotation threshold by the final appended row. Copy both
    # bounded files so the target also proves it can load the committed generation's anchor.
    journal_cap = registry.JOURNAL_ROTATE_BYTES + registry.MAX_JOURNAL_ROW_BYTES
    for name in (registry.JOURNAL_FILE, registry.JOURNAL_FILE + ".1"):
        try:
            with (live.parent / name).open("rb") as stream:
                journal = stream.read(journal_cap + 1)
        except FileNotFoundError:
            continue
        if len(journal) > journal_cap:
            raise registry.RegistryError("journal_too_large")
        (snapshot / name).write_bytes(journal)
    loaded = registry.RegistryStore(snapshot).load(complete_publication=False)
    if loaded is None:
        raise ValueError("target store did not load registry")
except Exception as exc:
    print(json.dumps({"error": getattr(exc, "code", type(exc).__name__)}))
    sys.exit(1)
print(json.dumps({"ok": True, "generation": loaded.generation, "digest": loaded.digest}))
'''


@contextmanager
def registry_activation_lock():
    """Use the writers' lock only while checking compatibility at a command boundary."""
    with ExitStack() as stack:
        from leafhft.engine_registry import RegistryStore

        store = RegistryStore(LIVE_REGISTRY.parent, lock_timeout_s=REGISTRY_LOCK_TIMEOUT_S)
        try:
            stack.enter_context(store._lock())
        except TimeoutError as exc:
            raise Refused("registry_lock_timeout") from exc
        except OSError as exc:
            raise Refused("registry_lock_failed: " + type(exc).__name__) from exc
        yield store


def _registry_check_child(argv: list[str], private: Path) -> subprocess.CompletedProcess:
    """Drain both pipes concurrently, retaining at most 64 KiB each, even for noisy imports.

    Keep subprocess.run's timeout/kill/reap semantics. Reader threads discard excess bytes;
    no unbounded communicate() buffer or temporary output file is involved.
    """
    buffers = [bytearray(), bytearray()]
    oversized = threading.Event()
    errors = []
    readers = []
    marker = b"\n[truncated]\n"

    def drain(fd, output):
        try:
            with os.fdopen(fd, "rb", buffering=0) as stream:
                while chunk := stream.read(8192):
                    room = MAX_REGISTRY_CHECK_OUTPUT_BYTES - len(output)
                    output.extend(chunk[:room])
                    if len(chunk) > room:
                        oversized.set()
        except OSError as exc:
            errors.append(exc)

    with ExitStack() as stack:
        writers = []
        for output in buffers:
            read_fd, write_fd = os.pipe()
            writer = stack.enter_context(os.fdopen(write_fd, "wb", buffering=0))
            writers.append(writer)
            thread = threading.Thread(target=drain, args=(read_fd, output), daemon=True)
            thread.start()
            readers.append(thread)
        try:
            completed = subprocess.run(
                argv, cwd=private, env={**os.environ, "PYTHONPATH": str(private)},
                stdout=writers[0], stderr=writers[1],
                timeout=REGISTRY_CHECK_TIMEOUT_S, check=False)
        finally:
            for writer in writers:
                writer.close()
            for thread in readers:
                thread.join(timeout=REGISTRY_CHECK_TIMEOUT_S)
    if any(thread.is_alive() for thread in readers) or errors:
        raise Refused("target_cannot_read_live_registry: output_unreadable")
    if oversized.is_set():
        for output in buffers:
            if len(output) == MAX_REGISTRY_CHECK_OUTPUT_BYTES:
                output[-len(marker):] = marker
        raise Refused("target_cannot_read_live_registry: output_too_large [truncated]")
    # subprocess.run normally leaves these None when given file descriptors.
    if completed.stdout is None:
        completed.stdout = buffers[0].decode("utf-8", errors="replace")
    if completed.stderr is None:
        completed.stderr = buffers[1].decode("utf-8", errors="replace")
    return completed


def recheck_target_registry(sha: str, store, checked: dict | None) -> dict | None:
    """Revalidate under the held lock; None records an absent registry at the check."""
    try:
        current = store.load(complete_publication=False)
        identity = ({"generation": current.generation, "digest": current.digest}
                    if current is not None else None)
        if identity is None:
            if checked is None:
                return None
            raise Refused("target_cannot_read_live_registry: registry_missing")
        if identity != checked:
            checked = check_target_registry(sha)
            if checked != identity:
                raise Refused("target_cannot_read_live_registry: registry_changed")
        return checked
    except Refused:
        raise
    except Exception as exc:
        raise Refused("target_cannot_read_live_registry: " + type(exc).__name__) from exc


def _target_registry_archive(sha: str) -> bytes:
    """Read one uncompressed target archive, bounded in bytes and wall time."""
    with subprocess.Popen(["git", "-C", REPO.as_posix(), "archive", "--format=tar", sha,
                           "leafhft"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL) as proc:
        expired = threading.Event()

        def expire():
            expired.set()
            proc.kill()

        timer = threading.Timer(REGISTRY_CHECK_TIMEOUT_S, expire)
        timer.daemon = True
        timer.start()
        try:
            data = proc.stdout.read(MAX_REGISTRY_PACKAGE_BYTES + 1)
            if len(data) > MAX_REGISTRY_PACKAGE_BYTES:
                raise ValueError("target package exceeds byte cap")
            code = proc.wait(timeout=REGISTRY_CHECK_TIMEOUT_S)
            if expired.is_set():
                raise TimeoutError("target package archive timed out")
            if code != 0 or not data:
                raise ValueError("target package archive unreadable")
            return data
        finally:
            timer.cancel()
            if proc.poll() is None:
                proc.kill()
            proc.wait()


def _extract_registry_package(data: bytes, private: Path) -> None:
    """Extract regular target files only, with no links or paths outside leafhft."""
    if len(data) > MAX_REGISTRY_PACKAGE_BYTES:
        raise ValueError("target package exceeds byte cap")
    size = 0
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:") as archive:
        for count, member in enumerate(archive, 1):
            parts = member.name.rstrip("/").split("/")
            if (count > MAX_REGISTRY_PACKAGE_FILES or parts[0] != "leafhft"
                    or any(part in ("", ".", "..") or "\\" in part or ":" in part for part in parts)
                    or not (member.isdir() or member.isfile())):
                raise ValueError("invalid target package member")
            destination = private.joinpath(*parts)
            if member.isdir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            size += member.size
            if member.size < 0 or size > MAX_REGISTRY_PACKAGE_BYTES:
                raise ValueError("target package exceeds byte cap")
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.extractfile(member) as stream:
                destination.write_bytes(stream.read(member.size))
    if not (private / "leafhft/__init__.py").is_file():
        raise ValueError("target package missing __init__.py")


def check_target_registry(sha: str) -> dict | None:
    """Every target, including rollback: its own strict reader must accept the live registry.

    No override. Git archives the target package; one isolated, time-bounded Python child checks it.
    All leafhft dependencies come from that archive, never the current checkout. A missing or
    incompatible target reader fails closed. No live files or checkout state are written.
    """
    remedy = "; release assignments until the registry fits the target's limits, then deploy"
    try:
        try:
            os.lstat(LIVE_REGISTRY)
        except FileNotFoundError:
            return
        if not SHA.fullmatch(sha):
            raise ValueError("invalid target sha")
        with tempfile.TemporaryDirectory(prefix="leafhft-registry-check-") as directory:
            private = Path(directory)
            _extract_registry_package(_target_registry_archive(sha), private)
            completed = _registry_check_child(
                [sys.executable, "-I", "-B", "-c", _REGISTRY_CHECK, str(private),
                 str(LIVE_REGISTRY.resolve()), str(private / "registry")],
                private)
            result = json.loads(completed.stdout)
            if (completed.returncode == 0 and isinstance(result, dict) and result.get("ok") is True
                    and type(result.get("generation")) is int and result["generation"] > 0
                    and isinstance(result.get("digest"), str) and DIGEST.fullmatch(result["digest"])):
                return {"generation": result["generation"], "digest": result["digest"]}
            reason = result.get("error") if isinstance(result, dict) else None
            if not isinstance(reason, str) or not re.fullmatch(r"[A-Za-z0-9_]{1,80}", reason):
                reason = "guard_failed"
            raise Refused("target_cannot_read_live_registry: " + reason + remedy)
    except Refused:
        raise
    except Exception as exc:
        raise Refused(f"target_cannot_read_live_registry: {type(exc).__name__}" + remedy) from exc


def read_head() -> str:
    try:
        code, out = _read(["git", "-C", REPO.as_posix(), "rev-parse", "HEAD"], 30)
    except (OSError, subprocess.SubprocessError) as exc:
        raise Refused(f"checked-out head of {REPO.as_posix()} unreadable ({type(exc).__name__})")
    head = out.strip().lower()
    if code != 0 or not SHA.fullmatch(head):
        raise Refused(f"checked-out head of {REPO.as_posix()} unreadable (git exited {code})")
    return head


def read_deployed() -> dict[str, dict]:
    """Rows of `leafhft deployed --json` keyed by unit; anything malformed refuses."""
    try:
        code, out = _read(["leafhft", "deployed", "--json"], READ_TIMEOUT_S)
    except (OSError, subprocess.SubprocessError) as exc:
        raise Refused(f"deployed state unreadable: {type(exc).__name__}")
    if code not in (0, 1, 2):
        raise Refused(f"deployed state unreadable: leafhft deployed --json exited {code}")
    try:
        report = json.loads(out)
    except ValueError:
        raise Refused("deployed state unreadable: output is not JSON")
    if (not isinstance(report, dict) or not isinstance(report.get("rows"), list)
            or report.get("verdict") not in ("IN_SYNC", "DRIFTED", "DEGRADED")):
        raise Refused("deployed state unreadable: no verdict and rows")
    rows: dict[str, dict] = {}
    for row in report["rows"]:
        unit = row.get("unit") if isinstance(row, dict) else None
        if (not isinstance(unit, str) or not UNIT.fullmatch(unit.strip())
                or type(row.get("live")) is not bool):
            raise Refused("deployed state unreadable: malformed row")
        if unit.strip() in rows:
            raise Refused(f"deployed state unreadable: duplicate row {unit.strip()}")
        rows[unit.strip()] = row
    return rows


def identity(row: dict) -> str:
    """A unit's identity as rollout.sh --expect-unselected spells it: the full running sha when
    live, '-' when not live, 'unknown' when live without a full sha (matches nothing)."""
    if row.get("live") is not True:
        return "-"
    value = row.get("git_sha")
    value = value.strip() if isinstance(value, str) else ""
    return value if SHA.fullmatch(value) else "unknown"


def expected_identities(rows: dict[str, dict], units: list[str], sha: str) -> dict[str, str]:
    """Per-unit expectation after a rollout: every named unit live on the target, every other
    deployed unit exactly as captured before any mutation."""
    selected = set(units)
    return {unit: sha if unit in selected else identity(rows[unit]) for unit in sorted(rows)}


def instance_name(unit: str) -> str:
    return unit.removeprefix("leafhft-live@").removesuffix(".service")


def read_active_states(units: list[str]) -> dict[str, str]:
    """`systemctl is-active` for every unit in one bounded read: one state per line, in order.

    The exit code is ignored (3 for an inactive unit); anything but one state per unit refuses.
    """
    if not units:
        return {}
    try:
        _code, out = _read(["systemctl", "is-active", *units], 30)
    except (OSError, subprocess.SubprocessError) as exc:
        raise Refused(f"unit active state unreadable ({type(exc).__name__})")
    states = [line.strip() for line in out.splitlines()]
    if len(states) != len(units) or any(not ACTIVE_STATE.fullmatch(state) for state in states):
        raise Refused("unit active state unreadable: systemctl is-active gave no state per unit")
    return dict(zip(units, states))


def parse_units(text: str | None) -> list[str]:
    if not text:
        return []
    units = [part.strip() for part in text.split(",")]
    if (len(units) > MAX_UNITS or len(set(units)) != len(units)
            or any(not UNIT.fullmatch(unit) for unit in units)):
        raise Refused("invalid --units: comma-separated, unique, full leafhft-live@<book>.service names")
    return units


def digest_proof_files() -> list[str]:
    """DIGEST_PROOF_FILES exactly as deploy.sh declares it; never a copy."""
    try:
        source = DEPLOY_SH.read_text(encoding="utf-8")
    except OSError as exc:
        raise Refused(f"digest proof list unreadable ({type(exc).__name__})")
    declaration = "DIGEST_PROOF_FILES=("
    if source.count(declaration) != 1:
        raise Refused("digest proof list unreadable: deploy.sh must declare it once")
    files = shlex.split(source.split(declaration, 1)[1].split(")", 1)[0])
    if not files:
        raise Refused("digest proof list is empty")
    return files


def digest_moved_files(running: str, target: str, files: list[str]) -> list[str]:
    try:
        code, out = _read(["git", "-C", REPO.as_posix(), "diff", "--name-only",
                           running, target, "--", *files], 30)
    except (OSError, subprocess.SubprocessError) as exc:
        raise Refused(f"digest proof unavailable ({type(exc).__name__})")
    if code != 0:
        raise Refused(f"digest proof unavailable: git diff {running[:12]} {target[:12]} exited {code}")
    return sorted({line.strip() for line in out.splitlines()} & set(files))


def arms_starts(journal: Path) -> tuple[dict[str, int], bool]:
    """Starts per config digest from the bounded tail the live gate itself reads."""
    try:
        with journal.open("rb") as stream:
            size = stream.seek(0, os.SEEK_END)
            stream.seek(max(0, size - ARMS_READ_BYTES))
            data = stream.read(ARMS_READ_BYTES)
    except FileNotFoundError:
        return {}, False
    except OSError as exc:
        raise Refused(f"arms journal unreadable ({type(exc).__name__})")
    truncated = size > ARMS_READ_BYTES
    if truncated:
        data = data.partition(b"\n")[2]
    counts: dict[str, int] = {}
    starts: dict[str, int] = {}
    try:
        for line in data.splitlines():
            row = json.loads(line)
            digest = row["digest"]
            counts[digest] = counts.get(digest, 0) + 1
            starts[digest] = max(starts.get(digest, 0), counts[digest], int(row.get("starts", 0)))
    except (ValueError, KeyError, TypeError, AttributeError):
        raise Refused("arms journal unreadable: malformed row")
    return starts, truncated


def commands_for(path: str, sha: str, units: list[str], predecessors: dict[str, str] | None = None,
                 override: str | None = None) -> list[list[str]]:
    deploy = ["bash", (REPO / "deploy/runner/deploy.sh").as_posix(), sha]
    if path == RESTART_UNCHANGED:
        return [deploy + ["--restart-unchanged"]]
    rollout = ["bash", (REPO / "deploy/runner/rollout.sh").as_posix(), sha, "--units", ",".join(units)]
    if predecessors:
        rollout += ["--expect-unselected", ",".join(f"{unit}={value}" for unit, value in predecessors.items())]
    if override is not None:
        rollout += ["--window-override", override]
    return [deploy, rollout]


def decide(sha: str, requested: list[str], override: str | None = None) -> dict:
    """Every hard guard, then the path; raises Refused before anything could run."""
    check_containment()
    head = read_head()
    if head != sha:
        raise Refused(f"{sha} is not the checked-out head of {REPO.as_posix()} ({head})")
    rows = read_deployed()
    live = sorted(unit for unit, row in rows.items() if row["live"])
    units = requested or live
    if not units:
        raise Refused("no live units and no --units named")
    unknown = [unit for unit in units if unit not in rows]
    if unknown:
        raise Refused("unit not in deployed state: " + ", ".join(unknown))
    # deploy.sh runs on both paths and refuses a sha-less or drifted live fleet without
    # --force-degraded, which this verb never passes; refuse the same way before touching it.
    live_shas = set()
    for unit in live:
        value = rows[unit].get("git_sha")
        value = value.strip() if isinstance(value, str) else ""
        if not value:
            raise Refused(f"DEGRADED: live unit {unit} reports no sha; deploy.sh would need --force-degraded")
        if not SHA.fullmatch(value):
            raise Refused(f"deployed state unreadable: live unit {unit} lacks a full sha")
        live_shas.add(value)
    if len(live_shas) > 1:
        raise Refused("DRIFTED: live units run " + ", ".join(sorted(s[:12] for s in live_shas)))
    if not live_shas:
        raise Refused("DEGRADED: no live unit; deploy.sh would need --force-degraded")
    running = {}
    for unit in units:
        value = rows[unit].get("git_sha")
        value = value.strip() if isinstance(value, str) else ""
        running[unit] = value if SHA.fullmatch(value) else None
    files = digest_proof_files()
    (fleet_sha,) = live_shas
    # fleet_moved is exactly what deploy.sh will prove; a non-live named unit's older sha
    # can only add to the moving side.
    fleet_moved = digest_moved_files(fleet_sha, sha, files)
    moved = set(fleet_moved)
    for source in sorted({s for s in running.values() if s} - live_shas):
        moved.update(digest_moved_files(source, sha, files))
    unproved = sorted(unit for unit, value in running.items() if value is None)
    digest_may_move = 1 if moved or unproved else 0
    path = ROLLOUT if digest_may_move else RESTART_UNCHANGED
    if path == RESTART_UNCHANGED:
        if set(units) != set(live):
            raise Refused("restart-unchanged restarts exactly the live fleet (deploy.sh:201-231); "
                          "--units must name every live unit or be omitted")
        starts, truncated = arms_starts(ARMS_JOURNAL)
        for unit in units:
            digest = rows[unit].get("config_digest")
            if not isinstance(digest, str) or not DIGEST.fullmatch(digest):
                raise Refused(f"{unit}: config digest unreadable; ack start budget unprovable")
            if truncated and digest not in starts:
                raise Refused(f"{unit}: ack history outside the bounded arms journal")
            if starts.get(digest, 0) >= ACK_MAX_STARTS:
                raise Refused(f"{unit}: ack used {starts[digest]} of {ACK_MAX_STARTS} starts; "
                              "a restart would close its gate")
    # A rollout short of every deployed unit is a subset: capture what the unselected units are
    # before anything mutates, so the install, rollout.sh and the re-read can hold them to it.
    unselected = sorted(set(rows) - set(units)) if path == ROLLOUT else []
    predecessors = {unit: identity(rows[unit]) for unit in unselected}
    return {"sha": sha, "units": units, "path": path, "digest_may_move": digest_may_move,
            "moved_files": sorted(moved), "fleet_moved_files": fleet_moved, "unproved_units": unproved,
            "running_shas": running, "subset": bool(unselected), "unselected": unselected,
            "predecessors": predecessors,
            "expected": expected_identities(rows, units, sha) if unselected else {},
            "environment": ({INSTALL_SUBSET_ENV: ",".join(instance_name(unit) for unit in units)}
                            if unselected else {}),
            "active_before": read_active_states(unselected),
            "commands": commands_for(path, sha, units, predecessors, override)}


def projected_seconds(path: str, count: int) -> int:
    if path == RESTART_UNCHANGED:
        return DEPLOY_ESTIMATE_S + count * RESTART_UNIT_ESTIMATE_S
    # rollout.sh runs deploy.sh again first (rollout.sh:400-405).
    return 2 * DEPLOY_ESTIMATE_S + count * ROLLOUT_UNIT_ESTIMATE_S


def window_refusals(now: float, path: str, count: int, *, remaining: int | None = None,
                    gap: bool = True) -> list[str]:
    """Named time refusals for now..projected end; empty means clear. At a later boundary
    `remaining` replaces the whole-run projection and `gap=False` skips the gap, which rollout.sh
    waits for and re-checks at every restart boundary itself."""
    seconds = projected_seconds(path, count) if remaining is None else remaining
    end = max(now + seconds, now + 1)
    reasons = []
    for name, begin, finish in WINDOWS:
        for day in range(int(now // DAY_S) - 1, int(end // DAY_S) + 1):
            start_s, end_s = day * DAY_S + begin, day * DAY_S + finish
            if now < end_s and end > start_s:
                reasons.append(f"inside or crossing the {name} window "
                               f"(now {_iso(now)}, projected end {_iso(end)})")
                break
    phase = int(now) % GAP_CYCLE_S
    if gap and not GAP_MIN_S <= phase <= GAP_MAX_S:
        reasons.append(f"outside the [{GAP_MIN_S}, {GAP_MAX_S}] s settlement gap "
                       f"(now {phase} s into the {GAP_CYCLE_S} s cycle)")
    return reasons


def boundary_refusals(now: float, decision: dict, index: int) -> list[str]:
    """Time refusals on a fresh clock immediately before command `index` mutates anything."""
    count = len(decision["units"])
    if index == 0:
        return window_refusals(now, decision["path"], count)
    # Before rollout.sh: its own deploy.sh pass plus one cycle per book must still clear both
    # windows; on a subset rollout.sh and rearm.py enforce the gap and the blackout immediately
    # before every stop (the re-arm included), and a fourteen-unit run relies on this projection alone.
    return window_refusals(now, decision["path"], count,
                           remaining=DEPLOY_ESTIMATE_S + count * ROLLOUT_UNIT_ESTIMATE_S, gap=False)


def _write_json(path: Path, obj: dict) -> None:
    fd, temporary = tempfile.mkstemp(prefix=".deploy-wrapper-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(obj, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def create_receipt(receipt: dict, now: float) -> Path:
    RECEIPT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.fromtimestamp(now, dt.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    path = RECEIPT_DIR / f"{stamp}-{receipt['sha'][:12]}.json"
    with path.open("x", encoding="utf-8") as stream:  # first writer wins, never overwrite
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    return path


def child_receipt(tail: list[str]) -> tuple[str | None, dict | None]:
    paths = [line.split("receipt: ", 1)[1].strip() for line in tail if line.startswith("receipt: ")]
    if not paths:
        return None, None
    try:
        with open(paths[-1], "rb") as stream:
            data = stream.read(MAX_JSON_BYTES + 1)
        obj = json.loads(data) if len(data) <= MAX_JSON_BYTES else None
    except (OSError, ValueError):
        obj = None
    return paths[-1], obj if isinstance(obj, dict) else None


def step_failure(decision: dict, index: int, code: int, child: dict | None) -> str | None:
    """None when this step proved what the next one needs; else the named failure."""
    argv = decision["commands"][index]
    if argv[1].endswith("rollout.sh"):
        if code == 0:
            return None
        # rollout.sh's receipt names what stopped it (a restart boundary, a book, a verifier).
        detail = child.get("error") if child else None
        return f"rollout.sh exited {code}" + (f": {detail}" if isinstance(detail, str) and detail else "")
    # deploy.sh's exit is the fleet verdict (0..2); its receipt says whether the deploy finished.
    if code > 2:
        return f"deploy.sh exited {code}"
    if (child is None or child.get("target_sha") != decision["sha"]
            or child.get("stage") != "finished" or child.get("stage_exit") != 0):
        return "deploy.sh receipt missing or not finished"
    expected = 1 if decision["fleet_moved_files"] else 0
    if child.get("digest_may_move") != expected:
        return (f"decision mismatch: deploy.sh proved digest_may_move={child.get('digest_may_move')}, "
                f"this verb expected {expected}; rerun the verb")
    if decision["path"] == RESTART_UNCHANGED:
        if code != 0 or child.get("units_left_on_old_code"):
            return (f"restart-unchanged incomplete (exit {code}, left on old code: "
                    f"{child.get('units_left_on_old_code')})")
    return None


def install_state_failure(decision: dict, receipt: dict) -> str | None:
    """After deploy.sh's install: every unselected unit keeps the active state captured before."""
    try:
        after = read_active_states(decision["unselected"])
    except Refused as exc:
        return f"{exc}; refusing before any restart"
    receipt["unselected_active_after_install"] = after
    changed = [f"{unit} {decision['active_before'][unit]} -> {after[unit]}"
               for unit in decision["unselected"] if after[unit] != decision["active_before"][unit]]
    if changed:
        return ("unselected unit active state changed during install: " + ", ".join(changed)
                + "; refusing before any restart")
    return None


def identity_failure(decision: dict, receipt: dict) -> str | None:
    """After the rollout: re-read the deployed state; named units on the target, every other
    unit exactly as captured before any mutation."""
    try:
        rows = read_deployed()
    except Refused as exc:
        return f"post-deploy identity read: {exc}"
    observed = {unit: identity(rows[unit]) if unit in rows else "absent" for unit in decision["expected"]}
    receipt["deployed_after"] = observed
    differ = [f"{unit} expected {want[:12]}, found {observed[unit][:12]}"
              for unit, want in decision["expected"].items() if observed[unit] != want]
    if differ:
        return "post-deploy identities differ: " + "; ".join(differ)
    return None


def parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="leafhft deploy", description=__doc__.splitlines()[0])
    parser.add_argument("sha", help="40-hex target sha; must be the checked-out head of /opt/leafhft")
    parser.add_argument("--units", help="comma-separated leafhft-live@<book>.service; default all live")
    parser.add_argument("--dry-run", action="store_true", help="print decision and commands, write nothing")
    parser.add_argument("--window-override", metavar="REASON",
                        help="run inside a time window; recorded in the receipt; never lifts CONTAINMENT")
    parser.add_argument("--approved-by", required=True, help="operator handle that approved this deploy")
    parser.add_argument("--approval-ref", help="operator receipt id for the approval")
    return parser.parse_args(argv)


def validate(args: argparse.Namespace) -> tuple[str, list[str], str | None]:
    sha = args.sha.strip().lower()
    if not SHA.fullmatch(sha):
        raise Refused("target must be a full 40-hex commit sha")
    if not HANDLE.fullmatch(args.approved_by):
        raise Refused("--approved-by must be a handle of letters, digits and _.@- (max 64)")
    if args.approval_ref is not None and not REFERENCE.fullmatch(args.approval_ref):
        raise Refused("--approval-ref must be letters, digits and _.:@/- (max 128)")
    override = args.window_override
    if override is not None:
        override = override.strip()
        if not override or len(override) > MAX_REASON_CHARS or not override.isprintable():
            raise Refused(f"--window-override needs a printable reason of 1..{MAX_REASON_CHARS} chars")
    return sha, parse_units(args.units), override


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        sha, requested, override = validate(args)
        return _deploy(args, sha, requested, override)
    except Refused as exc:
        print(f"REFUSED: {exc}", file=sys.stderr)
        return 2


def _deploy(args, sha: str, requested: list[str], override: str | None) -> int:
    try:
        decision = decide(sha, requested, override)
    except Refused as exc:
        print(f"REFUSED: {exc}", file=sys.stderr)
        return 2
    # Read the clock AFTER the preflight reads: a clock taken before them accepted phase 420
    # after a 61 s preflight whose real phase was 481.
    now = _now()
    windows = window_refusals(now, decision["path"], len(decision["units"]))
    reason = ", ".join(decision["moved_files"] + [f"no running sha for {u}" for u in decision["unproved_units"]])
    print(f"decision: {decision['path']} (digest_may_move={decision['digest_may_move']}"
          + (f": {reason}" if reason else "") + ")")
    print("units: " + ",".join(decision["units"]))
    for name, value in decision["environment"].items():
        print(f"environment: {name}={value}")
    if decision["predecessors"]:
        print("unselected, held to their captured identity: "
              + ", ".join(f"{unit}={value[:12]}" for unit, value in decision["predecessors"].items()))
    for index, command in enumerate(decision["commands"], 1):
        print(f"command {index}: {shlex.join(command)}")
    if windows and override is None:
        for message in windows:
            print(f"REFUSED: {message}", file=sys.stderr)
        return 2
    for message in windows:
        print(f"window override ({override}): {message}")
    # Preserve all existing guard refusals before acquiring the writers' lock. Dry runs
    # only read the registry; real checks release the lock before receipts and commands.
    if args.dry_run:
        check_target_registry(sha)
        print("dry run: nothing executed, no receipt written")
        return 0
    with registry_activation_lock():
        registry = check_target_registry(sha)
    receipt = {
        "schema": SCHEMA, "sha": sha, "units": decision["units"], "path": decision["path"],
        "digest_may_move": decision["digest_may_move"], "moved_files": decision["moved_files"],
        "running_shas": decision["running_shas"], "commands": decision["commands"],
        "exit_codes": [], "child_receipts": [], "started_at": _iso(now), "ended_at": None,
        "approved_by": args.approved_by, "approval_ref": args.approval_ref,
        "window_override": override, "window_refusals_overridden": windows,
        "ack_max_starts": ACK_MAX_STARTS, "outcome": "running", "failure": None,
        "environment": decision["environment"], "predecessors": decision["predecessors"],
        "unselected_active_before": decision["active_before"],
        "unselected_active_after_install": None, "deployed_after": None, "boundaries": [],
    }
    if registry is not None:
        receipt["registry"] = registry
    try:
        receipt_path = create_receipt(receipt, now)
    except OSError as exc:
        print(f"REFUSED: receipt unwritable under {RECEIPT_DIR.as_posix()} ({type(exc).__name__})",
              file=sys.stderr)
        return 2
    print(f"receipt: {receipt_path.as_posix()}")
    failure = None
    registry_refused = False
    for index, command in enumerate(decision["commands"]):
        try:
            with registry_activation_lock() as store:
                registry = recheck_target_registry(sha, store, registry)
            if registry is not None:
                receipt["registry"] = registry
        except Refused as exc:
            registry_refused = True
            script = Path(command[1]).name
            receipt["boundaries"].append({"command": index + 1, "script": script,
                                          "at": _iso(_now()), "refusals": [str(exc)]})
            failure = (f"registry guard before command {index + 1} ({script}): {exc}; "
                       "wait for registry writers to finish, then rerun deploy with a target "
                       "that can read the live registry")
            if receipt["exit_codes"]:
                failure = "partial_deploy_refused: " + failure
            break
        # A fresh clock at every mutation boundary; the entry check alone goes stale.
        boundary = _now()
        refusals = boundary_refusals(boundary, decision, index)
        script = Path(command[1]).name
        receipt["boundaries"].append({"command": index + 1, "script": script,
                                      "at": _iso(boundary), "refusals": refusals})
        if refusals and override is None:
            failure = (f"time guard before command {index + 1} ({script}) at {_iso(boundary)}: "
                       + "; ".join(refusals))
            break
        for message in refusals:
            print(f"window override ({override}): {message}")
        print(f"running: {shlex.join(command)}", flush=True)
        try:
            code, tail = _execute(command, decision["environment"])
        except (OSError, subprocess.SubprocessError) as exc:
            code, tail = -1, []
            failure = f"{command[1]} did not run ({type(exc).__name__})"
        path, child = child_receipt(tail)
        receipt["exit_codes"].append(code)
        receipt["child_receipts"].append(path)
        failure = failure or step_failure(decision, index, code, child)
        if not failure and decision["subset"] and index == 0:
            failure = install_state_failure(decision, receipt)
        if failure:
            break
        try:
            _write_json(receipt_path, receipt)
        except OSError as exc:
            failure = f"receipt update failed ({type(exc).__name__})"
            break
    if not failure and decision["subset"]:
        failure = identity_failure(decision, receipt)
    receipt.update(ended_at=_iso(_now()), outcome="failed" if failure else "succeeded", failure=failure)
    try:
        _write_json(receipt_path, receipt)
    except OSError as exc:
        print(f"receipt update failed: {type(exc).__name__}", file=sys.stderr)
        failure = failure or "receipt update failed"
    if failure:
        print(f"FAILED: {failure}", file=sys.stderr)
        if registry_refused:
            return 5 if receipt["exit_codes"] else 2
        return 1
    print("deploy verb finished")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
