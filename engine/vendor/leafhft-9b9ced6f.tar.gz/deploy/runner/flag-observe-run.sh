#!/bin/bash
# Live flag observer (SH4): reads the recorders' shadow spool, writes only its own state root.
set -euo pipefail
exec /opt/leafhft/.venv/bin/python /opt/leafhft/scripts/kalshi_flag_observe.py --spool /var/lib/leafhft/shadow --state /var/lib/leafhft/observe --watch /etc/leafhft/observe-watch.json --engines-dir /etc/leafhft/engines --follow
