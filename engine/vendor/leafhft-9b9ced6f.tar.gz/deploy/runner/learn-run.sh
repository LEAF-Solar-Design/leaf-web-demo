#!/bin/bash
# Every tick: the Kalshi live learning report over every ticket ledger under the runs root.
# Never overlaps (flock -n), never blocks systemd on a slow script (timeout 120 per invocation).
set -euo pipefail

runs_root="${LEAFHFT_RUNS:-/var/lib/leafhft/runs}"
py="${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}"
scripts_dir="${LEAFHFT_SCRIPTS:-/opt/leafhft/scripts}"
live_policy="${LEAFHFT_LIVE_POLICY:-/etc/leafhft/kalshi-policy.json}"
shadow_policy="${LEAFHFT_SHADOW_POLICY:-/etc/leafhft/kalshi-shadow-policy.json}"
shadow_since="$(cat /var/lib/leafhft/kalshi-shadow-since 2>/dev/null || echo 2026-09-10T04:00:00Z)"

if [[ ! -d "$runs_root" ]]; then
  echo "missing runs root: $runs_root" >&2
  exit 1
fi

lock="$(dirname -- "$runs_root")/learn.lock"
exec 9>"$lock" || { echo "missing lock path: $lock" >&2; exit 1; }
flock -n 9 || { echo "tick already running, skipping" >&2; exit 0; }

if timeout 120 "$py" "$scripts_dir/kalshi_live_learn.py" --runs "$runs_root" \
    --live-policy "$live_policy" --shadow-policy "$shadow_policy" --shadow-clean-since "$shadow_since" \
    --out "$runs_root/kalshi-learn.json" --md "$runs_root/kalshi-learn.md"; then
  echo "kalshi-learn: $runs_root/kalshi-learn.json"
else
  echo "kalshi-learn failed" >&2
fi

if timeout 120 "$py" "$scripts_dir/kalshi_live_learn.py" --runs "$runs_root" \
    --ledger-name kalshi-shadow-tickets.jsonl --label shadow \
    --live-policy "$live_policy" --shadow-policy "$shadow_policy" \
    --clean-since "$shadow_since" --shadow-clean-since "$shadow_since" \
    --out "$runs_root/kalshi-learn-shadow.json" --md "$runs_root/kalshi-learn-shadow.md"; then
  echo "kalshi-learn-shadow: $runs_root/kalshi-learn-shadow.json"
  cat "$runs_root/kalshi-learn-shadow.md"
else
  echo "kalshi-learn-shadow failed" >&2
fi

for run_dir in "$runs_root"/*live-polymarket_us-kalshi_edge*; do
  [[ -d "$run_dir" ]] || continue
  polymarket_learn=("$py" "$scripts_dir/kalshi_live_learn.py" --runs "$runs_root" --venue polymarket_us)
  if timeout 120 "${polymarket_learn[@]}" \
      --out "$runs_root/kalshi-learn-polymarket-us.json" --md "$runs_root/kalshi-learn-polymarket-us.md"; then
    echo "kalshi-learn-polymarket-us: $runs_root/kalshi-learn-polymarket-us.json"
    cat "$runs_root/kalshi-learn-polymarket-us.md"
  else
    echo "kalshi-learn-polymarket-us failed" >&2
  fi
  if timeout 120 "${polymarket_learn[@]}" \
      --ledger-name polymarket-us-shadow-tickets.jsonl --label shadow \
      --clean-since "$(cat /var/lib/leafhft/polymarket-us-shadow-since 2>/dev/null || echo 2026-09-10T04:00:00Z)" \
      --out "$runs_root/kalshi-learn-polymarket-us-shadow.json" --md "$runs_root/kalshi-learn-polymarket-us-shadow.md"; then
    echo "kalshi-learn-polymarket-us-shadow: $runs_root/kalshi-learn-polymarket-us-shadow.json"
    cat "$runs_root/kalshi-learn-polymarket-us-shadow.md"
  else
    echo "kalshi-learn-polymarket-us-shadow failed" >&2
  fi
  break
done

exit 0
