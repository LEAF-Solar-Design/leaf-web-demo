#!/bin/bash
# Optional /etc/leafhft/lane-bindings.json maps symbols to live lane document paths.
# LEAFHFT_ETC relocates it with the other runner configuration.
set -euo pipefail

# Account lanes have their own supervisor and credential boundary.
if [[ -n ${LEAFHFT_ACCOUNT_LANE_ID:-} ]]; then
  echo 'Use the account supervisor for account lanes.' >&2
  exit 2
fi
# The legacy books are the operator's own account; account lanes never reach this script.
export LEAFHFT_RISK_REGIME="${LEAFHFT_RISK_REGIME:-owner}"

if [[ $# -ne 1 ]]; then
  echo 'Usage: live-run.sh <binanceus-mm|kalshi-btc-15m|kalshi-perp-btc>' >&2
  exit 2
fi

etc="${LEAFHFT_ETC:-/etc/leafhft}"

# Whitelist for the kalshi-<coin>-15m / kalshi-<coin>-1h label pattern below; must match
# leafhft.feeds.kalshi.SYMBOL_MAP exactly.
KALSHI_SYMBOLS=(BTC-15M ETH-15M BTC-1H ETH-1H BNB-15M DOGE-15M HYPE-15M NEAR-15M SOL-15M XRP-15M ZEC-15M BNB-1H HYPE-1H XRP-1H)

stake="5.00"
if [[ -f "$etc/live-stake" ]]; then
  stake="$(<"$etc/live-stake")"
fi
if [[ ! "$stake" =~ ^[0-9]{1,3}(\.[0-9]{1,2})?$ ]]; then
  echo "invalid live-stake: $stake" >&2
  exit 2
fi

profile="s2c"
if [[ -f "$etc/live-profile" ]]; then
  profile="$(<"$etc/live-profile")"
fi
case "$profile" in
  s2c|aggressive) ;;
  *) echo "invalid live-profile: $profile" >&2; exit 2 ;;
esac

alternate=""
if [[ -f "$etc/live-alternate" ]]; then
  alternate="$(<"$etc/live-alternate")"
fi
case "$alternate" in
  ""|anchor_mm) ;;
  *) echo "invalid live-alternate: $alternate" >&2; exit 2 ;;
esac

transport="rest"
if [[ -f "$etc/live-transport" ]]; then
  transport="$(<"$etc/live-transport")"
fi
if [[ -z "$transport" ]]; then
  transport="rest"
fi
case "$transport" in
  ws|rest) ;;
  *) echo "invalid live-transport: $transport" >&2; exit 2 ;;
esac

kalshi_stake="5.00"
if [[ -f "$etc/kalshi-stake" ]]; then
  kalshi_stake="$(<"$etc/kalshi-stake")"
fi
if [[ ! "$kalshi_stake" =~ ^[0-9]{1,3}(\.[0-9]{1,2})?$ ]]; then
  echo "invalid kalshi-stake: $kalshi_stake" >&2
  exit 2
fi

kalshi_profile="kalshi-experiment"
if [[ -f "$etc/kalshi-profile" ]]; then
  kalshi_profile="$(<"$etc/kalshi-profile")"
fi
case "$kalshi_profile" in
  kalshi-experiment|kalshi-week2|kalshi-experiment-5x|kalshi-house-money|kalshi-favorites-5x) ;;
  *) echo "invalid kalshi-profile: $kalshi_profile" >&2; exit 2 ;;
esac

kalshi_perp_stake="20.00"
if [[ -f "$etc/kalshi-perp-stake" ]]; then
  kalshi_perp_stake="$(<"$etc/kalshi-perp-stake")"
fi
if [[ ! "$kalshi_perp_stake" =~ ^[0-9]{1,2}(\.[0-9]{1,2})?$ ]]; then
  echo "invalid kalshi-perp-stake: $kalshi_perp_stake" >&2
  exit 2
fi

kalshi_perp_profile="kalshi-sleeve"
if [[ -f "$etc/kalshi-perp-profile" ]]; then
  kalshi_perp_profile="$(<"$etc/kalshi-perp-profile")"
fi
case "$kalshi_perp_profile" in
  kalshi-sleeve|kalshi-sleeve-fast) ;;
  *) echo "invalid kalshi-perp-profile: $kalshi_perp_profile" >&2; exit 2 ;;
esac

kalshi_perp_params=""
if [[ -f "$etc/kalshi-perp-params" ]]; then
  kalshi_perp_params="$(<"$etc/kalshi-perp-params")"
fi
if [[ -n "$kalshi_perp_params" ]]; then
  if (( ${#kalshi_perp_params} > 512 )) || [[ ! "$kalshi_perp_params" =~ ^\{.*\}$ ]] || [[ "$kalshi_perp_params" == *$'\n'* ]]; then
    echo "invalid kalshi-perp-params: $kalshi_perp_params" >&2
    exit 2
  fi
fi

kalshi_params=""
if [[ -f "$etc/kalshi-params" ]]; then
  kalshi_params="$(<"$etc/kalshi-params")"
fi
if [[ -n "$kalshi_params" ]]; then
  if (( ${#kalshi_params} > 512 )) || [[ ! "$kalshi_params" =~ ^\{.*\}$ ]] || [[ "$kalshi_params" == *$'\n'* ]]; then
    echo "invalid kalshi-params: $kalshi_params" >&2
    exit 2
  fi
fi

kalshi_policy_path="$etc/kalshi-policy.json"
kalshi_shadow_policy_path="$etc/kalshi-shadow-policy.json"

echo "stake=$stake profile=$profile alternate=$alternate transport=$transport kalshi_stake=$kalshi_stake kalshi_profile=$kalshi_profile kalshi_perp_stake=$kalshi_perp_stake kalshi_perp_profile=$kalshi_perp_profile kalshi_perp_params=$kalshi_perp_params" >&2
echo "kalshi_params=$kalshi_params" >&2

case "$1" in
  binanceus-mm) args=(--venue binanceus --symbol BTC-USD --strategy mm --stake-usd "$stake" --limits-profile "$profile" --seconds 86400 --transport "$transport" --adopt-inventory) ;;
  polymarket-us-*-15m|polymarket-us-*-1h)
    coin="${1#polymarket-us-}"
    suffix="${coin##*-}"
    coin="${coin%-*}"
    case "$coin" in
      btc|eth|sol|xrp|doge|bnb|hype) ;;
      *) echo "Unknown live label: $1" >&2; exit 2 ;;
    esac
    symbol="${coin^^}-${suffix^^}"
    polymarket_stake="50.00"
    if [[ -f "$etc/polymarket-us-stake" ]]; then
      polymarket_stake="$(<"$etc/polymarket-us-stake")"
    fi
    if [[ ! "$polymarket_stake" =~ ^[0-9]{1,3}(\.[0-9]{1,2})?$ ]]; then
      echo "invalid polymarket-us-stake" >&2; exit 2
    fi
    polymarket_profile="kalshi-experiment"
    if [[ -f "$etc/polymarket-us-profile" ]]; then
      polymarket_profile="$(<"$etc/polymarket-us-profile")"
    fi
    case "$polymarket_profile" in
      kalshi-experiment|kalshi-week2|kalshi-experiment-5x|kalshi-house-money|kalshi-favorites-5x) ;;
      *) echo "invalid polymarket-us-profile" >&2; exit 2 ;;
    esac
    polymarket_policy_path="$etc/polymarket-us-policy.json"
    policy_py="${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}"
    policy_stake="$("$policy_py" -c '
import json, math, sys
with open(sys.argv[1], "rb") as f:
    data = f.read(8193)
if len(data) > 8192:
    raise SystemExit("policy file exceeds 8192 bytes")
obj = json.loads(data)
ceiling = obj.get("stake_ceiling_usd", 50.0)
stake = float(sys.argv[2])
if type(ceiling) not in (int, float) or not math.isfinite(ceiling) or not 1 <= ceiling <= 50 or not 1 <= stake <= 50:
    raise SystemExit("polymarket_us stake must be between 1 and 50 dollars")
print("%.2f" % ceiling)
' "$polymarket_policy_path" "$polymarket_stake")" || { echo "invalid polymarket-us-policy.json or stake" >&2; exit 2; }
    echo "polymarket_us sizing source: policy path=$polymarket_policy_path derived_stake=$policy_stake profile=$polymarket_profile" >&2
    args=(--venue polymarket_us --symbol "$symbol" --strategy kalshi_edge --policy "$polymarket_policy_path" --stake-usd "$policy_stake" --limits-profile "$polymarket_profile" --index-from kalshi --seconds 86400)
    ;;
  kalshi-*-15m|kalshi-*-1h)
    coin="${1#kalshi-}"
    suffix="${coin##*-}"
    coin="${coin%-*}"
    symbol="${coin^^}-${suffix^^}"
    known=0
    for s in "${KALSHI_SYMBOLS[@]}"; do
      if [[ "$s" == "$symbol" ]]; then known=1; break; fi
    done
    if [[ "$known" -ne 1 ]]; then
      echo "Unknown live label: $1" >&2
      exit 2
    fi
    if [[ -f "$kalshi_policy_path" ]]; then
      policy_py="${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}"
      policy_stake="$("$policy_py" -c '
import json, sys
with open(sys.argv[1], "rb") as f:
    data = f.read(8193)
if len(data) > 8192:
    raise SystemExit("policy file exceeds 8192 bytes")
obj = json.loads(data)
ceiling = float(obj.get("stake_ceiling_usd", 500.0))
print("%.2f" % ceiling)
' "$kalshi_policy_path")" || { echo "invalid kalshi-policy.json: $kalshi_policy_path" >&2; exit 2; }
      echo "kalshi sizing source: policy path=$kalshi_policy_path derived_stake=$policy_stake" >&2
      args=(--venue kalshi --symbol "$symbol" --strategy kalshi_edge --policy "$kalshi_policy_path" --stake-usd "$policy_stake" --limits-profile "$kalshi_profile" --seconds 86400)
    else
      echo "kalshi sizing source: etc kalshi-stake=$kalshi_stake kalshi-params=$kalshi_params" >&2
      args=(--venue kalshi --symbol "$symbol" --strategy kalshi_edge --stake-usd "$kalshi_stake" --limits-profile "$kalshi_profile" --seconds 86400)
      if [[ -n "$kalshi_params" ]]; then
        args+=(--params "$kalshi_params")
      fi
    fi
    if [[ -f "$etc/kalshi-engine-bindings.json" && -d "$etc/engines" ]]; then
      args+=(--engines-dir "$etc/engines" --engine-bindings "$etc/kalshi-engine-bindings.json")
      args+=(--engine-account-overrides "$etc/kalshi-engine-account-overrides.json")
      args+=(--dashboard-account-identity "/var/lib/leafhft/dashboard-account.json")
    fi
    # Optional path only. Missing, invalid and disabled specs preserve baseline sizing.
    args+=(--execution-experiment "$etc/kalshi-execution-experiment.json")
    if [[ -e "$etc/lane-bindings.json" ]]; then
      lane_py="${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}"
      lane_paths="$("$lane_py" -c '
import json, sys
def pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate symbol")
        result[key] = value
    return result
with open(sys.argv[1], "rb") as stream:
    data = stream.read(65537)
if len(data) > 65536:
    raise ValueError("lane bindings exceeds 65536 bytes")
obj = json.loads(data, object_pairs_hook=pairs)
if type(obj) is not dict or len(obj) > 64:
    raise ValueError("lane bindings must be a symbol map")
for symbol, paths in obj.items():
    if not symbol or len(symbol) > 16 or type(paths) is not list or len(paths) > 4:
        raise ValueError("invalid lane binding")
    if any(type(p) is not str or not p.startswith("/") or len(p) > 4096
           or not p.isprintable() for p in paths):
        raise ValueError("invalid lane document path")
    if len(set(paths)) != len(paths):
        raise ValueError("duplicate lane document path")
for path in obj.get(sys.argv[2], []):
    print(path)
' "$etc/lane-bindings.json" "$symbol")" || { echo "invalid lane-bindings.json" >&2; exit 4; }
      if [[ -n "$lane_paths" ]]; then
        while IFS= read -r lane_path; do
          args+=(--lane "$lane_path")
        done <<< "$lane_paths"
      fi
    fi
    if [[ -f "$etc/kalshi-shadow-policy-$suffix.json" ]]; then
      kalshi_shadow_policy_path="$etc/kalshi-shadow-policy-$suffix.json"
    fi
    if [[ -f "$kalshi_shadow_policy_path" ]]; then
      shadow_py="${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}"
      shadow_cash="$("$shadow_py" -c '
import json, sys
with open(sys.argv[1], "rb") as f:
    data = f.read(8193)
if len(data) > 8192:
    raise SystemExit("shadow policy file exceeds 8192 bytes")
obj = json.loads(data)
ceiling = float(obj.get("stake_ceiling_usd", 500.0))
print(int(max(1, min(500, round(ceiling)))))
' "$kalshi_shadow_policy_path")" || { echo "invalid ${kalshi_shadow_policy_path##*/}: $kalshi_shadow_policy_path" >&2; exit 2; }
      echo "kalshi shadow: policy path=$kalshi_shadow_policy_path shadow_cash_usd=$shadow_cash" >&2
      args+=(--shadow-policy "$kalshi_shadow_policy_path" --shadow-cash-usd "$shadow_cash")
    fi
    # Probe flags only for symbols listed in kalshi-probe-hosts (one per line); every other
    # book keeps a byte-identical argv. The bindings JSON is validated inside the process
    # (probe_bindings never raises), never here, so a bad file cannot stop an incumbent.
    if [[ -f "$etc/kalshi-probe-hosts" ]]; then
      probe_host=0
      while IFS= read -r probe_line || [[ -n "$probe_line" ]]; do
        probe_line="${probe_line//[[:space:]]/}"
        if [[ "$probe_line" == "$symbol" ]]; then probe_host=1; break; fi
      done < "$etc/kalshi-probe-hosts"
      if [[ "$probe_host" -eq 1 ]]; then
        if [[ -f "$etc/probe-bindings.json" ]]; then
          echo "kalshi probes: bindings=$etc/probe-bindings.json" >&2
          args+=(--probe-bindings "$etc/probe-bindings.json" --lifecycle-dir /var/lib/leafhft/engine-lifecycle --engine-registry /var/lib/leafhft/engine-registry/projection.json)
        else
          echo "kalshi probes: $symbol listed but $etc/probe-bindings.json is absent; no probes" >&2
        fi
      fi
    fi
    # X5: no fresh start of an opening producer while legacy-owner is exit_only. An absent or
    # authority role is one stat and exit 0; JSON is read inside the process, never here.
    timeout 10 "${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}" -m leafhft.exposure_conformance prestart --domain legacy-owner --symbol "$symbol" || exit 4
    ;;
  kalshi-perp-btc) args=(--venue kalshi-perp --symbol BTC-PERP --strategy perp_breakout --stake-usd "$kalshi_perp_stake" --limits-profile "$kalshi_perp_profile" --seconds 86400)
    timeout 10 "${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}" -m leafhft.exposure_conformance prestart --domain legacy-owner --producer perp || exit 4
    ;;
  *) echo "Unknown live label: $1" >&2; exit 2 ;;
esac

if [[ "$1" == "kalshi-perp-btc" && -n "$kalshi_perp_params" ]]; then
  args+=(--params "$kalshi_perp_params")
fi

if [[ "$1" == kalshi-*-15m || "$1" == kalshi-*-1h ]] && [[ -f "$etc/kalshi-classification-mode" ]]; then
  classification_mode="$(<"$etc/kalshi-classification-mode")"
  classification_mode="${classification_mode//[[:space:]]/}"
  case "$classification_mode" in
    ticker)
      args+=(--classification-mode ticker)
      echo "kalshi classification: ticker" >&2
      ;;
    ""|legacy) ;;
    *) echo "invalid kalshi-classification-mode" >&2; exit 2 ;;
  esac
fi

# Only owner Kalshi policy books opt in; off preserves the launch argv.
if [[ "$1" == kalshi-*-15m || "$1" == kalshi-*-1h ]] && [[ -f "$etc/kalshi-hot-observation-mode" ]]; then
  hot_observation_mode="$(<"$etc/kalshi-hot-observation-mode")"
  hot_observation_mode="${hot_observation_mode//[[:space:]]/}"
  case "$hot_observation_mode" in
    shadow|use)
      if [[ "${classification_mode:-}" == ticker ]]; then
        args+=(--hot-observation-mode "$hot_observation_mode")
        echo "kalshi hot observation: $hot_observation_mode" >&2
      else
        echo "kalshi hot observation: skipped (classification is not ticker)" >&2
      fi
      ;;
    ""|off) ;;
    *) echo "kalshi hot observation: skipped (invalid mode file)" >&2 ;;
  esac
fi

if [[ -n "$alternate" ]]; then
  args+=(--alternate "$alternate" --reference-venue coinbase --block-minutes 240)
fi

if [[ "$profile" == "aggressive" ]]; then
  params='{"half_spread_bps": 0.5, "vol_mult": 1.5, "order_frac": 0.09, "target_frac": 0.7, "seed_frac": 0, "reseed_lots": 2, "cost_rt_bps": 0, "min_edge_bps": 0.05, "requote_bps": 0.4, "join_touch": true}'
else
  params='{"half_spread_bps": 0.5, "vol_mult": 1.5, "order_frac": 0.4, "seed_frac": 0, "cost_rt_bps": 0, "min_edge_bps": 0.05, "requote_bps": 0.4, "join_touch": true}'
fi

LEAFHFT_BUILD_SHA=""
LEAFHFT_BUILD_DIRTY=0
if build_sha="$(timeout 5 git -C /opt/leafhft -c safe.directory=/opt/leafhft rev-parse HEAD 2>/dev/null)" && [[ "$build_sha" =~ ^[0-9a-f]{40}$ ]]; then
  if build_status="$(timeout 5 git -C /opt/leafhft -c safe.directory=/opt/leafhft status --porcelain --untracked-files=no 2>/dev/null)"; then
    LEAFHFT_BUILD_SHA="$build_sha"
    if [[ -n "$build_status" ]]; then
      LEAFHFT_BUILD_DIRTY=1
    fi
  fi
fi
export LEAFHFT_BUILD_SHA LEAFHFT_BUILD_DIRTY
echo "build sha=${LEAFHFT_BUILD_SHA:-unknown} dirty=$LEAFHFT_BUILD_DIRTY" >&2

# Stage B: kalshi-parity-mirror-hosts adds --parity-mirror and kalshi-executor-hosts (written
# only by stage_b.py) adds --parity-mirror --executor-mode, because executor mode always brings
# the mirror (C16c rule). One symbol per line, at most 64 lines of under 256 characters. A
# symlink, directory or oversized file is unusable and adds no flag; an unlisted book keeps a
# byte-identical argv. Bounded shell reads only, no subprocess, fails closed to fewer flags.
stage_b_listed() {
  local file="$1" want="$2" line="" count=0 found=1
  if [[ ! -e "$file" && ! -L "$file" ]]; then return 1; fi
  if [[ -L "$file" || ! -f "$file" || ! -r "$file" ]]; then return 2; fi
  while IFS= read -r -n 256 line || [[ -n "$line" ]]; do
    count=$((count + 1))
    if [[ "$count" -gt 64 || "${#line}" -ge 256 ]]; then return 2; fi
    line="${line//[[:space:]]/}"
    if [[ "$line" == "$want" ]]; then found=0; fi
  done < "$file"
  return "$found"
}
if [[ "$1" == kalshi-*-15m || "$1" == kalshi-*-1h ]]; then
  parity_state=0
  stage_b_listed "$etc/kalshi-parity-mirror-hosts" "$symbol" || parity_state=$?
  executor_state=0
  stage_b_listed "$etc/kalshi-executor-hosts" "$symbol" || executor_state=$?
  if [[ "$parity_state" -eq 2 ]]; then
    echo "kalshi stage b: $etc/kalshi-parity-mirror-hosts unusable; it adds no flag" >&2
  fi
  if [[ "$executor_state" -eq 2 ]]; then
    echo "kalshi stage b: $etc/kalshi-executor-hosts unusable; it adds no flag" >&2
  fi
  if [[ "$executor_state" -eq 0 ]]; then
    echo "kalshi stage b: $symbol executor mode (kalshi-executor-hosts)" >&2
    args+=(--parity-mirror --executor-mode)
  elif [[ "$parity_state" -eq 0 ]]; then
    echo "kalshi stage b: $symbol parity mirror (kalshi-parity-mirror-hosts)" >&2
    args+=(--parity-mirror)
  fi
  # B8: kalshi-book-taps (same bounded reader) adds --book-tap for a listed book only; the
  # address is a CLI argument outside the config digest, and an unlisted book keeps its argv.
  tap_state=0
  stage_b_listed "$etc/kalshi-book-taps" "$symbol" || tap_state=$?
  if [[ "$tap_state" -eq 2 ]]; then
    echo "kalshi book tap: $etc/kalshi-book-taps unusable; it adds no flag" >&2
  elif [[ "$tap_state" -eq 0 ]]; then
    echo "kalshi book tap: $symbol (kalshi-book-taps)" >&2
    args+=(--book-tap "/run/leafhft/book-tap/$symbol.sock")
  fi
fi

if [[ "$1" == kalshi-* || "$1" == polymarket-us-* ]]; then
  exec /opt/leafhft/.venv/bin/python -m leafhft live \
    "${args[@]}" \
    --ack-dir /var/lib/leafhft/live-ack --run-dir /var/lib/leafhft/runs
fi

exec /opt/leafhft/.venv/bin/python -m leafhft live \
  "${args[@]}" \
  --params "$params" \
  --ack-dir /var/lib/leafhft/live-ack --run-dir /var/lib/leafhft/runs
