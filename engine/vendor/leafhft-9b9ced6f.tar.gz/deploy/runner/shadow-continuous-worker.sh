#!/usr/bin/env bash
# Continuous local paper control plane. No live trading or notification client.
set -euo pipefail
umask 077
: "${SHADOW_DATABASE:?set SHADOW_DATABASE}"
: "${SHADOW_ENGINES_DIR:?set SHADOW_ENGINES_DIR}"
: "${SHADOW_SPOOL_DIR:?set SHADOW_SPOOL_DIR}"
: "${SHADOW_OUT_DIR:?set SHADOW_OUT_DIR}"
exec "${PYTHON:-python3}" -m scripts.kalshi_shadow_continuous \
  --database "$SHADOW_DATABASE" \
  --engines-dir "$SHADOW_ENGINES_DIR" \
  --spool-dir "$SHADOW_SPOOL_DIR" \
  --out-dir "$SHADOW_OUT_DIR" "$@"
