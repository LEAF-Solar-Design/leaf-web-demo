#!/bin/sh
set -eu
exec /opt/leafhft/.venv/bin/python /opt/leafhft/scripts/kalshi_ab_crossover.py tick
