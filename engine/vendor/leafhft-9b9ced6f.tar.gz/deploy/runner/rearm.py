#!/usr/bin/env python3
"""Plan or apply gate recovery using each live unit's own recent journal.

--apply refuses (exit 2, nothing stopped, no ack written) while /var/lib/leafhft/CONTAINMENT
exists or cannot be stat'ed; no flag, variable or window override lifts it. --plan only reads."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time

ACK_DIR = Path("/var/lib/leafhft/live-ack")
# deploy.py's CONTAINMENT marker, the same path and the same fail-closed rule.
CONTAINMENT = Path("/var/lib/leafhft/CONTAINMENT")
JOURNAL_BYTES = 1024 * 1024
UNIT = re.compile(r"leafhft-live@[A-Za-z0-9_.-]+\.service")
SENTENCE = re.compile(
    r"I authorize live trading with config ([0-9a-f]{64})"
    r"(?: under policy bounds [0-9a-f]{12})?"
    r" and a stake of at most \$[0-9]+\.[0-9]{2}"
)
# The restart boundary, the one copy the deploy verb imports and rollout.sh's
# rollout_boundary_refusal mirrors: the [60, 420] s gap of the 900 s settlement
# cycle and the 23:35-00:25Z blackout (seconds after 00:00Z; it runs past midnight).
GAP_CYCLE_S, GAP_MIN_S, GAP_MAX_S = 900, 60, 420
BLACKOUT_START_S, BLACKOUT_END_S = 84_900, 1_500
# rollout.sh sets these on a subset: "1" arms the guard immediately before the
# stop; a reason lifts the blackout refusal only, never the gap.
WINDOW_GUARD_ENV = "LEAFHFT_REARM_WINDOW_GUARD"
WINDOW_OVERRIDE_ENV = "LEAFHFT_REARM_WINDOW_OVERRIDE"
MAX_OVERRIDE_CHARS = 300
GAP_REFUSED, BLACKOUT_REFUSED = 3, 4  # --apply exit codes; the unit was not stopped
WINDOW_REFUSED = "window refused: "


class WindowRefused(RuntimeError):
    """The restart boundary refused a stop; nothing was stopped or written."""

    def __init__(self, code: int, reason: str):
        super().__init__(reason)
        self.code, self.reason = code, reason


def _now() -> float:
    return time.time()


def book_hold_marker(unit: str) -> str | None:
    """Map only Kalshi book instances to their operator HOLD marker name."""
    match = re.fullmatch(r"leafhft-live@kalshi-([a-z0-9]+)-([a-z0-9]+)\.service", unit)
    return f"HOLD-{match[1]}-{match[2]}" if match else None


def book_held(unit: str) -> bool:
    marker = book_hold_marker(unit)
    if marker is None:
        return False
    directory = os.environ.get("LEAFHFT_HOLD_DIR") or "/root/leafhft-cliff"
    try:
        os.lstat(Path(directory) / marker)
    except FileNotFoundError:
        return False
    except OSError:
        return True
    return True


def check_containment() -> None:
    """deploy.py's check_containment: raises RuntimeError when the marker exists or cannot be
    stat'ed (unreadable is treated as contained); returns only when it is missing."""
    try:
        os.lstat(CONTAINMENT)
    except FileNotFoundError:
        return
    except OSError as exc:
        raise RuntimeError(f"CONTAINMENT marker unreadable ({type(exc).__name__}); treated as contained")
    raise RuntimeError(f"CONTAINMENT: {CONTAINMENT.as_posix()} exists; no override lifts it")


def window_refusal(epoch: float) -> tuple[int, str] | None:
    """Pure arithmetic, no I/O: None when a stop may start at `epoch`, else (exit code, reason)."""
    epoch = int(epoch)
    day, phase = epoch % 86_400, epoch % GAP_CYCLE_S
    if not GAP_MIN_S <= phase <= GAP_MAX_S:
        return GAP_REFUSED, (f"restart boundary at epoch {epoch} is {phase} s into the "
                             f"{GAP_CYCLE_S} s cycle, outside the [{GAP_MIN_S}, {GAP_MAX_S}] s gap")
    if day >= BLACKOUT_START_S or day < BLACKOUT_END_S:
        clock = f"{day // 3600:02d}:{day % 3600 // 60:02d}:{day % 60:02d}Z"
        return BLACKOUT_REFUSED, (f"restart boundary at epoch {epoch} ({clock}) falls in the "
                                  "23:35-00:25Z blackout")
    return None


def check_window(unit: str, override: str | None = None, now: float | None = None) -> None:
    """The guard, on a fresh clock: raises WindowRefused outside the gap, or inside the blackout
    unless `override` names a reason. Call it after every read, immediately before the stop."""
    refusal = window_refusal(_now() if now is None else now)
    if refusal is None:
        return
    code, reason = refusal
    if code == BLACKOUT_REFUSED and override:
        print(f"window override ({override}): {unit}: re-arm {reason}", flush=True)
        return
    raise WindowRefused(code, reason)


def window_guard_from_env():
    """None when rollout.sh did not arm the guard; fails closed on a malformed setting."""
    armed = os.environ.get(WINDOW_GUARD_ENV, "")
    if armed in ("", "0"):
        return None
    if armed != "1":
        raise ValueError(f"{WINDOW_GUARD_ENV} must be 0 or 1")
    override = os.environ.get(WINDOW_OVERRIDE_ENV, "").strip() or None
    if override is not None and (len(override) > MAX_OVERRIDE_CHARS or not override.isprintable()):
        raise ValueError(f"{WINDOW_OVERRIDE_ENV} must be a printable reason of 1..{MAX_OVERRIDE_CHARS} chars")
    return lambda unit: check_window(unit, override)


def parse_journal(unit: str, journal: str, ack_dir: Path = ACK_DIR) -> dict | None:
    """Use the latest startup's sentence, never borrow another unit's authority."""
    if UNIT.fullmatch(unit) is None:
        raise ValueError("invalid live unit")
    # Every startup prints a sentence. Keep only the latest startup, including
    # its preceding digest; later gate exceptions repeat that digest.
    lines = journal.splitlines()
    sentence_indices = [i for i, line in enumerate(lines) if line.startswith("ack sentence:")]
    if sentence_indices:
        start = max(0, sentence_indices[-1] - 1)
        lines = lines[start:]
    if not any(line.startswith("LIVE GATE CLOSED:") for line in lines):
        return None
    digests = [line.removeprefix("config digest: ") for line in lines
               if line.startswith("config digest: ")]
    sentences = [line.removeprefix("ack sentence: ") for line in lines
                 if line.startswith("ack sentence: ")]
    if not digests or not sentences or SENTENCE.fullmatch(sentences[-1]) is None:
        raise ValueError(f"{unit}: cannot parse gate digest and exact sentence")
    digest = digests[-1]
    match = SENTENCE.fullmatch(sentences[-1])
    if re.fullmatch(r"[0-9a-f]{64}", digest) is None or match.group(1) != digest:
        raise ValueError(f"{unit}: printed digest does not match sentence")
    name = f"LIVE-ACK-{digest[:12]}.txt"
    printed_names = re.findall(r"LIVE-ACK-[^\s/]+\.txt", "\n".join(lines))
    if any(printed != name for printed in printed_names):
        raise ValueError(f"{unit}: printed digest does not match ack name")
    return {"unit": unit, "digest": digest, "sentence": sentences[-1],
            "ack_path": str(ack_dir / name)}


def _systemctl(*args: str) -> str:
    return subprocess.run(["systemctl", *args], check=True, capture_output=True,
                          text=True, timeout=30).stdout.strip()


def live_units() -> list[str]:
    output = _systemctl("list-units", "--all", "--plain", "--no-legend", "leafhft-live@*")
    output += "\n" + _systemctl("list-unit-files", "--no-legend", "leafhft-live@*")
    return sorted({word for word in output.split() if UNIT.fullmatch(word)})


def read_journal(unit: str) -> str:
    if UNIT.fullmatch(unit) is None:
        raise ValueError("invalid live unit")
    # Spool command output, then read at most 1 MiB into memory. A partial first
    # line cannot become a sentence. journalctl itself is time and entry bounded.
    with tempfile.TemporaryFile() as output:
        subprocess.run(["journalctl", "-u", unit, "--since", "10 minutes ago",
                        "-n", "2000", "--no-pager", "-o", "cat"],
                       stdout=output, stderr=subprocess.PIPE, check=True, timeout=15)
        size = output.tell()
        output.seek(max(0, size - JOURNAL_BYTES))
        data = output.read(JOURNAL_BYTES)
    if size > JOURNAL_BYTES:
        data = data.partition(b"\n")[2]
    return data.decode("utf-8", errors="strict")


def apply_plan(plan: dict, guard=None, checkpoint=None) -> str | None:
    unit = plan["unit"]
    if book_held(unit):
        print(f"held, not started: {unit}", flush=True)
        return "held"
    # Revalidate the immutable plan fields before stopping or writing anything.
    expected = parse_journal(unit, f"config digest: {plan['digest']}\n"
                             f"ack sentence: {plan['sentence']}\nLIVE GATE CLOSED: ack missing")
    if expected != plan:
        raise ValueError(f"{unit}: invalid ack plan")
    import grp
    import pwd

    uid, gid = pwd.getpwnam("leafhft").pw_uid, grp.getgrnam("leafhft").gr_gid
    # The restart boundary, after the journal read and every lookup: nothing sits between the
    # last check and the stop. A refusal raises here and the unit is left untouched.
    if guard is not None:
        guard(unit)
    check_containment()
    _systemctl("stop", unit)
    state = _systemctl("show", "--property=ActiveState", "--value", unit)
    if state not in ("inactive", "failed"):
        raise RuntimeError(f"{unit}: stop did not settle ({state}); no ack written")
    # After stop, reject drift in the refusal that supplied the reviewed sentence.
    if parse_journal(unit, read_journal(unit)) != plan:
        raise RuntimeError(f"{unit}: gate evidence changed; left stopped")
    target = Path(plan["ack_path"])
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        # Checkpoints run immediately before ACK temp creation and unit start.
        if checkpoint is not None:
            checkpoint(unit)
        fd, temporary = tempfile.mkstemp(prefix=".rearm-", dir=target.parent)
        with os.fdopen(fd, "wb") as ack:
            os.fchmod(ack.fileno(), 0o640)
            os.fchown(ack.fileno(), uid, gid)
            ack.write((plan["sentence"] + "\n").encode())
            ack.flush()
            os.fsync(ack.fileno())
        os.replace(temporary, target)
        temporary = None
        directory_fd = os.open(target.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        if temporary is not None:
            os.unlink(temporary)
    if book_held(unit):
        print(f"held, not started: {unit}", flush=True)
        return "held"
    if checkpoint is not None:
        checkpoint(unit)
    _systemctl("start", unit)
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        state = _systemctl("show", "--property=ActiveState", "--value", unit)
        if state == "active":
            return
        time.sleep(1)
    raise RuntimeError(f"{unit}: did not reach active ({state})")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--plan", action="store_true")
    action.add_argument("--apply", action="store_true")
    parser.add_argument("units", nargs="*", help="full leafhft-live@ unit names; default: all")
    args = parser.parse_args(argv)
    plans, errors, held = [], [], []
    try:
        if args.apply:
            check_containment()
        guard = window_guard_from_env() if args.apply else None
        for unit in args.units or live_units():
            try:
                if book_held(unit):
                    held.append(unit)
                    print(f"held, not started: {unit}", flush=True)
                    continue
                plan = parse_journal(unit, read_journal(unit))
                if plan is not None:
                    plans.append(plan)
            except (ValueError, OSError, subprocess.SubprocessError) as exc:
                errors.append(str(exc))
        print(json.dumps({"plans": plans, "refused": errors, "held": held}, indent=2))
        if errors:
            return 2
        if args.apply:
            for plan in plans:
                if guard is None:
                    result = apply_plan(plan)
                else:
                    result = apply_plan(plan, guard)
                if result == "held":
                    held.append(plan["unit"])
                    print(json.dumps({"held": held}, indent=2))
                    continue
                print(f"{plan['unit']}: active")
        return 0
    except WindowRefused as exc:
        # The caller (rollout.sh) holds the re-arm to the next gap on 3 and stops on 4.
        print(WINDOW_REFUSED + exc.reason)
        print("rearm held: unit not stopped, no ack written")
        return exc.code
    except (ValueError, OSError, RuntimeError, KeyError, subprocess.SubprocessError) as exc:
        print(f"rearm refused: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
