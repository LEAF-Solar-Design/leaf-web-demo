#!/bin/bash
# Kashbot account lanes enter Python without inherited venue credentials.
set -euo pipefail
umask 077
[[ $# -ge 1 && $# -le 2 ]] || exit 2
lane=$1
role=${2:-run}
[[ $lane =~ ^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$ ]] || exit 2
[[ $role == run || $role == push ]] || exit 2
[[ ${LEAFHFT_ACCOUNT_LANE_ID:-} == "$lane" ]] || exit 2
regime_env=()
if [[ ${LEAFHFT_ACCOUNT_RISK_REGIME:-} == owner ]]; then
  regime_env=(LEAFHFT_ACCOUNT_RISK_REGIME=owner)
fi
exec env -i PATH=/usr/bin:/bin PYTHONUNBUFFERED=1 \
  LEAFHFT_ACCOUNT_LANE_ID="$lane" CREDENTIALS_DIRECTORY="${CREDENTIALS_DIRECTORY:-}" \
  "${regime_env[@]}" \
  /opt/leafhft/.venv/bin/python -m leafhft.account_lane_agent "$role" "$lane"
