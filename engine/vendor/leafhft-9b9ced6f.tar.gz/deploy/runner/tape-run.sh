#!/bin/bash
# Every tick: fill-tape.json for the newest live run dirs, then scoreboard.json over the runs root,
# mirrored into the newest live run dir. Never overlaps (flock -n), never blocks systemd on a slow
# script (timeout 120 per invocation), bounded to MAX_LIVE_DIRS per tick, and never touches a
# recorder run directory even if its name happened to match the live glob.
set -euo pipefail

runs_root="${LEAFHFT_RUNS:-/var/lib/leafhft/runs}"
py="${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}"
scripts_dir="${LEAFHFT_SCRIPTS:-/opt/leafhft/scripts}"
# The frozen baseline began with main 177c45c (the two-sided maker) on this date; the
# scoreboard must never count pre-baseline runs as operating blocks.
baseline="${LEAFHFT_BASELINE:-2026-09-07}"
MAX_LIVE_DIRS=20

if [[ ! -d "$runs_root" ]]; then
  echo "missing runs root: $runs_root" >&2
  exit 1
fi

lock="$(dirname -- "$runs_root")/tape.lock"
exec 9>"$lock" || { echo "missing lock path: $lock" >&2; exit 1; }
flock -n 9 || { echo "tick already running, skipping" >&2; exit 0; }

shopt -s nullglob
candidates=()
for d in "$runs_root"/*-live-*; do
  [[ -d "$d" ]] || continue
  base="$(basename -- "$d")"
  [[ "$base" != record-* ]] || continue
  [[ -f "$d/ledger.sqlite" ]] || continue
  candidates+=("$d")
done
shopt -u nullglob

dirs=()
if [[ ${#candidates[@]} -gt 0 ]]; then
  while IFS= read -r line; do
    dirs+=("$line")
  done < <(printf '%s\n' "${candidates[@]}" | sort -r | head -n "$MAX_LIVE_DIRS")
fi

for d in "${dirs[@]}"; do
  ledger="$d/ledger.sqlite"
  tape="$d/fill-tape.json"
  if [[ -f "$tape" && -f "$d/receipt.json" && "$tape" -nt "$ledger" ]]; then
    continue
  fi
  if timeout 120 "$py" "$scripts_dir/fill_tape.py" "$d" --out "$tape"; then
    echo "tape: $d"
  else
    echo "tape failed: $d" >&2
  fi
done

if timeout 120 "$py" "$scripts_dir/live_bound.py" "$runs_root" --since "$baseline" --out "$runs_root/scoreboard.json"; then
  if [[ -n "${dirs[0]:-}" ]]; then
    cp -f -- "$runs_root/scoreboard.json" "${dirs[0]}/scoreboard.json" || echo "scoreboard copy to run dir failed" >&2
  fi
else
  echo "scoreboard failed" >&2
fi

exit 0
