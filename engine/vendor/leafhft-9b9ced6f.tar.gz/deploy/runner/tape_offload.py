#!/usr/bin/env python3
"""Offload closed recorder tapes, then reclaim only locally unchanged verified data."""

import argparse
import base64
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import stat as stat_module
import subprocess
import time


GIB = 1024 ** 3
HASH_CHUNK = 8 * 1024 ** 2
DAY = 86400
DIR_NAME = re.compile(r"\d{8}-\d{6}(?:-\d+)?-record-[A-Za-z0-9_.-]+", re.ASCII)
FILE_NAME = re.compile(r"(?:ticks(?:\.\d{3})?\.jsonl|record-summary\.json|signals\.json|coverage\.jsonl?)", re.ASCII)


def eligible_name(name):
    return DIR_NAME.fullmatch(name) is not None


def s3_key(prefix, directory, file):
    if not eligible_name(directory) or FILE_NAME.fullmatch(file) is None:
        raise ValueError("invalid recorder name")
    if not prefix or any(not re.fullmatch(r"[A-Za-z0-9_.-]+", part) or part in (".", "..")
                         for part in prefix.split("/")):
        raise ValueError("invalid S3 prefix")
    return f"{prefix}/{directory}/{file}"


def closed(file_stat, now, open_paths):
    return file_stat["path"] not in open_paths and now - file_stat["mtime_ns"] / 1e9 > 1800


def same_record(record, current):
    return bool(record) and all(record.get(key) == current.get(key)
                                for key in ("path", "size", "mtime_ns", "sha256_b64"))


def same_metadata(record, current):
    return bool(record) and bool(record.get("sha256_b64")) and all(
        key in record and record[key] == current[key]
        for key in ("path", "size", "mtime_ns", "dev", "ino"))


def should_delete(record, stat, now, keep_days, open_paths):
    return (same_record(record, stat) and bool(stat.get("sha256_b64"))
            and stat["path"] not in open_paths
            and now - stat["mtime_ns"] / 1e9 > keep_days * DAY)


def pressure_candidates(records, stats, now, open_paths):
    return sorted((item for item in stats
                   if should_delete(records.get(item["path"]), item, now, 1, open_paths)),
                  key=lambda item: (item["mtime_ns"], item["path"]))


def open_files():
    paths = set()
    for fd_dir in Path("/proc").glob("[0-9]*/fd"):
        try:
            for fd in fd_dir.iterdir():
                try:
                    target = os.readlink(fd)
                    if os.path.isabs(target):
                        paths.add(os.path.normpath(target))
                except OSError:
                    pass
        except OSError:
            pass
    return paths


def free_gb(root):
    return shutil.disk_usage(root).free / GIB


def metadata(path):
    if path.parent.is_symlink() or not path.parent.is_dir():
        raise ValueError("recorder directory changed")
    st = path.lstat()
    if not stat_module.S_ISREG(st.st_mode):
        raise ValueError("not a regular tape file")
    return {"path": str(path), "size": st.st_size, "mtime_ns": st.st_mtime_ns,
            "dev": st.st_dev, "ino": st.st_ino}


class ReadThrottle:
    """Shared monotonic token bucket, allowing one 8 MiB read burst."""

    def __init__(self, mbps):
        self.rate = mbps * 1024 ** 2
        self.tokens = HASH_CHUNK
        self.updated = time.monotonic()

    def consume(self, size):
        while True:
            now = time.monotonic()
            self.tokens = min(HASH_CHUNK, self.tokens + (now - self.updated) * self.rate)
            self.updated = now
            if self.tokens >= size:
                self.tokens -= size
                return
            time.sleep((size - self.tokens) / self.rate)


def snapshot(path, throttle=None, metrics=None):
    started = time.monotonic()
    try:
        return hash_snapshot(path, throttle, metrics)
    finally:
        if metrics is not None:
            metrics["hash_seconds"] += time.monotonic() - started


def hash_snapshot(path, throttle, metrics):
    before = metadata(path)
    digest = hashlib.sha256()
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, "rb") as stream:
        st = os.fstat(stream.fileno())
        if (st.st_dev, st.st_ino) != (before["dev"], before["ino"]):
            raise ValueError("file replaced before hashing")
        remaining = before["size"]
        while remaining:
            size = min(HASH_CHUNK, remaining)
            if throttle is not None:
                throttle.consume(size)
            chunk = stream.read(size)
            if not chunk:
                raise ValueError("file truncated while hashing")
            digest.update(chunk)
            remaining -= len(chunk)
            if metrics is not None:
                metrics["bytes_hashed"] += len(chunk)
    if metadata(path) != before:
        raise ValueError("file changed while hashing")
    return dict(before, sha256_b64=base64.b64encode(digest.digest()).decode("ascii"))


def discover(root):
    files, ignored = [], 0
    for directory in sorted(root.iterdir(), key=lambda path: path.name):
        if directory.is_symlink() or not directory.is_dir() or not eligible_name(directory.name):
            ignored += 1
            continue
        for path in sorted(directory.iterdir()):
            if path.is_symlink() or not path.is_file() or FILE_NAME.fullmatch(path.name) is None:
                ignored += 1
                continue
            files.append(path)
    return files, ignored


def aws_call(aws, arguments, timeout):
    result = subprocess.run([aws, "s3api", *arguments, "--output", "json"],
                            capture_output=True, text=True, timeout=timeout, check=True)
    response = json.loads(result.stdout)
    if not isinstance(response, dict):
        raise ValueError("AWS response must be an object")
    return response


def upload(args, current, timeout):
    deadline = time.monotonic() + timeout
    path = Path(current["path"])
    key = s3_key(args.prefix, path.parent.name, path.name)
    common = ["--bucket", args.bucket, "--key", key]
    aws_call(args.aws, ["put-object", *common, "--body", str(path),
                       "--checksum-algorithm", "SHA256", "--checksum-sha256",
                       current["sha256_b64"]], timeout)
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise ValueError("upload verification time budget exhausted")
    head = aws_call(args.aws, ["head-object", *common, "--checksum-mode", "ENABLED"], remaining)
    if head.get("ContentLength") != current["size"] or head.get("ChecksumSHA256") != current["sha256_b64"]:
        raise ValueError("S3 size or checksum mismatch")
    if metadata(path) != {key: value for key, value in current.items() if key != "sha256_b64"}:
        raise ValueError("file changed during upload")
    return {key_name: current[key_name] for key_name in
            ("path", "size", "mtime_ns", "dev", "ino", "sha256_b64")} | {
                "key": key, "etag": head.get("ETag"), "version_id": head.get("VersionId"),
                "verified_at_utc": datetime.now(timezone.utc).isoformat()}


def load_index(path):
    if not path.exists():
        return {}
    if path.is_symlink() or path.stat().st_size > 50 * 1024 ** 2:
        raise ValueError("verified index is unsafe or exceeds 50 MB")
    records = {}
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            record = json.loads(line)
            if not isinstance(record, dict) or not isinstance(record.get("path"), str):
                raise ValueError("invalid verified index")
            records[record["path"]] = record
    return records


def append_json(path, record):
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


@contextmanager
def acquire_lock(state_dir, plan=False):
    import fcntl

    path = state_dir / "offload.lock"
    if plan and not path.exists():
        yield
        return
    if not plan:
        state_dir.mkdir(parents=True, exist_ok=True)
    with path.open("r" if plan else "a") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def run(args, records):
    started = time.monotonic()
    now = time.time()
    counts = dict.fromkeys(("discovered", "in_use", "too_recent", "uploaded", "already_verified",
                            "failed", "deleted", "dirs_removed", "ignored"), 0)
    summary = {"counts": counts, "bytes_uploaded": 0, "bytes_freed": 0,
               "bytes_hashed": 0, "hash_seconds": 0,
               "free_gb_before": free_gb(args.runs_root)}
    throttle = ReadThrottle(args.max_read_mbps)
    paths, counts["ignored"] = discover(args.runs_root)
    counts["discovered"] = len(paths)
    opened = open_files()
    active = {str(Path(path).parent) for path in opened}
    stats = []
    upload_stopped = False

    def failure(path, error):
        counts["failed"] += 1
        print(f"failed {path}: {type(error).__name__}: {str(error).splitlines()[0]}")

    for path in paths:
        try:
            if str(path) in opened:
                counts["in_use"] += 1
                print(f"in_use {path}")
                continue
            current = metadata(path)
            if not closed(current, now, opened):
                counts["too_recent"] += 1
                print(f"too_recent {path}")
                continue
            record = records.get(str(path))
            if same_metadata(record, current):
                stats.append(dict(current, sha256_b64=record["sha256_b64"]))
                counts["already_verified"] += 1
                print(f"already_verified {path}")
                continue
            # Old index records get one hash and an append-only identity upgrade.
            hashed = False
            if (record and ("dev" not in record or "ino" not in record)
                    and all(record.get(key) == current[key]
                            for key in ("path", "size", "mtime_ns"))):
                current = snapshot(path, throttle, summary)
                hashed = True
                if same_record(record, current):
                    record = dict(record, dev=current["dev"], ino=current["ino"])
                    if not args.plan:
                        append_json(args.state_dir / "verified.jsonl", record)
                    records[str(path)] = record
                    stats.append(current)
                    counts["already_verified"] += 1
                    print(f"already_verified {path}")
                    continue
            remaining = args.max_wall_s - (time.monotonic() - started)
            if (upload_stopped or remaining <= 0
                    or summary["bytes_uploaded"] >= args.max_upload_gb * GIB
                    or summary["bytes_uploaded"] + current["size"] > args.max_upload_gb * GIB):
                upload_stopped = True
                print(f"upload_bound {path}")
                continue
            if args.plan:
                print(f"would_upload {path}")
                continue
            if not hashed:
                current = snapshot(path, throttle, summary)
            stats.append(current)
            remaining = args.max_wall_s - (time.monotonic() - started)
            if remaining <= 0 or summary["bytes_uploaded"] + current["size"] > args.max_upload_gb * GIB:
                upload_stopped = True
                print(f"upload_bound {path}")
                continue
            fresh_open = open_files()
            opened.update(fresh_open)
            active.update(str(Path(item).parent) for item in fresh_open)
            if str(path) in opened:
                counts["in_use"] += 1
                print(f"in_use {path}")
                continue
            timeout = min(1800, 60 + current["size"] / (4 * 1024 ** 2), remaining)
            # Count attempted bytes as well so failures cannot bypass the run budget.
            summary["bytes_uploaded"] += current["size"]
            record = upload(args, current, timeout)
            append_json(args.state_dir / "verified.jsonl", record)
            records[str(path)] = record
            counts["uploaded"] += 1
            print(f"verified {path}")
        except (OSError, ValueError, subprocess.SubprocessError) as error:
            failure(path, error)

    delete_attempted = set()

    def delete(current, keep_days, pressure=False):
        path = Path(current["path"])
        if str(path) in delete_attempted:
            return
        delete_attempted.add(str(path))
        try:
            fresh = snapshot(path, throttle, summary)
            opened.update(open_files())
            active.update(str(Path(item).parent) for item in opened)
            if not should_delete(records.get(str(path)), fresh, now, keep_days, opened):
                return
            action = "pressure_delete" if pressure else "delete"
            if args.plan:
                print(f"would_{action} {path}")
                return
            if metadata(path) != {key: value for key, value in fresh.items() if key != "sha256_b64"}:
                return
            path.unlink()
            counts["deleted"] += 1
            summary["bytes_freed"] += fresh["size"]
            print(f"{action} {path}")
            if str(path.parent) not in active:
                try:
                    os.rmdir(path.parent)
                    counts["dirs_removed"] += 1
                    print(f"rmdir {path.parent}")
                except OSError:
                    pass  # Nonempty directories, including ignored files, stay intact.
        except FileNotFoundError:
            pass
        except (OSError, ValueError) as error:
            failure(path, error)

    for current in stats:
        if should_delete(records.get(current["path"]), current, now, args.keep_days, opened):
            delete(current, args.keep_days)
    for current in pressure_candidates(records, stats, now, opened):
        if free_gb(args.runs_root) >= args.min_free_gb:
            break
        delete(current, 1, pressure=True)
    summary.update(wall_seconds=time.monotonic() - started, free_gb_after=free_gb(args.runs_root))
    print(json.dumps(summary, sort_keys=True))
    if not args.plan:
        append_json(args.state_dir / "runs.jsonl", summary)
    return 1 if counts["failed"] else 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs-root", type=Path, default=Path("/var/lib/leafhft/runs"))
    parser.add_argument("--bucket", default="leaf-leafhft-tapes-807034087062-us-east-1")
    parser.add_argument("--prefix", default="runner")
    parser.add_argument("--state-dir", type=Path, default=Path("/var/lib/leafhft/offload"))
    parser.add_argument("--keep-days", type=float, default=3)
    parser.add_argument("--min-free-gb", type=float, default=5)
    parser.add_argument("--max-upload-gb", type=float, default=3)
    parser.add_argument("--max-read-mbps", type=float, default=40)
    parser.add_argument("--max-wall-s", type=float, default=3000)
    parser.add_argument("--aws", default="/usr/local/bin/aws")
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args(argv)
    try:
        if not math.isfinite(args.max_read_mbps) or args.max_read_mbps <= 0:
            raise ValueError("max-read-mbps must be finite and positive")
        for value in (args.keep_days, args.min_free_gb, args.max_upload_gb, args.max_wall_s):
            if not math.isfinite(value) or value < 0:
                raise ValueError("bounds must be finite and nonnegative")
        s3_key(args.prefix, "20260915-000000-record-check", "ticks.jsonl")
        if not re.fullmatch(r"[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]", args.bucket):
            raise ValueError("invalid bucket")
        if args.runs_root.is_symlink() or not args.runs_root.is_dir():
            raise ValueError("runs root must be a real directory")
        args.runs_root = args.runs_root.resolve()
        if args.state_dir.is_symlink():
            raise ValueError("state directory cannot be a symlink")
        args.state_dir = args.state_dir.resolve()
        if args.state_dir == args.runs_root or args.runs_root in args.state_dir.parents:
            raise ValueError("state directory must be outside runs root")
        for name in ("offload.lock", "verified.jsonl", "runs.jsonl"):
            if (args.state_dir / name).is_symlink():
                raise ValueError("state files cannot be symlinks")
        with acquire_lock(args.state_dir, args.plan):
            records = load_index(args.state_dir / "verified.jsonl")
            return run(args, records)
    except BlockingIOError:
        print("refused: offload lock held")
        return 0
    except (ValueError, OSError, ImportError) as error:
        print(f"refused: {str(error).splitlines()[0]}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
