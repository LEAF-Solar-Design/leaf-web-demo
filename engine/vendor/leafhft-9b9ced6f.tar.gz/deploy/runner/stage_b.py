#!/usr/bin/env python3
"""Stage B acceptance per book (C16d): executor mode on one Kalshi book at a time.

Contract (fails closed; every refusal prints `stage_b refused: <code>: <detail>` on stderr):
  * writes only under --state-dir (ledger.json, .lock, ticks-<window>.jsonl, receipts/) and the
    hosts files <etc>/kalshi-executor-hosts (flip, unflip) and <etc>/kalshi-parity-mirror-hosts
    (mirror, unmirror). It restarts nothing and re-acks nothing: flip and
    unflip print the one-unit restart and re-ack commands for the runner train, never run them;
    restart-plan (read only, no lock) prints the one guarded one-book rollout.
  * every read is bounded: status files 1 MiB, config files 64 KiB, the newest 128 run dirs, at
    most 256 windows, tick lines of 64 KiB and at most 4096 of them per window.
  * a file that cannot be read is null in the tick line, never zero, and a null fails the verdict.
    An unreadable or unscanned run dir is missing evidence (a null line), never an absent run.
  * a window, every tick line and every final receipt carry the identity the book's own files
    report (status build sha and dirty, config.json build sha and digest); --sha is only asserted.
  * a run dir that cannot be classified (no or null venue, an unknown mode, a timestamp that
    cannot be read) is an unknown candidate: it is excluded only by readable proof (another venue, a
    known other mode, another book's symbol, a status AND a config both older than the window), and
    while one lies in a window the verdict is unavailable, never accept. A status read that no
    timestamp dates is unknown too: it never counts as fresh or as coverage, yet the harm it read
    (a divergence, a disturbance) is judged and refuses.
  * a candidate is never excluded before it is fully resolved: resolve_candidate reads, and retries
    once, its classification and every timestamp, and exclude_resolved is the one exclusion. Every
    resolved field is a tagged value, Resolved(value) or Unavailable(reason), never None, and the
    scan filters nothing before resolve (a non-run name or a non-directory is a resolved fact).
  * coverage is counted in 900 s intervals over the whole window with at most 2 missed in a row.
  * verdict precedence is refused > unavailable > insufficient > accept: harm read in the window
    (any rule but unreadable, which is missing evidence) refuses it beside any unknown candidate or
    short window. Resolution is per tick; nothing unavailable on one tick carries into the next.
  * a done or final receipt is written once under a fixed name; a retry adopts it, then saves.
  * every flip and every rollback is its own rollout.sh transaction: restart-plan prints
    --txn stage-b-<book>-<flip|rollback>-<step start, compact UTC>, derived from the ledger.
  * flip refuses, in this order: containment, bad_symbol, already_flipped, mirror_not_accepted,
    mirror_sha_mismatch, stage_b_in_progress. unflip (the rollback) refuses only bad_symbol and
    not_flipped and is never blocked by containment.
  * mirror refuses, in this order: containment, bad_symbol, bad_sha, bad_request_id, already_mirrored,
    already_flipped; unmirror (its rollback) refuses bad_symbol, bad_sha, bad_request_id, bad_input,
    not_mirrored and still_flipped and is never blocked by containment. restart-plan prints a mirror
    or unmirror step's rollout exactly like a flip's.
  * ledger mutations run under one lock and land atomically; a request id replays its recorded
    result with no second write, and refuses request_id_reused on another verb, symbol, sha or
    phase. Every hosts write keeps the file's mode and owner or refuses hosts_owner_unpreserved.

Exit codes: 0 done or accept, 1 verdict refused, 2 refused or bad input, 3 insufficient evidence,
4 evidence unavailable (an unknown candidate lies in the window).
Run as root on the runner:
  /opt/leafhft/.venv/bin/python /opt/leafhft/deploy/runner/stage_b.py <verb> ...
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shlex
import stat
import sys
import tempfile
import time

try:
    import fcntl
except ImportError:  # Windows: the O_CREAT|O_EXCL lock file below
    fcntl = None

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from leafhft.parity_mirror import DIVERGENCE_CLASSES  # noqa: E402

# Equal to scripts/probe_watch.py's tuple (a test pins it); only the first, second and fourth are judged.
DISTURBANCE_KEYS = ("incumbent_refusals_by_probe", "lane_refusals_by_probe", "revision_retries",
                    "stale_snapshot_refusals")
JUDGED_DISTURBANCE = ("incumbent_refusals_by_probe", "lane_refusals_by_probe", "stale_snapshot_refusals")

DEFAULT_ETC = "/etc/leafhft"
DEFAULT_STATE_DIR = "/var/lib/leafhft/stage-b"
DEFAULT_RUNS_ROOT = "/var/lib/leafhft/runs"
DEFAULT_CONTAINMENT = "/var/lib/leafhft/CONTAINMENT"
HOSTS_NAME = "kalshi-executor-hosts"
MIRROR_HOSTS_NAME = "kalshi-parity-mirror-hosts"  # live-run.sh adds --parity-mirror for each listed book
STATUS_NAME = "kalshi-edge-status.json"
CONFIG_NAME = "config.json"
LEDGER_SCHEMA = "leafhft.stage-b.ledger.v1"
RECEIPT_SCHEMA = "leafhft.stage-b.receipt.v1"
PYTHON = "/opt/leafhft/.venv/bin/python"
RUNNER_DIR = "/opt/leafhft/deploy/runner"
REARM_GUARD_ENV = "LEAFHFT_REARM_WINDOW_GUARD"  # equal to rearm.WINDOW_GUARD_ENV (a test pins it)

MAX_WINDOWS = 256
MAX_REQUESTS = 1024
MAX_LEDGER_BYTES = 4 * 1024 * 1024
MAX_HOSTS_BYTES = 64 * 1024
MAX_HOSTS = 64
MAX_TICK_LINE = 64 * 1024
MAX_TICK_LINES = 4096
MAX_RUN_DIRS = 128
MAX_SCAN_ENTRIES = 65536
MAX_STATUS_BYTES = 1024 * 1024
MAX_CONFIG_BYTES = 64 * 1024
MAX_TEXT = 200
TICK_CADENCE_S = 900
MIN_TICK_COVERAGE = 0.75
MAX_UNCOVERED_RUN = 2  # consecutive uncovered 900 s intervals, leading and trailing runs included
STALE_STATUS_S = 180
RUN_GAP_S = 300
DEFAULT_HOURS = 24.0
MAX_HOURS = 720.0
LOCK_WAIT_S = 30.0

EXIT_OK, EXIT_VERDICT_REFUSED, EXIT_REFUSED, EXIT_INSUFFICIENT, EXIT_UNAVAILABLE = 0, 1, 2, 3, 4

# Equal to leafhft.config.VENUES and MODES (a test pins them): a run config naming one of these proves
# what the run is; anything else, or nothing, leaves it unknown.
RUN_VENUES = ("coinbase", "kraken", "binanceus", "kalshi", "kalshi-perp", "polymarket_us")
RUN_MODES = ("paper", "replay", "live")
MAX_UNKNOWN = 128  # unknown candidates reported per scan; the rest collapse into one unknown entry
RUN_NAME = "live-kalshi"  # a scan entry whose name lacks it is resolved as not_a_run

SHA_RE = re.compile(r"[0-9a-f]{40}")
TXN_RE = re.compile(r"[A-Za-z0-9._-]{1,64}")  # rollout.sh --txn
DIGEST_RE = re.compile(r"[0-9a-f]{64}")
SYMBOL_RE = re.compile(r"[A-Z0-9]{1,16}-[A-Z0-9]{1,8}")  # probe_watch.SYMBOL_RE
REQUEST_ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,119}")
WINDOW_ID_RE = re.compile(r"w\d{3}-[a-z0-9-]{1,32}-(?:mirror|flipped)")
PHASES = ("mirror", "flipped")
WINDOW_STATES = ("open", "accepted", "refused", "rearmed", "closed")
MUTATING = ("flip", "unflip", "arm", "mirror", "unmirror")
MIRROR_VERBS = ("mirror", "unmirror")  # the verbs that write kalshi-parity-mirror-hosts
STEP_OF_VERB = {"unflip": "rollback", "mirror": "mirror", "unmirror": "unmirror"}  # restart-plan steps when not flipped
RULES = ("unreadable", "stale_status", "mirror_not_running", "mirror_invalidated", "mirror_idle",
         "divergence", "run_gap", "identity_unverified", "identity_changed", "executor_mode_unconfirmed",
         "disturbance", "executor_mode_on")
IDENTITY_KEYS = ("git_sha", "config_sha", "config_digest", "dirty")


class Refused(Exception):
    """A refused action or bad input; main() prints the code and exits 2."""

    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


# --------------------------------------------------------------------------- time and values
def _utc(moment: datetime) -> datetime:
    return moment.replace(tzinfo=timezone.utc) if moment.tzinfo is None else moment.astimezone(timezone.utc)


def iso(moment: datetime) -> str:
    return _utc(moment).strftime("%Y-%m-%dT%H:%M:%SZ")


def iso_ts(stamp: float | None) -> str | None:
    return None if stamp is None else iso(datetime.fromtimestamp(stamp, timezone.utc))


def parse_iso(value) -> datetime | None:
    """An aware ISO-8601 instant in UTC, or None on anything else."""
    if type(value) is not str or not value or len(value) > 40:
        return None
    text = value[:-1] + "+00:00" if value.endswith(("Z", "z")) else value
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    return None if parsed.tzinfo is None else parsed.astimezone(timezone.utc)


def _int(value) -> int | None:
    return value if type(value) is int else None


def _text(value, cap: int = 64) -> str | None:
    return value[:cap] if type(value) is str else None


def _clip(value, cap: int = 128):
    return value[:cap] if type(value) is str else None


# --------------------------------------------------------------------------- files
class Paths:
    def __init__(self, args) -> None:
        self.etc = Path(args.etc)
        self.hosts = self.etc / HOSTS_NAME
        self.mirror_hosts = self.etc / MIRROR_HOSTS_NAME
        self.state = Path(args.state_dir)
        self.ledger = self.state / "ledger.json"
        self.lock = self.state / ".lock"
        self.receipts = self.state / "receipts"
        self.runs_root = Path(args.runs_root)
        self.containment = Path(args.containment)

    def ticks(self, window_id: str) -> Path:
        return self.state / f"ticks-{window_id}.jsonl"


_READ_FLAGS = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)


def _read_capped(path: Path, cap: int) -> bytes:
    """At most cap bytes of a regular file, never through a symlink; ValueError over the cap."""
    fd = os.open(path, _READ_FLAGS)
    with os.fdopen(fd, "rb") as stream:
        data = stream.read(cap + 1)
    if len(data) > cap:
        raise ValueError(f"{path.name} over {cap} bytes")
    return data


def _read_capped_json(path: Path, cap: int):
    return json.loads(_read_capped(path, cap))


def _write_all(fd: int, data: bytes) -> None:
    view = memoryview(data)
    while view:
        view = view[os.write(fd, view):]


def _fsync_dir(directory: Path) -> None:
    if os.name != "posix":
        return
    try:
        fd = os.open(directory, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _replace_file(path: Path, data: bytes, *, mode: int, owner, code: str) -> None:
    """Atomic replace in the same directory: temp, fsync, mode and owner set BEFORE the replace."""
    fd, temp = tempfile.mkstemp(prefix=f".{path.name}-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.chmod(temp, mode)
            if owner is not None and hasattr(os, "chown"):
                os.chown(temp, owner[0], owner[1])
        except OSError as exc:
            raise Refused(code, f"cannot keep mode {oct(mode)} and owner on {path}: {exc}") from exc
        if os.name == "posix":
            got = os.stat(temp)
            if stat.S_IMODE(got.st_mode) != mode or (
                    owner is not None and (got.st_uid, got.st_gid) != (owner[0], owner[1])):
                raise Refused(code, f"{path} would lose mode {oct(mode)} or owner {owner}")
        os.replace(temp, path)
    except BaseException:
        try:
            os.unlink(temp)
        except OSError:
            pass
        raise
    _fsync_dir(path.parent)


def _state_dir(paths: Paths, *, create: bool) -> bool:
    directory = paths.state
    if directory.is_symlink():
        raise Refused("state_dir_unavailable", f"{directory} is a symlink")
    if not directory.exists():
        if not create:
            return False
        try:
            directory.mkdir(mode=0o750)  # never parents: nothing is created outside --state-dir
        except OSError as exc:
            raise Refused("state_dir_unavailable", f"{directory}: {exc}") from exc
    if not directory.is_dir():
        raise Refused("state_dir_unavailable", f"{directory} is not a directory")
    return True


def _contained(path: Path) -> bool:
    """True when the containment marker exists or cannot be stat'ed."""
    try:
        os.lstat(path)
    except FileNotFoundError:
        return False
    except OSError:
        return True
    return True


@contextmanager
def _locked(paths: Paths):
    """One mutation at a time: flock where fcntl exists, else an O_EXCL lock file removed on exit."""
    deadline = time.monotonic() + LOCK_WAIT_S
    if fcntl is not None:
        fd = os.open(paths.lock, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        try:
            while True:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() > deadline:
                        raise Refused("locked", f"{paths.lock} held by another stage_b run") from None
                    time.sleep(0.1)
            yield
        finally:
            os.close(fd)
        return
    while True:
        try:
            os.close(os.open(paths.lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600))
            break
        except FileExistsError:
            if time.monotonic() > deadline:
                raise Refused("locked", f"{paths.lock} exists; remove it by hand only when no stage_b "
                                        "run is alive") from None
            time.sleep(0.1)
    try:
        yield
    finally:
        try:
            os.unlink(paths.lock)
        except OSError:
            pass


# --------------------------------------------------------------------------- hosts file
def _read_hosts(path: Path) -> tuple[bytes | None, list[str]]:
    """(current bytes or None when absent, the symbols in file order); refuses anything malformed."""
    try:
        info = os.lstat(path)
    except FileNotFoundError:
        return None, []
    except OSError as exc:
        raise Refused("hosts_unreadable", f"{path}: {exc}") from exc
    if stat.S_ISLNK(info.st_mode):
        raise Refused("hosts_symlink", f"{path} is a symlink")
    if not stat.S_ISREG(info.st_mode):
        raise Refused("hosts_corrupt", f"{path} is not a regular file")
    try:
        data = _read_capped(path, MAX_HOSTS_BYTES)
        text = data.decode("utf-8")
    except (OSError, ValueError) as exc:
        raise Refused("hosts_corrupt", f"{path}: {exc}") from exc
    symbols: list[str] = []
    for line in text.splitlines():
        entry = line.strip()
        if not entry or entry.startswith("#"):
            continue
        if not SYMBOL_RE.fullmatch(entry):
            raise Refused("hosts_corrupt", f"{path}: bad line {entry[:40]!r}")
        if entry not in symbols:
            if len(symbols) >= MAX_HOSTS:
                raise Refused("hosts_corrupt", f"{path}: over {MAX_HOSTS} symbols")
            symbols.append(entry)
    return data, symbols


def _hosts_add(data: bytes | None, symbol: str) -> bytes:
    data = data or b""
    if data and not data.endswith(b"\n"):
        data += b"\n"
    return data + symbol.encode("ascii") + b"\n"


def _hosts_remove(data: bytes | None, symbol: str) -> bytes:
    needle = symbol.encode("ascii")
    return b"".join(line for line in (data or b"").splitlines(keepends=True) if line.strip() != needle)


def _write_hosts(path: Path, data: bytes) -> None:
    """Keep the prior mode and owner (a new file: 0644, the directory's owner), atomically."""
    try:
        info = os.lstat(path)
    except FileNotFoundError:
        info = None
    except OSError as exc:
        raise Refused("hosts_unwritable", f"{path}: {exc}") from exc
    if info is not None and stat.S_ISLNK(info.st_mode):
        raise Refused("hosts_symlink", f"{path} is a symlink")
    try:
        if info is not None:
            mode, owner = stat.S_IMODE(info.st_mode), (info.st_uid, info.st_gid)
        else:
            parent = os.stat(path.parent)
            mode, owner = 0o644, (parent.st_uid, parent.st_gid)
        _replace_file(path, data, mode=mode, owner=owner, code="hosts_owner_unpreserved")
    except OSError as exc:
        raise Refused("hosts_unwritable", f"{path}: {exc}") from exc


# --------------------------------------------------------------------------- ledger
def _new_ledger() -> dict:
    return {"schema": LEDGER_SCHEMA, "windows": [], "flips": {}, "mirrors": {}, "requests": {}}


def _corrupt(detail: str) -> Refused:
    return Refused("ledger_corrupt", detail)


def _validate_ledger(ledger) -> dict:
    if not isinstance(ledger, dict) or ledger.get("schema") != LEDGER_SCHEMA:
        raise _corrupt("not a stage-b ledger")
    windows, flips, requests = ledger.get("windows"), ledger.get("flips"), ledger.get("requests")
    if not isinstance(windows, list) or len(windows) > MAX_WINDOWS:
        raise _corrupt("windows")
    if not isinstance(flips, dict) or not isinstance(requests, dict) or len(requests) > MAX_REQUESTS:
        raise _corrupt("flips or requests")
    seen = set()
    for window in windows:
        if (not isinstance(window, dict) or type(window.get("id")) is not str
                or not WINDOW_ID_RE.fullmatch(window["id"]) or window["id"] in seen
                or type(window.get("symbol")) is not str or not SYMBOL_RE.fullmatch(window["symbol"])
                or window.get("phase") not in PHASES or window.get("state") not in WINDOW_STATES
                or type(window.get("sha")) is not str or not SHA_RE.fullmatch(window["sha"])
                or type(window.get("config_digest")) is not str
                or not DIGEST_RE.fullmatch(window["config_digest"])
                or parse_iso(window.get("armed_at")) is None):
            raise _corrupt(f"window {str(window)[:80]}")
        seen.add(window["id"])
    for symbol, row in flips.items():
        if not SYMBOL_RE.fullmatch(symbol) or not isinstance(row, dict) or parse_iso(row.get("at")) is None:
            raise _corrupt(f"flip {symbol[:40]}")
    mirrors = ledger.setdefault("mirrors", {})  # a ledger written before the mirror verb has none
    if not isinstance(mirrors, dict):
        raise _corrupt("mirrors")
    for symbol, row in mirrors.items():
        if not SYMBOL_RE.fullmatch(symbol) or not isinstance(row, dict) or parse_iso(row.get("at")) is None:
            raise _corrupt(f"mirror {symbol[:40]}")
    for request_id, row in requests.items():
        if (not REQUEST_ID_RE.fullmatch(request_id) or not isinstance(row, dict)
                or row.get("verb") not in MUTATING or row.get("state") not in ("pending", "done")):
            raise _corrupt(f"request {request_id[:40]}")
    return ledger


def _load_ledger(paths: Paths) -> dict:
    try:
        raw = _read_capped(paths.ledger, MAX_LEDGER_BYTES)
    except FileNotFoundError:
        return _new_ledger()
    except (OSError, ValueError) as exc:
        raise _corrupt(f"{paths.ledger}: {exc}") from exc
    try:
        ledger = json.loads(raw)
    except ValueError as exc:
        raise _corrupt(f"{paths.ledger}: {exc}") from exc
    return _validate_ledger(ledger)


def _save_ledger(paths: Paths, ledger: dict) -> None:
    data = (json.dumps(ledger, indent=1, sort_keys=True) + "\n").encode("utf-8")
    if len(data) > MAX_LEDGER_BYTES:
        raise Refused("ledger_full", f"ledger would exceed {MAX_LEDGER_BYTES} bytes")
    _replace_file(paths.ledger, data, mode=0o640, owner=None, code="ledger_unwritable")


def _latest(ledger: dict, symbol: str, phase: str, state: str) -> dict | None:
    for window in reversed(ledger["windows"]):
        if window["symbol"] == symbol and window["phase"] == phase and window["state"] == state:
            return window
    return None


def _in_progress(ledger: dict, hosts: list[str]) -> list[str]:
    """Flipped symbols without an accepted flipped window armed at or after their flip on the flip's sha."""
    blocked = []
    for symbol in hosts:
        flip = ledger["flips"].get(symbol)
        flipped_at = parse_iso(flip.get("at")) if isinstance(flip, dict) else None
        flip_sha = flip.get("sha") if isinstance(flip, dict) else None
        proven = flipped_at is not None and type(flip_sha) is str and any(
            window["symbol"] == symbol and window["phase"] == "flipped" and window["state"] == "accepted"
            and parse_iso(window["armed_at"]) >= flipped_at and window["sha"] == flip_sha
            for window in ledger["windows"])
        if not proven:
            blocked.append(symbol)
    return blocked


def _replay(ledger: dict, request_id: str, verb: str, symbol: str, key: str) -> dict | None:
    row = ledger["requests"].get(request_id)
    if row is None:
        return None
    if row.get("verb") != verb or row.get("symbol") != symbol or row.get("key") != key:
        raise Refused("request_id_reused",
                      f"{request_id} was {row.get('verb')} {row.get('symbol')} {row.get('key')}")
    return row


def _pending_other(ledger: dict, request_id: str) -> None:
    for other, row in ledger["requests"].items():
        if row.get("state") == "pending" and other != request_id:
            raise Refused("request_pending", f"{other} ({row.get('verb')} {row.get('symbol')}) is pending; "
                                             "rerun it with the same --request-id first")


def _request_room(ledger: dict) -> None:
    if len(ledger["requests"]) >= MAX_REQUESTS:
        raise Refused("ledger_full", f"{MAX_REQUESTS} request ids recorded")


# --------------------------------------------------------------------------- receipts
def _receipt_body(now: datetime, verb: str, symbol, **fields) -> dict:
    body = {"schema": RECEIPT_SCHEMA, "at": iso(now), "verb": verb, "symbol": _clip(symbol, 64),
            "sha": None, "request_id": None, "window": None, "hosts_before": None, "hosts_after": None,
            "outcome": None, "refusals": []}
    body.update(fields)
    return body


def _receipt(paths: Paths, now: datetime, body: dict) -> Path:
    """Create only: <state-dir>/receipts/<utc>-<verb>-<symbol>.json, never overwritten."""
    directory = paths.receipts
    if directory.is_symlink():
        raise Refused("receipts_unwritable", f"{directory} is a symlink")
    directory.mkdir(mode=0o750, exist_ok=True)
    symbol = body.get("symbol")
    safe = symbol if type(symbol) is str and SYMBOL_RE.fullmatch(symbol) else "invalid"
    stamp = _utc(now).strftime("%Y%m%dT%H%M%SZ")
    data = (json.dumps(body, indent=2, sort_keys=True) + "\n").encode("utf-8")
    flags = (os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
             | getattr(os, "O_BINARY", 0))
    for suffix in range(1, 100):
        name = f"{stamp}-{body['verb']}-{safe}" + ("" if suffix == 1 else f"-{suffix}") + ".json"
        try:
            fd = os.open(directory / name, flags, 0o640)
        except FileExistsError:
            continue
        try:
            _write_all(fd, data)
            os.fsync(fd)
        finally:
            os.close(fd)
        return directory / name
    raise Refused("receipt_collision", f"99 receipts named {stamp}-{body['verb']}-{safe}")


def _receipts_dir(paths: Paths) -> Path:
    directory = paths.receipts
    if directory.is_symlink():
        raise Refused("receipts_unwritable", f"{directory} is a symlink")
    directory.mkdir(mode=0o750, exist_ok=True)
    return directory


def _read_receipt(paths: Paths, name: str) -> dict | None:
    """receipts/<name>.json as a dict, None when absent; refuses receipt_conflict when unreadable."""
    path = paths.receipts / f"{name}.json"
    try:
        body = _read_capped_json(path, MAX_STATUS_BYTES)
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as exc:
        raise Refused("receipt_conflict", f"{path.name} unreadable: {type(exc).__name__}") from exc
    if not isinstance(body, dict):
        raise Refused("receipt_conflict", f"{path.name} is not a receipt object")
    return body


def _receipt_once(paths: Paths, name: str, body: dict) -> tuple[Path, dict | None]:
    """Create receipts/<name>.json exactly once: (path, None) when this call wrote it, else
    (path, the existing body) for the caller to match. Written to a temp file and hard-linked into
    place, so the named receipt is never partial and never overwritten."""
    directory = _receipts_dir(paths)
    path = directory / f"{name}.json"
    data = (json.dumps(body, indent=2, sort_keys=True) + "\n").encode("utf-8")
    fd, temp = tempfile.mkstemp(prefix=f".{name}-", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temp, 0o640)
        try:
            os.link(temp, path)
        except FileExistsError:
            existing = _read_receipt(paths, name)
            if existing is None:
                raise Refused("receipt_conflict", f"{path.name} vanished while adopting it") from None
            return path, existing
    finally:
        try:
            os.unlink(temp)
        except OSError:
            pass
    _fsync_dir(directory)
    return path, None


def _match_receipt(name: str, existing: dict, expected: dict) -> None:
    """Refuses receipt_conflict unless every expected field of an adopted receipt matches."""
    for key, value in expected.items():
        if existing.get(key) != value:
            raise Refused("receipt_conflict", f"{name}.json records {key} {str(existing.get(key))[:80]!r}, "
                                              f"this run {str(value)[:80]!r}")


def _refused_receipt(args, paths: Paths, now: datetime, exc: Refused) -> None:
    """Best effort: a refusal never fails harder because its receipt could not be written."""
    try:
        _, hosts = _read_hosts(paths.mirror_hosts if args.command in MIRROR_VERBS else paths.hosts)
    except (Refused, OSError):
        hosts = None
    body = _receipt_body(now, args.command, getattr(args, "symbol", None),
                         sha=_clip(getattr(args, "sha", None), 64),
                         request_id=_clip(getattr(args, "request_id", None)),
                         phase=getattr(args, "phase", None), hosts_before=hosts, hosts_after=hosts,
                         outcome="refused", refusals=[exc.code], detail=exc.detail[:MAX_TEXT * 2])
    try:
        if _state_dir(paths, create=True):
            _receipt(paths, now, body)
    except (Refused, OSError):
        pass


# --------------------------------------------------------------------------- output
def _unit(symbol: str) -> str:
    return f"leafhft-live@kalshi-{symbol.lower()}.service"


def _txn(symbol: str, step: str, started) -> str:
    """rollout.sh --txn for one Stage B step: stage-b-<book>-<flip|rollback>-<step start, compact UTC>.
    Derived from the step's recorded start, never free text, so a re-print resumes its own transaction."""
    moment = parse_iso(started)
    if moment is None:
        raise _corrupt(f"{step} of {symbol} has no readable start")
    tag = f"stage-b-{symbol.lower()}-{step}-{moment.strftime('%Y%m%dT%H%M%SZ')}"
    if not TXN_RE.fullmatch(tag):
        raise Refused("bad_txn", tag[:MAX_TEXT])
    return tag


def _commands(verb: str, symbol: str, sha: str, request_id: str) -> list[str]:
    """Printed for the runner train with the operator's yes; this tool runs none of them."""
    unit = _unit(symbol)
    # restart-plan prints the guarded one-book rollout (rollout.sh re-acks with the guard itself);
    # the rearm lines recover a rollout that stopped with the gate closed.
    rows = [f"{PYTHON} {RUNNER_DIR}/stage_b.py restart-plan --symbol {symbol} --sha {sha}",
            f"python3 {RUNNER_DIR}/rearm.py --plan {unit}",
            f"{REARM_GUARD_ENV}=1 python3 {RUNNER_DIR}/rearm.py --apply {unit}"]
    if verb == "flip":
        rows.append(f"{PYTHON} {RUNNER_DIR}/stage_b.py arm --symbol {symbol} --phase flipped "
                    f"--sha {sha} --request-id {request_id}-arm")
    if verb == "mirror":
        rows.append(f"{PYTHON} {RUNNER_DIR}/stage_b.py arm --symbol {symbol} --phase mirror "
                    f"--sha {sha} --request-id {request_id}-arm")
    return rows


def _print_result(result: dict) -> int:
    print(json.dumps(result, sort_keys=True))
    commands = result.get("commands") or []
    if commands:
        print("next, by the runner train with the operator's yes (stage_b ran none of these):")
        for command in commands:
            print(f"  {command}")
    return EXIT_OK


def _check_symbol(symbol) -> None:
    if type(symbol) is not str or not SYMBOL_RE.fullmatch(symbol):
        raise Refused("bad_symbol", f"{str(symbol)[:40]!r} is not a book symbol like BTC-15M")


def _check_sha(sha) -> None:
    if type(sha) is not str or not SHA_RE.fullmatch(sha):
        raise Refused("bad_sha", "--sha must be 40 lowercase hex characters")


def _check_request_id(request_id) -> None:
    if type(request_id) is not str or not REQUEST_ID_RE.fullmatch(request_id):
        raise Refused("bad_request_id", "--request-id must match [A-Za-z0-9][A-Za-z0-9_.:-]{0,119}")


# --------------------------------------------------------------------------- flip and unflip
def _hosts_change(paths: Paths, ledger: dict, request_id: str, data: bytes, *, path: Path | None = None) -> None:
    """Write a hosts file (by default the executor hosts file); on a failed write the pending request
    is dropped (the file is unchanged)."""
    try:
        _write_hosts(paths.hosts if path is None else path, data)
    except Refused:
        ledger["requests"].pop(request_id, None)
        try:
            _save_ledger(paths, ledger)
        except (Refused, OSError):
            pass
        raise


def cmd_flip(args, paths: Paths, now: datetime) -> int:
    symbol, sha, request_id = args.symbol, args.sha, args.request_id
    if _contained(paths.containment):
        raise Refused("containment", f"{paths.containment} exists")
    _check_symbol(symbol)
    _check_sha(sha)
    _check_request_id(request_id)
    with _locked(paths):
        ledger = _load_ledger(paths)
        before_bytes, before = _read_hosts(paths.hosts)
        row = _replay(ledger, request_id, "flip", symbol, sha)
        if row is not None and row["state"] == "done":
            return _print_result(row["result"])
        if row is None:
            _pending_other(ledger, request_id)
            if symbol in before:
                raise Refused("already_flipped", f"{symbol} is in {paths.hosts}")
            mirror = _latest(ledger, symbol, "mirror", "accepted")
            if mirror is None:
                raise Refused("mirror_not_accepted", f"no accepted mirror window for {symbol}")
            if mirror["sha"] != sha:
                raise Refused("mirror_sha_mismatch", f"mirror window {mirror['id']} accepted sha {mirror['sha']}")
            blocked = _in_progress(ledger, before)
            if blocked:
                raise Refused("stage_b_in_progress",
                              "no accepted flipped window after the flip of " + ", ".join(blocked))
            _request_room(ledger)
            row = {"verb": "flip", "symbol": symbol, "key": sha, "state": "pending", "at": iso(now),
                   "hosts_before": before, "window": mirror["id"],
                   "mirror_config_digest": mirror.get("config_digest")}
            ledger["requests"][request_id] = row
            _save_ledger(paths, ledger)
        if symbol not in before:
            _hosts_change(paths, ledger, request_id, _hosts_add(before_bytes, symbol))
        _, after = _read_hosts(paths.hosts)
        if symbol not in after or [s for s in after if s != symbol] != [s for s in before if s != symbol]:
            raise Refused("hosts_readback", f"{paths.hosts} reads {after}")
        mirror_digest = row.get("mirror_config_digest")
        txn = _txn(symbol, "flip", row.get("at"))
        ledger["flips"][symbol] = {"at": iso(now), "sha": sha, "request_id": request_id,
                                   "mirror_config_digest": mirror_digest, "txn": txn}
        result = {"verb": "flip", "outcome": "done", "symbol": symbol, "sha": sha, "request_id": request_id,
                  "window": row.get("window"), "mirror_config_digest": mirror_digest,
                  "hosts_before": row.get("hosts_before"), "hosts_after": after, "txn": txn,
                  "unit": _unit(symbol), "commands": _commands("flip", symbol, sha, request_id)}
        name = f"flip-{request_id}"
        receipt, existing = _receipt_once(paths, name, _receipt_body(
            now, "flip", symbol, sha=sha, request_id=request_id, window=row.get("window"),
            mirror_config_digest=mirror_digest, hosts_before=row.get("hosts_before"), hosts_after=after,
            outcome="done", txn=txn, commands=result["commands"]))
        if existing is not None:
            _match_receipt(name, existing, {"verb": "flip", "symbol": symbol, "sha": sha, "outcome": "done"})
        result["receipt"] = receipt.name
        row.update(state="done", result=result)
        _save_ledger(paths, ledger)
    return _print_result(result)


def cmd_unflip(args, paths: Paths, now: datetime) -> int:
    symbol, sha, request_id, reason = args.symbol, args.sha, args.request_id, args.reason
    _check_symbol(symbol)
    _check_sha(sha)
    _check_request_id(request_id)
    if type(reason) is not str or not reason.strip() or len(reason) > 500:
        raise Refused("bad_input", "--reason must be 1 to 500 characters")
    with _locked(paths):
        ledger = _load_ledger(paths)
        before_bytes, before = _read_hosts(paths.hosts)
        row = _replay(ledger, request_id, "unflip", symbol, sha)
        if row is not None and row["state"] == "done":
            return _print_result(row["result"])
        superseded = []
        if row is None:
            if symbol not in before:
                raise Refused("not_flipped", f"{symbol} is not in {paths.hosts}")
            # The rollback always goes through: a pending, never completed request on this symbol
            # is dropped so it cannot re-add the book after the unflip.
            for other, pending in list(ledger["requests"].items()):
                if pending.get("state") == "pending" and pending.get("symbol") == symbol:
                    superseded.append(other)
                    del ledger["requests"][other]
            _request_room(ledger)
            row = {"verb": "unflip", "symbol": symbol, "key": sha, "state": "pending", "at": iso(now),
                   "hosts_before": before, "reason": reason, "superseded": superseded}
            ledger["requests"][request_id] = row
            _save_ledger(paths, ledger)
        if symbol in before:
            _hosts_change(paths, ledger, request_id, _hosts_remove(before_bytes, symbol))
        _, after = _read_hosts(paths.hosts)
        if symbol in after or after != [s for s in before if s != symbol]:
            raise Refused("hosts_readback", f"{paths.hosts} reads {after}")
        ledger["flips"].pop(symbol, None)
        closed = []
        for window in ledger["windows"]:
            if window["symbol"] == symbol and window["phase"] == "flipped" and window["state"] == "open":
                window.update(state="closed", closed_at=iso(now), closed_by=request_id)
                closed.append(window["id"])
        txn = _txn(symbol, "rollback", row.get("at"))
        result = {"verb": "unflip", "outcome": "done", "symbol": symbol, "sha": sha, "request_id": request_id,
                  "reason": row.get("reason"), "closed_windows": closed, "superseded": row.get("superseded", []),
                  "hosts_before": row.get("hosts_before"), "hosts_after": after, "unit": _unit(symbol),
                  "txn": txn, "commands": _commands("unflip", symbol, sha, request_id)}
        name = f"unflip-{request_id}"
        receipt, existing = _receipt_once(paths, name, _receipt_body(
            now, "unflip", symbol, sha=sha, request_id=request_id, window=closed[0] if closed else None,
            hosts_before=row.get("hosts_before"), hosts_after=after, outcome="done", reason=row.get("reason"),
            closed_windows=closed, txn=txn, commands=result["commands"]))
        if existing is not None:
            _match_receipt(name, existing, {"verb": "unflip", "symbol": symbol, "sha": sha, "outcome": "done"})
        result["receipt"] = receipt.name
        row.update(state="done", result=result)
        _save_ledger(paths, ledger)
    return _print_result(result)


# --------------------------------------------------------------------------- mirror and unmirror
def cmd_mirror(args, paths: Paths, now: datetime) -> int:
    """Adds one book to kalshi-parity-mirror-hosts so its next restart runs the C15 parity mirror."""
    symbol, sha, request_id = args.symbol, args.sha, args.request_id
    if _contained(paths.containment):
        raise Refused("containment", f"{paths.containment} exists")
    _check_symbol(symbol)
    _check_sha(sha)
    _check_request_id(request_id)
    with _locked(paths):
        ledger = _load_ledger(paths)
        before_bytes, before = _read_hosts(paths.mirror_hosts)
        _, executor = _read_hosts(paths.hosts)
        row = _replay(ledger, request_id, "mirror", symbol, sha)
        if row is not None and row["state"] == "done":
            return _print_result(row["result"])
        if row is None:
            _pending_other(ledger, request_id)
            if symbol in before:
                raise Refused("already_mirrored", f"{symbol} is in {paths.mirror_hosts}")
            if symbol in executor:
                raise Refused("already_flipped", f"{symbol} is in {paths.hosts}; executor mode already runs "
                                                 "the mirror")
            _request_room(ledger)
            row = {"verb": "mirror", "symbol": symbol, "key": sha, "state": "pending", "at": iso(now),
                   "hosts_before": before}
            ledger["requests"][request_id] = row
            _save_ledger(paths, ledger)
        if symbol not in before:
            _hosts_change(paths, ledger, request_id, _hosts_add(before_bytes, symbol), path=paths.mirror_hosts)
        _, after = _read_hosts(paths.mirror_hosts)
        if symbol not in after or [s for s in after if s != symbol] != [s for s in before if s != symbol]:
            raise Refused("hosts_readback", f"{paths.mirror_hosts} reads {after}")
        txn = _txn(symbol, "mirror", row.get("at"))
        ledger["mirrors"][symbol] = {"at": iso(now), "sha": sha, "request_id": request_id, "txn": txn}
        result = {"verb": "mirror", "outcome": "done", "symbol": symbol, "sha": sha, "request_id": request_id,
                  "hosts_file": MIRROR_HOSTS_NAME, "hosts_before": row.get("hosts_before"), "hosts_after": after,
                  "txn": txn, "unit": _unit(symbol), "commands": _commands("mirror", symbol, sha, request_id)}
        name = f"mirror-{request_id}"
        receipt, existing = _receipt_once(paths, name, _receipt_body(
            now, "mirror", symbol, sha=sha, request_id=request_id, hosts_file=MIRROR_HOSTS_NAME,
            hosts_before=row.get("hosts_before"), hosts_after=after, outcome="done", txn=txn,
            unit=_unit(symbol), commands=result["commands"]))
        if existing is not None:
            _match_receipt(name, existing, {"verb": "mirror", "symbol": symbol, "sha": sha, "outcome": "done"})
        result["receipt"] = receipt.name
        row.update(state="done", result=result)
        _save_ledger(paths, ledger)
    return _print_result(result)


def cmd_unmirror(args, paths: Paths, now: datetime) -> int:
    """Removes one book from kalshi-parity-mirror-hosts and closes its open mirror window; never blocked
    by containment, because it only lowers what the book runs."""
    symbol, sha, request_id, reason = args.symbol, args.sha, args.request_id, args.reason
    _check_symbol(symbol)
    _check_sha(sha)
    _check_request_id(request_id)
    if type(reason) is not str or not reason.strip() or len(reason) > 500:
        raise Refused("bad_input", "--reason must be 1 to 500 characters")
    with _locked(paths):
        ledger = _load_ledger(paths)
        before_bytes, before = _read_hosts(paths.mirror_hosts)
        _, executor = _read_hosts(paths.hosts)
        row = _replay(ledger, request_id, "unmirror", symbol, sha)
        if row is not None and row["state"] == "done":
            return _print_result(row["result"])
        superseded = []
        if row is None:
            if symbol not in before:
                raise Refused("not_mirrored", f"{symbol} is not in {paths.mirror_hosts}")
            if symbol in executor:
                raise Refused("still_flipped", f"{symbol} is in {paths.hosts}; unflip it first, executor mode "
                                               "keeps the mirror on")
            # A pending, never completed mirror of this symbol is dropped so it cannot re-add the book.
            for other, pending in list(ledger["requests"].items()):
                if (pending.get("state") == "pending" and pending.get("symbol") == symbol
                        and pending.get("verb") == "mirror"):
                    superseded.append(other)
                    del ledger["requests"][other]
            _request_room(ledger)
            row = {"verb": "unmirror", "symbol": symbol, "key": sha, "state": "pending", "at": iso(now),
                   "hosts_before": before, "reason": reason, "superseded": superseded}
            ledger["requests"][request_id] = row
            _save_ledger(paths, ledger)
        if symbol in before:
            _hosts_change(paths, ledger, request_id, _hosts_remove(before_bytes, symbol), path=paths.mirror_hosts)
        _, after = _read_hosts(paths.mirror_hosts)
        if symbol in after or after != [s for s in before if s != symbol]:
            raise Refused("hosts_readback", f"{paths.mirror_hosts} reads {after}")
        ledger["mirrors"].pop(symbol, None)
        closed = []
        for window in ledger["windows"]:
            if window["symbol"] == symbol and window["phase"] == "mirror" and window["state"] == "open":
                window.update(state="closed", closed_at=iso(now), closed_by=request_id)
                closed.append(window["id"])
        txn = _txn(symbol, "unmirror", row.get("at"))
        result = {"verb": "unmirror", "outcome": "done", "symbol": symbol, "sha": sha, "request_id": request_id,
                  "reason": row.get("reason"), "closed_windows": closed, "superseded": row.get("superseded", []),
                  "hosts_file": MIRROR_HOSTS_NAME, "hosts_before": row.get("hosts_before"), "hosts_after": after,
                  "unit": _unit(symbol), "txn": txn, "commands": _commands("unmirror", symbol, sha, request_id)}
        name = f"unmirror-{request_id}"
        receipt, existing = _receipt_once(paths, name, _receipt_body(
            now, "unmirror", symbol, sha=sha, request_id=request_id, window=closed[0] if closed else None,
            hosts_file=MIRROR_HOSTS_NAME, hosts_before=row.get("hosts_before"), hosts_after=after,
            outcome="done", reason=row.get("reason"), closed_windows=closed, superseded=row.get("superseded", []),
            unit=_unit(symbol), txn=txn, commands=result["commands"]))
        if existing is not None:
            _match_receipt(name, existing, {"verb": "unmirror", "symbol": symbol, "sha": sha, "outcome": "done"})
        result["receipt"] = receipt.name
        row.update(state="done", result=result)
        _save_ledger(paths, ledger)
    return _print_result(result)


# --------------------------------------------------------------------------- identity
def _sha_or_none(value) -> str | None:
    return value if type(value) is str and SHA_RE.fullmatch(value) else None


def _identity(run: dict, status) -> dict:
    """The identity a run's own files report; a field that cannot be read is None, never guessed.

    git_sha and dirty from the status build block (leafhft build_identity()), config_sha and
    config_digest from config.json's build.git_sha and digest (EngineConfig.digest())."""
    build = status.get("build") if isinstance(status, dict) else None
    build = build if isinstance(build, dict) else {}
    config = _value(run.get("config"))
    config = config if isinstance(config, dict) else {}
    config_build = config.get("build") if isinstance(config.get("build"), dict) else {}
    digest, dirty = config.get("digest"), build.get("dirty")
    return {"git_sha": _sha_or_none(build.get("git_sha")), "config_sha": _sha_or_none(config_build.get("git_sha")),
            "config_digest": digest if type(digest) is str and DIGEST_RE.fullmatch(digest) else None,
            "dirty": dirty if type(dirty) is bool else None}


def _arm_identity(paths: Paths, symbol: str, sha: str, now: datetime) -> dict:
    """The identity of the book's newest fresh run; refuses identity_unreadable or identity_sha_mismatch.

    One scan of --runs-root. The caller's --sha is an assertion against it, never the source."""
    runs, _gaps, error = _scan_runs(paths.runs_root)
    moment = now.timestamp()
    dated = [(_value(run["status_mtime"]), run["name"], run) for run in runs if run["symbol"] == symbol]
    fresh = [row for row in dated if row[0] is not None and moment - row[0] <= STALE_STATUS_S]
    if not fresh:
        raise Refused("identity_unreadable", f"no run of {symbol} with a status at most {STALE_STATUS_S} s old"
                                             + (f" ({error})" if error else ""))
    run = max(fresh, key=lambda row: (row[0], row[1]))[2]
    where = run["name"][:MAX_TEXT]
    try:
        status = _read_capped_json(run["path"] / STATUS_NAME, MAX_STATUS_BYTES)
    except (OSError, ValueError) as exc:
        raise Refused("identity_unreadable", f"{where}: status unreadable ({type(exc).__name__})") from exc
    if not isinstance(status, dict):
        raise Refused("identity_unreadable", f"{where}: status is not an object")
    observed = _identity(run, status)
    missing = [key for key in IDENTITY_KEYS if observed[key] is None]
    if missing:
        raise Refused("identity_unreadable", f"{where}: {', '.join(missing)} unreadable")
    if observed["dirty"] is not False:
        raise Refused("identity_unreadable", f"{where}: the running build is dirty")
    if observed["git_sha"] != observed["config_sha"]:
        raise Refused("identity_unreadable", f"{where}: status sha {observed['git_sha']} but config.json "
                                             f"sha {observed['config_sha']}")
    if observed["git_sha"] != sha:
        raise Refused("identity_sha_mismatch", f"{where} runs {observed['git_sha']}, not --sha {sha}")
    return {**observed, "run": run["name"][:MAX_TEXT]}


# --------------------------------------------------------------------------- arm
def cmd_arm(args, paths: Paths, now: datetime) -> int:
    symbol, phase, sha, request_id = args.symbol, args.phase, args.sha, args.request_id
    _check_symbol(symbol)
    if phase not in PHASES:
        raise Refused("bad_input", "--phase must be mirror or flipped")
    _check_sha(sha)
    _check_request_id(request_id)
    key = f"{sha}:{phase}"
    with _locked(paths):
        ledger = _load_ledger(paths)
        _, hosts = _read_hosts(paths.hosts)
        row = _replay(ledger, request_id, "arm", symbol, key)
        if row is not None:
            return _print_result(row["result"])
        if phase == "flipped" and symbol not in hosts:
            raise Refused("not_flipped", f"{symbol} is not in {paths.hosts}")
        if phase == "mirror" and symbol in hosts:
            raise Refused("already_flipped", f"{symbol} is in {paths.hosts}")
        observed = _arm_identity(paths, symbol, sha, now)
        windows = ledger["windows"]
        if len(windows) >= MAX_WINDOWS:
            raise Refused("ledger_full", f"{MAX_WINDOWS} windows recorded")
        _request_room(ledger)
        replaced = []
        for window in windows:
            if window["symbol"] == symbol and window["phase"] == phase and window["state"] == "open":
                window.update(state="rearmed", rearmed_at=iso(now), rearmed_by=request_id)
                replaced.append(window["id"])
        # A flipped window carries the rollout transaction of the flip it judges, through to its verdict.
        flip = ledger["flips"].get(symbol) if phase == "flipped" else None
        txn = flip.get("txn") if isinstance(flip, dict) and type(flip.get("txn")) is str else None
        window = {"id": f"w{len(windows) + 1:03d}-{symbol.lower()}-{phase}", "symbol": symbol, "phase": phase,
                  "sha": observed["git_sha"], "config_digest": observed["config_digest"],
                  "identity_run": observed["run"], "armed_at": iso(now), "request_id": request_id,
                  "state": "open", "verdict_at": None, "txn": txn}
        windows.append(window)
        result = {"verb": "arm", "outcome": "done", "symbol": symbol, "phase": phase, "sha": window["sha"],
                  "config_digest": window["config_digest"], "identity_run": window["identity_run"],
                  "request_id": request_id, "window": window["id"], "armed_at": window["armed_at"],
                  "rearmed": replaced, "txn": txn}
        name = f"arm-{request_id}"
        receipt, existing = _receipt_once(paths, name, _receipt_body(
            now, "arm", symbol, sha=window["sha"], config_digest=window["config_digest"],
            identity_run=window["identity_run"], request_id=request_id, window=window["id"], phase=phase,
            hosts_before=hosts, hosts_after=hosts, outcome="done", rearmed=replaced, txn=txn))
        if existing is not None:
            _match_receipt(name, existing, {"window": window["id"], "sha": window["sha"], "phase": phase,
                                            "config_digest": window["config_digest"]})
        result["receipt"] = receipt.name
        ledger["requests"][request_id] = {"verb": "arm", "symbol": symbol, "key": key, "state": "done",
                                          "at": iso(now), "result": result}
        _save_ledger(paths, ledger)
    return _print_result(result)


# --------------------------------------------------------------------------- tick
class _Mark:
    """A resolved value that is not data: ABSENT (proven gone) or INVALID (read twice, unparsable)."""

    def __init__(self, name: str) -> None:
        self.name = name

    def __repr__(self) -> str:
        return self.name


ABSENT = _Mark("ABSENT")
INVALID = _Mark("INVALID")


@dataclass(frozen=True)
class Resolved:
    """A field read (retried once on failure): a value, ABSENT only when both reads and an lstat agree
    the file is gone, or INVALID when both reads returned content that does not parse."""
    value: object


@dataclass(frozen=True)
class Unavailable:
    """A field no read established within the retry budget. It keeps its candidate: inside every
    window, an unknown line, a judge that says unavailable."""
    reason: str


TIME_FIELDS = ("status_mtime", "run_started", "dir_mtime")  # the tagged timestamps a candidate carries


def _value(field):
    """A tagged field's data for a consumer or a report: the value read, else None (unavailable, absent
    or invalid). A report's null, never a resolution: exclusion reads the tags themselves."""
    if isinstance(field, Resolved) and field.value is not ABSENT and field.value is not INVALID:
        return field.value
    return None


def _resolve_read(read, path: Path, label: str):
    """THE retry for every resolved read: read(path), once more on any failure. Resolved(value);
    Resolved(INVALID) when the last read raised ValueError; Resolved(ABSENT) when the last read raised
    FileNotFoundError and an lstat confirms the path is gone; Unavailable otherwise: the exception name,
    or `<label>_failed_after_retry` when the path exists yet both reads missed it."""
    failure = None
    for _attempt in range(2):
        try:
            return Resolved(read(path))
        except FileNotFoundError:
            failure = None
        except OSError as exc:
            failure = type(exc).__name__
        except ValueError:
            failure = INVALID
    if failure is INVALID:
        return Resolved(INVALID)
    if failure is not None:
        return Unavailable(failure)
    try:
        os.lstat(path)
    except FileNotFoundError:
        return Resolved(ABSENT)
    except OSError as exc:
        return Unavailable(type(exc).__name__)
    return Unavailable(f"{label}_failed_after_retry")


def _stat_mtime(path: Path) -> float:
    return path.stat().st_mtime


def _read_config(path: Path):
    return _read_capped_json(path, MAX_CONFIG_BYTES)


def _mtime(path: Path) -> tuple[float | None, str | None]:
    """(mtime, None); (None, None) when the file does not exist; (None, error) when stat raises otherwise."""
    try:
        return path.stat().st_mtime, None
    except FileNotFoundError:
        return None, None
    except OSError as exc:
        return None, type(exc).__name__


def _classify(config) -> tuple[str, str | None]:
    """What a run config proves: ('live', symbol) a live Kalshi run of a valid symbol, ('other', None)
    readable proof of another venue or a known other mode, ('unreadable', reason) no config or no
    valid symbol on a live Kalshi config, ('unknown', reason) a config that cannot be classified."""
    if not isinstance(config, dict):
        return "unreadable", "config_unreadable"
    venue = config.get("venue")
    if venue is None:
        return "unknown", "venue_missing"
    if type(venue) is not str or venue not in RUN_VENUES:
        return "unknown", "venue_unknown"
    if venue != "kalshi":
        return "other", None
    if "mode" in config:  # a config with no mode key predates the field and is live
        mode = config["mode"]
        if type(mode) is not str or mode not in RUN_MODES:
            return "unknown", "mode_unknown"
        if mode != "live":
            return "other", None
    symbol = config.get("symbol")
    if type(symbol) is not str or not SYMBOL_RE.fullmatch(symbol):
        return "unreadable", "config_symbol_unreadable"
    return "live", symbol


def _resolve_mtime(path: Path):
    """A file's mtime as a tagged value: Resolved(mtime), Resolved(ABSENT) (both stats and an lstat
    agree it is gone), or Unavailable (a stat error, or stat_failed_after_retry when the file exists
    yet both stats failed). Never None."""
    return _resolve_read(_stat_mtime, path, "stat")


def _resolve_is_dir(entry):
    """Whether a scan entry is a directory, as a tagged value: entry.is_dir(follow_symlinks=False)
    retried once when it says no or raises; a no twice is Resolved(False) only when an lstat agrees
    (not a directory, or gone), else Unavailable (is_dir_failed_after_retry or the error's name)."""
    failure = None
    for _attempt in range(2):
        try:
            if entry.is_dir(follow_symlinks=False):
                return Resolved(True)
            failure = None
        except OSError as exc:
            failure = type(exc).__name__
    if failure is not None:
        return Unavailable(failure)
    try:
        mode = os.lstat(entry.path).st_mode
    except FileNotFoundError:
        return Resolved(False)
    except OSError as exc:
        return Unavailable(type(exc).__name__)
    return Unavailable("is_dir_failed_after_retry") if stat.S_ISDIR(mode) else Resolved(False)


def _resolve_times(entry) -> dict:
    """The first half of resolve_candidate, run for EVERY entry the scan meets before anything about it
    is judged: its name, its directory type, then its timestamps, each a tagged value.

    A name that is not a run name, or an entry proven not a directory, comes back fully resolved as kind
    not_a_run (exclude_resolved drops it on that fact); a run-named entry whose type cannot be read comes
    back resolved as unknown. Otherwise stamp is the newest resolved timestamp (the dir's own mtime
    when neither run file exists, since creating one moves it), and None while any timestamp is
    unavailable, which puts the candidate inside every window."""
    name, path = entry.name, Path(entry.path)
    if RUN_NAME not in name:
        return _entry_candidate(name, path, Unavailable("not_read"), "not_a_run", "not_a_run_name")
    is_dir = _resolve_is_dir(entry)
    if isinstance(is_dir, Unavailable):
        return _entry_candidate(name, path, is_dir, "unknown", f"entry_unavailable: {is_dir.reason}")
    if is_dir.value is not True:
        return _entry_candidate(name, path, is_dir, "not_a_run", "not_a_run_dir")
    times = {"status_mtime": _resolve_mtime(path / STATUS_NAME), "run_started": _resolve_mtime(path / CONFIG_NAME)}
    empty = all(isinstance(field, Resolved) and field.value is ABSENT for field in times.values())
    if empty:  # one retry, like every other timestamp
        times["dir_mtime"] = _resolve_read(lambda _path: entry.stat(follow_symlinks=False).st_mtime, path, "stat")
    unavailable = next((field.reason for field in times.values() if isinstance(field, Unavailable)), None)
    readable = [_value(field) for field in times.values() if _value(field) is not None]
    return {"name": name, "path": path, "is_dir": is_dir, **times, "empty": empty, "unavailable": unavailable,
            "stamp": None if unavailable is not None or not readable else max(readable), "resolved": False}


def _entry_candidate(name: str, path: Path, is_dir, kind: str, reason: str) -> dict:
    """A scan entry resolved on its name or its directory type alone: no run file is read. A non-run
    name never reads its type (is_dir stays Unavailable("not_read")); only an unknown one is unavailable."""
    unavailable = is_dir.reason if kind == "unknown" else None
    return {"name": name, "path": path, "is_dir": is_dir, "empty": False, "unavailable": unavailable,
            "stamp": None, "kind": kind, "reason": reason, "symbol": None, "config": Unavailable("not_read"),
            "resolved": True}


def resolve_candidate(candidate: dict, *, truncated: bool = False) -> dict:
    """Complete a candidate's resolution: its classification (kind, venue, mode, symbol) and every
    timestamp it carries (status mtime, config mtime, the dir mtime of an empty one), each read,
    retried once on failure, and recorded as a value or as unavailable.

    THE RULE: a candidate is never excluded before it is fully resolved. No code path (scan, tick
    filtering, observation, judge) drops, skips or excludes a candidate before this ran, and the only
    exclusion is exclude_resolved over its result. Idempotent: a resolved candidate returns as is.
    A candidate past the MAX_RUN_DIRS cut is resolved with its classification unavailable
    (runs_truncated): its timestamps are resolved, its config is never read (bounded reads).

    Every field is a tagged value (Resolved or Unavailable), never None: the config read that decides
    kind, venue and mode is retried once like every timestamp, and only a second failure makes it
    Unavailable, which keeps the candidate unknown, never unreadable after one read.

    kind is live (a live Kalshi run of a valid symbol), other (readable proof of another venue or a
    known other mode), unreadable (no config, an unparsable one, or no valid symbol on a live Kalshi
    config), unknown (unclassifiable, an unavailable config read, no run file, or any unavailable
    timestamp: config.json read with no mtime is unavailable for EVERY kind), truncated, or not_a_run
    (resolved by _resolve_times on the entry's name or directory type)."""
    if candidate.get("resolved") is True:
        return candidate
    unavailable, symbol = candidate["unavailable"], None
    if truncated:
        kind, reason, config = "truncated", "runs_truncated", Unavailable("runs_truncated")
    else:
        config = _resolve_read(_read_config, candidate["path"] / CONFIG_NAME, "read")
        body = _value(config)
        present = isinstance(config, Resolved) and config.value is not ABSENT
        kind, reason = _classify(body)
        if isinstance(body, dict):
            value = body.get("symbol")
            symbol = value if type(value) is str and SYMBOL_RE.fullmatch(value) else None
        started = candidate["run_started"]
        if unavailable is None and present and isinstance(started, Resolved) and started.value is ABSENT:
            unavailable = "config_mtime"  # config.json read while no stat of it succeeded
        if kind == "other":
            pass  # readable proof of another book: its timestamps only place it in time
        elif unavailable is not None:
            kind, reason = "unknown", f"timestamps_unavailable: {unavailable}"
        elif isinstance(config, Unavailable):
            kind, reason = "unknown", f"config_unavailable: {config.reason}"
            unavailable = reason
        elif candidate["empty"] and not present:
            kind, reason = "unknown", "no_run_files"
        elif kind == "live":
            reason = None
    return {**candidate, "kind": kind, "reason": reason, "symbol": symbol, "config": config,
            "unavailable": unavailable, "stamp": None if unavailable is not None else candidate["stamp"],
            "resolved": True}


def exclude_resolved(candidate: dict, window: dict | None = None) -> bool:
    """True only on readable proof over a fully resolved candidate: the one exclusion in this module.

    THE RULE: a candidate is never excluded before it is fully resolved (resolve_candidate), so an
    unresolved one is always kept. With no window it excludes only a classification proving another
    book (another venue, a known other mode) and an entry resolved as not a run (its name, or a
    directory type two reads and an lstat agree on). With a window it also excludes another book's
    readable symbol, and a candidate EVERY resolved timestamp of which predates the window's arm. An
    unavailable field (any Unavailable timestamp counts as inside the window) or any timestamp inside
    the window keeps it: a run to observe, or an unknown line the judge reads as unavailable."""
    if candidate.get("resolved") is not True:
        return False
    if candidate["kind"] in ("other", "not_a_run"):
        return True
    if window is None:
        return False
    if candidate["symbol"] is not None and candidate["symbol"] != window["symbol"]:
        return True
    if candidate["unavailable"] is not None or candidate["stamp"] is None:
        return False
    if any(isinstance(candidate.get(field), Unavailable) for field in TIME_FIELDS):
        return False
    return candidate["stamp"] < parse_iso(window["armed_at"]).timestamp()


def _scan_candidates(runs_root: Path) -> tuple[list[dict], str | None]:
    """(candidates, error): every entry under the runs root, fully resolved, minus readable proof of
    another book or of not being a run, in tick-line order: live runs, truncated, unreadable, unknown
    (newest first within each).

    NO filtering before resolve: every entry (at most MAX_SCAN_ENTRIES, the one guard) goes through
    _resolve_times, which resolves its name and directory type before anything is judged. The newest
    MAX_RUN_DIRS run dirs are classified; the rest are truncated candidates, missing evidence and
    never absent runs. Unknown candidates past MAX_UNKNOWN collapse into one unknown entry with no
    stamp, inside every window. error is set when the root is unreadable or the entry loop hit
    MAX_SCAN_ENTRIES."""
    staged, error = [], None
    try:
        with os.scandir(runs_root) as entries:
            for index, entry in enumerate(entries):
                if index >= MAX_SCAN_ENTRIES:
                    error = "runs_scan_truncated"
                    break
                candidate = _resolve_times(entry)
                staged.append(candidate)
    except OSError as exc:
        return [], f"runs root unreadable: {type(exc).__name__}"
    # Run dirs still to classify first, newest first; a candidate no timestamp places sorts newest, so
    # the cut never truncates it. Entries already resolved on their name or type sort last and never
    # take a place under the MAX_RUN_DIRS cut.
    ordered = sorted(staged, key=lambda row: (row["resolved"] is not True, row["stamp"] is None,
                                              row["stamp"] or 0.0, row["name"]), reverse=True)
    groups: dict[str, list[dict]] = {"live": [], "truncated": [], "unreadable": [], "unknown": []}
    for position, candidate in enumerate(ordered):
        candidate = resolve_candidate(candidate, truncated=position >= MAX_RUN_DIRS)
        if exclude_resolved(candidate):
            continue
        groups[candidate["kind"]].append(candidate)
    unknown = groups["unknown"]
    if len(unknown) > MAX_UNKNOWN:
        extra = len(unknown) - (MAX_UNKNOWN - 1)
        unknown[MAX_UNKNOWN - 1:] = [{"name": f"{extra} more", "path": None, "empty": False,
                                      "unavailable": "unknown_truncated", "stamp": None, "kind": "unknown",
                                      "reason": "unknown_truncated", "symbol": None,
                                      "config": Unavailable("unknown_truncated"), "resolved": True}]
    return groups["live"] + groups["truncated"] + groups["unreadable"] + unknown, error


def _scan_runs(runs_root: Path) -> tuple[list[dict], list[dict], str | None]:
    """(runs, gaps, error): the report view of _scan_candidates; it excludes nothing itself.

    runs are the live candidates; every other candidate is a gap {name, stamp, reason}, plus its
    readable symbol and unknown True when it is unknown."""
    candidates, error = _scan_candidates(runs_root)
    runs, gaps = [], []
    for candidate in candidates:
        candidate = resolve_candidate(candidate)  # idempotent: the scan resolved it; no branch reads it first
        if candidate["kind"] == "live":
            runs.append(candidate)
            continue
        gap = {"name": candidate["name"], "stamp": candidate["stamp"], "reason": candidate["reason"]}
        if candidate["kind"] == "unknown":
            gap.update(symbol=candidate["symbol"], unknown=True)
        gaps.append(gap)
    return runs, gaps, error


def _mirror_view(block) -> dict | None:
    if not isinstance(block, dict):
        return None
    invalidated = block.get("invalidated_at")
    divergences = block.get("divergences")
    return {"state": _text(block.get("state")), "window": _int(block.get("window")),
            "invalidated_at": invalidated if invalidated is None or type(invalidated) is int else "malformed",
            "frames": _int(block.get("frames")),
            "divergences": ({name: _int(divergences.get(name)) for name in DIVERGENCE_CLASSES}
                            if isinstance(divergences, dict) else None),
            "dropped": _int(block.get("dropped"))}


def _disturbance_view(status: dict) -> dict | None:
    executor = status.get("executor")
    block = executor.get("disturbance") if isinstance(executor, dict) else None
    if not isinstance(block, dict):
        return None
    return {key: _int(block.get(key)) for key in DISTURBANCE_KEYS}


def _null_line(now: datetime, note: str, *, unknown: bool = False) -> dict:
    return {"at": iso(now), "run": None, "run_started": None, "status_mtime": None, "age_s": None,
            "status": None, "executor_mode": None, "mirror": None, "disturbance": None,
            **dict.fromkeys(IDENTITY_KEYS), "note": note[:MAX_TEXT], "unknown": unknown}


def _observe(run: dict, now: datetime) -> dict:
    run = resolve_candidate(run)  # idempotent: nothing here reads the candidate before it is resolved
    status = None
    try:
        loaded = _read_capped_json(run["path"] / STATUS_NAME, MAX_STATUS_BYTES)
        status = loaded if isinstance(loaded, dict) else None
    except (OSError, ValueError):
        status = None
    status_mtime = _value(run["status_mtime"])
    undated = None
    if status is not None and status_mtime is None:
        # The status appeared after the scan proved it absent: re-read its timestamp once. A status
        # that no timestamp dates proves no freshness, so the line is undated (no age, no coverage
        # credit, unknown to the judge), yet every value it read is kept: harm read from the venue
        # (a divergence, a disturbance) still refuses the window.
        status_mtime, stat_error = _mtime(run["path"] / STATUS_NAME)
        if status_mtime is None:
            undated = f"status_mtime_unavailable{': ' + stat_error if stat_error else ''}: {run['name']}"
    age_s = (max(0, int(now.timestamp() - status_mtime))
             if status is not None and status_mtime is not None else None)
    mode = status.get("executor_mode") if status is not None else None
    if type(mode) is not bool:
        config = _value(run["config"])
        mode = config.get("executor_mode") if isinstance(config, dict) else None
        mode = mode if type(mode) is bool else None
    line = {"at": iso(now), "run": run["name"][:MAX_TEXT], "run_started": iso_ts(_value(run["run_started"])),
            "status_mtime": iso_ts(status_mtime), "age_s": age_s,
            "status": "ok" if status is not None else None, "executor_mode": mode,
            "mirror": _mirror_view(status.get("parity_mirror")) if status is not None else None,
            "disturbance": _disturbance_view(status) if status is not None else None,
            **_identity(run, status)}
    if undated is not None:
        line.update(note=undated[:MAX_TEXT], undated=True)
    return line


def _tick_lines(window: dict, candidates: list[dict], error: str | None, now: datetime) -> list[dict]:
    """One line per candidate the window keeps: an observed line for a live run of the window's book,
    a null line for any other candidate (marked unknown for the judge when it is unknown), one null
    line on a scan error. Each candidate is resolved before exclude_resolved judges it, and nothing
    is skipped any other way."""
    lines = []
    for candidate in candidates:
        candidate = resolve_candidate(candidate)
        if exclude_resolved(candidate, window):
            continue
        if candidate["kind"] == "live":
            lines.append(_observe(candidate, now))
        else:
            lines.append(_null_line(now, f"{candidate['reason']}: {candidate['name']}",
                                    unknown=candidate["kind"] == "unknown"))
    if error is not None:
        lines.append(_null_line(now, error))
    return lines or [_null_line(now, f"no run of {window['symbol']} observed")]


def _count_lines(path: Path) -> int:
    """Newlines in the tick file, counted in bounded chunks and stopping past MAX_TICK_LINES."""
    try:
        fd = os.open(path, _READ_FLAGS)
    except FileNotFoundError:
        return 0
    count, budget = 0, MAX_TICK_LINES * MAX_TICK_LINE
    with os.fdopen(fd, "rb") as stream:
        while count <= MAX_TICK_LINES and budget > 0:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            budget -= len(chunk)
            count += chunk.count(b"\n")
    return count


def _append_ticks(path: Path, lines: list[dict]) -> None:
    encoded = []
    for line in lines:
        data = (json.dumps(line, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
        if len(data) > MAX_TICK_LINE:
            data = (json.dumps(_null_line(parse_iso(line["at"]), "line over 64 KiB"), sort_keys=True,
                               separators=(",", ":")) + "\n").encode("utf-8")
        encoded.append(data)
    if _count_lines(path) + len(encoded) > MAX_TICK_LINES:
        raise Refused("ticks_full", f"{path.name} would exceed {MAX_TICK_LINES} lines")
    flags = (os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
             | getattr(os, "O_BINARY", 0))
    fd = os.open(path, flags, 0o640)
    try:
        _write_all(fd, b"".join(encoded))
        os.fsync(fd)
    finally:
        os.close(fd)


def _read_ticks(path: Path) -> tuple[list[dict], int, bool]:
    """(lines, unreadable line count, truncated): at most MAX_TICK_LINES lines of MAX_TICK_LINE bytes."""
    try:
        fd = os.open(path, _READ_FLAGS)
    except FileNotFoundError:
        return [], 0, False
    lines, bad, truncated = [], 0, False
    with os.fdopen(fd, "rb") as stream:
        for index in range(MAX_TICK_LINES + 1):
            raw = stream.readline(MAX_TICK_LINE + 1)
            if not raw:
                break
            if index == MAX_TICK_LINES:
                truncated = True
                break
            if len(raw) > MAX_TICK_LINE:
                bad += 1
                while raw and not raw.endswith(b"\n"):
                    raw = stream.readline(MAX_TICK_LINE + 1)
                continue
            try:
                row = json.loads(raw)
            except ValueError:
                bad += 1
                continue
            if isinstance(row, dict):
                lines.append(row)
            else:
                bad += 1
    return lines, bad, truncated


def cmd_tick(args, paths: Paths, now: datetime) -> int:
    if not _state_dir(paths, create=False):
        print("stage_b tick: no state dir, nothing armed")
        return EXIT_OK
    failures = []
    with _locked(paths):
        ledger = _load_ledger(paths)
        windows = [window for window in ledger["windows"] if window["state"] == "open"][:MAX_WINDOWS]
        if not windows:
            print("stage_b tick: no open window")
            return EXIT_OK
        candidates, error = _scan_candidates(paths.runs_root)
        for window in windows:
            lines = _tick_lines(window, candidates, error, now)
            try:
                _append_ticks(paths.ticks(window["id"]), lines)
            except (Refused, OSError) as exc:
                code = exc.code if isinstance(exc, Refused) else "io_error"
                failures.append(window["id"])
                print(f"stage_b refused: {code}: {window['id']}: {exc}", file=sys.stderr)
                continue
            print(f"stage_b tick {iso(now)} {window['id']}: {len(lines)} line(s)"
                  + (f" ({lines[0].get('note')})" if lines[0].get("run") is None else ""))
    return EXIT_REFUSED if failures else EXIT_OK


# --------------------------------------------------------------------------- verdict
def judge(window: dict, lines: list[dict], bad: int, truncated: bool, hours: float, now: datetime) -> dict:
    """Pure verdict over one window's tick lines; the rules are in the module's contract and RULES."""
    armed = parse_iso(window["armed_at"])
    age_s = (now - armed).total_seconds()
    need_s = hours * 3600
    # N complete 900 s intervals 0..N-1; a line past them counts for every rule but not coverage.
    intervals = max(0, int(age_s // TICK_CADENCE_S))
    rows = []
    # The rows the rules read: every row but an unknown one, which is missing evidence. An undated row
    # is judged too (the harm it read refuses) but feeds no freshness rule and earns no coverage.
    judged: list[tuple[datetime, dict, bool]] = []
    unknown: list[str] = []
    covered: set[int] = set()
    for line in lines:
        at = parse_iso(line.get("at"))
        if at is None:
            bad += 1
        elif armed <= at <= now:
            rows.append((at, line))
            # An "ok" status no timestamp dates proves no freshness: unknown, and no coverage credit.
            undated = line.get("status") == "ok" and (line.get("undated", False) is not False
                                                      or parse_iso(line.get("status_mtime")) is None
                                                      or type(line.get("age_s")) is not int)
            if line.get("unknown", False) is not False:  # anything but an explicit False is unknown
                unknown.append(f"{str(line.get('note'))[:MAX_TEXT]} at {iso(at)}")
            else:
                if undated:
                    unknown.append(f"status_mtime_unavailable: {str(line.get('run'))[:MAX_TEXT]} at {iso(at)}")
                judged.append((at, line, undated))
            index = int((at - armed).total_seconds() // TICK_CADENCE_S)
            if (index < intervals and line.get("status") == "ok" and not undated
                    and type(line.get("run")) is str):
                covered.add(index)
    # Longest run of uncovered intervals from the covered set alone: O(lines), never O(N).
    edges = [-1, *sorted(covered), intervals]
    max_uncovered = max(later - earlier - 1 for earlier, later in zip(edges, edges[1:]))
    reasons = []
    if age_s < need_s:
        reasons.append("young")
    if len(covered) < math.ceil(MIN_TICK_COVERAGE * intervals):
        reasons.append("coverage")
    if max_uncovered > MAX_UNCOVERED_RUN:
        reasons.append("coverage_gap")
    times = sorted(at for at, _ in rows)
    base = {"window": window["id"], "symbol": window["symbol"], "phase": window["phase"], "sha": window["sha"],
            "config_digest": window.get("config_digest"), "armed_at": window["armed_at"],
            "window_start": window["armed_at"], "window_end": iso(now),
            "first_tick": iso(times[0]) if times else None, "last_tick": iso(times[-1]) if times else None,
            "hours": hours, "age_s": int(age_s), "intervals": intervals, "covered_intervals": len(covered),
            "coverage": round(len(covered) / intervals, 4) if intervals else 0,
            "max_uncovered_run": max_uncovered, "lines": len(rows), "insufficient_reasons": reasons,
            "unknown_candidates": len(unknown), "unknown": unknown[:16], "txn": window.get("txn")}

    failed: dict[str, str] = {}

    def fail(rule: str, detail: str) -> None:
        failed.setdefault(rule, detail[:MAX_TEXT * 2])

    if bad:
        fail("unreadable", f"{bad} tick line(s) unreadable")
    if truncated:
        fail("unreadable", f"tick file over {MAX_TICK_LINES} lines")
    flipped = window["phase"] == "flipped"
    runs: dict[str, dict] = {}
    by_tick: dict[datetime, list] = {}
    max_retries = None
    for at, line, undated in judged:
        when = iso(at)
        run = line.get("run") if type(line.get("run")) is str else None
        where = f"{run or 'no run'} at {when}"
        mirror = line.get("mirror")
        if line.get("status") is None:
            fail("unreadable", f"no readable status: {where}")
        if not isinstance(mirror, dict):
            fail("unreadable", f"no parity_mirror block: {where}")
            mirror = None
        else:
            divergences = mirror.get("divergences")
            if (type(mirror.get("frames")) is not int or type(mirror.get("dropped")) is not int
                    or not isinstance(divergences, dict)
                    or any(type(divergences.get(name)) is not int for name in DIVERGENCE_CLASSES)):
                fail("unreadable", f"parity_mirror counters unreadable: {where}")
            if mirror.get("state") != "running":
                fail("mirror_not_running", f"state {mirror.get('state')!r}: {where}")
            dropped = mirror.get("dropped")
            if mirror.get("invalidated_at") is not None or (type(dropped) is int and dropped > 0):
                fail("mirror_invalidated", f"invalidated_at {mirror.get('invalidated_at')!r}, "
                                           f"dropped {dropped!r}: {where}")
            if isinstance(divergences, dict):
                hits = {name: divergences.get(name) for name in DIVERGENCE_CLASSES
                        if type(divergences.get(name)) is int and divergences.get(name) > 0}
                if hits:
                    fail("divergence", f"{hits}: {where}")
        if flipped:
            disturbance = line.get("disturbance")
            if (not isinstance(disturbance, dict)
                    or any(type(disturbance.get(key)) is not int for key in JUDGED_DISTURBANCE)):
                fail("unreadable", f"executor.disturbance unreadable: {where}")
            if isinstance(disturbance, dict):
                hits = {key: disturbance.get(key) for key in JUDGED_DISTURBANCE
                        if type(disturbance.get(key)) is int and disturbance.get(key) > 0}
                if hits:
                    fail("disturbance", f"{hits}: {where}")
                retries = disturbance.get("revision_retries")
                if type(retries) is int:
                    max_retries = retries if max_retries is None else max(max_retries, retries)
            if line.get("executor_mode") is not True:
                fail("executor_mode_unconfirmed", f"executor_mode {line.get('executor_mode')!r}: {where}")
        elif line.get("executor_mode") is True:
            fail("executor_mode_on", f"executor_mode true in a mirror window: {where}")
        if run is None:
            continue
        observed = {key: line.get(key) for key in IDENTITY_KEYS}
        missing = [key for key in IDENTITY_KEYS if observed[key] is None]
        if missing or observed["dirty"] is not False:
            fail("identity_unverified", f"{', '.join(missing) or 'dirty build'}: {where}")
        bound = {"git_sha": window["sha"], "config_sha": window["sha"], "config_digest": window.get("config_digest")}
        moved = [f"{key} {observed[key]} bound {value}" for key, value in bound.items()
                 if observed[key] is not None and observed[key] != value]
        if moved:
            fail("identity_changed", f"{where}: " + ", ".join(moved))
        if undated:
            # No freshness: an undated row never stands for its run's newest status (stale_status), its
            # last status (run_gap) or its frames (mirror_idle), so it can mask no dated row's harm.
            continue
        started = parse_iso(line.get("run_started"))
        if started is None:
            fail("unreadable", f"run_started unreadable: {where}")
            continue
        entry = runs.setdefault(run, {"started": started, "last_status": None, "frames": None})
        status_at = parse_iso(line.get("status_mtime"))
        if status_at is not None and (entry["last_status"] is None or status_at > entry["last_status"]):
            entry["last_status"] = status_at
        frames = mirror.get("frames") if mirror is not None else None
        if type(frames) is int:
            entry["frames"] = frames if entry["frames"] is None else max(entry["frames"], frames)
        by_tick.setdefault(at, []).append((started, run, line))

    for at, entries in sorted(by_tick.items()):
        _, run, line = max(entries, key=lambda item: (item[0], item[1]))
        age = line.get("age_s")
        if type(age) is int and age > STALE_STATUS_S:
            fail("stale_status", f"newest run {run} status {age} s old at {iso(at)}")
    for run, entry in sorted(runs.items()):
        if entry["frames"] is not None and entry["frames"] <= 0:
            fail("mirror_idle", f"frames never rose above 0 in {run}")
    ordered = sorted((entry["started"], run, entry) for run, entry in runs.items())
    for previous, current in zip(ordered, ordered[1:]):
        last = previous[2]["last_status"]
        if last is not None and (current[0] - last).total_seconds() > RUN_GAP_S:
            fail("run_gap", f"{current[1]} started {int((current[0] - last).total_seconds())} s after "
                            f"{previous[1]}'s last status")

    failed_rules = [{"rule": rule, "detail": failed[rule]} for rule in RULES if rule in failed]
    # refused > unavailable > insufficient > accept. Harm read in the window (every rule but
    # unreadable, which is missing evidence) refuses it whatever unknown candidate or short window sits
    # beside it; only when nothing harms does an unknown line make it unavailable.
    if not any(row["rule"] != "unreadable" for row in failed_rules):
        if unknown:
            # A run the scan could not classify may be this book's: missing evidence, never accept.
            return {**base, "verdict": "unavailable", "failed_rules": []}
        if reasons:
            return {**base, "verdict": "insufficient", "failed_rules": []}
    return {**base, "verdict": "refused" if failed_rules else "accept", "failed_rules": failed_rules,
            "max_revision_retries": max_retries}


def cmd_verdict(args, paths: Paths, now: datetime) -> int:
    symbol, phase, hours = args.symbol, args.phase, args.hours
    _check_symbol(symbol)
    if phase not in PHASES:
        raise Refused("bad_input", "--phase must be mirror or flipped")
    if not (type(hours) in (int, float) and math.isfinite(hours) and DEFAULT_HOURS <= hours <= MAX_HOURS):
        raise Refused("bad_input", f"--hours must be in [{DEFAULT_HOURS:g}, {MAX_HOURS:g}]")
    if not _state_dir(paths, create=False):
        raise Refused("no_open_window", f"no state dir {paths.state}")
    exits = {"accept": EXIT_OK, "refused": EXIT_VERDICT_REFUSED}
    with _locked(paths):
        ledger = _load_ledger(paths)
        window = _latest(ledger, symbol, phase, "open")
        if window is None:
            raise Refused("no_open_window", f"no open {phase} window for {symbol}")
        name = f"verdict-{window['id']}"
        recorded = _read_receipt(paths, name)
        if recorded is not None:
            # A final receipt with an open window: the ledger save after it failed. Adopt, never rejudge.
            outcome = recorded.get("outcome")
            if (recorded.get("verb") != "verdict" or recorded.get("window") != window["id"]
                    or outcome not in exits or parse_iso(recorded.get("at")) is None):
                raise Refused("receipt_conflict", f"{name}.json is not a final verdict for {window['id']}")
            window.update(state="accepted" if outcome == "accept" else "refused", verdict_at=recorded["at"])
            _save_ledger(paths, ledger)
            print(json.dumps({"verdict": outcome, "window": window["id"], "adopted": True,
                              "refusals": recorded.get("refusals"), "receipt": f"{name}.json"}, sort_keys=True))
            return exits[outcome]
        lines, bad, truncated = _read_ticks(paths.ticks(window["id"]))
        report = judge(window, lines, bad, truncated, float(hours), now)
        outcome = report["verdict"]
        body = _receipt_body(
            now, "verdict", symbol, sha=window["sha"], request_id=window["request_id"], window=window["id"],
            phase=phase, outcome=outcome, refusals=[row["rule"] for row in report["failed_rules"]],
            **{key: report[key] for key in ("config_digest", "window_start", "window_end", "first_tick",
                                            "last_tick", "intervals", "covered_intervals", "coverage",
                                            "max_uncovered_run", "insufficient_reasons", "unknown_candidates",
                                            "txn")},
            report=report)
        if outcome in ("insufficient", "unavailable"):
            # Not final: the window stays open. An unavailable one stays so until the unknown run dir is
            # made readable or removed and the book re-armed; its unknown tick lines never age out.
            receipt = _receipt(paths, now, body)
        else:
            # The receipt first, then the ledger: a crash between leaves an open window plus a final
            # receipt, and the next verdict adopts it.
            receipt, prior = _receipt_once(paths, name, body)
            if prior is not None:
                raise Refused("receipt_conflict", f"{name}.json appeared under the lock")
            window.update(state="accepted" if outcome == "accept" else "refused", verdict_at=iso(now))
            _save_ledger(paths, ledger)
    print(json.dumps({"verdict": outcome, "window": window["id"], "failed_rules": report["failed_rules"],
                      "intervals": report["intervals"], "covered_intervals": report["covered_intervals"],
                      "coverage": report["coverage"], "max_uncovered_run": report["max_uncovered_run"],
                      "insufficient_reasons": report["insufficient_reasons"], "unknown": report["unknown"],
                      "receipt": receipt.name}, sort_keys=True))
    return EXIT_UNAVAILABLE if outcome == "unavailable" else exits.get(outcome, EXIT_INSUFFICIENT)


# --------------------------------------------------------------------------- restart-plan
_DEPLOY = None


def _load_deploy():
    """deploy.py loaded once, lazily and by path (never via sys.path), read only: its guards and
    windows are the one copy this tool projects."""
    global _DEPLOY
    if _DEPLOY is None:
        spec = importlib.util.spec_from_file_location("leafhft_runner_deploy_for_stage_b", HERE / "deploy.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _DEPLOY = module
    return _DEPLOY


def _current_step(ledger: dict, symbol: str, sha: str) -> tuple[str, str]:
    """(step, txn) of the book's current Stage B step: its done flip while flipped, else its newest done
    rollback, mirror or unmirror. Refuses no_stage_b_step, step_pending, or step_sha_mismatch when the step is on another sha."""
    flip = ledger["flips"].get(symbol)
    if flip is not None:
        request_id = flip.get("request_id") if isinstance(flip, dict) else None
        row = ledger["requests"].get(request_id) if type(request_id) is str else None
        if not isinstance(row, dict) or row.get("verb") != "flip" or row.get("symbol") != symbol:
            raise _corrupt(f"flip of {symbol} names no flip request")
        step = "flip"
    else:
        steps = [(parse_iso(row.get("at")), request_id, row) for request_id, row in ledger["requests"].items()
                 if row.get("verb") in STEP_OF_VERB and row.get("symbol") == symbol and row.get("state") == "done"]
        steps = [item for item in steps if item[0] is not None]
        if not steps:
            raise Refused("no_stage_b_step", f"{symbol} has no flip, rollback, mirror or unmirror in the ledger; "
                                             "mirror or flip it first")
        _, request_id, row = max(steps, key=lambda item: (item[0], item[1]))
        step = STEP_OF_VERB[row["verb"]]
    if row.get("state") != "done":
        raise Refused("step_pending", f"{request_id} is pending; rerun it with the same --request-id first")
    if row.get("key") != sha:
        raise Refused("step_sha_mismatch", f"the {step} {request_id} was on {str(row.get('key'))[:40]}, not {sha}")
    return step, _txn(symbol, step, row.get("at"))


def cmd_restart_plan(args, paths: Paths, now: datetime) -> int:
    """Read only, no lock, creates nothing: the one guarded one-book rollout for a same-sha flip.

    deploy.py's restart-unchanged path restarts the whole live fleet and cannot re-ack a moved
    config digest, so a flip goes through rollout.sh --units <unit>, which waits for the gap, restarts
    the book and re-acks it with the settlement guard armed. The step (the book's flip, or its newest
    rollback) comes from the ledger, read without the lock, and names the rollout transaction: each
    flip and each rollback of each book has its own rollout state, and a re-print resumes that one."""
    symbol, sha = args.symbol, args.sha
    _check_symbol(symbol)
    _check_sha(sha)
    if _contained(paths.containment):
        raise Refused("containment", f"{paths.containment} exists")
    try:
        deploy = _load_deploy()
    except Exception as exc:  # noqa: BLE001 - any failure to load the deploy verb refuses
        raise Refused("deploy_unavailable", f"{type(exc).__name__}: {str(exc)[:MAX_TEXT]}") from exc
    try:
        deploy.check_containment()
        head = deploy.read_head()
        rows = deploy.read_deployed()
    except deploy.Refused as exc:
        raise Refused("restart_refused", str(exc)[:MAX_TEXT * 2]) from exc
    if head != sha:
        raise Refused("head_mismatch", f"the runner checkout is at {head}, not {sha}")
    unit = _unit(symbol)
    if unit not in rows:
        raise Refused("unit_unknown", f"{unit} is not in leafhft deployed --json")
    drifted = sorted(name for name, row in rows.items() if row.get("live") is True and deploy.identity(row) != sha)
    if drifted:
        raise Refused("fleet_not_on_sha", f"live on another sha: {', '.join(drifted)[:MAX_TEXT]}; "
                                          "move the code with deploy.py first")
    reasons = deploy.window_refusals(now.timestamp(), deploy.ROLLOUT, 1, gap=False)
    if reasons:
        raise Refused("restart_window", "; ".join(reasons)[:MAX_TEXT * 2])
    ledger = _load_ledger(paths) if _state_dir(paths, create=False) else _new_ledger()
    step, txn = _current_step(ledger, symbol, sha)
    unselected = [name for name in sorted(rows) if name != unit]
    command = (f"test ! -e {shlex.quote(str(paths.containment))} && bash {RUNNER_DIR}/rollout.sh {sha} "
               f"--txn {txn} --units {unit}")
    if unselected:
        command += " --expect-unselected " + ",".join(f"{name}={deploy.identity(rows[name])}"
                                                      for name in unselected)
    print(json.dumps({"unit": unit, "sha": sha, "step": step, "txn": txn, "unselected": unselected,
                      "command": command, "resume": f"{command} --resume"}, sort_keys=True))
    print(command)
    return EXIT_OK


# --------------------------------------------------------------------------- status
def cmd_status(args, paths: Paths, now: datetime) -> int:
    """Read only: takes no lock and creates nothing."""
    ledger = _load_ledger(paths) if _state_dir(paths, create=False) else _new_ledger()
    _, hosts = _read_hosts(paths.hosts)
    _, mirror_hosts = _read_hosts(paths.mirror_hosts)
    contained = _contained(paths.containment)
    open_windows = []
    last_verdicts: dict[str, dict] = {}
    for window in ledger["windows"]:
        if window["state"] == "open":
            armed = parse_iso(window["armed_at"])
            open_windows.append({"id": window["id"], "symbol": window["symbol"], "phase": window["phase"],
                                 "sha": window["sha"], "armed_at": window["armed_at"],
                                 "age_s": int((now - armed).total_seconds())})
        elif window["state"] in ("accepted", "refused") and window.get("verdict_at"):
            last_verdicts[window["symbol"]] = {"window": window["id"], "phase": window["phase"],
                                               "verdict": window["state"], "verdict_at": window["verdict_at"]}
    blocked = _in_progress(ledger, hosts)
    candidates = sorted({window["symbol"] for window in ledger["windows"]
                         if window["phase"] == "mirror" and window["state"] == "accepted"} - set(hosts))
    pending = sorted(request_id for request_id, row in ledger["requests"].items() if row.get("state") == "pending")
    report = {"hosts": hosts, "mirror_hosts": mirror_hosts, "containment": contained, "open_windows": open_windows,
              "last_verdicts": dict(sorted(last_verdicts.items())), "in_progress": blocked,
              "may_flip_next": [] if blocked or contained else candidates, "pending_requests": pending}
    if args.json:
        print(json.dumps(report, sort_keys=True))
        return EXIT_OK
    print(f"hosts ({HOSTS_NAME}): {', '.join(hosts) or 'none'}")
    print(f"mirror hosts ({MIRROR_HOSTS_NAME}): {', '.join(mirror_hosts) or 'none'}")
    print(f"containment: {'PRESENT' if contained else 'absent'}")
    for row in open_windows:
        print(f"open {row['id']} {row['symbol']} {row['phase']} sha {row['sha'][:12]} "
              f"armed {row['armed_at']} ({row['age_s'] // 3600} h)")
    for symbol, row in report["last_verdicts"].items():
        print(f"last verdict {symbol}: {row['verdict']} {row['phase']} at {row['verdict_at']} ({row['window']})")
    if blocked:
        print("in progress (no accepted flipped verdict yet): " + ", ".join(blocked))
    if pending:
        print("pending requests: " + ", ".join(pending))
    print("may flip next: " + (", ".join(report["may_flip_next"]) or "none"))
    return EXIT_OK


# --------------------------------------------------------------------------- main
def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(prog="stage_b.py", description="Stage B acceptance per book (C16d).")
    result.add_argument("--etc", default=DEFAULT_ETC)
    result.add_argument("--state-dir", default=DEFAULT_STATE_DIR)
    result.add_argument("--runs-root", default=DEFAULT_RUNS_ROOT)
    result.add_argument("--containment", default=DEFAULT_CONTAINMENT)
    commands = result.add_subparsers(dest="command", required=True)
    flip = commands.add_parser("flip")
    unflip = commands.add_parser("unflip")
    arm = commands.add_parser("arm")
    mirror = commands.add_parser("mirror")
    unmirror = commands.add_parser("unmirror")
    for command in (flip, unflip, arm, mirror, unmirror):
        command.add_argument("--symbol", required=True)
        command.add_argument("--sha", required=True)
        command.add_argument("--request-id", required=True)
    unflip.add_argument("--reason", required=True)
    unmirror.add_argument("--reason", required=True)
    arm.add_argument("--phase", required=True, choices=PHASES)
    commands.add_parser("tick")
    verdict = commands.add_parser("verdict")
    verdict.add_argument("--symbol", required=True)
    verdict.add_argument("--phase", required=True, choices=PHASES)
    verdict.add_argument("--hours", type=float, default=DEFAULT_HOURS)
    status = commands.add_parser("status")
    status.add_argument("--json", action="store_true")
    restart_plan = commands.add_parser("restart-plan")
    restart_plan.add_argument("--symbol", required=True)
    restart_plan.add_argument("--sha", required=True)
    return result


HANDLERS = {"flip": cmd_flip, "unflip": cmd_unflip, "arm": cmd_arm, "tick": cmd_tick,
            "verdict": cmd_verdict, "status": cmd_status, "restart-plan": cmd_restart_plan,
            "mirror": cmd_mirror, "unmirror": cmd_unmirror}


def main(argv=None, *, now: datetime | None = None) -> int:
    try:
        args = parser().parse_args(argv)
    except SystemExit as exc:
        return exc.code if isinstance(exc.code, int) else EXIT_REFUSED
    moment = _utc(now) if now is not None else datetime.now(timezone.utc)
    paths = Paths(args)
    try:
        if args.command in MUTATING:
            _state_dir(paths, create=True)
        return HANDLERS[args.command](args, paths, moment)
    except Refused as exc:
        print(f"stage_b refused: {exc.code}: {exc.detail}", file=sys.stderr)
        if args.command in MUTATING:
            _refused_receipt(args, paths, moment, exc)
        return EXIT_REFUSED
    except OSError as exc:
        refused = Refused("io_error", f"{type(exc).__name__}: {exc}")
        print(f"stage_b refused: {refused.code}: {refused.detail}", file=sys.stderr)
        if args.command in MUTATING:
            _refused_receipt(args, paths, moment, refused)
        return EXIT_REFUSED


if __name__ == "__main__":
    raise SystemExit(main())
