#!/bin/bash
set -euo pipefail

# The digest hashes authorized config fields: config defines them, cli maps inputs/defaults,
# live-run supplies values; config imports only types, and types/policy are stdlib-only leaves.
# Any new package import in config or module feeding an authorized field MUST extend this list.
DIGEST_PROOF_FILES=(
  deploy/runner/live-run.sh
  leafhft/cli.py
  leafhft/config.py
  leafhft/policy.py
  leafhft/types.py
)

fail() { echo "$*" >&2; exit 2; }
# Normalize command output at the boundary, including CRLF from native tools.
# Preserve line boundaries, but never let surrounding whitespace enter an ID.
normalize() {
  local line normalized=''
  while IFS= read -r line; do
    line="${line#"${line%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"
    normalized+="${normalized:+$'\n'}$line"
  done <<< "${!1}"
  printf -v "$1" '%s' "$normalized"
}
[[ $EUID -eq 0 ]] || fail 'deploy.sh must run as root'
[[ $# -ge 1 ]] || fail 'Usage: deploy.sh <target-sha> [--restart-unchanged] [--force-degraded]'
target=$1; shift
[[ "$target" =~ ^[0-9a-fA-F]{40}$ ]] || fail 'target must be a full commit SHA'
target=${target,,}
restart=0; force=0
for arg in "$@"; do
  case "$arg" in
    --restart-unchanged) restart=1 ;;
    --force-degraded) force=1 ;;
    *) fail "Unknown argument: $arg" ;;
  esac
done
base=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
normalize base
cd "$base"
export PATH="$base/.venv/bin:$PATH"
running=''; digest_may_move=1; moved=''; plan=''; restarted=''; left=''
units=''; stage=preflight; local_main_pinned=''

# Keep a receipt even if checkout, installation or a restart fails. The final
# machine verdict owns the exit code; stage_exit records a deploy refusal.
finish() {
  local stage_exit=$? final_code=0 final receipt
  trap - EXIT
  set +e
  printf 'units restarted:\n%s\n' "$restarted"
  while IFS= read -r unit; do
    [[ -z "$unit" ]] || echo "left on old code: $unit"
  done <<< "$left"
  if [[ -n "$left" || $digest_may_move -eq 1 ]]; then
    echo 'python3 /opt/leafhft/deploy/runner/rearm.py --plan'
    echo 'then: python3 /opt/leafhft/deploy/runner/rearm.py --apply'
  fi
  final=$(timeout 60 leafhft deployed --json)
  final_code=$?
  normalize final
  receipt=$(timeout 30 python3 -c '
import datetime, json, pathlib, sys
running, target, local_main_pinned, moving, moved, restarted, left, plan, stage, status, code, raw = sys.argv[1:]
try:
    report = json.loads(raw)
except ValueError:
    report = {"verdict": "UNREADABLE", "error": "invalid final deployed JSON", "output": raw}
root = pathlib.Path("/var/lib/leafhft/deploy-receipts")
root.mkdir(parents=True, exist_ok=True)
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
path = root / (stamp + "-" + target[:12] + ".json")
with path.open("x") as stream:
    json.dump({"running_sha": running or None, "target_sha": target,
        "local_main_pinned": local_main_pinned or None,
        "digest_may_move": int(moving), "moved_files": moved.splitlines(),
        "units_restarted": restarted.splitlines(), "units_left_on_old_code": left.splitlines(),
        "install_units_plan": plan, "final_deployed_verdict": report.get("verdict", "UNREADABLE").strip(),
        "final_deployed": report, "final_exit_code": int(code),
        "stage": stage, "stage_exit": int(status)}, stream, indent=2)
    stream.write("\n")
print(path)
' "$running" "$target" "$local_main_pinned" "$digest_may_move" "$moved" "$restarted" "$left" "$plan" "$stage" "$stage_exit" "$final_code" "$final")
  if [[ $? -eq 0 ]]; then
    normalize receipt
    echo "receipt: $receipt"
  else
    echo 'receipt write failed' >&2
  fi
  printf '%s\n' "$final"
  if [ "$stage" = checkout ] && [ "$stage_exit" -ne 0 ]; then
    exit "$stage_exit"
  fi
  exit "$final_code"
}
trap finish EXIT

pre_code=0
pre=$(timeout 60 leafhft deployed --json) || pre_code=$?
normalize pre
[[ $pre_code -le 2 ]] || fail 'UNREADABLE: cannot establish running SHA'
parsed=$(timeout 30 python3 -c '
import json, re, sys
report = json.load(sys.stdin)
rows = report["rows"]
for r in rows:
    r["unit"] = r["unit"].strip()
    if isinstance(r.get("git_sha"), str):
        r["git_sha"] = r["git_sha"].strip()
live = [r for r in rows if r["live"] is True]
missing_sha = any(r.get("git_sha") in (None, "") for r in live)
for r in live:
    if r.get("git_sha") in (None, ""):
        continue
    if not re.fullmatch("[0-9a-f]{40}", r.get("git_sha") or ""):
        sys.exit("UNREADABLE: live row lacks a full SHA")
for r in rows:
    if not re.fullmatch(r"leafhft-live@[A-Za-z0-9_-]+\.service", r["unit"]):
        sys.exit("UNREADABLE: invalid unit")
shas = sorted({r["git_sha"] for r in live if r.get("git_sha") not in (None, "")})
if len(shas) > 1:
    sys.exit("DRIFTED: multiple live SHAs")
print(shas[0] if shas and not missing_sha else "-")
for unit in sorted({r["unit"] for r in live}):
    print(unit)
' <<< "$pre") || fail 'Refused: running identity unavailable'
normalize parsed
running=${parsed%%$'\n'*}
if [[ "$parsed" == *$'\n'* ]]; then units=${parsed#*$'\n'}; fi
left=$units
if [[ "$running" == - ]]; then
  running=''
  [[ $force -eq 1 ]] || fail 'DEGRADED: no live SHA; use --force-degraded (no restarts)'
fi
timeout 120 git fetch origin
timeout 30 git merge-base --is-ancestor "$target" origin/main || fail 'target is not an ancestor of origin/main'
if [[ -n "$running" ]]; then
  timeout 30 git merge-base --is-ancestor "$running" "$target" || fail 'target is not a descendant of running SHA'
  timeout 30 git diff --stat "$running" "$target"
  digest_may_move=0
  for file in "${DIGEST_PROOF_FILES[@]}"; do
    diff_code=0
    timeout 30 git diff --quiet "$running" "$target" -- "$file" || diff_code=$?
    if [[ $diff_code -eq 1 ]]; then
      digest_may_move=1
      moved+="${moved:+$'\n'}$file"
    elif [[ $diff_code -ne 0 ]]; then
      fail "Digest proof unavailable: $file"
    fi
  done
fi
if [[ $digest_may_move -eq 1 ]]; then
  echo "digest may move: ${moved:-no running SHA}"
  [[ ${LEAFHFT_ALLOW_ACK_CHANGE:-0} != 1 ]] || echo 'Re-ack cost acknowledged; restart proof still required'
  [[ $restart -eq 0 ]] || echo 'REFUSED --restart-unchanged: digest identity not proved'
fi
stage=checkout
timeout 60 git checkout --detach "$target"
timeout 30 git branch -f main "$target"
local_main_pinned=$target
head=$(timeout 30 git rev-parse HEAD)
normalize head
[[ "$head" == "$target" ]] || fail 'HEAD does not equal target'
# Root's umask must not hide source from per-account and transfer service users.
timeout 30 chmod -R a+rX leafhft scripts
timeout 180 pip install -q -e .
stage=install-plan
plan=$(timeout 120 bash deploy/runner/install-units.sh --plan 2>&1) || fail "Installer plan failed: $plan"
normalize plan
printf '%s\n' "$plan"
retirement_states=''
while read -r action verb name rest; do
  [[ "$action $verb" == 'would retire' && -n "$name" ]] || continue
  active=$(timeout 15 systemctl is-active "$name" 2>/dev/null || true)
  normalize active
  retirement_states+="${retirement_states:+$'\n'}$name $active"
done <<< "$plan"
retirement_note=$(timeout 30 python3 -c '
import re, sys
plan = sys.stdin.read()
states = dict(line.split(" ", 1) for line in sys.argv[1].splitlines())
refused = set(re.findall(r"refused to retire\s+(\S+)", plan))
unrefused = set(re.findall(r"would retire\s+(\S+)", plan)) - refused
unsafe = {unit for unit in unrefused if unit.startswith("leafhft-live@")
          or states.get(unit) in {"active", "activating", "reloading", "deactivating"}}
if unsafe:
    sys.exit("Refused unrefused retirement: " + ", ".join(sorted(unsafe)))
for unit in sorted(unrefused):
    print("retiring inactive unit " + unit)
' "$retirement_states" <<< "$plan") || fail 'Unsafe installer plan'
normalize retirement_note
if [[ -n "$retirement_note" ]]; then
  printf '%s\n' "$retirement_note"
  plan+=$'\n'"$retirement_note"
fi
stage=install
timeout 180 bash deploy/runner/install-units.sh
stage=restarts
if [[ $restart -eq 1 && $digest_may_move -eq 0 && $force -eq 0 ]]; then
  while IFS= read -r unit; do
    [[ -n "$unit" ]] || continue
    environment=$(timeout 30 systemctl show -p Environment "$unit") || break
    normalize environment
    if ! timeout 30 python3 -c '
import shlex, sys
tokens = shlex.split(sys.stdin.read().removeprefix("Environment="))
sys.exit(0 if "LEAFHFT_AUTHZ_V2=1" in tokens else 1)
' <<< "$environment"; then
      echo "Restart refused (V2 authorization absent): $unit"
      continue
    fi
    timeout 60 systemctl restart "$unit" || break
    restarted+="${restarted:+$'\n'}$unit"
    # Remove only this exact line, without subprocesses or pattern matching.
    remaining=''
    while IFS= read -r pending; do
      [[ "$pending" == "$unit" ]] || remaining+="${remaining:+$'\n'}$pending"
    done <<< "$left"
    left=$remaining
    timeout 25 sleep 20
    timeout 30 systemctl is-active --quiet "$unit" || break
    live_units=$(timeout 60 leafhft deployed --live-units) || break
    normalize live_units
    found=0
    while IFS= read -r live_unit; do
      [[ "$live_unit" != "$unit" ]] || found=1
    done <<< "$live_units"
    [[ $found -eq 1 ]] || break
  done <<< "$units"
fi
stage=finished
