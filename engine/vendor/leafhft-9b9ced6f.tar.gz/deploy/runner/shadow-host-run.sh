#!/bin/bash
# Frozen offline Engine Lab cohort. This process receives no venue credentials.
set -euo pipefail
py="${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}"
scripts_dir="${LEAFHFT_SCRIPTS:-/opt/leafhft/scripts}"
shadow="${LEAFHFT_SHADOW_DIR:-/var/lib/leafhft/shadow}"
engines="${LEAFHFT_ENGINES_DIR:-/etc/leafhft/engines}"
results="${LEAFHFT_SHADOW_RESULTS_DIR:-$shadow/results}"
exec "$py" "$scripts_dir/kalshi_shadow_host.py" \
  --spool-dir "$shadow" --engines-dir "$engines" \
  --manifest "$shadow/manifest.json" --out-dir "$results/cohort" \
  --managed --follow
