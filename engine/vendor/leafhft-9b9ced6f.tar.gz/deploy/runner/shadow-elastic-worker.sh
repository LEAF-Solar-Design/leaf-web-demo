#!/bin/sh
# Offline inputs must be staged locally. No secrets or venue bootstrap.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
PYTHON=$(command -v python3)
if [ "${1:-}" = 'claim-run' ]; then
    shift
    # Coordinator uses the EC2 role. Only its offline children deny network.
    # Pass --fleet-name matching Terraform and --result-prefix allowed by its role.
    exec env -i PATH="$PATH" PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 \
        "$PYTHON" "$ROOT/scripts/kalshi_shadow_fleet.py" claim-run "$@"
fi
if [ "$#" -lt 5 ] || [ "$#" -gt 6 ]; then
    echo 'usage: shadow-elastic-worker.sh PLAN SHARD SPOOL ENGINES OUTPUT [--resume]' >&2
    exit 2
fi
if [ "$#" -eq 6 ] && [ "$6" != '--resume' ]; then
    exit 2
fi
exec env -i PATH="$PATH" PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 \
    "$PYTHON" "$ROOT/scripts/kalshi_shadow_fleet.py" worker \
    --plan "$1" --shard-id "$2" --spool-dir "$3" --engines-dir "$4" \
    --out-dir "$5" ${6:+"$6"}
