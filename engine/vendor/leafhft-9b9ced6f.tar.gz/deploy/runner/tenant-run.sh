#!/bin/bash
# Provision leafhft-<tenant> and its root-owned config before enabling a unit.
# Config grammar: TENANT_ID=<id>, MODE=dry_run, optional DASHBOARD_TOKEN=<bearer>.
# Input is tenant-local quote/order JSONL, never a shell command or Python config.
set -euo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export LC_ALL=C
umask 077
refuse() { echo 'Tenant dry-run configuration refused.' >&2; exit 2; }
[[ $# -ge 1 && $# -le 2 ]] || refuse
tenant=$1
role=${2:-run}
[[ $tenant =~ ^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$ ]] || refuse
[[ $role == run || $role == push ]] || refuse
[[ ${LEAFHFT_MODE:-dry_run} == dry_run ]] || refuse
[[ ${LEAFHFT_LIVE:-0} == 0 ]] || refuse
[[ -z ${LEAFHFT_TENANT_ID+x} || $LEAFHFT_TENANT_ID == "$tenant" ]] || refuse
while IFS= read -r name; do
  case "${name^^}" in
    *PRIVATE*KEY*|*KEY*PRIVATE*|*KALSHI*KEY*PATH*|*KALSHI*KEY*FILE*|*KALSHI*KEY*PEM*|*LIVE*ACK*) refuse ;;
  esac
done < <(compgen -e)
[[ $(id -un) == "leafhft-$tenant" ]] || refuse
runtime="/run/leafhft-tenants/$tenant"
state="/var/lib/leafhft-tenants/$tenant"
config="/etc/leafhft-tenants/$tenant/config.env"
safe_path() {
  local part current=''
  local -a pieces
  IFS=/ read -r -a pieces <<< "$1"
  for part in "${pieces[@]}"; do
    [[ -n $part ]] || continue
    current="$current/$part"
    [[ ! -L $current ]] || refuse
  done
}
for path in "$runtime" "$state" "$config"; do safe_path "$path"; done
[[ -d $runtime && -d $state && -f $config ]] || refuse
[[ $(stat -c %u "$config") == 0 ]] || refuse
permissions=$(stat -c %a "$config")
[[ $permissions =~ ^[0-7]{3,4}$ ]] || refuse
(( (8#$permissions & 077) == 0 )) || refuse
[[ $(stat -c %h "$config") == 1 && $(stat -c %s "$config") -le 8192 ]] || refuse
for path in /etc/leafhft-tenants "/etc/leafhft-tenants/$tenant"; do
  [[ $(stat -c %u "$path") == 0 ]] || refuse
  permissions=$(stat -c %a "$path")
  (( (8#$permissions & 022) == 0 )) || refuse
done
for path in "$runtime" "$state"; do
  [[ $(stat -c %u "$path") == "$(id -u)" ]] || refuse
  permissions=$(stat -c %a "$path")
  (( (8#$permissions & 077) == 0 )) || refuse
done
# systemd LoadCredential supplies a private copy of the root-owned source.
credential="${CREDENTIALS_DIRECTORY:-}/config"
[[ $credential == "/run/credentials/leafhft-tenant@$tenant.service/config" ||
   $credential == "/run/credentials/leafhft-push@$tenant.service/config" ]] || refuse
safe_path "$credential"
[[ -f $credential && -r $credential ]] || refuse
seen_tenant=0
seen_mode=0
seen_token=0
dashboard_token=''
while IFS= read -r line || [[ -n $line ]]; do
  [[ -z $line || $line == \#* ]] && continue
  case "$line" in
    TENANT_ID=*) (( seen_tenant == 0 )) || refuse; seen_tenant=1; [[ ${line#*=} == "$tenant" ]] || refuse ;;
    MODE=*) (( seen_mode == 0 )) || refuse; seen_mode=1; [[ ${line#*=} == dry_run ]] || refuse ;;
    DASHBOARD_TOKEN=*)
      (( seen_token == 0 )) || refuse; seen_token=1
      dashboard_token=${line#*=}
      [[ $dashboard_token =~ ^[A-Za-z0-9._-]{32,4096}$ ]] || refuse ;;
    *) refuse ;;
  esac
done < "$credential"
(( seen_tenant == 1 )) || refuse
safe_path "$state/runs"
[[ ! -e $state/runs || -d $state/runs ]] || refuse
mkdir -p -- "$state/runs"
export LEAFHFT_DASHBOARD_TOKEN="$dashboard_token"
if [[ $role == push ]]; then
  [[ -n $dashboard_token ]] || refuse
  exec env -i PATH="$PATH" HOME="$state" PYTHONUNBUFFERED=1 LEAFHFT_LIVE=0 \
    LEAFHFT_TENANT_ID="$tenant" LEAFHFT_STATE_DIR="$state" LEAFHFT_HOST="kashbot-$tenant" \
    /bin/bash -c 'IFS= read -r LEAFHFT_DASHBOARD_TOKEN; export LEAFHFT_DASHBOARD_TOKEN; exec /opt/leafhft/.venv/bin/python -m leafhft push --tenant-id "$1" --url https://ops-dashboard-seven.vercel.app --runs "$2"' \
    tenant-push "$tenant" "$state/runs" <<< "$dashboard_token"
fi
safe_path "$state/input.jsonl"
[[ -f $state/input.jsonl ]] || refuse
exec env -i PATH="$PATH" HOME="$state" PYTHONUNBUFFERED=1 LEAFHFT_LIVE=0 \
  LEAFHFT_TENANT_ID="$tenant" LEAFHFT_STATE_DIR="$state" LEAFHFT_HOST="kashbot-$tenant" \
  /opt/leafhft/.venv/bin/python -m leafhft paper --venue kalshi --strategy mm \
  --paper-orders "$state/input.jsonl" --runs "$state/runs"
