#!/bin/sh
exec /opt/leafhft/.venv/bin/python /opt/leafhft/scripts/kalshi_daily_read.py --no-notify
