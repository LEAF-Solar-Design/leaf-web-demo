#!/usr/bin/env bash
# Dedicated paper stream uploader. Uses its instance role.
set -euo pipefail
umask 077
: "${SHADOW_BUCKET:?set SHADOW_BUCKET}"
: "${SHADOW_TABLE:?set SHADOW_TABLE}"
: "${SHADOW_FLEET:?set SHADOW_FLEET}"
: "${SHADOW_SPOOL_DIR:?set SHADOW_SPOOL_DIR}"
: "${SHADOW_ENGINES_DIR:?set SHADOW_ENGINES_DIR}"
: "${AWS_REGION:?set AWS_REGION}"
queue=()
if [[ -n "${SHADOW_QUEUE_URL:-}" ]]; then
  queue=(--queue-url "$SHADOW_QUEUE_URL")
fi
exec "${PYTHON:-python3}" -m scripts.kalshi_shadow_aws upload \
  --region "$AWS_REGION" --bucket "$SHADOW_BUCKET" --table "$SHADOW_TABLE" \
  --fleet "$SHADOW_FLEET" \
  --engines-dir "$SHADOW_ENGINES_DIR" \
  --spool-dir "$SHADOW_SPOOL_DIR" "${queue[@]}" "$@"
