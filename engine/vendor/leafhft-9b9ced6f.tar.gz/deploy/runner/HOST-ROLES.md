# Runner host roles (L7c)

`install-units.sh` installs and starts a different set of units depending on which host it runs on.
The host says which one it is in one file, `/etc/leafhft-host-role`.

## The role file

- Path: `/etc/leafhft-host-role`, directly under `/etc` and not under `/etc/leafhft`. tmpfiles makes
  `/etc/leafhft` 0775 root:leafhft, and a write by the service user must never switch a host's role.
- Owner and mode: a regular file (not a symlink), owned by root, writable by nobody but root
  (0644 root:root). The installer refuses a symlink, a group- or other-writable file, and, when it
  runs as root, a file root does not own.
- Grammar: exactly one line, `runner` or `tenant`, with an optional trailing newline (a CR before it
  is stripped). An empty file, any other word (`Tenant` and `combined` included) or a second line
  exits 2 with `Invalid host role file: <reason>`, in `--check`, `--plan` and apply, before anything
  changes.
- No environment variable sets the role. If `LEAFHFT_HOST_ROLE` is set at all, even empty, the
  installer exits 2 and says to write the file instead. `LEAFHFT_HOST_ROLE_FILE` moves the path
  and exists for tests.

## What each role installs and starts

- `combined` (no role file): today's behaviour, byte for byte. Every unit file is installed,
  `enabled.txt` is the wanted set, and the registry audit timer starts. No `host role:` line is
  printed. This is the transition default, so merging and deploying this change alters nothing on
  a host that has no role file.
- `runner`: prints `host role: runner` first. `enabled.txt` is the wanted set, exactly as today.
  Every unit file is installed except the nine account unit files (`leafhft-account@`,
  `leafhft-account-push@`, `leafhft-account-sync@`, the account agent and the provisioner), and each
  skipped one is named on a `not installing` line. It never stops, disables or deletes an account
  unit or an account unit file already on the host.
- `tenant`: prints `host role: tenant` first. `enabled-tenant.txt` is the wanted set, and it may be
  empty. The installed files are the nine account unit files plus the source unit of each wanted
  line (and, for a timer, its service). The account control agent enables the account lanes at
  runtime, as it does today. The tenant list refuses every runner unit (anything in `enabled.txt`,
  wanted or drained, and any live book, the live secrets loader, a paper book or a recorder), so a
  live book never starts on the tenant host. The registry audit timer starts only when the tenant
  list names it. `LEAFHFT_INSTALL_LIVE_ONLY` is refused.

`enabled-tenant.txt` is validated in every role whenever it exists, so CI's `--check` (which runs
with no role file) rejects a bad line.

## Moving the lanes (L7d)

BE-B3 installs fifteen `leafhft-bookd@SYMBOL.service` instances through `enabled.txt`
on combined/runner hosts only. Each requires the root `leafhft-bookd-secrets.service`;
that helper is installed but never directly enabled or retired while an instance is wanted.
The installer creates the dedicated `leafhft-bookd` user through its sysusers file before
starting instances. It never adds that user to the trading or account groups.

**L7d follow-up: tenant-host bookd listing.** The UNIX sockets are host-local. Before moving
any stream consumer to a tenant host, L7d must add a tenant-specific bookd wanted set,
its secrets dependency and sysusers installation, narrow the current tenant-list refusal,
provision that host's read-only secret access, and include the streams in its health inventory.
BE-B3 does not edit `enabled-tenant.txt`; a tenant-host consumer must remain direct until
that follow-up and its S0-S3 gates in `docs/BOOK-FEED.md` are complete.

1. Create the tenant host's role file as `tenant` (0644 root:root) before its first install.
2. Move the lanes to the tenant host (L7d, operator): credentials, `/etc/leafhft-accounts` state and
   the re-arm, then compare against the L7a baseline.
3. Write `runner` on the runner. Stale account unit files left there are removed by hand after the
   lanes are proven on the tenant host.

## Static unit-health inventory

`scripts/leafhft_alert.py` (`collect_units`) reads the same role file and validation contract
as the installer. Default collection uses `enabled.txt` for combined and runner hosts, and the
adjacent `enabled-tenant.txt` for tenant hosts. An explicit inventory path bypasses role lookup
and validation. An invalid role or a missing or unreadable selected list reports collection
unavailable, without falling back to the runner list.

A comment-only tenant list returns an empty unit collection without querying systemd. This
checks only the static inventory and the services its timers trigger. It does not discover
dynamically managed account lanes, prove useful work or establish a successful tenant handoff.
The L7a baseline comparison and L7d workload move remain separate.

## Not role-aware yet

`leafhft deployed` and `deploy.sh` still read `enabled.txt` only. Run on the tenant host they
would read the runner's list. Role-aware deployment tools and dynamic account-lane handoff
evidence remain deferred. Only `collect_units` is role-aware in the alert collector; this does
not make its other collection or status reporting tenant-scoped.
