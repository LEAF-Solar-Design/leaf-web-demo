#!/bin/bash
set -euo pipefail

if [[ ${LEAFHFT_GOLD_OWNER_FENCE:-} != v1 ]]; then
  echo 'Owner Gold refused: unit fence marker missing (reload units).' >&2
  exit 4
fi

if [[ -n ${LEAFHFT_ACCOUNT_LANE_ID:-} ]]; then
  echo 'Use the account supervisor for account lanes.' >&2
  exit 2
fi

role_file=${LEAFHFT_HOST_ROLE_FILE:-/etc/leafhft-host-role}
if [[ -e "$role_file" || -L "$role_file" ]]; then
  if [[ ! -f "$role_file" || ! -r "$role_file" ]]; then
    echo 'Gold requires a readable runner host role file.' >&2
    exit 2
  fi
  # Preserve trailing newlines so only one line ending is accepted.
  role=$(cat -- "$role_file" && printf '.') || exit 2
  role=${role%.}
  role=${role%$'\n'}
  role=${role%$'\r'}
  if [[ "$role" != runner ]]; then
    echo 'Gold requires the runner host role.' >&2
    exit 2
  fi
fi

etc=${LEAFHFT_ETC:-/etc/leafhft}
stake="5.00"
if [[ -e "$etc/kalshi-gold-stake" || -L "$etc/kalshi-gold-stake" ]]; then
  [[ -f "$etc/kalshi-gold-stake" && -r "$etc/kalshi-gold-stake" ]] || exit 2
  stake=$(cat -- "$etc/kalshi-gold-stake") || exit 2
fi
if [[ ! "$stake" =~ ^[0-9]{1,2}(\.[0-9]{1,2})?$ ]]; then
  echo 'Invalid kalshi-gold-stake: expected 1.00 to 50.00.' >&2
  exit 2
fi
whole=${stake%%.*}
fraction=00
if [[ "$stake" == *.* ]]; then
  fraction=${stake#*.}
  fraction=${fraction}0
  fraction=${fraction:0:2}
fi
stake_cents=$((10#$whole * 100 + 10#$fraction))
if (( stake_cents < 100 || stake_cents > 5000 )); then
  echo 'Invalid kalshi-gold-stake: expected 1.00 to 50.00.' >&2
  exit 2
fi

export LEAFHFT_RISK_REGIME=owner
timeout 10 "${LEAFHFT_PY:-/opt/leafhft/.venv/bin/python}" -m leafhft.exposure_conformance prestart --domain legacy-owner --symbol GOLD-15M || exit 4

LEAFHFT_BUILD_SHA=""
LEAFHFT_BUILD_DIRTY=0
if build_sha="$(timeout 5 git -C /opt/leafhft -c safe.directory=/opt/leafhft rev-parse HEAD 2>/dev/null)" && [[ "$build_sha" =~ ^[0-9a-f]{40}$ ]]; then
  if build_status="$(timeout 5 git -C /opt/leafhft -c safe.directory=/opt/leafhft status --porcelain --untracked-files=no 2>/dev/null)"; then
    LEAFHFT_BUILD_SHA="$build_sha"
    if [[ -n "$build_status" ]]; then
      LEAFHFT_BUILD_DIRTY=1
    fi
  fi
fi
export LEAFHFT_BUILD_SHA LEAFHFT_BUILD_DIRTY

exec /opt/leafhft/.venv/bin/python -m leafhft.gold_live_main run --stake-usd "$stake" --seconds 86400 --ack-dir /var/lib/leafhft/gold-live-ack --run-dir /var/lib/leafhft/gold-runs
