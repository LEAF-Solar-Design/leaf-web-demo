#!/usr/bin/env bash
set -euo pipefail

rollout_now() {
  if [[ -n "${ROLLOUT_NOW_EPOCH:-}" ]]; then
    printf '%s\n' "$ROLLOUT_NOW_EPOCH"
  else
    date -u "${1:-+%s}"
  fi
}
rollout_sleep() {
  local seconds=$1 scaled
  case "${ROLLOUT_SLEEP_SCALE:-1}" in
    0) scaled=0 ;;
    1) scaled=$seconds ;;
    *)
      scaled=$(python3 -c 'import sys; print(float(sys.argv[1]) * float(sys.argv[2]))' "$seconds" "$ROLLOUT_SLEEP_SCALE")
      scaled=${scaled//$'\r'/} ;;
  esac
  if [[ "$scaled" != 0 && "$scaled" != 0.0 ]]; then sleep "$scaled"; fi
  if [[ -n "${ROLLOUT_NOW_EPOCH:-}" ]]; then
    export ROLLOUT_NOW_EPOCH=$(( ROLLOUT_NOW_EPOCH + seconds ))
  fi
}

# R7: serialize the existing deploy and rearm tools, one settlement gap per book.
fail() {
  echo "$*" >&2
  if [[ ${state_ready:-0} -eq 1 ]]; then data error "$state_file" "$*"; fi
  exit 2
}

# 23:35-00:25Z in seconds after 00:00Z (it runs past midnight).
ROLLOUT_BLACKOUT_START_S=84900
ROLLOUT_BLACKOUT_END_S=1500
# Pure arithmetic on one integer epoch, no I/O: returns 0 when a restart may start now, 3 (with
# the reason printed) outside the [60, 420] s gap of the 900 s cycle, 2 inside the 23:35-00:25Z
# blackout, 1 on an unreadable clock. Called with a fresh clock at every restart boundary.
rollout_boundary_refusal() {
  local epoch=$1 day phase
  [[ "$epoch" =~ ^[0-9]+$ ]] || { echo "restart boundary clock unreadable: $epoch"; return 1; }
  day=$(( epoch % 86400 )); phase=$(( epoch % 900 ))
  if (( phase < 60 || phase > 420 )); then
    echo "restart boundary at epoch $epoch is $phase s into the 900 s cycle, outside the [60, 420] s gap"
    return 3
  fi
  if (( day >= ROLLOUT_BLACKOUT_START_S || day < ROLLOUT_BLACKOUT_END_S )); then
    printf 'restart boundary at epoch %s (%02d:%02d:%02dZ) falls in the 23:35-00:25Z blackout\n' \
      "$epoch" $(( day / 3600 )) $(( day % 3600 / 60 )) $(( day % 60 ))
    return 2
  fi
}

# The containment marker deploy.py's check_containment refuses on. No flag or override lifts it.
ROLLOUT_CONTAINMENT=/var/lib/leafhft/CONTAINMENT
# Bash builtins only, no external command, so the fourteen-unit command sequence is unchanged.
# Returns 0 when the marker is absent, 1 (the reason printed) when it exists (a dangling link
# counts) or when its directory exists but is not a searchable directory: unreadable is treated as
# contained, deploy.py's rule for any stat error other than a missing file.
rollout_containment_refusal() {
  local marker=$1 parent
  parent=${marker%/*}
  if [[ -e "$marker" || -L "$marker" ]]; then
    echo "CONTAINMENT: $marker exists; no override lifts it"
    return 1
  fi
  if [[ -n "$parent" && ( -e "$parent" || -L "$parent" ) ]] && ! [[ -d "$parent" && -x "$parent" ]]; then
    echo "CONTAINMENT marker unreadable ($parent is not a searchable directory); treated as contained"
    return 1
  fi
  return 0
}

# Final verification of a --units subset; JSON only, fails closed on anything malformed.
# Usage: rollout_verify_subset <deployed-json> <target-sha> <unit=sha|-,...> <selected unit>...
# Every selected unit must be live on the target; every unselected unit exactly as captured
# before any mutation (live on its sha, or not live when it was not live); no other unit live;
# and the collector verdict those identities imply (DRIFTED when two shas are live, DEGRADED
# when a unit is expected not live, else IN_SYNC). Prints IN_SYNC_SUBSET naming both sets,
# then one line per unit expected live, for the status check.
rollout_verify_subset() {
  python3 - "$@" <<'PY'
import json
import re
import sys

try:
    raw, target, spec, *selected = sys.argv[1:]
    if not re.fullmatch(r"[0-9a-f]{40}", target) or not selected:
        raise ValueError("usage: <deployed-json> <target-sha> <unit=sha|-,...> <selected unit>...")
    expected = {}
    for item in filter(None, spec.split(",")):
        unit, sep, identity = item.partition("=")
        if not sep or unit in expected or not (identity == "-" or re.fullmatch(r"[0-9a-f]{40}", identity)):
            raise ValueError("malformed predecessor identity: " + item)
        expected[unit] = identity
    unselected = list(expected)
    for unit in selected:
        if unit in expected:
            raise ValueError(unit + ": both selected and unselected")
        expected[unit] = target
    report = json.loads(raw)
    if not isinstance(report, dict) or not isinstance(report.get("rows"), list):
        raise ValueError("deployed report has no rows")
    rows = {}
    for row in report["rows"]:
        if not isinstance(row, dict) or not isinstance(row.get("unit"), str) or row["unit"].strip() in rows:
            raise ValueError("deployed report has a malformed or duplicate row")
        rows[row["unit"].strip()] = row
    problems = []
    for unit, identity in expected.items():
        row = rows.get(unit)
        if row is None:
            problems.append(unit + ": no deployed row")
            continue
        live = row.get("live") is True
        sha = row.get("git_sha")
        sha = sha.strip() if isinstance(sha, str) else ""
        if identity == "-":
            if live:
                problems.append(unit + ": was not live before the rollout and is live now")
        elif not live:
            problems.append(unit + ": expected live on " + identity[:12] + ", not live")
        elif sha != identity:
            problems.append(unit + ": expected " + identity[:12] + ", running " + (sha[:12] or "no sha"))
    outside = sorted(u for u, r in rows.items() if r.get("live") is True and u not in expected)
    if outside:
        problems.append("live units outside this rollout: " + ", ".join(outside))
    shas = {identity for identity in expected.values() if identity != "-"}
    want = "DRIFTED" if len(shas) > 1 else "DEGRADED" if "-" in expected.values() else "IN_SYNC"
    verdict = str(report.get("verdict", "")).strip()
    if verdict != want:
        problems.append("verdict " + (verdict or "missing") + ", these identities imply " + want)
    if problems:
        raise ValueError("; ".join(problems))
    print("IN_SYNC_SUBSET selected=" + ",".join(selected) + " unselected=" + ",".join(unselected))
    for unit, identity in expected.items():
        if identity != "-":
            print(unit)
except (ValueError, TypeError, AttributeError) as exc:
    sys.exit("subset verification refused: " + str(exc))
PY
}

# `source rollout.sh` defines the helpers above and stops here, before any argument parsing or
# mutation, so tests run the real verifier and boundary arithmetic. Execution never returns here.
if [[ "${BASH_SOURCE[0]}" != "$0" ]]; then return 0; fi

[[ $EUID -eq 0 ]] || fail 'rollout.sh must run as root'
[[ $# -ge 1 ]] || fail 'Usage: rollout.sh <40-hex-sha> [--no-rearm] [--resume] [--units a,b,c] [--expect-unselected unit=sha|-,...] [--window-override reason] [--dry-run]'
target=$1; shift
[[ "$target" =~ ^[0-9a-fA-F]{40}$ ]] || fail 'target must be a full commit SHA'
target=${target,,}
no_rearm=0; resume=0; dry_run=0; selection=''; expect_unselected=''; window_override=''
subset=0; predecessors=''
txn=''
while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-rearm) no_rearm=1 ;;
    --resume) resume=1 ;;
    --dry-run) dry_run=1 ;;
    --units)
      [[ $# -ge 2 && -n "$2" && "$2" != --* ]] || fail '--units requires a nonempty list'
      selection=$2; shift ;;
    --expect-unselected)
      [[ $# -ge 2 && -n "$2" && "$2" != --* ]] || fail '--expect-unselected requires unit=sha|- pairs'
      expect_unselected=$2; shift ;;
    --window-override)
      [[ $# -ge 2 && -n "$2" ]] || fail '--window-override requires a reason'
      window_override=$2; shift ;;
    --txn)
      # One transaction per tag: its own state file, so --resume resumes that tag and nothing else.
      [[ $# -ge 2 && "$2" != --* && "$2" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || fail '--txn requires a tag matching [A-Za-z0-9._-]{1,64}'
      txn=$2; shift ;;
    *) fail "Unknown argument: $1" ;;
  esac
  shift
done
base=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
base=${base//$'\r'/}
cd "$base"
export PATH="$base/.venv/bin:$PATH"
state_file="/var/lib/leafhft/rollout-state/${target:0:12}.json"
[[ -z "$txn" ]] || state_file="/var/lib/leafhft/rollout-state/${target:0:12}-$txn.json"
receipt_dir=/var/lib/leafhft/rollout-receipts
stage=preflight; current=''; deploy_receipt=''; digest_may_move=1
state_ready=0; deploy_done=0; final='{"verdict":"UNREADABLE"}'
all_units=(); units=()
for book in zec-15m btc-15m eth-15m sol-15m xrp-15m doge-15m bnb-15m hype-15m near-15m btc-1h eth-1h hype-1h bnb-1h xrp-1h; do
  all_units+=("leafhft-live@kalshi-$book.service")
done

# JSON and filesystem operations only. Authorization and deployment remain in
# their existing tools. All persistent replacements stay on the same filesystem.
data() {
  python3 - "$@" <<'PY'
import datetime as dt
import json
import os
from pathlib import Path
import re
import shlex
import sys
import tempfile
import time

# A book may write its status while the verify loop runs.
STATUS_FUTURE_SKEW_S = 30

action, *args = sys.argv[1:]

def now_epoch():
    return float(os.environ.get("ROLLOUT_NOW_EPOCH") or time.time())

def read(path):
    return json.loads(Path(path).read_text())

def atomic(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".rollout-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(obj, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)

def latest(root, unit):
    label = unit.removeprefix("leafhft-live@").removesuffix(".service")
    # Include the interval so BTC-15m can never borrow BTC-1h evidence.
    paths = []
    for path in Path(root).glob("*live-kalshi-*/kalshi-edge-status.json"):
        config = path.parent / "config.json"
        if config.exists():
            cfg = read(config)
            matches = (str(cfg.get("venue", "")).lower() == "kalshi"
                       and str(cfg.get("symbol", "")).lower() == label.removeprefix("kalshi-")
                       and cfg.get("mode", "live") == "live")
        else:
            matches = re.search(r"live-" + re.escape(label) + r"(?:[^a-zA-Z0-9]|$)", path.parent.name, re.I)
        # Current CLI names runs live-kalshi-kalshi_edge; config.json binds the
        # book. Also accept the explicit per-book names used by older runners.
        if matches:
            paths.append(path)
    if not paths:
        raise ValueError(unit + ": no status file")
    path = max(paths, key=lambda p: p.stat().st_mtime_ns)
    return path, read(path)

def status(root, unit, now, restart=None, healthy=False, *, future_skew_s=0):
    path, obj = latest(root, unit)
    mtime = path.stat().st_mtime
    if not -future_skew_s <= float(now) - mtime < 120:
        raise ValueError(unit + ": stale status")
    stamp = obj.get("generated_at")
    if stamp is not None:
        stamp = dt.datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            raise ValueError("generated_at has no timezone")
        stamp = stamp.timestamp()
        if not -future_skew_s <= float(now) - stamp < 120:
            raise ValueError(unit + ": stale generated_at")
    else:
        stamp = mtime
    if restart is not None and stamp <= float(restart):
        raise ValueError(unit + ": status predates restart")
    authority = obj.get("authority")
    if not isinstance(authority, dict) or authority.get("error"):
        raise ValueError(unit + ": authority unavailable")
    if healthy:
        for block in ("engine", "policy"):
            if not isinstance(obj.get(block), dict) or obj[block].get("error", "missing") is not None:
                raise ValueError(unit + ": " + block + " error")
    else:
        if authority.get("unreconciled") or authority.get("cash_unreconciled"):
            raise ValueError(unit + ": authority unreconciled")
        if authority.get("retry_queue_depth", 0) or authority.get("retry_queue", 0) or authority.get("retry_dropped"):
            raise ValueError(unit + ": authority retry queue")
        if authority.get("intent_counts", {}).get("unknown", 0):
            raise ValueError(unit + ": unknown intent")
        for intents in (authority.get("intents", []), obj.get("intents", [])):
            for intent in (intents.values() if isinstance(intents, dict) else intents):
                if intent.get("state") == "unknown":
                    raise ValueError(unit + ": unknown intent")
    return obj

try:
    if action == "paths":
        source = Path("deploy/runner/live-run.sh").read_text()
        for flag, env in (("ack-dir", "LEAFHFT_ACK_DIR"), ("run-dir", "LEAFHFT_RUN_DIR")):
            value = os.environ.get(env)
            if not value:
                values = set(re.findall(r"--" + flag + r"\s+(/[^\s\"']+)", source))
                if len(values) != 1:
                    raise ValueError("cannot resolve --" + flag + " from live-run.sh")
                value = values.pop()
            print(value)
    elif action == "units":
        known, selection, *expected = args
        found = set(re.findall(r"leafhft-live@kalshi-[\w-]+\.service", known))
        if selection:
            requested = selection.split(",")
            if len(set(requested)) != len(requested) or any(u not in found or u not in expected for u in requested):
                raise ValueError("invalid --units subset")
        else:
            if found != set(expected):
                raise ValueError("exactly fourteen expected Kalshi units are required")
            requested = expected
        print("\n".join(requested))
    elif action == "acks":
        root, now, environment = args
        v2 = "LEAFHFT_AUTHZ_V2=1" in shlex.split(environment.removeprefix("Environment="))
        root = Path(root)
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            if path.name == "arms.jsonl":
                if v2:
                    counts = {}
                    for line in path.read_text().splitlines():
                        row = json.loads(line)
                        digest = row["digest"]
                        counts[digest] = counts.get(digest, 0) + 1
                        if max(counts[digest], row.get("starts", 0)) >= 48:
                            raise ValueError("arms journal starts >= 48: " + str(path))
            elif float(now) - path.stat().st_mtime > 6 * 86400:
                print("WARNING: ack older than 6 days: " + str(path))
    elif action == "init":
        path, target, mode, resume, *units = args
        if resume == "1":
            obj = read(path)
            if obj["target_sha"] != target or obj["selected_units"] != units or obj["no_rearm"] != int(mode):
                raise ValueError("resume state does not match target, units, or mode")
        else:
            if Path(path).exists():
                raise ValueError("state already exists; use --resume")
            obj = {"target_sha": target, "selected_units": units, "no_rearm": int(mode),
                   "deploy_done": False, "deploy_receipt": "", "digest_may_move": 1,
                   "stage": "preflight", "stage_exit": 0, "units": {u: {"stage": "pending", "timestamps": {}} for u in units}}
            atomic(path, obj)
        print(int(obj["deploy_done"]))
        print(obj["deploy_receipt"])
        print(obj["digest_may_move"])
    elif action == "update":
        path, stage, unit, step, receipt, moving = args
        obj = read(path)
        now = now_epoch()
        obj.update(stage=stage, deploy_receipt=receipt, digest_may_move=int(moving), updated_at=now)
        obj.setdefault("timestamps", {})[stage] = now
        if step == "deploy_done":
            obj["deploy_done"] = True
        if unit:
            entry = obj["units"][unit]
            entry.update(stage=step)
            entry["timestamps"][step] = now
            if step == "failed":
                entry["failed_stage"] = stage
        atomic(path, obj)
    elif action == "error":
        obj = read(args[0])
        obj["error"] = args[1]
        atomic(args[0], obj)
    elif action == "note":
        path, key, value = args
        obj = read(path)
        obj[key] = value
        atomic(path, obj)
    elif action == "held":
        # A restart boundary refused after this book's checkpoints and before its stop: nothing
        # was stopped, so it drops restart_started (left on old code) and records the refusal.
        path, unit, reason = args
        obj = read(path)
        entry = obj["units"][unit]
        entry["timestamps"].pop("restart_started", None)
        entry["timestamps"]["restart_held"] = now_epoch()
        entry.update(stage="window")
        obj["restart_held"] = reason
        atomic(path, obj)
    elif action == "predecessors":
        # Subset only: the identity of every unselected unit, captured once before any mutation
        # and kept in the state file so a resume verifies against the same pre-mutation read. A
        # resume (saved identities present) holds this run's fresh read to them and refuses on any
        # drift: a moved unselected book means another lane touched the fleet; the operator decides.
        path, raw, expect, *universe = args
        obj = read(path)
        unselected = [u for u in universe if u not in obj["selected_units"]]

        def identities(raw):
            # Fails closed: unreadable JSON, a malformed row, or a live unit without a full sha.
            try:
                report = json.loads(raw)
            except ValueError:
                raise ValueError("deployed state unreadable")
            if not isinstance(report, dict) or not isinstance(report.get("rows"), list):
                raise ValueError("deployed state unreadable")
            rows = {}
            for row in report["rows"]:
                if not isinstance(row, dict) or not isinstance(row.get("unit"), str):
                    raise ValueError("deployed state has a malformed row")
                rows[row["unit"].strip()] = row
            found = {}
            for unit in unselected:
                row = rows.get(unit, {})
                if row.get("live") is True:
                    sha = row.get("git_sha")
                    sha = sha.strip() if isinstance(sha, str) else ""
                    if not re.fullmatch(r"[0-9a-f]{40}", sha):
                        raise ValueError(unit + ": live without a full sha")
                    found[unit] = sha
                else:
                    found[unit] = "-"
            return found

        fresh = None
        if "predecessors" not in obj:
            started = [u for u, v in obj["units"].items() if "restart_started" in v["timestamps"]]
            if obj["deploy_done"] or started:
                raise ValueError("state has no predecessor identities and mutation already began")
            obj["predecessors"] = identities(raw)
            atomic(path, obj)
        else:
            fresh = identities(raw)
        captured = obj["predecessors"]
        if set(captured) != set(unselected):
            raise ValueError("stored predecessor identities do not cover the unselected units")
        if fresh is not None:
            drift = [u + ": saved " + captured[u][:12] + ", found " + fresh[u][:12]
                     for u in unselected if fresh[u] != captured[u]]
            if drift:
                raise ValueError("predecessor_drift: " + "; ".join(drift)
                                 + "; resume refused, an unselected book moved since the rollout began")
        if expect:
            named = {}
            for item in expect.split(","):
                unit, sep, identity = item.partition("=")
                if not sep or unit in named or not (identity == "-" or re.fullmatch(r"[0-9a-f]{40}", identity)):
                    raise ValueError("--expect-unselected must be unit=<40-hex>|- pairs")
                named[unit] = identity
            if set(named) != set(unselected):
                raise ValueError("--expect-unselected must name exactly the unselected units")
            moved = [u + ": expected " + named[u][:12] + ", found " + captured[u][:12]
                     for u in unselected if named[u] != captured[u]]
            if moved:
                raise ValueError("unselected identities moved since the caller's read: " + "; ".join(moved))
        print(",".join(u + "=" + captured[u] for u in unselected))
    elif action == "unit-stage":
        print(read(args[0])["units"][args[1]]["stage"])
    elif action == "deploy-receipt":
        output, target = args
        paths = [line.split("receipt: ", 1)[1].strip() for line in output.splitlines() if line.startswith("receipt: ")]
        if not paths:
            raise ValueError("deploy did not print a receipt")
        obj = read(paths[-1])
        if obj.get("target_sha") != target or obj.get("stage") != "finished" or obj.get("stage_exit") != 0:
            raise ValueError("deploy did not finish successfully: " + paths[-1])
        moving = obj.get("digest_may_move")
        if type(moving) is not int or moving not in (0, 1):
            raise ValueError("invalid digest_may_move")
        print(paths[-1])
        print(moving)
    elif action == "precheck":
        status(*args)
    elif action == "fresh":
        # Only the subset's final check omits the restart timestamp.
        status(*args, healthy=True, future_skew_s=STATUS_FUTURE_SKEW_S if len(args) == 3 else 0)
    elif action == "plan":
        raw, unit = args
        plan = json.loads(raw)
        if isinstance(plan.get("refused"), list) and plan["refused"]:
            print("rearm refused: " + "; ".join(map(str, plan["refused"])), file=sys.stderr)
            sys.exit(2)
        if plan.get("refused") == [] and plan.get("plans") == []:
            sys.exit(3)
        if plan.get("refused") != [] or len(plan.get("plans", [])) != 1 or plan["plans"][0].get("unit") != unit:
            raise ValueError("rearm must produce exactly one plan and no refusal")
    elif action == "verify":
        raw, target, root, now, *units = args
        obj = json.loads(raw)
        rows = [r for r in obj["rows"] if r.get("live") is True]
        if (obj.get("verdict", "").strip() != "IN_SYNC" or len(rows) != 14
                or {r["unit"].strip() for r in rows} != set(units)
                or {r.get("git_sha", "").strip() for r in rows} != {target}):
            raise ValueError("deployed must have fourteen live target rows and verdict IN_SYNC")
        for unit in units:
            status(root, unit, now, healthy=True, future_skew_s=STATUS_FUTURE_SKEW_S)
    elif action == "finish":
        path, ready, directory, target, stage, code, current, receipt, moving, raw, *units = args
        obj = read(path) if ready == "1" else {"target_sha": target, "units": {u: {"stage": "pending", "timestamps": {}} for u in units}}
        if current and code != "0" and current in obj["units"]:
            entry = obj["units"][current]
            entry.update(stage="failed", failed_stage=stage)
            entry["timestamps"]["failed"] = now_epoch()
        try:
            report = json.loads(raw)
        except ValueError:
            report = {"verdict": "UNREADABLE", "output": raw}
        if not isinstance(report, dict):
            report = {"verdict": "UNREADABLE", "output": raw}
        obj.update(stage=stage, stage_exit=int(code), deploy_receipt=receipt or None,
                   digest_may_move=int(moving), final_deployed=report,
                   final_deployed_verdict=report.get("verdict", "UNREADABLE"))
        obj["units_verified"] = [u for u, v in obj["units"].items() if v["stage"] == "verified"]
        obj["units_left_on_old_code"] = [u for u, v in obj["units"].items()
                                         if v["stage"] != "verified" and "restart_started" not in v["timestamps"]]
        obj["units_unverified"] = [u for u in obj["units"] if u not in obj["units_verified"]]
        if ready == "1":
            atomic(path, obj)
        stamp = dt.datetime.fromtimestamp(now_epoch(), dt.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        receipt_path = Path(directory) / (stamp + "-" + target[:12] + ".json")
        atomic(receipt_path, obj)
        print(receipt_path)
except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
    sys.exit(str(exc))
PY
}

finish() {
  local code=$? receipt
  trap - EXIT
  set +e
  if [[ $dry_run -eq 0 ]]; then
    if [[ $code -ne 0 ]]; then
      final=$(timeout 60 leafhft deployed --json)
      # Preserve the original selection and mode when resuming a subset.
      printf 'Remaining command: ' >&2
      printf 'bash deploy/runner/rollout.sh %q --resume' "$target" >&2
      [[ $no_rearm -eq 0 ]] || printf ' --no-rearm' >&2
      [[ -z "$selection" ]] || printf ' --units %q' "$selection" >&2
      [[ -z "$expect_unselected" ]] || printf ' --expect-unselected %q' "$expect_unselected" >&2
      [[ -z "$window_override" ]] || printf ' --window-override %q' "$window_override" >&2
      # A tagged run resumes its own transaction; without --txn --resume would select the sha-only state.
      [[ -z "$txn" ]] || printf ' --txn %q' "$txn" >&2
      printf '\n' >&2
    fi
    receipt=$(data finish "$state_file" "$state_ready" "$receipt_dir" "$target" "$stage" "$code" "$current" "$deploy_receipt" "$digest_may_move" "$final" "${units[@]}")
    if [[ $? -eq 0 ]]; then echo "receipt: $receipt"; else echo 'rollout receipt write failed' >&2; code=2; fi
  fi
  exit "$code"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

REARM_REFUSAL_WAIT_S=${REARM_REFUSAL_WAIT_S:-90}
case "$REARM_REFUSAL_WAIT_S" in
  ''|*[!0-9]*|????*) fail 'REARM_REFUSAL_WAIT_S must be an integer in 10..600' ;;
esac
while [[ "$REARM_REFUSAL_WAIT_S" == 0* && ${#REARM_REFUSAL_WAIT_S} -gt 1 ]]; do
  REARM_REFUSAL_WAIT_S=${REARM_REFUSAL_WAIT_S#0}
done
(( REARM_REFUSAL_WAIT_S >= 10 && REARM_REFUSAL_WAIT_S <= 600 )) || fail 'REARM_REFUSAL_WAIT_S must be an integer in 10..600'
# CONTAINMENT refuses before any read or mutation, --dry-run and --resume included.
containment=$(rollout_containment_refusal "$ROLLOUT_CONTAINMENT") || fail "$containment"

known=$(timeout 30 systemctl list-units --all --plain --no-legend 'leafhft-live@kalshi-*')
known+=$'\n'$(timeout 30 systemctl list-unit-files --no-legend 'leafhft-live@kalshi-*' || true)  # no instance unit FILES exist on a real host; an empty match is not an error
selected=$(data units "$known" "$selection" "${all_units[@]}")
selected=${selected//$'\r'/}
mapfile -t units <<< "$selected"
if [[ $no_rearm -eq 1 && ${#units[@]} -ne 14 ]]; then
  fail '--no-rearm requires all fourteen units because deploy.sh restarts the whole live fleet'
fi
# Fewer than fourteen units is a subset rollout: unselected books keep their code and lifecycle.
[[ ${#units[@]} -eq ${#all_units[@]} ]] || subset=1
[[ $subset -eq 1 || -z "$expect_unselected" ]] || fail '--expect-unselected needs a --units subset'
paths=$(data paths)
paths=${paths//$'\r'/}
ack_dir=${paths%%$'\n'*}; runs_dir=${paths#*$'\n'}
environments=''
for unit in "${units[@]}"; do
  environment=$(timeout 30 systemctl show -p Environment "$unit")
  environments+=" ${environment#Environment=}"
done
now=$(rollout_now); now=${now//$'\r'/}
data acks "$ack_dir" "$now" "$environments"

if [[ $dry_run -eq 1 ]]; then
  printf 'bash deploy/runner/deploy.sh %q\n' "$target"
  if [[ $no_rearm -eq 1 ]]; then
    echo 'If deploy receipt digest_may_move is 0:'
    printf 'bash deploy/runner/deploy.sh %q --restart-unchanged\n' "$target"
    echo 'Otherwise refuse --no-rearm.'
  else
    for unit in "${units[@]}"; do
      echo "# $unit: wait for epoch % 900 in [60,420], at most 1200 seconds; precheck fresh authority status"
      echo 'date -u +%s'
      echo '# Outside the window: sleep 15, then check date again'
      printf 'systemctl stop %q\nsystemctl show --property=ActiveState --value %q\nsystemctl start %q\n' "$unit" "$unit" "$unit"
      echo "# Poll the rearm plan every 3 seconds for at most ${REARM_REFUSAL_WAIT_S}s; abort on refusal or non-gate failure"
      printf 'python3 deploy/runner/rearm.py --plan %q\npython3 deploy/runner/rearm.py --apply %q\n' "$unit" "$unit"
      printf 'systemctl is-active %q\nleafhft deployed --live-units\n' "$unit"
      echo '# Verify status newer than restart; atomically checkpoint verified'
    done
  fi
  echo 'leafhft deployed --json'
  exit 0
fi

if [[ $subset -eq 1 ]]; then
  # install-units.sh (run by deploy.sh) starts only these live instances and enables every other
  # one without --now, so an inactive or failed unselected book never starts here.
  live_only=''
  for unit in "${units[@]}"; do
    instance=${unit#leafhft-live@}
    live_only+="${live_only:+,}${instance%.service}"
  done
  export LEAFHFT_INSTALL_LIVE_ONLY=$live_only
fi
saved=$(data init "$state_file" "$target" "$no_rearm" "$resume" "${units[@]}")
saved=${saved//$'\r'/}
mapfile -t saved_fields <<< "$saved"
deploy_done=${saved_fields[0]}; deploy_receipt=${saved_fields[1]}; digest_may_move=${saved_fields[2]}
state_ready=1
checkpoint() { data update "$state_file" "$stage" "$current" "$1" "$deploy_receipt" "$digest_may_move"; }
if [[ $subset -eq 1 ]]; then
  # The unselected identities, read before any mutation (and cross-checked against the caller's
  # own read when --expect-unselected names it); the final verifier holds every one to it. On
  # --resume this fresh read must equal the saved identities (predecessor_drift refuses).
  pre=$(timeout 60 leafhft deployed --json) || true
  predecessors=$(data predecessors "$state_file" "$pre" "$expect_unselected" "${all_units[@]}" 2>&1) \
    || fail "predecessor identities refused before this run mutates anything: $predecessors"
  predecessors=${predecessors//$'\r'/}
fi
run_deploy() {
  local output code=0 parsed line
  output=$(bash deploy/runner/deploy.sh "$target" "$@") || code=$?
  printf '%s\n' "$output"
  while IFS= read -r line; do
    if [[ "$line" == 'receipt: '* ]]; then
      deploy_receipt=${line#receipt: }; deploy_receipt=${deploy_receipt//$'\r'/}
    fi
  done <<< "$output"
  # deploy's exit is the fleet verdict. A completed source move can leave the
  # old fleet DEGRADED/DRIFTED until this orchestrator has rearmed each book.
  [[ $code -le 2 ]] || fail "deploy command failed ($code)"
  parsed=$(data deploy-receipt "$output" "$target") || fail 'deploy receipt refused'
  parsed=${parsed//$'\r'/}
  deploy_receipt=${parsed%$'\n'*}; digest_may_move=${parsed##*$'\n'}
}
stage=deploy
checkpoint entered
if [[ $deploy_done -eq 0 ]]; then
  run_deploy
  checkpoint deploy_done
fi

if [[ $no_rearm -eq 1 ]]; then
  [[ $digest_may_move -eq 0 ]] || fail '--no-rearm refused: digest may move'
  pending=0
  for unit in "${units[@]}"; do
    completed=$(data unit-stage "$state_file" "$unit")
    completed=${completed//$'\r'/}
    [[ "$completed" == verified ]] || pending=1
  done
  if [[ $pending -eq 1 ]]; then
    run_deploy --restart-unchanged
    [[ $digest_may_move -eq 0 ]] || fail 'restart-unchanged digest proof changed'
  fi
else
  for unit in "${units[@]}"; do
    completed=$(data unit-stage "$state_file" "$unit")
    completed=${completed//$'\r'/}
    [[ $resume -eq 0 || "$completed" != verified ]] || continue
    current=$unit; stage=window
    checkpoint window
    start=$(rollout_now); start=${start//$'\r'/}
    while :; do
      while :; do
        now=$(rollout_now); now=${now//$'\r'/}
        (( now - start < 1200 )) || fail "$unit: window timed out after twenty minutes"
        phase=$(( now % 900 ))
        if (( phase >= 60 && phase <= 420 )); then break; fi
        rollout_sleep 15
      done
      now=$(rollout_now +%s.%N); now=${now//$'\r'/}
      data precheck "$runs_dir" "$unit" "$now"
      checkpoint prechecked
      stage=rearm
      restart=$(rollout_now +%s.%N); restart=${restart//$'\r'/}
      checkpoint restart_started
      stop_started=$(rollout_now); stop_started=${stop_started//$'\r'/}
      # CONTAINMENT immediately before this book's stop, on both paths: the book is left unstopped
      # (`data held` drops its restart_started, so it counts as left on old code) and the rollout ends.
      if ! containment=$(rollout_containment_refusal "$ROLLOUT_CONTAINMENT"); then
        stage=window
        data held "$state_file" "$unit" "$unit: $containment"
        fail "$unit: $containment; stopping before this book's stop"
      fi
      # Fourteen units: exactly the pre-L16a sequence, no boundary re-check (the verb's admission
      # projection covers the whole run); tests pin it against the pre-L16a script command by command.
      [[ $subset -eq 1 ]] || break
      # The restart boundary itself, on the clock read after the precheck and every checkpoint
      # write and immediately before the stop: the gap again and the 23:35-00:25Z blackout, which
      # stops the rollout between books. A refusal leaves the book unstopped: `data held` drops
      # its restart_started, so it counts as left on old code, and outside the gap it waits again.
      boundary_code=0
      boundary_reason=$(rollout_boundary_refusal "$stop_started") || boundary_code=$?
      if [[ $boundary_code -eq 0 ]]; then break; fi
      if [[ $boundary_code -eq 2 && -n "$window_override" ]]; then
        echo "window override ($window_override): $unit: $boundary_reason"
        break
      fi
      stage=window
      data held "$state_file" "$unit" "$unit: $boundary_reason"
      [[ $boundary_code -eq 3 ]] || fail "$unit: $boundary_reason; stopping between books"
    done
    timeout 30 systemctl stop "$unit"
    while :; do
      stop_now=$(rollout_now); stop_now=${stop_now//$'\r'/}
      remaining=$(( 30 - stop_now + stop_started ))
      (( remaining > 0 )) || fail "$unit: stop did not settle within 30 seconds"
      active=$(timeout "$remaining" systemctl show --property=ActiveState --value "$unit")
      active=${active//$'\r'/}
      [[ "$active" != inactive && "$active" != failed ]] || break
      rollout_sleep 1
    done
    checkpoint stopped
    timeout 30 systemctl start "$unit"
    checkpoint started
    held_at=''
    while :; do
      refusal_started=$(rollout_now); refusal_started=${refusal_started//$'\r'/}
      while :; do
        refusal_now=$(rollout_now); refusal_now=${refusal_now//$'\r'/}
        remaining=$(( REARM_REFUSAL_WAIT_S - refusal_now + refusal_started ))
        (( remaining > 0 )) || fail "$unit: no fresh gate refusal within ${REARM_REFUSAL_WAIT_S}s"
        plan_code=0
        # rearm.py uses positional units, not a --unit option.
        plan=$(timeout "$remaining" python3 deploy/runner/rearm.py --plan "$unit") || plan_code=$?
        [[ $plan_code -ne 124 ]] || fail "$unit: no fresh gate refusal within ${REARM_REFUSAL_WAIT_S}s"
        parsed_code=0
        plan_message=$(data plan "$plan" "$unit" 2>&1) || parsed_code=$?
        if [[ $parsed_code -eq 0 && $plan_code -eq 0 ]]; then break; fi
        [[ $parsed_code -eq 3 ]] || fail "$unit: $plan_message"
        [[ $plan_code -eq 0 ]] || fail "$unit: rearm plan command failed ($plan_code)"
        active=$(timeout 15 systemctl show --property=ActiveState --value "$unit")
        active=${active//$'\r'/}
        if [[ "$active" == failed ]]; then
          failure=$(timeout 15 systemctl show -p Result,ExecMainStatus "$unit")
          failure=${failure//$'\r'/}
          [[ $'\n'"$failure"$'\n' == *$'\nExecMainStatus=4\n'* ]] || fail "$unit: non-gate failure: $failure"
        fi
        rollout_sleep 3
      done
      checkpoint planned
      # CONTAINMENT before the re-arm, on both paths: the book stays gate-closed and unacked.
      # rearm.py --apply refuses on the marker too; this names the reason before calling it.
      containment=$(rollout_containment_refusal "$ROLLOUT_CONTAINMENT") \
        || fail "$unit: $containment; stopping with this book gate-closed before its re-arm"
      # Fourteen units: the pre-L16a sequence, straight to the apply below (see the admission boundary).
      [[ $subset -eq 1 ]] || break
      # rearm.py --apply stops and starts the book again (rearm.py apply_plan), so that restart is a
      # boundary too. rearm.py runs the guard itself, after its own journal read and immediately
      # before its stop, so no read sits between the last check and the stop; --window-override
      # reaches it and lifts only the blackout. 3: outside the gap, 4: inside the blackout, and
      # either way the book was not stopped. Outside the gap the re-arm is held (bounded, one
      # cycle) and the plan re-read; inside the blackout the rollout stops with this book
      # gate-closed, which trades nothing.
      rearm_code=0
      rearm_output=$(LEAFHFT_REARM_WINDOW_GUARD=1 LEAFHFT_REARM_WINDOW_OVERRIDE="$window_override" \
        timeout 120 python3 deploy/runner/rearm.py --apply "$unit") || rearm_code=$?
      rearm_output=${rearm_output//$'\r'/}
      [[ -z "$rearm_output" ]] || printf '%s\n' "$rearm_output"
      if [[ $rearm_code -eq 0 ]]; then break; fi
      boundary=$(rollout_now); boundary=${boundary//$'\r'/}
      boundary_reason="restart boundary refused (rearm.py exited $rearm_code)"
      while IFS= read -r line; do
        [[ "$line" != 'window refused: '* ]] || boundary_reason=${line#window refused: }
      done <<< "$rearm_output"
      [[ $rearm_code -ne 4 ]] \
        || fail "$unit: re-arm $boundary_reason; stopping with this book gate-closed before its re-arm restart"
      [[ $rearm_code -eq 3 ]] || fail "$unit: rearm apply failed ($rearm_code)"
      [[ -n "$held_at" ]] || held_at=$boundary
      echo "$unit: re-arm $boundary_reason; holding the re-arm restart for the next gap"
      data note "$state_file" rearm_held "$unit: re-arm $boundary_reason"
      checkpoint rearm_held
      while :; do
        (( boundary - held_at < 900 )) \
          || fail "$unit: re-arm restart held since epoch $held_at without reaching a gap; stopping with this book gate-closed"
        rollout_sleep 15
        boundary=$(rollout_now); boundary=${boundary//$'\r'/}
        phase=$(( boundary % 900 ))
        if (( phase >= 60 && phase <= 420 )); then break; fi
      done
    done
    if [[ $subset -eq 0 ]]; then
      timeout 120 python3 deploy/runner/rearm.py --apply "$unit"
    fi
    checkpoint applied
    stage=verify
    fresh_started=$(rollout_now); fresh_started=${fresh_started//$'\r'/}
    while :; do
      active=$(timeout 30 systemctl is-active "$unit" 2>/dev/null || true)
      active=${active//$'\r'/}
      live=$(timeout 60 leafhft deployed --live-units 2>/dev/null || true)
      live=${live//$'\r'/}
      found=0
      while IFS= read -r row; do [[ "$row" != "$unit" ]] || found=1; done <<< "$live"
      now=$(rollout_now +%s.%N); now=${now//$'\r'/}
      if [[ "$active" == active && $found -eq 1 ]] \
          && data fresh "$runs_dir" "$unit" "$now" "$restart" 2>/dev/null; then break; fi
      fresh_now=$(rollout_now); fresh_now=${fresh_now//$'\r'/}
      (( fresh_now - fresh_started < 90 )) || fail "$unit: readiness unavailable within 90 seconds"
      rollout_sleep 5
    done
    checkpoint verified
    current=''
  done
fi
stage=verify
checkpoint entered
if [[ $subset -eq 1 ]]; then
  # A subset leaves the fleet on two shas, so the collector reads DRIFTED and exits 1.
  final=$(timeout 60 leafhft deployed --json) || true
  verified=$(rollout_verify_subset "$final" "$target" "$predecessors" "${units[@]}" 2>&1) \
    || fail "final verification: $verified"
  verified=${verified//$'\r'/}
  mapfile -t verified_lines <<< "$verified"
  now=$(rollout_now +%s.%N); now=${now//$'\r'/}
  for unit in "${verified_lines[@]:1}"; do
    data fresh "$runs_dir" "$unit" "$now" || fail "final verification: $unit status unhealthy"
  done
  echo "${verified_lines[0]}"
  data note "$state_file" subset_verdict "${verified_lines[0]}"
else
  final=$(timeout 60 leafhft deployed --json)
  now=$(rollout_now +%s.%N); now=${now//$'\r'/}
  data verify "$final" "$target" "$runs_dir" "$now" "${all_units[@]}"
fi
if [[ $no_rearm -eq 1 ]]; then
  for unit in "${units[@]}"; do current=$unit; checkpoint verified; done
  current=''
fi
stage=finished
checkpoint finished
