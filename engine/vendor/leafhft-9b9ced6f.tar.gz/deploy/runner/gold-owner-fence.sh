#!/bin/bash
set -euo pipefail
shopt -s nullglob

root=${1-/etc/leafhft-accounts}
if [[ ! -e "$root" && ! -L "$root" ]]; then
  exit 0
fi
if [[ ! -d "$root" || ! -r "$root" || ! -x "$root" ]]; then
  printf 'Owner Gold refused: accounts root %s is not a readable, searchable directory.\n' "$root" >&2
  exit 1
fi

for lane in "$root"/*; do
  if [[ -d "$lane" && ( ! -r "$lane" || ! -x "$lane" ) ]]; then
    printf 'Owner Gold refused: lane %s is not a readable, searchable directory.\n' "$lane" >&2
    exit 1
  fi
done

for gold_opt_in in "$root"/*/gold.json; do
  if [[ -e "$gold_opt_in" || -L "$gold_opt_in" ]]; then
    printf 'Owner Gold refused: lane %s has opted into Gold.\n' "${gold_opt_in%/gold.json}" >&2
    exit 1
  fi
done
exit 0
