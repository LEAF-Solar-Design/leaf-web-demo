# Spot recorder host

This deployment supports the LeafHFT spot data collection lane on the separate
Ubuntu 24.04 recorder host. The default enabled set configures Coinbase and Kraken
independently for nine symbols per venue.
Each symbol writes under `/var/lib/leafhft-rec/runs/<venue>/<symbol>`.

## Install

Run `sudo bash deploy/recorder/install.sh <40-character sha>` on the recorder host.
The host must already have the `leafhft` user, `/opt/leafhft-rec/venv` with boto3,
chrony, and its instance role. No AWS CLI or stored credentials are required.
The bundle must contain the repository contents at its root and be published at
`code/leafhft-<sha>.tar.gz` in `leaf-leafhft-tapes-807034087062-us-east-1`, with a
full-object SHA256 checksum returned by HeadObject with checksum mode enabled.

The installer verifies the downloaded bytes before extraction or activation.
It retains releases at `/opt/leafhft-rec/src.<sha>`, installs the package editable
in the existing venv, and swaps the `src` symlink atomically. On the first install,
an existing real `src` directory is preserved as `src.before-recorder-installer`;
that initial conversion requires a brief rename before the link is installed.
Repeated installs verify the bundle again and reuse its marked release directory.
A host-local lock serializes installs. Releases and the initial backup are not
deleted. A package-install or service failure exits nonzero; rerun the same SHA
after correcting the failed step. Activation is not a whole-install transaction.

All 20 entries in `enabled.txt` are enabled and restarted: 18 recorder services
and the offload and clock timers. Other loaded or installed recorder units are
stopped and disabled. Unit active states are printed.
For rollback, install a previously published SHA; keep its bundle and checksum.

## Offload and clock evidence

The hourly timer calls the unchanged runner tape offloader once per valid symbol
directory, sequentially, using `recorder/<venue>/<symbol>` as the S3 prefix.
It retains three days, with an 8 GB free-space target. A failed symbol does not
skip the remaining symbols, and any failure produces exit status 1. The service
has a 3300-second overall timeout, so a large backlog can require later runs.
The executable boto3 shim accepts only checksum-aware put-object and head-object
requests and rejects keys outside `recorder/` before creating an S3 client.

Every ten minutes the clock timer appends UTC, chrony reference, signed system
offset (negative means slow), and last offset to `runs/clock/chrony.jsonl`.
The offload wrapper also uploads a locked snapshot to `recorder/clock/chrony.jsonl`
and checks remote size and checksum. The tape offloader excludes clock filenames,
so this separate snapshot preserves its existing rules. Local clock logs are kept.

Inspect `systemctl status leafhft-rec-coinbase@BTC-USD.service` and the corresponding
Kraken unit, plus `journalctl -u leafhft-rec-offload.service` and
`journalctl -u leafhft-rec-clock.service` for failures.

## Configured coverage

`enabled.txt` configures BTC-USD, ETH-USD, SOL-USD, XRP-USD, DOGE-USD, BNB-USD,
HYPE-USD, NEAR-USD and ZEC-USD for each of Coinbase and Kraken, plus
`leafhft-rec-offload.timer` and `leafhft-rec-clock.timer`.
This is the configured default set, not proof of live or healthy feeds.
Confirm the installed bundle, feed symbol mappings (including Kraken's v2 DOGE
websocket symbol), and fresh per-venue, per-symbol output before claiming live
coverage. Any required feed repair must be in the installed bundle before its
repaired behavior is available. A unit file alone does not establish working
feed coverage.

## Verification

`python -m pytest tests/test_recorder_host_units.py -q`
