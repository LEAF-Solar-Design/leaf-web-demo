#!/bin/bash
set -euo pipefail
shopt -s nullglob
status=0
for venue in coinbase kraken; do
    for directory in /var/lib/leafhft-rec/runs/"$venue"/*; do
        [[ -d "$directory" && ! -L "$directory" ]] || continue
        symbol=${directory##*/}
        [[ "$symbol" =~ ^[A-Z0-9]+-USD$ ]] || continue
        /usr/bin/python3 /opt/leafhft-rec/src/deploy/runner/tape_offload.py \
            --runs-root "$directory" --prefix "recorder/$venue/$symbol" \
            --state-dir /var/lib/leafhft-rec/offload --keep-days 3 --min-free-gb 8 \
            --aws /opt/leafhft-rec/src/deploy/recorder/aws_s3api_shim.py || status=1
    done
done
# Clock logs are not tape filenames. Upload a locked snapshot separately, without reclamation.
/usr/bin/python3 - <<'PY' || status=1
import base64
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

path = Path("/var/lib/leafhft-rec/runs/clock/chrony.jsonl")
if not path.exists():
    raise SystemExit(0)
with path.open("rb") as stream:
    fcntl.flock(stream, fcntl.LOCK_SH)
    data = stream.read()
digest = base64.b64encode(hashlib.sha256(data).digest()).decode("ascii")
aws = "/opt/leafhft-rec/src/deploy/recorder/aws_s3api_shim.py"
common = ["--bucket", "leaf-leafhft-tapes-807034087062-us-east-1",
          "--key", "recorder/clock/chrony.jsonl"]
with tempfile.NamedTemporaryFile(dir="/var/lib/leafhft-rec/offload") as snapshot:
    snapshot.write(data)
    snapshot.flush()
    subprocess.run([aws, "s3api", "put-object", *common, "--body", snapshot.name,
                    "--checksum-algorithm", "SHA256", "--checksum-sha256", digest,
                    "--output", "json"], check=True, timeout=120)
    result = subprocess.run([aws, "s3api", "head-object", *common, "--checksum-mode", "ENABLED",
                             "--output", "json"], check=True, capture_output=True, text=True, timeout=120)
    head = json.loads(result.stdout)
    if head.get("ContentLength") != len(data) or head.get("ChecksumSHA256") != digest:
        raise ValueError("clock snapshot checksum mismatch")
PY
exit "$status"
