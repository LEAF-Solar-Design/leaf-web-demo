#!/bin/bash
set -euo pipefail
[[ $# == 1 && "$1" =~ ^[0-9a-f]{40}$ ]] || { echo 'usage: install.sh <40-character sha>' >&2; exit 2; }
[[ $EUID == 0 ]] || { echo 'install requires root' >&2; exit 2; }
sha=$1
base=/opt/leafhft-rec
exec 9>"$base/install.lock"
flock -n 9
"$base/venv/bin/python" - "$sha" <<'PY'
import base64
import hashlib
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile
import boto3

sha = sys.argv[1]
base = Path("/opt/leafhft-rec")
release = base / ("src." + sha)
key = "code/leafhft-" + sha + ".tar.gz"
client = boto3.client("s3")
bucket = "leaf-leafhft-tapes-807034087062-us-east-1"
head = client.head_object(Bucket=bucket, Key=key, ChecksumMode="ENABLED")
expected = head.get("ChecksumSHA256")
with tempfile.TemporaryFile() as archive:
    client.download_fileobj(bucket, key, archive)
    archive.seek(0)
    digest = hashlib.file_digest(archive, "sha256")
    actual = base64.b64encode(digest.digest()).decode("ascii")
    if not expected or actual != expected:
        raise SystemExit("refused: bundle checksum mismatch or missing ChecksumSHA256")
    if release.is_symlink():
        raise SystemExit("refused: release is a symlink")
    if release.exists():
        if (release / ".bundle_checksum_sha256").read_text().strip() != actual:
            raise SystemExit("refused: existing release checksum differs")
    else:
        with tempfile.TemporaryDirectory(prefix=".install-", dir=base) as staging:
            tree = Path(staging) / "source"
            tree.mkdir()
            archive.seek(0)
            with tarfile.open(fileobj=archive, mode="r:gz") as bundle:
                # Ubuntu 24.04 Python: data filter rejects escaping paths and links.
                bundle.extractall(tree, filter="data")
            (tree / ".deployed_sha").write_text(sha + "\n")
            (tree / ".bundle_checksum_sha256").write_text(actual + "\n")
            os.rename(tree, release)

# Validate the allowlist before changing packages, the source link, or services.
enabled = (release / "deploy/recorder/enabled.txt").read_text().splitlines()
if not enabled or len(enabled) != len(set(enabled)):
    raise SystemExit("refused: empty or duplicate enabled units")
for unit in enabled:
    match = re.fullmatch(r"leafhft-rec-(coinbase|kraken)@([A-Z0-9]+-USD)\.service", unit)
    if match:
        template = "leafhft-rec-" + match[1] + "@.service"
    elif unit in ("leafhft-rec-offload.timer", "leafhft-rec-clock.timer"):
        template = unit
    else:
        raise SystemExit("refused: invalid enabled unit: " + unit)
    if not (release / "deploy/recorder/units" / template).is_file():
        raise SystemExit("refused: missing unit template")
subprocess.run([str(base / "venv/bin/pip"), "install", "-e", str(release)], check=True)
for name in ("aws_s3api_shim.py", "offload-all.sh", "clock-log.sh", "install.sh"):
    (release / "deploy/recorder" / name).chmod(0o755)
current = base / "src"
with tempfile.TemporaryDirectory(prefix=".link-", dir=base) as staging:
    link = Path(staging) / "src"
    link.symlink_to(release, target_is_directory=True)
    if current.exists() and not current.is_symlink():
        # Preserve the initial extracted deployment. Subsequent swaps are atomic.
        backup = base / "src.before-recorder-installer"
        if backup.exists():
            raise SystemExit("refused: initial source backup already exists")
        current.rename(backup)
    os.replace(link, current)
PY
install -d -o leafhft -g leafhft -m 0750 \
    /var/lib/leafhft-rec /var/lib/leafhft-rec/runs /var/lib/leafhft-rec/offload \
    /var/lib/leafhft-rec/runs/clock
mapfile -t enabled < "$base/src/deploy/recorder/enabled.txt"
for unit in "${enabled[@]}"; do
    if [[ "$unit" =~ ^leafhft-rec-(coinbase|kraken)@([A-Z0-9]+-USD)\.service$ ]]; then
        install -d -o leafhft -g leafhft -m 0750 \
            "/var/lib/leafhft-rec/runs/${BASH_REMATCH[1]}" \
            "/var/lib/leafhft-rec/runs/${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
    fi
done
install -m 0644 "$base/src/deploy/recorder/units/"* /etc/systemd/system/
systemctl daemon-reload
# Include loaded instances as well as installed unit files; templates cannot run.
known=$(systemctl list-unit-files 'leafhft-rec-*' --no-legend --no-pager; \
        systemctl list-units --all 'leafhft-rec-*' --plain --no-legend --no-pager)
while read -r unit _; do
    [[ "$unit" == leafhft-rec-* && "$unit" != *@.service ]] || continue
    keep=false
    for wanted in "${enabled[@]}"; do
        [[ "$unit" != "$wanted" ]] || keep=true
    done
    if [[ "$keep" == false ]]; then
        systemctl stop "$unit"
        systemctl disable "$unit"
    fi
done <<< "$known"
systemctl enable "${enabled[@]}"
systemctl restart "${enabled[@]}"
for unit in "${enabled[@]}"; do
    printf '%s: ' "$unit"
    systemctl is-active "$unit"
done
