#!/opt/leafhft-rec/venv/bin/python
"""The two checksum-aware S3 operations used by the recorder offloader."""

from datetime import date, datetime
import json
import sys


def parse(argv):
    operations = {
        "put-object": {"--bucket", "--key", "--body", "--checksum-algorithm",
                       "--checksum-sha256", "--output"},
        "head-object": {"--bucket", "--key", "--checksum-mode", "--output"},
    }
    if len(argv) < 2 or argv[0] != "s3api" or argv[1] not in operations:
        raise ValueError("expected s3api put-object or head-object")
    op = argv[1]
    values = {}
    tail = argv[2:]
    if len(tail) % 2:
        raise ValueError("missing flag value")
    for flag, value in zip(tail[::2], tail[1::2]):
        if flag not in operations[op] or flag in values:
            raise ValueError("unknown or duplicate flag: " + flag)
        if not value or value.startswith("--"):
            raise ValueError("missing flag value: " + flag)
        values[flag] = value
    if set(values) != operations[op]:
        raise ValueError("missing required flags")
    if values["--output"] != "json":
        raise ValueError("output must be json")
    if not values["--key"].startswith("recorder/") or values["--key"] == "recorder/":
        raise ValueError("key must be within recorder/")
    if op == "put-object" and values["--checksum-algorithm"] != "SHA256":
        raise ValueError("checksum algorithm must be SHA256")
    if op == "head-object" and values["--checksum-mode"] != "ENABLED":
        raise ValueError("checksum mode must be ENABLED")
    return op, values


def json_default(value):
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    raise TypeError("unsupported response value")


def main(argv=None):
    try:
        op, values = parse(sys.argv[1:] if argv is None else argv)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 2
    try:
        import boto3

        client = boto3.client("s3")
        common = {"Bucket": values["--bucket"], "Key": values["--key"]}
        if op == "put-object":
            with open(values["--body"], "rb") as body:
                response = client.put_object(**common, Body=body,
                                             ChecksumAlgorithm="SHA256",
                                             ChecksumSHA256=values["--checksum-sha256"])
        else:
            response = client.head_object(**common, ChecksumMode="ENABLED")
        print(json.dumps({k: v for k, v in response.items() if k != "ResponseMetadata"},
                         default=json_default))
        return 0
    except Exception as error:
        print(f"S3 operation failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
