#!/bin/bash
set -euo pipefail
exec /usr/bin/python3 - <<'PY'
from datetime import datetime, timezone
import fcntl
import json
from pathlib import Path
import re
import subprocess

tracking = subprocess.run(["chronyc", "tracking"], check=True, capture_output=True,
                          text=True, timeout=30).stdout
fields = dict(line.split(":", 1) for line in tracking.splitlines() if ":" in line)
fields = {k.strip(): v.strip() for k, v in fields.items()}
system = re.fullmatch(r"([0-9.eE+-]+) seconds (slow|fast) of NTP time", fields["System time"])
if system is None:
    raise ValueError("unrecognized chrony system offset")
offset = float(system[1]) * (-1 if system[2] == "slow" else 1)
record = {"utc": datetime.now(timezone.utc).isoformat(), "reference": fields["Reference ID"],
          "system_time_offset_s": offset, "last_offset_s": float(fields["Last offset"].split()[0])}
path = Path("/var/lib/leafhft-rec/runs/clock/chrony.jsonl")
path.parent.mkdir(parents=True, exist_ok=True)
with path.open("a", encoding="utf-8") as stream:
    fcntl.flock(stream, fcntl.LOCK_EX)
    stream.write(json.dumps(record, allow_nan=False) + "\n")
    stream.flush()
PY
